# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_crt_finance', defaultValue='${STORAGE_ACCT_crt_finance}', label='STORAGE_ACCT_crt_finance')
dbutils.widgets.text(name='STORAGE_ACCT_crt_partner_extracts', defaultValue='${STORAGE_ACCT_crt_partner_extracts}', label='STORAGE_ACCT_crt_partner_extracts')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='partner_extracts_crt_sa', defaultValue='${partner_extracts_crt_sa}', label='partner_extracts_crt_sa')
dbutils.widgets.text(name='misc_crt_sa', defaultValue='${misc_crt_sa}', label='misc_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
dbutils.widgets.text(name='digital_crt_sa', defaultValue='${digital_crt_sa}', label='digital_crt_sa')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_misc', defaultValue='${STORAGE_ACCT_crt_misc}', label='STORAGE_ACCT_crt_misc')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='finance_crt_sa', defaultValue='${finance_crt_sa}', label='finance_crt_sa')
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='hr_crt_sa', defaultValue='${hr_crt_sa}', label='hr_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS misc__process;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__ccpa;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__promotions;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__plan;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__prescriber;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS finance__fn_reports;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__lookup_codes;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__employee_performance;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_resp(
response_id BIGINT,
file_id BIGINT,
answer_num INT,
answer_num_other INT,
campaign_batch_nbr SMALLINT,
campaign_cd STRING,
campaign_id DECIMAL(19,0),
comment_1 STRING,
comment_2 STRING,
disposition_code DECIMAL(19,0),
number_contacted STRING,
question_num INT,
response_channel STRING,
response_desc STRING,
response_value STRING,
risk_score STRING,
site_location STRING,
store_nbr INT,
survey_id INT,
total_no_attempt SMALLINT,
create_dttm STRING,
update_dttm STRING,
response_direction_code DECIMAL(19,0),
response_phase_code DECIMAL(19,0),
response_dttm STRING,
contact_type_code STRING,
contact_sequence_code STRING,
offer_cd STRING,
treatment_cd STRING,
fill_sold_date STRING,
issue_id STRING,
issue_name STRING,
comm_id BIGINT,
comm_subject STRING,
comm_name STRING,
cell_code STRING,
msg_send_rslt_cd STRING,
mime_type_cd SMALLINT,
ebm_trigger_send_dttm STRING,
ebm_trigger_evt_id BIGINT,
orig_evt_ip_addr STRING,
msg_part_type_open_cd STRING,
redirect_link_name STRING,
dest_url_addr STRING,
evt_click_or_open_dttm STRING,
confirm_page_txn_id STRING,
confirm_page_txn_amt STRING,
confirm_page_info STRING,
preferred_lang_cd STRING,
final_call_attempt_start_dt STRING,
final_call_attempt_end_dt STRING,
call_transfer_start_dttm STRING,
call_transfer_answer_dttm STRING,
refill_due_date STRING,
barcode STRING,
register_nbr SMALLINT,
cntrl_treatmt_ind BIGINT)
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/campaign_resp'
PARTITIONED BY (
date_of_contact STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_resp_cust(
response_id DECIMAL(18,0),
address_1 STRING,
address_2 STRING,
age DECIMAL(3,0),
audience_id DECIMAL(18,0),
city STRING,
dob STRING,
email_address STRING,
first_name STRING,
gender_cd STRING,
last_name STRING,
middle_name STRING,
pat_id DECIMAL(16,0),
phone_1 STRING,
phone_2 STRING,
state STRING,
zip_4 STRING,
zip_5 STRING,
update_dttm STRING,
cust_id STRING,
rx_nbr DECIMAL(8,0),
call_duration DECIMAL(10,0),
me_id STRING,
drug_id INT,
generic_prod_id STRING,
src_cd STRING,
src_id_char STRING)
USING DELTA
LOCATION
'abfss://campaign-phi@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/campaign_resp_cust'
PARTITIONED BY (
create_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_resp_file(
file_id DECIMAL(18,0),
vendor_id DECIMAL(18,0),
file_received_dttm STRING,
response_file_name STRING,
create_dttm STRING,
update_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/campaign_resp_file'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_customer_extracts_activity(
cust_src_id STRING,
extract_info STRING,
create_dttm STRING)
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_customer_extracts_activity'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_email_rtd_log(
tkt_nbr STRING,
db_name STRING,
tbl_name STRING,
del_rec_cnt INT,
stat_cd STRING,
idh_update_dttm STRING)
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_email_rtd_log'
PARTITIONED BY (
idh_batch_id DECIMAL(18,0))""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.cmg_satr_eligibility(
pat_id DECIMAL(13,0),
rx_count INT,
str_nbr INT,
create_dt DATE,
fill_sold_dt DATE)
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/cmg_satr_eligibility'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.cmg_satr_eligibility_hist(
pat_id DECIMAL(13,0),
rx_count INT,
str_nbr INT,
create_dt DATE,
fill_sold_dt DATE)
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/cmg_satr_eligibility_hist'
PARTITIONED BY (
curr_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.icplus_status_update_har(
str_nbr INT,
bin_nbr STRING,
prcs_ctrl_nbr STRING,
store_npi_nbr STRING,
general_recipient_nbr STRING,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
other_payr_coverage_cd DECIMAL(2,0),
plan_group_nbr STRING,
plan_tot_paid_dlrs DECIMAL(8,2),
plan_return_cost_dlrs DECIMAL(8,2),
plan_return_fee_dlrs DECIMAL(8,2),
plan_return_copay_dlrs DECIMAL(8,2),
plan_return_tax_dlrs DECIMAL(8,2),
plan_ar_dlrs DECIMAL(8,2),
plan_submit_fee_dlrs DECIMAL(8,2),
basis_of_reimb_detrm STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
third_party_plan_id STRING,
claim_ref_nbr STRING,
del_adjud_cd STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
plan_type STRING,
contract_name STRING,
plan_name STRING,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
cob_ind STRING,
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/icplus_status_update_har'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.account_links(
me_id BIGINT,
employee_id STRING,
employee_relationship STRING,
status STRING,
update_date STRING,
originator STRING,
email_status STRING,
email_status_date STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/account_links'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.activity_details(
activity_id BIGINT,
client_name STRING,
title STRING,
description STRING,
is_team_member_visible STRING,
activity_type STRING,
br_points BIGINT,
offer_code STRING,
affiliation_code STRING,
start_date STRING,
end_date STRING,
logo STRING,
action_text STRING,
action_type STRING,
action_navigation STRING,
confirm_text STRING,
completion_message STRING,
cta_text STRING,
cta_type STRING,
cta_navigation STRING,
insight_id STRING,
sort_rank STRING,
background_color STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/activity_details'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.activity_tracking(
me_id BIGINT,
employee_id STRING,
employee_relationship STRING,
activity_id BIGINT,
client_name STRING,
br_points BIGINT,
completion_date STRING,
email_status STRING,
email_status_date STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/activity_tracking'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.eligibility_archive(
employee_id STRING,
employee_relationship STRING,
employee_status STRING,
city STRING,
state STRING,
postal_code STRING,
date_of_birth STRING,
coverage_effective_date STRING,
medical_carrier STRING,
gender STRING,
plan_code STRING,
location_code STRING,
business_postal_code STRING,
operation_code STRING,
operation_desc STRING,
market_code STRING,
market_desc STRING,
district_code STRING,
district_desc STRING,
community_code STRING,
community_desc STRING,
coverage_category STRING,
company_code STRING,
ysa_funded STRING,
ysa_funded_date STRING,
employee_ssn STRING,
first_name STRING,
middle_initial STRING,
last_name STRING,
address_line1 STRING,
address_line2 STRING,
member_ssn STRING,
day_phone STRING,
evening_phone STRING,
cell_phone STRING,
email STRING,
dependent_children_seq STRING,
execution_time STRING,
file_name STRING,
action STRING,
insert_date STRING,
update_date STRING,
archive_action STRING,
archive_date STRING,
archive_action_file_name STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/eligibility_archive'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.eligibility_main(
employee_id STRING,
employee_relationship STRING,
employee_status STRING,
city STRING,
state STRING,
postal_code STRING,
date_of_birth STRING,
coverage_effective_date STRING,
medical_carrier STRING,
gender STRING,
plan_code STRING,
location_code STRING,
business_postal_code STRING,
operation_code STRING,
operation_desc STRING,
market_code STRING,
market_desc STRING,
district_code STRING,
district_desc STRING,
community_code STRING,
community_desc STRING,
coverage_category STRING,
company_code STRING,
ysa_funded STRING,
ysa_funded_date STRING,
employee_ssn STRING,
first_name STRING,
middle_initial STRING,
last_name STRING,
address_line1 STRING,
address_line2 STRING,
member_ssn STRING,
day_phone STRING,
evening_phone STRING,
cell_phone STRING,
email STRING,
dependent_children_seq STRING,
execution_time STRING,
file_name STRING,
action STRING,
insert_date STRING,
update_date STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/eligibility_main'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.smoking_questions(
question_id BIGINT,
question_text STRING,
question_type STRING,
options array<struct<optionId:string,optionText:string>>,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/smoking_questions'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.smoking_responses(
me_id BIGINT,
employee_id STRING,
employee_relationship STRING,
questions array<struct<questionId:string,optionId:string,additionalComments:string>>,
update_date STRING,
completion_date STRING,
job_id BIGINT,
job_status STRING,
email_status STRING,
email_status_date STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/smoking_responses'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS finance__fn_reports.mgr_rpt_agg_results(
fill_enter_month STRING,
tot_brand_awp_dlrs DECIMAL(18,2),
tot_generic_awp_dlrs DECIMAL(18,2),
tot_brand_cogs_dlrs DECIMAL(18,2),
tot_generic_cogs_dlrs DECIMAL(18,2),
tot_brand_fill_cnt INT,
tot_generic_fill_cnt INT,
brand_30_day_equiv DECIMAL(18,2),
generic_30_day_equiv DECIMAL(18,2))
USING DELTA
LOCATION
'abfss://fn-reports-bussnstv@{getArgument('finance_crt_sa')}.dfs.core.windows.net/mgr_rpt_agg_results'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS finance__fn_reports.mgr_rpt_tl_prescription_fill(
rx_nbr INT,
str_nbr INT,
rx_create_dt STRING,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
pat_id DECIMAL(13,0),
pbr_id DECIMAL(11,0),
pbr_loc_id SMALLINT,
fill_sold_dt STRING,
fill_sold_tm STRING,
fill_sold_dlrs DECIMAL(8,2),
fill_stat_cd STRING,
fill_qty_dspn DECIMAL(8,3),
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_awp_cost_dlrs DECIMAL(8,2),
fill_discnt_cd STRING,
fill_discnt_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
fill_label_price_dlrs DECIMAL(8,2),
fill_vrfy_user_id DECIMAL(9,0),
fill_vrfy_dt STRING,
fill_vrfy_tm STRING,
fill_type_cd STRING,
fill_del_dt STRING,
fill_del_tm STRING,
fill_data_review_user_id DECIMAL(9,0),
fill_data_review_dt STRING,
fill_data_review_tm STRING,
fill_enter_user_id DECIMAL(9,0),
fill_enter_dt STRING,
fill_enter_tm STRING,
fill_src_cd STRING,
fill_wac_dlrs DECIMAL(8,2),
filling_user_id DECIMAL(9,0),
filling_dt STRING,
filling_tm STRING,
fill_enter_str_nbr INT,
fill_review_str_nbr INT,
drug_id INT,
drug_name STRING,
dea_class_cd STRING,
refills_remain_cnt SMALLINT,
orig_refills_remain_when_enter STRING,
tot_amt_paid_ind STRING,
sims_upc STRING,
override_user_id DECIMAL(9,0),
override_dt STRING,
override_tm STRING,
relocate_fm_str_nbr INT,
create_user_id DECIMAL(9,0),
create_dttm STRING,
edw_batch_id DECIMAL(18,0),
update_user_id DECIMAL(9,0),
update_dttm STRING,
src_partition_nbr tinyint,
accept_consult_ind STRING,
cash_disc_sav_dlrs DECIMAL(8,2),
data_rev_spec_dttm STRING,
data_rev_spec_id DECIMAL(9,0),
data_rev_spec_str_nbr DECIMAL(5,0),
fax_image_id STRING,
fill_price_override_dlrs DECIMAL(8,2),
fill_rph_of_rec_id DECIMAL(9,0),
route_str_tech_inits STRING,
drug_whse_ind STRING,
lvl_of_svc_cd STRING,
rx_daw_ind STRING,
sourcing_ind STRING,
tip_rsn_for_svc_cd STRING,
fill_est_pick_up_dttm STRING,
cost_plus_fee_cd STRING,
edw_src_ind STRING,
celgene_md_auth_nbr STRING,
celgene_conf_nbr STRING,
ecom_ind STRING,
fill_print_dt STRING,
fill_print_tm STRING,
pat_language_pref_cd STRING,
fill_rebill_dt STRING,
fill_rebill_tm STRING,
fill_90day_ind STRING,
fill_90day_stat_cd STRING,
pat_pickup_id STRING,
pickup_id STRING,
pickup_first_name STRING,
pickup_last_name STRING,
pickup_id_state STRING,
pickup_id_cntry STRING,
pickup_id_qlfr STRING,
pickup_rel_cd STRING,
dspn_ndc STRING,
overstock_ind STRING,
medicare_d_nte_ind STRING,
medicare_d_print_dttm STRING,
partial_fill_tot_intended_qty DECIMAL(8,3),
triplicate_ser_nbr STRING,
delivery_cd STRING,
delivery_cmnts STRING,
fill_sold_local_dttm STRING,
orig_enter_dttm STRING,
pat_pickup_gov_auth STRING,
pat_pickup_id_qlfr STRING,
pat_pickup_relation_cd STRING,
route_str_rph_initials STRING,
src_sys_name STRING,
src_sys_txn_id STRING,
sys_stat_when_enter SMALLINT)
USING DELTA
LOCATION
'abfss://fn-reports-phi@{getArgument('finance_crt_sa')}.dfs.core.windows.net/mgr_rpt_tl_prescription_fill'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__lookup_codes.dim_cd(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_cd'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__lookup_codes.dim_cd_lookup(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_cd_lookup'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.dim_school(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://recruiting-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_school'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.employee_xref(
employee_id STRING,
biographical_created_by STRING,
biographical_created_on DATE,
legacy_emp_id STRING,
date_of_birth DATE,
biographical_last_modified_by STRING,
biographical_last_modified_on DATE,
biographical_portlet_name STRING,
biographical_update_flag STRING,
personal_start_date DATE,
birth_name STRING,
personal_created_by STRING,
personal_created_on DATE,
display_name STRING,
personal_end_date DATE,
first_name STRING,
first_name_alt1 STRING,
gender STRING,
personal_last_modified_by STRING,
personal_last_modified_on DATE,
last_name STRING,
last_name_alt1 STRING,
marital_status STRING,
middle_name_initials STRING,
middle_name_alt1 STRING,
nationality STRING,
native_preferred_language STRING,
salutation STRING,
suffix STRING,
personal_portlet_name STRING,
personal_update_flag STRING,
race_ethnicity STRING,
veteran_status STRING,
disability_status_from_form_cc305 STRING,
employees_name_given_in_form_cc305 STRING,
submission_date_of_form_cc305 DATE,
card_type STRING,
national_id_country STRING,
national_id_created_by STRING,
national_id_created_on DATE,
national_id_primary STRING,
national_id_last_modified_by STRING,
national_id_last_modified_on DATE,
national_id STRING,
national_id_portlet_name STRING,
national_id_update_flag STRING,
email_type STRING,
email_update_flag STRING,
email_created_by STRING,
email_created_on DATE,
email_address STRING,
email_is_primary STRING,
email_last_modified_by STRING,
email_last_modified_on DATE,
phone_type STRING,
phone_update_flag STRING,
phone_area_code STRING,
phone_country_code STRING,
phone_created_by STRING,
phone_created_on DATE,
phone_extension STRING,
phone_is_primary STRING,
phone_last_modified_by STRING,
phone_last_modified_on DATE,
phone_number STRING,
employment_hire_created_by STRING,
employment_hire_created_on DATE,
employment_hire_last_modified_by STRING,
employment_hire_last_modified_on DATE,
original_start_date DATE,
service_date DATE,
employment_hire_start_date DATE,
employment_hire_portlet_name STRING,
employment_hire_update_flag STRING,
requisition_number STRING,
recent_hire_date DATE,
legal_hold_date DATE,
employment_term_end_date DATE,
employment_term_created_by STRING,
employment_term_created_on DATE,
employment_term_event_reason STRING,
last_date_worked DATE,
employment_term_last_modified_by STRING,
employment_term_last_modified_on DATE,
new_main_employment_id STRING,
ok_to_rehire STRING,
employment_term_payroll_end_date DATE,
employment_term_portlet_name STRING,
employment_term_update_flag STRING,
date_of_death DATE,
manager_id STRING,
manager_ind STRING,
manager_first_name STRING,
manager_middle_name_initials STRING,
manager_last_name STRING,
avg_52wk_hrs STRING,
avg_12wk_hrs STRING,
bonus_amt DECIMAL(11,2),
bonus_year STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/employee_xref'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employee_performance.fct_emp_performance_details(
period_key BIGINT,
employee_id BIGINT,
performance_start_date DATE,
performance_approver_id BIGINT,
performance_approver_name STRING,
performance_end_date DATE,
performance_effective_date DATE,
performance_effective_end_date DATE,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id BIGINT,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key BIGINT,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date DATE,
performance_emp_ack_date DATE,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://employee-performance-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_emp_performance_details'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.fct_payroll_details(
emp_id DECIMAL(11,0),
cost_center STRING,
org_key STRING,
period_key BIGINT,
cd_key BIGINT,
pos STRING,
loc STRING,
business_unit STRING,
dept STRING,
division STRING,
job_title STRING,
line_of_business STRING,
loc_type_cd STRING,
charged_payr_loc_key STRING,
ck_nbr STRING,
prcs_dt STRING,
batch_dt STRING,
wek_nbr DECIMAL(2,0),
pos_start_dt STRING,
payr_amt DECIMAL(21,2),
flng_mrtl_stat STRING,
fed_exempt DECIMAL(2,0),
state_exempts DECIMAL(2,0),
slry_rate DECIMAL(11,2),
hrly_rate DECIMAL(11,6),
direct_dpst_ind STRING,
acct_cd DECIMAL(4,0),
register_type STRING,
bank_nbr DECIMAL(3,0),
comments STRING,
case_nbr STRING,
state_num_taxed DECIMAL(2,0),
city_num_taxed DECIMAL(2,0),
rsdnt_state_tax_ind STRING,
rsdnt_city_tax_ind STRING,
local_cd STRING,
state_cd DECIMAL(2,0),
corp_cd DECIMAL(4,0),
rsdnt_local_cd DECIMAL(4,0),
rsdnt_state_cd DECIMAL(2,0),
avg_52wk_hrs DECIMAL(5,2),
avg_12wk_hrs DECIMAL(5,2),
reglr_hrs DECIMAL(5,2),
overtime_hrs DECIMAL(5,2),
scheduled_hrs DECIMAL(5,2),
gross_pay_amt DECIMAL(11,2),
net_pay_amt DECIMAL(11,2),
taxable_gross_amt DECIMAL(11,2),
federal_gross_amt DECIMAL(11,2),
state_tax_amt DECIMAL(11,2),
local_tax_amt DECIMAL(11,2),
special_local_tax_amt DECIMAL(11,2),
fica_amt DECIMAL(11,2),
medicare_amt DECIMAL(11,2),
rsdnt_state_tax_amt DECIMAL(11,2),
rsdnt_local_tax_amt DECIMAL(11,2),
dsab_tax_amt DECIMAL(11,2),
overtime1_prem_pay_amt DECIMAL(11,2),
overtime2_prem_pay_amt DECIMAL(11,2),
calc_gross_earnings_amt DECIMAL(11,2),
neg_adj_amt DECIMAL(11,2),
tot_manual_earnings_amt DECIMAL(11,2),
corporate_medical_tax_amt DECIMAL(11,2),
employer_fica_tax_amt DECIMAL(11,2),
sut_tax_amt DECIMAL(11,2),
fut_tax_amt DECIMAL(11,2),
st_txbl_wages_amt DECIMAL(11,2),
earnings_hours DOUBLE,
emp_rec_id DECIMAL(15,0),
acc_year STRING,
acc_month STRING)
USING DELTA
LOCATION
'abfss://payroll-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_payroll_details'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.fct_scholarship_details(
school_key BIGINT,
payment_type STRING,
scholarship_award_type STRING,
period_key BIGINT,
application_id BIGINT,
employee_id BIGINT,
scholarship_desc STRING,
check_nbr STRING,
check_amt DECIMAL(7,2),
check_status STRING,
relinquishment_amt DECIMAL(9,2),
corp_monies_charged DECIMAL(7,2),
district_monies_charged DECIMAL(7,2),
budget_credit_amt DECIMAL(7,2),
location STRING,
position STRING,
status_date DATE,
cd_key BIGINT,
scholarship_year INT,
award_nbr INT,
scholarship_comments_ind STRING,
school_phone_nbr STRING,
expect_grad_year DATE,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date DATE)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_scholarship_details'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employee_performance.latest_performance_rating(
employee_id STRING,
latest_employee_acknowledgement STRING,
latest_location_when_rated STRING,
latest_mgr_acknowledgement STRING,
latest_overall_rating STRING,
latest_overall_rating_desc STRING,
latest_position_when_rated STRING,
latest_rating_period_start_date DATE,
latest_rating_period_end_date DATE,
latest_reviewed_by_employee_id STRING,
latest_reviewer_first_name STRING,
latest_reviewer_middle_name STRING,
latest_reviewer_last_name STRING,
latest_review_type STRING,
previous_year_overall_rating STRING,
previous_year_overall_rating_desc STRING,
previous_year_rating_period_start_date DATE,
previous_year_rating_period_end_date DATE,
previous_2_year_overall_rating STRING,
previous_2_year_overall_rating_desc STRING,
previous_2_year_rating_period_start_date DATE,
previous_2_year_rating_period_end_date DATE,
latest_promotion_rating STRING,
latest_promotion_rating_desc STRING)
USING DELTA
LOCATION
'abfss://employee-performance-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/latest_performance_rating'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue(
pat_id STRING,
records_ingest_dt STRING,
src_system STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/missing_demo_profiles_queue'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking(
pat_id STRING,
removal_dt STRING,
src_system STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/omnicell_missing_profile_tracking'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS misc__process.optum_otc_card_list_adhoc_history(
card_first_6_char STRING)
USING DELTA
LOCATION
'abfss://process-pii@{getArgument('misc_crt_sa')}.dfs.core.windows.net/optum_otc_card_list_adhoc_history'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__plan.optum_otc_upc_list(
upc STRING ,
upc_desc STRING ,
epos_nbr STRING ,
upc_nbr DECIMAL(14,0) ,
src_rec_begin_dt STRING ,
src_rec_end_dt STRING ,
edw_create_dttm STRING ,
edw_update_dttm STRING ,
edw_batch_id DECIMAL(18,0) )
USING DELTA
LOCATION
'abfss://plan-bussnstv@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/optum_otc_upc_list'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_acm_config(
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
history_seq_nbr SMALLINT,
history_seq_cd STRING)
USING DELTA
LOCATION
'abfss://patient-services-bussnstv@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_acm_config'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_gfd_work_sheet(
store_nbr INT,
rx_nbr INT,
pat_id DECIMAL(13,0),
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
image_id STRING,
drug_mme DECIMAL(5,1),
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr DECIMAL(10,0),
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_gfd_work_sheet'
PARTITIONED BY (
src_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl(
work_list_nbr DECIMAL(10,0),
pat_id DECIMAL(13,0),
rx_gfd_list_nbr SMALLINT,
rx_gfd_cd STRING,
rx_gfd_comments STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_gfd_work_sheet_dtl'
PARTITIONED BY (
src_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_madr_auto_rule_def(
rule_id DECIMAL(6,0),
rule_active_ind STRING,
rule_cat STRING,
rule_code STRING,
rule_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING)
USING DELTA
LOCATION
'abfss://patient-services-bussnstv@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_madr_auto_rule_def'
PARTITIONED BY (
history_seq_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_madr_auto_rules(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING)
USING DELTA
LOCATION
'abfss://patient-services-bussnstv@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_madr_auto_rules'
PARTITIONED BY (
history_seq_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_nucleus_verification(
str_nbr INT,
rx_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
fill_enter_dt STRING,
fill_enter_tm STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
rx_create_dt STRING,
edw_batch_id STRING,
edw_create_dttm STRING,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_nucleus_verification'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_resp_cust_encrypt(
response_id STRING ,
address_1 STRING ,
address_2 STRING ,
age STRING ,
audience_id STRING ,
city STRING ,
dob STRING ,
email_address STRING ,
first_name STRING ,
gender_cd STRING ,
last_name STRING ,
middle_name STRING ,
pat_id STRING ,
phone_1 STRING ,
phone_2 STRING ,
state STRING ,
zip_4 STRING ,
zip_5 STRING ,
update_dttm STRING ,
cust_id STRING ,
rx_nbr STRING ,
call_duration STRING ,
me_id STRING ,
drug_id STRING ,
generic_prod_id STRING ,
src_cd STRING ,
src_id_char STRING ,
create_dttm STRING )
USING DELTA
LOCATION
'abfss://campaign-phi@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/campaign_resp_cust_encrypt'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_attention_need(
phrm_pat_id DECIMAL(13,0),
str_nbr INT,
rx_nbr INT,
drug_name STRING,
pat_first_name STRING,
pat_last_name STRING,
next_fill_dt DATE,
first_appear_dt DATE,
idh_ingestion_time STRING,
src_file_dt DATE)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_attention_need'
PARTITIONED BY (
idh_ingestion_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_pat_cmg_eligibility_chk(
pharmacypatientid DECIMAL(13,0),
patientstatus STRING,
cmg_eligibility_flag STRING,
client_name STRING,
idh_ingestion_time STRING,
srcfiledate STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_pat_cmg_eligibility_chk'
PARTITIONED BY (
create_date STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_pat_event_log_before(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_month STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_pat_event_log_before'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_pat_event_log_current(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_pat_event_log_current'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_rx_event_log_before(
pharmacypatientid DECIMAL(13,0),
gpi_14 STRING,
rx_nbr_last INT,
clientstoreid_last INT,
fill_sold_dt_last STRING,
fill_days_supply_last INT,
filldisp_nbr_last INT,
refill_remaining_last INT,
copay DECIMAL(8,2),
script_alignment_status STRING,
clientstoreid INT,
sync_date STRING,
sync_cycle_length INT,
loginname STRING,
usergroup STRING,
dspn_fill_nbr SMALLINT,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_month STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_rx_event_log_before'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo(
sales_txn_id STRING,
txn_business_dt_promo DATE,
store_nbr_promo INT,
loc_store_sk INT,
register_nbr_promo INT,
txn_nbr_promo INT,
txn_ly_card_promo STRING,
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo_dtl(
sales_txn_id STRING,
line_seq_nbr_promo DECIMAL(38,0),
promo_seq_nbr INT,
promo_type STRING,
promo_adj_dlrs DECIMAL(8,2),
promo_plu DECIMAL(14,0),
promo_entry_mode STRING,
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_dtl'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo_item(
sales_txn_id STRING,
line_seq_nbr_promo DECIMAL(38,0),
upc_nbr DECIMAL(14,0),
prod_sk INT,
original_unit_price_dlrs_promo DECIMAL(8,2),
regular_ext_price_dlrs_promo DECIMAL(8,2),
qty_promo DECIMAL(8,0),
selling_price_dlrs_promo DECIMAL(8,2),
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_item'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_eit_incremental_extracts(
extract_name STRING,
edw_batch_id DECIMAL(18,0),
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_eit_incremental_extracts'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_master_patient_merge(
merged_fm_pat_id DECIMAL(13,0),
pat_id DECIMAL(13,0),
src_create_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_master_patient_merge'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_master_patient_merge_pat_event(
merged_fm_pat_id DECIMAL(13,0),
pat_id DECIMAL(13,0),
src_create_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_master_patient_merge_pat_event'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_master_patient_merge_pat_event_daily(
merged_fm_pat_id DECIMAL(13,0),
pat_id DECIMAL(13,0),
src_create_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_master_patient_merge_pat_event_daily'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_master_patient_merge_rx_event(
merged_fm_pat_id DECIMAL(13,0),
pat_id DECIMAL(13,0),
src_create_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_master_patient_merge_rx_event'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_master_patient_merge_work_order(
merged_fm_pat_id DECIMAL(13,0),
pat_id DECIMAL(13,0),
src_create_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_master_patient_merge_work_order'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patient_merge(
pharmacypatientid DECIMAL(13,0),
mergedpharmacypatientid DECIMAL(13,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patient_merge'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patient_metric_12_enrolled_days_final(
clientstoreid INT,
district_nbr INT,
area_nbr INT,
region_nbr INT,
operation_nbr INT,
average_enroll_days_90 INT,
average_enroll_days_30 INT)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patient_metric_12_enrolled_days_final'
PARTITIONED BY (
reporting_month INT)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patient_removal(
pharmacypatientid DECIMAL(13,0),
patientremovalreason STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patient_removal'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patient_removal_hist(
pharmacypatientid DECIMAL(13,0),
patientremovalreason STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patient_removal_hist'
PARTITIONED BY (
record_create_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patients_eligible(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patients_eligible'
PARTITIONED BY (
rpt_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patients_eligible_merge_update(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING,
rpt_month STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patients_eligible_merge_update'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_patients_eligible_post_process(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING,
rpt_month STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_patients_eligible_post_process'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current(
third_party_plan_id STRING,
plan_group_nbr STRING,
plan_type STRING,
ingestion_date STRING,
inc_ind STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_plan_inc_exc_current'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_current(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_current'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_current_adhoc(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_current_adhoc'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_daily(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_daily'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_daily_adhoc(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_daily_adhoc'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_monthly(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_monthly'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_previous(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_previous'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_previous_adhoc(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_demo_previous_adhoc'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx(
pharmacypatientid DECIMAL(13,0),
storencpdp STRING,
storenpi STRING,
prescriberid DECIMAL(11,0),
deanum STRING,
prescriberlastname STRING,
prescriberfirstname STRING,
prescribermiddlename STRING,
prescriberphonenum STRING,
prescriberfaxnum STRING,
rxnum INT,
fillnum SMALLINT,
productidqualifier STRING,
productid STRING,
medicationname STRING,
dispensedquantity DECIMAL(8,3),
dayssupply SMALLINT,
sigtext STRING,
writtendate STRING,
filldate STRING,
solddate STRING,
originalrefillsauthorized SMALLINT,
rxstatus STRING,
copayamount DECIMAL(8,2),
bin STRING,
pcn STRING,
groupid STRING,
memberid STRING,
clientstoreid INT,
autofillprogram STRING,
dawcode STRING,
originalfilldate STRING,
originalquantity DECIMAL(8,3),
refillsremaining SMALLINT,
expirationdate STRING,
ndc STRING,
brandgenericflag STRING,
paymenttype STRING,
partialfill STRING,
originaldayssupply SMALLINT,
writtenquantity DECIMAL(8,3),
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_rx'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx_closed_stat_daily(
pharmacypatientid DECIMAL(13,0),
clientstoreid INT,
rxnum INT,
productidqualifier STRING,
productid STRING,
filldate STRING,
rxstatus STRING,
closereasoncd STRING,
closelogdttm STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_rx_closed_stat_daily'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx_daily(
pharmacypatientid DECIMAL(13,0),
storencpdp STRING,
storenpi STRING,
prescriberid DECIMAL(11,0),
deanum STRING,
prescriberlastname STRING,
prescriberfirstname STRING,
prescribermiddlename STRING,
prescriberphonenum STRING,
prescriberfaxnum STRING,
rxnum INT,
fillnum SMALLINT,
productidqualifier STRING,
productid STRING,
medicationname STRING,
dispensedquantity DECIMAL(8,3),
dayssupply SMALLINT,
sigtext STRING,
writtendate STRING,
filldate STRING,
solddate STRING,
originalrefillsauthorized SMALLINT,
rxstatus STRING,
copayamount DECIMAL(8,2),
bin STRING,
pcn STRING,
groupid STRING,
memberid STRING,
clientstoreid INT,
autofillprogram STRING,
dawcode STRING,
originalfilldate STRING,
originalquantity DECIMAL(8,3),
refillsremaining SMALLINT,
expirationdate STRING,
ndc STRING,
brandgenericflag STRING,
paymenttype STRING,
partialfill STRING,
originaldayssupply SMALLINT,
writtenquantity DECIMAL(8,3),
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_pmap_patient_rx_daily'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_previous_eligible_patients_phase2(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_previous_eligible_patients_phase2'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_store_update_list(
clientstoreid INT,
name STRING,
displayname STRING,
openflag INT,
storencpdpid STRING,
storenpi STRING,
storeaddress1 STRING,
storeaddress2 STRING,
storecity STRING,
storestateprov STRING,
storepostalcode STRING,
storelatitude STRING,
storelongitude STRING,
storephonenum STRING,
storefaxnum STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_store_update_list'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.electronic_ad_bulletin(
event_type STRING,
event_sequence_nbr STRING,
event_version_type_code STRING,
event_version_seq_nbr STRING,
market_code STRING,
ad_evt_type_cd STRING ,
event_start_date STRING,
event_end_date STRING,
ad_wk_begin_dt STRING,
dutch_door STRING,
page STRING,
layout INT,
abc STRING,
wic STRING,
photo_avail STRING,
basic_ind STRING,
percent_of_storescarrying STRING,
description STRING,
primary_wic_indicator STRING,
spot_type STRING,
plu STRING,
limit STRING,
ad_retail STRING,
ad_sur STRING,
w_o_c_mult_rtl STRING,
us_l14_lo_mc_hisur_l14_lo_mc_hi STRING,
dr_l14_lo_mc_hisur_l14_lo_mc_hi STRING,
ak_l14_lo_mc_hisur_l14_lo_mc_hi STRING,
hi_l14_lo_mc_hisur_l14_lo_mc_hi STRING,
pr_l14_lo_mc_hisur_l14_lo_mc_hi STRING,
ao_lty_type STRING,
ao_lty_math_table STRING,
ao_lty_offer_code STRING,
lty_offer_cap STRING,
farr STRING,
fsi_type STRING,
comments STRING,
invoice_cost STRING,
deptl_cost STRING,
distr_cost STRING,
us_code STRING,
explode STRING,
srl_number STRING,
item_type STRING,
item_sts STRING,
item_to_picture STRING,
offer_type STRING,
sd_ind STRING,
scandown STRING,
vendor STRING,
cm_id STRING,
cm STRING,
dmm STRING,
gmm STRING,
distr_nbr_typ_stsgrp_nbr_fcst STRING,
spotnumber STRING,
upc STRING,
vendorname STRING,
vendor_point_rate STRING,
display STRING,
pr_item_dept_cost STRING,
event_key STRING,
orig_layout INT,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://promotions-pii@{getArgument('retail_crt_sa')}.dfs.core.windows.net/electronic_ad_bulletin'
PARTITIONED BY (
eab_filename STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.mobile_hit_transaction(
accept_language STRING,
browser STRING,
browser_type STRING,
browser_height DECIMAL(32,0),
browser_width DECIMAL(32,0),
campaign STRING,
c_color STRING,
channel STRING,
click_action STRING,
click_action_type BIGINT,
click_context STRING,
click_context_type BIGINT,
click_sourceid DECIMAL(32,0),
click_tag STRING,
code_ver STRING,
color STRING,
connection_type STRING,
cookies STRING,
country STRING,
ct_connect_type STRING,
currency STRING,
curr_factor STRING,
curr_rate DECIMAL(24,12),
cust_hit_time_gmt DECIMAL(32,0),
cust_visid STRING,
daily_visitor BIGINT,
date_time STRING,
domain STRING,
duplicated_from STRING,
duplicate_events STRING,
duplicate_purchase BIGINT,
evar1 STRING,
evar2 STRING,
evar3 STRING,
evar4 STRING,
evar5 STRING,
evar6 STRING,
evar7 STRING,
evar8 STRING,
evar9 STRING,
evar10 STRING,
evar11 STRING,
evar12 STRING,
evar13 STRING,
evar14 STRING,
evar15 STRING,
evar16 STRING,
evar17 STRING,
evar18 STRING,
evar19 STRING,
evar20 STRING,
evar21 STRING,
evar22 STRING,
evar23 STRING,
evar24 STRING,
evar25 STRING,
evar26 STRING,
evar27 STRING,
evar28 STRING,
evar29 STRING,
evar30 STRING,
evar31 STRING,
evar32 STRING,
evar33 STRING,
evar34 STRING,
evar35 STRING,
evar36 STRING,
evar37 STRING,
evar38 STRING,
evar39 STRING,
evar40 STRING,
evar41 STRING,
evar42 STRING,
evar43 STRING,
evar44 STRING,
evar45 STRING,
evar46 STRING,
evar47 STRING,
evar48 STRING,
evar49 STRING,
evar50 STRING,
evar51 STRING,
evar52 STRING,
evar53 STRING,
evar54 STRING,
evar55 STRING,
evar56 STRING,
evar57 STRING,
evar58 STRING,
evar59 STRING,
evar60 STRING,
evar61 STRING,
evar62 STRING,
evar63 STRING,
evar64 STRING,
evar65 STRING,
evar66 STRING,
evar67 STRING,
evar68 STRING,
evar69 STRING,
evar70 STRING,
evar71 STRING,
evar72 STRING,
evar73 STRING,
evar74 STRING,
evar75 STRING,
event_list STRING,
exclude_hit BIGINT,
first_hit_pagename STRING,
first_hit_page_url STRING,
first_hit_referrer STRING,
first_hit_time_gmt DECIMAL(32,0),
geo_city STRING,
geo_country STRING,
geo_dma DECIMAL(32,0),
geo_region STRING,
geo_zip STRING,
hier1 STRING,
hier2 STRING,
hier3 STRING,
hier4 STRING,
hier5 STRING,
hitid_high STRING,
hitid_low STRING,
hit_source BIGINT,
hit_time_gmt DECIMAL(32,0),
homepage STRING,
hourly_visitor BIGINT,
ip STRING,
ip2 STRING,
java_enabled STRING,
javascript STRING,
j_jscript STRING,
language STRING,
last_hit_time_gmt DECIMAL(32,0),
last_purchase_num DECIMAL(32,0),
last_purchase_time_gmt DECIMAL(32,0),
mobile_id DECIMAL(32,0),
monthly_visitor BIGINT,
mvvar1 STRING,
mvvar2 STRING,
mvvar3 STRING,
namespace STRING,
new_visit BIGINT,
os STRING,
page_event STRING,
page_event_var1 STRING,
page_event_var2 STRING,
page_event_var3 STRING,
pagename STRING,
page_type STRING,
page_url STRING,
paid_search BIGINT,
partner_plugins STRING,
persistent_cookie STRING,
plugins STRING,
post_browser_height DECIMAL(32,0),
post_browser_width DECIMAL(32,0),
post_campaign STRING,
post_channel STRING,
post_cookies STRING,
post_currency STRING,
post_cust_hit_time_gmt DECIMAL(32,0),
post_cust_visid BIGINT,
post_evar1 STRING,
post_evar2 STRING,
post_evar3 STRING,
post_evar4 STRING,
post_evar5 STRING,
post_evar6 STRING,
post_evar7 STRING,
post_evar8 STRING,
post_evar9 STRING,
post_evar10 STRING,
post_evar11 STRING,
post_evar12 STRING,
post_evar13 STRING,
post_evar14 STRING,
post_evar15 STRING,
post_evar16 STRING,
post_evar17 STRING,
post_evar18 STRING,
post_evar19 STRING,
post_evar20 STRING,
post_evar21 STRING,
post_evar22 STRING,
post_evar23 STRING,
post_evar24 STRING,
post_evar25 STRING,
post_evar26 STRING,
post_evar27 STRING,
post_evar28 STRING,
post_evar29 STRING,
post_evar30 STRING,
post_evar31 STRING,
post_evar32 STRING,
post_evar33 STRING,
post_evar34 STRING,
post_evar35 STRING,
post_evar36 STRING,
post_evar37 STRING,
post_evar38 STRING,
post_evar39 STRING,
post_evar40 STRING,
post_evar41 STRING,
post_evar42 STRING,
post_evar43 STRING,
post_evar44 STRING,
post_evar45 STRING,
post_evar46 STRING,
post_evar47 STRING,
post_evar48 STRING,
post_evar49 STRING,
post_evar50 STRING,
post_evar51 STRING,
post_evar52 STRING,
post_evar53 STRING,
post_evar54 STRING,
post_evar55 STRING,
post_evar56 STRING,
post_evar57 STRING,
post_evar58 STRING,
post_evar59 STRING,
post_evar60 STRING,
post_evar61 STRING,
post_evar62 STRING,
post_evar63 STRING,
post_evar64 STRING,
post_evar65 STRING,
post_evar66 STRING,
post_evar67 STRING,
post_evar68 STRING,
post_evar69 STRING,
post_evar70 STRING,
post_evar71 STRING,
post_evar72 STRING,
post_evar73 STRING,
post_evar74 STRING,
post_evar75 STRING,
post_event_list STRING,
post_hier1 STRING,
post_hier2 STRING,
post_hier3 STRING,
post_hier4 STRING,
post_hier5 STRING,
post_java_enabled STRING,
post_keywords STRING,
post_mvvar1 STRING,
post_mvvar2 STRING,
post_mvvar3 STRING,
post_page_event STRING,
post_page_event_var1 STRING,
post_page_event_var2 STRING,
post_page_event_var3 STRING,
post_pagename STRING,
post_pagename_no_url STRING,
post_page_type STRING,
post_page_url STRING,
post_partner_plugins STRING,
post_persistent_cookie STRING,
post_product_list STRING,
post_prop1 STRING,
post_prop2 STRING,
post_prop3 STRING,
post_prop4 STRING,
post_prop5 STRING,
post_prop6 STRING,
post_prop7 STRING,
post_prop8 STRING,
post_prop9 STRING,
post_prop10 STRING,
post_prop11 STRING,
post_prop12 STRING,
post_prop13 STRING,
post_prop14 STRING,
post_prop15 STRING,
post_prop16 STRING,
post_prop17 STRING,
post_prop18 STRING,
post_prop19 STRING,
post_prop20 STRING,
post_prop21 STRING,
post_prop22 STRING,
post_prop23 STRING,
post_prop24 STRING,
post_prop25 STRING,
post_prop26 STRING,
post_prop27 STRING,
post_prop28 STRING,
post_prop29 STRING,
post_prop30 STRING,
post_prop31 STRING,
post_prop32 STRING,
post_prop33 STRING,
post_prop34 STRING,
post_prop35 STRING,
post_prop36 STRING,
post_prop37 STRING,
post_prop38 STRING,
post_prop39 STRING,
post_prop40 STRING,
post_prop41 STRING,
post_prop42 STRING,
post_prop43 STRING,
post_prop44 STRING,
post_prop45 STRING,
post_prop46 STRING,
post_prop47 STRING,
post_prop48 STRING,
post_prop49 STRING,
post_prop50 STRING,
post_prop51 STRING,
post_prop52 STRING,
post_prop53 STRING,
post_prop54 STRING,
post_prop55 STRING,
post_prop56 STRING,
post_prop57 STRING,
post_prop58 STRING,
post_prop59 STRING,
post_prop60 STRING,
post_prop61 STRING,
post_prop62 STRING,
post_prop63 STRING,
post_prop64 STRING,
post_prop65 STRING,
post_prop66 STRING,
post_prop67 STRING,
post_prop68 STRING,
post_prop69 STRING,
post_prop70 STRING,
post_prop71 STRING,
post_prop72 STRING,
post_prop73 STRING,
post_prop74 STRING,
post_prop75 STRING,
post_purchaseid STRING,
post_referrer STRING,
post_search_engine STRING,
post_state STRING,
post_survey STRING,
post_tnt STRING,
post_transactionid STRING,
post_t_time_info STRING,
post_visid_high STRING,
post_visid_low STRING,
post_visid_type BIGINT,
post_zip STRING,
p_plugins STRING,
prev_page DECIMAL(32,0),
product_list STRING,
product_merchandising STRING,
prop1 STRING,
prop2 STRING,
prop3 STRING,
prop4 STRING,
prop5 STRING,
prop6 STRING,
prop7 STRING,
prop8 STRING,
prop9 STRING,
prop10 STRING,
prop11 STRING,
prop12 STRING,
prop13 STRING,
prop14 STRING,
prop15 STRING,
prop16 STRING,
prop17 STRING,
prop18 STRING,
prop19 STRING,
prop20 STRING,
prop21 STRING,
prop22 STRING,
prop23 STRING,
prop24 STRING,
prop25 STRING,
prop26 STRING,
prop27 STRING,
prop28 STRING,
prop29 STRING,
prop30 STRING,
prop31 STRING,
prop32 STRING,
prop33 STRING,
prop34 STRING,
prop35 STRING,
prop36 STRING,
prop37 STRING,
prop38 STRING,
prop39 STRING,
prop40 STRING,
prop41 STRING,
prop42 STRING,
prop43 STRING,
prop44 STRING,
prop45 STRING,
prop46 STRING,
prop47 STRING,
prop48 STRING,
prop49 STRING,
prop50 STRING,
prop51 STRING,
prop52 STRING,
prop53 STRING,
prop54 STRING,
prop55 STRING,
prop56 STRING,
prop57 STRING,
prop58 STRING,
prop59 STRING,
prop60 STRING,
prop61 STRING,
prop62 STRING,
prop63 STRING,
prop64 STRING,
prop65 STRING,
prop66 STRING,
prop67 STRING,
prop68 STRING,
prop69 STRING,
prop70 STRING,
prop71 STRING,
prop72 STRING,
prop73 STRING,
prop74 STRING,
prop75 STRING,
purchaseid STRING,
quarterly_visitor BIGINT,
ref_domain STRING,
referrer STRING,
ref_type STRING,
resolution STRING,
sampled_hit STRING,
search_engine STRING,
search_page_num DECIMAL(32,0),
secondary_hit BIGINT,
service STRING,
sourceid DECIMAL(32,0),
s_resolution STRING,
state STRING,
stats_server STRING,
tnt STRING,
tnt_post_vista STRING,
transactionid STRING,
truncated_hit STRING,
t_time_info STRING,
ua_color STRING,
ua_os STRING,
ua_pixels STRING,
user_agent STRING,
user_hash DECIMAL(32,0),
userid DECIMAL(32,0),
username STRING,
user_server STRING,
va_closer_detail STRING,
va_closer_id BIGINT,
va_finder_detail STRING,
va_finder_id BIGINT,
va_instance_event BIGINT,
va_new_engagement BIGINT,
visid_high STRING,
visid_low STRING,
visid_new STRING,
visid_timestamp DECIMAL(32,0),
visid_type BIGINT,
visit_keywords STRING,
visit_num DECIMAL(32,0),
visit_page_num DECIMAL(32,0),
visit_referrer STRING,
visit_search_engine DECIMAL(32,0),
visit_start_pagename STRING,
visit_start_page_url STRING,
visit_start_time_gmt DECIMAL(32,0),
weekly_visitor BIGINT,
yearly_visitor BIGINT,
zip STRING,
mobileaction STRING,
mobileappid STRING,
mobilecampaigncontent STRING,
mobilecampaignmedium STRING,
mobilecampaignname STRING,
mobilecampaignsource STRING,
mobilecampaignterm STRING,
mobiledayofweek STRING,
mobiledayssincefirstuse STRING,
mobiledayssincelastuse STRING,
mobiledevice STRING,
mobilehourofday STRING,
mobileinstalldate STRING,
mobilelaunchnumber STRING,
mobileltv STRING,
mobileosversion STRING,
mobileresolution STRING,
podecimalofdecimalerest STRING,
podecimalofdecimalerestdistance STRING,
post_mobileaction STRING,
post_mobileappid STRING,
post_mobilecampaigncontent STRING,
post_mobilecampaignmedium STRING,
post_mobilecampaignname STRING,
post_mobilecampaignsource STRING,
post_mobilecampaignterm STRING,
post_mobiledayofweek STRING,
post_mobiledayssincefirstuse STRING,
post_mobiledayssincelastuse STRING,
post_mobiledevice STRING,
post_mobilehourofday STRING,
post_mobileinstalldate STRING,
post_mobilelaunchnumber STRING,
post_mobileltv STRING,
post_mobileosversion STRING,
post_mobileresolution STRING,
post_podecimalofdecimalerest STRING,
post_podecimalofdecimalerestdistance STRING,
socialassettrackingcode STRING,
socialauthor STRING,
socialaveragesentiment STRING,
socialcontentprovider STRING,
sociallanguage STRING,
sociallatlong STRING,
sociallink STRING,
socialproperty STRING,
socialterm STRING,
socialtermslist STRING,
post_socialassettrackingcode STRING,
post_socialauthor STRING,
post_socialaveragesentiment STRING,
post_socialcontentprovider STRING,
post_sociallanguage STRING,
post_sociallatlong STRING,
post_sociallink STRING,
post_socialproperty STRING,
post_socialterm STRING,
post_socialtermslist STRING,
video STRING,
videoad STRING,
videoadinpod STRING,
videoadplayername STRING,
videoadpod STRING,
videochannel STRING,
videocontenttype STRING,
videopath STRING,
videoplayername STRING,
videosegment STRING,
post_video STRING,
post_videoad STRING,
post_videoadinpod STRING,
post_videoadplayername STRING,
post_videoadpod STRING,
post_videochannel STRING,
post_videocontenttype STRING,
post_videopath STRING,
post_videoplayername STRING,
post_videosegment STRING)
USING DELTA
LOCATION
'abfss://ecom-pii@{getArgument('digital_crt_sa')}.dfs.core.windows.net/mobile_hit_transaction'
PARTITIONED BY (
hit_date STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.pos_transaction(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
dim_loc_store_sk BIGINT,
loc_store_sk BIGINT,
store_nbr INT,
dim_loc_mgrs_sk BIGINT,
loyalty_dim_cust_sk BIGINT,
loyalty_cust_sk BIGINT,
loyalty_eid_dim_cust_sk BIGINT,
loyalty_mid_dim_cust_sk BIGINT,
prog_type_cd STRING,
prog_acct_nbr STRING,
prog_cust_id STRING,
src_cust_id STRING,
txn_end_dttm STRING,
ord_stat_cd STRING,
fulfillment_type_cd STRING,
originating_str_nbr INT,
fulfillment_str_nbr INT,
pick_up_at_str_nbr INT,
bypass_reason_cd SMALLINT,
ord_entry_channel_cd STRING,
ord_desc STRING,
promise_dt STRING,
promise_tm STRING,
rx_reqst_fill_dt STRING,
rx_reqst_fill_tm STRING,
txn_type STRING,
ord_ship_dt STRING,
ord_ship_tm STRING,
return_stat_desc STRING,
prcs_ind STRING,
prcs_immediate_ind STRING,
nbr_of_images INT,
tot_image_sz_kb DECIMAL(10,2),
pcp_ord_id STRING,
vndr_cust_id STRING,
vndr_ord_id STRING,
commision_vndr_cd STRING,
photo_origin_id STRING,
spcl_ord_desc STRING,
orig_inv_dlrs DECIMAL(8,2),
prod_cost_dlrs DECIMAL(8,2),
shipping_price_dlrs DECIMAL(8,2),
in_str_ord_ind STRING,
share_ord_ind STRING,
aarp_ind STRING,
ord_return_ind STRING,
pre_click_ord_ind STRING,
held_ord_ind STRING,
lens_ord_ind STRING,
self_pay_ind STRING,
xref_line_item_seq_nbr SMALLINT,
generic_ord_ind STRING,
fsa_ind STRING,
cashier_nbr SMALLINT,
cashier_employee_id DECIMAL(10,0),
mgr_employee_id DECIMAL(10,0),
create_id STRING,
loyalty_employee_id DECIMAL(10,0),
exchange_cd STRING,
offline_txn_ind STRING,
price_verify_cd STRING,
register_nbr SMALLINT,
store_register_sk BIGINT,
rfn_value STRING,
next_gen_rfn_value STRING,
training_txn_ind STRING,
txn_incomplete_ind STRING,
txn_nbr SMALLINT,
txn_start_dttm STRING,
txn_tot_discnt_line_cnt SMALLINT,
txn_tot_discnt_line_qty SMALLINT,
txn_tot_discnt_return_dlrs DECIMAL(8,2),
txn_tot_discnt_sale_dlrs DECIMAL(8,2),
txn_tot_dlrs DECIMAL(8,2),
txn_tot_line_cnt SMALLINT,
txn_tot_line_voided_cnt SMALLINT,
txn_tot_line_voids_cnt SMALLINT,
txn_tot_mfg_coup_dlrs DECIMAL(8,2),
txn_tot_net_qty DECIMAL(5,0),
txn_tot_price_vrfy_line_cnt SMALLINT,
txn_tot_reg_line_cnt SMALLINT,
txn_tot_reg_line_qty SMALLINT,
txn_tot_reg_return_dlrs DECIMAL(8,2),
txn_tot_reg_sale_dlrs DECIMAL(8,2),
txn_tot_return_dlrs DECIMAL(8,2),
txn_tot_return_line_cnt SMALLINT,
txn_tot_rx_line_cnt SMALLINT,
txn_tot_tax_dlrs DECIMAL(8,2),
txn_tot_tndr_cnt SMALLINT,
txn_tot_tndr_dlrs DECIMAL(8,2),
txn_tot_void_dlrs DECIMAL(8,2),
txn_tot_wag_coup_dlrs DECIMAL(8,2),
discnt_mode_cd STRING,
affiliate_discnt_cd STRING,
post_void_status_cd STRING,
return_reason_cd SMALLINT,
return_auth_nbr STRING,
vndr_refund_id DECIMAL(19,0),
shipping_price_discnt_dlrs DECIMAL(8,2),
suggest_tax_return_dlrs DECIMAL(8,2),
actl_tax_return_dlrs DECIMAL(8,2),
suggest_ship_return_dlrs DECIMAL(8,2),
actl_ship_return_dlrs DECIMAL(8,2),
paypal_return_dlrs DECIMAL(8,2),
authenticator_id STRING,
credit_card_return_dlrs DECIMAL(8,2),
gift_card_return_dlrs DECIMAL(8,2),
loyalty_enrl_ind STRING,
aarp_opt_out_ind STRING,
identification_method STRING,
price_button_evt_ind STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-pii@{getArgument('retail_crt_sa')}.dfs.core.windows.net/pos_transaction'
PARTITIONED BY (
sales_txn_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.pos_transaction_cost_adj(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
adj_cd STRING,
adj_dlrs DECIMAL(8,2),
loyalty_adj_dlrs DECIMAL(8,2),
cost_type_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/pos_transaction_cost_adj'
PARTITIONED BY (
sales_txn_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.pos_transaction_cost_dtl(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
cost_type_cd STRING,
cost_dlrs DECIMAL(8,2),
cost_src_type_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/pos_transaction_cost_dtl'
PARTITIONED BY (
sales_txn_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.pos_transaction_detail(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
ord_item_id STRING,
dim_prod_sk BIGINT,
prod_price_chng_sk BIGINT,
prod_sk BIGINT,
src_sys_prod_id_1 STRING,
src_sys_prod_id_2 STRING,
src_sys_prod_id_3 STRING,
src_sys_prod_id_4 STRING,
upc_nbr DECIMAL(14,0),
loyalty_dim_cust_sk BIGINT,
loyalty_cust_sk BIGINT,
loyalty_eid_dim_cust_sk BIGINT,
loyalty_mid_dim_cust_sk BIGINT,
prog_type_cd STRING,
prog_acct_nbr STRING,
prog_cust_id STRING,
upc_desc STRING,
txn_type STRING,
tax_type_cd STRING,
ecomm_order_ind STRING,
tax_exempt_ind STRING,
tax_exempt_id STRING,
fsa_item_ind STRING,
rx_not_on_ic_ind STRING,
price_verify_ind STRING,
return_ind STRING,
sale_ind STRING,
walgreen_brand_ind STRING,
prod_id INT,
rx_nbr DECIMAL(8,0),
item_unit_price_dlrs DECIMAL(8,2),
original_price_dlrs DECIMAL(8,2),
selling_price_dlrs DECIMAL(8,2),
unit_qty DECIMAL(18,0),
item_void_cd STRING,
ecomm_order_nbr DECIMAL(12,0),
over_age_cd STRING,
birth_date STRING,
wag_coup_cd STRING,
mfg_coup_cd STRING,
discnt_cd STRING,
rx_type_cd STRING,
price_modify_cd STRING,
upc_hardkey_cd STRING,
dept_hardkey_cd STRING,
regstr_key_nbr SMALLINT,
payout_acct_nbr SMALLINT,
photo_env_nbr DECIMAL(11,0),
photo_print_cnt SMALLINT,
item_sz DECIMAL(7,2),
discnt_applicable_qty DECIMAL(8,0),
discnt_qualify_qty DECIMAL(8,0),
rx_fill_nbr INT,
xfer_rx_nbr INT,
rx_str_nbr INT,
rx_tranfer_to_str_nbr INT,
list_price_dlrs DECIMAL(8,2),
raw_tot_price_dlrs DECIMAL(8,2),
sale_price_dlrs DECIMAL(8,2),
discnt_dlrs DECIMAL(8,2),
prod_cost_dlrs DECIMAL(8,2),
price_before_discnt_dlrs DECIMAL(8,2),
coupon_savings_dlrs DECIMAL(8,2),
aarp_ind STRING,
availability_ind STRING,
price_override_reason STRING,
eye_side STRING,
item_stat STRING,
item_stat_detail STRING,
orig_ord_wic DECIMAL(10,0),
est_price_dlrs DECIMAL(8,2),
ready_price_dlrs DECIMAL(8,2),
ready_dt STRING,
ready_tm STRING,
sold_dt STRING,
sold_tm STRING,
voiding_dlrs DECIMAL(7,2),
disposable_item_desc STRING,
gqm_prod_id STRING,
wic DECIMAL(18,0),
return_shipment_req_ind STRING,
return_reason_desc STRING,
return_stat_desc STRING,
prod_discnt_tot_dlrs DECIMAL(8,2),
prod_price_before_discnt_dlrs DECIMAL(8,2),
return_bonus_dlrs DECIMAL(8,2),
qty_rcvd DECIMAL(18,0),
qty_to_return DECIMAL(18,0),
loyalty_elig_ind STRING,
price_cd STRING,
loyalty_redeem_elig_ind STRING,
rx_elig_ind STRING,
rx_partial_fill_cd_ind STRING,
rx_primary_plan_gov_funded_ind STRING,
rx_cob_plan_gov_funded_ind STRING,
rx_30_to_90_day_ind STRING,
line_item_dtl_nbr DECIMAL(38,0),
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-phi@{getArgument('retail_crt_sa')}.dfs.core.windows.net/pos_transaction_detail'
PARTITIONED BY (
sales_txn_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.pos_transaction_otuc(
sales_txn_id STRING,
sales_txn_dt STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
line_item_dtl_nbr DECIMAL(38,0),
plu_nbr DECIMAL(4,0),
one_tm_use_coupon_barcode STRING,
entry_mode_cd STRING,
basket_lvl_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/pos_transaction_otuc'
PARTITIONED BY (
sales_txn_year STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.refill_reminder_info(
mongo_id STRING,
record_id STRING,
pat_id STRING,
me_id STRING,
first_name STRING,
last_name STRING,
customer_type STRING,
br_ind STRING,
campaign_code STRING,
audience_id STRING,
treatment_code STRING,
gpi14 STRING,
create_dttm STRING,
update_dttm STRING,
preference_mode STRING,
phi_ind STRING,
planned_contact_dttm STRING,
upi_code STRING,
channel_code STRING,
timezone_cd STRING,
email struct<emailId:string,psmSent:struct<status:string,sentDTTM:string>,order:struct<submitDTTM:string,channel:string,submitStatus:string,orderReference:string>,dispositionCode:string>,
email_id STRING,
psm_sent_status STRING,
psm_sent_dttm STRING,
submit_dttm STRING,
order_channel STRING,
order_submit_status STRING,
order_reference STRING,
email_disposition_code STRING,
control_group STRING,
reminder_template STRING,
language_pref STRING,
rx_details array<struct<rxNumber:string,drugName:string,drugId:string,groupDrugName:string,lastFillDate:string,ninetyDayInd:string,prescriberFName:string,prescriberLName:string,quantity:string,store:struct<brand:string,number:string>>>,
rx_number STRING,
drug_name STRING,
drug_id STRING,
group_drug_name STRING,
last_fill_date STRING,
ninety_day_ind STRING,
prescriber_first_name STRING,
prescriber_last_name STRING,
quantity STRING,
store_brand STRING,
store_number STRING,
phone_numbers array<struct<phoneNumber:string,sms:struct<status:string,sentDTTM:string>,dispositionCd:string,dispositionDTTM:string>>,
phone_number STRING,
phone_status STRING,
sent_dttm STRING,
disposition_cd STRING,
disposition_dttm STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/refill_reminder_info'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.sms_message_details(
messagedirection STRING,
message_id STRING,
client_id STRING,
client_name STRING,
carrier_id STRING,
carrier_name STRING,
short_code STRING,
country_code STRING,
phonenumber STRING,
campaigntype_id STRING,
campaigntypename STRING,
trigger_id STRING,
campaign_id STRING,
campaignname STRING,
clienttag STRING,
messagetext STRING,
status_id STRING,
statusdescription STRING,
detailedstatusid STRING,
detailedstatusdescription STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://ecom-pii@{getArgument('digital_crt_sa')}.dfs.core.windows.net/sms_message_details'
PARTITIONED BY (
submitted_date STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_rx_order_overview(
rx_ord_ref_num STRING,
rx_ord_dttm TIMESTAMP,
rx_ord_owner_me_id STRING,
rx_ord_store_num STRING,
rx_ord_channel_cd STRING,
rx_ord_channel_detail_cd STRING,
rx_ord_submit_status_cd STRING,
rx_ord_process_count STRING,
rx_ord_gq_submit_dttm TIMESTAMP,
rx_ord_site_cd STRING)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_rx_order_overview'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_rx_order_retail(
rx_r_id STRING,
rx_r_ref_num STRING,
rx_r_dttm TIMESTAMP,
rx_r_doc_fname STRING,
rx_r_doc_lname STRING,
rx_r_xfr_rx_num STRING,
rx_r_xfr_store_num STRING,
rx_r_val_app_cd STRING,
rx_r_est_price STRING,
rx_r_submit_q STRING,
rx_r_submit_q_stat STRING,
rx_r_fill_nbr STRING,
rx_r_req_fill_dttm TIMESTAMP,
rx_r_90_day_ind STRING,
rx_r_update_dttm TIMESTAMP,
rx_r_generic_ind STRING,
rx_r_sold_dttm TIMESTAMP,
rx_r_fill_num_disp STRING,
rx_r_ready_price STRING,
rx_r_doc_area_cd STRING,
rx_r_doc_phone_nbr STRING,
rx_r_xfr_pharm_name STRING,
rx_r_xfr_pharm_area_cd STRING,
rx_r_xfr_pharm_phone_nbr STRING,
rx_r_dtl_id STRING,
rx_r_delivery_ind STRING,
rx_r_delivery_comments STRING,
rx_r_addl_cmnts STRING,
rx_r_transfer_rx_num STRING,
drug_id STRING)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_rx_order_retail'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_wep_rx_info(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_wep_rx_info'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_addr_comm_chanl(
pat_id DECIMAL(13,0),
first_name STRING,
middle_initial STRING,
last_name STRING,
last_name_suffix STRING,
last_name_soundex STRING,
gndr_cd STRING,
brth_dt STRING,
head_of_household_pat_id DECIMAL(13,0),
head_of_household_relation_cd STRING,
pat_discnt_cd STRING,
pat_clinic_med_id STRING,
snap_cap_pref_ind STRING,
generic_substn_pref_ind STRING,
therapeutic_substn_pref_ind STRING,
mail_list_pref_ind STRING,
preferred_lang_cd STRING,
purged_rx_ind STRING,
pet_pat_ind STRING,
pat_mail_svc_id STRING,
pat_cmnt STRING,
pat_create_str_nbr INT,
deceased_ind STRING,
pat_allergy_hlth_type_cd STRING,
wc_ind STRING,
pat_signature_ind STRING,
pat_internet_register_ind STRING,
pat_extrernal_rx_otc_item_ind STRING,
orig_register_dttm STRING,
hipaa_signature_capture_ind STRING,
hipaa_signature_capture_dt STRING,
hipaa_signature_capture_str_nb INT,
buyout_pat_ind STRING,
hipaa_acknowlege_ltr_ind STRING,
lock_ind STRING,
lock_str_nbr INT,
lock_user_id DECIMAL(9,0),
lock_dttm STRING,
smoking_ind STRING,
pregnancy_ind STRING,
pregnancy_due_dt STRING,
pat_brochure_ind STRING,
homecare_ind STRING,
bal_hold_ind STRING,
spclty_ind STRING,
bill_addr_ind STRING,
link_cd STRING,
pat_allergy_hlth_inq_ind STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
pet_type STRING,
phone_cntc_pref_ind STRING,
no_phone_reason_cd STRING,
primary_phone_pref_cd STRING,
src_update_dttm STRING,
auto_refill_pref_str_nbr DECIMAL(5,0),
pat_auto_refill_ind STRING,
pat_pickup_gov_auth_id STRING,
pat_pickup_qlfr_type STRING,
pat_pickup_relation_cd STRING,
pat_primary_care_pbr_id DECIMAL(11,0),
pat_primary_care_pbr_loc_id DECIMAL(2,0),
pat_residence_cd DECIMAL(2,0),
pat_unmerge_vrfy_ind STRING,
pat_twin_ind STRING,
pat_90day_pref_ind STRING,
pat_90day_pref_dttm STRING,
addr_seq_nbr SMALLINT,
addr_line STRING,
city STRING,
state_cd STRING,
zip_cd_5 STRING,
zip_cd_4 STRING,
history_seq_nbr SMALLINT,
pat_addr_src_eff_dt STRING,
pat_addr_src_eff_tm STRING,
src_end_dt STRING,
src_end_tm STRING,
history_seq_cd STRING,
comm_cntc_tm_cd STRING,
phone_type_cd STRING,
comm_channel_val STRING,
txt_msg_ind STRING,
txt_msg_carr STRING,
addr_type_cd STRING,
channel_type_cd STRING,
pat_comm_src_eff_dt STRING,
pat_comm_src_eff_tm STRING)
USING DELTA
LOCATION
'abfss://patient-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/patient_addr_comm_chanl'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__prescriber.prescriber_pres_location(
pbr_id DECIMAL(11,0),
stat_cd STRING,
dea_nbr STRING,
dea_suffix STRING,
pbr_spin_nbr STRING,
first_name STRING,
middle_initial STRING,
middle_name STRING,
last_name STRING,
last_name_suffix STRING,
last_name_soundex STRING,
pbr_type_cd STRING,
tax_id STRING,
hc_reform_nbr STRING,
company_cd STRING,
prv_stat_cd STRING,
prof_stat_cd STRING,
gndr_cd STRING,
brth_dt STRING,
dea_expire_dt STRING,
upin STRING,
pbr_npi DECIMAL(10,0),
src_eff_dt STRING,
src_eff_tm STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_end_dt STRING,
src_end_tm STRING,
edw_batch_id DECIMAL(18,0),
history_seq_nbr SMALLINT,
history_seq_cd STRING,
pbr_loc_id SMALLINT,
pbr_internal_group_id STRING,
pbr_loc_internal_group_id STRING,
replace_by_pbr_id DECIMAL(11,0),
replace_by_pbr_loc_id SMALLINT,
pbr_frgn_license_nbr STRING,
phone_area_cd STRING,
phone_nbr STRING,
fax_area_cd STRING,
fax_nbr STRING,
addr_line_1 STRING,
addr_line_2 STRING,
city STRING,
state_cd STRING,
zip_cd_5 STRING,
zip_cd_4 STRING,
cmnt STRING,
last_actv_dttm STRING,
e_prescribe_ind STRING,
e_prescribe_hub_nbr SMALLINT,
clinic_site_nbr INT,
clinic_id STRING,
phone_cmnt STRING,
chng_req_ind STRING,
pbr_src_cd STRING,
ndc_pbr_loc_id SMALLINT,
ndc_pbr_id DECIMAL(11,0),
pbr_app_cd STRING,
loc_history_seq_nbr SMALLINT,
loc_history_seq_cd STRING)
USING DELTA
LOCATION
'abfss://prescriber-pii@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescriber_pres_location'""")
# COMMAND ----------
migration_data=[{"release": "8.0.2", "scripts": ["D.1.1.crt.partner_extracts__pharmacy_healthcare.sql", "D.12.1.crt.digital__ecom.sql", "D.16.1.crt.retail__retail_sales.sql", "D.17.1.crt.misc__process.sql", "D.2.1.crt.retail__ccpa.sql", "D.3.1.crt.retail__promotions.sql", "D.32.1.crt.pharmacy_healthcare__plan.sql", "D.33.1.crt.pharmacy_healthcare__patient.sql", "D.34.1.crt.pharmacy_healthcare__prescriber.sql", "D.5.1.crt.marketing__campaign.sql", "D.57.1.crt.hr__compensation_benefits.sql", "D.58.1.crt.finance__fn_reports.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "D.60.1.crt.hr__payroll.sql", "D.62.1.crt.hr__lookup_codes.sql", "D.63.1.crt.hr__recruiting.sql", "D.64.1.crt.hr__employee_performance.sql", "T.1030.1.crt.campaign_resp.sql", "T.1033.1.crt.campaign_resp_cust.sql", "T.1039.1.crt.campaign_resp_file.sql", "T.1065.1.crt.ccpa_customer_extracts_activity.sql", "T.1067.1.crt.ccpa_email_rtd_log.sql", "T.1081.1.crt.cmg_satr_eligibility.sql", "T.1082.1.crt.cmg_satr_eligibility_hist.sql", "T.1392.1.crt.icplus_status_update_har.sql", "T.14377.1.crt.account_links.sql", "T.14378.1.crt.activity_details.sql", "T.14379.1.crt.activity_tracking.sql", "T.14380.1.crt.eligibility_archive.sql", "T.14381.1.crt.eligibility_main.sql", "T.14382.1.crt.smoking_questions.sql", "T.14384.1.crt.smoking_responses.sql", "T.14401.1.crt.mgr_rpt_agg_results.sql", "T.14402.1.crt.mgr_rpt_tl_prescription_fill.sql", "T.14446.1.crt.dim_cd.sql", "T.14448.1.crt.dim_cd_lookup.sql", "T.14450.1.crt.dim_school.sql", "T.14454.1.crt.employee_xref.sql", "T.14466.1.crt.fct_emp_performance_details.sql", "T.14467.1.crt.fct_payroll_details.sql", "T.14468.1.crt.fct_scholarship_details.sql", "T.14492.1.crt.latest_performance_rating.sql", "T.1500.1.crt.missing_demo_profiles_queue.sql", "T.1541.1.crt.omnicell_missing_profile_tracking.sql", "T.1545.1.crt.optum_otc_card_list_adhoc_history.sql", "T.1547.1.crt.optum_otc_upc_list.sql", "T.1625.1.crt.prescription_acm_config.sql", "T.1698.1.crt.prescription_gfd_work_sheet.sql", "T.1699.1.crt.prescription_gfd_work_sheet_dtl.sql", "T.1706.1.crt.prescription_madr_auto_rule_def.sql", "T.1707.1.crt.prescription_madr_auto_rules.sql", "T.1709.1.crt.prescription_nucleus_verification.sql", "T.176.1.crt.campaign_resp_cust_encrypt.sql", "T.1766.1.crt.sa_attention_need.sql", "T.1767.1.crt.sa_pat_cmg_eligibility_chk.sql", "T.1773.1.crt.sa_pat_event_log_before.sql", "T.1776.1.crt.sa_pat_event_log_current.sql", "T.1784.1.crt.sa_rx_event_log_before.sql", "T.1798.1.crt.sales_transaction_promo.sql", "T.1799.1.crt.sales_transaction_promo_dtl.sql", "T.1800.1.crt.sales_transaction_promo_item.sql", "T.1807.1.crt.satr_eit_incremental_extracts.sql", "T.1810.1.crt.satr_master_patient_merge.sql", "T.1811.1.crt.satr_master_patient_merge_pat_event.sql", "T.1812.1.crt.satr_master_patient_merge_pat_event_daily.sql", "T.1813.1.crt.satr_master_patient_merge_rx_event.sql", "T.1814.1.crt.satr_master_patient_merge_work_order.sql", "T.1815.1.crt.satr_patient_merge.sql", "T.1816.1.crt.satr_patient_metric_12_enrolled_days_final.sql", "T.1818.1.crt.satr_patient_removal.sql", "T.1819.1.crt.satr_patient_removal_hist.sql", "T.1820.1.crt.satr_patients_eligible.sql", "T.1823.1.crt.satr_patients_eligible_merge_update.sql", "T.1824.1.crt.satr_patients_eligible_post_process.sql", "T.1825.1.crt.satr_plan_inc_exc_current.sql", "T.1826.1.crt.satr_pmap_patient_demo_current.sql", "T.1827.1.crt.satr_pmap_patient_demo_current_adhoc.sql", "T.1828.1.crt.satr_pmap_patient_demo_daily.sql", "T.1829.1.crt.satr_pmap_patient_demo_daily_adhoc.sql", "T.1830.1.crt.satr_pmap_patient_demo_monthly.sql", "T.1831.1.crt.satr_pmap_patient_demo_previous.sql", "T.1832.1.crt.satr_pmap_patient_demo_previous_adhoc.sql", "T.1833.1.crt.satr_pmap_patient_rx.sql", "T.1835.1.crt.satr_pmap_patient_rx_closed_stat_daily.sql", "T.1836.1.crt.satr_pmap_patient_rx_daily.sql", "T.1838.1.crt.satr_previous_eligible_patients_phase2.sql", "T.1839.1.crt.satr_store_update_list.sql", "T.253.1.crt.electronic_ad_bulletin.sql", "T.279.1.crt.mobile_hit_transaction.sql", "T.284.1.crt.pos_transaction.sql", "T.291.1.crt.pos_transaction_cost_adj.sql", "T.295.1.crt.pos_transaction_cost_dtl.sql", "T.297.1.crt.pos_transaction_detail.sql", "T.313.1.crt.pos_transaction_otuc.sql", "T.340.1.crt.refill_reminder_info.sql", "T.379.1.crt.sms_message_details.sql", "T.403.1.crt.www_rx_order_overview.sql", "T.404.1.crt.www_rx_order_retail.sql", "T.415.1.crt.www_wep_rx_info.sql", "T.6299.1.crt.patient_addr_comm_chanl.sql", "T.6300.1.crt.prescriber_pres_location.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.0.2", "table_id": "T.1030.1", "table_name": "campaign_resp", "table_schema": "marketing__campaign.campaign_resp", "table_legacy_schema": "dae_cooked.campaign_resp", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_resp", "table_partition": "\n  date_of_contact STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1033.1", "table_name": "campaign_resp_cust", "table_schema": "marketing__campaign.campaign_resp_cust", "table_legacy_schema": "dae_cooked.campaign_resp_cust", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_resp_cust", "table_partition": "\n  create_dt STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1039.1", "table_name": "campaign_resp_file", "table_schema": "marketing__campaign.campaign_resp_file", "table_legacy_schema": "dae_cooked.campaign_resp_file", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_resp_file", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1065.1", "table_name": "ccpa_customer_extracts_activity", "table_schema": "retail__ccpa.ccpa_customer_extracts_activity", "table_legacy_schema": "dae_cooked.ccpa_customer_extracts_activity", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_customer_extracts_activity", "table_partition": "", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1067.1", "table_name": "ccpa_email_rtd_log", "table_schema": "retail__ccpa.ccpa_email_rtd_log", "table_legacy_schema": "dae_cooked.ccpa_email_rtd_log", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_email_rtd_log", "table_partition": "\n  idh_batch_id DECIMAL(18,0", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1081.1", "table_name": "cmg_satr_eligibility", "table_schema": "marketing__campaign.cmg_satr_eligibility", "table_legacy_schema": "dae_cooked.cmg_satr_eligibility", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.cmg_satr_eligibility", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1082.1", "table_name": "cmg_satr_eligibility_hist", "table_schema": "marketing__campaign.cmg_satr_eligibility_hist", "table_legacy_schema": "dae_cooked.cmg_satr_eligibility_hist", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.cmg_satr_eligibility_hist", "table_partition": "\n  curr_mnth STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1392.1", "table_name": "icplus_status_update_har", "table_schema": "pharmacy_healthcare__patient_services.icplus_status_update_har", "table_legacy_schema": "dae_cooked.icplus_status_update_har", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.icplus_status_update_har", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14377.1", "table_name": "account_links", "table_schema": "hr__compensation_benefits.account_links", "table_legacy_schema": "emp_wlns.account_links", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.account_links", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14378.1", "table_name": "activity_details", "table_schema": "hr__compensation_benefits.activity_details", "table_legacy_schema": "emp_wlns.activity_details", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.activity_details", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14379.1", "table_name": "activity_tracking", "table_schema": "hr__compensation_benefits.activity_tracking", "table_legacy_schema": "emp_wlns.activity_tracking", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.activity_tracking", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14380.1", "table_name": "eligibility_archive", "table_schema": "hr__compensation_benefits.eligibility_archive", "table_legacy_schema": "emp_wlns.eligibility_archive", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.eligibility_archive", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14381.1", "table_name": "eligibility_main", "table_schema": "hr__compensation_benefits.eligibility_main", "table_legacy_schema": "emp_wlns.eligibility_main", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.eligibility_main", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14382.1", "table_name": "smoking_questions", "table_schema": "hr__compensation_benefits.smoking_questions", "table_legacy_schema": "emp_wlns.smoking_questions", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.smoking_questions", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14384.1", "table_name": "smoking_responses", "table_schema": "hr__compensation_benefits.smoking_responses", "table_legacy_schema": "emp_wlns.smoking_responses", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.smoking_responses", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14401.1", "table_name": "mgr_rpt_agg_results", "table_schema": "finance__fn_reports.mgr_rpt_agg_results", "table_legacy_schema": "fin_cooked.mgr_rpt_agg_results", "table_domain": "finance", "table_subdomain": "fn_reports", "table_location": "finance__fn_reports.mgr_rpt_agg_results", "table_partition": "", "table_db": "finance__fn_reports", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14402.1", "table_name": "mgr_rpt_tl_prescription_fill", "table_schema": "finance__fn_reports.mgr_rpt_tl_prescription_fill", "table_legacy_schema": "fin_cooked.mgr_rpt_tl_prescription_fill", "table_domain": "finance", "table_subdomain": "fn_reports", "table_location": "finance__fn_reports.mgr_rpt_tl_prescription_fill", "table_partition": "", "table_db": "finance__fn_reports", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14446.1", "table_name": "dim_cd", "table_schema": "hr__lookup_codes.dim_cd", "table_legacy_schema": "hr_cooked.dim_cd", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "hr__lookup_codes.dim_cd", "table_partition": "", "table_db": "hr__lookup_codes", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14448.1", "table_name": "dim_cd_lookup", "table_schema": "hr__lookup_codes.dim_cd_lookup", "table_legacy_schema": "hr_cooked.dim_cd_lookup", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "hr__lookup_codes.dim_cd_lookup", "table_partition": "", "table_db": "hr__lookup_codes", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14450.1", "table_name": "dim_school", "table_schema": "hr__recruiting.dim_school", "table_legacy_schema": "hr_cooked.dim_school", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.dim_school", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14454.1", "table_name": "employee_xref", "table_schema": "hr__compensation_benefits.employee_xref", "table_legacy_schema": "hr_cooked.employee_xref", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.employee_xref", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14466.1", "table_name": "fct_emp_performance_details", "table_schema": "hr__employee_performance.fct_emp_performance_details", "table_legacy_schema": "hr_cooked.fct_emp_performance_details", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "hr__employee_performance.fct_emp_performance_details", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "hr__employee_performance", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14467.1", "table_name": "fct_payroll_details", "table_schema": "hr__payroll.fct_payroll_details", "table_legacy_schema": "hr_cooked.fct_payroll_details", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.fct_payroll_details", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14468.1", "table_name": "fct_scholarship_details", "table_schema": "hr__compensation_benefits.fct_scholarship_details", "table_legacy_schema": "hr_cooked.fct_scholarship_details", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.fct_scholarship_details", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.14492.1", "table_name": "latest_performance_rating", "table_schema": "hr__employee_performance.latest_performance_rating", "table_legacy_schema": "hr_cooked.latest_performance_rating", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "hr__employee_performance.latest_performance_rating", "table_partition": "", "table_db": "hr__employee_performance", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1500.1", "table_name": "missing_demo_profiles_queue", "table_schema": "partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue", "table_legacy_schema": "dae_cooked.missing_demo_profiles_queue", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1541.1", "table_name": "omnicell_missing_profile_tracking", "table_schema": "partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking", "table_legacy_schema": "dae_cooked.omnicell_missing_profile_tracking", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1545.1", "table_name": "optum_otc_card_list_adhoc_history", "table_schema": "misc__process.optum_otc_card_list_adhoc_history", "table_legacy_schema": "dae_cooked.optum_otc_card_list_adhoc_history", "table_domain": "misc", "table_subdomain": "process", "table_location": "misc__process.optum_otc_card_list_adhoc_history", "table_partition": "", "table_db": "misc__process", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1547.1", "table_name": "optum_otc_upc_list", "table_schema": "pharmacy_healthcare__plan.optum_otc_upc_list", "table_legacy_schema": "dae_cooked.optum_otc_upc_list", "table_domain": "pharmacy_healthcare", "table_subdomain": "plan", "table_location": "pharmacy_healthcare__plan.optum_otc_upc_list", "table_partition": "", "table_db": "pharmacy_healthcare__plan", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1625.1", "table_name": "prescription_acm_config", "table_schema": "pharmacy_healthcare__patient_services.prescription_acm_config", "table_legacy_schema": "dae_cooked.prescription_acm_config", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_acm_config", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1698.1", "table_name": "prescription_gfd_work_sheet", "table_schema": "pharmacy_healthcare__patient_services.prescription_gfd_work_sheet", "table_legacy_schema": "dae_cooked.prescription_gfd_work_sheet", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_gfd_work_sheet", "table_partition": "\n  src_create_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1699.1", "table_name": "prescription_gfd_work_sheet_dtl", "table_schema": "pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl", "table_legacy_schema": "dae_cooked.prescription_gfd_work_sheet_dtl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl", "table_partition": "\n  src_create_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1706.1", "table_name": "prescription_madr_auto_rule_def", "table_schema": "pharmacy_healthcare__patient_services.prescription_madr_auto_rule_def", "table_legacy_schema": "dae_cooked.prescription_madr_auto_rule_def", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_madr_auto_rule_def", "table_partition": "\n  history_seq_cd STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1707.1", "table_name": "prescription_madr_auto_rules", "table_schema": "pharmacy_healthcare__patient_services.prescription_madr_auto_rules", "table_legacy_schema": "dae_cooked.prescription_madr_auto_rules", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_madr_auto_rules", "table_partition": "\n  history_seq_cd STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1709.1", "table_name": "prescription_nucleus_verification", "table_schema": "pharmacy_healthcare__patient_services.prescription_nucleus_verification", "table_legacy_schema": "dae_cooked.prescription_nucleus_verification", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_nucleus_verification", "table_partition": "\n  fill_enter_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.176.1", "table_name": "campaign_resp_cust_encrypt", "table_schema": "marketing__campaign.campaign_resp_cust_encrypt", "table_legacy_schema": "acapdb.campaign_resp_cust_encrypt", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_resp_cust_encrypt", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1766.1", "table_name": "sa_attention_need", "table_schema": "partner_extracts__pharmacy_healthcare.sa_attention_need", "table_legacy_schema": "dae_cooked.sa_attention_need", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_attention_need", "table_partition": "\n  idh_ingestion_dt STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1767.1", "table_name": "sa_pat_cmg_eligibility_chk", "table_schema": "partner_extracts__pharmacy_healthcare.sa_pat_cmg_eligibility_chk", "table_legacy_schema": "dae_cooked.sa_pat_cmg_eligibility_chk", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_pat_cmg_eligibility_chk", "table_partition": "\n  create_date STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1773.1", "table_name": "sa_pat_event_log_before", "table_schema": "partner_extracts__pharmacy_healthcare.sa_pat_event_log_before", "table_legacy_schema": "dae_cooked.sa_pat_event_log_before", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_pat_event_log_before", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1776.1", "table_name": "sa_pat_event_log_current", "table_schema": "partner_extracts__pharmacy_healthcare.sa_pat_event_log_current", "table_legacy_schema": "dae_cooked.sa_pat_event_log_current", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_pat_event_log_current", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1784.1", "table_name": "sa_rx_event_log_before", "table_schema": "partner_extracts__pharmacy_healthcare.sa_rx_event_log_before", "table_legacy_schema": "dae_cooked.sa_rx_event_log_before", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_rx_event_log_before", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1798.1", "table_name": "sales_transaction_promo", "table_schema": "retail__retail_sales.sales_transaction_promo", "table_legacy_schema": "dae_cooked.sales_transaction_promo", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1799.1", "table_name": "sales_transaction_promo_dtl", "table_schema": "retail__retail_sales.sales_transaction_promo_dtl", "table_legacy_schema": "dae_cooked.sales_transaction_promo_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo_dtl", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1800.1", "table_name": "sales_transaction_promo_item", "table_schema": "retail__retail_sales.sales_transaction_promo_item", "table_legacy_schema": "dae_cooked.sales_transaction_promo_item", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo_item", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1807.1", "table_name": "satr_eit_incremental_extracts", "table_schema": "partner_extracts__pharmacy_healthcare.satr_eit_incremental_extracts", "table_legacy_schema": "dae_cooked.satr_eit_incremental_extracts", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_eit_incremental_extracts", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1810.1", "table_name": "satr_master_patient_merge", "table_schema": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge", "table_legacy_schema": "dae_cooked.satr_master_patient_merge", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1811.1", "table_name": "satr_master_patient_merge_pat_event", "table_schema": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_pat_event", "table_legacy_schema": "dae_cooked.satr_master_patient_merge_pat_event", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_pat_event", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1812.1", "table_name": "satr_master_patient_merge_pat_event_daily", "table_schema": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_pat_event_daily", "table_legacy_schema": "dae_cooked.satr_master_patient_merge_pat_event_daily", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_pat_event_daily", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1813.1", "table_name": "satr_master_patient_merge_rx_event", "table_schema": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_rx_event", "table_legacy_schema": "dae_cooked.satr_master_patient_merge_rx_event", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_rx_event", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1814.1", "table_name": "satr_master_patient_merge_work_order", "table_schema": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_work_order", "table_legacy_schema": "dae_cooked.satr_master_patient_merge_work_order", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_master_patient_merge_work_order", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1815.1", "table_name": "satr_patient_merge", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patient_merge", "table_legacy_schema": "dae_cooked.satr_patient_merge", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patient_merge", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1816.1", "table_name": "satr_patient_metric_12_enrolled_days_final", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patient_metric_12_enrolled_days_final", "table_legacy_schema": "dae_cooked.satr_patient_metric_12_enrolled_days_final", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patient_metric_12_enrolled_days_final", "table_partition": "\n  reporting_month INT", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1818.1", "table_name": "satr_patient_removal", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patient_removal", "table_legacy_schema": "dae_cooked.satr_patient_removal", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patient_removal", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1819.1", "table_name": "satr_patient_removal_hist", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patient_removal_hist", "table_legacy_schema": "dae_cooked.satr_patient_removal_hist", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patient_removal_hist", "table_partition": "\n  record_create_dt STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1820.1", "table_name": "satr_patients_eligible", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patients_eligible", "table_legacy_schema": "dae_cooked.satr_patients_eligible", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patients_eligible", "table_partition": "\n  rpt_month STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1823.1", "table_name": "satr_patients_eligible_merge_update", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patients_eligible_merge_update", "table_legacy_schema": "dae_cooked.satr_patients_eligible_merge_update", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patients_eligible_merge_update", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1824.1", "table_name": "satr_patients_eligible_post_process", "table_schema": "partner_extracts__pharmacy_healthcare.satr_patients_eligible_post_process", "table_legacy_schema": "dae_cooked.satr_patients_eligible_post_process", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_patients_eligible_post_process", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1825.1", "table_name": "satr_plan_inc_exc_current", "table_schema": "partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current", "table_legacy_schema": "dae_cooked.satr_plan_inc_exc_current", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1826.1", "table_name": "satr_pmap_patient_demo_current", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_current", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_current", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_current", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1827.1", "table_name": "satr_pmap_patient_demo_current_adhoc", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_current_adhoc", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_current_adhoc", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_current_adhoc", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1828.1", "table_name": "satr_pmap_patient_demo_daily", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_daily", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_daily", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_daily", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1829.1", "table_name": "satr_pmap_patient_demo_daily_adhoc", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_daily_adhoc", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_daily_adhoc", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_daily_adhoc", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1830.1", "table_name": "satr_pmap_patient_demo_monthly", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_monthly", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_monthly", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_monthly", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1831.1", "table_name": "satr_pmap_patient_demo_previous", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_previous", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_previous", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_previous", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1832.1", "table_name": "satr_pmap_patient_demo_previous_adhoc", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_previous_adhoc", "table_legacy_schema": "dae_cooked.satr_pmap_patient_demo_previous_adhoc", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_previous_adhoc", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1833.1", "table_name": "satr_pmap_patient_rx", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx", "table_legacy_schema": "dae_cooked.satr_pmap_patient_rx", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1835.1", "table_name": "satr_pmap_patient_rx_closed_stat_daily", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx_closed_stat_daily", "table_legacy_schema": "dae_cooked.satr_pmap_patient_rx_closed_stat_daily", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx_closed_stat_daily", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1836.1", "table_name": "satr_pmap_patient_rx_daily", "table_schema": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx_daily", "table_legacy_schema": "dae_cooked.satr_pmap_patient_rx_daily", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_pmap_patient_rx_daily", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1838.1", "table_name": "satr_previous_eligible_patients_phase2", "table_schema": "partner_extracts__pharmacy_healthcare.satr_previous_eligible_patients_phase2", "table_legacy_schema": "dae_cooked.satr_previous_eligible_patients_phase2", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_previous_eligible_patients_phase2", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.1839.1", "table_name": "satr_store_update_list", "table_schema": "partner_extracts__pharmacy_healthcare.satr_store_update_list", "table_legacy_schema": "dae_cooked.satr_store_update_list", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_store_update_list", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.253.1", "table_name": "electronic_ad_bulletin", "table_schema": "retail__promotions.electronic_ad_bulletin", "table_legacy_schema": "acapdb.electronic_ad_bulletin", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.electronic_ad_bulletin", "table_partition": "\n  eab_filename STRING", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.279.1", "table_name": "mobile_hit_transaction", "table_schema": "digital__ecom.mobile_hit_transaction", "table_legacy_schema": "acapdb.mobile_hit_transaction", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.mobile_hit_transaction", "table_partition": "\n  hit_date STRING", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.284.1", "table_name": "pos_transaction", "table_schema": "retail__retail_sales.pos_transaction", "table_legacy_schema": "acapdb.pos_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.pos_transaction", "table_partition": "\n  sales_txn_dt STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.291.1", "table_name": "pos_transaction_cost_adj", "table_schema": "retail__retail_sales.pos_transaction_cost_adj", "table_legacy_schema": "acapdb.pos_transaction_cost_adj", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.pos_transaction_cost_adj", "table_partition": "\n  sales_txn_dt STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.295.1", "table_name": "pos_transaction_cost_dtl", "table_schema": "retail__retail_sales.pos_transaction_cost_dtl", "table_legacy_schema": "acapdb.pos_transaction_cost_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.pos_transaction_cost_dtl", "table_partition": "\n  sales_txn_dt STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.297.1", "table_name": "pos_transaction_detail", "table_schema": "retail__retail_sales.pos_transaction_detail", "table_legacy_schema": "acapdb.pos_transaction_detail", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.pos_transaction_detail", "table_partition": "\n  sales_txn_dt STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.313.1", "table_name": "pos_transaction_otuc", "table_schema": "retail__retail_sales.pos_transaction_otuc", "table_legacy_schema": "acapdb.pos_transaction_otuc", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.pos_transaction_otuc", "table_partition": "\n  sales_txn_year STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.340.1", "table_name": "refill_reminder_info", "table_schema": "digital__ecom.refill_reminder_info", "table_legacy_schema": "acapdb.refill_reminder_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.refill_reminder_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.379.1", "table_name": "sms_message_details", "table_schema": "digital__ecom.sms_message_details", "table_legacy_schema": "acapdb.sms_message_details", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.sms_message_details", "table_partition": "\n  submitted_date STRING", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.403.1", "table_name": "www_rx_order_overview", "table_schema": "digital__ecom.www_rx_order_overview", "table_legacy_schema": "acapdb.www_rx_order_overview", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_rx_order_overview", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.404.1", "table_name": "www_rx_order_retail", "table_schema": "digital__ecom.www_rx_order_retail", "table_legacy_schema": "acapdb.www_rx_order_retail", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_rx_order_retail", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.415.1", "table_name": "www_wep_rx_info", "table_schema": "digital__ecom.www_wep_rx_info", "table_legacy_schema": "acapdb.www_wep_rx_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_wep_rx_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.6299.1", "table_name": "patient_addr_comm_chanl", "table_schema": "pharmacy_healthcare__patient.patient_addr_comm_chanl", "table_legacy_schema": "dae_served.patient_addr_comm_chanl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient", "table_location": "pharmacy_healthcare__patient.patient_addr_comm_chanl", "table_partition": "", "table_db": "pharmacy_healthcare__patient", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.2", "table_id": "T.6300.1", "table_name": "prescriber_pres_location", "table_schema": "pharmacy_healthcare__prescriber.prescriber_pres_location", "table_legacy_schema": "dae_served.prescriber_pres_location", "table_domain": "pharmacy_healthcare", "table_subdomain": "prescriber", "table_location": "pharmacy_healthcare__prescriber.prescriber_pres_location", "table_partition": "", "table_db": "pharmacy_healthcare__prescriber", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

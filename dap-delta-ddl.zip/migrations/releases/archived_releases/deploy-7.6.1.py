# Databricks notebook source
# COMMAND ----------
spark.sql(f"""INSERT OVERWRITE pharmacy_healthcare__patient_services.prescription_fill_verify
SELECT
rx_nbr,
str_nbr,
rx_fill_nbr,
rx_fill_nbr_dspn,
reqst_actn_cd,
response_cd,
vrfy_txn_id,
vrfy_txn_dt,
str_npi_nbr,
phrm_service_type_cd,
phrm_txn_id,
response_actn,
response_msg,
vrx_call_origin,
src_create_user_id,
src_create_dttm,
src_update_user_id,
src_update_dttm,
create_dttm,
update_dttm,
edw_batch_id,
0 as delta_batch_id,
vrfy_txn_yr,
vrfy_txn_mnth
FROM staging__pharmacy_healthcare__patient_services.prescription_fill_verify_data_migration;""")
# COMMAND ----------
spark.sql(f"""INSERT OVERWRITE pharmacy_healthcare__patient_services.tl_prescription_close_log
SELECT
xfer_fm_rx_nbr,
xfer_fm_str_nbr,
rx_create_dt,
xfer_to_rx_nbr ,
xfer_to_str_nbr ,
xfer_to_competitor_str_name,
close_reason_cd,
close_reason_cmnt,
xfer_fm_rph_initials,
xfer_to_rph_initials,
xfer_to_competitor_area_cd,
xfer_to_competitor_phone_nbr,
rx_xfer_close_reason_cd,
relocate_fm_str_nbr,
create_user_id,
edw_batch_id,
update_user_id,
update_dttm,
src_partition_nbr,
close_log_create_dttm,
xfer_to_rph_first_name,
xfer_to_rph_last_name,
xfer_to_phrm_dea_nbr,
xfer_to_competitor_addr_line,
xfer_to_competitor_city,
xfer_to_competitor_state_cd,
xfer_to_competitor_zip_cd_5,
xfer_to_competitor_zip_cd_4,
0 AS delta_batch_id,
rx_create_yr,
rx_create_yrmnth
FROM staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration;""")
# COMMAND ----------
migration_data=[{"release": "7.6.1", "scripts": ["T.1879.2.crt.tl_prescription_close_log.sql", "T.1696.2.crt.prescription_fill_verify.sql"], "migration_date": "2022-07-05"}]
table_data=[{"release": "7.6.1", "table_id": "T.1879.2", "table_name": "tl_prescription_close_log", "table_schema": "pharmacy_healthcare__patient_services.tl_prescription_close_log", "table_legacy_schema": "dae_cooked.tl_prescription_close_log", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "", "table_partition": "\n  rx_create_yr STRING, \n  rx_create_yrmnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-07-05 21:01:14", "update_date": ""}, {"release": "7.6.1", "table_id": "T.1696.2", "table_name": "prescription_fill_verify", "table_schema": "pharmacy_healthcare__patient_services.prescription_fill_verify", "table_legacy_schema": "dae_cooked.prescription_fill_verify", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_fill_verify", "table_partition": "\n  vrfy_txn_yr STRING, \n  vrfy_txn_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-07-05 21:01:14", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

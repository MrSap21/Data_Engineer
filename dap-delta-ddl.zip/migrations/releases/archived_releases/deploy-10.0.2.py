# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.deduction_stg(
sed_employee_id DECIMAL(11,0),
process_date STRING,
deduction_code DECIMAL(4,0),
deduction_amount DECIMAL(11,2),
register_type STRING,
batch_id DECIMAL(5,0),
pay_period_end_date STRING,
emp_rec_id DECIMAL(15,0),
wage_type_description STRING,
short_description STRING,
sequence_num DECIMAL(8,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/deduction_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.earnings_stg(
sed_employee_id DECIMAL(11,0),
process_date STRING,
earnings_code DECIMAL(4,0),
earnings_hours DECIMAL(5,2),
earnings_amount DECIMAL(11,2),
location_charged DECIMAL(5,0),
register_type STRING,
batch_id DECIMAL(5,0),
pay_period_end_date STRING,
emp_rec_id DECIMAL(15,0),
charge_corp_code DECIMAL(4,0),
cost_center STRING,
short_description STRING,
sequence_num DECIMAL(8,0),
wage_type_description STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/earnings_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_prl_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_prl_stg'""")
# COMMAND ----------
migration_data=[{"release": "10.0.2", "scripts": ["T.20036.1.wrg.dim_cd_prl_stg.sql", "T.14622.1.wrg.deduction_stg.sql", "T.14658.1.wrg.earnings_stg.sql"], "migration_date": "2022-11-09"}]
table_data=[{"release": "10.0.2", "table_id": "T.20036.1", "table_name": "dim_cd_prl_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_prl_stg", "table_legacy_schema": "", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_prl_stg", "table_partition": "", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-11-09 14:17:08", "update_date": ""}, {"release": "10.0.2", "table_id": "T.14622.1", "table_name": "deduction_stg", "table_schema": "staging__hr__payroll.deduction_stg", "table_legacy_schema": "hr_raw.deduction", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.deduction_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-11-09 14:17:08", "update_date": ""}, {"release": "10.0.2", "table_id": "T.14658.1", "table_name": "earnings_stg", "table_schema": "staging__hr__payroll.earnings_stg", "table_legacy_schema": "hr_raw.earnings", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.earnings_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-11-09 14:17:08", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
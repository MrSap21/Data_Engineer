# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_mna_buyout', defaultValue='${STORAGE_ACCT_crt_mna_buyout}', label='STORAGE_ACCT_crt_mna_buyout')
dbutils.widgets.text(name='STORAGE_ACCT_crt_partner_extracts', defaultValue='${STORAGE_ACCT_crt_partner_extracts}', label='STORAGE_ACCT_crt_partner_extracts')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_crt_misc', defaultValue='${STORAGE_ACCT_crt_misc}', label='STORAGE_ACCT_crt_misc')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS misc__process;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS mna_buyout__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_email_provisioning_aggregation_stats(
seven_part_key STRING,
offer_score DECIMAL(6,4),
population INT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_email_provisioning_aggregation_stats'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_non_demographic_raw_data(
external_src_id STRING,
non_demo_attr1 struct<name:string,value:string>,
non_demo_attr2 struct<name:string,value:string>,
non_demo_attr3 struct<name:string,value:string>,
non_demo_attr4 struct<name:string,value:string>,
non_demo_attr5 struct<name:string,value:string>,
non_demo_attr6 struct<name:string,value:string>,
non_demo_attr7 struct<name:string,value:string>,
non_demo_attr8 struct<name:string,value:string>,
non_demo_attr9 struct<name:string,value:string>,
non_demo_attr10 struct<name:string,value:string>,
non_demo_attr11 struct<name:string,value:string>,
non_demo_attr12 struct<name:string,value:string>,
non_demo_attr13 struct<name:string,value:string>,
non_demo_attr14 struct<name:string,value:string>,
non_demo_attr15 struct<name:string,value:string>,
non_demo_attr16 struct<name:string,value:string>,
non_demo_attr17 struct<name:string,value:string>,
non_demo_attr18 struct<name:string,value:string>,
non_demo_attr19 struct<name:string,value:string>,
non_demo_attr20 struct<name:string,value:string>,
non_demo_attr21 struct<name:string,value:string>,
non_demo_attr22 struct<name:string,value:string>,
non_demo_attr23 struct<name:string,value:string>,
non_demo_attr24 struct<name:string,value:string>,
non_demo_attr25 struct<name:string,value:string>,
edw_create_userid STRING,
edw_create_dttm STRING,
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/wrk_car_vip_payer_non_demographic_raw_data'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_email_provisioning_ruleout_aggr_intermediate(
idh_batch_id STRING,
member_id STRING,
email_address STRING,
audience_key DECIMAL(18,0),
campaign_code STRING,
customer_test_1 STRING,
customer_test_2 STRING,
customer_test_3 STRING,
customer_test_4 STRING,
run_date STRING,
model_score DECIMAL(6,4),
seed_ind STRING,
test_holdout_flag STRING,
offer_code_1 STRING,
offer_type_1 STRING,
offer_position_1 STRING,
offer_code_2 STRING,
offer_type_2 STRING,
offer_position_2 STRING,
offer_code_3 STRING,
offer_type_3 STRING,
offer_position_3 STRING,
offer_code_4 STRING,
offer_type_4 STRING,
offer_position_4 STRING,
offer_code_5 STRING,
offer_type_5 STRING,
offer_position_5 STRING,
offer_code_6 STRING,
offer_type_6 STRING,
offer_position_6 STRING,
offer_code_7 STRING,
offer_type_7 STRING,
offer_position_7 STRING,
offer_code_8 STRING,
offer_type_8 STRING,
offer_position_8 STRING,
offer_code_9 STRING,
offer_type_9 STRING,
offer_position_9 STRING,
offer_code_10 STRING,
offer_type_10 STRING,
offer_position_10 STRING,
version_code_1 STRING,
version_code_2 STRING,
campaign_logic STRING,
channel_code STRING,
filler_1 STRING,
filler_2 STRING,
filler_3 STRING,
filler_4 STRING,
filler_5 STRING,
filler_6 STRING,
filler_7 STRING,
filler_8 STRING,
filler_9 STRING,
filler_10 STRING,
filler_11 STRING,
filler_12 STRING,
filler_13 STRING,
filler_14 STRING,
filler_15 STRING,
filler_16 STRING,
filler_17 STRING,
filler_18 STRING,
filler_19 STRING,
filler_20 STRING,
filler_21 STRING,
filler_22 STRING,
filler_23 STRING,
filler_24 STRING,
filler_25 STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_email_provisioning_ruleout_aggr_intermediate'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_email_rule_output_aggr_rownum(
idh_batch_id STRING,
member_id STRING,
email_address STRING,
audience_key DECIMAL(18,0),
campaign_code STRING,
customer_test_1 STRING,
customer_test_2 STRING,
customer_test_3 STRING,
customer_test_4 STRING,
run_date STRING,
model_score DECIMAL(6,4),
seed_ind STRING,
test_holdout_flag STRING,
offer_code_1 STRING,
offer_type_1 STRING,
offer_position_1 STRING,
offer_code_2 STRING,
offer_type_2 STRING,
offer_position_2 STRING,
offer_code_3 STRING,
offer_type_3 STRING,
offer_position_3 STRING,
offer_code_4 STRING,
offer_type_4 STRING,
offer_position_4 STRING,
offer_code_5 STRING,
offer_type_5 STRING,
offer_position_5 STRING,
offer_code_6 STRING,
offer_type_6 STRING,
offer_position_6 STRING,
offer_code_7 STRING,
offer_type_7 STRING,
offer_position_7 STRING,
offer_code_8 STRING,
offer_type_8 STRING,
offer_position_8 STRING,
offer_code_9 STRING,
offer_type_9 STRING,
offer_position_9 STRING,
offer_code_10 STRING,
offer_type_10 STRING,
offer_position_10 STRING,
version_code_1 STRING,
version_code_2 STRING,
campaign_logic STRING,
channel_code STRING,
filler_1 STRING,
filler_2 STRING,
filler_3 STRING,
filler_4 STRING,
filler_5 STRING,
filler_6 STRING,
filler_7 STRING,
filler_8 STRING,
filler_9 STRING,
filler_10 STRING,
filler_11 STRING,
filler_12 STRING,
filler_13 STRING,
filler_14 STRING,
filler_15 STRING,
filler_16 STRING,
filler_17 STRING,
filler_18 STRING,
filler_19 STRING,
filler_20 STRING,
filler_21 STRING,
filler_22 STRING,
filler_23 STRING,
filler_24 STRING,
filler_25 STRING,
rownum INT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_email_rule_output_aggr_rownum'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_email_rule_output_codes(
cval STRING,
rownum INT,
colnum INT,
colvalseq INT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_email_rule_output_codes'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_email_rule_output_codestypes(
code STRING,
type STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_email_rule_output_codestypes'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_email_rule_output_types(
cval STRING,
rownum INT,
colnum INT,
colvalseq INT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_email_rule_output_types'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_loyalty_offer_affinity_partial(
loyaltymrbid STRING,
emailscore DECIMAL(8,5),
emaildecile INT,
emailrank BIGINT,
mailscore DECIMAL(8,5),
maildecile INT,
mailrank BIGINT,
instoreprintscore DECIMAL(8,5),
instoreprintdecile INT,
instoreprintrank BIGINT,
digitaldisplayscore DECIMAL(8,5),
digitaldisplaydecile INT,
digitaldisplayrank BIGINT,
emailoptin INT,
prefferedstore STRING,
src_tbl_flag STRING,
emp_flag STRING,
aarp_active_ind STRING,
everyday_point_flag STRING,
beauty_club_flag STRING,
audience_id DECIMAL(18,0),
unsubscribe_hardbounce_ind STRING,
under_age_18_ind STRING,
br_welcomestream_ind STRING,
eml_addr_activity_cd STRING,
suspcs_mbr_ind STRING,
do_not_eml_ind STRING,
do_not_eml_br_ind STRING,
diabetes_subscribe_ind STRING,
news_ltr_subscribe_ind STRING,
photo_subscribe_ind STRING,
spcl_off_subscribe_ind STRING,
takecare_subscribe_ind STRING,
walk_social_subscribe_ind STRING,
wkly_ad_subscribe_ind STRING,
last_subscribe_activity_dt STRING,
eml_activity_month_segment STRING,
loyalty_subscribe_ind STRING,
mobileapp_ind STRING,
duanereade_cobrand_ind STRING,
src_id STRING,
state STRING,
dma STRING,
loyalty_senior_flag STRING,
idh_batch_id STRING,
emailid STRING,
txn_instore_last_year STRING,
txn_online_last_year STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_loyalty_offer_affinity_partial'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payor_humana_campaign_metadata(
humana_external_id STRING,
me_id STRING,
eid_cust_sk BIGINT,
eid STRING,
dependent_code STRING,
price_transparency_flag STRING,
gic_member_status STRING,
priority1_gic_ind STRING,
pcp_ind STRING,
pcp_name STRING,
pcp_phone_number STRING,
gic_active STRING,
pat_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/wrk_car_vip_payor_humana_campaign_metadata'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payor_patid_non_match_records_unmodifed(
pat_id STRING,
cust_src_id STRING,
insight_name STRING,
integration_prtnr STRING,
first_name STRING,
last_name STRING,
brth_dt STRING,
gndr_cd STRING,
addr_line_1 STRING,
addr_line_2 STRING,
city STRING,
county STRING,
state_cd STRING,
zip_cd_5 STRING,
comm_cd STRING,
comm_val STRING,
run_dt DATE)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/wrk_car_vip_payor_patid_non_match_records_unmodifed'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_rp_provisioning_aggregation_stats(
seven_part_key STRING,
offer_score DECIMAL(6,4),
population INT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_rp_provisioning_aggregation_stats'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_seniorday_provisioning_aggregation_stats(
seven_part_key STRING,
offer_score DECIMAL(6,4),
population INT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/campaign_seniorday_provisioning_aggregation_stats'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.ch_reconciliation(
batch_dttm STRING,
day_dt STRING,
ora_contactdatetime STRING,
contact_date STRING,
ora_planned_contact_date STRING,
planned_contact_date STRING,
ora_campaign_cd STRING,
campaigncode STRING,
channel_cd STRING,
ora_channel_cd STRING,
packageid STRING,
ora_packageid STRING,
ora_cellid STRING,
cell_id STRING,
ora_offer_cd STRING,
offer_cd STRING,
ora_treatment_id STRING,
treatment_id STRING,
ora_contactstatusid STRING,
contact_status_id STRING,
oracle_count_val STRING,
count_val STRING,
count_value_diff DOUBLE,
per_diff DOUBLE,
reason STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/ch_reconciliation'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__pharmacy_healthcare.competitor_decode(
lookup_type STRING,
lookup_cd STRING,
lookup_desc STRING,
lookup_name STRING,
lookup_sort_ord tinyint)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/pharmacy_healthcare/competitor_decode'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__pharmacy_healthcare.competitor_master(
wag_competitor_id DECIMAL(9,0),
eff_dt STRING,
eff_tm STRING,
end_dt STRING,
end_tm STRING,
src_provider_id STRING,
competitor_name STRING,
wag_competitor_name STRING,
parent_org_name STRING,
prev_org_name STRING,
competitor_str_nbr STRING,
addr_line_1 STRING,
addr_line_2 STRING,
city STRING,
state_cd STRING,
zip_cd_5 STRING,
zip_cd_4 STRING,
phone_area_cd STRING,
phone_nbr STRING,
msa_name STRING,
competitor_stat STRING,
competitor_stat_update_dttm STRING,
str_open_dt STRING,
str_close_dt STRING,
rx_open_tm_sun STRING,
rx_open_tm_mon STRING,
rx_open_tm_tue STRING,
rx_open_tm_wed STRING,
rx_open_tm_thu STRING,
rx_open_tm_fri STRING,
rx_open_tm_sat STRING,
rx_close_tm_sun STRING,
rx_close_tm_mon STRING,
rx_close_tm_tue STRING,
rx_close_tm_wed STRING,
rx_close_tm_thu STRING,
rx_close_tm_fri STRING,
rx_close_tm_sat STRING,
rx_hr_per_wk DECIMAL(3,0),
open_24_hrs_ind STRING,
str_hrs_update_dttm STRING,
drv_thru_ind STRING,
drv_thru_ind_update_dttm STRING,
copy_rx_per_day DECIMAL(4,0),
copy_rx_per_day_dttm STRING,
copy_rx_calc_rec DECIMAL(5,0),
mpr_rx_per_day DECIMAL(4,0),
mpr_rx_per_day_update_dttm STRING,
re_rx_per_day DECIMAL(4,0),
re_rx_per_day_update_dttm STRING,
ops_rx_per_day DECIMAL(4,0),
ops_rx_per_day_update_dttm STRING,
building_type STRING,
building_type_update_dttm STRING,
buyout_priority STRING,
buyout_type_cd STRING,
buyout_update_dttm STRING,
file_acquisition_ind STRING,
relocation_ind STRING,
wag_competitor_type_cd STRING,
wag_sublayer_cd STRING,
wag_pend_data_issue_ind STRING,
wag_district_nbr INT,
nearest_wag_str_nbr INT,
miles_fm_wag_str DECIMAL(6,2),
fips STRING,
longitude STRING,
latitude STRING,
mcode STRING,
lcode STRING,
locked_dttm STRING,
moved_dttm STRING,
wag_created_ind STRING,
first_created_dttm STRING,
create_user_id DECIMAL(10,0),
create_dttm STRING,
update_user_id DECIMAL(10,0),
update_dttm STRING,
parent_org_name_chng_dt STRING,
buyout_loc_id DECIMAL(9,0),
buyout_sqft DECIMAL(6,0),
buyout_wag_ta_position STRING,
buyout_competitor_ta_position STRING,
buyout_ta_position STRING,
buyout_city_type STRING,
buyout_ta_detail_update_dttm STRING,
buyout_stat STRING,
msa_cd STRING,
relation_id STRING,
wag_chain_type_cd STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/pharmacy_healthcare/competitor_master'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__pharmacy_healthcare.competitor_msa(
msa_cd STRING,
eff_dt STRING,
eff_tm STRING,
end_dt STRING,
end_tm STRING,
discounter_cnt DECIMAL(6,0),
drug_str_cnt DECIMAL(6,0),
grocer_cnt DECIMAL(6,0),
other_rx_cnt DECIMAL(6,0),
discounter_coverage DECIMAL(12,2),
drug_str_coverage DECIMAL(12,2),
grocer_coverage DECIMAL(12,2),
other_rx_coverage DECIMAL(12,2),
shape_area DECIMAL(16,2),
create_user_id DECIMAL(10,0),
create_dttm STRING,
update_user_id DECIMAL(10,0),
update_dttm STRING,
wag_str_cnt DECIMAL(6,0),
wag_coverage DECIMAL(12,2),
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/pharmacy_healthcare/competitor_msa'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_humana_dch_weekly_gic_prc_trn_current(
external_id STRING,
meid STRING,
dependent_code STRING,
zip_code STRING,
dob STRING,
first_name STRING,
last_name STRING,
gic_active STRING,
priority1_gic_ind STRING,
pcp_name STRING,
pcp_phone_number STRING,
pcp_ind STRING,
gic_member_status STRING,
price_transparency_flag STRING,
idh_batch_id BIGINT,
run_dt DATE,
pat_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/wrk_humana_dch_weekly_gic_prc_trn_current'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payor_humana_dch_gic_prc_trn(
external_id STRING,
meid STRING,
dependent_code STRING,
zip_code STRING,
dob STRING,
first_name STRING,
last_name STRING,
gic_active STRING,
priority1_gic_ind STRING,
pcp_name STRING,
pcp_phone_number STRING,
pcp_ind STRING,
gic_member_status STRING,
price_transparency_flag STRING,
idh_batch_id BIGINT,
run_dt DATE,
pat_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/car_vip_payor_humana_dch_gic_prc_trn'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payor_humana_dch_gic_prc_trn_weekly_extract(
external_id STRING,
meid STRING,
dependent_code STRING,
zip_code STRING,
dob STRING,
first_name STRING,
last_name STRING,
gic_active STRING,
priority1_gic_ind STRING,
pcp_name STRING,
pcp_phone_number STRING,
pcp_ind STRING,
gic_member_status STRING,
price_transparency_flag STRING,
idh_batch_id STRING,
pat_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/car_vip_payor_humana_dch_gic_prc_trn_weekly_extract'
PARTITIONED BY (
run_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS misc__process.proc_cntrl_extract_batch_meta_detail(
src_database_name STRING,
src_table_name STRING,
extract_date_1 DATE,
extract_date_2 DATE,
extract_dttm_1 TIMESTAMP,
extract_dttm_2 TIMESTAMP,
extract_range DECIMAL(5,0),
extract_file_name STRING,
extract_record_cnt INT,
extract_seq INT,
condition_1 STRING,
condition_2 STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_misc')}.dfs.core.windows.net/misc/process/proc_cntrl_extract_batch_meta_detail'
PARTITIONED BY (
proj_name STRING,
dept_id STRING,
extract_name STRING,
batch_id DECIMAL(18,0),
insert_dttm TIMESTAMP)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.rx_meta_data(
file_name STRING,
tracking_id STRING,
update_tsmp STRING,
file_dt STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/rx_meta_data'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_rx_test(
pharmacypatientid DECIMAL(13,0),
gpi_14 STRING,
rx_nbr_last INT,
clientstoreid_last INT,
fill_sold_dt_last STRING,
fill_days_supply_last INT,
filldisp_nbr_last INT,
refill_remaining_last INT,
copay DECIMAL(8,2),
script_alignment_status STRING,
clientstoreid INT,
sync_date STRING,
sync_cycle_length INT,
loginname STRING,
usergroup STRING,
dspn_fill_nbr SMALLINT,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/sa_rx_test'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payor_patid_non_match_records_hist(
pat_id STRING,
cust_src_id STRING,
insight_name STRING,
integration_prtnr STRING,
first_name STRING,
last_name STRING,
brth_dt STRING,
gndr_cd STRING,
addr_line_1 STRING,
addr_line_2 STRING,
city STRING,
county STRING,
state_cd STRING,
zip_cd_5 STRING,
comm_cd STRING,
comm_val STRING,
run_dt DATE)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/car_vip_payor_patid_non_match_records_hist'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payor_patid_non_match_records_weekly_extract(
pat_id STRING,
cust_src_id STRING,
insight_name STRING,
integration_prtnr STRING,
first_name STRING,
last_name STRING,
brth_dt STRING,
gndr_cd STRING,
addr_line_1 STRING,
addr_line_2 STRING,
city STRING,
county STRING,
state_cd STRING,
zip_cd_5 STRING,
comm_cd STRING,
comm_val STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/car_vip_payor_patid_non_match_records_weekly_extract'
PARTITIONED BY (
run_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.ecom_account_cep_profile(
cust_sk BIGINT,
src_card_id STRING,
edw_rec_begin_dt DATE,
ecom_acct_id STRING,
src_sys_cd STRING,
composite_type_cd STRING,
msg_type_cd STRING,
card_exp_dt STRING,
action_desc STRING,
action_dttm TIMESTAMP,
edw_rec_end_dt DATE,
edw_create_dttm TIMESTAMP,
edw_update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/ecom_account_cep_profile'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.humana_dch_weekly_gic_prc_trn_delta(
external_id STRING,
meid STRING,
dependent_code STRING,
zip_code STRING,
dob STRING,
first_name STRING,
last_name STRING,
gic_active STRING,
priority1_gic_ind STRING,
pcp_name STRING,
pcp_phone_number STRING,
pcp_ind STRING,
gic_member_status STRING,
price_transparency_flag STRING,
idh_batch_id BIGINT,
run_dt DATE,
pat_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/humana_dch_weekly_gic_prc_trn_delta'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.humana_dch_weekly_gic_prc_trn_unmodifed(
external_id STRING,
meid STRING,
dependent_code STRING,
zip_code STRING,
dob STRING,
first_name STRING,
last_name STRING,
gic_active STRING,
priority1_gic_ind STRING,
pcp_name STRING,
pcp_phone_number STRING,
pcp_ind STRING,
gic_member_status STRING,
price_transparency_flag STRING,
idh_batch_id BIGINT,
run_dt DATE,
pat_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/humana_dch_weekly_gic_prc_trn_unmodifed'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.ref_mobile_decrypt_data(
dis_post_evar1 STRING,
decrypt_dis_post_evar1 STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/ref_mobile_decrypt_data'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.rx_sms_refill_info(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/rx_sms_refill_info'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_hs_activity(
hs_activity_id STRING,
profile_id STRING,
hs_usergoal_id STRING,
create_dttm STRING,
create_user_id STRING,
update_dttm STRING,
update_user_id STRING,
activity_type STRING,
activity_name STRING,
activity_date STRING,
measurement DECIMAL(9,2),
unit STRING,
time_of_day BIGINT,
duration BIGINT,
step_count BIGINT,
intensity BIGINT,
feel BIGINT,
comments STRING,
route_id STRING,
external_id STRING,
active_ind BIGINT,
photo_id STRING,
loyalty_processed BIGINT,
dha_processed BIGINT)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_hs_activity'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_hs_activity_details(
hs_activity_details_id STRING,
hs_activity_id STRING,
hs_category_cd STRING,
hs_category_value STRING,
hs_category_unit STRING,
hs_category_date STRING,
active_ind BIGINT,
create_dttm STRING,
update_dttm STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_hs_activity_details'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.rx_uce_insights(
integration_prtnr STRING,
insights STRING,
insight_dtl STRING,
insight_name STRING,
default_value STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/rx_uce_insights'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_source_system_lookup_31st_jan(
me_id STRING,
source_system STRING,
source_system_id STRING,
source_status STRING,
create_dttm STRING,
create_user STRING,
update_dttm STRING,
update_user STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_source_system_lookup_31st_jan'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_wep_rx_info(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_wep_rx_info'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_ws_activity_log(
entry_id STRING,
device_info STRING,
app_version STRING,
activity_desc STRING,
return_code STRING,
me_id STRING,
affiliate_id STRING,
ip_address STRING,
create_dttm TIMESTAMP,
addl_info STRING,
transaction_id STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_ws_activity_log'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.rx_uce_ndc_group(
ndc_group STRING,
ndc_nbr STRING,
therapy STRING,
months STRING,
active_flag STRING,
create_time STRING,
update_time STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/rx_uce_ndc_group'""")
# COMMAND ----------
migration_data=[{"release": "7.0.1", "scripts": ["D.1.1.crt.partner_extracts__pharmacy_healthcare.sql", "D.12.1.crt.digital__ecom.sql", "D.17.1.crt.misc__process.sql", "D.26.1.crt.mna_buyout__pharmacy_healthcare.sql", "D.5.1.crt.marketing__campaign.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "T.1009.1.crt.campaign_email_provisioning_aggregation_stats.sql", "T.101.1.crt.wrk_car_vip_payer_non_demographic_raw_data.sql", "T.1010.1.crt.campaign_email_provisioning_ruleout_aggr_intermediate.sql", "T.1011.1.crt.campaign_email_rule_output_aggr_rownum.sql", "T.1012.1.crt.campaign_email_rule_output_codes.sql", "T.1014.1.crt.campaign_email_rule_output_codestypes.sql", "T.1015.1.crt.campaign_email_rule_output_types.sql", "T.1019.1.crt.campaign_loyalty_offer_affinity_partial.sql", "T.103.1.crt.wrk_car_vip_payor_humana_campaign_metadata.sql", "T.105.1.crt.wrk_car_vip_payor_patid_non_match_records_unmodifed.sql", "T.1052.1.crt.campaign_rp_provisioning_aggregation_stats.sql", "T.1054.1.crt.campaign_seniorday_provisioning_aggregation_stats.sql", "T.1069.1.crt.ch_reconciliation.sql", "T.1085.1.crt.competitor_decode.sql", "T.1086.1.crt.competitor_master.sql", "T.1087.1.crt.competitor_msa.sql", "T.109.1.crt.wrk_humana_dch_weekly_gic_prc_trn_current.sql", "T.15.1.crt.car_vip_payor_humana_dch_gic_prc_trn.sql", "T.16.1.crt.car_vip_payor_humana_dch_gic_prc_trn_weekly_extract.sql", "T.1734.1.crt.proc_cntrl_extract_batch_meta_detail.sql", "T.1760.1.crt.rx_meta_data.sql", "T.1789.1.crt.sa_rx_test.sql", "T.18.1.crt.car_vip_payor_patid_non_match_records_hist.sql", "T.19.1.crt.car_vip_payor_patid_non_match_records_weekly_extract.sql", "T.247.1.crt.ecom_account_cep_profile.sql", "T.27.1.crt.humana_dch_weekly_gic_prc_trn_delta.sql", "T.28.1.crt.humana_dch_weekly_gic_prc_trn_unmodifed.sql", "T.339.1.crt.ref_mobile_decrypt_data.sql", "T.347.1.crt.rx_sms_refill_info.sql", "T.392.1.crt.www_hs_activity.sql", "T.393.1.crt.www_hs_activity_details.sql", "T.41.1.crt.rx_uce_insights.sql", "T.414.1.crt.www_source_system_lookup_31st_jan.sql", "T.415.1.crt.www_wep_rx_info.sql", "T.416.1.crt.www_ws_activity_log.sql", "T.45.1.crt.rx_uce_ndc_group.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.0.1", "table_id": "T.1009.1", "table_name": "campaign_email_provisioning_aggregation_stats", "table_schema": "marketing__campaign.campaign_email_provisioning_aggregation_stats", "table_legacy_schema": "dae_cooked.campaign_email_provisioning_aggregation_stats", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_email_provisioning_aggregation_stats", "table_partition": "\n  batch_id STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.101.1", "table_name": "wrk_car_vip_payer_non_demographic_raw_data", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_non_demographic_raw_data", "table_legacy_schema": "acapcar.wrk_car_vip_payer_non_demographic_raw_data", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_non_demographic_raw_data", "table_partition": "\n  idh_load_dt STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1010.1", "table_name": "campaign_email_provisioning_ruleout_aggr_intermediate", "table_schema": "marketing__campaign.campaign_email_provisioning_ruleout_aggr_intermediate", "table_legacy_schema": "dae_cooked.campaign_email_provisioning_ruleout_aggr_intermediate", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_email_provisioning_ruleout_aggr_intermediate", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1011.1", "table_name": "campaign_email_rule_output_aggr_rownum", "table_schema": "marketing__campaign.campaign_email_rule_output_aggr_rownum", "table_legacy_schema": "dae_cooked.campaign_email_rule_output_aggr_rownum", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_email_rule_output_aggr_rownum", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1012.1", "table_name": "campaign_email_rule_output_codes", "table_schema": "marketing__campaign.campaign_email_rule_output_codes", "table_legacy_schema": "dae_cooked.campaign_email_rule_output_codes", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_email_rule_output_codes", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1014.1", "table_name": "campaign_email_rule_output_codestypes", "table_schema": "marketing__campaign.campaign_email_rule_output_codestypes", "table_legacy_schema": "dae_cooked.campaign_email_rule_output_codestypes", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_email_rule_output_codestypes", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1015.1", "table_name": "campaign_email_rule_output_types", "table_schema": "marketing__campaign.campaign_email_rule_output_types", "table_legacy_schema": "dae_cooked.campaign_email_rule_output_types", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_email_rule_output_types", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1019.1", "table_name": "campaign_loyalty_offer_affinity_partial", "table_schema": "marketing__campaign.campaign_loyalty_offer_affinity_partial", "table_legacy_schema": "dae_cooked.campaign_loyalty_offer_affinity_partial", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_loyalty_offer_affinity_partial", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.103.1", "table_name": "wrk_car_vip_payor_humana_campaign_metadata", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payor_humana_campaign_metadata", "table_legacy_schema": "acapcar.wrk_car_vip_payor_humana_campaign_metadata", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payor_humana_campaign_metadata", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.105.1", "table_name": "wrk_car_vip_payor_patid_non_match_records_unmodifed", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payor_patid_non_match_records_unmodifed", "table_legacy_schema": "acapcar.wrk_car_vip_payor_patid_non_match_records_unmodifed", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payor_patid_non_match_records_unmodifed", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1052.1", "table_name": "campaign_rp_provisioning_aggregation_stats", "table_schema": "marketing__campaign.campaign_rp_provisioning_aggregation_stats", "table_legacy_schema": "dae_cooked.campaign_rp_provisioning_aggregation_stats", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_rp_provisioning_aggregation_stats", "table_partition": "\n  batch_id STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1054.1", "table_name": "campaign_seniorday_provisioning_aggregation_stats", "table_schema": "marketing__campaign.campaign_seniorday_provisioning_aggregation_stats", "table_legacy_schema": "dae_cooked.campaign_seniorday_provisioning_aggregation_stats", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_seniorday_provisioning_aggregation_stats", "table_partition": "\n  batch_id STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1069.1", "table_name": "ch_reconciliation", "table_schema": "marketing__campaign.ch_reconciliation", "table_legacy_schema": "dae_cooked.ch_reconciliation", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.ch_reconciliation", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1085.1", "table_name": "competitor_decode", "table_schema": "mna_buyout__pharmacy_healthcare.competitor_decode", "table_legacy_schema": "dae_cooked.competitor_decode", "table_domain": "mna_buyout", "table_subdomain": "pharmacy_healthcare", "table_location": "mna_buyout__pharmacy_healthcare.competitor_decode", "table_partition": "", "table_db": "mna_buyout__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1086.1", "table_name": "competitor_master", "table_schema": "mna_buyout__pharmacy_healthcare.competitor_master", "table_legacy_schema": "dae_cooked.competitor_master", "table_domain": "mna_buyout", "table_subdomain": "pharmacy_healthcare", "table_location": "mna_buyout__pharmacy_healthcare.competitor_master", "table_partition": "", "table_db": "mna_buyout__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1087.1", "table_name": "competitor_msa", "table_schema": "mna_buyout__pharmacy_healthcare.competitor_msa", "table_legacy_schema": "dae_cooked.competitor_msa", "table_domain": "mna_buyout", "table_subdomain": "pharmacy_healthcare", "table_location": "mna_buyout__pharmacy_healthcare.competitor_msa", "table_partition": "", "table_db": "mna_buyout__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.109.1", "table_name": "wrk_humana_dch_weekly_gic_prc_trn_current", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_humana_dch_weekly_gic_prc_trn_current", "table_legacy_schema": "acapcar.wrk_humana_dch_weekly_gic_prc_trn_current", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_humana_dch_weekly_gic_prc_trn_current", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.15.1", "table_name": "car_vip_payor_humana_dch_gic_prc_trn", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payor_humana_dch_gic_prc_trn", "table_legacy_schema": "acapcar.car_vip_payor_humana_dch_gic_prc_trn", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payor_humana_dch_gic_prc_trn", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.16.1", "table_name": "car_vip_payor_humana_dch_gic_prc_trn_weekly_extract", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payor_humana_dch_gic_prc_trn_weekly_extract", "table_legacy_schema": "acapcar.car_vip_payor_humana_dch_gic_prc_trn_weekly_extract", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payor_humana_dch_gic_prc_trn_weekly_extract", "table_partition": "\n  run_dt STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1734.1", "table_name": "proc_cntrl_extract_batch_meta_detail", "table_schema": "misc__process.proc_cntrl_extract_batch_meta_detail", "table_legacy_schema": "dae_cooked.proc_cntrl_extract_batch_meta_detail", "table_domain": "misc", "table_subdomain": "process", "table_location": "misc__process.proc_cntrl_extract_batch_meta_detail", "table_partition": "\n  proj_name STRING, \n  dept_id STRING, \n  extract_name STRING, \n  batch_id DECIMAL(18,0", "table_db": "misc__process", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1760.1", "table_name": "rx_meta_data", "table_schema": "partner_extracts__pharmacy_healthcare.rx_meta_data", "table_legacy_schema": "dae_cooked.rx_meta_data", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.rx_meta_data", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.1789.1", "table_name": "sa_rx_test", "table_schema": "partner_extracts__pharmacy_healthcare.sa_rx_test", "table_legacy_schema": "dae_cooked.sa_rx_test", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_rx_test", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.18.1", "table_name": "car_vip_payor_patid_non_match_records_hist", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payor_patid_non_match_records_hist", "table_legacy_schema": "acapcar.car_vip_payor_patid_non_match_records_hist", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payor_patid_non_match_records_hist", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.19.1", "table_name": "car_vip_payor_patid_non_match_records_weekly_extract", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payor_patid_non_match_records_weekly_extract", "table_legacy_schema": "acapcar.car_vip_payor_patid_non_match_records_weekly_extract", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payor_patid_non_match_records_weekly_extract", "table_partition": "\n  run_dt STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.247.1", "table_name": "ecom_account_cep_profile", "table_schema": "digital__ecom.ecom_account_cep_profile", "table_legacy_schema": "acapdb.ecom_account_cep_profile", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.ecom_account_cep_profile", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.27.1", "table_name": "humana_dch_weekly_gic_prc_trn_delta", "table_schema": "partner_extracts__pharmacy_healthcare.humana_dch_weekly_gic_prc_trn_delta", "table_legacy_schema": "acapcar.humana_dch_weekly_gic_prc_trn_delta", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.humana_dch_weekly_gic_prc_trn_delta", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.28.1", "table_name": "humana_dch_weekly_gic_prc_trn_unmodifed", "table_schema": "partner_extracts__pharmacy_healthcare.humana_dch_weekly_gic_prc_trn_unmodifed", "table_legacy_schema": "acapcar.humana_dch_weekly_gic_prc_trn_unmodifed", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.humana_dch_weekly_gic_prc_trn_unmodifed", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.339.1", "table_name": "ref_mobile_decrypt_data", "table_schema": "digital__ecom.ref_mobile_decrypt_data", "table_legacy_schema": "acapdb.ref_mobile_decrypt_data", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.ref_mobile_decrypt_data", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.347.1", "table_name": "rx_sms_refill_info", "table_schema": "digital__ecom.rx_sms_refill_info", "table_legacy_schema": "acapdb.rx_sms_refill_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.rx_sms_refill_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.392.1", "table_name": "www_hs_activity", "table_schema": "digital__ecom.www_hs_activity", "table_legacy_schema": "acapdb.www_hs_activity", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_hs_activity", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.393.1", "table_name": "www_hs_activity_details", "table_schema": "digital__ecom.www_hs_activity_details", "table_legacy_schema": "acapdb.www_hs_activity_details", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_hs_activity_details", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.41.1", "table_name": "rx_uce_insights", "table_schema": "partner_extracts__pharmacy_healthcare.rx_uce_insights", "table_legacy_schema": "acapcar.rx_uce_insights", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.rx_uce_insights", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.414.1", "table_name": "www_source_system_lookup_31st_jan", "table_schema": "digital__ecom.www_source_system_lookup_31st_jan", "table_legacy_schema": "acapdb.www_source_system_lookup_31st_jan", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_source_system_lookup_31st_jan", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.415.1", "table_name": "www_wep_rx_info", "table_schema": "digital__ecom.www_wep_rx_info", "table_legacy_schema": "acapdb.www_wep_rx_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_wep_rx_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.416.1", "table_name": "www_ws_activity_log", "table_schema": "digital__ecom.www_ws_activity_log", "table_legacy_schema": "acapdb.www_ws_activity_log", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_ws_activity_log", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.0.1", "table_id": "T.45.1", "table_name": "rx_uce_ndc_group", "table_schema": "partner_extracts__pharmacy_healthcare.rx_uce_ndc_group", "table_legacy_schema": "acapcar.rx_uce_ndc_group", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.rx_uce_ndc_group", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_marketing', defaultValue='${STORAGE_ACCT_wrg_marketing}', label='STORAGE_ACCT_wrg_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_monthly_stg(
globalpatientid STRING,
pharmacypatientid DECIMAL(13,0),
patientlastname STRING,
patientfirstname STRING,
patientmiddlename STRING,
patientsuffix STRING,
patientdateofbirth STRING,
patientgender STRING,
patientaddress1 STRING,
patientcity STRING,
patientstateprov STRING,
patientpostalcode STRING,
patientphonenum1 STRING,
patientemail STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_pmap_patient_demo_monthly_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.campaign_resp_file_stg(
file_id DECIMAL(18,0),
vendor_id DECIMAL(18,0),
file_received_dttm STRING,
response_file_name STRING,
create_dttm STRING,
update_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/campaign_resp_file_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.1.4", "scripts": ["D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "D.53.1.wrg.marketing__campaign.sql", "T.5117.1.wrg.satr_pmap_patient_demo_monthly_stg.sql", "T.6931.1.wrg.campaign_resp_file_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.1.4", "table_id": "T.5117.1", "table_name": "satr_pmap_patient_demo_monthly_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_monthly_stg", "table_legacy_schema": "dae_scratch.satr_pmap_patient_demo_monthly", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_pmap_patient_demo_monthly_stg", "table_partition": "", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.4", "table_id": "T.6931.1", "table_name": "campaign_resp_file_stg", "table_schema": "staging__marketing__campaign.campaign_resp_file_stg", "table_legacy_schema": "dae_work.campaign_resp_file", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.campaign_resp_file_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

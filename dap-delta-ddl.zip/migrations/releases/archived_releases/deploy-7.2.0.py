# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.pharmacy_staff(
str_nbr INT,
phrm_staff_user_id DECIMAL(9,0),
src_eff_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
src_eff_tm STRING,
first_name STRING ,
middle_initial STRING ,
last_name STRING ,
home_phone_area_cd STRING ,
home_phone STRING ,
rph_label STRING ,
phrm_staff_initials STRING ,
phrm_staff_position_cd STRING ,
phrm_staff_license_nbr STRING ,
phrm_staff_spcl_license_nbr STRING ,
phrm_rph_access_ind STRING ,
ic_access_lvl_nbr SMALLINT ,
ic_editable_ind STRING ,
emp_ind STRING ,
emp_status_ind STRING ,
src_create_user_id DECIMAL(9,0) ,
src_create_dttm TIMESTAMP,
src_update_user_id DECIMAL(9,0) ,
src_end_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
src_end_tm STRING,
edw_batch_id DECIMAL(18,0),
history_seq_nbr SMALLINT,
history_seq_cd STRING ,
rph_consult_barcd_nbr STRING ,
rph_barcd_exp_dttm TIMESTAMP,
phrm_npi_id DECIMAL(10,0),
auth_rfp_phrm_staff_ind STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/pharmacy_staff'
PARTITIONED BY (
history_seq_cd)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_sdl(
rx_nbr INT,
str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
fill_enter_tm STRING,
sdl_msg_id STRING ,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
pat_id DECIMAL(13,0),
fill_qty_dspn DECIMAL(8,3) ,
fill_days_supply DECIMAL(3,0) ,
fill_nbr_dspn DECIMAL(3,0) ,
drug_name STRING ,
drug_ndc_nbr STRING ,
rx_written_dttm TIMESTAMP,
general_pbr_nbr STRING ,
submit_user_id DECIMAL(9,0),
submit_dttm TIMESTAMP,
plan_id STRING ,
plan_group_nbr STRING ,
general_recipient_nbr STRING ,
prior_auth_cd STRING ,
prior_auth_nbr STRING ,
rx_deny_override_cd STRING ,
elig_override_cd STRING ,
diagnosis_cd STRING ,
pay_cd STRING ,
dl_proc_msg STRING ,
dl_additional_msg STRING ,
dur_conflict_cd STRING ,
dur_intervention_cd STRING ,
dur_outcome_cd STRING ,
other_payr_reject_cd STRING ,
other_cover_cd DECIMAL(2,0) ,
other_payr_cvrg_type STRING ,
plan_other_amt_paid_type STRING ,
plan_other_amt_paid DECIMAL(8,2) ,
other_payr_id STRING ,
other_payr_id_qlfr STRING ,
first_provider_paid_dlrs DECIMAL(8,2) ,
plan_tot_paid_dlrs DECIMAL(8,2) ,
plan_returnd_cost_dlrs DECIMAL(8,2) ,
plan_returnd_fee_dlrs DECIMAL(8,2) ,
plan_incentive_paid_dlrs DECIMAL(8,2) ,
fill_rtl_price_dlrs DECIMAL(8,2) ,
pat_rem_ded_dlrs DECIMAL(8,2) ,
pat_rem_ben_dlrs DECIMAL(8,2) ,
pat_acc_ded_dlrs DECIMAL(8,2) ,
pat_ded_apply_dlrs DECIMAL(8,2) ,
fill_del_adjud_cd STRING ,
fill_adjud_cd STRING ,
claim_ref_nbr STRING ,
plan_returnd_copay_dlrs DECIMAL(8,2) ,
plan_returnd_tax_dlrs DECIMAL(8,2) ,
fill_sold_dlrs DECIMAL(8,2) ,
sales_adj_cd STRING ,
rx_daw_ind STRING ,
claim_reversal_ind STRING ,
edw_batch_id DECIMAL(18,0) ,
relocate_fm_str_nbr INT,
src_partition_nbr TINYINT ,
place_of_service_cd DECIMAL(2,0) ,
rx_deny_override_2_cd STRING ,
rx_deny_override_3_cd STRING ,
delay_reason_cd DECIMAL(2,0) ,
return_plan_group_nbr STRING ,
return_third_party_plan_id STRING ,
covered_mbr_network_id STRING ,
prcs_fee_collect_dlrs DECIMAL(8,2) ,
provider_network_collect_dlrs DECIMAL(8,2) ,
brand_drug_collect_dlrs DECIMAL(8,2) ,
npref_form_collect_dlrs DECIMAL(8,2) ,
coverage_gap_collect_dlrs DECIMAL(8,2) ,
plan_fund_asst_dlrs DECIMAL(8,2) ,
third_party_ingrd_cont_dlrs DECIMAL(8,2) ,
third_party_disp_cont_fee_dlrs DECIMAL(8,2) ,
plan_sales_tax_dlrs DECIMAL(8,2) ,
pat_sales_tax_dlrs DECIMAL(8,2) ,
other_payr_recognize_dlrs DECIMAL(8,2) ,
benefit_stg_deduct_dlrs DECIMAL(8,2) ,
benefit_stg_initial_cvrg_dlrs DECIMAL(8,2) ,
benefit_stg_coverage_gap_dlrs DECIMAL(8,2) ,
benefit_stg_catastrophic_dlrs DECIMAL(8,2) ,
plan_return_coinsure_dlrs DECIMAL(8,2) ,
plan_other_amt_paid_2_type STRING ,
plan_other_amt_paid_3_type STRING ,
plan_other_amt_2_paid DECIMAL(8,2) ,
plan_other_amt_3_paid DECIMAL(8,2) ,
phrm_service_type_cd DECIMAL(2,0) ,
brand_npref_form_collect_dlrs DECIMAL(8,2) ,
ingrd_cost_pd_rmb_calc_meth_cd STRING ,
return_copay_dlrs DECIMAL(8,2) ,
plan_incent_submtd_dlrs DECIMAL(8,2) ,
plan_gross_due_dlrs DECIMAL(8,2) ,
benefit_stg_1_amt DECIMAL(8,2),
benefit_stg_1_qlfr_cd STRING ,
benefit_stg_2_amt DECIMAL(8,2),
benefit_stg_2_qlfr_cd STRING ,
benefit_stg_3_amt DECIMAL(8,2),
benefit_stg_3_qlfr_cd STRING ,
benefit_stg_4_amt DECIMAL(8,2),
benefit_stg_4_qlfr_cd STRING ,
coupon_ind STRING ,
coupon_drug_id INT,
sdl_type_cd SMALLINT
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_sdl'
PARTITIONED BY (
fill_sold_yr STRING)""")
# COMMAND ----------
migration_data=[{"release": "7.2.0", "scripts": ["D.6.1.crt.pharmacy_healthcare__patient_services.sql", "T.1594.1.crt.pharmacy_staff.sql", "T.1713.1.crt.prescription_sdl.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.2.0", "table_id": "T.1594.1", "table_name": "pharmacy_staff", "table_schema": "pharmacy_healthcare__patient_services.pharmacy_staff", "table_legacy_schema": "dae_cooked.pharmacy_staff", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.pharmacy_staff", "table_partition": "\n  history_seq_cd STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.0", "table_id": "T.1713.1", "table_name": "prescription_sdl", "table_schema": "pharmacy_healthcare__patient_services.prescription_sdl", "table_legacy_schema": "dae_cooked.prescription_sdl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_sdl", "table_partition": "\n  fill_sold_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_marketing', defaultValue='${STORAGE_ACCT_wrg_marketing}', label='STORAGE_ACCT_wrg_marketing')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.plan_type_info_stg(
pat_id DECIMAL(13,0),
third_party_plan_name STRING,
primary_plan_grp_nbr STRING,
plan_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/plan_type_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_30_days_patients_plan_phase2_stg(
pat_id DECIMAL(13,0),
plan_type STRING,
third_party_plan_id STRING,
plan_group_nbr STRING,
fill_sold_dt STRING,
cob_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_30_days_patients_plan_phase2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_30_days_patients_plan_phase2_temp_stg(
pat_id STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_id STRING,
plan_group_nbr STRING,
fill_sold_dt STRING,
cob_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_30_days_patients_plan_phase2_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patient_eligibile_demo_plan_info_stg(
pat_id DECIMAL(13,0),
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
primary_plan_grp_nbr STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patient_eligibile_demo_plan_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patient_eligibile_new_pat_elig_ind_info_stg(
pat_id DECIMAL(13,0),
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
primary_plan_grp_nbr STRING,
new_pat_ind STRING,
patient_entered_dt STRING,
eligible_ind STRING,
idh_create_dttm STRING,
idh_update_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patient_eligibile_new_pat_elig_ind_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.satr_patient_eligibile_staging2_phase2_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_sold_dt STRING,
fill_enter_dt STRING,
fill_days_supply SMALLINT,
drug_id INT,
gpi14 STRING,
inc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/satr_patient_eligibile_staging2_phase2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_complete_stg(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_complete_stg'
PARTITIONED BY (
rpt_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_complete_1_stg(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_complete_1_stg'
PARTITIONED BY (
rpt_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_merge_update_dedup_stg(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING,
rpt_month STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_merge_update_dedup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_stage_final_plan_info_stg(
pat_id DECIMAL(13,0),
third_party_plan_name STRING,
primary_plan_grp_nbr STRING,
plan_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_stage_final_plan_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_stage_plan_info_temp_stg(
pat_id DECIMAL(13,0),
third_party_plan_name STRING,
primary_plan_grp_nbr STRING,
bin_nbr STRING,
processor_ctrl_nbr STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_stage_plan_info_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_temp1_stg(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_temp1_stg'
PARTITIONED BY (
rpt_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_temp_plan_stg(
pat_id DECIMAL(13,0),
new_pat_ind INT,
enrollment_status STRING,
inc_ind STRING,
plan_type STRING,
third_party_plan_name STRING,
patient_entered_dt STRING,
first_name STRING,
last_name STRING,
birth_date STRING,
gender_code STRING,
deceased_ind STRING,
eligible_ind STRING,
primary_plan_grp_nbr STRING,
idh_create_dttm STRING,
idh_update_dttm STRING,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_temp_plan_stg'
PARTITIONED BY (
rpt_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_sold_dt STRING,
fill_enter_dt STRING,
fill_days_supply SMALLINT,
drug_id INT,
gpi14 STRING,
inc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_filtered_staging1_phase2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_1_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_sold_dt STRING,
fill_enter_dt STRING,
fill_days_supply SMALLINT,
drug_id INT,
gpi14 STRING,
inc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_filtered_staging1_phase2_1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_2_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_sold_dt STRING,
fill_enter_dt STRING,
fill_days_supply SMALLINT,
drug_id INT,
gpi14 STRING,
inc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_filtered_staging1_phase2_2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.satr_pilot_stores_phase2_stg(
str_nbr INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/satr_pilot_stores_phase2_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.5.2", "scripts": ["D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "D.53.1.wrg.marketing__campaign.sql", "T.10142.1.wrg.plan_type_info_stg.sql", "T.11541.1.wrg.satr_30_days_patients_plan_phase2_stg.sql", "T.11542.1.wrg.satr_30_days_patients_plan_phase2_temp_stg.sql", "T.11606.1.wrg.satr_patient_eligibile_demo_plan_info_stg.sql", "T.11607.1.wrg.satr_patient_eligibile_new_pat_elig_ind_info_stg.sql", "T.11609.1.wrg.satr_patient_eligibile_staging2_phase2_stg.sql", "T.11633.1.wrg.satr_patients_eligible_complete_stg.sql", "T.11634.1.wrg.satr_patients_eligible_complete_1_stg.sql", "T.11639.1.wrg.satr_patients_eligible_merge_update_dedup_stg.sql", "T.11647.1.wrg.satr_patients_eligible_stage_final_plan_info_stg.sql", "T.11648.1.wrg.satr_patients_eligible_stage_plan_info_temp_stg.sql", "T.11651.1.wrg.satr_patients_eligible_temp1_stg.sql", "T.11653.1.wrg.satr_patients_eligible_temp_plan_stg.sql", "T.11655.1.wrg.satr_patients_filtered_staging1_phase2_stg.sql", "T.11656.1.wrg.satr_patients_filtered_staging1_phase2_1_stg.sql", "T.11662.1.wrg.satr_patients_filtered_staging1_phase2_2_stg.sql", "T.11688.1.wrg.satr_pilot_stores_phase2_stg.sql"], "migration_date": "2022-08-18"}]
table_data=[{"release": "8.5.2", "table_id": "T.10142.1", "table_name": "plan_type_info_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.plan_type_info_stg", "table_legacy_schema": "dae_work.plan_type_info", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.plan_type_info_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11541.1", "table_name": "satr_30_days_patients_plan_phase2_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_30_days_patients_plan_phase2_stg", "table_legacy_schema": "dae_work.satr_30_days_patients_plan_phase2", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_30_days_patients_plan_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11542.1", "table_name": "satr_30_days_patients_plan_phase2_temp_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_30_days_patients_plan_phase2_temp_stg", "table_legacy_schema": "dae_work.satr_30_days_patients_plan_phase2_temp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_30_days_patients_plan_phase2_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11606.1", "table_name": "satr_patient_eligibile_demo_plan_info_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patient_eligibile_demo_plan_info_stg", "table_legacy_schema": "dae_work.satr_patient_eligibile_demo_plan_info", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patient_eligibile_demo_plan_info_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11607.1", "table_name": "satr_patient_eligibile_new_pat_elig_ind_info_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patient_eligibile_new_pat_elig_ind_info_stg", "table_legacy_schema": "dae_work.satr_patient_eligibile_new_pat_elig_ind_info", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patient_eligibile_new_pat_elig_ind_info_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11609.1", "table_name": "satr_patient_eligibile_staging2_phase2_stg", "table_schema": "staging__marketing__campaign.satr_patient_eligibile_staging2_phase2_stg", "table_legacy_schema": "dae_work.satr_patient_eligibile_staging2_phase2", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.satr_patient_eligibile_staging2_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11633.1", "table_name": "satr_patients_eligible_complete_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_complete_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_complete", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_complete_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11634.1", "table_name": "satr_patients_eligible_complete_1_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_complete_1_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_complete_1", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_complete_1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11639.1", "table_name": "satr_patients_eligible_merge_update_dedup_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_merge_update_dedup_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_merge_update_dedup", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_merge_update_dedup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11647.1", "table_name": "satr_patients_eligible_stage_final_plan_info_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_stage_final_plan_info_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_stage_final_plan_info", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_stage_final_plan_info_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11648.1", "table_name": "satr_patients_eligible_stage_plan_info_temp_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_stage_plan_info_temp_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_stage_plan_info_temp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_stage_plan_info_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11651.1", "table_name": "satr_patients_eligible_temp1_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_temp1_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_temp1", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_temp1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11653.1", "table_name": "satr_patients_eligible_temp_plan_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_temp_plan_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_temp_plan", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_temp_plan_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11655.1", "table_name": "satr_patients_filtered_staging1_phase2_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_stg", "table_legacy_schema": "dae_work.satr_patients_filtered_staging1_phase2", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11656.1", "table_name": "satr_patients_filtered_staging1_phase2_1_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_1_stg", "table_legacy_schema": "dae_work.satr_patients_filtered_staging1_phase2_1", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11662.1", "table_name": "satr_patients_filtered_staging1_phase2_2_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_2_stg", "table_legacy_schema": "dae_work.satr_patients_filtered_staging1_phase2_2", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_filtered_staging1_phase2_2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.2", "table_id": "T.11688.1", "table_name": "satr_pilot_stores_phase2_stg", "table_schema": "staging__marketing__campaign.satr_pilot_stores_phase2_stg", "table_legacy_schema": "dae_work.satr_pilot_stores_phase2", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.satr_pilot_stores_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Releases

Releases are the key component for defining a collection of scripts to deploy together as a package. These might be grouped together in different ways, and will always work as long as any table dependencies are deployed prior to the given script. There are both upgrades and downgrades, and the files you list will be deployed in the order they are written in. 



## Schema
```json
{
    "upgrade": [
        ...
    ],
    "downgrade": [
        ...
    ]
}
```


## Standard Practices

For a planned release, we want to assure our naming convention for our releases makes sense. This naming convention is key to defining something which others understand when working as a team. Below is an example which shows rules to adhere to when using create_release.py and defining release numbers. The example here uses R5 as a model.

5.0.0 - Changes required to alter past delpoyments. In this case, R4 tables are dropped or altered.
5.0.1 - All OTL Tables
5.1.0 - Drop 1 Sync Tables
5.1.1 - Drop 1 Manual Tables (does not exist - no drop 1 manual tables)
5.2.0 - Drop 2 Sync Tables
5.2.1 - Drop 2 Manual Tables
5.3.0 - Drop 3 Sync Tables
5.3.1 - Drop 3 Manual Tables
5.4.0 - Drop 4 Sync Tables
5.4.1 - Drop 4 Manual Tables
5.5.0 - Drop 5 Sync Tables
5.5.1 - Drop 5 Manual Tables
...


Note the pattern generally follows this set of rules:
- __Code Drops__: The Drop Number defines the second number. Note, there is no Drop 0. Thus, we use this for changes to previous releases and OTL tables.
- __Sync Tables__: For sync tables, the third number is always 0.
- __ETL Tables__: For all ETL tables, we release these with anything greater than 1. The number can go up if required to distinguish ETL tables apart.


#!/bin/bash
export REVISION="$@"

if [[ ! -v "${ENVIRONMENT}" ]]; then
    echo "[ALERT]: No ENVIRONMENT set! Defaulting to dev."
    export ENVIRONMENT=dev
fi
if [[ -v "${REVISION}" ]]; then
    echo "migrating release(s): $REVISION"
fi

echo "running for $ENVIRONMENT (NOTE: This only matters for manual deployments)"

cd ..
export $(grep -v '^#' env_config/$ENVIRONMENT.properties | xargs)
py migrations/migrate.py






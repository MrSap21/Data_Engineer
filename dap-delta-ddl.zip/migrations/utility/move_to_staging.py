import datetime
import json
import pandas as pd
import os
# from .helpers.metadata import Metadata
# meta = Metadata()
# df_ddl = meta.load_ddl_as_df()
# ddl = meta.load_ddl_json()

old_paths_to_remove = []
df_ddl = pd.read_json(path_or_buf='./ddl.json', orient='records')
with open('./ddl.json', 'r') as f:
    ddl = json.load(f)


with open('./utility/assets/move_to_staging.txt', 'r') as f:
    move_list = f.read().split('\n')
    # clean list incase of any whitespace in there
    move_list = list(map(str.strip, move_list))
print(move_list)

def fix_file(old_path, new_path, old_location, new_location, old_tbl_name, new_tbl_name):
    with open(f'.{old_path}','r') as f:
        txt = f.read()
    txt = txt.replace(old_location, new_location).replace(old_tbl_name, new_tbl_name)
    txt = txt.replace("_etl,recurse=True","_etl',recurse=True")
    with open(f'.{new_path}','w') as f:
        f.write(txt)
    old_paths_to_remove.append(f'.{old_path}')
    

try: 
    for i in ddl:
        if i.get('id') in move_list:

            old_tbl_name = i.get('param_table_name')
            new_tbl_name = f'staging__{old_tbl_name}_etl'
            old_name = i.get('table_name')
            new_name = old_name+'_etl'
            old_location = i.get('location')
            new_location = f"'abfss://wrangled@${{wrangled_sa}}.dfs.core.windows.net/{i.get('domain_param')}/{i.get('subdomain_param')}/staging/{new_name}'"
            old_path = i.get('path')
            new_path = old_path.replace('/curated/','/wrangled/').replace('1.crt.','1.wrg.').replace(old_name, new_name)
            old_down_path = i.get('downgrade_path')
            new_down_path = old_down_path.replace(old_name, new_name).replace('/curated/','/wrangled/').replace('0.crt.','0.wrg.')
            new_loc_storage_acct_param = "${wrangled_sa}"
            new_loc_container_param = "wrangled"
            new_ancestors = []
            for a in i.get('ancestors'):
                if a.startswith('D_'):
                    script =  df_ddl[(df_ddl.id.str.startswith('D')) & (df_ddl.zone=='wrangled') & (df_ddl.domain==i.get('domain')) & (df_ddl.subdomain==i.get('subdomain'))]['script'].iloc[0]
                    new_ancestors.append(script)
                else:
                    new_ancestors.append(a)

            i.update({'location': new_location})
            i.update({'path': new_path})
            i.update({'downgrade_path': new_down_path})
            i.update({'param_table_name': new_tbl_name})
            i.update({'loc_storage_acct_param': new_loc_storage_acct_param})
            i.update({'loc_container_param': new_loc_container_param})
            i.update({'zone': 'wrangled'})
            i.update({'ancestors': new_ancestors})
            i.update({'script': new_path.split('/')[-1]})
            i.update({'table_name': new_name})

            fix_file(old_path=old_path, new_path=new_path, old_location=old_location, new_location=new_location, old_tbl_name=old_tbl_name, new_tbl_name=new_tbl_name)
            fix_file(old_path=old_down_path, new_path=new_down_path, old_location=old_location, new_location=new_location, old_tbl_name=old_tbl_name, new_tbl_name=new_tbl_name)
            # for k,v in i.items():
            #     print(k,v)

except Exception as e:
    print(old_path)
    print(e)
    exit(1)
finally:
    pass

with open('./ddl.json', 'w') as f:
    json.dump(ddl, f, indent=2)

for op in old_paths_to_remove:
    os.remove(op)
import json
import pandas as pd
from pathlib import Path
from .helpers.metadata import Metadata
from .helpers.release import Release

meta = Metadata()
release = Release()

if __name__ == "__main__":
    df_ddl = meta.load_ddl_as_df()
    df_ddl_tbd = meta.load_tbd_ddl_as_df()
    release_num = release.create_release_num()
    deploy_list = release.get_deploy_list()

    upgrade, downgrade = [], []
    schemas = []
    not_found_list, tbd_list = [], []
    for tbl in deploy_list:
        try:
            i = df_ddl[df_ddl.legacy_schema == tbl]
            for a in i['ancestors'].iloc[0]:
                upgrade.append(a)
            upgrade.append(i['script'].iloc[0])
            downgrade.append(i['downgrade_path'].iloc[0].split('/')[-1])
        except Exception as e:
            try:
                pass
                print('--------------------------------------------------------------')
                print(f'[ERROR]: {tbl} not found in prepared DDL. Checking TBD DDL ...')
                i = df_ddl_tbd[df_ddl_tbd.legacy_schema == tbl].iloc[0]
                print(f'--------> [ALERT]: {tbl} in TBD DDL. Prepare updates.json with domain/subdomain & run ddl_move_tbd_file.py')
                tbd_list.append({
                    "legacy_schema": tbl,
                    "domain": "<domain>",
                    "subdomain": "<subdomain>"
                })
            except  Exception as e:
                pass
                print('--------------------------------------------------------------')
                print(f'--------> [FATAL]: {tbl} does not exist in DDL or TBD DDL. Add Script and Record in ddl.json')
                not_found_list.append(tbl)


    new_release = release.new_release_init
    up = list(set(upgrade))
    up.sort()
    new_release['upgrade'] = up
    # new_release['upgrade'] not currently used
    new_release['upgrade'] = release.check_if_table_deployed(deploy_scripts_list=new_release['upgrade'])
    release.write_release(release_json=new_release)
    meta.write_updates_json(updates_dict=tbd_list)
    release.write_not_found_list(not_found_list=not_found_list)








# ==================================

# # load metadata
# df_ddl = pd.read_json(path_or_buf='ddl.json', orient='records')
# df_tbd = pd.read_json(path_or_buf='ddl_tbd.json', orient='records')
# current_releases = [str(f.parts[-1]).replace('.json','') for f in Path('./releases/').glob('*.json')]

# # load deployment list
# with open('./utility/assets/deploy_list.txt', 'r') as f:
#     deploy_list = f.read().split('\n')
#     # clean list incase of any whitespace in there
#     deploy_list = list(map(str.strip, deploy_list))
#     deploy_list = list(map(str.lower, deploy_list))
# if len(deploy_list) == 0:
#     print('[EEROR]: ./assets/deploy_list.txt file is empty! Exiting...')
#     exit(1)


# # gather input info, recursively
# def get_release_num():
#     release_num = input('Enter valid release # [X.X.X]: ')
#     if release_num is None:
#         print('[ERROR]: Please provide a string.')
#         get_release_num()
#     elif not all([i.isdigit() for i in release_num.split('.')]):
#         print('[ERROR]: invalid release number given. Must be all digits in format X.X.X')
#         get_release_num()
#     elif len(release_num.split('.')) != 3:
#         print('[ERROR]: invalid release number given. Must be all digits in format X.X.X')
#         get_release_num()
#     elif release_num in current_releases:
#         chk = input(f'Overwrite current release? [{release_num}](Y/N): ' )
#         if chk in ['y', 'Y']:
#             return release_num
#         else:
#             get_release_num()
#     else:
#         return release_num

# release_num = get_release_num()


# upgrade, downgrade = [], []
# schemas = []
# not_found_list, tbd_list = [], []
# for tbl in deploy_list:
#     try:
#         i = df_ddl[df_ddl.legacy_schema == tbl]
#         for a in i['ancestors'].iloc[0]:
#             upgrade.append(a)
#         upgrade.append(i['script'].iloc[0])
#         downgrade.append(i['downgrade_path'].iloc[0].split('/')[-1])
#     except Exception as e:
#         try:
#             print('--------------------------------------------------------------')
#             print(f'[ERROR]: {tbl} not found in prepared DDL. Checking TBD DDL ...')
#             i = df_tbd[df_tbd.legacy_schema == tbl].iloc[0]
#             print(f'    [ALERT]: {tbl} in TBD DDL. Prepare updates.json with domain/subdomain & run ddl_move_tbd_file.py')
#             tbd_list.append({
#                 "legacy_schema": tbl,
#                 "domain": "<domain>",
#                 "": "<>"
#             })
#         except  Exception as e:
#             print('--------------------------------------------------------------')
#             print(f'    [FATAL]: {tbl} does not exist in DDL or TBD DDL. Add Script and Record in ddl.json')
#             not_found_list.append(tbl)


# release = {
#     "upgrade": [],
#     "downgrade": []
# }
# up = list(set(upgrade))
# down = list(set(downgrade))
# up.sort()
# down.sort(reverse=True)
# release['upgrade'] = up
# release['downgrade'] = down


# with open(f'./releases/{release_num}.json', 'w') as f:
#     json.dump(release, f, indent=2)

# with open(f'./utility/assets/updates.json', 'w') as f:
#     json.dump(tbd_list, f, indent=2)

# with open(f'./utility/assets/not_found_list.txt', 'w') as f:
#     for tbl in not_found_list:
#         f.write(f'{tbl}\n')
import datetime
import json
import pandas as pd

import shutil
from zipfile import ZipFile

namingfix = {
    'wrangled': 'wrg',
    'curated': 'crt'
}

# ENTER YOURE TABLE NAME(S) WHICH YOU NEED TO UPDATE IN THE FILE HERE
with open('./utility/assets/updates.json', 'r') as f:
    tables = json.load(f)

with open('./ddl.json', 'r') as f:
    ddl = json.load(f)

df_ddl = pd.read_json(path_or_buf='./ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./ddl_tbd.json', orient='records')

for t in tables:
    df_update = df_tbd[df_tbd.legacy_schema == t.get('legacy_schema')]
    if len(df_update) > 1 or len(df_ddl[df_ddl.legacy_schema == t.get('legacy_schema')]) > 0:
        print('[WARNING] =====================================')
        print(f"Error! More than 1 table found for {t.get('legacy_schema')}")
        print('[ON] ==========================================')
        print(t.get('legacy_schema'))
        print(df_update)

    else:
        try:
            table_name = df_update['table_name'].iloc[0]
            table_zone = df_update['zone'].iloc[0]
            name = df_update['path'].iloc[0].split('.')[-2]

            zippath = '../scripts/' + df_update['zone'].iloc[0] + '/tbd.zip'
            path = df_update['path'].iloc[0].replace('./scripts/wrangled/','').replace('./scripts/curated/','')
            new_path = '.' + df_update['path'].iloc[0].replace('/tbd/',f"/{t.get('domain','')}/{t.get('subdomain','')}/")
            new_path = new_path.replace(f".1.{name}",f".1.{namingfix[table_zone]}.{name}").replace(f".0.{name}",f".1.{namingfix[table_zone]}.{name}")
            new_location_addtl_path = f"${{DOMAIN_{t.get('domain')}}}/${{SUBDOMAIN_{t.get('subdomain')}}}/"
            if df_update['zone'].iloc[0] == 'wrangled':
                if '_stg.sql' not in new_path:
                    new_path = new_path.replace('.sql','_stg.sql')
                    new_location_addtl_path = new_location_addtl_path + "staging/"
                    
            new_script = new_path.split('/')[-1]
            new_down_script = new_script.replace(f".1.{namingfix[table_zone]}",f".0.{namingfix[table_zone]}")
            new_downgrade_path = '/'.join(new_path.split('/')[:-1]) + '/downgrade/' + new_down_script
            
            new_domain_param = f"${{DOMAIN_{t.get('domain')}}}"
            new_subdomain_param = f"${{SUBDOMAIN_{t.get('subdomain')}}}"
            new_location = df_update['location'].iloc[0].replace('/${DOMAIN_tbd}/${SUBDOMAIN_tbd}/',f'/{new_domain_param}/{new_subdomain_param}/').replace('_tbd}',f"_{t.get('domain')}}}")
            new_table_name_param = df_update['param_table_name'].iloc[0].replace(df_update['domain_param'].iloc[0], new_domain_param).replace(df_update['subdomain_param'].iloc[0], new_subdomain_param)
            ancestors = df_ddl[(df_ddl.id.str.startswith('D')) & (df_ddl.domain == t.get('domain')) & (df_ddl.subdomain == t.get('subdomain')) & (df_ddl.zone == table_zone)]['script'].tolist()
            # this part writes the new file
            # ======================================================================
            print(f"--- copying {zippath}/{path} into {new_path}")
            with ZipFile(zippath) as z:
                with z.open(path) as zf, open(new_path,'wb') as f:
                    shutil.copyfileobj(zf, f)
            with open(new_path,'r') as f:
                txt = f.read()
            txt = txt.replace(df_update['location'].iloc[0], new_location)\
                .replace(df_update['domain_param'].iloc[0], new_domain_param)\
                .replace(df_update['subdomain_param'].iloc[0], new_subdomain_param)
                
            with open(new_path,'w') as f:
                f.write(txt)
            with open(new_downgrade_path,'w') as f:
                f.write('-- Databricks notebook source\n')
                f.write('SET spark.databricks.delta.retentionDurationCheck.enabled = false;\n')
                f.write(f"DELETE FROM {new_table_name_param};\n")
                f.write(f"VACUUM {new_table_name_param} RETAIN 0 HOURS;\n")
                f.write(f"DROP TABLE {new_table_name_param};\n")
                f.write('SET spark.databricks.delta.retentionDurationCheck.enabled = True;\n')
                f.write('-- COMMAND ----------\n')
                f.write('%python\n')
                f.write("dbutils.fs.rm(${TABLE_LOCATION}, recurse=True)")
            # ======================================================================
            df_update = df_update.fillna('').astype(str)
            # this part updates the json metadata
            d = {
                "id": df_update['id'].iloc[0],
                "script": new_script,
                "path": new_path.replace('../','./'),
                "table_name": df_update['table_name'].iloc[0],
                "param_table_name": new_table_name_param,
                "legacy_db": df_update['legacy_db'].iloc[0],
                "legacy_schema": df_update['legacy_schema'].iloc[0],
                "table_type": df_update['table_type'].iloc[0],
                "zone": df_update['zone'].iloc[0],
                "domain": t.get('domain'),
                "subdomain": t.get('subdomain'),
                "data_classification_level": t.get('data_classification_level'),
                "location_addtl_path": new_location_addtl_path,
                "location": "",
                "domain_param": new_domain_param,
                "subdomain_param": new_subdomain_param,
                "loc_storage_acct_param": df_update['loc_storage_acct_param'].iloc[0].replace('_tbd}',f"_{t.get('domain')}}}"),
                "loc_container_param": df_update['loc_container_param'].iloc[0].replace('_tbd}',f"_{t.get('domain')}}}"),
                "deploy_flag": "",
                "downgrade_path": new_downgrade_path.replace('../','./'),
                "storage_type": df_update['storage_type'].iloc[0],
                "partitioned_by": "\n  wo_complete_dt_bus_wk_sk INT",
                "clustered_by": df_update['clustered_by'].iloc[0],
                "sorted_by": df_update['sorted_by'].iloc[0],
                "table_buckets": df_update['table_buckets'].iloc[0],
                "ancestors": ancestors,
                "descendents": df_update['descendents'].iloc[0],
                "create_date": df_update['create_date'].iloc[0],
                "created_by": "brandon.donelan@walgreens.com",
                "update_date": datetime.datetime.now().strftime('%Y-%m-%d'),
                "updated_by": "tbd",
                "deployment_date": datetime.datetime.now().strftime('%Y-%m-%d'),
                "deploy_file_path": ""
            }
            ddl.append(d)

            with open('./ddl.json', 'w') as f:
                json.dump(ddl, f, indent=2)
            
            print(d['script'])
            print(d['downgrade_path'].split('/')[-1])
        except Exception as e:
            print('[ERROR] =======================================')
            print(e)
            print('[ON] ==========================================')
            print(t.get('legacy_schema'))
            print(df_update)
        


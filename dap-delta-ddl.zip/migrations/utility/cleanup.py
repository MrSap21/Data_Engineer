import json
import pandas as pd
import re
import os
from dataclasses import dataclass
from pathlib import Path
from .helpers.metadata import Metadata
from .helpers.release import Release

meta = Metadata()
release = Release()
scripts = set()
used, not_used = [], []
ddl_clean = []
idx=0

@dataclass 
class File:
    name: str
    path: str
    new_name: str
    new_path: str

if __name__ == "__main__":
    current_releases = release.list_releases()
    ddl = meta.open_ddl_json()
    for r in current_releases:
        rel = release.open_release(release=r)

        for i in rel['upgrade']:
            if '.1.crt' in i or '.1.wrg' in i:
                scripts.add(i) 
    
    for d in ddl:
        if d.get('script') in scripts or d.get('script').startswith('D.'):
            ddl_clean.append(d.copy())
    
    for d in ddl_clean:
        filename = d.get('script')
        filepath = d.get('path')
        if not filename.startswith('D.'):
            idx+=1
            file_parts = filename.split('.')
            new_id = f"{file_parts[0]}.{idx}.{file_parts[2]}"
            new_filename = f"{file_parts[0]}.{idx}.{file_parts[2]}.{file_parts[3]}.{file_parts[4]}.sql"
            new_filepath = f'./clean/{new_filename}'
            # new_filepath = filepath.replace(filename,new_filename).replace('./scripts/', './clean/')
            d.update({
                'id': new_id,
                'script': new_filename,
                'path': new_filepath
            })
        else:
            new_filename = filename
            new_filepath = f'./clean/{new_filename}'
        used.append(File(filename, filepath, new_filename, new_filepath))

for i in used:
    print(i.name, i.new_name)
        

    
       


    # for file in Path('../scripts/').glob('**/*.sql'):
    #     filepath = str(file).replace('\\','/')
    #     filename = filepath.split('/')[-1]
    #     if filename in scripts:
    #         used.append(File(filename, filepath))

    #     if filename not in scripts:
    #         not_used.append(File(filename, filepath))
    #         idx=idx+1
    # for i in used:
    #     print(i.name)




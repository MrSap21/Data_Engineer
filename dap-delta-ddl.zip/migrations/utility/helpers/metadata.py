import json
import pandas as pd
from pathlib import Path
from typing import List, Dict

class Metadata:
    def __init__(self):
        self.stem = ''
        cwd = Path().cwd()
        path_parts = cwd.parts
        if 'migrations' == path_parts[-1]:
            self.stem = './' + self.stem
        elif 'utility' == path_parts[-1]:
            self.stem = '../' + self.stem
        elif 'dap-delta-ddl' == path_parts[-1]:
            self.stem = './migrations/' + self.stem
        
        self.ddl_file = self.stem + 'ddl.json'
        self.ddl_tbd_file = self.stem + 'ddl_tbd.json'
        self.assets_stem = self.stem + 'utility/assets'

    def open_ddl_json(self) -> Dict:
        """Opens the ddl metadata in ddl.json and returns a python dictionary object"""
        with open(self.ddl_file, 'r') as f:
            ddl = json.load(f)
        return ddl

    def open_tbd_ddl_json(self) -> Dict:
        """Opens the ddl_tbd metadata in ddl_tbd.json and returns a python dictionary object"""
        with open(self.ddl_tbd_file, 'r') as f:
            ddl_tbd = json.load(f)
        return ddl_tbd

    def load_ddl_as_df(self) -> pd.DataFrame:
        """Opens the ddl metadata in ddl.json and returns a pandas dataframe"""
        df_ddl = pd.read_json(path_or_buf=self.ddl_file, orient='records')
        return df_ddl

    def load_tbd_ddl_as_df(self) -> pd.DataFrame:
        """Opens the ddl metadata in ddl_tbd.json and returns a pandas dataframe"""
        df_tbd_ddl = pd.read_json(path_or_buf=self.ddl_tbd_file, orient='records')
        return df_tbd_ddl

    def write_ddl(self, new_ddl) -> None:
        """will overwrite the ddl.json metadata given you update the dictionary and need to save the changes.
        -> includes a safety check to assure your intentions. exits if "N"
        """
        chk = input('Are you sure you want to overwrite the Metadata DDL? (Y/N): ')
        if chk.lower() == 'y':
            print('writing json ....')
            with open('./ddl.json', 'w') as f: #self.ddl_file
                json.dump(new_ddl, f, indent=2)
            print('done!')
        else:
            print('Not overwriting based on your input!')
            exit(0)

    def load_updates_json(self) -> Dict:
        with open(f'{self.assets_stem}/updates.json', 'r') as f:
            updates = json.load(f)
        return updates
    
    def clear_updates_json(self) -> None:
        with open(f'{self.assets_stem}/updates.json', 'w') as f:
            json.dumps('{[]}')

    def write_updates_json(self, updates_dict: Dict) -> None:
        """writes the assets/updates.json document for use with moving ddl from tbd zip folders to the repo"""
        with open(f'{self.assets_stem}/updates.json', 'w') as f:
            json.dump(updates_dict, f, indent=2) 
    
    def create_ancestors(self, zone: str, domain: str, subdomain: str) -> List:
        df_ddl = self.load_ddl_as_df()
        ancestors = df_ddl[(df_ddl.id.str.startswith('D')) & (df_ddl.zone==zone) & (df_ddl.domain==domain) & (df_ddl.subdomain==subdomain)]['script'].tolist()
        return ancestors
import json
import pandas as pd
from pathlib import Path
from typing import List, Dict

class Release:
    def __init__(self):
        self.stem = ''
        cwd = Path().cwd()
        path_parts = cwd.parts
        if 'migrations' == path_parts[-1]:
            self.stem = './' + self.stem
        elif 'utility' == path_parts[-1]:
            self.stem = '../' + self.stem
        elif 'dap-delta-ddl' == path_parts[-1]:
            self.stem = './migrations/' + self.stem
        self.release_num = ""
        self.new_release_init = {
            "upgrade": [],
            "downgrade": []
        }
        
        self.ddl_file = self.stem + 'ddl.json'
        self.ddl_tbd_file = self.stem + 'ddl_tbd.json'
        self.assets_stem = self.stem + 'utility/assets'
        self.release_stem = self.stem + 'releases'
        self.R = ''
        self.current_releases = [str(f.parts[-1]).replace('.json','') for f in Path(self.release_stem).glob('*.json')]

    def list_releases(self) -> List:
        """Returns a list of all current releases"""
        return self.current_releases

    def create_release_num(self, _release_num: str = None) -> str:
        # gather input info, recursively
        if _release_num is not None:
            release_num = _release_num
        else:
            release_num = input('Enter valid release # [X.X.X]: ')
            
        if release_num is None:
            print('[ERROR]: Please provide a string.')
            create_release_num()
        elif not all([i.isdigit() for i in release_num.split('.')]):
            print('[ERROR]: invalid release number given. Must be all digits in format X.X.X')
            create_release_num()
        elif len(release_num.split('.')) != 3:
            print('[ERROR]: invalid release number given. Must be all digits in format X.X.X')
            create_release_num()
        elif release_num in self.current_releases:
            chk = input(f'Overwrite current release? [{release_num}](Y/N): ' )
            if chk in ['y', 'Y']:
                self.R = release_num.split('.')[0]
                self.release_num = release_num
                return release_num
            else:
                create_release_num()
        else:
            self.R = release_num.split('.')[0]
            self.release_num = release_num
            return release_num

    def get_deploy_list(self) -> List:
        """Reads the list stored in assets/deployment_list.txt to know what legacy tables to create a release for"""
        with open(f"{self.assets_stem}/deploy_list.txt", 'r') as f:
            deploy_list = f.read().split('\n')
            # clean list incase of any whitespace in there
            deploy_list = list(map(str.strip, deploy_list))
            deploy_list = list(map(str.lower, deploy_list))
        if len(deploy_list) == 0:
            print('[EEROR]: ./assets/deploy_list.txt file is empty! Exiting...')
            exit(1)
        return deploy_list

    def get_releases_for_major_release(self) -> List:
        """This uses previously inputed info to find the releases which are grouped with this release. 
            -> For example 7.4.5 will return "7" for Release 7.
            -> Then, it will list out all releases starting with 7, and return that to the user.
            -> used in create_release.py to filter scripts which are already deployed
        """
        if self.R == '':
            print('R is not defined given the release number entered - was it not entered yet?')
            print('check helpers.release.Release.get_releases_for_major_release function to trace')
            exit(1)
        R_list = []
        for i in self.current_releases:
            if i.split('.')[0] == self.R:
                R_list.append(i)
        return R_list

    def open_release(self, release: str) -> pd.DataFrame:
        """opens a release json document defining code to deploy"""
        try:
            with open(f"{self.release_stem}/{release}.json", 'r') as f:
                release_json = json.load(f)
        except Exception as e:
            print(f'[FATAL]: Error with json release: {release}')
            exit(1)
        return release_json

    def check_if_table_deployed(self, deploy_scripts_list: List) -> List:
        """Given a release of new scripts, this checks to see if it is already in a past release. This way it is not deployed 2 times."""
        releases: List = self.get_releases_for_major_release()
        for r in releases:
            if r < self.release_num:
                scripts = self.open_release(r)
                for s in scripts['upgrade']:
                    if s in deploy_scripts_list and not s.startswith('D'):
                        print(f'{s} already in release {r}')
                        deploy_scripts_list.remove(s)
        return deploy_scripts_list
        
    def write_release(self, release_json: Dict) -> None:
        """given input for the release json, write the release json document in migrations/releases/X.X.X.json"""
        with open(f'./releases/{self.release_num}.json', 'w') as f:
            json.dump(release_json, f, indent=2)

    def write_not_found_list(self, not_found_list: List) -> None:
        with open(f'./utility/assets/not_found_list.txt', 'w') as f:
            for tbl in not_found_list:
                f.write(f'{tbl}\n')
    
import json
import pandas as pd
from dataclasses import dataclass, asdict, InitVar
from typing import Optional, List
from .helpers.metadata import Metadata
from .helpers.release import Release

meta = Metadata()

# configs = {
#     "config1_otl": {"config": []},
#     "config1_1": {"config": []},
#     "config1_2": {"config": []},
#     "config2": {"config": []},
#     "config3": {"config": []},
# }

df_phase2 = pd.read_csv('./utility/assets/phase2.csv')
df_delta = df_phase2[df_phase2.plan_flag == True]

scripts1_otl = df_delta[(df_delta.tranche == 1.0) & (df_delta.plan_flag == True) & (df_delta.migration_type == '1x Load Only')]['ddl_lookup'].tolist()
scripts4_1 = df_delta[(df_delta.tranche == 4.1)]['ddl_lookup'].tolist()
scripts4_2 = df_delta[(df_delta.tranche == 4.2)]['ddl_lookup'].tolist()
scripts = scripts1_otl + scripts4_1 + scripts4_2 

ReleaseJSON_1_otl = {"release_num":"9.1.0", "release": {"upgrade":[],"downgrade":[]}}
ReleaseJSON_4_1 = {"release_num":"9.4.1", "release": {"upgrade":[],"downgrade":[]}}
ReleaseJSON_4_2 = {"release_num":"9.4.2", "release": {"upgrade":[],"downgrade":[]}}


@dataclass 
class Config:
    location: InitVar
    new_location: InitVar
    env: InitVar = None

    sourceEnvironment: str = "<env>"
    targetEnvironment: str = "<env>"
    sourceContainer: str = "curated"
    targetContainer: str = None
    sourceDomain: str = "legacy"
    targetDomain: str = None
    sourceZone: str = "curated"
    targetZone: str = "curated"
    sourcePath: str = None
    targetPath: str = ""

    def __post_init__(self, location, new_location, env=None):
        if "curated@dapprodadlscrt01" in location:
            self.sourcePath = location.replace("abfss://curated@dapprodadlscrt01.dfs.core.windows.net/","")
        else:
            self.sourceDomain = self.targetDomain
            self.sourceContainer = location.replace('abfss://','').split('@')[0]
            self.sourcePath = f"/{location.split('/')[-1]}"
        if env:
            self.sourceEnvironment = env
            self.targetEnvironment = env


drop_scripts_path='./scripts/phase-2-migration'
if __name__ == "__main__":
    df_ddl = meta.load_ddl_as_df()
    ddl = meta.open_ddl_json()
    
    changes=[]
    for d in ddl:
        if d['script'] in scripts:
            df_d = df_delta[df_delta.ddl_lookup == d['script']]
            if df_d.classification.iloc[0] not in ['pci', 'phi', 'pii', 'bussnstv', 'nonsnstv']:
                print(f'BAD Classification: {df_d.classification.iloc[0]} on table: {df_d.table_schema.iloc[0]}')
            
            d['location'] = ''
            d['location_addtl_path'] = ''
            d['data_classification_level'] = df_d.classification.iloc[0]
            
            changes.append(d['script'])
            down_script = d['downgrade_path'].split('/')[-1]
            d['downgrade_path'] = f'{drop_scripts_path}/{down_script}'
            with open(f".{d['downgrade_path']}", 'w') as f:
                f.write('-- Databricks notebook source\n')
                f.write(f'DROP TABLE IF EXISTS {df_d.table_schema.iloc[0]};')
            
            conf = asdict(Config(
                location = df_d.table_location.iloc[0],
                new_location = df_d.new_location.iloc[0],
                env = "prod",
                sourceContainer = "curated",
                targetContainer = df_d.destContainer.iloc[0],
                targetDomain = d["domain"],
            ))

            if d['script'] in scripts1_otl:
                # configs["config1_otl"]["config"].append(conf)
                ReleaseJSON_1_otl["release"]["upgrade"].append(down_script)
                ReleaseJSON_1_otl["release"]["upgrade"].append(d['script'])
            if d['script'] in scripts4_1:
                #configs["config1_1"]["config"].append(conf)
                ReleaseJSON_4_1["release"]["upgrade"].append(down_script)
                ReleaseJSON_4_1["release"]["upgrade"].append(d['script'])
            if d['script'] in scripts4_2:
                #configs["config1_2"]["config"].append(conf)
                ReleaseJSON_4_2["release"]["upgrade"].append(down_script)
                ReleaseJSON_4_2["release"]["upgrade"].append(d['script'])
    
    print(len(changes))
    # with open('config1_1.json', 'w') as f:
    #     json.dump(configs["config1_1"], f, indent=4)
    # with open('config1_2.json', 'w') as f:
    #     json.dump(configs["config1_2"], f, indent=4)
    # with open('config2.json', 'w') as f:
    #     json.dump(configs["config2"], f, indent=4)
    # with open('config3.json', 'w') as f:
    #     json.dump(configs["config3"], f, indent=4)
    
    releases = [ReleaseJSON_1_otl, ReleaseJSON_4_1, ReleaseJSON_4_2]
    for r in releases:
        release = Release()
        release.create_release_num(r["release_num"])
        release.write_release(release_json=r["release"])

    meta.write_ddl(new_ddl=ddl)
    #chk = df_phase2[['ddl_lookup','table_schema']].groupby('ddl_lookup').count().reset_index()
    
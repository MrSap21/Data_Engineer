import datetime
import json
import pandas as pd
import os

from .helpers.metadata import Metadata
meta = Metadata()
mapper = {
        'Y': True,
        'N': False
    }

record = {
    "id": "",
    "script": "",
    "path": "",
    "table_name": "",
    "param_table_name": "",
    "legacy_db": "",
    "legacy_schema": "",
    "table_type": "",
    "zone": "",
    "domain": "",
    "subdomain": "",
    "data_classification_level": "",
    "location_addtl_path": "",
    "location": "",
    "domain_param": "",
    "subdomain_param": "",
    "loc_storage_acct_param": "",
    "loc_container_param": "",
    "deploy_flag": "0",
    "downgrade_path": "",
    "storage_type": "",
    "partitioned_by": "",
    "clustered_by": "",
    "sorted_by": "",
    "table_buckets": "",
    "ancestors": [],
    "descendents": [],
    "create_date": datetime.datetime.now().strftime('%Y-%m-%d'),
    "created_by": "create_script",
    "update_date": "",
    "updated_by": "",
    "deployment_date": "",
    "deploy_file_path": ""
}

def create_record(meta):
    df_ddl = meta.load_ddl_as_df()
    df_tbd_ddl = meta.load_tbd_ddl_as_df()
    

    q = input('Add Versioned DDL for Existing Table? (Y/N): ')
    if mapper[q.upper()]:
        tbl_id = input('Table ID: ')
        if '.' in tbl_id: 
            last_version = int(tbl_id.split('.')[-1]) + 1
            new_tbl_id = '.'.join(tbl_id.split('.')[:-1]) + f'.{last_version}'


        df_ddl_record = df_ddl[df_ddl.id == tbl_id]
        ancestors = df_ddl_record['ancestors'].iloc[0]
        ancestors.append(df_ddl_record['script'].iloc[0])
        record['id'] = new_tbl_id
        record['script'] = df_ddl_record['script'].iloc[0].replace(tbl_id, new_tbl_id)
        record['path'] = df_ddl_record['path'].iloc[0].replace(tbl_id, new_tbl_id)
        record['table_name'] = df_ddl_record['table_name'].iloc[0]
        record['param_table_name'] = df_ddl_record['param_table_name'].iloc[0]
        record['legacy_db'] = df_ddl_record['legacy_db'].iloc[0]
        record['legacy_schema'] = df_ddl_record['legacy_schema'].iloc[0]
        record['table_type'] = df_ddl_record['table_type'].iloc[0]
        record['zone'] = df_ddl_record['zone'].iloc[0]
        record['domain'] = df_ddl_record['domain'].iloc[0]
        record['subdomain'] = df_ddl_record['subdomain'].iloc[0]
        record['data_classification_level'] = df_ddl_record['data_classification_level'].iloc[0]
        record['location_addtl_path'] = df_ddl_record['location_addtl_path'].iloc[0]
        record['location'] = df_ddl_record['location'].iloc[0]
        record['domain_param'] = df_ddl_record['domain_param'].iloc[0]
        record['subdomain_param'] = df_ddl_record['subdomain_param'].iloc[0]
        record['loc_storage_acct_param'] = df_ddl_record['loc_storage_acct_param'].iloc[0]
        record['loc_container_param'] = df_ddl_record['loc_container_param'].iloc[0]
        record['storage_type'] = "DELTA"
        record['partitioned_by'] = df_ddl_record['partitioned_by'].iloc[0]
        record['clustered_by'] = df_ddl_record['clustered_by'].iloc[0]
        record['sorted_by'] = df_ddl_record['sorted_by'].iloc[0]
        record['table_buckets'] = df_ddl_record['table_buckets'].iloc[0]
        record['ancestors'] = ancestors
        record['descendents'] = df_ddl_record['descendents'].iloc[0]

    else:
        obj_type = input('Object Type (Database=D, Table=T, View=V): ').upper()
        obj_name = input('Table Name: ').lower()
        domain = input('Domain: ').lower()
        subdomain = input('Subdomain: ').lower()
        zone = input('Zone: ').lower()
        data_class = input('Data Classification (pci/phi/pii/bussns/ or empty): ').lower()
        if zone not in ['curated', 'wrangled']:
            raise("Zone must be eiter curated or wrangled!")

        df = pd.concat([df_ddl, df_tbd_ddl])
        df['idnum'] = df['id'].copy()
        df['idnum'] = df['idnum'].apply(lambda x: x.split('.')[1] if isinstance(x, str) else 0).astype(int)
        num = max(df[df.id.str.startswith('T')]['idnum'].tolist()) + 1
        new_tbl_id = f"{obj_type}.{num}.1"
        new_down_id = f"{obj_type}.{num}.0"
        if zone == 'curated':
            location_addtl_path = f"${{DOMAIN_{domain}}}/${{SUBDOMAIN_{subdomain}}}/"
            location = f"'abfss://${{CONTAINER_crt_{domain}}}@${{STORAGE_ACCT_crt_{domain}}}.dfs.core.windows.net/${{DOMAIN_{domain}}}/${{SUBDOMAIN_{subdomain}}}/{obj_name}'"
            param_table_name = f"${{DOMAIN_{domain}}}__${{SUBDOMAIN_{subdomain}}}.{obj_name}"
            zone_abrv='crt'
        else:
            if not obj_name.endswith('_stg'):
                obj_name=obj_name+'_stg'
            location_addtl_path = f"${{DOMAIN_{domain}}}/${{SUBDOMAIN_{subdomain}}}/staging/"
            location = f"'abfss://${{CONTAINER_wrg_{domain}}}@${{STORAGE_ACCT_wrg_{domain}}}.dfs.core.windows.net/${{DOMAIN_{domain}}}/${{SUBDOMAIN_{subdomain}}}/staging/{obj_name}'"
            param_table_name = f"staging__${{DOMAIN_{domain}}}__${{SUBDOMAIN_{subdomain}}}.{obj_name}"
            zone_abrv='wrg'
            

        record['id'] = new_tbl_id
        record['script'] = f"{new_tbl_id}.{zone_abrv}.{obj_name}.sql"
        record['path'] = f"./scripts/{zone}/{domain}/{subdomain}/{new_tbl_id}.{zone_abrv}.{obj_name}.sql"
        record['table_name'] = obj_name
        record['param_table_name'] = param_table_name
        record['legacy_db'] = None
        record['legacy_schema'] = ""
        record['table_type'] = obj_type
        record['zone'] = zone
        record['domain'] = domain
        record['subdomain'] = subdomain
        record['data_classification_level'] = data_class
        record['location_addtl_path'] = location_addtl_path
        record['location'] = location
        record['domain_param'] = f"${{DOMAIN_{domain}}}"
        record['subdomain_param'] = f"${{SUBDOMAIN_{subdomain}}}"
        record['loc_storage_acct_param'] = f"${{STORAGE_ACCT_crt_{domain}}}"
        record['loc_container_param'] = f"${{CONTAINER_crt_{domain}}}"
        record['downgrade_path'] = f"./scripts/{zone}/{domain}/{subdomain}/downgrade/{new_down_id}.{zone_abrv}.{obj_name}.sql"
        record['storage_type'] = "DELTA"
        record['ancestors'] = df_ddl[(df_ddl.table_type == 'database') & (df_ddl.domain == domain) & (df_ddl.subdomain == subdomain) & (df_ddl.zone == zone)]['script'].tolist()

    return record



def confirm(record):
    print(json.dumps(record, indent=2))
    print('')
    chk_input = input('Confirm above record is correct? (Y/N): ').upper()
    chk = mapper[chk_input]
    return chk


def write_empty_file(record):
    print('writing at path: ', f".{record['path']}")
    with open(f".{record['path']}", 'w') as f:
        f.write('-- Databricks notebook source\n')
    if record['id'].endswith('1'):
        with open(f".{record['downgrade_path']}", 'w') as f:
            f.write('-- Databricks notebook source\n')

if __name__ == "__main__":
    try:
        ddl = meta.open_ddl_json()
        record = create_record(meta)
        confirm = confirm(record=record)
        if confirm:
            write_empty_file(record)
            ddl.append(record)
            meta.write_ddl(new_ddl=ddl)
    except Exception as e:
        print('[ERROR]: problem creating ddl !')
        print(e)
        exit(1)

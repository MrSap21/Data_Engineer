import json
import pandas as pd
import re
import os
from pathlib import Path
from .helpers.metadata import Metadata
from .helpers.release import Release

meta = Metadata()
release = Release()
type_mapper = {
    '0': 'drop',
    '1': 'create',
    '2': 'alter/insert',
    '?': '?'
}
if __name__ == "__main__":
    current_releases = release.list_releases()
    df_ddl = meta.load_ddl_as_df()
    with open('../env_config/prod.properties', 'r') as f:
        env = f.read()
    envs = env.split('\n')
    for e in envs:
        if '=' in e:
            e = e.strip().split('=') 
            os.environ[e[0]] = e[1]
        
    txt = []
    r_tables, r_scripts, report = {}, {}, []
    notes = {}
    for r in current_releases:
        r_tables[r] = []
        r_scripts[r] = []
        

        rel = release.open_release(release=r)
        print(r, '---------------------------')
        try:
            for i in rel['upgrade']:
                if '.0.' in i:
                    version='0'
                    j = i.replace('.0.', '.1.')
                    df_i = df_ddl[df_ddl.script == j]
                    if not len(df_i)>0:
                        pass
                    else:
                        r_scripts[r].append(i)
                        script_name = i
                elif '.1.' in i:
                    version='1'
                    df_i = df_ddl[df_ddl.script == i]
                    r_scripts[r].append(i)
                    script_name = i
                elif '.2.' in i:
                    version='2'
                    df_i = df_ddl[df_ddl.script == i]
                    r_scripts[r].append(i)
                    script_name = i
                else:
                    version='?'

                if len(df_i)>0 and not str(df_i['id'].iloc[0]).startswith('D.'):
                    tbl_name = str(df_i['param_table_name'].iloc[0]).replace(df_i['domain_param'].iloc[0], df_i['domain'].iloc[0]).replace(df_i['subdomain_param'].iloc[0], df_i['subdomain'].iloc[0])
                    old_name = str(df_i['legacy_schema'].iloc[0])
                    loc = df_i['location'].iloc[0]
                    params = re.findall(r"\$\{(.*?)\}", loc, re.DOTALL)
                    for p in params:
                        loc = loc.replace(f"${{{p}}}", os.getenv(p, f"${{{p}}}"))

                    partition_cols = ' '.join([a.strip().replace(',','|') for a in str(df_i['partitioned_by'].iloc[0]).split('\n')])
                    print(f"{df_i['legacy_schema'].iloc[0]} --> {tbl_name}")
                    txt.append(f"{df_i['legacy_schema'].iloc[0]} --> {tbl_name}")
                    r_tables[r].append(old_name.upper())
                    report.append({
                        'release': r,
                        'script': script_name,
                        'legacy_schema': old_name.upper(),
                        'new_schema': tbl_name,
                        'name': df_i['table_name'].iloc[0],
                        'zone': df_i['zone'].iloc[0],
                        'data_class': df_i['data_classification_level'].iloc[0],
                        'loc': loc,
                        'type': type_mapper[version]
                    })
                    
        except Exception as e:
            print(f'[ERROR]: cant find table - {i}')
            print(e)

    with open(f'{meta.assets_stem}/report/report.csv', 'w') as f:
        f.write('release #,script,legacy table schema,databricks schema,table name,zone,data classification level,location,type\n')
        for r in report:
            f.write(f"{r['release']},{r['script']},{r['legacy_schema']},{r['new_schema']},{r['name']},{r['zone']},{r['data_class']},{r['loc']},{r['type']}\n")

    with open(f'{meta.assets_stem}/report/table_list.txt', 'w') as f:
        for k in r_tables.keys():
            f.write(f'{k} -----------------------\n')
            for v in r_tables[k]:
                f.write(f'{v}\n')

    with open(f'{meta.assets_stem}/report/script_list.txt', 'w') as f:
        for k in r_scripts.keys():
            f.write(f'{k} -----------------------\n')
            for v in r_scripts[k]:
                f.write(f'{v}\n')
import datetime
import json
import pandas as pd
import os

from .helpers.metadata import Metadata

meta = Metadata()
old_paths_to_remove = []
def fix_file(old_path, new_path, old_location, new_location, old_tbl_name, new_tbl_name):
    with open(f'.{old_path}','r') as f:
        txt = f.read()
    txt = txt.replace(old_location, new_location).replace(old_tbl_name, new_tbl_name)
    with open(f'.{new_path}','w') as f:
        f.write(txt)
    
    old_paths_to_remove.append(f'.{old_path}')

new_ddl, changed = [], []
ids = []
def move(updates, ddl):
    for u in updates:
        if u.get('script', False) == False:
            print('must have script name in the updates.json file to use this tool. Exiting.')
            print(f'value: \n {u}')
            exit(1)
        else:
            for d in ddl:
                if d['script'] == u['script']:
                    new_path = d['path'].replace(d['domain'],u['domain']).replace(d['subdomain'],u['subdomain'])
                    new_downgrade_path = d['downgrade_path'].replace(d['domain'],u['domain']).replace(d['subdomain'],u['subdomain'])
                    new_domain_param = d['domain_param'].replace(d['domain'],u['domain'])
                    new_subdomain_param = d['subdomain_param'].replace(d['subdomain'],u['subdomain'])
                    new_location_addtl_path = ""
                    new_param_table_name = d['param_table_name'].replace(d['domain_param'],new_domain_param).replace(d['subdomain_param'],new_subdomain_param)
                    new_loc_storage_acct_param = ""
                    new_loc_container_param = ""
                    new_location = ""
                    fix_file(
                        old_path=d['path'], 
                        new_path=new_path, 
                        old_location=d['location'], 
                        new_location=new_location, 
                        old_tbl_name=d['param_table_name'], 
                        new_tbl_name=new_param_table_name
                    )
                    fix_file(
                        old_path=d['downgrade_path'], 
                        new_path=new_downgrade_path, 
                        old_location=d['location'], 
                        new_location=new_location, 
                        old_tbl_name=d['param_table_name'], 
                        new_tbl_name=new_param_table_name
                    )
                    d.update({'domain': u['domain']})
                    d.update({'subdomain': u['subdomain']})
                    d.update({'location_addtl_path': new_location_addtl_path})
                    d.update({'param_table_name': new_param_table_name})
                    d.update({'domain_param': new_domain_param})
                    d.update({'subdomain_param':new_subdomain_param})
                    d.update({'loc_storage_acct_param': new_loc_storage_acct_param})
                    d.update({'loc_container_param': new_loc_container_param})
                    d.update({'location': new_location})
                    d.update({'path': new_path})
                    d.update({'downgrade_path': new_downgrade_path})
                    d.update({'ancestors': meta.create_ancestors(zone=d['zone'], domain=u['domain'], subdomain=u['subdomain'])})
                    changed.append(d)
                    ids.append(d['id'])
    for d in ddl:
        if d['id'] not in ids:
            new_ddl.append(d)
    for d in changed:
        new_ddl.append(d)
    return new_ddl


if __name__ == "__main__":
    try:
        ddl = meta.open_ddl_json()
        updates = meta.load_updates_json()
        new_ddl = move(updates=updates, ddl=ddl)
    except Exception as e:
        print('[ERROR]: problem moving domains!')
        print(e)
        exit(1)
    # old paths to remove is defined above near imports
    for op in old_paths_to_remove:
        os.remove(op)
    
    meta.write_ddl(new_ddl=new_ddl)

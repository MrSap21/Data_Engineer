import datetime
import json
import os
import re
from pathlib import Path
from typing import Dict, List

ENV = os.getenv('ENVIRONMENT')
os.environ['TABLE_BUCKETS'] = '<NOT USED>'


def get_ddl_json():
    with open('./migrations/ddl.json', 'r') as f:
        ddl = json.load(f)
    return ddl


def read_release(releases, ddl) -> Dict:
    upgrades = {}
    downgrades = {}
    release_info = {}
    for r in releases:
        release_info[r] = []
        path = f"migrations/releases/{r}.json"
        print(r)
        with open(path, 'r') as f:
            release = json.load(f)
        for i in release.get('upgrade'):
            for d in ddl:
                if d.get('script','') == i:
                    release_info[r].append(i)
                    d['deploy_file_path'] = []
                    d['deploy_file_path'] = d.get('path','')
                    upgrades[i] = d.copy()
                if d.get('downgrade_path','').split('/')[-1] == i:
                    release_info[r].append(i)
                    d['deploy_file_path'] = d.get('downgrade_path','')
                    upgrades[i] = d.copy()
        for i in release.get('downgrade'):
            for d in ddl:
                if d.get('downgrade_path','').split('/')[-1] == i:
                    d['down_deploy_file_path'] = d.get('downgrade_path','')
                    downgrades[i] = d.copy()
    return {'upgrades': upgrades, 'downgrades': downgrades, 'release_info': release_info}


def set_meta_params(param: str, ddl: Dict):
    """not yet needed, but if we need to dynamically set a table's partition it will be needed"""
    if param == "PARTITION_BY":
        return ddl['partition_by']
    elif param == "TABLE_STORAGE_TYPE":
        return ddl['storage_type']
    elif param == "TABLE_LOCATION":
        if ddl['location'] is None or ddl['location'] == '':
            if ddl['zone'] == 'curated' and ddl['data_classification_level'] is not None and ddl['data_classification_level'] != '':
                location = f"'abfss://${{{ddl['subdomain']}_cntr}}-${{data_class_{ddl['data_classification_level']}}}@${{{ddl['domain']}_crt_sa}}.dfs.core.windows.net/{ddl['table_name']}'"
                ddl['location'] = location
                ddl['location_addtl_path'] = ""
                ddl['loc_storage_acct_param'] = f"${{{ddl['domain']}_crt_sa}}"
                ddl['loc_container_param'] = f"${{{ddl['subdomain']}_cntr}}-${{data_class_{ddl['data_classification_level']}}}"
            elif ddl['zone'] == 'curated' and (ddl['data_classification_level'] is None or ddl['data_classification_level'] == ''):
                location_addtl_path = f"${{DOMAIN_{ddl['domain']}}}/${{SUBDOMAIN_{ddl['subdomain']}}}/"
                location = f"'abfss://${{CONTAINER_crt_{ddl['domain']}}}@${{STORAGE_ACCT_crt_{ddl['domain']}}}.dfs.core.windows.net/${{DOMAIN_{ddl['domain']}}}/${{SUBDOMAIN_{ddl['subdomain']}}}/{ddl['table_name']}'"
                ddl['location'] = location
                ddl['location_addtl_path'] = location_addtl_path
                ddl['loc_storage_acct_param'] = f"${{STORAGE_ACCT_crt_{ddl['domain']}}}"
                ddl['loc_container_param'] = f"${{CONTAINER_crt_{ddl['domain']}}}"
            elif ddl['zone'] == 'wrangled':
                location = f"'abfss://wrangled@${{wrangled_sa}}.dfs.core.windows.net/{ddl['domain']}/{ddl['subdomain']}/staging/{ddl['table_name']}'"
                ddl['location'] = location
                ddl['location_addtl_path'] = f"{ddl['domain']}/{ddl['subdomain']}/staging/"
                ddl['loc_storage_acct_param'] = "${wrangled_sa}"
                ddl['loc_container_param'] = f"wrangled_sa"
        else:
            location = ddl['location']
        return location
    else:
        return f"{{getArgument('{param}')}}"

def write_notebook(releases: Dict):
    """collecting the DDL to write a single notebook that can be executed."""
    # Creating a generic notebook for each release pipeline execution:
    for k,v in releases['release_info'].items():
        release_num = k
        all_upgrades, release_ddl = [], {}
        scripts = []
        widgets = set()

        # enforce order of operations
        deploy_list = [i for i in releases['upgrades'].keys() if i in v]
        deployment_sorting_list = sorted(deploy_list)
        for k in deployment_sorting_list:
            if k not in scripts:
                ddl = releases['upgrades'][k]
                release_ddl[k] = ddl
                txt = Path(ddl['deploy_file_path']).read_text()
                params = re.findall(r"\$\{(.*?)\}", txt, re.DOTALL)
                if 'TABLE_LOCATION' in params:
                    txt = txt.replace("${TABLE_LOCATION}", set_meta_params(param='TABLE_LOCATION', ddl=ddl))
                    params = re.findall(r"\$\{(.*?)\}", txt, re.DOTALL) # just re-retrieve them, lazily
                for i in params:
                    if 'STORAGE_ACCT_' in i or i.endswith('_crt_sa'):
                        widgets.add(i)
                        txt = txt.replace(f"${{{i}}}",f"{{getArgument('{i}')}}")
                    else:
                        txt = txt.replace(f"${{{i}}}", os.getenv(i, set_meta_params(param=i, ddl=ddl)).strip())

                if ddl['deploy_file_path'].endswith('.sql'):
                    if '%python' in txt:
                        txt = txt.replace('-- Databricks notebook source\n','%sql\n')\
                                .replace('-- COMMAND ----------\n','# COMMAND ----------\n')\
                                .replace('%python\n','')\
                                .replace("rm('",'rm(f"').replace("',",'",')
                    else:
                        txt = txt.replace('-- Databricks notebook source\n','')\
                            .replace('-- COMMAND ----------\n','# COMMAND ----------\n')
                        lines=[]
                        for line in txt.splitlines():
                            line = line.strip()
                            if not line.startswith('--') and line != '':
                                lines.append(line)
                        txt = '\n'.join(line for line in lines)
                        txt = 'spark.sql(f"""' + txt + '""")'
                        # because teradata sync tables have {} in comments...
                        txt = txt.replace('{','{{').replace('}','}}').replace('{{getArg', '{getArg').replace("')}}.dfs", "')}.dfs")
                elif ddl['deploy_file_path'].endswith('.py'):
                    txt = txt.replace('# Databricks notebook source\n','')
                    txt = txt.replace("rm('",'rm(f"').replace("',",'",')
                all_upgrades.append(txt)
                scripts.append(k)

        end = deployment_tracking(releases=release_ddl, release_info=releases['release_info'][release_num], release_num=release_num)
        with open(f"./ddl_deploy/curated/database/deploy-{release_num}.py", "w") as f:
            f.write('# Databricks notebook source\n')
            for w in widgets:
            # for w in os.environ.keys():
                if 'STORAGE_ACCT_' in str(w) or str(w).endswith('crt_sa'):
                    f.write(f"dbutils.widgets.text(name='{w}', defaultValue='${{{w}}}', label='{w}')\n")
            f.write(f"# COMMAND ----------\n")
            for i in all_upgrades:
                f.write(f"{i}\n# COMMAND ----------\n")
            f.write(end)


def prepare_releases(release_state) -> Dict:
    """Reads the release JSON file which defines which scripts we need to migrate"""
    with open(release_state, 'r') as f:
        releases = json.load(f)
    return releases


def update_state(release_state: str, deployment: Dict) -> None:
    """Updates the state defined in ./migrations/deploy.json following the successful migration"""
    for d in deployment['deploy']:
        deployment['state'].update({d: str(datetime.datetime.now().strftime('%Y-%m-%d'))})
    deployment['deploy'] = []
    with open(release_state, 'w') as f:
        json.dump(deployment,f,indent=2)


def copy(releases: Dict) -> None:
    """copies scripts in migration from ./scripts/ to ./ddl_deploy/ folder where the DevOps pipeline will pick it up"""
    for k, ddl in releases['upgrades'].items():
        widgets=set()
        txt = Path(ddl['deploy_file_path']).read_text()
        print(k, ddl['deploy_file_path'].split('/')[-1])
        params = re.findall(r"\$\{(.*?)\}", txt, re.DOTALL)
        if 'TABLE_LOCATION' in params:
            txt = txt.replace("${TABLE_LOCATION}", set_meta_params(param='TABLE_LOCATION', ddl=ddl))
            params = re.findall(r"\$\{(.*?)\}", txt, re.DOTALL) # just re-retrieve them, lazily
        for i in params:
            if 'STORAGE_ACCT_' in i or i.endswith('_crt_sa'):
                widgets.add(i)
                txt = txt.replace(f"${{{i}}}",f"{{getArgument('{i}')}}")
            else:
                txt = txt.replace(f"${{{i}}}", os.getenv(i, set_meta_params(param=i, ddl=ddl)).strip())

        file_target_path = ddl['deploy_file_path'].replace('./scripts/','./ddl_deploy/').replace('downgrade/','')
        if file_target_path.endswith('.py'):
            txt = txt.replace('# Databricks notebook source\n','')
        elif file_target_path.endswith('.sql'):
            txt = txt.replace('-- Databricks notebook source\n','')
        create_path = '.'
        for i in file_target_path.split('/')[1:-1]:
            create_path = create_path + '/' +  i
            Path(create_path).mkdir(exist_ok=True)
        with open(file_target_path, 'w') as f:
            if file_target_path.endswith('.py'):
                f.write('# Databricks notebook source\n')
            elif file_target_path.endswith('.sql'):
                f.write('-- Databricks notebook source\n')
            for w in widgets:
                f.write(f"CREATE WIDGET TEXT {w} DEFAULT ${{w}};\n")
            f.write(txt)


def update_metadata(ddl: List, releases: Dict) -> None:
    """updates the ddl metadata following deployment"""
    new_ddl = []
    for d in ddl:
        if d.get('script') in releases['upgrades'].keys():
            d.update({
                'location_addtl_path': releases['upgrades'][d.get('script')]['location_addtl_path'],
                'location': releases['upgrades'][d.get('script')]['location'],
                'loc_storage_acct_param':  releases['upgrades'][d.get('script')]['loc_storage_acct_param'],
                'loc_container_param':  releases['upgrades'][d.get('script')]['loc_container_param'],
                'deploy_flag': True,
                'deployment_date': str(datetime.datetime.now().strftime('%Y-%m-%d'))
            })
        if d.get('downgrade_path','').split('/')[-1] in releases['upgrades'].keys():            
            d.update({
                'deploy_flag': False,
                'deployment_date': "test"
            })
        new_ddl.append(d)
    with open('./migrations/ddl.json', 'w') as f:
        json.dump(ddl, f, indent=2)
    

def deployment_tracking(releases: Dict, release_info: List, release_num: str) -> str:
    """Creates MERGE statement for tables in master_data__information_schema."""
    tbl_data = []
    release_data =[]
    table_names_list = ['.']
    release_data.append({
        'release': release_num,
        'scripts': release_info,
        'migration_date': datetime.datetime.now().strftime('%Y-%m-%d')
    })
    for i in release_info:
        if releases.get(i, False) and not i.startswith('D'):
            if '.0.' in i:
                table_names_list.append(releases.get(i)['table_name'])
            else:
                schema = releases.get(i)['param_table_name']
                location = releases.get(i)['location']
                try:
                    params = re.findall(r"\$\{(.*?)\}", schema, re.DOTALL)
                    for p in params:
                        schema = schema.replace(f"${{{p}}}", os.getenv(p, set_meta_params(param=p, ddl=schema)).strip())
                    params = re.findall(r"\$\{(.*?)\}", location, re.DOTALL)
                    for p in params:
                        location = schema.replace(f"${{{p}}}", os.getenv(p, set_meta_params(param=p, ddl=location)).strip())
                except Exception as e:
                    print(i, schema,location)
                    pass
                tbl_data.append({
                    'release': release_num,
                    'table_id': releases.get(i)['id'],
                    'table_name': releases.get(i)['table_name'],
                    'table_schema': schema,
                    'table_legacy_schema': releases.get(i)['legacy_schema'] or "",
                    'table_domain': releases.get(i)['domain'],
                    'table_subdomain': releases.get(i)['subdomain'],
                    'table_location': location,
                    'table_partition': releases.get(i)['partitioned_by'],
                    'table_db': schema.split('.')[0],
                    'table_zone': releases.get(i)['zone'],
                    'create_date': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'update_date': ""
                })
    with open('migrations/state/migrations_merge_template.py', 'r') as f:
        txt = f.read()
    txt = txt.replace('<MIGRATION_DATA>', json.dumps(release_data))
    txt = txt.replace('<TABLE_DATA>', json.dumps(tbl_data))
    txt = txt.replace('<TABLE_NAMES_LIST>',f"""'{"','".join(table_names_list)}'""")
    return txt


if __name__ == '__main__':
    deployment = prepare_releases(release_state=f"migrations/deploy.json")
    print(f"deploying the following releases: {deployment['deploy']}")
    ddl = get_ddl_json()
    releases = read_release(deployment['deploy'], ddl)
    write_notebook(releases)
    # copy(releases=releases)
    update_state(release_state=f"migrations/deploy.json", deployment=deployment)
    update_metadata(ddl=ddl, releases=releases)


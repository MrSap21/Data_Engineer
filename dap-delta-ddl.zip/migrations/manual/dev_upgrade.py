# Databricks notebook source
%sql
CREATE SCHEMA IF NOT EXISTS retail__product;
--LOCATION 'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/retail/product';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__retail__product;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/retail/product/staging';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__finance__account_payables;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/finance/account_payables/staging';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/digital/ecom/staging';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/recruiting/staging';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS hr__employment_history;
--LOCATION 'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/employment_history';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS hr__payroll;
--LOCATION 'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/payroll';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS hr__recruiting;
--LOCATION 'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/recruiting';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__hr__employment_history;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS staging__hr__organization_structure;
--LOCATION 'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/organization_structure/staging';
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS hr__employment_history.address(
  update_flag STRING, 
  person_id STRING, 
  address_type STRING, 
  start_date STRING, 
  address1 STRING, 
  apartment STRING, 
  city STRING, 
  street_number STRING, 
  address2 STRING, 
  careof STRING, 
  municipality STRING, 
  governorate STRING, 
  town STRING, 
  municipality1 STRING, 
  camp STRING, 
  camp1 STRING, 
  building STRING, 
  district STRING, 
  country STRING, 
  county STRING, 
  created_by STRING, 
  created_on STRING, 
  urbanization STRING, 
  end_date STRING, 
  last_modified_by STRING, 
  last_modified_on STRING, 
  province STRING, 
  state STRING, 
  zip_code STRING, 
  batch_id STRING, 
  create_date STRING, 
  create_user_id STRING, 
  update_date STRING, 
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/employment_history/address'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS hr__payroll.bank(
  update_flag STRING, 
  external_code BIGINT, 
  bank_country STRING, 
  bank_name STRING, 
  business_identifier_code STRING, 
  city STRING, 
  created_by STRING, 
  created_date STRING, 
  status STRING, 
  last_modified_by STRING, 
  last_modified_date STRING, 
  mdf_system_record_status STRING, 
  postal_code STRING, 
  routing_number STRING, 
  street STRING, 
  batch_id STRING, 
  create_date STRING, 
  create_user_id STRING, 
  update_date STRING, 
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/payroll/bank'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS hr__recruiting.econtacts(
  update_flag STRING, 
  employee_id STRING, 
  name STRING, 
  relationship STRING, 
  created_by STRING, 
  created_on STRING, 
  email STRING, 
  last_modified_by STRING, 
  last_modified_on STRING, 
  phone STRING, 
  primary_flag STRING, 
  second_phone STRING, 
  batch_id STRING, 
  create_date STRING, 
  create_user_id STRING, 
  update_date STRING, 
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/recruiting/econtacts'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS hr__recruiting.email(
  update_flag STRING, 
  employee_id STRING, 
  email_type STRING, 
  created_by STRING, 
  created_on STRING, 
  email_address STRING, 
  is_primary STRING, 
  last_modified_by STRING, 
  last_modified_on STRING, 
  batch_id STRING, 
  create_date STRING, 
  create_user_id STRING, 
  update_date STRING, 
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/recruiting/email'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS hr__payroll.foeventreason(
  update_flag STRING, 
  external_code STRING, 
  start_date STRING, 
  created_by STRING, 
  created_date_time STRING, 
  created_on STRING, 
  description STRING, 
  empl_status STRING, 
  end_date STRING, 
  event STRING, 
  implicit_position_action BIGINT, 
  last_modified_by STRING, 
  last_modified_date_time STRING, 
  last_modified_on STRING, 
  name STRING, 
  payroll_event STRING, 
  status STRING, 
  batch_id STRING, 
  create_date STRING, 
  create_user_id STRING, 
  update_date STRING, 
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/payroll/foeventreason'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_stg(
   update_flag STRING,  
   person_id STRING,  
   address_type STRING,  
   start_date STRING,  
   address1 STRING,  
   apartment STRING,  
   city STRING,  
   street_number STRING,  
   address2 STRING,  
   careof STRING,  
   municipality STRING,  
   governorate STRING,  
   town STRING,  
   municipality1 STRING,  
   camp STRING,  
   camp1 STRING,  
   building STRING,  
   district STRING,  
   country STRING,  
   county STRING,  
   created_by STRING,  
   created_on STRING,  
   urbanization STRING,  
   end_date STRING,  
   last_modified_by STRING,  
   last_modified_on STRING,  
   province STRING,  
   state STRING,  
   zip_code STRING,  
   tracking_id STRING,  
  batch_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_stg'
PARTITIONED BY (
  partition_column STRING)
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_stg(
   update_flag STRING,  
   external_code STRING,  
   bank_country STRING,  
   bank_name STRING,  
   business_identifier_code STRING,  
   city STRING,  
   created_by STRING,  
   created_date STRING,  
   status STRING,  
   last_modified_by STRING,  
   last_modified_date STRING,  
   mdf_system_record_status STRING,  
   postal_code STRING,  
   routing_number STRING,  
   street STRING,  
   tracking_id STRING,  
  batch_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_stg'
PARTITIONED BY (
  partition_column STRING)
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__recruiting.email_stg(
   update_flag STRING,  
   employee_id STRING,  
   email_type STRING,  
   created_by STRING,  
   created_on STRING,  
   email_address STRING,  
   is_primary STRING,  
   last_modified_by STRING,  
   last_modified_on STRING,  
   tracking_id STRING,  
  batch_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/recruiting/staging/email_stg'
PARTITIONED BY (
  partition_column STRING)
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_stg(
   update_flag STRING,  
   external_code STRING,  
   start_date STRING,  
   created_by STRING,  
   created_date_time STRING,  
   created_on STRING,  
   description STRING,  
   empl_status STRING,  
   end_date STRING,  
   event STRING,  
   implicit_position_action STRING,  
   last_modified_by STRING,  
   last_modified_date_time STRING,  
   last_modified_on STRING,  
   name STRING,  
   payroll_event STRING,  
   status STRING,  
   tracking_id STRING,  
  batch_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_stg'
PARTITIONED BY (
  partition_column STRING)
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_delta_stg(
   update_flag STRING,  
   person_id STRING,  
   address_type STRING,  
   start_date STRING,  
   address1 STRING,  
   apartment STRING,  
   city STRING,  
   street_number STRING,  
   address2 STRING,  
   careof STRING,  
   municipality STRING,  
   governorate STRING,  
   town STRING,  
   municipality1 STRING,  
   camp STRING,  
   camp1 STRING,  
   building STRING,  
   district STRING,  
   country STRING,  
   county STRING,  
   created_by STRING,  
   created_on STRING,  
   urbanization STRING,  
   end_date STRING,  
   last_modified_by STRING,  
   last_modified_on STRING,  
   province STRING,  
   state STRING,  
   zip_code STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_delta_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_persistent_stg(
   update_flag STRING,  
   person_id STRING,  
   address_type STRING,  
   start_date STRING,  
   address1 STRING,  
   apartment STRING,  
   city STRING,  
   street_number STRING,  
   address2 STRING,  
   careof STRING,  
   municipality STRING,  
   governorate STRING,  
   town STRING,  
   municipality1 STRING,  
   camp STRING,  
   camp1 STRING,  
   building STRING,  
   district STRING,  
   country STRING,  
   county STRING,  
   created_by STRING,  
   created_on STRING,  
   urbanization STRING,  
   end_date STRING,  
   last_modified_by STRING,  
   last_modified_on STRING,  
   province STRING,  
   state STRING,  
   zip_code STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_persistent_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_unchanged_stg(
   update_flag STRING,  
   person_id STRING,  
   address_type STRING,  
   start_date STRING,  
   address1 STRING,  
   apartment STRING,  
   city STRING,  
   street_number STRING,  
   address2 STRING,  
   careof STRING,  
   municipality STRING,  
   governorate STRING,  
   town STRING,  
   municipality1 STRING,  
   camp STRING,  
   camp1 STRING,  
   building STRING,  
   district STRING,  
   country STRING,  
   county STRING,  
   created_by STRING,  
   created_on STRING,  
   urbanization STRING,  
   end_date STRING,  
   last_modified_by STRING,  
   last_modified_on STRING,  
   province STRING,  
   state STRING,  
   zip_code STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_unchanged_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_delta_stg(
   update_flag STRING,  
   external_code BIGINT,  
   bank_country STRING,  
   bank_name STRING,  
   business_identifier_code STRING,  
   city STRING,  
   created_by STRING,  
   created_date STRING,  
   status STRING,  
   last_modified_by STRING,  
   last_modified_date STRING,  
   mdf_system_record_status STRING,  
   postal_code STRING,  
   routing_number STRING,  
   street STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_delta_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_persistent_stg(
   update_flag STRING,  
   external_code BIGINT,  
   bank_country STRING,  
   bank_name STRING,  
   business_identifier_code STRING,  
   city STRING,  
   created_by STRING,  
   created_date STRING,  
   status STRING,  
   last_modified_by STRING,  
   last_modified_date STRING,  
   mdf_system_record_status STRING,  
   postal_code STRING,  
   routing_number STRING,  
   street STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_persistent_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_unchanged_stg(
   update_flag STRING,  
   external_code BIGINT,  
   bank_country STRING,  
   bank_name STRING,  
   business_identifier_code STRING,  
   city STRING,  
   created_by STRING,  
   created_date STRING,  
   status STRING,  
   last_modified_by STRING,  
   last_modified_date STRING,  
   mdf_system_record_status STRING,  
   postal_code STRING,  
   routing_number STRING,  
   street STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_unchanged_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_delta_stg(
   update_flag STRING,  
   external_code STRING,  
   start_date STRING,  
   created_by STRING,  
   created_date_time STRING,  
   created_on STRING,  
   description STRING,  
   empl_status STRING,  
   end_date STRING,  
   event STRING,  
   implicit_position_action BIGINT,  
   last_modified_by STRING,  
   last_modified_date_time STRING,  
   last_modified_on STRING,  
   name STRING,  
   payroll_event STRING,  
   status STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_delta_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_persistent_stg(
   update_flag STRING,  
   external_code STRING,  
   start_date STRING,  
   created_by STRING,  
   created_date_time STRING,  
   created_on STRING,  
   description STRING,  
   empl_status STRING,  
   end_date STRING,  
   event STRING,  
   implicit_position_action BIGINT,  
   last_modified_by STRING,  
   last_modified_date_time STRING,  
   last_modified_on STRING,  
   name STRING,  
   payroll_event STRING,  
   status STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_persistent_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_unchanged_stg(
   update_flag STRING,  
   external_code STRING,  
   start_date STRING,  
   created_by STRING,  
   created_date_time STRING,  
   created_on STRING,  
   description STRING,  
   empl_status STRING,  
   end_date STRING,  
   event STRING,  
   implicit_position_action BIGINT,  
   last_modified_by STRING,  
   last_modified_date_time STRING,  
   last_modified_on STRING,  
   name STRING,  
   payroll_event STRING,  
   status STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_unchanged_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.jobclassificationusa_persistent_stg(
   update_flag STRING,  
   external_code STRING,  
   job_classification_country_country STRING,  
   job_classification_effective_start_date STRING,  
   job_classification_external_code STRING,  
   created_by STRING,  
   created_date_time STRING,  
   cust_census_code STRING,  
   cust_standard_code STRING,  
   eeo1_job_category STRING,  
   eeo4_job_category STRING,  
   eeo5_job_category STRING,  
   eeo6_job_category STRING,  
   eeo_job_group STRING,  
   flsa_status_usa STRING,  
   last_modified_by STRING,  
   last_modified_date_time STRING,  
   local_job_title STRING,  
   mdf_system_record_status STRING,  
   batch_id STRING,  
   create_date STRING,  
   create_user_id STRING,  
   update_date STRING,  
  update_user_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/organization_structure/staging/jobclassificationusa_persistent_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS retail__product.part(
  part_nbr STRING, 
  part_rvsn_nbr STRING, 
  part_desc_1 STRING, 
  part_desc_2 STRING, 
  std_cost STRING, 
  std_cost_currency STRING, 
  std_cost_dt STRING, 
  stock_ind STRING, 
  mfgr_name STRING, 
  mfgr_part_nbr STRING, 
  lead_time_ind_days STRING, 
  flex_fld_1 STRING, 
  flex_fld_2 STRING, 
  flex_fld_3 STRING, 
  part_flex_txt_1 STRING, 
  part_flex_txt_2 STRING, 
  part_flex_txt_3 STRING, 
  origin_cntry STRING, 
  ops_study_nbr STRING, 
  fcst_usag_1 STRING, 
  fcst_usag_2 STRING, 
  fcst_usag_3 STRING, 
  pvt_lable_ind STRING, 
  gnfr_ind STRING, 
  prod_brand_name STRING, 
  mat_group_cd STRING, 
  cntrl_wic STRING, 
  cntrl_upc STRING, 
  wic STRING, 
  upc STRING, 
  uom STRING)
USING DELTA
LOCATION
   'abfss://curated@dapdevadlscrt01.dfs.core.windows.net/retail/product/part'
PARTITIONED BY (
  load_mnth STRING)
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__retail__product.adr_part_managed_stg(
  part_nbr STRING,
  part_rvsn_nbr STRING,
  part_desc_1 STRING,
  part_desc_2 STRING,
  std_cost STRING,
  std_cost_currency STRING,
  std_cost_dt STRING,
  stock_ind STRING,
  mfgr_name STRING,
  mfgr_part_nbr STRING,
  lead_time_ind_days STRING,
  flex_fld_1 STRING,
  flex_fld_2 STRING,
  flex_fld_3 STRING,
  part_flex_txt_1 STRING,
  part_flex_txt_2 STRING,
  part_flex_txt_3 STRING,
  origin_cntry STRING,
  ops_study_nbr STRING,
  fcst_usag_1 STRING,
  fcst_usag_2 STRING,
  fcst_usag_3 STRING,
  pvt_lable_ind STRING,
  gnfr_ind STRING,
  prod_brand_name STRING,
  mat_group_cd STRING,
  cntrl_wic STRING,
  cntrl_upc STRING,
  wic STRING,
  upc STRING,
  uom STRING,
  tracking_id STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/retail/product/staging/adr_part_managed_stg'



# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_source_system_lookup_update_records_stg(
    me_id STRING
    ,source_system STRING
    ,source_system_id STRING
    ,source_status STRING
    ,create_dttm TIMESTAMP
    ,CREATE_USER STRING
    ,UPDATE_DTTM TIMESTAMP
    ,UPDATE_USER STRING)
USING DELTA
LOCATION
   'abfss://${CONTAINER_wrg_digital}@${STORAGE_ACCT_wrg_digital}.dfs.core.windows.net/${DOMAIN_digital}/${SUBDOMAIN_ecom}/staging/www_source_system_lookup_update_records_stg'
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS staging__finance__account_payables.load_month_hist_stg(
   load_date DATE,  
  file_name STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/finance/account_payables/staging/load_month_hist_stg'



# COMMAND ----------

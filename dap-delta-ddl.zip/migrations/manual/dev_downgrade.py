# Databricks notebook source
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__finance__account_payables.load_month_hist_stg;
VACUUM staging__finance__account_payables.load_month_hist_stg RETAIN 0 HOURS;
DROP TABLE staging__finance__account_payables.load_month_hist_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/finance/account_payables/staging/load_month_hist_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__digital__ecom.rx_notification_update_records_stg;
VACUUM staging__digital__ecom.rx_notification_update_records_stg RETAIN 0 HOURS;
DROP TABLE staging__digital__ecom.rx_notification_update_records_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/digital/ecom/staging/rx_notification_update_records_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM adr_part_managed_stg;
VACUUM adr_part_managed_stg RETAIN 0 HOURS;
DROP TABLE adr_part_managed_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/retail/product/staging/adr_part_managed_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM retail__product.part;
VACUUM retail__product.part RETAIN 0 HOURS;
DROP TABLE retail__product.part;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://curated@dapdevadlscrt01.dfs.core.windows.net/retail/product/part', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM jobclassificationusa_persistent_stg;
VACUUM jobclassificationusa_persistent_stg RETAIN 0 HOURS;
DROP TABLE jobclassificationusa_persistent_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/organization_structure/staging/jobclassificationusa_persistent_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM foeventreason_unchanged_stg;
VACUUM foeventreason_unchanged_stg RETAIN 0 HOURS;
DROP TABLE foeventreason_unchanged_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_unchanged_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM foeventreason_persistent_stg;
VACUUM foeventreason_persistent_stg RETAIN 0 HOURS;
DROP TABLE foeventreason_persistent_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_persistent_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM foeventreason_delta_stg;
VACUUM foeventreason_delta_stg RETAIN 0 HOURS;
DROP TABLE foeventreason_delta_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_delta_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM bank_unchanged_stg;
VACUUM bank_unchanged_stg RETAIN 0 HOURS;
DROP TABLE bank_unchanged_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_unchanged_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM bank_persistent_stg;
VACUUM bank_persistent_stg RETAIN 0 HOURS;
DROP TABLE bank_persistent_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_persistent_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM bank_delta_stg;
VACUUM bank_delta_stg RETAIN 0 HOURS;
DROP TABLE bank_delta_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_delta_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM address_unchanged_stg;
VACUUM address_unchanged_stg RETAIN 0 HOURS;
DROP TABLE address_unchanged_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_unchanged_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM address_persistent_stg;
VACUUM address_persistent_stg RETAIN 0 HOURS;
DROP TABLE address_persistent_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_persistent_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM address_delta_stg;
VACUUM address_delta_stg RETAIN 0 HOURS;
DROP TABLE address_delta_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_delta_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__hr__payroll.foeventreason_stg;
VACUUM staging__hr__payroll.foeventreason_stg RETAIN 0 HOURS;
DROP TABLE staging__hr__payroll.foeventreason_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/foeventreason_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__hr__recruiting.email_stg;
VACUUM staging__hr__recruiting.email_stg RETAIN 0 HOURS;
DROP TABLE staging__hr__recruiting.email_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/recruiting/staging/email_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__hr__payroll.bank_stg;
VACUUM staging__hr__payroll.bank_stg RETAIN 0 HOURS;
DROP TABLE staging__hr__payroll.bank_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/payroll/staging/bank_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__hr__employment_history.address_stg;
VACUUM staging__hr__employment_history.address_stg RETAIN 0 HOURS;
DROP TABLE staging__hr__employment_history.address_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net/hr/employment_history/staging/address_stg', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM hr__payroll.foeventreason;
VACUUM hr__payroll.foeventreason RETAIN 0 HOURS;
DROP TABLE hr__payroll.foeventreason;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/payroll/foeventreason', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM hr__recruiting.email;
VACUUM hr__recruiting.email RETAIN 0 HOURS;
DROP TABLE hr__recruiting.email;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/recruiting/email', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM hr__recruiting.econtacts;
VACUUM hr__recruiting.econtacts RETAIN 0 HOURS;
DROP TABLE hr__recruiting.econtacts;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/recruiting/econtacts', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM hr__payroll.bank;
VACUUM hr__payroll.bank RETAIN 0 HOURS;
DROP TABLE hr__payroll.bank;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/payroll/bank', recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM hr__employment_history.address;
VACUUM hr__employment_history.address RETAIN 0 HOURS;
DROP TABLE hr__employment_history.address;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
-- COMMAND ----------
# COMMAND ----------
dbutils.fs.rm('abfss://curated@dapdevadlscrt01.dfs.core.windows.net/hr/employment_history/address', recurse=True)
# COMMAND ----------

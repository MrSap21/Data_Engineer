# Databricks notebook source
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__prescriber.prescriber(
  pbr_id DECIMAL(11,0),
  stat_cd STRING ,
  dea_nbr STRING ,
  dea_suffix STRING ,
  pbr_spin_nbr STRING ,
  first_name STRING ,
  middle_initial STRING ,
  middle_name STRING ,
  last_name STRING ,
  last_name_suffix STRING ,
  last_name_soundex STRING ,
  pbr_type_cd STRING ,
  tax_id STRING ,
  hc_reform_nbr STRING ,
  company_cd STRING ,
  prv_stat_cd STRING ,
  prof_stat_cd STRING ,
  gndr_cd STRING ,
  brth_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  dea_expire_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  upin STRING ,
  pbr_npi DECIMAL(10,0) ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_create_user_id DECIMAL(9,0),
  src_create_dttm TIMESTAMP,
  src_update_user_id DECIMAL(9,0) ,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  history_seq_nbr SMALLINT ,
  history_seq_cd STRING ,
  pbr_loc_id SMALLINT,
  pbr_internal_group_id STRING ,
  pbr_loc_internal_group_id STRING ,
  replace_by_pbr_id DECIMAL(11,0),
  replace_by_pbr_loc_id SMALLINT,
  pbr_frgn_license_nbr STRING 
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/prescriber/prescriber'
PARTITIONED BY (
  history_seq_cd)

--  pbr_id DECIMAL(11,0), 
--  stat_cd STRING, 
--  dea_nbr STRING, 
--  dea_suffix STRING, 
--  pbr_spin_nbr STRING, 
--  first_name STRING, 
--  middle_initial STRING, 
--  middle_name STRING, 
--  last_name STRING, 
--  last_name_suffix STRING, 
--  last_name_soundex STRING, 
--  pbr_type_cd STRING, 
--  tax_id STRING, 
--  hc_reform_nbr STRING, 
--  company_cd STRING, 
--  prv_stat_cd STRING, 
--  prof_stat_cd STRING, 
--  gndr_cd STRING, 
--  brth_dt STRING, 
--  dea_expire_dt STRING, 
--  upin STRING, 
--  pbr_npi DECIMAL(10,0), 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_create_dttm STRING, 
--  src_update_user_id DECIMAL(9,0), 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  history_seq_nbr SMALLINT, 
--  pbr_loc_id SMALLINT, 
--  pbr_internal_group_id STRING, 
--  pbr_loc_internal_group_id STRING, 
--  replace_by_pbr_id DECIMAL(11,0), 
--  replace_by_pbr_loc_id SMALLINT, 
--  pbr_frgn_license_nbr STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__prescriber.prescriber_location(
  pbr_id DECIMAL(11,0),
  pbr_loc_id SMALLINT,
  phone_area_cd STRING ,
  phone_nbr STRING ,
  fax_area_cd STRING ,
  fax_nbr STRING ,
  addr_line_1 STRING ,
  addr_line_2 STRING ,
  city STRING ,
  state_cd STRING ,
  zip_cd_5 STRING ,
  zip_cd_4 STRING ,
  cmnt STRING ,
  last_actv_dttm DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  e_prescribe_ind STRING ,
  e_prescribe_hub_nbr SMALLINT ,
  clinic_site_nbr INT ,
  clinic_id STRING ,
  phone_cmnt STRING ,
  chng_req_ind STRING ,
  pbr_src_cd STRING ,
  ndc_pbr_loc_id SMALLINT ,
  ndc_pbr_id DECIMAL(11,0) ,
  pbr_app_cd STRING ,
  src_create_user_id DECIMAL(9,0),
  src_create_dttm TIMESTAMP,
  src_update_user_id DECIMAL(9,0) ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  history_seq_nbr SMALLINT
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/prescriber/prescriber_location'
PARTITIONED BY (
  history_seq_cd STRING)

--  pbr_id DECIMAL(11,0), 
--  pbr_loc_id SMALLINT, 
--  phone_area_cd STRING, 
--  phone_nbr STRING, 
--  fax_area_cd STRING, 
--  fax_nbr STRING, 
--  addr_line_1 STRING, 
--  addr_line_2 STRING, 
--  city STRING, 
--  state_cd STRING, 
--  zip_cd_5 STRING, 
--  zip_cd_4 STRING, 
--  cmnt STRING, 
--  last_actv_dttm STRING, 
--  e_prescribe_ind STRING, 
--  e_prescribe_hub_nbr SMALLINT, 
--  clinic_site_nbr INT, 
--  clinic_id STRING, 
--  phone_cmnt STRING, 
--  chng_req_ind STRING, 
--  pbr_src_cd STRING, 
--  ndc_pbr_loc_id SMALLINT, 
--  ndc_pbr_id DECIMAL(11,0), 
--  pbr_app_cd STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_create_dttm STRING, 
--  src_update_user_id DECIMAL(9,0), 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  history_seq_nbr SMALLINT

# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__prescriber.prescriber_specialty(
  pbr_id DECIMAL(11,0),
  spclty_cd STRING ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_create_user_id DECIMAL(9,0),
  src_create_dttm TIMESTAMP,
  src_update_user_id DECIMAL(9,0) ,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  history_seq_nbr SMALLINT ,
  history_seq_cd STRING ,
  pbr_loc_id SMALLINT
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/prescriber/prescriber_specialty'


--  pbr_id DECIMAL(11,0), 
--  spclty_cd STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_create_dttm STRING, 
--  src_update_user_id DECIMAL(9,0), 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING, 
--  pbr_loc_id SMALLINT
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__prescriber.prescriber_state_license(
  pbr_id DECIMAL(11,0),
  state_license_nbr STRING ,
  state_cd STRING ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_create_user_id DECIMAL(9,0),
  src_update_user_id DECIMAL(9,0) ,
  src_create_dttm TIMESTAMP,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  history_seq_nbr SMALLINT ,
  history_seq_cd STRING ,
  pbr_loc_id SMALLINT,
  pbr_state_ctrl_substance_nbr STRING 
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/prescriber/prescriber_state_license'




--  pbr_id DECIMAL(11,0), 
--  state_license_nbr STRING, 
--  state_cd STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_update_user_id DECIMAL(9,0), 
--  src_create_dttm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING, 
--  pbr_loc_id SMALLINT, 
--  pbr_state_ctrl_substance_nbr STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS master_data__customer.customer_preference(
  cust_pref_chng_sk BIGINT COMMENT 'customer preference change surrogate key',
  cust_sk BIGINT COMMENT 'customer sk',
  cust_pref_prog_group_sk BIGINT COMMENT 'customer preference program group surrogate key',
  cust_src_id STRING COMMENT 'customer source identifier',
  cust_src_cd STRING COMMENT 'customer source code',
  composite_type_cd STRING COMMENT 'composite type code' ,
  msg_type_cd STRING COMMENT 'message type code' ,
  cust_pref_prog_group_cd STRING COMMENT 'customer preference program group code',
  cust_pref_prog_cd STRING COMMENT 'customer preference program code',
  cust_pref_type_cd STRING COMMENT 'customer preference type code',
  src_sys_cd STRING COMMENT 'source system code',
  edw_rec_begin_dt DATE COMMENT 'edw record begin date{"FORMAT":"YYYY/MM/DD" }' ,
  cust_pref_id DECIMAL(19,0) COMMENT 'customer preference identifier' ,
  cust_pref_val STRING COMMENT 'customer preference value',
  src_pref_eff_dt DATE COMMENT 'source preference effective date{"FORMAT":"YYYY/MM/DD" }' ,
  src_pref_expire_dt DATE COMMENT 'source preference expiration date{"FORMAT":"YYYY/MM/DD" }' ,
  suspcs_mbr_ind STRING COMMENT 'suspicious member indicator',
  pref_create_user_id STRING COMMENT 'preference CREATE user identifier',
  pref_create_dttm TIMESTAMP COMMENT 'preference CREATE datetime' ,
  pref_create_src_sys_cd STRING COMMENT 'preference CREATE source system code',
  pref_update_dttm TIMESTAMP COMMENT 'preference update datetime' ,
  pref_update_src_sys_cd STRING COMMENT 'preference update source system code',
  last_update_pref_store_nbr INT COMMENT 'preference update store DOUBLE' ,
  cust_prog_enrl_channel_cd STRING COMMENT 'customer program enrollment channel code',
  cust_prog_enrl_sub_channel_cd STRING COMMENT 'customer program enrollment sub channel code',
  edw_rec_end_dt DATE COMMENT 'edw record end date{"FORMAT":"YYYY/MM/DD" }',
  EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime{"FORMAT":"YYYY/MM/DD" }',
  EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update dttm',
  edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/master_data/customer/customer_preference'
PARTITIONED BY (
  edw_create_month STRING)

--  cust_pref_chng_sk BIGINT, 
--  cust_sk BIGINT, 
--  cust_pref_prog_group_sk BIGINT, 
--  cust_src_id STRING, 
--  cust_src_cd STRING, 
--  composite_type_cd STRING, 
--  msg_type_cd STRING, 
--  cust_pref_prog_group_cd STRING, 
--  cust_pref_prog_cd STRING, 
--  cust_pref_type_cd STRING, 
--  src_sys_cd STRING, 
--  edw_rec_begin_dt STRING, 
--  cust_pref_id DECIMAL(19,0), 
--  cust_pref_val STRING, 
--  src_pref_eff_dt STRING, 
--  src_pref_expire_dt STRING, 
--  suspcs_mbr_ind STRING, 
--  pref_create_user_id STRING, 
--  pref_create_dttm STRING, 
--  pref_create_src_sys_cd STRING, 
--  pref_update_dttm STRING, 
--  pref_update_src_sys_cd STRING, 
--  last_update_pref_store_nbr INT, 
--  cust_prog_enrl_channel_cd STRING, 
--  cust_prog_enrl_sub_channel_cd STRING, 
--  edw_rec_end_dt STRING, 
--  edw_create_dttm STRING, 
--  edw_update_dttm STRING, 
--  edw_batch_id DECIMAL(18,0)

# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient;
--LOCATION 'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;
--LOCATION 'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient_services';
# COMMAND ----------
%sql
CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__drug;
--LOCATION 'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug';
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_merge(
  merged_fm_pat_id DECIMAL(13,0),
  pat_id DECIMAL(13,0),
  src_create_dttm TIMESTAMP,
  src_create_user_id DECIMAL(9,0),
  pat_merge_stat_ind STRING ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  history_seq_nbr SMALLINT,
  history_seq_cd STRING ,
  edw_batch_id DECIMAL(18,0)
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient_merge'




--  merged_fm_pat_id DECIMAL(13,0), 
--  pat_id DECIMAL(13,0), 
--  src_create_dttm STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  pat_merge_stat_ind STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING, 
--  edw_batch_id DECIMAL(18,0)
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_payment_account(
  pat_id DECIMAL(13,0),
  pat_card_seq_nbr INT,
  card_id DECIMAL(18,0) ,
  pat_ck_acct_nbr STRING ,
  pat_ck_acct_rt_nbr STRING ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  src_update_user_id DECIMAL(9,0),
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient_payment_account'




--  pat_id DECIMAL(13,0), 
--  pat_card_seq_nbr INT, 
--  card_id DECIMAL(18,0), 
--  pat_ck_acct_nbr STRING, 
--  pat_ck_acct_rt_nbr STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  src_update_user_id DECIMAL(9,0), 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_plan_information(
  pat_id DECIMAL(13,0),
  third_party_plan_id STRING ,
  insure_mbr_id STRING ,
  plan_grp_nbr STRING ,
  pat_plan_expire_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  primary_plan_ind STRING ,
  person_cd STRING ,
  subscriber_pat_id DECIMAL(13,0),
  relation_cd STRING ,
  uc_ind STRING ,
  brand_copay_dlrs DECIMAL(8,2) ,
  generic_copay_dlrs DECIMAL(8,2) ,
  cob_ind STRING ,
  mfgr_card_ind STRING ,
  employer_id STRING ,
  remain_deductable_dlrs DECIMAL(8,2) ,
  remain_benefit_dlrs DECIMAL(8,2) ,
  major_medical_plan_id STRING ,
  image_id STRING ,
  src_create_user_id DECIMAL(9,0),
  src_update_user_id DECIMAL(9,0) ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_end_tm STRING ,
  edw_batch_id DECIMAL(18,0) ,
  upi STRING ,
  src_create_dttm TIMESTAMP,
  history_seq_nbr SMALLINT ,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient_plan_information'
PARTITIONED BY (
  history_seq_cd)

--  pat_id DECIMAL(13,0), 
--  third_party_plan_id STRING, 
--  insure_mbr_id STRING, 
--  plan_grp_nbr STRING, 
--  pat_plan_expire_dt STRING, 
--  primary_plan_ind STRING, 
--  person_cd STRING, 
--  subscriber_pat_id DECIMAL(13,0), 
--  relation_cd STRING, 
--  uc_ind STRING, 
--  brand_copay_dlrs DECIMAL(8,2), 
--  generic_copay_dlrs DECIMAL(8,2), 
--  cob_ind STRING, 
--  mfgr_card_ind STRING, 
--  employer_id STRING, 
--  remain_deductable_dlrs DECIMAL(8,2), 
--  remain_benefit_dlrs DECIMAL(8,2), 
--  major_medical_plan_id STRING, 
--  image_id STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_update_user_id DECIMAL(9,0), 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  upi STRING, 
--  src_create_dttm STRING, 
--  history_seq_nbr SMALLINT
# COMMAND ----------
%sql
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_plan_information(
  pat_id DECIMAL(13,0),
  third_party_plan_id STRING ,
  insure_mbr_id STRING ,
  plan_grp_nbr STRING ,
  pat_plan_expire_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  primary_plan_ind STRING ,
  person_cd STRING ,
  subscriber_pat_id DECIMAL(13,0),
  relation_cd STRING ,
  uc_ind STRING ,
  brand_copay_dlrs DECIMAL(8,2) ,
  generic_copay_dlrs DECIMAL(8,2) ,
  cob_ind STRING ,
  mfgr_card_ind STRING ,
  employer_id STRING ,
  remain_deductable_dlrs DECIMAL(8,2) ,
  remain_benefit_dlrs DECIMAL(8,2) ,
  major_medical_plan_id STRING ,
  image_id STRING ,
  src_create_user_id DECIMAL(9,0),
  src_update_user_id DECIMAL(9,0) ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_end_tm STRING ,
  edw_batch_id DECIMAL(18,0) ,
  upi STRING ,
  src_create_dttm TIMESTAMP,
  history_seq_nbr SMALLINT ,
  history_seq_cd STRING)
USING DELTA
LOCATION
   'abfss://wrangled@dapuatadlswrng01.dfs.core.windows.net/pharmacy_healthcare/patient/staging/patient_plan_information_data_migration'
PARTITIONED BY (
  history_seq_cd)
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_drug_medispan_record_chng(
  drug_id INT,
  medispan_rec_sect_cd STRING ,
  medispan_last_chng_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug/drug_drug_medispan_record_chng'




--  drug_id INT, 
--  medispan_rec_sect_cd STRING, 
--  medispan_last_chng_dt STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_medispan(
  ndc_upc_hri_id STRING,
  upc_hri_form_cd SMALLINT,
  drug_stat_cd STRING ,
  seq_cd STRING ,
  labeler_cd INT,
  generic_id_type_cd STRING ,
  generic_ingrd_id DECIMAL(9,0),
  dea_class_cd STRING ,
  ahfscc_therapeutic_class_cd INT,
  fda_therapeutic_equivlnc_cd STRING ,
  format_id_nbr STRING ,
  rx_otc_ind STRING ,
  third_party_restrict_cd STRING ,
  maint_drug_ind STRING ,
  dspn_unit_cd STRING ,
  unit_dose_unit_of_use_cd STRING ,
  route_admin STRING ,
  form_type_cd STRING ,
  dlrs_rank SMALLINT,
  rx_rank_cd SMALLINT,
  secondary_upc_hri_form_cd STRING ,
  secondary_drug_id STRING ,
  generic_drug_cd STRING ,
  drug_type_cd STRING ,
  internal_external_cd STRING ,
  single_ingrd_cd STRING ,
  storage_cond_cd STRING ,
  limit_stability_cd STRING ,
  old_id_form_cd SMALLINT,
  old_drug_id STRING ,
  old_format_id_nbr STRING ,
  old_id_eff_dt DATE,
  new_id_form_cd SMALLINT,
  new_drug_id STRING ,
  new_format_id_nbr STRING ,
  new_id_eff_dt DATE,
  prod_name STRING ,
  prod_name_extn STRING ,
  drug_to_drug_interact_cd SMALLINT,
  pcm_pattern_cd SMALLINT,
  allergy_pattern_cd SMALLINT,
  hfpg_ind STRING ,
  generic_prod_id STRING ,
  generic_prod_id_name STRING ,
  mfgr_name STRING ,
  mfgr_name_abbr STRING ,
  prod_desc_abbr STRING ,
  drug_name_cd STRING ,
  generic_prod_pkg_cd STRING ,
  drug_strength DECIMAL(13,5),
  drug_strength_uom STRING ,
  dosage_form_cd STRING ,
  pkg_sz DECIMAL(8,3),
  pkg_sz_uom STRING ,
  pkg_qty INT,
  repack_cd STRING ,
  tot_pkg_qty DECIMAL(12,3),
  desi_class_cd STRING ,
  pkg_desc STRING ,
  legend_chng_dt DATE,
  next_smaller_ndc_suffix_nbr STRING ,
  next_larger_ndc_suffix_nbr STRING ,
  dur_knwlgbsd_drug_cd_nbr STRING ,
  wholesale_unit_price DECIMAL(13,5),
  awp_reportd_ind STRING ,
  medispan_drug_class STRING ,
  medispan_drug_class_grp STRING ,
  medispan_drug_subclass STRING ,
  medispan_drug_name STRING ,
  ppg_ind STRING ,
  src_eff_dt DATE,
  src_eff_tm STRING,
  src_end_dt DATE,
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  history_seq_nbr SMALLINT,
  history_seq_cd STRING ,
  hzrds_lvl_cd STRING ,
  AUTH_GENERIC_CD STRING ,
  FDA_IND STRING ,
  FDA_IND_VALUE STRING ,
  AUTH_NDC_UPC_HRI STRING ,
  DDID STRING ,
  RXCUI_TYPE STRING ,
  RXCUI STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug/drug_medispan'




--  ndc_upc_hri_id STRING, 
--  upc_hri_form_cd SMALLINT, 
--  drug_stat_cd STRING, 
--  seq_cd STRING, 
--  labeler_cd INT, 
--  generic_id_type_cd STRING, 
--  generic_ingrd_id DECIMAL(9,0), 
--  dea_class_cd STRING, 
--  ahfscc_therapeutic_class_cd INT, 
--  fda_therapeutic_equivlnc_cd STRING, 
--  format_id_nbr STRING, 
--  rx_otc_ind STRING, 
--  third_party_restrict_cd STRING, 
--  maint_drug_ind STRING, 
--  dspn_unit_cd STRING, 
--  unit_dose_unit_of_use_cd STRING, 
--  route_admin STRING, 
--  form_type_cd STRING, 
--  dlrs_rank SMALLINT, 
--  rx_rank_cd SMALLINT, 
--  secondary_upc_hri_form_cd STRING, 
--  secondary_drug_id STRING, 
--  generic_drug_cd STRING, 
--  drug_type_cd STRING, 
--  internal_external_cd STRING, 
--  single_ingrd_cd STRING, 
--  storage_cond_cd STRING, 
--  limit_stability_cd STRING, 
--  old_id_form_cd SMALLINT, 
--  old_drug_id STRING, 
--  old_format_id_nbr STRING, 
--  old_id_eff_dt STRING, 
--  new_id_form_cd SMALLINT, 
--  new_drug_id STRING, 
--  new_format_id_nbr STRING, 
--  new_id_eff_dt STRING, 
--  prod_name STRING, 
--  prod_name_extn STRING, 
--  drug_to_drug_interact_cd SMALLINT, 
--  pcm_pattern_cd SMALLINT, 
--  allergy_pattern_cd SMALLINT, 
--  hfpg_ind STRING, 
--  generic_prod_id STRING, 
--  generic_prod_id_name STRING, 
--  mfgr_name STRING, 
--  mfgr_name_abbr STRING, 
--  prod_desc_abbr STRING, 
--  drug_name_cd STRING, 
--  generic_prod_pkg_cd STRING, 
--  drug_strength DECIMAL(13,5), 
--  drug_strength_uom STRING, 
--  dosage_form_cd STRING, 
--  pkg_sz DECIMAL(8,3), 
--  pkg_sz_uom STRING, 
--  pkg_qty INT, 
--  repack_cd STRING, 
--  tot_pkg_qty DECIMAL(12,3), 
--  desi_class_cd STRING, 
--  pkg_desc STRING, 
--  legend_chng_dt STRING, 
--  next_smaller_ndc_suffix_nbr STRING, 
--  next_larger_ndc_suffix_nbr STRING, 
--  dur_knwlgbsd_drug_cd_nbr STRING, 
--  wholesale_unit_price DECIMAL(13,5), 
--  awp_reportd_ind STRING, 
--  medispan_drug_class STRING, 
--  medispan_drug_class_grp STRING, 
--  medispan_drug_subclass STRING, 
--  medispan_drug_name STRING, 
--  ppg_ind STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING, 
--  hzrds_lvl_cd STRING, 
--  auth_generic_cd STRING, 
--  fda_ind STRING, 
--  fda_ind_value STRING, 
--  auth_ndc_upc_hri STRING, 
--  ddid STRING, 
--  rxcui_type STRING, 
--  rxcui STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_medispan_awp(
  ndc_upc_hri_id STRING ,
  awp_1_3_cd STRING ,
  awp_4_6_cd STRING ,
  awp_pkg_price_dlrs DECIMAL(10,2),
  awp_unit_price_dlrs DECIMAL(10,5),
  awp_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  upc_hri_form_cd SMALLINT,
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug/drug_medispan_awp'




--  ndc_upc_hri_id STRING, 
--  awp_1_3_cd STRING, 
--  awp_4_6_cd STRING, 
--  awp_pkg_price_dlrs DECIMAL(10,2), 
--  awp_unit_price_dlrs DECIMAL(10,5), 
--  awp_eff_dt STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  upc_hri_form_cd SMALLINT, 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_medispan_direct_price(
  ndc_upc_hri_id STRING ,
  direct_price_unit_price_dlrs DECIMAL(13,5),
  direct_price_pkg_price_dlrs DECIMAL(10,2),
  direct_price_unit_price_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  upc_hri_form_cd SMALLINT,
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug/drug_medispan_direct_price'




--  ndc_upc_hri_id STRING, 
--  direct_price_unit_price_dlrs DECIMAL(13,5), 
--  direct_price_pkg_price_dlrs DECIMAL(10,2), 
--  direct_price_unit_price_eff_dt STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  upc_hri_form_cd SMALLINT, 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_medispan_record_change(
  ndc_upc_hri_id STRING ,
  medispan_rec_sect_cd STRING ,
  medispan_last_chng_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  upc_hri_form_cd SMALLINT,
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug/drug_medispan_record_change'




--  ndc_upc_hri_id STRING, 
--  medispan_rec_sect_cd STRING, 
--  medispan_last_chng_dt STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  upc_hri_form_cd SMALLINT, 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_medispan_hcfa_ffp_price(
  ndc_upc_hri_id STRING ,
  hcfa_ffp_limit_dlrs DECIMAL(10,5),
  hcfa_ffp_limit_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  upc_hri_form_cd SMALLINT,
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/drug/drug_medispan_hcfa_ffp_price'




--  ndc_upc_hri_id STRING, 
--  hcfa_ffp_limit_dlrs DECIMAL(10,5), 
--  hcfa_ffp_limit_eff_dt STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  upc_hri_form_cd SMALLINT, 
--  history_seq_nbr SMALLINT, 
--  history_seq_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_address(
  pat_id DECIMAL(13,0),
  addr_type_cd STRING ,
  addr_seq_nbr SMALLINT,
  addr_line STRING ,
  city STRING ,
  state_cd STRING ,
  zip_cd_5 STRING ,
  zip_cd_4 STRING ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd"}',
  src_end_tm STRING,
  edw_batch_id DECIMAL(18,0),
  src_update_user_id DECIMAL(9,0),
  history_seq_nbr SMALLINT,
  history_seq_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient_address'
PARTITIONED BY (
  history_seq_cd)

--  pat_id DECIMAL(13,0), 
--  addr_type_cd STRING, 
--  addr_seq_nbr SMALLINT, 
--  addr_line STRING, 
--  city STRING, 
--  state_cd STRING, 
--  zip_cd_5 STRING, 
--  zip_cd_4 STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  src_update_user_id DECIMAL(9,0), 
--  history_seq_nbr SMALLINT
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient_communication_channel(
  pat_id DECIMAL(13,0),
  channel_type_cd STRING ,
  comm_channel_val STRING ,
  txt_msg_ind STRING ,
  txt_msg_carr STRING ,
  src_eff_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }' ,
  src_eff_tm STRING,
  src_end_dt DATE COMMENT '{"FORMAT":"yyyy-mm-dd" }',
  src_end_tm STRING ,
  edw_batch_id DECIMAL(18,0) ,
  src_update_user_id DECIMAL(9,0) ,
  history_seq_nbr SMALLINT ,
  history_seq_cd STRING ,
  comm_cntc_tm_cd STRING ,
  phone_type_cd STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient_communication_channel'
PARTITIONED BY (
  history_seq_cd)

--  pat_id DECIMAL(13,0), 
--  channel_type_cd STRING, 
--  comm_channel_val STRING, 
--  txt_msg_ind STRING, 
--  txt_msg_carr STRING, 
--  src_eff_dt STRING, 
--  src_eff_tm STRING, 
--  src_end_dt STRING, 
--  src_end_tm STRING, 
--  edw_batch_id DECIMAL(18,0), 
--  src_update_user_id DECIMAL(9,0), 
--  history_seq_nbr SMALLINT, 
--  comm_cntc_tm_cd STRING, 
--  phone_type_cd STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient(
  pat_id DECIMAL(13,0),
  first_name STRING ,
  middle_initial STRING ,
  last_name STRING ,
  last_name_suffix STRING ,
  last_name_soundex STRING ,
  gndr_cd STRING ,
  brth_dt STRING,
  head_of_household_pat_id DECIMAL(13,0),
  head_of_household_relation_cd STRING ,
  pat_discnt_cd STRING ,
  pat_clinic_med_id STRING ,
  snap_cap_pref_ind STRING ,
  generic_substn_pref_ind STRING ,
  therapeutic_substn_pref_ind STRING ,
  mail_list_pref_ind STRING ,
  preferred_lang_cd STRING ,
  purged_rx_ind STRING ,
  pet_pat_ind STRING ,
  pat_mail_svc_id STRING ,
  pat_cmnt STRING ,
  pat_create_str_nbr INT,
  deceased_ind STRING ,
  pat_allergy_hlth_type_cd STRING ,
  wc_ind STRING ,
  pat_signature_ind STRING ,
  pat_internet_register_ind STRING ,
  pat_extrernal_rx_otc_item_ind STRING ,
  orig_register_dttm TIMESTAMP,
  hipaa_signature_capture_ind STRING ,
  hipaa_signature_capture_dt DATE,
  hipaa_signature_capture_str_nb INT,
  buyout_pat_ind STRING ,
  hipaa_acknowlege_ltr_ind STRING ,
  lock_ind STRING ,
  lock_str_nbr INT,
  lock_user_id DECIMAL(9,0),
  lock_dttm TIMESTAMP,
  smoking_ind STRING ,
  pregnancy_ind STRING ,
  pregnancy_due_dt DATE,
  pat_brochure_ind STRING ,
  homecare_ind STRING ,
  bal_hold_ind STRING ,
  spclty_ind STRING ,
  bill_addr_ind STRING ,
  link_cd STRING ,
  pat_allergy_hlth_inq_ind STRING ,
  src_create_user_id DECIMAL(9,0),
  src_create_dttm TIMESTAMP,
  src_update_user_id DECIMAL(9,0),
  edw_batch_id DECIMAL(18,0),
  pet_type STRING ,
  phone_cntc_pref_ind STRING ,
  no_phone_reason_cd STRING ,
  primary_phone_pref_cd STRING ,
  src_update_dttm TIMESTAMP,
  auto_refill_pref_str_nbr DECIMAL(5,0),
  pat_auto_refill_ind STRING ,
  pat_pickup_gov_auth_id STRING ,
  pat_pickup_qlfr_type STRING ,
  pat_pickup_relation_cd STRING ,
  pat_primary_care_pbr_id DECIMAL(11,0),
  pat_primary_care_pbr_loc_id DECIMAL(2,0),
  pat_residence_cd DECIMAL(2,0),
  pat_unmerge_vrfy_ind STRING ,
  pat_twin_ind STRING ,
  pat_90day_pref_ind STRING ,
  pat_90day_pref_dttm TIMESTAMP,
  pat_alg_block_madr_ind STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient'




--  pat_id DECIMAL(13,0), 
--  first_name STRING, 
--  middle_initial STRING, 
--  last_name STRING, 
--  last_name_suffix STRING, 
--  last_name_soundex STRING, 
--  gndr_cd STRING, 
--  brth_dt STRING, 
--  head_of_household_pat_id DECIMAL(13,0), 
--  head_of_household_relation_cd STRING, 
--  pat_discnt_cd STRING, 
--  pat_clinic_med_id STRING, 
--  snap_cap_pref_ind STRING, 
--  generic_substn_pref_ind STRING, 
--  therapeutic_substn_pref_ind STRING, 
--  mail_list_pref_ind STRING, 
--  preferred_lang_cd STRING, 
--  purged_rx_ind STRING, 
--  pet_pat_ind STRING, 
--  pat_mail_svc_id STRING, 
--  pat_cmnt STRING, 
--  pat_create_str_nbr INT, 
--  deceased_ind STRING, 
--  pat_allergy_hlth_type_cd STRING, 
--  wc_ind STRING, 
--  pat_signature_ind STRING, 
--  pat_internet_register_ind STRING, 
--  pat_extrernal_rx_otc_item_ind STRING, 
--  orig_register_dttm STRING, 
--  hipaa_signature_capture_ind STRING, 
--  hipaa_signature_capture_dt STRING, 
--  hipaa_signature_capture_str_nb INT, 
--  buyout_pat_ind STRING, 
--  hipaa_acknowlege_ltr_ind STRING, 
--  lock_ind STRING, 
--  lock_str_nbr INT, 
--  lock_user_id DECIMAL(9,0), 
--  lock_dttm STRING, 
--  smoking_ind STRING, 
--  pregnancy_ind STRING, 
--  pregnancy_due_dt STRING, 
--  pat_brochure_ind STRING, 
--  homecare_ind STRING, 
--  bal_hold_ind STRING, 
--  spclty_ind STRING, 
--  bill_addr_ind STRING, 
--  link_cd STRING, 
--  pat_allergy_hlth_inq_ind STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_create_dttm STRING, 
--  src_update_user_id DECIMAL(9,0), 
--  edw_batch_id DECIMAL(18,0), 
--  pet_type STRING, 
--  phone_cntc_pref_ind STRING, 
--  no_phone_reason_cd STRING, 
--  primary_phone_pref_cd STRING, 
--  src_update_dttm STRING, 
--  auto_refill_pref_str_nbr DECIMAL(5,0), 
--  pat_auto_refill_ind STRING, 
--  pat_pickup_gov_auth_id STRING, 
--  pat_pickup_qlfr_type STRING, 
--  pat_pickup_relation_cd STRING, 
--  pat_primary_care_pbr_id DECIMAL(11,0), 
--  pat_primary_care_pbr_loc_id DECIMAL(2,0), 
--  pat_residence_cd DECIMAL(2,0), 
--  pat_unmerge_vrfy_ind STRING, 
--  pat_twin_ind STRING, 
--  pat_90day_pref_ind STRING, 
--  pat_90day_pref_dttm STRING, 
--  pat_alg_block_madr_ind STRING
# COMMAND ----------
%sql
--synced with snowflake
CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient.patient(
  pat_id DECIMAL(13,0),
  first_name STRING ,
  middle_initial STRING ,
  last_name STRING ,
  last_name_suffix STRING ,
  last_name_soundex STRING ,
  gndr_cd STRING ,
  brth_dt STRING,
  head_of_household_pat_id DECIMAL(13,0),
  head_of_household_relation_cd STRING ,
  pat_discnt_cd STRING ,
  pat_clinic_med_id STRING ,
  snap_cap_pref_ind STRING ,
  generic_substn_pref_ind STRING ,
  therapeutic_substn_pref_ind STRING ,
  mail_list_pref_ind STRING ,
  preferred_lang_cd STRING ,
  purged_rx_ind STRING ,
  pet_pat_ind STRING ,
  pat_mail_svc_id STRING ,
  pat_cmnt STRING ,
  pat_create_str_nbr INT,
  deceased_ind STRING ,
  pat_allergy_hlth_type_cd STRING ,
  wc_ind STRING ,
  pat_signature_ind STRING ,
  pat_internet_register_ind STRING ,
  pat_extrernal_rx_otc_item_ind STRING ,
  orig_register_dttm TIMESTAMP,
  hipaa_signature_capture_ind STRING ,
  hipaa_signature_capture_dt DATE,
  hipaa_signature_capture_str_nb INT,
  buyout_pat_ind STRING ,
  hipaa_acknowlege_ltr_ind STRING ,
  lock_ind STRING ,
  lock_str_nbr INT,
  lock_user_id DECIMAL(9,0),
  lock_dttm TIMESTAMP,
  smoking_ind STRING ,
  pregnancy_ind STRING ,
  pregnancy_due_dt DATE,
  pat_brochure_ind STRING ,
  homecare_ind STRING ,
  bal_hold_ind STRING ,
  spclty_ind STRING ,
  bill_addr_ind STRING ,
  link_cd STRING ,
  pat_allergy_hlth_inq_ind STRING ,
  src_create_user_id DECIMAL(9,0),
  src_create_dttm TIMESTAMP,
  src_update_user_id DECIMAL(9,0),
  edw_batch_id DECIMAL(18,0),
  pet_type STRING ,
  phone_cntc_pref_ind STRING ,
  no_phone_reason_cd STRING ,
  primary_phone_pref_cd STRING ,
  src_update_dttm TIMESTAMP,
  auto_refill_pref_str_nbr DECIMAL(5,0),
  pat_auto_refill_ind STRING ,
  pat_pickup_gov_auth_id STRING ,
  pat_pickup_qlfr_type STRING ,
  pat_pickup_relation_cd STRING ,
  pat_primary_care_pbr_id DECIMAL(11,0),
  pat_primary_care_pbr_loc_id DECIMAL(2,0),
  pat_residence_cd DECIMAL(2,0),
  pat_unmerge_vrfy_ind STRING ,
  pat_twin_ind STRING ,
  pat_90day_pref_ind STRING ,
  pat_90day_pref_dttm TIMESTAMP,
  pat_alg_block_madr_ind STRING
  ,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
   'abfss://curated@dapuatadlscrt01.dfs.core.windows.net/pharmacy_healthcare/patient/patient'




--  pat_id DECIMAL(13,0), 
--  first_name STRING, 
--  middle_initial STRING, 
--  last_name STRING, 
--  last_name_suffix STRING, 
--  last_name_soundex STRING, 
--  gndr_cd STRING, 
--  brth_dt STRING, 
--  head_of_household_pat_id DECIMAL(13,0), 
--  head_of_household_relation_cd STRING, 
--  pat_discnt_cd STRING, 
--  pat_clinic_med_id STRING, 
--  snap_cap_pref_ind STRING, 
--  generic_substn_pref_ind STRING, 
--  therapeutic_substn_pref_ind STRING, 
--  mail_list_pref_ind STRING, 
--  preferred_lang_cd STRING, 
--  purged_rx_ind STRING, 
--  pet_pat_ind STRING, 
--  pat_mail_svc_id STRING, 
--  pat_cmnt STRING, 
--  pat_create_str_nbr INT, 
--  deceased_ind STRING, 
--  pat_allergy_hlth_type_cd STRING, 
--  wc_ind STRING, 
--  pat_signature_ind STRING, 
--  pat_internet_register_ind STRING, 
--  pat_extrernal_rx_otc_item_ind STRING, 
--  orig_register_dttm STRING, 
--  hipaa_signature_capture_ind STRING, 
--  hipaa_signature_capture_dt STRING, 
--  hipaa_signature_capture_str_nb INT, 
--  buyout_pat_ind STRING, 
--  hipaa_acknowlege_ltr_ind STRING, 
--  lock_ind STRING, 
--  lock_str_nbr INT, 
--  lock_user_id DECIMAL(9,0), 
--  lock_dttm STRING, 
--  smoking_ind STRING, 
--  pregnancy_ind STRING, 
--  pregnancy_due_dt STRING, 
--  pat_brochure_ind STRING, 
--  homecare_ind STRING, 
--  bal_hold_ind STRING, 
--  spclty_ind STRING, 
--  bill_addr_ind STRING, 
--  link_cd STRING, 
--  pat_allergy_hlth_inq_ind STRING, 
--  src_create_user_id DECIMAL(9,0), 
--  src_create_dttm STRING, 
--  src_update_user_id DECIMAL(9,0), 
--  edw_batch_id DECIMAL(18,0), 
--  pet_type STRING, 
--  phone_cntc_pref_ind STRING, 
--  no_phone_reason_cd STRING, 
--  primary_phone_pref_cd STRING, 
--  src_update_dttm STRING, 
--  auto_refill_pref_str_nbr DECIMAL(5,0), 
--  pat_auto_refill_ind STRING, 
--  pat_pickup_gov_auth_id STRING, 
--  pat_pickup_qlfr_type STRING, 
--  pat_pickup_relation_cd STRING, 
--  pat_primary_care_pbr_id DECIMAL(11,0), 
--  pat_primary_care_pbr_loc_id DECIMAL(2,0), 
--  pat_residence_cd DECIMAL(2,0), 
--  pat_unmerge_vrfy_ind STRING, 
--  pat_twin_ind STRING, 
--  pat_90day_pref_ind STRING, 
--  pat_90day_pref_dttm STRING, 
--  pat_alg_block_madr_ind STRING
# COMMAND ----------

import json
import os
from pathlib import Path
import pandas as pd
import re

df_ddl = pd.read_json(path_or_buf='./migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./migrations/ddl_tbd.json', orient='records')
df_schemas = df_ddl[df_ddl.id.str.startswith('D_')]

def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()
ddl_tbd = get_ddl_json(type='_tbd')


# update the ddl locations on all files
# step 1: unzip the tbd files
# step 2: run
# step 3: re-zip files

dont_change_list = [
    T_1.19302.1__staging__property_services__property_services.prprty_spotlight_trans_approval_stg.sql,
    T_1.19308.1__staging__property_services__property_services.prprty_tracker_idle_dispo_stg.sql,
    T_1.19309.1__staging__property_services__property_services.prprty_tracker_parent_stg.sql,
    T_1.19310.1__staging__property_services__property_services.prprty_tracker_portfolio_stg.sql,
    T_1.19215.1__property_services__property_services.prprty_spotlight_trans_approval.sql,
    T_1.19216.1__property_services__property_services.prprty_spotlight_trans_approval_hist.sql,
    T_1.19226.1__property_services__property_services.prprty_tracker_idle_dispo.sql,
    T_1.19227.1__property_services__property_services.prprty_tracker_idle_dispo_hist.sql,
    T_1.19228.1__property_services__property_services.prprty_tracker_parent.sql,
    T_1.19229.1__property_services__property_services.prprty_tracker_parent_hist.sql,
    T_1.19230.1__property_services__property_services.prprty_tracker_portfolio.sql,
    T_1.19231.1__property_services__property_services.prprty_tracker_portfolio_hist.sql,
    T_1.15382.1__mna_buyout__pharmacy_healthcare.rad_rx_denormalized.sql,
    T_1.15433.1__mna_buyout__pharmacy_healthcare.rad_rx_script.sql,
    T_1.15340.1__mna_buyout__retail.rad_customer_one_view.sql,
    T_1.15444.1__mna_buyout__retail.rad_sales_txn_detail.sql,
    T_1.1443.1__master_data__location.location_area.sql,
    T_1.1444.1__master_data__location.location_area_staff.sql,
    T_1.1453.1__master_data__location.location_store.sql,
    T_1.1449.1__master_data__location.location_operation.sql,
    T_1.1446.1__master_data__location.location_district.sql,
    T_1.19434.1__staging__master_data__location.location_area_stg.sql,
    T_1.19435.1__staging__master_data__location.location_area_staff_stg.sql,
    T_1.19437.1__staging__master_data__location.location_store_stg.sql,
    T_1.19438.1__staging__master_data__location.location_operation_stg.sql,
    T_1.19436.1__staging__master_data__location.location_district_stg.sql
]

def fix_file(file_path, old_location):
    with open(file_path,'r') as f:
        txt = f.read()
    txt.replace(old_location, '${LOCATION}')
    with open(file_path.replace('./scripts/','./test/'),'w') as f: #TODO: change /test/ after testing
        f.write(txt)


try:
    for d in ddl:
        old_container = d['loc_container_param']
        new_container = old_container.replace(f'{d['domain'][:-1]}_{d['subdomain']}}}')
        old_location = d['location']
        new_location = old_location.replace(f'/{d['domain_param']}','').replace(f'/{d['subdomain_param']}','').replace(old_container,new_container)
        fix_file(file_path=d['path'], old_location)
        fix_file(file_path=d['downgrade_path'], old_location)
        d.update({'location': new_location})
except Exception as e:
    print(df_ddl[df_ddl.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl.json', 'w') as f:
    json.dump(ddl, f, indent=2)


try:
    for d in ddl_tbd:
        old_container = d['loc_container_param']
        new_container = old_container.replace(f'{d['domain'][:-1]}_{d['subdomain']}}}')
        old_location = d['location']
        new_location = old_location.replace(f'/{d['domain_param']}','').replace(f'/{d['subdomain_param']}','').replace(old_container,new_container)
        fix_file(file_path=d['path'], old_location)
        fix_file(file_path=d['downgrade_path'], old_location)
        d.update({'location': new_location})
except Exception as e:
    print(df_tbd[df_tbd.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl_tbd.json', 'w') as f:
    json.dump(ddl, f, indent=2)






# ddl_clean = []
# ddl_tbd = []

# for i in ddl:
#     if i.get('domain','') == 'tbd':
#         ddl_tbd.append(i)
#     else:
#         ddl_clean.append(i)
# with open('./migrations/ddl.json', 'w') as f:
#         json.dump(ddl_clean, f, indent=2)
# with open('./migrations/ddl_tbd.json', 'w') as f:
#         json.dump(ddl_tbd, f, indent=2)






    

# try: 
#     for i in ddl:
#         fix_file(i['path'], i['partition_by'])
#         else:
#             pass
            # don't edit wrangled tables, as the container stays as wrangled

        # if not i.get('id','').startswith('D_'):
        #     schema = df_schemas[(df_schemas.zone == i.get('zone')) & (df_schemas.domain == i.get('domain')) & (df_schemas.subdomain == i.get('subdomain'))]['script'].iloc[0]
        #     ancs = i.get('ancestors', [])
        #     if ancs == []:
        #         ancs.append(schema)
        #     else:
        #         for a in ancs:
        #             new_ancs = [schema]
        #             try:
        #                 script_name = df_ddl[df_ddl.legacy_schema == a]['script'].iloc[0]
        #             except:
        #                 script_name = df_tbd[df_tbd.legacy_schema == a]['script'].iloc[0]
        #             new_ancs.append(script_name)
        #         ancs = new_ancs
        #     i.update({'ancestors':  ancs})
        #     if len(ancs) > 1:
        #         print(ancs)

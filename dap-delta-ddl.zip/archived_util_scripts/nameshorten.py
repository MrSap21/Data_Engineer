import json
import os
from pathlib import Path
import pandas as pd
import re
import shutil

df_ddl = pd.read_json(path_or_buf='./migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./migrations/ddl_tbd.json', orient='records')

def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()
ddl_tbd = get_ddl_json(type='_tbd')



def fix_file(old_path, new_path):
    if old_path == new_path and '__' not in old_path:
        pass
    else:
        try:
            shutil.copy(old_path, new_path)
            os.remove(old_path)
        except Exception as e:
            print(old_path, new_path)
            pass
changes = {}

try:
    for d in ddl:
        if d['id'].startswith('V_') or d['id'].startswith('T_'):
            old_id=d['id']
            new_id=d['id'].replace('T_1.','T.').replace('V_1.','V.')
            old_script = d['script']
            new_script = old_script.replace(old_script.split('.')[-3], '1').replace('T_1.','T.').replace('V_1.','V.')
            old_path = d['path']
            new_path = old_path.replace(old_script, new_script)

            old_downgrade_script = d['downgrade_path'].split('/')[-1]
            new_downgrade_script = old_downgrade_script.replace(old_downgrade_script.split('.')[-3],'0').replace('T_1.','T.').replace('V_1.','V.').replace('.1__','.0__')
            old_downgrade_path = d['downgrade_path']
            new_downgrade_path = old_downgrade_path.replace(old_downgrade_script, new_downgrade_script)

            d.update({'id': new_id})
            d.update({'script': new_script})
            d.update({'path': new_path})
            d.update({'downgrade_path': new_downgrade_path})
            changes[old_downgrade_script] = new_downgrade_script
            changes[old_script] = new_script

            fix_file(old_path=old_path, new_path=new_path)
            fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)

        elif d['id'].startswith('D_'):
            old_id=d['id']
            new_id=d['id'].replace('D_1.','T.')
            old_script = d['script']
            new_script = old_script.replace('D_1.','D.').replace('.1__','.1.')
            old_downgrade_script = d['downgrade_path'].split('/')[-1]
            new_downgrade_script = old_downgrade_script.replace('.0__','.0.').replace('D_1.','D.')

            old_path = d['path']
            new_path = old_path.replace(old_script,new_script)
            old_downgrade_path = d['downgrade_path']
            new_downgrade_path = old_downgrade_path.replace(old_downgrade_script, new_downgrade_script)
            
            d.update({'id': new_id})
            d.update({'script': new_script})
            d.update({'path': new_path})
            d.update({'downgrade_path': new_downgrade_path})
            changes[old_downgrade_script] = new_downgrade_script
            changes[old_script] = new_script
            
            fix_file(old_path=old_path, new_path=new_path)
            fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)
    for d in ddl:
        old_ancestors = d['ancestors']
        new_ancestors = []
        if isinstance(old_ancestors, list):
            for a in old_ancestors:
                new_ancestors.append(changes.get(a,''))
        d.update({'ancestors': new_ancestors})
    
except Exception as e:
    print(df_ddl[df_ddl.id == old_id].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl.json', 'w') as f:
        json.dump(ddl, f, indent=2)


try:
    for d in ddl_tbd:
        if d['id'].startswith('V_') or d['id'].startswith('T_'):
            old_id=d['id']
            new_id=d['id'].replace('T_1.','T.').replace('V_1.','V.')
            old_script = d['script']
            new_script = old_script.replace(old_script.split('.')[-3], '1').replace('T_1.','T.').replace('V_1.','V.')
            old_path = d['path']
            new_path = old_path.replace(old_script, new_script)

            old_downgrade_script = d['downgrade_path'].split('/')[-1]
            new_downgrade_script = old_downgrade_script.replace(old_downgrade_script.split('.')[-3],'0').replace('T_1.','T.').replace('V_1.','V.').replace('.1__','.0__')
            old_downgrade_path = d['downgrade_path']
            new_downgrade_path = old_downgrade_path.replace(old_downgrade_script, new_downgrade_script)


            d.update({'id': new_id})
            d.update({'script': new_script})
            d.update({'path': new_path})
            d.update({'downgrade_path': new_downgrade_path})
            changes[old_downgrade_script] = new_downgrade_script
            changes[old_script] = new_script

            fix_file(old_path=old_path, new_path=new_path)
            fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)

    for d in ddl:
        old_ancestors = d['ancestors']
        new_ancestors = []
        if isinstance(old_ancestors, list):
            for a in old_ancestors:
                new_ancestors.append(changes.get(a,''))
        d.update({'ancestors': new_ancestors})
except Exception as e:
    print(df_tbd[df_tbd.id == old_id].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl_tbd.json', 'w') as f:
    json.dump(ddl_tbd, f, indent=2)


with open('changes.json', 'w') as f:
    json.dump(changes, f, indent=2)
import json
import os
from pathlib import Path
import pandas as pd
import re



with open('./ddl.json', 'r') as f:
    ddl = json.load(f)
df_ddl = pd.read_json(path_or_buf='./ddl.json', orient='records')
print(df_ddl[(df_ddl.id.str.startswith('D.'))][['script', 'zone', 'domain', 'sub_domain']])
new = []
for d in ddl:
    if (d['ancestors'] == [] or d['ancestors'] == [""]) and d['table_type'] != 'database':
        a = df_ddl[((df_ddl.id.str.startswith('D.')) & (df_ddl.zone==d['zone']) & (df_ddl.domain==d['domain']) & (df_ddl.sub_domain==d['sub_domain']))]['script'].tolist()
        if a == [''] or a == []: print(d['id'])
        d.update({'ancestors': a})
        new.append(d)
    else:
        new.append(d)



with open('./ddl.json', 'w') as f:
    json.dump(new, f, indent=2)



import json
from pathlib import Path


def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()

# for d in ddl:
#     if d['domain'] == 'finance':
#         print(d['legacy_schema'])

    # if d['script'].startswith('D.') and d['id'].startswith('T.'):
    #     d.update({'id': d['id'].replace('T.','D.')})

with open('./migrations/ddl.json', 'w') as f:
    json.dump(ddl, f, indent=2)

with open(f'./changes2.json', 'r') as f:
    changes = json.load(f)


current_releases = [str(f).replace('\\','/') for f in Path('./migrations/releases/').glob('*.json')]
print(current_releases)
for file in current_releases:
    new_rel = {
        'upgrade':[],
        "downgrade": []
    }
    with open(file, 'r') as f:
        rel = json.load(f)
    
    for i in rel['upgrade']:
        try:
            c=False
            i = i.replace('.py','.sql')
            if changes.get('i') is not None:
                new_rel['upgrade'].append(changes[i])
                print(f'i-----------------{changes[i]}')
                c=True
            else:
                filename = i.split('.')[-2]
                if i.startswith('D'): v = i.replace('.staging__','.wrg.').replace(f".1.{filename}", f".1.crt.{filename}")
                elif i.endswith('_stg.sql') or i.endswith('_etl.sql'): v = i.replace(f".{filename}", f".wrg.{filename}")
                else: v = i.replace(f".{filename}", f".crt.{filename}")
                for d in ddl:
                    if v == d['script']:
                        print(f'v-----------------{v}')
                        new_rel['upgrade'].append(v)
                        c=True
            if not c:
                raise()
        except:
            print(i)
            pass

    for i in rel['downgrade']:
        try:
            c=False
            i = i.replace('.py','.sql')
            if changes.get('i') is not None:
                new_rel['downgrade'].append(changes[i])
                print(f'i-----------------{changes[i]}')
                c=True
            else:
                filename = i.split('.')[-2]
                if i.startswith('D'): v = i.replace('.staging__','.wrg.').replace(f".1.{filename}", f".1.crt.{filename}")
                elif i.endswith('_stg.sql') or i.endswith('_etl.sql'): v = i.replace(f".{filename}", f".wrg.{filename}")
                else: v = i.replace(f".{filename}", f".crt.{filename}")
                for d in ddl:
                    if v == d['script']:
                        print(f'v-----------------{v}')
                        new_rel['upgrade'].append(v)
                        c=True
            if not c:
                raise()
        except:
            print(i,v)
            pass
    with open(file, 'w') as f:
        json.dump(new_rel,f,indent=2)



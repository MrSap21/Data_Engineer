import json
import os
from pathlib import Path
import pandas as pd
import re

df_ddl = pd.read_json(path_or_buf='./migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./migrations/ddl_tbd.json', orient='records')
df_schemas = df_ddl[df_ddl.id.str.startswith('D_')]

def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()
ddl_tbd = get_ddl_json(type='_tbd')

new_ddl = []
new_ddl_tbd = []


# update the ddl locations on all files
# step 1: unzip the tbd files
# step 2: run
# step 3: re-zip files


def fix_file(file_path, old_location):
    with open(file_path,'r') as f:
        txt = f.read()
    txt = txt.replace(old_location, '${TABLE_LOCATION}')
    # pathpart = file_path.split('/')[-1]
    # with open('./test/'+pathpart,'w') as f: #TODO: change /test/ after testing
    #     f.write(txt)
    with open(file_path,'w') as f: 
        f.write(txt)


try:
    for d in ddl:
        old_container = d['loc_container_param']
        old_location = d['location']
        fix_file(file_path=d['path'], old_location=old_location)
        if not d.get('downgrade_path','') == '':
            fix_file(file_path=d['downgrade_path'], old_location=old_location)
        
        ddl_meta_rewrite={}
        prev_field=''
        for k,v in d.items():
            current_field = k
            if current_field == 'subdomain':
                ddl_meta_rewrite['subdomain'] = v
                current_field = 'subdomain'
                ddl_meta_rewrite['data_classification_level'] = ''
                if d['zone'] == 'wrangled':
                    ddl_meta_rewrite['location_addtl_path'] = f"{d['domain_param']}/{d['subdomain_param']}/staging/"
                else:
                    ddl_meta_rewrite['location_addtl_path'] = f"{d['domain_param']}/{d['subdomain_param']}/"
            elif current_field in ['upgrade_id', 'wrangled_extra_layer']:
                pass                
            else:
                ddl_meta_rewrite[k] = v
            prev_field=current_field

        new_ddl.append(ddl_meta_rewrite)
        # new_container = old_container.replace(f'{d['domain'][:-1]}_{d['subdomain']}}}')
        # new_location = old_location.replace(f'/{d['domain_param']}','').replace(f'/{d['subdomain_param']}','').replace(old_container,new_container)
        # d.update({'location': new_location})
        
except Exception as e:
    print(df_ddl[df_ddl.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./testddl.json', 'w') as f:
    json.dump(new_ddl, f, indent=2)
# with open('./migrations/ddl.json', 'w') as f:
#     json.dump(ddl, f, indent=2)



try:
    for d in ddl_tbd:
        old_container = d['loc_container_param']
        old_location = d['location']
        fix_file(file_path=d['path'], old_location=old_location)
        if not d.get('downgrade_path','') == '':
            fix_file(file_path=d['downgrade_path'], old_location=old_location)
        
        ddl_meta_rewrite={}
        prev_field=''
        for k,v in d.items():
            current_field = k
            if current_field == 'subdomain':
                ddl_meta_rewrite['subdomain'] = v
                current_field = 'subdomain'
                ddl_meta_rewrite['data_classification_level'] = ''
                if d['zone'] == 'wrangled':
                    ddl_meta_rewrite['location_addtl_path'] = f"{d['domain_param']}/{d['subdomain_param']}/staging/"
                else:
                    ddl_meta_rewrite['location_addtl_path'] = f"{d['domain_param']}/{d['subdomain_param']}/"
            elif current_field == 'subdomain_param':
                ddl_meta_rewrite['subdomain_param'] = v
                current_field = 'subdomain_param'
            elif current_field in ['upgrade_id', 'wrangled_extra_layer']:
                pass                
            else:
                ddl_meta_rewrite[k] = v
            prev_field=current_field

        new_ddl_tbd.append(ddl_meta_rewrite)
        # new_container = old_container.replace(f'{d['domain'][:-1]}_{d['subdomain']}}}')
        # new_location = old_location.replace(f'/{d['domain_param']}','').replace(f'/{d['subdomain_param']}','').replace(old_container,new_container)
        # d.update({'location': new_location})
        
except Exception as e:
    print(df_tbd[df_tbd.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./testddltbd.json', 'w') as f:
    json.dump(new_ddl_tbd, f, indent=2)

# try:
#     for d in ddl_tbd:
#         old_container = d['loc_container_param']
#         new_container = old_container.replace(f'{d['domain'][:-1]}_{d['subdomain']}}}')
#         old_location = d['location']
#         new_location = old_location.replace(f'/{d['domain_param']}','').replace(f'/{d['subdomain_param']}','').replace(old_container,new_container)
#         fix_file(file_path=d['path'], old_location)
#         fix_file(file_path=d['downgrade_path'], old_location)
#         d.update({'location': new_location})
# except Exception as e:
#     print(df_tbd[df_tbd.id == d.get('id')].iloc[0])
#     print(e)
#     exit(1)
# finally:
#     pass
# with open('./migrations/ddl_tbd.json', 'w') as f:
#     json.dump(ddl, f, indent=2)






# ddl_clean = []
# ddl_tbd = []

# for i in ddl:
#     if i.get('domain','') == 'tbd':
#         ddl_tbd.append(i)
#     else:
#         ddl_clean.append(i)
# with open('./migrations/ddl.json', 'w') as f:
#         json.dump(ddl_clean, f, indent=2)
# with open('./migrations/ddl_tbd.json', 'w') as f:
#         json.dump(ddl_tbd, f, indent=2)






    

# try: 
#     for i in ddl:
#         fix_file(i['path'], i['partition_by'])
#         else:
#             pass
            # don't edit wrangled tables, as the container stays as wrangled

        # if not i.get('id','').startswith('D_'):
        #     schema = df_schemas[(df_schemas.zone == i.get('zone')) & (df_schemas.domain == i.get('domain')) & (df_schemas.subdomain == i.get('subdomain'))]['script'].iloc[0]
        #     ancs = i.get('ancestors', [])
        #     if ancs == []:
        #         ancs.append(schema)
        #     else:
        #         for a in ancs:
        #             new_ancs = [schema]
        #             try:
        #                 script_name = df_ddl[df_ddl.legacy_schema == a]['script'].iloc[0]
        #             except:
        #                 script_name = df_tbd[df_tbd.legacy_schema == a]['script'].iloc[0]
        #             new_ancs.append(script_name)
        #         ancs = new_ancs
        #     i.update({'ancestors':  ancs})
        #     if len(ancs) > 1:
        #         print(ancs)

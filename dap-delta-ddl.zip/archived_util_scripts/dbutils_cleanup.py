import json
import os
from pathlib import Path
import pandas as pd
import re

df_ddl = pd.read_json(path_or_buf='./migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./migrations/ddl_tbd.json', orient='records')

def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()
ddl_tbd = get_ddl_json(type='_tbd')




def fix_file(path, d):
    table_name = d['param_table_name']
    
    if d['id'].startswith('T'):
        with open(path,'w') as f: 
            f.write('-- Databricks notebook source\n')
            f.write('SET spark.databricks.delta.retentionDurationCheck.enabled = false;\n')
            f.write(f"DELETE FROM {table_name};\n")
            f.write(f"VACUUM {table_name} RETAIN 0 HOURS;\n")
            f.write(f"DROP TABLE {table_name};\n")
            f.write('SET spark.databricks.delta.retentionDurationCheck.enabled = True;\n')
            f.write('-- COMMAND ----------\n')
            f.write('%python\n')
            f.write(f"dbutils.fs.rm({d['location']}, recurse=True)")

    elif d['id'].startswith('V'):
        with open(path,'w') as f: 
            f.write('-- Databricks notebook source\n')
            f.write(f"DROP VIEW IF EXISTS {table_name};\n")
    





try:
    for d in ddl:
        if d['id'].startswith('V') or d['id'].startswith('T'):
            path = d['downgrade_path']
            # new_path = old_path.replace('.py','.sql')
            fix_file(path=path, d=d)
            # d.update({'downgrade_path': new_path})
except Exception as e:
    print(df_ddl[df_ddl.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl.json', 'w') as f:
    json.dump(ddl, f, indent=2)


try:
    for d in ddl_tbd:
        if d['id'].startswith('V') or d['id'].startswith('T'):
            path = d['downgrade_path']
            # new_path = old_path.replace('.py','.sql')
            fix_file(path=path, d=d)
            # d.update({'downgrade_path': new_path})
except Exception as e:
    print(df_tbd[df_tbd.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl_tbd.json', 'w') as f:
    json.dump(ddl_tbd, f, indent=2)

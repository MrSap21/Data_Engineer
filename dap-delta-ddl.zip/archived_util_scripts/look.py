import pandas as pd
import re
from pathlib import Path

rgx = re.compile(r'CREATE .+\s*?\(', re.MULTILINE)

tables = []
for file in Path('ddl_deploy/curated/R8/').glob('*.py'):
    with open(file, 'r') as f: text = f.read()
    for s in re.finditer(rgx, text):
        span = s.span()
        table = text[span[0]:span[1]]\
            .replace('CREATE TABLE IF NOT EXISTS ','')\
            .replace('CREATE TABLE ','')\
            .replace('CREATE OR REPLACE VIEW ','')\
            .replace('CREATE VIEW ','')\
            .replace('(','')\
            .strip()
        tables.append(table)

with open('tables.txt', 'w') as f:
    for table in tables:
        f.write(f"{table}\n")


df=pd.read_csv('migrations/utility/assets/report/report.csv')

df=df[(df['release #'].str.startswith('8')) & (~df['databricks schema'].isin(tables))]
df.to_csv('out.csv')
print(df.head())

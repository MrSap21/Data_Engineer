import json
import os
from pathlib import Path
import pandas as pd
import re


df_ddl = pd.read_json(path_or_buf='./migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./migrations/ddl_tbd.json', orient='records')
used = []


def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()
ddl_tbd = get_ddl_json(type='_tbd')

def declutter(data):
    os.rm(data.get('path'))
    os.rm(data.get('downgrade_path'))


try:
    new_ddl = []
    for d in ddl:
        if d.get('script') not in used:
            declutter(data=d)
        else:
            new_ddl.append(d)
    
    for d in new_ddl:
        pass
        # id change?

except Exception as e:
    print(df_ddl[df_ddl.id == d.get('id')].iloc[0])
    print(e)
    exit(1)
finally:
    pass
    # with open('./migrations/ddl.json', 'w') as f:
    #     json.dump(ddl, f, indent=2)


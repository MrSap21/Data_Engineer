import json
import os
from pathlib import Path
import pandas as pd
import re
import shutil

df_ddl = pd.read_json(path_or_buf='./migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='./migrations/ddl_tbd.json', orient='records')

def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()
ddl_tbd = get_ddl_json(type='_tbd')



def fix_file(old_path, new_path):
    try:
        if old_path == new_path:
            pass
        else:
            shutil.copy(old_path, new_path)
            os.remove(old_path)
    except Exception as e:
        print(old_path, new_path)
        pass
changes = {}

namingfix = {
    'wrangled': 'wrg',
    'curated': 'crt'
}
try:
    for d in ddl:
        if d['id'].startswith('V') or d['id'].startswith('T'):
            table_name = d['table_name']
            table_zone = d['zone']
            table_domain = d['domain']
            table_subdomain = d['subdomain']

            old_script = d['script']
            new_script = old_script.replace(f".1.{table_name}", f".1.{namingfix[table_zone]}.{table_name}")
            if d['script'] not in d['path']:
                old_path = d['path']
                new_path = old_path.replace(old_path.split('/')[-1],new_script)
            else:
                old_path = d['path']
                new_path = old_path.replace(old_script, new_script)

            old_downgrade_script = d['downgrade_path'].split('/')[-1]
            new_downgrade_script = old_downgrade_script.replace(f".0.{table_name}", f".0.{namingfix[table_zone]}.{table_name}")
            if d['script'] not in d['path']:
                old_downgrade_path = d['downgrade_path']
                new_downgrade_path = old_downgrade_path.replace(old_downgrade_path.split('/')[-1],new_downgrade_script)
            else:
                old_downgrade_path = d['downgrade_path']
                new_downgrade_path = old_downgrade_path.replace(old_downgrade_script, new_downgrade_script)

            d.update({'script': new_script})
            d.update({'path': new_path})
            d.update({'downgrade_path': new_downgrade_path})
            changes[old_downgrade_script] = new_downgrade_script
            changes[old_script] = new_script

            fix_file(old_path=old_path, new_path=new_path)
            fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)

        elif d['id'].startswith('D'):

            old_script = d['script']
            if '__staging__' in old_script:
                new_script = old_script.replace('.1.staging__','.1.wrg.')
            else:
                filename = old_script.split('.')[-2]
                new_script = old_script.replace(f'.1.{filename}',f'.1.crt.{filename}')

            old_downgrade_script = d['downgrade_path'].split('/')[-1]
            if '__staging__' in old_downgrade_script:
                new_downgrade_script = old_downgrade_script.replace('.0.staging__','.0.wrg.')
            else:
                filename = old_downgrade_script.split('.')[-2]
                new_downgrade_script = old_downgrade_script.replace(f'.0.{filename}',f'.0.crt.{filename}')
            

            old_path = d['path']
            new_path = old_path.replace(old_script,new_script)
            old_downgrade_path = d['downgrade_path']
            new_downgrade_path = old_downgrade_path.replace(old_downgrade_script, new_downgrade_script)
            
            d.update({'script': new_script})
            d.update({'path': new_path})
            d.update({'downgrade_path': new_downgrade_path})
            changes[old_downgrade_script] = new_downgrade_script
            changes[old_script] = new_script
            
            fix_file(old_path=old_path, new_path=new_path)
            fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)
    for d in ddl:
        old_ancestors = d['ancestors']
        new_ancestors = []
        if isinstance(old_ancestors, list):
            for a in old_ancestors:
                new_ancestors.append(changes.get(a,''))
        d.update({'ancestors': new_ancestors})
    
except Exception as e:
    print(df_ddl[df_ddl.id == d['id']].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl.json', 'w') as f:
        json.dump(ddl, f, indent=2)


try:
    for d in ddl_tbd:
        if d['id'].startswith('V') or d['id'].startswith('T'):
            table_name = d['table_name']
            table_zone = d['zone']
            table_domain = d['domain']
            table_subdomain = d['subdomain']

            old_script = d['script']
            new_script = old_script.replace(f".1.{table_name}", f".1.{namingfix[table_zone]}.{table_name}")
            if d['script'] not in d['path']:
                old_path = d['path']
                new_path = old_path.replace(old_path.split('/')[-1],new_script)
            else:
                old_path = d['path']
                new_path = old_path.replace(old_script, new_script)

            old_downgrade_script = d['downgrade_path'].split('/')[-1]
            new_downgrade_script = old_downgrade_script.replace(f".0.{table_name}", f".0.{namingfix[table_zone]}.{table_name}")
            if d['script'] not in d['path']:
                old_downgrade_path = d['downgrade_path']
                new_downgrade_path = old_downgrade_path.replace(old_downgrade_path.split('/')[-1],new_downgrade_script)
            else:
                old_downgrade_path = d['downgrade_path']
                new_downgrade_path = old_downgrade_path.replace(old_downgrade_script, new_downgrade_script)

            
            

            d.update({'script': new_script})
            d.update({'path': new_path})
            d.update({'downgrade_path': new_downgrade_path})
            changes[old_downgrade_script] = new_downgrade_script
            changes[old_script] = new_script

            fix_file(old_path=old_path, new_path=new_path)
            fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)

    for d in ddl:
        old_ancestors = d['ancestors']
        new_ancestors = []
        if isinstance(old_ancestors, list):
            for a in old_ancestors:
                new_ancestors.append(changes.get(a,''))
        d.update({'ancestors': new_ancestors})
except Exception as e:
    print(df_tbd[df_tbd.id == d['id']].iloc[0])
    print(e)
    exit(1)
finally:
    pass
with open('./migrations/ddl_tbd.json', 'w') as f:
    json.dump(ddl_tbd, f, indent=2)


with open('changes3.json', 'w') as f:
    json.dump(changes, f, indent=2)
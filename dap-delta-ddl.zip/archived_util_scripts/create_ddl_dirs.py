import os
from pathlib import Path

paths = [str(i[0]).replace('\\','/').replace('/scripts/','/ddl_deploy/') for i in os.walk('./scripts/')]

for path in paths:
    if 'downgrade' not in path:
        Path(path).mkdir(exist_ok=True)
        with open(f'{path}/.dummy', 'w') as f:
            f.write('')

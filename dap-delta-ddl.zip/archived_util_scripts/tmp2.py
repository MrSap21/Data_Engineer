import json
from pathlib import Path
import shutil
import os

def get_ddl_json(type=''):
    with open(f'./migrations/ddl{type}.json', 'r') as f:
        ddl = json.load(f)
    return ddl
ddl = get_ddl_json()



def fix_file(old_path, new_path):
    if old_path == new_path and '__' not in old_path:
        pass
    else:
        try:
            shutil.copy(old_path, new_path)
            os.remove(old_path)
        except Exception as e:
            print(old_path, new_path)
            pass
changes = {}


def fix_file(old_path, new_path):
    try:
        if old_path == new_path:
            pass
        else:
            shutil.copy(old_path, new_path)
            os.remove(old_path)
    except Exception as e:
        print(e, old_path, new_path)
        pass
changes = {}

namingfix = {
    'wrangled': 'wrg',
    'curated': 'crt'
}
try:
    for d in ddl:
        if d['id'].startswith('D'):

            
            if d['zone'] == 'wrangled':
                old_script = d['script'].replace('.1.wrg.', '.1.crt.staging__')
                new_script = d['script']
                new_downgrade_script = d['downgrade_path'].split('/')[-1]
                old_downgrade_script = new_downgrade_script.replace('.0.wrg.','.0.crt.staging__')
        
                new_path = d['path']
                old_path = new_path.replace(new_path.split('/')[-1], old_script)
                new_downgrade_path = d['downgrade_path']
                old_downgrade_path = new_downgrade_path.replace(new_downgrade_path.split('/')[-1], old_downgrade_script)
                print(new_path)
                print(old_path)
                print(new_downgrade_path)
                print(old_downgrade_path)
                print('')
    #             d.update({'script': new_script})
    #             d.update({'path': new_path})
    #             d.update({'downgrade_path': new_downgrade_path})
    #             changes[old_downgrade_script] = new_downgrade_script
                changes[old_script] = new_script
            
                fix_file(old_path=old_path, new_path=new_path)
                fix_file(old_path=old_downgrade_path, new_path=new_downgrade_path)
    # for d in ddl:
    #     old_ancestors = d['ancestors']
    #     new_ancestors = []
    #     if isinstance(old_ancestors, list):
    #         for a in old_ancestors:
    #             new_ancestors.append(changes.get(a,''))
    #     d.update({'ancestors': new_ancestors})
    
except Exception as e:
    print(df_ddl[df_ddl.id == d['id']].iloc[0])
    print(e)
    exit(1)
# finally:
#     pass
# with open('./migrations/ddl.json', 'w') as f:
#         json.dump(ddl, f, indent=2)

[print(k, v) for k,v in changes.items()]

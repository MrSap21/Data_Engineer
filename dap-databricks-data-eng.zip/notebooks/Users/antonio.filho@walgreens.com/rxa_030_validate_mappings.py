# Databricks notebook source
# Mounting ADLS

# Define the variables used for creating connection strings
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
adlsFolderName = dbutils.widgets.get('AI_SERIAL_TEMP')
mountPoint = "/mnt/" + adlsFolderName

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
#
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")

# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")

endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

# Checking files

dbutils.fs.ls(mountPoint)

# COMMAND ----------

# Define Input Schema

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("yr_nbr", IntegerType(), False),
    StructField("mnth_nbr", IntegerType(), False),
    StructField("plan_id", StringType(), False),
    StructField("group_id", StringType(), False),
    StructField("channel", StringType(), False),
    StructField("contract", StringType(), False),
    StructField("client", StringType(), False),
    StructField("payer_type", StringType(), False)
  ])
)

# COMMAND ----------

# Read Input File

inputFilePath = mountPoint + "/rxa_000_010_" + dbutils.widgets.get('pIN_MAPS_TYPE') + ".dat"

df = spark.read.format("csv").options(header='true', delimiter = '�').schema(inputSchema).load(inputFilePath)
df.show()

# COMMAND ----------

# Clean Empty Values

from pyspark.sql.functions import *

dfClean = (df
              .withColumn("yr_nbr", col("yr_nbr"))
              .withColumn("mnth_nbr", col("mnth_nbr"))
              .withColumn("plan_id", trim(col("plan_id")))
              .withColumn("group_id", trim(col("group_id")))
              .withColumn("channel", trim(col("channel")))
              .withColumn("contract", trim(col("contract")))
              .withColumn("client", trim(col("client")))
              .withColumn("id", monotonically_increasing_id()))
dfClean.show()

# COMMAND ----------

# Mark Duplicates

dfCleanDupsMarkedAux = dfClean.groupBy(col("yr_nbr"), col("mnth_nbr"), col("plan_id"), col("group_id"), col("channel"), col("contract"), col("client")).agg(max(col("id")).alias("id")).withColumn("nk_dups", lit(False)).drop("yr_nbr", "mnth_nbr", "plan_id", "group_id", "channel", "contract", "client")

dfCleanDupsMarked = dfClean.join(dfCleanDupsMarkedAux, "id", "left").drop("id").withColumn("nk_dups", when(col("nk_dups") == False, col("nk_dups")).otherwise(True))

dfCleanDupsMarked.show()

# COMMAND ----------

# Validation

error_message = when(length(col("yr_nbr")) == 4, "").otherwise(" Year not Correct")
error_message = concat(error_message, when((col("mnth_nbr") > 0) & (col("mnth_nbr") <= 12), "").otherwise(" Month not Correct"))
error_message = concat(error_message, when((length(col("plan_id")) > 0) & (length(col("plan_id")) <= 8), "").otherwise(" Plan not Correct"))
error_message = concat(error_message, when((length(col("group_id")) > 0) & (length(col("group_id")) <= 15), "").otherwise(" Group not Correct"))
error_message = concat(error_message, when(length(col("channel")) == 1, "").otherwise(" Channel not Correct"))
error_message = concat(error_message, when((length(col("contract")) > 0) & (length(col("contract")) <= 75), "").otherwise(" Contract not Correct"))
error_message = concat(error_message, when((length(col("client")) > 0) & (length(col("client")) <= 175), "").otherwise(" Client not Correct"))
error_message = concat(error_message, when(dfCleanDupsMarked.nk_dups, "").otherwise(" Contains Duplicates"))

dfValidated = dfCleanDupsMarked.withColumn("errors", trim(lit(error_message))).drop("nk_dups")
                            
dfValidated.show()

# COMMAND ----------

# Filter errors

dfOutput = dfValidated.where(col("errors") == "")
dfErrors = dfValidated.where(col("errors") != "")

# COMMAND ----------

# Generate error dataset

pLC_MAPS_COUNT = int(dbutils.widgets.get('pLC_MAPS_COUNT'))
pLC_MAPS_FL = dbutils.widgets.get('pLC_MAPS_FL')

if dfClean.count() == (pLC_MAPS_COUNT - 1) :
  raise Exception("ABAC succeeded")

errorSchema = StructType([ \
    StructField("yr_nbr",StringType(),True),
    StructField("mnth_nbr",StringType(),True),
    StructField("plan_id",StringType(),True),
    StructField("group_id",StringType(),True),
    StructField("channel",StringType(),True),
    StructField("contract",StringType(),True),
    StructField("client",StringType(),True),
    StructField("payer_type",StringType(),True),
    StructField("errors",StringType(),True)
  ])

errorData = [("-99",
              "-99",
              "-na",
              "-na",
              "na",
              "-na",
              "-na",
              "-na",
              pLC_MAPS_FL + " " + "ABAC failed")]

dfErrorsAux = spark.createDataFrame(errorData, errorSchema)

dfRejectRecs = dfErrors.union(dfErrorsAux)

# COMMAND ----------

# Error Rollup

pLC_REJS_FILE = dbutils.widgets.get('pLC_REJS_FILE')

errorRollupSchema = StructType([ \
    StructField("rec_count",IntegerType(),True),
    StructField("file_nm",StringType(),True)
  ])

errorRollupData = [(dfRejectRecs.count(), pLC_REJS_FILE)]

dfRejectTrigger = spark.createDataFrame(errorRollupData, errorRollupSchema)

# COMMAND ----------

# Create output path

data_location_output = mountPoint + "/" + dbutils.widgets.get('pIN_OMAPS_FIXD') + "_" + dbutils.widgets.get('pIN_MAPS_TYPE') + "_" + dbutils.widgets.get('pLC_MAPS_PERD') + "_" + dbutils.widgets.get('pEDWBATCHID')
data_location_rejrecs = mountPoint + "/" + dbutils.widgets.get('pLC_REJS_FILE')  
data_location_trigger = mountPoint + "/" + dbutils.widgets.get('pLC_TRGR_FILE')
  
# Write in ADLS

dfOutput.coalesce(1).write.options(header='true', delimiter = '�').format("csv").mode("overwrite").save(data_location_output)
dfRejectRecs.coalesce(1).write.options(header='true', delimiter = '�').format("csv").mode("overwrite").save(data_location_rejrecs)
dfRejectTrigger.coalesce(1).write.options(header='true', delimiter = '�').format("csv").mode("overwrite").save(data_location_trigger)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

filesrejrecs = dbutils.fs.ls(data_location_rejrecs)
csv_file_rejrecs = [x.path for x in filesrejrecs if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_rejrecs, data_location_rejrecs.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_rejrecs, recurse = True)

filesrejtrigger = dbutils.fs.ls(data_location_trigger)
csv_file_rejtrigger = [x.path for x in filesrejtrigger if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_rejtrigger, data_location_trigger.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_trigger, recurse = True)

# COMMAND ----------


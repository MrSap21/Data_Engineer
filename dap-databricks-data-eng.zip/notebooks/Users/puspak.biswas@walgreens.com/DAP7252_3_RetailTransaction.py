# Databricks notebook source
# dbutils.widgets.text('PAR_NB_INPUT_FILE_PATH','retail/retail_sales/Puspak/7252/poslog_RetailTransaction/test220713')
# dbutils.widgets.text('PAR_NB_NEXT_GEN','retail/retail_sales/lookup/nextgen_decode')
# dbutils.widgets.text('PAR_NB_POS_EJ_RETAIL','retail/retail_sales/staging/pos_ej_RetailTransaction')
# dbutils.widgets.text('PAR_NB_POS_POST_RFNS','retail/retail_sales/staging/pos_post_void_w_orig_rfns')
# dbutils.widgets.text('PAR_NB_POS_POST_W_ORIG_INFO','retail/retail_sales/staging/pos_post_void_w_orig_info')
# dbutils.widgets.text('PAR_NB_POS_POST_RFNS_INVALID','retail/retail_sales/reject/pos_post_void_invalid_rfn')
# dbutils.widgets.text('PAR_NB_RT_RFN_OUTPUT_FILE_PATH','retail/retail_sales/staging/pos_rt_rfn')
# dbutils.widgets.text('PAR_PL_BATCH_ID','test220713')

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import arrays_zip
from pyspark.sql import functions as F

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

#dbutils.widgets.text("PAR_NB_INPUT_FILE_PATH","retail/retail_sales/staging/POSLog_RetailTransaction/12345")

filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_FILE_PATH")

#filePath = "/mnt/wrangled/retail/retail_sales/staging/POSLog_RetailTransaction/12345"

# COMMAND ----------

spark.conf.set("spark.sql.caseSensitive","true")

dfRT = spark.read.format("parquet").option('inferSchema','False').load(filePath)
#dfRT.count() 5419293

# COMMAND ----------

#PUSPAK
def LineItemTransformations(RtlTxnRow,txn_type):
  RtlTxn = RtlTxnRow.asDict()
  tmp_sale_count = 0
  tmp_ereturn_count = 0
  tmp_return_count = 0
  tmp_transaction_type = '10'
  tmp_sale_or_return = ''
  
  try:
    LineItem = RtlTxn['LineItem']
  except:
    LineItem = None
          
  try:
    TransactionStatus = RtlTxn['_TransactionStatus'] or ''
  except:
    TransactionStatus = ''
    
  try:
    Customer = RtlTxn['Customer']
    TaxCertificate = None
    for cst in Customer:
      if cst['TaxCertificate'] !=None:
        TaxCertificate = cst['TaxCertificate']
  except:
    TaxCertificate = None
    
  if int(txn_type.strip())== 20:
    tmp_transaction_type = "38"
  elif int(txn_type.strip()) == 92:
    if TransactionStatus.strip().upper() == 'CANCELED':
      tmp_transaction_type = "48"
    else:
      tmp_transaction_type = "25"
  elif int(txn_type.strip()) == 3: 
    if TransactionStatus.strip().upper() == 'CANCELED':
      tmp_transaction_type = "48"
    elif TaxCertificate != None:
      if len(TaxCertificate.strip()) > 0:
        tmp_transaction_type = "16"
    elif LineItem != None:
      if len(LineItem) == 1:
        try:
          TenderID = LineItem[0]['Tender']['TenderID'] or ''
        except:
          TenderID = ''
        try:
          ChangeTenderID = LineItem[0]['Tender']['TenderChange']['TenderID'] or ''
        except:
          ChangeTenderID = ''
        try:
          TenderType = LineItem[0]['Tender']['TenderChange']['_TenderType'] or ''
        except:
          TenderType = ''
        if ((TenderID.strip()) == '99') & ((TenderType.strip()).upper() == 'CASH') & ((ChangeTenderID.strip()) == '1'):
          tmp_transaction_type = "53"
      elif len(LineItem) > 1:
        for li in LineItem:
          try:
            ItemID = li['Sale']['ItemID'] or ''
          except:
            ItemID = ''
          if len(ItemID.strip()) > 0:
            tmp_sale_count = tmp_sale_count + 1
          try:
            RetailPriceModifier = li['Sale']['RetailPriceModifier']
          except:
            RetailPriceModifier = None
          if RetailPriceModifier != None:
            for rpm in RetailPriceModifier:               
              try:
                ReasonCode = rpm['ReasonCode'] or ''
              except:
                ReasonCode = ''
              if (ReasonCode.strip() == "1:EMPLOYEE") | (ReasonCode.strip() == "1:MILITARY") | (ReasonCode.strip() == "1:TEACHER"):
                tmp_transaction_type = "11"
              elif (ReasonCode.strip()) == "1:PROF":
                tmp_transaction_type = "12"
              elif (ReasonCode.strip()) == "1:SENIOR":
                tmp_transaction_type = "13"
              elif ((ReasonCode.strip())[0:8]) == "1:710000":
                tmp_transaction_type = "17"
        if len(tmp_sale_or_return.strip()) == 0:
          for li in LineItem:
            try:
              Return_ExtAmt = li['Return']['ExtendedAmount'] or ''
            except:
              Return_ExtAmt = ''
            if len(Return_ExtAmt.strip()) > 0:
              try:
                Return_ReasonCode = li['Return']['pcms:PCMSReturn']['pcms:ReasonCode'] or ''
              except:
                Return_ReasonCode = ''
              if Return_ReasonCode == '11:g':
                tmp_ereturn_count = tmp_ereturn_count + 1
              else:
                tmp_return_count = tmp_return_count + 1
        if (tmp_ereturn_count > 0) & (tmp_sale_count == 0):
          tmp_transaction_type = "15"
        elif (tmp_return_count > 0) & (tmp_sale_count == 0):
          tmp_transaction_type = "14"
                            
  return tmp_transaction_type

udf_LineItemTransformations = udf(LineItemTransformations,StringType())
#display(dfRT.select('RetailTransaction').withColumn('rt2',udf_LineItemTransformations(col('RetailTransaction'))))

# COMMAND ----------

#PUSPAK
dfTxnType=dfRT.withColumn('tmp_transaction_type',udf_LineItemTransformations(col('RetailTransaction'),col('txn_type')))\
                .withColumn('txn_type',col('tmp_transaction_type'))\
               .withColumn('ej_rfn',concat(substring(col('rfn'),1,18),(col('tmp_transaction_type') + 10)))\
               .withColumn('check_string_1',substring(col('ej_rfn'),1,11))\
               .withColumn('check_string_2',substring(col('ej_rfn'),13,8))\
               .withColumn('check_string',slice(split(concat(col('check_string_1'),col('check_string_2')),''),1,19))\
               .withColumn('multiplier',array(lit(3), lit(5), lit(7), lit(1), lit(3), lit(5), lit(7), lit(1), lit(3), lit(5), lit(7), lit(1), lit(3), lit(5), lit(7), lit(1), lit(3), lit(5), lit(7)))\
               .withColumn('zipped',arrays_zip(col('check_string'),col('multiplier')))\
               .withColumn('multiplied',expr("""transform(zipped,x -> int(x.check_string * x.multiplier))"""))\
               .withColumn('sum2',expr("""reduce(multiplied,0,((x,s) -> x+s))"""))\
               .withColumn('sum',(10 - (col('sum2')%10))%10)\
               .withColumn('ej_rfn_value',concat(col('check_string_1'),col('sum'),col('check_string_2')))\
               .drop('tmp_sale_count','tmp_ereturn_count','tmp_return_count'\
                     ,'ej_rfn','check_string_1','check_string_2','check_string','multiplier','zipped','multiplied','sum2','sum')

#display(dfTxnType.select(col('tmp_transaction_type')).distinct())

# COMMAND ----------

## reading lookup file
#dbutils.widgets.text("PAR_NB_NEXT_GEN","retail/retail_sales/lookup/nextgen_decode")

nextgenlkp = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NEXT_GEN")
df_nextgenlkp=spark.read.parquet(nextgenlkp)

## Input to Header
#display(df_nextgenlkp)
df_split=dfTxnType.select('*').withColumn('rfn',col('ej_rfn_value')).drop('ej_rfn_value')

# COMMAND ----------

#POS RETAIL Transaction rt

dfposrt_rfn=dfTxnType.select('str_nbr','txn_date',col('pcms:PCMSTransaction.wag:CashierEmployeeID').alias('employee_id'),col('OperatorID').alias('authenticator_id'),'ej_rfn_value',col('rfn').alias('next_gen_rfn_value'))

#dbutils.widgets.text("PAR_NB_RT_RFN_OUTPUT_FILE_PATH",'retail/retail_sales/staging/pos_rt_rfn')
#dbutils.widgets.text("PAR_PL_BATCH_ID",'12345')

rt_rfn = mountPoint + "/" + dbutils.widgets.get("PAR_NB_RT_RFN_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

# # Write in ADLS 
dfposrt_rfn.write.format("parquet").mode("overwrite").save(rt_rfn) 

# COMMAND ----------

#PUSPAK
#Create EJ Transaction Header
#txntype1 has 11,12,17 txn types
df_txntype1=df_split.filter((col('txn_type')=='11') | (col('txn_type')=='12') | (col('txn_type')=='17'))
df_txntype1=df_txntype1.withColumn('txn_type',when((trim(col('txn_type')))=='17','11').otherwise(col('txn_type')))\
                       .withColumn('discount_mode',coalesce(col('txn_type'),lit('  ')))\
                       .withColumn('txn_start_time',substring(col('BeginDateTime'),12,8))\
                       .withColumn('txn_stop_time',substring(col('EndDateTime'),12,8))\
                       .withColumn('offline',when((length(trim(coalesce(col('pcms:PCMSTransaction.pcms:OnlineStatus'),lit(' ')))) == 0) | (col('pcms:PCMSTransaction.pcms:OnlineStatus')=="0"),lit(''))\
                                  .otherwise(lit("O").cast(StringType())))\
                       .withColumn('sequence_nbr',lit(0).cast(IntegerType())).withColumn('bogo_seq_nbr',lit(0))\
                       .withColumn('original_txn_nbr',col('txn_nbr')).withColumn('ind',lit(None)).withColumn('rcd_type',lit(' '))\
                       .withColumn('EJ',concat(lit(' ')
                                               ,lpad(lit(' '),4,' ')
                                               ,lpad(lit(' '),7,' ')
                                               ,lpad(coalesce(col('txn_start_time'),lit(' ')),6,' ')
                                               ,lit(' ')
                                               ,lpad(coalesce(col('txn_stop_time'),lit(' ')),6,' ')
                                               ,lit(' ')
                                               ,col('discount_mode')
                                               ,lpad(lit(' '),22,' ')
                                               ,lpad(coalesce(col('offline'),lit(' ')),1,' ')
                                               ,lpad(coalesce(col('rfn'),lit(' ')),20,' ')
                                               ,lpad(lit(' '),9,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')


### txn_type not 11,12,17,38
df_txntype2=df_split.filter((col('txn_type')!='11') & (col('txn_type')!='12') & (col('txn_type')!='17') & (col('txn_type')!='38'))\
                    .withColumn('txn_start_time',substring(col('BeginDateTime'),12,8))\
                       .withColumn('txn_stop_time',substring(col('EndDateTime'),12,8))\
                       .withColumn('offline',when((length(trim(coalesce(col('pcms:PCMSTransaction.pcms:OnlineStatus'),lit(' ')))) == 0) | (col('pcms:PCMSTransaction.pcms:OnlineStatus')=="0"),lit(''))\
                                  .otherwise(lit("O").cast(StringType())))\
                       .withColumn('sequence_nbr',lit(0)).withColumn('bogo_seq_nbr',lit(0)).withColumn('rcd_type',lit(' '))\
                       .withColumn('original_txn_nbr',col('txn_nbr')).withColumn('ind',lit(None))\
                       .withColumn('EJ',when(~(trim(col('txn_type')).eqNullSafe('99')),
                                                concat(lit(' ')
                                               ,lpad(lit(' '),4,' ')
                                               ,lpad(lit(' '),7,' ')
                                               ,lpad(coalesce(col('txn_start_time'),lit(' ')),6,' ')
                                               ,lit(' ')
                                               ,lpad(coalesce(col('txn_stop_time'),lit(' ')),6,' ')
                                               ,lpad(lit(' '),25,' ')
                                               ,lpad(coalesce(col('offline'),lit(' ')),1,' ')
                                               ,lpad(coalesce(col('rfn'),lit(' ')),20,' ')
                                               ,lpad(lit(' '),9,' ')))\
                                  .otherwise(concat(lpad(lit(' '),51,' '),lpad(coalesce(col('rfn'),lit(' ')),20,' '),lpad(lit(' '),9,' '))))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#txn_type not 11,12,17 but equal to 38
df_txntype3=df_split.filter(col('txn_type')=='38')
df_txntype3_1=df_txntype3.withColumn('txn_start_time',substring(col('BeginDateTime'),12,8))\
                       .withColumn('txn_stop_time',substring(col('EndDateTime'),12,8))\
                       .withColumn('offline',when((length(trim(coalesce(col('pcms:PCMSTransaction.pcms:OnlineStatus'),lit(' ')))) == 0) | (col('pcms:PCMSTransaction.pcms:OnlineStatus')=="0"),lit(''))\
                                  .otherwise(lit("O").cast(StringType())))\
                       .withColumn('sequence_nbr',lit(0).cast(IntegerType())).withColumn('bogo_seq_nbr',lit(0))\
                       .withColumn('original_txn_nbr',col('txn_nbr')).withColumn('ind',lit(None)).withColumn('rcd_type',lit(' '))\
                       .withColumn('EJ',concat(lit(' ')
                                               ,lpad(lit(' '),4,' ')
                                               ,lpad(lit(' '),7,' ')
                                               ,lpad(coalesce(col('txn_start_time'),lit(' ')),6,' ')
                                               ,lit(' ')
                                               ,lpad(coalesce(col('txn_stop_time'),lit(' ')),6,' ')
                                               ,lpad(lit(' '),25,' ')
                                               ,lpad(coalesce(col('offline'),lit(' ')),1,' ')
                                               ,lpad(coalesce(col('rfn'),lit(' ')),20,' ')
                                               ,lpad(lit(' '),9,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

df_txntype3_2_pre=df_txntype3.withColumn('ind',when(upper(col('RetailTransaction._TransactionStatus'))=="POSTVOIDED","S")\
                                    .otherwise(lit("F").cast(StringType())))\
                         .withColumn('PCMSEvent_pcms_ApplicationEvent',df_txntype3.RetailTransaction['pcms:PCMSEvent'][0]['pcms:ApplicationEvent'])\
                         .withColumn('temp_App',instr(col('PCMSEvent_pcms_ApplicationEvent'),':'))\
                         .withColumn('temp_lastApp',length(col('PCMSEvent_pcms_ApplicationEvent'))-instr(reverse(col('PCMSEvent_pcms_ApplicationEvent')),':'))\
                         .withColumn('ggg',expr("""substring(PCMSEvent_pcms_ApplicationEvent,temp_App+1,temp_lastApp - temp_App)"""))\
                         .withColumn('original_txn_nbr_temp',when(upper(col('RetailTransaction._TransactionStatus'))=="POSTVOIDED", col('RetailTransaction.TransactionLink.SequenceNumber'))\
                                     .when(col('PCMSEvent_pcms_ApplicationEvent').isNotNull(), expr("""substring(PCMSEvent_pcms_ApplicationEvent,temp_App+1,temp_lastApp - temp_App)""")))\
                        .withColumn('original_txn_nbr',when(length(col('original_txn_nbr_temp'))<=4,lpad(col('original_txn_nbr_temp'),4,"0"))\
                                   .otherwise(col('original_txn_nbr_temp')))\
    .withColumn('unused1',when(col('PCMSEvent_pcms_ApplicationEvent')>0,expr("""substring_index(PCMSEvent_pcms_ApplicationEvent,temp_lastApp,62)""")))\
.withColumn('sequence_nbr',lit(0).cast(IntegerType())).withColumn('bogo_seq_nbr',lit(0))\
.withColumn('ind',lit(None)).withColumn('rcd_type',lit(' '))\
.withColumn('txn_start_time',substring(col('BeginDateTime'),12,8))\
                       .withColumn('txn_stop_time',substring(col('EndDateTime'),12,8))\
                       .withColumn('offline',when((length(trim(coalesce(col('pcms:PCMSTransaction.pcms:OnlineStatus'),lit(' ')))) == 0) | (col('pcms:PCMSTransaction.pcms:OnlineStatus')=="0"),lit('1'))\
                                  .otherwise(lit("O").cast(StringType())))\
                                  .withColumn('EJ',concat(lit(' ')
                                               ,lpad(lit(' '),4,' ')
                                               ,lpad(coalesce(col('unused1'),lit(' ')),7,' ')
                                               ,lpad(coalesce(col('txn_start_time'),lit(' ')),6,' ')
                                               ,lit(' ')
                                               ,lpad(coalesce(col('txn_stop_time'),lit(' ')),6,' ')
                                               ,lpad(lit(' '),25,' ')
                                               ,lpad(coalesce(col('offline'),lit(' ')),1,' ')
                                               ,lpad(coalesce(col('rfn'),lit(' ')),20,' ')
                                               ,lpad(lit(' '),9,' ')))

df_txntype3_2 = df_txntype3_2_pre.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ').where(length(trim(col('original_txn_nbr')))<=4)

df_error_postvoided_rejects =df_txntype3_2_pre.where(length(trim(col('original_txn_nbr')))>4).select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr',lit(' ').alias('rcd_type'),'original_txn_nbr',(lit('')).alias('ind'),'unused1').withColumn('reject_reason',lit('original_txn_nbr cannot be grater than 4 digits'))

post_voided_rej_file = mountPoint + "/"  + dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID')[0:(len(dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID')) - ((dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID'))[::-1]).find('/'))] + 'poslog_post_voided_rejects' + '/' + dbutils.widgets.get('PAR_PL_BATCH_ID')

df_error_postvoided_rejects.write.format('parquet').mode('overwrite').save(post_voided_rej_file)
#display(df_error_postvoided_rejects)

df_header=df_txntype1.union(df_txntype2).union(df_txntype3_1).union(df_txntype3_2)\
.select('record_nbr', 'detail_nbr', 'detail_type', 'sequence_nbr','bogo_seq_nbr','str_nbr', 'txn_date', 'txn_time','cashier_nbr','register_nbr', 'txn_type', 'txn_nbr', 'rcd_type','EJ')

#display(df_header)
#df_header.count() 5425074

# COMMAND ----------

#PUSPAK
#####Process Price Verify
df_split=df_split.withColumn('txn_type',when(col('txn_type')==17,11).otherwise(col('txn_type')))\
                 .filter(col('txn_type')!=38)

df_lineitem_1= df_split.withColumn('RetailTransaction_pcms:PCMSEvent',explode(col('RetailTransaction.pcms:PCMSEvent')))\
                       .withColumn('detail_nbr',col('RetailTransaction_pcms:PCMSEvent.pcms:DetailNumber._VALUE'))\
                       .withColumn('TxnType',col('RetailTransaction_pcms:PCMSEvent.pcms:DetailNumber._TxnType'))\

df_lineitem_1_joined = df_lineitem_1.join(df_nextgenlkp,trim(df_lineitem_1.TxnType) == trim(df_nextgenlkp.code),how='left').select('str_nbr', 'txn_date', 'txn_time', 'cashier_nbr', 'register_nbr', 'txn_type', 'txn_nbr', 'record_type', 'workstation_location', 'rfn','RetailTransaction_pcms:PCMSEvent','record_nbr', 'detail_nbr','ej_code').withColumnRenamed('ej_code','detail_type')\
.where(length(trim(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:ItemID')))>0)

df_lineitem_priceverify = df_lineitem_1_joined.withColumn('temp_sequence_nbr',when(col('RetailTransaction_pcms:PCMSEvent.pcms:DetailNumber._TxnType') == 'TxnDetail',col('RetailTransaction_pcms:PCMSEvent.pcms:DetailNumber._VALUE')).otherwise(lit('9999')))\
                             .withColumn('upc_or_tender'\
                                         ,lpad(substring(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:ItemID'),2,12),12,'0'))\
                             .withColumn('desc_or_acct_nbr'\
                                         ,substring(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:Description'),1,18))\
                             .withColumn('item_unit_cost',when(~(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:RegularSalesUnitPrice').rlike('\D+')),bround(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:RegularSalesUnitPrice')*100)).otherwise(None))\
                             .withColumn('int1',locate('-',col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:MerchandiseHierarchy._VALUE'))-2)\
                             .withColumn('int2',col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:MerchandiseHierarchy._VALUE'))\
                             .withColumn('dept_nbr',when(~(substring(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:MerchandiseHierarchy._VALUE'),2,4).rlike('\D+')),lpad(lit('6'),3,"0")).when(substring(col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:MerchandiseHierarchy._VALUE'),1,1) == 'D',expr("""substring(int2,2,int1)""")))\
                             .withColumn('quantity',lit(' '))\
                             .withColumn('tax_type',lit(' '))\
.withColumn('selling_price',col('RetailTransaction_pcms:PCMSEvent.pcms:PCMSProductInformation.pcms:RegularSalesUnitPrice'))\
.withColumn('price_verify',lit('Y'))\
.withColumn('item_unit_cost',lit(' '))\
.withColumn('item_cost',lit(' '))\
.withColumnRenamed('temp_sequence_nbr','sequence_nbr')\
.withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('A'))\
.withColumn('price_sign',lit(None))\
.withColumn('sale_indicator',lit(None))\
.withColumn('wag_coupon',lit(None))\
.withColumn('discount_mode',lit(None))\
.withColumn('item_void',lit(None))\
.withColumn('keyed_item',lit(None))\
.withColumn('returned_item',lit(None))\
.withColumn('price_modify',lit(None))\
.withColumn('training_item',lit(None))\
.withColumn('special',lit(None))\
.withColumn('unused5',lit(None))\
.withColumn('unused',lit(None))\
.withColumn('price_modify',lit(None))\
.withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),(lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),(lpad((coalesce(col('item_cost'),lit('0'))),6,' ')),(lpad((coalesce(col('item_unit_cost'),lit('0'))),7,' ')),(lpad((coalesce(col('dept_nbr'),lit('0'))),3,' ')),(lpad((coalesce(col('quantity'),lit('0'))),5,' ')),(lpad((coalesce(col('tax_type'),lit(' '))),1,' ')),(lpad((coalesce(col('selling_price'),lit('.00'))),8,' ')),(lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),(lpad((coalesce(col('sale_indicator'),lit(' '))),1,' ')),(lpad((coalesce(col('wag_coupon'),lit(' '))),1,' ')),(lpad((coalesce(col('discount_mode'),lit(' '))),1,' ')),(lpad((coalesce(col('item_void'),lit(' '))),1,' ')),(lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),(lpad((coalesce(col('returned_item'),lit(' '))),1,' ')),(lpad((coalesce(col('price_modify'),lit(' '))),1,' ')),(lpad((coalesce(col('price_verify'),lit(' '))),1,' ')),(lpad((coalesce(col('training_item'),lit(' '))),1,' ')),(lpad((coalesce(col('special'),lit(' '))),1,' ')),(lpad((coalesce(col('unused5'),lit(' '))),9,' '))))\
.select('record_nbr', 'detail_nbr', 'detail_type', 'sequence_nbr','bogo_seq_nbr','str_nbr', 'txn_date', 'txn_time','cashier_nbr','register_nbr', 'txn_type', 'txn_nbr', 'rcd_type','EJ') 

#df_lineitem_priceverify.count() 110052

# COMMAND ----------

#PUSPAK
###Select LineItem

df_lineitem_transform =df_split.withColumn('LineItem',explode(col('RetailTransaction.LineItem')))\
.withColumn('detail_nbr',expr("""LineItem['pcms:PCMSLineItem']['pcms:DetailNumber'][size(LineItem['pcms:PCMSLineItem']['pcms:DetailNumber'])-1]['_VALUE']""")).na.fill({'detail_nbr':'999'})\
.withColumn('detail_type_temp',expr("""LineItem['pcms:PCMSLineItem']['pcms:DetailNumber'][size(LineItem['pcms:PCMSLineItem']['pcms:DetailNumber'])-1]['_TxnType']"""))

df_lineitem_transform = df_lineitem_transform.join(df_nextgenlkp,trim(df_lineitem_transform.detail_type_temp) == trim(df_nextgenlkp.code),how='left').select(df_lineitem_transform['*'],'ej_code').withColumn('detail_type',col('ej_code')).na.fill({'detail_type':'9'})\
.withColumn('RetailTransaction_pcms:PCMSEvent',col('RetailTransaction.pcms:PCMSEvent'))\
.withColumn('RetailTransaction_XX_n_pcms_PCMSEvent',size(col('RetailTransaction.pcms:PCMSEvent')))\
.withColumn('RetailTransaction_pcms:PCMSRetailTransaction',col('RetailTransaction.pcms:PCMSRetailTransaction'))\
.withColumn('RetailTransaction_Customer',col('RetailTransaction.Customer'))\
.withColumn('RetailTransaction_LoyaltyAccount',col('RetailTransaction.LoyaltyAccount'))\
.withColumn('RetailTransaction_Reason',col('RetailTransaction.Reason'))\
.withColumn('RetailTransaction_TransactionStatus',col('RetailTransaction._TransactionStatus'))\
.withColumn('pcms:PCMSTransaction_pcms:TransactionType',col('pcms:PCMSTransaction.pcms:TransactionType'))\
.withColumn('pcms:PCMSTransaction_wag:DiscountRateWAGBrand',col('pcms:PCMSTransaction.wag:DiscountRateWAGBrand'))\
.withColumn('pcms:PCMSTransaction_wag:DiscountRateNonWAGBrand',col('pcms:PCMSTransaction.wag:DiscountRateNonWAGBrand'))\
.withColumn('Loyalty_reward_temp',expr("""(filter(LineItem.LoyaltyReward,x-> upper(x.PointsAwarded._Type)=='POINTSEARNED'))[size(filter(LineItem.LoyaltyReward,x-> upper(x.PointsAwarded._Type)=='POINTSEARNED'))-1]"""))\
.withColumn('RetailTransaction_LineItem_LoyaltyReward_value',lit(''))\
.withColumn('RetailTransaction_LineItem_LoyaltyReward_LoyaltyID',coalesce(col('Loyalty_reward_temp.LoyaltyID'),lit('')))\
.withColumn('RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_VALUE',coalesce(col('Loyalty_reward_temp.PointsAwarded._VALUE'),lit('')))\
.withColumn('RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_Type',coalesce(col('Loyalty_reward_temp.PointsAwarded._Type'),lit('')))

try:
  df_lineitem_transform = df_lineitem_transform.withColumn('pcms:PCMSTransaction_pcms:SourceSystem',col('pcms:PCMSTransaction.pcms:SourceSystem'))
except:
  df_lineitem_transform = df_lineitem_transform.withColumn('pcms:PCMSTransaction_pcms:SourceSystem',lit(None).cast(StringType()))

df_lineitem_transform=df_lineitem_transform.drop('tmp_transaction_type','RetailTransaction_pcms:PCMSRetailTransaction','RetailTransaction_Customer','RetailTransaction_Reason','RetailTransaction_TransactionStatus','pcms:PCMSTransaction_pcms:TransactionType','int1','temp_detail_type','pcms:PCMSTransaction_wag:DiscountRateWAGBrand','pcms:PCMSTransaction_wag:DiscountRateNonWAGBrand','detail_type_temp','Loyalty_reward_temp')
#df_lineitem_transform.count() 67043142

# COMMAND ----------

#PUSPAK
#Select Sale
dfSale=df_lineitem_transform.filter(col('LineItem.Sale.ExtendedAmount').isNotNull())
#dfSale.count() 15937385

#Select Discount
dfDiscount=df_lineitem_transform.filter((col('LineItem.Sale.ExtendedAmount').isNull()) & (upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe(lit("WORKER"))))
#dfDiscount.count() 0

#Select Return
dfReturn=df_lineitem_transform.filter(col('LineItem.Sale.ExtendedAmount').isNull() & (~(upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe("WORKER")))& col('LineItem.Return.ExtendedAmount').isNotNull())
#dfReturn.count() 73398

#Select Tax
dfTax=df_lineitem_transform.filter(col('LineItem.Sale.ExtendedAmount').isNull() & (~(upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe("WORKER"))) & col('LineItem.Return.ExtendedAmount').isNull() & col('LineItem.Tax').isNotNull())
#dfTax.count() 6903210

#Select Direct Mail Check
dfMailCheck=df_lineitem_transform.filter(col('LineItem.Sale.ExtendedAmount').isNull() & (~(upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe("WORKER"))) & col('LineItem.Return.ExtendedAmount').isNull() & col('LineItem.Tax').isNull() & col('LineItem.pcms:PCMSCouponEndorsement.pcms:SerialNumber').isNotNull())

#Select Tender
dfTender=df_lineitem_transform.filter(col('LineItem.Sale.ExtendedAmount').isNull() & (~(upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe("WORKER"))) & col('LineItem.Return.ExtendedAmount').isNull() & col('LineItem.Tax').isNull() & col('LineItem.pcms:PCMSCouponEndorsement.pcms:SerialNumber').isNull() & col('LineItem.Tender.TenderID').isNotNull())

# COMMAND ----------

#PUSPAK
#### Sale Transforms 1

dfSale_E0027=dfSale.filter(length(trim(col('RetailTransaction_LineItem_LoyaltyReward_LoyaltyID')))>0)\
                   .withColumn('tmp_upc_info',when(upper(col('RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_Type'))=="POINTSEARNED", lpad(substring(col('LineItem.Sale.ItemID'),2,12),12,'')))\
                   .withColumn('tmp_rebate_amt',when(upper(col('RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_Type'))=="POINTSEARNED", col('RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_VALUE')))\
                   .withColumn('rebate_upc_info',concat(coalesce((col('tmp_rebate_amt')/100).cast(DecimalType(10,2)),lit('')),lit(':').cast(StringType()), col('tmp_upc_info')))\
                   .withColumn('account_nbr',col('LineItem.Tender.GiftCard.CardNumber'))\
                   .withColumn('bogo_seq_nbr',lit('0').cast(StringType())).withColumn('rcd_type',lit('E').cast(StringType()))\
                   .withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999')))\
                   .withColumn('EJ',concat(lit('0027'),lit(':'),lit('W CARD-27'),lit(':'),(lpad((coalesce(col('account_nbr'),lit(' '))),19,' ')),lit(':'),(lpad((coalesce(col('rebate_upc_info'),lit(' '))),31,' ')),lpad(lit(' '),14,' ')))
                   
dfSale_E0027=dfSale_E0027.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#display(dfSale_E0027)
#dfSale_E0027.count() 1936

# COMMAND ----------

#PUSPAK
#### Sale Transform 2
dfSale_E0000=dfSale.filter((upper(col('LineItem.wag:RebateReceipt'))=='TRUE') | (upper(col('LineItem.Sale.GiftReceiptFlag'))=='TRUE'))\
                  .withColumn('rebate_data',when(upper(col('LineItem.wag:RebateReceipt'))=='TRUE',lit('REBATE RECEIPT ITEM:').cast(StringType()))\
                              .when(upper(col('LineItem.Sale.GiftReceiptFlag'))=='TRUE',lit('GIFT RECEIPT ITEM:').cast(StringType())))\
                  .withColumn('bogo_seq_nbr',lit('0').cast(StringType())).withColumn('rcd_type',lit('E').cast(StringType()))\
                  .withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999')))\
                  .withColumn('EJ',concat(lit('0000'),lit(':'),(lpad((coalesce(col('rebate_data'),lit(' '))),61,' ')),lpad(lit(' '),14,' ')))
  
dfSale_E0000=dfSale_E0000.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#display(dfSale_E0000)
#dfSale_E0000.count() 866

# COMMAND ----------

#PUSPAK
##### Sale Transform 3
dfSale_AgeRes=dfSale.filter(col('LineItem.wag:CustomerAgeRestriction').isNotNull())\
                    .withColumn('tmp_birthday',when((length(col('LineItem.wag:CustomerAgeRestriction'))==10) & ((size(split(col('LineItem.wag:CustomerAgeRestriction'),'-'))==3) & (((split(col('LineItem.wag:CustomerAgeRestriction'),'-'))[0]).rlike('^[0-9]*$')) & (((split(col('LineItem.wag:CustomerAgeRestriction'),'-'))[1]).between(1,12)) & (((split(col('LineItem.wag:CustomerAgeRestriction'),'-'))[2]).between(1,31))), col('LineItem.wag:CustomerAgeRestriction'))
                               .when((length(col('LineItem.wag:CustomerAgeRestriction'))==8) & ((size(split(col('LineItem.wag:CustomerAgeRestriction'),'-'))==3) & (((split(col('LineItem.wag:CustomerAgeRestriction'),'-'))[0]).rlike('^[0-9]*$')) & (((split(col('LineItem.wag:CustomerAgeRestriction'),'-'))[1]).between(1,12)) & (((split(col('LineItem.wag:CustomerAgeRestriction'),'-'))[2]).between(1,31))), col('LineItem.wag:CustomerAgeRestriction'))\
                                .when((length(col('LineItem.wag:CustomerAgeRestriction'))==8) & ((((col('LineItem.wag:CustomerAgeRestriction')[1:4])).rlike('^[0-9]*$')) & (((col('LineItem.wag:CustomerAgeRestriction'))[5:2]).between(1,12)) & (((col('LineItem.wag:CustomerAgeRestriction'))[7:2]).between(1,31))), col('LineItem.wag:CustomerAgeRestriction'))\
                               .otherwise(lit(None).cast(StringType())))\
                    .withColumn('upc_or_tender',lit('BIRTHDAY').cast(StringType()))\
                    .withColumn('desc_or_acct_nbr',when(col('tmp_birthday').isNotNull(),col('tmp_birthday'))
                               .when(length(col('LineItem.wag:CustomerAgeRestriction'))==6,concat(lit('XX/XX/XXXX ').cast(StringType()),lit(' '),upper(col('LineItem.wag:CustomerAgeRestriction'))))
                               .otherwise(substring(upper(col('LineItem.wag:CustomerAgeRestriction')),1,18)))\
                    .withColumn('keyed_item',lit('K').cast(StringType())).sort(col('str_nbr'),col('txn_date'))\
                    .withColumn('dedup_str_nbr',col('str_nbr').cast(IntegerType()))\
                    .withColumn('dedup_txn_date',col('txn_date').cast(IntegerType()))\
                    .withColumn('dedup_register_nbr',col('register_nbr').cast(IntegerType()))\
                    .withColumn('dedup_txn_nbr',col('txn_nbr').cast(IntegerType()))\
.dropDuplicates(['dedup_str_nbr','dedup_txn_date','record_nbr','dedup_register_nbr','dedup_txn_nbr','desc_or_acct_nbr'])

dfSale_AgeRes = dfSale_AgeRes.drop(*[i for i in dfSale_AgeRes.columns if i.startswith('dedup_')])

dfSale_AgeRes=dfSale_AgeRes.withColumn('quantity',lit(' ')).withColumn('tax_type',lit(' ')).withColumn('selling_price',lit(' '))\
.withColumn('price_verify',lit(' ')).withColumn('item_unit_cost',lit(' ')).withColumn('item_cost',lit(' '))\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('A'))\
.withColumn('price_sign',lit(None)).withColumn('sale_indicator',lit(None)).withColumn('wag_coupon',lit(None))\
.withColumn('discount_mode',lit(None)).withColumn('item_void',lit(None)).withColumn('dept_nbr',lit(None))\
.withColumn('returned_item',lit(None)).withColumn('price_modify',lit(None)).withColumn('training_item',lit(None))\
.withColumn('special',lit(None)).withColumn('unused5',lit(None)).withColumn('unused',lit(None))\
.withColumn('price_modify',lit(None))\
.withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),(lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),(lpad((coalesce(col('item_cost'),lit('0'))),6,' ')),(lpad((coalesce(col('item_unit_cost'),lit('0'))),7,' ')),(lpad((coalesce(col('dept_nbr'),lit('0'))),3,' ')),(lpad((coalesce(col('quantity'),lit('0'))),5,' ')),(lpad((coalesce(col('tax_type'),lit(' '))),1,' ')),(lpad((coalesce(col('selling_price'),lit('.00'))),8,' ')),(lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),(lpad((coalesce(col('sale_indicator'),lit(' '))),1,' ')),(lpad((coalesce(col('wag_coupon'),lit(' '))),1,' ')),(lpad((coalesce(col('discount_mode'),lit(' '))),1,' ')),(lpad((coalesce(col('item_void'),lit(' '))),1,' ')),(lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),(lpad((coalesce(col('returned_item'),lit(' '))),1,' ')),(lpad((coalesce(col('price_modify'),lit(' '))),1,' ')),(lpad((coalesce(col('price_verify'),lit(' '))),1,' ')),(lpad((coalesce(col('training_item'),lit(' '))),1,' ')),(lpad((coalesce(col('special'),lit(' '))),1,' ')),(lpad((coalesce(col('unused5'),lit(' '))),9,' '))))\
.select('record_nbr', 'detail_nbr', 'detail_type', 'sequence_nbr','bogo_seq_nbr','str_nbr', 'txn_date', 'txn_time', 'cashier_nbr', 'register_nbr', 'txn_type', 'txn_nbr', 'rcd_type','EJ') 

#display(dfSale_AgeRes)
#dfSale_AgeRes.count() 494929

# COMMAND ----------

#PUSPAK (INCOMPLETE)
####MERGE SALE AND RTURN
#### dfSale dfDiscount dfReturn(transform 1)
dfSale_Merge=dfSale.drop('RetailTransaction_pcms:PCMSRetailTransaction','RetailTransaction_Customer','RetailTransaction_LoyaltyAccount','RetailTransaction_Reason','RetailTransaction_TransactionStatus','pcms:PCMSTransaction_pcms:TransactionType','int1','temp_detail_type','pcms:PCMSTransaction_wag:DiscountRateWAGBrand','pcms:PCMSTransaction_wag:DiscountRateNonWAGBrand','LoyaltyReward','RetailTransaction_LineItem_LoyaltyReward_value','RetailTransaction_LineItem_LoyaltyReward_LoyaltyID','RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_VALUE','RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_Type','tmp_transaction_type','pcms:PCMSTransaction_pcms:SourceSystem')

dfReturn_Merge=dfReturn.drop('RetailTransaction_pcms:PCMSRetailTransaction','RetailTransaction_Customer','RetailTransaction_LoyaltyAccount','RetailTransaction_Reason','RetailTransaction_TransactionStatus','pcms:PCMSTransaction_pcms:TransactionType','int1','temp_detail_type','pcms:PCMSTransaction_wag:DiscountRateWAGBrand','pcms:PCMSTransaction_wag:DiscountRateNonWAGBrand','LoyaltyReward','RetailTransaction_LineItem_LoyaltyReward_value','RetailTransaction_LineItem_LoyaltyReward_LoyaltyID','RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_VALUE','RetailTransaction_LineItem_LoyaltyReward_PointsAwarded_Type','tmp_transaction_type','pcms:PCMSTransaction_pcms:SourceSystem')

dfReturn_Merge=dfReturn_Merge.withColumnRenamed('LineItem.Return.RetailPriceModifier','LineItem.Sale.RetailPriceModifier')\
.withColumnRenamed('LineItem.Return','LineItem.Sale')\
.withColumnRenamed('LineItem.Return._ItemSubType','LineItem.Sale._ItemSubType')\
.withColumnRenamed('LineItem.Return._ItemType','LineItem.Sale._ItemType')\
.withColumnRenamed('LineItem.Return.ItemID','RetailTransaction.LineItem.Sale.ItemID')\
.withColumnRenamed('LineItem.Return.POSIdentity','LineItem.Sale.POSIdentity')\
.withColumnRenamed('LineItem.Return.Description','LineItem.Sale.Description')\
.withColumnRenamed('LineItem.Return.RegularSalesUnitPrice','LineItem.Sale.RegularSalesUnitPrice')\
.withColumnRenamed('LineItem.Return.ActualSalesUnitPrice','LineItem.Sale.ActualSalesUnitPrice')\
.withColumnRenamed('LineItem.Return.ExtendedAmount','LineItem.Sale.ExtendedAmount')\
.withColumnRenamed('LineItem.Return.Quantity','LineItem.Sale.Quantity')\
.withColumnRenamed('LineItem.Return.SellingLocation','LineItem.Sale.SellingLocation')\
.withColumnRenamed('LineItem.Return.Tax','LineItem.Sale.Tax')\
.withColumnRenamed('LineItem.Return.pcms:PCMSReturn._value','.LineItem.Sale.pcms:PCMSSale._value')\
.withColumnRenamed('LineItem.Return.pcms:PCMSReturn.pcms:PriceDiscountable','LineItem.Sale.pcms:PCMSSale.pcms:PriceDiscountable')

dfMerge=dfSale_Merge.union(dfReturn_Merge)
#dfMerge.count() 16010783

### Linetype 216

df_line216=dfMerge.filter((col('LineItem._LineType')=="216") & (~(upper(col('LineItem._LineItemStatus')).eqNullSafe("CANCELED"))))\
                  .withColumn('temp_posidentity',expr("""filter(LineItem.Sale.POSIdentity,x-> (x._POSIDType)=='OriginalBarcode')"""))\
                  .withColumn('loyalty_acc_full_nbr',expr("""substring(temp_posidentity[size(temp_posidentity)-1]['POSItemID'],1,19)"""))\
                  .withColumn('loyalty_acc_nbr',substring(col('loyalty_acc_full_nbr'),10,9))\
                  .withColumn('device_type',substring(col('LineItem.Sale.pcms:PCMSSale.pcms_ItemStatus'),1,1))\
                  .withColumn('sequence_nbr',col('LineItem.SequenceNumber')).withColumn('bogo_seq_nbr',lit('0'))\
                  .withColumn('rcd_type',lit('E')).withColumn('e_record_type',lit('0061')).withColumn('sep1',lit(':'))\
                  .withColumn('sep2',lit(':')).withColumn('sep3',lit(':')).withColumn('sep4',lit(':')).withColumn('sep5',lit(':'))\
                  .withColumn('unused1',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0061:')\
                        ,lpad(coalesce(col('loyalty_acc_nbr'),lit(' ')),9,' '),lit(':')\
                        ,lpad(coalesce(col('loyalty_acc_full_nbr'),lit(' ')),19,' '),lit(':')\
                        ,lpad(coalesce(col('rfn'),lit(' ')),20,' '),lit(':')\
                        ,lpad(coalesce(col('device_type'),lit('0')),1,'0'),lit(':')\
                        ,lpad(lit(' '),22,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_line216.count() 18

m1 = dfMerge.filter(~((col('LineItem._LineType')=="216") & (~(upper(col('LineItem._LineItemStatus')).eqNullSafe("CANCELED")))))

##### Linetype 217
df_line217=m1.filter(((col('LineItem._LineType')=="217")))

df_line217_1=df_line217.withColumn('temp_posidentity',expr("""filter(LineItem.Sale.POSIdentity,x-> (x._POSIDType)=='OriginalBarcode')"""))\
                  .withColumn('coupon_barcode',expr("""concat(substring(temp_posidentity[size(temp_posidentity)-1]['POSItemID'],1,30),':',LineItem.SequenceNumber,':')"""))\
                  .withColumn('action_type',col('LineItem.Sale.pcms:PCMSSale.pcms:DocumentReference'))\
                  .withColumn('response_code',col('LineItem.Sale.pcms:PCMSSale.pcms:Supplier'))\
                  .withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0'))\
                  .withColumn('rcd_type',lit('E')).withColumn('e_record_type',lit('0071')).withColumn('sep2',lit(':'))\
                  .withColumn('sep1',lit(':')).withColumn('sep3',lit(':'))\
.withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('E')).withColumn('unused1',lit(None))\
.withColumn('unused2',lit(None)).withColumn('unused3',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0171:')\
                        ,lpad(coalesce(col('action_type'),lit(' ')),1,' '),lit(':')\
                        ,lpad(coalesce(col('response_code'),lit(' ')),3,' '),lit(':')\
                        ,lpad(coalesce(col('coupon_barcode'),lit(' ')),55,' '),lit(':')\
                        ,lpad(lit(' '),14,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')


df_line217_2=df_line217.where(col('LineItem.Sale.pcms:PCMSSale.pcms:DocumentReference')=='I')
df_line217_2=  df_line217_2.withColumn('vect_temp',split(col('LineItem.Sale.Description'),'\\|'))\
.withColumn('max_segments',expr("""size(filter(vect_temp,x-> length(trim(x)) > 0))"""))\
.withColumn('vect_temp',expr("""transform(vect_temp,x->substring(x,1,50))"""))\
.select('*',posexplode_outer(col('vect_temp')))\
.withColumnRenamed('pos','vect_index').withColumnRenamed('col','vect_temp')\
.withColumn('action_type',lit('D')).withColumn('segment_nbr',col('vect_index')+1).withColumn('bogo_seq_nbr',col('vect_index')+1)\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('sep1',lit(':')).withColumn('sep4',lit(':'))\
.withColumn('segment_data',concat(coalesce(col('vect_index'),lit('')),lit(':'),coalesce(col('sequence_nbr'),lit('')),lit(':')))\
.where(~(col('segment_data').startswith(':')))\
.withColumn('rcd_type',lit('E')).withColumn('e_record_type',lit('0071')).withColumn('sep2',lit(':')).withColumn('sep5',lit(':'))\
.withColumn('EJ',concat(lit('0071:')\
                        ,lpad(coalesce(col('action_type'),lit(' ')),1,' '),lit(':')\
                        ,lpad(coalesce(col('segment_nbr'),lit(' ')),1,' '),lit(':')\
                        ,lpad(coalesce(col('max_segments'),lit(' ')),1,' '),lit(':')\
                        ,lpad(coalesce(col('segment_data'),lit(' ')),55,'0'),lit(':')\
                        ,lpad(lit(' '),14,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_line217_2.count() # 66332. Difference of 121233 with onprem due to encryption

df_line217 = df_line217_1.union(df_line217_2)
#df_line217.count() #181074. diefference of 121233 due to df_line217_2

m2 = m1.filter(~((col('LineItem._LineType')=="217")))
##### Linetype 219
df_line219=m2.filter((col('LineItem._LineType')=="219"))\
.withColumn('aarp_card_nbr',substring(col('LineItem.Sale.SerialNumber'),1,16))\
.withColumn('input_type',when((upper(col('LineItem._EntryMethod'))=='SCANNED'),"C")
           .when((upper(col('LineItem._EntryMethod'))=='SWIPED'),"S")
           .when((upper(col('LineItem._EntryMethod'))=='KEYED'),"K"))\
.withColumn('sequence_nbr',(coalesce(col('LineItem.SequenceNumber'),lit('9999'))).cast(IntegerType()))\
.withColumn('dedup_str_nbr',col('str_nbr').cast(IntegerType()))\
.withColumn('dedup_txn_date',col('txn_date').cast(IntegerType()))\
.withColumn('dedup_register_nbr',col('register_nbr').cast(IntegerType()))\
.withColumn('dedup_txn_nbr',col('txn_nbr').cast(IntegerType()))

from pyspark.sql.window import Window
wspec = Window.partitionBy('dedup_str_nbr','dedup_txn_date','record_nbr','dedup_register_nbr','dedup_txn_nbr').orderBy(col('sequence_nbr').desc())
df_line219=df_line219.withColumn('dedup_row_nbr',row_number().over(wspec)).where(col('dedup_row_nbr')==1)
df_line219 = df_line219.drop(*[i for i in df_line219.columns if i.startswith('dedup_')])

df_line219 = df_line219\
.withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('E')).withColumn('e_record_type',lit('0064'))\
.withColumn('sep2',lit(':')).withColumn('sep1',lit(':')).withColumn('sep3',lit(':')).withColumn('unused',lit(None))\
.withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0064:')\
                        ,lpad(coalesce(col('aarp_card_nbr'),lit(' ')),16,' '),lit(':')\
                        ,lpad(coalesce(col('input_type'),lit(' ')),1,' '),lit(':')\
                        ,lpad(lit(' '),56,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_line219.count() 83912

m3 = m2.filter(~(col('LineItem._LineType')=="219"))
### Linetype 220
df_line220=m3.filter((col('LineItem._LineType')=="220"))\
.withColumn('description',when(col('LineItem.Sale.Description').isNotNull(),col('LineItem.Sale.Description'))
            .otherwise(lit('EMPLOYEE ID')))\
.withColumn('employee_id',col('LineItem.Sale.SerialNumber'))\
.withColumn('desc_employee_id',concat(col('description'),lit(':'),col('employee_id'),lit(':')))\
.withColumn('sequence_nbr',(coalesce(col('LineItem.SequenceNumber'),lit('9999'))).cast(IntegerType()))\
.withColumn('dedup_str_nbr',col('str_nbr').cast(IntegerType()))\
.withColumn('dedup_txn_date',col('txn_date').cast(IntegerType()))\
.withColumn('dedup_register_nbr',col('register_nbr').cast(IntegerType()))\
.withColumn('dedup_txn_nbr',col('txn_nbr').cast(IntegerType()))

df_line220=df_line220.withColumn('dedup_row_nbr',row_number().over(wspec)).where(col('dedup_row_nbr')==1)
df_line220 = df_line220.drop(*[i for i in df_line220.columns if i.startswith('dedup_')])

df_line220= df_line220\
.withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('E')).withColumn('e_record_type',lit('0020'))\
.withColumn('sep',lit(':')).withColumn('unused1',lit(None))\
.withColumn('unused5',lit(None)).withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999')))\
.withColumn('EJ',concat(lit('0220:')\
                        ,lpad(coalesce(col('desc_employee_id'),lit(' ')),60,' ')
                        ,lpad(lit(' '),15,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_line220.count() 0


## Process Discount
df_linetype=m3.filter(~(col('LineItem._LineType')=="220")).withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))
#df_linetype.count() 15812111

df_line_discount= df_linetype.withColumn('LineItem_pcms:PCMSLineItem_pcms:DetailNumber',explode(col('LineItem.pcms:PCMSLineItem.pcms:DetailNumber')))\
           .withColumn('LineItem_SequenceNumber',col('LineItem_pcms:PCMSLineItem_pcms:DetailNumber._VALUE'))\
           .withColumn('LineItem_pcms_PCMSLineItem_value',col('LineItem_pcms:PCMSLineItem_pcms:DetailNumber._TxnType'))\
           .filter(upper(col('LineItem_pcms_PCMSLineItem_value'))=='TXNDETAIL')                                 
#df_linetype.count() 15812111

dfDiscount_voided=dfDiscount.filter((~(upper(col('LineItem._CancelFlag')).eqNullSafe("TRUE"))))\
.withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))
for i in dfDiscount_voided.columns:
  dfDiscount_voided=dfDiscount_voided.withColumnRenamed(i,'dfDiscount_voided_'+i)

dfDiscount_nonvoided=dfDiscount.filter(((upper(col('LineItem._CancelFlag')).eqNullSafe("TRUE"))))\
.withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))

for i in dfDiscount_nonvoided.columns:
  dfDiscount_nonvoided=dfDiscount_nonvoided.withColumnRenamed(i,'dfDiscount_nonvoided_'+i)

dfDiscount_voidjoin=dfDiscount_voided.join(dfDiscount_nonvoided,(((dfDiscount_nonvoided.dfDiscount_nonvoided_str_nbr)==(dfDiscount_voided.dfDiscount_voided_str_nbr)) & ((dfDiscount_nonvoided.dfDiscount_nonvoided_txn_date)==(dfDiscount_voided.dfDiscount_voided_txn_date)) & ((dfDiscount_nonvoided.dfDiscount_nonvoided_register_nbr)==(dfDiscount_voided.dfDiscount_voided_register_nbr)) & ((dfDiscount_nonvoided.dfDiscount_nonvoided_txn_nbr)==(dfDiscount_voided.dfDiscount_voided_txn_nbr)) & ((dfDiscount_nonvoided.dfDiscount_nonvoided_LineItem_SequenceNumber) == (dfDiscount_voided.dfDiscount_voided_LineItem_SequenceNumber))),'leftouter')\
.select(dfDiscount_voided['*'],'dfDiscount_nonvoided_str_nbr','dfDiscount_nonvoided_txn_date','dfDiscount_nonvoided_register_nbr','dfDiscount_nonvoided_txn_nbr','dfDiscount_nonvoided_LineItem_SequenceNumber')\
.withColumn('LineItem.pcms:LineItemStatus',when(col('dfDiscount_nonvoided_str_nbr').isNull() | col('dfDiscount_nonvoided_txn_date').isNull() |col('dfDiscount_nonvoided_register_nbr').isNull() | col('dfDiscount_nonvoided_txn_nbr').isNull() | col('dfDiscount_nonvoided_LineItem_SequenceNumber').isNull(),lit('Cancelled')))\
.drop('dfDiscount_nonvoided_str_nbr','dfDiscount_nonvoided_txn_date','dfDiscount_nonvoided_register_nbr','dfDiscount_nonvoided_txn_nbr','dfDiscount_nonvoided_LineItem_SequenceNumber')

# COMMAND ----------

#PUSPAK
dfStarCoupon_join=df_line_discount.join(dfDiscount_voidjoin,((df_line_discount.str_nbr)==(dfDiscount_voidjoin.dfDiscount_voided_str_nbr)) & ((df_line_discount.txn_date)==(dfDiscount_voidjoin.dfDiscount_voided_txn_date)) & ((df_line_discount.register_nbr)==(dfDiscount_voidjoin.dfDiscount_voided_register_nbr)) & ((df_line_discount.txn_nbr)==(dfDiscount_voidjoin.dfDiscount_voided_txn_nbr)) & ((df_line_discount.LineItem_SequenceNumber) == (dfDiscount_voidjoin.dfDiscount_voided_LineItem_SequenceNumber)),'inner')\
.withColumnRenamed('dfDiscount_voided_LineItem.SequenceNumber','LineItem.SequenceNumber')\
.withColumnRenamed('dfDiscount_voided_LineItem.pcms:LineType','LineItem.pcms:LineType')\
.withColumnRenamed('dfDiscount_voided_LineItem.pcms:LineItemStatus','LineItem.pcms:LineItemStatus')\
.withColumnRenamed('dfDiscount_voided_LineItem._CancelFlag','LineItem._CancelFlag')\
.withColumnRenamed('dfDiscount_voided_LineItem.Discount.PriceDerivationRule.PriceDerivationRuleID','LineItem.Sale.ItemID')\
.withColumnRenamed('dfDiscount_voided_LineItem.Discount','LineItem.Discount')\
.withColumnRenamed('dfDiscount_voided_LineItem.Discount.DiscountBenefit','LineItem.Discount.DiscountBenefit')\
.withColumnRenamed('dfDiscount_voided_LineItem.Discount.PriceDerivationRule.PriceDerivationRuleID','LineItem.Discount.PriceDerivationRule')\
.withColumnRenamed('dfDiscount_voided_LineItem.Discount.pcms:PCMSDiscount','LineItem.Discount.pcms:PCMSDiscount')\
.withColumnRenamed('dfDiscount_voided_LineItem.Discount.pcms:PCMSDiscount.pcms:TriggerDetailNumber','LineItem.Discount.pcms:PCMSDiscount.pcms:TriggerDetailNumber')\
.select(df_line_discount['*'])\
.drop( 'LineItem_pcms_PCMSLineItem_value',  'LineItem_pcms:PCMSLineItem_pcms:DetailNumber')

dfStarCouponvoid_join=dfStarCoupon_join.join(dfDiscount_nonvoided,((dfStarCoupon_join.str_nbr)==(dfDiscount_nonvoided.dfDiscount_nonvoided_str_nbr)) & ((dfStarCoupon_join.txn_date)==(dfDiscount_nonvoided.dfDiscount_nonvoided_txn_date)) & ((dfStarCoupon_join.register_nbr)==(dfDiscount_nonvoided.dfDiscount_nonvoided_register_nbr)) & ((dfStarCoupon_join.txn_nbr)==(dfDiscount_nonvoided.dfDiscount_nonvoided_txn_nbr)) & ((dfStarCoupon_join.LineItem_SequenceNumber) == (dfDiscount_nonvoided.dfDiscount_nonvoided_LineItem_SequenceNumber)),'inner')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.SequenceNumber','LineItem.SequenceNumber')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.pcms:LineType','LineItem.pcms:LineType')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.pcms:LineItemStatus','LineItem.pcms:LineItemStatus')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem._CancelFlag','LineItem._CancelFlag')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.Discount.PriceDerivationRule.PriceDerivationRuleID','LineItem.Sale.ItemID')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.Discount','LineItem.Discount')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.Discount.DiscountBenefit','LineItem.Discount.DiscountBenefit')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.Discount.PriceDerivationRule.PriceDerivationRuleID','LineItem.Discount.PriceDerivationRule')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.Discount.pcms:PCMSDiscount','LineItem.Discount.pcms:PCMSDiscount')\
.withColumnRenamed('dfDiscount_nonvoided_LineItem.Discount.pcms:PCMSDiscount.pcms:TriggerDetailNumber','LineItem.Discount.pcms:PCMSDiscount.pcms:TriggerDetailNumber')\
.select(dfStarCoupon_join['*'])

df_process_discount=df_linetype.union(dfStarCoupon_join).union(dfStarCouponvoid_join)
#df_process_discount.count()

# COMMAND ----------

#PUSPAK
#### line type 221

df_line221=df_process_discount.filter(col('LineItem._LineType')=="221")\
.withColumn('serial_number',when(length(col('LineItem.Sale.SerialNumber'))>19,substring(col('LineItem.Sale.SerialNumber'),1,19))
                                .otherwise(col('LineItem.Sale.SerialNumber')))\
.withColumn('LoyaltyReward',explode_outer(col('LineItem.LoyaltyReward')))\
.withColumn('loyalty_acc_full_nbr',substring(col('LineItem.Sale.SerialNumber'),1,19))\
.withColumn('loyalty_acc_nbr',expr("""substring(serial_number,length(serial_number)-8,9)"""))\
.withColumn('device_type',substring(col('LineItem.Sale.pcms:PCMSSale.pcms_ItemStatus'),1,1))\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999')))\
.withColumn('points_earned',lpad(substring(col('LoyaltyReward.PointsAwarded._VALUE'),1,8),8,' '))\
.withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('E')).withColumn('unused1',lit(None))\
.withColumn('unused2',lit(None)).withColumn('unused3',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0161:')\
                        ,lpad(coalesce(col('loyalty_acc_nbr'),lit(' ')),9,' '),lit(':')\
                        ,lpad(coalesce(col('loyalty_acc_full_nbr'),lit(' ')),19,' '),lit(':')\
                        ,lpad(coalesce(col('rfn'),lit(' ')),20,' '),lit(':')\
                        ,lpad(coalesce(col('device_type'),lit('0')),1,'0'),lit(':')\
                        ,lpad(coalesce(col('points_earned'),lit(' ')),8,' ')\
                        ,lpad(lit(' '),14,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#df_line221.count() #0

# COMMAND ----------

#PUSPAK
######## StarCouponLine not void
df_E0075=df_process_discount.filter((col('LineItem.Discount').isNotNull()) &(upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe("WORKER")) & (col('LineItem.Discount.pcms:PCMSDiscount.pcms:TriggerDetailNumber').isNotNull()))

df_E0075=df_E0075.filter((~(upper(col('LineItem._LineItemStatus')).eqNullSafe("CANCELED"))) & (~(upper(col('LineItem._CancelFlag')).eqNullSafe("TRUE"))))\
.withColumn('temp_coupon_plu',col('LineItem.Discount.PriceDerivationRule.PriceDerivationRuleID'))\
.withColumn('coupon_giftcard_amount',when((col('LineItem.Sale.ActualSalesUnitPrice').isNotNull()) & (upper( col('LineItem._CancelFlag')).eqNullSafe('TRUE')),lpad(col('LineItem.Sale.ActualSalesUnitPrice') * 100,6,' ')))\
.withColumn('giftcard_account_nbr',col('LineItem.wag:AccountNumber'))\
.withColumn('coupon_plu_len',length(col('temp_coupon_plu')))\
.withColumn('coupon_plu',expr("substring(temp_coupon_plu,coupon_plu_len-4,4)"))\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E')).withColumn('unused',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0075:')\
                        ,lpad(coalesce(col('rfn'),lit(' ')),20,' '),lit(':')\
                        ,lpad(coalesce(col('coupon_plu'),lit(' ')),4,' '),lit(':')\
                        ,lpad(coalesce(col('coupon_giftcard_amount'),lit(' ')),6,' '),lit(':')\
                        ,lpad(coalesce(col('giftcard_account_nbr'),lit(' ')),19,' '),lit(':')\
                        ,lpad(lit(' '),22,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#df_E0075.count() #0

# COMMAND ----------

#PUSPAK
#Process Void Line

df_Process_Void_1=df_process_discount.filter(~ (upper(col('LineItem._CancelFlag')).eqNullSafe('TRUE')))\
.withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))

df_Process_Void_2=df_process_discount.filter(upper(col('LineItem._CancelFlag')).eqNullSafe('TRUE'))\
.withColumn('LineItem_ItemLink',col('LineItem.pcms:PCMSLineItem.pcms:ItemLink'))


df_Process_Void=df_Process_Void_1.join(df_Process_Void_2,((df_Process_Void_1.str_nbr)==(df_Process_Void_2.str_nbr)) & ((df_Process_Void_1.txn_date)==(df_Process_Void_2.txn_date)) & ((df_Process_Void_1.record_nbr)==(df_Process_Void_2.record_nbr)) & ((df_Process_Void_1.register_nbr)==(df_Process_Void_2.register_nbr)) & ((df_Process_Void_1.txn_nbr)==(df_Process_Void_2.txn_nbr)) & ((df_Process_Void_1.LineItem_SequenceNumber) == (df_Process_Void_2.LineItem_ItemLink)),'left_anti')

#display(df_Process_Void_1)
#df_Process_Void.count() 15341623

# COMMAND ----------

##Siri
##Bogolep Process
df_bogo_retrieve=df_Process_Void.withColumn('bogolep_info_tmp',expr("""(filter(LineItem.Sale.RetailPriceModifier,x-> (upper(x.Amount._Action)=='SUBTRACT') and ((upper(x.ReasonCode)=='8:BOGOLEP') or (upper(x.ReasonCode)=='8:BUYXGET1') or (upper(x.ReasonCode)=='8:BAGB'))))[size(filter(LineItem.Sale.RetailPriceModifier,x-> (upper(x.Amount._Action)=='SUBTRACT') and ((upper(x.ReasonCode)=='8:BOGOLEP') or (upper(x.ReasonCode)=='8:BUYXGET1') or (upper(x.ReasonCode)=='8:BAGB'))))-1]"""))\
.withColumn('bogolep_get_info',when((col('bogolep_info_tmp').isNotNull()),lit('FOUND:SUBT')))\
.withColumn('bogolep_info_tmp2',expr("""(filter(LineItem.Sale.RetailPriceModifier,x-> ((upper(x.Amount._Action)!='SUBTRACT') or (x.Amount._Action IS NULL)) and ((upper(x.ReasonCode)=='8:BOGOLEP') or (upper(x.ReasonCode)=='8:BUYXGET1') or (upper(x.ReasonCode)=='8:BAGB'))))[size(filter(LineItem.Sale.RetailPriceModifier,x-> ((upper(x.Amount._Action)!='SUBTRACT') or (x.Amount._Action IS NULL)) and ((upper(x.ReasonCode)=='8:BOGOLEP') or (upper(x.ReasonCode)=='8:BUYXGET1') or (upper(x.ReasonCode)=='8:BAGB'))))-1]"""))\
.withColumn('bogolep_buy_info',when(((col('bogolep_info_tmp2').isNotNull())),lit('FOUND')))\
.withColumn('RetailTransaction_value',when((col('bogolep_get_info').isNotNull()) & (col('bogolep_buy_info').isNotNull()),lit('FOUND:BOTH'))\
            .when(col('bogolep_get_info').isNotNull(),col('bogolep_get_info'))\
           .when(col('bogolep_buy_info').isNotNull(),col('bogolep_buy_info')))
#df_bogo_retrieve.count() 15341623

df_bogo_retrieve=df_bogo_retrieve.filter((col('RetailTransaction_value')=='FOUND:SUBT') | (col('RetailTransaction_value')=='FOUND') | (col('RetailTransaction_value')=='FOUND:BOTH'))
#df_bogo_retrieve.count() 823624

#normalise
df_bogo_norm=df_bogo_retrieve.withColumn('RetailPriceModifier',explode(col('LineItem.Sale.RetailPriceModifier')))\
.withColumn('bogo_discount_text',col('RetailPriceModifier.pcms:PCMSRetailPriceModifier.pcms:DiscountText'))\
.withColumn('vect_temp',split(col('bogo_discount_text'),':'))\
.withColumn('n',size(col('vect_temp')))\
.withColumn('LineItem_value',lpad(expr("""substring(vect_temp[0],-4,4)"""),4,'0'))\
.withColumn('bogo_group_index',when(col('n')<=4,lit(0)).otherwise((expr("""substring(ltrim(vect_temp[3]),1,2)""")).cast(IntegerType())))\
.filter((col('RetailPriceModifier.ReasonCode')=='8:BOGOLEP') | (col('RetailPriceModifier.ReasonCode')=='8:BAGB') | (col('RetailPriceModifier.ReasonCode')=='8:BUYXGET1') )\
.withColumn('bogo_seq_nbr',lit(0))\
.na.fill({'bogo_group_index':0})
#df_bogo_norm.count() 841047

##sort & aggregate
wspec1 = Window.partitionBy('str_nbr','txn_date','record_nbr','bogo_seq_nbr','LineItem_SequenceNumber','RetailTransaction_value','LineItem_value')

wspec2 = Window.partitionBy('str_nbr','txn_date','record_nbr','bogo_seq_nbr','LineItem_SequenceNumber','RetailTransaction_value','LineItem_value').orderBy(col('str_nbr'))

df_bogo_agg=df_bogo_norm.withColumn('temp_BoGoAmount',when((col('RetailTransaction_value')=='FOUND:SUBT') |((col('RetailTransaction_value')=='FOUND:BOTH') & (upper(col('RetailPriceModifier.Amount._Action'))=='SUBTRACT')),lit(1)).otherwise(lit(0)))\
.withColumn('GetQuantity',(sum(col('temp_BoGoAmount'))).over(wspec1))\
.withColumn('BoGoAmount',(sum(col('RetailPriceModifier.Amount._VALUE'))).over(wspec1))\
.withColumn('row_num',row_number().over(wspec2))\
.where(col('row_num')==1)\
.drop('row_num')
#df_bogo_agg.count() 824526

##split 1 -Agrregate 
wspec3 = Window.partitionBy('str_nbr','txn_date','record_nbr','bogo_seq_nbr','LineItem_SequenceNumber')
wspec4 = Window.partitionBy('str_nbr','txn_date','record_nbr','bogo_seq_nbr','LineItem_SequenceNumber').orderBy('str_nbr')

df_agg=df_bogo_agg.withColumn('BuyPrice',sum(col('BoGoAmount')).over(wspec3))\
.withColumn('BoGoAmount',sum(col('BoGoAmount')).over(wspec3))\
.withColumn('BuyQuantity',col('LineItem.Sale.Quantity'))\
.withColumn('row_num',row_number().over(wspec4))\
.withColumn('RetailTransaction_LineItem_Sale_ExtendedAmount_value',col('BuyPrice'))\
.withColumn('bogo_seq_nbr',lit('0'))\
.where(col('row_num')==1)\
.drop('row_num')\
.drop('Buy_Price','BuyQuantity')
#df_agg.count() 823624

##split 2 --select Go
df_go=df_bogo_agg.filter(col('GetQuantity')>0)
#df_go.count() 425268

df_go_1=df_go.withColumn('bogo_seq_nbr',lit(2)).withColumn('RetilTransaction_LineItem_Sale_ExtendedAmount',col('BoGoAmount'))\
.withColumn('RetailTransaction_LineItem_Sale_Quantity',col('GetQuantity'))

##Merge 
df_bogo_merge=df_agg.union(df_go_1)
#df_bogo_merge.count() #1248892

#go sort aggreegate
wspec4 = Window.partitionBy('str_nbr','txn_date','record_nbr','LineItem_value','bogo_group_index','bogo_seq_nbr')
wspec5 = Window.partitionBy('str_nbr','txn_date','record_nbr','LineItem_value','bogo_group_index','bogo_seq_nbr').orderBy('str_nbr')

df_go_sort=df_go.withColumn('BuyPrice',sum(col('LineItem.Sale.ExtendedAmount')).over(wspec4))\
.withColumn('BoGoAmount',sum(col('BoGoAmount')).over(wspec4))\
.withColumn('GetQuantity',sum(col('GetQuantity')).over(wspec4))\
.withColumn('row_num',row_number().over(wspec5))\
.where(col('row_num')==1)\
.drop('row_num')

## Select Bo,sort & aggregate
wspec4 = Window.partitionBy('str_nbr','txn_date','record_nbr','LineItem_value','bogo_group_index','bogo_seq_nbr')
wspec5 = Window.partitionBy('str_nbr','txn_date','record_nbr','LineItem_value','bogo_group_index','bogo_seq_nbr').orderBy('str_nbr')
df_bo=df_bogo_agg.filter((col('RetailTransaction_value')=='FOUND') | (col('RetailTransaction_value')=='FOUND:BOTH'))
#df_bo.count() 409478
df_bo= df_bo.withColumn('BuyPrice',sum(col('LineItem.Sale.ExtendedAmount')).over(wspec4))\
.withColumn('BoGoAmount',sum(col('BoGoAmount')).over(wspec4))\
.withColumn('row_num',row_number().over(wspec5))\
.where(col('row_num')==1)\
.drop('row_num')

for i in df_go_sort.columns:
  df_go_sort=df_go_sort.withColumnRenamed(i,'df_go_sort_'+i)
  
for i in df_bo.columns:
  df_bo=df_bo.withColumnRenamed(i,'df_bo_'+i)

## Join 
df_bogo_join=df_go_sort.join(df_bo,((df_go_sort.df_go_sort_str_nbr==df_bo.df_bo_str_nbr) & (df_go_sort.df_go_sort_txn_date==df_bo.df_bo_txn_date) & (df_go_sort.df_go_sort_record_nbr==df_bo.df_bo_record_nbr) & (df_go_sort.df_go_sort_LineItem_value==df_bo.df_bo_LineItem_value) & (df_go_sort.df_go_sort_bogo_group_index==df_bo.df_bo_bogo_group_index)),'inner')\
.withColumnRenamed('df_go_sort_LineItem_value','coupon_number')\
.withColumn('upc_bo',when((col('df_bo_RetailTransaction_value')=='FOUND') | (col('df_bo_RetailTransaction_value')=='FOUND:BOTH'),lpad(substring(col('df_bo_LineItem.Sale.ItemID'),2,12),12,' ')))\
.withColumn('upc_go',when((col('df_go_sort_RetailTransaction_value')=='FOUND') | (col('df_go_sort_RetailTransaction_value')=='FOUND:BOTH'),lpad(substring(col('df_go_sort_LineItem.Sale.ItemID'),2,12),12,' ')))\
.withColumn('price_bo',col('df_bo_BuyPrice')*100)\
.withColumn('price_go',col('df_go_sort_BoGoAmount')*100)\
.withColumn('sequence_nbr',col('df_bo_LineItem_SequenceNumber')).withColumn('bogo_seq_nbr',lit(0))\
.withColumn('bogo_group_index',col('df_bo_bogo_group_index')).withColumn('rcd_type',lit('E'))\
.withColumn('EJ',concat(lit('0022:')\
                        ,lpad(coalesce(col('coupon_number'),lit(' ')),4,' '),lit(':')\
                        ,lpad(coalesce(col('upc_bo'),lit(' ')),12,' '),lit(':')\
                        ,lpad(coalesce(col('price_bo'),lit(' ')),9,' '),lit(':')\
                        ,lpad(coalesce(col('upc_go'),lit(' ')),12,' '),lit(':')\
                        ,lpad(coalesce(col('price_go'),lit(' ')),9,' '),lit(':00000000:')\
                        ,lpad(lit(' '),15,' ')))\
.select(col('df_go_sort_record_nbr').alias('record_nbr'),col('df_go_sort_detail_nbr').alias('detail_nbr'),\
        col('df_go_sort_detail_type').alias('detail_type'),'sequence_nbr','bogo_seq_nbr',\
        col('df_go_sort_str_nbr').alias('str_nbr'),col('df_go_sort_txn_date').alias('txn_date'),\
        col('df_go_sort_txn_time').alias('txn_time'),col('df_go_sort_cashier_nbr').alias('cashier_nbr'),\
        col('df_go_sort_register_nbr').alias('register_nbr'),col('df_go_sort_txn_type').alias('txn_type'),\
        col('df_go_sort_txn_nbr').alias('txn_nbr'),'rcd_type','EJ')

#df_bogo_join.count() 407814

# COMMAND ----------

#Siri

# Sort & Join # Replace Buy Item

df_process_discount=df_process_discount.sort(['record_nbr','str_nbr','txn_date','register_nbr','txn_nbr','LineItem_SequenceNumber'])

df_bogo_merge=df_bogo_merge.sort(['record_nbr','str_nbr','txn_date','register_nbr','txn_nbr','LineItem_SequenceNumber'])

df_sort_join=df_process_discount.join(df_bogo_merge,((df_process_discount.record_nbr==df_bogo_merge.record_nbr) & (df_process_discount.str_nbr==df_bogo_merge.str_nbr) & (df_process_discount.txn_date==df_bogo_merge.txn_date) & (df_process_discount.register_nbr==df_bogo_merge.register_nbr) & (df_process_discount.txn_nbr==df_bogo_merge.txn_nbr) &
(df_process_discount.LineItem_SequenceNumber==df_bogo_merge.LineItem_SequenceNumber)),'leftOuter')\
.select(df_process_discount['*'])\
.sort(['str_nbr','txn_date','record_nbr'])

#df_sort_join.count() 16237379

# COMMAND ----------

#Sakina
# Process Item

df_Process_Item=df_sort_join.withColumn('temp_sequence_nbr1',expr("""(filter(LineItem['pcms:PCMSLineItem']['pcms:DetailNumber'],x->x._TxnType=='TxnDetail'))[size(filter(LineItem['pcms:PCMSLineItem']['pcms:DetailNumber'],x->x._TxnType=='TxnDetail'))-1]"""))\
.withColumn('temp_sequence_nbr',col('temp_sequence_nbr1._VALUE'))\
.withColumn('tmp_department',when(substring(col('LineItem.Sale.SellingLocation'),2,4)>=0,lit('006'))\
           .when(substring(col('LineItem.Sale.SellingLocation'),1,1)=='D',expr("""substring(LineItem.Sale.SellingLocation,2,locate('-',LineItem.Sale.SellingLocation)-2)""")))\
.withColumn('tmp_upc1',expr("""(filter(LineItem['Sale']['POSIdentity'],x->x._POSIDType=='PLU'))[size(filter(LineItem['Sale']['POSIdentity'],x->x._POSIDType=='PLU'))-1]"""))\
.withColumn('tmp_upc',col('tmp_upc1.POSItemID'))\

df_lkp_department = df_nextgenlkp.where(col('code_name')=='Department')

df_Process_Item = df_Process_Item.drop('ej_code').join(df_lkp_department,df_Process_Item.tmp_department == df_lkp_department.code,how='left').select(df_Process_Item['*'],df_nextgenlkp['code'],df_nextgenlkp['code_desc'])

df_Process_Item = df_Process_Item.withColumn('tmp_desc',when((col('tmp_upc').isNull()) & (col('LineItem._LineType')==2) & (col('code').isNotNull()) & (length(trim(col('tmp_department')))>=3),col('code_desc')))\
.withColumn('tmp_upc',when((col('tmp_upc').isNull()) & (col('LineItem._LineType')==2) & (col('code').isNotNull()) & (length(trim(col('tmp_department')))>=3),concat(lit('0200000000'),col('tmp_department'),lit('0')))\
                                            .when((col('tmp_upc').isNull()) & (col('LineItem._LineType')==2) & (col('code').isNotNull()) & (length(trim(col('tmp_department')))<3),concat(lit('0200000000'),lpad(col('tmp_department'),3,'0'),lit('0'))))\
.withColumn('photo_temp', F.split(col('LineItem.wag:PhotoOrderDetails'), ':'))\
.withColumn('bogo_seq_nbr',lit(2))\
.withColumn('wagcoupon_find',lit('N'))\
.withColumn('tmp_changing_date',lit('20091007'))\
.withColumn('line_nbr',when(trim(col('LineItem.pcms:PCMSLineItem.pcms:ItemLink')) != '',col('LineItem.pcms:PCMSLineItem.pcms:ItemLink')).otherwise(col('LineItem.SequenceNumber')))\
.withColumn('tmp_photo_count_total', when(((col('LineItem.Sale.ItemID') == '00492299999989') | (col('LineItem.Sale.ItemID') == '00492299999972') | (col('LineItem.Sale.ItemID') == '00492299999965')) & (trim(col('LineItem.wag:PhotoOrderDetails')) != ''), aggregate("photo_temp", lit(0.0), lambda acc, x: acc + x)))\
.withColumn('photo_count_total', when(col('tmp_photo_count_total').cast(IntegerType()) > 9999, lit(9999))\
                                .when(col('tmp_photo_count_total').cast(IntegerType()) < 0, lit(0))\
                                .otherwise(col('tmp_photo_count_total')))\
.withColumn('tmp_barcode',expr("""(filter(LineItem.Sale.POSIdentity,x-> upper(x._POSIDType) == 'ORIGINALBARCODE'))[size(filter(LineItem.Sale.POSIdentity,x-> upper(x._POSIDType) == 'ORIGINALBARCODE'))-1]"""))\
.withColumn('barcode', substring(col('tmp_barcode.POSItemID'),1,50))\
.withColumn('tmp_bogolep_wagcoup', expr("""(filter(LineItem.Sale.RetailPriceModifier,x-> x.ReasonCode == '8:WAG COUPON' and trim(x.PromotionID) != ''))[size(filter(LineItem.Sale.RetailPriceModifier,x-> x.ReasonCode == '8:WAG COUPON' and trim(x.PromotionID) != ''))-1]"""))\
.withColumn('bogolep_wagcoup', when(col('bogo_seq_nbr') == 2 , lit('B'))\
                              .when((col('tmp_bogolep_wagcoup').isNotNull()) & (col('LineItem._LineType') == "209") & (col('LineItem._EntryMethod') == "Digital"), lit('D'))\
                              .when((col('tmp_bogolep_wagcoup').isNotNull()) & (col('LineItem._LineType') == "209"), lit('C')))\
.withColumn('tmp_discount_find', expr("""(filter(LineItem.Sale.RetailPriceModifier,x-> substring(x.ReasonCode,1, 2) == '1:'))[size(filter(LineItem.Sale.RetailPriceModifier,x-> substring(x.ReasonCode,1, 2) == '1:'))-1]"""))\
.withColumn('discount_find', when(col('tmp_discount_find').isNotNull(), col('tmp_discount_find.ReasonCode')))\
.withColumn('tmp_modify_find', expr("""(filter(LineItem.Sale.RetailPriceModifier,x-> substring(x.ReasonCode,1, 2) == '3:'))[size(filter(LineItem.Sale.RetailPriceModifier,x-> substring(x.ReasonCode,1, 2) == '3:'))-1]"""))\
.withColumn('modify_find', when(col('tmp_modify_find').isNotNull(), col('tmp_modify_find.ReasonCode')))\
.withColumn('tmp_wagcoupon_find', expr("""(filter(LineItem.Sale.RetailPriceModifier,x-> trim(x.PromotionID) != '' and x.ReasonCode == '8:WAG COUPON'))[size(filter(LineItem.Sale.RetailPriceModifier,x-> trim(x.PromotionID) != '' and x.ReasonCode == '8:WAG COUPON'))-1]"""))\
.withColumn('wagcoupon_find', when(col('tmp_wagcoupon_find').isNotNull(), lit('Y')))\
.withColumn('temp_wagcoupon_amount', when((col('bogolep_wagcoup') != 'C') & (col('bogolep_wagcoup') != 'D') & (col('LineItem.Sale.RetailPriceModifier.Amount._VALUE').isNotNull()), aggregate("LineItem.Sale.RetailPriceModifier.Amount._VALUE", lit(0.0), lambda acc, x: coalesce(acc,lit(0.0)) + coalesce(x,lit(0.0)))))\
.withColumn('temp_selling_price', when((col('wagcoupon_find') == "Y") & (col('bogolep_wagcoup') != 'B'), when((col('bogolep_wagcoup') == 'C') | (col('bogolep_wagcoup') == 'D'), col('LineItem.Sale.ActualSalesUnitPrice')).otherwise(col('LineItem.Sale.ExtendedAmount') + col('temp_wagcoupon_amount'))))\
.withColumn('upc_or_tender', when(col('LineItem._LineType')=="221", upper(substring(col('LineItem.Sale.Description'),1,12)))\
                             .otherwise(lpad(substring(col('tmp_upc'), 2, 12), 12,'0')))\
.withColumn('desc_or_acct_nbr', when(col('LineItem._LineType')=="221" , substring(col('LineItem.Sale.SerialNumber'),1,18))\
                                .when((col('LineItem.Sale.ItemID') == '00492299999989') | (col('LineItem.Sale.ItemID') == '00492299999972') | (col('LineItem.Sale.ItemID') == '00492299999965'), concat(lit('PHOTO '), substring(col('barcode'), 6, 8),lpad(lpad(col('photo_count_total'),3,'0'),4,'0')))\
                               .when((col('LineItem.Sale.ItemID') == '00499999999998') | (col('LineItem.Sale.ItemID') == '00499999999981') | (col('LineItem.Sale.ItemID') == '00420000009573') | (col('LineItem.Sale.ItemID') == '00420000009078'), when(substring (col('LineItem.Sale.Description'),11,2) == ' *',concat(lit('RX '), substring(col('barcode'), 1, 7))).otherwise(concat(lit('RX '), substring(col('barcode'), 1, 7))))\
                               .when(trim(col('LineItem.Sale.Description')) != '',substring(col('LineItem.Sale.Description'), 1, 18))\
                               .otherwise(col('tmp_desc')))\
.withColumn('item_unit_cost',when((col('LineItem.Sale.RegularSalesUnitPrice').rlike('^\d*[.]\d*$')) & (upper(col('LineItem._CancelFlag'))!='TRUE'),col('LineItem.Sale.RegularSalesUnitPrice')*100))\
.withColumn('dept_nbr',col('tmp_department'))\
.withColumn('quantity', col('LineItem.Sale.Quantity'))\
.withColumn('tax_type', when((size(col('LineItem.Sale.Tax')) > 0) & (substring(df_Process_Item.LineItem.Sale.Tax[0].TaxRuleID,1,1) == '0'), " ")\
                        .when(size(col('LineItem.Sale.Tax')) > 0, substring(df_Process_Item.LineItem.Sale.Tax[0].TaxRuleID,1,1))\
                        .otherwise(lit(' ')))\
.withColumn('selling_price',when((col('wagcoupon_find') == 'Y') & (col('bogolep_wagcoup') != 'B'), col('temp_selling_price'))\
                            .when(col('LineItem._LineType') == "221", col('LineItem.Sale.ActualSalesUnitPrice'))
                            .otherwise(col('LineItem.Sale.ExtendedAmount')))\
.withColumn('price_sign', when((trim(col('LineItem.Return.ItemID')) == '') & (trim(col('LineItem.Sale.ItemID')) != '') & (col('LineItem.Sale.ItemID').cast(DecimalType()) == 314) & (col('txn_date') > col('tmp_changing_date')), lit('-'))\
                          .when((trim(col('LineItem.Return.ItemID')) != '') & (col('LineItem.Return.ItemID').cast(DecimalType()) == 314) & (col('txn_date') > col('tmp_changing_date')),lit(' '))\
                          .when((trim(col('LineItem.Return.ExtendedAmount')) != '') & (upper(col('LineItem._CancelFlag')) == 'TRUE'), lit('-'))\
                          .when((trim(col('LineItem.Return.ExtendedAmount')) == '') & (upper(col('LineItem._CancelFlag')) == 'TRUE') &(upper(col('LineItem.Discount.DiscountBenefit')) != "WORKER"), lit('-'))\
                          .when(col('bogolep_wagcoup') == "B", lit('-'))\
                          .when(col('bogolep_wagcoup') == "C", lit('-'))\
                          .when(col('bogolep_wagcoup') == "D", lit('-'))\
                          .when((upper(col('LineItem.Discount.DiscountBenefit')) == "WORKER") & (upper(col('LineItem._CancelFlag')) != "TRUE"), lit('-')))\
.withColumn('sale_indicator', when((col('LineItem.wag:AdvertisedPriceIndicator') == '1') | (col('LineItem.wag:AdvertisedPriceIndicator') == '3') | (upper(col('LineItem.wag:AdvertisedPriceIndicator'))=="TRUE"), lit('S')))\
.withColumn('wag_coupon', when(upper(col('LineItem.Discount.DiscountBenefit')) == "WORKER",lit('C'))\
                          .when((col('bogolep_wagcoup') == 'B') | (col('bogolep_wagcoup') == 'C') | (col('bogolep_wagcoup') == 'D'), col('bogolep_wagcoup'))\
                          .otherwise(lit(" ")))\
.withColumn('keyed_item', when(upper(col('LineItem._EntryMethod')) == "KEYED", lit('K'))\
                          .when(upper(col('LineItem._EntryMethod')) == "SCANNED", lit('S'))\
                          .when(upper(col('LineItem._EntryMethod')) == "UPC LOOKUP", lit('U'))\
                          .when(col('LineItem._EntryMethod').isNotNull(), upper(substring(col('LineItem._EntryMethod'),1,1))))\
.withColumn('returned_item', when(col('LineItem.Return.ExtendedAmount').isNotNull(), lit('R')))\
.withColumn('price_verify', when(trim(col('LineItem.Sale.pcms:PCMSSale.pcms:Manufacturer')) != '', lit('W')))\
.withColumn('special',when(upper(col('LineItem.wag:FSA')) == "TRUE", lit('F')))\
.withColumn('sequence_nbr',col('temp_sequence_nbr'))\
.withColumn('tmp_training_item', expr("""(filter(LineItem.LoyaltyReward,x-> (x.PointsAwarded._Type == 'PointsEarned') and (x.PointsAwarded._VALUE != '')))[size(filter(LineItem.LoyaltyReward,x-> (x.PointsAwarded._Type == 'PointsEarned') and (x.PointsAwarded._VALUE != '')))-1]"""))\
.withColumn('tmp2_training_item', col('LineItem._LineType') != "221")\
.withColumn('training_item', when((col('tmp_training_item').isNotNull()) & (col('tmp2_training_item')), lit('L'))\
                             .when(col('LineItem._LineType') == "203", lit('G')))\
.drop('code','code_desc')

df_lkp_linedisc = df_nextgenlkp.where(col('code_name')=='Line Discount')

df_Process_Item = df_Process_Item.alias("a").join(df_lkp_linedisc.alias("b"), rtrim(ltrim(col('discount_find'))) == col('b.code'),how='left').withColumn('tmp_discount_mode', when(substring(col('discount_find'),1,8) != '1:710000', col('b.ej_code')))

df_Process_Item = df_Process_Item.alias("c").join(df_lkp_linedisc.alias("d"), substring(col('c.discount_find'),1,8) == col('d.code'),how='left').withColumn('discount_mode', coalesce(col('tmp_discount_mode'),col('d.ej_code')))

df_lkp_itemvoid = df_nextgenlkp.where(col('code_name')=='Item Void')

df_Process_Item = df_Process_Item.alias("e").join(df_lkp_itemvoid.alias("f"), col('e.LineItem.Reason') == col('f.code'),how='left').withColumn('item_void', when(upper(col('e.LineItem._CancelFlag')) == "TRUE", coalesce(col('f.ej_code'),lit(8))))

df_lkp_picemodify = df_nextgenlkp.where(col('code_name')=='Price Modify')

df_Process_Item = df_Process_Item.alias("g").join(df_lkp_picemodify.alias("h"), ltrim(rtrim(col('g.modify_find'))) == col('h.code'),how='left').withColumn('price_modify', when(trim(col('g.modify_find')) != '', coalesce(col('h.ej_code'),lit(9))))

#display(df_Process_Item.filter(col('')))

#Sakina
# Subgraph : Graph - Process LineItem Void

df_Process_Item_Void_NonBlank = df_Process_Item.filter(col('item_void').isNotNull()).drop('code_desc', 'code_name', 'code', 'ej_code', 'ej_desc')

df_Process_Item_Void_Blank = df_Process_Item.filter(col('item_void').isNull()).drop('code_desc', 'code_name', 'code', 'ej_code', 'ej_desc')

df_join_void_voided_out = df_Process_Item_Void_Blank.alias('a').join(df_Process_Item_Void_NonBlank.alias('b'), (col('a.str_nbr') == col('b.str_nbr')) & (col('a.txn_date') == col('b.txn_date')) & (col('a.record_nbr') == col('b.record_nbr')) & (col('a.register_nbr') == col('b.register_nbr')) & (col('a.txn_nbr') == col('b.txn_nbr')) & (col('a.line_nbr') == col('b.line_nbr')),how='inner').select(df_Process_Item_Void_NonBlank['*'])

df_join_void_voided_unused = df_Process_Item_Void_Blank.alias('a').join(df_Process_Item_Void_NonBlank.alias('b'), (col('a.str_nbr') == col('b.str_nbr')) & (col('a.txn_date') == col('b.txn_date')) & (col('a.record_nbr') == col('b.record_nbr')) & (col('a.register_nbr') == col('b.register_nbr')) & (col('a.txn_nbr') == col('b.txn_nbr')) & (col('a.line_nbr') == col('b.line_nbr')),how='left_anti')

#df_join_void_voided_inner = df_join_void_voided.filter((col('a.str_nbr').isNotNull()) & (col('b.str_nbr').isNotNull()) & (col('a.txn_date').isNotNull()) & (col('b.txn_date').isNotNull()) & (col('a.record_nbr').isNotNull()) & (col('b.record_nbr').isNotNull()) & (col('a.register_nbr').isNotNull()) & (col('b.register_nbr').isNotNull()) & (col('a.txn_nbr').isNotNull()) & (col('b.txn_nbr').isNotNull()) & (col('a.line_nbr').isNotNull()) & (col('b.line_nbr').isNotNull()))

#df_join_void_voided_unused1 = df_join_void_voided.filter((col('a.str_nbr').isNotNull()) & (col('b.str_nbr').isNull()) & (col('a.txn_date').isNotNull()) & (col('b.txn_date').isNull()) & (col('a.record_nbr').isNotNull()) & (col('b.record_nbr').isNull()) & (col('a.register_nbr').isNotNull()) & (col('b.register_nbr').isNull()) & (col('a.txn_nbr').isNotNull()) & (col('b.txn_nbr').isNull()) & (col('a.line_nbr').isNotNull()) & (col('b.line_nbr').isNull()))

df_join_void_voided_inner_xform = df_join_void_voided_out.withColumn('price_sign', when(trim(col('g.price_sign')) == '', '-')
                                                                               .otherwise(lit(' ')))\
                                                      .withColumn('item_void', lit(''))\
                                                      .withColumn('sequence_nbr', col('g.line_nbr'))

df_merge_process_item = df_join_void_voided_out.unionByName(df_join_void_voided_inner_xform.unionByName(df_join_void_voided_unused))
#df_merge_process_item.count() 16236074

############################################################CHANGE NEEDED HERE############################################################################
#df_merge_process_item  = df_merge_process_item.withColumn('item_cost',lit(''))\
#.withColumn('price_modify',lit(''))
############################################################################################################################################################


df_merge_process_item = df_merge_process_item.withColumn('rcd_type',lit('A'))\
.withColumn('EJ',concat(lpad(coalesce(col('g.upc_or_tender'),lit(' ')),12,' ')\
                        ,lpad(coalesce(col('g.desc_or_acct_nbr'),lit(' ')),18,' ')\
                        ,lpad(coalesce(lit('0')),6,' ')\
                        ,lpad(coalesce(col('g.item_unit_cost'),lit('0')),7,' ')\
                        ,lpad(coalesce(col('g.dept_nbr'),lit('0')),3,' ')\
                        ,lpad(coalesce(col('g.quantity'),lit('0')),5,' ')\
                        ,lpad(coalesce(col('g.selling_price'),lit('.00')),8,' ')\
                        ,lpad(coalesce(col('g.price_sign'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.sale_indicator'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.wag_coupon'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.discount_mode'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.item_void'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.keyed_item'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.returned_item'),lit(' ')),1,' ')\
                        ,lpad(coalesce(lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.price_verify'),lit('0')),1,' ')\
                        ,lpad(coalesce(col('g.training_item'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('g.special'),lit(' ')),1,' ')\
                        ,lpad(coalesce(lit(' ')),9,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

# COMMAND ----------

## Siri 
#Select Well PAID
df_well_paid=df_sort_join.withColumn('count_tmp',expr("""(filter(LineItem.Sale.POSIdentity,x-> (upper(x._POSIDType)=='ORIGINALBARCODE') and ((x.POSItemID)!='') and (length(x.POSItemID)==41) and (regexp_extract(x.POSItemID,'%|%|%|%|%|%|')==True)))[size(filter(LineItem.Sale.POSIdentity,x-> (upper(x._POSIDType)=='ORIGINALBARCODE') and ((x.POSItemID)!='') and (length(x.POSItemID)==41) and (regexp_extract(x.POSItemID,'%|%|%|%|%|%|')==True)))-1]"""))\
.filter(col('count_tmp').isNotNull())

#Process well item
#normalise
df_well_paid=df_well_paid.withColumn('sequence_nbr',col('LineItem_SequenceNumber'))\
.withColumn('line_nbr',when(col('LineItem.pcms:PCMSLineItem.pcms:ItemLink').isNotNull(),col('LineItem.pcms:PCMSLineItem.pcms:ItemLink')).otherwise(col('LineItem_SequenceNumber')))\
.withColumn('temp_POSIdentity',explode(col('LineItem.Sale.POSIdentity')))\
.withColumn('POSItemID',col('temp_POSIdentity.POSItemID'))\
.withColumn('POSIDType',col('temp_POSIdentity._POSIDType'))\
.withColumn('return_value',col('LineItem.Return.ExtendedAmount')).drop('ej_code')

df_well_paid=df_well_paid.join(df_nextgenlkp,df_nextgenlkp.code==df_well_paid['LineItem.Reason'],'left')\
.select(df_well_paid['*'],df_nextgenlkp.code_name,df_nextgenlkp.ej_code)\
.withColumn('item_void',when(upper(col('LineItem._CancelFlag'))=='TRUE',when(col('code_name')=="Item Void",col('ej_code')).otherwise(lit('8'))))\
.filter(col('POSIDType')=='ORIGINALBARCODE')

#Reformat E0073
df_well_paid=df_well_paid.withColumn('temp_vec',split(col('POSItemID'),'|'))\
.withColumn('visit_id',col('temp_vec')[1]).withColumn('encounter_id',col('temp_vec')[2])\
.withColumn('copay_amt',col('temp_vec')[4]).withColumn('selfpay_amt',col('temp_vec')[5])\
.withColumn('sale_ind',when(col('item_void').isNotNull(),lit('V'))
           .when(col('item_void').isNotNull(),lit('R')).otherwise(lit('S')))\
.withColumn('rcd_type',lit('E')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('EJ',concat(lit('0073:')\
                        ,lpad(coalesce(col('visit_id'),lit(' ')),7,' '),lit(':')\
                        ,lpad(coalesce(col('encounter_id'),lit(' ')),10,' '),lit(':')\
                        ,lpad(coalesce(col('copay_amt'),lit(' ')),6,' '),lit(':')\
                        ,lpad(coalesce(col('selfpay_amt'),lit(' ')),6,' '),lit(':')\
                        ,lpad(coalesce(col('sale_ind'),lit(' ')),1,' '),lit(':')\
                        ,lpad(lit(' '),40,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')\
.sort(['str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ'])\
.dropDuplicates(['str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ'])

#display(df_well_paid) 0

# COMMAND ----------

##Process Line Buster #Siri
try:
  df_Process_Void = df_Process_Void.withColumn('pcms:PCMSTransaction_pcms:SourceSystem',col('pcms:PCMSTransaction.pcms:SourceSystem'))
except:
  df_Process_Void = df_Process_Void.withColumn('pcms:PCMSTransaction_pcms:SourceSystem',lit(None).cast(StringType()))

dfLineBuster=df_Process_Void.filter(col('pcms:PCMSTransaction.pcms:WorkstationLocation')=='LB')\
.withColumn('unused1',when(col('LineItem.Sale.pcms:PCMSSale.pcms:PriceDiscountable').isNotNull(),concat(lpad(col('LineItem.Sale.pcms:PCMSSale.pcms:ExternalReference'),3,' '),col('LineItem.Sale.pcms:PCMSSale.pcms:PriceDiscountable'))).otherwise(concat(lpad(col('LineItem.Sale.pcms:PCMSSale.pcms:ExternalReference'),3,' '),lit('::'))))\
.withColumn('sequence_nbr',coalesce(col('LineItem_SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E')).withColumn('line_buster',lit('LB'))\
.withColumn('EJ',concat(lit('0009:')\
                        ,lpad(coalesce(col('line_buster'),lit(' ')),2,' ')\
                        ,lpad(coalesce(col('unused1'),lit(' ')),64,' ')\
                        ,lpad(lit(' '),9,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#dfLineBuster.count() 0

# COMMAND ----------

#PUSPAK
##Process Script Rx

dfRx=df_Process_Void.filter((col('LineItem.Sale.ItemID')=='00499999999998') | (col('LineItem.Sale.ItemID')=='00499999999999') | (col('LineItem.Sale.ItemID')=='00420000009078') | (col('LineItem.Return.ItemID')=='00499999999998') | (col('LineItem.Return.ItemID')=='00499999999999') | (col('LineItem.Return.ItemID')=='00420000009078'))
#dfRx.count() 2687166

s1 = df_Process_Void.where(~((col('LineItem.Sale.ItemID').eqNullSafe('00499999999998')) | (col('LineItem.Sale.ItemID').eqNullSafe('00499999999999')) | (col('LineItem.Sale.ItemID').eqNullSafe('00420000009078')) | (col('LineItem.Return.ItemID').eqNullSafe('00499999999998')) | (col('LineItem.Return.ItemID').eqNullSafe('00499999999999')) | (col('LineItem.Return.ItemID').eqNullSafe('00420000009078'))))

##Prepaid
df_PrepaidRx=s1.filter((col('LineItem.Sale.ItemID').eqNullSafe('00499999999936')) | (col('LineItem.Return.ItemID').eqNullSafe('00499999999936')))
#df_PrepaidRx.count() 0

s2 = s1.where(~((col('LineItem.Sale.ItemID').eqNullSafe('00499999999936')) | (col('LineItem.Return.ItemID').eqNullSafe('00499999999936'))))

#PostPaid Rx
df_PostpaidRx=s2.filter((col('LineItem.Sale.ItemID').eqNullSafe('00499999999981') | col('LineItem.Sale.ItemID').eqNullSafe('00420000009573') | col('LineItem.Return.ItemID').eqNullSafe('00499999999981') | col('LineItem.Return.ItemID').eqNullSafe('00420000009573')))
#df_PostpaidRx.count() 6856

#E019 Merge
df_E0019=dfRx.union(df_PrepaidRx)

########Replicating incorrect code of ab initio which is incorrectly filtering return records with valid wag:patientId
df_E0019=df_E0019.filter((length(trim(col('LineItem.wag:patientId')))>0) & (~(col('LineItem.Sale.ExtendedAmount').isNull() & (~(upper(col('LineItem.Discount.DiscountBenefit')).eqNullSafe("WORKER")))& col('LineItem.Return.ExtendedAmount').isNotNull())))

##correct code that should be there in place of above code
#df_E0019=df_E0019.filter((length(trim(col('LineItem.wag:patientId')))>0))
#######################################################################################################################
#df_E0019.count() 2680241

###rollup E019
df_E0019=df_E0019.withColumn('LineItem_wag:patientId',col('LineItem.wag:patientId'))\
                 .withColumn('LineItem_wag:patientPhoneNumber',col('LineItem.wag:patientPhoneNumber'))\
                 .withColumn('LineItem_wag_patientType',col('LineItem.wag:patientType'))\
                 .withColumn('pt_A',when(ltrim(col('LineItem_wag_patientType'))=='A',1).otherwise(0))\
                 .withColumn('pt_M',when(ltrim(col('LineItem_wag_patientType'))=='M',1).otherwise(0))
                     
wspec1 = Window.partitionBy('str_nbr','txn_date','record_nbr','register_nbr','txn_nbr','LineItem_wag:patientId','LineItem_wag:patientPhoneNumber', 'LineItem_wag_patientType')
wspec2 = Window.partitionBy('str_nbr','txn_date','record_nbr','register_nbr','txn_nbr','LineItem_wag:patientId','LineItem_wag:patientPhoneNumber', 'LineItem_wag_patientType').orderBy('str_nbr')

df_E0019 = df_E0019.withColumn('tmp_adult_rx',sum(col('pt_A')).over(wspec1))\
.withColumn('tmp_underage_rx',sum(col('pt_M')).over(wspec1))\
.withColumn('row_num',row_number().over(wspec2)).where(col('row_num')==1)\
.withColumn('patient_phone_nbr',when(length(trim(col('LineItem_wag:patientPhoneNumber')))>0,ltrim(col('LineItem_wag:patientPhoneNumber'))))\
.withColumn('patient_id',when(length(trim(col('LineItem_wag:patientId')))>0,ltrim(col('LineItem_wag:patientId')))\
           .otherwise(lit('0000000000000')))\
.withColumn('adult_or_under_age',when(length(trim(col('LineItem_wag_patientType')))>0,ltrim(col('LineItem_wag_patientType')))\
           .otherwise(lit('A')))\
.withColumn('rx_cnt_info',when(col('tmp_adult_rx')>0,concat(col('tmp_adult_rx').cast(StringType()),lit(':0:')))\
          .when(col('tmp_underage_rx')>0,concat(lit('0:'),col('tmp_adult_rx').cast(StringType()),lit(':')))\
          .otherwise(lit('0:0:')))\
.withColumn('sequence_nbr',lit('9999')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E')).withColumn('unused',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0019:')\
                        ,lpad(coalesce(substring(col('patient_phone_nbr'),1,10),lit('0000000000000')),10,'0')\
                        ,lpad(coalesce(substring(col('patient_id'),1,13),lit(' ')),13,' ')\
                        ,lpad(coalesce(substring(col('adult_or_under_age'),1,1),lit('A')),1,'A')\
                        ,lit(':')\
                        ,lpad(coalesce(substring(col('rx_cnt_info'),1,8),lit('0')),8,'0')\
                        ,lpad(lit(' '),42,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_E0019.count() 1736624


#E0040
df_E0040=df_PrepaidRx.withColumn('LineItem_Sale_POSIdentity',expr("""(filter(LineItem.Sale.POSIdentity,x-> x._POSIDType=='OriginalBarcode'))[size(filter(LineItem.Sale.POSIdentity,x-> x._POSIDType=='OriginalBarcode'))-1]"""))\
.withColumn('rx_store_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),15,5))\
.withColumn('rx_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),1,11))\
.withColumn('rx_indicator',substring(col('LineItem_Sale_POSIdentity.POSItemID'),12,1))\
.withColumn('rx_type',substring(col('LineItem_Sale_POSIdentity.POSItemID'),13,2))\
.withColumn('fulfmnt_str_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),15,5))\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E')).withColumn('unused',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0040:')\
                        ,lpad(coalesce(col('rx_store_nbr'),lit(' ')),5,' '),lit(':')\
                        ,lpad(coalesce(col('rx_nbr'),lit(' ')),11,' ')\
                        ,lpad(coalesce(col('rx_indicator'),lit(' ')),1,' '),lit(':')\
                        ,lpad(coalesce(col('rx_type'),lit(' ')),2,' '),lit(':')\
                        ,lpad(coalesce(col('fulfmnt_str_nbr'),lit(' ')),5,' '),lit(':')\
                        ,lpad(lit(' '),46,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#E0140
df_E0140=dfRx.union(df_PrepaidRx).union(df_PostpaidRx)
#df_E0140.count() 2694022
df_E0140=df_E0140.withColumn('LineItem_Sale_POSIdentity',expr("""(filter(LineItem.Sale.POSIdentity,x-> x._POSIDType=='OriginalBarcode'))[size(filter(LineItem.Sale.POSIdentity,x-> x._POSIDType=='OriginalBarcode'))-1]"""))\
.withColumn('tm_fulfmnt_str_nbr',when((col('LineItem.Sale.ItemID')== "00499999999936"),substring(col('LineItem_Sale_POSIdentity.POSItemID'),15,5)).otherwise(lit(None)))\
.withColumn('rx_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),1,7))\
.withColumn('fill_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),8,2))\
.withColumn('fill_desp_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),10,2))\
.withColumn('rx_indicator',substring(col('LineItem_Sale_POSIdentity.POSItemID'),12,1))\
.withColumn('rx_type',substring(col('LineItem_Sale_POSIdentity.POSItemID'),13,2))\
.withColumn('fulfmnt_str_nbr',col('tm_fulfmnt_str_nbr'))\
.withColumn('rx_store_nbr',when(col('tm_fulfmnt_str_nbr').isNotNull(),col('tm_fulfmnt_str_nbr')).otherwise(col('str_nbr')))\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E')).withColumn('unused',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0140:')\
                        ,lpad(coalesce(col('rx_store_nbr'),lit(' ')),5,' '),lit(':')\
                        ,lpad(coalesce(col('rx_nbr'),lit(' ')),7,' ')\
                        ,lpad(coalesce(col('fill_nbr'),lit(' ')),2,' ')\
                        ,lpad(coalesce(col('fill_desp_nbr'),lit(' ')),2,' '),lit(':')\
                        ,lpad(coalesce(col('rx_indicator'),lit(' ')),1,' '),lit(':')\
                        ,lpad(coalesce(col('rx_type'),lit(' ')),2,' '),lit(':')\
                        ,lpad(coalesce(col('fulfmnt_str_nbr'),lit(' ')),5,' '),lit(':')\
                        ,lpad(lit(' '),46,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')


df_ProcessRx = df_E0019.unionAll(df_E0040).unionAll(df_E0140)
#df_ProcessRx.count() 4430646

# COMMAND ----------

### Siri Process Survey Coupon Redeemed

df_PSCR=df_Process_Void.filter((col('LineItem._LineType')=='209') & (col('LineItem.Sale.pcms:PCMSSale.pcms:ExternalReference').isNotNull()))\
.withColumn('activation_code',substring(col('LineItem.Sale.pcms:PCMSSale.pcms:ExternalReference'),1,6))\
.withColumn('coupon_upc_printed_tmp',expr("""(filter(LineItem.Sale.POSIdentity,x-> upper(x._POSIDType)=='ORIGINALBARCODE'))[size(filter(LineItem.Sale.POSIdentity,x-> upper(x._POSIDType)=='ORIGINALBARCODE'))-1]"""))\
.withColumn('tmp_coupon_upc_printed',substring(col('coupon_upc_printed_tmp.POSItemID'),1,12))\
.withColumn('coupon_upc_real_tmp',expr("""(filter(LineItem.Sale.POSIdentity,x-> upper(x._POSIDType)=='PLU'))[size(filter(LineItem.Sale.POSIdentity,x-> upper(x._POSIDType)=='PLU'))-1]"""))\
.withColumn('tmp_coupon_upc_real',substring(col('coupon_upc_real_tmp.POSItemID'),1,12))\
.withColumn('coupon_upc_printed',col('tmp_coupon_upc_printed'))\
.withColumn('coupon_upc_real',col('tmp_coupon_upc_real'))\
.withColumn('sequence_nbr',coalesce(col('LineItem_SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E'))\
.withColumn('EJ',concat(lit('0021:')\
                        ,lpad(coalesce(col('coupon_upc_printed'),lit(' ')),12,' '),lit(':')\
                        ,lpad(coalesce(col('coupon_upc_real'),lit(' ')),12,' '),lit(':')\
                        ,lpad(coalesce(col('activation_code'),lit(' ')),6,' '),lit(':')\
                        ,lpad(lit(' '),42,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')


#df_PSCR.count() #389

# COMMAND ----------

####PUSPAK  (INCOMPLETE due to Process Item missing in union )
#### Rx City of Au 215 
###E0018
df_RxCity_215=df_process_discount.filter(col('LineItem._LineType')=="215")\
.withColumn('LineItem_Sale_POSIdentity',expr("""(filter(LineItem.Sale.POSIdentity,x-> x._POSIDType=='OriginalBarcode'))[size(filter(LineItem.Sale.POSIdentity,x-> x._POSIDType=='OriginalBarcode'))-1]"""))\
.withColumn('rx_nbr',substring(col('LineItem_Sale_POSIdentity.POSItemID'),1,8))\
.withColumn('copy_amt',(col('LineItem.Sale.ExtendedAmount')*100).cast(DecimalType(7,0)))\
.withColumn('item_type',when((upper(col('LineItem._LineItemStatus')).eqNullSafe("CANCELED")),lit('V'))\
            .when(col('LineItem.Return.ItemID').isNotNull(),lit('R'))\
                             .otherwise(lit('S')))\
.withColumn('sequence_nbr',coalesce(col('LineItem.SequenceNumber'),lit('9999'))).withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('E'))\
.withColumn('survey_id',lit('AUSTIN PAP RX')).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lit('0018:')\
                        ,lpad(coalesce(col('survey_id'),lit(' ')),13,' '),lit(':')\
                        ,lpad(coalesce(col('rx_nbr'),lit(' ')),8,' '),lit(':')\
                        ,lpad(coalesce(col('copy_amt'),lit(' ')),7,' '),lit(':')\
                        ,lpad(coalesce(col('item_type'),lit(' ')),1,' ')\
                        ,lpad(lit(' '),42,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_RxCity_215.count() 0

df_ProcessA=df_line216.unionByName(df_line217).unionByName(df_line219).unionByName(df_line220).unionByName(df_line221).unionByName(df_E0075).unionByName(df_merge_process_item ).unionByName(df_well_paid).unionByName(df_bogo_join).unionByName(dfLineBuster).unionByName(df_ProcessRx).unionByName(df_PSCR).unionByName(df_RxCity_215)
#df_ProcessA.count() 5103853

# COMMAND ----------

#PUSPAK
####### dfReturn transform 2

dfReturn_Void_0=dfReturn.filter(~(upper(col('LineItem._CancelFlag')).eqNullSafe("TRUE"))).withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))
#dfReturn_Void_0.count()72109

dfReturn_Void_1=dfReturn.filter((upper(col('LineItem._CancelFlag')).eqNullSafe("TRUE"))).withColumn('LineItem_ItemLink',col('LineItem.pcms:PCMSLineItem.pcms:ItemLink'))
#dfReturn_Void_1.count() 1289

dfReturn_Void=dfReturn_Void_0.join(dfReturn_Void_1,((dfReturn_Void_0.str_nbr==dfReturn_Void_1.str_nbr) &(dfReturn_Void_0.txn_date==dfReturn_Void_1.txn_date) & (dfReturn_Void_0.register_nbr==dfReturn_Void_1.register_nbr) &(dfReturn_Void_0.txn_nbr==dfReturn_Void_1.txn_nbr) & (dfReturn_Void_0.LineItem_SequenceNumber == dfReturn_Void_1.LineItem_ItemLink)),'leftanti')
#dfReturn_Void.count() 70820


####Return transform 1 -- E0006

dfReturn_E0006_match=dfReturn_Void.filter((~(upper(col('LineItem._CancelFlag')).eqNullSafe('TRUE')))).withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))
                                          
dfReturn_E0006_nonmatch=dfReturn_Void.filter(upper(col('LineItem._CancelFlag')).eqNullSafe('TRUE')).withColumn('LineItem_ItemLink',col('LineItem.pcms:PCMSLineItem.pcms:ItemLink'))

dfReturn_E0006=dfReturn_E0006_match.join(dfReturn_E0006_nonmatch,((dfReturn_E0006_nonmatch.str_nbr==dfReturn_E0006_match.str_nbr) & (dfReturn_E0006_nonmatch.txn_date==dfReturn_E0006_match.txn_date) & (dfReturn_E0006_nonmatch.register_nbr==dfReturn_E0006_match.register_nbr) & (dfReturn_E0006_nonmatch.txn_nbr==dfReturn_E0006_match.txn_nbr) & (dfReturn_E0006_nonmatch.record_nbr==dfReturn_E0006_match.record_nbr) &(dfReturn_E0006_nonmatch.LineItem_ItemLink == dfReturn_E0006_match.LineItem_SequenceNumber)),'leftanti')
#dfReturn_E0006.count() 70820


####Rollup E0006
wspec1 = Window.partitionBy('str_nbr','txn_date','record_nbr','register_nbr','txn_type','txn_nbr','LineItem.wag:OrigRfn','LineItem.wag:OrigTenderType')
wspec2 = Window.partitionBy('str_nbr','txn_date','record_nbr','register_nbr','txn_type','txn_nbr','LineItem.wag:OrigRfn','LineItem.wag:OrigTenderType').orderBy('str_nbr')

dfReturn_E0006=dfReturn_E0006.withColumn('temp_refund_amt',(sum(col('LineItem.Return.ExtendedAmount'))).over(wspec1))\
                             .withColumn('row_num',row_number().over(wspec2)).where(col('row_num')==1).drop('row_num')

dfReturn_E0006=dfReturn_E0006\
.withColumn('orig_date',when(col('LineItem.wag:OrigRfn').isNotNull(),substring(col('LineItem.wag:OrigRfn'),13,6)).otherwise(col('txn_date')[3:6]))\
.withColumn('orig_str',when(col('LineItem.wag:OrigRfn').isNotNull(),substring(col('LineItem.wag:OrigRfn'),1,5)).otherwise(col('str_nbr')))\
.withColumn('orig_register',when(col('LineItem.wag:OrigRfn').isNotNull(),substring(col('LineItem.wag:OrigRfn'),6,2)).otherwise(substring(col('register_nbr'),2,2)))\
.withColumn('orig_txn_nbr',when(col('LineItem.wag:OrigRfn').isNotNull(),substring(col('LineItem.wag:OrigRfn'),8,4)))\
.withColumn('int_orig_trans_amt',when(col('LineItem.wag:OrigAmt').isNotNull(),((col('LineItem.wag:OrigAmt') * 100)).cast(DecimalType(7,2))))\
.withColumn('orig_trans_amt',when(length(col('int_orig_trans_amt'))>=7,col('int_orig_trans_amt')).otherwise(lpad(col('int_orig_trans_amt'),7,'0')))\
.withColumn('orig_tndr',when(col('LineItem.wag:OrigTenderID').isNotNull(),col('LineItem.wag:OrigTenderID')))\
.withColumn('refund_status',when(col('LineItem.wag:RefundStatus').isNotNull(),col('LineItem.wag:RefundStatus')))\
.withColumn('int_rcpt_entry',coalesce(col('LineItem.wag:ReceiptEntry'),lit('dummy')))\
.withColumn('rcpt_entry',when((col('int_rcpt_entry') != 'dummy') & (length(col('int_rcpt_entry')) == 1),col('int_rcpt_entry'))\
           .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '10'),lit('A'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '11'),lit('B'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '12'),lit('C'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '13'),lit('D'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '14'),lit('E'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '15'),lit('F'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '16'),lit('G'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '17'),lit('H'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '18'),lit('I'))\
            .when((col('int_rcpt_entry') != 'dummy') & (col('int_rcpt_entry') == '19'),lit('J'))\
            .when((length(col('int_rcpt_entry')) == 1),col('int_rcpt_entry')))\
.withColumn('tandem_stat',when(col('LineItem.wag:TandemStatus').isNotNull(),col('LineItem.wag:TandemStatus'))).drop('ej_code')\

dfReturn_E0006 = dfReturn_E0006.join(df_nextgenlkp,dfReturn_E0006['LineItem.Return.pcms:PCMSReturn.pcms:ReasonCode'] == df_nextgenlkp.code,how='left').select(dfReturn_E0006['*'],df_nextgenlkp.ej_code)\
.withColumn('refund_rsn',when(col('ej_code').isNotNull(),col('ej_code'))\
            .when(((length(col('LineItem.Return.pcms:PCMSReturn.pcms:ReasonCode')) == 3) & (substring(col('LineItem.Return.pcms:PCMSReturn.pcms:ReasonCode'),1,3) == '11:')),substring(col('LineItem.Return.pcms:PCMSReturn.pcms:ReasonCode'),4,1))\
           .otherwise(lit('3')))\
.withColumn('int_refund_amt',(round(col('temp_refund_amt')*100)).cast(IntegerType()))\
.withColumn('refund_amt',when(length(col('int_refund_amt')) >= 8,col('int_refund_amt'))\
            .otherwise(lpad(col('int_refund_amt'),8,'0')))\
.withColumn('register_loc',col('workstation_location'))\
.withColumn('sequence_nbr',lit('9999').cast(IntegerType()))\
.withColumn('mgr_id',when(col('LineItem.wag:ManagerNumber').isNotNull(),col('LineItem.wag:ManagerNumber')))\
.withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E'))\
.withColumn('EJ',concat(lit('0006:R')\
                        ,coalesce((col('orig_date')),lit('      '))\
                        ,lpad(coalesce(col('orig_str'),lit(' ')),5,' ')\
                        ,lpad(coalesce(col('orig_register'),lit(' ')),2,' ')\
                        ,lpad(coalesce(col('orig_txn_nbr'),lit('0')),4,'0')\
                        ,lpad(coalesce(col('orig_trans_amt'),lit(' ')),7,'0')\
                        ,lpad(coalesce(col('refund_amt'),lit(' ')),8,' ')\
                        ,lpad(coalesce(col('orig_tndr'),lit('0')),2,' 0')\
                        ,lit('::')\
                        ,lpad(coalesce(col('mgr_id'),lit('0')),3,'0')\
                        ,lpad(coalesce(col('register_loc'),lit(' ')),2,' ')\
                        ,lpad(coalesce(col('refund_status'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('rcpt_entry'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('tandem_stat'),lit(' ')),1,' ')\
                        ,lpad(coalesce(col('refund_rsn'),lit('3')),1,' '),lpad(lit(' '),29,' ')))\
.select('record_nbr','detail_nbr', 'detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr', 'register_nbr','txn_nbr','txn_type','rcd_type','EJ')

#dfReturn_E0006.count() 47194

# COMMAND ----------

###PUSPAK
###Retun Transform 2- Ecom UPC

dfReturn_upc=dfReturn_Void.filter(col('txn_type')==15)
#dfReturn_upc.count() 13

wspec1 = Window.partitionBy('str_nbr','txn_date','record_nbr'\
                            ,'register_nbr','txn_type','txn_nbr','LineItem.wag:ECommOrderNumber') 
wspec2 = Window.partitionBy('str_nbr','txn_date','record_nbr'\
                            ,'register_nbr','txn_type','txn_nbr','LineItem.wag:ECommOrderNumber').orderBy('str_nbr')

dfReturn_upc=dfReturn_upc.withColumn('temp_refund_amt',(sum(col('LineItem.Return.ExtendedAmount'))).over(wspec1))\
                         .withColumn('row_num',row_number().over(wspec2)).where(col('row_num')==1).drop('row_num')

dfReturn_upc=dfReturn_upc\
.withColumn('int_upc_or_tender',coalesce(col('LineItem.wag:ECommOrderNumber'),lit('dummy')))\
.withColumn('upc_or_tender',when(((col('int_upc_or_tender') != 'dummy') & (length(col('int_upc_or_tender')) > 12)),lpad(substring(col('int_upc_or_tender'),2,12),12,'0'))\
           .when(((col('int_upc_or_tender') != 'dummy') & (length(col('int_upc_or_tender')) <= 12)),lpad(col('int_upc_or_tender'),12,'0'))\
           .otherwise(lit('NO UPC FOUND')))\
.withColumn('selling_price',lit('0'))\
.withColumn('desc_or_acct_nbr',lit('E-COMM ORDER#'))\
.withColumn('price_verify',lit(' ')).withColumn('item_unit_cost',lit(' ')).withColumn('item_cost',lit(' '))\
.withColumn('sequence_nbr',lit('9999')).withColumn('bogo_seq_nbr',lit('0')).withColumn('rcd_type',lit('A'))\
.withColumn('price_sign',lit(None)).withColumn('sale_indicator',lit(None)).withColumn('wag_coupon',lit(None))\
.withColumn('discount_mode',lit(None)).withColumn('item_void',lit(None)).withColumn('dept_nbr',lit(None))\
.withColumn('returned_item',lit(None)).withColumn('price_modify',lit(None)).withColumn('training_item',lit(None))\
.withColumn('special',lit(None)).withColumn('unused5',lit(None)).withColumn('unused',lit(None))\
.withColumn('price_modify',lit(None)).withColumn('quantity',lpad(lit('0'),5,' ')).withColumn('tax_type',lpad(lit(' '),1,' '))\
.withColumn('keyed_item',lpad(lit(' '),1,' '))\
.withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),(lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),(lpad((coalesce(col('item_cost'),lit('0'))),6,' ')),(lpad((coalesce(col('item_unit_cost'),lit('0'))),7,' ')),(lpad((coalesce(col('dept_nbr'),lit('0'))),3,' ')),(lpad((coalesce(col('quantity'),lit('0'))),5,' ')),(lpad((coalesce(col('tax_type'),lit(' '))),1,' ')),(lpad((coalesce(col('selling_price'),lit('.00'))),8,' ')),(lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),(lpad((coalesce(col('sale_indicator'),lit(' '))),1,' ')),(lpad((coalesce(col('wag_coupon'),lit(' '))),1,' ')),(lpad((coalesce(col('discount_mode'),lit(' '))),1,' ')),(lpad((coalesce(col('item_void'),lit(' '))),1,' ')),(lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),(lpad((coalesce(col('returned_item'),lit(' '))),1,' ')),(lpad((coalesce(col('price_modify'),lit(' '))),1,' ')),(lpad((coalesce(col('price_verify'),lit(' '))),1,' ')),(lpad((coalesce(col('training_item'),lit(' '))),1,' ')),(lpad((coalesce(col('special'),lit(' '))),1,' ')),(lpad((coalesce(col('unused5'),lit(' '))),9,' '))))\
.select('record_nbr', 'detail_nbr', 'detail_type', 'sequence_nbr','bogo_seq_nbr','str_nbr', 'txn_date', 'txn_time', 'cashier_nbr', 'register_nbr', 'txn_type', 'txn_nbr', 'rcd_type','EJ')

#dfReturn_upc.count() 6

# COMMAND ----------

###PUSPAK
# #### Retun Transform 3 -- Process Refund Tax

dfReturn_RefundTax=dfReturn_Void.withColumn('LineItem_Return_POSIdentity',col('LineItem.Return.POSIdentity'))\
.withColumn('LineItem_Return_XX_n_POSIdentity',size(col('LineItem_Return_POSIdentity')))\
.withColumn('LineItem_Return_Tax',explode(col('LineItem.Return.Tax')))\
.withColumn('LineItem_Return_Tax',size(col('LineItem.Return.Tax')))
#dfReturn_RefundTax.count()     71492 

dfReturn_RefundTax = dfReturn_RefundTax.withColumn('temp1',explode('LineItem.Return.Tax'))\
.withColumn('LineItem_Return_Tax_TaxRuleID',col('temp1.TaxRuleID')).withColumn('LineItem_Return_Tax_Percent',col('temp1.Percent'))
wspec = Window.partitionBy('str_nbr','txn_date','record_nbr','register_nbr','txn_nbr','LineItem_Return_Tax_TaxRuleID','LineItem_Return_Tax_Percent').orderBy('str_nbr')
dfReturn_RefundTax = dfReturn_RefundTax.withColumn('row_num',row_number().over(wspec)).where(col('row_num')==1).drop('row_num','temp1')
#display(dfReturn_RefundTax.where((col('str_nbr')==16415) & (col('txn_date')==20220705) & (col('txn_time')==912)))
#dfReturn_RefundTax.count() 48901

# COMMAND ----------

###PUSPAK
####### Process Tax - B Record
dfTax_reform=dfTax.select('record_nbr','detail_nbr','detail_type','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','record_type',col('LineItem.Tax').alias('LineItem_Tax'),'LineItem')
#dfTax_reform.count() 6903210

#### First flow joins with dfReturn_RefundTax
dfTax_transform1=dfTax_reform.withColumn('LineItem_Tax_TaxRuleID',col('LineItem_Tax.TaxRuleID'))\
                             .withColumn('LineItem_Tax_Percent',col('LineItem_Tax.Percent'))

dfReturn_TaxJoin=dfReturn_RefundTax.join(dfTax_transform1,((dfTax_transform1.str_nbr==dfReturn_RefundTax.str_nbr) & (dfTax_transform1.txn_date==dfReturn_E0006_match.txn_date) & (dfTax_transform1.register_nbr==dfReturn_RefundTax.register_nbr) & (dfTax_transform1.txn_nbr==dfReturn_RefundTax.txn_nbr) & (dfTax_transform1.record_nbr==dfReturn_RefundTax.record_nbr) &(dfTax_transform1.LineItem_Tax_Percent == dfReturn_RefundTax.LineItem_Return_Tax_Percent) & (dfTax_transform1.LineItem_Tax_TaxRuleID == dfReturn_RefundTax.LineItem_Return_Tax_TaxRuleID)),'leftanti')

dfReturn_TaxJoin=dfReturn_TaxJoin.withColumn('upc_or_tender',lit('REFUND TAX%')).withColumn('keyed_item',lit('K'))\
                                 .withColumn('desc_or_acct_nbr',regexp_replace(col('LineItem_Return_Tax_Percent'),'0+$',''))\
                                 .withColumn('item_cost',lit(None).cast(StringType()))\
                     .withColumn('item_unit_cost',lit(None).cast(StringType()))\
                     .withColumn('dept_nbr',lit(None).cast(StringType())).withColumn('quantity',lit(None).cast(StringType()))\
                     .withColumn('selling_price',lit(None).cast(StringType())).withColumn('rcd_type',lit('A').cast(StringType()))\
                     .withColumn('sequence_nbr',lit('9999').cast(StringType()))\
                     .withColumn('price_sign',lit(None).cast(StringType())).withColumn('bogo_seq_nbr',lit('0').cast(StringType()))\
                     .withColumn('sale_indicator',lit(None).cast(StringType()))\
                     .withColumn('wag_coupon',lit(None).cast(StringType()))\
                     .withColumn('discount_mode',lit(None).cast(StringType()))\
                     .withColumn('item_void',lit(None).cast(StringType())).withColumn('tax_type',lit(None).cast(StringType()))\
                     .withColumn('returned_item',lit(None).cast(StringType()))\
                     .withColumn('price_modify',lit(None).cast(StringType()))\
                     .withColumn('price_verify',lit(None).cast(StringType()))\
                     .withColumn('training_item',lit(None).cast(StringType())).withColumn('special',lit(None).cast(StringType()))\
                     .withColumn('unused5',lit(None).cast(StringType()))\
                     .withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),(lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),(lpad((coalesce(col('item_cost'),lit('0'))),6,' ')),(lpad((coalesce(col('item_unit_cost'),lit('0'))),7,' ')),(lpad((coalesce(col('dept_nbr'),lit('0'))),3,' ')),(lpad((coalesce(col('quantity'),lit('0'))),5,' ')),(lpad((coalesce(col('tax_type'),lit(' '))),1,' ')),(lpad((coalesce(col('selling_price'),lit('.00'))),8,' ')),(lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),(lpad((coalesce(col('sale_indicator'),lit(' '))),1,' ')),(lpad((coalesce(col('wag_coupon'),lit(' '))),1,' ')),(lpad((coalesce(col('discount_mode'),lit(' '))),1,' ')),(lpad((coalesce(col('item_void'),lit(' '))),1,' ')),(lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),(lpad((coalesce(col('returned_item'),lit(' '))),1,' ')),(lpad((coalesce(col('price_modify'),lit(' '))),1,' ')),(lpad((coalesce(col('price_verify'),lit(' '))),1,' ')),(lpad((coalesce(col('training_item'),lit(' '))),1,' ')),(lpad((coalesce(col('special'),lit(' '))),1,' ')),(lpad((coalesce(col('unused5'),lit(' '))),9,' '))))
                     

dfReturn_TaxJoin=dfReturn_TaxJoin.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#dfReturn_TaxJoin.count() 497

## Second flow
dfTax_transform2=dfTax_reform.withColumn('tax_code',when(col('LineItem_Tax.TaxRuleID')=='0',lit(' '))
                                        .otherwise(col('LineItem_Tax.TaxRuleID')))\
                             .withColumn('tax_table_desc',concat((round(col('LineItem_Tax.Percent'),2)),lit('% '),lit('SALES TAX')))\
                             .withColumn('selling_price',col('LineItem_Tax.Amount')) \
                             .withColumn('price_sign',when(upper(col('LineItem_Tax._NegativeValue'))=="TRUE",lit('-')))\
                             .withColumn('sequence_nbr',col('LineItem_Tax.SequenceNumber')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('B')).withColumn('unused1',lit(None)).withColumn('unused2',lit(None)).withColumn('unused3',lit(None)).withColumn('unused5',lit(None))\
.withColumn('EJ',concat(lpad(lit(' '),11,' '),(lpad((coalesce(col('tax_code'),lit(' '))),1,' ')),(lpad((coalesce(col('tax_table_desc'),lit(' '))),18,' ')),lpad(lit(' '),18,' '),(lpad((coalesce(col('selling_price'),lit('.00'))),8,' ')),(lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),lpad(lit(' '),23,' ')))\
.select('record_nbr', 'detail_nbr', 'detail_type', 'sequence_nbr','bogo_seq_nbr','str_nbr', 'txn_date', 'txn_time', 'cashier_nbr', 'register_nbr', 'txn_type', 'txn_nbr', 'rcd_type','EJ') 
#dfTax_transform2.count() 6903210

# COMMAND ----------

###PUSPAK
#### Process DMC - E0007
dfMailCheck_E0007=dfMailCheck.withColumn('dmc_barcode_temp',expr("""(filter(LineItem['pcms:PCMSCouponEndorsement']['pcms:POSIdentity'],x -> upper(x._POSIDType)=='ORIGINALBARCODE'))[size(filter(LineItem['pcms:PCMSCouponEndorsement']['pcms:POSIdentity'],x -> upper(x._POSIDType)=='ORIGINALBARCODE'))-1]"""))\
.withColumn('dmc_barcode',col('dmc_barcode_temp.POSItemID')).drop('dmc_barcode_temp')\
.withColumn('check_info_w_rx',substring(concat(col('LineItem.wag:DMCRoutingNumber'),lit(':'), col('LineItem.wag:DMCAccountNumber'),lit(':'),col('LineItem.wag:DMCCheckNumber'),lit(':barcode')),1,42))\
                             .withColumn('rcd_type',lit('E')).withColumn('bogo_seq_nbr',lit('0'))\
                             .withColumn('sequence_nbr',lit('9999'))\
                             .withColumn('EJ',concat(lit('0007'),lit(':'),(lpad((coalesce(col('dmc_barcode'),lit(' '))),18,' ')),lit(':'),(lpad((coalesce(col('check_info_w_rx'),lit(' '))),42,' ')),lpad(lit(' '),14,' ')))
  
dfMailCheck_E0007=dfMailCheck_E0007.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#dfMailCheck_E0007.count() 0

# COMMAND ----------

###PUSPAK (INCOMPLTE due to info needed from runops)
##### Process Tender C Record
dfTender_Cancel=dfTender.filter(upper(col('LineItem._CancelFlag')).eqNullSafe('TRUE')).withColumn('LineItem_SequenceNumber',(col('LineItem.SequenceNumber'))-1)
#dfTender_Cancel.count() 154543

dfTender_NotCancel=dfTender.filter(~(upper(col('LineItem._CancelFlag')).eqNullSafe('TRUE'))).withColumn('LineItem_SequenceNumber',col('LineItem.SequenceNumber'))
#dfTender_NotCancel.count() 6001010

dfTender_join=dfTender_NotCancel.join(dfTender_Cancel,((dfTender_Cancel.str_nbr==dfTender_NotCancel.str_nbr) & (dfTender_Cancel.txn_date==dfTender_NotCancel.txn_date) & (dfTender_Cancel.record_nbr==dfTender_NotCancel.record_nbr) & (dfTender_Cancel.txn_nbr==dfTender_NotCancel.txn_nbr) & (dfTender_Cancel.LineItem_SequenceNumber == dfTender_NotCancel.LineItem_SequenceNumber)),'leftanti')
#dfTender_join.count() 5846468

df_check_select = dfTender_join.where(col('LineItem.Tender.TenderID').isin('29','30')).drop('ej_code')
#df_check_select.count() 11299

#Process Check
df_lkp_tndr = df_nextgenlkp.where(col('code_name')=='Tender')
df_check_select=df_check_select.join(df_lkp_tndr,df_check_select.LineItem.Tender.TenderID==df_lkp_tndr.code,how='left').select(df_check_select['*'],df_lkp_tndr.code_desc.alias('tender_part1'))\
.withColumn('routing_nbr',lpad(col('LineItem.Tender.Check.BankID'),9,'0'))\
.withColumn('check_info',concat(col('LineItem.Tender.Check.AccountNumber'),lit(':'),col('LineItem.Tender.Check.CheckNumber')))\
.withColumn('selling_price',col('LineItem.Tender.Amount._VALUE'))\
.withColumn('entry_mode',when(upper(col('LineItem._EntryMethod'))=='MSR',lit('M'))\
           .when(upper(col('LineItem._EntryMethod'))=='KEYED',lit('K'))\
           .when(upper(col('LineItem._EntryMethod'))=='SCANNED',lit('S')))\
.withColumn('sequence_nbr',col('LineItem.SequenceNumber'))\
.withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('C'))\
.withColumn('EJ',concat((rpad((coalesce(col('tender_part1'),lit('CHECK '))),6,' ')),
                        (lpad((coalesce(col('routing_nbr'),lit(''))),9,'0')),
                        lit(':'),
                        (lpad((coalesce(col('check_info'),lit(' '))),32,' ')),
                        (lpad((coalesce(col('selling_price'),lit(' '))),8,' ')),
                        (lpad(lit(' '),1,' ')),
                        lit('    '),
                        (lpad((coalesce(col('entry_mode'),lit(' '))),1,' ')),
                        lpad(lit(' '),18,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

df_check_deselect = dfTender_join.where(~(col('LineItem.Tender.TenderID').isin('29','30')))\
.withColumn('RetailTransaction_LineItem_Tender_TypeCode',col('LineItem.Tender._TypeCode'))\
.withColumn('RetailTransaction_LineItem_Tender_TenderType',col('LineItem.Tender._TenderType'))\
.withColumn('RetailTransaction_LineItem_Tender_TenderID',col('LineItem.Tender.TenderID'))\
.withColumn('RetailTransaction_LineItem_Tender_Amount',col('LineItem.Tender.Amount._VALUE'))\
.withColumn('RetailTransaction_LineItem_Tender_pcms_PCMSTender',col('LineItem.Tender.pcms:PCMSTender'))\
.withColumn('RetailTransaction_LineItem_Tender_GiftCard',col('LineItem.Tender.GiftCard'))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_PointsRedeemed',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_LoyaltyProgram.value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_LoyaltyProgram_LoyaltyAccountID',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_LoyaltyProgram_LoyaltyProgramID',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_HostAuthorized',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_pcms_AuthorizedOnline',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_AuthorizationCode',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_AuthorizingTermID',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_CardType',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_ExpirationDate',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_ServiceCode',lit('')).drop('ej_code')
#df_check_deselect.count() 5835169

df_select_tender_change=dfTender_join.where(col('LineItem.Tender.TenderChange.TenderID').isNotNull()).drop('ej_code')

df_select_tender_change_lookup= df_select_tender_change.join(df_nextgenlkp,df_nextgenlkp.code==df_select_tender_change.LineItem.Tender.TenderID,'left').select(df_select_tender_change['*'],df_nextgenlkp['code_desc']).where(col('code_desc')=='GIFT CARD')\
.withColumn('RetailTransaction_LineItem_Tender_TypeCode',lit("Refund"))\
.withColumn('RetailTransaction_LineItem_Tender_TenderType',col('LineItem.Tender.TenderChange._TenderType'))\
.withColumn('RetailTransaction_LineItem_Tender_TenderID',col('LineItem.Tender.TenderChange.TenderID'))\
.withColumn('RetailTransaction_LineItem_Tender_Amount',col('LineItem.Tender.Amount._VALUE'))\
.withColumn('RetailTransaction_LineItem_Tender_pcms_PCMSTender',col('LineItem.Tender.pcms:PCMSTender'))\
.withColumn('RetailTransaction_LineItem_Tender_GiftCard',col('LineItem.Tender.TenderChange.GiftCard'))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_PointsRedeemed',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_LoyaltyProgram.value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_LoyaltyProgram_LoyaltyAccountID',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_LoyaltyRedemption_LoyaltyProgram_LoyaltyProgramID',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_HostAuthorized',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_pcms_AuthorizedOnline',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_AuthorizationCode',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_Authorization_AuthorizingTermID',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_value',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_CardType',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_ExpirationDate',lit(''))\
.withColumn('RetailTransaction_LineItem_Tender_CreditDebit_ServiceCode',lit('')).drop('code_desc')
#df_select_tender_change_lookup.count() 0

df_merge_checkDeselect_tender = df_check_deselect.unionByName(df_select_tender_change_lookup)
#df_merge_checkDeselect_tender.count() 5835196

#Siri
#Process FS

df_C_NotCheck=df_merge_checkDeselect_tender.withColumn('tmp_txn_type_flag',when((col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken').isNotNull()) & (length(trim(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken')))>0),lit('T')).otherwise(None))

df_nextgenlkp_Tender=df_nextgenlkp.filter(col('code_name')=='Tender')

df_C_NotCheck=df_C_NotCheck.join(df_nextgenlkp_Tender,df_C_NotCheck.LineItem.Tender.TenderID==df_nextgenlkp_Tender.code,'left')\
.select(df_C_NotCheck['*'],df_nextgenlkp_Tender.code_desc)\
.withColumn('tender',col('code_desc'))\
.withColumn('tmp_txn_type_flag',when((col('tender').isNotNull()) & (upper(col('tender'))=='D EPP MFGCPN'),lit(None)).otherwise(col('tmp_txn_type_flag')))\
.withColumn('unused',when(col('tmp_txn_type_flag')=='T',lit('T')).otherwise(None))\
.withColumn('tender_type',when((upper(col('tender'))=='WCARD') & (col('LineItem.wag:WCardPlanID').isNotNull()), concat(col('tender'),lit('-'),col('LineItem.wag:WCardPlanID'))).otherwise(col('tender')))\
.withColumn('account_nbr',when((upper(col('tender'))=='GIFT CARD') | (upper(col('tender'))=='W CARD'),col('LineItem.Tender.GiftCard.CardNumber'))
           .when((upper(col('tender'))=='MFG COUPON') | (upper(col('tender'))=='D MFG COUPON') | (upper(col('tender'))=='D EPP MFGCPN'),col('LineItem.Tender.Coupon.PrimaryLabel'))
           .when(upper(col('tender'))=='CASH',lit(None))
           .when((upper(col('tender'))=='CREDIT CARD') | (upper(col('tender'))=='DEBIT CARD'),when((length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))>=12) & (length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))<=19),col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken')))
           .when((upper(col('tender'))=='MEDAGATE'),when((length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))>=12) & (length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))<=19),col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken')))
           .when((length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))>=12) & (length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))<=19),col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken')).otherwise(lit(None)))\
.withColumn('expiration_date',when((col('LineItem.wag:ExpiryDate').isNotNull()) & (~(col('LineItem.wag:ExpiryDate').rlike('\D+'))) & (length(col('LineItem.wag:ExpiryDate'))==4),col('LineItem.wag:ExpiryDate')).otherwise(col('LineItem.Tender.CreditDebit.ExpirationDate')))\
.withColumn('selling_price',col('LineItem.Tender.Amount._VALUE'))\
.withColumn('unused2',when((col('tmp_txn_type_flag')=='T') & (upper(col('tender'))!='CASH') &(length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))>=12) & (length(col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken'))<=19),col('LineItem.Tender.pcms:PCMSTender.pcms:PANToken')).otherwise(lit(None)))\
.withColumn('price_sign',when((upper(col('LineItem.Tender._TypeCode'))=='REFUND') | ((upper(col('tender'))=='CASH') & (col('tmp_txn_type_flag')=='T')),lit('-')))\
.withColumn('sequence_nbr',col('LineItem_SequenceNumber')).drop('code_desc')

df_nextgenlkp_Entry=df_nextgenlkp.filter(col('code_name')=='TenderEntryMode')

df_C_NotCheck=df_C_NotCheck.join(df_nextgenlkp_Entry,df_C_NotCheck.LineItem._EntryMethod==df_nextgenlkp_Entry.code_desc,'left')\
.select(df_C_NotCheck['*'],df_nextgenlkp_Entry.ej_code)\
.withColumn('entry_mode',when((upper(col('LineItem._EntryMethod'))=='MSR') | (upper(col('LineItem._EntryMethod'))=='SCANNED'),lit('S'))
            .when(upper(col('LineItem._EntryMethod'))=='KEYED',lit('K'))
            .when(col('ej_code').isNotNull(),col('ej_code')))\
.withColumn('rcd_type',lit('C')).withColumn('entry_mode_old',lit(''))\
.select('record_nbr','sequence_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','tender_type','account_nbr','entry_mode_old','expiration_date','unused2','selling_price','price_sign','entry_mode','unused')

#df_C_NotCheck.count() 5835169

#Select Debit Card

df_Debit_Card=df_merge_checkDeselect_tender.join(df_nextgenlkp_Tender,df_merge_checkDeselect_tender['LineItem.Tender.TenderID']==df_nextgenlkp_Tender.code,'left').select(df_merge_checkDeselect_tender['*'],df_nextgenlkp_Tender.ej_code,df_nextgenlkp_Tender.code_desc)\
.filter((col('LineItem.Tender.Cashback').isNotNull()) & (~(col('LineItem.Tender.Cashback').rlike('\D+'))) & (col('code_desc').isNotNull()) & (upper(col('code_desc'))=='DEBIT CARD'))\
.withColumn('tender_type',lit('CASH')).withColumn('selling_price',col('LineItem.Tender.Cashback'))\
.withColumn('price_sign',lit('-')).withColumn('sequence_nbr',col('LineItem_SequenceNumber')).withColumn('expiration_date',lit(''))\
.withColumn('rcd_type',lit('C')).withColumn('entry_mode_old',lit('')).withColumn('account_nbr',lit(''))\
.withColumn('unused2',lit(None))\
.withColumn('unused',lit(None))\
.withColumn('entry_mode',lit('')).withColumn('selling_price',lit(''))\
.select('record_nbr','sequence_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','tender_type','account_nbr','entry_mode_old','expiration_date','unused2','selling_price','price_sign','entry_mode','unused')

#df_Debit_Card.count() 60244

#Token Merge
df_token=df_C_NotCheck.union(df_Debit_Card)\

#print(df_token.count()) #5895413

#Filter
df_token_select=df_token.filter((col('unused2').isNotNull()) & (length(trim(col('unused2')))>0))
#df_token_select.count() 3452391

df_token_unselect=df_token.filter(~((col('unused2').isNotNull()) & (length(trim(col('unused2')))>0 )))
#df_token_unselect.count() 2443022

#Reformat Prioritize token value over default
df_token_select=df_token_select.withColumn('default_token_flag',when(ltrim(col('unused2'))=='999999A9999999B9999',lit('Y'))\
                                            .otherwise(lit('N')))\
.withColumn('tender_type',ltrim(col('tender_type')))\

#Dedup Sorted Txn Remove default Token
wspec = Window.partitionBy('str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','tender_type','sequence_nbr','selling_price').orderBy('default_token_flag')
df_token_dedup = df_token_select.withColumn('row_num',row_number().over(wspec))
df_token_dedup_out = df_token_dedup.where(col('row_num')==1).drop('row_num','default_token_flag')
#df_token_dedup_out.count()3440530
df_token_dedup_dups = df_token_dedup.where(col('row_num')!=1).drop('row_num')
#df_token_dedup_dups.count() 11861

#FBE: Filter valid token
df_token_select_fbe=df_token_dedup_dups.filter(col('default_token_flag')=='N')\
.drop('default_token_flag')
#df_token_select_fbe.count() 8451
df_dup_token=df_token_dedup_dups.filter(col('default_token_flag')=='Y')
#df_dup_token.count() 3410

#Dups token file
dups_token_path = mountPoint + "/"  + dbutils.widgets.get('PAR_NB_RT_RFN_OUTPUT_FILE_PATH')[0:(len(dbutils.widgets.get('PAR_NB_RT_RFN_OUTPUT_FILE_PATH')) - ((dbutils.widgets.get('PAR_NB_RT_RFN_OUTPUT_FILE_PATH'))[::-1]).find('/'))] + 'poslog_dup_txns_with_default_token_FS' + '/' + dbutils.widgets.get('PAR_PL_BATCH_ID')
df_dup_token.write.format('parquet').mode("overwrite").save(dups_token_path)
#print(dups_token_path)

#Gather
df_encrypt=df_token_select_fbe.union(df_token_unselect).union(df_token_dedup_out)
#df_encrypt.count() 5892003

#Select encrypted cards number for decryption
df_encrypt_select=df_encrypt.filter(((length(ltrim(col('account_nbr')))>11) & (length(ltrim(col('account_nbr')))<20)) | ((col('expiration_date').isNotNull()) & (length(ltrim(col('expiration_date')))==4)))
#df_encrypt_select.count() 3620874
df_encrypt_deselect = df_encrypt.where(((col('account_nbr').isNull()) | (length(trim(col('account_nbr')))<=11) | (length(ltrim(col('account_nbr')))>=20)) & ((col('expiration_date').isNull()) | (length(trim(col('expiration_date')))!=4)))
#df_encrypt_deselect.count() 2271129

#Reformat - Added Sur-Key for Decrypt
wspec = Window.orderBy('str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','tender_type','sequence_nbr','selling_price')
df_encrypt_select=df_encrypt_select.withColumn('sur_key',row_number().over(wspec))

#Filter PanToken with out default token
df_PanToken = df_encrypt_select.where((col('unused') == 'T') & (~(trim(col('unused2')).eqNullSafe('999999A9999999B9999'))))
#df_PanToken.count() 3461586

#Validate PANToken
df_validate_PANToken=df_PanToken.filter((col('unused2').isNotNull()) & (length(trim(col('unused2'))) >=12) & (length(trim(col('unused2'))) <=19) & ((trim(col('unused2')).rlike('^[A-Z0-9]*$'))) & (~((trim(col('unused2')).rlike('^[0-9]*$')))) & (~((trim(col('unused2')).rlike('^[A-Z]*$')))))
#df_validate_PANToken.count() 3448788
df_validate_PANToken_deselect =df_PanToken.filter(~(((col('unused2').isNotNull()) & (length(trim(col('unused2'))) >=12) & (length(trim(col('unused2'))) <=19) & ((trim(col('unused2')).rlike('^[A-Z0-9]*$'))) & (~((trim(col('unused2')).rlike('^[0-9]*$')))) & (~((trim(col('unused2')).rlike('^[A-Z]*$')))))))
#df_validate_PANToken_deselect.count() #12798

#Join rejected PANToken
df_invalid_encrypt=df_encrypt_select.join(df_validate_PANToken_deselect,df_encrypt_select.sur_key==df_validate_PANToken_deselect.sur_key,'inner').select(df_encrypt_select['*'])
#df_invalid_encrypt.count() 12798

#Write invalid pan token
invalid_token_path=mountPoint + "/"  + dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID')[0:(len(dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID')) - ((dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID'))[::-1]).find('/'))] + 'poslog_Invalid_Token' + '/' + dbutils.widgets.get('PAR_PL_BATCH_ID')
df_invalid_encrypt.write.format('parquet').mode("overwrite").save(invalid_token_path)

#Rfmt: Assign NULL to accnt_nbr and unused2 for rejected tokens-1
for c in df_invalid_encrypt.columns:
  df_invalid_encrypt = df_invalid_encrypt.withColumnRenamed(c,'b_'+c)
df_encrypt_select_fs=df_encrypt_select.join(df_invalid_encrypt,df_invalid_encrypt.b_sur_key==df_encrypt_select.sur_key,'left').select(df_encrypt_select['*'],df_invalid_encrypt.b_sur_key.alias('sur_key2'))\
.withColumn('unused2',when(col('sur_key2').isNotNull(),lit(None)).otherwise(col('unused2')))\
.withColumn('account_nbr',when(col('sur_key2').isNotNull(),lit(None)).otherwise(col('account_nbr')))\
.drop('sur_key','sur_key2')
#df_encrypt_deselect

#Merge
df_Fs=df_encrypt_select_fs.unionByName(df_encrypt_deselect)
#df_Fs.count() 5892003

#Reformat
df_Fs=df_Fs.withColumn('account_nbr',when(col('unused2').isNotNull(),lit('')).otherwise(substring(col('account_nbr'),1,25)))\
.withColumn('unused3',col('sequence_nbr'))\
.withColumn('expiration_date',when((length(trim(col('expiration_date')))==7),col('expiration_date'))
            .when((length(trim(col('expiration_date')))==5),col('expiration_date'))
            .when((length(trim(col('expiration_date')))==4),col('expiration_date')))

##########################Process Manufacture Coupon and Store Use Only##################################
#Select - Separate Manufacture Coupn from other Tenders
df_Fs_Select=df_Fs.filter((~(trim(col('tender_type')).eqNullSafe('D MFG COUPON'))) & (~(trim(col('tender_type')).eqNullSafe('MFG COUPON'))) & (~(trim(col('tender_type')).eqNullSafe('D EPP MFGCPN'))))
#df_Fs_Select.count()5757083

df_Fs_unselect=df_Fs.exceptAll(df_Fs_Select)
#df_Fs_unselect.count() 134920

#Select - Separate Store Use Only
df_Fs_Select_sep_only=df_Fs_Select.filter(~(upper(col('tender_type')).eqNullSafe('STOREUSEONLY')))\
.withColumn('detail_nbr',lit('999')).withColumn('detail_type',lit('9')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('EJ',concat((lpad((coalesce(col('tender_type'),lit(' '))),12,' ')),
                        (lpad((coalesce(col('account_nbr'),lit(' '))),25,' ')),
                        (lpad((coalesce(col('entry_mode_old'),lit(' '))),1,' ')),
                        (lpad((coalesce(col('expiration_date'),lit(' '))),4,' ')),
                        (lpad((coalesce(col('unused2'),lit(' '))),19,' ')),lpad(lit(' '),2,' '),
                        (lpad((coalesce(col('selling_price'),lit(' '))),8,' ')),
                        (lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),
                        (lpad((coalesce(col('entry_mode'),lit(' '))),1,' ')),lpad(lit(' '),7,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_Fs_Select_sep_only.count() 5757083

df_Fs_UnSelect_sep_only=df_Fs_Select.exceptAll(df_Fs_Select.filter(~(upper(col('tender_type')).eqNullSafe('STOREUSEONLY'))))\
.withColumn('upc_or_tender',lit('000000009393')).withColumn('rcd_type',lit('A'))\
.withColumn('desc_or_acct_nbr',lit('S/S EXPENSE')).withColumn('item_cost',lit('0')).withColumn('item_unit_cost',lit('0'))\
.withColumn('dept_nbr',lit('393')).withColumn('quantity',lit('1'))\
.withColumn('keyed_item',when(col('entry_mode')=='K',lit('K')))\
.withColumn('price_sign',when(length(trim(col('price_sign')))==0,lit('-'))
           .when(col('price_sign')=='-',lit(' ')))\
.withColumn('detail_nbr',lit('999')).withColumn('detail_type',lit('9')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),
                        (lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),
                        (lpad((coalesce(col('item_cost'),lit('     0'))),6,' ')),
                        (lpad((coalesce(col('item_unit_cost'),lit('      0'))),4,' ')),
                        (lpad((coalesce(col('dept_nbr'),lit('  0'))),3,' ')),
                        (lpad((coalesce(col('quantity'),lit('    0'))),5,' ')),lpad(lit(' '),1,' '),
                        (lpad((coalesce(col('selling_price'),lit('      .00'))),8,' ')),
                        (lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),lpad(lit(' '),4,' '),
                        (lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),lpad(lit(' '),14,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#df_Fs_UnSelect_sep_only.count() 0

#Manufacture Coupon Only
df_Fs_unselect_coup_only_select=df_Fs_unselect.withColumn('rcd_type',lit('A'))\
.withColumn('upc_or_tender',when((length(trim(col('account_nbr')))!=0) & (col('account_nbr').isNotNull()),
                                lpad(substring(trim('account_nbr'),2,12),12,' ')).otherwise(lit('NO UPC FOUND')))\
.withColumn('desc_or_acct_nbr',when(trim(col('tender_type'))=='MFG COUPON',lit('  MFG COUPON      '))
            .when(trim(col('tender_type'))=='D MFG COUPON',lit('D MFG COUPON'))
           .otherwise('D EPP MFGCPN'))\
.withColumn('item_cost',lit('0')).withColumn('item_unit_cost',lit('0'))\
.withColumn('dept_nbr',lit('0')).withColumn('quantity',lit('1'))\
.withColumn('keyed_item',when(col('entry_mode')=='K',lit('K'))
           .when((col('entry_mode')!='S') & (length(trim(col('account_nbr')))==0),lit('K'))
           .when((col('entry_mode')!='S') & (substring(col('account_nbr'),2,12)=='NO UPC FOUND'),lit('K'))
           .when((col('entry_mode')!='S') & (col('account_nbr').isNotNull()),lit('K')).otherwise(col('entry_mode')))\
.withColumn('special',when(col('tender_type')=='MFG COUPON',lit('O'))
           .when(col('tender_type')=='D MFG COUPON',lit('D')).otherwise(lit('P')))\
.withColumn('price_sign',when(length(trim(col('price_sign')))==0,lit('-'))
            .when(col('price_sign')=='-',lit(' ')))
#df_Fs_unselect_coup_only_select.count() 134920

#EJ File
df_Fs_coup_EJ=df_Fs_unselect_coup_only_select.withColumn('detail_nbr',lit('999')).withColumn('detail_type',lit('9')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),
                        (lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),
                        (lpad((coalesce(col('item_cost'),lit('     0'))),6,' ')),
                        (lpad((coalesce(col('item_unit_cost'),lit('      0'))),4,' ')),
                        (lpad((coalesce(col('dept_nbr'),lit('  0'))),3,' ')),
                        (lpad((coalesce(col('quantity'),lit('    0'))),5,' ')),lpad(lit(' '),1,' '),
                        (lpad((coalesce(col('selling_price'),lit('      .00'))),8,' ')),
                        (lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),lpad(lit(' '),3,' '),
                        (lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),lpad(lit(' '),4,' '),
                        (lpad((coalesce(col('special'),lit(' '))),1,' ')),lpad(lit(' '),9,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

df_FS_FINAL=df_Fs_Select_sep_only.unionByName(df_Fs_UnSelect_sep_only).unionByName(df_Fs_coup_EJ)
#df_FS_FINAL.count() 5892003

# COMMAND ----------

#Puspak
#union the lineitems

df_lineitem_union = df_lineitem_priceverify.unionByName(dfSale_E0027).unionByName(dfSale_E0000).unionByName(dfSale_AgeRes).unionByName(df_ProcessA).unionByName(dfReturn_E0006).unionByName(dfReturn_upc).unionByName(dfReturn_TaxJoin).unionByName(dfTax_transform2).unionByName(dfMailCheck_E0007).unionByName(df_check_select).unionByName(df_FS_FINAL)

#display(df_lineitem_union)

#df_lineitem_union.count()

# COMMAND ----------

# Siri
#Process D

df_Process_D_input=df_Fs_unselect_coup_only_select

wspec1 = Window.partitionBy('str_nbr','txn_date','register_nbr','txn_nbr','record_nbr')

df_Process_D_input=df_Process_D_input.withColumn('selling_price_final',when(col('price_sign')!='-',col('selling_price')* -1).otherwise(col('selling_price')))\
.withColumn('selling_price',sum(col('selling_price_final')).over(wspec1))\

df_split_Process_D=df_split.filter(col('txn_type')!='25')\
.withColumn('const_total_type',lit('TransactionGrandAmount'))\
.withColumn('RetailTransaction_Total',expr("""(filter(RetailTransaction.Total,x-> x._TotalType=='TransactionGrandAmount'))[size(filter(RetailTransaction.Total,x-> x._TotalType=='TransactionGrandAmount'))-1]"""))\
.withColumn('RetailTransaction_Total_value',when(col('RetailTransaction_Total').isNotNull(),col('RetailTransaction_Total._VALUE'))
            .otherwise(lit(None)))\
.withColumn('RetailTransaction_Total_TotalType',when(col('RetailTransaction_Total').isNotNull(),col('const_total_type'))
            .otherwise(lit(None)))\
.withColumn('RetailTransaction_Total_NegativeValue',when(col('RetailTransaction_Total').isNotNull(),col('RetailTransaction_Total._NegativeValue'))
            .otherwise(lit(None)))\
.filter(length(trim(col('RetailTransaction_Total_TotalType')))!=0)\
.withColumn('selling_price',col('RetailTransaction_Total_value'))\
.withColumn('price_sign',when(upper(col('RetailTransaction_Total_NegativeValue'))=='TRUE',lit('-')))

#df_split_Process_D.count() #5413384

#Join

df_Process_D_Join=df_split_Process_D.join(df_Process_D_input,((df_Process_D_input.str_nbr==df_split_Process_D.str_nbr) & (df_Process_D_input.txn_date==df_split_Process_D.txn_date) & (df_Process_D_input.register_nbr==df_split_Process_D.register_nbr) & (df_Process_D_input.txn_nbr==df_split_Process_D.txn_nbr) & (df_Process_D_input.cashier_nbr==df_split_Process_D.cashier_nbr) & (df_Process_D_input.txn_type==df_split_Process_D.txn_type) & (df_Process_D_input.txn_time==df_split_Process_D.txn_time) & (df_Process_D_input.record_nbr==df_split_Process_D.record_nbr)),'leftOuter').select(df_split_Process_D['*'])\
.filter((col('str_nbr').isNotNull()) & (col('txn_date').isNotNull()) & (col('register_nbr').isNotNull()) & (col('txn_nbr').isNotNull()))\
.sort(['str_nbr','txn_date','record_nbr'])\
.dropDuplicates(['str_nbr','txn_date','register_nbr','txn_date','record_nbr'])

df_Process_D=df_Process_D_Join.withColumn('sequence_nbr',lit('9999')).withColumn('bogo_seq_nbr',lit('0'))\
.withColumn('rcd_type',lit('E')).withColumn('total_ind',lit('TOTAL'))\
.withColumn('EJ',concat((lpad((coalesce(col('total_ind'),lit(' '))),5,' ')),lpad(lit(' '),43,' '),
                        (lpad((coalesce(col('selling_price'),lit('      .00'))),8,' ')),
                        (lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),lpad(lit(' '),23,' ')))\
.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#df_Process_D.count()
# 5413384

# COMMAND ----------

## Vamshi's Changes - Corrected logic
### Brand Rebate
dfBrandRebate=df_split.withColumn('LineItem',explode(col('RetailTransaction.LineItem'))) 

dfBrandRebate=dfBrandRebate.filter((col('LineItem.Tender.TenderID')=='187') & (col('LineItem.Tender.GiftCard.CardNumber').isNotNull()) & ((col('LineItem.wag:WCardPlanID') == '27') | (col('LineItem.wag:WCardPlanID').isNull())) & (col('LineItem.Tender._TypeCode')=='Refund'))

dfBrandRebate=dfBrandRebate.orderBy(col('rfn').asc())
dfBrandRebate=dfBrandRebate.dropDuplicates(['rfn'])

dfBrandRebate=dfBrandRebate \
.withColumn('tmp_rebate_amt',expr("""(filter(RetailTransaction.Total,x-> (x._TotalType)=='pcms:LoyaltyPointsEarned'))[size(filter(RetailTransaction.Total,x-> (x._TotalType)=='pcms:LoyaltyPointsEarned'))-1]""")['_VALUE']) \
.withColumn('tmp_rate_of_rebate',expr("""(filter(RetailTransaction.Total,x-> (x._TotalType)=='pcms:LoyaltyPointsBonus')) [size(filter(RetailTransaction.Total,x-> (x._TotalType)=='pcms:LoyaltyPointsBonus'))-1]""")['_VALUE']) \
.withColumn('account_nbr',col('LineItem.Tender.GiftCard.CardNumber')) \
.withColumn('rebate_info',when((col('tmp_rate_of_rebate')>0) & ((col('tmp_rate_of_rebate')/100) < 100),concat((col('tmp_rebate_amt')/100),lit(":P:"),(col('tmp_rate_of_rebate')/100))).otherwise(concat((col('tmp_rebate_amt')/100),lit(":A:"),(col('tmp_rebate_amt')/100)))) \
.withColumn('sequence_nbr',lit('9999').cast(IntegerType())) \
.withColumn('bogo_seq_nbr',lit('0').cast(IntegerType())) \
.withColumn('rcd_type',lit('E').cast(StringType())) \
.withColumn('e_record_type',lit('0026').cast(StringType())) \
.withColumn('EJ',concat(lit('0026'),lit(':'),lit('W CARD-27'),lit(':'),(lpad((coalesce(col('account_nbr'),lit(' '))),19,' ')),lit(':'),(lpad((coalesce(col('rebate_info'),lit(' '))),31,' ')),lpad(lit(' '),14,' ')))
                                                  
dfBrandRebate=dfBrandRebate.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

# COMMAND ----------

##Tax Exempt  #Sakina modified
df_taxexempt = df_split.withColumn('tmp_desc_or_acct_nbr',expr("""(filter(RetailTransaction.Customer,x-> x.TaxCertificate IS NOT NULL))[size(filter(RetailTransaction.Customer,x-> x.TaxCertificate IS NOT NULL))-1]"""))\
                     .filter(col('tmp_desc_or_acct_nbr.TaxCertificate').isNotNull()) \
                     .withColumn('desc_or_acct_nbr', col('tmp_desc_or_acct_nbr.TaxCertificate')) \
                     .withColumn('upc_or_tender',lit('TAX NUMBER').cast(StringType()))\
                     .withColumn('item_cost',lit(None).cast(StringType()))\
                     .withColumn('item_unit_cost',lit(None).cast(StringType()))\
                     .withColumn('dept_nbr',lit(None).cast(StringType())).withColumn('quantity',lit(None).cast(StringType()))\
                     .withColumn('selling_price',lit(None).cast(StringType())).withColumn('rcd_type',lit('A').cast(StringType()))\
                     .withColumn('sequence_nbr',lit('9999').cast(StringType()))\
                     .withColumn('price_sign',lit(None).cast(StringType())).withColumn('bogo_seq_nbr',lit('0').cast(StringType()))\
                     .withColumn('sale_indicator',lit(None).cast(StringType()))\
                     .withColumn('wag_coupon',lit(None).cast(StringType()))\
                     .withColumn('discount_mode',lit(None).cast(StringType()))\
                     .withColumn('item_void',lit(None).cast(StringType())).withColumn('tax_type',lit(None).cast(StringType()))\
                     .withColumn('keyed_item',lit(None).cast(StringType()))\
                     .withColumn('returned_item',lit(None).cast(StringType()))\
                     .withColumn('price_modify',lit(None).cast(StringType()))\
                     .withColumn('price_verify',lit(None).cast(StringType()))\
                     .withColumn('training_item',lit(None).cast(StringType())).withColumn('special',lit(None).cast(StringType()))\
                     .withColumn('unused5',lit(None).cast(StringType()))\
                     .withColumn('EJ',concat((lpad((coalesce(col('upc_or_tender'),lit(' '))),12,' ')),(lpad((coalesce(col('desc_or_acct_nbr'),lit(' '))),18,' ')),(lpad((coalesce(col('item_cost'),lit('0'))),6,' ')),(lpad((coalesce(col('item_unit_cost'),lit('0'))),7,' ')),(lpad((coalesce(col('dept_nbr'),lit('0'))),3,' ')),(lpad((coalesce(col('quantity'),lit('0'))),5,' ')),(lpad((coalesce(col('tax_type'),lit(' '))),1,' ')),(lpad((coalesce(col('selling_price'),lit('.00'))),8,' ')),(lpad((coalesce(col('price_sign'),lit(' '))),1,' ')),(lpad((coalesce(col('sale_indicator'),lit(' '))),1,' ')),(lpad((coalesce(col('wag_coupon'),lit(' '))),1,' ')),(lpad((coalesce(col('discount_mode'),lit(' '))),1,' ')),(lpad((coalesce(col('item_void'),lit(' '))),1,' ')),(lpad((coalesce(col('keyed_item'),lit(' '))),1,' ')),(lpad((coalesce(col('returned_item'),lit(' '))),1,' ')),(lpad((coalesce(col('price_modify'),lit(' '))),1,' ')),(lpad((coalesce(col('price_verify'),lit(' '))),1,' ')),(lpad((coalesce(col('training_item'),lit(' '))),1,' ')),(lpad((coalesce(col('special'),lit(' '))),1,' ')),(lpad((coalesce(col('unused5'),lit(' '))),9,' ')))).drop('tmp_desc_or_acct_nbr')
                     
df_taxexempt=df_taxexempt.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

#df_taxexempt.select('EJ').show(truncate=False)

# COMMAND ----------

#Sakina
#### Customer survey Info E0017

dfsurvey_E0017 = df_split.withColumn('tmp_RetailTransaction_Reason',expr("""(filter(RetailTransaction['pcms:PCMSEvent'],x-> ((substring(x['pcms:ApplicationEvent'] ,1,25) == "Customer Survey Printed: ") and ((substring(trim(x['pcms:ApplicationEvent']),-2,2)) >= "21") and (substring(trim(x['pcms:ApplicationEvent']),-2,2) <= "25"))))[size(filter(RetailTransaction['pcms:PCMSEvent'],x-> ((substring(x['pcms:ApplicationEvent'] ,1,25) == "Customer Survey Printed: ") and ((substring(trim(x['pcms:ApplicationEvent']),-2,2)) >= "21") and (substring(trim(x['pcms:ApplicationEvent']),-2,2) <= "25"))))-1]"""))\
                      .withColumn('RetailTransaction_Reason', col('tmp_RetailTransaction_Reason.pcms:ApplicationEvent'))\
                      .filter(col('RetailTransaction_Reason').isNotNull()) \
                      .withColumn('tmp_RetailTransaction_Total',expr("""(filter(RetailTransaction.Total,x-> upper(x._TotalType) == "TRANSACTIONGRANDAMOUNT"))[size(filter(RetailTransaction.Total,x-> upper(x._TotalType) == "TRANSACTIONGRANDAMOUNT"))-1]"""))\
                      .withColumn('tmp_total_value',col('tmp_RetailTransaction_Total._VALUE'))\
                      .withColumn('service_area',col('workstation_location'))\
                      .withColumn('transaction_amount',(col('tmp_total_value')*100).cast(DecimalType(8,2)))\
                      .withColumn('temp_reason',substring(col('RetailTransaction_Reason'),7,2))\
                      .withColumn('survey_inf',concat(col('temp_reason'),lit(':'),col('rfn'),(col('temp_reason')),lit(':')))\
                      .withColumn('sequence_nbr',lit('9999').cast(IntegerType()))\
                      .withColumn('bogo_seq_nbr',lit('0').cast(IntegerType()))\
                      .withColumn('rcd_type',lit('E').cast(StringType()))\
                      .withColumn('EJ',concat(lit('0017'),lit(':'),lit('2'),lit(':'),(lpad((coalesce(col('service_area'),lit(' '))),2,' ')),lit(':'),(lpad((coalesce(col('transaction_amount'),lit(' '))),8,' ')),lit(':'),(lpad((coalesce(col('survey_inf'),lit(' '))),48,' ')),lpad(lit(' '),13,' '))).drop('tmp_RetailTransaction_Reason','tmp_RetailTransaction_Total')
                      
dfsurvey_E0017 = dfsurvey_E0017.select('record_nbr','detail_nbr','detail_type'\
                                                          ,'sequence_nbr','bogo_seq_nbr','str_nbr'\
                                                          ,'txn_date','txn_time','cashier_nbr','register_nbr'\
                                                          ,'txn_type','txn_nbr','rcd_type','EJ')

# COMMAND ----------

## Vamshi's Changes - Corrected logic
###Customer 
dfcust_E010=df_split.filter(col('RetailTransaction.Customer.LocalRequirements').isNotNull() & ((size (col('RetailTransaction.Customer.LocalRequirements')))>1))

dfcust_E010 = dfcust_E010 \
                    .withColumn('Customer',explode(col('RetailTransaction.Customer')))\
                    .withColumn('LocalRequirements',explode(col('Customer.LocalRequirements')))\
                    .withColumn('LocalRequirements_Name',explode(col('LocalRequirements.Name')))\
                    .withColumn('tmp_name_value',upper(col('LocalRequirements_Name._VALUE')))\
                    .withColumn('spot_info',when((col('tmp_name_value')=="ZIPCODE") | (col('tmp_name_value')=="PHONENUMBER"), substring((concat(coalesce(col('LocalRequirements._VALUE'),lit('')),lit(':').cast(StringType()))),1,61)))\
                    .withColumn('sequence_nbr',lit('9999').cast(IntegerType()))\
                    .withColumn('bogo_seq_nbr',lit('0').cast(IntegerType()))\
                    .withColumn('rcd_type',lit('E').cast(StringType()))\
                    .withColumn('EJ',concat(lit('0010'),lit(':'),(lpad((coalesce(col('spot_info'),lit(' '))),61,' ')),lpad(lit(' '),14,' ')))\
                   .filter(col('spot_info').isNotNull())

dfcust_E010=dfcust_E010.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')
#dfcust_E010.select('LocalRequirements._VALUE','LocalRequirements_Name._VALUE','spot_info','EJ').show(truncate=False)

# COMMAND ----------

## Vamshi's Changes - Corrected logic
#Takecare
#############################FOR TESTING#######################################################
try:
  df_split = df_split.withColumn('pcms:PCMSTransaction_wag:LoyaltyAccountID',col('pcms:PCMSTransaction.wag:LoyaltyAccountID'))
except:
  df_split = df_split.withColumn('pcms:PCMSTransaction_wag:LoyaltyAccountID',lit(None))
  ##################################################################################################

df_takecare=df_split.filter(col('pcms:PCMSTransaction_wag:LoyaltyAccountID').isNotNull()) \
.withColumn('temp_col_a',expr("""transform(RetailTransaction.LineItem.Sale.RetailPriceModifier,x->transform(x,y->y.ReasonCode))"""))\
.withColumn('temp_col_b',flatten(expr("""filter(temp_col_a,x->x IS NOT NULL)"""))) \
.withColumn('discount_find',expr("""(filter(temp_col_b,x-> substring(x,1,2)=='1:'))[size(filter(temp_col_b,x-> substring(x,1,2)=='1:'))-1]""")) \
.withColumn('discount_upc',substring(col('pcms:PCMSTransaction_wag:LoyaltyAccountID'),3,12)) \
.withColumn('name_brand_discount_rate',when(~(col('pcms:PCMSTransaction.wag:DiscountRateNonWAGBrand').rlike('\D+')),lpad((col('pcms:PCMSTransaction.wag:DiscountRateNonWAGBrand')*10).cast(IntegerType()),3,' '))) \
.withColumn('w_brand_discount_rate',when(~(col('pcms:PCMSTransaction.wag:DiscountRateWAGBrand').rlike('\D+')),lpad((col('pcms:PCMSTransaction.wag:DiscountRateWAGBrand')*10),3,' ')))

df_takecare=df_takecare.join(df_nextgenlkp,df_takecare.discount_find==df_nextgenlkp.code,'left_outer')\
                       .withColumn('discount_name',when(col('discount_find').isNotNull() & (col('discount_find')==col('code')),concat(col('ej_code'),lit(':').cast(StringType())))
                                  .otherwise(lit(None).cast(StringType())))\
                       .withColumn('sequence_nbr',lit('9999').cast(IntegerType()))\
                       .withColumn('bogo_seq_nbr',lit('0').cast(IntegerType()))\
                       .withColumn('rcd_type',lit('E').cast(StringType()))\
                       .withColumn('EJ',concat(lit('0062'),lit(':'),(lpad((coalesce(col('discount_upc'),lit(' '))),12,' ')),lit(':'),(lpad((coalesce(col('name_brand_discount_rate'),lit(' '))),3,' ')),lit(':'),(lpad((coalesce(col('w_brand_discount_rate'),lit(' '))),3,' ')),lit(':'),(lpad((coalesce(col('discount_name'),lit(' '))),41,' ')),lpad(lit(' '),13,' ')))

df_takecare=df_takecare.select('record_nbr','detail_nbr','detail_type','sequence_nbr','bogo_seq_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','EJ')

# COMMAND ----------

#Puspak
#Pack EJ Transaction Records
df_Pack_EJ_txn_rec = df_Process_D.unionByName(dfBrandRebate).unionByName(df_taxexempt).unionByName(dfsurvey_E0017).unionByName(dfcust_E010).unionByName(df_takecare)
#df_Pack_EJ_txn_rec.count() 5415138

# COMMAND ----------

#Puspak
#Merge - Header Records FIRST
df_pos_ej_retail = df_header.unionByName(df_lineitem_union).unionByName(df_Pack_EJ_txn_rec)
#df_pos_ej_retail.count()
#df_header + 

# COMMAND ----------

#dbutils.widgets.text('PAR_NB_POS_EJ_RETAIL','retail/retail_sales/staging/pos_ej_retailtransaction')
pos_ej_retail=mountPoint + "/" + dbutils.widgets.get('PAR_NB_POS_EJ_RETAIL') +'/'+ dbutils.widgets.get('PAR_PL_BATCH_ID')

df_pos_ej_retail.write.format("parquet").mode("overwrite").save(pos_ej_retail)
print(pos_ej_retail)

# COMMAND ----------

pos_post_void_w_origins=mountPoint + "/" + dbutils.widgets.get('PAR_NB_POS_POST_RFNS') +'/'+ dbutils.widgets.get('PAR_PL_BATCH_ID')

df_pospostvoid_origns=spark.read.format('parquet').load(pos_post_void_w_origins)

df_pospostvoid_origns_valid=df_pospostvoid_origns.where((~(col('orig_rfn').rlike('\D+'))) & (~(col('post_void_rfn').rlike('\D+'))))

## Invalid pos_post  
df_pospostvoid_origns_invalid=df_pospostvoid_origns.where(((col('orig_rfn').rlike('\D+'))) | ((col('post_void_rfn').rlike('\D+'))))

post_void_w_origins_invalid_path=mountPoint + "/" + dbutils.widgets.get('PAR_NB_POS_POST_RFNS_INVALID') +'/'+ dbutils.widgets.get('PAR_PL_BATCH_ID')

df_pospostvoid_origns_invalid.write.format("parquet").mode("overwrite").save(post_void_w_origins_invalid_path)

# COMMAND ----------

df_pospostvoid_origns_valid=df_pospostvoid_origns_valid.sort(col('orig_rfn'))

df_Join1=dfRT.join(df_pospostvoid_origns_valid,df_pospostvoid_origns_valid.orig_rfn==dfRT.rfn,'inner').select('orig_rfn','post_void_rfn',col('str_nbr').alias('orig_str_nbr'),col('register_nbr').alias('orig_register_nbr'),col('txn_nbr').alias('orig_txn_nbr'))

df_Join1=df_Join1.sort('post_void_rfn')


####Join2 

df_Join2=dfRT.join(df_Join1,df_Join1.post_void_rfn==dfRT.rfn,'inner').select('orig_rfn','post_void_rfn','orig_str_nbr','orig_register_nbr','orig_txn_nbr',col('str_nbr').alias('pv_str_nbr'),col('register_nbr').alias('pv_register_nbr'),col('txn_nbr').alias('pv_txn_nbr'))

#dbutils.widgets.text('PAR_NB_POS_POST_W_ORIG_INFO','retail/retail_sales/staging/pos_post_void_w_orig_info')
post_void_w_origins_info_path=mountPoint + "/" + dbutils.widgets.get('PAR_NB_POS_POST_W_ORIG_INFO') +'/'+ dbutils.widgets.get('PAR_PL_BATCH_ID')

df_Join2.write.format("parquet").mode("overwrite").save(post_void_w_origins_info_path)


# COMMAND ----------

#df_split.unpersist()
# Databricks notebook source
SCOPE_NAME = "dapdevdatascope"
#dapdevdatascope

# Function to get the secret value based on secret key name from Key Vault
def get_secret(secret_key):
  return dbutils.secrets.get(scope = SCOPE_NAME, key = secret_key)

# Verify all the secret keys associated with your scope name
dbutils.secrets.list(SCOPE_NAME)

#import adal
#pre-requisite: Landing folder of files from on-prem must be mounted before executing the runbook.
#environment = dbutils.widgets.get("env")

#migration_id = 'rvdataextract002202104201229'
environment = 'dev'
environment = environment.strip()

if environment.lower() == 'dev': 
  adlsAccountName = "dapdevadlslnd01"
  adlsContainerName = "landing"
  adlsFolderName = ""
  mountPoint = "/mnt/landing"

  # Application (Client) ID
  applicationId = dbutils.secrets.get(scope="dapdevdataenggscope",key="applicationId")

  # Application (Client) Secret Key
  authenticationKey = dbutils.secrets.get(scope="dapdevdataenggscope",key="devdnaadls")

  # Directory (Tenant) ID
  tenandId = dbutils.secrets.get(scope="dapdevdataenggscope",key="adtenantid")

  endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
  source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

  # Connecting using Service Principal secrets and OAuth
  configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
             "fs.azure.account.oauth2.client.id": applicationId,
             "fs.azure.account.oauth2.client.secret": authenticationKey,
             "fs.azure.account.oauth2.client.endpoint": endpoint}

elif environment.lower() == 'test': 
#elif environment.lower() == 'test':
  adlsAccountName = "daptestadlslnd01"
  adlsContainerName = "landing"
  adlsFolderName = ""
  mountPoint = "/mnt/landing"

  # Application (Client) ID
  applicationId = dbutils.secrets.get(scope="daptestdataenggscope",key="applicationId")

  # Application (Client) Secret Key
  authenticationKey = dbutils.secrets.get(scope="daptestdataenggscope",key="testdnaadls")

  # Directory (Tenant) ID
  tenandId = dbutils.secrets.get(scope="daptestdataenggscope",key="adtenantid")

  endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
  source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

  # Connecting using Service Principal secrets and OAuth
  configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
             "fs.azure.account.oauth2.client.id": applicationId,
             "fs.azure.account.oauth2.client.secret": authenticationKey,
             "fs.azure.account.oauth2.client.endpoint": endpoint}

elif environment.lower() == 'uat':
  adlsAccountName = "dapuatadlslnd01"
  adlsContainerName = "landing"
  adlsFolderName = ""
  mountPoint = "/mnt/landing"

  # Application (Client) ID
  applicationId = dbutils.secrets.get(scope="dapuatdataenggscope",key="applicationId")

  # Application (Client) Secret Key
  authenticationKey = dbutils.secrets.get(scope="dapuatdataenggscope",key="uatdnaadls")

  # Directory (Tenant) ID
  tenandId = dbutils.secrets.get(scope="dapuatdataenggscope",key="adtenantid")

  endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
  source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

  # Connecting using Service Principal secrets and OAuth
  configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
             "fs.azure.account.oauth2.client.id": applicationId,
             "fs.azure.account.oauth2.client.secret": authenticationKey,
             "fs.azure.account.oauth2.client.endpoint": endpoint}

elif environment.lower() == 'prod':
  adlsAccountName = "dapprodadlslnd01"
  adlsContainerName = "landing"
  adlsFolderName = ""
  mountPoint = "/mnt/landing"

  # Application (Client) ID
  applicationId = dbutils.secrets.get(scope="dapproddataenggscope",key="applicationId")

  # Application (Client) Secret Key
  authenticationKey = dbutils.secrets.get(scope="dapproddataenggscope",key="proddnaadls")

  # Directory (Tenant) ID
  tenandId = dbutils.secrets.get(scope="dapproddataenggscope",key="adtenantid")

  endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
  source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

  # Connecting using Service Principal secrets and OAuth
  configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
             "fs.azure.account.oauth2.client.id": applicationId,
             "fs.azure.account.oauth2.client.secret": authenticationKey,
             "fs.azure.account.oauth2.client.endpoint": endpoint}
# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)
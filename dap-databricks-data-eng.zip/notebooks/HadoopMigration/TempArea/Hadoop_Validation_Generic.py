# Databricks notebook source
# Reading ADLS path
#parquet file from hadoop for the given table.
#df=spark.read.text("abfss://wrangled@dapuatadlswrng01.dfs.core.windows.net/property_services/property_services/property/2022/02/11/Spotlight_Approvals_20220208_20220216033456.txt")
dbutils.widgets.text("adlspath","adls_path")
adlspath=dbutils.widgets.get("adlspath")
ADLS_DATA=spark.read.parquet(adlspath)
#ADLS_DATA=spark.read.parquet("abfss://wrangled@dapuatadlswrng01.dfs.core.windows.net/common/idh_data_migration/tables/pharmacy_healthcare/patient_services/rx_event_1/r5idh2uat34runmar112022220311030716")
ADLS_DATA.createOrReplaceTempView('view')
ADLS_DATA.count()

# COMMAND ----------

#Querying on delta table
dbutils.widgets.text("hivetable","table")
table=dbutils.widgets.get("hivetable")
#print(table)
delta_DATA=spark.sql("select * from " + table);
#delta_DATA=spark.sql("select * from hive_metastore.pharmacy_healthcare__patient_services.rx_event_1");
delta_DATA.count()

# COMMAND ----------

#Querying on temp view
adls_data_fin=spark.sql("select * from view")
adls_data_fin.count()

# COMMAND ----------

##ADLS-Delta
df_data_ADLS_delta=adls_data_fin.subtract(delta_DATA)
print('Mismatched records =',df_data_ADLS_delta.count())
df_data_ADLS_delta.display()

# COMMAND ----------

##Delta-ADLS
df_data_delta_adls=delta_DATA.subtract(adls_data_fin)
print('Mismatched records =',df_data_delta_adls.count())
df_data_delta_adls.display()

# COMMAND ----------

import pandas as pd
import csv
from pyspark.sql.functions import lit 

dbutils.widgets.text("ddl_tgt_path","ddl_path")
path2=dbutils.widgets.get("ddl_tgt_path")
dbutils.widgets.text("ddl_table_list","list")
list1=dbutils.widgets.get("ddl_table_list")
lst = list1.split(" ")
print(lst)
#lst = ['catalina.catalina_campaigns','catalina.catalina_contact_history','catalina.catalina_coupon_metrics','catalina.catalina_customer_metrics']
with open(path2,'w',newline='') as f_obj:
#with open('/mnt/wrangled/common/testing/sampleddl_test.csv','w',newline='') as f_obj:
  for table in lst:
    ddl=spark.sql("desc table {}".format(table))
    desc_list = ddl.collect()[:-100]    
    for item in desc_list:
      f_obj.write(table+","+item[0]+","+item[1])
      f_obj.write("\n")
f_obj.close()

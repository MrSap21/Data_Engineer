# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# #Create Widgets for Parameters
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220301005521")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_rx_cntrl_substance")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","/pharmacy_healthcare/patient/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","/pharmacy_healthcare/patient/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","UAT_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_CNTRL_SUBSTANCE_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","UAT_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_UNPROCESSED_FILES","{'GG_TBF0_RX_CNTRL_SUBSTANCE': [{'assetid': 23850, 'assetname': #'PRDRX2STAGE_GG_TBF0_RX_CNTRL_SUBSTANCE_4_2022-02-25_03-26-35_01724_data_20220225220005.dsv', 'assetcurrentlocation': #'/pharmacy_healthcare/drug/icplus/2022/02/28/'}]}")
# dbutils.widgets.text("PAR_DB_FEED_NAME","gg_tbf0_rx_cntrl_substance")

# COMMAND ----------

import json
from pyspark.sql.functions import *
from pyspark.sql.types import *

# readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
# readList=readList.split(',')


# COMMAND ----------

#Implement Control Files Logic

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")
FEED_NAME=dbutils.widgets.get("PAR_DB_FEED_NAME") 
Input_File_List=dbutils.widgets.get("PAR_UNPROCESSED_FILES")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

# print (OUT_FILEPATH)
# print (REJ_FILE_NOISE_RMV)
# print(REJ_FILE_PAT_MOD)
# print(REJ_FILE_UPD_NULL)
# print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

#Define Input File Schema
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'src_partition_nbr',
'src_partition_nbr_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_partial_nbr',
'fill_partial_nbr_after',
'transaction_cd',
'transaction_cd_after',
'fill_verified_user_inits',
'fill_verified_user_inits_after',
'drug_id',
'drug_id_after',
'drug_non_system_name',
'drug_non_system_name_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after']

print(len(fieldList))


# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and (lst[6] == '"INSERT"' or lst[6] == 'INSERT'):
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6] or '"INSERT"' in key_list[6]:
    if val_len != 39:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or '"SQL COMPUPDATE"' in key_list[6] or 'PK UPDATE' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 40:
      return True
  else:
    if val_len != 40:
      return True

# COMMAND ----------

# Read input files
in_text = spark.read.text(readList)
in_text = in_text.withColumn("value",regexp_replace(col("value"),"\"","")).rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len = 40

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 24
print(f"Bad records count {rd_bad.count()}") # != 24

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\ <Only when the file is encrypted?
def handlEscpeQuotes(val):
 if not val:
   return ""
  
  #remove rightmost "
 outval = val[0:-1]
  #remove leftmost "
 outval = outval.lstrip("\"")
  #replace double \\ with \
 outval = outval.replace("\\\\","\\")
  #replace double \" with "
 outval = outval.replace("\\\"","\"")
 return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

from functools import reduce
df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col_name)),
#     df.columns,
#     df
# ))
#Extarct filename
from pyspark.sql.functions import input_file_name
df_fileName = df.withColumn("fileName",input_file_name())
#Extract partition number from file name

df_split = df_fileName.withColumn("src_partition_nbr",concat(split(col("fileName"),"_")[7]))
df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df_split = df_split.drop("fileName")

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_rx_cntrl_substance")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 

df_gg.createOrReplaceTempView("raw_gg_rx_cntrl_substance")


# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from raw_gg_rx_cntrl_substance where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_gg_rx_cntrl_substance where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_rx_cntrl_substance where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)


if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition

else:  
  sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETL_HIVE_CUTOFF_TBL)
  df_cutoff_records_output=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFK_ETL_DB) \
     .option("query",sel_ETL_Hive_Cutoff_tbl) \
     .load()


  cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
  cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

  #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
  cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
  RX_CUT_OFF_MAX_DTTM as rx_max,
  CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
  CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
  from cutoff_records_filter""" 
  cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
  

  #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
  cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
  RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
  from cutoff_records_filter"""
  cutoff_range_trans = spark.sql(cutoff_range_trans_sql)
  
  
  #Fetching rx_max and rx_trans_max as values
  rx_max = cutoff_range_rx.select("rx_max")
  rx_trans_max = cutoff_range_trans.select("rx_trans_max")
  
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(col("cdc_txn_commit_dttm") < rx_max.collect()[0][0])
    
  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(col("cdc_txn_commit_dttm") <= rx_max.collect()[0][0])
  
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  #Applying trans_cutoff range on trans related tables
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(col("cdc_txn_commit_dttm") < rx_trans_max.collect()[0][0])
    
  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(col("cdc_txn_commit_dttm") <= rx_trans_max.collect()[0][0])
  
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)
  
#Remove duplicates
dedup_group = nr_input_file_final.distinct()

#nr spacetrim
for col in dedup_group.columns:
    nr_spacetrim = dedup_group.withColumn(col, when(ltrim(rtrim(dedup_group[col])) == "",None).otherwise(ltrim(rtrim(dedup_group[col]))))

nr_spacetrim.createOrReplaceTempView("nr_spacetrim")



# COMMAND ----------

pUpdateReform="((cdc_seq_nbr == cdc_seq_nbr_after AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL)  AND   (cdc_rba_nbr == cdc_rba_nbr_after AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL)  AND   (cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL) AND  (cdc_before_after_cd_after == 'AFTER' AND  cdc_before_after_cd_after IS NOT NULL) AND    (cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND  cdc_operation_type_cd_after IS NOT NULL) AND    (cdc_before_after_cd == 'BEFORE' AND  cdc_before_after_cd IS NOT NULL) AND     (cdc_operation_type_cd == 'SQL COMPUPDATE' AND  cdc_operation_type_cd IS NOT NULL) AND (store_nbr_after == store_nbr AND store_nbr_after IS NOT NULL AND store_nbr IS NOT NULL) AND (rx_nbr_after == rx_nbr AND rx_nbr_after IS NOT NULL AND rx_nbr IS NOT NULL ) AND (fill_nbr_after == fill_nbr AND fill_nbr_after IS NOT NULL AND fill_nbr IS NOT NULL ) AND (fill_partial_nbr_after == fill_partial_nbr AND fill_partial_nbr_after IS NOT NULL AND fill_partial_nbr IS NOT NULL)  AND (transaction_cd_after == transaction_cd AND transaction_cd_after IS NOT NULL AND transaction_cd IS NOT NULL ) AND ((fill_verified_user_inits_after == fill_verified_user_inits AND fill_verified_user_inits_after IS NOT NULL AND fill_verified_user_inits IS NOT NULL) OR ( fill_verified_user_inits_after IS NULL AND fill_verified_user_inits IS NULL )) AND ((drug_id_after == drug_id AND drug_id_after IS NOT NULL AND drug_id IS NOT NULL) OR ( drug_id_after IS NULL AND drug_id IS NULL )) AND ((drug_non_system_name_after == drug_non_system_name AND drug_non_system_name_after IS NOT NULL AND drug_non_system_name IS NOT NULL )OR ( drug_non_system_name_after IS NULL AND drug_non_system_name IS NULL )) )"

# COMMAND ----------

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

gg_tbf0_rejected_query = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(gg_tbf0_rejected_query)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 
  
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")



# COMMAND ----------

gg_tbf0_update_afr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm_after.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr_after.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr_after.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd_after.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id_after.alias("edw_batch_id"), \
                                           gg_tbf0_update.src_partition_nbr_after.alias("src_partition_nbr"), \
                                           gg_tbf0_update.store_nbr_after.alias("store_nbr"), \
                                           gg_tbf0_update.rx_nbr_after.alias("rx_nbr"), \
                                           gg_tbf0_update.fill_nbr_after.alias("fill_nbr"), 
                                           gg_tbf0_update.fill_partial_nbr_after.alias("fill_partial_nbr"), \
										   gg_tbf0_update.transaction_cd_after.alias("transaction_cd"), \
										   gg_tbf0_update.fill_verified_user_inits_after.alias("fill_verified_user_inits"), \
										   gg_tbf0_update.drug_id_after.alias("drug_id"), \
										   gg_tbf0_update.drug_non_system_name_after.alias("drug_non_system_name"), \
										   gg_tbf0_update.create_user_id_after.alias("create_user_id"), \
										   gg_tbf0_update.create_dttm_after.alias("create_dttm"), \
										   gg_tbf0_update.update_user_id_after.alias("update_user_id"), \
										   gg_tbf0_update.update_dttm_after.alias("update_dttm"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_update_bfr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd.alias("cdc_before_after_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id.alias("edw_batch_id"), \
                                           gg_tbf0_update.src_partition_nbr.alias("src_partition_nbr"), \
                                           gg_tbf0_update.store_nbr.alias("store_nbr"), \
                                           gg_tbf0_update.rx_nbr.alias("rx_nbr"), \
                                           gg_tbf0_update.fill_nbr.alias("fill_nbr"), \
                                           gg_tbf0_update.fill_partial_nbr.alias("fill_partial_nbr"), 
                                           gg_tbf0_update.transaction_cd.alias("transaction_cd"), \
										   gg_tbf0_update.fill_verified_user_inits.alias("fill_verified_user_inits"), \
										   gg_tbf0_update.drug_id.alias("drug_id"), \
										   gg_tbf0_update.drug_non_system_name.alias("drug_non_system_name"), \
										   gg_tbf0_update.create_user_id.alias("create_user_id"), \
										   gg_tbf0_update.create_dttm.alias("create_dttm"), \
										   gg_tbf0_update.update_user_id.alias("update_user_id"), \
										   gg_tbf0_update.update_dttm.alias("update_dttm"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_insert_afr = nr_insert_check.select(nr_insert_check.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                           nr_insert_check.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                           nr_insert_check.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                           nr_insert_check.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                           nr_insert_check.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                           nr_insert_check.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                           nr_insert_check.edw_batch_id_after.alias("edw_batch_id"), \
                                           nr_insert_check.src_partition_nbr_after.alias("src_partition_nbr"), \
                                           nr_insert_check.store_nbr_after.alias("store_nbr"), \
                                           nr_insert_check.rx_nbr_after.alias("rx_nbr"), \
                                           nr_insert_check.fill_nbr_after.alias("fill_nbr"), 
                                           nr_insert_check.fill_partial_nbr_after.alias("fill_partial_nbr"), \
										   nr_insert_check.transaction_cd_after.alias("transaction_cd"), \
										   nr_insert_check.fill_verified_user_inits_after.alias("fill_verified_user_inits"), \
										   nr_insert_check.drug_id_after.alias("drug_id"), \
										   nr_insert_check.drug_non_system_name_after.alias("drug_non_system_name"), \
										   nr_insert_check.create_user_id_after.alias("create_user_id"), \
										   nr_insert_check.create_dttm_after.alias("create_dttm"), \
										   nr_insert_check.update_user_id_after.alias("update_user_id"), \
										   nr_insert_check.update_dttm_after.alias("update_dttm"), \
                                           nr_insert_check.table_name)

# COMMAND ----------

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")


# COMMAND ----------

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, store_nbr, rx_nbr, fill_nbr, fill_partial_nbr, fill_verified_user_inits, transaction_cd, drug_id, drug_non_system_name, src_partition_nbr, create_user_id, CONCAT(substring(create_dttm,0,10),' ',substring(create_dttm,12,19),'.000000') AS create_dttm, update_user_id, CONCAT(substring(update_dttm,0,10),' ',substring(update_dttm,12,19),'.000000') AS update_dttm,(CASE WHEN (cdc_operation_type_cd=='INSERT') THEN store_nbr ELSE '' END) AS relocate_fm_str_nbr"



# COMMAND ----------

etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Remove Blank Values
for col in etl_tbf0_reformat.columns:
    etl_tbf0_reformat = etl_tbf0_reformat.withColumn(col, when(ltrim(rtrim(etl_tbf0_reformat[col])) == "",None).otherwise(ltrim(rtrim(etl_tbf0_reformat[col]))))
    
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())\
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
.withColumn("create_dttm",to_timestamp(etl_tbf0_reformat["create_dttm"])) \
.withColumn("edw_batch_id",lit(BATCH_ID)) \
.withColumn("update_dttm",to_timestamp(etl_tbf0_reformat["update_dttm"])) 

etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)

# COMMAND ----------

#Load ETL_TBF0_PATIENT_MERGE formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

#Load TL_ETL_TBF0_PATIENT_MERGE formatted records to the Snowflake Table
TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]
etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", TL_SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFL_TEST_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TEST_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'

#print (IN_DATAFILE)
print (OUT_FILEPATH)
#print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC 
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit,explode, col
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList =sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(FEED_NAME))) \
.select(f"{FEED_NAME}.assetcurrentlocation",
f"{FEED_NAME}.assetid",
f"{FEED_NAME}.assetname")
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.text("PAR_DB_FILE_LIST","DAPDEVDWH01.PRDRX2STAGE")
#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pat_id',
'pat_id_after',
'pat_first_name',
'pat_first_name_after',
'pat_mid_init',
'pat_mid_init_after',
'pat_last_name',
'pat_last_name_after',
'pat_last_name_soundex',
'pat_last_name_soundex_after',
'pat_surname_suffix',
'pat_surname_suffix_after',
'pat_street_addr',
'pat_street_addr_after',
'pat_city',
'pat_city_after',
'pat_state',
'pat_state_after',
'pat_zip',
'pat_zip_after',
'pat_sex_cd',
'pat_sex_cd_after',
'pat_birth_dttm',
'pat_birth_dttm_after',
'pat_prim_area_cd',
'pat_prim_area_cd_after',
'pat_prim_phone',
'pat_prim_phone_after',
'pat_prim_phone_cd',
'pat_prim_phone_cd_after',
'pat_sec_area_cd',
'pat_sec_area_cd_after',
'pat_sec_phone',
'pat_sec_phone_after',
'pat_hoh_id',
'pat_hoh_id_after',
'pat_hoh_relation_cd',
'pat_hoh_relation_cd_after',
'pat_discount_cd',
'pat_discount_cd_after',
'pat_clinic_medical_id',
'pat_clinic_medical_id_after',
'pat_snap_cap_pref',
'pat_snap_cap_pref_after',
'pat_generic_subs_pref',
'pat_generic_subs_pref_after',
'pat_thera_subs_pref',
'pat_thera_subs_pref_after',
'pat_mail_list_pref',
'pat_mail_list_pref_after',
'pat_lang_pref_cd',
'pat_lang_pref_cd_after',
'pat_purged_rx_ind',
'pat_purged_rx_ind_after',
'pat_pet_ind',
'pat_pet_ind_after',
'pat_pet_type',
'pat_pet_type_after',
'pat_preappr_pay_ind',
'pat_preappr_pay_ind_after',
'pat_cc_nbr',
'pat_cc_nbr_after',
'pat_mail_service_id',
'pat_mail_service_id_after',
'pat_cmts',
'pat_cmts_after',
'pat_create_store_nbr',
'pat_create_store_nbr_after',
'pat_deceased_ind',
'pat_deceased_ind_after',
'pat_algy_hlth_type_cd',
'pat_algy_hlth_type_cd_after',
'pat_algy_hlth_cd_inq_ind',
'pat_algy_hlth_cd_inq_ind_after',
'pat_wc_ind',
'pat_wc_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'pat_phone_contact_pref',
'pat_phone_contact_pref_after',
'pat_signature_ind',
'pat_signature_ind_after',
'pat_internet_ind',
'pat_internet_ind_after',
'pat_ext_rx_otc_ind',
'pat_ext_rx_otc_ind_after',
'pat_registration_dttm',
'pat_registration_dttm_after',
'pat_cc_holder_zip',
'pat_cc_holder_zip_after',
'pat_mfg_card_ind',
'pat_mfg_card_ind_after',
'pat_sr_div_rec_nbr',
'pat_sr_div_rec_nbr_after',
'pat_hipaa_ind',
'pat_hipaa_ind_after',
'pat_hipaa_dttm',
'pat_hipaa_dttm_after',
'pat_hipaa_store_nbr',
'pat_hipaa_store_nbr_after',
'buyout_pat_ind',
'buyout_pat_ind_after',
'pat_hipaa_ack_ltr_ind',
'pat_hipaa_ack_ltr_ind_after',
'pat_email_address',
'pat_email_address_after',
'pat_email_dttm',
'pat_email_dttm_after',
'pat_email_user_id',
'pat_email_user_id_after',
'pat_lock_ind',
'pat_lock_ind_after',
'pat_lock_store_nbr',
'pat_lock_store_nbr_after',
'pat_lock_user_id',
'pat_lock_user_id_after',
'pat_lock_dttm',
'pat_lock_dttm_after',
'pat_smoking_ind',
'pat_smoking_ind_after',
'pat_pregnancy_ind',
'pat_pregnancy_ind_after',
'pat_preg_due_dttm',
'pat_preg_due_dttm_after',
'pat_pickup_id',
'pat_pickup_id_after',
'pat_brochure_ind',
'pat_brochure_ind_after',
'pat_large_print_ind',
'pat_large_print_ind_after',
'pat_ck_acct_nbr',
'pat_ck_acct_nbr_after',
'pat_ck_route_nbr',
'pat_ck_route_nbr_after',
'pat_homecare_ind',
'pat_homecare_ind_after',
'cust_balance_hold_ind',
'cust_balance_hold_ind_after',
'pat_specialty_ind',
'pat_specialty_ind_after',
'pat_hipaa_auth_name',
'pat_hipaa_auth_name_after',
'pat_hipaa_auth_exp',
'pat_hipaa_auth_exp_after',
'pat_hipaa_auth_other',
'pat_hipaa_auth_other_after',
'pat_hipaa_auth_cd',
'pat_hipaa_auth_cd_after',
'pat_rca_ind',
'pat_rca_ind_after',
'e2c_l4c',
'e2c_l4c_after',
'e2c_hash',
'e2c_hash_after',
'pat_text_msg_ind',
'pat_text_msg_ind_after',
'pat_text_msg_carrier',
'pat_text_msg_carrier_after',
'pat_prim_phone_pref_cd',
'pat_prim_phone_pref_cd_after',
'pat_billing_cd',
'pat_billing_cd_after',
'pat_link_cd',
'pat_link_cd_after',
'pat_autorefill_ind',
'pat_autorefill_ind_after',
'auto_refill_pref_str_nbr',
'auto_refill_pref_str_nbr_after',
'pat_residence_cd',
'pat_residence_cd_after',
'pat_prim_care_pbr_id',
'pat_prim_care_pbr_id_after',
'pat_prim_care_pbr_loc_id',
'pat_prim_care_pbr_loc_id_after',
'pat_pickup_id_qlfr',
'pat_pickup_id_qlfr_after',
'pat_pickup_gov_auth_id',
'pat_pickup_gov_auth_id_after',
'pat_pickup_rel_cd',
'pat_pickup_rel_cd_after',
'pat_unmerge_verify_ind',
'pat_unmerge_verify_ind_after',
'pat_twin_ind',
'pat_twin_ind_after',
'pat_90day_pref_ind',
'pat_90day_pref_ind_after',
'pat_90day_pref_dttm',
'pat_90day_pref_dttm_after',
'pat_alg_block_madr_ind',
'pat_alg_block_madr_ind_after' ]

print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split('"^|~"')
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 209:
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 210:
      return True
  else:
    if val_len != 210:
      return True




# COMMAND ----------

# Read Files

in_text = spark.read.text(readList)

in_text = in_text.rdd


# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 210

rd1 = in_text.map(lambda rw: rw[0].split('"^|~"')).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 120
print(f"Bad records count {rd_bad.count()}") # != 120

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:]
  outval = outval.lstrip("\"")
  if(len(str(outval)) > 1 ):
      if((outval[-2]!="\\")) :
    #remove rightmost "
        outval = outval.rstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    df.columns,
    df
))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_patient")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_seq_nbr )) ==0) then  cdc_seq_nbr else trim( cdc_seq_nbr)end) as cdc_seq_nbr ,
(case when (LENGTH(trim(cdc_rba_nbr )) ==0) then  cdc_rba_nbr else trim( cdc_rba_nbr)end) as cdc_rba_nbr ,
(case when (LENGTH(trim(cdc_operation_type_cd )) ==0) then  cdc_operation_type_cd else trim( cdc_operation_type_cd)end) as cdc_operation_type_cd ,
(case when (LENGTH(trim(cdc_before_after_cd )) ==0) then  cdc_before_after_cd else trim( cdc_before_after_cd)end) as cdc_before_after_cd ,
(case when (LENGTH(trim(cdc_txn_position_cd )) ==0) then  cdc_txn_position_cd else trim( cdc_txn_position_cd)end) as cdc_txn_position_cd ,
edw_batch_id,
(case when (LENGTH(trim(pat_id )) ==0) then  pat_id else trim( pat_id)end) as pat_id ,
(case when (LENGTH(trim(pat_first_name )) ==0) then  pat_first_name else trim( pat_first_name)end) as pat_first_name ,
(case when (LENGTH(trim(pat_mid_init )) ==0) then  pat_mid_init else trim( pat_mid_init)end) as pat_mid_init ,
(case when (LENGTH(trim(pat_last_name )) ==0) then  pat_last_name else trim( pat_last_name)end) as pat_last_name ,
(case when (LENGTH(trim(pat_last_name_soundex )) ==0) then  pat_last_name_soundex else trim( pat_last_name_soundex)end) as pat_last_name_soundex ,
(case when (LENGTH(trim(pat_surname_suffix )) ==0) then  pat_surname_suffix else trim( pat_surname_suffix)end) as pat_surname_suffix ,
(case when (LENGTH(trim(pat_street_addr )) ==0) then  pat_street_addr else trim( pat_street_addr)end) as pat_street_addr ,
(case when (LENGTH(trim(pat_city )) ==0) then  pat_city else trim( pat_city)end) as pat_city ,
(case when (LENGTH(trim(pat_state )) ==0) then  pat_state else trim( pat_state)end) as pat_state ,
(case when (LENGTH(trim(pat_zip )) ==0) then  pat_zip else trim( pat_zip)end) as pat_zip ,
(case when (LENGTH(trim(pat_sex_cd )) ==0) then  pat_sex_cd else trim( pat_sex_cd)end) as pat_sex_cd ,
(case when (LENGTH(trim(pat_birth_dttm)) ==0) then  pat_birth_dttm else concat(substring(pat_birth_dttm,1,10),' ',substring(pat_birth_dttm,12,8),'.000000') end) as pat_birth_dttm ,
(case when (LENGTH(trim(pat_prim_area_cd )) ==0) then  pat_prim_area_cd else trim( pat_prim_area_cd)end) as pat_prim_area_cd ,
(case when (LENGTH(trim(pat_prim_phone )) ==0) then  pat_prim_phone else trim( pat_prim_phone)end) as pat_prim_phone ,
(case when (LENGTH(trim(pat_prim_phone_cd )) ==0) then  pat_prim_phone_cd else trim( pat_prim_phone_cd)end) as pat_prim_phone_cd ,
(case when (LENGTH(trim(pat_sec_area_cd )) ==0) then  pat_sec_area_cd else trim( pat_sec_area_cd)end) as pat_sec_area_cd ,
(case when (LENGTH(trim(pat_sec_phone )) ==0) then  pat_sec_phone else trim( pat_sec_phone)end) as pat_sec_phone ,
(case when (LENGTH(trim(pat_hoh_id )) ==0) then  pat_hoh_id else trim( pat_hoh_id)end) as pat_hoh_id ,
(case when (LENGTH(trim(pat_hoh_relation_cd )) ==0) then  pat_hoh_relation_cd else trim( pat_hoh_relation_cd)end) as pat_hoh_relation_cd ,
(case when (LENGTH(trim(pat_discount_cd )) ==0) then  pat_discount_cd else trim( pat_discount_cd)end) as pat_discount_cd ,
(case when (LENGTH(trim(pat_clinic_medical_id )) ==0) then  pat_clinic_medical_id else trim( pat_clinic_medical_id)end) as pat_clinic_medical_id ,
(case when (LENGTH(trim(pat_snap_cap_pref )) ==0) then  pat_snap_cap_pref else trim( pat_snap_cap_pref)end) as pat_snap_cap_pref ,
(case when (LENGTH(trim(pat_generic_subs_pref )) ==0) then  pat_generic_subs_pref else trim( pat_generic_subs_pref)end) as pat_generic_subs_pref ,
(case when (LENGTH(trim(pat_thera_subs_pref )) ==0) then  pat_thera_subs_pref else trim( pat_thera_subs_pref)end) as pat_thera_subs_pref ,
(case when (LENGTH(trim(pat_mail_list_pref )) ==0) then  pat_mail_list_pref else trim( pat_mail_list_pref)end) as pat_mail_list_pref ,
(case when (LENGTH(trim(pat_lang_pref_cd )) ==0) then  pat_lang_pref_cd else trim( pat_lang_pref_cd)end) as pat_lang_pref_cd ,
(case when (LENGTH(trim(pat_purged_rx_ind )) ==0) then  pat_purged_rx_ind else trim( pat_purged_rx_ind)end) as pat_purged_rx_ind ,
(case when (LENGTH(trim(pat_pet_ind )) ==0) then  pat_pet_ind else trim( pat_pet_ind)end) as pat_pet_ind ,
(case when (LENGTH(trim(pat_pet_type )) ==0) then  pat_pet_type else trim( pat_pet_type)end) as pat_pet_type ,
(case when (LENGTH(trim(pat_preappr_pay_ind )) ==0) then  pat_preappr_pay_ind else trim( pat_preappr_pay_ind)end) as pat_preappr_pay_ind ,
(case when (LENGTH(trim(pat_cc_nbr )) ==0) then  pat_cc_nbr else trim( pat_cc_nbr)end) as pat_cc_nbr ,
(case when (LENGTH(trim(pat_mail_service_id )) ==0) then  pat_mail_service_id else trim( pat_mail_service_id)end) as pat_mail_service_id ,
(case when (LENGTH(trim(pat_cmts )) ==0) then  pat_cmts else trim( pat_cmts)end) as pat_cmts ,
(case when (LENGTH(trim(pat_create_store_nbr )) ==0) then  pat_create_store_nbr else trim( pat_create_store_nbr)end) as pat_create_store_nbr ,
(case when (LENGTH(trim(pat_deceased_ind )) ==0) then  pat_deceased_ind else trim( pat_deceased_ind)end) as pat_deceased_ind ,
(case when (LENGTH(trim(pat_algy_hlth_type_cd )) ==0) then  pat_algy_hlth_type_cd else trim( pat_algy_hlth_type_cd)end) as pat_algy_hlth_type_cd ,
(case when (LENGTH(trim(pat_algy_hlth_cd_inq_ind )) ==0) then  pat_algy_hlth_cd_inq_ind else trim( pat_algy_hlth_cd_inq_ind)end) as pat_algy_hlth_cd_inq_ind ,
(case when (LENGTH(trim(pat_wc_ind )) ==0) then  pat_wc_ind else trim( pat_wc_ind)end) as pat_wc_ind ,
(case when (LENGTH(trim(create_user_id )) ==0) then  create_user_id else trim( create_user_id)end) as create_user_id ,
(case when (LENGTH(trim(create_dttm)) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000') end) as create_dttm ,
(case when (LENGTH(trim( update_user_id )) ==0) then  update_user_id else trim( update_user_id)end) as update_user_id ,
(case when (LENGTH(trim(update_dttm)) ==0) then  update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000') end) as update_dttm ,
(case when (LENGTH(trim(pat_phone_contact_pref )) ==0) then  pat_phone_contact_pref else trim( pat_phone_contact_pref)end) as pat_phone_contact_pref ,
(case when (LENGTH(trim(pat_signature_ind )) ==0) then  pat_signature_ind else trim( pat_signature_ind)end) as pat_signature_ind ,
(case when (LENGTH(trim(pat_internet_ind )) ==0) then  pat_internet_ind else trim( pat_internet_ind)end) as pat_internet_ind ,
(case when (LENGTH(trim(pat_ext_rx_otc_ind )) ==0) then  pat_ext_rx_otc_ind else trim( pat_ext_rx_otc_ind)end) as pat_ext_rx_otc_ind ,
(case when (LENGTH(trim(pat_registration_dttm)) ==0) then  pat_registration_dttm else concat(substring(pat_registration_dttm,1,10),' ',substring(pat_registration_dttm,12,8),'.000000') end) as pat_registration_dttm ,
(case when (LENGTH(trim(pat_cc_holder_zip )) ==0) then  pat_cc_holder_zip else trim( pat_cc_holder_zip)end) as pat_cc_holder_zip ,
(case when (LENGTH(trim(pat_mfg_card_ind )) ==0) then  pat_mfg_card_ind else trim( pat_mfg_card_ind)end) as pat_mfg_card_ind ,
(case when (LENGTH(trim(pat_sr_div_rec_nbr )) ==0) then  pat_sr_div_rec_nbr else trim( pat_sr_div_rec_nbr)end) as pat_sr_div_rec_nbr ,
(case when (LENGTH(trim(pat_hipaa_ind )) ==0) then  pat_hipaa_ind else trim( pat_hipaa_ind)end) as pat_hipaa_ind ,
(case when (LENGTH(trim(pat_hipaa_dttm)) ==0) then  pat_hipaa_dttm else concat(substring(pat_hipaa_dttm,1,10),' ',substring(pat_hipaa_dttm,12,8),'.000000') end) as pat_hipaa_dttm ,
(case when (LENGTH(trim(pat_hipaa_store_nbr )) ==0) then  pat_hipaa_store_nbr else trim( pat_hipaa_store_nbr)end) as pat_hipaa_store_nbr ,
(case when (LENGTH(trim(buyout_pat_ind )) ==0) then  buyout_pat_ind else trim( buyout_pat_ind)end) as buyout_pat_ind ,
(case when (LENGTH(trim(pat_hipaa_ack_ltr_ind )) ==0) then  pat_hipaa_ack_ltr_ind else trim( pat_hipaa_ack_ltr_ind)end) as pat_hipaa_ack_ltr_ind ,
(case when (LENGTH(trim(pat_email_address )) ==0) then  pat_email_address else trim( pat_email_address)end) as pat_email_address ,
(case when (LENGTH(trim(pat_email_dttm)) ==0) then  pat_email_dttm else concat(substring(pat_email_dttm,1,10),' ',substring(pat_email_dttm,12,8),'.000000') end) as pat_email_dttm ,
(case when (LENGTH(trim(pat_email_user_id )) ==0) then  pat_email_user_id else trim( pat_email_user_id)end) as pat_email_user_id ,
(case when (LENGTH(trim(pat_lock_ind )) ==0) then  pat_lock_ind else trim( pat_lock_ind)end) as pat_lock_ind ,
(case when (LENGTH(trim(pat_lock_store_nbr )) ==0) then  pat_lock_store_nbr else trim( pat_lock_store_nbr)end) as pat_lock_store_nbr ,
(case when (LENGTH(trim(pat_lock_user_id )) ==0) then  pat_lock_user_id else trim( pat_lock_user_id)end) as pat_lock_user_id ,
(case when (LENGTH(trim(pat_lock_dttm)) ==0) then  pat_lock_dttm else concat(substring(pat_lock_dttm,1,10),' ',substring(pat_lock_dttm,12,8),'.000000') end) as pat_lock_dttm ,
(case when (LENGTH(trim(pat_smoking_ind )) ==0) then  pat_smoking_ind else trim( pat_smoking_ind)end) as pat_smoking_ind ,
(case when (LENGTH(trim(pat_pregnancy_ind )) ==0) then  pat_pregnancy_ind else trim( pat_pregnancy_ind)end) as pat_pregnancy_ind ,
(case when (LENGTH(trim(pat_preg_due_dttm)) ==0) then  pat_preg_due_dttm else concat(substring(pat_preg_due_dttm,1,10),' ',substring(pat_preg_due_dttm,12,8),'.000000') end) as pat_preg_due_dttm ,
(case when (LENGTH(trim(pat_pickup_id )) ==0) then  pat_pickup_id else trim( pat_pickup_id)end) as pat_pickup_id ,
(case when (LENGTH(trim(pat_brochure_ind )) ==0) then  pat_brochure_ind else trim( pat_brochure_ind)end) as pat_brochure_ind ,
(case when (LENGTH(trim(pat_large_print_ind )) ==0) then  pat_large_print_ind else trim( pat_large_print_ind)end) as pat_large_print_ind ,
(case when (LENGTH(trim(pat_ck_acct_nbr )) ==0) then  pat_ck_acct_nbr else trim( pat_ck_acct_nbr)end) as pat_ck_acct_nbr ,
(case when (LENGTH(trim(pat_ck_route_nbr )) ==0) then  pat_ck_route_nbr else trim( pat_ck_route_nbr)end) as pat_ck_route_nbr ,
(case when (LENGTH(trim(pat_homecare_ind )) ==0) then  pat_homecare_ind else trim( pat_homecare_ind)end) as pat_homecare_ind ,
(case when (LENGTH(trim(cust_balance_hold_ind )) ==0) then  cust_balance_hold_ind else trim( cust_balance_hold_ind)end) as cust_balance_hold_ind ,
(case when (LENGTH(trim(pat_specialty_ind )) ==0) then  pat_specialty_ind else trim( pat_specialty_ind)end) as pat_specialty_ind ,
(case when (LENGTH(trim(pat_hipaa_auth_name )) ==0) then  pat_hipaa_auth_name else trim( pat_hipaa_auth_name)end) as pat_hipaa_auth_name ,
(case when (LENGTH(trim(pat_hipaa_auth_exp )) ==0) then  pat_hipaa_auth_exp else trim( pat_hipaa_auth_exp)end) as pat_hipaa_auth_exp ,
(case when (LENGTH(trim(pat_hipaa_auth_other )) ==0) then  pat_hipaa_auth_other else trim( pat_hipaa_auth_other)end) as pat_hipaa_auth_other ,
(case when (LENGTH(trim(pat_hipaa_auth_cd )) ==0) then  pat_hipaa_auth_cd else trim( pat_hipaa_auth_cd)end) as pat_hipaa_auth_cd ,
(case when (LENGTH(trim(pat_rca_ind )) ==0) then  pat_rca_ind else trim( pat_rca_ind)end) as pat_rca_ind ,
(case when (LENGTH(trim(e2c_l4c )) ==0) then  e2c_l4c else trim( e2c_l4c)end) as e2c_l4c ,
(case when (LENGTH(trim(e2c_hash )) ==0) then  e2c_hash else trim(regexp_replace(e2c_hash,'[\u00C7]',''))end) as e2c_hash ,
(case when (LENGTH(trim(pat_text_msg_ind )) ==0) then  pat_text_msg_ind else trim( pat_text_msg_ind)end) as pat_text_msg_ind ,
(case when (LENGTH(trim(pat_text_msg_carrier )) ==0) then  pat_text_msg_carrier else trim( pat_text_msg_carrier)end) as pat_text_msg_carrier ,
(case when (LENGTH(trim(pat_prim_phone_pref_cd )) ==0) then  pat_prim_phone_pref_cd else trim( pat_prim_phone_pref_cd)end) as pat_prim_phone_pref_cd ,
(case when (LENGTH(trim(pat_billing_cd )) ==0) then  pat_billing_cd else trim( pat_billing_cd)end) as pat_billing_cd ,
(case when (LENGTH(trim(pat_link_cd )) ==0) then  pat_link_cd else trim( pat_link_cd)end) as pat_link_cd ,
(case when (LENGTH(trim(pat_autorefill_ind )) ==0) then  pat_autorefill_ind else trim( pat_autorefill_ind)end) as pat_autorefill_ind ,
(case when (LENGTH(trim(auto_refill_pref_str_nbr )) ==0) then  auto_refill_pref_str_nbr else trim( auto_refill_pref_str_nbr)end) as auto_refill_pref_str_nbr ,
(case when (LENGTH(trim(pat_residence_cd )) ==0) then  pat_residence_cd else trim( pat_residence_cd)end) as pat_residence_cd ,
(case when (LENGTH(trim(pat_prim_care_pbr_id )) ==0) then  pat_prim_care_pbr_id else trim( pat_prim_care_pbr_id)end) as pat_prim_care_pbr_id ,
(case when (LENGTH(trim(pat_prim_care_pbr_loc_id )) ==0) then  pat_prim_care_pbr_loc_id else trim( pat_prim_care_pbr_loc_id)end) as pat_prim_care_pbr_loc_id ,
(case when (LENGTH(trim(pat_pickup_gov_auth_id )) ==0) then  pat_pickup_gov_auth_id else trim( pat_pickup_gov_auth_id)end) as pat_pickup_gov_auth_id ,
(case when (LENGTH(trim(pat_pickup_id_qlfr )) ==0) then  pat_pickup_id_qlfr else trim( pat_pickup_id_qlfr)end) as pat_pickup_id_qlfr ,
(case when (LENGTH(trim(pat_pickup_rel_cd )) ==0) then  pat_pickup_rel_cd else trim( pat_pickup_rel_cd)end) as pat_pickup_rel_cd ,
(case when (LENGTH(trim(pat_unmerge_verify_ind )) ==0) then  pat_unmerge_verify_ind else trim( pat_unmerge_verify_ind)end) as pat_unmerge_verify_ind ,
(case when (LENGTH(trim(pat_twin_ind )) ==0) then  pat_twin_ind else trim( pat_twin_ind)end) as pat_twin_ind ,
(case when (LENGTH(trim(pat_90day_pref_ind )) ==0) then  pat_90day_pref_ind else trim( pat_90day_pref_ind)end) as pat_90day_pref_ind ,
(case when (LENGTH(trim(pat_90day_pref_dttm)) ==0) then  pat_90day_pref_dttm else concat(substring(pat_90day_pref_dttm,1,10),' ',substring(pat_90day_pref_dttm,12,8),'.000000') end)  as pat_90day_pref_dttm ,
'000000' as tracking_id, 
(case when (LENGTH(trim(pat_alg_block_madr_ind )) ==0) then  pat_alg_block_madr_ind else trim( pat_alg_block_madr_ind)end) as pat_alg_block_madr_ind 
from gg_tbf0_patient where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd='PK UPDATE')"""

# COMMAND ----------

sql2 = """select
(case when (LENGTH(trim(cdc_txn_commit_dttm_after)) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after)end) as pat_id,
(case when (LENGTH(trim( pat_first_name_after )) ==0) then pat_first_name_after else trim(pat_first_name_after)end) as pat_first_name,
(case when (LENGTH(trim( pat_mid_init_after )) ==0) then pat_mid_init_after else trim(pat_mid_init_after)end) as pat_mid_init,
(case when (LENGTH(trim( pat_last_name_after )) ==0) then pat_last_name_after else trim(pat_last_name_after)end) as pat_last_name,
(case when (LENGTH(trim( pat_last_name_soundex_after )) ==0) then pat_last_name_soundex_after else trim(pat_last_name_soundex_after)end) as pat_last_name_soundex,
(case when (LENGTH(trim( pat_surname_suffix_after )) ==0) then pat_surname_suffix_after else trim(pat_surname_suffix_after)end) as pat_surname_suffix,
(case when (LENGTH(trim( pat_street_addr_after )) ==0) then pat_street_addr_after else trim(pat_street_addr_after)end) as pat_street_addr,
(case when (LENGTH(trim( pat_city_after )) ==0) then pat_city_after else trim(pat_city_after)end) as pat_city,
(case when (LENGTH(trim( pat_state_after )) ==0) then pat_state_after else trim(pat_state_after)end) as pat_state,
(case when (LENGTH(trim( pat_zip_after )) ==0) then pat_zip_after else trim(pat_zip_after)end) as pat_zip,
(case when (LENGTH(trim( pat_sex_cd_after )) ==0) then pat_sex_cd_after else trim(pat_sex_cd_after)end) as pat_sex_cd,
(case when (LENGTH(trim(pat_birth_dttm_after)) ==0) then  pat_birth_dttm_after else concat(substring(pat_birth_dttm_after,1,10),' ',substring(pat_birth_dttm_after,12,8),'.000000') end) as pat_birth_dttm,
(case when (LENGTH(trim( pat_prim_area_cd_after )) ==0) then pat_prim_area_cd_after else trim(pat_prim_area_cd_after)end) as pat_prim_area_cd,
(case when (LENGTH(trim( pat_prim_phone_after )) ==0) then pat_prim_phone_after else trim(pat_prim_phone_after)end) as pat_prim_phone,
(case when (LENGTH(trim( pat_prim_phone_cd_after )) ==0) then pat_prim_phone_cd_after else trim(pat_prim_phone_cd_after)end) as pat_prim_phone_cd,
(case when (LENGTH(trim( pat_sec_area_cd_after )) ==0) then pat_sec_area_cd_after else trim(pat_sec_area_cd_after)end) as pat_sec_area_cd,
(case when (LENGTH(trim( pat_sec_phone_after )) ==0) then pat_sec_phone_after else trim(pat_sec_phone_after)end) as pat_sec_phone,
(case when (LENGTH(trim( pat_hoh_id_after )) ==0) then pat_hoh_id_after else trim(pat_hoh_id_after)end) as pat_hoh_id,
(case when (LENGTH(trim( pat_hoh_relation_cd_after )) ==0) then pat_hoh_relation_cd_after else trim(pat_hoh_relation_cd_after)end) as pat_hoh_relation_cd,
(case when (LENGTH(trim( pat_discount_cd_after )) ==0) then pat_discount_cd_after else trim(pat_discount_cd_after)end) as pat_discount_cd,
(case when (LENGTH(trim( pat_clinic_medical_id_after )) ==0) then pat_clinic_medical_id_after else trim(pat_clinic_medical_id_after)end) as pat_clinic_medical_id,
(case when (LENGTH(trim( pat_snap_cap_pref_after )) ==0) then pat_snap_cap_pref_after else trim(pat_snap_cap_pref_after)end) as pat_snap_cap_pref,
(case when (LENGTH(trim( pat_generic_subs_pref_after )) ==0) then pat_generic_subs_pref_after else trim(pat_generic_subs_pref_after)end) as pat_generic_subs_pref,
(case when (LENGTH(trim( pat_thera_subs_pref_after )) ==0) then pat_thera_subs_pref_after else trim(pat_thera_subs_pref_after)end) as pat_thera_subs_pref,
(case when (LENGTH(trim( pat_mail_list_pref_after )) ==0) then pat_mail_list_pref_after else trim(pat_mail_list_pref_after)end) as pat_mail_list_pref,
(case when (LENGTH(trim( pat_lang_pref_cd_after )) ==0) then pat_lang_pref_cd_after else trim(pat_lang_pref_cd_after)end) as pat_lang_pref_cd,
(case when (LENGTH(trim( pat_purged_rx_ind_after )) ==0) then pat_purged_rx_ind_after else trim(pat_purged_rx_ind_after)end) as pat_purged_rx_ind,
(case when (LENGTH(trim( pat_pet_ind_after )) ==0) then pat_pet_ind_after else trim(pat_pet_ind_after)end) as pat_pet_ind,
(case when (LENGTH(trim( pat_pet_type_after )) ==0) then pat_pet_type_after else trim(pat_pet_type_after)end) as pat_pet_type,
(case when (LENGTH(trim( pat_preappr_pay_ind_after )) ==0) then pat_preappr_pay_ind_after else trim(pat_preappr_pay_ind_after)end) as pat_preappr_pay_ind,
(case when (LENGTH(trim( pat_cc_nbr_after )) ==0) then pat_cc_nbr_after else trim(pat_cc_nbr_after)end) as pat_cc_nbr,
(case when (LENGTH(trim( pat_mail_service_id_after )) ==0) then pat_mail_service_id_after else trim(pat_mail_service_id_after)end) as pat_mail_service_id,
(case when (LENGTH(trim( pat_cmts_after )) ==0) then pat_cmts_after else trim(pat_cmts_after)end) as pat_cmts,
(case when (LENGTH(trim( pat_create_store_nbr_after )) ==0) then pat_create_store_nbr_after else trim(pat_create_store_nbr_after)end) as pat_create_store_nbr,
(case when (LENGTH(trim( pat_deceased_ind_after )) ==0) then pat_deceased_ind_after else trim(pat_deceased_ind_after)end) as pat_deceased_ind,
(case when (LENGTH(trim( pat_algy_hlth_type_cd_after )) ==0) then pat_algy_hlth_type_cd_after else trim(pat_algy_hlth_type_cd_after)end) as pat_algy_hlth_type_cd,
(case when (LENGTH(trim( pat_algy_hlth_cd_inq_ind_after )) ==0) then pat_algy_hlth_cd_inq_ind_after else trim(pat_algy_hlth_cd_inq_ind_after)end) as pat_algy_hlth_cd_inq_ind,
(case when (LENGTH(trim( pat_wc_ind_after )) ==0) then pat_wc_ind_after else trim(pat_wc_ind_after)end) as pat_wc_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after)) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then  update_user_id_after else trim( update_user_id_after)end) as update_user_id ,
(case when (LENGTH(trim(update_dttm_after)) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000') end) as update_dttm ,
(case when (LENGTH(trim( pat_phone_contact_pref_after )) ==0) then pat_phone_contact_pref_after else trim(pat_phone_contact_pref_after)end) as pat_phone_contact_pref,
(case when (LENGTH(trim( pat_signature_ind_after )) ==0) then pat_signature_ind_after else trim(pat_signature_ind_after)end) as pat_signature_ind,
(case when (LENGTH(trim( pat_internet_ind_after )) ==0) then pat_internet_ind_after else trim(pat_internet_ind_after)end) as pat_internet_ind,
(case when (LENGTH(trim( pat_ext_rx_otc_ind_after )) ==0) then pat_ext_rx_otc_ind_after else trim(pat_ext_rx_otc_ind_after)end) as pat_ext_rx_otc_ind,
(case when (LENGTH(trim(pat_registration_dttm_after)) ==0) then  pat_registration_dttm_after else concat(substring(pat_registration_dttm_after,1,10),' ',substring(pat_registration_dttm_after,12,8),'.000000') end) as pat_registration_dttm,
(case when (LENGTH(trim( pat_cc_holder_zip_after )) ==0) then pat_cc_holder_zip_after else trim(pat_cc_holder_zip_after)end) as pat_cc_holder_zip,
(case when (LENGTH(trim( pat_mfg_card_ind_after )) ==0) then pat_mfg_card_ind_after else trim(pat_mfg_card_ind_after)end) as pat_mfg_card_ind,
(case when (LENGTH(trim( pat_sr_div_rec_nbr_after )) ==0) then pat_sr_div_rec_nbr_after else trim(pat_sr_div_rec_nbr_after)end) as pat_sr_div_rec_nbr,
(case when (LENGTH(trim( pat_hipaa_ind_after )) ==0) then pat_hipaa_ind_after else trim(pat_hipaa_ind_after)end) as pat_hipaa_ind,
(case when (LENGTH(trim(pat_hipaa_dttm_after)) ==0) then  pat_hipaa_dttm_after else concat(substring(pat_hipaa_dttm_after,1,10),' ',substring(pat_hipaa_dttm_after,12,8),'.000000') end) as pat_hipaa_dttm,
(case when (LENGTH(trim( pat_hipaa_store_nbr_after )) ==0) then pat_hipaa_store_nbr_after else trim(pat_hipaa_store_nbr_after)end) as pat_hipaa_store_nbr,
(case when (LENGTH(trim( buyout_pat_ind_after )) ==0) then buyout_pat_ind_after else trim(buyout_pat_ind_after)end) as buyout_pat_ind,
(case when (LENGTH(trim( pat_hipaa_ack_ltr_ind_after )) ==0) then pat_hipaa_ack_ltr_ind_after else trim(pat_hipaa_ack_ltr_ind_after)end) as pat_hipaa_ack_ltr_ind,
(case when (LENGTH(trim( pat_email_address_after )) ==0) then pat_email_address_after else trim(pat_email_address_after)end) as pat_email_address,
(case when (LENGTH(trim(pat_email_dttm_after)) ==0) then  pat_email_dttm_after else concat(substring(pat_email_dttm_after,1,10),' ',substring(pat_email_dttm_after,12,8),'.000000') end) as pat_email_dttm,
(case when (LENGTH(trim( pat_email_user_id_after )) ==0) then pat_email_user_id_after else trim(pat_email_user_id_after)end) as pat_email_user_id,
(case when (LENGTH(trim( pat_lock_ind_after )) ==0) then pat_lock_ind_after else trim(pat_lock_ind_after)end) as pat_lock_ind ,
(case when (LENGTH(trim( pat_lock_store_nbr_after )) ==0) then pat_lock_store_nbr_after else trim(pat_lock_store_nbr_after)end) as pat_lock_store_nbr,
(case when (LENGTH(trim( pat_lock_user_id_after )) ==0) then pat_lock_user_id_after else trim(pat_lock_user_id_after)end) as pat_lock_user_id,
(case when (LENGTH(trim(pat_lock_dttm_after)) ==0) then  pat_lock_dttm_after else concat(substring(pat_lock_dttm_after,1,10),' ',substring(pat_lock_dttm_after,12,8),'.000000') end) as pat_lock_dttm,
(case when (LENGTH(trim( pat_smoking_ind_after )) ==0) then pat_smoking_ind_after else trim(pat_smoking_ind_after)end)  as pat_smoking_ind,
(case when (LENGTH(trim( pat_pregnancy_ind_after )) ==0) then pat_pregnancy_ind_after else trim(pat_pregnancy_ind_after)end) as pat_pregnancy_ind,
(case when (LENGTH(trim(pat_preg_due_dttm_after)) ==0) then  pat_preg_due_dttm_after else concat(substring(pat_preg_due_dttm_after,1,10),' ',substring(pat_preg_due_dttm_after,12,8),'.000000') end) as pat_preg_due_dttm,
(case when (LENGTH(trim( pat_pickup_id_after )) ==0) then pat_pickup_id_after else trim(pat_pickup_id_after)end) as pat_pickup_id,
(case when (LENGTH(trim( pat_brochure_ind_after )) ==0) then pat_brochure_ind_after else trim(pat_brochure_ind_after)end) as pat_brochure_ind,
(case when (LENGTH(trim( pat_large_print_ind_after )) ==0) then pat_large_print_ind_after else trim(pat_large_print_ind_after)end) as pat_large_print_ind,
(case when (LENGTH(trim( pat_ck_acct_nbr_after )) ==0) then pat_ck_acct_nbr_after else trim(pat_ck_acct_nbr_after)end) as pat_ck_acct_nbr,
(case when (LENGTH(trim( pat_ck_route_nbr_after )) ==0) then pat_ck_route_nbr_after else trim(pat_ck_route_nbr_after)end) as pat_ck_route_nbr,
(case when (LENGTH(trim( pat_homecare_ind_after )) ==0) then pat_homecare_ind_after else trim(pat_homecare_ind_after)end) as pat_homecare_ind,
(case when (LENGTH(trim( cust_balance_hold_ind_after )) ==0) then cust_balance_hold_ind_after else trim(cust_balance_hold_ind_after)end) as cust_balance_hold_ind,
(case when (LENGTH(trim( pat_specialty_ind_after )) ==0) then pat_specialty_ind_after else trim(pat_specialty_ind_after)end) as pat_specialty_ind,
(case when (LENGTH(trim( pat_hipaa_auth_name_after )) ==0) then pat_hipaa_auth_name_after else trim(pat_hipaa_auth_name_after)end) as pat_hipaa_auth_name,
(case when (LENGTH(trim( pat_hipaa_auth_exp_after )) ==0) then pat_hipaa_auth_exp_after else trim(pat_hipaa_auth_exp_after)end) as pat_hipaa_auth_exp,
(case when (LENGTH(trim( pat_hipaa_auth_other_after )) ==0) then pat_hipaa_auth_other_after else trim(pat_hipaa_auth_other_after)end) as pat_hipaa_auth_other,
(case when (LENGTH(trim( pat_hipaa_auth_cd_after )) ==0) then pat_hipaa_auth_cd_after else trim(pat_hipaa_auth_cd_after)end) as pat_hipaa_auth_cd,
(case when (LENGTH(trim( pat_rca_ind_after )) ==0) then pat_rca_ind_after else trim(pat_rca_ind_after)end) as pat_rca_ind,
(case when (LENGTH(trim( e2c_l4c_after )) ==0) then e2c_l4c_after else trim(e2c_l4c_after)end) as e2c_l4c,
(case when (LENGTH(trim(e2c_hash_after )) ==0) then  e2c_hash_after else trim(regexp_replace(e2c_hash_after,'[\u00C7]',''))end) as e2c_hash,
(case when (LENGTH(trim( pat_text_msg_ind_after )) ==0) then pat_text_msg_ind_after else trim(pat_text_msg_ind_after)end) as pat_text_msg_ind,
(case when (LENGTH(trim( pat_text_msg_carrier_after )) ==0) then pat_text_msg_carrier_after else trim(pat_text_msg_carrier_after)end) as pat_text_msg_carrier,
(case when (LENGTH(trim( pat_prim_phone_pref_cd_after )) ==0) then pat_prim_phone_pref_cd_after else trim(pat_prim_phone_pref_cd_after)end) as pat_prim_phone_pref_cd,
(case when (LENGTH(trim( pat_billing_cd_after )) ==0) then pat_billing_cd_after else trim(pat_billing_cd_after)end) as pat_billing_cd,
(case when (LENGTH(trim( pat_link_cd_after )) ==0) then pat_link_cd_after else trim(pat_link_cd_after)end) as pat_link_cd,
(case when (LENGTH(trim( pat_autorefill_ind_after )) ==0) then pat_autorefill_ind_after else trim(pat_autorefill_ind_after)end) as pat_autorefill_ind,
(case when (LENGTH(trim( auto_refill_pref_str_nbr_after )) ==0) then auto_refill_pref_str_nbr_after else trim(auto_refill_pref_str_nbr_after)end) as auto_refill_pref_str_nbr,
(case when (LENGTH(trim( pat_residence_cd_after )) ==0) then pat_residence_cd_after else trim(pat_residence_cd_after)end) as pat_residence_cd,
(case when (LENGTH(trim( pat_prim_care_pbr_id_after )) ==0) then pat_prim_care_pbr_id_after else trim(pat_prim_care_pbr_id_after)end) as pat_prim_care_pbr_id,
(case when (LENGTH(trim( pat_prim_care_pbr_loc_id_after )) ==0) then pat_prim_care_pbr_loc_id_after else trim(pat_prim_care_pbr_loc_id_after)end) as pat_prim_care_pbr_loc_id,
(case when (LENGTH(trim( pat_pickup_gov_auth_id_after )) ==0) then pat_pickup_gov_auth_id_after else trim(pat_pickup_gov_auth_id_after)end) as pat_pickup_gov_auth_id,
(case when (LENGTH(trim( pat_pickup_id_qlfr_after )) ==0) then pat_pickup_id_qlfr_after else trim(pat_pickup_id_qlfr_after)end) as pat_pickup_id_qlfr,
(case when (LENGTH(trim( pat_pickup_rel_cd_after )) ==0) then pat_pickup_rel_cd_after else trim(pat_pickup_rel_cd_after)end) as pat_pickup_rel_cd,
(case when (LENGTH(trim( pat_unmerge_verify_ind_after )) ==0) then pat_unmerge_verify_ind_after else trim(pat_unmerge_verify_ind_after)end) as pat_unmerge_verify_ind,
(case when (LENGTH(trim( pat_twin_ind_after )) ==0) then pat_twin_ind_after else trim(pat_twin_ind_after)end) as pat_twin_ind,
(case when (LENGTH(trim( pat_90day_pref_ind_after )) ==0) then pat_90day_pref_ind_after else trim(pat_90day_pref_ind_after)end) as pat_90day_pref_ind,
(case when (LENGTH(trim(pat_90day_pref_dttm_after)) ==0) then  pat_90day_pref_dttm_after else concat(substring(pat_90day_pref_dttm_after,1,10),' ',substring(pat_90day_pref_dttm_after,12,8),'.000000') end) as pat_90day_pref_dttm ,
'000000' as tracking_id, 
(case when (LENGTH(trim(pat_alg_block_madr_ind_after )) ==0) then  pat_alg_block_madr_ind_after else trim( pat_alg_block_madr_ind_after)end) as pat_alg_block_madr_ind
from  gg_tbf0_patient where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd='PK UPDATE')"""

# COMMAND ----------

sql3 = """select
(case when (LENGTH(trim(cdc_txn_commit_dttm)) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after)end) as pat_id,
(case when (LENGTH(trim( pat_first_name_after )) ==0) then pat_first_name_after else trim(pat_first_name_after)end) as pat_first_name,
(case when (LENGTH(trim( pat_mid_init_after )) ==0) then pat_mid_init_after else trim(pat_mid_init_after)end) as pat_mid_init,
(case when (LENGTH(trim( pat_last_name_after )) ==0) then pat_last_name_after else trim(pat_last_name_after)end) as pat_last_name,
(case when (LENGTH(trim( pat_last_name_soundex_after )) ==0) then pat_last_name_soundex_after else trim(pat_last_name_soundex_after)end) as pat_last_name_soundex,
(case when (LENGTH(trim( pat_surname_suffix_after )) ==0) then pat_surname_suffix_after else trim(pat_surname_suffix_after)end) as pat_surname_suffix,
(case when (LENGTH(trim( pat_street_addr_after )) ==0) then pat_street_addr_after else trim(pat_street_addr_after)end) as pat_street_addr,
(case when (LENGTH(trim( pat_city_after )) ==0) then pat_city_after else trim(pat_city_after)end) as pat_city,
(case when (LENGTH(trim( pat_state_after )) ==0) then pat_state_after else trim(pat_state_after)end) as pat_state,
(case when (LENGTH(trim( pat_zip_after )) ==0) then pat_zip_after else trim(pat_zip_after)end) as pat_zip,
(case when (LENGTH(trim( pat_sex_cd_after )) ==0) then pat_sex_cd_after else trim(pat_sex_cd_after)end) as pat_sex_cd,
(case when (LENGTH(trim(pat_birth_dttm_after)) ==0) then  pat_birth_dttm_after else concat(substring(pat_birth_dttm_after,1,10),' ',substring(pat_birth_dttm_after,12,8),'.000000') end) as pat_birth_dttm,
(case when (LENGTH(trim( pat_prim_area_cd_after )) ==0) then pat_prim_area_cd_after else trim(pat_prim_area_cd_after)end) as pat_prim_area_cd,
(case when (LENGTH(trim( pat_prim_phone_after )) ==0) then pat_prim_phone_after else trim(pat_prim_phone_after)end) as pat_prim_phone,
(case when (LENGTH(trim( pat_prim_phone_cd_after )) ==0) then pat_prim_phone_cd_after else trim(pat_prim_phone_cd_after)end) as pat_prim_phone_cd,
(case when (LENGTH(trim( pat_sec_area_cd_after )) ==0) then pat_sec_area_cd_after else trim(pat_sec_area_cd_after)end) as pat_sec_area_cd,
(case when (LENGTH(trim( pat_sec_phone_after )) ==0) then pat_sec_phone_after else trim(pat_sec_phone_after)end) as pat_sec_phone,
(case when (LENGTH(trim( pat_hoh_id_after )) ==0) then pat_hoh_id_after else trim(pat_hoh_id_after)end) as pat_hoh_id,
(case when (LENGTH(trim( pat_hoh_relation_cd_after )) ==0) then pat_hoh_relation_cd_after else trim(pat_hoh_relation_cd_after)end) as pat_hoh_relation_cd,
(case when (LENGTH(trim( pat_discount_cd_after )) ==0) then pat_discount_cd_after else trim(pat_discount_cd_after)end) as pat_discount_cd,
(case when (LENGTH(trim( pat_clinic_medical_id_after )) ==0) then pat_clinic_medical_id_after else trim(pat_clinic_medical_id_after)end) as pat_clinic_medical_id,
(case when (LENGTH(trim( pat_snap_cap_pref_after )) ==0) then pat_snap_cap_pref_after else trim(pat_snap_cap_pref_after)end) as pat_snap_cap_pref,
(case when (LENGTH(trim( pat_generic_subs_pref_after )) ==0) then pat_generic_subs_pref_after else trim(pat_generic_subs_pref_after)end) as pat_generic_subs_pref,
(case when (LENGTH(trim( pat_thera_subs_pref_after )) ==0) then pat_thera_subs_pref_after else trim(pat_thera_subs_pref_after)end) as pat_thera_subs_pref,
(case when (LENGTH(trim( pat_mail_list_pref_after )) ==0) then pat_mail_list_pref_after else trim(pat_mail_list_pref_after)end) as pat_mail_list_pref,
(case when (LENGTH(trim( pat_lang_pref_cd_after )) ==0) then pat_lang_pref_cd_after else trim(pat_lang_pref_cd_after)end) as pat_lang_pref_cd,
(case when (LENGTH(trim( pat_purged_rx_ind_after )) ==0) then pat_purged_rx_ind_after else trim(pat_purged_rx_ind_after)end) as pat_purged_rx_ind,
(case when (LENGTH(trim( pat_pet_ind_after )) ==0) then pat_pet_ind_after else trim(pat_pet_ind_after)end) as pat_pet_ind,
(case when (LENGTH(trim( pat_pet_type_after )) ==0) then pat_pet_type_after else trim(pat_pet_type_after)end) as pat_pet_type,
(case when (LENGTH(trim( pat_preappr_pay_ind_after )) ==0) then pat_preappr_pay_ind_after else trim(pat_preappr_pay_ind_after)end) as pat_preappr_pay_ind,
(case when (LENGTH(trim( pat_cc_nbr_after )) ==0) then pat_cc_nbr_after else trim(pat_cc_nbr_after)end) as pat_cc_nbr,
(case when (LENGTH(trim( pat_mail_service_id_after )) ==0) then pat_mail_service_id_after else trim(pat_mail_service_id_after)end) as pat_mail_service_id,
(case when (LENGTH(trim( pat_cmts_after )) ==0) then pat_cmts_after else trim(pat_cmts_after)end) as pat_cmts,
(case when (LENGTH(trim( pat_create_store_nbr_after )) ==0) then pat_create_store_nbr_after else trim(pat_create_store_nbr_after)end) as pat_create_store_nbr,
(case when (LENGTH(trim( pat_deceased_ind_after )) ==0) then pat_deceased_ind_after else trim(pat_deceased_ind_after)end) as pat_deceased_ind,
(case when (LENGTH(trim( pat_algy_hlth_type_cd_after )) ==0) then pat_algy_hlth_type_cd_after else trim(pat_algy_hlth_type_cd_after)end) as pat_algy_hlth_type_cd,
(case when (LENGTH(trim( pat_algy_hlth_cd_inq_ind_after )) ==0) then pat_algy_hlth_cd_inq_ind_after else trim(pat_algy_hlth_cd_inq_ind_after)end) as pat_algy_hlth_cd_inq_ind,
(case when (LENGTH(trim( pat_wc_ind_after )) ==0) then pat_wc_ind_after else trim(pat_wc_ind_after)end) as pat_wc_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after)) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then  update_user_id_after else trim( update_user_id_after)end) as update_user_id ,
(case when (LENGTH(trim(update_dttm_after)) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000') end) as update_dttm ,
(case when (LENGTH(trim( pat_phone_contact_pref_after )) ==0) then pat_phone_contact_pref_after else trim(pat_phone_contact_pref_after)end) as pat_phone_contact_pref,
(case when (LENGTH(trim( pat_signature_ind_after )) ==0) then pat_signature_ind_after else trim(pat_signature_ind_after)end) as pat_signature_ind,
(case when (LENGTH(trim( pat_internet_ind_after )) ==0) then pat_internet_ind_after else trim(pat_internet_ind_after)end) as pat_internet_ind,
(case when (LENGTH(trim( pat_ext_rx_otc_ind_after )) ==0) then pat_ext_rx_otc_ind_after else trim(pat_ext_rx_otc_ind_after)end) as pat_ext_rx_otc_ind,
(case when (LENGTH(trim(pat_registration_dttm_after)) ==0) then  pat_registration_dttm_after else concat(substring(pat_registration_dttm_after,1,10),' ',substring(pat_registration_dttm_after,12,8),'.000000') end) as pat_registration_dttm,
(case when (LENGTH(trim( pat_cc_holder_zip_after )) ==0) then pat_cc_holder_zip_after else trim(pat_cc_holder_zip_after)end) as pat_cc_holder_zip,
(case when (LENGTH(trim( pat_mfg_card_ind_after )) ==0) then pat_mfg_card_ind_after else trim(pat_mfg_card_ind_after)end) as pat_mfg_card_ind,
(case when (LENGTH(trim( pat_sr_div_rec_nbr_after )) ==0) then pat_sr_div_rec_nbr_after else trim(pat_sr_div_rec_nbr_after)end) as pat_sr_div_rec_nbr,
(case when (LENGTH(trim( pat_hipaa_ind_after )) ==0) then pat_hipaa_ind_after else trim(pat_hipaa_ind_after)end) as pat_hipaa_ind,
(case when (LENGTH(trim(pat_hipaa_dttm_after)) ==0) then  pat_hipaa_dttm_after else concat(substring(pat_hipaa_dttm_after,1,10),' ',substring(pat_hipaa_dttm_after,12,8),'.000000') end) as pat_hipaa_dttm,
(case when (LENGTH(trim( pat_hipaa_store_nbr_after )) ==0) then pat_hipaa_store_nbr_after else trim(pat_hipaa_store_nbr_after)end) as pat_hipaa_store_nbr,
(case when (LENGTH(trim( buyout_pat_ind_after )) ==0) then buyout_pat_ind_after else trim(buyout_pat_ind_after)end) as buyout_pat_ind,
(case when (LENGTH(trim( pat_hipaa_ack_ltr_ind_after )) ==0) then pat_hipaa_ack_ltr_ind_after else trim(pat_hipaa_ack_ltr_ind_after)end) as pat_hipaa_ack_ltr_ind,
(case when (LENGTH(trim( pat_email_address_after )) ==0) then pat_email_address_after else trim(pat_email_address_after)end) as pat_email_address,
(case when (LENGTH(trim(pat_email_dttm_after)) ==0) then  pat_email_dttm_after else concat(substring(pat_email_dttm_after,1,10),' ',substring(pat_email_dttm_after,12,8),'.000000') end) as pat_email_dttm,
(case when (LENGTH(trim( pat_email_user_id_after )) ==0) then pat_email_user_id_after else trim(pat_email_user_id_after)end) as pat_email_user_id,
(case when (LENGTH(trim( pat_lock_ind_after )) ==0) then pat_lock_ind_after else trim(pat_lock_ind_after)end) as pat_lock_ind ,
(case when (LENGTH(trim( pat_lock_store_nbr_after )) ==0) then pat_lock_store_nbr_after else trim(pat_lock_store_nbr_after)end) as pat_lock_store_nbr,
(case when (LENGTH(trim( pat_lock_user_id_after )) ==0) then pat_lock_user_id_after else trim(pat_lock_user_id_after)end) as pat_lock_user_id,
(case when (LENGTH(trim(pat_lock_dttm_after)) ==0) then  pat_lock_dttm_after else concat(substring(pat_lock_dttm_after,1,10),' ',substring(pat_lock_dttm_after,12,8),'.000000') end) as pat_lock_dttm,
(case when (LENGTH(trim( pat_smoking_ind_after )) ==0) then pat_smoking_ind_after else trim(pat_smoking_ind_after)end)  as pat_smoking_ind,
(case when (LENGTH(trim( pat_pregnancy_ind_after )) ==0) then pat_pregnancy_ind_after else trim(pat_pregnancy_ind_after)end) as pat_pregnancy_ind,
(case when (LENGTH(trim(pat_preg_due_dttm_after)) ==0) then  pat_preg_due_dttm_after else concat(substring(pat_preg_due_dttm_after,1,10),' ',substring(pat_preg_due_dttm_after,12,8),'.000000') end) as pat_preg_due_dttm,
(case when (LENGTH(trim( pat_pickup_id_after )) ==0) then pat_pickup_id_after else trim(pat_pickup_id_after)end) as pat_pickup_id,
(case when (LENGTH(trim( pat_brochure_ind_after )) ==0) then pat_brochure_ind_after else trim(pat_brochure_ind_after)end) as pat_brochure_ind,
(case when (LENGTH(trim( pat_large_print_ind_after )) ==0) then pat_large_print_ind_after else trim(pat_large_print_ind_after)end) as pat_large_print_ind,
(case when (LENGTH(trim( pat_ck_acct_nbr_after )) ==0) then pat_ck_acct_nbr_after else trim(pat_ck_acct_nbr_after)end) as pat_ck_acct_nbr,
(case when (LENGTH(trim( pat_ck_route_nbr_after )) ==0) then pat_ck_route_nbr_after else trim(pat_ck_route_nbr_after)end) as pat_ck_route_nbr,
(case when (LENGTH(trim( pat_homecare_ind_after )) ==0) then pat_homecare_ind_after else trim(pat_homecare_ind_after)end) as pat_homecare_ind,
(case when (LENGTH(trim( cust_balance_hold_ind_after )) ==0) then cust_balance_hold_ind_after else trim(cust_balance_hold_ind_after)end) as cust_balance_hold_ind,
(case when (LENGTH(trim( pat_specialty_ind_after )) ==0) then pat_specialty_ind_after else trim(pat_specialty_ind_after)end) as pat_specialty_ind,
(case when (LENGTH(trim( pat_hipaa_auth_name_after )) ==0) then pat_hipaa_auth_name_after else trim(pat_hipaa_auth_name_after)end) as pat_hipaa_auth_name,
(case when (LENGTH(trim( pat_hipaa_auth_exp_after )) ==0) then pat_hipaa_auth_exp_after else trim(pat_hipaa_auth_exp_after)end) as pat_hipaa_auth_exp,
(case when (LENGTH(trim( pat_hipaa_auth_other_after )) ==0) then pat_hipaa_auth_other_after else trim(pat_hipaa_auth_other_after)end) as pat_hipaa_auth_other,
(case when (LENGTH(trim( pat_hipaa_auth_cd_after )) ==0) then pat_hipaa_auth_cd_after else trim(pat_hipaa_auth_cd_after)end) as pat_hipaa_auth_cd,
(case when (LENGTH(trim( pat_rca_ind_after )) ==0) then pat_rca_ind_after else trim(pat_rca_ind_after)end) as pat_rca_ind,
(case when (LENGTH(trim( e2c_l4c_after )) ==0) then e2c_l4c_after else trim(e2c_l4c_after)end) as e2c_l4c,
(case when (LENGTH(trim(e2c_hash_after )) ==0) then  e2c_hash_after else trim(regexp_replace(e2c_hash_after,'[\u00C7]',''))end) as e2c_hash,
(case when (LENGTH(trim( pat_text_msg_ind_after )) ==0) then pat_text_msg_ind_after else trim(pat_text_msg_ind_after)end) as pat_text_msg_ind,
(case when (LENGTH(trim( pat_text_msg_carrier_after )) ==0) then pat_text_msg_carrier_after else trim(pat_text_msg_carrier_after)end) as pat_text_msg_carrier,
(case when (LENGTH(trim( pat_prim_phone_pref_cd_after )) ==0) then pat_prim_phone_pref_cd_after else trim(pat_prim_phone_pref_cd_after)end) as pat_prim_phone_pref_cd,
(case when (LENGTH(trim( pat_billing_cd_after )) ==0) then pat_billing_cd_after else trim(pat_billing_cd_after)end) as pat_billing_cd,
(case when (LENGTH(trim( pat_link_cd_after )) ==0) then pat_link_cd_after else trim(pat_link_cd_after)end) as pat_link_cd,
(case when (LENGTH(trim( pat_autorefill_ind_after )) ==0) then pat_autorefill_ind_after else trim(pat_autorefill_ind_after)end) as pat_autorefill_ind,
(case when (LENGTH(trim( auto_refill_pref_str_nbr_after )) ==0) then auto_refill_pref_str_nbr_after else trim(auto_refill_pref_str_nbr_after)end) as auto_refill_pref_str_nbr,
(case when (LENGTH(trim( pat_residence_cd_after )) ==0) then pat_residence_cd_after else trim(pat_residence_cd_after)end) as pat_residence_cd,
(case when (LENGTH(trim( pat_prim_care_pbr_id_after )) ==0) then pat_prim_care_pbr_id_after else trim(pat_prim_care_pbr_id_after)end) as pat_prim_care_pbr_id,
(case when (LENGTH(trim( pat_prim_care_pbr_loc_id_after )) ==0) then pat_prim_care_pbr_loc_id_after else trim(pat_prim_care_pbr_loc_id_after)end) as pat_prim_care_pbr_loc_id,
(case when (LENGTH(trim( pat_pickup_gov_auth_id_after )) ==0) then pat_pickup_gov_auth_id_after else trim(pat_pickup_gov_auth_id_after)end) as pat_pickup_gov_auth_id,
(case when (LENGTH(trim( pat_pickup_id_qlfr_after )) ==0) then pat_pickup_id_qlfr_after else trim(pat_pickup_id_qlfr_after)end) as pat_pickup_id_qlfr,
(case when (LENGTH(trim( pat_pickup_rel_cd_after )) ==0) then pat_pickup_rel_cd_after else trim(pat_pickup_rel_cd_after)end) as pat_pickup_rel_cd,
(case when (LENGTH(trim( pat_unmerge_verify_ind_after )) ==0) then pat_unmerge_verify_ind_after else trim(pat_unmerge_verify_ind_after)end) as pat_unmerge_verify_ind,
(case when (LENGTH(trim( pat_twin_ind_after )) ==0) then pat_twin_ind_after else trim(pat_twin_ind_after)end) as pat_twin_ind,
(case when (LENGTH(trim( pat_90day_pref_ind_after )) ==0) then pat_90day_pref_ind_after else trim(pat_90day_pref_ind_after)end) as pat_90day_pref_ind,
(case when (LENGTH(trim(pat_90day_pref_dttm_after)) ==0) then  pat_90day_pref_dttm_after else concat(substring(pat_90day_pref_dttm_after,1,10),' ',substring(pat_90day_pref_dttm_after,12,8),'.000000') end) as pat_90day_pref_dttm ,
'000000' as tracking_id, 
(case when (LENGTH(trim(pat_alg_block_madr_ind_after )) ==0) then  pat_alg_block_madr_ind_after else trim( pat_alg_block_madr_ind_after)end) as pat_alg_block_madr_ind
from  gg_tbf0_patient where (cdc_operation_type_cd = 'INSERT' )"""

# COMMAND ----------

df1 = spark.sql(sql1)

display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)



dfFinal.createOrReplaceTempView("gg_tbf0_patient_final")



# COMMAND ----------

query = "SELECT pat_id FROM {0}.{1}".format(SNFL_DB, SNFL_TEST_TBL_NAME)

df4 = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase", SNFL_DB) \
  .option("query", query) \
  .load()

#display(df4)
df4.createOrReplaceTempView("etl_proc_test_patient")

dfGood = spark.sql("select * from gg_tbf0_patient_final where pat_id not in (select pat_id from etl_proc_test_patient)")

# drop columns
dfGood = dfGood.drop("tracking_id")

# convert date and number columns
dfGood = dfGood.withColumn("cdc_txn_commit_dttm", to_timestamp(dfGood["cdc_txn_commit_dttm"]))\
               .withColumn("pat_birth_dttm", to_timestamp(dfGood["pat_birth_dttm"]))\
               .withColumn("create_dttm", to_timestamp(dfGood["create_dttm"]))\
               .withColumn("update_dttm", to_timestamp(dfGood["update_dttm"]))\
               .withColumn("pat_registration_dttm", to_timestamp(dfGood["pat_registration_dttm"]))\
               .withColumn("pat_hipaa_dttm", to_timestamp(dfGood["pat_hipaa_dttm"]))\
               .withColumn("pat_email_dttm", to_timestamp(dfGood["pat_email_dttm"]))\
               .withColumn("pat_lock_dttm", to_timestamp(dfGood["pat_lock_dttm"]))\
               .withColumn("pat_preg_due_dttm", to_timestamp(dfGood["pat_preg_due_dttm"]))\
               .withColumn("pat_90day_pref_dttm", to_timestamp(dfGood["pat_90day_pref_dttm"]))\
               .withColumn("create_user_id",when(dfGood["create_user_id"] == "",None).otherwise(dfGood["create_user_id"]))\
               .withColumn("update_user_id",when(dfGood["update_user_id"] == "",None).otherwise(dfGood["update_user_id"]))\
               .withColumn("pat_email_user_id",when(dfGood["pat_email_user_id"] == "",None).otherwise(dfGood["pat_email_user_id"]))\
               .withColumn("pat_lock_user_id",when(dfGood["pat_lock_user_id"] == "",None).otherwise(dfGood["pat_lock_user_id"]))\
               .withColumn("pat_create_store_nbr",when(dfGood["pat_create_store_nbr"] == "",None).otherwise(dfGood["pat_create_store_nbr"]))\
               .withColumn("pat_hipaa_store_nbr",when(dfGood["pat_hipaa_store_nbr"] == "",None).otherwise(dfGood["pat_hipaa_store_nbr"]))\
               .withColumn("pat_lock_store_nbr",when(dfGood["pat_lock_store_nbr"] == "",None).otherwise(dfGood["pat_lock_store_nbr"]))\
               .withColumn("auto_refill_pref_str_nbr",when(dfGood["auto_refill_pref_str_nbr"] == "",None).otherwise(dfGood["auto_refill_pref_str_nbr"]))\
               .withColumn("cdc_seq_nbr",when(dfGood["cdc_seq_nbr"] == "",None).otherwise(dfGood["cdc_seq_nbr"]))\
               .withColumn("pat_residence_cd",when(dfGood["pat_residence_cd"] == "",None).otherwise(dfGood["pat_residence_cd"]))\
               .withColumn("pat_prim_care_pbr_loc_id",when(dfGood["pat_prim_care_pbr_loc_id"] == "",None).otherwise(dfGood["pat_prim_care_pbr_loc_id"]))\
               .withColumn("cdc_rba_nbr",when(dfGood["cdc_rba_nbr"] == "",None).otherwise(dfGood["cdc_rba_nbr"]))\
               .withColumn("edw_batch_id",when(dfGood["edw_batch_id"] == "",None).otherwise(dfGood["edw_batch_id"]))\
               .withColumn("pat_id",when(dfGood["pat_id"] == "",None).otherwise(dfGood["pat_id"]))\
               .withColumn("pat_hoh_id",when(dfGood["pat_hoh_id"] == "",None).otherwise(dfGood["pat_hoh_id"]))\
               .withColumn("pat_prim_care_pbr_id",when(dfGood["pat_prim_care_pbr_id"] == "",None).otherwise(dfGood["pat_prim_care_pbr_id"]))

#Update Varchar columns to null
from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",sel_snfl_tbl)\
   .load()

#display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
#print(str_cols)


for col in str_cols:
  dfGood = dfGood.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))
  
display(dfGood)
print(f"Final good after union {dfGood.count()}")


# COMMAND ----------


dfBad = spark.sql("select * from gg_tbf0_patient where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

display(dfBad)

print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

#WRITING DATA IN OUTPUT AND RJECT FOLDER

dfG = dfGood.write.mode("overwrite").parquet(OUT_FILEPATH)

dfB = dfBad.write.mode("overwrite").parquet(REJ_BAD_FILEPATH)

  


# COMMAND ----------

# Delete records from snfk table

del_snfl_tbl = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


# COMMAND ----------

# Writing to the Snowflakes Table

dfGood=dfGood.withColumn("edw_batch_id",lit(BATCH_ID))

dfGood.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("dbtable", SNFL_TBL_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .option("truncate_table","ON")\
   .option("use staging table","OFF")\
   .mode("append") \
   .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

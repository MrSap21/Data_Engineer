# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# #Create Widgets for Parameters
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220128144200")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_PAT_THRD_PTY")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","GG_TBF0_PAT_THRD_PTY")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","/pharmacy_healthcare/patient/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","/pharmacy_healthcare/patient/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT.ETL_TBF0_PAT_THRD_PTY_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_UNPROCESSED_FILES","")

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")

import json
from pyspark.sql.functions import *
from pyspark.sql.types import *

readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
readList=readList.split(',')
print(readList)

# COMMAND ----------

#Implement Control Files Logic

# COMMAND ----------

# initializing variables
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
print (REJ_FILE_NOISE_RMV)
print(REJ_FILE_PAT_MOD)
print(REJ_FILE_UPD_NULL)
print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Define Input File Schema
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pat_id',
'pat_id_after',
'plan_id',
'plan_id_after',
'general_recipient_nbr',
'general_recipient_nbr_after',
'plan_group_nbr',
'plan_group_nbr_after',
'plan_pat_exp_dttm',
'plan_pat_exp_dttm_after',
'primary_plan_ind',
'primary_plan_ind_after',
'person_cd',
'person_cd_after',
'pat_plan_plcy_hldr_id',
'pat_plan_plcy_hldr_id_after',
'pat_plan_plcy_hldr_rel',
'pat_plan_plcy_hldr_rel_after',
'pat_usual_cust_ind',
'pat_usual_cust_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'upi',
'upi_after',
'pat_brand_copay',
'pat_brand_copay_after',
'pat_generic_copay',
'pat_generic_copay_after',
'pat_cob_ind',
'pat_cob_ind_after',
'pat_mfg_card_ind',
'pat_mfg_card_ind_after',
'pat_employer_id',
'pat_employer_id_after',
'pat_rem_ded_amt',
'pat_rem_ded_amt_after',
'pat_rem_ben_amt',
'pat_rem_ben_amt_after',
'maj_med_plan_id',
'maj_med_plan_id_after',
'image_id',
'image_id_after']

print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 61:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 62:
      return True
  else:
    if val_len != 62:
      return True

# COMMAND ----------

readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[8]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[8]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[8]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[8]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

# Read input files
# in_text = spark.read.text(readList)
# in_text = in_text.rdd

# Read files based on partitions
in1_text = spark.read.text(readList_src_1)
in2_text = spark.read.text(readList_src_2)
in3_text = spark.read.text(readList_src_3)
in4_text = spark.read.text(readList_src_4)
in1_text = in1_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in2_text = in2_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in3_text = in3_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in4_text = in4_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

# rdb = in_text.filter(lambda x: checkbad(x[0]))

# if rdb.count()>0:
#   df_junk = spark.createDataFrame(rdb)
#   df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)
  
rdb1 = in1_text.filter(lambda x: checkbad(x[0]))
rdb2 = in2_text.filter(lambda x: checkbad(x[0]))
rdb3 = in3_text.filter(lambda x: checkbad(x[0]))
rdb4 = in4_text.filter(lambda x: checkbad(x[0]))

rdb_count = rdb1.count()+ rdb2.count()+ rdb3.count()+ rdb4.count()
rdb= rdb1+rdb2+rdb3+rdb4
if rdb_count>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)  

# COMMAND ----------

print(rdb_count)

# COMMAND ----------

#split and add schema
col_len = 62

# rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

# print(f"Total count {rd1.count()}")

# rd_good = rd1.filter(lambda x: x[0] == col_len)
# rd_bad = rd1.filter(lambda x: x[0] != col_len)

# print(f"Good records count {rd_good.count()}") # = 62
# print(f"Bad records count {rd_bad.count()}") # != 62

rd1 = in1_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd2 = in2_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd3 = in3_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd4 = in4_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd1_good = rd1.filter(lambda x: x[0] == col_len)
rd2_good = rd2.filter(lambda x: x[0] == col_len)
rd3_good = rd3.filter(lambda x: x[0] == col_len)
rd4_good = rd4.filter(lambda x: x[0] == col_len)

rd_bad_all = rd1+rd2+rd3+rd4
rd_bad = rd_bad_all.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
# df = spark.createDataFrame(rd_good, schema)

df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

df = df_g1.union(df_g2).union(df_g3).union(df_g4)
#display(df)

# COMMAND ----------

#function to remove "" & \\ Only when the file is encrypted
def handlEscpeQuotes(val):
 if not val:
   return ""
  
  #remove rightmost "
 outval = val[0:-1]
  #remove leftmost "
 outval = outval.lstrip("\"")
  #replace double \\ with \
 outval = outval.replace("\\\\","\\")
  #replace double \" with "
 outval = outval.replace("\\\"","\"")
 return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

from functools import reduce
df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
#     df.columns,
#     df
# ))

df_gg = df.withColumn("table_name",lit("gg_pat_tbf0_thrd_pty")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 

df_gg.createOrReplaceTempView("raw_pat_gg_thrd_pty")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from raw_pat_gg_thrd_pty where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_pat_gg_thrd_pty where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_pat_gg_thrd_pty where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)


if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition

else:  
  sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETL_HIVE_CUTOFF_TBL)
  df_cutoff_records_output=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFK_ETL_DB) \
     .option("query",sel_ETL_Hive_Cutoff_tbl) \
     .load()


  cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
  cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

  #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
  cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
  RX_CUT_OFF_MAX_DTTM as rx_max,
  CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
  CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
  from cutoff_records_filter""" 
  cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
  

  #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
  cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
  RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
  from cutoff_records_filter"""
  cutoff_range_trans = spark.sql(cutoff_range_trans_sql)

  #Fetching rx_max and rx_trans_max as values
  rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
  rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max

  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_trans_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_trans_max)
  
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)
  
#Remove duplicates
dedup_group = nr_input_file_final.distinct()

#nr spacetrim
for col in dedup_group.columns:
    nr_spacetrim = dedup_group.withColumn(col, when(ltrim(rtrim(dedup_group[col])) == "",None).otherwise(ltrim(rtrim(dedup_group[col]))))

nr_spacetrim.createOrReplaceTempView("nr_spacetrim")



# COMMAND ----------

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND  cdc_before_after_cd_after IS NOT NULL)  AND  ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND  cdc_operation_type_cd_after IS NOT NULL) AND  (cdc_before_after_cd == 'BEFORE' AND  cdc_before_after_cd IS NOT NULL) AND  (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND  cdc_operation_type_cd IS NOT NULL ) AND RTRIM(LOWER(pat_id)) == RTRIM(LOWER(pat_id_after)) AND   pat_id IS NOT NULL AND   pat_id_after IS NOT NULL AND    RTRIM(LOWER(plan_id)) == RTRIM(LOWER(plan_id_after))  AND   plan_id IS NOT NULL AND   plan_id_after IS NOT NULL AND    general_recipient_nbr == general_recipient_nbr_after  AND   general_recipient_nbr IS NOT NULL AND   general_recipient_nbr_after IS NOT NULL AND    cdc_seq_nbr == cdc_seq_nbr_after  AND   cdc_seq_nbr IS NOT NULL AND   cdc_seq_nbr_after IS NOT NULL AND     cdc_rba_nbr == cdc_rba_nbr_after  AND   cdc_rba_nbr IS NOT NULL AND   cdc_rba_nbr_after IS NOT NULL AND    cdc_txn_commit_dttm == cdc_txn_commit_dttm_after  AND   cdc_txn_commit_dttm IS NOT NULL AND   cdc_txn_commit_dttm_after IS NOT NULL AND  (( RTRIM(LOWER(plan_group_nbr)) == RTRIM(LOWER(plan_group_nbr_after ))  AND plan_group_nbr IS NOT NULL AND plan_group_nbr_after IS NOT NULL ) OR ( plan_group_nbr IS NULL AND plan_group_nbr_after IS NULL )) AND  (( RTRIM(LOWER(plan_pat_exp_dttm)) == RTRIM(LOWER(plan_pat_exp_dttm_after ))  AND plan_pat_exp_dttm IS NOT NULL AND plan_pat_exp_dttm_after IS NOT NULL ) OR ( plan_pat_exp_dttm IS NULL AND plan_pat_exp_dttm_after IS NULL )) AND  (( RTRIM(LOWER(primary_plan_ind)) == RTRIM(LOWER(primary_plan_ind_after ))  AND primary_plan_ind IS NOT NULL AND primary_plan_ind_after IS NOT NULL ) OR ( primary_plan_ind IS NULL AND primary_plan_ind_after IS NULL )) AND  (( RTRIM(LOWER(person_cd)) == RTRIM(LOWER(person_cd_after ))  AND person_cd IS NOT NULL AND person_cd_after IS NOT NULL ) OR ( person_cd IS NULL AND person_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_plan_plcy_hldr_id)) == RTRIM(LOWER(pat_plan_plcy_hldr_id_after ))  AND pat_plan_plcy_hldr_id IS NOT NULL AND pat_plan_plcy_hldr_id_after IS NOT NULL ) OR ( pat_plan_plcy_hldr_id IS NULL AND pat_plan_plcy_hldr_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_plan_plcy_hldr_rel)) == RTRIM(LOWER(pat_plan_plcy_hldr_rel_after ))  AND pat_plan_plcy_hldr_rel IS NOT NULL AND pat_plan_plcy_hldr_rel_after IS NOT NULL ) OR ( pat_plan_plcy_hldr_rel IS NULL AND pat_plan_plcy_hldr_rel_after IS NULL )) AND  (( RTRIM(LOWER(pat_usual_cust_ind)) == RTRIM(LOWER(pat_usual_cust_ind_after ))  AND pat_usual_cust_ind IS NOT NULL AND pat_usual_cust_ind_after IS NOT NULL ) OR ( pat_usual_cust_ind IS NULL AND pat_usual_cust_ind_after IS NULL )) AND  (( RTRIM(LOWER(upi)) == RTRIM(LOWER(upi_after ))  AND upi IS NOT NULL AND upi_after IS NOT NULL ) OR ( upi IS NULL AND upi_after IS NULL )) AND  (( RTRIM(LOWER(pat_brand_copay)) == RTRIM(LOWER(pat_brand_copay_after ))  AND pat_brand_copay IS NOT NULL AND pat_brand_copay_after IS NOT NULL ) OR ( pat_brand_copay IS NULL AND pat_brand_copay_after IS NULL )) AND  (( RTRIM(LOWER(pat_generic_copay)) == RTRIM(LOWER(pat_generic_copay_after ))  AND pat_generic_copay IS NOT NULL AND pat_generic_copay_after IS NOT NULL ) OR ( pat_generic_copay IS NULL AND pat_generic_copay_after IS NULL )) AND  (( RTRIM(LOWER(pat_cob_ind)) == RTRIM(LOWER(pat_cob_ind_after ))  AND pat_cob_ind IS NOT NULL AND pat_cob_ind_after IS NOT NULL ) OR ( pat_cob_ind IS NULL AND pat_cob_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_mfg_card_ind)) == RTRIM(LOWER(pat_mfg_card_ind_after ))  AND pat_mfg_card_ind IS NOT NULL AND pat_mfg_card_ind_after IS NOT NULL ) OR ( pat_mfg_card_ind IS NULL AND pat_mfg_card_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_employer_id)) == RTRIM(LOWER(pat_employer_id_after ))  AND pat_employer_id IS NOT NULL AND pat_employer_id_after IS NOT NULL ) OR ( pat_employer_id IS NULL AND pat_employer_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_rem_ded_amt)) == RTRIM(LOWER(pat_rem_ded_amt_after ))  AND pat_rem_ded_amt IS NOT NULL AND pat_rem_ded_amt_after IS NOT NULL ) OR ( pat_rem_ded_amt IS NULL AND pat_rem_ded_amt_after IS NULL )) AND  (( RTRIM(LOWER(pat_rem_ben_amt)) == RTRIM(LOWER(pat_rem_ben_amt_after ))  AND pat_rem_ben_amt IS NOT NULL AND pat_rem_ben_amt_after IS NOT NULL ) OR ( pat_rem_ben_amt IS NULL AND pat_rem_ben_amt_after IS NULL )) AND  (( RTRIM(LOWER(maj_med_plan_id)) == RTRIM(LOWER(maj_med_plan_id_after ))  AND maj_med_plan_id IS NOT NULL AND maj_med_plan_id_after IS NOT NULL ) OR ( maj_med_plan_id IS NULL AND maj_med_plan_id_after IS NULL )) AND  (( RTRIM(LOWER(image_id)) == RTRIM(LOWER(image_id_after ))  AND image_id IS NOT NULL AND image_id_after IS NOT NULL ) OR ( image_id IS NULL AND image_id_after IS NULL )) )"

# COMMAND ----------

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

gg_tbf0_rejected_query = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(gg_tbf0_rejected_query)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 
  
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")


# COMMAND ----------

gg_tbf0_update_afr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm_after.alias("cdc_txn_commit_dttm"), \
                                            gg_tbf0_update.cdc_seq_nbr_after.alias("cdc_seq_nbr"), \
                                            gg_tbf0_update.cdc_rba_nbr_after.alias("cdc_rba_nbr"), \
                                            gg_tbf0_update.cdc_operation_type_cd_after.alias("cdc_operation_type_cd"), \
                                            gg_tbf0_update.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                            gg_tbf0_update.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                            gg_tbf0_update.edw_batch_id_after.alias("edw_batch_id"), \
                                            gg_tbf0_update.src_partition_nbr_after.alias("src_partition_nbr"), \
                                            gg_tbf0_update.pat_id_after.alias("pat_id"), \
                                            gg_tbf0_update.plan_id_after.alias("plan_id"), \
                                            gg_tbf0_update.general_recipient_nbr_after.alias("general_recipient_nbr"), \
                                            gg_tbf0_update.plan_group_nbr_after.alias("plan_group_nbr"), \
                                            gg_tbf0_update.plan_pat_exp_dttm_after.alias("plan_pat_exp_dttm"), \
                                            gg_tbf0_update.primary_plan_ind_after.alias("primary_plan_ind"), \
                                            gg_tbf0_update.person_cd_after.alias("person_cd"), \
                                            gg_tbf0_update.pat_plan_plcy_hldr_id_after.alias("pat_plan_plcy_hldr_id"), \
                                            gg_tbf0_update.pat_plan_plcy_hldr_rel_after.alias("pat_plan_plcy_hldr_rel"), \
                                            gg_tbf0_update.pat_usual_cust_ind_after.alias("pat_usual_cust_ind"), \
                                            gg_tbf0_update.create_user_id_after.alias("create_user_id"), \
                                            gg_tbf0_update.create_dttm_after.alias("create_dttm"), \
                                            gg_tbf0_update.update_user_id_after.alias("update_user_id"), \
                                            gg_tbf0_update.update_dttm_after.alias("update_dttm"), \
                                            gg_tbf0_update.upi_after.alias("upi"), \
                                            gg_tbf0_update.pat_brand_copay_after.alias("pat_brand_copay"), \
                                            gg_tbf0_update.pat_generic_copay_after.alias("pat_generic_copay"), \
                                            gg_tbf0_update.pat_cob_ind_after.alias("pat_cob_ind"), \
                                            gg_tbf0_update.pat_mfg_card_ind_after.alias("pat_mfg_card_ind"), \
                                            gg_tbf0_update.pat_employer_id_after.alias("pat_employer_id"), \
                                            gg_tbf0_update.pat_rem_ded_amt_after.alias("pat_rem_ded_amt"), \
                                            gg_tbf0_update.pat_rem_ben_amt_after.alias("pat_rem_ben_amt"), \
                                            gg_tbf0_update.maj_med_plan_id_after.alias("maj_med_plan_id"), \
                                            gg_tbf0_update.image_id_after.alias("image_id"), \
                                            gg_tbf0_update.table_name)

gg_tbf0_update_bfr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd.alias("cdc_before_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id.alias("edw_batch_id"), \
                                           gg_tbf0_update.src_partition_nbr.alias("src_partition_nbr"), \
                                           gg_tbf0_update.pat_id.alias("pat_id"), \
                                           gg_tbf0_update.plan_id.alias("plan_id"), \
                                           gg_tbf0_update.general_recipient_nbr.alias("general_recipient_nbr"), \
                                           gg_tbf0_update.plan_group_nbr.alias("plan_group_nbr"), \
                                           gg_tbf0_update.plan_pat_exp_dttm.alias("plan_pat_exp_dttm"), \
                                           gg_tbf0_update.primary_plan_ind.alias("primary_plan_ind"), \
                                           gg_tbf0_update.person_cd.alias("person_cd"), \
                                           gg_tbf0_update.pat_plan_plcy_hldr_id.alias("pat_plan_plcy_hldr_id"), \
                                           gg_tbf0_update.pat_plan_plcy_hldr_rel.alias("pat_plan_plcy_hldr_rel"), \
                                           gg_tbf0_update.pat_usual_cust_ind.alias("pat_usual_cust_ind"), \
                                           gg_tbf0_update.create_user_id.alias("create_user_id"), \
                                           gg_tbf0_update.create_dttm.alias("create_dttm"), \
                                           gg_tbf0_update.update_user_id.alias("update_user_id"), \
                                           gg_tbf0_update.update_dttm.alias("update_dttm"), \
                                           gg_tbf0_update.upi.alias("upi"), \
                                           gg_tbf0_update.pat_brand_copay.alias("pat_brand_copay"), \
                                           gg_tbf0_update.pat_generic_copay.alias("pat_generic_copay"), \
                                           gg_tbf0_update.pat_cob_ind.alias("pat_cob_ind"), \
                                           gg_tbf0_update.pat_mfg_card_ind.alias("pat_mfg_card_ind"), \
                                           gg_tbf0_update.pat_employer_id.alias("pat_employer_id"), \
                                           gg_tbf0_update.pat_rem_ded_amt.alias("pat_rem_ded_amt"), \
                                           gg_tbf0_update.pat_rem_ben_amt.alias("pat_rem_ben_amt"), \
                                           gg_tbf0_update.maj_med_plan_id.alias("maj_med_plan_id"), \
                                           gg_tbf0_update.image_id.alias("image_id"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_insert_afr = nr_insert_check.select(nr_insert_check.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                            nr_insert_check.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                            nr_insert_check.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                            nr_insert_check.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                            nr_insert_check.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                            nr_insert_check.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                            nr_insert_check.edw_batch_id_after.alias("edw_batch_id"), \
                                            nr_insert_check.src_partition_nbr_after.alias("src_partition_nbr"), \
                                            nr_insert_check.pat_id_after.alias("pat_id"), \
                                            nr_insert_check.plan_id_after.alias("plan_id"), \
                                            nr_insert_check.general_recipient_nbr_after.alias("general_recipient_nbr"), \
                                            nr_insert_check.plan_group_nbr_after.alias("plan_group_nbr"), \
                                            nr_insert_check.plan_pat_exp_dttm_after.alias("plan_pat_exp_dttm"), \
                                            nr_insert_check.primary_plan_ind_after.alias("primary_plan_ind"), \
                                            nr_insert_check.person_cd_after.alias("person_cd"), \
                                            nr_insert_check.pat_plan_plcy_hldr_id_after.alias("pat_plan_plcy_hldr_id"), \
                                            nr_insert_check.pat_plan_plcy_hldr_rel_after.alias("pat_plan_plcy_hldr_rel"), \
                                            nr_insert_check.pat_usual_cust_ind_after.alias("pat_usual_cust_ind"), \
                                            nr_insert_check.create_user_id_after.alias("create_user_id"), \
                                            nr_insert_check.create_dttm_after.alias("create_dttm"), \
                                            nr_insert_check.update_user_id_after.alias("update_user_id"), \
                                            nr_insert_check.update_dttm_after.alias("update_dttm"), \
                                            nr_insert_check.upi_after.alias("upi"), \
                                            nr_insert_check.pat_brand_copay_after.alias("pat_brand_copay"), \
                                            nr_insert_check.pat_generic_copay_after.alias("pat_generic_copay"), \
                                            nr_insert_check.pat_cob_ind_after.alias("pat_cob_ind"), \
                                            nr_insert_check.pat_mfg_card_ind_after.alias("pat_mfg_card_ind"), \
                                            nr_insert_check.pat_employer_id_after.alias("pat_employer_id"), \
                                            nr_insert_check.pat_rem_ded_amt_after.alias("pat_rem_ded_amt"), \
                                            nr_insert_check.pat_rem_ben_amt_after.alias("pat_rem_ben_amt"), \
                                            nr_insert_check.maj_med_plan_id_after.alias("maj_med_plan_id"), \
                                            nr_insert_check.image_id_after.alias("image_id"), \
                                            nr_insert_check.table_name)

# COMMAND ----------

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pPatIdModCheck="(CAST(pat_id AS LONG)%4 == CAST(src_partition_nbr AS INTEGER) -1) AND (table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where "

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")


# COMMAND ----------

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, pat_id, plan_id, general_recipient_nbr, plan_group_nbr, CONCAT(substring(plan_pat_exp_dttm,0,10),' ',substring(plan_pat_exp_dttm,12,19),'.000000') AS plan_pat_exp_dttm, primary_plan_ind, person_cd, pat_plan_plcy_hldr_id, pat_plan_plcy_hldr_rel, pat_usual_cust_ind, create_user_id, CONCAT(substring(create_dttm,0,10),' ',substring(create_dttm,12,19),'.000000') AS create_dttm, update_user_id, CONCAT(substring(update_dttm,0,10),' ',substring(update_dttm,12,19),'.000000') AS update_dttm, upi, pat_brand_copay, pat_generic_copay, pat_cob_ind, pat_mfg_card_ind, pat_employer_id, pat_rem_ded_amt, pat_rem_ben_amt, maj_med_plan_id, image_id, src_partition_nbr"

# COMMAND ----------

etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Remove Blank Values
for col in etl_tbf0_reformat.columns:
    etl_tbf0_reformat = etl_tbf0_reformat.withColumn(col, when(ltrim(rtrim(etl_tbf0_reformat[col])) == "",None).otherwise(ltrim(rtrim(etl_tbf0_reformat[col]))))
    
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())\
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
.withColumn("plan_pat_exp_dttm",to_timestamp(etl_tbf0_reformat["plan_pat_exp_dttm"])) \
.withColumn("create_dttm",to_timestamp(etl_tbf0_reformat["create_dttm"])) \
.withColumn("update_dttm",to_timestamp(etl_tbf0_reformat["update_dttm"]))
#.withColumn("src_partition_nbr",lit("1"))

etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)


# COMMAND ----------

#Load ETL_TBF0_PAT_THRD_PTY_STG formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()
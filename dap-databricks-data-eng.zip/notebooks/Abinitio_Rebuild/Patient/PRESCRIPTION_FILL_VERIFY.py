# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
# REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB_STG = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_SNFK_STG_TBL_NAME")
SNFL_IDL_TBL_NAME = dbutils.widgets.get("PAR_SNFK_IDL_TBL_NAME")
SNFL_DB_IDL = dbutils.widgets.get("PAR_DB_IDL")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID



# COMMAND ----------

# MAGIC 
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")


# COMMAND ----------

# Extracting File Name and Path

import os
# from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")



readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]


# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['RX_NBR',             
'STORE_NBR',              
'FILL_NBR',         
'FILL_NBR_DISPENSED',
'TRANSACTION_ID',
# 'REQST_ACTN_CD',       
'TRANSACTION_DATE',         
'PHARMACY_ID', 
'PHARMACY_ID_TYPE',        
'PHARMACY_TRANSACTION_ID',         
'REQUEST_ACTION',
'RESPONSE_CD',         
'RESPONSE_ACTN',       
'RESPONSE_MSG',       
'VRX_CALL_ORIGIN',     
'CREATE_USER_ID',  
'CREATE_DTTM',
'UPDATE_USER_ID', 
'UPDATE_DTTM',
'Add_col']


# COMMAND ----------

# readList="/mnt/wrangled/pharmacy_healthcare/lexis_nexis/lnverify-1001-tbf0_ln_vrx_20210907000501_20210909001102.dat"

# pharmacy_healthcare/patient/output/tablename/batchid
in_text = spark.read.text(readList)
in_text = in_text.rdd
# display(in_text)
# in_text.show()


# COMMAND ----------

#split and add schema

import re
de="\x01"
#delimiter1 = re.escape('^|~')
delimiter = de.encode('utf-8').decode('unicode-escape')


rd1 = in_text.map(lambda rw: rw[0].split(delimiter))

#print(f"Total count {rd1.count()}")

#rd_good = rd1.filter(lambda x: x[0] == col_len)
#rd_bad = rd1.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd1, schema)


# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

#df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    df.columns,
    df
))


# COMMAND ----------

#CAST(from_unixtime(to_unix_timestamp (current_timestamp(),'yyyy-MM-dd HH:mm:ss'))  as  TIMESTAMP) as CREATE_DTTM ,
#CAST(from_unixtime(to_unix_timestamp (current_timestamp(),'yyyy-MM-dd HH:mm:ss'))  as  TIMESTAMP) as UPDATE_DTTM,
#CAST('${hivevar:pEDWBatchId}' as  DECIMAL(18,0)) as  EDW_BATCH_ID,
#CAST(DATE_FORMAT(transaction_date,'yyyy') as STRING) as VRFY_TXN_YR,
#CAST(DATE_FORMAT(transaction_date,'MM') as STRING) as VRFY_TXN_MNTH
from pyspark.sql.functions import col, substring, lit
df = df.distinct()
df = df.withColumnRenamed("CREATE_USER_ID","SRC_CREATE_USER_ID") \
   .withColumnRenamed("CREATE_DTTM","SRC_CREATE_DTTM") \
   .withColumnRenamed("UPDATE_USER_ID","SRC_UPDATE_USER_ID") \
   .withColumnRenamed("UPDATE_DTTM","SRC_UPDATE_DTTM")

df=df.withColumn("CREATE_DTTM",current_timestamp()).withColumn("UPDATE_DTTM",current_timestamp())

df=df.withColumn("EDW_BATCH_ID",lit(BATCH_ID)).withColumn("VRFY_TXN_YR",substring(lit(df.TRANSACTION_DATE),1, 4)).withColumn("VRFY_TXN_MNTH",substring(lit(df.TRANSACTION_DATE),6, 2)).drop("Add_col")



# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_pat_thrd_pty")

# COMMAND ----------

sel_qry = """select 
(case when (LENGTH(trim(RX_NBR)) ==0) then RX_NBR else trim(RX_NBR)end) as RX_NBR,
(case when (LENGTH(trim(STORE_NBR)) ==0) then STORE_NBR else trim(STORE_NBR)end) as STR_NBR,
(case when (LENGTH(trim(FILL_NBR)) ==0) then FILL_NBR else trim(FILL_NBR)end) as RX_FILL_NBR,
(case when (LENGTH(trim(FILL_NBR_DISPENSED)) ==0) then FILL_NBR_DISPENSED else trim(FILL_NBR_DISPENSED)end) as RX_FILL_NBR_DSPN,
(case when (LENGTH(trim(REQUEST_ACTION)) ==0) then REQUEST_ACTION else trim(REQUEST_ACTION)end) as REQST_ACTN_CD,
(case when (LENGTH(trim(RESPONSE_CD)) ==0) then RESPONSE_CD else trim(RESPONSE_CD)end) as RESPONSE_CD,
(case when (LENGTH(trim(TRANSACTION_ID)) ==0) then TRANSACTION_ID else trim(TRANSACTION_ID)end) as VRFY_TXN_ID,
(case when (LENGTH(trim(TRANSACTION_DATE)) ==0) then TRANSACTION_DATE else trim(TRANSACTION_DATE)end) as VRFY_TXN_DT,
(case when (LENGTH(trim(PHARMACY_ID)) ==0) then PHARMACY_ID else trim(PHARMACY_ID)end) as STR_NPI_NBR,
(case when (LENGTH(trim(PHARMACY_ID_TYPE)) ==0) then PHARMACY_ID_TYPE else trim(PHARMACY_ID_TYPE)end) as PHRM_SERVICE_TYPE_CD,
(case when (LENGTH(trim(PHARMACY_TRANSACTION_ID)) ==0) then PHARMACY_TRANSACTION_ID else trim(PHARMACY_TRANSACTION_ID)end) as PHRM_TXN_ID,
(case when (LENGTH(trim(RESPONSE_ACTN)) ==0) then RESPONSE_ACTN else trim(RESPONSE_ACTN)end) as RESPONSE_ACTN,
(case when (LENGTH(trim(RESPONSE_MSG)) ==0) then RESPONSE_MSG else trim(RESPONSE_MSG)end) as RESPONSE_MSG,
(case when (LENGTH(trim(VRX_CALL_ORIGIN)) ==0) then VRX_CALL_ORIGIN else trim(VRX_CALL_ORIGIN)end) as VRX_CALL_ORIGIN,
(case when (LENGTH(trim(SRC_CREATE_USER_ID)) ==0) then SRC_CREATE_USER_ID else trim(SRC_CREATE_USER_ID)end) as SRC_CREATE_USER_ID,
(case when (LENGTH(trim(SRC_CREATE_DTTM )) ==0) then  SRC_CREATE_DTTM else concat(substring(SRC_CREATE_DTTM,1,10),' ',substring(SRC_CREATE_DTTM,12,8),'.000000') end) as SRC_CREATE_DTTM,
(case when (LENGTH(trim(SRC_UPDATE_USER_ID)) ==0) then SRC_UPDATE_USER_ID else trim(SRC_UPDATE_USER_ID)end) as SRC_UPDATE_USER_ID,
(case when (LENGTH(trim(SRC_UPDATE_DTTM )) ==0) then  SRC_UPDATE_DTTM else concat(substring(SRC_UPDATE_DTTM,1,10),' ',substring(SRC_UPDATE_DTTM,12,8),'.000000') end) as SRC_UPDATE_DTTM,
CREATE_DTTM,
UPDATE_DTTM, 
(case when (LENGTH(trim(EDW_BATCH_ID)) ==0) then EDW_BATCH_ID else trim(EDW_BATCH_ID)end) as EDW_BATCH_ID
from gg_tbf0_pat_thrd_pty"""

# COMMAND ----------

dfFinal = spark.sql(sel_qry)


# COMMAND ----------

dfGood = dfFinal.withColumn("RX_NBR",when(col("RX_NBR") =="",None).otherwise(col("RX_NBR"))).withColumn("STR_NBR",when(col("STR_NBR") =="",None).otherwise(col("STR_NBR"))).withColumn("RX_FILL_NBR",when(col("RX_FILL_NBR") =="",None).otherwise(col("RX_FILL_NBR"))).withColumn("RX_FILL_NBR_DSPN",when(col("RX_FILL_NBR_DSPN") =="",None).otherwise(col("RX_FILL_NBR_DSPN"))).withColumn("REQST_ACTN_CD",when(col("REQST_ACTN_CD") =="",None).otherwise(col("REQST_ACTN_CD"))).withColumn("RESPONSE_CD",when(col("RESPONSE_CD") =="",None).otherwise(col("RESPONSE_CD"))).withColumn("VRFY_TXN_ID",when(col("VRFY_TXN_ID") =="",None).otherwise(col("VRFY_TXN_ID"))).withColumn("VRFY_TXN_DT",when(col("VRFY_TXN_DT") =="",None).otherwise(to_date(dfFinal["VRFY_TXN_DT"]))).withColumn("STR_NPI_NBR",when(col("STR_NPI_NBR") =="",None).otherwise(col("STR_NPI_NBR"))).withColumn("PHRM_SERVICE_TYPE_CD",when(col("PHRM_SERVICE_TYPE_CD") =="",None).otherwise(col("PHRM_SERVICE_TYPE_CD"))).withColumn("PHRM_TXN_ID",when(col("PHRM_TXN_ID") =="",None).otherwise(col("PHRM_TXN_ID"))).withColumn("RESPONSE_ACTN",when(col("RESPONSE_ACTN") =="",None).otherwise(col("RESPONSE_ACTN"))).withColumn("RESPONSE_MSG",when(col("RESPONSE_MSG") =="",None).otherwise(col("RESPONSE_MSG"))).withColumn("VRX_CALL_ORIGIN",when(col("VRX_CALL_ORIGIN") =="",None).otherwise(col("VRX_CALL_ORIGIN"))).withColumn("SRC_CREATE_USER_ID",when(col("SRC_CREATE_USER_ID") =="",None).otherwise(col("SRC_CREATE_USER_ID"))).withColumn("SRC_CREATE_DTTM",when(col("SRC_CREATE_DTTM") =="",None).otherwise(to_timestamp(dfFinal["SRC_CREATE_DTTM"]))).withColumn("SRC_UPDATE_USER_ID",when(col("SRC_UPDATE_USER_ID") =="",None).otherwise(col("SRC_UPDATE_USER_ID"))).withColumn("SRC_UPDATE_DTTM",when(col("SRC_UPDATE_DTTM") =="",None).otherwise(to_timestamp(dfFinal["SRC_UPDATE_DTTM"]))).withColumn("CREATE_DTTM",when(col("CREATE_DTTM") =="",None).otherwise(to_timestamp(dfFinal["CREATE_DTTM"]))).withColumn("UPDATE_DTTM",when(col("UPDATE_DTTM") =="",None).otherwise(to_timestamp(dfFinal["UPDATE_DTTM"]))).withColumn("EDW_BATCH_ID",when(col("EDW_BATCH_ID") =="",None).otherwise(col("EDW_BATCH_ID")))


# COMMAND ----------


#import pandas as pd
from datetime import datetime


#Update varchars as null

from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB_STG) \
   .option("query",sel_snfl_tbl)\
   .load()

#display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
#print(str_cols)


for col in str_cols:
  dfGood = dfGood.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))




# COMMAND ----------

#WRITING DATA IN OUTPUT AND RJECT FOLDER

# dfG = dfGood.write.mode('overwrite').parquet(OUT_FILEPATH)

# COMMAND ----------

# Delete records from snfk table

del_snfl_tbl = "DELETE FROM {0}.{1}".format(SNFL_DB_STG, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB_STG,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


# COMMAND ----------

# Writing to the Snowflakes stage Table

dfGood.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB_STG) \
   .option("dbtable", SNFL_TBL_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

# Writing to the Snowflakes IDL Table 

dfGood.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB_IDL) \
   .option("dbtable", SNFL_IDL_TBL_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

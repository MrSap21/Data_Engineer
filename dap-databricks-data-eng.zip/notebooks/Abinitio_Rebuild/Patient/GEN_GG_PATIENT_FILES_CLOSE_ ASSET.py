# Databricks notebook source
# dbutils.widgets.text("PAR_FEED_NAME","gg_patient,gg_patient_phone")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")
# dbutils.widgets.text("PAR_WRITEAPI_KEY1","statusId")
# dbutils.widgets.text("PAR_WRITEAPI_VALUE1","200")
# dbutils.widgets.text("PAR_WRITEAPI_KEY2","assetId")
# dbutils.widgets.text("PAR_READAPI_KEY","feedName")

# COMMAND ----------

# ReadAPI Call to fetch asset id's
try:
  FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
  READAPI_URL=dbutils.widgets.get("PAR_READAPI_URL")
  READAPI_KEY=dbutils.widgets.get("PAR_READAPI_KEY")
  Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPINative", 600, 
                    {"PAR_READAPI_KEY":READAPI_KEY,
                     "PAR_READAPI_URL":READAPI_URL,
                     "PAR_READAPI_VALUE":FEED_NAME,
                     "PAR_RETURN_FILE_TYPE":"A"});
except:
  print("No Active Asset Found/READ API FAILED")
  dbutils.notebook.exit("No Active Asset Found/READ API FAILED")

# COMMAND ----------

import json
from pyspark.sql import *
from pyspark.sql.functions import concat,lit,explode, col

FeedNameList=FEED_NAME.split(",")
dfAssetIdStrFinal=''

for Feedname in FeedNameList :
  if Feedname.upper() in Input_File_List.upper():
    rddjson = sc.parallelize([Input_File_List])
    #print(rddjson.collect())

    dfFileList = sqlContext.read.json(rddjson).withColumn(Feedname,explode(col(Feedname))) \
    .select(f"{Feedname}.assetcurrentlocation",
    f"{Feedname}.assetid",
    f"{Feedname}.assetname")
    dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

    #display(dfRaw)

    #Create list of asset id's to return for WriteAPI
    dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
    dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]

    dfAssetIdStr="{}".format(dfAssetIdArray).replace("[","").replace("]","").replace(" ","")
    dfAssetIdStrFinal+=dfAssetIdStr+','
dfAssetIdStrFinal=dfAssetIdStrFinal[0:len(dfAssetIdStrFinal)-1]
print(dfAssetIdStrFinal)

# COMMAND ----------

#Write API to Update Asset Status
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1=dbutils.widgets.get("PAR_WRITEAPI_KEY1")
PAR_WRITEAPI_VALUE1=dbutils.widgets.get("PAR_WRITEAPI_VALUE1")
PAR_WRITEAPI_KEY2=dbutils.widgets.get("PAR_WRITEAPI_KEY2")
PAR_WRITEAPI_VALUE2=dfAssetIdStrFinal

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit("Active Assets Closed")

# COMMAND ----------



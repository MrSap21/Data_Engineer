# Databricks notebook source
# # dbutils.widgets.text("PAR_DB_BATCH_ID","20211109084501")
# # dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_patient")
# # dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient/output")
# # dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient/reject")
# # dbutils.widgets.text("PAR_DB_SNFK_DB","UAT_STAGING")
# # dbutils.widgets.text("PAR_DB_SNFK_ETL","UAT_ETL")
# # dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT.GG_TBF0_PATIENT_STG")
# # dbutils.widgets.text("PAR_DB_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# # dbutils.widgets.text("PAR_FEED_NAME","gg_patient")
# # dbutils.widgets.text("PAR_READAPI_URL","https://dapuatappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# # dbutils.widgets.text("SNFL_CUTTOFF_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# # dbutils.widgets.text("PAR_DB_SNFK_TEST_TBL_NAME","PATIENT.ETL_PROC_TEST_PATIENT_STG")
# #dbutils.widgets.text("PAR_UNPROCESSED_FILES","{'gg_patient': [{'assetid': 4457, 'assetname': 'PRDRX2STAGE_GG_TBF0_PATIENT_3_2022-01-29_01-27-04_02366_data_20220129215948.dsv', 'assetcurrentlocation': 'master_data/customer/icplus/2022/02/02/'}, {'assetid': 4458, 'assetname': 'PRDRX2STAGE_GG_TBF0_PATIENT_4_2022-01-29_01-27-02_02379_data_20220129220005.dsv', 'assetcurrentlocation': 'master_data/customer/icplus/2022/02/02/'}, {'assetid': 4459, 'assetname': 'PRDRX2STAGE_GG_TBF0_PATIENT_2_2022-01-29_01-27-02_02379_data_20220129220005.dsv', 'assetcurrentlocation': 'master_data/customer/icplus/2022/02/02/'}, {'assetid': 4460, 'assetname': 'PRDRX2STAGE_GG_TBF0_PATIENT_1_2022-01-29_01-27-04_02373_data_20220129215948.dsv', 'assetcurrentlocation': 'master_data/customer/icplus/2022/02/02/'}]}")
# # dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# # dbutils.widgets.text("PAR_PIPELINE_NAME","rx_PostLoad_PrescriptionFill_Child_Proc")
# # dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# # dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# # dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")
# # dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
#dbutils.widgets.remove("PAR_UnprocessedFiles")
# #dbutils.widgets.remove("PAR_UNPROCESSED_FILES")
# # ReadAPI Call to fetch asset file names with current location:  
# dbutils.widgets.text("PAR_FEED_NAME","gg_patient")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")

# COMMAND ---------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 10000, 
                 {"PAR_EDW_BATCH_ID":BATCH_ID,
                  "PAR_FEED_NAMES":FEED_NAME,
                  "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                  "PAR_READAPI_URL":READAPI_URL,
                  "PAR_SQL_SERVER":PAR_SQL_SERVER,
                  "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                  "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                  "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                  "PAR_RETURN_FILE_TYPE":"A"});

print(Input_File_List)


#FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
#READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")



#print(Input_File_List)


# COMMAND ----------

check=Input_File_List.split()
print(check)
countcheck=check.count("'assetname':")
print(countcheck)

# COMMAND ----------

# initializing variables
#Input_File_List=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
#print(Input_File_List)
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFL_TEST_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TEST_TBL_NAME")
SNFL_ETL_DB=dbutils.widgets.get("PAR_DB_SNFK_ETL")
SNFL_CUTTOFF_TBL_NAME=dbutils.widgets.get("SNFL_CUTTOFF_TBL_NAME")
#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'
#print (IN_DATAFILE)
# print (OUT_FILEPATH)
# #print (REJ_FILEPATH)
# print(REJ_BAD_FILEPATH)
# print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *


rddjson = sc.parallelize([Input_File_List])

if countcheck>1:
  dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(FEED_NAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")


else:
  dfFileList = sqlContext.read.json(rddjson).select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")


# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]


# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit,explode, col
from pyspark.sql.types import *

# #inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
# rddjson = sc.parallelize([Input_File_List])
# #print(rddjson.collect())

# dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(FEED_NAME))) \
# .select(f"{FEED_NAME}.assetcurrentlocation",
# f"{FEED_NAME}.assetid",
# f"{FEED_NAME}.assetname")
# dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

# #display(dfRaw)

# #Create list of asset id's to return for WriteAPI
# dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
# dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
# dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
#print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

# getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
# getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

# dfNamePath = dfRaw\
#              .withColumn("filepath", getPathUDF("full_filename"))\
#              .withColumn("filename", getNameUDF("full_filename"))\
#              .drop("full_filename")

#display(dfNamePath)


#Input_File_List1=''.join(Input_File_List)
#readList=Input_File_List.split(",")

#readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

#print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.text("PAR_DB_FILE_LIST","DAPDEVDWH01.PRDRX2STAGE")
#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pat_id',
'pat_id_after',
'pat_first_name',
'pat_first_name_after',
'pat_mid_init',
'pat_mid_init_after',
'pat_last_name',
'pat_last_name_after',
'pat_last_name_soundex',
'pat_last_name_soundex_after',
'pat_surname_suffix',
'pat_surname_suffix_after',
'pat_street_addr',
'pat_street_addr_after',
'pat_city',
'pat_city_after',
'pat_state',
'pat_state_after',
'pat_zip',
'pat_zip_after',
'pat_sex_cd',
'pat_sex_cd_after',
'pat_birth_dttm',
'pat_birth_dttm_after',
'pat_prim_area_cd',
'pat_prim_area_cd_after',
'pat_prim_phone',
'pat_prim_phone_after',
'pat_prim_phone_cd',
'pat_prim_phone_cd_after',
'pat_sec_area_cd',
'pat_sec_area_cd_after',
'pat_sec_phone',
'pat_sec_phone_after',
'pat_hoh_id',
'pat_hoh_id_after',
'pat_hoh_relation_cd',
'pat_hoh_relation_cd_after',
'pat_discount_cd',
'pat_discount_cd_after',
'pat_clinic_medical_id',
'pat_clinic_medical_id_after',
'pat_snap_cap_pref',
'pat_snap_cap_pref_after',
'pat_generic_subs_pref',
'pat_generic_subs_pref_after',
'pat_thera_subs_pref',
'pat_thera_subs_pref_after',
'pat_mail_list_pref',
'pat_mail_list_pref_after',
'pat_lang_pref_cd',
'pat_lang_pref_cd_after',
'pat_purged_rx_ind',
'pat_purged_rx_ind_after',
'pat_pet_ind',
'pat_pet_ind_after',
'pat_pet_type',
'pat_pet_type_after',
'pat_preappr_pay_ind',
'pat_preappr_pay_ind_after',
'pat_cc_nbr',
'pat_cc_nbr_after',
'pat_mail_service_id',
'pat_mail_service_id_after',
'pat_cmts',
'pat_cmts_after',
'pat_create_store_nbr',
'pat_create_store_nbr_after',
'pat_deceased_ind',
'pat_deceased_ind_after',
'pat_algy_hlth_type_cd',
'pat_algy_hlth_type_cd_after',
'pat_algy_hlth_cd_inq_ind',
'pat_algy_hlth_cd_inq_ind_after',
'pat_wc_ind',
'pat_wc_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'pat_phone_contact_pref',
'pat_phone_contact_pref_after',
'pat_signature_ind',
'pat_signature_ind_after',
'pat_internet_ind',
'pat_internet_ind_after',
'pat_ext_rx_otc_ind',
'pat_ext_rx_otc_ind_after',
'pat_registration_dttm',
'pat_registration_dttm_after',
'pat_cc_holder_zip',
'pat_cc_holder_zip_after',
'pat_mfg_card_ind',
'pat_mfg_card_ind_after',
'pat_sr_div_rec_nbr',
'pat_sr_div_rec_nbr_after',
'pat_hipaa_ind',
'pat_hipaa_ind_after',
'pat_hipaa_dttm',
'pat_hipaa_dttm_after',
'pat_hipaa_store_nbr',
'pat_hipaa_store_nbr_after',
'buyout_pat_ind',
'buyout_pat_ind_after',
'pat_hipaa_ack_ltr_ind',
'pat_hipaa_ack_ltr_ind_after',
'pat_email_address',
'pat_email_address_after',
'pat_email_dttm',
'pat_email_dttm_after',
'pat_email_user_id',
'pat_email_user_id_after',
'pat_lock_ind',
'pat_lock_ind_after',
'pat_lock_store_nbr',
'pat_lock_store_nbr_after',
'pat_lock_user_id',
'pat_lock_user_id_after',
'pat_lock_dttm',
'pat_lock_dttm_after',
'pat_smoking_ind',
'pat_smoking_ind_after',
'pat_pregnancy_ind',
'pat_pregnancy_ind_after',
'pat_preg_due_dttm',
'pat_preg_due_dttm_after',
'pat_pickup_id',
'pat_pickup_id_after',
'pat_brochure_ind',
'pat_brochure_ind_after',
'pat_large_print_ind',
'pat_large_print_ind_after',
'pat_ck_acct_nbr',
'pat_ck_acct_nbr_after',
'pat_ck_route_nbr',
'pat_ck_route_nbr_after',
'pat_homecare_ind',
'pat_homecare_ind_after',
'cust_balance_hold_ind',
'cust_balance_hold_ind_after',
'pat_specialty_ind',
'pat_specialty_ind_after',
'pat_hipaa_auth_name',
'pat_hipaa_auth_name_after',
'pat_hipaa_auth_exp',
'pat_hipaa_auth_exp_after',
'pat_hipaa_auth_other',
'pat_hipaa_auth_other_after',
'pat_hipaa_auth_cd',
'pat_hipaa_auth_cd_after',
'pat_rca_ind',
'pat_rca_ind_after',
'e2c_l4c',
'e2c_l4c_after',
'e2c_hash',
'e2c_hash_after',
'pat_text_msg_ind',
'pat_text_msg_ind_after',
'pat_text_msg_carrier',
'pat_text_msg_carrier_after',
'pat_prim_phone_pref_cd',
'pat_prim_phone_pref_cd_after',
'pat_billing_cd',
'pat_billing_cd_after',
'pat_link_cd',
'pat_link_cd_after',
'pat_autorefill_ind',
'pat_autorefill_ind_after',
'auto_refill_pref_str_nbr',
'auto_refill_pref_str_nbr_after',
'pat_residence_cd',
'pat_residence_cd_after',
'pat_prim_care_pbr_id',
'pat_prim_care_pbr_id_after',
'pat_prim_care_pbr_loc_id',
'pat_prim_care_pbr_loc_id_after',
'pat_pickup_id_qlfr',
'pat_pickup_id_qlfr_after',
'pat_pickup_gov_auth_id',
'pat_pickup_gov_auth_id_after',
'pat_pickup_rel_cd',
'pat_pickup_rel_cd_after',
'pat_unmerge_verify_ind',
'pat_unmerge_verify_ind_after',
'pat_twin_ind',
'pat_twin_ind_after',
'pat_90day_pref_ind',
'pat_90day_pref_ind_after',
'pat_90day_pref_dttm',
'pat_90day_pref_dttm_after',
'pat_alg_block_madr_ind',
'pat_alg_block_madr_ind_after' ]

#print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split('"^|~"')
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 209:
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 210:
      return True
  else:
    if val_len != 210:
      return True

# COMMAND ----------

readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[5]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[5]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[5]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[5]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

# Read files based on partitions
in1_text = spark.read.text(readList_src_1)
in2_text = spark.read.text(readList_src_2)
in3_text = spark.read.text(readList_src_3)
in4_text = spark.read.text(readList_src_4)

in1_text = in1_text.rdd
in2_text = in2_text.rdd
in3_text = in3_text.rdd
in4_text = in4_text.rdd


# COMMAND ----------

# write bad data
rdb1 = in1_text.filter(lambda x: checkbad(x[0]))
rdb2 = in2_text.filter(lambda x: checkbad(x[0]))
rdb3 = in3_text.filter(lambda x: checkbad(x[0]))
rdb4 = in4_text.filter(lambda x: checkbad(x[0]))

rdb_count = rdb1.count()+ rdb2.count()+ rdb3.count()+ rdb4.count()
rdb= rdb1+rdb2+rdb3+rdb4
if rdb_count>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)


# COMMAND ----------

#split and add schema
col_len = 210

rd1 = in1_text.map(lambda rw: rw[0].split('"^|~"')).map(lambda lst : addlistlength(lst))
rd2 = in2_text.map(lambda rw: rw[0].split('"^|~"')).map(lambda lst : addlistlength(lst))
rd3 = in3_text.map(lambda rw: rw[0].split('"^|~"')).map(lambda lst : addlistlength(lst))
rd4 = in4_text.map(lambda rw: rw[0].split('"^|~"')).map(lambda lst : addlistlength(lst))

rd1_good = rd1.filter(lambda x: x[0] == col_len)
rd2_good = rd2.filter(lambda x: x[0] == col_len)
rd3_good = rd3.filter(lambda x: x[0] == col_len)
rd4_good = rd4.filter(lambda x: x[0] == col_len)

rd_bad_all = rd1+rd2+rd3+rd4
rd_bad = rd_bad_all.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

df = df_g1.union(df_g2).union(df_g3).union(df_g4)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:]
  outval = outval.lstrip("\"")
  if(len(str(outval)) > 1 ):
      if((outval[-2]!="\\")) :
    #remove rightmost "
        outval = outval.rstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
   lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
   df.columns,
   df
))

# COMMAND ----------

#display(df)
#print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_patient")

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_patient"))
          
#display(df_gg)

df_gg.createOrReplaceTempView("raw_gg_tbf0_patient")

# COMMAND ----------

#print(df_gg.count())

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

#pRxCutoffTableCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR table_name == 'gg_tbf0_rx_consult_hist' OR  table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_lis')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

#pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR table_name  == 'gg_tbf0_rx_consult_actv' OR  table_name  == 'gg_tbf0_dur_history' OR table_name  == 'gg_tbf0_rx_consult_adhoc'   OR  table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_lis')"

#pSrcCleanseXfr

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND  cdc_before_after_cd_after IS NOT NULL)  AND  ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND  cdc_operation_type_cd_after IS NOT NULL) AND  (cdc_before_after_cd == 'BEFORE' AND  cdc_before_after_cd IS NOT NULL) AND  (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND  cdc_operation_type_cd IS NOT NULL ) AND  pat_id == pat_id_after AND  pat_id IS NOT NULL AND  pat_id_after IS NOT NULL AND   cdc_seq_nbr == cdc_seq_nbr_after AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL AND   cdc_rba_nbr == cdc_rba_nbr_after AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL AND   cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL AND  (( RTRIM(LOWER(pat_first_name)) == RTRIM(LOWER(pat_first_name_after ))  AND pat_first_name IS NOT NULL AND pat_first_name_after IS NOT NULL ) OR ( pat_first_name IS NULL AND pat_first_name_after IS NULL )) AND  (( RTRIM(LOWER(pat_mid_init)) == RTRIM(LOWER(pat_mid_init_after ))  AND pat_mid_init IS NOT NULL AND pat_mid_init_after IS NOT NULL ) OR ( pat_mid_init IS NULL AND pat_mid_init_after IS NULL )) AND  (( RTRIM(LOWER(pat_last_name)) == RTRIM(LOWER(pat_last_name_after ))  AND pat_last_name IS NOT NULL AND pat_last_name_after IS NOT NULL ) OR ( pat_last_name IS NULL AND pat_last_name_after IS NULL )) AND  (( RTRIM(LOWER(pat_last_name_soundex)) == RTRIM(LOWER(pat_last_name_soundex_after ))  AND pat_last_name_soundex IS NOT NULL AND pat_last_name_soundex_after IS NOT NULL ) OR ( pat_last_name_soundex IS NULL AND pat_last_name_soundex_after IS NULL )) AND  (( RTRIM(LOWER(pat_surname_suffix)) == RTRIM(LOWER(pat_surname_suffix_after ))  AND pat_surname_suffix IS NOT NULL AND pat_surname_suffix_after IS NOT NULL ) OR ( pat_surname_suffix IS NULL AND pat_surname_suffix_after IS NULL )) AND  (( RTRIM(LOWER(pat_street_addr)) == RTRIM(LOWER(pat_street_addr_after ))  AND pat_street_addr IS NOT NULL AND pat_street_addr_after IS NOT NULL ) OR ( pat_street_addr IS NULL AND pat_street_addr_after IS NULL )) AND  (( RTRIM(LOWER(pat_city)) == RTRIM(LOWER(pat_city_after ))  AND pat_city IS NOT NULL AND pat_city_after IS NOT NULL ) OR ( pat_city IS NULL AND pat_city_after IS NULL )) AND  (( RTRIM(LOWER(pat_state)) == RTRIM(LOWER(pat_state_after ))  AND pat_state IS NOT NULL AND pat_state_after IS NOT NULL ) OR ( pat_state IS NULL AND pat_state_after IS NULL )) AND  (( RTRIM(LOWER(pat_zip)) == RTRIM(LOWER(pat_zip_after ))  AND pat_zip IS NOT NULL AND pat_zip_after IS NOT NULL ) OR ( pat_zip IS NULL AND pat_zip_after IS NULL )) AND  (( RTRIM(LOWER(pat_sex_cd)) == RTRIM(LOWER(pat_sex_cd_after ))  AND pat_sex_cd IS NOT NULL AND pat_sex_cd_after IS NOT NULL ) OR ( pat_sex_cd IS NULL AND pat_sex_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_birth_dttm)) == RTRIM(LOWER(pat_birth_dttm_after ))  AND pat_birth_dttm IS NOT NULL AND pat_birth_dttm_after IS NOT NULL ) OR ( pat_birth_dttm IS NULL AND pat_birth_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_prim_area_cd)) == RTRIM(LOWER(pat_prim_area_cd_after ))  AND pat_prim_area_cd IS NOT NULL AND pat_prim_area_cd_after IS NOT NULL ) OR ( pat_prim_area_cd IS NULL AND pat_prim_area_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_prim_phone)) == RTRIM(LOWER(pat_prim_phone_after ))  AND pat_prim_phone IS NOT NULL AND pat_prim_phone_after IS NOT NULL ) OR ( pat_prim_phone IS NULL AND pat_prim_phone_after IS NULL )) AND  (( RTRIM(LOWER(pat_prim_phone_cd)) == RTRIM(LOWER(pat_prim_phone_cd_after ))  AND pat_prim_phone_cd IS NOT NULL AND pat_prim_phone_cd_after IS NOT NULL ) OR ( pat_prim_phone_cd IS NULL AND pat_prim_phone_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_sec_area_cd)) == RTRIM(LOWER(pat_sec_area_cd_after ))  AND pat_sec_area_cd IS NOT NULL AND pat_sec_area_cd_after IS NOT NULL ) OR ( pat_sec_area_cd IS NULL AND pat_sec_area_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_sec_phone)) == RTRIM(LOWER(pat_sec_phone_after ))  AND pat_sec_phone IS NOT NULL AND pat_sec_phone_after IS NOT NULL ) OR ( pat_sec_phone IS NULL AND pat_sec_phone_after IS NULL )) AND  (( RTRIM(LOWER(pat_hoh_id)) == RTRIM(LOWER(pat_hoh_id_after ))  AND pat_hoh_id IS NOT NULL AND pat_hoh_id_after IS NOT NULL ) OR ( pat_hoh_id IS NULL AND pat_hoh_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_hoh_relation_cd)) == RTRIM(LOWER(pat_hoh_relation_cd_after ))  AND pat_hoh_relation_cd IS NOT NULL AND pat_hoh_relation_cd_after IS NOT NULL ) OR ( pat_hoh_relation_cd IS NULL AND pat_hoh_relation_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_discount_cd)) == RTRIM(LOWER(pat_discount_cd_after ))  AND pat_discount_cd IS NOT NULL AND pat_discount_cd_after IS NOT NULL ) OR ( pat_discount_cd IS NULL AND pat_discount_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_clinic_medical_id)) == RTRIM(LOWER(pat_clinic_medical_id_after ))  AND pat_clinic_medical_id IS NOT NULL AND pat_clinic_medical_id_after IS NOT NULL ) OR ( pat_clinic_medical_id IS NULL AND pat_clinic_medical_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_snap_cap_pref)) == RTRIM(LOWER(pat_snap_cap_pref_after ))  AND pat_snap_cap_pref IS NOT NULL AND pat_snap_cap_pref_after IS NOT NULL ) OR ( pat_snap_cap_pref IS NULL AND pat_snap_cap_pref_after IS NULL )) AND  (( RTRIM(LOWER(pat_generic_subs_pref)) == RTRIM(LOWER(pat_generic_subs_pref_after ))  AND pat_generic_subs_pref IS NOT NULL AND pat_generic_subs_pref_after IS NOT NULL ) OR ( pat_generic_subs_pref IS NULL AND pat_generic_subs_pref_after IS NULL )) AND  (( RTRIM(LOWER(pat_thera_subs_pref)) == RTRIM(LOWER(pat_thera_subs_pref_after ))  AND pat_thera_subs_pref IS NOT NULL AND pat_thera_subs_pref_after IS NOT NULL ) OR ( pat_thera_subs_pref IS NULL AND pat_thera_subs_pref_after IS NULL )) AND  (( RTRIM(LOWER(pat_mail_list_pref)) == RTRIM(LOWER(pat_mail_list_pref_after ))  AND pat_mail_list_pref IS NOT NULL AND pat_mail_list_pref_after IS NOT NULL ) OR ( pat_mail_list_pref IS NULL AND pat_mail_list_pref_after IS NULL )) AND  (( RTRIM(LOWER(pat_lang_pref_cd)) == RTRIM(LOWER(pat_lang_pref_cd_after ))  AND pat_lang_pref_cd IS NOT NULL AND pat_lang_pref_cd_after IS NOT NULL ) OR ( pat_lang_pref_cd IS NULL AND pat_lang_pref_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_purged_rx_ind)) == RTRIM(LOWER(pat_purged_rx_ind_after ))  AND pat_purged_rx_ind IS NOT NULL AND pat_purged_rx_ind_after IS NOT NULL ) OR ( pat_purged_rx_ind IS NULL AND pat_purged_rx_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_pet_ind)) == RTRIM(LOWER(pat_pet_ind_after ))  AND pat_pet_ind IS NOT NULL AND pat_pet_ind_after IS NOT NULL ) OR ( pat_pet_ind IS NULL AND pat_pet_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_pet_type)) == RTRIM(LOWER(pat_pet_type_after ))  AND pat_pet_type IS NOT NULL AND pat_pet_type_after IS NOT NULL ) OR ( pat_pet_type IS NULL AND pat_pet_type_after IS NULL )) AND  (( RTRIM(LOWER(pat_preappr_pay_ind)) == RTRIM(LOWER(pat_preappr_pay_ind_after ))  AND pat_preappr_pay_ind IS NOT NULL AND pat_preappr_pay_ind_after IS NOT NULL ) OR ( pat_preappr_pay_ind IS NULL AND pat_preappr_pay_ind_after IS NULL ))  AND (( RTRIM(LOWER(pat_cc_nbr)) == RTRIM(LOWER(pat_cc_nbr_after ))  AND pat_cc_nbr IS NOT NULL AND pat_cc_nbr_after IS NOT NULL ) OR ( pat_cc_nbr IS NULL AND pat_cc_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_mail_service_id)) == RTRIM(LOWER(pat_mail_service_id_after ))  AND pat_mail_service_id IS NOT NULL AND pat_mail_service_id_after IS NOT NULL ) OR ( pat_mail_service_id IS NULL AND pat_mail_service_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_cmts)) == RTRIM(LOWER(pat_cmts_after ))  AND pat_cmts IS NOT NULL AND pat_cmts_after IS NOT NULL ) OR ( pat_cmts IS NULL AND pat_cmts_after IS NULL )) AND  (( RTRIM(LOWER(pat_create_store_nbr)) == RTRIM(LOWER(pat_create_store_nbr_after ))  AND pat_create_store_nbr IS NOT NULL AND pat_create_store_nbr_after IS NOT NULL ) OR ( pat_create_store_nbr IS NULL AND pat_create_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_deceased_ind)) == RTRIM(LOWER(pat_deceased_ind_after ))  AND pat_deceased_ind IS NOT NULL AND pat_deceased_ind_after IS NOT NULL ) OR ( pat_deceased_ind IS NULL AND pat_deceased_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_algy_hlth_type_cd)) == RTRIM(LOWER(pat_algy_hlth_type_cd_after ))  AND pat_algy_hlth_type_cd IS NOT NULL AND pat_algy_hlth_type_cd_after IS NOT NULL ) OR ( pat_algy_hlth_type_cd IS NULL AND pat_algy_hlth_type_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_algy_hlth_cd_inq_ind)) == RTRIM(LOWER(pat_algy_hlth_cd_inq_ind_after ))  AND pat_algy_hlth_cd_inq_ind IS NOT NULL AND pat_algy_hlth_cd_inq_ind_after IS NOT NULL ) OR ( pat_algy_hlth_cd_inq_ind IS NULL AND pat_algy_hlth_cd_inq_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_wc_ind)) == RTRIM(LOWER(pat_wc_ind_after ))  AND pat_wc_ind IS NOT NULL AND pat_wc_ind_after IS NOT NULL ) OR ( pat_wc_ind IS NULL AND pat_wc_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_phone_contact_pref)) == RTRIM(LOWER(pat_phone_contact_pref_after ))  AND pat_phone_contact_pref IS NOT NULL AND pat_phone_contact_pref_after IS NOT NULL ) OR ( pat_phone_contact_pref IS NULL AND pat_phone_contact_pref_after IS NULL )) AND  (( RTRIM(LOWER(pat_signature_ind)) == RTRIM(LOWER(pat_signature_ind_after ))  AND pat_signature_ind IS NOT NULL AND pat_signature_ind_after IS NOT NULL ) OR ( pat_signature_ind IS NULL AND pat_signature_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_internet_ind)) == RTRIM(LOWER(pat_internet_ind_after ))  AND pat_internet_ind IS NOT NULL AND pat_internet_ind_after IS NOT NULL ) OR ( pat_internet_ind IS NULL AND pat_internet_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_ext_rx_otc_ind)) == RTRIM(LOWER(pat_ext_rx_otc_ind_after ))  AND pat_ext_rx_otc_ind IS NOT NULL AND pat_ext_rx_otc_ind_after IS NOT NULL ) OR ( pat_ext_rx_otc_ind IS NULL AND pat_ext_rx_otc_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_registration_dttm)) == RTRIM(LOWER(pat_registration_dttm_after ))  AND pat_registration_dttm IS NOT NULL AND pat_registration_dttm_after IS NOT NULL ) OR ( pat_registration_dttm IS NULL AND pat_registration_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_cc_holder_zip)) == RTRIM(LOWER(pat_cc_holder_zip_after ))  AND pat_cc_holder_zip IS NOT NULL AND pat_cc_holder_zip_after IS NOT NULL ) OR ( pat_cc_holder_zip IS NULL AND pat_cc_holder_zip_after IS NULL )) AND  (( RTRIM(LOWER(pat_mfg_card_ind)) == RTRIM(LOWER(pat_mfg_card_ind_after ))  AND pat_mfg_card_ind IS NOT NULL AND pat_mfg_card_ind_after IS NOT NULL ) OR ( pat_mfg_card_ind IS NULL AND pat_mfg_card_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_sr_div_rec_nbr)) == RTRIM(LOWER(pat_sr_div_rec_nbr_after ))  AND pat_sr_div_rec_nbr IS NOT NULL AND pat_sr_div_rec_nbr_after IS NOT NULL ) OR ( pat_sr_div_rec_nbr IS NULL AND pat_sr_div_rec_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_ind)) == RTRIM(LOWER(pat_hipaa_ind_after ))  AND pat_hipaa_ind IS NOT NULL AND pat_hipaa_ind_after IS NOT NULL ) OR ( pat_hipaa_ind IS NULL AND pat_hipaa_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_dttm)) == RTRIM(LOWER(pat_hipaa_dttm_after ))  AND pat_hipaa_dttm IS NOT NULL AND pat_hipaa_dttm_after IS NOT NULL ) OR ( pat_hipaa_dttm IS NULL AND pat_hipaa_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_store_nbr)) == RTRIM(LOWER(pat_hipaa_store_nbr_after ))  AND pat_hipaa_store_nbr IS NOT NULL AND pat_hipaa_store_nbr_after IS NOT NULL ) OR ( pat_hipaa_store_nbr IS NULL AND pat_hipaa_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(buyout_pat_ind)) == RTRIM(LOWER(buyout_pat_ind_after ))  AND buyout_pat_ind IS NOT NULL AND buyout_pat_ind_after IS NOT NULL ) OR ( buyout_pat_ind IS NULL AND buyout_pat_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_ack_ltr_ind)) == RTRIM(LOWER(pat_hipaa_ack_ltr_ind_after ))  AND pat_hipaa_ack_ltr_ind IS NOT NULL AND pat_hipaa_ack_ltr_ind_after IS NOT NULL ) OR ( pat_hipaa_ack_ltr_ind IS NULL AND pat_hipaa_ack_ltr_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_email_address)) == RTRIM(LOWER(pat_email_address_after ))  AND pat_email_address IS NOT NULL AND pat_email_address_after IS NOT NULL ) OR ( pat_email_address IS NULL AND pat_email_address_after IS NULL )) AND  (( RTRIM(LOWER(pat_email_dttm)) == RTRIM(LOWER(pat_email_dttm_after ))  AND pat_email_dttm IS NOT NULL AND pat_email_dttm_after IS NOT NULL ) OR ( pat_email_dttm IS NULL AND pat_email_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_email_user_id)) == RTRIM(LOWER(pat_email_user_id_after ))  AND pat_email_user_id IS NOT NULL AND pat_email_user_id_after IS NOT NULL ) OR ( pat_email_user_id IS NULL AND pat_email_user_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_lock_ind)) == RTRIM(LOWER(pat_lock_ind_after ))  AND pat_lock_ind IS NOT NULL AND pat_lock_ind_after IS NOT NULL ) OR ( pat_lock_ind IS NULL AND pat_lock_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_lock_store_nbr)) == RTRIM(LOWER(pat_lock_store_nbr_after ))  AND pat_lock_store_nbr IS NOT NULL AND pat_lock_store_nbr_after IS NOT NULL ) OR ( pat_lock_store_nbr IS NULL AND pat_lock_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_lock_user_id)) == RTRIM(LOWER(pat_lock_user_id_after ))  AND pat_lock_user_id IS NOT NULL AND pat_lock_user_id_after IS NOT NULL ) OR ( pat_lock_user_id IS NULL AND pat_lock_user_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_lock_dttm)) == RTRIM(LOWER(pat_lock_dttm_after ))  AND pat_lock_dttm IS NOT NULL AND pat_lock_dttm_after IS NOT NULL ) OR ( pat_lock_dttm IS NULL AND pat_lock_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_smoking_ind)) == RTRIM(LOWER(pat_smoking_ind_after ))  AND pat_smoking_ind IS NOT NULL AND pat_smoking_ind_after IS NOT NULL ) OR ( pat_smoking_ind IS NULL AND pat_smoking_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_pregnancy_ind)) == RTRIM(LOWER(pat_pregnancy_ind_after ))  AND pat_pregnancy_ind IS NOT NULL AND pat_pregnancy_ind_after IS NOT NULL ) OR ( pat_pregnancy_ind IS NULL AND pat_pregnancy_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_preg_due_dttm)) == RTRIM(LOWER(pat_preg_due_dttm_after ))  AND pat_preg_due_dttm IS NOT NULL AND pat_preg_due_dttm_after IS NOT NULL ) OR ( pat_preg_due_dttm IS NULL AND pat_preg_due_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_id)) == RTRIM(LOWER(pat_pickup_id_after ))  AND pat_pickup_id IS NOT NULL AND pat_pickup_id_after IS NOT NULL ) OR ( pat_pickup_id IS NULL AND pat_pickup_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_brochure_ind)) == RTRIM(LOWER(pat_brochure_ind_after ))  AND pat_brochure_ind IS NOT NULL AND pat_brochure_ind_after IS NOT NULL ) OR ( pat_brochure_ind IS NULL AND pat_brochure_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_large_print_ind)) == RTRIM(LOWER(pat_large_print_ind_after ))  AND pat_large_print_ind IS NOT NULL AND pat_large_print_ind_after IS NOT NULL ) OR ( pat_large_print_ind IS NULL AND pat_large_print_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_ck_acct_nbr)) == RTRIM(LOWER(pat_ck_acct_nbr_after ))  AND pat_ck_acct_nbr IS NOT NULL AND pat_ck_acct_nbr_after IS NOT NULL ) OR ( pat_ck_acct_nbr IS NULL AND pat_ck_acct_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_ck_route_nbr)) == RTRIM(LOWER(pat_ck_route_nbr_after ))  AND pat_ck_route_nbr IS NOT NULL AND pat_ck_route_nbr_after IS NOT NULL ) OR ( pat_ck_route_nbr IS NULL AND pat_ck_route_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_homecare_ind)) == RTRIM(LOWER(pat_homecare_ind_after ))  AND pat_homecare_ind IS NOT NULL AND pat_homecare_ind_after IS NOT NULL ) OR ( pat_homecare_ind IS NULL AND pat_homecare_ind_after IS NULL )) AND  (( RTRIM(LOWER(cust_balance_hold_ind)) == RTRIM(LOWER(cust_balance_hold_ind_after ))  AND cust_balance_hold_ind IS NOT NULL AND cust_balance_hold_ind_after IS NOT NULL ) OR ( cust_balance_hold_ind IS NULL AND cust_balance_hold_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_specialty_ind)) == RTRIM(LOWER(pat_specialty_ind_after ))  AND pat_specialty_ind IS NOT NULL AND pat_specialty_ind_after IS NOT NULL ) OR ( pat_specialty_ind IS NULL AND pat_specialty_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_auth_name)) == RTRIM(LOWER(pat_hipaa_auth_name_after ))  AND pat_hipaa_auth_name IS NOT NULL AND pat_hipaa_auth_name_after IS NOT NULL ) OR ( pat_hipaa_auth_name IS NULL AND pat_hipaa_auth_name_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_auth_exp)) == RTRIM(LOWER(pat_hipaa_auth_exp_after ))  AND pat_hipaa_auth_exp IS NOT NULL AND pat_hipaa_auth_exp_after IS NOT NULL ) OR ( pat_hipaa_auth_exp IS NULL AND pat_hipaa_auth_exp_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_auth_other)) == RTRIM(LOWER(pat_hipaa_auth_other_after ))  AND pat_hipaa_auth_other IS NOT NULL AND pat_hipaa_auth_other_after IS NOT NULL ) OR ( pat_hipaa_auth_other IS NULL AND pat_hipaa_auth_other_after IS NULL )) AND  (( RTRIM(LOWER(pat_hipaa_auth_cd)) == RTRIM(LOWER(pat_hipaa_auth_cd_after ))  AND pat_hipaa_auth_cd IS NOT NULL AND pat_hipaa_auth_cd_after IS NOT NULL ) OR ( pat_hipaa_auth_cd IS NULL AND pat_hipaa_auth_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_rca_ind)) == RTRIM(LOWER(pat_rca_ind_after ))  AND pat_rca_ind IS NOT NULL AND pat_rca_ind_after IS NOT NULL ) OR ( pat_rca_ind IS NULL AND pat_rca_ind_after IS NULL )) AND  (( RTRIM(LOWER(e2c_l4c)) == RTRIM(LOWER(e2c_l4c_after ))  AND e2c_l4c IS NOT NULL AND e2c_l4c_after IS NOT NULL ) OR ( e2c_l4c IS NULL AND e2c_l4c_after IS NULL )) AND (( RTRIM(LOWER(e2c_hash)) == RTRIM(LOWER(e2c_hash_after ))  AND e2c_hash IS NOT NULL AND e2c_hash_after IS NOT NULL ) OR ( e2c_hash IS NULL AND e2c_hash_after IS NULL )) AND  (( RTRIM(LOWER(pat_text_msg_ind)) == RTRIM(LOWER(pat_text_msg_ind_after ))  AND pat_text_msg_ind IS NOT NULL AND pat_text_msg_ind_after IS NOT NULL ) OR ( pat_text_msg_ind IS NULL AND pat_text_msg_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_text_msg_carrier)) == RTRIM(LOWER(pat_text_msg_carrier_after ))  AND pat_text_msg_carrier IS NOT NULL AND pat_text_msg_carrier_after IS NOT NULL ) OR ( pat_text_msg_carrier IS NULL AND pat_text_msg_carrier_after IS NULL )) AND  (( RTRIM(LOWER(pat_prim_phone_pref_cd)) == RTRIM(LOWER(pat_prim_phone_pref_cd_after ))  AND pat_prim_phone_pref_cd IS NOT NULL AND pat_prim_phone_pref_cd_after IS NOT NULL ) OR ( pat_prim_phone_pref_cd IS NULL AND pat_prim_phone_pref_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_billing_cd)) == RTRIM(LOWER(pat_billing_cd_after ))  AND pat_billing_cd IS NOT NULL AND pat_billing_cd_after IS NOT NULL ) OR ( pat_billing_cd IS NULL AND pat_billing_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_link_cd)) == RTRIM(LOWER(pat_link_cd_after ))  AND pat_link_cd IS NOT NULL AND pat_link_cd_after IS NOT NULL ) OR ( pat_link_cd IS NULL AND pat_link_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_autorefill_ind)) == RTRIM(LOWER(pat_autorefill_ind_after ))  AND pat_autorefill_ind IS NOT NULL AND pat_autorefill_ind_after IS NOT NULL ) OR ( pat_autorefill_ind IS NULL AND pat_autorefill_ind_after IS NULL )) AND  (( RTRIM(LOWER(auto_refill_pref_str_nbr)) == RTRIM(LOWER(auto_refill_pref_str_nbr_after ))  AND auto_refill_pref_str_nbr IS NOT NULL AND auto_refill_pref_str_nbr_after IS NOT NULL ) OR ( auto_refill_pref_str_nbr IS NULL AND auto_refill_pref_str_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pat_residence_cd)) == RTRIM(LOWER(pat_residence_cd_after ))  AND pat_residence_cd IS NOT NULL AND pat_residence_cd_after IS NOT NULL ) OR ( pat_residence_cd IS NULL AND pat_residence_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_prim_care_pbr_id)) == RTRIM(LOWER(pat_prim_care_pbr_id_after ))  AND pat_prim_care_pbr_id IS NOT NULL AND pat_prim_care_pbr_id_after IS NOT NULL ) OR ( pat_prim_care_pbr_id IS NULL AND pat_prim_care_pbr_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_prim_care_pbr_loc_id)) == RTRIM(LOWER(pat_prim_care_pbr_loc_id_after ))  AND pat_prim_care_pbr_loc_id IS NOT NULL AND pat_prim_care_pbr_loc_id_after IS NOT NULL ) OR ( pat_prim_care_pbr_loc_id IS NULL AND pat_prim_care_pbr_loc_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_gov_auth_id)) == RTRIM(LOWER(pat_pickup_gov_auth_id_after ))  AND pat_pickup_gov_auth_id IS NOT NULL AND pat_pickup_gov_auth_id_after IS NOT NULL ) OR ( pat_pickup_gov_auth_id IS NULL AND pat_pickup_gov_auth_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_id_qlfr)) == RTRIM(LOWER(pat_pickup_id_qlfr_after ))  AND pat_pickup_id_qlfr IS NOT NULL AND pat_pickup_id_qlfr_after IS NOT NULL ) OR ( pat_pickup_id_qlfr IS NULL AND pat_pickup_id_qlfr_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_rel_cd)) == RTRIM(LOWER(pat_pickup_rel_cd_after ))  AND pat_pickup_rel_cd IS NOT NULL AND pat_pickup_rel_cd_after IS NOT NULL ) OR ( pat_pickup_rel_cd IS NULL AND pat_pickup_rel_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_unmerge_verify_ind)) == RTRIM(LOWER(pat_unmerge_verify_ind_after ))  AND pat_unmerge_verify_ind IS NOT NULL AND pat_unmerge_verify_ind_after IS NOT NULL ) OR ( pat_unmerge_verify_ind IS NULL AND pat_unmerge_verify_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_twin_ind)) == RTRIM(LOWER(pat_twin_ind_after ))  AND pat_twin_ind IS NOT NULL AND pat_twin_ind_after IS NOT NULL ) OR ( pat_twin_ind IS NULL AND pat_twin_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_90day_pref_ind)) == RTRIM(LOWER(pat_90day_pref_ind_after ))  AND pat_90day_pref_ind IS NOT NULL AND pat_90day_pref_ind_after IS NOT NULL ) OR ( pat_90day_pref_ind IS NULL AND pat_90day_pref_ind_after IS NULL )) AND  (( RTRIM(LOWER(pat_90day_pref_dttm)) == RTRIM(LOWER(pat_90day_pref_dttm_after ))  AND pat_90day_pref_dttm IS NOT NULL AND pat_90day_pref_dttm_after IS NOT NULL ) OR ( pat_90day_pref_dttm IS NULL AND pat_90day_pref_dttm_after IS NULL )) AND (( RTRIM(LOWER(pat_alg_block_madr_ind)) == RTRIM(LOWER(pat_alg_block_madr_ind_after )) AND pat_alg_block_madr_ind IS NOT NULL AND pat_alg_block_madr_ind_after IS NOT NULL ) OR ( pat_alg_block_madr_ind IS NULL AND pat_alg_block_madr_ind_after IS NULL )) )" 

pPatIdModCheck="(CAST(pat_id AS LONG)%4 == CAST(src_partition_nbr AS INTEGER) -1) AND (table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

#pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, pat_id, pat_first_name, pat_mid_init, pat_last_name, pat_last_name_soundex, pat_surname_suffix, pat_street_addr, pat_city, pat_state, pat_zip, pat_sex_cd, CONCAT(pat_birth_dttm,'.000000') AS pat_birth_dttm, pat_prim_area_cd, pat_prim_phone, pat_prim_phone_cd, pat_sec_area_cd, pat_sec_phone, pat_hoh_id, pat_hoh_relation_cd, pat_discount_cd, pat_clinic_medical_id, pat_snap_cap_pref, pat_generic_subs_pref, pat_thera_subs_pref, pat_mail_list_pref, pat_lang_pref_cd, pat_purged_rx_ind, pat_pet_ind, pat_pet_type, pat_preappr_pay_ind, pat_cc_nbr, pat_mail_service_id, pat_cmts, pat_create_store_nbr, pat_deceased_ind, pat_algy_hlth_type_cd, pat_algy_hlth_cd_inq_ind, pat_wc_ind, create_user_id, CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id, CONCAT(update_dttm,'.000000') AS update_dttm, pat_phone_contact_pref, pat_signature_ind, pat_internet_ind, pat_ext_rx_otc_ind, CONCAT(pat_registration_dttm,'.000000') AS pat_registration_dttm, pat_cc_holder_zip, pat_mfg_card_ind, pat_sr_div_rec_nbr, pat_hipaa_ind, CONCAT(pat_hipaa_dttm,'.000000') AS pat_hipaa_dttm, pat_hipaa_store_nbr, buyout_pat_ind, pat_hipaa_ack_ltr_ind, pat_email_address, CONCAT(pat_email_dttm,'.000000') AS pat_email_dttm, pat_email_user_id, pat_lock_ind, pat_lock_store_nbr, pat_lock_user_id, CONCAT(pat_lock_dttm,'.000000') AS pat_lock_dttm, pat_smoking_ind, pat_pregnancy_ind, CONCAT(pat_preg_due_dttm,'.000000') AS pat_preg_due_dttm, pat_pickup_id, pat_brochure_ind, pat_large_print_ind, pat_ck_acct_nbr, pat_ck_route_nbr, pat_homecare_ind, cust_balance_hold_ind, pat_specialty_ind, pat_hipaa_auth_name, pat_hipaa_auth_exp, pat_hipaa_auth_other, pat_hipaa_auth_cd, pat_rca_ind, e2c_l4c, REPLACE(e2c_hash,'[\u00C7]','') AS e2c_hash, pat_text_msg_ind, pat_text_msg_carrier, pat_prim_phone_pref_cd, pat_billing_cd, pat_link_cd, src_partition_nbr,pat_autorefill_ind, auto_refill_pref_str_nbr, pat_residence_cd, pat_prim_care_pbr_id, pat_prim_care_pbr_loc_id, pat_pickup_gov_auth_id, pat_pickup_id_qlfr, pat_pickup_rel_cd, pat_unmerge_verify_ind, pat_twin_ind, pat_90day_pref_ind, CONCAT(pat_90day_pref_dttm,'.000000') AS pat_90day_pref_dttm,pat_alg_block_madr_ind"
#, tracking_id,partition_column"



# COMMAND ----------

# Read ETL_HIVE_CUTOFF table:
from pyspark.sql import *
from pyspark.sql.functions import *

sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}.{1}".format(SNFL_ETL_DB, SNFL_CUTTOFF_TBL_NAME)

#print(sel_ETL_Hive_Cutoff_tbl)
df_cutoff_records_output=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_ETL_DB) \
   .option("query",sel_ETL_Hive_Cutoff_tbl) \
   .load()

#display(df_cutoff_records_output)

# Filtering the cutoff timestamp for the current batch
cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
#display(cutoff_records_filter)

cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
RX_CUT_OFF_MAX_DTTM as rx_max,
CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
from cutoff_records_filter""" 

cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
#display(cutoff_range_rx)

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
from cutoff_records_filter"""

cutoff_range_trans = spark.sql(cutoff_range_trans_sql)
#display(cutoff_range_trans)

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_patient where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_patient where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_patient where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)

nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#display(nr_input_filter_nopartition)
#Fetching rx_max and rx_trans_max as values
if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  #display(nr_input_file_filter_rx)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual)
  nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck)
  nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual)
  nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

#display(ded)


# COMMAND ----------

#print(dedup_group.count())

# COMMAND ----------

nr_spacetrim_sql = """select CONCAT(CONCAT(SUBSTRING(cdc_txn_commit_dttm,0,10),' '),SUBSTRING(cdc_txn_commit_dttm,12,8)) AS cdc_txn_commit_dttm, CONCAT(CONCAT(SUBSTRING(cdc_txn_commit_dttm_after,0,10),' '),SUBSTRING(cdc_txn_commit_dttm_after, 12,8)) AS cdc_txn_commit_dttm_after, (case when (LENGTH(TRIM(cdc_seq_nbr))==0) then cdc_seq_nbr else TRIM(cdc_seq_nbr) end) AS cdc_seq_nbr, (case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after, (case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr, (case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after, (case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd, (case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after) end) as cdc_operation_type_cd_after, (case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd, (case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after, (case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd, (case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after, edw_batch_id AS edw_batch_id , edw_batch_id AS edw_batch_id_after , (case when (LENGTH(TRIM( src_partition_nbr )) ==0) then  src_partition_nbr else TRIM( src_partition_nbr ) end) as src_partition_nbr ,(case when (LENGTH(TRIM( src_partition_nbr_after )) ==0) then  src_partition_nbr_after else TRIM( src_partition_nbr_after ) end) as src_partition_nbr_after ,pat_id AS pat_id , pat_id_after AS pat_id_after , (case when (LENGTH(TRIM(pat_first_name))==0) then pat_first_name else TRIM(pat_first_name) end) AS pat_first_name , (case when (LENGTH(TRIM(pat_first_name_after))==0) then pat_first_name_after else TRIM(pat_first_name_after) end) AS pat_first_name_after , pat_mid_init AS pat_mid_init , pat_mid_init_after AS pat_mid_init_after , (case when (LENGTH(TRIM(pat_last_name))==0) then pat_last_name else TRIM(pat_last_name) end) AS pat_last_name , (case when (LENGTH(TRIM(pat_last_name_after))==0) then pat_last_name_after else TRIM(pat_last_name_after) end) AS pat_last_name_after , pat_last_name_soundex AS pat_last_name_soundex , pat_last_name_soundex_after AS pat_last_name_soundex_after , pat_surname_suffix AS pat_surname_suffix , pat_surname_suffix_after AS pat_surname_suffix_after , (case when (LENGTH(TRIM(pat_street_addr))==0) then pat_street_addr else TRIM(pat_street_addr) end) AS pat_street_addr , (case when (LENGTH(TRIM(pat_street_addr_after))==0) then pat_street_addr_after else TRIM(pat_street_addr_after) end) AS pat_street_addr_after , (case when (LENGTH(TRIM(pat_city))==0) then pat_city else TRIM(pat_city) end) AS pat_city , (case when (LENGTH(TRIM(pat_city_after))==0) then pat_city_after else TRIM(pat_city_after) end) AS pat_city_after , pat_state AS pat_state , pat_state_after AS pat_state_after , pat_zip AS pat_zip , pat_zip_after AS pat_zip_after , pat_sex_cd AS pat_sex_cd , pat_sex_cd_after AS pat_sex_cd_after , CONCAT(CONCAT(SUBSTRING(pat_birth_dttm,0,10),' '),SUBSTRING(pat_birth_dttm, 12,8)) AS pat_birth_dttm , CONCAT(CONCAT(SUBSTRING(pat_birth_dttm_after,0,10),' '),SUBSTRING(pat_birth_dttm_after, 12,8)) AS pat_birth_dttm_after , pat_prim_area_cd AS pat_prim_area_cd , pat_prim_area_cd_after AS pat_prim_area_cd_after , pat_prim_phone AS pat_prim_phone , pat_prim_phone_after AS pat_prim_phone_after , pat_prim_phone_cd AS pat_prim_phone_cd , pat_prim_phone_cd_after AS pat_prim_phone_cd_after , pat_sec_area_cd AS pat_sec_area_cd , pat_sec_area_cd_after AS pat_sec_area_cd_after , pat_sec_phone AS pat_sec_phone , pat_sec_phone_after AS pat_sec_phone_after , pat_hoh_id AS pat_hoh_id , pat_hoh_id_after AS pat_hoh_id_after , pat_hoh_relation_cd AS pat_hoh_relation_cd , pat_hoh_relation_cd_after AS pat_hoh_relation_cd_after , pat_discount_cd AS pat_discount_cd , pat_discount_cd_after AS pat_discount_cd_after , pat_clinic_medical_id AS pat_clinic_medical_id , pat_clinic_medical_id_after AS pat_clinic_medical_id_after , pat_snap_cap_pref AS pat_snap_cap_pref , pat_snap_cap_pref_after AS pat_snap_cap_pref_after , pat_generic_subs_pref AS pat_generic_subs_pref , pat_generic_subs_pref_after AS pat_generic_subs_pref_after , pat_thera_subs_pref AS pat_thera_subs_pref , pat_thera_subs_pref_after AS pat_thera_subs_pref_after , pat_mail_list_pref AS pat_mail_list_pref , pat_mail_list_pref_after AS pat_mail_list_pref_after , pat_lang_pref_cd AS pat_lang_pref_cd , pat_lang_pref_cd_after AS pat_lang_pref_cd_after , pat_purged_rx_ind AS pat_purged_rx_ind , pat_purged_rx_ind_after AS pat_purged_rx_ind_after , pat_pet_ind AS pat_pet_ind , pat_pet_ind_after AS pat_pet_ind_after , (case when (LENGTH(TRIM(pat_pet_type))==0) then pat_pet_type else TRIM(pat_pet_type) end) AS pat_pet_type , (case when (LENGTH(TRIM(pat_pet_type_after))==0) then pat_pet_type_after else TRIM(pat_pet_type_after) end) AS pat_pet_type_after , pat_preappr_pay_ind AS pat_preappr_pay_ind , pat_preappr_pay_ind_after AS pat_preappr_pay_ind_after , (case when (LENGTH(TRIM(pat_cc_nbr))==0) then pat_cc_nbr else TRIM(pat_cc_nbr) end) AS pat_cc_nbr , (case when (LENGTH(TRIM(pat_cc_nbr_after))==0) then pat_cc_nbr_after else TRIM(pat_cc_nbr_after) end) AS pat_cc_nbr_after, (case when (LENGTH(TRIM(pat_mail_service_id))==0) then pat_mail_service_id else TRIM(pat_mail_service_id) end) AS pat_mail_service_id , (case when (LENGTH(TRIM(pat_mail_service_id_after))==0) then pat_mail_service_id_after else TRIM(pat_mail_service_id_after) end) AS pat_mail_service_id_after , (case when (LENGTH(TRIM(pat_cmts))==0) then pat_cmts else TRIM(pat_cmts) end) AS pat_cmts , (case when (LENGTH(TRIM(pat_cmts_after))==0) then pat_cmts_after else TRIM(pat_cmts_after) end) AS pat_cmts_after , pat_create_store_nbr AS pat_create_store_nbr , pat_create_store_nbr_after AS pat_create_store_nbr_after , pat_deceased_ind AS pat_deceased_ind , pat_deceased_ind_after AS pat_deceased_ind_after , pat_algy_hlth_type_cd AS pat_algy_hlth_type_cd , pat_algy_hlth_type_cd_after AS pat_algy_hlth_type_cd_after , pat_algy_hlth_cd_inq_ind AS pat_algy_hlth_cd_inq_ind , pat_algy_hlth_cd_inq_ind_after AS pat_algy_hlth_cd_inq_ind_after , pat_wc_ind AS pat_wc_ind , pat_wc_ind_after AS pat_wc_ind_after , create_user_id AS create_user_id , create_user_id_after AS create_user_id_after , CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm, 12,8)) AS create_dttm , CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after, 12,8)) AS create_dttm_after , update_user_id AS update_user_id , update_user_id_after AS update_user_id_after , CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm, 12,8)) AS update_dttm , CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after, 12,8)) AS update_dttm_after , pat_phone_contact_pref AS pat_phone_contact_pref , pat_phone_contact_pref_after AS pat_phone_contact_pref_after , pat_signature_ind AS pat_signature_ind , pat_signature_ind_after AS pat_signature_ind_after , pat_internet_ind AS pat_internet_ind , pat_internet_ind_after AS pat_internet_ind_after , pat_ext_rx_otc_ind AS pat_ext_rx_otc_ind , pat_ext_rx_otc_ind_after AS pat_ext_rx_otc_ind_after , CONCAT(CONCAT(SUBSTRING(pat_registration_dttm,0,10),' '),SUBSTRING(pat_registration_dttm, 12,8)) AS pat_registration_dttm , CONCAT(CONCAT(SUBSTRING(pat_registration_dttm_after,0,10),' '),SUBSTRING(pat_registration_dttm_after, 12,8)) AS pat_registration_dttm_after , (case when (LENGTH(TRIM(pat_cc_holder_zip))==0) then pat_cc_holder_zip else TRIM(pat_cc_holder_zip) end) AS pat_cc_holder_zip , (case when (LENGTH(TRIM(pat_cc_holder_zip_after))==0) then pat_cc_holder_zip_after else TRIM(pat_cc_holder_zip_after) end) AS pat_cc_holder_zip_after , pat_mfg_card_ind AS pat_mfg_card_ind , pat_mfg_card_ind_after AS pat_mfg_card_ind_after , (case when (LENGTH(TRIM(pat_sr_div_rec_nbr))==0) then pat_sr_div_rec_nbr else TRIM(pat_sr_div_rec_nbr) end) AS pat_sr_div_rec_nbr , (case when (LENGTH(TRIM(pat_sr_div_rec_nbr_after))==0) then pat_sr_div_rec_nbr_after else TRIM(pat_sr_div_rec_nbr_after) end) AS pat_sr_div_rec_nbr_after , pat_hipaa_ind AS pat_hipaa_ind , pat_hipaa_ind_after AS pat_hipaa_ind_after , CONCAT(CONCAT(SUBSTRING(pat_hipaa_dttm,0,10),' '),SUBSTRING(pat_hipaa_dttm, 12,8)) AS pat_hipaa_dttm , CONCAT(CONCAT(SUBSTRING(pat_hipaa_dttm_after,0,10),' '),SUBSTRING(pat_hipaa_dttm_after, 12,8)) AS pat_hipaa_dttm_after , pat_hipaa_store_nbr AS pat_hipaa_store_nbr , pat_hipaa_store_nbr_after AS pat_hipaa_store_nbr_after , buyout_pat_ind AS buyout_pat_ind , buyout_pat_ind_after AS buyout_pat_ind_after , pat_hipaa_ack_ltr_ind AS pat_hipaa_ack_ltr_ind , pat_hipaa_ack_ltr_ind_after AS pat_hipaa_ack_ltr_ind_after , (case when (LENGTH(TRIM(pat_email_address))==0) then pat_email_address else TRIM(pat_email_address) end) AS pat_email_address , (case when (LENGTH(TRIM(pat_email_address_after))==0) then pat_email_address_after else TRIM(pat_email_address_after) end) AS pat_email_address_after , CONCAT(CONCAT(SUBSTRING(pat_email_dttm,0,10),' '),SUBSTRING(pat_email_dttm, 12,8)) AS pat_email_dttm , CONCAT(CONCAT(SUBSTRING(pat_email_dttm_after,0,10),' '),SUBSTRING(pat_email_dttm_after, 12,8)) AS pat_email_dttm_after , pat_email_user_id AS pat_email_user_id , pat_email_user_id_after AS pat_email_user_id_after , pat_lock_ind AS pat_lock_ind , pat_lock_ind_after AS pat_lock_ind_after , pat_lock_store_nbr AS pat_lock_store_nbr , pat_lock_store_nbr_after AS pat_lock_store_nbr_after , pat_lock_user_id AS pat_lock_user_id , pat_lock_user_id_after AS pat_lock_user_id_after , CONCAT(CONCAT(SUBSTRING(pat_lock_dttm,0,10),' '),SUBSTRING(pat_lock_dttm, 12,8)) AS pat_lock_dttm , CONCAT(CONCAT(SUBSTRING(pat_lock_dttm_after,0,10),' '),SUBSTRING(pat_lock_dttm_after, 12,8)) AS pat_lock_dttm_after , pat_smoking_ind AS pat_smoking_ind , pat_smoking_ind_after AS pat_smoking_ind_after , pat_pregnancy_ind AS pat_pregnancy_ind , pat_pregnancy_ind_after AS pat_pregnancy_ind_after , CONCAT(CONCAT(SUBSTRING(pat_preg_due_dttm,0,10),' '),SUBSTRING(pat_preg_due_dttm, 12,8)) AS pat_preg_due_dttm , CONCAT(CONCAT(SUBSTRING(pat_preg_due_dttm_after,0,10),' '),SUBSTRING(pat_preg_due_dttm_after, 12,8)) AS pat_preg_due_dttm_after , (case when (LENGTH(TRIM(pat_pickup_id))==0) then pat_pickup_id else TRIM(pat_pickup_id) end) AS pat_pickup_id , (case when (LENGTH(TRIM(pat_pickup_id_after))==0) then pat_pickup_id_after else TRIM(pat_pickup_id_after) end) AS pat_pickup_id_after , pat_brochure_ind AS pat_brochure_ind , pat_brochure_ind_after AS pat_brochure_ind_after , pat_large_print_ind AS pat_large_print_ind , pat_large_print_ind_after AS pat_large_print_ind_after , (case when (LENGTH(TRIM(pat_ck_acct_nbr))==0) then pat_ck_acct_nbr else TRIM(pat_ck_acct_nbr) end) AS pat_ck_acct_nbr , (case when (LENGTH(TRIM(pat_ck_acct_nbr_after))==0) then pat_ck_acct_nbr_after else TRIM(pat_ck_acct_nbr_after) end) AS pat_ck_acct_nbr_after , (case when (LENGTH(TRIM(pat_ck_route_nbr))==0) then pat_ck_route_nbr else TRIM(pat_ck_route_nbr) end) AS pat_ck_route_nbr , (case when (LENGTH(TRIM(pat_ck_route_nbr_after))==0) then pat_ck_route_nbr_after else TRIM(pat_ck_route_nbr_after) end) AS pat_ck_route_nbr_after , pat_homecare_ind AS pat_homecare_ind , pat_homecare_ind_after AS pat_homecare_ind_after , cust_balance_hold_ind AS cust_balance_hold_ind , cust_balance_hold_ind_after AS cust_balance_hold_ind_after , pat_specialty_ind AS pat_specialty_ind , pat_specialty_ind_after AS pat_specialty_ind_after , (case when (LENGTH(TRIM(pat_hipaa_auth_name))==0) then pat_hipaa_auth_name else TRIM(pat_hipaa_auth_name) end) AS pat_hipaa_auth_name , (case when (LENGTH(TRIM(pat_hipaa_auth_name_after))==0) then pat_hipaa_auth_name_after else TRIM(pat_hipaa_auth_name_after) end) AS pat_hipaa_auth_name_after , (case when (LENGTH(TRIM(pat_hipaa_auth_exp))==0) then pat_hipaa_auth_exp else TRIM(pat_hipaa_auth_exp) end) AS pat_hipaa_auth_exp , (case when (LENGTH(TRIM(pat_hipaa_auth_exp_after))==0) then pat_hipaa_auth_exp_after else TRIM(pat_hipaa_auth_exp_after) end) AS pat_hipaa_auth_exp_after , (case when (LENGTH(TRIM(pat_hipaa_auth_other))==0) then pat_hipaa_auth_other else TRIM(pat_hipaa_auth_other) end) AS pat_hipaa_auth_other , (case when (LENGTH(TRIM(pat_hipaa_auth_other_after))==0) then pat_hipaa_auth_other_after else TRIM(pat_hipaa_auth_other_after) end) AS pat_hipaa_auth_other_after , pat_hipaa_auth_cd AS pat_hipaa_auth_cd , pat_hipaa_auth_cd_after AS pat_hipaa_auth_cd_after , pat_rca_ind AS pat_rca_ind , pat_rca_ind_after AS pat_rca_ind_after , (case when (LENGTH(TRIM(e2c_l4c))==0) then e2c_l4c else TRIM(e2c_l4c) end) AS e2c_l4c , (case when (LENGTH(TRIM(e2c_l4c_after))==0) then e2c_l4c_after else TRIM(e2c_l4c_after) end) AS e2c_l4c_after , (case when (LENGTH(TRIM(e2c_hash))==0) then e2c_hash else TRIM(e2c_hash) end) AS e2c_hash , (case when (LENGTH(TRIM(e2c_hash_after))==0) then e2c_hash_after else TRIM(e2c_hash_after) end) AS e2c_hash_after , pat_text_msg_ind AS pat_text_msg_ind , pat_text_msg_ind_after AS pat_text_msg_ind_after , (case when (LENGTH(TRIM(pat_text_msg_carrier))==0) then pat_text_msg_carrier else TRIM(pat_text_msg_carrier) end) AS pat_text_msg_carrier , (case when (LENGTH(TRIM(pat_text_msg_carrier_after))==0) then pat_text_msg_carrier_after else TRIM(pat_text_msg_carrier_after) end) AS pat_text_msg_carrier_after , pat_prim_phone_pref_cd AS pat_prim_phone_pref_cd , pat_prim_phone_pref_cd_after AS pat_prim_phone_pref_cd_after , pat_billing_cd AS pat_billing_cd , pat_billing_cd_after AS pat_billing_cd_after , (case when (LENGTH(TRIM(pat_link_cd))==0) then pat_link_cd else TRIM(pat_link_cd) end) AS pat_link_cd , (case when (LENGTH(TRIM(pat_link_cd_after))==0) then pat_link_cd_after else TRIM(pat_link_cd_after) end) AS pat_link_cd_after , pat_autorefill_ind AS pat_autorefill_ind , pat_autorefill_ind_after AS pat_autorefill_ind_after , auto_refill_pref_str_nbr AS auto_refill_pref_str_nbr , auto_refill_pref_str_nbr_after AS auto_refill_pref_str_nbr_after , pat_residence_cd AS pat_residence_cd , pat_residence_cd_after AS pat_residence_cd_after , pat_prim_care_pbr_id AS pat_prim_care_pbr_id , pat_prim_care_pbr_id_after AS pat_prim_care_pbr_id_after , pat_prim_care_pbr_loc_id AS pat_prim_care_pbr_loc_id , pat_prim_care_pbr_loc_id_after AS pat_prim_care_pbr_loc_id_after , (case when (LENGTH(TRIM(pat_pickup_id_qlfr))==0) then pat_pickup_id_qlfr else TRIM(pat_pickup_id_qlfr) end) AS pat_pickup_id_qlfr , (case when (LENGTH(TRIM(pat_pickup_id_qlfr_after))==0) then pat_pickup_id_qlfr_after else TRIM(pat_pickup_id_qlfr_after) end) AS pat_pickup_id_qlfr_after , (case when (LENGTH(TRIM(pat_pickup_gov_auth_id))==0) then pat_pickup_gov_auth_id else TRIM(pat_pickup_gov_auth_id) end) AS pat_pickup_gov_auth_id , (case when (LENGTH(TRIM(pat_pickup_gov_auth_id_after))==0) then pat_pickup_gov_auth_id_after else TRIM(pat_pickup_gov_auth_id_after) end) AS pat_pickup_gov_auth_id_after , (case when (LENGTH(TRIM(pat_pickup_rel_cd))==0) then pat_pickup_rel_cd else TRIM(pat_pickup_rel_cd) end) AS pat_pickup_rel_cd , (case when (LENGTH(TRIM(pat_pickup_rel_cd_after))==0) then pat_pickup_rel_cd_after else TRIM(pat_pickup_rel_cd_after) end) AS pat_pickup_rel_cd_after , pat_unmerge_verify_ind AS pat_unmerge_verify_ind , pat_unmerge_verify_ind_after AS pat_unmerge_verify_ind_after , pat_twin_ind AS pat_twin_ind , pat_twin_ind_after AS pat_twin_ind_after , pat_90day_pref_ind AS pat_90day_pref_ind , pat_90day_pref_ind_after AS pat_90day_pref_ind_after , CONCAT(CONCAT(SUBSTRING(pat_90day_pref_dttm,0,10),' '),SUBSTRING(pat_90day_pref_dttm, 12,8)) AS pat_90day_pref_dttm , CONCAT(CONCAT(SUBSTRING(pat_90day_pref_dttm_after,0,10),' '),SUBSTRING(pat_90day_pref_dttm_after, 12,8)) AS pat_90day_pref_dttm_after, (case when (LENGTH(TRIM(pat_alg_block_madr_ind))==0) then pat_alg_block_madr_ind else TRIM(pat_alg_block_madr_ind) end) AS pat_alg_block_madr_ind,(case when (LENGTH(TRIM(pat_alg_block_madr_ind_after))==0) then pat_alg_block_madr_ind_after else TRIM(pat_alg_block_madr_ind_after) end) AS pat_alg_block_madr_ind_after from dedup_group"""


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV)
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL)

#display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

#print(gg_tbf0_rejected.count())

# COMMAND ----------

# print(nr_spacetrim.count())

# print(nr_update_check.count())

# print(nr_insert_check.count())

# print(nr_rejected.count())

# print(gg_tbf0_update.count())



# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,
cdc_seq_nbr_after as cdc_seq_nbr,
cdc_rba_nbr_after as cdc_rba_nbr,
cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,edw_batch_id_after as edw_batch_id ,src_partition_nbr_after AS src_partition_nbr ,pat_id_after AS pat_id , pat_first_name_after AS pat_first_name , pat_mid_init_after AS pat_mid_init , pat_last_name_after AS pat_last_name , pat_last_name_soundex_after AS pat_last_name_soundex , pat_surname_suffix_after AS pat_surname_suffix , pat_street_addr_after AS pat_street_addr , pat_city_after AS pat_city , pat_state_after AS pat_state , pat_zip_after AS pat_zip , pat_sex_cd_after AS pat_sex_cd , pat_birth_dttm_after AS pat_birth_dttm , pat_prim_area_cd_after AS pat_prim_area_cd , pat_prim_phone_after AS pat_prim_phone , pat_prim_phone_cd_after AS pat_prim_phone_cd , pat_sec_area_cd_after AS pat_sec_area_cd , pat_sec_phone_after AS pat_sec_phone , pat_hoh_id_after AS pat_hoh_id , pat_hoh_relation_cd_after AS pat_hoh_relation_cd , pat_discount_cd_after AS pat_discount_cd , pat_clinic_medical_id_after AS pat_clinic_medical_id , pat_snap_cap_pref_after AS pat_snap_cap_pref , pat_generic_subs_pref_after AS pat_generic_subs_pref , pat_thera_subs_pref_after AS pat_thera_subs_pref , pat_mail_list_pref_after AS pat_mail_list_pref , pat_lang_pref_cd_after AS pat_lang_pref_cd , pat_purged_rx_ind_after AS pat_purged_rx_ind , pat_pet_ind_after AS pat_pet_ind , pat_pet_type_after AS pat_pet_type , pat_preappr_pay_ind_after AS pat_preappr_pay_ind , pat_cc_nbr_after AS pat_cc_nbr , pat_mail_service_id_after AS pat_mail_service_id , pat_cmts_after AS pat_cmts , pat_create_store_nbr_after AS pat_create_store_nbr , pat_deceased_ind_after AS pat_deceased_ind , pat_algy_hlth_type_cd_after AS pat_algy_hlth_type_cd , pat_algy_hlth_cd_inq_ind_after AS pat_algy_hlth_cd_inq_ind , pat_wc_ind_after AS pat_wc_ind , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , pat_phone_contact_pref_after AS pat_phone_contact_pref , pat_signature_ind_after AS pat_signature_ind , pat_internet_ind_after AS pat_internet_ind , pat_ext_rx_otc_ind_after AS pat_ext_rx_otc_ind , pat_registration_dttm_after AS pat_registration_dttm , pat_cc_holder_zip_after AS pat_cc_holder_zip , pat_mfg_card_ind_after AS pat_mfg_card_ind , pat_sr_div_rec_nbr_after AS pat_sr_div_rec_nbr , pat_hipaa_ind_after AS pat_hipaa_ind , pat_hipaa_dttm_after AS pat_hipaa_dttm , pat_hipaa_store_nbr_after AS pat_hipaa_store_nbr , buyout_pat_ind_after AS buyout_pat_ind , pat_hipaa_ack_ltr_ind_after AS pat_hipaa_ack_ltr_ind , pat_email_address_after AS pat_email_address , pat_email_dttm_after AS pat_email_dttm , pat_email_user_id_after AS pat_email_user_id , pat_lock_ind_after AS pat_lock_ind , pat_lock_store_nbr_after AS pat_lock_store_nbr , pat_lock_user_id_after AS pat_lock_user_id , pat_lock_dttm_after AS pat_lock_dttm , pat_smoking_ind_after AS pat_smoking_ind , pat_pregnancy_ind_after AS pat_pregnancy_ind , pat_preg_due_dttm_after AS pat_preg_due_dttm , pat_pickup_id_after AS pat_pickup_id , pat_brochure_ind_after AS pat_brochure_ind , pat_large_print_ind_after AS pat_large_print_ind , pat_ck_acct_nbr_after AS pat_ck_acct_nbr , pat_ck_route_nbr_after AS pat_ck_route_nbr , pat_homecare_ind_after AS pat_homecare_ind , cust_balance_hold_ind_after AS cust_balance_hold_ind , pat_specialty_ind_after AS pat_specialty_ind , pat_hipaa_auth_name_after AS pat_hipaa_auth_name , pat_hipaa_auth_exp_after AS pat_hipaa_auth_exp , pat_hipaa_auth_other_after AS pat_hipaa_auth_other , pat_hipaa_auth_cd_after AS pat_hipaa_auth_cd , pat_rca_ind_after AS pat_rca_ind , e2c_l4c_after AS e2c_l4c , e2c_hash_after AS e2c_hash , pat_text_msg_ind_after AS pat_text_msg_ind , pat_text_msg_carrier_after AS pat_text_msg_carrier , pat_prim_phone_pref_cd_after AS pat_prim_phone_pref_cd , pat_billing_cd_after AS pat_billing_cd , pat_link_cd_after AS pat_link_cd , pat_autorefill_ind_after AS pat_autorefill_ind , auto_refill_pref_str_nbr_after AS auto_refill_pref_str_nbr , pat_residence_cd_after AS pat_residence_cd , pat_prim_care_pbr_id_after AS pat_prim_care_pbr_id , pat_prim_care_pbr_loc_id_after AS pat_prim_care_pbr_loc_id , pat_pickup_id_qlfr_after AS pat_pickup_id_qlfr , pat_pickup_gov_auth_id_after AS pat_pickup_gov_auth_id , pat_pickup_rel_cd_after AS pat_pickup_rel_cd , pat_unmerge_verify_ind_after AS pat_unmerge_verify_ind , pat_twin_ind_after AS pat_twin_ind , pat_90day_pref_ind_after AS pat_90day_pref_ind , pat_90day_pref_dttm_after AS pat_90day_pref_dttm ,pat_alg_block_madr_ind_after as pat_alg_block_madr_ind, 'gg_tbf0_patient' AS table_name from gg_tbf0_update """

pTgtUpdBfrXfr = """select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd,edw_batch_id as edw_batch_id,  src_partition_nbr AS src_partition_nbr ,pat_id AS pat_id , pat_first_name AS pat_first_name , pat_mid_init AS pat_mid_init , pat_last_name AS pat_last_name , pat_last_name_soundex AS pat_last_name_soundex , pat_surname_suffix AS pat_surname_suffix , pat_street_addr AS pat_street_addr , pat_city AS pat_city , pat_state AS pat_state , pat_zip AS pat_zip , pat_sex_cd AS pat_sex_cd , pat_birth_dttm AS pat_birth_dttm , pat_prim_area_cd AS pat_prim_area_cd , pat_prim_phone AS pat_prim_phone , pat_prim_phone_cd AS pat_prim_phone_cd , pat_sec_area_cd AS pat_sec_area_cd , pat_sec_phone AS pat_sec_phone , pat_hoh_id AS pat_hoh_id , pat_hoh_relation_cd AS pat_hoh_relation_cd , pat_discount_cd AS pat_discount_cd , pat_clinic_medical_id AS pat_clinic_medical_id , pat_snap_cap_pref AS pat_snap_cap_pref , pat_generic_subs_pref AS pat_generic_subs_pref , pat_thera_subs_pref AS pat_thera_subs_pref , pat_mail_list_pref AS pat_mail_list_pref , pat_lang_pref_cd AS pat_lang_pref_cd , pat_purged_rx_ind AS pat_purged_rx_ind , pat_pet_ind AS pat_pet_ind , pat_pet_type AS pat_pet_type , pat_preappr_pay_ind AS pat_preappr_pay_ind , pat_cc_nbr AS pat_cc_nbr , pat_mail_service_id AS pat_mail_service_id , pat_cmts AS pat_cmts , pat_create_store_nbr AS pat_create_store_nbr , pat_deceased_ind AS pat_deceased_ind , pat_algy_hlth_type_cd AS pat_algy_hlth_type_cd , pat_algy_hlth_cd_inq_ind AS pat_algy_hlth_cd_inq_ind , pat_wc_ind AS pat_wc_ind , create_user_id AS create_user_id , create_dttm AS create_dttm , update_user_id AS update_user_id , update_dttm AS update_dttm , pat_phone_contact_pref AS pat_phone_contact_pref , pat_signature_ind AS pat_signature_ind , pat_internet_ind AS pat_internet_ind , pat_ext_rx_otc_ind AS pat_ext_rx_otc_ind , pat_registration_dttm AS pat_registration_dttm , pat_cc_holder_zip AS pat_cc_holder_zip , pat_mfg_card_ind AS pat_mfg_card_ind , pat_sr_div_rec_nbr AS pat_sr_div_rec_nbr , pat_hipaa_ind AS pat_hipaa_ind , pat_hipaa_dttm AS pat_hipaa_dttm , pat_hipaa_store_nbr AS pat_hipaa_store_nbr , buyout_pat_ind AS buyout_pat_ind , pat_hipaa_ack_ltr_ind AS pat_hipaa_ack_ltr_ind , pat_email_address AS pat_email_address , pat_email_dttm AS pat_email_dttm , pat_email_user_id AS pat_email_user_id , pat_lock_ind AS pat_lock_ind , pat_lock_store_nbr AS pat_lock_store_nbr , pat_lock_user_id AS pat_lock_user_id , pat_lock_dttm AS pat_lock_dttm , pat_smoking_ind AS pat_smoking_ind , pat_pregnancy_ind AS pat_pregnancy_ind , pat_preg_due_dttm AS pat_preg_due_dttm , pat_pickup_id AS pat_pickup_id , pat_brochure_ind AS pat_brochure_ind , pat_large_print_ind AS pat_large_print_ind , pat_ck_acct_nbr AS pat_ck_acct_nbr , pat_ck_route_nbr AS pat_ck_route_nbr , pat_homecare_ind AS pat_homecare_ind , cust_balance_hold_ind AS cust_balance_hold_ind , pat_specialty_ind AS pat_specialty_ind , pat_hipaa_auth_name AS pat_hipaa_auth_name , pat_hipaa_auth_exp AS pat_hipaa_auth_exp , pat_hipaa_auth_other AS pat_hipaa_auth_other , pat_hipaa_auth_cd AS pat_hipaa_auth_cd , pat_rca_ind AS pat_rca_ind , e2c_l4c AS e2c_l4c , e2c_hash AS e2c_hash , pat_text_msg_ind AS pat_text_msg_ind , pat_text_msg_carrier AS pat_text_msg_carrier , pat_prim_phone_pref_cd AS pat_prim_phone_pref_cd , pat_billing_cd AS pat_billing_cd , pat_link_cd AS pat_link_cd , pat_autorefill_ind AS pat_autorefill_ind , auto_refill_pref_str_nbr AS auto_refill_pref_str_nbr , pat_residence_cd AS pat_residence_cd , pat_prim_care_pbr_id AS pat_prim_care_pbr_id , pat_prim_care_pbr_loc_id AS pat_prim_care_pbr_loc_id , pat_pickup_id_qlfr AS pat_pickup_id_qlfr , pat_pickup_gov_auth_id AS pat_pickup_gov_auth_id , pat_pickup_rel_cd AS pat_pickup_rel_cd , pat_unmerge_verify_ind AS pat_unmerge_verify_ind , pat_twin_ind AS pat_twin_ind , pat_90day_pref_ind AS pat_90day_pref_ind , pat_90day_pref_dttm AS pat_90day_pref_dttm ,pat_alg_block_madr_ind, 'gg_tbf0_patient' AS table_name from gg_tbf0_update """

pTgtInsBfrAftXfr = """select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
cdc_seq_nbr as cdc_seq_nbr,
cdc_rba_nbr as cdc_rba_nbr,
cdc_operation_type_cd as cdc_operation_type_cd 
,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,edw_batch_id_after as edw_batch_id ,src_partition_nbr_after AS src_partition_nbr ,pat_id_after AS pat_id , pat_first_name_after AS pat_first_name , pat_mid_init_after AS pat_mid_init , pat_last_name_after AS pat_last_name , pat_last_name_soundex_after AS pat_last_name_soundex , pat_surname_suffix_after AS pat_surname_suffix , pat_street_addr_after AS pat_street_addr , pat_city_after AS pat_city , pat_state_after AS pat_state , pat_zip_after AS pat_zip , pat_sex_cd_after AS pat_sex_cd , pat_birth_dttm_after AS pat_birth_dttm , pat_prim_area_cd_after AS pat_prim_area_cd , pat_prim_phone_after AS pat_prim_phone , pat_prim_phone_cd_after AS pat_prim_phone_cd , pat_sec_area_cd_after AS pat_sec_area_cd , pat_sec_phone_after AS pat_sec_phone , pat_hoh_id_after AS pat_hoh_id , pat_hoh_relation_cd_after AS pat_hoh_relation_cd , pat_discount_cd_after AS pat_discount_cd , pat_clinic_medical_id_after AS pat_clinic_medical_id , pat_snap_cap_pref_after AS pat_snap_cap_pref , pat_generic_subs_pref_after AS pat_generic_subs_pref , pat_thera_subs_pref_after AS pat_thera_subs_pref , pat_mail_list_pref_after AS pat_mail_list_pref , pat_lang_pref_cd_after AS pat_lang_pref_cd , pat_purged_rx_ind_after AS pat_purged_rx_ind , pat_pet_ind_after AS pat_pet_ind , pat_pet_type_after AS pat_pet_type , pat_preappr_pay_ind_after AS pat_preappr_pay_ind , pat_cc_nbr_after AS pat_cc_nbr , pat_mail_service_id_after AS pat_mail_service_id , pat_cmts_after AS pat_cmts , pat_create_store_nbr_after AS pat_create_store_nbr , pat_deceased_ind_after AS pat_deceased_ind , pat_algy_hlth_type_cd_after AS pat_algy_hlth_type_cd , pat_algy_hlth_cd_inq_ind_after AS pat_algy_hlth_cd_inq_ind , pat_wc_ind_after AS pat_wc_ind , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , pat_phone_contact_pref_after AS pat_phone_contact_pref , pat_signature_ind_after AS pat_signature_ind , pat_internet_ind_after AS pat_internet_ind , pat_ext_rx_otc_ind_after AS pat_ext_rx_otc_ind , pat_registration_dttm_after AS pat_registration_dttm , pat_cc_holder_zip_after AS pat_cc_holder_zip , pat_mfg_card_ind_after AS pat_mfg_card_ind , pat_sr_div_rec_nbr_after AS pat_sr_div_rec_nbr , pat_hipaa_ind_after AS pat_hipaa_ind , pat_hipaa_dttm_after AS pat_hipaa_dttm , pat_hipaa_store_nbr_after AS pat_hipaa_store_nbr , buyout_pat_ind_after AS buyout_pat_ind , pat_hipaa_ack_ltr_ind_after AS pat_hipaa_ack_ltr_ind , pat_email_address_after AS pat_email_address , pat_email_dttm_after AS pat_email_dttm , pat_email_user_id_after AS pat_email_user_id , pat_lock_ind_after AS pat_lock_ind , pat_lock_store_nbr_after AS pat_lock_store_nbr , pat_lock_user_id_after AS pat_lock_user_id , pat_lock_dttm_after AS pat_lock_dttm , pat_smoking_ind_after AS pat_smoking_ind , pat_pregnancy_ind_after AS pat_pregnancy_ind , pat_preg_due_dttm_after AS pat_preg_due_dttm , pat_pickup_id_after AS pat_pickup_id , pat_brochure_ind_after AS pat_brochure_ind , pat_large_print_ind_after AS pat_large_print_ind , pat_ck_acct_nbr_after AS pat_ck_acct_nbr , pat_ck_route_nbr_after AS pat_ck_route_nbr , pat_homecare_ind_after AS pat_homecare_ind , cust_balance_hold_ind_after AS cust_balance_hold_ind , pat_specialty_ind_after AS pat_specialty_ind , pat_hipaa_auth_name_after AS pat_hipaa_auth_name , pat_hipaa_auth_exp_after AS pat_hipaa_auth_exp , pat_hipaa_auth_other_after AS pat_hipaa_auth_other , pat_hipaa_auth_cd_after AS pat_hipaa_auth_cd , pat_rca_ind_after AS pat_rca_ind , e2c_l4c_after AS e2c_l4c , e2c_hash_after AS e2c_hash , pat_text_msg_ind_after AS pat_text_msg_ind , pat_text_msg_carrier_after AS pat_text_msg_carrier , pat_prim_phone_pref_cd_after AS pat_prim_phone_pref_cd , pat_billing_cd_after AS pat_billing_cd , pat_link_cd_after AS pat_link_cd , pat_autorefill_ind_after AS pat_autorefill_ind , auto_refill_pref_str_nbr_after AS auto_refill_pref_str_nbr , pat_residence_cd_after AS pat_residence_cd , pat_prim_care_pbr_id_after AS pat_prim_care_pbr_id , pat_prim_care_pbr_loc_id_after AS pat_prim_care_pbr_loc_id , pat_pickup_id_qlfr_after AS pat_pickup_id_qlfr , pat_pickup_gov_auth_id_after AS pat_pickup_gov_auth_id , pat_pickup_rel_cd_after AS pat_pickup_rel_cd , pat_unmerge_verify_ind_after AS pat_unmerge_verify_ind , pat_twin_ind_after AS pat_twin_ind , pat_90day_pref_ind_after AS pat_90day_pref_ind , pat_90day_pref_dttm_after AS pat_90day_pref_dttm ,pat_alg_block_madr_ind, 'gg_tbf0_patient' AS table_name from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

# print(gg_tbf0_update_afr.count())

# print(gg_tbf0_update_bfr.count())

# print(gg_tbf0_insert_afr.count())

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD)

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
#display(etl_tbf0_file)
  

# COMMAND ----------

# print(gg_tbf0_insert_patid_check.count())
# print(gg_tbf0_insert_nopatid.count())
# print(gg_tbf0_insert_patid_check_rejected.count())

# COMMAND ----------

#print(etl_tbf0_file.count())

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
#print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)


#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))


etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())


#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# print(etl_tbf0_reformat_cdc_check_notnull.count())
# print(etl_tbf0_reformat_cdc_check.count())

# COMMAND ----------


#Load ETL_TBF0_* formatted records to the Snowflake Table
df_etl_final=etl_tbf0_reformat_cdc_check_notnull
df_etl_final=df_etl_final\
.withColumn("CDC_TXN_COMMIT_DTTM",to_timestamp(regexp_replace(df_etl_final["CDC_TXN_COMMIT_DTTM"],"  "," "))) \
.withColumn("PAT_BIRTH_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_BIRTH_DTTM"],"  "," "))) \
.withColumn("CREATE_DTTM",to_timestamp(regexp_replace(df_etl_final["CREATE_DTTM"],"  "," "))) \
.withColumn("UPDATE_DTTM",to_timestamp(regexp_replace(df_etl_final["UPDATE_DTTM"],"  "," "))) \
.withColumn("PAT_REGISTRATION_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_REGISTRATION_DTTM"],"  "," "))) \
.withColumn("PAT_HIPAA_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_HIPAA_DTTM"],"  "," "))) \
.withColumn("PAT_EMAIL_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_EMAIL_DTTM"],"  "," "))) \
.withColumn("PAT_LOCK_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_LOCK_DTTM"],"  "," "))) \
.withColumn("PAT_PREG_DUE_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_PREG_DUE_DTTM"],"  "," "))) \
.withColumn("PAT_90DAY_PREF_DTTM",to_timestamp(regexp_replace(df_etl_final["PAT_90DAY_PREF_DTTM"],"  "," "))) \
.withColumn("CDC_SEQ_NBR",df_etl_final["CDC_SEQ_NBR"].cast(LongType())) \
.withColumn("CDC_RBA_NBR",df_etl_final["CDC_RBA_NBR"].cast(LongType())) \
.withColumn("EDW_BATCH_ID",df_etl_final["EDW_BATCH_ID"].cast(LongType())) \
.withColumn("PAT_ID",df_etl_final["PAT_ID"].cast(LongType())) \
.withColumn("PAT_HOH_ID",df_etl_final["PAT_HOH_ID"].cast(LongType())) \
.withColumn("PAT_CREATE_STORE_NBR",df_etl_final["PAT_CREATE_STORE_NBR"].cast(LongType())) \
.withColumn("CREATE_USER_ID",df_etl_final["CREATE_USER_ID"].cast(LongType())) \
.withColumn("UPDATE_USER_ID",df_etl_final["UPDATE_USER_ID"].cast(LongType())) \
.withColumn("PAT_HIPAA_STORE_NBR",df_etl_final["PAT_HIPAA_STORE_NBR"].cast(LongType())) \
.withColumn("PAT_EMAIL_USER_ID",df_etl_final["PAT_EMAIL_USER_ID"].cast(LongType())) \
.withColumn("PAT_LOCK_STORE_NBR",df_etl_final["PAT_LOCK_STORE_NBR"].cast(LongType())) \
.withColumn("PAT_LOCK_USER_ID",df_etl_final["PAT_LOCK_USER_ID"].cast(LongType())) \
.withColumn("AUTO_REFILL_PREF_STR_NBR",df_etl_final["AUTO_REFILL_PREF_STR_NBR"].cast(LongType())) \
.withColumn("PAT_RESIDENCE_CD",df_etl_final["PAT_RESIDENCE_CD"].cast(LongType())) \
.withColumn("PAT_PRIM_CARE_PBR_ID",df_etl_final["PAT_PRIM_CARE_PBR_ID"].cast(LongType())) \
.withColumn("PAT_PRIM_CARE_PBR_LOC_ID",df_etl_final["PAT_PRIM_CARE_PBR_LOC_ID"].cast(LongType()))\
.withColumn("edw_batch_id",lit(BATCH_ID))

# COMMAND ----------

#print(df_etl_final.count())

# COMMAND ----------

df_etl_final=df_etl_final.select("CDC_TXN_COMMIT_DTTM", "CDC_SEQ_NBR", "CDC_RBA_NBR", "CDC_OPERATION_TYPE_CD", "CDC_BEFORE_AFTER_CD", "CDC_TXN_POSITION_CD", "EDW_BATCH_ID", "PAT_ID", "PAT_FIRST_NAME", "PAT_MID_INIT", "PAT_LAST_NAME", "PAT_LAST_NAME_SOUNDEX", "PAT_SURNAME_SUFFIX", "PAT_STREET_ADDR", "PAT_CITY", "PAT_STATE", "PAT_ZIP", "PAT_SEX_CD", "PAT_BIRTH_DTTM", "PAT_PRIM_AREA_CD", "PAT_PRIM_PHONE", "PAT_PRIM_PHONE_CD", "PAT_SEC_AREA_CD", "PAT_SEC_PHONE", "PAT_HOH_ID", "PAT_HOH_RELATION_CD", "PAT_DISCOUNT_CD", "PAT_CLINIC_MEDICAL_ID", "PAT_SNAP_CAP_PREF", "PAT_GENERIC_SUBS_PREF", "PAT_THERA_SUBS_PREF", "PAT_MAIL_LIST_PREF", "PAT_LANG_PREF_CD", "PAT_PURGED_RX_IND", "PAT_PET_IND", "PAT_PET_TYPE", "PAT_PREAPPR_PAY_IND", "PAT_CC_NBR", "PAT_MAIL_SERVICE_ID", "PAT_CMTS", "PAT_CREATE_STORE_NBR", "PAT_DECEASED_IND", "PAT_ALGY_HLTH_TYPE_CD", "PAT_ALGY_HLTH_CD_INQ_IND", "PAT_WC_IND", "CREATE_USER_ID", "CREATE_DTTM", "UPDATE_USER_ID", "UPDATE_DTTM", "PAT_PHONE_CONTACT_PREF", "PAT_SIGNATURE_IND", "PAT_INTERNET_IND", "PAT_EXT_RX_OTC_IND", "PAT_REGISTRATION_DTTM", "PAT_CC_HOLDER_ZIP", "PAT_MFG_CARD_IND", "PAT_SR_DIV_REC_NBR", "PAT_HIPAA_IND", "PAT_HIPAA_DTTM", "PAT_HIPAA_STORE_NBR", "BUYOUT_PAT_IND", "PAT_HIPAA_ACK_LTR_IND", "PAT_EMAIL_ADDRESS", "PAT_EMAIL_DTTM", "PAT_EMAIL_USER_ID", "PAT_LOCK_IND", "PAT_LOCK_STORE_NBR", "PAT_LOCK_USER_ID", "PAT_LOCK_DTTM", "PAT_SMOKING_IND", "PAT_PREGNANCY_IND", "PAT_PREG_DUE_DTTM", "PAT_PICKUP_ID", "PAT_BROCHURE_IND", "PAT_LARGE_PRINT_IND", "PAT_CK_ACCT_NBR", "PAT_CK_ROUTE_NBR", "PAT_HOMECARE_IND", "CUST_BALANCE_HOLD_IND", "PAT_SPECIALTY_IND", "PAT_HIPAA_AUTH_NAME", "PAT_HIPAA_AUTH_EXP", "PAT_HIPAA_AUTH_OTHER", "PAT_HIPAA_AUTH_CD", "PAT_RCA_IND", "E2C_L4C", "E2C_HASH", "PAT_TEXT_MSG_IND", "PAT_TEXT_MSG_CARRIER", "PAT_PRIM_PHONE_PREF_CD", "PAT_BILLING_CD", "PAT_LINK_CD", "SRC_PARTITION_NBR", "PAT_AUTOREFILL_IND", "AUTO_REFILL_PREF_STR_NBR", "PAT_RESIDENCE_CD", "PAT_PRIM_CARE_PBR_ID", "PAT_PRIM_CARE_PBR_LOC_ID", "PAT_PICKUP_GOV_AUTH_ID", "PAT_PICKUP_ID_QLFR", "PAT_PICKUP_REL_CD", "PAT_UNMERGE_VERIFY_IND", "PAT_TWIN_IND", "PAT_90DAY_PREF_IND", "PAT_90DAY_PREF_DTTM","PAT_ALG_BLOCK_MADR_IND")


#display(df_etl_final)

# COMMAND ----------

import pyspark.sql.functions as func
for col in df_etl_final.columns:
    df_etl_final = df_etl_final.withColumn(col, when(func.ltrim(func.rtrim(df_etl_final[col])) == "",None).otherwise(df_etl_final[col]))
    

#display(df_etl_final)

# COMMAND ----------

df_etl_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB ) \
    .option("dbtable", "PATIENT.ETL_TBF0_PATIENT_STG") \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

#print(df_etl_final.count())

# COMMAND ----------


#Write API Call to Close Open Assets
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_ASSET_STATUS='200'
#dfAssetIdStr
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/UpdateProcessedFilesStatus", 200, 
                   {"PAR_ASSET_STATUS":PAR_ASSET_STATUS,
                    "PAR_FEED_NAMES":FEED_NAME,
                    "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                    "PAR_SQL_SERVER":PAR_SQL_SERVER,
                    "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                    "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                    "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                    "PAR_WRITEAPI_URL":PAR_WRITEAPI_URL})
print("Write API successfully executed...")
dbutils.notebook.exit("ETL_TBF0_PATIENT_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")

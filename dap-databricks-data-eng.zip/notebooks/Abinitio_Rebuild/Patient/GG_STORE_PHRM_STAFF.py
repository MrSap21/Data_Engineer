# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'


print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'store_nbr',
'store_nbr_after',
'phrm_staff_user_id',
'phrm_staff_user_id_after',
'staff_initials',
'staff_initials_after',
'phrm_staff_first_name',
'phrm_staff_first_name_after',
'phrm_staff_mid_init',
'phrm_staff_mid_init_after',
'phrm_staff_last_name',
'phrm_staff_last_name_after',
'phrm_staff_position_cd',
'phrm_staff_position_cd_after',
'phrm_rph_label_id',
'phrm_rph_label_id_after',
'phrm_staff_lic_nbr',
'phrm_staff_lic_nbr_after',
'phrm_staff_home_area_cd',
'phrm_staff_home_area_cd_after',
'phrm_staff_home_phone',
'phrm_staff_home_phone_after',
'phrm_phrmcst_access_ind',
'phrm_phrmcst_access_ind_after',
'p2000_access_level',
'p2000_access_level_after',
'employment_status_ind',
'employment_status_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'phrm_staff_spec_lic_nbr',
'phrm_staff_spec_lic_nbr_after',
'phrm_staff_employed_ind',
'phrm_staff_employed_ind_after',
'icplus_editable_ind',
'icplus_editable_ind_after',
'rph_consult_barcd_nbr',
'rph_consult_barcd_nbr_after',
'rph_barcd_exp_dttm',
'rph_barcd_exp_dttm_after',
'phrm_staff_npi',
'phrm_staff_npi_after',
'phrm_staff_rfp_ind',
'phrm_staff_rfp_ind_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if '"INSERT"' in key_list[6]:
    if val_len != 63 :
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 64:
      return True
  else:
    if val_len != 64:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 64

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 64
print(f"Bad records count {rd_bad.count()}") # != 64


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    df.columns,
    df
))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_store_phrm_staff")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
(case when (LENGTH(trim( edw_batch_id )) ==0) then edw_batch_id else trim(edw_batch_id)end) as edw_batch_id,
(case when (LENGTH(trim( store_nbr )) ==0) then store_nbr else trim(store_nbr)end) as store_nbr,
(case when (LENGTH(trim( phrm_staff_user_id )) ==0) then phrm_staff_user_id else trim(phrm_staff_user_id)end) as phrm_staff_user_id,
(case when (LENGTH(trim( staff_initials )) ==0) then staff_initials else trim(staff_initials)end) as staff_initials,
(case when (LENGTH(trim( phrm_staff_first_name )) ==0) then phrm_staff_first_name else trim(phrm_staff_first_name)end) as phrm_staff_first_name,
(case when (LENGTH(trim( phrm_staff_mid_init )) ==0) then phrm_staff_mid_init else trim(phrm_staff_mid_init)end) as phrm_staff_mid_init,
(case when (LENGTH(trim( phrm_staff_last_name )) ==0) then phrm_staff_last_name else trim(phrm_staff_last_name)end) as phrm_staff_last_name,
(case when (LENGTH(trim( phrm_staff_position_cd )) ==0) then phrm_staff_position_cd else trim(phrm_staff_position_cd)end) as phrm_staff_position_cd,
(case when (LENGTH(trim( phrm_rph_label_id )) ==0) then phrm_rph_label_id else trim(phrm_rph_label_id)end) as phrm_rph_label_id,
(case when (LENGTH(trim( phrm_staff_lic_nbr )) ==0) then phrm_staff_lic_nbr else trim(phrm_staff_lic_nbr)end) as phrm_staff_lic_nbr,
(case when (LENGTH(trim( phrm_staff_home_area_cd )) ==0) then phrm_staff_home_area_cd else trim(phrm_staff_home_area_cd)end) as phrm_staff_home_area_cd,
(case when (LENGTH(trim( phrm_staff_home_phone )) ==0) then phrm_staff_home_phone else trim(phrm_staff_home_phone)end) as phrm_staff_home_phone,
(case when (LENGTH(trim( phrm_phrmcst_access_ind )) ==0) then phrm_phrmcst_access_ind else trim(phrm_phrmcst_access_ind)end) as phrm_phrmcst_access_ind,
(case when (LENGTH(trim( p2000_access_level )) ==0) then p2000_access_level else trim(p2000_access_level)end) as p2000_access_level,
(case when (LENGTH(trim( employment_status_ind )) ==0) then employment_status_ind else trim(employment_status_ind)end) as employment_status_ind,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim(create_dttm )) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim(update_dttm )) ==0) then  update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000') end) as update_dttm,
(case when (LENGTH(trim( phrm_staff_spec_lic_nbr )) ==0) then phrm_staff_spec_lic_nbr else trim(phrm_staff_spec_lic_nbr)end) as phrm_staff_spec_lic_nbr,
(case when (LENGTH(trim( phrm_staff_employed_ind )) ==0) then phrm_staff_employed_ind else trim(phrm_staff_employed_ind)end) as phrm_staff_employed_ind,
(case when (LENGTH(trim( icplus_editable_ind )) ==0) then icplus_editable_ind else trim(icplus_editable_ind)end) as icplus_editable_ind,
(case when (LENGTH(trim( rph_consult_barcd_nbr )) ==0) then rph_consult_barcd_nbr else trim(rph_consult_barcd_nbr)end) as rph_consult_barcd_nbr,
(case when (LENGTH(trim(rph_barcd_exp_dttm )) ==0) then  rph_barcd_exp_dttm else concat(substring(rph_barcd_exp_dttm,1,10),' ',substring(rph_barcd_exp_dttm,12,8),'.000000') end) as rph_barcd_exp_dttm,
(case when (LENGTH(trim( phrm_staff_npi )) ==0) then phrm_staff_npi else trim(phrm_staff_npi)end) as phrm_staff_npi,
(case when (LENGTH(trim( phrm_staff_rfp_ind )) ==0) then phrm_staff_rfp_ind else trim(phrm_staff_rfp_ind)end) as phrm_staff_rfp_ind,
'000000' as tracking_id     
from gg_tbf0_store_phrm_staff where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql2 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
(case when (LENGTH(trim( edw_batch_id_after )) ==0) then edw_batch_id_after else trim(edw_batch_id_after)end) as edw_batch_id,
(case when (LENGTH(trim( store_nbr_after )) ==0) then store_nbr_after else trim(store_nbr_after)end) as store_nbr,
(case when (LENGTH(trim( phrm_staff_user_id_after )) ==0) then phrm_staff_user_id_after else trim(phrm_staff_user_id_after)end) as phrm_staff_user_id,
(case when (LENGTH(trim( staff_initials_after )) ==0) then staff_initials_after else trim(staff_initials_after)end) as staff_initials,
(case when (LENGTH(trim( phrm_staff_first_name_after )) ==0) then phrm_staff_first_name_after else trim(phrm_staff_first_name_after)end) as phrm_staff_first_name,
(case when (LENGTH(trim( phrm_staff_mid_init_after )) ==0) then phrm_staff_mid_init_after else trim(phrm_staff_mid_init_after)end) as phrm_staff_mid_init,
(case when (LENGTH(trim( phrm_staff_last_name_after )) ==0) then phrm_staff_last_name_after else trim(phrm_staff_last_name_after)end) as phrm_staff_last_name,
(case when (LENGTH(trim( phrm_staff_position_cd_after )) ==0) then phrm_staff_position_cd_after else trim(phrm_staff_position_cd_after)end) as phrm_staff_position_cd,
(case when (LENGTH(trim( phrm_rph_label_id_after )) ==0) then phrm_rph_label_id_after else trim(phrm_rph_label_id_after)end) as phrm_rph_label_id,
(case when (LENGTH(trim( phrm_staff_lic_nbr_after )) ==0) then phrm_staff_lic_nbr_after else trim(phrm_staff_lic_nbr_after)end) as phrm_staff_lic_nbr,
(case when (LENGTH(trim( phrm_staff_home_area_cd_after )) ==0) then phrm_staff_home_area_cd_after else trim(phrm_staff_home_area_cd_after)end) as phrm_staff_home_area_cd,
(case when (LENGTH(trim( phrm_staff_home_phone_after )) ==0) then phrm_staff_home_phone_after else trim(phrm_staff_home_phone_after)end) as phrm_staff_home_phone,
(case when (LENGTH(trim( phrm_phrmcst_access_ind_after )) ==0) then phrm_phrmcst_access_ind_after else trim(phrm_phrmcst_access_ind_after)end) as phrm_phrmcst_access_ind,
(case when (LENGTH(trim( p2000_access_level_after )) ==0) then p2000_access_level_after else trim(p2000_access_level_after)end) as p2000_access_level,
(case when (LENGTH(trim( employment_status_ind_after )) ==0) then employment_status_ind_after else trim(employment_status_ind_after)end) as employment_status_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after)) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim(update_dttm_after)) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000') end) as update_dttm,
(case when (LENGTH(trim( phrm_staff_spec_lic_nbr_after )) ==0) then phrm_staff_spec_lic_nbr_after else trim(phrm_staff_spec_lic_nbr_after)end) as phrm_staff_spec_lic_nbr,
(case when (LENGTH(trim( phrm_staff_employed_ind_after )) ==0) then phrm_staff_employed_ind_after else trim(phrm_staff_employed_ind_after)end) as phrm_staff_employed_ind,
(case when (LENGTH(trim( icplus_editable_ind_after )) ==0) then icplus_editable_ind_after else trim(icplus_editable_ind_after)end) as icplus_editable_ind,
(case when (LENGTH(trim( rph_consult_barcd_nbr_after )) ==0) then rph_consult_barcd_nbr_after else trim(rph_consult_barcd_nbr_after)end) as rph_consult_barcd_nbr,
(case when (LENGTH(trim(rph_barcd_exp_dttm_after)) ==0) then  rph_barcd_exp_dttm_after else concat(substring(rph_barcd_exp_dttm_after,1,10),' ',substring(rph_barcd_exp_dttm_after,12,8),'.000000') end) as rph_barcd_exp_dttm,
(case when (LENGTH(trim( phrm_staff_npi_after )) ==0) then phrm_staff_npi_after else trim(phrm_staff_npi_after)end) as phrm_staff_npi,
(case when (LENGTH(trim( phrm_staff_rfp_ind_after )) ==0) then phrm_staff_rfp_ind_after else trim(phrm_staff_rfp_ind_after)end) as phrm_staff_rfp_ind,
'000000' as tracking_id     
from gg_tbf0_store_phrm_staff where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
(case when (LENGTH(trim( edw_batch_id_after )) ==0) then edw_batch_id_after else trim(edw_batch_id_after)end) as edw_batch_id,
(case when (LENGTH(trim( store_nbr_after )) ==0) then store_nbr_after else trim(store_nbr_after)end) as store_nbr,
(case when (LENGTH(trim( phrm_staff_user_id_after )) ==0) then phrm_staff_user_id_after else trim(phrm_staff_user_id_after)end) as phrm_staff_user_id,
(case when (LENGTH(trim( staff_initials_after )) ==0) then staff_initials_after else trim(staff_initials_after)end) as staff_initials,
(case when (LENGTH(trim( phrm_staff_first_name_after )) ==0) then phrm_staff_first_name_after else trim(phrm_staff_first_name_after)end) as phrm_staff_first_name,
(case when (LENGTH(trim( phrm_staff_mid_init_after )) ==0) then phrm_staff_mid_init_after else trim(phrm_staff_mid_init_after)end) as phrm_staff_mid_init,
(case when (LENGTH(trim( phrm_staff_last_name_after )) ==0) then phrm_staff_last_name_after else trim(phrm_staff_last_name_after)end) as phrm_staff_last_name,
(case when (LENGTH(trim( phrm_staff_position_cd_after )) ==0) then phrm_staff_position_cd_after else trim(phrm_staff_position_cd_after)end) as phrm_staff_position_cd,
(case when (LENGTH(trim( phrm_rph_label_id_after )) ==0) then phrm_rph_label_id_after else trim(phrm_rph_label_id_after)end) as phrm_rph_label_id,
(case when (LENGTH(trim( phrm_staff_lic_nbr_after )) ==0) then phrm_staff_lic_nbr_after else trim(phrm_staff_lic_nbr_after)end) as phrm_staff_lic_nbr,
(case when (LENGTH(trim( phrm_staff_home_area_cd_after )) ==0) then phrm_staff_home_area_cd_after else trim(phrm_staff_home_area_cd_after)end) as phrm_staff_home_area_cd,
(case when (LENGTH(trim( phrm_staff_home_phone_after )) ==0) then phrm_staff_home_phone_after else trim(phrm_staff_home_phone_after)end) as phrm_staff_home_phone,
(case when (LENGTH(trim( phrm_phrmcst_access_ind_after )) ==0) then phrm_phrmcst_access_ind_after else trim(phrm_phrmcst_access_ind_after)end) as phrm_phrmcst_access_ind,
(case when (LENGTH(trim( p2000_access_level_after )) ==0) then p2000_access_level_after else trim(p2000_access_level_after)end) as p2000_access_level,
(case when (LENGTH(trim( employment_status_ind_after )) ==0) then employment_status_ind_after else trim(employment_status_ind_after)end) as employment_status_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after)) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim(update_dttm_after)) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000') end) as update_dttm,
(case when (LENGTH(trim( phrm_staff_spec_lic_nbr_after )) ==0) then phrm_staff_spec_lic_nbr_after else trim(phrm_staff_spec_lic_nbr_after)end) as phrm_staff_spec_lic_nbr,
(case when (LENGTH(trim( phrm_staff_employed_ind_after )) ==0) then phrm_staff_employed_ind_after else trim(phrm_staff_employed_ind_after)end) as phrm_staff_employed_ind,
(case when (LENGTH(trim( icplus_editable_ind_after )) ==0) then icplus_editable_ind_after else trim(icplus_editable_ind_after)end) as icplus_editable_ind,
(case when (LENGTH(trim( rph_consult_barcd_nbr_after )) ==0) then rph_consult_barcd_nbr_after else trim(rph_consult_barcd_nbr_after)end) as rph_consult_barcd_nbr,
(case when (LENGTH(trim(rph_barcd_exp_dttm_after)) ==0) then  rph_barcd_exp_dttm_after else concat(substring(rph_barcd_exp_dttm_after,1,10),' ',substring(rph_barcd_exp_dttm_after,12,8),'.000000') end) as rph_barcd_exp_dttm,
(case when (LENGTH(trim( phrm_staff_npi_after )) ==0) then phrm_staff_npi_after else trim(phrm_staff_npi_after)end) as phrm_staff_npi,
(case when (LENGTH(trim( phrm_staff_rfp_ind_after )) ==0) then phrm_staff_rfp_ind_after else trim(phrm_staff_rfp_ind_after)end) as phrm_staff_rfp_ind,
'000000' as tracking_id    
from gg_tbf0_store_phrm_staff where cdc_operation_type_cd_before ='INSERT'"""

# COMMAND ----------

df1 = spark.sql(sql1)

display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)

dfFinal.createOrReplaceTempView("gg_tbf0_store_phrm_staff_final")

# drop columns
df_final = dfFinal.drop("tracking_id")
# convert date and number columns
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
           .withColumn("create_dttm",to_timestamp(df_final["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(df_final["update_dttm"]))\
           .withColumn("rph_barcd_exp_dttm",to_timestamp(df_final["rph_barcd_exp_dttm"]))\
           .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr")))\
           .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr")))\
           .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id")))\
           .withColumn("store_nbr",when(col("store_nbr") == "",None).otherwise(col("store_nbr")))\
           .withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id")))\
           .withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id")))\
           .withColumn("phrm_staff_npi",when(col("phrm_staff_npi") == "",None).otherwise(col("phrm_staff_npi")))\
           .withColumn("p2000_access_level",when(col("p2000_access_level") == "",None).otherwise(col("p2000_access_level")))


#final df to load
display(df_final)
print(f"Final count after union {df_final.count()}")





# COMMAND ----------

#Bad records 
dfBad = spark.sql("select * from gg_tbf0_store_phrm_staff where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")
display(dfBad)
print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

# WRITING DATA IN OUTPUT AND RJECT FOLDER
df_final.write.parquet(OUT_FILEPATH)

dfBad.write.parquet(REJ_BAD_FILEPATH)



# COMMAND ----------

# MAGIC %run 
# MAGIC ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# delete records from snfk table
delete_gg_snowflake = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})



# COMMAND ----------

#Writing to the Snowflakes Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
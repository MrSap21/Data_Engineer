# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# #Create Widgets for Parameters
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220128144200")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_patient_merge")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","/pharmacy_healthcare/patient/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","/pharmacy_healthcare/patient/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT.ETL_TBF0_PATIENT_MERGE_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_UNPROCESSED_FILES","{'gg_patient_merge': [{'assetid': 4432, 'assetname': 'PRDRX2STAGE_GG_TBF0_PATIENT_MERGE_2022-01-30_00-29-23_01698_data.dsv', 'assetcurrentlocation': 'pharmacy_healthcare/patient_services/icplus/2022/01/31/'}]}")
# dbutils.widgets.text("PAR_DB_FEED_NAME","gg_patient_merge")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'




# COMMAND ----------

# Extracting File Name and Path
import json
from pyspark.sql.types import *
import os
from pyspark.sql.functions import *



readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
readList=readList.split(',')

print(readList)

# COMMAND ----------

#Columns List for Schema

fieldList = [
'row_length',  
'cdc_txn_commit_dttm' ,
'cdc_txn_commit_dttm_after' ,
'cdc_seq_nbr' ,
'cdc_seq_nbr_after' ,
'cdc_rba_nbr' ,
'cdc_rba_nbr_after' ,
'cdc_operation_type_cd' ,
'cdc_operation_type_cd_after' ,
'cdc_before_after_cd' ,
'cdc_before_after_cd_after' ,
'cdc_txn_position_cd' ,
'cdc_txn_position_cd_after' ,
'edw_batch_id' ,
'edw_batch_id_after' ,
'pat_id' ,
'pat_id_after' ,
'pat_area_cd' ,
'pat_area_cd_after' ,
'pat_phone' ,
'pat_phone_after' ,
'pat_call_time_codes' ,
'pat_call_time_codes_after' ,
'pat_text_msg_ind' ,
'pat_text_msg_ind_after' ,
'pat_phone_type_cd' ,
'pat_phone_type_cd_after' ,
'pat_phone_ordr_of_entry' ,
'pat_phone_ordr_of_entry_after']
#'partition_column']

col_len = len(fieldList)
print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if '"INSERT"' in key_list[6]:
    if val_len != 27 :
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 28:
      return True
  else:
    if val_len != 28:
      return True

# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
in_text = in_text.rdd

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len = 28

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
#rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 28
#print(f"Bad records count {rd_bad.count()}") # != 28


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

#Creating RD and assigning Schema to it

df = spark.createDataFrame(rd_good, schema)

#display(df)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name,udf_handlEscpeQuotes(col(col_name))),
    df.columns,
    df
))
#display(df)

# COMMAND ----------

df=df.withColumn("table_name",lit("gg_tbf0_patient_phone")).withColumn("edw_batch_id",lit(BATCH_ID)).withColumn("edw_batch_id_after",lit(BATCH_ID))
#display(df)
df.createOrReplaceTempView("gg_tbf0_patient_phone")



# COMMAND ----------

#table_name='gg_tbf0_patient_phone'
batch_id=str(BATCH_ID)

pRejFilePatMod="PatIdCheckRejected_"+batch_id+"_patient_phone"
pRejFileNoiseRmv="UpdateInsertCheckRejected_"+batch_id+"_patient_phone"
pRejFileUpdNull="UpdateNullReject_"+batch_id+"_patient_phone"
pRejFileCDCcheck="cdc_operation_type_cd_nullCheck_"+batch_id+"_patient_phone"

pRxCutoffTableCheck="table_name == 'gg_tbf0_rx_close_log' or table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' or  table_name == 'gg_tbf0_rx_cmpnd_nonsys' or   table_name == 'gg_tbf0_erx_msg_mapping' or table_name == 'gg_tbf0_rx_open_log' or  table_name == 'gg_tbf0_ret_to_stk_call_list'"

pRxCutoffTableCheckEqual="table_name == 'gg_tbf0_rx' or table_name == 'gg_tbf0_rx_consult_hist'"

pRxTransCutoffTableCheck="table_name  == 'gg_tbf0_fill' or  table_name == 'gg_tbf0_rx_transaction' or   table_name  == 'gg_tbf0_dur_history' or   table_name  ==  'gg_tbf0_rx_cntrl_substance' or table_name  == 'gg_tbf0_sdl_history' or  table_name  == 'gg_tbf0_exception'"

pRxTransCutoffTableCheckEqual= "table_name  == 'gg_tbf0_rx_consult_actv' or table_name  == 'gg_tbf0_rx_consult_adhoc'"

pNopartitionTableCheck="table_name  != 'gg_tbf0_fill' and table_name != 'gg_tbf0_rx_transaction' and table_name  != 'gg_tbf0_rx_consult_actv' and  table_name  != 'gg_tbf0_dur_history' and table_name  != 'gg_tbf0_rx_consult_adhoc'   and  table_name  !=  'gg_tbf0_rx_cntrl_substance' and table_name  != 'gg_tbf0_sdl_history' and  table_name  != 'gg_tbf0_exception' and  table_name != 'gg_tbf0_rx' and table_name != 'gg_tbf0_rx_close_log' and table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' and  table_name != 'gg_tbf0_rx_cmpnd_nonsys' and table_name != 'gg_tbf0_rx_consult_hist' and  table_name != 'gg_tbf0_erx_msg_mapping' and table_name != 'gg_tbf0_rx_open_log' and  table_name != 'gg_tbf0_ret_to_stk_call_list'"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' and table_name != 'gg_tbf0_rx_consult_hist' and table_name != 'gg_tbf0_sdl_history' and table_name != 'gg_tbf0_pat_thrd_pty' and table_name != 'gg_tbf0_patient' and table_name != 'gg_tbf0_pat_algy_hlth_cd' and table_name != 'gg_tbf0_pat_rca_service')"

# COMMAND ----------

pSrcGgTbf0Schema =["cdc_txn_commit_dttm" , "cdc_txn_commit_dttm_after" , "cdc_seq_nbr" , "cdc_seq_nbr_after" , "cdc_rba_nbr" , "cdc_rba_nbr_after" , "cdc_operation_type_cd" , "cdc_operation_type_cd_after" , "cdc_before_after_cd" , "cdc_before_after_cd_after" , "cdc_txn_position_cd" , "cdc_txn_position_cd_after" , "edw_batch_id" , "edw_batch_id_after" , "pat_id" , "pat_id_after" , "pat_area_cd" , "pat_area_cd_after" , "pat_phone" , "pat_phone_after" , "pat_call_time_codes" , "pat_call_time_codes_after" , "pat_text_msg_ind" , "pat_text_msg_ind_after" , "pat_phone_type_cd" , "pat_phone_type_cd_after" , "pat_phone_ordr_of_entry" , "pat_phone_ordr_of_entry_after" ,"src_partition_nbr", "src_partition_nbr_after", "tracking_id" , "partition_column", "table_name"]


pUpdateReform="pat_id IS NULL"

pSrcCleanseXfr="'${batchId}' AS edw_batch_id , '${batchId}' AS edw_batch_id_after , pat_id AS pat_id , pat_id_after AS pat_id_after , (SIZE(TRIM(pat_area_cd))==0?pat_area_cd:TRIM(pat_area_cd)) AS pat_area_cd , (SIZE(TRIM(pat_area_cd_after))==0?pat_area_cd_after:TRIM(pat_area_cd_after)) AS pat_area_cd_after , (SIZE(TRIM(pat_phone))==0?pat_phone:TRIM(pat_phone)) AS pat_phone , (SIZE(TRIM(pat_phone_after))==0?pat_phone_after:TRIM(pat_phone_after)) AS pat_phone_after , (SIZE(TRIM(pat_call_time_codes))==0?pat_call_time_codes:TRIM(pat_call_time_codes)) AS pat_call_time_codes , (SIZE(TRIM(pat_call_time_codes_after))==0?pat_call_time_codes_after:TRIM(pat_call_time_codes_after)) AS pat_call_time_codes_after , (SIZE(TRIM(pat_text_msg_ind))==0?pat_text_msg_ind:TRIM(pat_text_msg_ind)) AS pat_text_msg_ind , (SIZE(TRIM(pat_text_msg_ind_after))==0?pat_text_msg_ind_after:TRIM(pat_text_msg_ind_after)) AS pat_text_msg_ind_after , (SIZE(TRIM(pat_phone_type_cd))==0?pat_phone_type_cd:TRIM(pat_phone_type_cd)) AS pat_phone_type_cd , (SIZE(TRIM(pat_phone_type_cd_after))==0?pat_phone_type_cd_after:TRIM(pat_phone_type_cd_after)) AS pat_phone_type_cd_after , (SIZE(TRIM(pat_phone_ordr_of_entry))==0?pat_phone_ordr_of_entry:TRIM(pat_phone_ordr_of_entry)) AS pat_phone_ordr_of_entry , (SIZE(TRIM(pat_phone_ordr_of_entry_after))==0?pat_phone_ordr_of_entry_after:TRIM(pat_phone_ordr_of_entry_after)) AS pat_phone_ordr_of_entry_after , src_partition_nbr AS src_partition_nbr , src_partition_nbr_after AS src_partition_nbr_after , tracking_id AS tracking_id , partition_column AS partition_column"

pTgtUpdBfrXfr="'${batchId}' as edw_batch_id,pat_id AS pat_id , pat_area_cd AS pat_area_cd , pat_phone AS pat_phone , pat_call_time_codes AS pat_call_time_codes , pat_text_msg_ind AS pat_text_msg_ind , pat_phone_type_cd AS pat_phone_type_cd , pat_phone_ordr_of_entry AS pat_phone_ordr_of_entry , src_partition_nbr AS src_partition_nbr,tracking_id AS tracking_id , partition_column AS partition_column,'${pSrcGgTbf0}' AS table_name" 

pTgtUpdAftXfr=" '${batchId}' as edw_batch_id ,pat_id_after AS pat_id , pat_area_cd_after AS pat_area_cd , pat_phone_after AS pat_phone , pat_call_time_codes_after AS pat_call_time_codes , pat_text_msg_ind_after AS pat_text_msg_ind , pat_phone_type_cd_after AS pat_phone_type_cd , pat_phone_ordr_of_entry_after AS pat_phone_ordr_of_entry ,src_partition_nbr_after AS src_partition_nbr, tracking_id AS tracking_id , partition_column AS partition_column,'${pSrcGgTbf0}' AS table_name" 

pPatIdModCheck="(table_name == 'gg_tbf0_rx' or table_name == 'gg_tbf0_rx_consult_hist' or table_name == 'gg_tbf0_sdl_history' or table_name == 'gg_tbf0_pat_thrd_pty' or table_name == 'gg_tbf0_patient' or table_name == 'gg_tbf0_pat_algy_hlth_cd' or table_name == 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="cdc_txn_commit_dttm AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, pat_id, pat_area_cd, pat_phone, pat_call_time_codes, (CASE WHEN (pat_text_msg_ind !='Y') THEN 'N' ELSE pat_text_msg_ind END) AS pat_text_msg_ind, pat_phone_type_cd, pat_phone_ordr_of_entry" 

pEtlTableSchema="(chararray)$0 AS cdc_txn_commit_dttm :chararray, (chararray)$1 AS cdc_seq_nbr :chararray, (chararray)$2 AS cdc_rba_nbr :chararray, (chararray)$3 AS cdc_operation_type_cd :chararray, (chararray)$4 AS cdc_before_after_cd :chararray, (chararray)$5 AS cdc_txn_position_cd :chararray, (chararray)$6 AS edw_batch_id :chararray, (chararray)$7 AS src_partition_nbr :chararray, (chararray)$8 AS pat_id :chararray, (chararray)$9 AS pat_area_cd :chararray, (chararray)$10 AS pat_phone :chararray, (chararray)$11 AS pat_call_time_codes :chararray, (chararray)$12 AS pat_text_msg_ind :chararray, (chararray)$13 AS pat_phone_type_cd :chararray, (chararray)$14 AS pat_phone_ordr_of_entry :chararray, (chararray)$15 AS tracking_id :chararray, (chararray)$16 AS partition_column :chararray" 


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# # Read ETL_HIVE_CUTOFF table:
# from pyspark.sql import *
# ETLDB=dbutils.widgets.get("PAR_NB_ETL")
# ETLCUTOFFTBL=dbutils.widgets.get("PAR_NB_CUTOFF_TBL")
# sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETLCUTOFFTBL)

# print(sel_ETL_Hive_Cutoff_tbl)
# df_cutoff_records_output=spark.read \
#    .format("snowflake") \
#    .options(**options) \
#    .option("sfWarehouse", SNFL_WH) \
#    .option("sfDatabase",ETLDB) \
#    .option("query",sel_ETL_Hive_Cutoff_tbl) \
#    .load()

# #display(df_cutoff_records_output)

# # Filtering the cutoff timestamp for the current batch
# cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
# #display(cutoff_records_filter)

# cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

# #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
# cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
# RX_CUT_OFF_MAX_DTTM as rx_max,
# CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
# CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
# from cutoff_records_filter""" 

# cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
# #display(cutoff_range_rx)

# #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
# cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
# RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
# CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
# CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
# from cutoff_records_filter"""

# cutoff_range_trans = spark.sql(cutoff_range_trans_sql)
# #display(cutoff_range_trans)

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from gg_tbf0_patient_phone where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from gg_tbf0_patient_phone where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual
nr_input_filter_nopartition_sql = "select * from gg_tbf0_patient_phone where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#Fetching rx_max and rx_trans_max as values
# rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
# rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max



# #Applying rx_cutoff range on rx related tables
nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)

# #Applying trans_cutoff range on trans related tables
nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)

nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)


#Remove duplicates
dedup_group = nr_input_file_final.distinct()
dedup_group.createOrReplaceTempView("dedup_group")

#display(dedup_group)


# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (length(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else 
concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (length(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (length(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (length(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (length(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (length(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (length(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (length(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (length(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (length(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (length(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (length(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
edw_batch_id AS edw_batch_id , 
edw_batch_id AS edw_batch_id_after , 
pat_id AS pat_id , 
pat_id_after AS pat_id_after , 
(case when (length(trim(pat_area_cd))==0) then pat_area_cd else trim(pat_area_cd)  end) AS pat_area_cd , 
(case when (length(trim(pat_area_cd_after))==0) then pat_area_cd_after else trim(pat_area_cd_after)  end) AS pat_area_cd_after , 
(case when (length(trim(pat_phone))==0) then pat_phone else trim(pat_phone)  end) AS pat_phone ,
(case when (length(trim(pat_phone_after))==0) then pat_phone_after else trim(pat_phone_after)  end) AS pat_phone_after , 
(case when (length(trim(pat_call_time_codes))==0) then pat_call_time_codes else trim(pat_call_time_codes)  end) AS pat_call_time_codes ,
(case when (length(trim(pat_call_time_codes_after))==0) then pat_call_time_codes_after else trim(pat_call_time_codes_after)  end) AS pat_call_time_codes_after ,
(case when (length(trim(pat_text_msg_ind))==0) then pat_text_msg_ind else trim(pat_text_msg_ind)  end) AS pat_text_msg_ind ,
(case when (length(trim(pat_text_msg_ind_after))==0) then pat_text_msg_ind_after else trim(pat_text_msg_ind_after)  end) AS pat_text_msg_ind_after ,
(case when (length(trim(pat_phone_type_cd))==0) then pat_phone_type_cd else trim(pat_phone_type_cd)  end) AS pat_phone_type_cd , 
(case when (length(trim(pat_phone_type_cd_after))==0) then pat_phone_type_cd_after else trim(pat_phone_type_cd_after)  end) AS pat_phone_type_cd_after , 
(case when (length(trim(pat_phone_ordr_of_entry))==0) then pat_phone_ordr_of_entry else trim(pat_phone_ordr_of_entry)  end) AS pat_phone_ordr_of_entry , 
(case when (length(trim(pat_phone_ordr_of_entry_after))==0) then pat_phone_ordr_of_entry_after else trim(pat_phone_ordr_of_entry_after)  end) AS pat_phone_ordr_of_entry_after 
from dedup_group"""

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )

if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV)
  
nr_update_check.createOrReplaceTempView("nr_update_check")
gg_tbf0_rejected_sql = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(gg_tbf0_rejected_sql)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL)
  
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
nr_insert_check.createOrReplaceTempView("nr_insert_check")
#display(gg_tbf0_update)


# COMMAND ----------

pTgtUpdAftXfr = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id ,
(case when (LENGTH(trim(pat_id_after))==0) then  pat_id_after else trim(pat_id_after) end)AS pat_id , 
(case when (LENGTH(trim(pat_area_cd_after))==0) then pat_area_cd_after else trim(pat_area_cd_after) end) AS pat_area_cd , 
(case when (LENGTH(trim(pat_phone_after))==0) then pat_phone_after else trim(pat_phone_after) end) AS pat_phone , 
(case when (LENGTH(trim(pat_call_time_codes_after))==0) then pat_call_time_codes_after else trim(pat_call_time_codes_after) end) AS pat_call_time_codes , 
(case when (LENGTH(trim(pat_text_msg_ind_after))==0) then pat_text_msg_ind_after else trim(pat_text_msg_ind_after) end) AS pat_text_msg_ind , 
(case when (LENGTH(trim(pat_phone_type_cd_after))==0) then pat_phone_type_cd_after else trim(pat_phone_type_cd_after) end) AS pat_phone_type_cd , 
(case when (LENGTH(trim(pat_phone_ordr_of_entry_after))==0) then pat_phone_ordr_of_entry_after else trim(pat_phone_ordr_of_entry_after) end) AS pat_phone_ordr_of_entry ,
'gg_tbf0_patient_phone' AS table_name
from gg_tbf0_update"""

pTgtUpdBfrXfr = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm)) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id,
(case when (LENGTH(trim(pat_id )) ==0) then pat_id else trim(pat_id) end)  AS pat_id , 
(case when (LENGTH(trim(pat_area_cd )) ==0) then pat_area_cd else trim(pat_area_cd) end)  AS pat_area_cd , 
(case when (LENGTH(trim(pat_phone )) ==0) then pat_phone else trim(pat_phone) end)  AS pat_phone , 
(case when (LENGTH(trim(pat_call_time_codes )) ==0) then pat_call_time_codes else trim(pat_call_time_codes) end)  AS pat_call_time_codes , 
(case when (LENGTH(trim(pat_text_msg_ind )) ==0) then pat_text_msg_ind else trim( pat_text_msg_ind) end) AS pat_text_msg_ind , 
(case when (LENGTH(trim(pat_phone_type_cd )) ==0) then pat_phone_type_cd else trim(pat_phone_type_cd) end)  AS pat_phone_type_cd , 
(case when (LENGTH(trim(pat_phone_ordr_of_entry )) ==0) then pat_phone_ordr_of_entry else trim(pat_phone_ordr_of_entry) end)  AS pat_phone_ordr_of_entry , 
'gg_tbf0_patient_phone' AS table_name
from gg_tbf0_update"""

pTgtInsBfrAftXfr = """select
(case when (LENGTH(trim(cdc_txn_commit_dttm)) ==0) then cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_seq_nbr)) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim(cdc_rba_nbr)) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim(cdc_operation_type_cd)) ==0) then cdc_operation_type_cd else trim( cdc_operation_type_cd ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id ,
(case when (LENGTH(trim(pat_id_after))==0) then  pat_id_after else trim(pat_id_after) end)AS pat_id , 
(case when (LENGTH(trim(pat_area_cd_after))==0) then pat_area_cd_after else trim(pat_area_cd_after) end) AS pat_area_cd , 
(case when (LENGTH(trim(pat_phone_after))==0) then pat_phone_after else trim(pat_phone_after) end) AS pat_phone , 
(case when (LENGTH(trim(pat_call_time_codes_after))==0) then pat_call_time_codes_after else trim(pat_call_time_codes_after) end) AS pat_call_time_codes , 
(case when (LENGTH(trim(pat_text_msg_ind_after))==0) then pat_text_msg_ind_after else trim(pat_text_msg_ind_after) end) AS pat_text_msg_ind , 
(case when (LENGTH(trim(pat_phone_type_cd_after))==0) then pat_phone_type_cd_after else trim(pat_phone_type_cd_after) end) AS pat_phone_type_cd , 
(case when (LENGTH(trim(pat_phone_ordr_of_entry_after))==0) then pat_phone_ordr_of_entry_after else trim(pat_phone_ordr_of_entry_after) end) AS pat_phone_ordr_of_entry ,
'gg_tbf0_patient_phone' AS table_name
from nr_insert_check"""


gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
#display(etl_tbf0_file)

# COMMAND ----------

etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK)
  
  
  
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
etl_tbf0_reformat_cdc_check_notnull.write.mode('overwrite').parquet(OUT_FILEPATH)
#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull_format=etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())\
 .withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
 .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr"))) \
 .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr"))) \
 .withColumn("cdc_operation_type_cd",when(col("cdc_operation_type_cd") == "",None).otherwise(col("cdc_operation_type_cd"))) \
 .withColumn("cdc_before_after_cd",when(col("cdc_before_after_cd") == "",None).otherwise(col("cdc_before_after_cd"))) \
 .withColumn("cdc_txn_position_cd",when(col("cdc_txn_position_cd") == "",None).otherwise(col("cdc_txn_position_cd"))) \
 .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id"))) \
 .withColumn("SRC_PARTITION_NBR",lit(1)) \
 .withColumn("pat_id",when(col("pat_id") == "",None).otherwise(col("pat_id"))) \
 .withColumn("pat_area_cd",when(col("pat_area_cd") == "",None).otherwise(col("pat_area_cd"))) \
 .withColumn("pat_phone",when(col("pat_phone") == "",None).otherwise(col("pat_phone"))) \
 .withColumn("pat_call_time_codes",when(col("pat_call_time_codes") == "",None).otherwise(col("pat_call_time_codes"))) \
 .withColumn("pat_text_msg_ind",when(col("pat_text_msg_ind") == "",None).otherwise(col("pat_text_msg_ind"))) \
 .withColumn("pat_phone_type_cd",when(col("pat_phone_type_cd") == "",None).otherwise(col("pat_phone_type_cd"))) \
 .withColumn("pat_phone_ordr_of_entry",when(col("pat_phone_ordr_of_entry") == "",None).otherwise(col("pat_phone_ordr_of_entry")))
 
etl_tbf0_reformat_cdc_check_notnull_format=etl_tbf0_reformat_cdc_check_notnull_format.withColumn("pat_id",trim(col("pat_id")))
etl_tbf0_reformat_cdc_check_notnull_format=etl_tbf0_reformat_cdc_check_notnull_format.withColumn("pat_id",col("pat_id").cast(LongType())) \
  .withColumn("cdc_seq_nbr",col("cdc_seq_nbr").cast(LongType())) \
  .withColumn("cdc_rba_nbr",col("cdc_rba_nbr").cast(LongType())) \
  .withColumn("edw_batch_id",col("edw_batch_id").cast(LongType()))

etl_tbf0_reformat_cdc_check_notnull_format=etl_tbf0_reformat_cdc_check_notnull_format.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","SRC_PARTITION_NBR","pat_id","pat_area_cd","pat_phone","pat_call_time_codes","pat_text_msg_ind","pat_phone_type_cd","pat_phone_ordr_of_entry")

#display(etl_tbf0_reformat_cdc_check_notnull_format)


etl_tbf0_reformat_cdc_check_notnull_format.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# Databricks notebook source
# dbutils.widgets.text("SNOWFLAKE_WAREHOUSE","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("SNOWFLAKE_DATABASE","DEV_PHARMACY_HEALTHCARE")
# dbutils.widgets.text("SNOWFLAKE_DATABASE_STAGING","DEV_STAGING")
# dbutils.widgets.text("PAR_PL_SCHEMA_MASTER_PATIENT_MERGE","PATIENT")
# dbutils.widgets.text("PAR_PL_TABLE_MASTER_PATIENT_MERGE","MASTER_PATIENT_MERGE_STG")
# dbutils.widgets.text("SNOWFLAKE_DATABASE_CONSUMPTION","DEV_CONSUMPTION")
# dbutils.widgets.text("PAR_PL_SCHEMA_PATIENT_MERGE","PRDEDWVW")
# dbutils.widgets.text("PAR_PL_TABLE_PATIENT_MERGE","PATIENT_MERGE")
# dbutils.widgets.text("PAR_PL_BATCH_ID","20120203")
# dbutils.widgets.text("transaction","false")

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

SNOWFLAKE_WAREHOUSE=dbutils.widgets.get("SNOWFLAKE_WAREHOUSE")
SNOWFLAKE_DATABASE=dbutils.widgets.get("SNOWFLAKE_DATABASE")
DB_STAGING=dbutils.widgets.get("SNOWFLAKE_DATABASE_STAGING",)
SCHEMA_MASTER_PATIENT_MERGE=dbutils.widgets.get("PAR_PL_SCHEMA_MASTER_PATIENT_MERGE")
MASTER_PATIENT_MERGE=dbutils.widgets.get("PAR_PL_TABLE_MASTER_PATIENT_MERGE")
DATABASE_CONSUMPTION=dbutils.widgets.get("SNOWFLAKE_DATABASE_CONSUMPTION")
SCHEMA_PATIENT_MERGE=dbutils.widgets.get("PAR_PL_SCHEMA_PATIENT_MERGE")
PATIENT_MERGE=dbutils.widgets.get("PAR_PL_TABLE_PATIENT_MERGE")
BATCH_ID=dbutils.widgets.get("PAR_PL_BATCH_ID")

# COMMAND ----------

query1 = """INSERT INTO """+DB_STAGING+"""."""+SCHEMA_MASTER_PATIENT_MERGE+"""."""+MASTER_PATIENT_MERGE+"""  SELECT merged_fm_pat_id, pat_id,src_create_dttm, edw_batch_id FROM """+DATABASE_CONSUMPTION+"""."""+SCHEMA_PATIENT_MERGE+"""."""+PATIENT_MERGE+ """ WHERE history_seq_cd='C' AND edw_batch_id="""+BATCH_ID

# COMMAND ----------

print(query1)

# COMMAND ----------

query2="""UPDATE """+DB_STAGING+"""."""+SCHEMA_MASTER_PATIENT_MERGE+"""."""+MASTER_PATIENT_MERGE+""" TGT SET PAT_ID=PM.PAT_ID, EDW_BATCH_ID="""+BATCH_ID+""" FROM ( select merged_fm_pat_id, PAT_ID,src_create_dttm FROM """+DB_STAGING+"""."""+SCHEMA_MASTER_PATIENT_MERGE+"""."""+MASTER_PATIENT_MERGE+""" WHERE pat_id<>merged_fm_pat_id ) pm WHERE TGT.PAT_ID = PM.merged_fm_pat_id AND PM.src_create_dttm>TGT.src_create_dttm"""

# COMMAND ----------

print(query2)

# COMMAND ----------

# import the snowflake.connector package
import snowflake.connector
import os
import re
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import serialization

password=dbutils.secrets.get(scope = "dapadbscope", key = "dapsfprivatekey") #"dapdevdbrauthn")

val1 = bytearray(re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",password).replace("\\n","\n").encode())

p_key = serialization.load_pem_private_key(
    val1,
    password = None,#'devsnowcli'.encode(),   
    backend = default_backend()
    )

pkb = p_key.private_bytes(
  encoding = serialization.Encoding.DER,
  format = serialization.PrivateFormat.PKCS8,
  encryption_algorithm = serialization.NoEncryption()
  )

v_autocommit = False 

if dbutils.widgets.get("transaction").lower() == "false":
  print("Auto Commit True")
  v_autocommit = True

with snowflake.connector.connect(
  user=	dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
  account=dbutils.secrets.get(scope='dapadbscope', key='dapsfshortaccountname'), #"wba_rpu_nprod_datainsight_01.east-us-2.privatelink",
  private_key=pkb,
  database=SNOWFLAKE_DATABASE, #"DEV_ETL",
  warehouse=SNOWFLAKE_WAREHOUSE,#"WBADEVDBENGINEER_WH",
  autocommit=v_autocommit
  ) as con:
  con.execute_string(query1.replace ("\\'", "'"))
  result=(1,1)
  while result!=(0,0):
    cur=con.cursor()
    cur.execute(query2)
    queryid=cur.sfqid
    results=cur.get_results_from_sfqid(queryid)
    res=cur.fetchall()
    result=res[0]
    print(res[0])
    

# COMMAND ----------


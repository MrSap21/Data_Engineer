# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","19981117163100")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_PAT_ALGY_HLTH_CD")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","pat_algy_hlth_cd")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","/pharmacy_healthcare/patient/output")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","/pharmacy_healthcare/patient/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT.ETL_TBF0_PAT_ALGY_HLTH_CD_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")

# COMMAND ----------

# # ReadAPI Call to fetch asset file names with current location:  
# FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
# READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPI", 200, 
#                   {"PAR_READAPI_KEY":"feedNames",
#                    "PAR_READAPI_URL":READAPI_URL,
#                    "PAR_READAPI_VALUE":FEED_NAME,
#                    "PAR_RETURN_FILE_TYPE":"A"});

# print(Input_File_List)

# COMMAND ----------

# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")
# dbutils.widgets.text("PAR_JOB_NAME","pat_xform_patient_allergy_health_conditn")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")

# COMMAND ----------

FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PAR_SQL_SERVER_DB=dbutils.widgets.get("PAR_SQL_SERVER_DB")
PAR_SQL_SERVER=dbutils.widgets.get("PAR_SQL_SERVER")
PAR_SQL_SERVER_AD_CLIENT_ID=dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET=dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_JOB_NAME=dbutils.widgets.get("PAR_JOB_NAME")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 200, 
                  {"PAR_PIPELINE_NAME":PAR_JOB_NAME,
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_FEED_NAMES":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A",
                   "PAR_SQL_SERVER":PAR_SQL_SERVER,
                   "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                   "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                   "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                   "PAR_EDW_BATCH_ID":BATCH_ID
                  });

# COMMAND ----------

print(Input_File_List)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
print (REJ_FILE_NOISE_RMV)
print(REJ_FILE_PAT_MOD)
print(REJ_FILE_UPD_NULL)
print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

#inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")

rddjson = sc.parallelize([Input_File_List])
print(rddjson.collect())

#dfFileList1 = sqlContext.read.json(rddjson)
dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(FEED_NAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
display(dfFileList)

#dfRaw1 = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm' ,
'cdc_txn_commit_dttm_after' ,
'cdc_seq_nbr' ,
'cdc_seq_nbr_after' ,
'cdc_rba_nbr' ,
'cdc_rba_nbr_after' ,
'cdc_operation_type_cd' ,
'cdc_operation_type_cd_after' ,
'cdc_before_after_cd' ,
'cdc_before_after_cd_after' ,
'cdc_txn_position_cd' ,
'cdc_txn_position_cd_after' ,
'edw_batch_id' ,
'edw_batch_id_after' ,
'pat_id' ,
'pat_id_after' ,
'pat_code_type' ,
'pat_code_type_after' ,
'pat_allergy_health_cd' ,
'pat_allergy_health_cd_after' ,
'active_ind' ,
'active_ind_after' ,
'create_user_id' ,
'create_user_id_after' ,
'create_dttm' ,
'create_dttm_after' ,
'deactivate_user_id' ,
'deactivate_user_id_after' ,
'deactivate_dttm' ,
'deactivate_dttm_after' ,
'screen_entire_prof_ind' ,
'screen_entire_prof_ind_after']

print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 31:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 32:
      return True
  else:
    if val_len != 32:
      return True

# COMMAND ----------

readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[9]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[9]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[9]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[9]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

# Read input files
# in_text = spark.read.text(readList)
# in_text = in_text.rdd

# Read files based on partitions
in1_text = spark.read.text(readList_src_1)
in2_text = spark.read.text(readList_src_2)
in3_text = spark.read.text(readList_src_3)
in4_text = spark.read.text(readList_src_4)
in1_text = in1_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in2_text = in2_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in3_text = in3_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in4_text = in4_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

# rdb = in_text.filter(lambda x: checkbad(x[0]))

# if rdb.count()>0:
#   df_junk = spark.createDataFrame(rdb)
#   df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)
  
rdb1 = in1_text.filter(lambda x: checkbad(x[0]))
rdb2 = in2_text.filter(lambda x: checkbad(x[0]))
rdb3 = in3_text.filter(lambda x: checkbad(x[0]))
rdb4 = in4_text.filter(lambda x: checkbad(x[0]))

rdb_count = rdb1.count()+ rdb2.count()+ rdb3.count()+ rdb4.count()
rdb= rdb1+rdb2+rdb3+rdb4
if rdb_count>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)  

# COMMAND ----------

#split and add schema
col_len = 32

# rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

# print(f"Total count {rd1.count()}")

# rd_good = rd1.filter(lambda x: x[0] == col_len)
# rd_bad = rd1.filter(lambda x: x[0] != col_len)

# print(f"Good records count {rd_good.count()}") # = 32
# print(f"Bad records count {rd_bad.count()}") # != 32

rd1 = in1_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd2 = in2_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd3 = in3_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd4 = in4_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd1_good = rd1.filter(lambda x: x[0] == col_len)
rd2_good = rd2.filter(lambda x: x[0] == col_len)
rd3_good = rd3.filter(lambda x: x[0] == col_len)
rd4_good = rd4.filter(lambda x: x[0] == col_len)

rd_bad_all = rd1+rd2+rd3+rd4
rd_bad = rd_bad_all.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

# df = spark.createDataFrame(rd_good, schema)

df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

df = df_g1.union(df_g2).union(df_g3).union(df_g4)

# COMMAND ----------

#function to remove "" & \\ <Only when the file is encrypted?
#def handlEscpeQuotes(val):
  
#  if not val:
#    return ""
  
  #remove rightmost "
#  outval = val[0:-1]
  #remove leftmost "
#  outval = outval.lstrip("\"")
  #replace double \\ with \
#  outval = outval.replace("\\\\","\\")
  #replace double \" with "
#  outval = outval.replace("\\\"","\"")
#  return outval

#udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
#     df.columns,
#     df
# ))

# COMMAND ----------

#display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_pat_algy_hlth_cd")
df.display()

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_pat_algy_hlth_cd")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 
          
display(df_gg)

df_gg.createOrReplaceTempView("raw_gg_tbf0_pat_algy_hlth_cd")
#df_gg.printSchema()

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')" 

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND pat_id  == pat_id_after   AND pat_id IS NOT NULL AND pat_id_after IS NOT NULL AND  pat_code_type  == pat_code_type_after   AND pat_code_type IS NOT NULL AND pat_code_type_after IS NOT NULL AND  pat_allergy_health_cd  == pat_allergy_health_cd_after   AND pat_allergy_health_cd IS NOT NULL AND pat_allergy_health_cd_after IS NOT NULL AND  create_dttm ==  create_dttm_after   AND create_dttm IS NOT NULL AND create_dttm_after IS NOT NULL AND  cdc_seq_nbr ==  cdc_seq_nbr_after   AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL AND  cdc_rba_nbr ==  cdc_rba_nbr_after   AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL AND  cdc_txn_commit_dttm  ==  cdc_txn_commit_dttm_after   AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL AND  ((active_ind  == active_ind_after AND active_ind IS NOT NULL AND active_ind_after IS NOT NULL ) OR ( active_ind  IS NULL  AND  active_ind_after IS NULL ) )   AND  ((deactivate_user_id  == deactivate_user_id_after AND deactivate_user_id IS NOT NULL AND deactivate_user_id_after IS NOT NULL ) OR ( deactivate_user_id  IS NULL  AND  deactivate_user_id_after  IS NULL ) )   AND  ((deactivate_dttm  == deactivate_dttm_after AND deactivate_dttm IS NOT NULL AND deactivate_dttm_after IS NOT NULL ) OR ( deactivate_dttm  IS NULL  AND  deactivate_dttm_after  IS NULL ) )   AND  ((screen_entire_prof_ind  == screen_entire_prof_ind_after AND screen_entire_prof_ind IS NOT NULL AND screen_entire_prof_ind_after IS NOT NULL)  OR ( screen_entire_prof_ind  IS NULL  AND  screen_entire_prof_ind_after  IS NULL ) ))"

pPatIdModCheck="(CAST(pat_id AS LONG)%4 == CAST(src_partition_nbr AS INTEGER) -1) AND (table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id,pat_id, pat_code_type, pat_allergy_health_cd, active_ind, create_user_id, create_dttm, deactivate_user_id, deactivate_dttm, screen_entire_prof_ind,src_partition_nbr"
#, src_partition_nbr, tracking_id, partition_column"

# COMMAND ----------

# Read ETL_HIVE_CUTOFF table:
from pyspark.sql import *

sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETL_HIVE_CUTOFF_TBL)

print(sel_ETL_Hive_Cutoff_tbl)
df_cutoff_records_output=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFK_ETL_DB) \
   .option("query",sel_ETL_Hive_Cutoff_tbl) \
   .load()

#display(df_cutoff_records_output)

# Filtering the cutoff timestamp for the current batch
cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
#display(cutoff_records_filter)

cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
RX_CUT_OFF_MAX_DTTM as rx_max,
CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
from cutoff_records_filter""" 

cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
display(cutoff_range_rx)

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
from cutoff_records_filter"""

cutoff_range_trans = spark.sql(cutoff_range_trans_sql)
display(cutoff_range_trans)

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_pat_algy_hlth_cd where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_pat_algy_hlth_cd where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_pat_algy_hlth_cd where " + pNopartitionTableCheck

#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)

nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition

else:  
  #Fetching rx_max and rx_trans_max as values
  rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
  #print(rx_max)
  rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max
  #print(rx_trans_max)

  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_trans_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_trans_max)

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

#Remove duplicates
dedup_group = nr_input_file_final.distinct()

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

display(ded)
#dedup_group.printSchema()

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
(case when (LENGTH(trim( edw_batch_id )) ==0) then edw_batch_id else trim(edw_batch_id) end) as edw_batch_id,
(case when (LENGTH(trim( edw_batch_id_after )) ==0) then edw_batch_id_after else trim(edw_batch_id_after) end) as edw_batch_id_after,
(case when (LENGTH(TRIM( src_partition_nbr )) ==0) then  src_partition_nbr else TRIM( src_partition_nbr ) end) as src_partition_nbr ,(case when (LENGTH(TRIM( src_partition_nbr_after )) ==0) then  src_partition_nbr_after else TRIM( src_partition_nbr_after ) end) as src_partition_nbr_after ,
(case when (LENGTH(trim( pat_id )) ==0) then pat_id else trim(pat_id) end) as pat_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after) end) as pat_id_after,
(case when (LENGTH(trim( pat_code_type )) ==0) then pat_code_type else trim(pat_code_type) end) as pat_code_type,
(case when (LENGTH(trim( pat_code_type_after )) ==0) then pat_code_type_after else trim(pat_code_type_after) end) as pat_code_type_after,
(case when (LENGTH(trim( pat_allergy_health_cd )) ==0) then pat_allergy_health_cd else trim(pat_allergy_health_cd) end) as pat_allergy_health_cd,
(case when (LENGTH(trim( pat_allergy_health_cd_after )) ==0) then pat_allergy_health_cd_after else trim(pat_allergy_health_cd_after) end) as pat_allergy_health_cd_after,
(case when (LENGTH(trim( active_ind )) ==0) then active_ind else trim(active_ind) end) as active_ind,
(case when (LENGTH(trim( active_ind_after )) ==0) then active_ind_after else trim(active_ind_after) end) as active_ind_after,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id) end) as create_user_id,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after) end) as create_user_id_after,
(case when (LENGTH(trim(create_dttm )) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8))  end) as create_dttm,
(case when (LENGTH(trim(create_dttm_after )) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8))  end) as create_dttm_after,
(case when (LENGTH(trim( deactivate_user_id )) ==0) then deactivate_user_id else trim(deactivate_user_id) end) as deactivate_user_id,
(case when (LENGTH(trim( deactivate_user_id_after )) ==0) then deactivate_user_id_after else trim(deactivate_user_id_after) end) as deactivate_user_id_after,
(case when (LENGTH(trim(deactivate_dttm )) ==0) then  deactivate_dttm else concat(substring(deactivate_dttm,1,10),' ',substring(deactivate_dttm,12,8)) end) as deactivate_dttm,
(case when (LENGTH(trim(deactivate_dttm_after )) ==0) then  deactivate_dttm_after else concat(substring(deactivate_dttm_after,1,10),' ',substring(deactivate_dttm_after,12,8))  end) as deactivate_dttm_after,
(case when (LENGTH(trim( screen_entire_prof_ind )) ==0) then screen_entire_prof_ind else trim(screen_entire_prof_ind) end) as screen_entire_prof_ind,
(case when (LENGTH(trim( screen_entire_prof_ind_after )) ==0) then screen_entire_prof_ind_after else trim(screen_entire_prof_ind_after) end) as screen_entire_prof_ind_after from dedup_group
"""

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  #print(gg_tbf0_rejected.count())
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 

#print(gg_tbf0_rejected.count())  
display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")

# COMMAND ----------

pTgtUpdAftXfr = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
src_partition_nbr_after AS src_partition_nbr ,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after) end) as pat_id,
(case when (LENGTH(trim( pat_code_type_after )) ==0) then pat_code_type_after else trim(pat_code_type_after) end) as pat_code_type,
(case when (LENGTH(trim( pat_allergy_health_cd_after )) ==0) then pat_allergy_health_cd_after else trim(pat_allergy_health_cd_after) end) as pat_allergy_health_cd,
(case when (LENGTH(trim( active_ind_after )) ==0) then active_ind_after else trim(active_ind_after) end) as active_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after) end) as create_user_id,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( deactivate_user_id_after )) ==0) then deactivate_user_id_after else trim(deactivate_user_id_after) end) as deactivate_user_id,
(case when (LENGTH(trim( deactivate_dttm_after )) ==0) then deactivate_dttm_after else concat(substring(deactivate_dttm_after,1,10),' ',substring(deactivate_dttm_after,12,8),'.000000') end) as deactivate_dttm,
(case when (LENGTH(trim( screen_entire_prof_ind_after )) ==0) then screen_entire_prof_ind_after else trim(screen_entire_prof_ind_after) end) as screen_entire_prof_ind,
"gg_tbf0_pat_algy_hlth_cd" as table_name
from gg_tbf0_update """

pTgtUpdBfrXfr = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id,
src_partition_nbr AS src_partition_nbr ,
(case when (LENGTH(trim( pat_id )) ==0) then pat_id else trim(pat_id) end) as pat_id,
(case when (LENGTH(trim( pat_code_type )) ==0) then pat_code_type else trim(pat_code_type) end) as pat_code_type,
(case when (LENGTH(trim( pat_allergy_health_cd )) ==0) then pat_allergy_health_cd else trim(pat_allergy_health_cd) end) as pat_allergy_health_cd,
(case when (LENGTH(trim( active_ind )) ==0) then active_ind else trim(active_ind) end) as active_ind,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id) end) as create_user_id,
(case when (LENGTH(trim(create_dttm )) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000')  end) as create_dttm,
(case when (LENGTH(trim( deactivate_user_id )) ==0) then deactivate_user_id else trim(deactivate_user_id) end) as deactivate_user_id,
(case when (LENGTH(trim(deactivate_dttm )) ==0) then  deactivate_dttm else concat(substring(deactivate_dttm,1,10),' ',substring(deactivate_dttm,12,8),'.000000')  end) as deactivate_dttm,
(case when (LENGTH(trim( screen_entire_prof_ind )) ==0) then screen_entire_prof_ind else trim(screen_entire_prof_ind) end) as screen_entire_prof_ind,
"gg_tbf0_pat_algy_hlth_cd" as table_name
from gg_tbf0_update """

pTgtInsBfrAftXfr = """select
(case when (LENGTH(trim(cdc_txn_commit_dttm)) ==0) then cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_seq_nbr)) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim(cdc_rba_nbr)) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim(cdc_operation_type_cd)) ==0) then cdc_operation_type_cd else trim( cdc_operation_type_cd ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim(cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim(cdc_txn_position_cd_after)) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id,
src_partition_nbr_after AS src_partition_nbr ,
(case when (LENGTH(trim(pat_id_after)) ==0) then pat_id_after else trim(pat_id_after) end) as pat_id,
(case when (LENGTH(trim(pat_code_type_after)) ==0) then pat_code_type_after else trim(pat_code_type_after) end) as pat_code_type,
(case when (LENGTH(trim(pat_allergy_health_cd_after)) ==0) then pat_allergy_health_cd_after else trim(pat_allergy_health_cd_after) end) as pat_allergy_health_cd,
(case when (LENGTH(trim(active_ind_after)) ==0) then active_ind_after else trim(active_ind_after) end) as active_ind,
(case when (LENGTH(trim(create_user_id_after)) ==0) then create_user_id_after else trim(create_user_id_after) end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after)) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim(deactivate_user_id_after)) ==0) then deactivate_user_id_after else trim(deactivate_user_id_after) end) as deactivate_user_id,
(case when (LENGTH(trim(deactivate_dttm_after)) ==0) then deactivate_dttm_after else concat(substring(deactivate_dttm_after,1,10),' ',substring(deactivate_dttm_after,12,8),'.000000') end) as deactivate_dttm,
(case when (LENGTH(trim(screen_entire_prof_ind_after)) ==0) then screen_entire_prof_ind_after else trim(screen_entire_prof_ind_after) end) as screen_entire_prof_ind,
"gg_tbf0_pat_algy_hlth_cd" as table_name
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
display(etl_tbf0_file)

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
#display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull()) \
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
.withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr"))) \
.withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr"))) \
.withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id"))) \
.withColumn("pat_id",when(col("pat_id") == "",None).otherwise(col("pat_id"))) \
.withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id"))) \
.withColumn("create_dttm",to_timestamp(etl_tbf0_reformat["create_dttm"])) \
.withColumn("deactivate_user_id",when(col("deactivate_user_id") == "",None).otherwise(col("deactivate_user_id"))) \
.withColumn("deactivate_dttm",to_timestamp(etl_tbf0_reformat["deactivate_dttm"])) \
.withColumn("screen_entire_prof_ind",when(col("screen_entire_prof_ind") == "",None).otherwise(col("screen_entire_prof_ind"))) \
.withColumn("src_partition_nbr",when(col("src_partition_nbr") == "",None).otherwise(col("src_partition_nbr")))
# .withColumn("SRC_PARTITION_NBR",lit(1))

#display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
#print(etl_tbf0_reformat_cdc_check.count())
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)

print(etl_tbf0_reformat_cdc_check_notnull.count())  

display(etl_tbf0_reformat_cdc_check_notnull)  
#etl_tbf0_reformat_cdc_check_notnull.printSchema()
etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

# COMMAND ----------

# pat_null=etl_tbf0_reformat_cdc_check_notnull.where("pat_id is null")
# display(pat_null)
# print(pat_null.count())

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

#Write API Call to Close Open Assets
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_ASSET_STATUS='200'
#dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/UpdateProcessedFilesStatus", 200, 
                  {"PAR_ASSET_STATUS":PAR_ASSET_STATUS,
                   "PAR_FEED_NAMES":FEED_NAME,
                   "PAR_PIPELINE_NAME":PAR_JOB_NAME,
                   "PAR_SQL_SERVER":PAR_SQL_SERVER,
                   "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                   "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                   "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                   "PAR_WRITEAPI_URL":PAR_WRITEAPI_URL})


# COMMAND ----------


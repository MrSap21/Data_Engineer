# Databricks notebook source
# Python code to mount and access Azure Data Lake Storage Gen2 Account to Azure Databricks with Service Principal and OAuth
# Author: Dhyanendra Singh Rathore
# Define the variables used for creating connection strings 
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
mountPoint = "/mnt/WCARD_ITEM_EXCEPTION_LIST"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

# Define Input Schema

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("profile_number", IntegerType(), False),
    StructField("item_department_number", StringType(), False)
  ])
)

# COMMAND ----------

# Load Input File

inputFileFullPath = mountPoint + "/" + dbutils.widgets.get('AI_FTP') + "/WCRDRITM.DAT"

dfInput = spark.read.format("csv").options(header='true', delimiter = '|').schema(inputSchema).load(inputFileFullPath)

#display(dfInput)

# COMMAND ----------

# Filter only valid Wcard profiles

from pyspark.sql.functions import *

dfInputFiltered = dfInput.filter((col("profile_number") == 26) | (col("profile_number") == 27) | (col("profile_number") == 28) | (col("profile_number") == 29) | (col("profile_number") == 30) | (col("profile_number") == 31) | (col("profile_number") == 32))

#display(dfInputFiltered)

# COMMAND ----------

dfInputSplit = dfInputFiltered.withColumn("item_department_number", split("item_department_number", ";"))

#display(dfInputSplit)

# COMMAND ----------

dfInputNormalized = dfInputSplit.withColumn("item_department_number", explode("item_department_number"))

#display(dfInputNormalized)

# COMMAND ----------

# Write output files

data_location_output = "{0}/{1}/wcard_profile_exception_list".format(mountPoint, dbutils.widgets.get('AI_LOAD'))

dfInputNormalized.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(data_location_output)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

# COMMAND ----------


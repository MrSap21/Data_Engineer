# Databricks notebook source
#Widgets for passing required parameters values

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220823062450")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_REJECT_FOLDER","retail/retail_sales/reject")
# dbutils.widgets.text("PAR_DELETE_LKP_FILE","wcard_last_transaction_delete_lkp")
# dbutils.widgets.text("PAR_WCARD_LAST_TRAN_FILE","wcard_last_transaction")
# dbutils.widgets.text("PAR_WCARD_LAST_TRAN_REJ_FILE","WCARD_LAST_TRANS.rej")
# dbutils.widgets.text("PAR_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_SNFK_DB1","UAT_STAGING")
# dbutils.widgets.text("PAR_SNFK_DB2","UAT_RETAIL")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_LAST_TRANSACTION")
# dbutils.widgets.text("PAR_SNFK_TBL2","RETAIL_SALES.WCARD_ACCT_ID_STG")
# dbutils.widgets.text("PAR_WCARD_UPDATE_FILE","wcard_last_transaction_update_ascii.pipe_delim")
# dbutils.widgets.text("PAR_WCARD_INSERT_FILE","wcard_last_transaction_insert_ascii.pipe_delim")

# COMMAND ----------

#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
Delete_LKPFile = dbutils.widgets.get("PAR_DELETE_LKP_FILE")
Wcard_Trans_Input_File = dbutils.widgets.get("PAR_WCARD_LAST_TRAN_FILE")
Wcard_trans_Rej_File = dbutils.widgets.get("PAR_WCARD_LAST_TRAN_REJ_FILE")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_DB2 = dbutils.widgets.get("PAR_SNFK_DB2")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
SNFL_TBL_NAME2 = dbutils.widgets.get("PAR_SNFK_TBL2")
Wcard_Update_File = dbutils.widgets.get("PAR_WCARD_UPDATE_FILE")
Wcard_Insert_File = dbutils.widgets.get("PAR_WCARD_INSERT_FILE")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

WcardLastTranDF=spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+Wcard_Trans_Input_File+"/"+Batch_id)

WcardLastTranDF=WcardLastTranDF.withColumn("tandem_txn_tm",WcardLastTranDF.tandem_txn_tm.cast(StringType()))

#Sort and Dedup on  {acct_id; prog_id; profile_id}:

DedupSortDF = WcardLastTranDF.select("*", row_number().over(Window.partitionBy("acct_id","prog_id","profile_id").orderBy("acct_id","prog_id","profile_id")).alias("row_num"))
DedupSortHolder = DedupSortDF.filter(DedupSortDF.row_num ==1).drop("row_num")

ValidCheckDF = DedupSortHolder.filter(((trim(col("acct_id")).isNotNull()) & (col("acct_id")!='')) & ((trim(col("prog_id")).isNotNull()) & (col("prog_id")!='')) & ((col("profile_id").isNotNull()) & (trim(col("profile_id"))!='')))

# COMMAND ----------

#Read wcard_last_transaction_delete_lkp File:
WcardLKPDF=spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+Delete_LKPFile+"/"+Batch_id)
ReformatDF = WcardLKPDF.select("acct_id")
Reformat1DF = ValidCheckDF.select("acct_id")
GatherDF = ReformatDF.unionByName(Reformat1DF)
DedupSortHolder1 = GatherDF.dropDuplicates(['acct_id'])

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Delete stg table:
delete_WcardAccIDstg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB1, SNFL_TBL_NAME2)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_WcardAccIDstg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB1,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

DedupSortHolder1.cache()
DedupSortHolder1.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("truncate","true")\
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB1) \
        .option("dbtable", SNFL_TBL_NAME2) \
        .option("continue_on_error","on")\
        .save()
#display(DedupSortHolder1)

# COMMAND ----------

#Reading tables:

sel_wcard_last_tran_table = "Select ACCT_ID,PROFILE_ID,PROG_ID,TANDEM_TXN_DT,substring(to_varchar(TANDEM_TXN_TM,'HH24:MI:SS.FF'), 1,11) as TANDEM_TXN_TM,STR_NBR,REGISTER_NBR,TANDEM_TXN_NBR,TANDEM_STR_TXN_DT,TANDEM_STR_TXN_TM,TANDEM_CASHIER_NBR,TANDEM_REQ_TYPE,TANDEM_ACTN_TYPE,TANDEM_APRV_NBR,TANDEM_ORIG,TANDEM_APRV_DLRS,TANDEM_RESPONSE_CD,TANDEM_RBT_TYPE,TANDEM_RBT_DLRS,TANDEM_RBT_PCTG,TANDEM_RBT_AGAINST_DLRS,TANDEM_STARTING_BAL_DLRS,TANDEM_END_BAL_DLRS,TANDEM_TXN_DLRS,TANDEM_CLNT_NAME,TANDEM_USER_ID,TXN_TYPE_CD,CREATE_DTTM FROM {0}".format(SNFL_TBL_NAME1)

wcard_last_tran_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB2) \
     .option("query",sel_wcard_last_tran_table) \
     .load()

# COMMAND ----------

#Join On tables file:
wcard_last_tran_tbl_df.createOrReplaceTempView("wcard_last_transaction")
DedupSortHolder1= DedupSortHolder1.withColumnRenamed("ACCT_ID","ACCT_ID_1")
DedupSortHolder1.createOrReplaceTempView("wcard_acct_id_stg")
JoinOnTablesDF = spark.sql("select * from wcard_last_transaction a inner join wcard_acct_id_stg b on a.acct_id=b.acct_id_1").select ("acct_id","a.profile_id","a.prog_id","a.tandem_txn_dt","a.tandem_txn_tm","a.str_nbr","a.register_nbr","a.tandem_txn_nbr","a.tandem_str_txn_dt","a.tandem_str_txn_tm","a.tandem_cashier_nbr","a.tandem_req_type","a.tandem_actn_type","a.tandem_aprv_nbr","a.tandem_orig","a.tandem_aprv_dlrs","a.tandem_response_cd","a.tandem_rbt_type","a.tandem_rbt_dlrs","a.tandem_rbt_pctg","a.tandem_rbt_against_dlrs","a.tandem_starting_bal_dlrs","a.tandem_end_bal_dlrs","a.tandem_txn_dlrs","a.tandem_clnt_name","a.tandem_user_id","a.txn_type_cd","a.create_dttm") 

# COMMAND ----------


#jOIN ON TABLEJOIN AND FBE ValidCheckDF
JoinsDF = ValidCheckDF.join(JoinOnTablesDF,
on=[JoinOnTablesDF.acct_id==ValidCheckDF.acct_id,
JoinOnTablesDF.prog_id==ValidCheckDF.prog_id,
JoinOnTablesDF.profile_id==ValidCheckDF.profile_id], how='inner')

Join5DF=JoinsDF.withColumn("update_flag",lit("Y")) \
.withColumn("deleted_tandem_txn_dt",JoinOnTablesDF.tandem_txn_dt)\
.withColumn("deleted_tandem_txn_tm",JoinOnTablesDF.tandem_txn_tm).select(ValidCheckDF.acct_id,ValidCheckDF.profile_id,ValidCheckDF.prog_id,ValidCheckDF.tandem_txn_dt,ValidCheckDF.tandem_txn_tm,ValidCheckDF.str_nbr,ValidCheckDF.register_nbr,ValidCheckDF.tandem_txn_nbr,ValidCheckDF.tandem_str_txn_dt,ValidCheckDF.tandem_str_txn_tm,ValidCheckDF.tandem_cashier_nbr,ValidCheckDF.tandem_req_type,ValidCheckDF.tandem_actn_type,ValidCheckDF.tandem_aprv_nbr,ValidCheckDF.tandem_orig,ValidCheckDF.tandem_aprv_dlrs,ValidCheckDF.tandem_response_cd,ValidCheckDF.tandem_rbt_type,ValidCheckDF.tandem_rbt_dlrs,ValidCheckDF.tandem_rbt_pctg,ValidCheckDF.tandem_rbt_against_dlrs,ValidCheckDF.tandem_starting_bal_dlrs,ValidCheckDF.tandem_end_bal_dlrs,ValidCheckDF.tandem_txn_dlrs,ValidCheckDF.tandem_clnt_name,ValidCheckDF.tandem_user_id,ValidCheckDF.txn_type_cd,ValidCheckDF.create_dttm,"deleted_tandem_txn_dt","deleted_tandem_txn_tm","update_flag")

# COMMAND ----------

#Unused Anti join on join 5

JoinAntiDF = ValidCheckDF.join(JoinOnTablesDF,on=[JoinOnTablesDF.acct_id==ValidCheckDF.acct_id,JoinOnTablesDF.prog_id==ValidCheckDF.prog_id,
JoinOnTablesDF.profile_id==ValidCheckDF.profile_id], how='left_anti')

# FBE Validcheck on flag
FBEValidCheckFlagDF = Join5DF.filter("update_flag = 'Y'")
FBEValidCheckFlagDropDF = FBEValidCheckFlagDF.drop("update_flag","deleted_tandem_txn_dt","deleted_tandem_txn_tm")

#Gather on Join and RFT:
Gather_DF = JoinAntiDF.unionByName(FBEValidCheckFlagDropDF)

# COMMAND ----------

#Gather-1 and lookup file

WcardInsertAsciiDF = Gather_DF.join(WcardLKPDF,
on=[Gather_DF.acct_id==WcardLKPDF.acct_id,
Gather_DF.prog_id==WcardLKPDF.prog_id,
Gather_DF.profile_id==WcardLKPDF.profile_id], how='left_outer')

WcardInsertAsciiFilterDF = WcardInsertAsciiDF.filter((WcardLKPDF.acct_id.isNull()) & (WcardLKPDF.prog_id.isNull()) & (WcardLKPDF.profile_id.isNull()))

WcardInsertAsciiFilter1DF = WcardInsertAsciiFilterDF.select(Gather_DF.acct_id,Gather_DF.profile_id,Gather_DF.prog_id,Gather_DF.tandem_txn_dt,Gather_DF.tandem_txn_tm,Gather_DF.str_nbr,Gather_DF.register_nbr,Gather_DF.tandem_txn_nbr,Gather_DF.tandem_str_txn_dt,Gather_DF.tandem_str_txn_tm,Gather_DF.tandem_cashier_nbr,Gather_DF.tandem_req_type,Gather_DF.tandem_actn_type,Gather_DF.tandem_aprv_nbr,Gather_DF.tandem_orig,Gather_DF.tandem_aprv_dlrs,Gather_DF.tandem_response_cd,Gather_DF.tandem_rbt_type,Gather_DF.tandem_rbt_dlrs,Gather_DF.tandem_rbt_pctg,Gather_DF.tandem_rbt_against_dlrs,Gather_DF.tandem_starting_bal_dlrs,Gather_DF.tandem_end_bal_dlrs,Gather_DF.tandem_txn_dlrs,Gather_DF.tandem_clnt_name,Gather_DF.tandem_user_id,Gather_DF.txn_type_cd,Gather_DF.create_dttm).distinct()

#Generate wcard_last_transaction_insert_ascii.pipe_delim file:
print("wcard_last_transaction_insert_ascii.pipe_delim Count: {}".format(WcardInsertAsciiFilter1DF.count()))
WcardInsertAsciiFilter1DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Wcard_Insert_File+"/"+Batch_id)

# COMMAND ----------

RFT2DF = WcardLKPDF.select("acct_id","profile_id","prog_id","tandem_txn_dt","tandem_txn_tm","str_nbr","register_nbr","tandem_txn_nbr","tandem_str_txn_dt","tandem_str_txn_tm","tandem_cashier_nbr","tandem_req_type","tandem_actn_type","tandem_aprv_nbr","tandem_orig","tandem_aprv_dlrs","tandem_response_cd","tandem_rbt_type","tandem_rbt_dlrs","tandem_rbt_pctg","tandem_rbt_against_dlrs","tandem_starting_bal_dlrs","tandem_end_bal_dlrs","tandem_txn_dlrs","tandem_clnt_name","tandem_user_id","txn_type_cd","create_dttm") 

# COMMAND ----------

#Phase2 Dedup Sorted-1:
DedupSort1DF = RFT2DF.select("*", row_number().over(Window.partitionBy("acct_id").orderBy(RFT2DF['acct_id'])).alias("row_num")) 

DedupSort1Holder = DedupSort1DF.filter(DedupSort1DF.row_num ==1).drop("row_num").select ("acct_id","profile_id","prog_id","tandem_txn_dt","tandem_txn_tm","str_nbr","register_nbr","tandem_txn_nbr","tandem_str_txn_dt","tandem_str_txn_tm","tandem_cashier_nbr","tandem_req_type","tandem_actn_type","tandem_aprv_nbr","tandem_orig","tandem_aprv_dlrs","tandem_response_cd","tandem_rbt_type","tandem_rbt_dlrs","tandem_rbt_pctg","tandem_rbt_against_dlrs","tandem_starting_bal_dlrs","tandem_end_bal_dlrs","tandem_txn_dlrs","tandem_clnt_name","tandem_user_id","txn_type_cd","create_dttm")

# COMMAND ----------

#Phase 2 Join on tableJoin and DedupSort1DF

JoinDF = DedupSort1Holder.join(JoinOnTablesDF, on=[DedupSort1Holder.acct_id==JoinOnTablesDF.acct_id], how='inner').select(JoinOnTablesDF.acct_id,JoinOnTablesDF.profile_id,JoinOnTablesDF.prog_id,JoinOnTablesDF.tandem_txn_dt,JoinOnTablesDF.tandem_txn_tm,JoinOnTablesDF.str_nbr,JoinOnTablesDF.register_nbr,JoinOnTablesDF.tandem_txn_nbr,JoinOnTablesDF.tandem_str_txn_dt,JoinOnTablesDF.tandem_str_txn_tm,JoinOnTablesDF.tandem_cashier_nbr,JoinOnTablesDF.tandem_req_type,JoinOnTablesDF.tandem_actn_type,JoinOnTablesDF.tandem_aprv_nbr,JoinOnTablesDF.tandem_orig,JoinOnTablesDF.tandem_aprv_dlrs,JoinOnTablesDF.tandem_response_cd,JoinOnTablesDF.tandem_rbt_type,JoinOnTablesDF.tandem_rbt_dlrs,JoinOnTablesDF.tandem_rbt_pctg,JoinOnTablesDF.tandem_rbt_against_dlrs,JoinOnTablesDF.tandem_starting_bal_dlrs,JoinOnTablesDF.tandem_end_bal_dlrs,JoinOnTablesDF.tandem_txn_dlrs,JoinOnTablesDF.tandem_clnt_name,JoinOnTablesDF.tandem_user_id,JoinOnTablesDF.txn_type_cd,JoinOnTablesDF.create_dttm) 

# COMMAND ----------

Drop_update_flagDF = FBEValidCheckFlagDF.withColumn("tandem_txn_dt",FBEValidCheckFlagDF.deleted_tandem_txn_dt) \
.withColumn("tandem_txn_tm",FBEValidCheckFlagDF.deleted_tandem_txn_tm).select("acct_id","profile_id","prog_id","tandem_txn_dt","tandem_txn_tm","str_nbr","register_nbr","tandem_txn_nbr","tandem_str_txn_dt","tandem_str_txn_tm","tandem_cashier_nbr","tandem_req_type","tandem_actn_type","tandem_aprv_nbr","tandem_orig","tandem_aprv_dlrs","tandem_response_cd","tandem_rbt_type","tandem_rbt_dlrs","tandem_rbt_pctg","tandem_rbt_against_dlrs","tandem_starting_bal_dlrs","tandem_end_bal_dlrs","tandem_txn_dlrs","tandem_clnt_name","tandem_user_id","txn_type_cd","create_dttm")

# COMMAND ----------

#gather-2 Phase 2
Gather_DF2 = JoinDF.unionByName(Drop_update_flagDF).dropDuplicates()

#Generate wcard_last_transaction_update_ascii.pipe_delim file:
print("wcard_last_transaction_update_ascii.pipe_delim Count: {}".format(Gather_DF2.count()))
Gather_DF2.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Wcard_Update_File+"/"+Batch_id)

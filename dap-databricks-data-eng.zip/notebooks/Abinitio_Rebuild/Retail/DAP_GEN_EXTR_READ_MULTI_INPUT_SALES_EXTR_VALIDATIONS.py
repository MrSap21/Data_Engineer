# Databricks notebook source
# DBTITLE 1,Import libraries
# Import Python libs
from functools import reduce

from pyspark.sql.functions import *

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# DBTITLE 1,Function to remove double quotes
#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:]
  outval = outval.lstrip("\"")
  if(len(str(outval)) > 1 ):
      if((outval[-2]!="\\")) :
    #remove rightmost "
        outval = outval.rstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

# DBTITLE 1,RXEXT004
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_RXEXT004")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_RXEXT004"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.ro_ref_num.isNotNull()) & (length(col("ro_ref_num")) > 0) & (col("ro_ref_num").rlike("^\d*\d*$")) & (col("ro_self_pay").rlike("^\d*\d*$")) & (col("ro_st_num").rlike("^\d*\d*$")) & (col("ro_generic").rlike("^\d*\d*$")) & (col("order_type").rlike("^\d*\d*$")) & (col("rd_store_num").rlike("^[+]?\d*\d*$")) & (col("estimated_price").rlike("^[-]?\d*\.?\d*$")) & (col("ready_price").rlike("^[-]?\d*\.?\d*$")) & (col("xfr_rx_nbr").rlike("^\d*\d*$")) & (col("xfr_store_nbr").rlike("^[+]?\d*\d*$")))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,RXEXT005
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_RXEXT005")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_RXEXT005"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.ro_ref_num.isNotNull()) & (length(col("ro_ref_num")) > 0) & (col("ro_ref_num").rlike("^\d*\d*$")) & (col("ro_self_pay").rlike("^\d*\d*$")) & (col("ro_st_num").rlike("^\d*\d*$")) & (col("ro_generic").rlike("^\d*\d*$")) & (col("order_type").rlike("^\d*\d*$")) & (col("rs_ship_hand_amt").rlike("^[-]?\d*\.?\d*$")) & (col("rs_total_cost_amt").rlike("^\d*\d*$")) & (col("rs_email_sent").rlike("^[-]?\d*\d*$")))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,RXEXT006
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_RXEXT006")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_RXEXT006"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.ro_ref_num.isNotNull()) & (length(col("ro_ref_num")) > 0) & (col("ro_ref_num").rlike("^\d*\d*$")) & (col("ro_self_pay").rlike("^\d*\d*$")) & (col("ro_st_num").rlike("^\d*\d*$")) & (col("ro_generic").rlike("^\d*\d*$")) & (col("order_type").rlike("^\d*\d*$")) & (col("rt_qty").rlike("^[-]?\d*\.?\d*$")))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,PHEXT003
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT003")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT003"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.gqm_order_id.isNotNull()) & (length(col("gqm_order_id")) > 0) & (col("gqm_order_id").rlike("^\d*\d*$")) & (dfQuotes.sub_total_price.isNotNull()) & (length(col("sub_total_price")) > 0) & (col("sub_total_price").rlike("^[-]?\d*\.?\d*$")) & (dfQuotes.total_order_discount.isNotNull()) & (length(col("total_order_discount")) > 0) & (col("total_order_discount").rlike("^[-]?\d*\.?\d*$")) & (dfQuotes.order_tax.isNotNull()) & (length(col("order_tax")) > 0) & (col("order_tax").rlike("^[-]?\d*\.?\d*$")) & (col("store_nbr").rlike("^\d*\d*$")) & (col("order_freight").rlike("^[-]?\d*\.?\d*$")) & (col("shr_order_ind").rlike("^\d*\d*$")) & (dfQuotes.order_placed_dttm.isNotNull()) & (length(col("order_placed_dttm")) > 0) & (dfQuotes.create_dttm.isNotNull()) & (length(col("create_dttm")) > 0))

dfFinal = dfFinal.drop(col("customer_id")).drop(col("token_id")).drop(col("fulfillment_vndr_id"))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,PHEXT005
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT005")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT005"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.gqm_order_id.isNotNull()) & (col("gqm_order_id").rlike("^\d*\d*$")) & (length(col("gqm_order_id")) > 0) & dfQuotes.item_qty.isNotNull() & (col("item_qty").rlike("^\d*\d*$")) & (length(col("item_qty")) > 0) & dfQuotes.file_size.isNotNull() & (col("file_size").rlike("^\d*\d*$")) & (length(col("file_size")) > 0))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,SSEXT007
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_SSEXT007")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_SSEXT007"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((col("origin_of_order").rlike("^\d*\d*$")) & (col("store_number").rlike("^\d*\d*$")) & (col("original_invoice_amount").rlike("^[-]?\d*\.?\d*$")) & (col("employee_discount_applied_cd").rlike("^\d*\d*$")) & (col("ship_to_location").rlike("^\d*\d*$")) & (col("pickup_at_store_num").rlike("^\d*\d*$")) & (col("ea_order_ind").rlike("^\d*\d*$")) & (col("held_order_bypass_reason").rlike("^\d*\d*$")) & (col("aarp_ind").rlike("^\d*\d*$")) & (col("raw_subtotal").rlike("^[-]?\d*\.?\d*$")) & (col("tax").rlike("^[-]?\d*\.?\d*$")) & (col("shipping").rlike("^[-]?\d*\.?\d*$")) & (col("loyalty_redeem_dlrs").rlike("^[-]?\d*\.?\d*$")))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,PHEXT004
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT004")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT004"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.gqm_order_id.isNotNull()) & (col("gqm_order_id").rlike("^\d*\d*$")) & (length(col("gqm_order_id")) > 0) & (dfQuotes.refund_id.isNotNull()) & (col("refund_id").rlike("^\d*\d*$")) & (length(col("refund_id")) > 0) & (dfQuotes.sub_total_price.isNotNull()) & (col("sub_total_price").rlike("^[-]?\d*\.?\d*$")) & (length(col("sub_total_price")) > 0) & (dfQuotes.return_cd.isNotNull()) & (col("return_cd").rlike("^\d*\d*$")) & (length(col("return_cd")) > 0) & (col("freight").rlike("^[-]?\d*\.?\d*$")) & (col("tax_total").rlike("^[-]?\d*\.?\d*$")) & (col("vendor_refund_id").rlike("^\d*\d*$")) & (col("gc_amount").rlike("^[-]?\d*\.?\d*$")) & (col("cc_amount").rlike("^[-]?\d*\.?\d*$")) & (col("paypal_amount").rlike("^[-]?\d*\.?\d*$")) & (col("freight_discount_total").rlike("^[-]?\d*\.?\d*$") & (dfQuotes.refund_dttm.isNotNull()) & (length(col("refund_dttm")) > 0) & (dfQuotes.create_dttm.isNotNull()) & (length(col("create_dttm")) > 0)))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,SSEXT004
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_SSEXT004")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_SSEXT004"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.sugg_tax_refund.isNotNull()) & (col("sugg_tax_refund").rlike("^[-]?\d*\.?\d*$")) & (length(col("sugg_tax_refund")) > 0) & (dfQuotes.actl_tax_refund.isNotNull()) & (col("actl_tax_refund").rlike("^[-]?\d*\.?\d*$")) & (length(col("actl_tax_refund")) > 0) & (dfQuotes.sugg_ship_refund.isNotNull()) & (col("sugg_ship_refund").rlike("^[-]?\d*\.?\d*$")) & (length(col("sugg_ship_refund")) > 0) & (dfQuotes.actl_ship_refund.isNotNull()) & (col("actl_ship_refund").rlike("^[-]?\d*\.?\d*$")) & (length(col("actl_ship_refund")) > 0) & (dfQuotes.proc_immed.isNotNull()) & (col("proc_immed").rlike("^\d*\d*$")) & (length(col("proc_immed")) > 0) & (dfQuotes.processed.isNotNull()) & (col("processed").rlike("^\d*\d*$")) & (length(col("processed")) > 0) & (dfQuotes.quantity_to_return.isNotNull()) & (col("quantity_to_return").rlike("^\d*\d*$")) & (length(col("quantity_to_return")) > 0) & (dfQuotes.quantity_to_repl.isNotNull()) & (dfQuotes.ret_shipment_req.isNotNull()) & (col("ret_shipment_req").rlike("^\d*\d*$")) & (length(col("ret_shipment_req")) > 0) & (dfQuotes.bonus_refund.isNotNull()) & (col("bonus_refund").rlike("^\d*\d*$")) & (length(col("bonus_refund")) > 0) & (dfQuotes.quantity_received.isNotNull()) & (col("quantity_received").rlike("^\d*\d*$")) & (length(col("quantity_received")) > 0) & (dfQuotes.refund_amount.isNotNull()) & (col("refund_amount").rlike("^[-]?\d*\.?\d*$")) & (length(col("refund_amount")) > 0) & (dfQuotes.amount.isNotNull()) & (col("amount").rlike("^[-]?\d*\.?\d*$")) & (length(col("amount")) > 0) & col("loyalty_redeem_dlrs").rlike("^[-]?\d*\.?\d*$") & (dfQuotes.created_date.isNotNull()) & (length(col("created_date")) > 0))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,SSEXT008
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_SSEXT008")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_SSEXT008"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.TYPE.isNotNull()) & (col("TYPE").rlike("^\d*\d*$")) & (length(col("TYPE")) > 0) & (dfQuotes.type_1.isNotNull()) & (col("type_1").rlike("^\d*\d*$")) & (length(col("type_1")) > 0) & (col("quantity").rlike("^[-]?\d*\.?\d*$")) & (col("wic").rlike("^[-]?\d*\.?\d*$")) & (col("total_sale_price").rlike("^[-]?\d*\.?\d*$")) & (col("plu_code").rlike("^\d*\d*$")) & (col("coupon_saving").rlike("^\d*\d*$")) & (col("item_size").rlike("^[-]?\d*\.?\d*$")) & (col("ordered_quantity").rlike("^[-]?\d*\.?\d*$")) & (col("product_cost").rlike("^[-]?\d*\.?\d*$")) & (col("eye_side").rlike("^\d*\d*$")) & (col("availability_cd").rlike("^\d*\d*$")) & (col("aarp_ind").rlike("^\d*\d*$")) & (col("override_price_ind").rlike("^\d*\d*$")) & (col("orig_ordered_wic").rlike("^\d*\d*$")) & (col("list_price").rlike("^[-]?\d*\.?\d*$")) & (col("raw_total_price").rlike("^[-]?\d*\.?\d*$")) & (col("sale_price").rlike("^[-]?\d*\.?\d*$")) & (col("on_sale").rlike("^\d*\d*$")) & (col("order_discount").rlike("^[-]?\d*\.?\d*$")) & (col("qty_discounted").rlike("^[-]?\d*\.?\d*$")) & (col("qty_as_qualifier").rlike("^\d*\d*$")) & (col("amount").rlike("^[-]?\d*\.?\d*$")) & (col("discounted").rlike("^\d*\d*$")) & (col("amount_is_final").rlike("^\d*\d*$")))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,PHEXT016
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT016")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT016"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.gqm_order_id.isNotNull()) & (col("gqm_order_id").rlike("^\d*\d*$")) & (length(col("gqm_order_id")) > 0) & (dfQuotes.unit_price.isNotNull()) & (col("unit_price").rlike("^[-]?\d*\.?\d*$")) & (length(col("unit_price")) > 0) & (dfQuotes.product_price_before_discount.isNotNull()) & (col("product_price_before_discount").rlike("^[-]?\d*\.?\d*$")) & (length(col("product_price_before_discount")) > 0) & (dfQuotes.product_qty.isNotNull()) & (col("product_qty").rlike("^\d*\d*$")) & (length(col("product_qty")) > 0) & (col("product_discount_table").rlike("^[-]?\d*\.?\d*$")) & (dfQuotes.create_dttm.isNotNull()) & (length(col("create_dttm")) > 0))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

# COMMAND ----------

# DBTITLE 1,PHEXT017
inputPath = dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT017")
batchId = dbutils.widgets.get("pEDW_BATCH_ID")

file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pIN_PARQUET_EXTR_PHEXT017"), dbutils.widgets.get("pEDW_BATCH_ID"))

dfcurrent=spark.read.parquet(file_path)

dfQuotes = (reduce(
    lambda dfcurrent, col_name: dfcurrent.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfcurrent.columns,
    dfcurrent
))

dfFinal = dfQuotes.filter((dfQuotes.gqm_order_id.isNotNull()) & (col("gqm_order_id").rlike("^\d*\d*$")) & (length(col("gqm_order_id")) > 0) & (dfQuotes.refund_id.isNotNull()) & (col("refund_id").rlike("^\d*\d*$")) & (length(col("refund_id")) > 0) &(dfQuotes.refund_item_id.isNotNull()) & (col("refund_item_id").rlike("^\d*\d*$")) & (length(col("refund_item_id")) > 0) & (dfQuotes.unit_price.isNotNull()) & (col("unit_price").rlike("^[-]?\d*\.?\d*$")) & (length(col("unit_price")) > 0) & (dfQuotes.product_price_before_discount.isNotNull()) & (col("product_price_before_discount").rlike("^[-]?\d*\.?\d*$")) & (length(col("product_price_before_discount")) > 0) & (dfQuotes.product_qty.isNotNull()) & (col("product_qty").rlike("^\d*\d*$")) & (length(col("product_qty")) > 0) & (col("product_discount_total").rlike("^[-]?\d*\.?\d*$")) & (dfQuotes.create_dttm.isNotNull()) & (length(col("create_dttm")) > 0))

dfFinal.write.format("parquet").mode("overwrite").save(file_path)

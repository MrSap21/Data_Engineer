# Databricks notebook source
# dbutils.widgets.text("PAR_SQL_SERVER","dapuatsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapuatsqldb01")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","uatdnasqldb")
# dbutils.widgets.text("PAR_FEED_NAME","IT005P,IT018P,IT024P,IT027P,IT142P,IT143P")
# dbutils.widgets.text("PAR_JOB_NAME","PL_MSTR_DAP_IDL_PRODUCT_CIF_PRODUCT_UPC_PRICE_DETAIL_SRC_CIF")
# dbutils.widgets.text("PAR_MANUAL_CATCH_UP_DATE","2022-08-31")

# COMMAND ----------

pSQLServer = dbutils.widgets.get("PAR_SQL_SERVER")
pSQLServerDB = dbutils.widgets.get("PAR_SQL_SERVER_DB")
pSQLServerClientID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
pSQLServerClientSecret = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
pFeed_Name = dbutils.widgets.get("PAR_FEED_NAME")
pJob_Name = dbutils.widgets.get("PAR_JOB_NAME")
pManual_Catch_Up_Date = dbutils.widgets.get("PAR_MANUAL_CATCH_UP_DATE")

from pyspark.sql.types import StringType, IntegerType
import pandas as pd
from pyspark.sql.functions import split, col, lit, to_date, substring, concat_ws, date_add, regexp_extract, trim, to_timestamp, count, date_format

# COMMAND ----------

# Connect to Azure SQL Server
import pyodbc 
import os
import adal

conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                      f'Server={pSQLServer};'
                      f'Database={pSQLServerDB};'
                      f'UID={dbutils.secrets.get(scope="dapadbscope",key=pSQLServerClientID)};'
                      f'PWD={dbutils.secrets.get(scope="dapadbscope",key=pSQLServerClientSecret)};'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )
cursor = conn.cursor()

# COMMAND ----------

def last_run_asset(feedjobname):
  max_asset = cursor.execute(
      (
        "SELECT cast(AssetID as varchar) AssetId, AssetName, AssetCurrentLocation FROM idfwba.Asset "
        "where AssetID IN ("
        "SELECT MAX(A.AssetID) FROM idfwba.Feed F JOIN idfwba.Asset A ON F.FeedID = A.FeedID "
        "JOIN idfwba.AssetStatus AU ON A.AssetID = AU.AssetID "
        "JOIN dbo.DAP_Proc_Cntrl_Feed_Job_Execution E ON E.asset_id = A.AssetID "
        "WHERE F.FeedName = ? "
        "AND AU.StatusID = 200 AND E.close_job_dttm IS NOT NULL)"), (feedjobname)).fetchall()
            
  return max_asset

def get_unprocessed_assets(feedjobname):
  un_processed_files = cursor.execute(
    (
      "SELECT DISTINCT cast(A.AssetID as varchar) as AssetID,A.AssetName,A.AssetCurrentLocation "
      "FROM idfwba.Feed F JOIN idfwba.Asset A ON F.FeedID = A.FeedID "
      "JOIN idfwba.AssetStatus AU ON A.AssetID = AU.AssetID "
      "WHERE F.FeedName = ? "
      "AND AU.StatusID = 24014"), (feedjobname)).fetchall()
  
  return un_processed_files

def close_assets(close_asset,feed_name):
  test_val = close_asset.select('Asset_Id').rdd.flatMap(lambda x: x).collect()
  for i in test_val:
    cursor.execute(
      (
        '''UPDATE ATT
           SET ATT.StatusID = 200 
           FROM idfwba.Feed F JOIN idfwba.Asset A ON F.FeedID = A.FeedID
           JOIN idfwba.AssetStatus ATT ON ATT.AssetID = A.AssetID
           WHERE A.AssetID IN (?) AND F.FeedName   = ? '''
      ),(i,feed_name))
  cursor.commit()
  
def last_failed_job(job_name):
  failed_job = cursor.execute(
    (
      "SELECT TOP 1 SUBSTRING(CAST(Edw_batch_id AS VARCHAR),1,8) as Edw_batch_id FROM dbo.DAP_Proc_Cntrl_Pipeline_Run_Detail "
      "WHERE PipeLine_Name = ? "
      "AND Status_cd = -1 AND CAST(Start_dttm AS DATE) = CAST(DATEADD(D,-1,GETDATE()) AS DATE)"
      "ORDER BY Edw_batch_id DESC"
    ),(job_name)).fetchone()
  
  return failed_job

def send_notification(assets):
  
  import requests
  import json

  API_ENDPOINT = "https://dapuatdotnetappsrv-functionapp.azurewebsites.net/api/SendEmail"
  to = "dineshkumar.rajan@walgreens.com,oza.devang@walgreens.com,mohana.ramlingam@walgreens.com"

  body = json.dumps({"EmailFrom": "dineshkumar.rajan@walgreens.com", "EmailTo": to, "EmailSubject": pJob_Name + " Pipeline Failed", "EmailBody": "Unprocessed back dated files available for the feed " + pFeed_Name + "\n" + ",".join(assets.select('Asset_Name').rdd.flatMap(lambda x: x).collect()) + ". Manual catch up to be done.", "EmailAttachmentFilePath": ""})

  headers = {'Content-Type': 'application/json'}
#   print(body)
  response = requests.post(API_ENDPOINT, data=body, headers=headers)
  print(response)

# COMMAND ----------

def get_un_processed_assets(feed_name):
  un_processed_files = get_unprocessed_assets(feed_name)
  up_asset_id =[]
  up_asset_name=[]
  up_asset_filepath=[]
  for r in un_processed_files:
    up_asset_id.append(r[0])
    up_asset_name.append(r[1])
    up_asset_filepath.append(r[2])
  up_final_list = {'Asset_Id':up_asset_id,'Asset_Name':up_asset_name,'Asset_path':up_asset_filepath}

  up_df = pd.DataFrame(up_final_list)
#   up_asset_count = len(up_df)
  if len(up_df) > 0:
    up_df = spark.createDataFrame(up_df)
    df_1 = up_df.withColumn("src_file_date",split(up_df.Asset_Name,"_")[1][1:8])
    un_processed_asset = df_1.withColumn('file_date',to_date(col('src_file_date'),'yyyyMMdd'))
  else:
    raise Exception("No files available to process for the feed: " + feed_name)
#     un_processed_asset= df_1.withColumn('file_date',to_date(concat_ws('-',substring(df_1.src_file_date,1,4),substring(df_1.src_file_date,5,2),substring(df_1.src_file_date,7,2)),'y-M-d'))
  return un_processed_asset

# COMMAND ----------

def get_last_processed_asset(feed_name):
  processed_files = last_run_asset(feed_name)
  asset_id =[]
  asset_name=[]
  asset_filepath=[]
  for r in processed_files:
    asset_id.append(r[0])
    asset_name.append(r[1])
    asset_filepath.append(r[2])
  final_list = {'Asset_Id':asset_id,'Asset_Name':asset_name,'Asset_path':asset_filepath}

  dataframe_table = pd.DataFrame(final_list)
#   asset_count = len(dataframe_table)
  if len(dataframe_table) > 0:
    p_df = spark.createDataFrame(dataframe_table)
    p_df_1 = p_df.withColumn('src_file_date',split(p_df.Asset_Name,"_")[1][1:8])
    processed_asset = p_df_1.withColumn('file_date',to_date(col('src_file_date'),'yyyyMMdd'))
  else:
    raise Exception("All assets are processed for the feed: " + feed_name)
  return processed_asset

# COMMAND ----------

# get last run asset.
last_processed_asset = get_last_processed_asset(pFeed_Name)
# get all unprocessed files 
un_processed_assets = get_un_processed_assets(pFeed_Name) 
# create new column with last processed file date incremented by 1 day applicable only for regular run.
# for any manual catup run, catup run file date is passed.

last_failed_job_run = last_failed_job(pJob_Name)

# last_failed date
if last_failed_job_run != None and un_processed_assets.count() > 0 and len(pManual_Catch_Up_Date) != 10:
  if un_processed_assets.filter(un_processed_assets.src_file_date == last_failed_job_run[0]).count() > 0:
    raise Exception("Files arrived late, manual catch up to be done.")
#     send_notification(un_processed_assets)
  else:
    last_processed_asset_date = last_processed_asset.withColumn('nxt_file_date',date_add(to_date(lit(last_failed_job_run[0]),'yyyyMMdd'),1))
elif pManual_Catch_Up_Date != '':
  last_processed_asset_date = last_processed_asset.withColumn('nxt_file_date',lit(pManual_Catch_Up_Date))
else:
  last_processed_asset_date = last_processed_asset.withColumn('nxt_file_date',date_add(col('file_date'),1))

# COMMAND ----------

# file less than current date (backdated files)
back_dated_assets = un_processed_assets.select(col('Asset_Id')).filter(un_processed_assets.file_date < last_processed_asset_date.first()['nxt_file_date'])
# Multiple file for same day, sorted by asset desc
current_files = un_processed_assets.select(col('Asset_Id')).sort(col('Asset_Id').desc()).filter(un_processed_assets.file_date == last_processed_asset_date.first()['nxt_file_date'])

# COMMAND ----------

if current_files.count() > 1:
  # after sort by asset_id desc, except MAX asset files, mark other files assets  status to 200
  current_files_final = current_files.filter(current_files.Asset_Id < current_files.first()['Asset_Id']) 
  current_assets = back_dated_assets.union(current_files_final)  
  # close all the backdated & unprocessed multiple files status to 200
  close_assets(current_assets,pFeed_Name)
elif current_files.count() == 0 and back_dated_assets.count() > 0:
  close_assets(back_dated_assets,pFeed_Name)
  raise Exception("No files available to process for the feed: " + pFeed_Name)
else:
  close_assets(back_dated_assets,pFeed_Name)

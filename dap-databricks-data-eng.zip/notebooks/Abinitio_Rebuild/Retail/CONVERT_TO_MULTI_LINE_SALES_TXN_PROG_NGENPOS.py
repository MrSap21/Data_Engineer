# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove("PAR_OUTPUT_SCHEMA")

# COMMAND ----------

# DBTITLE 1,Setup
### NOTE: Type NUL or ␀ for \x00, Type SOH or  for \x01 or type your own delimiter e.g , | etc.

from pyspark.sql.functions import *
from pyspark.sql.types import *
import re

#dbutils.widgets.text("PAR_MNT_POINT", "")            # /mnt/wrangled
dbutils.widgets.text("PAR_INPUT_FILE_PATH", "")      # retail/retail_sales/staging/edw_idl_ngenpos_workstationloc/20220121054422 NOTE: This could be any location. 
dbutils.widgets.text("PAR_INPUT_FILE", "")           # edw_idl_ngenpos_workstationloc_20220207023508.dat
dbutils.widgets.text("PAR_NUM_COLS", "")             # 3
dbutils.widgets.text("PAR_DELIMITER", "")            # Type NUL or ␀ for \x00, Type SOH or  for \x01 or type your own delimiter e.g , | etc. 
dbutils.widgets.text("PAR_PARQUET_OUT_LOCATION", "") # retail/retail_sales/staging/edw_idl_ngenpos_workstationloc/20220121054422 NOTE: This could be any location. 
#dbutils.widgets.text("PAR_OUTPUT_SCHEMA", "")        # pcms_TransactionType,pcms_WorkstationLocation,wag_RFN
dbutils.widgets.text("PAR_RJECT_REC_PATH", "")        # path for the reject record

var_Input_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH')
var_Input_File = var_Input_File_Path + '/' + dbutils.widgets.get('PAR_INPUT_FILE') 
var_Converted_File_Path = var_Input_File_Path + '/' + 'converted_delimited' 
var_Converted_File = var_Converted_File_Path + '/' + 'MULTI_ROW_' + dbutils.widgets.get('PAR_INPUT_FILE')
var_Parquet_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_PARQUET_OUT_LOCATION')
var_num_cols = int(dbutils.widgets.get('PAR_NUM_COLS'))
var_Reject_File = mountPoint + '/' + dbutils.widgets.get('PAR_RJECT_REC_PATH')

#var_Input_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH')

#var_Parquet_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_PARQUET_OUT_LOCATION')


var_Get_Delimiter = dbutils.widgets.get('PAR_DELIMITER').strip()
# var_Delimiter = dbutils.widgets.get('PAR_DELIMITER').strip()

if var_Get_Delimiter == '␀' or var_Get_Delimiter == 'NUL': #'\x00':
    var_Delimiter = "Default_Nul_character"
elif var_Get_Delimiter == 'SOH' or var_Get_Delimiter == '': #\x01':
    var_Delimiter = ''
elif var_Get_Delimiter == '':
    dbutils.notebook.exit("No delimiter specified. \n Type NUL or ␀ for '\\x00', Type SOH or  for '\\x01' or type your own delimiter e.g , | etc.")
else:
    var_Delimiter = var_Get_Delimiter

# NOTE: by default nullable is being set to True in the output schema below
#       If you set it to False then it does a null check for all the columns.
#       For data set with millions of rows it ipacts the performance 
#       Since this conversion is for sanity testing so it's ok to set it to True

#var_Output_Schema = StructType(list(map(lambda fl : StructField(fl.strip(), StringType(),True), dbutils.widgets.get('PAR_OUTPUT_SCHEMA').split(',')))) 

# print(var_File_Path)
print('Input file is                          : ', var_Input_File)
print('Converted multi line delimited file is : ', var_Converted_File)
print('Converted Parquet file location is     : ', var_Parquet_File_Path)
print('Number of columns in file              : ', var_num_cols)
#print('Parquet schema for converted file      : ', var_Output_Schema)
print('Delimiter                              : ', var_Delimiter)
print('-----', bytes(var_Delimiter, 'utf-8'), '-----', var_Delimiter)
print('Reject path is                          : ', var_Reject_File)



# COMMAND ----------

# DBTITLE 1,Single Row File ==> Multi Row File -- Single delimiter
import os
""" 
  This code can handle large files of multi Gigs. 
  NOTE: This code will not work for non utf-8 encoded files.
        It will throw the following error 
        // UnicodeDecodeError: 'utf-8' codec can't decode byte 0xff in position 7742: invalid start byte //
"""
def read_In_Chunks(file_Obj, chunk_Size=8192):
    """
    Function to lazily read a file in small chunks instead of reading the entire file into memory.
    Default chunk size is 8kB. It can be overriden as 1024/2048/4096/8192 based on performance
    """
    while True:
        data = file_Obj.read(chunk_Size)
        if not data:
            break
        yield data

def process_file_chunk(chunk, num_cols):
    """
    Processes a file chunk and returns back any partial chunk which
    is incomplete to form a fully formed row based on the number of columns. 
    """
#   Handling NUL delimiter since it cannot be typed/copied in the browser
    if var_Delimiter == 'Default_Nul_character':
        chunk_list = chunk.split('\x00')
    else:
        chunk_list = chunk.split(var_Delimiter)
#     print(chunk_list)
    write_data_list = []
    begin_cols = 0
    num_of_sub_chunks = int(len(chunk_list)/num_cols)
    end_cols = num_cols
      
    for rowcount in range(num_of_sub_chunks - 1):
        """batch the writes to file for performance"""
        #   Handling NUL delimiter since it cannot be typed/copied in the browser
        if var_Delimiter == 'Default_Nul_character':
            write_data_list.append('\x00'.join(chunk_list[begin_cols:end_cols]))
        else:
            write_data_list.append(var_Delimiter.join(chunk_list[begin_cols:end_cols]))
        begin_cols += num_cols
        end_cols += num_cols
#         print(','.join(chunk_list[begin_cols:end_cols])) # -- uncomment for debugging
    output_File_Obj.writelines('\n'.join(write_data_list))
    output_File_Obj.write('\n')
    if len(chunk_list[begin_cols:]) > 0:
#         print('REMAINING partial DATA -->', ','.join(chunk_list[begin_cols:])) # -- uncomment for debugging
        #   Handling NUL delimiter since it cannot be typed/copied in the browser
        if var_Delimiter == 'Default_Nul_character':
            partial_chunk = '\x00'.join(chunk_list[begin_cols:])
        else:
            partial_chunk = var_Delimiter.join(chunk_list[begin_cols:])
        
    return partial_chunk

input_File_Obj = open(var_Input_File, 'r', encoding='unicode_escape')

if os.path.exists(var_Converted_File_Path) == False:
    os.mkdir(var_Converted_File_Path)
output_File_Obj = open(var_Converted_File, 'w')
partial_chunk = ''

for chunk in read_In_Chunks(input_File_Obj, None):
    file_chunk = partial_chunk + chunk 
    partial_chunk = process_file_chunk(file_chunk, var_num_cols)

if len(partial_chunk) > 0:
    output_File_Obj.writelines(partial_chunk)

input_File_Obj.close()
output_File_Obj.close()

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
#   if  len(lst1) > 6 and lst[6] == 'INSERT':
#     lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

def checkbad(val):
  key_list = val.split("\x00")
  val_len = len(key_list)
  
  if val_len > 95:
   return True
  
#   if 'INSERT' in key_list[6]:
#     if val_len != 43 :
#       return True
#   elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
#     if val_len != 44:
#       return True
  else:
    if val_len != 95:
      return True

# COMMAND ----------

# Read files
in_text = spark.read.text(var_Converted_File)
#in_text = in_text.withColumn("value", regexp_replace(in_text.value, '', '|')) #.drop("value")
#display(in_text)
print(in_text.count())

in_text = in_text.rdd

# # write bad data
rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  #display(df_junk)
  df_junk.write.mode('overwrite').parquet(var_Reject_File)

# COMMAND ----------

File =  'retail/retail_sales/staging/dap_idl_ngenpos_event/20220307044536'
currFile = mountPoint + '/' + File + '/'
print('currFile :'+currFile)

currDF =spark.read.format("parquet").load(currFile)  #.toDF(*Input_Schema)
#currDF = currDF.filter(currDF.nsf_dt.isNull())
display(currDF)

# COMMAND ----------

fieldList = ['row_length',            
             'RetailStoreID',
             'SequenceNumber',
             'DetailNumber',
             'ItemLink',
             'valcSubType',
             'wag_cardType',
             'wag_firstName',
             'wag_lookupSucessful',
             'wag_redemptionDisabled',
             'wag_pinpadOffline',
             'wag_idMethod',
             'wag_zipCodeBy',
             'wag_phoneBy',
             'wag_lastName',
             'wag_seqNum',
             'wag_limitApproved',
             'wag_limitNum',
             'wag_cardNumber',
             'wag_memberStatus',
             'wag_zipCode',
             'wag_loyaltyMbrId',
             'wag_phone',
             'wag_managerId',
             'wag_employeeId',
             'wag_verifyType',
             'wag_providedZipCode',
             'wag_actualZipCode',
             'wag_success',
             'wag_discInd',
             'wag_ServRecRewardPtsMgrAuth',
             'wag_BalanceRewardNumberOfpointsAwarded',
             'wag_BalanceRewardpointsAwarded',
             'wag_ServRecPercentangeAdjustmentMgrAuth',
             'wag_ServRecPercentageAdjApplied',
             'wag_ServRecGiftCardMgrAuth',
             'wag_ServRecGiftCardActivation',
             'wag_ManagerCashierNumber',
             'wag_ManagerEmpID',
             'pcms_BeginDateTime',
             'wag_patientId',
             'wag_languageUsed',
             'wag_numberOfOptOutWindowDisplayed',
             'wag_consentCaptureOutcome',
             'wag_timetakenForConsentCapture',
             'wag_RFN',
             'namespace',
             'valc',
             'wag_OnlineIndicator',
             'wag_programCode',
             'wag_optInOfferedType',
             'wag_PhoneNumber',
             'wag_SaleLookupStatus',
             'wag_MaskedPaymentCard',
             'wag_BalanceRewardCard',
             'wag_BalanceRewardCardNumber',
             'wag_LastName1',
             'wag_FirstName1',
             'wag_EmailID',
             'wag_EcommerceLookupStatus',
             'wag_openAcctType',
             'wag_dobBy',
             'wag_openAcctId',
             'wag_FillNumber',
             'wag_GovtFundIndicatorForPrimaryPlan',
             'wag_GovtFundIndicatorForCobPlan',
             'wag_PartialFillCode',
             'wag_conversion30dayTo90Day',
             'pcms_ApplicationEvent',
             'pcms_ItemLink',
             'wag_PinPadFunctional',
             'wag_EmvEnabled',
             'wag_ScriptID',
             'wag_Status',
             'wag_VerificationMode',
             'wag_NumberOfIncorrectAttempts',
             'wag_textEnrollmentCaptureOutcome',
             'wag_PointsRedeemed',
             'wag_TotalPointsEarned',
             'wag_additionalGMDCall',
             'wag_OrderNumber',
             'wag_Type',
             'wag_PickupLocation',
             'wag_LookupMethod',
             'wag_EPPId',
             'wag_InputMethod',
             'wag_Data',
             'wag_MemberId',
             'wag_WalletCardToken',
             'wag_Amount',
             'wag_PaymentToken',
             'wag_DeliveryType',
             'wag_AuthStatus',
             'wag_TxnId',
             'wag_RxNumber',
             'wag_RegisterType'            
            
     ]

# COMMAND ----------

#split and add schema
col_len = 95

rd1 = in_text.map(lambda rw: rw[0].split("\x00")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
#rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 44
#print(f"Bad records count {rd_bad.count()}") # != 28


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)
df = df.drop("row_length")
display(df)

# COMMAND ----------

df.write.mode('overwrite').parquet(var_Parquet_File_Path)

# COMMAND ----------

# DBTITLE 1,Multi Row Delimited ==> Parquet
# """ Convert to parquet"""
#    Handling NUL delimiter since it cannot be typed/copied in the browser
# if var_Delimiter == 'Default_Nul_character':
#     df = spark.read.format("csv").option("delimiter", "\x00").option("inferSchema","true").schema(var_Output_Schema).load(var_Converted_File)
# else:
#     df = spark.read.format("csv").option("delimiter", var_Delimiter).option("inferSchema","true").schema(var_Output_Schema).load(var_Converted_File)

# df.write.format("parquet").mode("overwrite").save(var_Parquet_File_Path)
# print("Parquet file:", var_Parquet_File_Path)
# df.count() 

# COMMAND ----------

# df = spark.read.parquet(var_Parquet_File_Path)
# print("Parquet file:", var_Parquet_File_Path)
# df.take(3)
# df.printSchema()

# COMMAND ----------


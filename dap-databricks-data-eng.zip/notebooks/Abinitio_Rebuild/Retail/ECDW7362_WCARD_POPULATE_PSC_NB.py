# Databricks notebook source
# #Widgets for passing required parameters values

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220427072901")
# #dbutils.widgets.text("PAR_INPUT_FILELIST","{'RXC_PSC_ACCOUNT_dat': {'assetid': 5210, 'assetname': 'RXC_PSC_ACCOUNT_20220424190929.dat', 'assetcurrentlocation': 'pharmacy_healthcare/patient_services/psc/2022/04/26/'}}")
# dbutils.widgets.text("PAR_INPUT_FILENAME","RXC_PSC_ACCOUNT_20220424190929.dat")
# dbutils.widgets.text("PAR_INPUT_FILEPATH","pharmacy_healthcare/patient_services/psc/2022/04/26/")
# dbutils.widgets.text("PAR_FEED_NAME","RXC_PSC_ACCOUNT_dat")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_REJECT_FOLDER","retail/retail_sales/reject")
# dbutils.widgets.text("PAR_PSC_CREATEDTTM_LKP_FILE","wcard_psc_create_dttm_lkp")
# dbutils.widgets.text("PAR_PSC_EVENTTYPE_LKP_FILE","wcard_psc_event_type_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_PSC_TYPE_LKP_FILE","wcard_psc_type_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_PSC_PAIDCD_LKP_FILE","wcard_psc_paid_cd_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_PSC_STATUSCD_LKP_FILE","wcard_psc_status_code_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_PSC_RELCD_LKP_FILE","wcard_psc_relation_cd_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_PSC_SRCSYSCD_LKP_FILE","wcard_source_system_code_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_PSC_SRCREJ_FILE","ECDW7362_PSC_SOURCE.rej")
# dbutils.widgets.text("PAR_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_SNFK_DB1","DEV_STAGING")
# dbutils.widgets.text("PAR_SNFK_DB2","DEV_RETAIL")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_PSC_CARD_HLDR_STG")
# dbutils.widgets.text("PAR_SNFK_TBL2","RETAIL_SALES.WCARD_PSC_CARD_HLDR_ADDR_STG")
# dbutils.widgets.text("PAR_SNFK_TBL3","RETAIL_SALES.WCARD_CARDHOLDER")
# dbutils.widgets.text("PAR_SNFK_TBL4","RETAIL_SALES.WCARD_CARDHOLDER_ADDRESS")
# dbutils.widgets.text("PAR_SNFK_TBL5","RETAIL_SALES.WCARD_PSC_EVENT")
# dbutils.widgets.text("PAR_OUTPUT_WCARDHLDR_FILE","wcard_psc_cardholder")
# dbutils.widgets.text("PAR_OUTPUT_WCARDHLDRNAME_FILE","wcard_psc_cardholder_name")
# dbutils.widgets.text("PAR_OUTPUT_WCARDHLDRADDRESS_FILE","wcard_psc_cardholder_address")
# dbutils.widgets.text("PAR_OUTPUT_WCARDHLDRCNTCT_FILE","wcard_psc_cardholder_contact")
# dbutils.widgets.text("PAR_OUTPUT_WCARDACNT_HLDR_FILE","wcard_psc_account_cardholder")
# dbutils.widgets.text("PAR_OP_WCRDHLDR_UNLOAD","ECDW7362_wcard_cardholder_unload")
# dbutils.widgets.text("PAR_OP_WCRDHLDR_ADD_UNLOAD","ECDW7362_wcard_cardholder_address_unload")
# dbutils.widgets.text("PAR_OUTPUT_WCARDADDRSTND_RES_FILE","wcard_psc_addr_stand_result")
# dbutils.widgets.text("PAR_OUTPUT_WCARD_PSCEVNT_FILE","wcard_psc_event")
# dbutils.widgets.text("PAR_OUTPUT_WCARD_PSCDTL_FILE","wcard_psc_dtl")

# COMMAND ----------

#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
#Input_File_List = dbutils.widgets.get("PAR_INPUT_FILELIST")
Input_File_Name = dbutils.widgets.get("PAR_INPUT_FILENAME")
Input_File_Path = dbutils.widgets.get("PAR_INPUT_FILEPATH")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
PscCreatedttm_LKPFile = dbutils.widgets.get("PAR_PSC_CREATEDTTM_LKP_FILE")
PscEventType_LKPFile = dbutils.widgets.get("PAR_PSC_EVENTTYPE_LKP_FILE")
PscType_LKPFile = dbutils.widgets.get("PAR_PSC_TYPE_LKP_FILE")
PscPaidCd_LKPFile = dbutils.widgets.get("PAR_PSC_PAIDCD_LKP_FILE")
PscStatusCd_LKPFile = dbutils.widgets.get("PAR_PSC_STATUSCD_LKP_FILE")
PscRelCd_LKPFile = dbutils.widgets.get("PAR_PSC_RELCD_LKP_FILE")
PscSrcSysCd_LKPFile = dbutils.widgets.get("PAR_PSC_SRCSYSCD_LKP_FILE")
PscSrcRejFile = dbutils.widgets.get("PAR_PSC_SRCREJ_FILE")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_DB2 = dbutils.widgets.get("PAR_SNFK_DB2")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
SNFL_TBL_NAME2 = dbutils.widgets.get("PAR_SNFK_TBL2")
SNFL_TBL_NAME3 = dbutils.widgets.get("PAR_SNFK_TBL3")
SNFL_TBL_NAME4 = dbutils.widgets.get("PAR_SNFK_TBL4")
SNFL_TBL_NAME5 = dbutils.widgets.get("PAR_SNFK_TBL5")
WCardHldrOutFile1 = dbutils.widgets.get("PAR_OUTPUT_WCARDHLDR_FILE")
WCardHldrNameOutFile2 = dbutils.widgets.get("PAR_OUTPUT_WCARDHLDRNAME_FILE")
WCardHldrAddressOutFile3 = dbutils.widgets.get("PAR_OUTPUT_WCARDHLDRADDRESS_FILE")
WCardHldrContactOutFile4 = dbutils.widgets.get("PAR_OUTPUT_WCARDHLDRCNTCT_FILE")
WCardAccCardHldrOutFile5 = dbutils.widgets.get("PAR_OUTPUT_WCARDACNT_HLDR_FILE")
WCardCardHldrUnloadFile1 = dbutils.widgets.get("PAR_OP_WCRDHLDR_UNLOAD")
WCardCardHldrAddUnloadFile2 = dbutils.widgets.get("PAR_OP_WCRDHLDR_ADD_UNLOAD")
WCardAddrStandResOutFile6 = dbutils.widgets.get("PAR_OUTPUT_WCARDADDRSTND_RES_FILE")
WCardPscEvntOutFile7 = dbutils.widgets.get("PAR_OUTPUT_WCARD_PSCEVNT_FILE")
WCardPscDtlOutFile8 = dbutils.widgets.get("PAR_OUTPUT_WCARD_PSCDTL_FILE")

# COMMAND ----------

#Fetching Effective Date from Source file name:
EFF_DT = Input_File_Name
if len(EFF_DT)!=0:
  EFF_DT = (EFF_DT).split("_")
  if len(EFF_DT)==5:
    EFF_DT = EFF_DT[-2][:8]
  elif len(EFF_DT)==4:
    EFF_DT = EFF_DT[-1][:8]

EFF_DT = EFF_DT[:4]+"-"+EFF_DT[4:6]+"-"+EFF_DT[6:]  
print("EFF_DT : {}".format(EFF_DT))    

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

pscCreateDttmLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscCreatedttm_LKPFile) \
.withColumn("create_dttm_key",col("_c0")) \
.withColumn("create_dttm",date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss")).select("create_dttm_key","create_dttm")

#display(pscCreateDttmLkpDF)

pscCreateDttmLkpDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+"wcard_psc_create_dttm_lkp1")

# COMMAND ----------

#Defining schema for RXC_PSC_ACCOUNT source file:
Source_Schema = ['WCARD_ID',
'WCARD_ID_POS',
'WCARD_RELATION_CD',
'WCARD_FIRST_NAME',
'WCARD_MID_INIT',
'WCARD_LAST_NAME',
'WCARD_SURNAME_SUFFIX',
'WCARD_SEX_CD',
'WCARD_BIRTH_DTTM',
'WCARD_STREET_ADDR',
'WCARD_APT_NBR',
'WCARD_CITY',
'WCARD_STATE',
'WCARD_ZIP',
'WCARD_AREA_CD',
'WCARD_PHONE',
'WCARD_EMAIL_ADDRESS',
'WCARD_COVERAGE_TYPE',
'WCARD_MKT_IND',
'CREATE_STORE_NBR',
'CREATE_DTTM',
'UPDATE_STORE_NBR',
'UPDATE_DTTM',
'WCARD_SENT_DTTM',
'WCARD_STATUS',
'WCARD_ACTION',
'CREATED_BY',
'UPDATED_BY',
'TERM_DTTM',
'RENEWAL_DTTM',
'UPGRADE_DTTM',
'PAID_IND',
'PAID_DTTM',
'PLAN_TYPE',
'BATCH_RUN_FLAG',
'ENROLL_EMP_ID',
'RENEW_EMP_ID',
'ADDRESS_VALID_IND',
'ANCHOR_RETURN_CODE',
'PAT_ID']

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema)))
#print(schema)

# Format in EDW std & Load Staging:

RxcPscAccSrcDF = spark.read.format("csv").option("delimiter","\x01").schema(schema).load(mountPoint+"/"+Input_File_Path+"/"+Input_File_Name)

# Read LookUp Files:
#1. wcard_psc_event_type_ascii.pipe_delim_lkp:
pscEventTypeLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscEventType_LKPFile) \
.withColumnRenamed("_c0","psc_mbr_event_type") \
.withColumnRenamed("_c1","psc_mbr_event_type_desc")

#display(pscEventTypeLkpDF)

#2. wcard_psc_type_ascii.pipe_delim_lkp:
pscTypeLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscType_LKPFile) \
.withColumnRenamed("_c0","psc_mbr_type") \
.withColumnRenamed("_c1","psc_mbr_type_desc")

#display(pscTypeLkpDF)

#3. wcard_psc_paid_cd_ascii.pipe_delim_lkp:
pscPaidCdLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscPaidCd_LKPFile) \
.withColumnRenamed("_c0","psc_mbr_paid_cd") \
.withColumnRenamed("_c1","psc_mbr_paid_desc")

#display(pscPaidCdLkpDF)

#4. wcard_psc_status_code_ascii.pipe_delim_lkp:
pscStatusCdLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscStatusCd_LKPFile) \
.withColumnRenamed("_c0","psc_wcard_stat_cd") \
.withColumnRenamed("_c1","psc_wcard_stat_desc")

#display(pscStatusCdLkpDF)

#5. wcard_psc_relation_cd_ascii.pipe_delim_lkp:
pscRelationCdLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscRelCd_LKPFile) \
.withColumnRenamed("_c0","psc_mbr_relation_cd") \
.withColumnRenamed("_c1","psc_mbr_relation_desc")

#display(pscRelationCdLkpDF)

#6. wcard_source_system_code_ascii.pipe_delim_lkp:
pscSrcSysCdLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_Folder+"/"+PscSrcSysCd_LKPFile) \
.withColumnRenamed("_c0","src_sys_cd") \
.withColumnRenamed("_c1","src_sys_desc")

#display(pscSrcSysCdLkpDF)

#7. wcard_psc_create_dttm_lkp:
pscCreateDttmLkpDF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+"wcard_psc_create_dttm_lkp1")
#display(pscCreateDttmLkpDF)

#Filter Valid Codes from Source:

RxcPscAccFilterDF = RxcPscAccSrcDF.join(pscEventTypeLkpDF,RxcPscAccSrcDF.PLAN_TYPE == pscEventTypeLkpDF.psc_mbr_event_type,"left_outer")
RxcPscAccFilterDF = RxcPscAccFilterDF.join(pscPaidCdLkpDF,RxcPscAccFilterDF.PAID_IND == pscPaidCdLkpDF.psc_mbr_paid_cd,"left_outer") 
RxcPscAccFilterDF = RxcPscAccFilterDF.join(pscRelationCdLkpDF,RxcPscAccFilterDF.WCARD_RELATION_CD == pscRelationCdLkpDF.psc_mbr_relation_cd,"left_outer") 
RxcPscAccFilterDF = RxcPscAccFilterDF.join(pscStatusCdLkpDF,RxcPscAccFilterDF.WCARD_STATUS == pscStatusCdLkpDF.psc_wcard_stat_cd,"left_outer")
RxcPscAccFilterDF = RxcPscAccFilterDF.join(pscTypeLkpDF,RxcPscAccFilterDF.WCARD_COVERAGE_TYPE == pscTypeLkpDF.psc_mbr_type,"left_outer")

#display(RxcPscAccFilterDF)

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------

RxcPscAccFilterDF1 = RxcPscAccFilterDF.filter(((RxcPscAccFilterDF.PLAN_TYPE!="") & ((RxcPscAccFilterDF.psc_mbr_event_type!="") & (RxcPscAccFilterDF.psc_mbr_event_type.isNotNull())) | (RxcPscAccFilterDF.PLAN_TYPE.isNull())) & ((RxcPscAccFilterDF.PAID_IND!="") & ((RxcPscAccFilterDF.psc_mbr_paid_cd!="") & (RxcPscAccFilterDF.psc_mbr_paid_cd.isNotNull())) | (RxcPscAccFilterDF.PAID_IND.isNull())) & ((RxcPscAccFilterDF.psc_mbr_relation_cd!="") & (RxcPscAccFilterDF.psc_mbr_relation_cd.isNotNull())) & ((RxcPscAccFilterDF.psc_wcard_stat_cd!="") & (RxcPscAccFilterDF.psc_wcard_stat_cd.isNotNull())) & ((RxcPscAccFilterDF.psc_mbr_type!="") & (RxcPscAccFilterDF.psc_mbr_type.isNotNull())))

#Reject from PSC Source:
RxcPscAccFilterRejDF = RxcPscAccFilterDF.subtract(RxcPscAccFilterDF1)

#display(RxcPscAccFilterRejDF)
#print(RxcPscAccFilterRejDF.count())

RxcPscAccFilterRejDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Reject_Folder+"/"+PscSrcRejFile+"/"+Batch_id)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

from pyspark.sql.window import Window

#Reformat to EDW field names:
var_src_sys_cd = pscSrcSysCdLkpDF.filter(pscSrcSysCdLkpDF.src_sys_desc=="prescription savings club").select("src_sys_cd").collect()

if len(var_src_sys_cd)!=0:
  var_src_sys_cd = var_src_sys_cd[0].src_sys_cd
else:
  var_src_sys_cd = None
  
#print(var_src_sys_cd)

var_create_dttm = pscCreateDttmLkpDF.filter(pscCreateDttmLkpDF.create_dttm_key=="Create_DTTM").select("create_dttm").collect()

if len(var_create_dttm)!=0:
  var_create_dttm = var_create_dttm[0].create_dttm
else:
  var_create_dttm = None

#print(var_create_dttm)

RfmtEdwFieldNamesDF = RxcPscAccFilterDF1.withColumn("card_hldr_id",RxcPscAccFilterDF1.WCARD_ID) \
.withColumn("acct_id",RxcPscAccFilterDF1.WCARD_ID_POS) \
.withColumn("psc_mbr_relation_cd",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_RELATION_CD))) \
.withColumn("first_name",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_FIRST_NAME))) \
.withColumn("mid_name",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_MID_INIT))) \
.withColumn("last_name",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_LAST_NAME))) \
.withColumn("card_hldr_sufx",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_SURNAME_SUFFIX))) \
.withColumn("gndr",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_SEX_CD))) \
.withColumn("brth_dt",RxcPscAccFilterDF1.WCARD_BIRTH_DTTM) \
.withColumn("addr_line_1",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_STREET_ADDR))) \
.withColumn("addr_line_2",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_APT_NBR))) \
.withColumn("city_name",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_CITY))) \
.withColumn("state_cd",ltrim(rtrim(RxcPscAccFilterDF1.WCARD_STATE))) \
.withColumn("zip_cd_5",when((RxcPscAccFilterDF1.WCARD_ZIP!="") & (RxcPscAccFilterDF1.WCARD_ZIP.isNotNull()),substring(rtrim(ltrim(RxcPscAccFilterDF1.WCARD_ZIP)),1,5))
           .otherwise(lit(None))) \
.withColumn("zip_cd_4",when((substring(rtrim(ltrim(RxcPscAccFilterDF1.WCARD_ZIP)),6,4))=="0000","0000").when((RxcPscAccFilterDF1.WCARD_ZIP!="") & (RxcPscAccFilterDF1.WCARD_ZIP.isNotNull()),substring(rtrim(ltrim(RxcPscAccFilterDF1.WCARD_ZIP)),-4,4)).otherwise(lit(None))) \
.withColumn("phone_number",concat(rtrim(ltrim(RxcPscAccFilterDF1.WCARD_AREA_CD)),rtrim(ltrim(RxcPscAccFilterDF1.WCARD_PHONE)))) \
.withColumn("email_address",rtrim(ltrim(RxcPscAccFilterDF1.WCARD_EMAIL_ADDRESS))) \
.withColumn("psc_mbr_type",RxcPscAccFilterDF1.WCARD_COVERAGE_TYPE)  \
.withColumn("mktg_opt_in_ind",rtrim(ltrim(RxcPscAccFilterDF1.WCARD_MKT_IND))) \
.withColumn("card_send_dt",when((RxcPscAccFilterDF1.WCARD_SENT_DTTM.isNotNull()) & (RxcPscAccFilterDF1.WCARD_SENT_DTTM!=""),substring(RxcPscAccFilterDF1.WCARD_SENT_DTTM,1,8)).otherwise(lit(None))) \
.withColumn("card_send_tm",when((RxcPscAccFilterDF1.WCARD_SENT_DTTM.isNotNull()) & (RxcPscAccFilterDF1.WCARD_SENT_DTTM!=""),substring(RxcPscAccFilterDF1.WCARD_SENT_DTTM,-8,8)).otherwise(lit(None))) \
.withColumn("psc_wcard_stat_cd",rtrim(ltrim(RxcPscAccFilterDF1.WCARD_STATUS))) \
.withColumn("internal_actn_cd",rtrim(ltrim(RxcPscAccFilterDF1.WCARD_ACTION))) \
.withColumn("mbr_term_dt",when((RxcPscAccFilterDF1.TERM_DTTM.isNotNull()) & (RxcPscAccFilterDF1.TERM_DTTM!=""),substring(RxcPscAccFilterDF1.TERM_DTTM,1,8)).otherwise(lit(None))) \
.withColumn("mbr_term_tm",when((RxcPscAccFilterDF1.TERM_DTTM.isNotNull()) & (RxcPscAccFilterDF1.TERM_DTTM!=""),substring(RxcPscAccFilterDF1.TERM_DTTM,-8,8)).otherwise(lit(None))) \
.withColumn("psc_mbr_paid_cd",rtrim(ltrim(RxcPscAccFilterDF1.PAID_IND))) \
.withColumn("psc_paid_dt",when((RxcPscAccFilterDF1.PAID_DTTM.isNotNull()) & (RxcPscAccFilterDF1.PAID_DTTM!=""),substring(RxcPscAccFilterDF1.PAID_DTTM,1,8)).otherwise(lit(None))) \
.withColumn("psc_paid_tm",when((RxcPscAccFilterDF1.PAID_DTTM.isNotNull()) & (RxcPscAccFilterDF1.PAID_DTTM!=""),substring(RxcPscAccFilterDF1.PAID_DTTM,-8,8)).otherwise(lit(None))) \
.withColumn("psc_mbr_event_type",rtrim(ltrim(RxcPscAccFilterDF1.PLAN_TYPE))) \
.withColumn("batch_run_cd",rtrim(ltrim(RxcPscAccFilterDF1.BATCH_RUN_FLAG))) \
.withColumn("vld_addr_ind",rtrim(ltrim(RxcPscAccFilterDF1.ADDRESS_VALID_IND))) \
.withColumn("addr_stand_return_cd",rtrim(ltrim(RxcPscAccFilterDF1.ANCHOR_RETURN_CODE))) \
.withColumn("psc_mbr_event_dt",when(((RxcPscAccFilterDF1.PLAN_TYPE=="E") & (RxcPscAccFilterDF1.UPDATE_DTTM!="")),substring(RxcPscAccFilterDF1.UPDATE_DTTM,1,8)).when(((RxcPscAccFilterDF1.PLAN_TYPE=="R") & (RxcPscAccFilterDF1.RENEWAL_DTTM!="")),substring(RxcPscAccFilterDF1.RENEWAL_DTTM,1,8)).when(((RxcPscAccFilterDF1.PLAN_TYPE=="U") & (RxcPscAccFilterDF1.UPGRADE_DTTM!="")),substring(RxcPscAccFilterDF1.UPGRADE_DTTM,1,8)).when(((RxcPscAccFilterDF1.PLAN_TYPE=="C") & (RxcPscAccFilterDF1.UPDATE_DTTM!="")),substring(RxcPscAccFilterDF1.UPDATE_DTTM,1,8)).when(((RxcPscAccFilterDF1.PLAN_TYPE=="X") & (RxcPscAccFilterDF1.UPDATE_DTTM!="")),substring(RxcPscAccFilterDF1.UPDATE_DTTM,1,8)).when(((RxcPscAccFilterDF1.PLAN_TYPE=="X") & (RxcPscAccFilterDF1.CREATE_DTTM!="")),substring(RxcPscAccFilterDF1.CREATE_DTTM,1,8)).otherwise(substring(RxcPscAccFilterDF1.UPDATE_DTTM,1,8))) \
.withColumn("psc_mbr_event_tm",when(((RxcPscAccFilterDF1.PLAN_TYPE=="E") & (RxcPscAccFilterDF1.UPDATE_DTTM!="")),RxcPscAccFilterDF1.UPDATE_DTTM).when(((RxcPscAccFilterDF1.PLAN_TYPE=="R") & (RxcPscAccFilterDF1.RENEWAL_DTTM!="")),RxcPscAccFilterDF1.RENEWAL_DTTM).when(((RxcPscAccFilterDF1.PLAN_TYPE=="U") & (RxcPscAccFilterDF1.UPGRADE_DTTM!="")),RxcPscAccFilterDF1.UPGRADE_DTTM).when(((RxcPscAccFilterDF1.PLAN_TYPE=="C") & (RxcPscAccFilterDF1.UPDATE_DTTM!="")),RxcPscAccFilterDF1.UPDATE_DTTM).when(((RxcPscAccFilterDF1.PLAN_TYPE=="X") & (RxcPscAccFilterDF1.UPDATE_DTTM!="")),RxcPscAccFilterDF1.UPDATE_DTTM).when(((RxcPscAccFilterDF1.PLAN_TYPE=="X") & (RxcPscAccFilterDF1.CREATE_DTTM!="")),RxcPscAccFilterDF1.CREATE_DTTM).otherwise(RxcPscAccFilterDF1.UPDATE_DTTM)) \
.withColumn("authenticator_id",when(((RxcPscAccFilterDF1.UPDATED_BY!="") & (RxcPscAccFilterDF1.UPDATED_BY.isNotNull())),rtrim(ltrim(RxcPscAccFilterDF1.UPDATED_BY))).otherwise(RxcPscAccFilterDF1.CREATED_BY)) \
.withColumn("emp_id",when(((RxcPscAccFilterDF1.PLAN_TYPE=="E") | (RxcPscAccFilterDF1.PLAN_TYPE=="U") | (RxcPscAccFilterDF1.PLAN_TYPE=="C")),RxcPscAccFilterDF1.ENROLL_EMP_ID).when(RxcPscAccFilterDF1.PLAN_TYPE=="R",RxcPscAccFilterDF1.RENEW_EMP_ID).when(((RxcPscAccFilterDF1.PLAN_TYPE=="X") & (RxcPscAccFilterDF1.ENROLL_EMP_ID!="")),RxcPscAccFilterDF1.ENROLL_EMP_ID).when(((RxcPscAccFilterDF1.PLAN_TYPE=="X") & (RxcPscAccFilterDF1.RENEW_EMP_ID!="")),RxcPscAccFilterDF1.RENEW_EMP_ID).otherwise(lit(None))) \
.withColumn("psc_event_location_nbr",when((RxcPscAccFilterDF1.UPDATE_STORE_NBR!=""),RxcPscAccFilterDF1.UPDATE_STORE_NBR).when(((RxcPscAccFilterDF1.PLAN_TYPE!="") & (RxcPscAccFilterDF1.UPDATE_STORE_NBR!="") & (RxcPscAccFilterDF1.CREATE_STORE_NBR!="")),RxcPscAccFilterDF1.CREATE_STORE_NBR).otherwise(lit(None))) \
.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("create_dttm",lit(var_create_dttm)) \
.withColumn("eff_dt",current_date()) \
.withColumn("end_dt",lit(None))

RfmtEdwFieldNamesDF = RfmtEdwFieldNamesDF.select("card_hldr_id","acct_id","psc_mbr_relation_cd","first_name","mid_name","last_name","card_hldr_sufx","gndr","brth_dt","addr_line_1","addr_line_2","city_name","state_cd","zip_cd_5","zip_cd_4","phone_number","email_address","psc_mbr_type","mktg_opt_in_ind","psc_event_location_nbr","card_send_dt","card_send_tm","psc_wcard_stat_cd","internal_actn_cd","authenticator_id","mbr_term_dt","mbr_term_tm","psc_mbr_event_dt","psc_mbr_event_tm","psc_mbr_paid_cd","psc_paid_dt","psc_paid_tm","psc_mbr_event_type","batch_run_cd","emp_id","vld_addr_ind","addr_stand_return_cd","src_sys_cd","create_dttm","eff_dt","end_dt")

#Sort on Card Holder ID and Dedup Sorted Card Holder ID:
RfmtSortHolderIdDF = RfmtEdwFieldNamesDF.select("*", row_number().over(Window.partitionBy("card_hldr_id").orderBy(RfmtEdwFieldNamesDF['card_hldr_id'])).alias("row_num")) 
RfmtSortHolderIdDF1 = RfmtSortHolderIdDF.filter(RfmtSortHolderIdDF.row_num ==1).drop("row_num")

#display(RfmtSortHolderIdDF1)

#1. Reformat in Staging Format to load wcard_psc_card_hldr_stg table:

wcardPscCardHldrStgDF = RfmtSortHolderIdDF1.withColumn("brth_dt",to_date(concat(substring(RfmtSortHolderIdDF1.brth_dt,1,4),lit("-"),substring(RfmtSortHolderIdDF1.brth_dt,5,2),lit("-"),substring(RfmtSortHolderIdDF1.brth_dt,7,2)))).select("card_hldr_id","src_sys_cd","brth_dt")

#display(wcardPscCardHldrStgDF)

#2. Reformat in EDW Format:

RfmtEdwFormatDF = RfmtSortHolderIdDF1.select("*")
#RfmtEdwFormatDF.printSchema()
#display(RfmtEdwFormatDF)

#3. Reformat in Staging Format to load wcard_psc_card_hldr_addr_stg table:

wcardPscCardHldrAddrStgDF = RfmtSortHolderIdDF1.withColumn("addr_type_cd",lit("CON")).select("card_hldr_id","src_sys_cd","state_cd","city_name","addr_line_1","addr_line_2","addr_type_cd","zip_cd_5","zip_cd_4")

#display(wcardPscCardHldrAddrStgDF)

# COMMAND ----------

#writing the above DF's to WCARD_PSC_CARD_HLDR_STG and WCARD_PSC_CARD_HLDR_ADDR_STG Tables:

#1. For WCARD_PSC_CARD_HLDR_STG:
delete_WCARD_PSC_CARD_HLDRstg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB1, SNFL_TBL_NAME1)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_WCARD_PSC_CARD_HLDRstg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB1,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

wcardPscCardHldrStgDF.cache()
wcardPscCardHldrStgDF.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB1) \
        .option("dbtable", SNFL_TBL_NAME1) \
        .option("continue_on_error","on")\
        .save()

#2. For WCARD_PSC_CARD_HLDR_ADDR_STG:
delete_WCARD_PSC_CARD_HLDR_ADDRstg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB1, SNFL_TBL_NAME2)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_WCARD_PSC_CARD_HLDR_ADDRstg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB1,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

wcardPscCardHldrAddrStgDF.cache()
wcardPscCardHldrAddrStgDF.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB1) \
        .option("dbtable", SNFL_TBL_NAME2) \
        .option("continue_on_error","on")\
        .save()

# COMMAND ----------

#Normalize for PSC Events:

#Filter NULL Plan Types and Enrollment Plan:

NormalizePscEventsDF = RxcPscAccFilterDF1.filter((RxcPscAccFilterDF1.PLAN_TYPE=="") | (RxcPscAccFilterDF1.PLAN_TYPE.isNull()) |(RxcPscAccFilterDF1.PLAN_TYPE == "E"))

NormalizePscEventsDeselectDF = RxcPscAccFilterDF1.subtract(NormalizePscEventsDF)

#Filter Enrollment:
FilterEnrollDF = NormalizePscEventsDF.filter(RxcPscAccFilterDF1.PLAN_TYPE == "E")

FilterEnrollDeselectDF = NormalizePscEventsDF.subtract(FilterEnrollDF)

#Process Enrollment Records:
#Normalize for three Event Types - E/U/R:

arr = array(lit(0),lit(1),lit(2))

NormalizeEURDF = FilterEnrollDF.withColumn("index",arr).withColumn("index",explode(col("index")))

NormalizeEURDF1 = NormalizeEURDF.withColumn("PLAN_TYPE",when(NormalizeEURDF.index==0,"E").when(NormalizeEURDF.index==1,"R").when(NormalizeEURDF.index==2,"U")) \
.withColumn("UPDATE_DTTM",when(NormalizeEURDF.index==0,NormalizeEURDF.CREATE_DTTM).when(((NormalizeEURDF.index==1) & ((NormalizeEURDF.RENEWAL_DTTM.isNotNull()) & (NormalizeEURDF.RENEWAL_DTTM!=""))),NormalizeEURDF.RENEWAL_DTTM).when(((NormalizeEURDF.index==1) & ((NormalizeEURDF.RENEWAL_DTTM.isNull()) | (NormalizeEURDF.RENEWAL_DTTM==""))),NormalizeEURDF.UPDATE_DTTM).when(NormalizeEURDF.index==2,NormalizeEURDF.UPGRADE_DTTM)) \
.withColumn("UPDATE_STORE_NBR",when(NormalizeEURDF.index==0,NormalizeEURDF.CREATE_STORE_NBR).when(NormalizeEURDF.index==1,NormalizeEURDF.UPDATE_STORE_NBR).when(NormalizeEURDF.index==2,NormalizeEURDF.UPDATE_STORE_NBR)) \
.withColumn("UPDATED_BY",when(NormalizeEURDF.index==0,NormalizeEURDF.CREATED_BY).when(NormalizeEURDF.index==1,NormalizeEURDF.UPDATED_BY).when(NormalizeEURDF.index==2,NormalizeEURDF.UPDATED_BY)) \
.withColumn("originated_record",when(NormalizeEURDF.index==0,lit("N")).when(NormalizeEURDF.index==1,lit("Y")).when(NormalizeEURDF.index==2,lit("Y")))
#display(NormalizeEURDF1)

#Process Renewal and Upgrade for Enrollment Category:

#Filter Renewal-1:
FilterRenewalDF = NormalizeEURDF1.filter(NormalizeEURDF1.PLAN_TYPE=="R")

FilterRenewalDeselectDF = NormalizeEURDF1.subtract(FilterRenewalDF)

#Filter Original Rcords from source:
FilterOrgRecrdsDF = FilterRenewalDF.filter((FilterRenewalDF.originated_record=="N") & ((FilterRenewalDF.RENEWAL_DTTM=="") | (FilterRenewalDF.RENEWAL_DTTM.isNull())))

FilterOrgRecrdsDeselectDF = FilterRenewalDF.subtract(FilterOrgRecrdsDF)

#Reformat-  to modify NULL Renewal DTTM:
RfmtModifyNullRenewalDF = FilterOrgRecrdsDF.withColumn("RENEWAL_DTTM",FilterOrgRecrdsDF.UPDATE_DTTM) \
.withColumn("UPDATE_DTTM",FilterOrgRecrdsDF.UPDATE_DTTM) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Filter Valid Plan and timestamp fields-1:
FilterValidPlanDF = FilterOrgRecrdsDeselectDF.filter(((FilterOrgRecrdsDeselectDF.PLAN_TYPE.isNotNull()) & (FilterOrgRecrdsDeselectDF.PLAN_TYPE!="")) & (((FilterOrgRecrdsDeselectDF.PLAN_TYPE=="E") & ((FilterOrgRecrdsDeselectDF.CREATE_DTTM!="") & (FilterOrgRecrdsDeselectDF.CREATE_DTTM.isNotNull()))) | ((FilterOrgRecrdsDeselectDF.PLAN_TYPE=="R") & ((FilterOrgRecrdsDeselectDF.RENEWAL_DTTM!="") & (FilterOrgRecrdsDeselectDF.RENEWAL_DTTM.isNotNull()))) | ((FilterOrgRecrdsDeselectDF.PLAN_TYPE=="U") & ((FilterOrgRecrdsDeselectDF.UPGRADE_DTTM!="") & (FilterOrgRecrdsDeselectDF.UPGRADE_DTTM.isNotNull()))) | ((FilterOrgRecrdsDeselectDF.PLAN_TYPE=="C") & ((FilterOrgRecrdsDeselectDF.UPDATE_DTTM!="") & (FilterOrgRecrdsDeselectDF.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Gather-1:
GatherDF1 = RfmtModifyNullRenewalDF.union(FilterValidPlanDF)

# COMMAND ----------

#Filter Upgrade:
FilterUpgradeDF = FilterRenewalDeselectDF.filter(FilterRenewalDeselectDF.PLAN_TYPE=="U")

FilterUpgradeDeselectDF = FilterRenewalDeselectDF.subtract(FilterUpgradeDF)

#Filter Original Rcords from source-1:
FilterOrgRecFrmSrcDF = FilterUpgradeDF.filter((FilterUpgradeDF.originated_record=="N") & ((FilterUpgradeDF.UPGRADE_DTTM.isNull()) | (FilterUpgradeDF.UPGRADE_DTTM=="")))

FilterOrgRecFrmSrcDeselectDF = FilterUpgradeDF.subtract(FilterOrgRecFrmSrcDF)

#Reformat-  to modify NULL Upgrade DTTM:
RfmtModifyUpgradeDttmDF = FilterOrgRecFrmSrcDF.withColumn("UPGRADE_DTTM",FilterOrgRecFrmSrcDF.UPDATE_DTTM) \
.withColumn("UPDATE_DTTM",FilterOrgRecFrmSrcDF.UPDATE_DTTM).select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Filter Valid Plan and timestamp fields-2:
FilterValidPlanDF1 = FilterOrgRecFrmSrcDeselectDF.filter(((FilterOrgRecFrmSrcDeselectDF.PLAN_TYPE.isNotNull()) & (FilterOrgRecFrmSrcDeselectDF.PLAN_TYPE!="")) & (((FilterOrgRecFrmSrcDeselectDF.PLAN_TYPE=="E") & ((FilterOrgRecFrmSrcDeselectDF.CREATE_DTTM!="") & (FilterOrgRecFrmSrcDeselectDF.CREATE_DTTM.isNotNull()))) | ((FilterOrgRecFrmSrcDeselectDF.PLAN_TYPE=="R") & ((FilterOrgRecFrmSrcDeselectDF.RENEWAL_DTTM!="") & (FilterOrgRecFrmSrcDeselectDF.RENEWAL_DTTM.isNotNull()))) | ((FilterOrgRecFrmSrcDeselectDF.PLAN_TYPE=="U") & ((FilterOrgRecFrmSrcDeselectDF.UPGRADE_DTTM!="") & (FilterOrgRecFrmSrcDeselectDF.UPGRADE_DTTM.isNotNull()))) | ((FilterOrgRecFrmSrcDeselectDF.PLAN_TYPE=="C") & ((FilterOrgRecFrmSrcDeselectDF.UPDATE_DTTM!="") & (FilterOrgRecFrmSrcDeselectDF.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Gather-2:
GatherDF2 = RfmtModifyUpgradeDttmDF.union(FilterValidPlanDF1)

#Union on Gather-1 and Gather-2:
Gather1AndGather2DF = GatherDF1.union(GatherDF2)

# Final Union on Gather1AndGather2DF and FilterUpgradeDeselectDF DF's:
FilterUpgradeDeselectDF = FilterUpgradeDeselectDF.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

GatherFinalDF = Gather1AndGather2DF.union(FilterUpgradeDeselectDF)

#display(GatherFinalDF)

# COMMAND ----------

#Filter Valid Plan and timestamp fields-2:
FilterValidPlanDF2 = GatherFinalDF.filter(((GatherFinalDF.PLAN_TYPE.isNotNull()) & (GatherFinalDF.PLAN_TYPE!="")) & (((GatherFinalDF.PLAN_TYPE=="E") & ((GatherFinalDF.CREATE_DTTM!="") & (GatherFinalDF.CREATE_DTTM.isNotNull()))) | ((GatherFinalDF.PLAN_TYPE=="R") & ((GatherFinalDF.RENEWAL_DTTM!="") & (GatherFinalDF.RENEWAL_DTTM.isNotNull()))) | ((GatherFinalDF.PLAN_TYPE=="U") & ((GatherFinalDF.UPGRADE_DTTM!="") & (GatherFinalDF.UPGRADE_DTTM.isNotNull()))) | ((GatherFinalDF.PLAN_TYPE=="C") & ((GatherFinalDF.UPDATE_DTTM!="") & (GatherFinalDF.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Reformat to assign plan_type=X for NULL:
RfmtAssignXplanTypeDF = FilterEnrollDeselectDF.withColumn("PLAN_TYPE",lit("X")) \
.withColumn("originated_record",lit("N")).select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

Union_DF_1 = FilterValidPlanDF2.union(RfmtAssignXplanTypeDF)

Union_DF_1.cache()

#Filter for Cancel and Renewal and Upgrade:
FilterCRU_DF = NormalizePscEventsDeselectDF.filter(NormalizePscEventsDeselectDF.PLAN_TYPE=="C")
FilterCRUdeselect_DF = NormalizePscEventsDeselectDF.subtract(FilterCRU_DF)

# COMMAND ----------

#Process Cancel Records:

#Normalize for Four Event Types - E/U/R/C:

arr1 = array(lit(0),lit(1),lit(2),lit(3))

NormalizeEURC_DF = FilterCRU_DF.withColumn("index",arr1).withColumn("index",explode(col("index")))

NormalizeEURC_DF1 = NormalizeEURC_DF.withColumn("PLAN_TYPE",when(NormalizeEURC_DF.index==0,"E").when(NormalizeEURC_DF.index==1,"R").when(NormalizeEURC_DF.index==2,"U").when(NormalizeEURC_DF.index==3,"C")) \
.withColumn("UPDATE_DTTM",when(NormalizeEURC_DF.index==0,NormalizeEURC_DF.CREATE_DTTM).when(((NormalizeEURC_DF.index==1) & ((NormalizeEURC_DF.RENEWAL_DTTM.isNotNull()) & (NormalizeEURC_DF.RENEWAL_DTTM!=""))),NormalizeEURC_DF.RENEWAL_DTTM).when(((NormalizeEURC_DF.index==1) & ((NormalizeEURC_DF.RENEWAL_DTTM.isNull()) | (NormalizeEURC_DF.RENEWAL_DTTM==""))),NormalizeEURC_DF.UPDATE_DTTM).when(((NormalizeEURC_DF.index==2) & ((NormalizeEURC_DF.UPGRADE_DTTM.isNotNull()) & (NormalizeEURC_DF.UPGRADE_DTTM!=""))),NormalizeEURC_DF.UPGRADE_DTTM).when(((NormalizeEURC_DF.index==2) & ((NormalizeEURC_DF.UPGRADE_DTTM.isNull()) | (NormalizeEURC_DF.UPGRADE_DTTM==""))),NormalizeEURC_DF.UPDATE_DTTM).when(NormalizeEURC_DF.index==3,NormalizeEURC_DF.UPDATE_DTTM)) \
.withColumn("UPDATE_STORE_NBR",when(NormalizeEURC_DF.index==0,NormalizeEURC_DF.CREATE_STORE_NBR).when(NormalizeEURC_DF.index==1,NormalizeEURC_DF.UPDATE_STORE_NBR).when(NormalizeEURC_DF.index==2,NormalizeEURC_DF.UPDATE_STORE_NBR).when(NormalizeEURC_DF.index==3,NormalizeEURC_DF.UPDATE_STORE_NBR)) \
.withColumn("UPDATED_BY",when(NormalizeEURC_DF.index==0,NormalizeEURC_DF.CREATED_BY).when(NormalizeEURC_DF.index==1,NormalizeEURC_DF.UPDATED_BY).when(NormalizeEURC_DF.index==2,NormalizeEURC_DF.UPDATED_BY).when(NormalizeEURC_DF.index==3,NormalizeEURC_DF.UPDATED_BY)) \
.withColumn("originated_record",when(NormalizeEURC_DF.index==0,lit("Y")).when(NormalizeEURC_DF.index==1,lit("Y")).when(NormalizeEURC_DF.index==2,lit("Y")).when(NormalizeEURC_DF.index==3,lit("N")))

#Process Renewal and Upgrade for Cancel Category:

# Filter Renewal-1:
FilterRU_DF = NormalizeEURC_DF1.filter(NormalizeEURC_DF1.PLAN_TYPE=="R")
FilterRUdeselect_DF = NormalizeEURC_DF1.subtract(FilterRU_DF)

#Filter Original Rcords from source:
filterOrgRecrdFrmSrcDF = FilterRU_DF.filter((FilterRU_DF.originated_record=="N") & ((FilterRU_DF.RENEWAL_DTTM=="") | (FilterRU_DF.RENEWAL_DTTM.isNull())))

filterOrgRecrdFrmSrcDeselectDF = FilterRU_DF.subtract(filterOrgRecrdFrmSrcDF)

#Reformat-  to modify NULL Renewal DTTM:
RfmtModifyNullRenewalDF1 = filterOrgRecrdFrmSrcDF.withColumn("RENEWAL_DTTM",filterOrgRecrdFrmSrcDF.UPDATE_DTTM) \
.withColumn("UPDATE_DTTM",filterOrgRecrdFrmSrcDF.UPDATE_DTTM) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Filter Valid Plan and timestamp fields-1:
FilterValidPlanTsFieldsDF = filterOrgRecrdFrmSrcDeselectDF.filter(((filterOrgRecrdFrmSrcDeselectDF.PLAN_TYPE.isNotNull()) & (filterOrgRecrdFrmSrcDeselectDF.PLAN_TYPE!="")) & (((filterOrgRecrdFrmSrcDeselectDF.PLAN_TYPE=="E") & ((filterOrgRecrdFrmSrcDeselectDF.CREATE_DTTM!="") & (filterOrgRecrdFrmSrcDeselectDF.CREATE_DTTM.isNotNull()))) | ((filterOrgRecrdFrmSrcDeselectDF.PLAN_TYPE=="R") & ((filterOrgRecrdFrmSrcDeselectDF.RENEWAL_DTTM!="") & (filterOrgRecrdFrmSrcDeselectDF.RENEWAL_DTTM.isNotNull()))) | ((filterOrgRecrdFrmSrcDeselectDF.PLAN_TYPE=="U") & ((filterOrgRecrdFrmSrcDeselectDF.UPGRADE_DTTM!="") & (filterOrgRecrdFrmSrcDeselectDF.UPGRADE_DTTM.isNotNull()))) | ((filterOrgRecrdFrmSrcDeselectDF.PLAN_TYPE=="C") & ((filterOrgRecrdFrmSrcDeselectDF.UPDATE_DTTM!="") & (filterOrgRecrdFrmSrcDeselectDF.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Gather-1:
GatherRfmtDF1 = RfmtModifyNullRenewalDF1.union(FilterValidPlanTsFieldsDF)

#display(GatherRfmtDF1)

# COMMAND ----------

#Filter Upgrade:
FilterUpgradeRecsDF = FilterRUdeselect_DF.filter(FilterRUdeselect_DF.PLAN_TYPE=="U")

FilterUpgradeRecsDeselectDF = FilterRUdeselect_DF.subtract(FilterUpgradeRecsDF)

#Filter Original Rcords from source-1:
FilterOrgRecFrmSourceDF = FilterUpgradeRecsDF.filter((FilterUpgradeRecsDF.originated_record=="N") & ((FilterUpgradeRecsDF.UPGRADE_DTTM.isNull()) | (FilterUpgradeRecsDF.UPGRADE_DTTM=="")))

FilterOrgRecFrmSourceDeselectDF = FilterUpgradeRecsDF.subtract(FilterOrgRecFrmSourceDF)

#Reformat-  to modify NULL Upgrade DTTM:
RfmtModifyUpgradeDttmDF1 = FilterOrgRecFrmSourceDF.withColumn("UPGRADE_DTTM",FilterOrgRecFrmSourceDF.UPDATE_DTTM) \
.withColumn("UPDATE_DTTM",FilterOrgRecFrmSourceDF.UPDATE_DTTM).select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Filter Valid Plan and timestamp fields-2:
FilterValidPlanDF2 = FilterOrgRecFrmSourceDeselectDF.filter(((FilterOrgRecFrmSourceDeselectDF.PLAN_TYPE.isNotNull()) & (FilterOrgRecFrmSourceDeselectDF.PLAN_TYPE!="")) & (((FilterOrgRecFrmSourceDeselectDF.PLAN_TYPE=="E") & ((FilterOrgRecFrmSourceDeselectDF.CREATE_DTTM!="") & (FilterOrgRecFrmSourceDeselectDF.CREATE_DTTM.isNotNull()))) | ((FilterOrgRecFrmSourceDeselectDF.PLAN_TYPE=="R") & ((FilterOrgRecFrmSourceDeselectDF.RENEWAL_DTTM!="") & (FilterOrgRecFrmSourceDeselectDF.RENEWAL_DTTM.isNotNull()))) | ((FilterOrgRecFrmSourceDeselectDF.PLAN_TYPE=="U") & ((FilterOrgRecFrmSourceDeselectDF.UPGRADE_DTTM!="") & (FilterOrgRecFrmSourceDeselectDF.UPGRADE_DTTM.isNotNull()))) | ((FilterOrgRecFrmSourceDeselectDF.PLAN_TYPE=="C") & ((FilterOrgRecFrmSourceDeselectDF.UPDATE_DTTM!="") & (FilterOrgRecFrmSourceDeselectDF.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Gather-2:
GatherRfmtDF2 = RfmtModifyUpgradeDttmDF1.union(FilterValidPlanDF2)

#Union on Gather-1 and Gather-2:
Gather1AndGather2DF1 = GatherRfmtDF1.union(GatherRfmtDF2)

#display(Gather1AndGather2DF1)

# Final Union on Gather1AndGather2DF1 and FilterUpgradeRecsDeselectDF DF's:
FilterUpgradeRecsDeselectDF = FilterUpgradeRecsDeselectDF.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

GatherFinalDF1 = Gather1AndGather2DF1.union(FilterUpgradeRecsDeselectDF)

#display(GatherFinalDF1)

#Filter Valid Plan and timestamp fields:
FilterValidPlanDF3 = GatherFinalDF1.filter(((GatherFinalDF1.PLAN_TYPE.isNotNull()) & (GatherFinalDF1.PLAN_TYPE!="")) & (((GatherFinalDF1.PLAN_TYPE=="E") & ((GatherFinalDF1.CREATE_DTTM!="") & (GatherFinalDF1.CREATE_DTTM.isNotNull()))) | ((GatherFinalDF1.PLAN_TYPE=="R") & ((GatherFinalDF1.RENEWAL_DTTM!="") & (GatherFinalDF1.RENEWAL_DTTM.isNotNull()))) | ((GatherFinalDF1.PLAN_TYPE=="U") & ((GatherFinalDF1.UPGRADE_DTTM!="") & (GatherFinalDF1.UPGRADE_DTTM.isNotNull()))) | ((GatherFinalDF1.PLAN_TYPE=="C") & ((GatherFinalDF1.UPDATE_DTTM!="") & (GatherFinalDF1.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

FilterValidPlanDF3.cache()
#display(FilterValidPlanDF3)

# COMMAND ----------

# Process Renewal and Upgrade:
#Filter Renewal-1:

FilterRU_DF1 = FilterCRUdeselect_DF.filter(FilterCRUdeselect_DF.PLAN_TYPE=="R")
FilterRUdeselect_DF1 = FilterCRUdeselect_DF.subtract(FilterRU_DF1)

#Normalize for three Event Types - E/U/R:
Normalize3EvntTypeDF1 = FilterRU_DF1.withColumn("index",arr).withColumn("index",explode(col("index")))

Normalize3EvntTypeDF_1 = Normalize3EvntTypeDF1.withColumn("PLAN_TYPE",when(Normalize3EvntTypeDF1.index==0,"E").when(Normalize3EvntTypeDF1.index==1,"R").when(Normalize3EvntTypeDF1.index==2,"U")) \
.withColumn("UPDATE_DTTM",when(Normalize3EvntTypeDF1.index==0,Normalize3EvntTypeDF1.CREATE_DTTM).when(((Normalize3EvntTypeDF1.index==1) & ((Normalize3EvntTypeDF1.RENEWAL_DTTM.isNotNull()) & (Normalize3EvntTypeDF1.RENEWAL_DTTM!=""))),Normalize3EvntTypeDF1.RENEWAL_DTTM).when(((Normalize3EvntTypeDF1.index==1) & ((Normalize3EvntTypeDF1.RENEWAL_DTTM.isNull()) | (Normalize3EvntTypeDF1.RENEWAL_DTTM==""))),Normalize3EvntTypeDF1.UPDATE_DTTM).when(Normalize3EvntTypeDF1.index==2,Normalize3EvntTypeDF1.UPGRADE_DTTM)) \
.withColumn("UPDATE_STORE_NBR",when(Normalize3EvntTypeDF1.index==0,Normalize3EvntTypeDF1.CREATE_STORE_NBR).when(Normalize3EvntTypeDF1.index==1,Normalize3EvntTypeDF1.UPDATE_STORE_NBR).when(Normalize3EvntTypeDF1.index==2,Normalize3EvntTypeDF1.UPDATE_STORE_NBR)) \
.withColumn("UPDATED_BY",when(Normalize3EvntTypeDF1.index==0,Normalize3EvntTypeDF1.CREATED_BY).when(Normalize3EvntTypeDF1.index==1,Normalize3EvntTypeDF1.UPDATED_BY).when(Normalize3EvntTypeDF1.index==2,Normalize3EvntTypeDF1.UPDATED_BY)) \
.withColumn("originated_record",when(Normalize3EvntTypeDF1.index==0,lit("Y")).when(Normalize3EvntTypeDF1.index==1,lit("N")).when(Normalize3EvntTypeDF1.index==2,lit("Y")))

#display(Normalize3EvntTypeDF_1)

#Normalize for three Event Types - E/U/R-2:
Normalize3EvntTypeDF2 = FilterRUdeselect_DF1.withColumn("index",arr).withColumn("index",explode(col("index")))

Normalize3EvntTypeDF_2 = Normalize3EvntTypeDF2.withColumn("PLAN_TYPE",when(Normalize3EvntTypeDF2.index==0,"E").when(Normalize3EvntTypeDF2.index==1,"R").when(Normalize3EvntTypeDF2.index==2,"U")) \
.withColumn("UPDATE_DTTM",when(Normalize3EvntTypeDF2.index==0,Normalize3EvntTypeDF2.CREATE_DTTM).when(Normalize3EvntTypeDF2.index==1,Normalize3EvntTypeDF2.RENEWAL_DTTM).when(((Normalize3EvntTypeDF2.index==2) & ((Normalize3EvntTypeDF2.UPGRADE_DTTM.isNotNull()) & (Normalize3EvntTypeDF2.UPGRADE_DTTM!=""))),Normalize3EvntTypeDF2.UPGRADE_DTTM).when(((Normalize3EvntTypeDF2.index==2) & ((Normalize3EvntTypeDF2.UPGRADE_DTTM.isNull()) | (Normalize3EvntTypeDF2.UPGRADE_DTTM==""))),Normalize3EvntTypeDF2.UPDATE_DTTM)) \
.withColumn("UPDATE_STORE_NBR",when(Normalize3EvntTypeDF2.index==0,Normalize3EvntTypeDF2.CREATE_STORE_NBR).when(Normalize3EvntTypeDF2.index==1,Normalize3EvntTypeDF2.UPDATE_STORE_NBR).when(Normalize3EvntTypeDF2.index==2,Normalize3EvntTypeDF2.UPDATE_STORE_NBR)) \
.withColumn("UPDATED_BY",when(Normalize3EvntTypeDF2.index==0,Normalize3EvntTypeDF2.CREATED_BY).when(Normalize3EvntTypeDF2.index==1,Normalize3EvntTypeDF2.UPDATED_BY).when(Normalize3EvntTypeDF2.index==2,Normalize3EvntTypeDF2.UPDATED_BY)) \
.withColumn("originated_record",when(Normalize3EvntTypeDF2.index==0,lit("Y")).when(Normalize3EvntTypeDF2.index==1,lit("Y")).when(Normalize3EvntTypeDF2.index==2,lit("N")))

#display(Normalize3EvntTypeDF_2)

#Filter Original Rcords from source:
FilOrgRecFrmSrcDF = Normalize3EvntTypeDF_1.filter((Normalize3EvntTypeDF_1.originated_record=="N") & ((Normalize3EvntTypeDF_1.RENEWAL_DTTM.isNull()) | (Normalize3EvntTypeDF_1.RENEWAL_DTTM=="")))

FilOrgRecFrmSrcDeselectDF = Normalize3EvntTypeDF_1.subtract(FilOrgRecFrmSrcDF)

#Reformat-  to modify NULL Renewal DTTM:
RfmtModNRnwlDF = FilOrgRecFrmSrcDF.withColumn("RENEWAL_DTTM",FilOrgRecFrmSrcDF.UPDATE_DTTM) \
.withColumn("UPDATE_DTTM",FilOrgRecFrmSrcDF.UPDATE_DTTM).select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Filter Valid Plan and timestamp fields-1:
FilValidPlanTsDF = FilOrgRecFrmSrcDeselectDF.filter(((FilOrgRecFrmSrcDeselectDF.PLAN_TYPE.isNotNull()) & (FilOrgRecFrmSrcDeselectDF.PLAN_TYPE!="")) & (((FilOrgRecFrmSrcDeselectDF.PLAN_TYPE=="E") & ((FilOrgRecFrmSrcDeselectDF.CREATE_DTTM!="") & (FilOrgRecFrmSrcDeselectDF.CREATE_DTTM.isNotNull()))) | ((FilOrgRecFrmSrcDeselectDF.PLAN_TYPE=="R") & ((FilOrgRecFrmSrcDeselectDF.RENEWAL_DTTM!="") & (FilOrgRecFrmSrcDeselectDF.RENEWAL_DTTM.isNotNull()))) | ((FilOrgRecFrmSrcDeselectDF.PLAN_TYPE=="U") & ((FilOrgRecFrmSrcDeselectDF.UPGRADE_DTTM!="") & (FilOrgRecFrmSrcDeselectDF.UPGRADE_DTTM.isNotNull()))) | ((FilOrgRecFrmSrcDeselectDF.PLAN_TYPE=="C") & ((FilOrgRecFrmSrcDeselectDF.UPDATE_DTTM!="") & (FilOrgRecFrmSrcDeselectDF.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#display(FilValidPlanTsDF)

#Gather-1:
Gather_DF1 = RfmtModNRnwlDF.union(FilValidPlanTsDF)

# COMMAND ----------

#Filter Original Rcords from source-1:
FilOrgRecFrmSrcDF1 = Normalize3EvntTypeDF_2.filter((Normalize3EvntTypeDF_2.originated_record=="N") & ((Normalize3EvntTypeDF_2.UPGRADE_DTTM=="") | (Normalize3EvntTypeDF_2.UPGRADE_DTTM.isNull())))

FilOrgRecFrmSrcDeselectDF1 = Normalize3EvntTypeDF_2.subtract(FilOrgRecFrmSrcDF1)

#Reformat-  to modify NULL Upgrade DTTM:
RfmtModNUpdDF = FilOrgRecFrmSrcDF1.withColumn("UPGRADE_DTTM",FilOrgRecFrmSrcDF1.UPDATE_DTTM) \
.withColumn("UPDATE_DTTM",FilOrgRecFrmSrcDF1.UPDATE_DTTM).select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

#Filter Valid Plan and timestamp fields-2:
FilValidPlanTsDF1 = FilOrgRecFrmSrcDeselectDF1.filter(((FilOrgRecFrmSrcDeselectDF1.PLAN_TYPE.isNotNull()) & (FilOrgRecFrmSrcDeselectDF1.PLAN_TYPE!="")) & (((FilOrgRecFrmSrcDeselectDF1.PLAN_TYPE=="E") & ((FilOrgRecFrmSrcDeselectDF1.CREATE_DTTM!="") & (FilOrgRecFrmSrcDeselectDF1.CREATE_DTTM.isNotNull()))) | ((FilOrgRecFrmSrcDeselectDF1.PLAN_TYPE=="R") & ((FilOrgRecFrmSrcDeselectDF1.RENEWAL_DTTM!="") & (FilOrgRecFrmSrcDeselectDF1.RENEWAL_DTTM.isNotNull()))) | ((FilOrgRecFrmSrcDeselectDF1.PLAN_TYPE=="U") & ((FilOrgRecFrmSrcDeselectDF1.UPGRADE_DTTM!="") & (FilOrgRecFrmSrcDeselectDF1.UPGRADE_DTTM.isNotNull()))) | ((FilOrgRecFrmSrcDeselectDF1.PLAN_TYPE=="C") & ((FilOrgRecFrmSrcDeselectDF1.UPDATE_DTTM!="") & (FilOrgRecFrmSrcDeselectDF1.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

Gather_DF2 = RfmtModNUpdDF.union(FilValidPlanTsDF1)

Gather_DF1AndDF2 = Gather_DF1.union(Gather_DF2)

#Filter Valid Plan and timestamp fields-1:
FilValidPlanTmFieldsDF = Gather_DF1AndDF2.filter(((Gather_DF1AndDF2.PLAN_TYPE.isNotNull()) & (Gather_DF1AndDF2.PLAN_TYPE!="")) & (((Gather_DF1AndDF2.PLAN_TYPE=="E") & ((Gather_DF1AndDF2.CREATE_DTTM!="") & (Gather_DF1AndDF2.CREATE_DTTM.isNotNull()))) | ((Gather_DF1AndDF2.PLAN_TYPE=="R") & ((Gather_DF1AndDF2.RENEWAL_DTTM!="") & (Gather_DF1AndDF2.RENEWAL_DTTM.isNotNull()))) | ((Gather_DF1AndDF2.PLAN_TYPE=="U") & ((Gather_DF1AndDF2.UPGRADE_DTTM!="") & (Gather_DF1AndDF2.UPGRADE_DTTM.isNotNull()))) | ((Gather_DF1AndDF2.PLAN_TYPE=="C") & ((Gather_DF1AndDF2.UPDATE_DTTM!="") & (Gather_DF1AndDF2.UPDATE_DTTM.isNotNull()))))) \
.select("originated_record","WCARD_ID","WCARD_ID_POS","WCARD_RELATION_CD","WCARD_FIRST_NAME","WCARD_MID_INIT","WCARD_LAST_NAME","WCARD_SURNAME_SUFFIX","WCARD_SEX_CD","WCARD_BIRTH_DTTM","WCARD_STREET_ADDR","WCARD_APT_NBR","WCARD_CITY","WCARD_STATE","WCARD_ZIP","WCARD_AREA_CD","WCARD_PHONE","WCARD_EMAIL_ADDRESS","WCARD_COVERAGE_TYPE","WCARD_MKT_IND","CREATE_STORE_NBR","CREATE_DTTM","UPDATE_STORE_NBR","UPDATE_DTTM","WCARD_SENT_DTTM","WCARD_STATUS","WCARD_ACTION","CREATED_BY","UPDATED_BY","TERM_DTTM","RENEWAL_DTTM","UPGRADE_DTTM","PAID_IND","PAID_DTTM","PLAN_TYPE","BATCH_RUN_FLAG","ENROLL_EMP_ID","RENEW_EMP_ID","ADDRESS_VALID_IND","ANCHOR_RETURN_CODE","PAT_ID")

FilValidPlanTmFieldsDF.cache()

#Gather to collect all plan_type(s):
GatherAllPlanTypeDF = Union_DF_1.unionByName(FilterValidPlanDF3).unionByName(FilValidPlanTmFieldsDF)

#display(GatherAllPlanTypeDF)
#print(GatherAllPlanTypeDF.count())

# COMMAND ----------

#Reformat to EDW field names:

#print(var_src_sys_cd)
#print(var_create_dttm)

RfmtEdwFieldNamesDF1 = GatherAllPlanTypeDF.withColumn("card_hldr_id",GatherAllPlanTypeDF.WCARD_ID)  \
.withColumn("acct_id",GatherAllPlanTypeDF.WCARD_ID_POS) \
.withColumn("psc_mbr_relation_cd",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_RELATION_CD))) \
.withColumn("first_name",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_FIRST_NAME))) \
.withColumn("mid_name",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_MID_INIT))) \
.withColumn("last_name",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_LAST_NAME))) \
.withColumn("card_hldr_sufx",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_SURNAME_SUFFIX))) \
.withColumn("gndr",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_SEX_CD))) \
.withColumn("brth_dt",GatherAllPlanTypeDF.WCARD_BIRTH_DTTM) \
.withColumn("addr_line_1",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_STREET_ADDR))) \
.withColumn("addr_line_2",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_APT_NBR))) \
.withColumn("city_name",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_CITY))) \
.withColumn("state_cd",ltrim(rtrim(GatherAllPlanTypeDF.WCARD_STATE))) \
.withColumn("zip_cd_5",when((GatherAllPlanTypeDF.WCARD_ZIP!="") & (GatherAllPlanTypeDF.WCARD_ZIP.isNotNull()),substring(rtrim(ltrim(GatherAllPlanTypeDF.WCARD_ZIP)),1,5))
           .otherwise(lit(None))) \
.withColumn("zip_cd_4",when((substring(rtrim(ltrim(GatherAllPlanTypeDF.WCARD_ZIP)),6,4))=="0000","0000").when((GatherAllPlanTypeDF.WCARD_ZIP!="") & (GatherAllPlanTypeDF.WCARD_ZIP.isNotNull()),substring(rtrim(ltrim(GatherAllPlanTypeDF.WCARD_ZIP)),-4,4)).otherwise(lit(None))) \
.withColumn("phone_number",concat(rtrim(ltrim(GatherAllPlanTypeDF.WCARD_AREA_CD)),rtrim(ltrim(GatherAllPlanTypeDF.WCARD_PHONE)))) \
.withColumn("email_address",rtrim(ltrim(GatherAllPlanTypeDF.WCARD_EMAIL_ADDRESS))) \
.withColumn("psc_mbr_type",GatherAllPlanTypeDF.WCARD_COVERAGE_TYPE) \
.withColumn("mktg_opt_in_ind",rtrim(ltrim(GatherAllPlanTypeDF.WCARD_MKT_IND))) \
.withColumn("card_send_dt",when((GatherAllPlanTypeDF.WCARD_SENT_DTTM.isNotNull()) & (GatherAllPlanTypeDF.WCARD_SENT_DTTM!=""),substring(GatherAllPlanTypeDF.WCARD_SENT_DTTM,1,8)).otherwise(lit(None))) \
.withColumn("card_send_tm",when((GatherAllPlanTypeDF.WCARD_SENT_DTTM.isNotNull()) & (GatherAllPlanTypeDF.WCARD_SENT_DTTM!=""),substring(GatherAllPlanTypeDF.WCARD_SENT_DTTM,-8,8)).otherwise(lit(None))) \
.withColumn("psc_wcard_stat_cd",rtrim(ltrim(GatherAllPlanTypeDF.WCARD_STATUS))) \
.withColumn("internal_actn_cd",rtrim(ltrim(GatherAllPlanTypeDF.WCARD_ACTION))) \
.withColumn("mbr_term_dt",when((GatherAllPlanTypeDF.TERM_DTTM.isNotNull()) & (GatherAllPlanTypeDF.TERM_DTTM!=""),substring(GatherAllPlanTypeDF.TERM_DTTM,1,8)).otherwise(lit(None))) \
.withColumn("mbr_term_tm",when((GatherAllPlanTypeDF.TERM_DTTM.isNotNull()) & (GatherAllPlanTypeDF.TERM_DTTM!=""),substring(GatherAllPlanTypeDF.TERM_DTTM,-8,8)).otherwise(lit(None))) \
.withColumn("psc_mbr_paid_cd",rtrim(ltrim(GatherAllPlanTypeDF.PAID_IND))) \
.withColumn("psc_paid_dt",when((GatherAllPlanTypeDF.PAID_DTTM.isNotNull()) & (GatherAllPlanTypeDF.PAID_DTTM!=""),substring(GatherAllPlanTypeDF.PAID_DTTM,1,8)).otherwise(lit(None))) \
.withColumn("psc_paid_tm",when((GatherAllPlanTypeDF.PAID_DTTM.isNotNull()) & (GatherAllPlanTypeDF.PAID_DTTM!=""),substring(GatherAllPlanTypeDF.PAID_DTTM,-8,8)).otherwise(lit(None))) \
.withColumn("psc_mbr_event_type",rtrim(ltrim(GatherAllPlanTypeDF.PLAN_TYPE))) \
.withColumn("batch_run_cd",rtrim(ltrim(GatherAllPlanTypeDF.BATCH_RUN_FLAG))) \
.withColumn("vld_addr_ind",rtrim(ltrim(GatherAllPlanTypeDF.ADDRESS_VALID_IND))) \
.withColumn("addr_stand_return_cd",rtrim(ltrim(GatherAllPlanTypeDF.ANCHOR_RETURN_CODE))) \
.withColumn("psc_mbr_event_dt",when(((GatherAllPlanTypeDF.PLAN_TYPE=="E") & (GatherAllPlanTypeDF.CREATE_DTTM!="")),substring(GatherAllPlanTypeDF.CREATE_DTTM,1,8)).when(((GatherAllPlanTypeDF.PLAN_TYPE=="R") & (GatherAllPlanTypeDF.RENEWAL_DTTM!="")),substring(GatherAllPlanTypeDF.RENEWAL_DTTM,1,8)).when(((GatherAllPlanTypeDF.PLAN_TYPE=="U") & (GatherAllPlanTypeDF.UPGRADE_DTTM!="")),substring(GatherAllPlanTypeDF.UPGRADE_DTTM,1,8)).when(((GatherAllPlanTypeDF.PLAN_TYPE=="C") & (GatherAllPlanTypeDF.UPDATE_DTTM!="")),substring(GatherAllPlanTypeDF.UPDATE_DTTM,1,8)).when(((GatherAllPlanTypeDF.PLAN_TYPE=="X") & (GatherAllPlanTypeDF.UPDATE_DTTM!="")),substring(GatherAllPlanTypeDF.UPDATE_DTTM,1,8)).when(((GatherAllPlanTypeDF.PLAN_TYPE=="X") & (GatherAllPlanTypeDF.CREATE_DTTM!="")),substring(GatherAllPlanTypeDF.CREATE_DTTM,1,8)).otherwise(substring(GatherAllPlanTypeDF.UPDATE_DTTM,1,8))) \
.withColumn("psc_mbr_event_tm",when(((GatherAllPlanTypeDF.PLAN_TYPE=="E") & (GatherAllPlanTypeDF.CREATE_DTTM!="")),GatherAllPlanTypeDF.CREATE_DTTM).when(((GatherAllPlanTypeDF.PLAN_TYPE=="R") & (GatherAllPlanTypeDF.RENEWAL_DTTM!="")),GatherAllPlanTypeDF.RENEWAL_DTTM).when(((GatherAllPlanTypeDF.PLAN_TYPE=="U") & (GatherAllPlanTypeDF.UPGRADE_DTTM!="")),GatherAllPlanTypeDF.UPGRADE_DTTM).when(((GatherAllPlanTypeDF.PLAN_TYPE=="C") & (GatherAllPlanTypeDF.UPDATE_DTTM!="")),GatherAllPlanTypeDF.UPDATE_DTTM).when(((GatherAllPlanTypeDF.PLAN_TYPE=="X") & (GatherAllPlanTypeDF.UPDATE_DTTM!="")),GatherAllPlanTypeDF.UPDATE_DTTM).when(((GatherAllPlanTypeDF.PLAN_TYPE=="X") & (GatherAllPlanTypeDF.CREATE_DTTM!="")),GatherAllPlanTypeDF.CREATE_DTTM).otherwise(GatherAllPlanTypeDF.UPDATE_DTTM)) \
.withColumn("authenticator_id",when(((GatherAllPlanTypeDF.PLAN_TYPE=="E") & ((GatherAllPlanTypeDF.CREATE_DTTM!="") | (GatherAllPlanTypeDF.CREATE_DTTM.isNotNull()))),rtrim(ltrim(GatherAllPlanTypeDF.CREATED_BY))).when(((rtrim(ltrim(GatherAllPlanTypeDF.UPDATED_BY))!="") & (rtrim(ltrim(GatherAllPlanTypeDF.UPDATED_BY)).isNotNull())),GatherAllPlanTypeDF.UPDATED_BY).otherwise(rtrim(ltrim(GatherAllPlanTypeDF.CREATED_BY)))) \
.withColumn("emp_id",when(((GatherAllPlanTypeDF.PLAN_TYPE=="E") | (GatherAllPlanTypeDF.PLAN_TYPE=="U") | (GatherAllPlanTypeDF.PLAN_TYPE=="C")),GatherAllPlanTypeDF.ENROLL_EMP_ID).when(GatherAllPlanTypeDF.PLAN_TYPE=="R",GatherAllPlanTypeDF.RENEW_EMP_ID).when(((GatherAllPlanTypeDF.PLAN_TYPE=="X") & (((GatherAllPlanTypeDF.ENROLL_EMP_ID!="") & (GatherAllPlanTypeDF.ENROLL_EMP_ID.isNotNull())))),GatherAllPlanTypeDF.ENROLL_EMP_ID).when(((GatherAllPlanTypeDF.PLAN_TYPE=="X") & (((GatherAllPlanTypeDF.RENEW_EMP_ID!="") & (GatherAllPlanTypeDF.RENEW_EMP_ID.isNotNull())))),GatherAllPlanTypeDF.RENEW_EMP_ID).otherwise(lit(None))) \
.withColumn("psc_event_location_nbr",when((GatherAllPlanTypeDF.PLAN_TYPE=="E") & ((GatherAllPlanTypeDF.CREATE_DTTM!="") | (GatherAllPlanTypeDF.CREATE_DTTM.isNotNull())),GatherAllPlanTypeDF.CREATE_STORE_NBR).when(((GatherAllPlanTypeDF.UPDATE_STORE_NBR!="") & (GatherAllPlanTypeDF.UPDATE_STORE_NBR.isNotNull())),GatherAllPlanTypeDF.UPDATE_STORE_NBR).when((GatherAllPlanTypeDF.PLAN_TYPE=="E") & (((GatherAllPlanTypeDF.UPDATE_STORE_NBR=="") | (GatherAllPlanTypeDF.UPDATE_STORE_NBR.isNull()))) & (((GatherAllPlanTypeDF.CREATE_STORE_NBR!="") & (GatherAllPlanTypeDF.CREATE_STORE_NBR.isNotNull()))),GatherAllPlanTypeDF.CREATE_STORE_NBR).otherwise(lit(None))) \
.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("create_dttm",lit(var_create_dttm)) \
.withColumn("eff_dt",current_date()) \
.withColumn("end_dt",lit(None)) \
.withColumn("originated_record",GatherAllPlanTypeDF.originated_record)

RfmtEdwFieldNamesDF1 = RfmtEdwFieldNamesDF1.select("originated_record","card_hldr_id","acct_id","psc_mbr_relation_cd","first_name","mid_name","last_name","card_hldr_sufx","gndr","brth_dt","addr_line_1","addr_line_2","city_name","state_cd","zip_cd_5","zip_cd_4","phone_number","email_address","psc_mbr_type","mktg_opt_in_ind","psc_event_location_nbr","card_send_dt","card_send_tm","psc_wcard_stat_cd","internal_actn_cd","authenticator_id","mbr_term_dt","mbr_term_tm","psc_mbr_event_dt","psc_mbr_event_tm","psc_mbr_paid_cd","psc_paid_dt","psc_paid_tm","psc_mbr_event_type","batch_run_cd","emp_id","vld_addr_ind","addr_stand_return_cd","src_sys_cd","create_dttm","eff_dt","end_dt")

#display(RfmtEdwFieldNamesDF1)

#Filter out Upgrades for Non-Primary Members - Invalid Upgrades:
FilterInvalidUpgradesDF = RfmtEdwFieldNamesDF1.filter(~((RfmtEdwFieldNamesDF1.psc_mbr_relation_cd!="P") & (RfmtEdwFieldNamesDF1.psc_mbr_event_type=="U")))

# COMMAND ----------

#Create Wcard CardHolder File-1:
#display(RfmtEdwFormatDF)
#print(RfmtEdwFormatDF.count())

#RFT: For Cardholder Table:
RfmtCardHolderTabDF = RfmtEdwFormatDF.withColumn("brth_dt",concat(substring(RfmtEdwFormatDF.brth_dt,1,4),lit("-"),substring(RfmtEdwFormatDF.brth_dt,5,2),lit("-"),substring(RfmtEdwFormatDF.brth_dt,7,2))) \
.withColumn("card_hldr_id",RfmtEdwFormatDF.card_hldr_id) \
.withColumn("eff_dt",lit(EFF_DT)) \
.withColumn("src_sys_cd",RfmtEdwFormatDF.src_sys_cd)

RfmtCardHolderTabDF = RfmtCardHolderTabDF.select("card_hldr_id","src_sys_cd","eff_dt","brth_dt","end_dt")

#Dedup Sorted - on Card Hldr Id:
DedupCardHldrID_DF = RfmtCardHolderTabDF.select("*",row_number().over(Window.partitionBy("card_hldr_id").orderBy(RfmtCardHolderTabDF['card_hldr_id'])).alias("row_num")) 
DedupCardHldrID_DF1 = WriteNullParquet(DedupCardHldrID_DF.filter(DedupCardHldrID_DF.row_num ==1).drop("row_num"))

#display(DedupCardHldrID_DF1)

#OUF:  WCARD Cardholder Table:
print("wcard_psc_cardholder Count: {}".format(DedupCardHldrID_DF1.count()))
DedupCardHldrID_DF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardHldrOutFile1+"/"+Batch_id)

#Create Wcard CardHolder Name File-2:

#RFT: For Cardholder Name Table:
RfmtCardHolderNameTabDF = RfmtEdwFormatDF.withColumn("card_hldr_name_eff_dt",lit(EFF_DT)) \
.withColumn("first_name",coalesce(RfmtEdwFormatDF.first_name,lit(""))) \
.withColumn("mid_name",coalesce(RfmtEdwFormatDF.mid_name,lit(""))) \
.withColumn("last_name",coalesce(RfmtEdwFormatDF.last_name,lit(""))) \
.withColumn("card_hldr_ttl",lit(None)) \
.withColumn("card_hldr_sufx",RfmtEdwFormatDF.card_hldr_sufx) \
.withColumn("card_hldr_id",RfmtEdwFormatDF.card_hldr_id) \
.withColumn("src_sys_cd",RfmtEdwFormatDF.src_sys_cd) \
.withColumn("card_hldr_name_end_dt",lit(None)) \
.select("card_hldr_id","card_hldr_name_eff_dt","src_sys_cd","first_name","mid_name","last_name","card_hldr_ttl","card_hldr_sufx","card_hldr_name_end_dt")

#Dedup Sorted- on Card Hldr Id:
DedupCardHldrNameID_DF = RfmtCardHolderNameTabDF.select("*",row_number().over(Window.partitionBy("card_hldr_id").orderBy(RfmtCardHolderNameTabDF['card_hldr_id'])).alias("row_num")) 
DedupCardHldrNameID_DF1 = WriteNullParquet(DedupCardHldrNameID_DF.filter(DedupCardHldrNameID_DF.row_num ==1).drop("row_num"))

#display(DedupCardHldrNameID_DF1)

#OUF:  WCARD Cardholder Name Table:
print("wcard_psc_cardholder_name Count: {}".format(DedupCardHldrNameID_DF1.count()))
DedupCardHldrNameID_DF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardHldrNameOutFile2+"/"+Batch_id)

#Create Wcard CardHolder Address File-3:

#RFT: For Cardholder Address Table:
RfmtCardHolderAddressTabDF = RfmtEdwFormatDF.withColumn("addr_eff_dt",lit(EFF_DT)) \
.withColumn("addr_line_1",RfmtEdwFormatDF.addr_line_1) \
.withColumn("addr_line_2",RfmtEdwFormatDF.addr_line_2) \
.withColumn("city_name",RfmtEdwFormatDF.city_name) \
.withColumn("state_cd",RfmtEdwFormatDF.state_cd) \
.withColumn("addr_type_cd",lit("CON")) \
.withColumn("card_hldr_id",RfmtEdwFormatDF.card_hldr_id) \
.withColumn("zip_cd_5",RfmtEdwFormatDF.zip_cd_5) \
.withColumn("zip_cd_4",RfmtEdwFormatDF.zip_cd_4) \
.withColumn("src_sys_cd",RfmtEdwFormatDF.src_sys_cd) \
.withColumn("addr_end_dt",lit(None)) \
.select("card_hldr_id","src_sys_cd","state_cd","city_name","addr_line_1","addr_line_2","addr_type_cd","zip_cd_5","zip_cd_4","addr_eff_dt","addr_end_dt")

#Dedup Sorted- on Card Hldr Id:
DedupCardHldrAddressID_DF = RfmtCardHolderAddressTabDF.select("*",row_number().over(Window.partitionBy("card_hldr_id").orderBy(RfmtCardHolderAddressTabDF['card_hldr_id'])).alias("row_num")) 
DedupCardHldrAddressID_DF1 = WriteNullParquet(DedupCardHldrAddressID_DF.filter(DedupCardHldrAddressID_DF.row_num ==1).drop("row_num"))

#display(DedupCardHldrAddressID_DF1)

#OUF:  WCARD Cardholder Name Table:
print("wcard_psc_cardholder_address Count: {}".format(DedupCardHldrAddressID_DF1.count()))
DedupCardHldrAddressID_DF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardHldrAddressOutFile3+"/"+Batch_id)

# COMMAND ----------

#Create Wcard CardHolder Contact File-4:

#RFT: For Cardholder Contact Table:
RfmtCardHolderContactTabDF = RfmtEdwFormatDF.withColumn("cardholder_effective_date",lit(EFF_DT)) \
.withColumn("hp_cntc_chnl_val",lit("")) \
.withColumn("wp_cntc_chnl_val",RfmtEdwFormatDF.phone_number) \
.withColumn("em_cntc_chnl_val",RfmtEdwFormatDF.email_address) \
.withColumn("cntc_chnl_type_cd",lit("")) \
.withColumn("cardholder_id",RfmtEdwFormatDF.card_hldr_id) \
.withColumn("src_sys_cd",RfmtEdwFormatDF.src_sys_cd)

NormalizeArr = array(lit(0),lit(1),lit(2))

#Normalize to Create a record for the 3 contact types:
Normalize3ContactTypesDF = RfmtCardHolderContactTabDF.withColumn("index",NormalizeArr).withColumn("index",explode(col("index"))) 

Normalize3ContactTypesDF1 = Normalize3ContactTypesDF.withColumn("channel_type_cd",when(Normalize3ContactTypesDF.index==0,lit("HP")).when(Normalize3ContactTypesDF.index==1,lit("WP")).when(Normalize3ContactTypesDF.index==2,lit("EM"))) \
.withColumn("cntc_chnl_val",when(Normalize3ContactTypesDF.index==0,Normalize3ContactTypesDF.hp_cntc_chnl_val).when(Normalize3ContactTypesDF.index==1,Normalize3ContactTypesDF.wp_cntc_chnl_val).when(Normalize3ContactTypesDF.index==2,Normalize3ContactTypesDF.em_cntc_chnl_val)) \
.withColumn("card_hldr_id",Normalize3ContactTypesDF.cardholder_id) \
.withColumn("cntc_chnl_eff_dt",Normalize3ContactTypesDF.cardholder_effective_date) \
.withColumn("cntc_chnl_end_dt",lit(None)) \
.select("card_hldr_id","src_sys_cd","cntc_chnl_eff_dt","channel_type_cd","cntc_chnl_val","cntc_chnl_end_dt")

#FBE: Not NULL contacts:
FilterNotNullContctDF = Normalize3ContactTypesDF1.filter(Normalize3ContactTypesDF1.cntc_chnl_val!="")

#Dedup Sorted- on Card Hldr Id and Chanl Type Cd:
DedupSortCHIandCTC_DF = FilterNotNullContctDF.select("*",row_number().over(Window.partitionBy("card_hldr_id","channel_type_cd").orderBy(FilterNotNullContctDF.card_hldr_id,FilterNotNullContctDF.channel_type_cd)).alias("row_num")) 

DedupSortCHIandCTC_DF1 = WriteNullParquet(DedupSortCHIandCTC_DF.filter(DedupSortCHIandCTC_DF.row_num ==1).drop("row_num"))

#OUF:  WCARD Cardholder Contact Table:
print("wcard_psc_cardholder_contact Count: {}".format(DedupSortCHIandCTC_DF1.count()))
DedupSortCHIandCTC_DF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardHldrContactOutFile4+"/"+Batch_id)

#Create Wcard Account CardHolder File-5:

#RFT: For Account Cardholder Table:
RfmtAccCardHolderTabDF = RfmtEdwFormatDF.withColumn("acct_card_hldr_eff_dt",lit(EFF_DT)) \
.withColumn("card_ownr_ind",lit(None)) \
.withColumn("mbr_id_type_cd",lit(None)) \
.withColumn("mbr_id",lit(None)) \
.withColumn("card_hldr_id",RfmtEdwFormatDF.card_hldr_id) \
.withColumn("acct_id",RfmtEdwFormatDF.acct_id) \
.withColumn("src_sys_cd",RfmtEdwFormatDF.src_sys_cd) \
.withColumn("acct_card_hldr_end_dt",lit(None)) \
.select("card_hldr_id","acct_id","acct_card_hldr_eff_dt","src_sys_cd","acct_card_hldr_end_dt","card_ownr_ind","mbr_id","mbr_id_type_cd")

#Dedup Sorted- on Card Hldr Id:
DedupAccCardHldrID_DF = RfmtAccCardHolderTabDF.select("*",row_number().over(Window.partitionBy("card_hldr_id").orderBy(RfmtAccCardHolderTabDF['card_hldr_id'])).alias("row_num")) 
DedupAccCardHldrID_DF1 = WriteNullParquet(DedupAccCardHldrID_DF.filter(DedupAccCardHldrID_DF.row_num ==1).drop("row_num"))

#OUF:  WCARD Account Cardholder Table:
print("wcard_psc_account_cardholder Count: {}".format(DedupAccCardHldrID_DF1.count()))
DedupAccCardHldrID_DF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardAccCardHldrOutFile5+"/"+Batch_id)

# COMMAND ----------

sel_wcard_cardholder_tbl = "Select * FROM {0}".format(SNFL_TBL_NAME3)

wcardCardHolder_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB2) \
     .option("query",sel_wcard_cardholder_tbl) \
     .load()

#display(wcardCardHolder_tbl_df)
wcardCardHolder_tbl_df.createOrReplaceTempView("wcard_cardholder")
wcardPscCardHldrStgDF.createOrReplaceTempView("wcard_psc_card_hldr_stg")

sel_wcard_cardholder_add_tbl = "Select * FROM {0}".format(SNFL_TBL_NAME4)

wcardCardHolderAdd_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB2) \
     .option("query",sel_wcard_cardholder_add_tbl) \
     .load()

#display(wcardCardHolderAdd_tbl_df)
wcardCardHolderAdd_tbl_df.createOrReplaceTempView("wcard_cardholder_address")
wcardPscCardHldrAddrStgDF.createOrReplaceTempView("wcard_psc_card_hldr_addr_stg")

#Wcard Cardholder for Eff Date:
WcardCH_FOR_EFF_DF = spark.sql("select * from wcard_cardholder a INNER JOIN wcard_psc_card_hldr_stg b on a.card_hldr_id = b.card_hldr_id and a.src_sys_cd = b.src_sys_cd and COALESCE(a.brth_dt, cast('1900-01-01' as date)) = COALESCE(b.brth_dt, cast('1900-01-01' as date)) where a.end_dt is NULL").select("a.card_hldr_id","a.src_sys_cd","eff_dt","a.brth_dt","end_dt")
WcardCH_FOR_EFF_DF.cache()

WcardCH_FOR_EFF_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardCardHldrUnloadFile1+"/"+Batch_id)

#Wcard Cardholder Address for Eff Date:
WcardCHADD_FOR_EFF_DT = spark.sql("select * from wcard_cardholder_address a INNER JOIN wcard_psc_card_hldr_addr_stg b on a.card_hldr_id = b.card_hldr_id and a.src_sys_cd = b.src_sys_cd and a.addr_type_cd = b.addr_type_cd and COALESCE(a.state_cd, 'NO DATA')  = COALESCE(b.state_cd, 'NO DATA') and COALESCE(a.city_name, 'NO DATA')  = COALESCE(b.city_name, 'NO DATA') and COALESCE(a.addr_line_1, 'NO DATA')  = COALESCE(b.addr_line_1, 'NO DATA') and COALESCE(a.addr_line_2, 'NO DATA') = COALESCE(b.addr_line_2, 'NO DATA') and COALESCE(a.zip_cd_5, 'NO DATA')  = COALESCE(b.zip_cd_5, 'NO DATA') and COALESCE(a.zip_cd_4, 'NO DATA')  = COALESCE(b.zip_cd_4, 'NO DATA') where a.addr_end_dt is NULL") \
.select("a.card_hldr_id","a.src_sys_cd","a.state_cd","a.city_name","a.addr_line_1","a.addr_line_2","a.addr_type_cd","a.zip_cd_5","a.zip_cd_4","a.addr_eff_dt","a.addr_end_dt")
WcardCHADD_FOR_EFF_DT.cache()

WcardCHADD_FOR_EFF_DT.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardCardHldrAddUnloadFile2+"/"+Batch_id)

# COMMAND ----------

#create wcard PSC addr Stand Result File-6:

#RFT: For PSC Addr Stand Result Table:
RfmtWcardPSCAddStandResTabDF = RfmtEdwFormatDF.withColumn("card_hldr_id",RfmtEdwFormatDF.card_hldr_id) \
.withColumn("src_sys_cd",RfmtEdwFormatDF.src_sys_cd) \
.withColumn("addr_type_cd",lit("CON")) \
.withColumn("addr_stand_return_cd",RfmtEdwFormatDF.addr_stand_return_cd) \
.withColumn("vld_addr_ind",RfmtEdwFormatDF.vld_addr_ind) \
.withColumn("create_dttm",RfmtEdwFormatDF.create_dttm) \
.withColumn("addr_stand_eff_dt",lit(EFF_DT)) \
.withColumn("addr_stand_end_dt",lit(None))

RfmtWcardPSCAddStandResTabDF1 = RfmtWcardPSCAddStandResTabDF.join(WcardCHADD_FOR_EFF_DT,on=[RfmtWcardPSCAddStandResTabDF.card_hldr_id==WcardCHADD_FOR_EFF_DT.card_hldr_id,WcardCHADD_FOR_EFF_DT.src_sys_cd=="1",WcardCHADD_FOR_EFF_DT.addr_type_cd=="CON"],how='left_outer').select(RfmtWcardPSCAddStandResTabDF.card_hldr_id,RfmtWcardPSCAddStandResTabDF.src_sys_cd,RfmtWcardPSCAddStandResTabDF.addr_type_cd,RfmtWcardPSCAddStandResTabDF.addr_stand_return_cd,WcardCHADD_FOR_EFF_DT.addr_eff_dt,RfmtWcardPSCAddStandResTabDF.create_dttm,RfmtWcardPSCAddStandResTabDF.vld_addr_ind,RfmtWcardPSCAddStandResTabDF.addr_stand_eff_dt,RfmtWcardPSCAddStandResTabDF.addr_stand_end_dt)

RfmtWcardPSCAddStandResTabDF1 = RfmtWcardPSCAddStandResTabDF1.withColumn("addr_eff_dt",when(RfmtWcardPSCAddStandResTabDF1.addr_eff_dt.isNotNull(),RfmtWcardPSCAddStandResTabDF1.addr_eff_dt).otherwise(lit(EFF_DT))) 

#display(RfmtWcardPSCAddStandResTabDF1)
RfmtWcardPSCAddStandResTabDF1 = WriteNullParquet(RfmtWcardPSCAddStandResTabDF1)

#OUF:  WCARD Psc Addr Stand Result: 
print("wcard_psc_addr_stand_result Count: {}".format(RfmtWcardPSCAddStandResTabDF1.count()))
RfmtWcardPSCAddStandResTabDF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardAddrStandResOutFile6+"/"+Batch_id)

# COMMAND ----------

#create create wcard psc event File-7:

#RFT: For Psc Event Table:
RfmtPscEvntTabDF = FilterInvalidUpgradesDF.withColumn("originated_record",FilterInvalidUpgradesDF.originated_record) \
.withColumn("psc_event_end_dt",lit(None)) \
.withColumn("psc_mbr_event_dt",concat(substring(FilterInvalidUpgradesDF.psc_mbr_event_dt,1,4),lit("-"),substring(FilterInvalidUpgradesDF.psc_mbr_event_dt,5,2),lit("-"),substring(FilterInvalidUpgradesDF.psc_mbr_event_dt,7,2))) \
.withColumn("psc_mbr_event_tm",substring(FilterInvalidUpgradesDF.psc_mbr_event_tm,-8,8)) \
.withColumn("psc_paid_dt",concat(substring(FilterInvalidUpgradesDF.psc_paid_dt,1,4),lit("-"),substring(FilterInvalidUpgradesDF.psc_paid_dt,5,2),lit("-"),substring(FilterInvalidUpgradesDF.psc_paid_dt,7,2)))

RfmtPscEvntTabDF1 = RfmtPscEvntTabDF.join(WcardCH_FOR_EFF_DF,on=[RfmtPscEvntTabDF.card_hldr_id==WcardCH_FOR_EFF_DF.card_hldr_id,RfmtPscEvntTabDF.src_sys_cd==WcardCH_FOR_EFF_DF.src_sys_cd],how = 'left_outer') \
.select("originated_record",RfmtPscEvntTabDF.card_hldr_id,RfmtPscEvntTabDF.src_sys_cd,"psc_mbr_event_dt","psc_mbr_event_type","psc_mbr_event_tm","psc_mbr_type","psc_event_location_nbr","authenticator_id","psc_mbr_paid_cd","psc_paid_dt","psc_paid_tm","emp_id","create_dttm","psc_event_end_dt",WcardCH_FOR_EFF_DF.eff_dt)

RfmtPscEvntTabFinal_DF = RfmtPscEvntTabDF1.withColumn("card_hldr_eff_dt",when(RfmtPscEvntTabDF1.eff_dt.isNotNull(),RfmtPscEvntTabDF1.eff_dt).otherwise(lit(EFF_DT))).select("originated_record","card_hldr_id","src_sys_cd","psc_mbr_event_dt","psc_mbr_event_type","psc_mbr_event_tm","card_hldr_eff_dt","psc_mbr_type","psc_event_location_nbr","authenticator_id","psc_mbr_paid_cd","psc_paid_dt","psc_paid_tm","emp_id","create_dttm","psc_event_end_dt")

#Closing Normalized old records:

#Scan to generate Group Key:

AssignGrpKeyDF = RfmtPscEvntTabFinal_DF.withColumn("group_change_key",row_number().over(Window.partitionBy("card_hldr_id").orderBy(RfmtPscEvntTabFinal_DF.card_hldr_id,RfmtPscEvntTabFinal_DF.psc_mbr_event_dt,RfmtPscEvntTabFinal_DF.psc_mbr_event_tm))) 

AssignGrpKeyDF1 = AssignGrpKeyDF.withColumnRenamed("card_hldr_id","card_hldr_id_2") \
.withColumnRenamed("originated_record","originated_record_2") \
.withColumnRenamed("psc_mbr_event_type","psc_mbr_event_type_2") \
.withColumnRenamed("psc_mbr_event_dt","psc_mbr_event_dt_2") \
.withColumnRenamed("card_hldr_eff_dt","card_hldr_eff_dt_2") \
.withColumnRenamed("src_sys_cd","src_sys_cd_2") \
.withColumnRenamed("psc_mbr_event_tm","psc_mbr_event_tm_2") \
.withColumnRenamed("psc_mbr_type","psc_mbr_type_2") \
.withColumnRenamed("psc_event_location_nbr","psc_event_location_nbr_2") \
.withColumnRenamed("authenticator_id","authenticator_id_2") \
.withColumnRenamed("psc_mbr_paid_cd","psc_mbr_paid_cd_2") \
.withColumnRenamed("psc_paid_dt","psc_paid_dt_2") \
.withColumnRenamed("psc_paid_tm","psc_paid_tm_2") \
.withColumnRenamed("emp_id","emp_id_2") \
.withColumnRenamed("create_dttm","create_dttm_2") \
.withColumnRenamed("psc_event_end_dt","psc_event_end_dt_2") \
.withColumnRenamed("group_change_key","group_change_key_2")

#display(AssignGrpKeyDF1)

#Rollup to get Max Group key:
w = Window.partitionBy('card_hldr_id')
RollUpAndGetMaxGrpKeyDF = RfmtPscEvntTabFinal_DF.select("*",count("card_hldr_id").over(w).alias("max_grp_chng_key")) \
.withColumn("group_change_key",col("max_grp_chng_key")).drop("max_grp_chng_key")

#display(RollUpAndGetMaxGrpKeyDF)

#Join to get latest record and Reformat as Target:
joinToGetLatestRecDF = RollUpAndGetMaxGrpKeyDF.join(AssignGrpKeyDF1,on=[RollUpAndGetMaxGrpKeyDF.card_hldr_id==AssignGrpKeyDF1.card_hldr_id_2,RollUpAndGetMaxGrpKeyDF.group_change_key==AssignGrpKeyDF1.group_change_key_2],how='inner').select(AssignGrpKeyDF1.card_hldr_id_2.alias("card_hldr_id"),AssignGrpKeyDF1.src_sys_cd_2.alias("src_sys_cd"),AssignGrpKeyDF1.psc_mbr_event_dt_2.alias("psc_mbr_event_dt"),AssignGrpKeyDF1.psc_mbr_event_type_2.alias("psc_mbr_event_type"),AssignGrpKeyDF1.psc_mbr_event_tm_2.alias("psc_mbr_event_tm"),AssignGrpKeyDF1.card_hldr_eff_dt_2.alias("card_hldr_eff_dt"),AssignGrpKeyDF1.psc_mbr_type_2.alias("psc_mbr_type"),AssignGrpKeyDF1.psc_event_location_nbr_2.alias("psc_event_location_nbr"),AssignGrpKeyDF1.authenticator_id_2.alias("authenticator_id"),AssignGrpKeyDF1.psc_mbr_paid_cd_2.alias("psc_mbr_paid_cd"),AssignGrpKeyDF1.psc_paid_dt_2.alias("psc_paid_dt"),AssignGrpKeyDF1.psc_paid_tm_2.alias("psc_paid_tm"),AssignGrpKeyDF1.emp_id_2.alias("emp_id"),AssignGrpKeyDF1.create_dttm_2.alias("create_dttm"),AssignGrpKeyDF1.psc_event_end_dt_2.alias("psc_event_end_dt"))

#display(joinToGetLatestRecDF)

# COMMAND ----------

#Reformat for old records:

RfmtOldRecordsDF = AssignGrpKeyDF1.join(RollUpAndGetMaxGrpKeyDF,on=[RollUpAndGetMaxGrpKeyDF.card_hldr_id==AssignGrpKeyDF1.card_hldr_id_2,RollUpAndGetMaxGrpKeyDF.group_change_key==AssignGrpKeyDF1.group_change_key_2],how='left_anti').select(AssignGrpKeyDF1.card_hldr_id_2.alias("card_hldr_id"),AssignGrpKeyDF1.src_sys_cd_2.alias("src_sys_cd"),AssignGrpKeyDF1.psc_mbr_event_dt_2.alias("psc_mbr_event_dt"),AssignGrpKeyDF1.psc_mbr_event_type_2.alias("psc_mbr_event_type"),AssignGrpKeyDF1.psc_mbr_event_tm_2.alias("psc_mbr_event_tm"),AssignGrpKeyDF1.card_hldr_eff_dt_2.alias("card_hldr_eff_dt"),AssignGrpKeyDF1.psc_mbr_type_2.alias("psc_mbr_type"),AssignGrpKeyDF1.psc_event_location_nbr_2.alias("psc_event_location_nbr"),AssignGrpKeyDF1.authenticator_id_2.alias("authenticator_id"),AssignGrpKeyDF1.psc_mbr_paid_cd_2.alias("psc_mbr_paid_cd"),AssignGrpKeyDF1.psc_paid_dt_2.alias("psc_paid_dt"),AssignGrpKeyDF1.psc_paid_tm_2.alias("psc_paid_tm"),AssignGrpKeyDF1.emp_id_2.alias("emp_id"),AssignGrpKeyDF1.create_dttm_2.alias("create_dttm"),AssignGrpKeyDF1.psc_event_end_dt_2.alias("psc_event_end_dt")) 

#display(RfmtOldRecordsDF)

sel_wcard_psc_event_tbl = "Select * FROM {0} where psc_event_end_dt is NULL and src_sys_cd=1".format(SNFL_TBL_NAME5)

wcardCardPscEvnt_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB2) \
     .option("query",sel_wcard_psc_event_tbl) \
     .load()

#display(wcardCardPscEvnt_tbl_df)

#Join to find existing records:

ExistingRecsDF = RfmtOldRecordsDF.join(wcardCardPscEvnt_tbl_df,on=[RfmtOldRecordsDF.card_hldr_id==wcardCardPscEvnt_tbl_df.CARD_HLDR_ID,RfmtOldRecordsDF.psc_mbr_event_type==wcardCardPscEvnt_tbl_df.PSC_MBR_EVENT_TYPE],how='left_anti')

#Union: 
UnionTransform1 = joinToGetLatestRecDF.union(ExistingRecsDF)

#Dedup Sorted - on Logical Keys:
DeDupLogicalKeyDF = UnionTransform1.select("*",row_number().over(Window.partitionBy("card_hldr_id","psc_mbr_event_type").orderBy(UnionTransform1.card_hldr_id,UnionTransform1.psc_mbr_event_type)).alias("row_num"))

DeDupLogicalKeyDF1 = WriteNullParquet(DeDupLogicalKeyDF.filter(DeDupLogicalKeyDF.row_num ==1).drop("row_num"))

#display(DeDupLogicalKeyDF1)
#OUF:  WCARD Psc Event Table:
print("wcard_psc_event Count: {}".format(DeDupLogicalKeyDF1.count()))
DeDupLogicalKeyDF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardPscEvntOutFile7+"/"+Batch_id)

# COMMAND ----------

#create wcard psc detail File-8:

#RFT: For Psc Detail Table:
RfmtPscDtlTabDF = RfmtEdwFormatDF.withColumn("psc_mbr_dtl_eff_dt",lit(EFF_DT)) \
.withColumn("card_send_dt",concat(substring(RfmtEdwFormatDF.card_send_dt,1,4),lit("-"),substring(RfmtEdwFormatDF.card_send_dt,5,2),lit("-"),substring(RfmtEdwFormatDF.card_send_dt,7,2))) \
.withColumn("mbr_term_dt",concat(substring(RfmtEdwFormatDF.mbr_term_dt,1,4),lit("-"),substring(RfmtEdwFormatDF.mbr_term_dt,5,2),lit("-"),substring(RfmtEdwFormatDF.mbr_term_dt,7,2))) \
.withColumn("psc_mbr_dtl_end_dt",lit(None))

RfmtPscDtlTabDF1 = RfmtPscDtlTabDF.join(WcardCH_FOR_EFF_DF,on=[RfmtPscDtlTabDF.card_hldr_id==WcardCH_FOR_EFF_DF.card_hldr_id,RfmtPscDtlTabDF.src_sys_cd==WcardCH_FOR_EFF_DF.src_sys_cd],how = 'left_outer') \
.select(RfmtPscDtlTabDF.card_hldr_id,RfmtPscDtlTabDF.src_sys_cd,WcardCH_FOR_EFF_DF.eff_dt,RfmtPscDtlTabDF.psc_mbr_dtl_eff_dt,RfmtPscDtlTabDF.psc_mbr_relation_cd,RfmtPscDtlTabDF.gndr,RfmtPscDtlTabDF.mktg_opt_in_ind,RfmtPscDtlTabDF.internal_actn_cd,RfmtPscDtlTabDF.batch_run_cd,RfmtPscDtlTabDF.psc_wcard_stat_cd,RfmtPscDtlTabDF.card_send_dt,RfmtPscDtlTabDF.card_send_tm,RfmtPscDtlTabDF.mbr_term_dt,RfmtPscDtlTabDF.mbr_term_tm,RfmtPscDtlTabDF.create_dttm,RfmtPscDtlTabDF.psc_mbr_dtl_end_dt)

RfmtPscDtlTabDF1 = RfmtPscDtlTabDF1.withColumn("card_hldr_eff_dt",when(RfmtPscDtlTabDF1.eff_dt.isNotNull(),RfmtPscDtlTabDF1.eff_dt).otherwise(lit(EFF_DT))).select("card_hldr_id","src_sys_cd","card_hldr_eff_dt","psc_mbr_dtl_eff_dt","psc_mbr_relation_cd","gndr","mktg_opt_in_ind","internal_actn_cd","batch_run_cd","psc_wcard_stat_cd","card_send_dt","card_send_tm","mbr_term_dt","mbr_term_tm","create_dttm","psc_mbr_dtl_end_dt")

RfmtPscDtlTabFinal_DF = RfmtPscDtlTabDF1.select("*",row_number().over(Window.partitionBy("card_hldr_id","card_hldr_eff_dt").orderBy(RfmtPscDtlTabDF1.card_hldr_id,RfmtPscDtlTabDF1.card_hldr_eff_dt)).alias("row_num")) 
RfmtPscDtlTabFinal_DF = WriteNullParquet(RfmtPscDtlTabFinal_DF.filter(RfmtPscDtlTabFinal_DF.row_num ==1).drop("row_num"))

#display(RfmtPscDtlTabFinal_DF)

#OUF: WCARD Psc Detail Table:
print("wcard_psc_dtl Count: {}".format(RfmtPscDtlTabFinal_DF.count()))
RfmtPscDtlTabFinal_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WCardPscDtlOutFile8+"/"+Batch_id)

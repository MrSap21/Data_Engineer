# Databricks notebook source
#Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#Widgets Declaration
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220919143037")
# dbutils.widgets.text("PAR_INPUT_FOLDER_POS_TENDER_ORD","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_INPUT_FILE_POS_TENDER_ORD","pos_tender_org_insert_ascii")
# dbutils.widgets.text("PAR_SNFK_WH","PROD_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_SNFK_DB_STAGING","PROD_STAGING")
# dbutils.widgets.text("PAR_SNFK_TABLE1","RETAIL_SALES.DIM_CARD_STG")
# dbutils.widgets.text("PAR_SNFK_DB_RETAIL","PROD_RETAIL")
# dbutils.widgets.text("PAR_SNFK_TABLE2","RETAIL_SALES.DIM_CARD")
# dbutils.widgets.text("PAR_OUTPUT_FOLDER_1","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_OUTPUT_FILE_1","dap_idl_sales_pos_tender_inter_ascii")
# dbutils.widgets.text("PAR_OUTPUT_FOLDER_2","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_OUTPUT_FILE_2","dap_idl_sales_pos_tender_insert_ascii")
# dbutils.widgets.text("PAR_OUTPUT_FOLDER_3","retail/retail_sales/output")
# dbutils.widgets.text("PAR_OUTPUT_FILE_3","dim_card_insert_ascii")

# COMMAND ----------

#Reading Parameters
PAR_DB_BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PAR_INPUT_FOLDER_POS_TENDER_ORD = dbutils.widgets.get("PAR_INPUT_FOLDER_POS_TENDER_ORD")
PAR_INPUT_FILE_POS_TENDER_ORD = dbutils.widgets.get("PAR_INPUT_FILE_POS_TENDER_ORD")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFK_DB_STAGING = dbutils.widgets.get("PAR_SNFK_DB_STAGING")
SNFK_TABLE1 = dbutils.widgets.get("PAR_SNFK_TABLE1")
SNFK_DB_RETAIL = dbutils.widgets.get("PAR_SNFK_DB_RETAIL")
SNFK_TABLE2 = dbutils.widgets.get("PAR_SNFK_TABLE2")
OUTPUT_FOLDER_1 = dbutils.widgets.get("PAR_OUTPUT_FOLDER_1")
OUTPUT_FILE_1 = dbutils.widgets.get("PAR_OUTPUT_FILE_1")
OUTPUT_FOLDER_2 = dbutils.widgets.get("PAR_OUTPUT_FOLDER_2")
OUTPUT_FILE_2 = dbutils.widgets.get("PAR_OUTPUT_FILE_2")
OUTPUT_FOLDER_3 = dbutils.widgets.get("PAR_OUTPUT_FOLDER_3")
OUTPUT_FILE_3 = dbutils.widgets.get("PAR_OUTPUT_FILE_3")

# COMMAND ----------

#Create pos_tender and dim_card files for load
#Importing Functions
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# Read pos_tender_org file
pos_tender_org_df=spark.read.parquet(mountPoint + '/' + PAR_INPUT_FOLDER_POS_TENDER_ORD + '/' + PAR_INPUT_FILE_POS_TENDER_ORD)

tf1=pos_tender_org_df.filter(((pos_tender_org_df.acct_nbr.isNull()) | (trim(pos_tender_org_df.acct_nbr)=="")) & ((pos_tender_org_df.card_token_val.isNotNull()) & (trim(pos_tender_org_df.card_token_val)!="")))

drop_duplicates_df=tf1.select('card_token_val').dropDuplicates(['card_token_val'])

tf2=pos_tender_org_df.filter(((pos_tender_org_df.acct_nbr.isNotNull()) & (trim(pos_tender_org_df.acct_nbr)!="")) | ((pos_tender_org_df.card_token_val.isNull()) | (trim(pos_tender_org_df.card_token_val)=="")))

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFK_DB_STAGING $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#lOAD to Staging DIM_CARD

delete_DIMCARDstg_snowflake = "Truncate table {0}.{1}".format(SNFK_DB_STAGING, SNFK_TABLE1)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_DIMCARDstg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFK_DB_STAGING,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

drop_duplicates_df.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFK_DB_STAGING) \
        .option("dbtable", SNFK_TABLE1) \
        .option("continue_on_error","on") \
        .save()

# COMMAND ----------

#Reformat_Card_ID

reformat_card_id_df=tf1.withColumn('card_id',lit(1)).withColumn('hash_key',lit('-1')).withColumn('encr_key',lit('-1'))

#Reformat to Pass only Credit Card
tf3=tf2.filter((tf2.card_token_val.isNotNull()) & (trim(tf2.card_token_val)!=""))

reformat_pass_credit_card_df=tf3.withColumn('card_id',lit(-1)).withColumn('hash_key',lit('-1')).withColumn('encr_key',lit('-1'))

tf4=tf2.filter((tf2.card_token_val.isNull()) | (trim(tf2.card_token_val)==""))

reformat_pass_credit_card_df_t2=tf4.withColumn('card_id',lit(-1)).withColumn('hash_key',lit('-1')).withColumn('e2c_f6c',lit(None)).withColumn('e2c_l4c',lit('-1'))

#Gathertokens
gather_df=reformat_card_id_df.union(reformat_pass_credit_card_df)

# COMMAND ----------

#Extracting dim_card_stg table data
Select_query= "select card_token_val,e2c_f6c,e2c_l4c from "+SNFK_DB_RETAIL+"."+SNFK_TABLE2+" where card_token_val in (select card_token_val from " + SNFK_DB_STAGING + "." + SNFK_TABLE1 +") or card_token_val = '999999A9999999B9999'"

table_data=spark.read \
      .format("snowflake") \
      .options(**options) \
      .option("sfWarehouse", SNFL_WH) \
      .option("sfDatabase",SNFK_DB_STAGING) \
      .option("query",Select_query) \
      .load()

rename_table_columns=table_data.selectExpr("CARD_TOKEN_VAL as card_token_val","E2c_F6C as e2c_f6c","E2C_L4C as e2c_l4c")

dedup_table_data=rename_table_columns.dropDuplicates(["card_token_val"])
#inner join Assigning card_id's for existing cards

inner_join_df=gather_df.join(dedup_table_data,trim(gather_df.card_token_val).cast(StringType())==trim(dedup_table_data.card_token_val).cast(StringType()),"inner")

select_inner_join_df=inner_join_df.withColumn("acct_nbr",when(((gather_df.acct_nbr.isNull()) | (trim(gather_df.acct_nbr)=="")) & ((gather_df.card_token_val.isNotNull()) & (trim(gather_df.card_token_val)!="")),gather_df.card_token_val.substr(-4,4)).otherwise(gather_df.acct_nbr)).select(gather_df.txn_id,gather_df.txn_dt,gather_df.tndr_type_cd,gather_df.tndr_dlrs,gather_df.tndr_seq_nbr,gather_df.entry_mode_cd,gather_df.card_id,col("acct_nbr"),gather_df.card_token_val,gather_df.ck_bank_route_nbr,gather_df.ck_nbr,gather_df.expire_dt,gather_df.loc_id,gather_df.hash_key,gather_df.sequence_nbr,dedup_table_data.e2c_f6c,dedup_table_data.e2c_l4c)

#Anti_inner_join Filtering new cardtransactions

left_anti_join_df=gather_df.join(dedup_table_data,trim(gather_df.card_token_val).cast(StringType())==trim(dedup_table_data.card_token_val).cast(StringType()),"leftanti")

# COMMAND ----------

#Generate card ids not for transactions not in dim_card table

anti_inner_join_row_df=left_anti_join_df.withColumn("row_num",row_number().over(Window.partitionBy("card_token_val").orderBy(col('card_token_val'),col('sequence_nbr').desc())))

dedup_anti_inner_join_df = anti_inner_join_row_df.filter(anti_inner_join_row_df.row_num == 1).drop("row_num")

dup_anti_inner_join_df = anti_inner_join_row_df.filter(anti_inner_join_row_df.row_num !=1).drop("row_num").withColumnRenamed("card_token_val","card_token_val_1").withColumnRenamed("acct_nbr","acct_nbr_1")

#Extracting Max_card_ID
lkp_query= "select 'max_card_id' as lkp_key,max(card_id) as max_card_id  from "+SNFK_DB_RETAIL+"."+SNFK_TABLE2

lkp_card_id=spark.read \
      .format("snowflake") \
      .options(**options) \
      .option("sfWarehouse", SNFL_WH) \
      .option("sfDatabase",SNFK_DB_RETAIL) \
      .option("query",lkp_query) \
      .load()

#catching max_card_id

TMP_CARD_ID=int(lkp_card_id.withColumn("max_card_id",when(lkp_card_id.MAX_CARD_ID.isNull(),"0") \
                                          .otherwise(lkp_card_id.MAX_CARD_ID)).select("MAX_CARD_ID").collect()[0].MAX_CARD_ID)
#Generating Card_id

DIMCard_Final1 = dedup_anti_inner_join_df.withColumn("card_id",row_number().over(Window.orderBy("card_token_val"))+TMP_CARD_ID) 

#Transform data  to pos_tender_card
DIMCard_Final2=DIMCard_Final1.withColumn("e2c_l4c",when(((DIMCard_Final1.acct_nbr.isNull()) | (trim(DIMCard_Final1.acct_nbr)=="")) & ((DIMCard_Final1.card_token_val.isNotNull()) & (trim(DIMCard_Final1.card_token_val)!="")),DIMCard_Final1.card_token_val.substr(-4,4)).otherwise(gather_df.acct_nbr)) \
.withColumn("e2c_f6c",regexp_extract(col("card_token_val"),r'[0-9]+',0)) \
.withColumn("acct_nbr",when(((DIMCard_Final1.acct_nbr.isNull()) | (trim(DIMCard_Final1.acct_nbr)=="")) & ((DIMCard_Final1.card_token_val.isNotNull()) & (trim(DIMCard_Final1.card_token_val)!="")),DIMCard_Final1.card_token_val.substr(-4,4)).otherwise(DIMCard_Final1.acct_nbr)).drop(DIMCard_Final1.encr_key)

#Transform data  to dim_card structures 

DIMCard_Final3=DIMCard_Final1.withColumn("e2c_l4c",when(((DIMCard_Final1.acct_nbr.isNull()) | (trim(DIMCard_Final1.acct_nbr)=="")) & ((DIMCard_Final1.card_token_val.isNotNull()) & (trim(DIMCard_Final1.card_token_val)!="")),DIMCard_Final1.card_token_val.substr(-4,4)).otherwise(gather_df.acct_nbr)) \
.withColumn("e2c_f6c",regexp_extract(col("card_token_val"),r'[0-9]+',0)).selectExpr(['card_id','e2c_f6c','e2c_l4c','tndr_type_cd','card_token_val','txn_dt as latest_txn_dt']).filter(trim(col('card_token_val'))!="")

#Join- Assign newly created cards ids to the other transactions of the same card

new_card_join=DIMCard_Final1.join(dup_anti_inner_join_df,trim(DIMCard_Final1.card_token_val).cast(StringType()) == trim(dup_anti_inner_join_df.card_token_val_1).cast(StringType()),"inner") \
.withColumn("e2c_l4c",when(((DIMCard_Final1.acct_nbr.isNull()) | (trim(DIMCard_Final1.acct_nbr)=="")) & ((DIMCard_Final1.card_token_val.isNotNull()) & (trim(DIMCard_Final1.card_token_val)!="")),DIMCard_Final1.card_token_val.substr(-4,4)).otherwise(gather_df.acct_nbr)) \
.withColumn("e2c_f6c",regexp_extract(dup_anti_inner_join_df.card_token_val_1,r'[0-9]+',0)) \
.withColumn("acct_nbr",when(((dup_anti_inner_join_df.acct_nbr_1.isNull()) | (trim(dup_anti_inner_join_df.acct_nbr_1)=="")) & ((dup_anti_inner_join_df.card_token_val_1.isNotNull()) & (trim(dup_anti_inner_join_df.card_token_val_1)!="")),dup_anti_inner_join_df.card_token_val_1.substr(-4,4)).otherwise(dup_anti_inner_join_df.acct_nbr_1)).drop(dup_anti_inner_join_df.card_id).drop(dup_anti_inner_join_df.acct_nbr_1).drop(DIMCard_Final1.card_token_val).withColumnRenamed("card_token_val_1","card_token_val").drop(DIMCard_Final1.tndr_type_cd).drop(DIMCard_Final1.txn_id).drop(DIMCard_Final1.txn_dt).drop(DIMCard_Final1.tndr_dlrs).drop(DIMCard_Final1.tndr_seq_nbr).drop(DIMCard_Final1.entry_mode_cd).drop(DIMCard_Final1.ck_bank_route_nbr).drop(DIMCard_Final1.ck_nbr).drop(DIMCard_Final1.expire_dt).drop(DIMCard_Final1.loc_id).drop(DIMCard_Final1.sequence_nbr).drop(DIMCard_Final1.hash_key).drop("encr_key")

# COMMAND ----------

#Union of all inputs to File

pos_tender_inter_df_union=reformat_pass_credit_card_df_t2.unionByName(select_inner_join_df).unionByName(DIMCard_Final2).unionByName(new_card_join)
pos_tender_inter_df=pos_tender_inter_df_union.select('txn_id','txn_dt','tndr_type_cd','card_id','tndr_dlrs','tndr_seq_nbr','entry_mode_cd','acct_nbr','card_token_val','ck_bank_route_nbr','ck_nbr','expire_dt','loc_id','hash_key','sequence_nbr','e2c_f6c','e2c_l4c')

#writing dap_idl_sales_pos_tender_inter_ascii to parquet
print("dap_idl_sales_pos_tender_inter_ascii.pipe_delim OutPut File Count:{}".format(pos_tender_inter_df.count()))
pos_tender_inter_df.write.format("parquet").mode("overwrite").save(mountPoint+"/"+OUTPUT_FOLDER_1+"/"+OUTPUT_FILE_1+"/"+PAR_DB_BATCH_ID)

#Reformat for pos_tender_insert_ascii
pos_tender_insert_ascii=pos_tender_inter_df.drop("hash_key","sequence_nbr","e2c_f6c","e2c_l4c","card_token_val")

#writing dap_idl_sales_pos_tender_insert_ascii to parquet
print("dap_idl_sales_pos_tender_insert_ascii.pipe_delim OutPut File Count:{}".format(pos_tender_inter_df.count()))
pos_tender_insert_ascii.write.format("parquet").mode("overwrite").save(mountPoint+"/"+OUTPUT_FOLDER_2+"/"+OUTPUT_FILE_2+"/"+PAR_DB_BATCH_ID)

# COMMAND ----------

#Write dim_card_insert_ascii to parquet
DIMCard_Final3 = DIMCard_Final3.select("card_id","card_token_val","latest_txn_dt","e2c_f6c","e2c_l4c","tndr_type_cd")

print("dim_card_insert_ascii.pipe_delim OutPut File Count:{}".format(DIMCard_Final3.count()))
DIMCard_Final3.write.format("parquet").mode("overwrite").save(mountPoint+"/"+OUTPUT_FOLDER_3+"/"+OUTPUT_FILE_3+"/"+PAR_DB_BATCH_ID)

#Writing to taget DIM_CARD will be done in next copy activity in pipeline

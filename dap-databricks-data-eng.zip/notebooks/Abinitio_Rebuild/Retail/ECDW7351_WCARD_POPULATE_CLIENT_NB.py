# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#Widgets for passing required parameters values
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220511071019")
# dbutils.widgets.text("PAR_FEED_NAME","WCARD_PROFILE_ID,WCARD_MEMBER_ID_TYPE,WCARD_PROGRAM_TYPES,WCARD_ADDL_INFO,WCARD_SETUP")
# dbutils.widgets.text("PAR_INPUT_FILELIST1","")
# dbutils.widgets.text("PAR_INPUT_FILELIST2","")
# dbutils.widgets.text("PAR_INPUT_FILELIST3","")
# dbutils.widgets.text("PAR_INPUT_FILELIST4","")
# dbutils.widgets.text("PAR_INPUT_FILELIST5","")
# dbutils.widgets.text("PAR_INPUT_FILELIST6","")
# dbutils.widgets.text("PAR_INPUT_FILELIST7","")
# dbutils.widgets.text("PAR_INPUT_FILELIST8","")
# dbutils.widgets.text("PAR_INPUT_FILELIST9","")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_PSC_SRCSYSCD_LKP_FILE","wcard_source_system_code_ascii.pipe_delim_lkp")
# dbutils.widgets.text("PAR_OUT_FILE1","wcard_profile")
# dbutils.widgets.text("PAR_OUT_FILE2","wcard_member_identifier_type_insert_ascii.pipe_delim")
# dbutils.widgets.text("PAR_OUT_FILE3","wcard_program_type_insert_ascii.pipe_delim")
# dbutils.widgets.text("PAR_OUT_FILE4","wcard_address_type")
# dbutils.widgets.text("PAR_OUT_FILE5","wcard_contact_type")
# dbutils.widgets.text("PAR_OUT_FILE6","wcard_client")
# dbutils.widgets.text("PAR_OUT_FILE7","wcard_program_contact_channel")
# dbutils.widgets.text("PAR_OUT_FILE8","wcard_program_contact")
# dbutils.widgets.text("PAR_OUT_FILE9","wcard_program")
# dbutils.widgets.text("PAR_OUT_FILE10","wcard_cardholder")
# dbutils.widgets.text("PAR_OUT_FILE11","wcard_cardholder_name")
# dbutils.widgets.text("PAR_OUT_FILE12","wcard_cardholder_address")
# dbutils.widgets.text("PAR_OUT_FILE13","wcard_cardholder_contact")
# dbutils.widgets.text("PAR_OUT_FILE14","wcard_contact_channel_type_insert_ascii.pipe_delim")
# dbutils.widgets.text("PAR_OUT_FILE15","wcard_account")
# dbutils.widgets.text("PAR_OUT_FILE16","wcard_account_cardholder")
# dbutils.widgets.text("PAR_OUT_FILE17","wcard_program_contact_address")


# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Input_Filelist1 = dbutils.widgets.get("PAR_INPUT_FILELIST1")
Input_Filelist2 = dbutils.widgets.get("PAR_INPUT_FILELIST2")
Input_Filelist3 = dbutils.widgets.get("PAR_INPUT_FILELIST3")
Input_Filelist4 = dbutils.widgets.get("PAR_INPUT_FILELIST4")
Input_Filelist5 = dbutils.widgets.get("PAR_INPUT_FILELIST5")
Input_Filelist6 = dbutils.widgets.get("PAR_INPUT_FILELIST6")
Input_Filelist7 = dbutils.widgets.get("PAR_INPUT_FILELIST7")
Input_Filelist8 = dbutils.widgets.get("PAR_INPUT_FILELIST8")
Input_Filelist9 = dbutils.widgets.get("PAR_INPUT_FILELIST9")
staging_folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
PscSrcSysCd_LKPFile = dbutils.widgets.get("PAR_PSC_SRCSYSCD_LKP_FILE")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
Out_file1 = dbutils.widgets.get("PAR_OUT_FILE1")
Out_file2 = dbutils.widgets.get("PAR_OUT_FILE2")
Out_file3 = dbutils.widgets.get("PAR_OUT_FILE3")
Out_file4 = dbutils.widgets.get("PAR_OUT_FILE4")
Out_file5 = dbutils.widgets.get("PAR_OUT_FILE5")
Out_file6 = dbutils.widgets.get("PAR_OUT_FILE6")
Out_file7 = dbutils.widgets.get("PAR_OUT_FILE7")
Out_file8 = dbutils.widgets.get("PAR_OUT_FILE8")
Out_file9 = dbutils.widgets.get("PAR_OUT_FILE9")
Out_file10 = dbutils.widgets.get("PAR_OUT_FILE10")
Out_file11 = dbutils.widgets.get("PAR_OUT_FILE11")
Out_file12 = dbutils.widgets.get("PAR_OUT_FILE12")
Out_file13 = dbutils.widgets.get("PAR_OUT_FILE13")
Out_file14 = dbutils.widgets.get("PAR_OUT_FILE14")
Out_file15 = dbutils.widgets.get("PAR_OUT_FILE15")
Out_file16 = dbutils.widgets.get("PAR_OUT_FILE16")
Out_file17 = dbutils.widgets.get("PAR_OUT_FILE17")

# COMMAND ----------

#Convert json asset location/filname to FIle Name List
import json
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

inputFileList1 = dbutils.widgets.get("PAR_INPUT_FILELIST1")
rddjson1 = sc.parallelize([inputFileList1])
#print(rddjson.collect())
dfFileList1 = sqlContext.read.json(rddjson1)
dfRaw1 = dfFileList1.select(concat(lit('/'),dfFileList1.assetcurrentlocation,dfFileList1.assetname).alias('full_filename'))
WCARD_PROFILE_ID_filepath = dfRaw1.select("full_filename").collect()[0].full_filename

#display(dfRaw1)

EFF_DT = WCARD_PROFILE_ID_filepath
if len(EFF_DT)!=0:
  EFF_DT = ((EFF_DT).split("_")[-1])[:8]
  
EFF_DT = EFF_DT[:4]+"-"+EFF_DT[4:6]+"-"+EFF_DT[6:]  
print("EFF_DT : {}".format(EFF_DT))

inputFileList2 = dbutils.widgets.get("PAR_INPUT_FILELIST2")
rddjson2 = sc.parallelize([inputFileList2])
#print(rddjson.collect())
dfFileList2 = sqlContext.read.json(rddjson2)
dfRaw2 = dfFileList2.select(concat(lit('/'),dfFileList2.assetcurrentlocation,dfFileList2.assetname).alias('full_filename'))
WCARD_MEMBER_ID_TYPE_filepath = dfRaw2.select("full_filename").collect()[0].full_filename
#display(dfRaw2)

inputFileList3 = dbutils.widgets.get("PAR_INPUT_FILELIST3")
rddjson3 = sc.parallelize([inputFileList3])
#print(rddjson.collect())
dfFileList3 = sqlContext.read.json(rddjson3)
dfRaw3 = dfFileList3.select(concat(lit('/'),dfFileList3.assetcurrentlocation,dfFileList3.assetname).alias('full_filename'))
WCARD_PROGRAM_TYPES_filepath = dfRaw3.select("full_filename").collect()[0].full_filename
#display(dfRaw3)

inputFileList4 = dbutils.widgets.get("PAR_INPUT_FILELIST4")
rddjson4 = sc.parallelize([inputFileList4])
#print(rddjson.collect())
dfFileList4 = sqlContext.read.json(rddjson4)
dfRaw4 = dfFileList4.select(concat(lit('/'),dfFileList4.assetcurrentlocation,dfFileList4.assetname).alias('full_filename'))
WCARD_ADDL_INFO_filepath = dfRaw4.select("full_filename").collect()[0].full_filename
#display(dfRaw4)

inputFileList5 = dbutils.widgets.get("PAR_INPUT_FILELIST5")
rddjson5 = sc.parallelize([inputFileList5])
#print(rddjson.collect())
dfFileList5 = sqlContext.read.json(rddjson5)
dfRaw5 = dfFileList5.select(concat(lit('/'),dfFileList5.assetcurrentlocation,dfFileList5.assetname).alias('full_filename'))
WCARD_SETUP_filepath = dfRaw5.select("full_filename").collect()[0].full_filename
#display(dfRaw5)

inputFileList6 = dbutils.widgets.get("PAR_INPUT_FILELIST6")
rddjson6 = sc.parallelize([inputFileList6])
#print(rddjson.collect())
dfFileList6 = sqlContext.read.json(rddjson6)
dfRaw6 = dfFileList6.select(concat(lit('/'),dfFileList6.assetcurrentlocation,dfFileList6.assetname).alias('full_filename'))
WCARD_CLIENT_filepath = dfRaw6.select("full_filename").collect()[0].full_filename
#display(dfRaw6)

inputFileList7 = dbutils.widgets.get("PAR_INPUT_FILELIST7")
rddjson7 = sc.parallelize([inputFileList7])
#print(rddjson.collect())
dfFileList7 = sqlContext.read.json(rddjson7)
dfRaw7 = dfFileList7.select(concat(lit('/'),dfFileList7.assetcurrentlocation,dfFileList7.assetname).alias('full_filename'))
WCARD_MSTR_filepath = dfRaw7.select("full_filename").collect()[0].full_filename
#display(dfRaw7)

inputFileList8 = dbutils.widgets.get("PAR_INPUT_FILELIST8")
rddjson8 = sc.parallelize([inputFileList8])
#print(rddjson.collect())
dfFileList8 = sqlContext.read.json(rddjson8)
dfRaw8 = dfFileList8.select(concat(lit('/'),dfFileList8.assetcurrentlocation,dfFileList8.assetname).alias('full_filename'))
WCARD_CARDHLDR_INFORMATION_filepath = dfRaw8.select("full_filename").collect()[0].full_filename
#display(dfRaw8)

inputFileList9 = dbutils.widgets.get("PAR_INPUT_FILELIST9")
rddjson9 = sc.parallelize([inputFileList9])
#print(rddjson.collect())
dfFileList9 = sqlContext.read.json(rddjson9)
dfRaw9 = dfFileList9.select(concat(lit('/'),dfFileList9.assetcurrentlocation,dfFileList9.assetname).alias('full_filename'))
WCARD_WCARD_MAPPING_filepath = dfRaw9.select("full_filename").collect()[0].full_filename
#display(dfRaw9)

# COMMAND ----------

# wcard_source_system_code_ascii.pipe_delim_lkp:
pscSrcSysCdLkpDF = spark.read.format("csv").option("delimiter","|").load(mountPoint+"/"+Lookup_folder+"/"+PscSrcSysCd_LKPFile) \
.withColumnRenamed("_c0","src_sys_cd") \
.withColumnRenamed("_c1","src_sys_desc")
#display(pscSrcSysCdLkpDF)

# COMMAND ----------

#Defining schema for WCARD_PROFILE_ID source file:
from pyspark.sql.types import *
Source_Schema1 = ['profile_number',
'profile_description']
schema1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema1)))

Source_Schema2 = ['mbr_id_type_cd',
'mbr_id_type_desc']
schema2 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema2)))

Source_Schema3 = ['prog_type_cd',
'prog_type_desc']
schema3 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema3)))
#print(schema1)
#print(schema2)
#print(schema3)
WCARD_PROFILE_DF = spark.read.format("csv").option("delimiter","|").schema(schema1).load(mountPoint+WCARD_PROFILE_ID_filepath)
WCARD_MEMBER_DF = spark.read.format("csv").option("delimiter","|").schema(schema2).load(mountPoint+WCARD_MEMBER_ID_TYPE_filepath)
WCARD_PROGRAM_DF = spark.read.format("csv").option("delimiter","|").schema(schema3).load(mountPoint+WCARD_PROGRAM_TYPES_filepath)

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------

#Sort on profile_number profile_description and Dedup Sorted profile_number profile_description:
from pyspark.sql.window import Window

WCARD_PROFILE_FieldNamesDF = WCARD_PROFILE_DF.select("profile_number","profile_description")

SortProfileDF = WCARD_PROFILE_FieldNamesDF.select("*", row_number().over(Window.partitionBy("profile_number","profile_description").orderBy(WCARD_PROFILE_FieldNamesDF.profile_number,WCARD_PROFILE_FieldNamesDF.profile_description)).alias("row_num"))

SortProfileDF1 = SortProfileDF.filter(SortProfileDF.row_num ==1).drop("row_num")
#display(SortProfileDF1)
dedupDF = SortProfileDF1.select("*", row_number().over(Window.partitionBy("profile_number").orderBy(SortProfileDF1.profile_number)).alias("row_num"))

dedupDF1 = dedupDF.filter(dedupDF.row_num ==1).drop("row_num")

#RFMT
RFMTProfileDF= dedupDF1.withColumn("profile_id",dedupDF1.profile_number) \
.withColumn("profile_desc",dedupDF1.profile_description) \
.withColumn("profile_eff_dt",lit(EFF_DT)) \
.withColumn("profile_end_dt",lit(None))
#display(RFMTProfileDF)
RFMTProfileDF1 = WriteNullParquet(RFMTProfileDF.select("profile_id","profile_desc","profile_eff_dt","profile_end_dt"))

#writing outputfile wcard_profile.dat to Staging folder
RFMTProfileDF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file1+"/"+Batch_id)

# COMMAND ----------

#Sort on mbr_id_type_cd,mbr_id_type_desc and Dedup Sorted mbr_id_type_cd,mbr_id_type_desc:
from pyspark.sql.window import Window

WCARD_MemberID_DF = WCARD_MEMBER_DF.select("mbr_id_type_cd","mbr_id_type_desc")

SortMemberDF = WCARD_MemberID_DF.select("*", row_number().over(Window.partitionBy("mbr_id_type_cd","mbr_id_type_desc").orderBy(WCARD_MemberID_DF.mbr_id_type_cd,WCARD_MemberID_DF.mbr_id_type_desc)).alias("row_num"))

SortMemberDF1 = SortMemberDF.filter(SortMemberDF.row_num ==1).drop("row_num")

dedupMemberDF = SortMemberDF1.select("*", row_number().over(Window.partitionBy("mbr_id_type_cd").orderBy(SortMemberDF1.mbr_id_type_cd)).alias("row_num"))

dedupMemberDF1 = dedupMemberDF.filter(dedupMemberDF.row_num ==1).drop("row_num")
#RFMT
RFMTMemberDF= dedupMemberDF1.withColumn("mbr_id_type_cd",dedupMemberDF1.mbr_id_type_cd) \
.withColumn("mbr_id_type_desc",dedupMemberDF1.mbr_id_type_desc)

RFMTMemberDF1 = WriteNullParquet(RFMTMemberDF.select("mbr_id_type_cd","mbr_id_type_desc"))

#writing outputfile wcard_member_identifier_type_insert_ascii.pipe_delim to Staging folder
RFMTMemberDF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file2+"/"+Batch_id)

# COMMAND ----------

#Sort on prog_type_cd,prog_type_desc and Dedup Sorted prog_type_cd,prog_type_desc:
from pyspark.sql.window import Window

WCARD_ProgramTYP_DF = WCARD_PROGRAM_DF.select("prog_type_cd","prog_type_desc")

SortProgramDF = WCARD_ProgramTYP_DF.select("*", row_number().over(Window.partitionBy("prog_type_cd","prog_type_desc").orderBy(WCARD_ProgramTYP_DF.prog_type_cd,WCARD_ProgramTYP_DF.prog_type_desc)).alias("row_num"))

SortProgramDF1 = SortProgramDF.filter(SortProgramDF.row_num ==1).drop("row_num")

dedupProgramDF = SortProgramDF1.select("*", row_number().over(Window.partitionBy("prog_type_cd").orderBy(SortProgramDF1.prog_type_cd)).alias("row_num"))

dedupProgramDF1 = dedupProgramDF.filter(dedupProgramDF.row_num ==1).drop("row_num")
#RFMT
RFMTProgramDF= dedupProgramDF1.withColumn("prog_type_cd",dedupProgramDF1.prog_type_cd) \
.withColumn("prog_type_desc",dedupProgramDF1.prog_type_desc)

RFMTProgramDF1 = WriteNullParquet(RFMTProgramDF.select("prog_type_cd","prog_type_desc"))

#writing outputfile wcard_member_identifier_type_insert_ascii.pipe_delim to Staging folder
RFMTProgramDF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file3+"/"+Batch_id)

# COMMAND ----------

#Defining schema for WCARD_ADDL_INFO,WCARD_SETUP source file:
from pyspark.sql.types import *
Src_ADDL_Schema1 = ['client_addl_seq_id',
'client_seq_id',
'record_type',
'name',
'title',
'phone',
'email',
'fax',
'addr1',
'addr2',
'state',
'city',
'zip',
'crtd_by',
'crtd_dt',
'mdfd_by',
'mdfd_dt']
ADDL_schema1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Src_ADDL_Schema1)))

Src_SETUP_Schema2 =['client_setup_seq_id',
'client_seq_id',
'client_num',
'client_dscnt_pct',
'mbr_rebt_pct',
'profile_num',
'client_amt_rqstd',
'wag_brand_rebt_ind',
'acct_actn',
'reject_files_ind',
'mbr_id_type',
'trmntd_f',
'trmntd_dt',
'crtd_by',
'crtd_dt',
'mdfd_by',
'mdfd_dt',
'client_sends_cardnum',
'client_sends_amt',
'gnrt_inv',
'actvt_reqd',
'client_sends_numofcards',
'dflt_rebt_pct',
'bulk_ship_ind',
'new_card_charge',
'source_id',
'initial_dollar_amt_ind',
'initial_dollar_amt',
'crd_manf_mstr_id',
'letter_type_id',
'material_id',
'include_cover_letter',
'inital_amt_for',
'first_file_procsd']

SETUP_schema2 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Src_SETUP_Schema2)))
WCARD_ADDL_DF = spark.read.format("csv").option("delimiter","").schema(ADDL_schema1).load(mountPoint+WCARD_ADDL_INFO_filepath)
WCARD_SETUP_DF = spark.read.format("csv").option("delimiter","|").schema(SETUP_schema2).load(mountPoint+WCARD_SETUP_filepath)

# COMMAND ----------

#Sort and dedup on 

dedupADDLDF = WCARD_ADDL_DF.dropDuplicates(["client_addl_seq_id","client_seq_id","record_type","name","title","phone","email","fax","addr1","addr2","state","city","zip","crtd_by","crtd_dt","mdfd_by","mdfd_dt"])

dedupADDLDF1 = dedupADDLDF.select(col("record_type")).distinct()

#Sort and dedup on WCARD_SETUP

SortSETUP_DF = WCARD_SETUP_DF.select("*", row_number().over(Window.partitionBy("client_setup_seq_id","client_seq_id","client_num","client_dscnt_pct","mbr_rebt_pct","profile_num","client_amt_rqstd","wag_brand_rebt_ind","acct_actn","reject_files_ind","mbr_id_type","trmntd_f","trmntd_dt","crtd_by","crtd_dt","mdfd_by","mdfd_dt","client_sends_cardnum","client_sends_amt","gnrt_inv","actvt_reqd","client_sends_numofcards","dflt_rebt_pct","bulk_ship_ind","new_card_charge","source_id","initial_dollar_amt_ind","initial_dollar_amt","crd_manf_mstr_id","letter_type_id","material_id","include_cover_letter","inital_amt_for","first_file_procsd").orderBy(WCARD_SETUP_DF.client_setup_seq_id,WCARD_SETUP_DF.client_seq_id,WCARD_SETUP_DF.client_num,WCARD_SETUP_DF.client_dscnt_pct,WCARD_SETUP_DF.mbr_rebt_pct,WCARD_SETUP_DF.profile_num,WCARD_SETUP_DF.client_amt_rqstd,WCARD_SETUP_DF.wag_brand_rebt_ind,WCARD_SETUP_DF.acct_actn,WCARD_SETUP_DF.reject_files_ind,WCARD_SETUP_DF.mbr_id_type,WCARD_SETUP_DF.trmntd_f,WCARD_SETUP_DF.trmntd_dt,WCARD_SETUP_DF.crtd_by,WCARD_SETUP_DF.crtd_dt,WCARD_SETUP_DF.mdfd_by,WCARD_SETUP_DF.mdfd_dt,WCARD_SETUP_DF.client_sends_cardnum,WCARD_SETUP_DF.client_sends_amt,WCARD_SETUP_DF.gnrt_inv,WCARD_SETUP_DF.actvt_reqd,WCARD_SETUP_DF.client_sends_numofcards,WCARD_SETUP_DF.dflt_rebt_pct,WCARD_SETUP_DF.bulk_ship_ind,WCARD_SETUP_DF.new_card_charge,WCARD_SETUP_DF.source_id,WCARD_SETUP_DF.initial_dollar_amt_ind,WCARD_SETUP_DF.initial_dollar_amt,WCARD_SETUP_DF.crd_manf_mstr_id,WCARD_SETUP_DF.letter_type_id,WCARD_SETUP_DF.material_id,WCARD_SETUP_DF.include_cover_letter,WCARD_SETUP_DF.inital_amt_for,WCARD_SETUP_DF.first_file_procsd)).alias("row_num"))
SortSETUP_DF1 = SortSETUP_DF.filter(SortSETUP_DF.row_num ==1).drop("row_num")

#RFMT on SortSETUP_DF1
RFMT_SETUP = SortSETUP_DF1.withColumn("trmntd_dt",when((SortSETUP_DF1.trmntd_dt.isNotNull()) & (SortSETUP_DF1.trmntd_dt!="")
,SortSETUP_DF1.trmntd_dt).otherwise(lit("")))

#SORT on RFMT_SETUP
dedupSETUP_DF = SortSETUP_DF1.select("*", row_number().over(Window.partitionBy("client_seq_id").orderBy(SortSETUP_DF1.client_seq_id)).alias("row_num"))
dedupSETUP_DF1 = dedupSETUP_DF.filter(dedupSETUP_DF.row_num ==1).drop("row_num")
dedupSETUP_DF1 = dedupSETUP_DF1.select("client_setup_seq_id","client_seq_id","client_num","client_dscnt_pct","mbr_rebt_pct","profile_num","client_amt_rqstd","wag_brand_rebt_ind","acct_actn","reject_files_ind","mbr_id_type","trmntd_f","trmntd_dt","client_sends_cardnum","client_sends_amt","gnrt_inv","actvt_reqd","dflt_rebt_pct","client_sends_numofcards","bulk_ship_ind","new_card_charge","initial_dollar_amt_ind","initial_dollar_amt","crd_manf_mstr_id","letter_type_id","material_id","include_cover_letter","inital_amt_for","first_file_procsd","source_id")

dedupADDLDF = dedupADDLDF.select("client_addl_seq_id","client_seq_id","record_type","name","title","phone","email","fax","addr1","addr2","state","city","zip","crtd_by","crtd_dt","mdfd_by","mdfd_dt")

# COMMAND ----------

#rollup on
ROOLUP_ADDL_DF = dedupADDLDF1.withColumn("type_desc",when(dedupADDLDF1.record_type=="CON",lit("CONTACT")).when(dedupADDLDF1.record_type=="SHI",lit("SHIPPING")).when(dedupADDLDF1.record_type=="BLKSHP",lit("BULK SHIPPING")).when(dedupADDLDF1.record_type=="TEC",lit("TECHNICAL")).when(dedupADDLDF1.record_type=="GEN",lit("GENERAL")).when(dedupADDLDF1.record_type=="BIL",lit("BILLING")).otherwise(lit("unknown"))) \
.withColumn("type_cd",dedupADDLDF1.record_type)

#RFMT ON convert to address typ table
RFMT_ADDL_typ = ROOLUP_ADDL_DF.withColumn("addr_type_cd",ROOLUP_ADDL_DF.type_cd) \
.withColumn("addr_type_desc",ROOLUP_ADDL_DF.type_desc) \
.withColumn("cntc_type_cd",ROOLUP_ADDL_DF.type_cd) \
.withColumn("cntc_type_desc",ROOLUP_ADDL_DF.type_desc)

# Generating wcard_address_type.dat to staging folder

select_RFMT_ADDL_typ = RFMT_ADDL_typ.select("addr_type_cd","addr_type_desc")
address_type = WriteNullParquet(select_RFMT_ADDL_typ.select("addr_type_cd","addr_type_desc"))

#writing outputfile wcard_address_type.dat to Staging folder
address_type.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file4+"/"+Batch_id)

#Generating wcard_contact_type.dat to staging folder
select_RFMT_ADDL_typ1 = RFMT_ADDL_typ.select("cntc_type_cd","cntc_type_desc")
select_RFMT_ADDL_typ1 = select_RFMT_ADDL_typ1.collect()
select_RFMT_ADDL_typ1.append({"cntc_type_cd":"ACCTMGR","cntc_type_desc":"ACCOUNT MANAGER"})
select_RFMT_ADDL_typ1 = spark.createDataFrame(select_RFMT_ADDL_typ1)

contact_type = WriteNullParquet(select_RFMT_ADDL_typ1.select("cntc_type_cd","cntc_type_desc"))

contact_type.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file5+"/"+Batch_id)

# COMMAND ----------

#Filter by GEN 
ADDL_FILTER_DF = dedupADDLDF.filter(dedupADDLDF1.record_type == "GEN")

#sort and dedup on create wcard client
from pyspark.sql.window import Window

ADDL_FLTR_SortADDLDF = ADDL_FILTER_DF.select("*", row_number().over(Window.partitionBy("client_seq_id","crtd_dt").orderBy(ADDL_FILTER_DF.client_seq_id,ADDL_FILTER_DF.crtd_dt)).alias("row_num"))
ADDL_FLTR_SortADDLDF1 = ADDL_FLTR_SortADDLDF.filter(ADDL_FLTR_SortADDLDF.row_num ==1).drop("row_num")

#Roll up on client_id for wcard_client
Rollup_ADDL_DF = ADDL_FLTR_SortADDLDF1.withColumn("clnt_id",ADDL_FLTR_SortADDLDF1.client_seq_id) \
.withColumn("addr_line_1",ADDL_FLTR_SortADDLDF1.addr1) \
.withColumn("addr_line_2",ADDL_FLTR_SortADDLDF1.addr2) \
.withColumn("state_cd",ADDL_FLTR_SortADDLDF1.state) \
.withColumn("city_name",ADDL_FLTR_SortADDLDF1.city) \
.withColumn("zip_cd_5",substring(ADDL_FLTR_SortADDLDF1.zip,1,5)) \
.withColumn("zip_cd_4",substring(ADDL_FLTR_SortADDLDF1.zip,6,4)) \
.withColumn("clnt_name",ADDL_FLTR_SortADDLDF1.name) \
.withColumn("addr_eff_dt",lit(EFF_DT)) \
.withColumn("addr_end_dt",lit(None))

Otput_file_WCARD_Client = WriteNullParquet(Rollup_ADDL_DF.select("clnt_id","clnt_name","state_cd","city_name","addr_line_1","addr_line_2","zip_cd_4","zip_cd_5","addr_eff_dt","addr_end_dt"))

#writing outputfile wcard_client to Staging folder
Otput_file_WCARD_Client.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file6+"/"+Batch_id)

# COMMAND ----------

# Join client seq id-1
Join_addl_setup_DF = dedupADDLDF.join(dedupSETUP_DF1,dedupADDLDF.client_seq_id == dedupSETUP_DF1.client_seq_id,"inner")

Join_addl_setup_DF1 = Join_addl_setup_DF.withColumn("wcard_client_addl_seq_id",dedupADDLDF.client_addl_seq_id) \
.withColumn("wcard_client_addl_record_type",dedupADDLDF.record_type) \
.withColumn("wcard_client_addl_name",dedupADDLDF.name) \
.withColumn("wcard_client_addl_title",dedupADDLDF.title) \
.withColumn("wcard_client_addl_phone",dedupADDLDF.phone) \
.withColumn("wcard_client_addl_email",dedupADDLDF.email) \
.withColumn("wcard_client_addl_fax",dedupADDLDF.fax) \
.withColumn("wcard_client_addl_addr1",dedupADDLDF.addr1) \
.withColumn("wcard_client_addl_addr2",dedupADDLDF.addr2) \
.withColumn("wcard_client_addl_state",dedupADDLDF.state) \
.withColumn("wcard_client_addl_city",dedupADDLDF.city) \
.withColumn("wcard_client_addl_zip",dedupADDLDF.zip) \
.withColumn("wcard_client_setup_seq_id",dedupSETUP_DF1.client_setup_seq_id) \
.withColumn("wcard_client_setup_client_num",dedupSETUP_DF1.client_num) \
.withColumn("wcard_client_setup_client_dscnt_pct",dedupSETUP_DF1.client_dscnt_pct) \
.withColumn("wcard_client_setup_mbr_rebt_pct",dedupSETUP_DF1.mbr_rebt_pct) \
.withColumn("wcard_client_setup_profile_num",dedupSETUP_DF1.profile_num) \
.withColumn("wcard_client_setup_client_amt_rqstd",dedupSETUP_DF1.client_amt_rqstd) \
.withColumn("wcard_client_setup_wag_brand_rebt_ind",dedupSETUP_DF1.wag_brand_rebt_ind) \
.withColumn("wcard_client_setup_acct_actn",dedupSETUP_DF1.acct_actn) \
.withColumn("wcard_client_setup_reject_files_ind",dedupSETUP_DF1.reject_files_ind) \
.withColumn("wcard_client_setup_mbr_id_type",dedupSETUP_DF1.mbr_id_type) \
.withColumn("wcard_client_setup_trmntd_f",dedupSETUP_DF1.trmntd_f) \
.withColumn("wcard_client_setup_trmntn_dt",dedupSETUP_DF1.trmntd_dt) \
.withColumn("wcard_client_setup_client_sends_cardnum",dedupSETUP_DF1.client_sends_cardnum) \
.withColumn("wcard_client_setup_client_sends_amt",dedupSETUP_DF1.client_sends_amt) \
.withColumn("wcard_client_setup_gnrt_inv",dedupSETUP_DF1.gnrt_inv) \
.withColumn("wcard_client_setup_actvt_reqd",dedupSETUP_DF1.actvt_reqd) \
.withColumn("wcard_client_setup_dflt_rebt_pct",dedupSETUP_DF1.dflt_rebt_pct) \
.withColumn("wcard_client_setup_client_sends_numofcards",dedupSETUP_DF1.client_sends_numofcards) \
.withColumn("wcard_client_setup_bulk_ship_ind",dedupSETUP_DF1.bulk_ship_ind) \
.withColumn("wcard_client_setup_new_card_charge",dedupSETUP_DF1.new_card_charge) \
.withColumn("wcard_client_setup_initial_dollar_amt_ind",dedupSETUP_DF1.initial_dollar_amt_ind) \
.withColumn("wcard_client_setup_initial_dollar_amt",dedupSETUP_DF1.initial_dollar_amt) \
.withColumn("wcard_client_setup_crd_manf_mstr_id",dedupSETUP_DF1.crd_manf_mstr_id) \
.withColumn("wcard_client_setup_letter_type_id",dedupSETUP_DF1.letter_type_id) \
.withColumn("wcard_client_setup_material_id",dedupSETUP_DF1.material_id) \
.withColumn("wcard_client_setup_include_cover_letter",dedupSETUP_DF1.include_cover_letter) \
.withColumn("wcard_client_setup_intial_amt_for",dedupSETUP_DF1.inital_amt_for) \
.withColumn("wcard_client_setup_first_file_procsd",dedupSETUP_DF1.first_file_procsd) \
.withColumn("wcard_client_setup_source_id",dedupSETUP_DF1.source_id)
#display(Join_addl_setup_DF1)

Join_addl_setup_DF1 = Join_addl_setup_DF1.select("wcard_client_setup_seq_id","wcard_client_setup_client_num","wcard_client_setup_client_dscnt_pct","wcard_client_setup_mbr_rebt_pct","wcard_client_setup_profile_num","wcard_client_setup_client_amt_rqstd","wcard_client_setup_wag_brand_rebt_ind","wcard_client_setup_acct_actn","wcard_client_setup_reject_files_ind","wcard_client_setup_mbr_id_type","wcard_client_setup_trmntd_f","wcard_client_setup_trmntn_dt","wcard_client_setup_client_sends_cardnum","wcard_client_setup_client_sends_amt","wcard_client_setup_gnrt_inv","wcard_client_setup_actvt_reqd","wcard_client_setup_dflt_rebt_pct","wcard_client_setup_client_sends_numofcards","wcard_client_setup_bulk_ship_ind","wcard_client_setup_new_card_charge","wcard_client_setup_initial_dollar_amt_ind","wcard_client_setup_initial_dollar_amt","wcard_client_setup_crd_manf_mstr_id","wcard_client_setup_letter_type_id","wcard_client_setup_material_id","wcard_client_setup_include_cover_letter","wcard_client_setup_intial_amt_for","wcard_client_setup_first_file_procsd","wcard_client_setup_source_id","wcard_client_addl_seq_id","wcard_client_addl_record_type","wcard_client_addl_name","wcard_client_addl_title","wcard_client_addl_phone","wcard_client_addl_email","wcard_client_addl_fax","wcard_client_addl_addr1","wcard_client_addl_addr2","wcard_client_addl_state","wcard_client_addl_city" ,"wcard_client_addl_zip")

# COMMAND ----------

#Defining schema for WCARD_CLIENT and WCARD_MSTR source file:
from pyspark.sql.types import *
Src_CLIENT_Schema = ['client_seq_id',
'client_mstr_seq_id',
'prog_mstr_seq_id',
'group_num',
'contr_start_dt',
'contr_end_dt',
'wag_acct_mgr',
'acct_mgr_phone',
'acct_mgr_email',
'district_num',
'crtd_by',
'crtd_dt',
'mdfd_by',
'mdfd_dt',
'card_design_seq_id']
Src_CLIENT_Schema1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Src_CLIENT_Schema)))

Src_MSTR_Schema = ['wcard_mstr_seq_id',
'client_mstr_name']
Src_MSTR_Schema2 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Src_MSTR_Schema)))
WCARD_CLIENT_DF = spark.read.format("csv").option("delimiter","").schema(Src_CLIENT_Schema1).load(mountPoint+WCARD_CLIENT_filepath)
WCARD_MSTR_DF = spark.read.format("csv").option("delimiter","|").schema(Src_MSTR_Schema2).load(mountPoint+WCARD_MSTR_filepath)

# COMMAND ----------

#Remove duplicate on wcard_client 
WCARD_CLIENT_dedupDF = WCARD_CLIENT_DF.select("*", row_number().over(Window.partitionBy("client_seq_id","client_mstr_seq_id","prog_mstr_seq_id","group_num","contr_start_dt","contr_end_dt","wag_acct_mgr","acct_mgr_phone","acct_mgr_email","district_num","crtd_by","crtd_dt","mdfd_by","mdfd_dt","card_design_seq_id").orderBy(WCARD_CLIENT_DF.client_seq_id,WCARD_CLIENT_DF.client_mstr_seq_id,WCARD_CLIENT_DF.prog_mstr_seq_id,WCARD_CLIENT_DF.group_num,WCARD_CLIENT_DF.contr_start_dt,WCARD_CLIENT_DF.contr_end_dt,WCARD_CLIENT_DF.wag_acct_mgr,WCARD_CLIENT_DF.acct_mgr_phone,WCARD_CLIENT_DF.acct_mgr_email,WCARD_CLIENT_DF.district_num,WCARD_CLIENT_DF.crtd_by,WCARD_CLIENT_DF.crtd_dt,WCARD_CLIENT_DF.mdfd_by,WCARD_CLIENT_DF.mdfd_dt,WCARD_CLIENT_DF.card_design_seq_id)).alias("row_num"))

WCARD_CLIENT_dedupDF1 = WCARD_CLIENT_dedupDF.filter(WCARD_CLIENT_dedupDF.row_num ==1).drop("row_num")

#RFT: Remove unused Client columns

RFMT_WCARD_CLIENT_dedupDF1 = WCARD_CLIENT_dedupDF1.withColumn("contr_start_dt",WCARD_CLIENT_dedupDF1.contr_start_dt) \
.withColumn("contr_end_dt",when((WCARD_CLIENT_dedupDF1.contr_end_dt.isNotNull()) & (WCARD_CLIENT_dedupDF1.contr_end_dt!=""),WCARD_CLIENT_dedupDF1.contr_end_dt).otherwise(lit("")))

#Sort by {client_seq_id}
srt_RFMT_WCARD_CLIENT_dedupDF1=RFMT_WCARD_CLIENT_dedupDF1.select("*", row_number().over(Window.partitionBy("client_seq_id").orderBy(RFMT_WCARD_CLIENT_dedupDF1.client_seq_id)).alias("row_num"))

srt_CLIENT1 = srt_RFMT_WCARD_CLIENT_dedupDF1.filter(srt_RFMT_WCARD_CLIENT_dedupDF1.row_num ==1).drop("row_num")

# COMMAND ----------

#Remove Duplicates-2

srt_WCARD_SETUP_DF = WCARD_SETUP_DF.select("*", row_number().over(Window.partitionBy("client_setup_seq_id","client_seq_id","client_num","client_dscnt_pct","mbr_rebt_pct","profile_num","client_amt_rqstd","wag_brand_rebt_ind","acct_actn","reject_files_ind","mbr_id_type","trmntd_f","trmntd_dt","crtd_by","crtd_dt","mdfd_by","mdfd_dt","client_sends_cardnum","client_sends_amt","gnrt_inv","actvt_reqd","client_sends_numofcards","dflt_rebt_pct","bulk_ship_ind","new_card_charge","source_id","initial_dollar_amt_ind","initial_dollar_amt","crd_manf_mstr_id","letter_type_id","material_id","include_cover_letter","inital_amt_for","first_file_procsd").orderBy(WCARD_SETUP_DF.client_setup_seq_id,WCARD_SETUP_DF.client_seq_id,WCARD_SETUP_DF.client_num,WCARD_SETUP_DF.client_dscnt_pct,WCARD_SETUP_DF.mbr_rebt_pct,WCARD_SETUP_DF.profile_num,WCARD_SETUP_DF.client_amt_rqstd,WCARD_SETUP_DF.wag_brand_rebt_ind,WCARD_SETUP_DF.acct_actn,WCARD_SETUP_DF.reject_files_ind,WCARD_SETUP_DF.mbr_id_type,WCARD_SETUP_DF.trmntd_f,WCARD_SETUP_DF.trmntd_dt,WCARD_SETUP_DF.crtd_by,WCARD_SETUP_DF.crtd_dt,WCARD_SETUP_DF.mdfd_by,WCARD_SETUP_DF.mdfd_dt,WCARD_SETUP_DF.client_sends_cardnum,WCARD_SETUP_DF.client_sends_amt,WCARD_SETUP_DF.gnrt_inv,WCARD_SETUP_DF.actvt_reqd,WCARD_SETUP_DF.client_sends_numofcards,WCARD_SETUP_DF.dflt_rebt_pct,WCARD_SETUP_DF.bulk_ship_ind,WCARD_SETUP_DF.new_card_charge,WCARD_SETUP_DF.source_id,WCARD_SETUP_DF.initial_dollar_amt_ind,WCARD_SETUP_DF.initial_dollar_amt,WCARD_SETUP_DF.crd_manf_mstr_id,WCARD_SETUP_DF.letter_type_id,WCARD_SETUP_DF.material_id,WCARD_SETUP_DF.include_cover_letter,WCARD_SETUP_DF.inital_amt_for,WCARD_SETUP_DF.first_file_procsd)).alias("row_num"))
srt_W_CLIENT1 = srt_WCARD_SETUP_DF.filter(srt_WCARD_SETUP_DF.row_num ==1).drop("row_num")

#RFT:Remove unused Client Setup Columns
RFMT_CLIENT1=srt_W_CLIENT1.withColumn("trmntd_dt",when((srt_W_CLIENT1.trmntd_dt.isNotNull()) & (srt_W_CLIENT1.trmntd_dt!=""),srt_W_CLIENT1.trmntd_dt).otherwise(lit("")))
#display(RFMT_CLIENT1)

srt_RFMT_CLIENT1=RFMT_CLIENT1.select("*", row_number().over(Window.partitionBy("client_seq_id").orderBy(RFMT_CLIENT1.client_seq_id)).alias("row_num"))
srt_RFMT_W_CLIENT1 = srt_RFMT_CLIENT1.filter(srt_RFMT_CLIENT1.row_num ==1).drop("row_num")
#display(srt_RFMT_W_CLIENT1)
#Join client seq id
Join_CLIENT_setup_DF = srt_CLIENT1.join(srt_RFMT_W_CLIENT1,srt_CLIENT1.client_seq_id == srt_RFMT_W_CLIENT1.client_seq_id,"inner")
#display(Join_CLIENT_setup_DF)

Join_CLIENT_setup_DF1 = Join_CLIENT_setup_DF.withColumn("wcard_client_client_seq_id",srt_CLIENT1.client_seq_id) \
.withColumn("wcard_client_client_mstr_seq_id",srt_CLIENT1.client_mstr_seq_id) \
.withColumn("wcard_client_program_mstr_seq_id",srt_CLIENT1.prog_mstr_seq_id) \
.withColumn("wcard_client_group_num",srt_CLIENT1.group_num) \
.withColumn("wcard_client_contr_start_dt",srt_CLIENT1.contr_start_dt) \
.withColumn("wcard_client_contr_end_dt",srt_CLIENT1.contr_end_dt) \
.withColumn("wcard_client_wag_acct_mgr",srt_CLIENT1.wag_acct_mgr) \
.withColumn("wcard_client_acct_mgr_phone",srt_CLIENT1.acct_mgr_phone) \
.withColumn("wcard_client_acct_mgr_email",srt_CLIENT1.acct_mgr_email) \
.withColumn("wcard_client_district_number",srt_CLIENT1.district_num) \
.withColumn("wcard_client_card_design_seq_id",srt_CLIENT1.card_design_seq_id) \
.withColumn("wcard_client_setup_seq_id",srt_RFMT_W_CLIENT1.client_setup_seq_id) \
.withColumn("wcard_client_setup_client_num",srt_RFMT_W_CLIENT1.client_num) \
.withColumn("wcard_client_setup_client_dscnt_pct",srt_RFMT_W_CLIENT1.client_dscnt_pct) \
.withColumn("wcard_client_setup_mbr_rebt_pct",srt_RFMT_W_CLIENT1.mbr_rebt_pct) \
.withColumn("wcard_client_setup_profile_num",srt_RFMT_W_CLIENT1.profile_num) \
.withColumn("wcard_client_setup_client_amt_rqstd",srt_RFMT_W_CLIENT1.client_amt_rqstd) \
.withColumn("wcard_client_setup_wag_brand_rebt_ind",srt_RFMT_W_CLIENT1.wag_brand_rebt_ind) \
.withColumn("wcard_client_setup_acct_actn",srt_RFMT_W_CLIENT1.acct_actn) \
.withColumn("wcard_client_setup_reject_files_ind",srt_RFMT_W_CLIENT1.reject_files_ind) \
.withColumn("wcard_client_setup_mbr_id_type",srt_RFMT_W_CLIENT1.mbr_id_type) \
.withColumn("wcard_client_setup_trmntd_f",srt_RFMT_W_CLIENT1.trmntd_f) \
.withColumn("wcard_client_setup_trmntn_dt",srt_RFMT_W_CLIENT1.trmntd_dt) \
.withColumn("wcard_client_setup_client_sends_cardnum",srt_RFMT_W_CLIENT1.client_sends_cardnum) \
.withColumn("wcard_client_setup_client_sends_amt",srt_RFMT_W_CLIENT1.client_sends_amt) \
.withColumn("wcard_client_setup_gnrt_inv",srt_RFMT_W_CLIENT1.gnrt_inv) \
.withColumn("wcard_client_setup_actvt_reqd",srt_RFMT_W_CLIENT1.actvt_reqd) \
.withColumn("wcard_client_setup_dflt_rebt_pct",srt_RFMT_W_CLIENT1.dflt_rebt_pct) \
.withColumn("wcard_client_setup_client_sends_numofcards",srt_RFMT_W_CLIENT1.client_sends_numofcards) \
.withColumn("wcard_client_setup_bulk_ship_ind",srt_RFMT_W_CLIENT1.bulk_ship_ind) \
.withColumn("wcard_client_setup_new_card_charge",srt_RFMT_W_CLIENT1.new_card_charge) \
.withColumn("wcard_client_setup_initial_dollar_amt_ind",srt_RFMT_W_CLIENT1.initial_dollar_amt_ind) \
.withColumn("wcard_client_setup_initial_dollar_amt",srt_RFMT_W_CLIENT1.initial_dollar_amt) \
.withColumn("wcard_client_setup_crd_manf_mstr_id",srt_RFMT_W_CLIENT1.crd_manf_mstr_id) \
.withColumn("wcard_client_setup_letter_type_id",srt_RFMT_W_CLIENT1.letter_type_id) \
.withColumn("wcard_client_setup_material_id",srt_RFMT_W_CLIENT1.material_id) \
.withColumn("wcard_client_setup_include_cover_letter",srt_RFMT_W_CLIENT1.include_cover_letter) \
.withColumn("wcard_client_setup_intial_amt_for",srt_RFMT_W_CLIENT1.inital_amt_for) \
.withColumn("wcard_client_setup_first_file_procsd",srt_RFMT_W_CLIENT1.first_file_procsd) \
.withColumn("wcard_client_setup_source_id",srt_RFMT_W_CLIENT1.source_id)

Join_CLIENT_setup_DF1 = Join_CLIENT_setup_DF1.select("wcard_client_client_seq_id","wcard_client_client_mstr_seq_id","wcard_client_program_mstr_seq_id","wcard_client_group_num","wcard_client_contr_start_dt","wcard_client_contr_end_dt","wcard_client_wag_acct_mgr","wcard_client_acct_mgr_phone","wcard_client_acct_mgr_email","wcard_client_district_number","wcard_client_card_design_seq_id","wcard_client_setup_seq_id","wcard_client_setup_client_num","wcard_client_setup_client_dscnt_pct","wcard_client_setup_mbr_rebt_pct","wcard_client_setup_profile_num","wcard_client_setup_client_amt_rqstd","wcard_client_setup_wag_brand_rebt_ind","wcard_client_setup_acct_actn","wcard_client_setup_reject_files_ind","wcard_client_setup_mbr_id_type","wcard_client_setup_trmntd_f","wcard_client_setup_trmntn_dt","wcard_client_setup_client_sends_cardnum","wcard_client_setup_client_sends_amt","wcard_client_setup_gnrt_inv","wcard_client_setup_actvt_reqd","wcard_client_setup_dflt_rebt_pct","wcard_client_setup_client_sends_numofcards","wcard_client_setup_bulk_ship_ind","wcard_client_setup_new_card_charge","wcard_client_setup_initial_dollar_amt_ind","wcard_client_setup_initial_dollar_amt","wcard_client_setup_crd_manf_mstr_id","wcard_client_setup_letter_type_id","wcard_client_setup_material_id","wcard_client_setup_include_cover_letter","wcard_client_setup_intial_amt_for","wcard_client_setup_first_file_procsd","wcard_client_setup_source_id")

# COMMAND ----------

# Remove Duplicates-5
Sort_WCARD_MSTRDF = WCARD_MSTR_DF.select("*", row_number().over(Window.partitionBy("wcard_mstr_seq_id","client_mstr_name").orderBy(WCARD_MSTR_DF.wcard_mstr_seq_id,WCARD_MSTR_DF.client_mstr_name)).alias("row_num"))

Sort_WCARD_MSTRDF1 = Sort_WCARD_MSTRDF.filter(Sort_WCARD_MSTRDF.row_num ==1).drop("row_num")

# COMMAND ----------

#RFT: Convert data to Program Contact Channel
RFMT_Join_client_seq_DF = Join_addl_setup_DF1.withColumn("prog_id",Join_addl_setup_DF1.wcard_client_setup_client_num) \
.withColumn("wcard_client_addl_record_type",Join_addl_setup_DF1.wcard_client_addl_record_type) \
.withColumn("fx_cntc_chnl_val",Join_addl_setup_DF1.wcard_client_addl_fax) \
.withColumn("wp_cntc_chnl_val",Join_addl_setup_DF1.wcard_client_addl_phone) \
.withColumn("em_cntc_chnl_val",Join_addl_setup_DF1.wcard_client_addl_email)

slct_RFMT_Join_client_seq_DF = RFMT_Join_client_seq_DF.select("prog_id","fx_cntc_chnl_val","wp_cntc_chnl_val","em_cntc_chnl_val","wcard_client_addl_record_type")

#Reformat-1 on Join_CLIENT_setup_DF1
RFMT_Join_CLIENT_setup_DF1 = Join_CLIENT_setup_DF1.withColumn("prog_id",Join_CLIENT_setup_DF1.wcard_client_setup_client_num) \
.withColumn("wp_cntc_chnl_val",Join_CLIENT_setup_DF1.wcard_client_acct_mgr_phone) \
.withColumn("fx_cntc_chnl_val",lit(None)) \
.withColumn("em_cntc_chnl_val",Join_CLIENT_setup_DF1.wcard_client_acct_mgr_email) \
.withColumn("wcard_client_addl_record_type",lit("ACCTMGR"))

slct_RFMT_Join_CLIENT_setup_DF = RFMT_Join_CLIENT_setup_DF1.select("prog_id","fx_cntc_chnl_val","wp_cntc_chnl_val","em_cntc_chnl_val","wcard_client_addl_record_type")

#GatherDF4
GatherDF4 = slct_RFMT_Join_client_seq_DF.union(slct_RFMT_Join_CLIENT_setup_DF)

#Normalize for three Event Types
arr = array(lit(0),lit(1),lit(2))

NormalizeDF = GatherDF4.withColumn("index",arr).withColumn("index",explode(col("index")))
NormalizeDF1 = NormalizeDF.withColumn("channel_type_cd",when(NormalizeDF.index==0,"PRMFX").when(NormalizeDF.index==1,"WP").when(NormalizeDF.index==2,"EM")) \
.withColumn("cntc_chnl_val",when(NormalizeDF.index==0,NormalizeDF.fx_cntc_chnl_val).when(NormalizeDF.index==1,NormalizeDF.wp_cntc_chnl_val).when(NormalizeDF.index==2,NormalizeDF.em_cntc_chnl_val)) \
.withColumn("cntc_type_cd",NormalizeDF.wcard_client_addl_record_type) \
.withColumn("cntc_chnl_eff_dt",lit(EFF_DT)) \
.withColumn("cntc_chnl_end_dt",lit(None))
#SORT AND DEdup on NormalizeDF1
Sort_NormalizeDF1 = NormalizeDF1.select("*", row_number().over(Window.partitionBy("prog_id","channel_type_cd","cntc_type_cd").orderBy(NormalizeDF1.prog_id,NormalizeDF1.channel_type_cd,NormalizeDF1.cntc_type_cd)).alias("row_num"))
Sort_NormalizeDF2 = Sort_NormalizeDF1.filter(Sort_NormalizeDF1.row_num ==1).drop("row_num")

slct_dedupNormalizeDF2 = WriteNullParquet(Sort_NormalizeDF2.select("prog_id","cntc_chnl_val","cntc_type_cd","channel_type_cd","cntc_chnl_eff_dt","cntc_chnl_end_dt"))

#writing outputfile wcard_program_contact_channel.dat to Staging folder
slct_dedupNormalizeDF2.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file7+"/"+Batch_id)

# COMMAND ----------

#Create wcard program contact
#Filter by non - 'GEN'
FILTER_DF = Join_addl_setup_DF1.filter(Join_addl_setup_DF1.wcard_client_addl_record_type != "GEN")

RFMT_FILTER_DF = FILTER_DF.withColumn("cntc_name",col("wcard_client_addl_name")) \
.withColumn("cntc_type_cd",FILTER_DF.wcard_client_addl_record_type) \
.withColumn("eff_dt",lit(EFF_DT)) \
.withColumn("prog_id",FILTER_DF.wcard_client_setup_client_num) \
.withColumn("end_dt",lit(None))

slct_RFMT_FILTER_DF = RFMT_FILTER_DF.select("cntc_name","cntc_type_cd","eff_dt","prog_id","end_dt")

Reformat_DF = Join_CLIENT_setup_DF1.withColumn("cntc_name",Join_CLIENT_setup_DF1.wcard_client_wag_acct_mgr) \
.withColumn("cntc_type_cd",lit("ACCTMGR")) \
.withColumn("eff_dt",lit(EFF_DT)) \
.withColumn("prog_id",Join_CLIENT_setup_DF1.wcard_client_setup_client_num) \
.withColumn("end_dt",lit(None))
slct_Reformat_DF = Reformat_DF.select("cntc_name","cntc_type_cd","eff_dt","prog_id","end_dt")

#Union 
GthrDF = slct_RFMT_FILTER_DF.union(slct_Reformat_DF)

# generating wcard_program_contact.dat
slct_GthrDF2 = WriteNullParquet(GthrDF.select("cntc_name","cntc_type_cd","eff_dt","prog_id","end_dt"))

#writing outputfile wcard_program_contact to Staging folder
slct_GthrDF2.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file8+"/"+Batch_id)

# COMMAND ----------

#Sort by mstr_seq_id-1

# Srt_Join_CLIENT_setup_DF1 = Join_CLIENT_setup_DF1.select("*", row_number().over(Window.partitionBy("wcard_client_client_mstr_seq_id").orderBy(Join_CLIENT_setup_DF1.wcard_client_client_mstr_seq_id)).alias("row_num"))
# Srt_Join_CLIENT_setup_DF2 = Srt_Join_CLIENT_setup_DF1.filter(Srt_Join_CLIENT_setup_DF1.row_num ==1).drop("row_num")


# COMMAND ----------

#Join mstr seq id
JoinDF = Join_CLIENT_setup_DF1.join(Sort_WCARD_MSTRDF1,Join_CLIENT_setup_DF1.wcard_client_client_mstr_seq_id == Sort_WCARD_MSTRDF1.wcard_mstr_seq_id,"inner")

JoinDF1 = JoinDF.withColumn("wcard_client_master_client_mstr_name",ltrim(rtrim(Sort_WCARD_MSTRDF1.client_mstr_name)))

#RFT for wcard program
RFT_JoinDF1 = JoinDF1.withColumn("prog_id",JoinDF1.wcard_client_setup_client_num) \
.withColumn("prog_name",JoinDF1.wcard_client_master_client_mstr_name) \
.withColumn("prog_type_cd",JoinDF1.wcard_client_program_mstr_seq_id) \
.withColumn("prog_eff_dt",lit(EFF_DT)) \
.withColumn("prog_end_dt",lit(None)) \
.withColumn("grp_nbr",JoinDF1.wcard_client_group_num) \
.withColumn("mbr_rbt_pct",JoinDF1.wcard_client_setup_mbr_rebt_pct) \
.withColumn("dist_nbr",JoinDF1.wcard_client_district_number) \
.withColumn("prog_req_dlrs",JoinDF1.wcard_client_setup_client_amt_rqstd) \
.withColumn("wag_brnd_rbt_ind",JoinDF1.wcard_client_setup_wag_brand_rebt_ind) \
.withColumn("prog_snds_crd_nbr_ind",JoinDF1.wcard_client_setup_client_sends_cardnum) \
.withColumn("prog_snds_dlrs_ind",JoinDF1.wcard_client_setup_client_sends_amt) \
.withColumn("inv_req_ind",JoinDF1.wcard_client_setup_gnrt_inv) \
.withColumn("card_actv_req_ind",JoinDF1.wcard_client_setup_actvt_reqd) \
.withColumn("card_mfg_cost",JoinDF1.wcard_client_setup_new_card_charge) \
.withColumn("src_id",ltrim(rtrim(JoinDF1.wcard_client_setup_source_id))) \
.withColumn("prog_discnt_pct",JoinDF1.wcard_client_setup_client_dscnt_pct) \
.withColumn("prog_trmn_dt",when((JoinDF1.wcard_client_setup_trmntn_dt.isNotNull()) & (JoinDF1.wcard_client_setup_trmntn_dt!=""),concat(substring(JoinDF1.wcard_client_setup_trmntn_dt,1,4),lit("-"),substring(JoinDF1.wcard_client_setup_trmntn_dt,5,2),lit("-"),substring(JoinDF1.wcard_client_setup_trmntn_dt,7,2))).otherwise(None)) \
.withColumn("card_mfgr_mast_id",JoinDF1.wcard_client_setup_crd_manf_mstr_id) \
.withColumn("acct_actn",JoinDF1.wcard_client_setup_acct_actn) \
.withColumn("bulk_ship_ind",JoinDF1.wcard_client_setup_bulk_ship_ind) \
.withColumn("card_dsgn_seq_nbr",JoinDF1.wcard_client_card_design_seq_id) \
.withColumn("prog_start_from_dt",when((JoinDF1.wcard_client_contr_start_dt.isNotNull()) & (JoinDF1.wcard_client_contr_start_dt!=""),concat(substring(JoinDF1.wcard_client_contr_start_dt,1,4),lit("-"),substring(JoinDF1.wcard_client_contr_start_dt,5,2),lit("-"),substring(JoinDF1.wcard_client_contr_start_dt,7,2))).otherwise(None)) \
.withColumn("prog_end_to_dt",when((JoinDF1.wcard_client_contr_end_dt.isNotNull()) & (JoinDF1.wcard_client_contr_end_dt!=""),concat(substring(JoinDF1.wcard_client_contr_end_dt,1,4),lit("-"),substring(JoinDF1.wcard_client_contr_end_dt,5,2),lit("-"),substring(JoinDF1.wcard_client_contr_end_dt,7,2))).otherwise(None)) \
.withColumn("clnt_id",JoinDF1.wcard_client_client_seq_id) \
.withColumn("profile_id",coalesce(JoinDF1.wcard_client_setup_profile_num,lit("0")))

#generating wcard_program.dat file

slct_programDF = RFT_JoinDF1.select("prog_id",
"prog_type_cd",
"prog_name",
"prog_eff_dt",
"prog_end_dt",
"grp_nbr",
"mbr_rbt_pct",
"dist_nbr",
"prog_req_dlrs",
"wag_brnd_rbt_ind",
"prog_snds_crd_nbr_ind",
"prog_snds_dlrs_ind",
"inv_req_ind",
"card_actv_req_ind",
"card_mfg_cost",
"src_id",
"prog_discnt_pct",
"prog_start_from_dt",
"prog_trmn_dt",
"card_mfgr_mast_id",
"acct_actn",
"bulk_ship_ind",
"card_dsgn_seq_nbr",
"prog_end_to_dt",
"clnt_id",
"profile_id")
slct_programDF2 = WriteNullParquet(slct_programDF.select("prog_id",
"prog_type_cd",
"prog_name",
"prog_eff_dt",
"prog_end_dt",
"grp_nbr",
"mbr_rbt_pct",
"dist_nbr",
"prog_req_dlrs",
"wag_brnd_rbt_ind",
"prog_snds_crd_nbr_ind",
"prog_snds_dlrs_ind",
"inv_req_ind",
"card_actv_req_ind",
"card_mfg_cost",
"src_id",
"prog_discnt_pct",
"prog_start_from_dt",
"prog_trmn_dt",
"card_mfgr_mast_id",
"acct_actn",
"bulk_ship_ind",
"card_dsgn_seq_nbr",
"prog_end_to_dt",
"clnt_id",
"profile_id"))

#writing outputfile wcard_program to Staging folder
slct_programDF2.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file9+"/"+Batch_id)

# COMMAND ----------

#2nd part of Graph
#Defining schema for  source file
from pyspark.sql.types import *
schema_card_holder = ['cardhldr_seq_id',
'cardhldr_fname',
'cardhldr_mname',
'cardhldr_lname',
'cardhldr_title',
'cardhldr_suffix',
'cardhldr_dob',
'cardhldr_addr1',
'cardhldr_addr2',
'cardhldr_city',
'cardhldr_state',
'cardhldr_zip',
'cardhldr_home_phone',
'cardhldr_work_phone',
'cardhldr_email',
'enrlmt_type',
'crtd_by',
'crtd_dt',
'mdfd_by',
'mdfd_dt',
'card_owner_flag']
schema_card_holder1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,schema_card_holder)))

Schema_wcard_mapping = ['wcard_mapping_seq_id',
'cardhldr_seq_id',
'client_seq_id',
'mbr_id',
'wcard_num',
'card_status',
'crtd_by',
'crtd_dt',
'mdfd_by',
'mdfd_dt',
'old_wcard_num',
'ecomm_id',
'actn_cntr',
'activation_auth_id',
'activation_date',
'activation_user',
'terminat_dt',
'loyalty_epsilon_mbr_id']
Schema_wcard_mapping1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Schema_wcard_mapping)))

WCARD_card_holder_DF = spark.read.format("csv").option("delimiter","").schema(schema_card_holder1).load(mountPoint+WCARD_CARDHLDR_INFORMATION_filepath)
WCARD_mapping_DF = spark.read.format("csv").option("delimiter","|").schema(Schema_wcard_mapping1).load(mountPoint+WCARD_WCARD_MAPPING_filepath)

# COMMAND ----------

#RFT:Remove unused Cardholder Columns
RFMT_WCARD_card_DF = WCARD_card_holder_DF.withColumn("cardhldr_dob",when((WCARD_card_holder_DF.cardhldr_dob!="") & (WCARD_card_holder_DF.cardhldr_dob.isNotNull()),substring(rtrim(ltrim(WCARD_card_holder_DF.cardhldr_dob)),1,8))
           .otherwise(lit(None))) \
.withColumn("card_owner_flg",WCARD_card_holder_DF.card_owner_flag) \
.withColumn("cardhldr_crtd_dt",WCARD_card_holder_DF.crtd_dt)

#Remove Duplicates-4
Sort_Card_hldr = RFMT_WCARD_card_DF.select("*", row_number().over(Window.partitionBy("cardhldr_seq_id","cardhldr_fname","cardhldr_mname","cardhldr_lname","cardhldr_title","cardhldr_suffix","cardhldr_dob","cardhldr_addr1","cardhldr_addr2","cardhldr_city","cardhldr_state","cardhldr_zip","cardhldr_home_phone","cardhldr_work_phone","cardhldr_email","enrlmt_type","card_owner_flg","cardhldr_crtd_dt").orderBy(RFMT_WCARD_card_DF.cardhldr_seq_id,RFMT_WCARD_card_DF.cardhldr_fname,RFMT_WCARD_card_DF.cardhldr_mname,RFMT_WCARD_card_DF.cardhldr_lname,RFMT_WCARD_card_DF.cardhldr_title,RFMT_WCARD_card_DF.cardhldr_suffix,RFMT_WCARD_card_DF.cardhldr_dob,RFMT_WCARD_card_DF.cardhldr_addr1,RFMT_WCARD_card_DF.cardhldr_addr2,RFMT_WCARD_card_DF.cardhldr_city,RFMT_WCARD_card_DF.cardhldr_state,RFMT_WCARD_card_DF.cardhldr_zip,RFMT_WCARD_card_DF.cardhldr_home_phone,RFMT_WCARD_card_DF.cardhldr_work_phone,RFMT_WCARD_card_DF.cardhldr_email,RFMT_WCARD_card_DF.enrlmt_type,RFMT_WCARD_card_DF.card_owner_flg,RFMT_WCARD_card_DF.cardhldr_crtd_dt)).alias("row_num"))

Sort_Card_hldr1 = Sort_Card_hldr.filter(Sort_Card_hldr.row_num ==1).drop("row_num")

# COMMAND ----------

#create wcard cardholder
#RFT: For Cardholder Table
var_src_sys_cd = pscSrcSysCdLkpDF.filter(pscSrcSysCdLkpDF.src_sys_desc=="wcard").select("src_sys_cd").collect()

if len(var_src_sys_cd)!=0:
  var_src_sys_cd = var_src_sys_cd[0].src_sys_cd
else:
  var_src_sys_cd = None

RFMT_Card_hldr = Sort_Card_hldr1.withColumn("brth_dt",concat(substring(Sort_Card_hldr1.cardhldr_dob,1,4),lit("-"),substring(Sort_Card_hldr1.cardhldr_dob,5,2),lit("-"),substring(Sort_Card_hldr1.cardhldr_dob,7,2))) \
.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("card_hldr_id",Sort_Card_hldr1.cardhldr_seq_id) \
.withColumn("eff_dt",lit(EFF_DT)) \
.withColumn("end_dt",lit(None))

srt_RFMT_Card_hldr = RFMT_Card_hldr.select("*", row_number().over(Window.partitionBy("card_hldr_id").orderBy(RFMT_Card_hldr.card_hldr_id)).alias("row_num"))

srt_RFMT_Card_hldr1 = srt_RFMT_Card_hldr.filter(srt_RFMT_Card_hldr.row_num ==1).drop("row_num")
#Generating wcard_cardholder.dat
select_dedup_Card_hldr2 = srt_RFMT_Card_hldr1.select("card_hldr_id","src_sys_cd","eff_dt","brth_dt","end_dt")
cardholderDF = WriteNullParquet(select_dedup_Card_hldr2.select("card_hldr_id","src_sys_cd","eff_dt","brth_dt","end_dt"))

#writing outputfile wcard_cardholder.dat to Staging folder
cardholderDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file10+"/"+Batch_id)

# COMMAND ----------

#RFT: For Cardholder Name Table
RFMT_CardholderName = Sort_Card_hldr1.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("card_hldr_name_eff_dt",lit(EFF_DT)) \
.withColumn("last_name",coalesce(Sort_Card_hldr1.cardhldr_lname,lit(" "))) \
.withColumn("mid_name",coalesce(Sort_Card_hldr1.cardhldr_mname,lit(" "))) \
.withColumn("first_name",coalesce(Sort_Card_hldr1.cardhldr_fname,lit(" "))) \
.withColumn("card_hldr_ttl",Sort_Card_hldr1.cardhldr_title) \
.withColumn("card_hldr_sufx",Sort_Card_hldr1.cardhldr_suffix) \
.withColumn("card_hldr_id",Sort_Card_hldr1.cardhldr_seq_id) \
.withColumn("card_hldr_name_end_dt",lit(None))

srt_CardholderName = RFMT_CardholderName.select("*", row_number().over(Window.partitionBy("card_hldr_id").orderBy(RFMT_CardholderName.card_hldr_id)).alias("row_num"))

srt_CardholderName1 = srt_CardholderName.filter(srt_CardholderName.row_num ==1).drop("row_num")

#Generating wcard_cardholder_name.dat

slct_CardholderName = srt_CardholderName1.select("card_hldr_id","card_hldr_name_eff_dt","src_sys_cd","first_name","mid_name","last_name","card_hldr_ttl","card_hldr_sufx","card_hldr_name_end_dt")
cardholder_nameDF = WriteNullParquet(slct_CardholderName.select("card_hldr_id","card_hldr_name_eff_dt","src_sys_cd","first_name","mid_name","last_name","card_hldr_ttl","card_hldr_sufx","card_hldr_name_end_dt"))

#writing outputfile wcard_cardholder_name.dat to Staging folder
cardholder_nameDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file11+"/"+Batch_id)

# COMMAND ----------

#create wcard cardholder address
RFMT_holder_address = Sort_Card_hldr1.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("addr_eff_dt",lit(EFF_DT)) \
.withColumn("addr_end_dt",lit(None)) \
.withColumn("addr_line_1",Sort_Card_hldr1.cardhldr_addr1) \
.withColumn("addr_line_2",Sort_Card_hldr1.cardhldr_addr2) \
.withColumn("city_name",Sort_Card_hldr1.cardhldr_city) \
.withColumn("state_cd",Sort_Card_hldr1.cardhldr_state) \
.withColumn("zip_cd_5",substring(Sort_Card_hldr1.cardhldr_zip,1,5)) \
.withColumn("zip_cd_4",substring(Sort_Card_hldr1.cardhldr_zip,6,4)) \
.withColumn("addr_type_cd",lit("GEN")) \
.withColumn("card_hldr_id",Sort_Card_hldr1.cardhldr_seq_id)

srt_holder_address = RFMT_holder_address.select("*", row_number().over(Window.partitionBy("card_hldr_id").orderBy(RFMT_holder_address.card_hldr_id)).alias("row_num"))

srt_holder_address1 = srt_holder_address.filter(srt_holder_address.row_num ==1).drop("row_num")
#Generating wcard_cardholder_address.dat
holder_addressDF = WriteNullParquet(srt_holder_address1.select("card_hldr_id","src_sys_cd","state_cd","city_name","addr_line_1","addr_line_2","addr_type_cd","zip_cd_5","zip_cd_4","addr_eff_dt","addr_end_dt"))

#writing outputfile wcard_cardholder_address.dat to Staging folder
holder_addressDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file12+"/"+Batch_id)

# COMMAND ----------

#create wcard cardholder contact
RFMT_cardholder_contact = Sort_Card_hldr1.withColumn("cardholder_effective_date",lit(EFF_DT)) \
.withColumn("hp_cntc_chnl_val",Sort_Card_hldr1.cardhldr_home_phone) \
.withColumn("wp_cntc_chnl_val",Sort_Card_hldr1.cardhldr_work_phone) \
.withColumn("em_cntc_chnl_val",Sort_Card_hldr1.cardhldr_email) \
.withColumn("cntc_chnl_type_cd",lit("")) \
.withColumn("cardholder_id",Sort_Card_hldr1.cardhldr_seq_id) \
.withColumn("cntc_chnl_end_dt",lit(None))

#Normalize to Create a record for the 3 contact types

arr1 = array(lit(0),lit(1),lit(2))
NorDF = RFMT_cardholder_contact.withColumn("index",arr1).withColumn("index",explode(col("index")))
NorDF1 = NorDF.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("channel_type_cd",when(NorDF.index==0,"HP").when(NorDF.index==1,"WP").when(NorDF.index==2,"EM")) \
.withColumn("cntc_chnl_val",when(NorDF.index==0,NorDF.hp_cntc_chnl_val).when(NorDF.index==1,NorDF.wp_cntc_chnl_val).when(NorDF.index==2,NorDF.em_cntc_chnl_val)) \
.withColumn("cntc_chnl_eff_dt",NorDF.cardholder_effective_date) \
.withColumn("card_hldr_id",NorDF.cardholder_id)

#create wcard cardholder contact
Rollup_df = NorDF1.withColumn("channel_type_desc",when(NorDF1.channel_type_cd=="EM",lit("EMAIL")).when(NorDF1.channel_type_cd=="WP",lit("WORK PHONE NUMBER")).when(NorDF1.channel_type_cd=="HP",lit("HOME PHONE NUMBER")).otherwise(lit("unknown")))

#sorting to NORDF1
srt_NorDF1 = NorDF1.select("*", row_number().over(Window.partitionBy("card_hldr_id","channel_type_cd").orderBy(NorDF1.card_hldr_id,NorDF1.channel_type_cd)).alias("row_num"))

srt_NorDF2 = srt_NorDF1.filter(srt_NorDF1.row_num ==1).drop("row_num")

#Generating wcard_cardholder_contact.dat

cardholder_contactDF = WriteNullParquet(srt_NorDF2.select("card_hldr_id","src_sys_cd","cntc_chnl_eff_dt","channel_type_cd","cntc_chnl_val","cntc_chnl_end_dt"))
#writing outputfile wcard_cardholder_contact.dat to Staging folder
cardholder_contactDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file13+"/"+Batch_id)

#Generating wcard_contact_channel_type_insert_ascii.pipe_delim File to Staging Folder
contact_chnnl_typDF = WriteNullParquet(Rollup_df.select("channel_type_cd","channel_type_desc").distinct())
#writing outputfile wcard_cardholder_contact.dat to Staging folder

contact_chnnl_typDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file14+"/"+Batch_id)

# COMMAND ----------

#Integrating Mapping, Client Setup & Addl Info

RFMT_WCARD_MAPPING = WCARD_mapping_DF.select("*", row_number().over(Window.partitionBy("wcard_mapping_seq_id","cardhldr_seq_id","client_seq_id","mbr_id","wcard_num","card_status","crtd_by","crtd_dt","mdfd_by","mdfd_dt","old_wcard_num","ecomm_id","actn_cntr","activation_auth_id","activation_date","activation_user","terminat_dt","loyalty_epsilon_mbr_id").orderBy(WCARD_mapping_DF.wcard_mapping_seq_id,WCARD_mapping_DF.cardhldr_seq_id,WCARD_mapping_DF.client_seq_id,WCARD_mapping_DF.mbr_id,WCARD_mapping_DF.wcard_num,WCARD_mapping_DF.card_status,WCARD_mapping_DF.crtd_by,WCARD_mapping_DF.crtd_dt,WCARD_mapping_DF.mdfd_by,WCARD_mapping_DF.mdfd_dt,WCARD_mapping_DF.old_wcard_num,WCARD_mapping_DF.ecomm_id,WCARD_mapping_DF.actn_cntr,WCARD_mapping_DF.activation_auth_id,WCARD_mapping_DF.activation_date,WCARD_mapping_DF.activation_user,WCARD_mapping_DF.terminat_dt,WCARD_mapping_DF.loyalty_epsilon_mbr_id)).alias("row_num"))

RFMT_WCARD_MAPPING1 = RFMT_WCARD_MAPPING.filter(RFMT_WCARD_MAPPING.row_num ==1).drop("row_num")
RFMT_WCARD_MAPPING1 = RFMT_WCARD_MAPPING1.select("wcard_mapping_seq_id","cardhldr_seq_id","client_seq_id","mbr_id","wcard_num","card_status","crtd_by","crtd_dt","mdfd_by","mdfd_dt","old_wcard_num","ecomm_id","actn_cntr","activation_auth_id","activation_date","activation_user","terminat_dt","loyalty_epsilon_mbr_id")

# COMMAND ----------

#Remove Duplicates-6
Srt_stup_client = WCARD_SETUP_DF.select("*", row_number().over(Window.partitionBy("client_setup_seq_id","client_seq_id","client_num","client_dscnt_pct","mbr_rebt_pct","profile_num","client_amt_rqstd","wag_brand_rebt_ind","acct_actn","reject_files_ind","mbr_id_type","trmntd_f","trmntd_dt","crtd_by","crtd_dt","mdfd_by","mdfd_dt","client_sends_cardnum","client_sends_amt","gnrt_inv","actvt_reqd","client_sends_numofcards","dflt_rebt_pct","bulk_ship_ind","new_card_charge","source_id","initial_dollar_amt_ind","initial_dollar_amt","crd_manf_mstr_id","letter_type_id","material_id","include_cover_letter","inital_amt_for","first_file_procsd").orderBy(WCARD_SETUP_DF.client_setup_seq_id,WCARD_SETUP_DF.client_seq_id,WCARD_SETUP_DF.client_num,WCARD_SETUP_DF.client_dscnt_pct,WCARD_SETUP_DF.mbr_rebt_pct,WCARD_SETUP_DF.profile_num,WCARD_SETUP_DF.client_amt_rqstd,WCARD_SETUP_DF.wag_brand_rebt_ind,WCARD_SETUP_DF.acct_actn,WCARD_SETUP_DF.reject_files_ind,WCARD_SETUP_DF.mbr_id_type,WCARD_SETUP_DF.trmntd_f,WCARD_SETUP_DF.trmntd_dt,WCARD_SETUP_DF.crtd_by,WCARD_SETUP_DF.crtd_dt,WCARD_SETUP_DF.mdfd_by,WCARD_SETUP_DF.mdfd_dt,WCARD_SETUP_DF.client_sends_cardnum,WCARD_SETUP_DF.client_sends_amt,WCARD_SETUP_DF.gnrt_inv,WCARD_SETUP_DF.actvt_reqd,WCARD_SETUP_DF.client_sends_numofcards,WCARD_SETUP_DF.dflt_rebt_pct,WCARD_SETUP_DF.bulk_ship_ind,WCARD_SETUP_DF.new_card_charge,WCARD_SETUP_DF.source_id,WCARD_SETUP_DF.initial_dollar_amt_ind,WCARD_SETUP_DF.initial_dollar_amt,WCARD_SETUP_DF.crd_manf_mstr_id,WCARD_SETUP_DF.letter_type_id,WCARD_SETUP_DF.material_id,WCARD_SETUP_DF.include_cover_letter,WCARD_SETUP_DF.inital_amt_for,WCARD_SETUP_DF.first_file_procsd)).alias("row_num"))

Srt_stup_client1 = Srt_stup_client.filter(Srt_stup_client.row_num ==1).drop("row_num")

#RFT:Remove unused Client Setup Columns-1
RFT_client1 = Srt_stup_client1.withColumn("trmntd_dt",when((Srt_stup_client1.trmntd_dt.isNotNull()) & (Srt_stup_client1.trmntd_dt!="")
,Srt_stup_client1.trmntd_dt).otherwise(lit("")))
RFT_client1 = RFT_client1.select("client_setup_seq_id","client_seq_id","client_num","client_dscnt_pct","mbr_rebt_pct","profile_num","client_amt_rqstd","wag_brand_rebt_ind","acct_actn","reject_files_ind","mbr_id_type","trmntd_f","trmntd_dt","client_sends_cardnum","client_sends_amt","gnrt_inv","actvt_reqd","dflt_rebt_pct","client_sends_numofcards","bulk_ship_ind","new_card_charge","initial_dollar_amt_ind","initial_dollar_amt","crd_manf_mstr_id","letter_type_id","material_id","include_cover_letter","inital_amt_for","first_file_procsd","source_id"
)

# COMMAND ----------

#Remove Duplicates-7
sort_on_addl = WCARD_ADDL_DF.select("*", row_number().over(Window.partitionBy("client_addl_seq_id","client_seq_id","record_type","name","title","phone","email","fax","addr1","addr2","state","city","zip","crtd_by","crtd_dt","mdfd_by","mdfd_dt").orderBy(WCARD_ADDL_DF.client_addl_seq_id,WCARD_ADDL_DF.client_seq_id,WCARD_ADDL_DF.record_type,WCARD_ADDL_DF.name,WCARD_ADDL_DF.title,WCARD_ADDL_DF.phone,WCARD_ADDL_DF.email,WCARD_ADDL_DF.fax,WCARD_ADDL_DF.addr1,WCARD_ADDL_DF.addr2,WCARD_ADDL_DF.state,WCARD_ADDL_DF.city,WCARD_ADDL_DF.zip,WCARD_ADDL_DF.crtd_by,WCARD_ADDL_DF.crtd_dt,WCARD_ADDL_DF.mdfd_by,WCARD_ADDL_DF.mdfd_dt)).alias("row_num"))

sort_on_addl2 = sort_on_addl.filter(sort_on_addl.row_num ==1).drop("row_num")
sort_on_addl2 = sort_on_addl2.select("client_addl_seq_id","client_seq_id","record_type","name","title","phone","email","fax","addr1","addr2","state","city","zip","crtd_by","crtd_dt","mdfd_by","mdfd_dt")

# COMMAND ----------

#Join client seq id-2
Join_mapping_client = RFMT_WCARD_MAPPING1.join(RFT_client1,RFMT_WCARD_MAPPING1.client_seq_id == RFT_client1.client_seq_id,"inner")

Join_mapping_client1 = Join_mapping_client.withColumn("wcard_client_setup_seq_id",RFT_client1.client_setup_seq_id) \
.withColumn("wcard_client_setup_client_num",RFT_client1.client_num) \
.withColumn("wcard_client_setup_client_dscnt_pct",RFT_client1.client_dscnt_pct) \
.withColumn("wcard_client_setup_mbr_rebt_pct",RFT_client1.mbr_rebt_pct) \
.withColumn("wcard_client_setup_profile_num",RFT_client1.profile_num) \
.withColumn("wcard_client_setup_client_amt_rqstd",RFT_client1.client_amt_rqstd) \
.withColumn("wcard_client_setup_wag_brand_rebt_ind",RFT_client1.wag_brand_rebt_ind) \
.withColumn("wcard_client_setup_acct_actn",RFT_client1.acct_actn) \
.withColumn("wcard_client_setup_reject_files_ind",RFT_client1.reject_files_ind) \
.withColumn("wcard_client_setup_mbr_id_type",RFT_client1.mbr_id_type) \
.withColumn("wcard_client_setup_trmntd_f",RFT_client1.trmntd_f) \
.withColumn("wcard_client_setup_trmntn_dt",RFT_client1.trmntd_dt) \
.withColumn("wcard_client_setup_client_sends_cardnum",RFT_client1.client_sends_cardnum) \
.withColumn("wcard_client_setup_client_sends_amt",RFT_client1.client_sends_amt) \
.withColumn("wcard_client_setup_gnrt_inv",RFT_client1.gnrt_inv) \
.withColumn("wcard_client_setup_actvt_reqd",RFT_client1.actvt_reqd) \
.withColumn("wcard_client_setup_dflt_rebt_pct",RFT_client1.dflt_rebt_pct) \
.withColumn("wcard_client_setup_client_sends_numofcards",RFT_client1.client_sends_numofcards) \
.withColumn("wcard_client_setup_bulk_ship_ind",RFT_client1.bulk_ship_ind) \
.withColumn("wcard_client_setup_new_card_charge",RFT_client1.new_card_charge) \
.withColumn("wcard_client_setup_initial_dollar_amt_ind",RFT_client1.initial_dollar_amt_ind) \
.withColumn("wcard_client_setup_initial_dollar_amt",RFT_client1.initial_dollar_amt) \
.withColumn("wcard_client_setup_crd_manf_mstr_id",RFT_client1.crd_manf_mstr_id) \
.withColumn("wcard_client_setup_letter_type_id",RFT_client1.letter_type_id) \
.withColumn("wcard_client_setup_material_id",RFT_client1.material_id) \
.withColumn("wcard_client_setup_include_cover_letter",RFT_client1.include_cover_letter) \
.withColumn("wcard_client_setup_intial_amt_for",RFT_client1.inital_amt_for) \
.withColumn("wcard_client_setup_first_file_procsd",RFT_client1.first_file_procsd) \
.withColumn("wcard_client_setup_source_id",RFT_client1.source_id) \
.withColumn("wcard_mapping_seq_id",RFMT_WCARD_MAPPING1.wcard_mapping_seq_id) \
.withColumn("wcard_mapping_cardhldr_seq_id",RFMT_WCARD_MAPPING1.cardhldr_seq_id) \
.withColumn("wcard_mapping_client_seq_id",RFMT_WCARD_MAPPING1.client_seq_id) \
.withColumn("wcard_mapping_mbr_id",ltrim(rtrim(RFMT_WCARD_MAPPING1.mbr_id))) \
.withColumn("wcard_mapping_wcard_num",RFMT_WCARD_MAPPING1.wcard_num) \
.withColumn("wcard_mapping_card_status",RFMT_WCARD_MAPPING1.card_status) \
.withColumn("wcard_mapping_old_wcard_num",RFMT_WCARD_MAPPING1.old_wcard_num) \
.withColumn("wcard_mapping_ecomm_id",RFMT_WCARD_MAPPING1.ecomm_id) \
.withColumn("wcard_mapping_actn_cntr",RFMT_WCARD_MAPPING1.actn_cntr) \
.withColumn("wcard_mapping_activation_auth_id",RFMT_WCARD_MAPPING1.activation_auth_id) \
.withColumn("wcard_mapping_activation_date",RFMT_WCARD_MAPPING1.activation_date) \
.withColumn("wcard_mapping_activation_user",RFMT_WCARD_MAPPING1.activation_user) \
.withColumn("wcard_mapping_terminat_dt",RFMT_WCARD_MAPPING1.terminat_dt) \
.withColumn("wcard_mapping_loyalty_epsilon_mbr_id",RFMT_WCARD_MAPPING1.loyalty_epsilon_mbr_id)

Join_mapping_client1 = Join_mapping_client1.select("wcard_mapping_seq_id","wcard_mapping_cardhldr_seq_id","wcard_mapping_client_seq_id","wcard_mapping_mbr_id","wcard_mapping_wcard_num","wcard_mapping_card_status","wcard_mapping_old_wcard_num","wcard_mapping_ecomm_id","wcard_mapping_actn_cntr","wcard_mapping_activation_auth_id","wcard_mapping_activation_date","wcard_mapping_activation_user","wcard_mapping_terminat_dt","wcard_mapping_loyalty_epsilon_mbr_id","wcard_client_setup_seq_id","wcard_client_setup_client_num","wcard_client_setup_client_dscnt_pct","wcard_client_setup_mbr_rebt_pct","wcard_client_setup_profile_num","wcard_client_setup_client_amt_rqstd","wcard_client_setup_wag_brand_rebt_ind","wcard_client_setup_acct_actn","wcard_client_setup_reject_files_ind","wcard_client_setup_mbr_id_type","wcard_client_setup_trmntd_f","wcard_client_setup_trmntn_dt","wcard_client_setup_client_sends_cardnum","wcard_client_setup_client_sends_amt","wcard_client_setup_gnrt_inv","wcard_client_setup_actvt_reqd","wcard_client_setup_dflt_rebt_pct","wcard_client_setup_client_sends_numofcards","wcard_client_setup_bulk_ship_ind","wcard_client_setup_new_card_charge","wcard_client_setup_initial_dollar_amt_ind","wcard_client_setup_initial_dollar_amt","wcard_client_setup_crd_manf_mstr_id","wcard_client_setup_letter_type_id","wcard_client_setup_material_id","wcard_client_setup_include_cover_letter","wcard_client_setup_intial_amt_for","wcard_client_setup_first_file_procsd","wcard_client_setup_source_id")
#Join Client Seq Id

join_client_addl = RFT_client1.join(sort_on_addl2,RFT_client1.client_seq_id == sort_on_addl2.client_seq_id,"inner")
#display(join_client_addl)
join_client_addl1 = join_client_addl.withColumn("wcard_client_setup_seq_id",RFT_client1.client_setup_seq_id) \
.withColumn("wcard_client_setup_client_num",RFT_client1.client_num) \
.withColumn("wcard_client_setup_client_dscnt_pct",RFT_client1.client_dscnt_pct) \
.withColumn("wcard_client_setup_mbr_rebt_pct",RFT_client1.mbr_rebt_pct) \
.withColumn("wcard_client_setup_profile_num",RFT_client1.profile_num) \
.withColumn("wcard_client_setup_client_amt_rqstd",RFT_client1.client_amt_rqstd) \
.withColumn("wcard_client_setup_wag_brand_rebt_ind",RFT_client1.wag_brand_rebt_ind) \
.withColumn("wcard_client_setup_acct_actn",RFT_client1.acct_actn) \
.withColumn("wcard_client_setup_reject_files_ind",RFT_client1.reject_files_ind) \
.withColumn("wcard_client_setup_mbr_id_type",RFT_client1.mbr_id_type) \
.withColumn("wcard_client_setup_trmntd_f",RFT_client1.trmntd_f) \
.withColumn("wcard_client_setup_trmntn_dt",RFT_client1.trmntd_dt) \
.withColumn("wcard_client_setup_client_sends_cardnum",RFT_client1.client_sends_cardnum) \
.withColumn("wcard_client_setup_client_sends_amt",RFT_client1.client_sends_amt) \
.withColumn("wcard_client_setup_gnrt_inv",RFT_client1.gnrt_inv) \
.withColumn("wcard_client_setup_actvt_reqd",RFT_client1.actvt_reqd) \
.withColumn("wcard_client_setup_dflt_rebt_pct",RFT_client1.dflt_rebt_pct) \
.withColumn("wcard_client_setup_client_sends_numofcards",RFT_client1.client_sends_numofcards) \
.withColumn("wcard_client_setup_bulk_ship_ind",RFT_client1.bulk_ship_ind) \
.withColumn("wcard_client_setup_new_card_charge",RFT_client1.new_card_charge) \
.withColumn("wcard_client_setup_initial_dollar_amt_ind",RFT_client1.initial_dollar_amt_ind) \
.withColumn("wcard_client_setup_initial_dollar_amt",RFT_client1.initial_dollar_amt) \
.withColumn("wcard_client_setup_crd_manf_mstr_id",RFT_client1.crd_manf_mstr_id) \
.withColumn("wcard_client_setup_letter_type_id",RFT_client1.letter_type_id) \
.withColumn("wcard_client_setup_material_id",RFT_client1.material_id) \
.withColumn("wcard_client_setup_include_cover_letter",RFT_client1.include_cover_letter) \
.withColumn("wcard_client_setup_intial_amt_for",RFT_client1.inital_amt_for) \
.withColumn("wcard_client_setup_first_file_procsd",RFT_client1.first_file_procsd) \
.withColumn("wcard_client_setup_source_id",RFT_client1.source_id) \
.withColumn("wcard_client_addl_seq_id",sort_on_addl2.client_addl_seq_id) \
.withColumn("wcard_client_addl_record_type",sort_on_addl2.record_type) \
.withColumn("wcard_client_addl_name",sort_on_addl2.name) \
.withColumn("wcard_client_addl_title",sort_on_addl2.title) \
.withColumn("wcard_client_addl_phone",sort_on_addl2.phone) \
.withColumn("wcard_client_addl_email",sort_on_addl2.email) \
.withColumn("wcard_client_addl_fax",sort_on_addl2.fax) \
.withColumn("wcard_client_addl_addr1",sort_on_addl2.addr1) \
.withColumn("wcard_client_addl_addr2",sort_on_addl2.addr2) \
.withColumn("wcard_client_addl_state",sort_on_addl2.state) \
.withColumn("wcard_client_addl_city",sort_on_addl2.city) \
.withColumn("wcard_client_addl_zip",sort_on_addl2.zip)

join_client_addl1 = join_client_addl1.select("wcard_client_setup_seq_id","wcard_client_setup_client_num","wcard_client_setup_client_dscnt_pct","wcard_client_setup_mbr_rebt_pct","wcard_client_setup_profile_num","wcard_client_setup_client_amt_rqstd","wcard_client_setup_wag_brand_rebt_ind","wcard_client_setup_acct_actn","wcard_client_setup_reject_files_ind","wcard_client_setup_mbr_id_type","wcard_client_setup_trmntd_f","wcard_client_setup_trmntn_dt","wcard_client_setup_client_sends_cardnum","wcard_client_setup_client_sends_amt","wcard_client_setup_gnrt_inv","wcard_client_setup_actvt_reqd","wcard_client_setup_dflt_rebt_pct","wcard_client_setup_client_sends_numofcards","wcard_client_setup_bulk_ship_ind","wcard_client_setup_new_card_charge","wcard_client_setup_initial_dollar_amt_ind","wcard_client_setup_initial_dollar_amt","wcard_client_setup_crd_manf_mstr_id","wcard_client_setup_letter_type_id","wcard_client_setup_material_id","wcard_client_setup_include_cover_letter","wcard_client_setup_intial_amt_for","wcard_client_setup_first_file_procsd","wcard_client_setup_source_id","wcard_client_addl_seq_id","wcard_client_addl_record_type","wcard_client_addl_name","wcard_client_addl_title","wcard_client_addl_phone","wcard_client_addl_email","wcard_client_addl_fax","wcard_client_addl_addr1","wcard_client_addl_addr2","wcard_client_addl_state","wcard_client_addl_city","wcard_client_addl_zip")

# COMMAND ----------

#Explicit Join on cardhldr seq id
jn_hldr_mppng = Sort_Card_hldr1.join(Join_mapping_client1,Sort_Card_hldr1.cardhldr_seq_id == Join_mapping_client1.wcard_mapping_cardhldr_seq_id,"right_outer")

jn_hldr_mppngl1 = jn_hldr_mppng.withColumn("wcard_cardholder_cardhldr_seq_id",Sort_Card_hldr1.cardhldr_seq_id) \
.withColumn("wcard_cardholder_cardhldr_fname",Sort_Card_hldr1.cardhldr_fname) \
.withColumn("wcard_cardholder_cardhldr_mname",Sort_Card_hldr1.cardhldr_mname) \
.withColumn("wcard_cardholder_cardhldr_lname",Sort_Card_hldr1.cardhldr_lname) \
.withColumn("wcard_cardholder_cardhldr_title",Sort_Card_hldr1.cardhldr_title) \
.withColumn("wcard_cardholder_cardhldr_suffix",Sort_Card_hldr1.cardhldr_suffix) \
.withColumn("wcard_cardholder_cardhldr_dob",Sort_Card_hldr1.cardhldr_dob) \
.withColumn("wcard_cardholder_cardhldr_addr1",Sort_Card_hldr1.cardhldr_addr1) \
.withColumn("wcard_cardholder_cardhldr_addr2",Sort_Card_hldr1.cardhldr_addr2) \
.withColumn("wcard_cardholder_cardhldr_city",Sort_Card_hldr1.cardhldr_city) \
.withColumn("wcard_cardholder_cardhldr_state",Sort_Card_hldr1.cardhldr_state) \
.withColumn("wcard_cardholder_cardhldr_zip",Sort_Card_hldr1.cardhldr_zip) \
.withColumn("wcard_cardholder_cardhldr_home_phone",Sort_Card_hldr1.cardhldr_home_phone) \
.withColumn("wcard_cardholder_cardhldr_work_phone",Sort_Card_hldr1.cardhldr_work_phone) \
.withColumn("wcard_cardholder_cardhldr_email",Sort_Card_hldr1.cardhldr_email) \
.withColumn("wcard_cardholder_enrlmt_type",Sort_Card_hldr1.enrlmt_type) \
.withColumn("wcard_cardholder_card_owner_flg",Sort_Card_hldr1.card_owner_flg) \
.withColumn("wcard_cardholder_cardhldr_crtd_dt",Sort_Card_hldr1.cardhldr_crtd_dt)

jn_hldr_mppngl1 = jn_hldr_mppngl1.select("wcard_mapping_seq_id","wcard_mapping_cardhldr_seq_id","wcard_mapping_client_seq_id","wcard_mapping_mbr_id","wcard_mapping_wcard_num","wcard_mapping_card_status","wcard_mapping_old_wcard_num","wcard_mapping_ecomm_id","wcard_mapping_actn_cntr","wcard_mapping_activation_auth_id","wcard_mapping_activation_date","wcard_mapping_activation_user","wcard_mapping_terminat_dt","wcard_mapping_loyalty_epsilon_mbr_id","wcard_client_setup_seq_id","wcard_client_setup_client_num","wcard_client_setup_client_dscnt_pct","wcard_client_setup_mbr_rebt_pct","wcard_client_setup_profile_num","wcard_client_setup_client_amt_rqstd","wcard_client_setup_wag_brand_rebt_ind","wcard_client_setup_acct_actn","wcard_client_setup_reject_files_ind","wcard_client_setup_mbr_id_type","wcard_client_setup_trmntd_f","wcard_client_setup_trmntn_dt","wcard_client_setup_client_sends_cardnum","wcard_client_setup_client_sends_amt","wcard_client_setup_gnrt_inv","wcard_client_setup_actvt_reqd","wcard_client_setup_dflt_rebt_pct","wcard_client_setup_client_sends_numofcards","wcard_client_setup_bulk_ship_ind","wcard_client_setup_new_card_charge","wcard_client_setup_initial_dollar_amt_ind","wcard_client_setup_initial_dollar_amt","wcard_client_setup_crd_manf_mstr_id","wcard_client_setup_letter_type_id","wcard_client_setup_material_id","wcard_client_setup_include_cover_letter","wcard_client_setup_intial_amt_for","wcard_client_setup_first_file_procsd","wcard_client_setup_source_id","wcard_cardholder_cardhldr_seq_id","wcard_cardholder_cardhldr_fname","wcard_cardholder_cardhldr_mname","wcard_cardholder_cardhldr_lname","wcard_cardholder_cardhldr_title","wcard_cardholder_cardhldr_suffix","wcard_cardholder_cardhldr_dob","wcard_cardholder_cardhldr_addr1","wcard_cardholder_cardhldr_addr2","wcard_cardholder_cardhldr_city","wcard_cardholder_cardhldr_state","wcard_cardholder_cardhldr_zip","wcard_cardholder_cardhldr_home_phone","wcard_cardholder_cardhldr_work_phone","wcard_cardholder_cardhldr_email","wcard_cardholder_enrlmt_type","wcard_cardholder_card_owner_flg" ,"wcard_cardholder_cardhldr_crtd_dt")

#RFT:Convert to Accnt Table
RFMT_ACCT_TABLE = jn_hldr_mppngl1.withColumn("acct_id",jn_hldr_mppngl1.wcard_mapping_wcard_num) \
.withColumn("enrl_type_cd",jn_hldr_mppngl1.wcard_cardholder_enrlmt_type) \
.withColumn("wcard_mapping_cardhldr_seq_id",jn_hldr_mppngl1.wcard_mapping_cardhldr_seq_id) \
.withColumn("actv_auth_id",jn_hldr_mppngl1.wcard_mapping_activation_auth_id) \
.withColumn("actv_dt",concat(substring(jn_hldr_mppngl1.wcard_mapping_activation_date,1,4),lit("-"),substring(jn_hldr_mppngl1.wcard_mapping_activation_date,5,2),lit("-"),substring(jn_hldr_mppngl1.wcard_mapping_activation_date,7,2))) \
.withColumn("actv_user_id",jn_hldr_mppngl1.wcard_mapping_activation_user) \
.withColumn("actv_atmpt_nbr",jn_hldr_mppngl1.wcard_mapping_actn_cntr) \
.withColumn("terminat_dt",concat(substring(jn_hldr_mppngl1.wcard_mapping_terminat_dt,1,4),lit("-"),substring(jn_hldr_mppngl1.wcard_mapping_terminat_dt,5,2),lit("-"),substring(jn_hldr_mppngl1.wcard_mapping_terminat_dt,7,2))) \
.withColumn("prog_id",jn_hldr_mppngl1.wcard_client_setup_client_num) \
.withColumn("loy_epsilon_mbr_id",jn_hldr_mppngl1.wcard_mapping_loyalty_epsilon_mbr_id)

#Rollup 2
Rollup_ACCT_TABLE = RFMT_ACCT_TABLE.withColumn("eff_dt",lit(EFF_DT)) \
.withColumn("end_dt",lit(None))
#Generting wcard_account.dat file to staging folder
ACCT_DF = WriteNullParquet(Rollup_ACCT_TABLE.select("acct_id","enrl_type_cd","actv_atmpt_nbr","actv_dt","actv_user_id","actv_auth_id","terminat_dt","eff_dt","end_dt","prog_id","loy_epsilon_mbr_id"))

#writing outputfile wcard_account.dat to Staging folder
ACCT_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file15+"/"+Batch_id)

# COMMAND ----------

# Join on cardhldr seq id
#RFT: For Account Cardholder Table
join_ACC_tab1 = Sort_Card_hldr1.join(Join_mapping_client1,Sort_Card_hldr1.cardhldr_seq_id == Join_mapping_client1.wcard_mapping_cardhldr_seq_id,"inner")

Rfmt_acc = join_ACC_tab1.withColumn("wcard_cardholder_cardhldr_seq_id",Sort_Card_hldr1.cardhldr_seq_id) \
.withColumn("wcard_cardholder_cardhldr_fname",Sort_Card_hldr1.cardhldr_fname) \
.withColumn("wcard_cardholder_cardhldr_mname",Sort_Card_hldr1.cardhldr_mname) \
.withColumn("wcard_cardholder_cardhldr_lname",Sort_Card_hldr1.cardhldr_lname) \
.withColumn("wcard_cardholder_cardhldr_title",Sort_Card_hldr1.cardhldr_title) \
.withColumn("wcard_cardholder_cardhldr_suffix",Sort_Card_hldr1.cardhldr_suffix) \
.withColumn("wcard_cardholder_cardhldr_dob",Sort_Card_hldr1.cardhldr_dob) \
.withColumn("wcard_cardholder_cardhldr_addr1",Sort_Card_hldr1.cardhldr_addr1) \
.withColumn("wcard_cardholder_cardhldr_addr2",Sort_Card_hldr1.cardhldr_addr2) \
.withColumn("wcard_cardholder_cardhldr_city",Sort_Card_hldr1.cardhldr_city) \
.withColumn("wcard_cardholder_cardhldr_state",Sort_Card_hldr1.cardhldr_state) \
.withColumn("wcard_cardholder_cardhldr_zip",Sort_Card_hldr1.cardhldr_zip) \
.withColumn("wcard_cardholder_cardhldr_home_phone",Sort_Card_hldr1.cardhldr_home_phone) \
.withColumn("wcard_cardholder_cardhldr_work_phone",Sort_Card_hldr1.cardhldr_work_phone) \
.withColumn("wcard_cardholder_cardhldr_email",Sort_Card_hldr1.cardhldr_email) \
.withColumn("wcard_cardholder_enrlmt_type",Sort_Card_hldr1.enrlmt_type) \
.withColumn("wcard_cardholder_card_owner_flg",Sort_Card_hldr1.card_owner_flg) \
.withColumn("wcard_cardholder_cardhldr_crtd_dt",Sort_Card_hldr1.cardhldr_crtd_dt)

Rfmt_acc = Rfmt_acc.select("wcard_mapping_seq_id","wcard_mapping_cardhldr_seq_id","wcard_mapping_client_seq_id","wcard_mapping_mbr_id","wcard_mapping_wcard_num","wcard_mapping_card_status","wcard_mapping_old_wcard_num","wcard_mapping_ecomm_id","wcard_mapping_actn_cntr","wcard_mapping_activation_auth_id","wcard_mapping_activation_date","wcard_mapping_activation_user","wcard_mapping_terminat_dt","wcard_mapping_loyalty_epsilon_mbr_id","wcard_client_setup_seq_id","wcard_client_setup_client_num","wcard_client_setup_client_dscnt_pct","wcard_client_setup_mbr_rebt_pct","wcard_client_setup_profile_num","wcard_client_setup_client_amt_rqstd","wcard_client_setup_wag_brand_rebt_ind","wcard_client_setup_acct_actn","wcard_client_setup_reject_files_ind","wcard_client_setup_mbr_id_type","wcard_client_setup_trmntd_f","wcard_client_setup_trmntn_dt","wcard_client_setup_client_sends_cardnum","wcard_client_setup_client_sends_amt","wcard_client_setup_gnrt_inv","wcard_client_setup_actvt_reqd","wcard_client_setup_dflt_rebt_pct","wcard_client_setup_client_sends_numofcards","wcard_client_setup_bulk_ship_ind","wcard_client_setup_new_card_charge","wcard_client_setup_initial_dollar_amt_ind","wcard_client_setup_initial_dollar_amt","wcard_client_setup_crd_manf_mstr_id","wcard_client_setup_letter_type_id","wcard_client_setup_material_id","wcard_client_setup_include_cover_letter","wcard_client_setup_intial_amt_for","wcard_client_setup_first_file_procsd","wcard_client_setup_source_id","wcard_cardholder_cardhldr_seq_id","wcard_cardholder_cardhldr_fname","wcard_cardholder_cardhldr_mname","wcard_cardholder_cardhldr_lname","wcard_cardholder_cardhldr_title","wcard_cardholder_cardhldr_suffix","wcard_cardholder_cardhldr_dob","wcard_cardholder_cardhldr_addr1","wcard_cardholder_cardhldr_addr2","wcard_cardholder_cardhldr_city","wcard_cardholder_cardhldr_state","wcard_cardholder_cardhldr_zip","wcard_cardholder_cardhldr_home_phone","wcard_cardholder_cardhldr_work_phone","wcard_cardholder_cardhldr_email","wcard_cardholder_enrlmt_type","wcard_cardholder_card_owner_flg","wcard_cardholder_cardhldr_crtd_dt")

NDF1 = Rfmt_acc.withColumn("src_sys_cd",lit(var_src_sys_cd)) \
.withColumn("acct_card_hldr_eff_dt",lit(EFF_DT)) \
.withColumn("card_ownr_ind",Rfmt_acc.wcard_cardholder_card_owner_flg) \
.withColumn("mbr_id_type_cd",Rfmt_acc.wcard_client_setup_mbr_id_type) \
.withColumn("mbr_id",Rfmt_acc.wcard_mapping_mbr_id) \
.withColumn("acct_id",Rfmt_acc.wcard_mapping_wcard_num) \
.withColumn("card_hldr_id",Rfmt_acc.wcard_cardholder_cardhldr_seq_id) \
.withColumn("acct_card_hldr_end_dt",lit(None))

srt_df = NDF1.select("*", row_number().over(Window.partitionBy("card_hldr_id").orderBy(NDF1.card_hldr_id)).alias("row_num"))
srt_df1 = srt_df.filter(srt_df.row_num ==1).drop("row_num")

# generating wcard_account_cardholder.dat
holder_DF = WriteNullParquet(srt_df1.select("card_hldr_id","acct_id","acct_card_hldr_eff_dt","src_sys_cd","acct_card_hldr_end_dt","card_ownr_ind","mbr_id","mbr_id_type_cd"))

#writing outputfile wcard_account_cardholder.dat to Staging folder
holder_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file16+"/"+Batch_id)

# COMMAND ----------

#create Wcard Program Contact Address
#RFT: For Program Contact Address Table
RT_Contact_Address = join_client_addl1.withColumn("addr_line_1",join_client_addl1.wcard_client_addl_addr1) \
.withColumn("addr_line_2",join_client_addl1.wcard_client_addl_addr2) \
.withColumn("state_cd",join_client_addl1.wcard_client_addl_state) \
.withColumn("zip_cd_5",substring(join_client_addl1.wcard_client_addl_zip,1,5)) \
.withColumn("zip_cd_4",substring(join_client_addl1.wcard_client_addl_zip,6,4)) \
.withColumn("addr_type_cd",coalesce(join_client_addl1.wcard_client_addl_record_type,lit(" "))) \
.withColumn("addr_eff_dt",lit(EFF_DT)) \
.withColumn("cntc_type_cd",coalesce(join_client_addl1.wcard_client_addl_record_type,lit(" "))) \
.withColumn("prog_id",join_client_addl1.wcard_client_setup_client_num) \
.withColumn("city",join_client_addl1.wcard_client_addl_city) \
.withColumn("addr_end_dt",lit(None))

ContactAddress_FILTER_DF = RT_Contact_Address.filter(RT_Contact_Address.addr_type_cd != "GEN")

# Generting wcard_program_contact_address.dat to staging folder
ContactAddr_DF = WriteNullParquet(ContactAddress_FILTER_DF.select("prog_id","addr_eff_dt","state_cd","city","addr_line_1","addr_line_2","addr_type_cd","zip_cd_5","zip_cd_4","cntc_type_cd","addr_end_dt","wcard_client_addl_zip"))

#writing outputfile wcard_program_contact_address.dat to Staging folder
ContactAddr_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Out_file17+"/"+Batch_id)

# Databricks notebook source
dbutils.widgets.text("PAR_NB_ERROR_MSG","",label="PAR_NB_ERROR_MSG")
dbutils.widgets.text("PAR_PL_ERROR_FOLDER","",label="PAR_PL_ERROR_FOLDER")
dbutils.widgets.text("PAR_NB_FILE_NAME","",label="PAR_NB_FILE_NAME")

errorMsg=dbutils.widgets.get("PAR_NB_ERROR_MSG")
folderName=dbutils.widgets.get("PAR_PL_ERROR_FOLDER")
fileName=dbutils.widgets.get("PAR_NB_FILE_NAME")
mountPath= "/mnt/curated/"
checkErrorFile=mountPath+folderName+"/"+fileName

# COMMAND ----------


  
try:
    emptyFileCheck=dbutils.fs.head(checkErrorFile,1)   
    if(len(emptyFileCheck) == 0):
      dbutils.notebook.exit(True)
    else:
      raise Exception(errorMsg)
      
except Exception as e:
    if 'java.io.FileNotFoundException' in str(e) :
                                       dbutils.notebook.exit(True) 
    else:
      raise 
 

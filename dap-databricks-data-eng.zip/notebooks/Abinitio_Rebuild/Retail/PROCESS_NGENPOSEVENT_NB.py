# Databricks notebook source
#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)
#eventDF=spark.read.parquet('/mnt/wrangled/retail/retail_sales/staging/dap_idl_ngenpos_event/20220511003718/*')

# COMMAND ----------

#dbutils.widgets.text("PAR_INPUT_FILE","dap_idl_ngenpos_event")
#dbutils.widgets.text("PAR_BATCH_ID","20220511003718")
#dbutils.widgets.text("PAR_INPUT_PATH","retail/retail_sales/staging")

# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_BATCH_ID")
Input_path = dbutils.widgets.get("PAR_INPUT_PATH")
Input_file = dbutils.widgets.get("PAR_INPUT_FILE")

# COMMAND ----------

#Read Input File
#eventDF=spark.read.parquet('/mnt/wrangled/retail/retail_sales/staging/dap_idl_ngenpos_event/20220511003718/*')
eventDF=spark.read.format("parquet").load(mountPoint+"/"+Input_path+"/"+Input_file+"/"+Batch_id)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
#eventDF.counF.withColt()#36940672
RenameFieldsDF=eventDF.withColumn("rx_nbr",eventDF.wag_ScriptID.cast(IntegerType())).withColumn("phone_verification_available_ind",when(eventDF.valcSubType=='PhoneNumberNotFoundForPatient','N').otherwise(lit(None)))
Fltrbusrules4DF=RenameFieldsDF.filter((RenameFieldsDF.valcSubType=='PatientValidation')|(RenameFieldsDF.valcSubType=='NumberOfIncorrectAttemptsExceeded')| (RenameFieldsDF.valcSubType=='PhoneNumberNotFoundForPatient'))

# COMMAND ----------

from pyspark.sql.window import Window
#SortedDF=Fltrbusrules4DF.sort(Fltrbusrules4DF.wag_RFN,Fltrbusrules4DF.rx_nbr,Fltrbusrules4DF.SequenceNumber,Fltrbusrules4DF.DetailNumber)
# DedupSortDF = SortedDF.select("*", row_number().over(Window.partitionBy("wag_RFN","rx_nbr","SequenceNumber","DetailNumber").orderBy(desc("wag_RFN"),desc("rx_nbr"),desc("SequenceNumber"),desc("DetailNumber"))).alias("row_num"))
# DedupSortHolder = DedupSortDF.filter(DedupSortDF.row_num ==1).drop("row_num")
#DedupSortHolder.count()
DedupHolderDF=Fltrbusrules4DF.dropDuplicates(['wag_RFN','rx_nbr','SequenceNumber','DetailNumber'])
#Sorted1DF=DedupHolderDF.sort(DedupHolderDF.wag_RFN,DedupHolderDF.rx_nbr)
DedupHolderDF.write.format('parquet').mode("overwrite").save(mountPoint+'/'+Input_path+'/'+'NgenEventDedup')

# COMMAND ----------

wspec = Window.partitionBy('wag_RFN','rx_nbr').orderBy('SequenceNumber','DetailNumber')
wspec2 = Window.partitionBy('wag_RFN','rx_nbr').orderBy('SequenceNumber','DetailNumber').rowsBetween(Window.unboundedPreceding,Window.unboundedFollowing)

DedupHolderDF2 = spark.read.format('parquet').load(mountPoint+'/'+Input_path+'/'+'NgenEventDedup')
rolledUp_df = DedupHolderDF2.withColumn('r',row_number().over(wspec))\
.withColumn('wag_Status_temp',when((trim(col('valcSubType'))=='PatientValidation') | (col('r')==1),col('wag_Status')).otherwise(None))\
.withColumn('wag_Status',last(col('wag_Status_temp'),True).over(wspec2))\
.withColumn('wag_VerificationMode_temp',when((trim(col('valcSubType'))=='PatientValidation') | (col('r')==1),col('wag_VerificationMode')).otherwise(None))\
.withColumn('wag_VerificationMode',last(col('wag_VerificationMode_temp'),True).over(wspec2))\
.withColumn('wag_NumberOfIncorrectAttempts_temp',when((trim(col('valcSubType'))=='NumberOfIncorrectAttemptsExceeded') | (col('r')==1),col('wag_NumberOfIncorrectAttempts')).otherwise(None))\
.withColumn('wag_NumberOfIncorrectAttempts',last(col('wag_NumberOfIncorrectAttempts_temp'),True).over(wspec2))\
.withColumn('phone_verification_available_ind_temp',when((trim(col('valcSubType'))=='PhoneNumberNotFoundForPatient'),lit('N'))\
            .when(col('r')==1,col('phone_verification_available_ind'))\
            .otherwise(None))\
.withColumn('phone_verification_available_ind',last(col('phone_verification_available_ind_temp'),True).over(wspec2))\
.where(col('r')==1).select('wag_RFN','rx_nbr','wag_Status','wag_VerificationMode','wag_NumberOfIncorrectAttempts','phone_verification_available_ind')
#display(rolledUp_df)
rolledUp_df.write.format('parquet').mode("overwrite").save(mountPoint+'/'+Input_path+'/'+'NgenPOSEventProcessedCashRPT'+'/'+Batch_id)



# COMMAND ----------

#display(DedupHolderDF2.where((col('wag_RFN').contains('00013417980422050703')) & ((col('rx_nbr').contains('5006995')))))
#DedupHolderDF2.where(DedupHolderDF2.rx_nbr=='807896').display()
#rolledUp_df.where(rolledUp_df.wag_RFN=='10209416127622050703').display()
#.where(rolledUp_df.rx_nbr=='807247').display()

# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

#Widgets for passing required parameters values
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220905143035")
# dbutils.widgets.text("PAR_INPUT_FOLDER1","pharmacy_healthcare/mail_order/output")
# dbutils.widgets.text("PAR_INPUT_FOLDER2","digital/ecom/outbound")
# dbutils.widgets.text("PAR_INPUT_FILE1","extract_from_mailmgt_dim_card")
# dbutils.widgets.text("PAR_INPUT_FILE2","extract_from_ecomm_dim_card")
# dbutils.widgets.text("PAR_OUTPUT_FOLDER1","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_OUTPUT_FILE1","combined_extract_from_mailmgt_dim_card")
# dbutils.widgets.text("PAR_OUTPUT_REJFILE1","retail/retail_sales/reject/ECDW7127T_extract_from_ecomm_dim_card_rej")
# dbutils.widgets.text("PAR_OUTPUT_DUPFILE1","retail/retail_sales/reject/ECDW7127T_extract_from_ecomm_dim_card_dup")
# dbutils.widgets.text("PAR_OUTPUT_FILE2","reconstructed_extract_from_ecomm_dim_card")
# dbutils.widgets.text("PAR_SNFK_WH","PROD_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_SNFK_DB1","PROD_STAGING")
# dbutils.widgets.text("PAR_SNFK_DB2","PROD_RETAIL")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.DIM_CARD_STG")
# dbutils.widgets.text("PAR_SNFK_TBL2","RETAIL_SALES.DIM_CARD")
# dbutils.widgets.text("PAR_OUTPUT_LKPFILE1","lkp_card")
# dbutils.widgets.text("PAR_OUTPUT_LDR1","retail/retail_sales/output/ecomm_dim_card_ldr")

# COMMAND ----------

# Defining Schema for two source files : mailmgt_dim_card and ecomm_dim_card

# source_schema=['tndr_type_cd',
#               'card_token_val',
#               'latest_txn_dt']

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
#schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,source_schema )))
#print(schema)

# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Input_Folder1 = dbutils.widgets.get("PAR_INPUT_FOLDER1")
Input_Folder2 = dbutils.widgets.get("PAR_INPUT_FOLDER2")
Input_File1 = dbutils.widgets.get("PAR_INPUT_FILE1")
Input_File2 = dbutils.widgets.get("PAR_INPUT_FILE2")
Output_Folder1 = dbutils.widgets.get("PAR_OUTPUT_FOLDER1")
Output_File1 = dbutils.widgets.get("PAR_OUTPUT_FILE1")
Output_RejFile1 = dbutils.widgets.get("PAR_OUTPUT_REJFILE1")
Output_DupFile1 = dbutils.widgets.get("PAR_OUTPUT_DUPFILE1")
Output_LkpFile1 = dbutils.widgets.get("PAR_OUTPUT_LKPFILE1")
Output_File2 = dbutils.widgets.get("PAR_OUTPUT_FILE2")
Output_File3 = dbutils.widgets.get("PAR_OUTPUT_LDR1")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_DB2 = dbutils.widgets.get("PAR_SNFK_DB2")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
SNFL_TBL_NAME2 = dbutils.widgets.get("PAR_SNFK_TBL2")

#mailmgt_dimcard_df = spark.read.format("csv").load(mountPoint+"/"+Input_Folder1+"/"+Input_File1+"_"+Batch_id+".dat")
mailmgt_dimcard_df = spark.read.format("parquet").load(mountPoint+"/"+Output_Folder1+"/Dim_Card_Files/"+Input_File1+"/"+Batch_id)

mailmgt_dimcard_df1 = (
mailmgt_dimcard_df.withColumn("tndr_type_cd",col("_c0").substr(1,1)) \
.withColumn("length",length("_c0"))
.withColumn("card_token_val",col("_c0").substr(lit(2),col("length") - lit(11))) \
.withColumn("latest_txn_dt",to_date(col("_c0").substr(-10,10),'yyyy-MM-dd'))
).drop("_c0","length")

#display(mailmgt_dimcard_df1)
#mailmgt_dimcard_df1.printSchema()

#ecomm_dimcard_df = spark.read.format("csv").load(mountPoint+"/"+Input_Folder2+"/"+Input_File2+"_"+Batch_id+".dat")
ecomm_dimcard_df = spark.read.format("parquet").load(mountPoint+"/"+Output_Folder1+"/Dim_Card_Files/"+Input_File2+"/"+Batch_id)

ecomm_dimcard_df1 = (
ecomm_dimcard_df.withColumn("tndr_type_cd",col("_c0").substr(1,1)) \
.withColumn("length",length("_c0"))
.withColumn("card_token_val",col("_c0").substr(lit(2),col("length") - lit(11))) \
.withColumn("latest_txn_dt",to_date(col("_c0").substr(-10,10),'yyyy-MM-dd'))
).drop("_c0","length")

#display(ecomm_dimcard_df1)
#ecomm_dimcard_df1.printSchema()

combined_dimcard_df = mailmgt_dimcard_df1.union(ecomm_dimcard_df1)
combined_dimcard_df = combined_dimcard_df.filter("length(trim(card_token_val)) >= 4 and length(trim(card_token_val)) <=20")

#writing combined_dimcard_df to staging folder in parquet format.
combined_dimcard_df.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Output_Folder1+"/"+Output_File1+"/"+Batch_id)

# COMMAND ----------

ValidCheckDF = combined_dimcard_df.filter((trim(col("card_token_val")).isNotNull()) & (col("card_token_val")!='') & (trim(col("tndr_type_cd")).isNotNull()) & (col("tndr_type_cd")!='') & (col("tndr_type_cd").isin("0","1","2")) & (trim(col("card_token_val"))!='#'))

#display(ValidCheckDF)

RejectRecs = combined_dimcard_df.subtract(ValidCheckDF)

RejectRecs.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Output_RejFile1+"/"+Batch_id)

# COMMAND ----------

#CardTokenVal_Distinct_recs = ValidCheckDF.dropDuplicates(['card_token_val'])

CardTokenVal_Distinct_recs = ValidCheckDF.select("tndr_type_cd","card_token_val","latest_txn_dt", row_number().over(Window.partitionBy("card_token_val").orderBy(ValidCheckDF['card_token_val'])).alias("row_num")) 
CardTokenVal_Distinct_recs1 = CardTokenVal_Distinct_recs.filter(CardTokenVal_Distinct_recs.row_num ==1).drop("row_num")

#display(CardTokenVal_Distinct_recs1)
#print(CardTokenVal_Distinct_recs.count())

CardTokenVal_Dup_recs = ValidCheckDF.subtract(CardTokenVal_Distinct_recs1)
#display(CardTokenVal_Dup_recs)
#print(CardTokenVal_Dup_recs.count())

CardTokenVal_Dup_recs.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Output_Folder1+"/"+Output_DupFile1+"/"+Batch_id)

# COMMAND ----------

ReformatColsDF = CardTokenVal_Distinct_recs1.withColumn("tndr_type_cd",(trim(col("tndr_type_cd")))) \
.withColumn("card_token_val",(trim(col("card_token_val"))))

#display(ReformatColsDF)

ReformatColsDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Output_Folder1+"/"+Output_File2+"/"+Batch_id)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

ReformatCardTokenValStg = ReformatColsDF.select("card_token_val")
#display(ReformatCardTokenValStg)

#writing the above DF to DIM_CARD_STG Table:

delete_DIMCARDstg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB1, SNFL_TBL_NAME1)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_DIMCARDstg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB1,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

ReformatCardTokenValStg.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB1) \
        .option("dbtable", SNFL_TBL_NAME1) \
        .option("continue_on_error","on")\
        .save()

# COMMAND ----------

sel_dim_card_tbl = "Select * FROM {0}".format(SNFL_TBL_NAME2)
dim_card_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB2) \
     .option("query",sel_dim_card_tbl) \
     .load()

#display(dim_card_tbl_df)

dim_card_tbl_df.createOrReplaceTempView("DIM_CARD_TBL")
ReformatCardTokenValStg.createOrReplaceTempView("DIM_CARD_STG_TBL")

DimCardAndDimCardStg = spark.sql("select card_token_val,card_id from DIM_CARD_TBL where card_token_val in (select card_token_val from DIM_CARD_STG_TBL)")

#display(DimCardAndDimCardStg)

cardTokenValJoin = ReformatColsDF.join(DimCardAndDimCardStg,ReformatColsDF.card_token_val == DimCardAndDimCardStg.card_token_val,"full_outer").filter(DimCardAndDimCardStg.card_token_val.isNull()) \
.drop(DimCardAndDimCardStg.card_token_val)
#display(cardTokenValJoin)

cardTokenValJoinFinalDF = cardTokenValJoin.withColumn("e2c_f6c",regexp_extract(col("card_token_val"),r'[0-9]+',0)) \
.withColumn("e2c_l4c",col("card_token_val").substr(-4,4)) \
.select("card_id","card_token_val","latest_txn_dt","e2c_f6c","e2c_l4c","tndr_type_cd",row_number().over(Window.partitionBy("card_token_val").orderBy(cardTokenValJoin['card_token_val'])).alias("row_num")) 
cardTokenValJoinFinalDF1 = cardTokenValJoinFinalDF.filter(cardTokenValJoinFinalDF.row_num ==1).drop("row_num")

cardTokenValJoinFinalDF1 = cardTokenValJoinFinalDF1.withColumn("e2c_f6c",when(length(col("e2c_f6c"))>=6,substring('e2c_f6c',1,6)).otherwise(col("e2c_f6c")))

#display(cardTokenValJoinFinalDF1)

getMaxCardID_DF = spark.sql("select 'max_card_id' as lkp_key,max(card_id) as max_card_id from DIM_CARD_TBL")
#display(getMaxCardID_DF)

getMaxCardID_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Output_Folder1+"/"+Output_LkpFile1+"/"+Batch_id)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
ReformatCardID_DF = cardTokenValJoinFinalDF1.withColumn("card_id",lit("null"))
#display(ReformatCardID_DF)

#retrieving current max card id from LKPUP DF:
curr_card_id = int(getMaxCardID_DF.withColumn("max_card_id",when(getMaxCardID_DF.max_card_id.isNull(),"0") \
                                          .otherwise(getMaxCardID_DF.max_card_id)).select("max_card_id").collect()[0].max_card_id)
#curr_card_id = int(curr_card_id)
#print(curr_card_id)

ReformatCardID_DF1 = ReformatCardID_DF.withColumn("tndr_type_cd",when(ReformatCardID_DF.tndr_type_cd=="0","14").when(ReformatCardID_DF.tndr_type_cd=="1","14").otherwise("359"))

DIMCard_Final = ReformatCardID_DF1.withColumn("card_id",row_number().over(Window.orderBy("card_token_val"))+curr_card_id) 

DIMCard_Final1 = DIMCard_Final.withColumn("latest_txn_dt",when(col("latest_txn_dt")=="0001-01-01","1900-01-01").otherwise(col("latest_txn_dt"))) 

#casting latest_txn_dt as date:
DIMCard_Final2 = DIMCard_Final1.withColumn("latest_txn_dt", to_date(DIMCard_Final1.latest_txn_dt, 'yyyy-MM-dd'))

#display(DIMCard_Final2)

print("FINAL DIM_CARD LDR FILE COUNT: {}".format(DIMCard_Final1.count()))

#write Final LDR file to Output Folder:
DIMCard_Final2.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Output_File3+"/"+Batch_id)

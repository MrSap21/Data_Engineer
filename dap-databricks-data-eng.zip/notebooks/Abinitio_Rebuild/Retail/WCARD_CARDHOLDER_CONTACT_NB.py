# Databricks notebook source
#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#Widgets for passing required parameters values

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220525064357")
# dbutils.widgets.text("PAR_STAGING_PATH","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_INPUT_FILE","wcard_cardholder_contact")
# dbutils.widgets.text("PAR_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_SNFK_DB1","DEV_RETAIL")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_CARDHOLDER_CONTACT")
# dbutils.widgets.text("PAR_UPDATE_OUTPUT_FILE","wcard_cardholder_contact_update_ascii.pipe_delim")
# dbutils.widgets.text("PAR_INSERT_OUTPUT_FILE","wcard_cardholder_contact_insert_ascii.pipe_delim")

# COMMAND ----------

Batch_Id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Path = dbutils.widgets.get("PAR_STAGING_PATH")
Input_File = dbutils.widgets.get("PAR_INPUT_FILE")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
Update_Output_File = dbutils.widgets.get("PAR_UPDATE_OUTPUT_FILE")
Insert_Output_File = dbutils.widgets.get("PAR_INSERT_OUTPUT_FILE")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

WcardCardHldrCnctSrcDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Path+"/"+Input_File+"/"+Batch_Id)
#display(WcardCardHldrCnctSrcDF)
#print(WcardCardHldrCnctSrcDF.count())

#Dedup Sorted:
WcardDepupSortedDF = WcardCardHldrCnctSrcDF.select("*", row_number().over(Window.partitionBy("card_hldr_id","channel_type_cd").orderBy(WcardCardHldrCnctSrcDF.card_hldr_id,WcardCardHldrCnctSrcDF.channel_type_cd)).alias("row_num")) 
WcardDepupSortedDF1 = WcardDepupSortedDF.filter(WcardDepupSortedDF.row_num ==1).drop("row_num")

#FBE:Only pass Valid Key:
FilterValidKeyDF = WcardDepupSortedDF1.filter(((WcardDepupSortedDF1.card_hldr_id.isNotNull()) & (WcardDepupSortedDF1.card_hldr_id!="")) & ((WcardDepupSortedDF1.channel_type_cd.isNotNull()) & (WcardDepupSortedDF1.channel_type_cd!="")))

#RFT - col concat:
RfmtColConcatDF = FilterValidKeyDF.withColumn("compare_col_concatenated",concat(FilterValidKeyDF.card_hldr_id,FilterValidKeyDF.channel_type_cd,coalesce(trim(FilterValidKeyDF.cntc_chnl_val),lit("Test1"))))
#display(RfmtColConcatDF)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#wcard cardholder contact result:
import datetime

EFF_DT = Batch_Id[:8]
EFF_DT=datetime.datetime.strptime(EFF_DT,"%Y%m%d").date()-datetime.timedelta(1)
print("EFF_DT : {}".format(EFF_DT))

sel_wcard_cardholder_cnct_tbl = "Select * FROM {0} where cntc_chnl_end_dt is NULL and src_sys_cd=0".format(SNFL_TBL_NAME1)

wcardCardHldrCnct_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB1) \
     .option("query",sel_wcard_cardholder_cnct_tbl) \
     .load()

#display(wcardCardHldrCnct_tbl_df)
#print(wcardCardHldrCnct_tbl_df.count())

#FBE:Only record with a null end dt:
FilterEndDt_DF = wcardCardHldrCnct_tbl_df.filter(wcardCardHldrCnct_tbl_df.CNTC_CHNL_END_DT.isNull())

#display(FilterEndDt_DF)

# RFT - col concat-1:
RfmtColConcatDF1 = FilterEndDt_DF.withColumn("compare_col_concatenated",concat(FilterEndDt_DF.CARD_HLDR_ID,FilterEndDt_DF.CHANNEL_TYPE_CD,coalesce(trim(FilterEndDt_DF.CNTC_CHNL_VAL),lit("Test1"))))

#display(RfmtColConcatDF1)

#Join-5:
JoinTableSrcFileDF = RfmtColConcatDF.join(RfmtColConcatDF1,on = [RfmtColConcatDF.card_hldr_id==RfmtColConcatDF1.CARD_HLDR_ID,RfmtColConcatDF.channel_type_cd==RfmtColConcatDF1.CHANNEL_TYPE_CD],how = "inner")

JoinTableSrcFileDF1 = JoinTableSrcFileDF.withColumn("update_flag",when(((RfmtColConcatDF.cntc_chnl_val.isNotNull()) & (RfmtColConcatDF1.CNTC_CHNL_VAL.isNotNull()) & (RfmtColConcatDF.cntc_chnl_val==RfmtColConcatDF1.CNTC_CHNL_VAL)),lit("N")).when((((RfmtColConcatDF.cntc_chnl_val=="") & (RfmtColConcatDF1.CNTC_CHNL_VAL=="")) | ((RfmtColConcatDF.cntc_chnl_val.isNull()) & (RfmtColConcatDF1.CNTC_CHNL_VAL.isNull()))),lit("N")).when(((RfmtColConcatDF.compare_col_concatenated.isNotNull()) & (RfmtColConcatDF1.compare_col_concatenated.isNotNull()) & (RfmtColConcatDF.compare_col_concatenated==RfmtColConcatDF1.compare_col_concatenated)),lit("N")).otherwise(lit("Y"))) \
.withColumn("cntc_chnl_end_dt1",lit(EFF_DT)) \
.withColumn("cntc_chnl_type_cd",RfmtColConcatDF.channel_type_cd)
#display(JoinTableSrcFileDF1)

JoinTableSrcFileDF1 = JoinTableSrcFileDF1.select(RfmtColConcatDF.card_hldr_id,RfmtColConcatDF.cntc_chnl_eff_dt,"cntc_chnl_type_cd",RfmtColConcatDF.cntc_chnl_val,"cntc_chnl_end_dt1",RfmtColConcatDF.src_sys_cd,"update_flag").withColumnRenamed("cntc_chnl_end_dt1","cntc_chnl_end_dt")

#FBE:Only pass where update flag = "Y":
FilterUpdateFlagYDF = JoinTableSrcFileDF1.filter(JoinTableSrcFileDF1.update_flag=="Y") \
.withColumnRenamed("cntc_chnl_type_cd","channel_type_cd").drop("update_flag") \
.select("card_hldr_id","src_sys_cd","cntc_chnl_eff_dt","channel_type_cd","cntc_chnl_val","cntc_chnl_end_dt")
#display(FilterUpdateFlagYDF)

#Wcard psc addr stand result Update File:
print("wcard_cardholder_contact_update_ascii.pipe_delim Count:{}".format(FilterUpdateFlagYDF.count()))
FilterUpdateFlagYDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Path+"/"+Update_Output_File+"/"+Batch_Id)

# COMMAND ----------

# Join UnUsed0 Port - Left_anti_join:
JoinTableSrcFileUnUsed0DF = RfmtColConcatDF.join(RfmtColConcatDF1,on = [RfmtColConcatDF.card_hldr_id==RfmtColConcatDF1.CARD_HLDR_ID,RfmtColConcatDF.channel_type_cd==RfmtColConcatDF1.CHANNEL_TYPE_CD],how="left_anti").drop("compare_col_concatenated")
#display(JoinTableSrcFileUnUsed0DF)

#RFT: Create insert record for updated row:
createInsRecDF = FilterUpdateFlagYDF.withColumn("cntc_chnl_end_dt",lit(None)) \
.withColumnRenamed("cntc_chnl_type_cd","channel_type_cd")

#Gather:2 - FilterNonEmpCardId_DF and createInsRecDF union:
GatherInsFinal_DF = createInsRecDF.unionByName(JoinTableSrcFileUnUsed0DF)

#FBE: Remove record where the contact value is NULL:
FilterCntctValDF = GatherInsFinal_DF.filter(GatherInsFinal_DF.cntc_chnl_val.isNotNull()) \
.select("card_hldr_id","src_sys_cd","cntc_chnl_eff_dt","channel_type_cd","cntc_chnl_val","cntc_chnl_end_dt")

#display(FilterCntctValDF)
#Wcard Cardholder Contact Load File:
print("wcard_cardholder_contact_insert_ascii.pipe_delim Count:{}".format(FilterCntctValDF.count()))
FilterCntctValDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Path+"/"+Insert_Output_File+"/"+Batch_Id)

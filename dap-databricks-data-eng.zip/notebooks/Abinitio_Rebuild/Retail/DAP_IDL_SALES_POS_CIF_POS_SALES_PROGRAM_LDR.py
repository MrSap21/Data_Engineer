# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove("PAR_MNT_POINT")

# COMMAND ----------

# DBTITLE 1,Setup
### NOTE: Type NUL or ␀ for \x00, Type SOH or  for \x01 or type your own delimiter e.g , | etc.

from pyspark.sql.functions import *
from pyspark.sql.types import *
import re

#dbutils.widgets.text("PAR_MNT_POINT", "")            # /mnt/wrangled
dbutils.widgets.text("PAR_INPUT_FILE_PATH1", "")      # retail/retail_sales/lookup/edw_idl_sales_pos_pos_aarp_txn_extr_output/12345 NOTE: This could be any location. 
dbutils.widgets.text("PAR_INPUT_FILE_PATH2", "")      # retail/retail_sales/lookup/edw_idl_pos_sales_trsanction_program_lk_output/12345
dbutils.widgets.text("PAR_INPUT_FILE_PATH3", "")      # retail/retail_sales/lookup/edw_idl_sales_nextgen_cif_pos_sales_program_ldr_output/12345
dbutils.widgets.text("PAR_INPUT_FILE_PATH4", "")      # retail/retail_sales/lookup/edw_idl_pos_sales_txn_program_ngenpos_output/12345
dbutils.widgets.text("PAR_PARQUET_OUT_LOCATION", "") # retail/retail_sales/staging/edw_idl_ngenpos_workstationloc/20220121054422 NOTE: This could be any location.
dbutils.widgets.text("PAR_RJECT_REC_PATH", "")        # path for the reject record
dbutils.widgets.text("PAR_RJECT_REC_PATH1", "")        # path for the reject record
dbutils.widgets.text("PAR_RJECT_REC_PATH2", "")        # path for the reject record
#dbutils.widgets.text("PAR_BATCH_ID", "12345")        # path for the reject record


#dbutils.widgets.text("PAR_NUM_COLS", "")             # 3
#dbutils.widgets.text("PAR_DELIMITER", "")            # Type NUL or ␀ for \x00, Type SOH or  for \x01 or type your own delimiter e.g , | etc. 
 
#dbutils.widgets.text("PAR_OUTPUT_SCHEMA", "")        # pcms_TransactionType,pcms_WorkstationLocation,wag_RFN


var_Input_File_Path1 = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH1')
var_Input_File_Path2 = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH2')
var_Input_File_Path3 = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH3')
var_Input_File_Path4 = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH4')
var_Parquet_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_PARQUET_OUT_LOCATION')
var_Reject_File = mountPoint + '/' + dbutils.widgets.get('PAR_RJECT_REC_PATH')
REJ_FILEPATH1 = mountPoint + '/' + dbutils.widgets.get('PAR_RJECT_REC_PATH1')
REJ_FILEPATH2 = mountPoint + '/' + dbutils.widgets.get('PAR_RJECT_REC_PATH2')
#batch_id = dbutils.widgets.get('PAR_BATCH_ID')


#var_Input_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH')
#var_Input_File = var_Input_File_Path + '/' + dbutils.widgets.get('PAR_INPUT_FILE') 
#var_Converted_File_Path = var_Input_File_Path + '/' + 'converted_delimited' 
#var_Converted_File = var_Converted_File_Path + '/' + 'MULTI_ROW_' + dbutils.widgets.get('PAR_INPUT_FILE')

#var_Parquet_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_PARQUET_OUT_LOCATION')
#var_num_cols = int(dbutils.widgets.get('PAR_NUM_COLS'))


# var_Get_Delimiter = dbutils.widgets.get('PAR_DELIMITER').strip()
# # var_Delimiter = dbutils.widgets.get('PAR_DELIMITER').strip()

# if var_Get_Delimiter == '␀' or var_Get_Delimiter == 'NUL': #'\x00':
#     var_Delimiter = "Default_Nul_character"
# elif var_Get_Delimiter == 'SOH' or var_Get_Delimiter == '': #\x01':
#     var_Delimiter = ''
# elif var_Get_Delimiter == '':
#     dbutils.notebook.exit("No delimiter specified. \n Type NUL or ␀ for '\\x00', Type SOH or  for '\\x01' or type your own delimiter e.g , | etc.")
# else:
#     var_Delimiter = var_Get_Delimiter

# NOTE: by default nullable is being set to True in the output schema below
#       If you set it to False then it does a null check for all the columns.
#       For data set with millions of rows it ipacts the performance 
#       Since this conversion is for sanity testing so it's ok to set it to True

#var_Output_Schema = StructType(list(map(lambda fl : StructField(fl.strip(), StringType(),True), dbutils.widgets.get('PAR_OUTPUT_SCHEMA').split(',')))) 

# print(var_File_Path)
print('Input file1 is                          : ', var_Input_File_Path1)
print('Input file2 is                          : ', var_Input_File_Path2)
print('Input file3 is                          : ', var_Input_File_Path3)
print('Input file4 is                          : ', var_Input_File_Path4)
print('Converted Parquet file location is     : ', var_Parquet_File_Path)
print('Reject path is                          : ', var_Reject_File)
print('Reject path1 is                          : ', REJ_FILEPATH1)
print('Reject path2 is                          : ', REJ_FILEPATH2)
#print('Batch ID is                          : ', batch_id)

#print('Converted multi line delimited file is : ', var_Converted_File)
#print('Number of columns in file              : ', var_num_cols)
#print('Parquet schema for converted file      : ', var_Output_Schema)
#print('Delimiter                              : ', var_Delimiter)
#print('-----', bytes(var_Delimiter, 'utf-8'), '-----', var_Delimiter)




# COMMAND ----------

#Reading File1

df1 =spark.read.format("parquet").load(var_Input_File_Path1)  #.toDF(*Input_Schema)
#display(df1)

# COMMAND ----------

df2 =spark.read.format("parquet").load(var_Input_File_Path2)  #.toDF(*Input_Schema)
#display(df2)

# COMMAND ----------

df3 =spark.read.format("parquet").load(var_Input_File_Path3)  #.toDF(*Input_Schema)
#display(df3)

# COMMAND ----------

df4 =spark.read.format("parquet").load(var_Input_File_Path4)  #.toDF(*Input_Schema)
df4 = df4.filter(df4.valcSubType=='LoyaltyLookup')
df4 = df4.withColumn("sales_txn_id", df4.wag_RFN)\
            .withColumn("next_gen_rfn_value", df4.wag_RFN)\
            .withColumn("identification_method", when(df4.wag_lookupSucessful=='true', df4.wag_idMethod))\
            .withColumn("wag_cardNumber", df4.wag_cardNumber)

df4 = df4.select(
        "sales_txn_id",
    lit("").alias("sales_txn_dt"),
    lit("").alias("sales_ord_src_type"),
    lit("").alias("sales_txn_type"),
    lit("").alias("src_sys_cd"),
    "wag_cardNumber",
    lit("").alias("store_nbr"),
    lit("").alias("src_cust_id"),
    lit("").alias("txn_end_dttm"),
    lit("").alias("ord_stat_cd"),
    lit("").alias("fulfillment_type_cd"),
    lit("").alias("originating_str_nbr"),
    lit("").alias("fulfillment_str_nbr"),
    lit("").alias("pick_up_at_str_nbr"),
    lit("").alias("bypass_reason_cd"),
    lit("").alias("ord_entry_channel_cd"),
    lit("").alias("ord_desc"),
    lit("").alias("promise_dt"),
    lit("").alias("promise_tm"),
    lit("").alias("rx_reqst_fill_dt"),
    lit("").alias("rx_reqst_fill_tm"),
    lit("").alias("txn_type"),
    lit("").alias("ord_ship_dt"),
    lit("").alias("ord_ship_tm"),
    lit("").alias("return_stat_desc"),
    lit("").alias("prcs_ind"),
    lit("").alias("prcs_immediate_ind"),
    lit("").alias("nbr_of_images"),
    lit("").alias("tot_image_sz_kb"),
    lit("").alias("pcp_ord_id"),
    lit("").alias("vndr_cust_id"),
    lit("").alias( "vndr_ord_id"),
    lit("").alias("commision_vndr_cd"),
    lit("").alias("photo_origin_id"),
    lit("").alias('spcl_ord_desc'),
    lit("").alias("orig_inv_dlrs"),
    lit("").alias("prod_cost_dlrs"),
    lit("").alias("shipping_price_dlrs"),
    lit("").alias("in_str_ord_ind"),
    lit("").alias("share_ord_ind"),
    lit("").alias("aarp_ind"),
    lit("").alias("ord_return_ind"),
    lit("").alias("pre_click_ord_ind"),
    lit("").alias("held_ord_ind"),
    lit("").alias("lens_ord_ind"),
    lit("").alias("self_pay_ind"),
    lit("").alias("xref_line_item_seq_nbr"),
    lit("").alias("generic_ord_ind"),
    lit("").alias("fsa_ind"),
    lit("").alias("cashier_nbr"),
    lit("").alias("create_id"),
    lit("").alias('cashier_employee_id'),
    lit("").alias("mgr_employee_id"),
    lit("").alias("loyalty_employee_id"),
    lit("").alias("exchange_cd"),
    lit("").alias('offline_txn_ind'),
    lit("").alias("price_verify_cd"),
    lit("").alias("register_nbr"),
    lit("").alias('rfn_value'),
    "next_gen_rfn_value",
    lit("").alias("training_txn_ind"),
    lit("").alias("txn_incomplete_ind"),
    lit("").alias("txn_nbr"),
    lit("").alias("txn_start_dttm"),
    lit("").alias("txn_tot_discnt_line_cnt"),
    lit("").alias("txn_tot_discnt_line_qty"),
    lit("").alias("txn_tot_discnt_return_dlrs"),
    lit("").alias("txn_tot_discnt_sale_dlrs"),
    lit("").alias("txn_tot_dlrs"),
    lit("").alias("txn_tot_line_cnt"),
    lit("").alias("txn_tot_line_voided_cnt"),
    lit("").alias("txn_tot_line_voids_cnt"),
    lit("").alias("txn_tot_mfg_coup_dlrs"),
    lit("").alias("txn_tot_net_qty"),
    lit("").alias("txn_tot_price_vrfy_line_cnt"),
    lit("").alias("txn_tot_reg_line_cnt"),
    lit("").alias("txn_tot_reg_line_qty"),
    lit("").alias("txn_tot_reg_return_dlrs"),
    lit("").alias("txn_tot_reg_sale_dlrs"),
    lit("").alias("txn_tot_return_dlrs"),
    lit("").alias("txn_tot_return_line_cnt"),
    lit("").alias("txn_tot_rx_line_cnt"),
    lit("").alias("txn_tot_tax_dlrs"),
    lit("").alias("txn_tot_tndr_cnt"),
    lit("").alias("txn_tot_tndr_dlrs"),
    lit("").alias("txn_tot_void_dlrs"),
    lit("").alias("txn_tot_wag_coup_dlrs"),
    lit("").alias('discnt_mode_cd'),
    lit("").alias("affiliate_discnt_cd"),
    lit("").alias("post_void_status_cd"),
    lit("").alias("return_reason_cd"),
    lit("").alias("return_auth_nbr"),
    lit("").alias('vndr_refund_id'),
    lit("").alias("shipping_price_discnt_dlrs"),
    lit("").alias("suggest_tax_return_dlrs"),
    lit("").alias("actl_tax_return_dlrs"),
    lit("").alias("suggest_ship_return_dlrs"),
    lit("").alias("actl_ship_return_dlrs"),
    lit("").alias("paypal_return_dlrs"),
    lit("").alias("authenticator_id"),
    lit("").alias("credit_card_return_dlrs"),
    lit("").alias("gift_card_return_dlrs"),
    lit("").alias("loyalty_enrl_ind"),
    lit("").alias("aarp_opt_out_ind"),
    "identification_method",
    lit("").alias("price_button_evt_ind"),
    lit("").alias("emp_discnt_button_use"),
    lit("").alias("loyalty_card_scan_ind"),
    lit("").alias("store_emp_loyalty_acct_ind"),
    lit("").alias("onscreen_redeem_button_use"),
    lit("").alias("bounty_super_refund_cd"),
    lit("").alias("void_type_cd"),
    lit("").alias("void_reason_cd"),
    lit("").alias("emv_stat_cd"),
    lit("").alias("pinpad_stat_cd"))
df4 = df4.sort("sales_txn_id", "wag_cardNumber")
#display(df4)

# COMMAND ----------

#Joining File1 and File2

df_j1 = df2.join(df1, df2.txn_id==df1.txn_id, "inner")
df_j1 = df_j1. select(
         df2.sales_txn_id,
    df2.sales_txn_dt,
     df2.sales_ord_src_type,
     df2.sales_txn_type,
     df2.src_sys_cd,
    lit("AARPTXN").alias("prog_type_cd"),
     df1.aarp_card_hldr_nbr.alias("prog_acct_nbr"),
     lit("").alias("prog_cust_id"),
     lit("").alias("entry_mode_cd")
    
        )
#display(df_j1)


# COMMAND ----------

#Rows filtered out in Join condition from both DF1 and DF2 dataframe

dfr1 = df1.join(df2, on='txn_id', how='left_anti')
dfr1.write.mode('overwrite').parquet(REJ_FILEPATH1)

dfr2 = df2.join(df1, on='txn_id', how='left_anti')
dfr1.write.mode('overwrite').parquet(REJ_FILEPATH2)
#display(dfr2)

# COMMAND ----------

df_j2 = df2.join(df3, df2.sales_txn_id==df3.sales_txn_id, "inner")

df_j2 = df_j2.select (
        df2.sales_txn_id,
        df2.sales_txn_dt,
        df2.sales_ord_src_type,
        df2.sales_txn_type,
        df2.src_sys_cd,
        df3.prog_type_cd,
        df3.prog_acct_nbr,
        df3.prog_cust_id,
        lit("").alias("entry_mode_cd")
   )


#display(df_j2)

# COMMAND ----------

#Union of Join1 and Join2

Union_J1_J2 = df_j1.union(df_j2)
Union_J1_J2 = Union_J1_J2.sort("sales_txn_id", "prog_acct_nbr")
Union_J1_J2_filter = Union_J1_J2.filter( ((Union_J1_J2.prog_acct_nbr.isNull()) | (trim(Union_J1_J2.prog_cust_id)=='')) | (((Union_J1_J2.prog_cust_id.isNull()) | (trim(Union_J1_J2.prog_cust_id)=='')) & (Union_J1_J2.prog_type_cd=='AARPTXN')))
#display(Union_J1_J2)
#Union_J1_J2_filter.count()
Union_J1_J2_filter_minus=Union_J1_J2.exceptAll(Union_J1_J2_filter)

#Union_J1_J2_filter_minus.count()


# COMMAND ----------

#Removing duplicates on sales_txn_id column from dataframe df4

df_rm_dp1 = df4.dropDuplicates(["sales_txn_id"])
#display(df_rm_dp1)

#Removing duplicates on sales_txn_id; wag_cardNumber columsn from dataframe df4
df_rm_dp2 = df4.dropDuplicates(["sales_txn_id", "wag_cardNumber"])
#display(df_rm_dp2)



# COMMAND ----------

#Joining Union_J1_J2 and df_rm_dp1 dataframe on sales_txn_id
Join_result1 = Union_J1_J2_filter.join(df_rm_dp1, trim(Union_J1_J2_filter.sales_txn_id)==trim(df_rm_dp1.sales_txn_id), 'leftouter' )
Join_result1 = Join_result1.withColumn("entry_mode_cd1", df_rm_dp1.identification_method)
Join_result1 = Join_result1.select(
                    Union_J1_J2_filter.sales_txn_id,
                    Union_J1_J2_filter.sales_txn_dt,
                    Union_J1_J2_filter.sales_ord_src_type,
                    Union_J1_J2_filter.sales_txn_type,
                    Union_J1_J2_filter.src_sys_cd,
                    Union_J1_J2_filter.prog_type_cd,
                    Union_J1_J2_filter.prog_acct_nbr,
                    Union_J1_J2_filter.prog_cust_id,
                    Join_result1.entry_mode_cd1.alias("entry_mode_cd")
                    )

# COMMAND ----------


#Joining Union_J1_J2 and df_rm_dp2 dataframes on {sales_txn_id; prog_acct_nbr}
#Column prog_acct_nbr is not present in df_rm_dp2 dataframe but Abinitio is joining two result with this column

#Join_result1 = Union_J1_J2.join(df_rm_dp2, (Union_J1_J2.sales_txn_id==df_rm_dp2.sales_txn_id) & (Union_J1_J2.prog_acct_nbr==df_rm_dp2.prog_acct_nbr), 'inner' )
Join_result2 = Union_J1_J2_filter_minus.join(df_rm_dp2, (Union_J1_J2_filter_minus.sales_txn_id==df_rm_dp2.sales_txn_id) & (Union_J1_J2_filter_minus.prog_acct_nbr==df_rm_dp2.wag_cardNumber), 'leftouter' )
#Join_result2 = Union_J1_J2.join(df_rm_dp2, (Union_J1_J2.sales_txn_id==df_rm_dp2.sales_txn_id),  'inner' )
Join_result2 = Join_result2.withColumn("entry_mode_cd1", df_rm_dp2.identification_method)
Join_result2 = Join_result2.select(
                    Union_J1_J2_filter_minus.sales_txn_id,
                    Union_J1_J2_filter_minus.sales_txn_dt,
                    Union_J1_J2_filter_minus.sales_ord_src_type,
                    Union_J1_J2_filter_minus.sales_txn_type,
                    Union_J1_J2_filter_minus.src_sys_cd,
                    Union_J1_J2_filter_minus.prog_type_cd,
                    Union_J1_J2_filter_minus.prog_acct_nbr,
                    Union_J1_J2_filter_minus.prog_cust_id,
                    Join_result2.entry_mode_cd1.alias("entry_mode_cd")
                    )
#display(Join_result2)


# COMMAND ----------

#Union both Join_result1 and Join_result2 dataframes

un_res1_res2 = Join_result1.union(Join_result2)
display(un_res1_res2)
#Creating a Sales Transaction Program LDR file
un_res1_res2.write.mode('overwrite').parquet(var_Parquet_File_Path)


# COMMAND ----------

# DBTITLE 1,Multi Row Delimited ==> Parquet
# """ Convert to parquet"""
#    Handling NUL delimiter since it cannot be typed/copied in the browser
# if var_Delimiter == 'Default_Nul_character':
#     df = spark.read.format("csv").option("delimiter", "\x00").option("inferSchema","true").schema(var_Output_Schema).load(var_Converted_File)
# else:
#     df = spark.read.format("csv").option("delimiter", var_Delimiter).option("inferSchema","true").schema(var_Output_Schema).load(var_Converted_File)

# df.write.format("parquet").mode("overwrite").save(var_Parquet_File_Path)
# print("Parquet file:", var_Parquet_File_Path)
# df.count() 

# COMMAND ----------

# df = spark.read.parquet(var_Parquet_File_Path)
# print("Parquet file:", var_Parquet_File_Path)
# df.take(3)
# df.printSchema()

# COMMAND ----------


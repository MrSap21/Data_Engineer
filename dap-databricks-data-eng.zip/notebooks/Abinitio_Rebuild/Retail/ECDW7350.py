# Databricks notebook source
#Widgets for passing required parameters values

#dbutils.widgets.text("PAR_DIM_PRODUCT_BATCH_ID","batch_id_lkp")
#dbutils.widgets.text("PAR_WCARD_ITEM_FSA_Table","wcard_item_fsa")
#dbutils.widgets.text("PAR_WCARD_WAG_BRAND","wcard_wag_brand")
#dbutils.widgets.text("PAR_WCARD_EPOS","wcard_epos")
#dbutils.widgets.text("PAR_WCARD_ITEM_CATEGORY_TYPE","wcard_item_category_type")
#dbutils.widgets.text("PAR_WCARD_ITEM_EPOS_TYPE","wcard_item_epos_type")
#dbutils.widgets.text("PAR_WCARD_SALES_CATEGORY","wcard_sales_category")
# dbutils.widgets.text("PAR_INPUT_FILE_NAME","mn872p20220331_20220401012519.dat")
# dbutils.widgets.text("PAR_INPUT_FILE_PATH","master_data/product/adr7/2022/05/09/")


# COMMAND ----------

#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Dim_Product_Batch_Id = dbutils.widgets.get("PAR_DIM_PRODUCT_BATCH_ID")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
PscSrcRej_File = dbutils.widgets.get("PAR_PSC_SRCREJ_FILE")
Input_File_Dim_Product = dbutils.widgets.get("PAR_INPUT_DIM_PRODUCT_FILE")
Wcard_FSA_file = dbutils.widgets.get("PAR_WCARD_ITEM_FSA_Table")
Wcard_Wag_Brand = dbutils.widgets.get("PAR_WCARD_WAG_BRAND")
Wcard_epos = dbutils.widgets.get("PAR_WCARD_EPOS")
Wcard_Item_Category_type = dbutils.widgets.get("PAR_WCARD_ITEM_CATEGORY_TYPE")
wcard_item_Epos_type = dbutils.widgets.get("PAR_WCARD_ITEM_EPOS_TYPE")
wcard_sales_category = dbutils.widgets.get("PAR_WCARD_SALES_CATEGORY")
input_file_mn872p = dbutils.widgets.get("PAR_INPUT_FILE_NAME")
input_file_path = dbutils.widgets.get("PAR_INPUT_FILE_PATH")


# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

#Reading file for the readList path
mn872pSrcDF = spark.read.format("text").load(mountPoint+"/"+input_file_path+"/"+input_file_mn872p)
mn872pSrcDF1=mn872pSrcDF.withColumn("item_number",substring(mn872pSrcDF.value,1,6)) \
.withColumn("product_identifier",substring(mn872pSrcDF.value,7,14)) \
.withColumn("item_description",substring(mn872pSrcDF.value,21,50)) \
.withColumn("store_dept_number",substring(mn872pSrcDF.value,71,3)) \
.withColumn("retail_mult_alpha",substring(mn872pSrcDF.value,74,2)) \
.withColumn("retail_price_alpha",substring(mn872pSrcDF.value,76,7)) \
.withColumn("retail_sur_alpha",substring(mn872pSrcDF.value,83,7)) \
.withColumn("walg_item_indicator",substring(mn872pSrcDF.value,90,1)) \
.withColumn("item_service_type",substring(mn872pSrcDF.value,91,2)) \
.withColumn("flexible_spending_account",substring(mn872pSrcDF.value,93,1)) \
.withColumn("wcard_profile_mask",substring(mn872pSrcDF.value,94,10)) \
.withColumn("product_category_code",substring(mn872pSrcDF.value,104,3)) \
.withColumn("product_category_desc",substring(mn872pSrcDF.value,107,30)) \
.withColumn("sales_category_code",substring(mn872pSrcDF.value,137,3)) \
.withColumn("store_dept_description",expr("""substring(value,140,length(value))"""))

# display(mn872pSrcDF)
#display(mn872pSrcDF1)

mn872pSrcDFNew = mn872pSrcDF1.drop(mn872pSrcDF1.value)
display(mn872pSrcDFNew)

# COMMAND ----------

DimProductDFNew=spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+Input_File_Dim_Product+"/"+Batch_id)
display(DimProductDFNew)


# COMMAND ----------

#Reformat product_identifier and item_number
#RFT:Convert Product Identifier to decimal
RFT_Convert_DF = mn872pSrcDFNew.withColumn("product_identifier",ltrim(mn872pSrcDFNew.product_identifier)) \
.withColumn("item_number",ltrim(mn872pSrcDFNew.item_number))
# display(RFT_Convert_DF)

# COMMAND ----------

#Sort on product_identifier and item_number and Dedup Sorted product_identifier and item_number:
#Dedup Sorted
Dedup_Sorted_DF = RFT_Convert_DF.select("*", row_number().over(Window.partitionBy("product_identifier","item_number").orderBy("product_identifier","item_number")).alias("row_num")) 
Dedup_Sorted1_DF = Dedup_Sorted_DF.filter(Dedup_Sorted_DF.row_num ==1).drop("row_num")
# display(Dedup_Sorted1_DF)

# COMMAND ----------

#Join On dedup sorted and dim product source file:
JoinOrigDF = DimProductDFNew.join(Dedup_Sorted1_DF,
on=[DimProductDFNew.upc_nbr==Dedup_Sorted1_DF.product_identifier,
DimProductDFNew.wic_nbr==Dedup_Sorted1_DF.item_number], how='inner')
# display(JoinOrigDF)

JoinOrigDF1 = JoinOrigDF.withColumn("upc_nbr",DimProductDFNew.upc_nbr) \
.withColumn("prod_id",DimProductDFNew.prod_id) \
.withColumn("prod_desc", DimProductDFNew.prod_desc) \
.withColumn("ops_dept_nbr",DimProductDFNew.ops_dept_nbr) \
.withColumn("item_number", Dedup_Sorted1_DF.item_number) \
.withColumn("product_identifier",Dedup_Sorted1_DF.product_identifier) \
.withColumn("item_description",Dedup_Sorted1_DF.item_description) \
.withColumn("store_dept_number",Dedup_Sorted1_DF.store_dept_number) \
.withColumn("walg_item_indicator",Dedup_Sorted1_DF.walg_item_indicator) \
.withColumn("item_service_type",Dedup_Sorted1_DF.item_service_type) \
.withColumn("flexible_spending_account",Dedup_Sorted1_DF.flexible_spending_account) \
.withColumn("wcard_profile_mask",Dedup_Sorted1_DF.wcard_profile_mask) \
.withColumn("product_category_code",Dedup_Sorted1_DF.product_category_code) \
.withColumn("product_category_desc",Dedup_Sorted1_DF.product_category_desc) \
.withColumn("sales_category_code",Dedup_Sorted1_DF.sales_category_code) \
.withColumn("store_dept_description",Dedup_Sorted1_DF.store_dept_description)

# display(JoinOrigDF1)


# COMMAND ----------

EFF_DT_DF = Batch_id[:4]+"-"+Batch_id[4:6]+"-"+Batch_id[6:8]
print(EFF_DT_DF)

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------


ItemFSALoadDF = JoinOrigDF1.withColumn("fsa_eff_dt",lit(EFF_DT_DF)) \
.withColumn("fsa_ind",JoinOrigDF1.flexible_spending_account) \
.withColumn("fsa_end_dt",lit(None)) \
.withColumn("prod_id",JoinOrigDF1.prod_id).select("prod_id","fsa_eff_dt","fsa_ind","fsa_end_dt")
# display(ItemFSALoadDF)
ItemFSALoadDF = WriteNullParquet(ItemFSALoadDF)
ItemFSALoadDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+"Wcard_FSA_file"+"/"+Batch_id)
print(mountPoint+"/"+Staging_Folder+"/"+"Wcard_FSA_file"+"/"+Batch_id)


# COMMAND ----------

#RFT: Convert data to WAG Brand Table
WagBrandTableDF = JoinOrigDF1.withColumn("wag_brand_eff_dt",lit(EFF_DT_DF)) \
.withColumn("wag_brnd_ind",JoinOrigDF1.walg_item_indicator)\
.withColumn("item_svc_type",JoinOrigDF1.item_service_type)\
.withColumn("wag_brand_end_dt",lit(None))\
.withColumn("prod_id",JoinOrigDF1.prod_id).select("prod_id","wag_brnd_ind","wag_brand_eff_dt","wag_brand_end_dt","item_svc_type")
# display(WagBrandTableDF)
WagBrandTableDF = WriteNullParquet(WagBrandTableDF)

WagBrandTableDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+"Wcard_Wag_Brand"+"/"+Batch_id)

# COMMAND ----------

WagEposDF = JoinOrigDF1.withColumn("item_epos_catg_eff_dt",lit(EFF_DT_DF)) \
.withColumn("item_catg_cd",when(((JoinOrigDF1.product_category_code.isNotNull()) & (JoinOrigDF1.product_category_code!="")),JoinOrigDF1.product_category_code).otherwise(lit(" ")))\
.withColumn("item_epos_cd",JoinOrigDF1.store_dept_number)\
.withColumn("sales_catg_cd",JoinOrigDF1.sales_category_code)\
.withColumn("item_epos_catg_end_dt",lit(None))\
.withColumn("prod_id",JoinOrigDF1.prod_id).select("prod_id","item_epos_cd","item_catg_cd","item_epos_catg_eff_dt","item_epos_catg_end_dt","sales_catg_cd")
# display(WagEposDF)
WagEposDF = WriteNullParquet(WagEposDF)

WagBrandTableDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+"Wcard_epos"+"/"+Batch_id)

# COMMAND ----------

WagItemCatTypeDF = JoinOrigDF1.withColumn("item_catg_cd",JoinOrigDF1.product_category_code)\
.withColumn("item_catg_cd_desc",JoinOrigDF1.product_category_desc)\
.withColumn("item_epos_cd",JoinOrigDF1.store_dept_number).select("item_catg_cd","item_catg_cd_desc","item_epos_cd")
# display(WagItemCatTypeDF)
WagItemCatTypeDF = WriteNullParquet(WagItemCatTypeDF)
WagItemCatTypeDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+"Wcard_Item_Category_type"+"/"+Batch_id)

# COMMAND ----------

WagItemEposTypeDF = JoinOrigDF1.withColumn("item_epos_cd",JoinOrigDF1.store_dept_number)\
.withColumn("item_catg_cd",lit(None))\
.withColumn("item_catg_cd_desc",lit(None))\
.withColumn("item_epos_cd_desc",JoinOrigDF1.store_dept_description).select("item_catg_cd","item_catg_cd_desc")
# display(WagItemEposTypeDF)
WagItemEposTypeDF = WriteNullParquet(WagItemEposTypeDF)
WagItemEposTypeDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+"wcard_item_Epos_type"+"/"+Batch_id)

# COMMAND ----------

#Rollup-2

Roll_up_DF = JoinOrigDF1.withColumn("sales_catg_desc",when((trim(JoinOrigDF1.sales_category_code)=="CIG"),lit("CIGARETTE"))) \
.withColumn("sales_catg_desc",when((trim(JoinOrigDF1.sales_category_code)=="EXP"),lit("EXPENSE"))) \
.withColumn("sales_catg_desc",when((trim(JoinOrigDF1.sales_category_code)=="LIQ"),lit("ALCOHOL"))) \
.withColumn("sales_catg_desc",when((trim(JoinOrigDF1.sales_category_code)=="RX"),lit("PRESCRIPTION"))) \
.withColumn("sales_catg_desc",when((trim(JoinOrigDF1.sales_category_code)=="SS"),lit("RETAIL")).otherwise(lit("UNKNOWN"))) \
.withColumn("sales_catg_cd",JoinOrigDF1.sales_category_code)

Roll_UP_Select_DF = Roll_up_DF.select("sales_catg_desc","sales_catg_cd")
# display(Roll_UP_Select_DF)



# COMMAND ----------

#Dedup on sales_catg_cd :
DedupSortDF = Roll_UP_Select_DF.select("*", row_number().over(Window.partitionBy("sales_catg_cd").orderBy(Roll_UP_Select_DF['sales_catg_cd'])).alias("row_num")) 
DedupSortHolder = DedupSortDF.filter(DedupSortDF.row_num ==1).drop("row_num").select ("sales_catg_cd","sales_catg_desc")

DedupSortHolder.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+"wcard_sales_category"+"/"+Batch_id)

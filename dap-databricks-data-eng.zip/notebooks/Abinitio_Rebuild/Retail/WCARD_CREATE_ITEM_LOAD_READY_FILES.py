# Databricks notebook source
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
mountPoint = "/mnt/WCARD_CREATE_ITEM_LOAD_READY_FILES"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

# INF:  ADR4 Item data-1

from pyspark.sql.functions import *

dfADR4Raw = spark.read.text(mountPoint + dbutils.widgets.get('ADR4_INPUT_DATA'))

dfADR4 = dfADR4Raw.select(trim(dfADR4Raw.value.substr(1, 6)).alias("item_number"),\
                          trim(dfADR4Raw.value.substr(7, 14)).alias("product_identifier"),\
                          trim(dfADR4Raw.value.substr(21, 50)).alias("item_description"),\
                          trim(dfADR4Raw.value.substr(71, 3)).alias("store_dept_number"),\
                          trim(dfADR4Raw.value.substr(74, 2)).alias("retail_mult_alpha"),\
                          trim(dfADR4Raw.value.substr(76, 7)).alias("retail_price_alpha"),\
                          trim(dfADR4Raw.value.substr(83, 7)).alias("retail_sur_alpha"),\
                          trim(dfADR4Raw.value.substr(90, 1)).alias("walg_item_indicator"),\
                          trim(dfADR4Raw.value.substr(91, 2)).alias("item_service_type"),\
                          trim(dfADR4Raw.value.substr(93, 1)).alias("flexible_spending_account"),\
                          trim(dfADR4Raw.value.substr(94, 10)).alias("wcard_profile_mask"),\
                          trim(dfADR4Raw.value.substr(104, 3)).alias("product_category_code"),\
                          trim(dfADR4Raw.value.substr(107, 30)).alias("product_category_desc"),\
                          trim(dfADR4Raw.value.substr(137, 3)).alias("sales_category_code"),\
                          trim(dfADR4Raw.value.substr(140, 50)).alias("store_dept_description"))

dfADR4 = dfADR4.groupBy("product_identifier", "item_number").agg(max(col("item_description")).alias("item_description"),\
                                                                 max(col("store_dept_number")).alias("store_dept_number"),\
                                                                 max(col("retail_mult_alpha")).alias("retail_mult_alpha"),\
                                                                 max(col("retail_price_alpha")).alias("retail_price_alpha"),\
                                                                 max(col("retail_sur_alpha")).alias("retail_sur_alpha"),\
                                                                 max(col("walg_item_indicator")).alias("walg_item_indicator"),\
                                                                 max(col("item_service_type")).alias("item_service_type"),\
                                                                 max(col("flexible_spending_account")).alias("flexible_spending_account"),\
                                                                 max(col("wcard_profile_mask")).alias("wcard_profile_mask"),\
                                                                 max(col("product_category_code")).alias("product_category_code"),\
                                                                 max(col("product_category_desc")).alias("product_category_desc"),\
                                                                 max(col("sales_category_code")).alias("sales_category_code"),\
                                                                 max(col("store_dept_description")).alias("store_dept_description"))

#display(dfADR4)

# COMMAND ----------

# INF: DIM Product Load Ready File

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("prod_id", StringType(), False),
    StructField("upc_nbr", StringType(), False),
    StructField("prod_desc", StringType(), False),
    StructField("wic_nbr", StringType(), False),
    StructField("retail_price30_dlrs", StringType(), False),
    StructField("prod_level_name", StringType(), False),
    StructField("ops_dept_nbr", StringType(), False)
  ])
)

dfProductLoadReadyFile = spark.read.format("csv").options(header='false', delimiter = '|').schema(inputSchema).load(mountPoint + dbutils.widgets.get('LOAD_READY_PROD'))

#display(dfProductLoadReadyFile)

# COMMAND ----------

# Join

dfADR4 = dfADR4.alias("t1").join(dfProductLoadReadyFile.alias("t2"), (col("t1.product_identifier") == col("t2.upc_nbr")) & (col("t1.item_number") == col("t2.wic_nbr")), how = "inner").select(col("t2.upc_nbr"), col("t2.prod_id"), col("t2.prod_desc"), col("t2.ops_dept_nbr"), col("t1.item_number"), col("t1.product_identifier"), col("t1.item_description"), col("t1.store_dept_number"), col("t1.walg_item_indicator"), col("t1.item_service_type"), col("t1.flexible_spending_account"), col("t1.wcard_profile_mask"), col("t1.product_category_code"), col("t1.product_category_desc"), col("t1.sales_category_code"), col("t1.store_dept_description"))

#display(dfADR4)

# COMMAND ----------

# Reformat and Normalize profile mask

from pyspark.sql.window import Window

dfItemProfileLoadReady = dfADR4.select(col("prod_id").alias("product_identifier"), col("wcard_profile_mask").cast(IntegerType()).alias("wcard_profile_mask"), col("store_dept_number").alias("store_dept_number"))

Convert32Bit = udf(lambda z: "{:032b}".format(z), StringType())

def ConvertArray(x):
    res = []
    for x_ in x:
        res.append(x_)
    return res

ConvertArrayUDF = udf(ConvertArray, ArrayType(StringType()))
  
dfItemProfileLoadReady = dfItemProfileLoadReady.withColumn("profile_number", explode(ConvertArrayUDF(Convert32Bit(dfItemProfileLoadReady.wcard_profile_mask))))
dfItemProfileLoadReady = dfItemProfileLoadReady.withColumn("profile_mask", when(col("profile_number") == 0, "N").otherwise("Y"))
dfItemProfileLoadReady = dfItemProfileLoadReady.withColumn("profile_number", row_number().over(Window.partitionBy(dfItemProfileLoadReady['product_identifier']).orderBy(dfItemProfileLoadReady['product_identifier'])))


#display(dfItemProfileLoadReady)

# COMMAND ----------

# Loading Item Profile Exception List

inputSchema = (
  StructType([
    StructField("profile_number", StringType(), False),
    StructField("item_department_number", StringType(), False)
  ])
)

dfProfileExceptionList = spark.read.format("csv").options(header='false', delimiter = '|').schema(inputSchema).load(mountPoint + dbutils.widgets.get('AI_PERSIST_SERIAL') + "/wcard_profile_exception_list_ascii.pipe_delim_lkp")

#display(dfProfileExceptionList)

# COMMAND ----------

# RFT: Convert profiles 27 thru 32 for exception list

dfItemProfileLoadReadyFinal = dfItemProfileLoadReady.alias("t1").join(dfProfileExceptionList.alias("t2"), (col("t1.profile_number") == col("t2.profile_number")), how = "left").select(col("t1.product_identifier"), col("t1.wcard_profile_mask"), col("t1.store_dept_number"), col("t1.profile_mask"), col("t1.profile_number"), col("t2.item_department_number"))

dfItemProfileLoadReadyFinal = dfItemProfileLoadReadyFinal.withColumn("profile_mask", when(((col("profile_number") == 26) | (col("profile_number") == 27) | (col("profile_number") == 28) | (col("profile_number") == 29) | (col("profile_number") == 30) | (col("profile_number") == 31) | (col("profile_number") == 32)), "Y").otherwise(col("profile_mask")))

dfItemProfileLoadReadyFinal = dfItemProfileLoadReadyFinal.withColumn("profile_mask", when(((col("profile_number") == 27) | (col("profile_number") == 31)) & (col("item_department_number").isNull()), "Y").otherwise(col("profile_mask")))

dfItemProfileLoadReadyFinal = dfItemProfileLoadReadyFinal.withColumn("profile_mask", when(((col("profile_number") == 27) | (col("profile_number") == 31)) &  (col("item_department_number").isNotNull()), "N").otherwise(col("profile_mask")))

dfItemProfileLoadReadyFinal = dfItemProfileLoadReadyFinal\
                              .filter(col("profile_mask") == "Y")\
                              .withColumn("item_profile_eff_dt", lit(dbutils.widgets.get('ADR4_EFF_DT')))\
                              .withColumn("item_profile_end_dt", lit(""))\
                              .select(col("profile_number").alias("profile_id"), col("item_profile_eff_dt"), col("item_profile_end_dt"), col("product_identifier").alias("prod_id"))

#display(dfItemProfileLoadReadyFinal)

# COMMAND ----------

# RFT: Convert data to FSA Table

dfItemFSALoadReady = dfADR4\
                    .withColumn("fsa_eff_dt", lit(dbutils.widgets.get('ADR4_EFF_DT')))\
                    .withColumn("fsa_end_dt", lit(""))\
                    .select(col("prod_id"), col("fsa_eff_dt"), col("flexible_spending_account").alias("fsa_ind"), col("fsa_end_dt"))     
                                
display(dfItemFSALoadReady)              

# COMMAND ----------

# RFT: Convert data to WAG Brand Table

dfItemWalgreensBrandLoadReady = dfADR4\
                    .withColumn("wag_brand_eff_dt", lit(dbutils.widgets.get('ADR4_EFF_DT')))\
                    .withColumn("wag_brand_end_dt", lit(""))\
                    .select(col("prod_id"), col("walg_item_indicator").alias("wag_brnd_ind"),  col("wag_brand_eff_dt"),  col("wag_brand_end_dt"), col("item_service_type").alias("item_svc_type"))     
                                
#display(dfItemWalgreensBrandLoadReady)  

# COMMAND ----------

# RFT: Convert data to EPOS Table

dfItemEPOSCategoryLoadReady = dfADR4\
                    .withColumn("item_epos_catg_eff_dt", lit(dbutils.widgets.get('ADR4_EFF_DT')))\
                    .withColumn("item_catg_cd", when(col("product_category_code").isNotNull(), col("product_category_code")).otherwise(lit("")))\
                    .withColumn("item_epos_cd", when(col("store_dept_number").isNotNull(), col("store_dept_number")).otherwise(lit("")))\
                    .withColumn("sales_catg_cd", col("sales_category_code"))\
                    .withColumn("item_epos_catg_end_dt", lit(""))\
                    .select(col("prod_id"), col("item_epos_cd"), col("item_catg_cd"), col("item_epos_catg_eff_dt"), col("item_epos_catg_end_dt"), col("sales_catg_cd"))     
                                
#display(dfItemEPOSCategoryLoadReady)

# COMMAND ----------

# RFT: Convert data to Catg Type Table

dfItemCatgTypeLoadReady = dfADR4\
                          .withColumn("item_catg_cd", when(col("product_category_code").isNotNull(), col("product_category_code")).otherwise(lit("")))\
                          .withColumn("item_catg_cd_desc", col("product_category_desc"))\
                          .withColumn("item_epos_cd", when(col("store_dept_number").isNotNull(), col("store_dept_number")).otherwise(lit("")))\
                          .select(col("item_catg_cd"), col("item_catg_cd_desc"), col("item_epos_cd"))     
                                
dfItemCatgTypeLoadReady = dfItemCatgTypeLoadReady.groupBy("item_catg_cd", "item_catg_cd_desc").agg(max(col("item_epos_cd")).alias("item_epos_cd"))
  
#display(dfItemCatgTypeLoadReady)

# COMMAND ----------

# RFT: Convert data to EPOS Table Table

dfItemEPOSTypeLoadReady = dfADR4\
                          .withColumn("item_epos_cd", when(col("store_dept_number").isNotNull(), col("store_dept_number")).otherwise(lit("")))\
                          .withColumn("item_epos_cd_desc", col("store_dept_description"))\
                          .select(col("item_epos_cd"), col("item_epos_cd_desc"))     
                                
dfItemEPOSTypeLoadReady = dfItemEPOSTypeLoadReady.groupBy("item_epos_cd").agg(max(col("item_epos_cd_desc")).alias("item_epos_cd_desc"))
  
#display(dfItemEPOSTypeLoadReady)

# COMMAND ----------

# OUF: wcard_sales_category

def DefineCategoryCode(x):
  if x == "CIG":
    return "CIGARETTE"
  elif x == "EXP":
    return "EXPENSE"
  elif x == "LIQ":
    return "ALCOHOL"
  elif x == "RX":
    return "PRESCRIPTION"
  elif x == "SS":
    return "RETAIL"
  else:
    return "UNKNOWN"

DefineCategoryCodeUDF = udf(DefineCategoryCode, StringType())

dfIWCardSalesCategoryLoadReady = dfADR4\
                                .withColumn("sales_catg_desc", DefineCategoryCodeUDF(trim(col("sales_category_code"))))\
                                .withColumn("sales_catg_cd", col("sales_category_code"))\
                                .select(col("sales_catg_cd"), col("sales_catg_desc"))     
                                
dfIWCardSalesCategoryLoadReady = dfIWCardSalesCategoryLoadReady.groupBy("sales_catg_cd").agg(max(col("sales_catg_desc")).alias("sales_catg_desc"))
  
#display(dfIWCardSalesCategoryLoadReady)

# COMMAND ----------

# Write output files

item_profile_load_ready_output_path = "{0}/{1}/wcard_item_profile.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))
item_FSA_load_ready_output_path = "{0}/{1}/wcard_item_fsa.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))
item_Walgreen_Brand_load_ready_output_path = "{0}/{1}/wcard_wag_brand.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))
item_EPOS_Category_load_ready_output_path = "{0}/{1}/wcard_epos.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))
item_Catg_Type_load_ready_output_path = "{0}/{1}/wcard_item_category_type.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))
item_EPOS_Type_load_ready_output_path = "{0}/{1}/wcard_item_epos_type.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))
wcard_sales_category_output_path = "{0}/{1}/wcard_sales_category.dat".format(mountPoint, dbutils.widgets.get('AI_LOAD'))

dfItemProfileLoadReadyFinal.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(item_profile_load_ready_output_path)
dfItemFSALoadReady.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(item_FSA_load_ready_output_path)
dfItemWalgreensBrandLoadReady.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(item_Walgreen_Brand_load_ready_output_path)
dfItemEPOSCategoryLoadReady.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(item_EPOS_Category_load_ready_output_path)
dfItemCatgTypeLoadReady.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(item_Catg_Type_load_ready_output_path)
dfItemEPOSTypeLoadReady.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(item_EPOS_Type_load_ready_output_path)
dfIWCardSalesCategoryLoadReady.coalesce(1).write.options(header='false', delimiter = '|').format("csv").mode("overwrite").save(wcard_sales_category_output_path)


# Renaming output and adding the correct extention

csv_file_output1 = [x.path for x in dbutils.fs.ls(item_profile_load_ready_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output1, item_profile_load_ready_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(item_profile_load_ready_output_path, recurse = True)

csv_file_output2 = [x.path for x in dbutils.fs.ls(item_FSA_load_ready_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output2, item_FSA_load_ready_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(item_FSA_load_ready_output_path, recurse = True)

csv_file_output3 = [x.path for x in dbutils.fs.ls(item_Walgreen_Brand_load_ready_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output3, item_Walgreen_Brand_load_ready_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(item_Walgreen_Brand_load_ready_output_path, recurse = True)

csv_file_output4 = [x.path for x in dbutils.fs.ls(item_EPOS_Category_load_ready_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output4, item_EPOS_Category_load_ready_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(item_EPOS_Category_load_ready_output_path, recurse = True)

csv_file_output5 = [x.path for x in dbutils.fs.ls(item_Catg_Type_load_ready_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output5, item_Catg_Type_load_ready_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(item_Catg_Type_load_ready_output_path, recurse = True)

csv_file_output6 = [x.path for x in dbutils.fs.ls(item_EPOS_Type_load_ready_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output6, item_EPOS_Type_load_ready_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(item_EPOS_Type_load_ready_output_path, recurse = True)

csv_file_output7 = [x.path for x in dbutils.fs.ls(wcard_sales_category_output_path) if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output7, wcard_sales_category_output_path.rstrip('/') + ".dat")
dbutils.fs.rm(wcard_sales_category_output_path, recurse = True)

# COMMAND ----------


# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("PAR_DB_SNW_TBL", 'SRC_POS_SALES_TXN_TENDER_NSF_STG')

# COMMAND ----------

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
IN_FILE = dbutils.widgets.get("PAR_DB_INPUT_FILE")
IN_FILE_PATH = dbutils.widgets.get("PAR_DB_INPUT_FILE_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNW_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNW_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNW_TBL")

IN_DATAFILE = mountPoint + '/'+ IN_FILE_PATH + '/'+ IN_FILE + '/'+ BATCH_ID
print(IN_DATAFILE)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

# COMMAND ----------

df1 = spark.read.parquet(IN_DATAFILE)
df1 = df1.filter(df1.nsf_dt.isNotNull())
#df1.count()
display(df1)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Deleting data from the Snowflakes table

del_snfl_tbl = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)
print(del_snfl_tbl)
#%run ../../Abinitio_Rebuild/Utilities/RunSnowSQL $query=del_snfl_tbl $transaction=True $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

df1.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()
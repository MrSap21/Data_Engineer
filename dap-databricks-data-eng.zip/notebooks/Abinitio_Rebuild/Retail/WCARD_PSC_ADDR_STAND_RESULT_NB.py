# Databricks notebook source
#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#Widgets for passing required parameters values

#dbutils.widgets.text("PAR_DB_BATCH_ID","20220516001005")
#dbutils.widgets.text("PAR_STAGING_PATH","retail/retail_sales/staging")
#dbutils.widgets.text("PAR_INPUT_FILE","wcard_psc_addr_stand_result")
#dbutils.widgets.text("PAR_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
#dbutils.widgets.text("PAR_SNFK_DB1","UAT_RETAIL")
#dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_PSC_ADDR_STAND_RESULT")
#dbutils.widgets.text("PAR_UPDATE_OUTPUT_FILE","wcard_psc_addr_stand_result_update_ascii.pipe_delim")
#dbutils.widgets.text("PAR_INSERT_OUTPUT_FILE","wcard_psc_addr_stand_result_insert_ascii.pipe_delim")

# COMMAND ----------

Batch_Id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Path = dbutils.widgets.get("PAR_STAGING_PATH")
Input_File = dbutils.widgets.get("PAR_INPUT_FILE")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
Update_Output_File = dbutils.widgets.get("PAR_UPDATE_OUTPUT_FILE")
Insert_Output_File = dbutils.widgets.get("PAR_INSERT_OUTPUT_FILE")

# COMMAND ----------

from pyspark.sql.functions import *
WcardStndResSrcDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Path+"/"+Input_File+"/"+Batch_Id)
#display(DF)
#print(DF.count())

#FBE:Only pass Valid Key:
FilterValidKeyDF = WcardStndResSrcDF.filter((WcardStndResSrcDF.card_hldr_id.isNotNull()) & (WcardStndResSrcDF.card_hldr_id!=""))

#RFT - col concat:
RfmtColConcatDF = FilterValidKeyDF.withColumn("compare_col_concatenated",concat(FilterValidKeyDF.card_hldr_id,FilterValidKeyDF.addr_type_cd,FilterValidKeyDF.addr_eff_dt,coalesce(trim(FilterValidKeyDF.addr_type_cd),lit("Test1")),coalesce(trim(FilterValidKeyDF.vld_addr_ind),lit("Test2")),coalesce(trim(FilterValidKeyDF.addr_stand_return_cd),lit("Test3"))))
#display(RfmtColConcatDF)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#wcard psc addr stand result:
import datetime

EFF_DT = Batch_Id[:8]
EFF_DT=datetime.datetime.strptime(EFF_DT,"%Y%m%d").date()-datetime.timedelta(1)
print(EFF_DT)

sel_wcard_psc_add_stnd_tbl = "Select * FROM {0} where addr_stand_end_dt is NULL and src_sys_cd=1".format(SNFL_TBL_NAME1)

wcardPscAddStnd_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB1) \
     .option("query",sel_wcard_psc_add_stnd_tbl) \
     .load()

#display(wcardPscAddStnd_tbl_df)
#print(wcardPscAddStnd_tbl_df.count())

#RFT - col concat-1:
RfmtColConcatDF1 = wcardPscAddStnd_tbl_df.withColumn("compare_col_concatenated",concat(wcardPscAddStnd_tbl_df.CARD_HLDR_ID,wcardPscAddStnd_tbl_df.ADDR_TYPE_CD,wcardPscAddStnd_tbl_df.ADDR_EFF_DT,coalesce(trim(wcardPscAddStnd_tbl_df.ADDR_TYPE_CD),lit("Test1")),coalesce(trim(wcardPscAddStnd_tbl_df.VLD_ADDR_IND),lit("Test2")),coalesce(trim(wcardPscAddStnd_tbl_df.ADDR_STAND_RETURN_CD),lit("Test3"))))

#display(RfmtColConcatDF1)

#Join-5:
JoinTableSrcFileDF = RfmtColConcatDF.join(RfmtColConcatDF1,RfmtColConcatDF.card_hldr_id==RfmtColConcatDF1.CARD_HLDR_ID,"inner")
JoinTableSrcFileDF1 = JoinTableSrcFileDF.withColumn("update_flag",when(((RfmtColConcatDF.addr_type_cd.isNotNull()) & (RfmtColConcatDF1.ADDR_TYPE_CD.isNotNull()) & (RfmtColConcatDF.addr_type_cd==RfmtColConcatDF1.ADDR_TYPE_CD)) & ((RfmtColConcatDF.vld_addr_ind.isNotNull()) & (RfmtColConcatDF1.VLD_ADDR_IND.isNotNull()) & (RfmtColConcatDF.vld_addr_ind==RfmtColConcatDF1.VLD_ADDR_IND)) & ((RfmtColConcatDF.addr_stand_return_cd.isNotNull()) & (RfmtColConcatDF1.ADDR_STAND_RETURN_CD.isNotNull()) & (RfmtColConcatDF.addr_stand_return_cd==RfmtColConcatDF1.ADDR_STAND_RETURN_CD)),lit("N")).when(((RfmtColConcatDF.addr_type_cd=="") & (RfmtColConcatDF1.ADDR_TYPE_CD=="") & (RfmtColConcatDF.vld_addr_ind=="") & (RfmtColConcatDF1.VLD_ADDR_IND=="") & (RfmtColConcatDF.addr_stand_return_cd=="") & (RfmtColConcatDF1.ADDR_STAND_RETURN_CD=="")) | ((RfmtColConcatDF.addr_type_cd.isNull()) & (RfmtColConcatDF1.ADDR_TYPE_CD.isNull()) & (RfmtColConcatDF.vld_addr_ind.isNull()) & (RfmtColConcatDF1.VLD_ADDR_IND.isNull()) & (RfmtColConcatDF.addr_stand_return_cd.isNull()) & (RfmtColConcatDF1.ADDR_STAND_RETURN_CD.isNull())),lit("N")).when(((RfmtColConcatDF.compare_col_concatenated.isNotNull()) & (RfmtColConcatDF1.compare_col_concatenated.isNotNull()) & (RfmtColConcatDF.compare_col_concatenated==RfmtColConcatDF1.compare_col_concatenated)),lit("N")).otherwise(lit("Y"))) \
.withColumn("addr_stand_end_dt1",lit(EFF_DT))

JoinTableSrcFileDF1 = JoinTableSrcFileDF1.select(RfmtColConcatDF.card_hldr_id,RfmtColConcatDF.src_sys_cd,RfmtColConcatDF.addr_type_cd,RfmtColConcatDF.addr_stand_return_cd,RfmtColConcatDF.addr_eff_dt,RfmtColConcatDF.create_dttm,RfmtColConcatDF.vld_addr_ind,RfmtColConcatDF.addr_stand_eff_dt,"addr_stand_end_dt1","update_flag").withColumnRenamed("addr_stand_end_dt1","addr_stand_end_dt")

#FBE:Only pass where update flag = "Y":
FilterUpdateFlagYDF = JoinTableSrcFileDF1.filter((JoinTableSrcFileDF1.update_flag=="Y") & ((JoinTableSrcFileDF1.card_hldr_id.isNotNull()) & (JoinTableSrcFileDF1.card_hldr_id!=""))).drop("update_flag")
#print(FilterUpdateFlagYDF.count())

#Wcard psc addr stand result Update File:
print("wcard_psc_addr_stand_result_update_ascii.pipe_delim Count:{}".format(FilterUpdateFlagYDF.count()))
FilterUpdateFlagYDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Path+"/"+Update_Output_File+"/"+Batch_Id)

# COMMAND ----------

# Join UnUsed0 Port - Left_anti_join:
JoinTableSrcFileUnUsed0DF = RfmtColConcatDF.join(RfmtColConcatDF1,RfmtColConcatDF.card_hldr_id==RfmtColConcatDF1.CARD_HLDR_ID,"left_anti").drop("compare_col_concatenated")
#display(JoinTableSrcFileUnUsed0DF)

#FBE:Only pass where card Holder Id is non blank:
FilterNonEmpCardId_DF = JoinTableSrcFileUnUsed0DF.filter((JoinTableSrcFileUnUsed0DF.card_hldr_id.isNotNull()) & (JoinTableSrcFileUnUsed0DF.card_hldr_id!=""))

#RFT: Create insert record for updated row:
createInsRecDF = FilterUpdateFlagYDF.withColumn("addr_stand_end_dt",lit(None))

#Gather:2 - FilterNonEmpCardId_DF and createInsRecDF union:
GatherInsFinal_DF = createInsRecDF.unionByName(FilterNonEmpCardId_DF)

#Wcard psc addr stand result Load File:
print("wcard_psc_addr_stand_result_insert_ascii.pipe_delim Count:{}".format(GatherInsFinal_DF.count()))
GatherInsFinal_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Path+"/"+Insert_Output_File+"/"+Batch_Id)

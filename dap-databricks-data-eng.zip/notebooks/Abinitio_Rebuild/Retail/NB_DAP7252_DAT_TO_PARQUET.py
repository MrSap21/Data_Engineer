# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove("PAR_DB_SNFK_WH")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME #+ '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
#REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/short_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'


#print (IN_DATAFILE)
print (OUT_FILEPATH)
print (REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

#Columns List for Schema

fieldList = [
'code_name',  
'code' ,
'code_desc' ,
'ej_code' ,
'ej_desc']


col_len = len(fieldList)
print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
# def addlistlength(lst) :
#   lst1 = list(lst)
#   if  len(lst1) > 6 and lst[6] == '"INSERT"':
#     lst1.insert(6, '"INSERT"')
#   list_len = len(lst1)
#   lst1.insert(0, list_len)
#   return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
# def checkbad(val):
#   key_list = val.split("^|~")
#   val_len = len(key_list)
  
#   if val_len <= 6:
#     return True
  
#   if '"INSERT"' in key_list[6]:
#     if val_len != 27 :
#       return True
#   elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
#     if val_len != 28:
#       return True
#   else:
#     if val_len != 28:
#       return True

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split(",")
  val_len = len(key_list)
  print('val_len:',val_len)
  
  if val_len > 5:
    print('less than 5')
    return True
    
#   if '"INSERT"' in key_list[6]:
#     if val_len != 27 :
#       return True
#   elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
#     if val_len != 28:
#       return True
  else:
    if val_len != 5:
      print('not equal to 5')
      return True
      

# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
display(in_text)
in_text = in_text.rdd

dataColl = in_text.collect()
for row in dataColl:
  print(row[0] ) #+ "," +str(row[1]))


# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))
# df_rdb = rdb.toDF()
# display(df_rdb)
print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
in_dat = spark.read.csv(readList, schema)
no_Cols = len(in_dat.columns)
print(no_Cols)
display(in_dat)

# COMMAND ----------

#Writing data in Parquet format to the output directory

in_dat.write.mode('overwrite').parquet(OUT_FILEPATH)

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
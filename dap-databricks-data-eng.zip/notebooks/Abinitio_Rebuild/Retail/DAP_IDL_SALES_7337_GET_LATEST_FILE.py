# Databricks notebook source
mountPoint=dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("fileDate",'')
#dbutils.widgets.text("Inpath",'')

fileDate=dbutils.widgets.get("fileDate")
Inpath=dbutils.widgets.get("Inpath")

Filepattern='/mnt/wrangled/'+Inpath+'/'+fileDate+'.fct_day_str_upc_*.dat'
print(Filepattern)

# COMMAND ----------

from pyspark.sql.types import *
import glob

#/mnt/wrangled/master_data/decode/pos/fct/*.dat
dflist=glob.glob(Filepattern)
#print(dflist)
dflist.sort(reverse=True)
dfmax=dflist[0]
#print(dfmax.replace("/mnt/wrangled/",""))
dbutils.notebook.exit(dfmax.replace("/mnt/wrangled/",""))


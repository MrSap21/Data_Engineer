# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")

IN_FILE1 = dbutils.widgets.get("PAR_DB_INPUT_FILE1")
IN_FILE2 = dbutils.widgets.get("PAR_DB_INPUT_FILE2")
IN_FILE3 = dbutils.widgets.get("PAR_DB_INPUT_FILE3")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

REJ_FILE1 = dbutils.widgets.get("PAR_DB_REJ_FILE1")
REJ_FILE2 = dbutils.widgets.get("PAR_DB_REJ_FILE2")
REJ_FILE3 = dbutils.widgets.get("PAR_DB_REJ_FILE3")
REJ_FILE4 = dbutils.widgets.get("PAR_DB_REJ_FILE4")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")



#IN_DATAFILE2 = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
IN_DATAFILE1 = mountPoint + '/'+ IN_FILE1 + '/'+ BATCH_ID
IN_DATAFILE2 = mountPoint + '/'+ IN_FILE2 + '/'+ BATCH_ID
IN_DATAFILE3 = mountPoint + '/'+ IN_FILE3 + '/'+ BATCH_ID
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_FILEPATH1 = mountPoint + '/'+ REJECT_PATH + '/' + REJ_FILE1 + '/' + BATCH_ID
REJ_FILEPATH2 = mountPoint + '/'+ REJECT_PATH + '/' + REJ_FILE2 + '/' + BATCH_ID
REJ_FILEPATH3 = mountPoint + '/'+ REJECT_PATH + '/' + REJ_FILE3 + '/' + BATCH_ID
REJ_FILEPATH4 = mountPoint + '/'+ REJECT_PATH + '/' + REJ_FILE4 + '/' + BATCH_ID
#REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/short_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'

print (IN_DATAFILE1)
print (IN_DATAFILE2)
print (IN_DATAFILE3)
print (OUT_FILEPATH)
print (REJ_FILEPATH1)
print(REJ_FILEPATH2)
print(REJ_FILEPATH3)


# COMMAND ----------

df1 = spark.read.parquet(IN_DATAFILE1)
#display(df1)

# COMMAND ----------

df2 = spark.read.parquet(IN_DATAFILE2)
#display(df2)

# COMMAND ----------

df12 = df2.join(df1, df2.txn_id==df1.txn_id, "inner") #.withColumn("sales_txn_id", df2.txn_id)
df12 = df12.select(
df12.sales_txn_id,
df12.sales_txn_dt,
df12.sales_ord_src_type,
df12.sales_txn_type,
df12.src_sys_cd)

#df12 = df12.withColumn("sales_txn_id", df12.txn_id)
#display(df12)

# COMMAND ----------

#Rows filtered out in Join condition from both DF1 and DF2 dataframe

dfr1 = df1.join(df2, on='txn_id', how='left_anti')
dfr1.write.mode('overwrite').parquet(REJ_FILEPATH1)

dfr2 = df2.join(df1, on='txn_id', how='left_anti')
dfr1.write.mode('overwrite').parquet(REJ_FILEPATH2)
#display(dfr2)

# COMMAND ----------

df3 = spark.read.parquet(IN_DATAFILE3)
df3 = df3.filter(lower(df3.wag_ExpiredItem)=='true')
#display(df3)

# COMMAND ----------

df23 = df12.join(df3, df12.sales_txn_id==df3.wag_RFN, "inner")

df23 = df23.withColumn('add_on_type_cd', lit('Expired_Rejected'))\
           .withColumn("wag_ExpirationDate", when (df23.wag_ExpirationDate.isNotNull(), date_format(df23.wag_ExpirationDate,"yyyy-MM-dd")).otherwise(df23.wag_ExpirationDate))\
           .withColumn("wag_MfgDate", when (df23.wag_MfgDate.isNotNull(), date_format(df23.wag_MfgDate,"yyyy-MM-dd")).otherwise(df23.wag_MfgDate))

df23 = df23.select(
        "sales_txn_id",
        "sales_txn_dt",
        "src_sys_cd",
        "sales_txn_type",
        "sales_ord_src_type",
        "add_on_type_cd",
        df23.DetailNumber.alias ('src_seq_nbr'),
        df23.wag_GTIN.alias('gtin'),
        df23.wag_ExpirationDate.alias('expire_dt'),
        df23.wag_MfgDate.alias('mfgr_dt'),
        df23.wag_LotNumber.alias('lot_nbr'),
        df23.wag_SerialNumber.alias('ser_nbr'),
        df23.wag_ExpiredItem.alias('expired_item_cd'))

df_final = df23
#display(df23)

# COMMAND ----------

#Rows filtered out in Join condition from both DF1 and DF2 dataframe

dfr3 = df3.join(df12, df3.wag_RFN==df12.sales_txn_id, how='left_anti')
dfr3.write.mode('overwrite').parquet(REJ_FILEPATH3)

dfr4 = df12.join(df3, df3.wag_RFN==df12.sales_txn_id, how='left_anti')
dfr1.write.mode('overwrite').parquet(REJ_FILEPATH4)
#display(dfr4)

# COMMAND ----------

# df23 = df23.withColumn("sales_txn_dt", to_timestamp(df23["sales_txn_dt"]))\
#                    .withColumn("src_seq_nbr",when(col("src_seq_nbr") == "",None).otherwise(col("src_seq_nbr")))\
#                    .withColumn("gtin",when(col("gtin") == "",None).otherwise(col("gtin")))\
#                    .withColumn("expire_dt", to_timestamp(df23["expire_dt"]))\
#                    .withColumn("mfgr_dt", to_timestamp(df23["mfgr_dt"]))

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Update Varchar columns to null
# from pyspark.sql.types import StringType
# from pyspark.sql import functions as F

# sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
# print(sel_snfl_tbl)
# dfsf=spark.read \
#    .format("snowflake") \
#    .options(**options) \
#    .option("sfWarehouse", SNFL_WH) \
#    .option("sfDatabase", SNFL_DB) \
#    .option("query",sel_snfl_tbl)\
#    .load()

# #display(dfsf)
# # get string
# str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
# #print(str_cols)


# for col in str_cols:
#   df_final = df23.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))
  
# display(df_final)
# #print(f"Final good after union {df_final.count()}")

# COMMAND ----------

#Creating Load Ready File

df_final.write.mode('overwrite').parquet(OUT_FILEPATH)

# COMMAND ----------

dfldr = spark.read.parquet(OUT_FILEPATH)
display(dfldr)
# Databricks notebook source
# dbutils.widgets.text("PAR_BATCH_ID","20221225153017")
# dbutils.widgets.text("PAR_SQL_SERVER","dapprodsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapprodsqldb01")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","proddnasqldb")
# dbutils.widgets.text("PAR_INPUT_PATH1","pharmacy_healthcare/mail_order/output")
# dbutils.widgets.text("PAR_INPUT_FILE1","extract_from_mailmgt_dim_card")
# dbutils.widgets.text("PAR_INPUT_PATH2","digital/ecom/outbound")
# dbutils.widgets.text("PAR_INPUT_FILE2","extract_from_ecomm_dim_card")
# dbutils.widgets.text("PAR_OUTPUT_FOLDER","retail/retail_sales/staging")

# COMMAND ----------

pBatchID = dbutils.widgets.get("PAR_BATCH_ID")
pSQLServer = dbutils.widgets.get("PAR_SQL_SERVER")
pSQLServerDB = dbutils.widgets.get("PAR_SQL_SERVER_DB")
pSQLServerClientID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
pSQLServerClientSecret = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
pInputPath1 = dbutils.widgets.get("PAR_INPUT_PATH1")
pInputFile1 = dbutils.widgets.get("PAR_INPUT_FILE1")
pInputPath2 = dbutils.widgets.get("PAR_INPUT_PATH2")
pInputFile2 = dbutils.widgets.get("PAR_INPUT_FILE2")
pOutputFile = dbutils.widgets.get("PAR_OUTPUT_FOLDER")

from pyspark.sql.types import StringType, IntegerType
import pandas as pd
from pyspark.sql.functions import split, col, lit, to_date, substring, concat_ws, date_add, regexp_extract, trim, to_timestamp, count, date_format

# COMMAND ----------

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

# # Connect to Azure SQL Server
# import pyodbc 
# import os
# import adal

# conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
#                       f'Server={pSQLServer};'
#                       f'Database={pSQLServerDB};'
#                       f'UID={dbutils.secrets.get(scope="dapadbscope",key=pSQLServerClientID)};'
#                       f'PWD={dbutils.secrets.get(scope="dapadbscope",key=pSQLServerClientSecret)};'
#                       'Authentication=ActiveDirectoryServicePrincipal'
#                      )
# cursor = conn.cursor()

# COMMAND ----------

# #mail_mgmt_batch_id = str(cursor.execute("SELECT Edw_batch_id from DAP_Proc_Cntrl_Batch_Detail where Proj_name='EDW_mail_mgmt_rpt_prd' and Src_stream_name='NA' and Batch_status_cd=1").fetchall()[0][0])
# mail_mgmt_batch_id = '20230102090059'
# print("Active Batch id for EDW_mail_mgmt_rpt_prd: {}".format(mail_mgmt_batch_id))
# ecomm_batch_id = str(cursor.execute("SELECT Edw_batch_id from DAP_Proc_Cntrl_Batch_Detail where Proj_name='EDW_ecommerce_prd' and Src_stream_name='NA' and Batch_status_cd=1").fetchall()[0][0])
# print("Active Batch id for EDW_ecommerce_prd: {}".format(ecomm_batch_id))

# COMMAND ----------

#Pick the Latest File for extract_from_mailmgt_dim_card*.dat under pharmacy_healthcare/mail_order/output folder:
import os
path = mountPoint+"/"+pInputPath1
filelist = []

for root, dirs, files in os.walk(path):
  for file in files:
    if file.__contains__('extract_from_mailmgt_dim_card'):
      filelist.append(os.path.join(root,file))
        
extFrmMailMgtLatestFile = max(filelist)
print("extract_from_mailmgt_dim_card Latest file: {}".format(extFrmMailMgtLatestFile))

# COMMAND ----------

# Reading extract_from_mailmgt_dim_card file and writing under master_data ecdw batch_id folder:

extFrmMailMgt_DF = spark.read.format("csv").load(extFrmMailMgtLatestFile)
print(mountPoint+"/"+pOutputFile+"/Dim_Card_Files/extract_from_mailmgt_dim_card/"+pBatchID)
extFrmMailMgt_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+pOutputFile+"/Dim_Card_Files/extract_from_mailmgt_dim_card/"+pBatchID)

# Reading extract_from_ecomm_dim_card file and writing under master_data ecdw batch_id folder:

extFrmEcomm_DF = spark.read.format("csv").load(mountPoint+"/"+pInputPath2+"/"+pInputFile2+".dat")
print(mountPoint+"/"+pOutputFile+"/Dim_Card_Files/extract_from_ecomm_dim_card/"+pBatchID)
extFrmEcomm_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+pOutputFile+"/Dim_Card_Files/extract_from_ecomm_dim_card/"+pBatchID)

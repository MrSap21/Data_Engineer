# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# # # #Widgets for passing required parameters values

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220119045142")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_USER_ID","devpos")
# dbutils.widgets.text("PAR_POSINTERM_INFILE","pos_interm") #Intermediate in File
# dbutils.widgets.text("PAR_POSCUSTSPOT_OUTFILE","pos_customer_spot_insert_ascii.pipe_delim") #Output File
# dbutils.widgets.text("PAR_POSPOSTVOID_ORIG_INFILE","pos_post_void_w_orig_info") #Intermediate in File
# dbutils.widgets.text("PAR_PREVDAY_POSTXN_INFILE","prev_day_pos_txn") #Intermediate in File
# dbutils.widgets.text("PAR_POSDECODE_LKPFILE","pos_decode_lookup") #Intermediate Lkp in File
# dbutils.widgets.text("PAR_POSTVOIDED_LKPFILE","Int_DF6_DF10_DF11_post_voided_txn_lookup") #Intermediate Lkp out File
# dbutils.widgets.text("PAR_POSTVOID_LKPFILE","Int_DF6_DF11_post_void_txn_lookup") #Intermediate Lkp out File
# dbutils.widgets.text("PAR_POSTXNXREF_OUTFILE","pos_txn_xref_insert_ascii.pipe_delim") #Output File
# dbutils.widgets.text("PAR_POSTXNUPDATE_OUTFILE","pos_txn_update.pipe_delim") #Output File
# dbutils.widgets.text("PAR_DECODEREPLACE_INFILE","pos_decode_replace_ascii.pipe_delim") #Intermediate in File
# dbutils.widgets.text("PAR_STRREGREPLACE_INFILE","str_register_replace_ascii") #Intermediate in File
# dbutils.widgets.text("PAR_TENDERCD_LKPFILE","tender_cd_lookup_ascii") #Intermediate lkp File
# dbutils.widgets.text("PAR_REGLOC_LKPFILE","register_loc_lookup_ascii") #Intermediate lkp File
# dbutils.widgets.text("PAR_POSFILE_LKPFILE","pos_file_lookup") #Intermediate lkp File
# dbutils.widgets.text("PAR_POSMAXID_LKPFILE","pos_decode_max_id_lookup_ascii") #Intermediate lkp File
# dbutils.widgets.text("PAR_UNKNOWNDECODE_OUTFILE","unknown_decodes.pipe_delim") #Output File
# dbutils.widgets.text("PAR_DECODEREPLACE_OUTFILE","pos_decode_replace_ascii.pipe_delim") #Intermediate out File
# dbutils.widgets.text("PAR_DECODEWVAL_LKPFILE","Int_DF7_DF8_DF11_decode_w_value_lookup") #Intermediate lkp out File
# dbutils.widgets.text("PAR_DECODEWNAME_LKPFILE","Int_DF7_DF8_decode_w_name_lookup") #Intermediate lkp out File
# dbutils.widgets.text("PAR_STRREGREPLACE_OUTFILE","str_register_replace_ascii_new") #Intermediate out File

# COMMAND ----------

#POS Customer Spot
from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark.sql.types import *

#retrieving input values from widget parameters
Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
User_ID = dbutils.widgets.get("PAR_USER_ID")
PosInterm_INFile = dbutils.widgets.get("PAR_POSINTERM_INFILE")
PosCustSpot_OUTFile = dbutils.widgets.get("PAR_POSCUSTSPOT_OUTFILE")
PostVoidOrig_INFile = dbutils.widgets.get("PAR_POSPOSTVOID_ORIG_INFILE")
PrevDayPosTxn_INFile = dbutils.widgets.get("PAR_PREVDAY_POSTXN_INFILE")
PostDecode_LKPFile = dbutils.widgets.get("PAR_POSDECODE_LKPFILE")
PostVoided_LKPFile = dbutils.widgets.get("PAR_POSTVOIDED_LKPFILE")
PostVoid_LKPFile = dbutils.widgets.get("PAR_POSTVOID_LKPFILE")
PostTxnXref_OUTFile = dbutils.widgets.get("PAR_POSTXNXREF_OUTFILE")
PostTxnUpdate_OUTFile = dbutils.widgets.get("PAR_POSTXNUPDATE_OUTFILE")
DecodeReplace_INFile = dbutils.widgets.get("PAR_DECODEREPLACE_INFILE")
StrRegReplace_INFile = dbutils.widgets.get("PAR_STRREGREPLACE_INFILE")
TenderCd_LKPFile = dbutils.widgets.get("PAR_TENDERCD_LKPFILE")
RegLoc_LKPFile = dbutils.widgets.get("PAR_REGLOC_LKPFILE")
PosFile_LKPFile = dbutils.widgets.get("PAR_POSFILE_LKPFILE")
PosMaxId_LKPFile = dbutils.widgets.get("PAR_POSMAXID_LKPFILE")
UnknownDecode_OUTFile = dbutils.widgets.get("PAR_UNKNOWNDECODE_OUTFILE")
DecodeReplace_OUTFile = dbutils.widgets.get("PAR_DECODEREPLACE_OUTFILE")
DecodeWVal_LKPFile = dbutils.widgets.get("PAR_DECODEWVAL_LKPFILE")
DecodeWName_LKPFile = dbutils.widgets.get("PAR_DECODEWNAME_LKPFILE")
StrRegReplace_OUTFile = dbutils.widgets.get("PAR_STRREGREPLACE_OUTFILE")

pos_intermDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+PosInterm_INFile)
#display(pos_intermDF)

pos_intermReformatDF = pos_intermDF.withColumn("local_cust_spot",regexp_replace(trim(col("rec_type_E_sub_typ_10_spot_info")),':','')) 

pos_intermReformatDF1 = pos_intermReformatDF.filter((col("rcd_type")=='E') & (col("rec_type_E_rcrd_sub_type")=='0010'))

pos_intermReformatDF1 = pos_intermReformatDF1.withColumn("zip_code_5",when(length("local_cust_spot")==5,col("local_cust_spot")).otherwise(lit(None))) \
.withColumn("phone_nbr",when(length("local_cust_spot")==10,col("local_cust_spot")).otherwise(lit(None))) \
.select(col("txn_cntr").alias("txn_id"),col("txn_date").alias("txn_dt"),"zip_code_5","phone_nbr","loc_id") 

pos_intermReformatDF_Final = pos_intermReformatDF1.select("txn_id","txn_dt","zip_code_5","phone_nbr","loc_id",row_number().over(Window.partitionBy("txn_id","txn_dt","zip_code_5","phone_nbr").orderBy(pos_intermReformatDF1['txn_id'])).alias("row_num"))

pos_intermReformatDF_Final1 = pos_intermReformatDF_Final.filter(col("row_num") ==1).drop("row_num")

#display(pos_intermReformatDF_Final1)
#pos_intermReformatDF_Final1.printSchema()

# Output File 1 : pos_customer_spot_insert_ascii
pos_intermReformatDF_Final1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PosCustSpot_OUTFile+"/"+Batch_id)

# COMMAND ----------

#Post Void Engine:

#display(pos_intermDF)
#pos_intermDF.printSchema()

pos_intermTrans0_DF = pos_intermDF.filter((col("rcd_type")==" ") & (col("txn_type")=="38") & (col("rec_in_txn_cntr")=="2"))
pos_intermTrans1_DF = pos_intermDF.filter((col("rcd_type")==" ") & (col("txn_type")!=38))

pos_intermTrans0_RFMT_DF = pos_intermTrans0_DF.withColumn("pv_cashier_nbr",col("cashier_nbr")) \
.withColumn("pv_txn_nbr",col("txn_nbr")) \
.withColumn("orig_txn_nbr",col("rec_type_M_38_not_1st_orig_tran_nbr")) \
.withColumn("pv_status",trim(col("post_void_status"))) \
.withColumn("pv_txn_id",col("txn_cntr"))

pos_intermTrans0_RFMT_selectDF = pos_intermTrans0_RFMT_DF.filter(col("pv_status")=="F")

pos_intermTrans0_RFMT_deselectDF = pos_intermTrans0_RFMT_DF.subtract(pos_intermTrans0_RFMT_selectDF)


pos_intermTrans1_RFMT_DF = pos_intermTrans1_DF.withColumn("orig_txn_nbr",col("txn_nbr")) \
.withColumn("orig_txn_id",col("txn_cntr")) \
.withColumn("orig_cashier_nbr",col("cashier_nbr"))


#NEW
for c in pos_intermTrans0_RFMT_deselectDF.columns:
  pos_intermTrans0_RFMT_deselectDF = pos_intermTrans0_RFMT_deselectDF.withColumnRenamed(c,'des_' + c)

#Join post voids to orig txns same register
pos_intermTransJoin = pos_intermTrans0_RFMT_deselectDF.join(pos_intermTrans1_RFMT_DF,
on=[(pos_intermTrans0_RFMT_deselectDF.des_str_nbr).cast(IntegerType())==(pos_intermTrans1_RFMT_DF.str_nbr).cast(IntegerType()),
(pos_intermTrans0_RFMT_deselectDF.des_register_nbr).cast(IntegerType())==(pos_intermTrans1_RFMT_DF.register_nbr).cast(IntegerType()),
(pos_intermTrans0_RFMT_deselectDF.des_orig_txn_nbr).cast(IntegerType())==(pos_intermTrans1_RFMT_DF.orig_txn_nbr).cast(IntegerType())],
                                                           how='left_outer')

#spark.conf.set("spark.sql.analyzer.failAmbiguousSelfJoin","false")

pos_intermTransJoin1 = pos_intermTransJoin.select(col('des_loc_id').alias('loc_id'),col('des_txn_date').alias('txn_date'),col('des_str_nbr').alias('str_nbr'),col('des_register_nbr').alias('register_nbr'),col('des_pv_cashier_nbr').alias('pv_cashier_nbr'),col('des_pv_txn_nbr').alias('pv_txn_nbr'),col('des_pv_txn_id').alias('pv_txn_id'),col('des_pv_status').alias('pv_status'),col('des_orig_txn_nbr').alias('orig_txn_nbr'),col('orig_txn_id'),col('orig_cashier_nbr'),(coalesce(col('total_sell_prc'),lit("0"))).alias('total_sell_prc'))

pos_intermTransJoinUnused = pos_intermTrans1_RFMT_DF.join(pos_intermTrans0_RFMT_deselectDF,
on=[(pos_intermTrans0_RFMT_deselectDF.des_str_nbr).cast(IntegerType())==(pos_intermTrans1_RFMT_DF.str_nbr).cast(IntegerType()),
(pos_intermTrans0_RFMT_deselectDF.des_register_nbr).cast(IntegerType())==(pos_intermTrans1_RFMT_DF.register_nbr).cast(IntegerType()),
(pos_intermTrans0_RFMT_deselectDF.des_orig_txn_nbr).cast(IntegerType())==(pos_intermTrans1_RFMT_DF.orig_txn_nbr).cast(IntegerType())],
                                                           how='left_anti')
#display(pos_intermTransJoinUnused)
#pos_intermTransJoinUnused.printSchema()

# COMMAND ----------

post_void_w_orig_infoDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+PostVoidOrig_INFile+"/"+Batch_id)

post_void_w_orig_infoFilterDF = post_void_w_orig_infoDF.filter(post_void_w_orig_infoDF.orig_register_nbr!=post_void_w_orig_infoDF.pv_register_nbr)
#post_void_w_orig_infoFilterDF.printSchema()

#Join – orig txns
JoinOrigTxnsDF = pos_intermTransJoinUnused.join(post_void_w_orig_infoFilterDF,
                                               on=[(pos_intermTransJoinUnused.str_nbr).cast(IntegerType())==(post_void_w_orig_infoFilterDF.orig_str_nbr).cast(IntegerType()),
                                                  (pos_intermTransJoinUnused.register_nbr).cast(IntegerType())==(post_void_w_orig_infoFilterDF.orig_register_nbr).cast(IntegerType()),
                                                  (pos_intermTransJoinUnused.orig_txn_nbr).cast(IntegerType())==(post_void_w_orig_infoFilterDF.orig_txn_nbr).cast(IntegerType())],                                   how='inner').select(pos_intermTransJoinUnused.loc_id,pos_intermTransJoinUnused.txn_date,pos_intermTransJoinUnused.str_nbr,pos_intermTransJoinUnused.register_nbr,pos_intermTransJoinUnused.orig_txn_nbr,pos_intermTransJoinUnused.orig_txn_id,pos_intermTransJoinUnused.orig_cashier_nbr,pos_intermTransJoinUnused.total_sell_prc,post_void_w_orig_infoFilterDF.orig_rfn,post_void_w_orig_infoFilterDF.post_void_rfn,post_void_w_orig_infoFilterDF.orig_str_nbr,post_void_w_orig_infoFilterDF.orig_register_nbr,post_void_w_orig_infoFilterDF.pv_str_nbr,post_void_w_orig_infoFilterDF.pv_register_nbr,post_void_w_orig_infoFilterDF.pv_txn_nbr)

#JoinOrigTxnsDF.printSchema()
#display(JoinOrigTxnsDF)

# COMMAND ----------

#Join – pv registers
pos_intermTransJoin1 = pos_intermTransJoin1.withColumnRenamed("total_sell_prc","total_sell_prc_left")
JoinOrigTxnsDF = JoinOrigTxnsDF.withColumnRenamed("total_sell_prc","total_sell_prc_right")

for c in JoinOrigTxnsDF.columns:
  JoinOrigTxnsDF = JoinOrigTxnsDF.withColumnRenamed(c,'org_'+ c)
  
JoinPvRegDF = pos_intermTransJoin1.join(JoinOrigTxnsDF,on=[(pos_intermTransJoin1.str_nbr).cast(IntegerType())==(JoinOrigTxnsDF.org_str_nbr).cast(IntegerType()),
                                                          (pos_intermTransJoin1.register_nbr).cast(IntegerType())==(JoinOrigTxnsDF.org_pv_register_nbr).cast(IntegerType()),
                                                          (pos_intermTransJoin1.orig_txn_nbr).cast(IntegerType())==(JoinOrigTxnsDF.org_orig_txn_nbr).cast(IntegerType())],
                                       how = 'left_outer')
JoinPvRegDF1 = JoinPvRegDF.select(pos_intermTransJoin1.loc_id,pos_intermTransJoin1.txn_date,pos_intermTransJoin1.str_nbr,pos_intermTransJoin1.register_nbr,pos_intermTransJoin1.pv_cashier_nbr,pos_intermTransJoin1.pv_txn_nbr,pos_intermTransJoin1.pv_txn_id,pos_intermTransJoin1.pv_status,pos_intermTransJoin1.orig_txn_nbr,coalesce(JoinOrigTxnsDF.org_orig_txn_id,pos_intermTransJoin1.orig_txn_id).alias("orig_txn_id"),coalesce(JoinOrigTxnsDF.org_orig_cashier_nbr,pos_intermTransJoin1.orig_cashier_nbr).alias("orig_cashier_nbr"),coalesce(JoinOrigTxnsDF.org_total_sell_prc_right,pos_intermTransJoin1.total_sell_prc_left).alias("total_sell_prc"))

#display(JoinPvRegDF1)
#JoinPvRegDF1.printSchema()

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------

# Rfrmt failed post voids and Join – pv registers gather:
pos_intermTrans0_RFMT_selectDF = pos_intermTrans0_RFMT_selectDF.withColumn("orig_txn_id",lit(None)).withColumn("orig_cashier_nbr",lit(None)).select("loc_id","txn_date","str_nbr","register_nbr","pv_cashier_nbr","pv_txn_nbr","pv_txn_id","pv_status","orig_txn_nbr","orig_txn_id","orig_cashier_nbr","total_sell_prc")
RFMT_PvRegGather = pos_intermTrans0_RFMT_selectDF.union(JoinPvRegDF1)

#RFMT_PvRegGather.printSchema()

RfmtGrpNbrDF = RFMT_PvRegGather.select("loc_id","txn_date","str_nbr","register_nbr","pv_cashier_nbr","pv_txn_nbr","pv_txn_id","pv_status","orig_txn_nbr","orig_txn_id","orig_cashier_nbr",coalesce(col("orig_txn_id"),col("pv_txn_id")).alias("xref_group_nbr"),"total_sell_prc")

#RfmtGrpNbrDF.printSchema()

#Rfrmt for post voided txn lookup:

RfmtPostVoidedTxnDF = RfmtGrpNbrDF.filter((col("pv_status")=='S') & (col("orig_txn_id").isNotNull()) & (col("orig_txn_id")!="")) \
.select("loc_id","str_nbr","register_nbr","pv_cashier_nbr","pv_txn_nbr","pv_txn_id","pv_status","orig_txn_nbr","orig_txn_id","orig_cashier_nbr","xref_group_nbr",col("total_sell_prc").alias("orig_total_sell_prc"))

#RfmtPostVoidedTxnDF.printSchema()

#Output File 2 - post_voided_txn_lookup
#RfmtPostVoidedTxnDF = WriteNullParquet(RfmtPostVoidedTxnDF)
RfmtPostVoidedTxnDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+PostVoided_LKPFile)

#Rfrmt for post void txn lookup:
RfmtPostVoidTxnDF = RfmtGrpNbrDF.select("loc_id","str_nbr","register_nbr","pv_cashier_nbr","pv_txn_nbr","pv_txn_id","pv_status","orig_txn_nbr","orig_txn_id","orig_cashier_nbr","xref_group_nbr",col("total_sell_prc").alias("orig_total_sell_prc"))

#RfmtPostVoidTxnDF.printSchema()

#Output File 3 - post_void_txn_lookup:
#RfmtPostVoidTxnDF = WriteNullParquet(RfmtPostVoidTxnDF)
RfmtPostVoidTxnDF = RfmtPostVoidTxnDF.na.fill({'orig_txn_id':'                  ','orig_cashier_nbr':'   ','orig_total_sell_prc':'0'})
RfmtPostVoidTxnDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+PostVoid_LKPFile)

# COMMAND ----------

#Fltr for unmatched post voids:
UnMatchPostVoidFilterDF = RfmtGrpNbrDF.filter((RfmtGrpNbrDF.pv_status=="S") & ((RfmtGrpNbrDF.orig_txn_id.isNull()) |(RfmtGrpNbrDF.orig_txn_id==""))) 

#Prev Days POS Txn:
PrevDayPosTxnDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+PrevDayPosTxn_INFile)

#PrevDayPosTxnDF.printSchema()

#Rfrmt Prev Day POS
RfmrPrevDayPosDF = PrevDayPosTxnDF.withColumn("txn_type",col("txn_type").cast("Integer")) \
.withColumn("post_void_status_cd",col("post_void_status_cd").cast("Integer")) 

RfmrPrevDayPosDF = RfmrPrevDayPosDF.filter((RfmrPrevDayPosDF.post_void_status_cd == 204) & (RfmrPrevDayPosDF.txn_type >=10) & (RfmrPrevDayPosDF.txn_type <=16)).select("txn_id","txn_dt","loc_id","txn_nbr","register_nbr")

#Join Unmatched to Prev Day:

JoinUnmatchPrevDayDF = UnMatchPostVoidFilterDF.join(RfmrPrevDayPosDF,on=[(UnMatchPostVoidFilterDF.loc_id).cast(IntegerType())==(RfmrPrevDayPosDF.loc_id).cast(IntegerType()),
                                                                        (UnMatchPostVoidFilterDF.register_nbr).cast(IntegerType())==(RfmrPrevDayPosDF.register_nbr).cast(IntegerType()),
                                                                        (UnMatchPostVoidFilterDF.orig_txn_nbr).cast(IntegerType())==(RfmrPrevDayPosDF.txn_nbr).cast(IntegerType())],
                                                   how = 'inner')

JoinUnmatchPrevDayDF1 = JoinUnmatchPrevDayDF.withColumn("potnl_rerung_txn_id",lit('')).withColumn("match_pct",lit('')) \
.select(UnMatchPostVoidFilterDF.pv_txn_id.alias("txn_id"),RfmrPrevDayPosDF.txn_dt,RfmrPrevDayPosDF.txn_id.alias("xref_txn_id"),"potnl_rerung_txn_id",UnMatchPostVoidFilterDF.orig_txn_nbr.alias("xref_txn_nbr"),"match_pct",UnMatchPostVoidFilterDF.loc_id)

#JoinUnmatchPrevDayDF.printSchema()
#display(JoinUnmatchPrevDayDF)

# COMMAND ----------

#Join to Curr Txn Xref:

for c in JoinUnmatchPrevDayDF1.columns:
  JoinUnmatchPrevDayDF1 = JoinUnmatchPrevDayDF1.withColumnRenamed(c,'pd_'+c)
  
CurrTxnXrefJoinDF = RfmtGrpNbrDF.join(JoinUnmatchPrevDayDF1,(trim(RfmtGrpNbrDF.pv_txn_id))==(trim(JoinUnmatchPrevDayDF1.pd_txn_id)),"left_outer")

PosDecodeLkpDF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+PostDecode_LKPFile)

xrefTypeCd = PosDecodeLkpDF.filter((PosDecodeLkpDF.cd_type == "XREF_SCENARIO") & (PosDecodeLkpDF.cd_name == "Post Void")).select("cd_id").collect() #[0].cd_id

if len(xrefTypeCd)!=0:
  xrefTypeCd = xrefTypeCd[0].cd_id
else:
  xrefTypeCd = None

TxnExtendStatCd = PosDecodeLkpDF.filter((PosDecodeLkpDF.cd_type == "XREF_SCENARIO_ROLE") & (PosDecodeLkpDF.cd_name == "PVoid Txn")).select("cd_id").collect() #[0].cd_id

if len(TxnExtendStatCd)!=0:
  TxnExtendStatCd = TxnExtendStatCd[0].cd_id
else:
  TxnExtendStatCd = None

CurrTxnXrefJoinColsDF = CurrTxnXrefJoinDF.withColumn("potnl_rerung_txn_id",lit(None).cast(StringType())) \
.withColumn("match_pct",lit(None).cast(StringType())) \
.withColumn("xref_type_cd",lit(xrefTypeCd)) \
.withColumn("txn_extend_status_cd",lit(TxnExtendStatCd)) \
.select(RfmtGrpNbrDF.pv_txn_id.alias("txn_id"),RfmtGrpNbrDF.txn_date.alias("txn_dt"),coalesce(JoinUnmatchPrevDayDF1.pd_xref_txn_id,RfmtGrpNbrDF.orig_txn_id).alias("xref_txn_id"),"potnl_rerung_txn_id",RfmtGrpNbrDF.orig_txn_nbr.alias("xref_txn_nbr"),"match_pct",RfmtGrpNbrDF.loc_id,"xref_type_cd","txn_extend_status_cd",RfmtGrpNbrDF.xref_group_nbr.alias("group_nbr"),RfmtGrpNbrDF.orig_cashier_nbr.alias("orig_txn_cashier_nbr"),RfmtGrpNbrDF.pv_cashier_nbr.alias("pvoid_txn_cashier_nbr"))

#CurrTxnXrefJoinColsDF.printSchema()
#display(CurrTxnXrefJoinColsDF)

# COMMAND ----------

#Rfrmt Post Voided Orig Txn:
TxnExtendStatCd1 = PosDecodeLkpDF.filter((PosDecodeLkpDF.cd_type == "XREF_SCENARIO_ROLE") & (PosDecodeLkpDF.cd_name == "Orig Txn")).select("cd_id").collect() #[0].cd_id

if len(TxnExtendStatCd1)!=0:
  TxnExtendStatCd1 = TxnExtendStatCd1[0].cd_id
else:
  TxnExtendStatCd1 = None  

RfmtPostVoidedOrgTxnDF = CurrTxnXrefJoinColsDF.where((col('xref_txn_id').isNotNull()) & ((col('xref_txn_id')!=''))) \
.withColumn("txn_id",col("xref_txn_id")) \
.withColumn("xref_txn_nbr",lit("-1")) \
.withColumn("xref_type_cd",lit(xrefTypeCd)) \
.withColumn("txn_extend_status_cd",lit(TxnExtendStatCd1))\
.select("txn_id","txn_dt","xref_txn_id","potnl_rerung_txn_id","xref_txn_nbr","match_pct","loc_id","xref_type_cd","txn_extend_status_cd","group_nbr","orig_txn_cashier_nbr","pvoid_txn_cashier_nbr")

#RfmtPostVoidedOrgTxnDF.printSchema()

#Gather : Join to Curr Txn Xref and Rfrmt Post Voided Orig Txn

CurrTxnRfmtPostGatherDF = RfmtPostVoidedOrgTxnDF.union(CurrTxnXrefJoinColsDF).withColumn('txn_dt',(trim(date_format(to_date(col('txn_dt'),'yyyyMMdd'),'yyyy-MM-dd'))))

#CurrTxnRfmtPostGatherDF.printSchema()

#Output File 4 - WRITE voiding and voided to txn xref:
#CurrTxnRfmtPostGatherDF = WriteNullParquet(CurrTxnRfmtPostGatherDF)

CurrTxnRfmtPostGatherDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PostTxnXref_OUTFile+"/"+Batch_id)

#Rfrmt POS Txn Updates:

RfmtPosTxnUpdatesDF = JoinUnmatchPrevDayDF1.withColumn("txn_id",col("pd_xref_txn_id")) \
.withColumn("post_void_status_cd",lit("10")).select("txn_id",col('pd_txn_dt').alias("txn_dt"),"post_void_status_cd")

#RfmtPosTxnUpdatesDF.printSchema()
#Output File 5 - POS Txn Updates:
RfmtPosTxnUpdatesDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PostTxnUpdate_OUTFile+"/"+Batch_id)

# COMMAND ----------

#Validate and ADD ID to New Codes:

#1. Reformat-A: Item void:

RfmtPosIntermDF1 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (pos_intermDF.rec_type_A_item_void.isNotNull()) &(trim(pos_intermDF.rec_type_A_item_void)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("LINE_VOID")) \
.withColumn("pos_decode_cd_value",col("rec_type_A_item_void")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF1 = RfmtPosIntermDF1.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#2. Reformat-A: Birthday:

RfmtPosIntermDF2 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (substring('rec_type_A_upc_tndr', 1,8)=="BIRTHDAY")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("AGE")) \
.withColumn("pos_decode_cd_value",when((pos_intermDF.rec_type_A_overage_ind.isNotNull()) & (pos_intermDF.rec_type_A_overage_ind!=""),trim(pos_intermDF.rec_type_A_overage_ind)).otherwise(lit("OVA"))) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",col("rec_type_A_birthday")) \

RfmtPosIntermDF2 = RfmtPosIntermDF2.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#3. Reformat-A: FSA or manfact cpn:

RfmtPosIntermDF3 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (pos_intermDF.rec_type_A_special.isNotNull()) &(trim(pos_intermDF.rec_type_A_special)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",when((pos_intermDF.rec_type_A_special == "O") | ((pos_intermDF.rec_type_A_special == "F") & (trim(pos_intermDF.rec_type_A_desc_acct_nbr)=="MFG COUPON") & (pos_intermDF.rec_type_A_price_sign == "-")),"MFG_COUPON")
.when((pos_intermDF.rec_type_A_special == "F"),"FSA_ITEM_TYPE")
.otherwise(lit("OTHER COUPON"))) \
.withColumn("pos_decode_cd_value",when((pos_intermDF.rec_type_A_special == "O") | ((pos_intermDF.rec_type_A_special == "F") & (trim(pos_intermDF.rec_type_A_desc_acct_nbr)=="MFG COUPON") & (pos_intermDF.rec_type_A_price_sign == "-")),"O")
.when((pos_intermDF.rec_type_A_special == "F"),"Y")
.otherwise(pos_intermDF.rec_type_A_special)) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF3 = RfmtPosIntermDF3.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF3.printSchema()

#4. Reformat-A: Walgreen cpn:

RfmtPosIntermDF4 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (pos_intermDF.rec_type_A_wag_cpn.isNotNull()) &(trim(pos_intermDF.rec_type_A_wag_cpn)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("WAG_COUPON")) \
.withColumn("pos_decode_cd_value",col("rec_type_A_wag_cpn")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF4 = RfmtPosIntermDF4.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF4.printSchema()

#5. Reformat-A: Dept entry:

RfmtPosIntermDF5 =  pos_intermDF.filter((pos_intermDF.rec_type_A_dept_hardkey_ind.isNotNull())&(trim(pos_intermDF.rec_type_A_dept_hardkey_ind)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("DEPT_ENTRY_MODE")) \
.withColumn("pos_decode_cd_value",rtrim(ltrim(pos_intermDF.rec_type_A_dept_hardkey_ind))) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF5 = RfmtPosIntermDF5.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF5.printSchema()

# COMMAND ----------

#6. Reformat-A: Item entry:

RfmtPosIntermDF6 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (pos_intermDF.rec_type_A_keyed_item.isNotNull()) &(trim(pos_intermDF.rec_type_A_keyed_item)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("ITEM_ENTRY_MODE")) \
.withColumn("pos_decode_cd_value",col("rec_type_A_keyed_item")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF6 = RfmtPosIntermDF6.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF6.printSchema()

#7. Reformat-A: Price modify:

RfmtPosIntermDF7 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (pos_intermDF.rec_type_A_prc_modify.isNotNull()) &(trim(pos_intermDF.rec_type_A_prc_modify)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("PRICE_MODIFY")) \
.withColumn("pos_decode_cd_value",col("rec_type_A_prc_modify")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF7 = RfmtPosIntermDF7.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF7.printSchema()

#8. Reformat-A: Txn_dtl_discnt_cd:
RfmtPosIntermDF8 = pos_intermDF.filter((pos_intermDF.rcd_type=="A") & (pos_intermDF.rec_type_A_emp_disc.isNotNull()) &(trim(pos_intermDF.rec_type_A_emp_disc)!="")) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type")) \
.withColumn("pos_decode_cd_type",lit("TXN_DTL_DISCNT_CD")) \
.withColumn("pos_decode_cd_value",col("rec_type_A_emp_disc")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None))

RfmtPosIntermDF8 = RfmtPosIntermDF8.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF8.printSchema()

#9. Reformat-Txn: Post Void:

RfmtPosIntermDF9 = pos_intermDF.filter((pos_intermDF.post_void_status.isNotNull()) & (trim(pos_intermDF.post_void_status)!="") & (pos_intermDF.post_void_status!="--")) \
.withColumn("pos_decode_cd_type",lit("POST_VOID")) \
.withColumn("pos_decode_cd_value",trim(pos_intermDF.post_void_status)) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("item_seq_nbr",lit(None)) \
.withColumn("pos_txn_sup_cd_value",lit(None))

# Dedup Sorted-4:
RfmtPosIntermDF9 = RfmtPosIntermDF9.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup", row_number().over(Window.partitionBy("txn_cntr").orderBy(RfmtPosIntermDF9['txn_cntr'])).alias("row_num")) 

RfmtPosIntermDF9 = RfmtPosIntermDF9.filter(RfmtPosIntermDF9.row_num ==1).drop("row_num")

#RfmtPosIntermDF9.printSchema()

#10. Reformat-C: Tender type: 

TndrCdLkp_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+TenderCd_LKPFile)
#display(TndrCdLkp_DF)

tenderCd = TndrCdLkp_DF.filter(TndrCdLkp_DF.tender_name=="CHECK").select("tender_cd").collect() #[0].tender_cd

if len(tenderCd)!=0:
  tenderCd = tenderCd[0].tender_cd
else:
  tenderCd = None

tenderCd1 = TndrCdLkp_DF.filter(TndrCdLkp_DF.tender_name=="ACH CHECK").select("tender_cd").collect() #[0].tender_cd

if len(tenderCd1)!=0:
  tenderCd1 = tenderCd1[0].tender_cd
else:
  tenderCd1 = None

RfmtPosIntermDF10 = pos_intermDF.filter((pos_intermDF.rcd_type=="C") & ((pos_intermDF.rec_type_C_p1_tndr_desc.isNotNull()) &(pos_intermDF.rec_type_C_p1_tndr_desc!=""))) 

RfmtPosIntermDF10 = RfmtPosIntermDF10.withColumn("temp_col",upper(ltrim(rtrim(concat(col("rec_type_C_p1_tndr_desc"),col("rec_type_C_not_check_p2_tndr_desc"))))))

RfmtPosIntermDF10 = RfmtPosIntermDF10.join(TndrCdLkp_DF,RfmtPosIntermDF10.temp_col == TndrCdLkp_DF.tender_name,'left_outer')

RfmtPosIntermDF10 = RfmtPosIntermDF10.withColumn("local_cd_value1",when(trim(pos_intermDF.rec_type_C_p1_tndr_desc)=="CHECK",lit(tenderCd))
            .when((trim(pos_intermDF.rec_type_C_p1_tndr_desc)=="ACH"),lit(tenderCd1))
           .when((TndrCdLkp_DF.tender_cd.isNotNull()) & (TndrCdLkp_DF.tender_cd!=""),TndrCdLkp_DF.tender_cd)
                                                .otherwise(None))

RfmtPosIntermDF10 = RfmtPosIntermDF10.withColumn("local_cd_value",when((RfmtPosIntermDF10.local_cd_value1.isNotNull()) & (trim(RfmtPosIntermDF10.local_cd_value1)!=""),col("local_cd_value1"))
.otherwise(ltrim(rtrim(concat(col("rec_type_C_p1_tndr_desc"),col("rec_type_C_not_check_p2_tndr_desc"))))))

RfmtPosIntermDF10 = RfmtPosIntermDF10.filter((pos_intermDF.rcd_type=="C") & (RfmtPosIntermDF10.local_cd_value.isNotNull()) &(trim(RfmtPosIntermDF10.local_cd_value)!="")) \
.withColumn("pos_decode_cd_type",lit("TENDER_TYPE")) \
.withColumn("pos_decode_cd_value",col("local_cd_value")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None)).select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

# RfmtPosIntermDF10.printSchema()

# COMMAND ----------

# 11. Reformat-C: Tender entry:

RfmtPosIntermDF11 = pos_intermDF.filter((pos_intermDF.rcd_type=="C") & (pos_intermDF.rec_type_C_not_check_entry_mode_new.isNotNull()) &(trim(pos_intermDF.rec_type_C_not_check_entry_mode_new)!="")) \
.withColumn("pos_decode_cd_type",lit("TENDER_ENTRY_MODE")) \
.withColumn("pos_decode_cd_value",col("rec_type_C_not_check_entry_mode_new")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF11 = RfmtPosIntermDF11.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF11.printSchema()

#12. Reformat-E: Refund status:

RfmtPosIntermDF12 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0006") &(pos_intermDF.rec_type_E_sub_typ_6_refund_status.isNotNull()) &(trim(pos_intermDF.rec_type_E_sub_typ_6_refund_status)!="")) \
.withColumn("pos_decode_cd_type",lit("REFUND_STATUS")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_6_refund_status")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF12 = RfmtPosIntermDF12.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF12.printSchema()

#13. Reformat-Txn_Type 11-Txn_discnt_mode_cd:

RfmtPosIntermDF13 = pos_intermDF.filter((pos_intermDF.txn_type=="11") & (pos_intermDF.rec_type_11_disc_mode.isNotNull()) &(trim(pos_intermDF.rec_type_11_disc_mode)!="")) \
.withColumn("pos_decode_cd_type",lit("TXN_DISCNT_MODE_CD")) \
.withColumn("pos_decode_cd_value",col("rec_type_11_disc_mode")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF13 = RfmtPosIntermDF13.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF13.printSchema()

#14. Reformat-E: Refund reason:

RfmtPosIntermDF14 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0006") &(trim(pos_intermDF.rec_type_E_sub_typ_6_refund_rsn)!="") & (pos_intermDF.rec_type_E_sub_typ_6_refund_rsn.isNotNull())) \
.withColumn("pos_decode_cd_type",lit("REFUND_REASON")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_6_refund_rsn")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF14 = RfmtPosIntermDF14.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF14.printSchema()

#15. E0026: Rebate Basis:

RfmtPosIntermDF15 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0026") &(trim(pos_intermDF.rec_type_E_sub_typ_26_wcard_rebt_basis)!="") & (pos_intermDF.rec_type_E_sub_typ_26_wcard_rebt_basis.isNotNull())) \
.withColumn("pos_decode_cd_type",lit("WCARD_RATE")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_26_wcard_rebt_basis")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF15 = RfmtPosIntermDF15.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF15.printSchema()

# COMMAND ----------

#16. Reformat-E: Registerlocation:

RfmtPosIntermDF16 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0006") &(trim(pos_intermDF.rec_type_E_sub_typ_6_register_loc)!="") & (pos_intermDF.rec_type_E_sub_typ_6_register_loc.isNotNull()) & (pos_intermDF.rec_type_E_sub_typ_6_rcpt_entry != "N")) \
.withColumn("pos_decode_cd_type",lit("REGISTER_LOCATION")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_6_register_loc")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF16 = RfmtPosIntermDF16.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF16.printSchema()

#17. Reformat-Txn_Type 12-Txn_discnt_mode_cd:

RfmtPosIntermDF17 = pos_intermDF.filter((pos_intermDF.txn_type=="12") & (trim(pos_intermDF.rec_type_12_disc_mode)!="") & (pos_intermDF.rec_type_12_disc_mode.isNotNull())) \
.withColumn("pos_decode_cd_type",lit("TXN_DISCNT_MODE_CD")) \
.withColumn("pos_decode_cd_value",col("rec_type_12_disc_mode")) \
.withColumn("load_to_sup",lit("Y")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",col("seq_nbr_by_rec_type"))

RfmtPosIntermDF17 = RfmtPosIntermDF17.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF17.printSchema()

#18. Reformat-E: Receipt entry:

RfmtPosIntermDF18 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0006") & (trim(pos_intermDF.rec_type_E_sub_typ_6_rcpt_entry)!="")) \
.withColumn("pos_decode_cd_type",lit("RECEIPT_ENTRY_MODE")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_6_rcpt_entry")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF18= RfmtPosIntermDF18.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF18.printSchema()

#19. Reformat-E: Tandem status:

RfmtPosIntermDF19 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0006") & (trim(pos_intermDF.rec_type_E_sub_typ_6_tandem_stat)!="") & (pos_intermDF.rec_type_E_sub_typ_6_tandem_stat.isNotNull())) \
.withColumn("pos_decode_cd_type",lit("TANDEM_STATUS")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_6_tandem_stat")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF19= RfmtPosIntermDF19.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF19.printSchema()

#20. Reformat-E: Original tender:

RfmtPosIntermDF20 = pos_intermDF.filter((pos_intermDF.rcd_type=="E") & (pos_intermDF.rec_type_E_rcrd_sub_type=="0006") & (trim(pos_intermDF.rec_type_E_sub_typ_6_orig_tndr)!="") & (pos_intermDF.rec_type_E_sub_typ_6_orig_tndr.isNotNull()) & (pos_intermDF.rec_type_E_sub_typ_6_rcpt_entry!="N")) \
.withColumn("pos_decode_cd_type",lit("TENDER_TYPE")) \
.withColumn("pos_decode_cd_value",col("rec_type_E_sub_typ_6_orig_tndr")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF20= RfmtPosIntermDF20.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#RfmtPosIntermDF20.printSchema()

# COMMAND ----------

#21. Reformat-Survey:

RfmtPosIntermDF21 = pos_intermDF.filter((trim(pos_intermDF.rcd_type)=="") & (pos_intermDF.rec_in_txn_cntr=="1") & (~pos_intermDF.txn_type.isin("99","11","12")) & (trim(pos_intermDF.rec_type_M_survey_ind)!="") & (pos_intermDF.rec_type_M_survey_ind.isNotNull())) \
.withColumn("pos_decode_cd_type",lit("SURVEY")) \
.withColumn("pos_decode_cd_value",col("rec_type_M_survey_ind")) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF21= RfmtPosIntermDF21.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")



#RfmtPosIntermDF21.printSchema()

#22. Reformat-M99:

regLocLkp_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+RegLoc_LKPFile)

RfmtPosIntermDF22 =  pos_intermDF.filter((trim(pos_intermDF.rcd_type)=="") & (pos_intermDF.txn_type=="99")) \
.join(regLocLkp_DF,upper(rtrim(ltrim(regLocLkp_DF.reg_desc)))==pos_intermDF.rec_type_M_99_reg_desc,"left_outer") \
.withColumn("pos_decode_cd_type",lit("REGISTER_LOCATION")) \
.withColumn("pos_decode_cd_value",when((regLocLkp_DF.reg_cd.isNotNull()) & (regLocLkp_DF.reg_cd!=""),regLocLkp_DF.reg_cd)
           .otherwise(substring(pos_intermDF.rec_type_M_99_reg_desc,1,2))) \
.withColumn("load_to_sup",lit("N")) \
.withColumn("pos_txn_sup_cd_value",lit(None)) \
.withColumn("item_seq_nbr",lit(None))

RfmtPosIntermDF22= RfmtPosIntermDF22.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","item_seq_nbr","txn_date","per_id","pos_decode_cd_type","pos_decode_cd_value","pos_txn_sup_cd_value","load_to_sup")

#used for str register
RfmtPosIntermDF22_1 =  pos_intermDF.filter((trim(pos_intermDF.rcd_type)=="") & (pos_intermDF.txn_type=="99"))


# COMMAND ----------

# Gather all 22 RFMT DF's:
from functools import reduce

def unionAll(*dfs):
   return reduce(DataFrame.unionAll, dfs)

RfmtPosIntermDF = unionAll(RfmtPosIntermDF1,RfmtPosIntermDF2,RfmtPosIntermDF3,RfmtPosIntermDF4,RfmtPosIntermDF5,RfmtPosIntermDF6,RfmtPosIntermDF7,RfmtPosIntermDF8,RfmtPosIntermDF9,RfmtPosIntermDF10,RfmtPosIntermDF11,RfmtPosIntermDF12,RfmtPosIntermDF13,RfmtPosIntermDF14,RfmtPosIntermDF15,RfmtPosIntermDF16,RfmtPosIntermDF17,RfmtPosIntermDF18,RfmtPosIntermDF19,RfmtPosIntermDF20,RfmtPosIntermDF21,RfmtPosIntermDF22)

#Src File : pos_decode_replace_ascii.pipe_delim 
posDecodeReplaceDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+DecodeReplace_INFile) \
.select("cd_id","cd_type","cd_value","cd_name","cd_desc")


#display(posDecodeReplaceDF)

#Component: Decode and txn_sup parsing:-

#Dedup Sorted on {cd_type; cd_value}:

RfmtPosIntermDecodeDF = PosDecodeLkpDF.join(RfmtPosIntermDF, ((RfmtPosIntermDF.pos_decode_cd_type == PosDecodeLkpDF.cd_type) & (RfmtPosIntermDF.pos_decode_cd_value == PosDecodeLkpDF.cd_value)),"rightOuter")

RfmtPosIntermDecodNonMatcheDF = RfmtPosIntermDecodeDF.filter((col("cd_type").isNull()) & (col("cd_value").isNull()))

#dropping dups
RfmtPosIntermDedupDF1 = RfmtPosIntermDecodNonMatcheDF.dropDuplicates(['pos_decode_cd_type','pos_decode_cd_value'])

tmpDropdupsFilePath = mountPoint+"/"+Staging_Folder+"/"+"TMP_DAP7111_DF7_tmpDropdupsFilePath"

RfmtPosIntermDedupDF1.write.mode('overwrite').parquet(tmpDropdupsFilePath)

RfmtPosIntermDedupDF = spark.read.parquet(tmpDropdupsFilePath)

#POS File lookup read
PosFileLkpDF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+PosFile_LKPFile)

RfmtUnknownDecodesDF =  RfmtPosIntermDedupDF.join(PosFileLkpDF,trim(RfmtPosIntermDedupDF.file_nbr) == trim(PosFileLkpDF.file_nbr),"inner").select("str_nbr","cashier_nbr","register_nbr","txn_nbr","rcd_type","txn_date","pos_decode_cd_type","pos_decode_cd_value",PosFileLkpDF.file_name,"rec_in_file","rec_in_txn_cntr")

#Output File 6 - Unknown decodes with data:
RfmtUnknownDecodesDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+UnknownDecode_OUTFile+"/"+Batch_id)

# COMMAND ----------

#Scan - Assign code id to NEW found codes:

posDecodeMaxIdLkp_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+PosMaxId_LKPFile)

maxCd_Id = posDecodeMaxIdLkp_DF.filter(posDecodeMaxIdLkp_DF.local_key=="A").select("max_cd_id").collect() #[0].max_cd_id

if len(maxCd_Id)!=0:
  maxCd_Id = int(maxCd_Id[0].max_cd_id)
else:
  maxCd_Id = 0

AssignCdIdNewDF = RfmtPosIntermDedupDF.withColumn("cd_id",row_number().over(Window.orderBy("pos_decode_cd_type","pos_decode_cd_value"))+maxCd_Id) \
.withColumn("cd_type",col("pos_decode_cd_type")) \
.withColumn("cd_value",col("pos_decode_cd_value")) \
.withColumn("cd_name",col("pos_decode_cd_value")) \
.withColumn("cd_desc",substring((concat(lit("UNK_"),RfmtPosIntermDedupDF.pos_decode_cd_type)),1,100)) \
.select("cd_id","cd_type","cd_value","cd_name","cd_desc")

#AssignCdIdNewDF.printSchema()

#Gather posDecodeReplaceDF and AssignCdIdNewDF:

posDecodeReplaceNewDF = posDecodeReplaceDF.union(AssignCdIdNewDF)
posDecodeReplaceNewDF.cache()

#####FOR TEST: This needs to be removed before prod#####
DecodeReplace_OUTFile = DecodeReplace_OUTFile + '_new'
########################################################
#Output File 7 - pos_decode_replace_ascii.pipe_delim:
posDecodeReplaceNewDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+DecodeReplace_OUTFile)

# COMMAND ----------

DecodeWValLkp_DF = posDecodeReplaceNewDF.select("cd_id","cd_type","cd_value","cd_name","cd_desc",row_number().over(Window.partitionBy("cd_type","cd_value").orderBy(posDecodeReplaceNewDF.cd_type,posDecodeReplaceNewDF.cd_value,posDecodeReplaceNewDF.cd_id.cast(IntegerType()))).alias("row_num")) 
DecodeWValLkp_DF = DecodeWValLkp_DF.filter(DecodeWValLkp_DF.row_num ==1).drop("row_num")

#Output File 8 - decode_w_value_lookup:
DecodeWValLkp_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+DecodeWVal_LKPFile)

# COMMAND ----------

DecodeWNameLkp_DF = posDecodeReplaceNewDF.select("cd_id","cd_type","cd_value","cd_name","cd_desc",row_number().over(Window.partitionBy("cd_type","cd_name").orderBy(posDecodeReplaceNewDF.cd_type,posDecodeReplaceNewDF.cd_name,posDecodeReplaceNewDF.cd_id.cast(IntegerType()))).alias("row_num")) 

DecodeWNameLkp_DF = DecodeWNameLkp_DF.filter(DecodeWNameLkp_DF.row_num ==1).drop("row_num")

#Output File 9 - decode_w_name_lookup:
DecodeWNameLkp_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+DecodeWName_LKPFile)

# COMMAND ----------

#Component: Store Register Parsing:

#Src File : str_register_replace_ascii.pipe_delim 
strRegReplaceDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+StrRegReplace_INFile)


RfmtM99DF = RfmtPosIntermDF22_1.select("txn_cntr","rec_in_txn_cntr","loc_id","register_nbr","txn_type","rcd_type","per_id","rec_type_M_99_unused1","rec_type_M_99_reg_desc","rec_type_M_99_undefined")

#Reformat - Drop & add  fields:
RfmtM99DF1 = RfmtM99DF.withColumn("register_dept_name",upper(ltrim(rtrim(col("rec_type_M_99_reg_desc"))))) \
.withColumn("create_id",lit(User_ID)) \
.withColumn("create_dttm",to_timestamp(current_date(),"MM-dd-yyyy HH:mm:ss")) \
.withColumn("update_id",lit(User_ID)) \
.withColumn("update_dttm",to_timestamp(current_date(),"MM-dd-yyyy HH:mm:ss"))

#RfmtM99DF1.printSchema()

RfmtM99DedupSortDF = RfmtM99DF1.select("register_nbr","loc_id","register_dept_name","create_id","create_dttm","update_id","update_dttm",row_number().over(Window.partitionBy("loc_id","register_nbr").orderBy(RfmtM99DF1.loc_id,RfmtM99DF1.register_nbr)).alias("row_num")) 

RfmtM99DedupSortDF = RfmtM99DedupSortDF.filter(RfmtM99DedupSortDF.row_num ==1).drop("row_num")

#Reformat - Change to upcase:

strRegReplaceDF1 = strRegReplaceDF.withColumn("register_dept_name",upper(ltrim(rtrim(strRegReplaceDF.register_dept_name))))


RftmtM99AndstrReplaceJoinDF = RfmtM99DedupSortDF.join(strRegReplaceDF,on = [trim(RfmtM99DedupSortDF.loc_id).cast(IntegerType()) == trim(strRegReplaceDF.loc_id).cast(IntegerType()), trim(RfmtM99DedupSortDF.register_nbr).cast(IntegerType()) == trim(strRegReplaceDF.register_nbr).cast(IntegerType())],how = 'full_outer')

RfmtOutDF = RftmtM99AndstrReplaceJoinDF.filter((RfmtM99DedupSortDF.loc_id.isNotNull()) & (RfmtM99DedupSortDF.register_nbr.isNotNull()) &
                                              (strRegReplaceDF.loc_id.isNotNull()) & (strRegReplaceDF.register_nbr.isNotNull())).select(RfmtM99DedupSortDF.register_nbr,RfmtM99DedupSortDF.loc_id,RfmtM99DedupSortDF.register_dept_name,RfmtM99DedupSortDF.create_id,RfmtM99DedupSortDF.create_dttm,RfmtM99DedupSortDF.update_id,RfmtM99DedupSortDF.update_dttm)

RfmtUnUsed0DF = RftmtM99AndstrReplaceJoinDF.filter((RfmtM99DedupSortDF.loc_id.isNotNull()) & (RfmtM99DedupSortDF.register_nbr.isNotNull()) &
                                              (strRegReplaceDF.loc_id.isNull()) & (strRegReplaceDF.register_nbr.isNull())).select(RfmtM99DedupSortDF.register_nbr,RfmtM99DedupSortDF.loc_id,RfmtM99DedupSortDF.register_dept_name,RfmtM99DedupSortDF.create_id,RfmtM99DedupSortDF.create_dttm,RfmtM99DedupSortDF.update_id,RfmtM99DedupSortDF.update_dttm)

RfmtUnUsed1DF = RftmtM99AndstrReplaceJoinDF.filter((RfmtM99DedupSortDF.loc_id.isNull()) & (RfmtM99DedupSortDF.register_nbr.isNull()) &
                                              (strRegReplaceDF.loc_id.isNotNull()) & (strRegReplaceDF.register_nbr.isNotNull())).select(strRegReplaceDF.register_nbr,strRegReplaceDF.loc_id,strRegReplaceDF.register_dept_name,strRegReplaceDF.create_id,strRegReplaceDF.create_dttm,strRegReplaceDF.update_id,strRegReplaceDF.update_dttm)

RfmtMergeDF = RfmtOutDF.union(RfmtUnUsed0DF.union(RfmtUnUsed1DF))# \
#.select(strRegReplaceDF.register_nbr,strRegReplaceDF.loc_id,strRegReplaceDF.register_dept_name,
#RfmtM99DF1.create_id,RfmtM99DF1.create_dttm,RfmtM99DF1.update_id,RfmtM99DF1.update_dttm)


RfmtMergeDF.show()

#Output File 10 - str_register_replace_ascii.pipe_delim_new:
RfmtMergeDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+StrRegReplace_OUTFile)

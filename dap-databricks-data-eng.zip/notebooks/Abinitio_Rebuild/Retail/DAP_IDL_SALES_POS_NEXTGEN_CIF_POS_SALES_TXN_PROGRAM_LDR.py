# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove("PAR_MNT_POINT")

# COMMAND ----------

# DBTITLE 1,Setup
### NOTE: Type NUL or ␀ for \x00, Type SOH or  for \x01 or type your own delimiter e.g , | etc.

from pyspark.sql.functions import *
from pyspark.sql.types import *
import re

#dbutils.widgets.text("PAR_MNT_POINT", "")            # /mnt/wrangled
dbutils.widgets.text("PAR_INPUT_FILE_PATH", "")      # retail/retail_sales/staging/edw_idl_ngenpos_workstationloc/20220121054422 NOTE: This could be any location. 
dbutils.widgets.text("PAR_INPUT_FILE", "")           # edw_idl_ngenpos_workstationloc_20220207023508.dat
#dbutils.widgets.text("PAR_NUM_COLS", "")             # 3
dbutils.widgets.text("PAR_DELIMITER", "")            # Type NUL or ␀ for \x00, Type SOH or  for \x01 or type your own delimiter e.g , | etc. 
dbutils.widgets.text("PAR_PARQUET_OUT_LOCATION", "") # retail/retail_sales/staging/edw_idl_ngenpos_workstationloc/20220121054422 NOTE: This could be any location. 
#dbutils.widgets.text("PAR_OUTPUT_SCHEMA", "")        # pcms_TransactionType,pcms_WorkstationLocation,wag_RFN
dbutils.widgets.text("PAR_RJECT_REC_PATH", "")        # path for the reject record

var_Input_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH')
var_Input_File = var_Input_File_Path + '/' + dbutils.widgets.get('PAR_INPUT_FILE')
var_Parquet_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_PARQUET_OUT_LOCATION')
var_Reject_File = mountPoint + '/' + dbutils.widgets.get('PAR_RJECT_REC_PATH')

#var_Input_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_INPUT_FILE_PATH')
 
#var_Converted_File_Path = var_Input_File_Path + '/' + 'converted_delimited' 
#var_Converted_File = var_Converted_File_Path + '/' + 'MULTI_ROW_' + dbutils.widgets.get('PAR_INPUT_FILE')

#var_Parquet_File_Path = mountPoint + '/' + dbutils.widgets.get('PAR_PARQUET_OUT_LOCATION')
#var_num_cols = int(dbutils.widgets.get('PAR_NUM_COLS'))


var_Get_Delimiter = dbutils.widgets.get('PAR_DELIMITER').strip()
# var_Delimiter = dbutils.widgets.get('PAR_DELIMITER').strip()

if var_Get_Delimiter == '␀' or var_Get_Delimiter == 'NUL': #'\x00':
    var_Delimiter = "Default_Nul_character"
elif var_Get_Delimiter == 'SOH' or var_Get_Delimiter == '': #\x01':
    var_Delimiter = ''
elif var_Get_Delimiter == '':
    dbutils.notebook.exit("No delimiter specified. \n Type NUL or ␀ for '\\x00', Type SOH or  for '\\x01' or type your own delimiter e.g , | etc.")
else:
    var_Delimiter = var_Get_Delimiter

# NOTE: by default nullable is being set to True in the output schema below
#       If you set it to False then it does a null check for all the columns.
#       For data set with millions of rows it ipacts the performance 
#       Since this conversion is for sanity testing so it's ok to set it to True

#var_Output_Schema = StructType(list(map(lambda fl : StructField(fl.strip(), StringType(),True), dbutils.widgets.get('PAR_OUTPUT_SCHEMA').split(',')))) 

# print(var_File_Path)
print('Input file is                          : ', var_Input_File)
#print('Converted multi line delimited file is : ', var_Converted_File)
print('Converted Parquet file location is     : ', var_Parquet_File_Path)
#print('Number of columns in file              : ', var_num_cols)
#print('Parquet schema for converted file      : ', var_Output_Schema)
print('Delimiter                              : ', var_Delimiter)
print('-----', bytes(var_Delimiter, 'utf-8'), '-----', var_Delimiter)
print('Reject path is                          : ', var_Reject_File)



# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
#   if  len(lst1) > 6 and lst[6] == 'INSERT':
#     lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

def checkbad(val):
  key_list = val.split("\x01")
  val_len = len(key_list)
  
  if val_len > 9:
    return True
  
#   if 'INSERT' in key_list[6]:
#     if val_len != 43 :
#       return True
#   elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
#     if val_len != 44:
#       return True
  else:
    if val_len != 9:
      return True

# COMMAND ----------

# Read files
in_text = spark.read.text(var_Input_File)


#in_text = in_text.withColumn("value", regexp_replace(in_text.value, '', '|')) #.drop("value")
#display(in_text)

in_text = in_text.rdd

# # write bad data
rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  display(df_junk)
  df_junk.write.mode('overwrite').parquet(var_Reject_File)

# COMMAND ----------

fieldList = ['row_length',
    'sales_txn_id',
    'sales_txn_dt',
    'sales_ord_src_type',
    'sales_txn_type',
    'src_sys_cd',
    'prog_type_cd',
    'prog_acct_nbr',
    'prog_cust_id',
    'null_Col'         
    ]

# COMMAND ----------

#split and add schema
col_len = 9

rd1 = in_text.map(lambda rw: rw[0].split("\x01")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
#rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 44
#print(f"Bad records count {rd_bad.count()}") # != 28


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)
df = df.drop("row_length", "null_Col")
display(df)

# COMMAND ----------

df.write.mode('overwrite').parquet(var_Parquet_File_Path)

# COMMAND ----------

# DBTITLE 1,Multi Row Delimited ==> Parquet
# """ Convert to parquet"""
#    Handling NUL delimiter since it cannot be typed/copied in the browser
# if var_Delimiter == 'Default_Nul_character':
#     df = spark.read.format("csv").option("delimiter", "\x00").option("inferSchema","true").schema(var_Output_Schema).load(var_Converted_File)
# else:
#     df = spark.read.format("csv").option("delimiter", var_Delimiter).option("inferSchema","true").schema(var_Output_Schema).load(var_Converted_File)

# df.write.format("parquet").mode("overwrite").save(var_Parquet_File_Path)
# print("Parquet file:", var_Parquet_File_Path)
# df.count() 

# COMMAND ----------

# df = spark.read.parquet(var_Parquet_File_Path)
# print("Parquet file:", var_Parquet_File_Path)
# df.take(3)
# df.printSchema()

# COMMAND ----------


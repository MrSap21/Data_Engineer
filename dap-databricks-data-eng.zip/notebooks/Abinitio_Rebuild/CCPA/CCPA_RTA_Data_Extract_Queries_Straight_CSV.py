# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
L4_mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_L4_Customer_Dim",60)



# COMMAND ----------

from pyspark.sql.types import StringType
import pandas as pd


# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID", "11111")

# dbutils.widgets.text("PAR_DB_TKT_NUMBR", "WJEKRKGSZY")
# dbutils.widgets.text("PAR_DB_SNFK_DB_MARKT", "UAT_MARKETING")
# dbutils.widgets.text("PAR_DB_SNFK_DB_DIGTL", "UAT_DIGITAL")

# dbutils.widgets.text("PAR_DB_SNFK_WH", "UAT_HISTORY_MIGRATION_SECONDARY_FR_WH")
# dbutils.widgets.text("PAR_DB_SNFK_DB_RETL", "UAT_RETAIL")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME", "CCPA.CCPA_CUSTOMER_REQUEST_LIST")

# dbutils.widgets.text("PAR_DB_SNFK_DB_MASTR", "UAT_MASTER_DATA")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME_CUST", "CUSTOMER.CUSTOMER")

# dbutils.widgets.text("PAR_DB_OUTPUT_PATH", "master_data/customer/ccpa/output/encrypted")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME", "WJEKRKGSZY_encrypted")

# COMMAND ----------

##########################Test#########################
# databasename = intidldb01
# viewname =intidldb01
# pscviewname =intedwdb01
# requestdb = intidldb01
# hivedb = dae_work
##########################################################

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")

TKT_NUM = dbutils.widgets.get("PAR_DB_TKT_NUMBR")
#CUSTOMER REQUEST LIST TABLE
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB_RETL = dbutils.widgets.get("PAR_DB_SNFK_DB_RETL")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")

#CUSTOMER TABLE
SNFL_DB_MASTR = dbutils.widgets.get("PAR_DB_SNFK_DB_MASTR")
SNFL_TBL_NAME_CUST = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME_CUST")

#SNOWFLAKE DB
SNFL_DB_DIGTL = dbutils.widgets.get("PAR_DB_SNFK_DB_DIGTL")
SNFL_DB_MARKT = dbutils.widgets.get("PAR_DB_SNFK_DB_MARKT")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")


L4_PATH = 'l4_customer_dim'
L4_LOAD_URI = '/mnt/{0}/{1}/'.format(L4_PATH,L4_PATH)


OUT_FILEPATH_CSV = mountPoint + '/'+ OUTPUT_PATH  + '/' + OUTPUT_FILENAME
print(OUT_FILEPATH_CSV)
print(L4_LOAD_URI)


# COMMAND ----------

# MAGIC %run /Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB_RETL $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

##########################Request########################################################################
#Read Requests 
from pyspark.sql import *
from pyspark.sql.functions import *



#Added task id - 10 June
qry_req_list = "select req.tkt_nbr, req.TASK_ID, cust.cust_sk, req.cust_src_id, req.src_sys_cd, req.lv_flag, req.tkt_open_dt, req.cust_first_name, req.cust_middle_name, req.cust_last_name, req.cust_eml_addr, req.edw_tkt_receive_dt from {0}.{1} req left outer join   {2}.{3} cust on cust.cust_src_id = req.cust_src_id and cust.src_sys_cd = req.src_sys_cd where  req.edw_reqst_complete_dt is NULL and edw_tkt_complete_dt is NULL and req.reqst_type_cd= 'RTA' and req.tkt_nbr='{4}'".format(SNFL_DB_RETL, SNFL_TBL_NAME, SNFL_DB_MASTR, SNFL_TBL_NAME_CUST, TKT_NUM)

#qry_req_list = "select req.tkt_nbr, req.TASK_ID, cust.cust_sk, req.cust_src_id, req.src_sys_cd, req.lv_flag, req.tkt_open_dt, req.cust_first_name, req.cust_middle_name, req.cust_last_name, req.cust_eml_addr, req.edw_tkt_receive_dt from {0}.{1} req left outer join   {2}.{3} cust on cust.cust_src_id = req.cust_src_id and cust.src_sys_cd = req.src_sys_cd where  req.reqst_type_cd= 'RTA' and req.tkt_nbr='{4}'".format(SNFL_DB_RETL, SNFL_TBL_NAME, SNFL_DB_MASTR, SNFL_TBL_NAME_CUST, TKT_NUM)


df_req_list=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_req_list) \
   .load()

df_req_list = df_req_list.withColumn("cust_first_name",   when ((col("cust_first_name") == '') | (col("cust_first_name").isNull()), lit(str("ĭĻÃq"))).otherwise(col("cust_first_name")))\
                            .withColumn("cust_middle_name", when ((col("cust_middle_name") == '') | (col("cust_middle_name").isNull()), lit(str("ĭĻÃq"))).otherwise(col("cust_middle_name")))\
                            .withColumn("cust_last_name", when ((col("cust_last_name") == '') | (col("cust_last_name").isNull()), lit(str("ĭĻÃq"))).otherwise(col("cust_last_name")))\
                            .withColumn("cust_eml_addr", when ((col("cust_eml_addr") == '') | (col("cust_eml_addr").isNull()), lit(str("ĭĻÃq"))).otherwise(col("cust_eml_addr")))

df_req_list = df_req_list.withColumn("CUST_SK", df_req_list["CUST_SK"].cast(StringType()))


                       

###########################################################################################

# COMMAND ----------

var_spl_rep_dt_tbl = SNFL_DB_RETL+'.CCPA.SPL_STATE_COMP_REPORT_DATE'
qry_rep_dt = "select distinct spl.state_cd, spl.report_fixed_dt, spl.report_all_days from {2} spl left outer join   {0}.{1} req on lower(spl.state_cd) = lower(req.cust_state_cd)  where  req.edw_reqst_complete_dt is NULL and req.edw_tkt_complete_dt is NULL and req.reqst_type_cd= 'RTA' and req.tkt_nbr='{3}'".format(SNFL_DB_RETL, SNFL_TBL_NAME, var_spl_rep_dt_tbl , TKT_NUM)

df_qry_rep_dt=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_rep_dt) \
   .load()



df_qry_rep_dt = df_qry_rep_dt.withColumn("NUM_DAYS",   when (lower(df_qry_rep_dt.STATE_CD) == 'ca', lit(datediff(current_date(),df_qry_rep_dt.REPORT_FIXED_DT))) 
                                                       .when (lower(df_qry_rep_dt.STATE_CD) != 'ca', lit(datediff(current_date(),df_qry_rep_dt.REPORT_ALL_DAYS)))
                                                        .otherwise(lit('0')))

df_qry_rep_dt.show()

var_rep_dys = df_qry_rep_dt.select("NUM_DAYS").rdd.map(lambda row : row[0]).collect()
# ec_custsrcid_2 = df_req_list.select("CUST_SK").where(df_req_list.SRC_SYS_CD == "EC").collect()

var_rep_dys = ''.join(var_rep_dys)

#var_rep_days = '0'

if var_rep_dys == None or var_rep_dys == '' :
    var_rep_days = '0'
    
else:
    var_rep_days = var_rep_dys
    
    
print(var_rep_days)
print(var_rep_dys)



# COMMAND ----------

df_ec_custsrcid = df_req_list.filter(df_req_list.SRC_SYS_CD == 'EC')
# df_ec_custsrcid.show()

df_lyt_custsrcid = df_req_list.filter(df_req_list.SRC_SYS_CD == 'LR')
# df_lyt_custsrcid.show()

df_cdi_custsrcid = df_req_list.filter(df_req_list.SRC_SYS_CD == 'CDI')
# df_cdi_custsrcid.show()

df_psc_custsrcid = df_req_list.filter(df_req_list.SRC_SYS_CD == 'PSC')
# df_psc_custsrcid.show()



# COMMAND ----------

#Getting Request Date

df_req_open_dt = df_req_list.filter(df_req_list.TKT_NBR == TKT_NUM) \
                            .select ("TKT_OPEN_DT").distinct()  #.collect()  #.rdd.flatMap(lambda r: r).collect()
df_req_open_dt = df_req_open_dt.withColumn("TKT_OPEN_DT", df_req_open_dt["TKT_OPEN_DT"].cast(StringType()))

list_req_open_dt = [row[0] for row in df_req_open_dt.select('TKT_OPEN_DT').collect()]
req_open_dt = ''
for x in list_req_open_dt:
  if x == None or x == '' :
    req_open_dt = 'NULL'
  else:
    req_open_dt +="'"+x+"'"
  #strg +=','+x
#c_cust_scr_id = ec_cust_scr_id.replace(",",'',1)
print (req_open_dt)



# COMMAND ----------

#Getting EC cust_src_id list

list_ec_cust_src_id = [row[0] for row in df_ec_custsrcid.select('cust_src_id').distinct().collect()]
ec_cust_scr_id = ''
if not list_ec_cust_src_id:
  ec_cust_scr_id = 'NULL'
else:
  for x in list_ec_cust_src_id:
    if x == None or x == '' :
      ec_cust_scr_id = 'NULL'  
    else:
      ec_cust_scr_id +=','+"'"+x+"'"
  #strg +=','+x
ec_cust_scr_id = ec_cust_scr_id.replace(",",'',1)
print (ec_cust_scr_id)

#Getting lyt cust_src_id list
list_lyt_cust_src_id = [row[0] for row in df_lyt_custsrcid.select('cust_src_id').distinct().collect()]
lyt_cust_scr_id = ''
if not list_lyt_cust_src_id:
  lyt_cust_scr_id = 'NULL'
else:
  for x in list_lyt_cust_src_id:
    if x == None or x == '' :
      lyt_cust_scr_id = 'NULL'  
    else:
      lyt_cust_scr_id +=','+"'"+x+"'"
  #strg +=','+x
lyt_cust_scr_id = lyt_cust_scr_id.replace(",",'',1)
print (lyt_cust_scr_id)

#Getting mid cust_src_id list for L4_CUSTOMER_DIM
list_cdi_cust_src_id = [row[0] for row in df_cdi_custsrcid.select('cust_src_id').distinct().collect()]
cdi_cust_scr_id = ''
if not list_lyt_cust_src_id:
  cdi_cust_scr_id = 'NULL'
else:
  for x in list_cdi_cust_src_id:
    if x == None or x == '' :
      cdi_cust_scr_id = 'NULL'  
    else:
      cdi_cust_scr_id +=','+"'"+x+"'"
  #strg +=','+x
cdi_cust_scr_id = cdi_cust_scr_id.replace(",",'',1)
print (cdi_cust_scr_id)

#Getting cust_sk list

list_cust_sk = [row[0] for row in df_req_list.select ('cust_sk').distinct().collect()]
#print (list_cust_sk)

lst_cust_sk = ''

for x in list_cust_sk:
  if x == None :
    print('x = None')
#     lst_cust_sk = 'NULL,'
  else:
    print('x = ' + x)
    lst_cust_sk +=','+"'"+x+"'"
  #strg +=','+x
  print('lst_cust_sk: ' + lst_cust_sk)

  
lst_cust_sk = lst_cust_sk.replace(",",'',1)
print (lst_cust_sk)


# COMMAND ----------

## setting df_req_list to pandas

df_req_list = df_req_list.toPandas()

# COMMAND ----------

####################Customer data #######################################################################################
#Customer data

var_cust_name = SNFL_DB_MASTR+'.CUSTOMER.CUSTOMER'
var_cust_addr = SNFL_DB_MASTR+'.CUSTOMER.CUSTOMER_ADDRESS'
var_cust_contact = SNFL_DB_MASTR+'.CUSTOMER.CUSTOMER_CONTACT_CHANNEL'


qry_cust_name = """
SELECT cust_SK AS cust_sk
	,CASE WHEN first_name IS NULL THEN '' ELSE first_name END AS Name_first_name
	,CASE WHEN middle_name IS NULL THEN '' ELSE middle_name END AS Name_middle_name
	,CASE WHEN last_name IS NULL THEN '' ELSE last_name END AS Name_last_name
FROM {0}
WHERE cust_sk IN ({1}) AND edw_rec_end_dt >= to_date({2}, 'YYYY-MM-DD') - {3}""".format(var_cust_name, lst_cust_sk, req_open_dt, var_rep_days)



df_cust_name=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_cust_name) \
   .load()

# df_cust_name.show()                         

qry_cust_dob = "select  cust_SK as cust_sk, brth_dt  as birth_date, (case when trim(gndr_cd) = 'M' then 'Male' when trim(gndr_cd) = 'F' then 'Female' when trim(gndr_cd) in ('U', 'Unknown', 'UNKNOWN', 'unknown') then '' when trim(gndr_cd) = 'Male' then 'Male' when trim(gndr_cd) = 'Unknown' then 'Unknown' else ' ' end) as gender, max(EDW_UPDATE_DTTM) as EDW_UPDATE_DTTM from {0} where cust_sk in ({1}) and edw_rec_end_dt>=to_date({2}, 'YYYY-MM-DD') - {3} and brth_dt is not NULL and gndr_cd is not NULL group by cust_sk,birth_date,gender".format(var_cust_name, lst_cust_sk, req_open_dt, var_rep_days)

df_cust_dob=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_cust_dob) \
   .load()

# df_cust_dob.show()

  
qry_cust_addr = """
SELECT cust_SK AS cust_sk
	,CASE WHEN addr_line_1 IS NULL THEN 'ĭĻÃq' ELSE addr_line_1 END AS postal_address_addr_line_1
    ,CASE WHEN addr_line_2 IS NULL THEN '' ELSE addr_line_2 END AS postal_address_addr_line_2
    ,CASE WHEN city IS NULL THEN '' ELSE city END AS postal_address_city
    ,CASE WHEN county IS NULL THEN '' ELSE county END AS postal_address_county
    ,CASE WHEN state_cd IS NULL THEN '' ELSE state_cd END AS postal_address_state_cd
    ,CASE WHEN zip_cd_5 IS NULL THEN '' ELSE zip_cd_5 END AS postal_address_zip_cd_5
    ,CASE WHEN zip_cd_4 IS NULL THEN '' ELSE zip_cd_4 END AS postal_address_zip_cd_4
FROM {0}
WHERE cust_sk IN ({1}) AND edw_rec_end_dt >= to_date({2}, 'YYYY-MM-DD') - {3}
""".format(var_cust_addr, lst_cust_sk, req_open_dt, var_rep_days) 


df_cust_addr=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_cust_addr) \
   .load()


                 
# df_cust_addr.show()


qry_cust_cont= "select  cust_SK as cust_sk, (case when cntc_chnnl_type_cd= 'E' and comm_val NOT in ('¼¥9\"ú;ñ', 'ż¯Ľşø;£', '?ıT¬Â¦%') then comm_val else '' end) as email, (case when cntc_chnnl_type_cd in('H','C','1') then comm_val  else '' end) as phone_number from {0} where cust_sk in ({1}) and edw_rec_end_dt>=to_date({2}, 'YYYY-MM-DD') - {3}".format(var_cust_contact, lst_cust_sk, req_open_dt, var_rep_days)

df_cust_cont=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_cust_cont) \
   .load()

# df_cust_cont.show()

#Joining dataframe df_cust_name and df_cust_addr
join_df_cust = df_cust_name.join(df_cust_dob, df_cust_name.CUST_SK == df_cust_dob.CUST_SK, "full" ).drop(df_cust_dob.CUST_SK )

#Joining dataframe df_cust_name and df_cust_addr
join_df_cust = join_df_cust.join(df_cust_addr, join_df_cust.CUST_SK == df_cust_addr.CUST_SK, "full" ).drop(df_cust_addr.CUST_SK)

#Joining dataframe df_cust_cont to the above result dataframe join_df_cust
join_df_cust = join_df_cust.join(df_cust_cont, join_df_cust.CUST_SK == df_cust_cont.CUST_SK, "full" ).drop(df_cust_cont.CUST_SK)


join_df_cust = join_df_cust.select ("CUST_SK", "NAME_FIRST_NAME", "NAME_MIDDLE_NAME", "NAME_LAST_NAME", "BIRTH_DATE", "GENDER", "POSTAL_ADDRESS_ADDR_LINE_1", "POSTAL_ADDRESS_ADDR_LINE_2", "POSTAL_ADDRESS_CITY", "POSTAL_ADDRESS_COUNTY", "POSTAL_ADDRESS_STATE_CD", "POSTAL_ADDRESS_ZIP_CD_5", "POSTAL_ADDRESS_ZIP_CD_4", "EMAIL", "PHONE_NUMBER" )



join_df_cust = join_df_cust.withColumn("Name_first_name",   when ((col("Name_first_name") == '') | (col("Name_first_name").isNull()), lit(str("ĭĻÃq"))).otherwise(col("Name_first_name")))\
                            .withColumn("Name_middle_name", when ((col("Name_middle_name") == '') | (col("Name_middle_name").isNull()), lit(str("ĭĻÃq"))).otherwise(col("Name_middle_name")))\
                            .withColumn("Name_last_name", when ((col("Name_last_name") == '') | (col("Name_last_name").isNull()), lit(str("ĭĻÃq"))).otherwise(col("Name_last_name")))\
              .withColumn("postal_address_addr_line_1",   when ((col("postal_address_addr_line_1") == '') | (col("postal_address_addr_line_1").isNull()), lit(str("ĭĻÃq"))).otherwise(col("postal_address_addr_line_1")))\
              .withColumn("postal_address_addr_line_2", when ((col("postal_address_addr_line_2") == '') | (col("postal_address_addr_line_2").isNull()), lit(str("ĭĻÃq"))).otherwise(col("postal_address_addr_line_2")))\
                  .withColumn("postal_address_city", when ((col("postal_address_city") == '') | (col("postal_address_city").isNull()), lit(str("ĭĻÃq"))).otherwise(col("postal_address_city")))\
                  .withColumn("postal_address_county", when ((col("postal_address_county") == '') | (col("postal_address_county").isNull()), lit(str("ĭĻÃq"))).otherwise(col("postal_address_county")))\
                  .withColumn("postal_address_zip_cd_5", when ((col("postal_address_zip_cd_5") == '') | (col("postal_address_zip_cd_5").isNull()), lit(str("ĭĻÃq"))).otherwise(col("postal_address_zip_cd_5")))\
                  .withColumn("postal_address_zip_cd_4", when ((col("postal_address_zip_cd_4") == '') | (col("postal_address_zip_cd_4").isNull()), lit(str("ĭĻÃq"))).otherwise(col("postal_address_zip_cd_4")))\
                  .withColumn("EMAIL", when ((col("EMAIL") == '') | (col("EMAIL").isNull()), lit(str("ĭĻÃq"))).otherwise(col("EMAIL")))\
                  .withColumn("PHONE_NUMBER", when ((col("PHONE_NUMBER") == '') | (col("PHONE_NUMBER").isNull()), lit(str("ĭĻÃq"))).otherwise(col("PHONE_NUMBER")))
        

join_df_cust = join_df_cust.toPandas()

# display(join_df_cust)

# COMMAND ----------

#########################Sales summary ##############################################################
##*** Sales txn summary query***
#sale new  12/18

# from pyspark.sql import functions as F
# from operator import add
# from functools import reduce

var_sales_trans =  SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION'
var_sales_trans_det  = SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION_DETAIL'
var_ecom_order  = SNFL_DB_DIGTL+'.ECOM.ECOM_ORDER_ITEM_RETURN'
var_product  = SNFL_DB_MASTR+'.PRODUCT.PRODUCT'
var_ecom_product  = SNFL_DB_DIGTL+'.ECOM.ECOM_PRODUCT'
var_sales_trans_prog =  SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION_PROGRAM'
var_product_hierarchy = SNFL_DB_MASTR+'.PRODUCT.PRODUCT_HIERARCHY'



#sale new  2/6 opstudy filters
sales_qry = "select r.cust_src_id,cast(r.total as decimal(10,2) ) as sales_total, r.ind as sales_ind from (select z.cust_src_id, sum(z.Total_sales) as total, 'EC_Purchases' as ind from ( select a.src_cust_id as cust_src_id, b.sales_txn_id, a.src_cust_id, b.sales_txn_dt, b.selling_price_dlrs as Total_sales, b.unit_qty,(case when d.prod_sk = '-1' and b.sales_ord_src_type = 'P' then 'Photo Item' when d.prod_sk = '-1' and  b.sales_ord_src_type = 'S' then 'Self Service Item' when e.prod_desc is NULL and b.sales_ord_src_type = 'S' then 'Self Service Item' else e.prod_desc end) as prod_desc from (select * from {0} where  src_cust_id in ({7}) and sales_txn_dt > to_date({9},  'YYYY-MM-DD') - {10} and sales_txn_dt <= to_date({9},  'YYYY-MM-DD') and src_sys_cd = 'EC' and sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) a inner join (select * from {1} where src_sys_cd = 'EC' AND sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) b on a.sales_txn_id = b.sales_txn_id and b.src_sys_cd = a.src_sys_cd AND b.sales_ord_src_type = a.sales_ord_src_type and a.sales_txn_dt = b.sales_txn_dt inner join (select * from {3} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31')d on b.prod_sk = d.prod_sk inner join (select * from {4} where end_dt = '9999-12-31') e on d.ecom_prod_id = e.ecom_prod_id inner join (select * from {6} where src_sys_cd = 'EC' and  edw_rec_end_dt = '9999-12-31'and ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74','80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )f on f.prod_sk = d.prod_sk ) z group by cust_src_id, Ind union all select z.cust_src_id, sum(z.Total_sales) as total, 'EC_Returns' as Ind from (select a.src_cust_id as cust_src_id, cast(c.create_dttm as DATE) as return_reported_date, c.qty_to_return, c.tot_return_dlrs as total_sales, (case when d.prod_sk = '-1' and  b.sales_ord_src_type = 'P' then 'Photo Item' when d.prod_sk = '-1' and  b.sales_ord_src_type = 'S' then 'Self Service Item' when e.prod_desc is NULL and b.sales_ord_src_type = 'S' then 'Self Service Item'  else e.prod_desc end) as prod_desc from (select * from {0} where  src_cust_id in ({7}) and sales_txn_dt > to_date({9},  'YYYY-MM-DD') - {10} and sales_txn_dt <= to_date({9},  'YYYY-MM-DD') and src_sys_cd = 'EC' and sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) a inner join (select * from {1} where src_sys_cd = 'EC' AND sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) b on a.sales_txn_id = b.sales_txn_id and b.src_sys_cd = a.src_sys_cd AND b.sales_ord_src_type = a.sales_ord_src_type and a.sales_txn_dt = b.sales_txn_dt inner join (select * from {2} where cast(create_dttm as DATE) > to_date({9},  'YYYY-MM-DD') -{10} and cast(create_dttm as DATE) <= to_date({9} , 'YYYY-MM-DD')) c on c.ord_src_type_cd = b.sales_ord_src_type and c.return_item_id = b.ord_item_id and c.ord_id = b.sales_txn_id inner join (select * from {3} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31')d on b.prod_sk = d.prod_sk inner join (select * from {4} where end_dt = '9999-12-31') e on d.ecom_prod_id = e.ecom_prod_id inner join (select * from {6} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31'and ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915', '74') )f on f.prod_sk = d.prod_sk )z group   by cust_src_id, Ind union all select z.cust_src_id, sum(z.Total_sales)as total , 'POS' as Ind from ( select X.Purchase_Date, X.UPC_Desc, x.cust_src_id,Sum (X.Total_Qty) as Total_Qty, SUM (X.Total_Sales) as Total_Sales, sum(X.Return_Flag) as returnss from (select d.sales_txn_dt as Purchase_Date,a.prog_cust_id as cust_src_id,(CASE WHEN d.wag_coup_cd in ('C', 'D') THEN (d.upc_desc || ' (' || 'W coupon)')WHEN d.mfg_coup_cd <> '--' THEN  (d.upc_desc || ' (' || 'Mfg coupon)') ELSE d.upc_desc END ) as UPC_Desc, CASE WHEN d.wag_coup_cd <> 'B' or d.return_ind = 'Y' THEN d.unit_qty ELSE 0 END as Total_Qty, selling_price_dlrs as Total_Sales,case when d.return_ind= 'Y' THEN 1 ELSE 0 END  as Return_Flag from ( select * from {5} where prog_cust_id in ({8}) and src_sys_cd = 'POS' and date(sales_txn_dt , 'YYYY-MM-DD') > to_date({9},  'YYYY-MM-DD') -{10} and date(sales_txn_dt , 'YYYY-MM-DD') <= to_date({9} , 'YYYY-MM-DD')) a inner join (select * from {0} where src_sys_cd = 'POS' and sales_txn_dt > to_date({9} , 'YYYY-MM-DD')-{10}) b on a.sales_txn_dt = b.sales_txn_dt and a.sales_txn_id = b.sales_txn_id inner join (select * from {1} where sales_txn_dt > to_date({9},  'YYYY-MM-DD') - {10} and sales_txn_dt <= to_date({9},  'YYYY-MM-DD') and src_sys_cd = 'POS') d on b.sales_txn_dt = d.sales_txn_dt and b.sales_txn_id = d.sales_txn_id and b.src_sys_cd = d.src_sys_cd inner join (select * from {6} where src_sys_cd = 'POS' and edw_rec_end_dt = '9999-12-31'and ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73','74', '80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )f on f.prod_sk = d.prod_sk where b.txn_type IN ( '10' , '11' , '12' , '13' , '14' ,'15' , '16' , '25' ) and  b.POST_VOID_STATUS_CD = '--' and  b.TXN_INCOMPLETE_IND = 'N' and  b.TRAINING_TXN_IND = 'N' and b.sales_txn_dt = d.sales_txn_dt and b.sales_txn_id = d.sales_txn_id and d.rx_nbr is null and d.unit_qty > 0  and d.item_void_cd = '--' ) x group by purchase_date, upc_desc, cust_src_id )z group by cust_src_id, ind)r".format(var_sales_trans, var_sales_trans_det, var_ecom_order, var_product, var_ecom_product, var_sales_trans_prog, var_product_hierarchy, ec_cust_scr_id,lyt_cust_scr_id, req_open_dt, var_rep_days)
                     

  
df_cust_sel=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",sales_qry) \
   .load()


df_cust_sel = df_cust_sel\
                    .withColumn("EC_PURCHASES", when ((col("SALES_IND") == 'EC_Purchases'), col("SALES_TOTAL")).otherwise(0))\
                    .withColumn("EC_RETURN", when ((col("SALES_IND") == 'EC_Returns'), col("SALES_TOTAL")).otherwise(0))\
                    .withColumn("POS", when ((col("SALES_IND") == 'POS'), col("SALES_TOTAL")).otherwise(0))
                    

df_cust_sel = df_cust_sel.select(sum(col("EC_PURCHASES") + col("POS") - col("EC_RETURN")).alias('SALES_TOTAL'))
df_cust_sel = df_cust_sel.withColumn("SALES_IND", lit('Total_Ind')).toPandas()


#display(df_cust_sel)

#sale tax ---Tax summary query 2/6 opstudy filters

sales_tax_qry = "select r.cust_src_id, cast(r.total as decimal(10,2) ) as sales_tx_total, r.ind as sales_tx_ind from ( select x.cust_src_id, sum(tax) as total, 'ECOM Tax' as ind from ( select distinct z.cust_src_id,z.txn_id, z.tax, 'ECOM Tax' as ind from ( select b.sales_txn_id as txn_id, a.src_cust_id as cust_src_id, b.sales_txn_dt, b.selling_price_dlrs, b.unit_qty,a.txn_tot_tax_dlrs as tax,(case when d.prod_sk = '-1' and b.sales_ord_src_type = 'P' then 'Photo Item' when d.prod_sk = '-1' and  b.sales_ord_src_type = 'S' then 'Self Service Item' when e.prod_desc is NULL and b.sales_ord_src_type = 'S' then 'Self Service Item' else e.prod_desc end) as prod_desc from (select * from {0} where  src_cust_id in ({7}) and sales_txn_dt > to_date({9}, 'YYYY-MM-DD') - {10} and sales_txn_dt <= to_date({9}, 'YYYY-MM-DD') and src_sys_cd = 'EC' and sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) a inner join (select * from {1} where src_sys_cd = 'EC' AND sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) b on a.sales_txn_id = b.sales_txn_id and b.src_sys_cd = a.src_sys_cd AND b.sales_ord_src_type = a.sales_ord_src_type and a.sales_txn_dt = b.sales_txn_dt inner join (select * from {2} where cast(create_dttm as DATE) > to_date({9}, 'YYYY-MM-DD') -{10} and cast(create_dttm as DATE) <=to_date({9}, 'YYYY-MM-DD')) c on c.ord_src_type_cd = b.sales_ord_src_type and c.return_item_id = b.ord_item_id and c.ord_id = b.sales_txn_id inner join (select * from {3} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31')d on b.prod_sk = d.prod_sk inner join (select * from {4} where end_dt = '9999-12-31') e on d.ecom_prod_id = e.ecom_prod_id inner join (select * from {6} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31' and  ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73','74', '80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )f on f.prod_sk = d.prod_sk) z group by z.cust_src_id,z.txn_id, Ind, tax ) x group by x.cust_src_id, ind union all select x.cust_src_id, sum(tax), 'POS Tax' as Ind from ( select distinct z.cust_src_id,z.txn_id, z.tax, 'POS Tax' as Ind from (select x.cust_src_id, X.Purchase_Date, X.UPC_Desc,x.txn_id, Sum (X.Total_Qty) as Total_Qty,SUM (X.Total_Sales) as Total_Sales, x.tax, sum(X.Return_Flag) as returnss from (select a.prog_cust_id as cust_src_id, d.sales_txn_dt as Purchase_Date, d.sales_txn_id as txn_id,(CASE WHEN d.wag_coup_cd in ('C', 'D') THEN (d.upc_desc || ' (' || 'W coupon)') WHEN d.mfg_coup_cd <> '--' THEN  (d.upc_desc || ' (' || 'Mfg coupon)') ELSE d.upc_desc END ) as UPC_Desc, CASE WHEN d.wag_coup_cd <> 'B' or d.return_ind = 'Y' THEN d.unit_qty ELSE 0 END as Total_Qty, selling_price_dlrs as Total_Sales, b.txn_tot_tax_dlrs as tax, case when d.return_ind= 'Y' THEN 1 ELSE 0 END  as Return_Flag from( select * from {5} where prog_cust_id in ({8}) and src_sys_cd = 'POS' and date(sales_txn_dt , 'YYYY-MM-DD') > to_date({9}, 'YYYY-MM-DD') - {10} and date(sales_txn_dt , 'YYYY-MM-DD') <= to_date({9}, 'YYYY-MM-DD') ) a inner join (select * from {0} where src_sys_cd = 'POS' and sales_txn_dt > to_date({9}, 'YYYY-MM-DD')-{10} and sales_txn_dt <= to_date({9}, 'YYYY-MM-DD')) b on a.sales_txn_dt = b.sales_txn_dt and a.sales_txn_id = b.sales_txn_id inner join (select * from {1} where sales_txn_dt > to_date({9}, 'YYYY-MM-DD') - {10} and sales_txn_dt <= to_date({9}, 'YYYY-MM-DD') and src_sys_cd = 'POS') d on b.sales_txn_dt = d.sales_txn_dt and b.sales_txn_id = d.sales_txn_id and b.src_sys_cd = d.src_sys_cd inner join (select * from {6} where src_sys_cd = 'POS' and edw_rec_end_dt = '9999-12-31' and  ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74','80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )f  on f.prod_sk = d.prod_sk where b.txn_type IN ( '10' , '11' , '12' , '13' , '14' ,'15' , '16' , '25' ) and  b.POST_VOID_STATUS_CD = '--' and  b.TXN_INCOMPLETE_IND = 'N' and  b.TRAINING_TXN_IND = 'N' and b.sales_txn_dt = d.sales_txn_dt and b.sales_txn_id = d.sales_txn_id and d.rx_nbr is null and d.unit_qty > 0 and d.item_void_cd = '--' ) x group by purchase_date, upc_desc, tax, cust_src_id, txn_id )z  group by z.cust_src_id,z.txn_id, Ind, tax ) x group by x.cust_src_id, ind ) r".format(var_sales_trans,var_sales_trans_det,var_ecom_order,var_product,var_ecom_product,var_sales_trans_prog,var_product_hierarchy,ec_cust_scr_id,lyt_cust_scr_id, req_open_dt, var_rep_days)

                                                
df_cust_sel_tx=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",sales_tax_qry) \
   .load()


df_cust_sel_tx = df_cust_sel_tx\
                    .withColumn("ECOM_TAX", when ((col("SALES_TX_IND") == 'ECOM Tax'), col("SALES_TX_TOTAL")).otherwise(0))\
                    .withColumn("POS_TAX", when ((col("SALES_TX_IND") == 'POS Tax'), col("SALES_TX_TOTAL")).otherwise(0))
#                     .withColumn("SALES_TX_TOTAL", col("ECOM_TAX")+col("POS_TAX"))\
#                     .withColumn("SALES_TX_IND", lit('TX_IND')).select("CUST_SRC_ID","SALES_TX_TOTAL", "SALES_TX_IND").dropDuplicates().toPandas()

df_cust_sel_tx = df_cust_sel_tx.select(sum(col("ECOM_TAX") + col("POS_TAX")).alias('SALES_TX_TOTAL'))
df_cust_sel_tx = df_cust_sel_tx.withColumn("SALES_TX_IND", lit('Tax_Ind')).toPandas()

 
#display(df_cust_sel_tx)
  

#########################################################################################################

# COMMAND ----------

###########################Loyalty ########################################################################################

var_loyalty_prog =  SNFL_DB_MARKT+'.LOYALTY.LOYALTY_CUSTOMER_PROGRAM'
var_loyalty_enrol = SNFL_DB_MARKT+'.LOYALTY.LOYALTY_ENROLLMENT'
var_loyalty_point = SNFL_DB_MARKT+'.LOYALTY.LOYALTY_MEMBER_POINT_BALANCE'
var_loyalty_saving = SNFL_DB_MARKT+'.LOYALTY.LOYALTY_MEMBER_SAVINGS_BALANCE'

var_cust_pref = SNFL_DB_MASTR+'.CUSTOMER.CUSTOMER_PREFERENCE'
var_cust_pref_prog = SNFL_DB_MASTR+'.CUSTOMER.CUSTOMER_PREFERENCE_PROGRAM'


##***Loyalty Info***

#12/19
qry_loyalty_info = "select p.loyalty_mbr_id as cust_src_id, p.prog_cd, p.prog_id as loyalty_card_no, a.enrl_dt as enrolment_date, (case when a.enrl_chnnl = 'NGPOS' then 'In-Store' when a.enrl_chnnl = 'ECOMM' then 'Online' when a.enrl_chnnl= 'MECOMM' then 'Mobile' when a.enrl_chnnl = 'CSR' then 'Call-Centre' when a.enrl_chnnl= 'Other' then 'Tablet' when a.enrl_chnnl= 'KIOSK' then 'Kiosk' when a.enrl_chnnl= 'IC' then 'Pharmacy' else '' end) as enrolment_channel, (case when cast(b.pnt_bal as INTEGER) is null then 0 else cast(b.pnt_bal as INTEGER) end) as member_pints_balance ,(case when c.pnt_earn_tot_lftm_cnt is null then 0 else c.pnt_earn_tot_lftm_cnt end) as total_points_earned_lifetime,(case when c.pnt_redeem_tot_lftm_cnt is null then 0 else c.pnt_redeem_tot_lftm_cnt end) as total_points_redeemed_lifetime from (select * from  {0} where loyalty_mbr_id in ({4}) and prog_cd in ('LYCD', 'VCD')) p left outer join {1} a on p.loyalty_mbr_id = a.loyalty_mbr_id and p.cust_sk = a.cust_sk left outer join (select * from {2}  where edw_rec_end_dt='9999-12-31' )b on p.loyalty_mbr_id=b.loyalty_mbr_id left outer join (select * from {3} where src_end_dt='9999-12-31')c on p.loyalty_mbr_id=c.loyalty_mbr_id".format(var_loyalty_prog,var_loyalty_enrol,var_loyalty_point,var_loyalty_saving,lyt_cust_scr_id)

df_loyalty_info=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_loyalty_info) \
   .load().toPandas()

# display(df_loyalty_info)


##***Loyalty Program details***
##Change the date format from / to -
qry_loyalty_prog = "select a.cust_src_id, b.cust_pref_prog_name, b.cust_pref_prog_start_dt as prog_start_date, case a.cust_pref_prog_cd  when '1000000018'  then to_date ('12-31-2021', 'MM-DD-YYYY')      when  '1000000123' then  to_date ( '08-31-2020', 'MM-DD-YYYY')   else b.cust_pref_prog_end_dt end as prog_end_date, a.src_pref_eff_dt as prog_optin_date, a.src_pref_expire_dt as prog_optout_date from {0} a join {1} b on a.cust_pref_prog_cd = b.cust_pref_prog_cd and b.edw_rec_end_dt = '9999-12-31' where a.src_sys_cd = 'OPV' and a.cust_src_cd = 'LR'and a.cust_pref_prog_group_cd = 'LOYALTY' and a.cust_pref_type_cd = 'OPTIN' and a.cust_pref_val = 'Y' and ( a.src_pref_eff_dt >= to_date({3}, 'YYYY-MM-DD') - {4} OR (a.src_pref_eff_dt < to_date({3}, 'YYYY-MM-DD') - {4} and a.cust_pref_prog_cd in ('1000000018', '1000000123'))) and b.cust_pref_prog_start_dt < b.cust_pref_prog_end_dt and a.edw_rec_end_dt = '9999-12-31'and a.cust_src_id in ({2}) order by a.src_pref_eff_dt".format(var_cust_pref,var_cust_pref_prog,lyt_cust_scr_id, req_open_dt, var_rep_days)    

df_loyalty_prog=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_loyalty_prog) \
   .load().toPandas()

# display(df_loyalty_prog)


# #Joining dataframes df_loyalty_info and df_loyalty_prog
# join_df_loyalty = df_loyalty_info.join(df_loyalty_prog, df_loyalty_info.CUST_SRC_ID == df_loyalty_prog.CUST_SRC_ID, "full" ).drop(df_loyalty_prog.CUST_SRC_ID)
# join_df_loyalty.show()
 
#####################################################################################################################

# COMMAND ----------

# #Joining dataframe join_df_loyalty with the main dataframe join_df fro straight CSV
# join_df = join_df.join(join_df_loyalty, join_df.CUST_SRC_ID == join_df_loyalty.CUST_SRC_ID, "full" ).drop(join_df_loyalty.CUST_SRC_ID)
# join_df.show()

# COMMAND ----------

##########################Pos Ecom Transaction queries ########################################################
 
#POS & ECOM Sales transactions Queries###############################

var_sales_trans_prog = SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION_PROGRAM'
var_sales_trans = SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION'
var_sales_trans_det = SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION_DETAIL'
var_sales_trans_tend = SNFL_DB_RETL+'.RETAIL_SALES.SALES_TRANSACTION_TENDER'
var_tender_card_hash = SNFL_DB_RETL+'.RETAIL_SALES.TENDER_CARD_HASH'
var_prod_hierarchy  =SNFL_DB_MASTR+'.PRODUCT.PRODUCT_HIERARCHY'

var_ecom_order_return = SNFL_DB_DIGTL+'.ECOM.ECOM_ORDER_ITEM_RETURN'
var_product = SNFL_DB_MASTR+'.PRODUCT.PRODUCT'
var_ecom_prod = SNFL_DB_DIGTL+'.ECOM.ECOM_PRODUCT'

#---payment query 2/6 Opstudy filters
qry_payment_all = "select distinct x.cust_src_id, x.purchase_date, (case when x.tndr_type_cd = '13' then 'Check' when x.tndr_type_cd = '12' then 'Cash' when x.tndr_type_cd = '471' then 'ALIPAY' when x.tndr_type_cd in('15', '365') then 'Food stamps' when x.tndr_type_cd = '16' then '3rd party' when x.tndr_type_cd = '17' then 'House charge' when x.tndr_type_cd = '476' then 'Solutran OTC' when x.tndr_type_cd = '19' then 'Foreign Currency' when x.tndr_type_cd = '22' then 'Refund Check' when x.tndr_type_cd = '23' then 'WIC Receivable' when x.tndr_type_cd = '24' then 'EBT Food' when x.tndr_type_cd = '25' then 'EBT Cash'when x.tndr_type_cd = '26' then 'Walgreens GIFT CARD' when x.tndr_type_cd = '27' then 'W Card' when x.tndr_type_cd = '28' then 'PREPAID' when x.tndr_type_cd = '30' then 'Prepared' when x.tndr_type_cd = '31' then 'ACH CHECK' when x.tndr_type_cd = '98' then 'Foreign Currency (Canadian)' when x.tndr_type_cd in ('106','99') then 'Foreign Currency' when x.tndr_type_cd = '100' then 'CRW CHG' when x.tndr_type_cd = '101' then 'Foreign Currency' when x.tndr_type_cd = '102' then 'EFT WIC RECV' when x.tndr_type_cd = '106' then 'Foreign Currency (PESO)' when x.tndr_type_cd = '110' then 'W CARD-31' when x.tndr_type_cd = '111' then 'Gift Card' when x.tndr_type_cd in ('125', '299', '318', '334', '397', '14') then 'Credit card' when x.tndr_type_cd in ('335','229', '406', '18') then 'Debit Card' when x.tndr_type_cd = '236' then 'Kash' when x.tndr_type_cd = '237' then '3rd party' when x.tndr_type_cd = '239' then 'Puerto Rico OTC' when x.tndr_type_cd = '267' then 'WIC' when x.tndr_type_cd = '268' then 'W CARD-29' when x.tndr_type_cd = '270' then 'W CARD-06' when x.tndr_type_cd = '274' then 'W CARD-27' when x.tndr_type_cd = '277' then 'W CARD-30' when x.tndr_type_cd = '279' then 'W CARD-02' when x.tndr_type_cd in ('279', '285') then 'Cash $' when x.tndr_type_cd = '288' then 'W CARD-03' when x.tndr_type_cd = '296' then 'W CARD-04' when x.tndr_type_cd = '297' then 'EBT Foodstamp' when x.tndr_type_cd = '307' then 'TYPE  DESCRI' when x.tndr_type_cd = '317' then 'TYPE THE FOL' when x.tndr_type_cd = '366' then 'WCheck' when x.tndr_type_cd = '383' then 'RIPTOR-31' when x.tndr_type_cd = '384' then 'RIPTOR-32' when x.tndr_type_cd = '385' then 'Tender Desc' when x.tndr_type_cd = '386' then 'RIPTOR-27' when x.tndr_type_cd = '391' then 'W CARD-24' when x.tndr_type_cd = '392' then 'RIPTOR-24' when x.tndr_type_cd = '398' then 'W CARD-3' when x.tndr_type_cd = '400' then 'W CARD--1' when x.tndr_type_cd = '406' then 'Debit Card' when x.tndr_type_cd = '407' then 'MEDAGATE' when x.tndr_type_cd = '409' then 'CHEC  313185' when x.tndr_type_cd = '410' then 'OTC' when x.tndr_type_cd = '412' then 'W CARD-1' when x.tndr_type_cd = '429' then 'Loyalty redeem' when x.tndr_type_cd = '430' then 'EWIC' when x.tndr_type_cd = '440' then 'D MFG COUPON' when x.tndr_type_cd = '469' then 'D EPP MFGCPN' when x.tndr_type_cd = '17' then 'House Charge' when x.tndr_type_cd = '311' then 'RX Unknown Tender Type' else 'Unknown Tender Type' end) as payment_type, x.tenders_dollars, x.account_number, x.card_first_6_digits, x.card_last_4_digits, x.purchase_type from (select a.sales_txn_dt as purchase_date, a.sales_txn_id as txn_id, a.prog_cust_id as cust_src_id, t.tndr_type_cd ,cast(t.tndr_dlrs as decimal(10,2) )as tenders_dollars, (case when t.acct_nbr is null then 'NA' else t.acct_nbr end) as account_number,(case when h.card_first_6_char = '999999' then 'N/A' else h.card_first_6_char end) as card_first_6_digits, (case when h.card_last_4_char = '9999' then 'N/A' else h.card_last_4_char end) as card_last_4_digits , (case trim(s.src_sys_cd) when 'POS' then 'In stores' when 'EC' then 'Online' else s.src_sys_cd end)as purchase_type from (select * from {0} where date(sales_txn_dt,  'YYYY-MM-DD') > to_date({8}, 'YYYY-MM-DD') - 365 and date(sales_txn_dt, 'YYYY-MM-DD') <= to_date({8}, 'YYYY-MM-DD') and prog_cust_id in ({7}) and src_sys_cd = 'POS') a inner join (select * from {1} where src_sys_cd = 'POS' and sales_txn_dt > to_date({8}, 'YYYY-MM-DD')-365 and sales_txn_dt <= to_date({8}, 'YYYY-MM-DD')) s on a.sales_txn_dt = s.sales_txn_dt and a.sales_txn_id = s.sales_txn_id inner join (select * from {1}_detail where sales_txn_dt > to_date({8}, 'YYYY-MM-DD') - 365 and sales_txn_dt <= to_date({8}, 'YYYY-MM-DD')and src_sys_cd = 'POS') d on s.sales_txn_dt = d.sales_txn_dt and s.sales_txn_id = d.sales_txn_id and s.src_sys_cd = d.src_sys_cd inner join (select * from {5} where src_sys_cd = 'POS' and edw_rec_end_dt = '9999-12-31' and ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74', '80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )e on e.prod_sk = d.prod_sk inner join (select * from {3} ) t on a.sales_txn_id = t.sales_txn_id and a.sales_txn_dt = t.sales_txn_dt and a.src_sys_cd = t.src_sys_cd inner join (select * from {4}) h on h.card_hash_val_sk = t.card_hash_val_sk where s.txn_type IN ( '10' , '11' , '12' , '13' , '14' ,'15' , '16' , '25' ) and  s.POST_VOID_STATUS_CD = '--' and  s.TXN_INCOMPLETE_IND = 'N'and  s.TRAINING_TXN_IND = 'N'and s.sales_txn_dt = d.sales_txn_dt and s.sales_txn_id = d.sales_txn_id and d.rx_nbr is null and d.unit_qty > 0 and d.item_void_cd = '--' union all select s.sales_txn_dt as purchase_date,s.sales_txn_id as txn_id, s.src_cust_id as cust_src_id, t.tndr_type_cd , cast(t.tndr_dlrs as decimal(10,2) )as tenders_dollars,(case when t.acct_nbr is null then 'NA' else t.acct_nbr end) as account_number,(case when h.card_first_6_char = '999999' then 'N/A' else h.card_first_6_char end) as card_first_6_digits,(case when h.card_last_4_char = '9999' then 'N/A' else h.card_last_4_char end) as card_last_4_digits ,(case trim(s.src_sys_cd) when 'POS' then 'In stores' when 'EC' then 'Online' else s.src_sys_cd end)as purchase_type from (select * from {1} where  src_cust_id in ({6}) and sales_txn_dt > to_date({8}, 'YYYY-MM-DD') - 365 and sales_txn_dt <= to_date({8}, 'YYYY-MM-DD') and src_sys_cd = 'EC' and sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) s inner join (select * from {2} where src_sys_cd = 'EC' AND sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) d on s.sales_txn_id = d.sales_txn_id and s.src_sys_cd = d.src_sys_cd AND s.sales_ord_src_type = d.sales_ord_src_type and s.sales_txn_dt = d.sales_txn_dt inner join (select * from {3} ) t on s.sales_txn_id = t.sales_txn_id and s.sales_txn_dt = t.sales_txn_dt and s.src_sys_cd = t.src_sys_cd inner join (select * from {4}) h on h.card_hash_val_sk = t.card_hash_val_sk inner join (select * from {5} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31' and  ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74','80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )e on e.prod_sk = d.prod_sk) x order by x.purchase_date desc".format(var_sales_trans_prog,var_sales_trans,var_sales_trans_det,var_sales_trans_tend,var_tender_card_hash, var_prod_hierarchy, ec_cust_scr_id,lyt_cust_scr_id, req_open_dt, var_rep_days)

df_payment_all=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_payment_all) \
   .load().toPandas()

# display(df_payment_all)


#---POS Purchases query 2/06 with opstudy filters
qry_pos_sales_trans = "select X.cust_src_id,X.purchase_date as pos_purchase_date, X.product_description as pos_product_description, Sum (X.Total_Qty) as pos_total_qty, cast(SUM (X.Total_Sales) as decimal(10,2)) as pos_total_sales, sum(X.Return_Flag) as pos_returns_qty from (select a.prog_cust_id as cust_src_id, d.sales_txn_dt as Purchase_Date,(CASE WHEN d.wag_coup_cd in ('C', 'D') THEN (d.upc_desc || ' (' || 'W coupon)') WHEN d.mfg_coup_cd <> '--' THEN  (d.upc_desc || ' (' || 'Mfg coupon)')ELSE d.upc_desc END ) as product_description, (CASE WHEN wag_coup_cd = 'B' or trim(return_ind) = 'Y' THEN 0 ELSE unit_qty END ) as Total_Qty, selling_price_dlrs as Total_Sales, case when d.return_ind= 'Y' THEN 1 ELSE 0 END  as Return_Flag from (select * from {0} where prog_cust_id in ({4}) and src_sys_cd = 'POS' and date(sales_txn_dt, 'YYYY-MM-DD') > to_date({5}, 'YYYY-MM-DD') - {6} and date(sales_txn_dt, 'YYYY-MM-DD')<= to_date({5}, 'YYYY-MM-DD')) a inner join (select * from {1} where src_sys_cd = 'POS' and sales_txn_dt > to_date({5}, 'YYYY-MM-DD')-{6} and date(sales_txn_dt, 'YYYY-MM-DD')<= to_date({5}, 'YYYY-MM-DD')) b on a.sales_txn_dt = b.sales_txn_dt and a.sales_txn_id = b.sales_txn_id inner join (select * from {2} where sales_txn_dt > to_date({5}, 'YYYY-MM-DD') - {6} and sales_txn_dt <= to_date({5}, 'YYYY-MM-DD') and src_sys_cd = 'POS') d  on b.sales_txn_dt = d.sales_txn_dt and b.sales_txn_id = d.sales_txn_id and b.src_sys_cd = d.src_sys_cd inner join (select * from {3} where src_sys_cd = 'POS' and  edw_rec_end_dt = '9999-12-31' and ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74','80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )e on e.prod_sk = d.prod_sk where b.txn_type IN ( '10' , '11' , '12' , '13' , '14' ,'15' , '16' , '25' ) and  b.POST_VOID_STATUS_CD = '--' and  b.TXN_INCOMPLETE_IND = 'N' and  b.TRAINING_TXN_IND = 'N' and b.sales_txn_dt = d.sales_txn_dt and b.sales_txn_id = d.sales_txn_id and d.rx_nbr is null and d.unit_qty > 0  and d.item_void_cd = '--' ) x group by purchase_date, product_description, cust_src_id order by purchase_date".format(var_sales_trans_prog,var_sales_trans,var_sales_trans_det, var_prod_hierarchy, lyt_cust_scr_id, req_open_dt, var_rep_days)

df_pos_sales_trans=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_pos_sales_trans) \
   .load().toPandas()

# display(df_pos_sales_trans)


# join_ecom_trans_df = df_payment_all.join(df_pos_sales_trans, df_payment_all.CUST_SRC_ID == df_pos_sales_trans.CUST_SRC_ID, "full" ).drop(df_pos_sales_trans.CUST_SRC_ID)
#join_ecom_trans_df.show()

#---ECOM Returns query 2/6 opstudy filters
qry_ecom_return = "select a.src_cust_id as cust_src_id, cast(c.create_dttm as DATE) as ecom_return_reported_date,c.qty_to_return as ecom_qty_to_return, cast(c.tot_return_dlrs as decimal(10,2)) as ecom_tot_return_dlrs, (case when d.prod_sk = '-1' and  b.sales_ord_src_type = 'P' then 'Photo Item' when d.prod_sk = '-1' and  b.sales_ord_src_type = 'S' then 'Self Service Item' when e.prod_desc is NULL and b.sales_ord_src_type = 'S' then 'Self Service Item'  else e.prod_desc end) as ecom_prod_desc from (select * from {0} where  src_cust_id in ({6}) and date (sales_txn_dt, 'YYYY-MM-DD') > to_date({7}, 'YYYY-MM-DD') - {8} and date (sales_txn_dt, 'YYYY-MM-DD') <= to_date({7}, 'YYYY-MM-DD') and src_sys_cd = 'EC' and sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) a inner join (select * from {1} where src_sys_cd = 'EC' AND sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) b on a.sales_txn_id = b.sales_txn_id and b.src_sys_cd = a.src_sys_cd AND b.sales_ord_src_type = a.sales_ord_src_type and a.sales_txn_dt = b.sales_txn_dt inner join (select * from {2} where date(to_date(create_dttm), 'YYYY-MM-DD')> to_date({7}, 'YYYY-MM-DD')  -{8} and date(to_date(create_dttm), 'YYYY-MM-DD')<= to_date({7}, 'YYYY-MM-DD')) c on c.ord_src_type_cd = b.sales_ord_src_type and c.return_item_id = b.ord_item_id and c.ord_id = b.sales_txn_id inner join (select * from {3} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31')d on b.prod_sk = d.prod_sk inner join (select * from {4} where end_dt = '9999-12-31') e on d.ecom_prod_id = e.ecom_prod_id inner join (select * from {5} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31'and ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74','80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )f on f.prod_sk = d.prod_sk order by ecom_return_reported_date".format(var_sales_trans, var_sales_trans_det, var_ecom_order_return, var_product, var_ecom_prod, var_prod_hierarchy, ec_cust_scr_id, req_open_dt, var_rep_days)

df_ecom_return=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_ecom_return) \
   .load()

df_ecom_return = df_ecom_return.toPandas()

# display(df_ecom_return)


#---ECOM purchases query 2/6 Opstudy filters
qry_ecom_sales_trans = "select x.cust_src_id, x.purchase_date as ecom_pur_purchase_date,x.prod_desc as ecom_pur_prod_desc, x.total_sales as ecom_pur_total_sales, x.unit_qty as ecom_pur_unit_qty from (select a.src_cust_id as cust_src_id, b.sales_txn_dt as purchase_date, (case when d.prod_sk = '-1' and b.sales_ord_src_type = 'P' then 'Photo Item' when d.prod_sk = '-1' and  b.sales_ord_src_type = 'S' then 'Self Service Item' when e.prod_desc is null and b.sales_ord_src_type = 'S' then 'Self Service Item' else e.prod_desc end) as prod_desc, cast(b.selling_price_dlrs as decimal(10,2)) as total_Sales, b.unit_qty from (select * from {0} where  src_cust_id in ({5}) and sales_txn_dt > to_date({6}, 'YYYY-MM-DD') - {7} and sales_txn_dt <= to_date({6}, 'YYYY-MM-DD') and src_sys_cd = 'EC' and sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) a inner join (select * from {1} where src_sys_cd = 'EC' AND sales_ord_src_type <> 'R' and sales_txn_type <> 'R' ) b on a.sales_txn_id = b.sales_txn_id and b.src_sys_cd = a.src_sys_cd AND b.sales_ord_src_type = a.sales_ord_src_type and a.sales_txn_dt = b.sales_txn_dt inner join (select * from {2} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31')d on b.prod_sk = d.prod_sk inner join (select * from {3} where end_dt = '9999-12-31') e on d.ecom_prod_id = e.ecom_prod_id inner join (select * from {4} where src_sys_cd = 'EC' and edw_rec_end_dt = '9999-12-31'and  ops_dept_nbr not in ('1', '2', '3', '4', '7', '12', '15', '31', '56', '73', '74', '80', '84', '103', '107', '115', '123', '124', '127', '158', '163', '174', '181', '212', '214', '902', '907', '908', '909', '910', '911', '912', '915') )f on f.prod_sk = d.prod_sk)x order by purchase_date".format(var_sales_trans,var_sales_trans_det,var_product,var_ecom_prod, var_prod_hierarchy, ec_cust_scr_id, req_open_dt, var_rep_days)

df_ecom_sales_trans=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_ecom_sales_trans) \
   .load().toPandas()

# display(df_ecom_sales_trans)


#######################################################################################################################

# COMMAND ----------

######################EMAIL Subscription ###############################

#Email subscription 12/17
#query.email.subscriptions = select cust_sk, cust_pref_type_cd, cust_pref_val from ${viewname}.customer_preference where cust_sk in (:ecCustSrcId)  and cust_pref_type_cd in ( 'shopping_wkly_ind', 'photo_ind', 'walk_social_ind', 'take_care_clinic_subscribe_ind', 'str_spcl_newsltr_ind') and edw_rec_end_dt = '9999-12-31' and cust_src_cd = 'EC' union all select cust_sk, 'balance_rewards' as cust_pref_type_cd,  do_not_eml_ind as cust_pref_val from ${viewname}.loyalty_customer_reference where cust_sk in (:lytCustSrcId) and edw_rec_end_dt = '9999-12-31' and src_sys_cd = 'LR';

var_cust_pref = SNFL_DB_MASTR+'.CUSTOMER.CUSTOMER_PREFERENCE'
var_loyalty_cust_ref = SNFL_DB_MARKT+'.LOYALTY.LOYALTY_CUSTOMER_REFERENCE'

#12/19
qry_email_subs = "select cust_sk, cust_pref_type_cd, cust_pref_val from {0} where cust_sk in ({2})  and cust_pref_type_cd in ( 'shopping_wkly_ind', 'photo_ind', 'walk_social_ind', 'take_care_clinic_subscribe_ind', 'str_spcl_newsltr_ind') and edw_rec_end_dt = '9999-12-31' and cust_src_cd = 'EC' and cust_pref_val = 'Y' union all select cust_sk, 'balance_rewards' as cust_pref_type_cd,  do_not_eml_ind as cust_pref_val from {1} where cust_sk in ({3}) and edw_rec_end_dt = '9999-12-31' and src_sys_cd = 'LR' and cust_pref_val = 'Y'".format(var_cust_pref,var_loyalty_cust_ref,ec_cust_scr_id,lyt_cust_scr_id)

df_email_subs=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFL_DB_RETL) \
   .option("query",qry_email_subs) \
   .load().toPandas()

# display(df_email_subs)

#Adding result to the json file
#df_email_subs.write.mode("Append").option("ignoreNullFields", "false").json(OUT_FILEPATH_JSON)

#########################################################################################

# COMMAND ----------

######################################customer inference hive ############################################

l4_df = spark.read.format("delta").load(L4_LOAD_URI)
l4_df.createOrReplaceTempView("l4_customer_dim")

# COMMAND ----------

customer_inferences = """SELECT mid
	,'' AS segment_lifestyle_fos
	,CASE upper(trim(life_cycle_baby_boomers)) WHEN 'Y' THEN 'Baby boomer' ELSE life_cycle_baby_boomers END AS life_cycle_baby_boomers
	,CASE upper(trim(life_cycle_dual_incm_no_kids)) WHEN 'Y' THEN 'Dual Income, no kids' ELSE life_cycle_dual_incm_no_kids END AS life_cycle_dual_incm_no_kids
	,CASE upper(trim(life_cycle_generation_x)) WHEN 'Y' THEN 'Gen X' ELSE life_cycle_generation_x END AS life_cycle_generation_x
	,CASE cast(advntg_home_owner AS INT) WHEN 0 THEN 'Unknown' WHEN 1 THEN 'Definite Renter' WHEN 2 THEN 'Probable Renter' WHEN 3 THEN 'Probable Owner' WHEN 4 THEN 'Definite Owner' ELSE advntg_home_owner END AS advntg_home_owner
	,CASE upper(trim(advntg_household_edu)) WHEN '0' THEN 'Unknown' WHEN '1' THEN 'Some High School or Less' WHEN '2' THEN 'High School' WHEN '3' THEN 'Some College' WHEN '4' THEN 'College' WHEN '5' THEN 'Graduate School' ELSE advntg_household_edu END AS advntg_household_edu
	,CASE upper(trim(advntg_household_mrtl_stat)) WHEN '1' THEN 'At least 1 married' WHEN '2' THEN 'At least 1 single' WHEN '3' THEN 'Both married and single' ELSE advntg_household_mrtl_stat END AS advntg_household_mrtl_stat
	,CASE upper(trim(advntg_household_sz)) WHEN '1' THEN 'One person' WHEN '2' THEN 'Two persons' WHEN '3' THEN 'Three persons' WHEN '4' THEN 'Four  persons' WHEN '5' THEN 'Five  persons' WHEN '6' THEN 'Six  persons' WHEN '7' THEN 'Seven  persons' WHEN '8' THEN 'Eight  persons' WHEN '9' THEN 'Nine or more persons' ELSE advntg_household_sz END AS advntg_household_sz
	,CASE upper(trim(advntg_presence_of_child)) WHEN '0' THEN 'No children present' WHEN '1' THEN 'Yes children present' WHEN NULL THEN ' ' ELSE advntg_presence_of_child END AS advntg_presence_of_child
	,CASE upper(trim(ethnic_group_cd)) WHEN 'A' THEN 'African American' WHEN 'B' THEN 'Far Eastern' WHEN 'C' THEN 'Southeast Asia' WHEN 'D' THEN 'Central & Southwest Asia' WHEN 'E' THEN 'Mediterranean' WHEN 'F' THEN 'Native American' WHEN 'G' THEN 'Scandinavian' WHEN 'H' THEN 'Polynesian' WHEN 'I' THEN 'Middle Eastern' WHEN 'J' THEN 'Jewish' WHEN 'K' THEN 'Western European' WHEN 'L' THEN 'Eastern European' WHEN 'O' THEN 'Other Groups' WHEN 'Y' THEN 'Hispanic' WHEN 'Z' THEN 'Unknown' ELSE ethnic_group_cd END AS ethnic_group_cd
	,CASE upper(trim(life_cycle_dual_incm_no_kids)) WHEN 'Y' THEN 'Yes-present' ELSE life_cycle_dual_incm_no_kids END AS life_cycle_dual_incm_no_kids_flag
	,CASE WHEN cast(median_household_incm AS INT) BETWEEN 0
				AND 25000 THEN '$0 to $25,000' WHEN cast(median_household_incm AS INT) BETWEEN 25001
				AND 50000 THEN '$25,001 to $50,000' WHEN cast(median_household_incm AS INT) BETWEEN 50001
				AND 75000 THEN '$50,001 to $75,000' WHEN cast(median_household_incm AS INT) BETWEEN 75001
				AND 100000 THEN '$75,001 to $100,000' WHEN cast(median_household_incm AS INT) BETWEEN 100001
				AND 125000 THEN '$100,001 to $125,000' WHEN cast(median_household_incm AS INT) BETWEEN 125001
				AND 150000 THEN '$125,001 to $150,000' WHEN cast(median_household_incm AS INT) BETWEEN 150001
				AND 200000 THEN '$150,001 to $200,000' WHEN cast(median_household_incm AS INT) BETWEEN 200001
				AND 250000 THEN '$200,001 to $250,000' WHEN cast(median_household_incm AS INT) BETWEEN 250001
				AND 500000 THEN '$250,001 to $500,000' WHEN cast(median_household_incm AS INT) >= 500001 THEN '$500,001 and higher' ELSE median_household_incm END AS median_household_incm
	,CASE upper(trim(lang_cd)) WHEN 'A1' THEN 'Afrikaans' WHEN 'A2' THEN 'Albanian' WHEN 'A3' THEN 'Amharic' WHEN 'A4' THEN 'Arabic' WHEN 'A5' THEN 'Armenian' WHEN 'A6' THEN 'Ashanti' WHEN 'A7' THEN 'Azeri' WHEN 'B1' THEN 'Bantu' WHEN 'B2' THEN 'Basque' WHEN 'B3' THEN 'Bengali' WHEN 'B4' THEN 'Bulgarian' WHEN 'B5' THEN 'Burmese' WHEN 'C1' THEN 'Chinese (Mandarin, Cantonese and other dialects)' WHEN 'C3' THEN 'Czech' WHEN 'D1' THEN 'Danish' WHEN 'D2' THEN 'Dutch' WHEN 'D3' THEN 'Dzongha' WHEN 'E1' THEN 'English' WHEN 'E2' THEN 'Estonian' WHEN 'F1' THEN 'Farsi' WHEN 'F2' THEN 'Finnish' WHEN 'F3' THEN 'French' WHEN 'G1' THEN 'Georgian' WHEN 'G2' THEN 'German' WHEN 'G3' THEN 'Ga' WHEN 'G4' THEN 'Greek' WHEN 'H2' THEN 'Hebrew' WHEN 'H3' THEN 'Hindi' WHEN 'H4' THEN 'Hungarian' WHEN 'I1' THEN 'Icelandic' WHEN 'I2' THEN 'Indonesian' WHEN 'I3' THEN 'Italian' WHEN 'J1' THEN 'Japanese' WHEN 'K1' THEN 'Kazakh' WHEN 'K2' THEN 'Khmer' WHEN 'K3' THEN 'Kirghiz' WHEN 'K4' THEN 'Korean' WHEN 'L1' THEN 'Laotian (Include Hmong)' WHEN 'L2' THEN 'Latvian' WHEN 'L3' THEN 'Lithuanian' WHEN 'M1' THEN 'Macedonian' WHEN 'M2' THEN 'Malagasy' WHEN 'M3' THEN 'Malay' WHEN 'M4' THEN 
				'Moldavian' WHEN 'M5' THEN 'Mongolian' WHEN 'N1' THEN 'Nepali' WHEN 'N2' THEN 'Norwegian' WHEN 'O1' THEN 'Oromo' WHEN 'P1' THEN 'Pashto' WHEN 'P2' THEN 'Polish' WHEN 'P3' THEN 'Portuguese' WHEN 'R1' THEN 'Romanian' WHEN 'R2' THEN 'Russian' WHEN 'S1' THEN 'Samoan' WHEN 'S2' THEN 'Serbo-Croatian' WHEN 'S3' THEN 'Sinhalese' WHEN 'S4' THEN 'Slovakian' WHEN 'S5' THEN 'Slovenian' WHEN 'S6' THEN 'Somali' WHEN 'S7' THEN 'Sotho' WHEN 'S8' THEN 'Spanish' WHEN 'S9' THEN 'Swahili' WHEN 'SA' THEN 'Swazi' WHEN 'SB' THEN 'Swedish' WHEN 'T1' THEN 'Tagalog' WHEN 'T2' THEN 'Tajik' WHEN 'T3' THEN 'Thai' WHEN 'T4' THEN 'Tibetan' WHEN 'T5' THEN 'Tongan' WHEN 'T6' THEN 'Turkish' WHEN 'T7' THEN 'Turkmeni' WHEN 'T8' THEN 'Tswana' WHEN 'U1' THEN 'Urdu' WHEN 'U2' THEN 'Uzbeki' WHEN 'V1' THEN 'Vietnamese' WHEN 'X1' THEN 'Xhosa' WHEN 'Z1' THEN 'Zulu' ELSE lang_cd END AS lang_cd
	,CASE upper(trim(nbr_of_child_in_household)) WHEN '1' THEN 'One child' WHEN '2' THEN 'Two children' WHEN '3' THEN 'Three children' WHEN '4' THEN 'Four  children' WHEN '5' THEN 'Five  children' WHEN '6' THEN 'Six  children' WHEN '7' THEN 'Seven  children' WHEN '8' THEN 'Eight  children' WHEN '9' THEN 'Nine or more children' WHEN ' ' THEN 'Unknown number of children' END AS nbr_of_child_in_household
	,CASE cast(Occp AS INT) WHEN 0 THEN 'Unknown/No Data' WHEN 1 THEN 'Physician/Dentist' WHEN 10 THEN 'Tradesman/Machine Oper / Laborer' WHEN 11 THEN 'Farmer' WHEN 12 THEN 'Student' WHEN 13 THEN 'Homemaker' WHEN 14 THEN 'Retired' WHEN 15 THEN 'Federal Employee' WHEN 16 THEN 'Federal Employee Retired' WHEN 17 THEN 'Military' WHEN 18 THEN 'Military Retired' WHEN 19 THEN 'Other' WHEN 2 THEN 'Health Care' WHEN 20 THEN 'Business Owner' WHEN 3 THEN 'Lawyers/Judges' WHEN 5 THEN 'Professional/Technical' WHEN 6 THEN 'Management' WHEN 7 THEN 'Teacher Educator' WHEN 8 THEN 'Sales/Marketing' WHEN 9 THEN 'Clerical/Service Worker' ELSE Occp END AS Occp
	,CASE upper(trim(advntg_tgt_incm)) WHEN '1' THEN '$ 0 – $ 14,999' WHEN '2' THEN '$15,000 - $19,999' WHEN '3' THEN '$20,000 - $29,999' WHEN '4' THEN '$30,000 - $39,999' WHEN '5' THEN '$40,000 - $49,999' WHEN '6' THEN '$50,000 - $74,999' WHEN '7' THEN '$75,000 - $99,999' WHEN '8' THEN '$100,000 - $124,999' WHEN '9' THEN '$125,000 - $149,999' WHEN 'A' THEN '$150,000 - $174,999' WHEN 'B' THEN '$175,000 – 199,999' WHEN 'C' THEN '$200,000 – 249,999' WHEN 'D' THEN '$250,000 or More' ELSE advntg_tgt_incm END AS advntg_tgt_incm
	,CASE upper(trim(child_age_0_to_2_yrs)) WHEN '1' THEN 'Male present' WHEN '2' THEN 'Female present' WHEN '3' THEN 'Male and Female present' WHEN '4' THEN 'Unknown Gender present' WHEN '5' THEN 'Male and Unknown Gender present' WHEN '6' THEN 'Female and Unknown Gender present' WHEN '7' THEN 'Male, Female and Unknown Gender present' END AS child_age_0_to_2_yrs
	,CASE upper(trim(child_age_3_to_5_yrs)) WHEN '1' THEN 'Male present' WHEN '2' THEN 'Female present' WHEN '3' THEN 'Male and Female present' WHEN '4' THEN 'Unknown Gender present' WHEN '5' THEN 'Male and Unknown Gender present' WHEN '6' THEN 'Female and Unknown Gender present' WHEN '7' THEN 'Male, Female and Unknown Gender present' END AS child_age_3_to_5_yrs
	,CASE upper(trim(child_age_6_to_10_yrs)) WHEN '1' THEN 'Male present' WHEN '2' THEN 'Female present' WHEN '3' THEN 'Male and Female present' WHEN '4' THEN 'Unknown Gender present' WHEN '5' THEN 'Male and Unknown Gender present' WHEN '6' THEN 'Female and Unknown Gender present' WHEN '7' THEN 'Male, Female and Unknown Gender present' END AS child_age_6_to_10_yrs
	,CASE upper(trim(child_age_11_to_15_yrs)) WHEN '1' THEN 'Male present' WHEN '2' THEN 'Female present' WHEN '3' THEN 'Male and Female present' WHEN '4' THEN 'Unknown Gender present' WHEN '5' THEN 'Male and Unknown Gender present' WHEN '6' THEN 'Female and Unknown Gender present' WHEN '7' THEN 'Male, Female and Unknown Gender present' END AS child_age_11_to_15_yrs
	,CASE upper(trim(child_age_16_to_17_yrs)) WHEN '1' THEN 'Male present' WHEN '2' THEN 'Female present' WHEN '3' THEN 'Male and Female present' WHEN '4' THEN 'Unknown Gender present' WHEN '5' THEN 'Male and Unknown Gender present' WHEN '6' THEN 'Female and Unknown Gender present' WHEN '7' THEN 'Male, Female and Unknown Gender present' END AS child_age_16_to_17_yrs
FROM l4_customer_dim where mid in ({0}) 
""".format(cdi_cust_scr_id)

print(customer_inferences)

# COMMAND ----------

df_l4_inference = spark.sql(customer_inferences).toPandas()

# print(df_l4_inference)

# COMMAND ----------


all_cols = []
df_all = pd.DataFrame()

for df in [df_req_list,join_df_cust,df_cust_sel,df_cust_sel_tx,df_loyalty_info,df_loyalty_prog,df_payment_all,df_pos_sales_trans,df_ecom_return,df_ecom_sales_trans,df_email_subs,df_l4_inference]: 
  for col in df.columns:
    if col not in all_cols:
      all_cols.append(col)


for df in [df_req_list,join_df_cust,df_cust_sel,df_cust_sel_tx,df_loyalty_info,df_loyalty_prog,df_payment_all,df_pos_sales_trans,df_ecom_return,df_ecom_sales_trans,df_email_subs,df_l4_inference]:
  df = df.fillna('').astype(str)
  for col in all_cols:
    if col not in df.columns:
      df[col] = ''

  df_all = pd.concat([df_all, df[all_cols]], axis=0, ignore_index=True)



# COMMAND ----------

var_tkt_nbr = df_req_list[~df_req_list["TKT_NBR"].isna()]["TKT_NBR"].iloc[0]
var_task_id = df_req_list[~df_req_list["TASK_ID"].isna()]["TASK_ID"].iloc[0]
var_lv_flag = df_req_list[~df_req_list["LV_FLAG"].isna()]["LV_FLAG"].iloc[0]
var_tkt_open_dt = df_req_list[~df_req_list["TKT_OPEN_DT"].isna()]["TKT_OPEN_DT"].iloc[0]


print(var_tkt_nbr)
print(var_task_id)
print(var_lv_flag)
print(var_tkt_open_dt)


# COMMAND ----------

## Fill static columns with data

df_all = df_all.replace({"TKT_NBR" : {'' : var_tkt_nbr}, 
                "TASK_ID" : {'' : var_task_id},
                "LV_FLAG" : {'' : var_lv_flag},
                "TKT_OPEN_DT" : {'' : var_tkt_open_dt}})


# COMMAND ----------



# COMMAND ----------

#Creating Filename

#Getting current Date&time

date1 = spark.sql("select date_format(current_timestamp(), 'yyyyMMddhhmmss') as cur_date" )

date2 = [row[0] for row in date1.select('cur_date').collect()]
date3 = ''
for x in date2:
  if x == None or x == '' :
    date3 = 'NULL'
  else:
    date3 +=x
 
print(date3)


#Making filename

fname = 'DAE'+'_'+'OTT_RTA_CMR_APPTEAMREPORT_ENC_'+date3+'Z_'+var_task_id #+'.csv'
print(fname)



# COMMAND ----------

#Creating complete sraight CSV file
import csv

dbutils.fs.mkdirs(OUT_FILEPATH_CSV)

df_all.to_csv(OUT_FILEPATH_CSV+"/"+fname+".csv",header=True, index=False,sep="\u0001", quoting=csv.QUOTE_NONE)



# COMMAND ----------

dbutils.notebook.exit(fname)
# Databricks notebook source
# import os
# import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)


# COMMAND ----------

from pyspark.sql.types import StringType
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import col, concat_ws

# COMMAND ----------

#dbutils.widgets.remove("PAR_DB_TKT_NUMBR")

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID", "11111")

# dbutils.widgets.text("PAR_DB_OUTPUT_PATH", "master_data/customer/ccpa/output/CompleteNestedCSV")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME", "WJEKRKGSZY_CompleteNestedCSV")

# dbutils.widgets.text("PAR_DB_INPUT_PATH", "master_data/customer/ccpa/output/decrypted/WJEKRKGSZY_decrypted/")
# dbutils.widgets.text("PAR_DB_INPUT_FILENAME", "DAE_OTT_RTA_CMR_APPTEAMREPORT_DEC_20221214054302Z_b3f7878f-9f51-455d-b37e-8fcb8799ef99.csv")

# dbutils.widgets.text("PAR_DB_OUTPUT_PATH_SUMM", "master_data/customer/ccpa/output/SummaryNestedCSV")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME_SUMM", "WJEKRKGSZY_SummaryNestedCSV")

# COMMAND ----------

##########################Test#########################
# databasename = intidldb01
# viewname =intidldb01
# pscviewname =intedwdb01
# requestdb = intidldb01
# hivedb = dae_work
##########################################################

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")


INPUT_PATH = dbutils.widgets.get("PAR_DB_INPUT_PATH")
INPUT_FILENAME = dbutils.widgets.get("PAR_DB_INPUT_FILENAME")

IN_FILEPATH = mountPoint + '/'+ INPUT_PATH  + '/' + INPUT_FILENAME
print(IN_FILEPATH)

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH  + '/' + OUTPUT_FILENAME
print(OUT_FILEPATH)


OUTPUT_PATH_SUMM = dbutils.widgets.get("PAR_DB_OUTPUT_PATH_SUMM")
OUTPUT_FILENAME_SUMM = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME_SUMM")

OUT_FILEPATH_SUMM = mountPoint + '/'+ OUTPUT_PATH_SUMM  + '/' + OUTPUT_FILENAME_SUMM
print(OUT_FILEPATH_SUMM)



# COMMAND ----------

# MAGIC %run /Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB_RETL $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

print(IN_FILEPATH)

# COMMAND ----------

df_read = spark.read.csv(IN_FILEPATH, header=True, sep='\u0001')
#df_read = df_read.filter(df_read.TKT_NBR.isNotNull())
df_read = df_read.dropDuplicates()
df_read = df_read.select([when((col(c)=='NULL') | (col(c).isNull()) ,None).otherwise(col(c)).alias(c) for c in df_read.columns])
display(df_read)


# COMMAND ----------

###RECOUPLE NAME and POSTAL_CODE ####

# Set NULLS to empty string for concat
df_read = df_read.fillna(value="") 
#("TKT_NBR","TASK_ID", "CUST_SK", "CUST_SRC_ID", "LV_FLAG", "CUST_FIRST_NAME", "CUST_MIDDLE_NAME", "CUST_LAST_NAME", "CUST_EML_ADDR", "NAME_FIRST_NAME","NAME_MIDDLE_NAME","NAME_LAST_NAME", "BIRTH_DATE", "GENDER", "POSTAL_ADDRESS_ADDR_LINE_1","POSTAL_ADDRESS_ADDR_LINE_2","POSTAL_ADDRESS_CITY","POSTAL_ADDRESS_COUNTY","POSTAL_ADDRESS_STATE_CD","POSTAL_ADDRESS_ZIP_CD_5","POSTAL_ADDRESS_ZIP_CD_4", "EMAIL", "PHONE_NUMBER", "TKT_OPEN_DT").fillna(value="") 

df_read = df_read.select("TKT_NBR",	"TASK_ID",	"CUST_SK",	"CUST_SRC_ID",	"SRC_SYS_CD",	"LV_FLAG",	"TKT_OPEN_DT",	"CUST_FIRST_NAME",	"CUST_MIDDLE_NAME",	"CUST_LAST_NAME",	"CUST_EML_ADDR",	"EDW_TKT_RECEIVE_DT", trim(concat_ws(' ',"NAME_FIRST_NAME","NAME_MIDDLE_NAME","NAME_LAST_NAME")).alias("NAME"),	"BIRTH_DATE",	"GENDER",trim(concat_ws(' ',"POSTAL_ADDRESS_ADDR_LINE_1","POSTAL_ADDRESS_ADDR_LINE_2","POSTAL_ADDRESS_CITY","POSTAL_ADDRESS_COUNTY","POSTAL_ADDRESS_STATE_CD","POSTAL_ADDRESS_ZIP_CD_5","POSTAL_ADDRESS_ZIP_CD_4")).alias("POSTAL_ADDRESS"),	"EMAIL",	"PHONE_NUMBER",	"SALES_TOTAL",	"SALES_IND",	"SALES_TX_TOTAL",	"SALES_TX_IND",	"PROG_CD",	"LOYALTY_CARD_NO",	"ENROLMENT_DATE",	"ENROLMENT_CHANNEL",	"MEMBER_PINTS_BALANCE",	"TOTAL_POINTS_EARNED_LIFETIME",	"TOTAL_POINTS_REDEEMED_LIFETIME",	"CUST_PREF_PROG_NAME",	"PROG_START_DATE",	"PROG_END_DATE",	"PROG_OPTIN_DATE",	"PROG_OPTOUT_DATE",	"PURCHASE_DATE",	"PAYMENT_TYPE",	"TENDERS_DOLLARS",	"ACCOUNT_NUMBER",	"CARD_FIRST_6_DIGITS",	"CARD_LAST_4_DIGITS",	"PURCHASE_TYPE",	"POS_PURCHASE_DATE",	"POS_PRODUCT_DESCRIPTION",	"POS_TOTAL_QTY",	"POS_TOTAL_SALES",	"POS_RETURNS_QTY",	"ECOM_RETURN_REPORTED_DATE",	"ECOM_QTY_TO_RETURN",	"ECOM_TOT_RETURN_DLRS",	"ECOM_PROD_DESC",	"ECOM_PUR_PURCHASE_DATE",	"ECOM_PUR_PROD_DESC",	"ECOM_PUR_TOTAL_SALES",	"ECOM_PUR_UNIT_QTY",	"CUST_PREF_TYPE_CD","CUST_PREF_VAL","mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs")

# df_read = df_read.select("TKT_NBR","TASK_ID", "CUST_SK", "CUST_SRC_ID", "LV_FLAG", "CUST_FIRST_NAME", "CUST_MIDDLE_NAME", "CUST_LAST_NAME", "CUST_EML_ADDR", concat_ws(' ',"NAME_FIRST_NAME","NAME_MIDDLE_NAME","NAME_LAST_NAME").alias("NAME"), "BIRTH_DATE", "GENDER" ,concat_ws(' ',"POSTAL_ADDRESS_ADDR_LINE_1","POSTAL_ADDRESS_ADDR_LINE_2","POSTAL_ADDRESS_CITY","POSTAL_ADDRESS_COUNTY","POSTAL_ADDRESS_STATE_CD","POSTAL_ADDRESS_ZIP_CD_5","POSTAL_ADDRESS_ZIP_CD_4").alias("POSTAL_ADDRESS"), "EMAIL", "PHONE_NUMBER", "TKT_OPEN_DT").fillna(value="")

# Set empty strings back to nulls
df_read = df_read.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in df_read.columns]) ## 
df_read.show()
#display(df_read)

# COMMAND ----------

display(df_read)

# COMMAND ----------

df_req_list = df_read.select("TKT_NBR","TASK_ID", "CUST_SK", "CUST_SRC_ID", "LV_FLAG", "CUST_FIRST_NAME", "CUST_MIDDLE_NAME", "CUST_LAST_NAME", "CUST_EML_ADDR", "NAME", "BIRTH_DATE", "GENDER", "POSTAL_ADDRESS", "EMAIL", "PHONE_NUMBER", "TKT_OPEN_DT")

df_req_list = df_req_list.withColumn("CUST_SK", df_req_list["CUST_SK"].cast(StringType()))

df_req_list_csv = df_req_list \
                          .withColumn('REQ_ID', df_req_list.TKT_NBR) \
                          .withColumn('REPORT_TYPE', df_req_list.LV_FLAG) \
                          .withColumn('PI_CATEGORY', lit('Customer Information')) \
                          .withColumn('PI_TYPE', lit('First Name')) \
                          .withColumn("PI_VALUE", lit(str(df_req_list.select("CUST_FIRST_NAME").distinct().rdd.map(lambda row : row[0]).filter(
            lambda x: x is not None).collect()))) \
                          .withColumn('APP_ID', lit('DAE')) \
                          .withColumn('EVENT_TS', df_req_list.TKT_OPEN_DT) \
                          .withColumn('COMMENT', lit('')) \
                          .withColumn('DP1', lit('')) \
                          .withColumn('DP2', lit('')) \
                          .withColumn('DP3', lit('')) \
                          .withColumn('DP4', lit('')) \
                          .withColumn('DP5', lit('')) \
                          .select ("CUST_SK", "CUST_SRC_ID", "REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5", "CUST_LAST_NAME", "CUST_EML_ADDR") \
                          .drop_duplicates()


df_req_list_csv = df_req_list_csv.withColumn("PI_VALUE", concat_ws(",", col("PI_VALUE")))
#df_req_list_csv.show()
#df_req_list_csv = df_req_list_csv.withColumn("PI_VALUE", ''.join(df_req_list_csv.PI_VALUE))


#df_req_list_csv.show()
df_mname = df_req_list_csv
df_mname = df_mname \
              .withColumn('PI_TYPE', lit('Middle Name')) \
              .withColumn("PI_VALUE", lit(str(df_req_list.select("CUST_MIDDLE_NAME").distinct().rdd.map(lambda row : row[0]).filter(
            lambda x: x is not None).collect()))) \
              .drop("NAME","CUST_MIDDLE_NAME","CUST_LAST_NAME", "CUST_EML_ADDR")


df_lname = df_req_list_csv
df_lname = df_lname \
              .withColumn('PI_TYPE', lit('Last Name')) \
              .withColumn("PI_VALUE", lit(str(df_req_list.select("CUST_LAST_NAME").distinct().rdd.map(lambda row : row[0]).filter(
            lambda x: x is not None).collect()))) \
              .drop("NAME","CUST_MIDDLE_NAME","CUST_LAST_NAME", "CUST_EML_ADDR")
              
#df_lname.show()

df_flname = df_req_list_csv
df_flname = df_flname \
            .withColumn('PI_TYPE', lit('Name')) \
            .withColumn("PI_VALUE", lit(str(df_req_list.select("NAME").distinct().rdd.map(lambda row : row[0]).filter(
            lambda x: x is not None).collect()))) \
            .drop("NAME","CUST_MIDDLE_NAME","CUST_LAST_NAME", "CUST_EML_ADDR")

df_email = df_req_list_csv
df_email = df_email \
            .withColumn('PI_TYPE', lit('Email Addresses')) \
            .withColumn("PI_VALUE", lit(str(df_req_list.select("CUST_EML_ADDR").distinct().rdd.map(lambda row : row[0]).filter(
            lambda x: x is not None).collect()))) \
            .drop("NAME","CUST_MIDDLE_NAME","CUST_LAST_NAME", "CUST_EML_ADDR")
#df_email.show()

df_req_list_csv = df_req_list_csv.drop("NAME","CUST_MIDDLE_NAME","CUST_LAST_NAME", "CUST_EML_ADDR")
#df_req_list_csv.show()

df_req_union = df_req_list_csv.union(df_mname)
df_req_union = df_req_union.union(df_lname)
df_req_union = df_req_union.union(df_flname)
df_req_union = df_req_union.union(df_email)
#df_req_union.show()

df_join_all = df_req_union.drop("CUST_SK", "CUST_SRC_ID").drop_duplicates()
display(df_join_all)
#df_join_all.show()

                                      



# COMMAND ----------

df_cust = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT", "BIRTH_DATE", "GENDER", "POSTAL_ADDRESS", "EMAIL", "PHONE_NUMBER")
#df_cust.show()

df_cust = df_cust.dropDuplicates()


#df_req_union_cust = df_req_union.join(df_cust, df_req_union.CUST_SK==df_cust.CUST_SK, "full").drop(df_req_union.CUST_SK)

df_cust = df_cust.withColumn("BIRTH_DATE", df_cust["BIRTH_DATE"].cast(StringType()))

df_cust = df_cust \
               .withColumn("PHONE_NUMBER", when (df_cust.PHONE_NUMBER.isNull(), " ").otherwise(df_cust.PHONE_NUMBER)) \
#df_req_union_cust.show()

df_req_union_bd = df_cust \
              .filter(df_cust.BIRTH_DATE != '') \
              .withColumn('PI_CATEGORY', lit('Customer Information')) \
              .withColumn('PI_TYPE', lit('Birth Date')) \
              .withColumn("PI_VALUE", df_cust.BIRTH_DATE ) \
              .withColumn('REQ_ID', df_cust.TKT_NBR) \
              .withColumn('REPORT_TYPE', df_cust.LV_FLAG) \
			  .withColumn('APP_ID', lit('DAE')) \
              .withColumn('EVENT_TS', df_cust.TKT_OPEN_DT) \
              .withColumn('COMMENT', lit('')) \
              .withColumn('DP1', lit('')) \
              .withColumn('DP2', lit('')) \
              .withColumn('DP3', lit('')) \
              .withColumn('DP4', lit('')) \
              .withColumn('DP5', lit('')) \
              .drop("BIRTH_DATE", "GENDER", "POSTAL_ADDRESS", "EMAIL", "PHONE_NUMBER") \
             .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_req_union_bd.show()

df_join_all = df_join_all.union(df_req_union_bd)
#display(df_join_all)

df_req_union_gnd = df_cust \
              .filter((df_cust.GENDER != '') ) \
              .withColumn('PI_CATEGORY', lit('Customer Information')) \
              .withColumn('PI_TYPE', lit('Gender')) \
              .withColumn("PI_VALUE", df_cust.GENDER ) \
              .withColumn('REQ_ID', df_cust.TKT_NBR) \
              .withColumn('REPORT_TYPE', df_cust.LV_FLAG) \
			  .withColumn('APP_ID', lit('DAE')) \
              .withColumn('EVENT_TS', df_cust.TKT_OPEN_DT) \
              .withColumn('COMMENT', lit('')) \
              .withColumn('DP1', lit('')) \
              .withColumn('DP2', lit('')) \
              .withColumn('DP3', lit('')) \
              .withColumn('DP4', lit('')) \
              .withColumn('DP5', lit('')) \
              .drop("BIRTH_DATE", "NAME", "GENDER", "POSTAL_ADDRESS", "EMAIL", "PHONE_NUMBER") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_req_union_gnd.show()
df_join_all = df_join_all.union(df_req_union_gnd)


df_cust_pa = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT", "POSTAL_ADDRESS")
df_cust_pa = df_cust_pa.filter(df_cust_pa.POSTAL_ADDRESS.isNotNull())
df_cust_pa = df_cust_pa.dropDuplicates()

df_req_union_pa = df_cust_pa \
               .withColumn('PI_CATEGORY', lit('Customer Information')) \
              .withColumn('PI_TYPE', lit('Postal Address')) \
              .withColumn("PI_VALUE", lit(str(df_cust_pa.select("POSTAL_ADDRESS").distinct().rdd.map(lambda row : row[0]).collect()))) \
              .withColumn('REQ_ID', df_cust_pa.TKT_NBR) \
              .withColumn('REPORT_TYPE', df_cust_pa.LV_FLAG) \
			  .withColumn('APP_ID', lit('DAE')) \
              .withColumn('EVENT_TS', df_cust_pa.TKT_OPEN_DT) \
              .withColumn('COMMENT', lit('')) \
              .withColumn('DP1', lit('')) \
              .withColumn('DP2', lit('')) \
              .withColumn('DP3', lit('')) \
              .withColumn('DP4', lit('')) \
              .withColumn('DP5', lit('')) \
              .drop("BIRTH_DATE", "NAME", "GENDER", "POSTAL_ADDRESS", "EMAIL", "PHONE_NUMBER") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_req_union_pa.show()
df_join_all = df_join_all.union(df_req_union_pa)


df_cust_ph = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT", "PHONE_NUMBER")
df_cust_ph = df_cust_ph.filter(df_cust_ph.PHONE_NUMBER.isNotNull())
df_cust_ph = df_cust_ph.dropDuplicates()
#df_cust_ph.show()

df_req_union_tel = df_cust_ph \
              .withColumn('PI_CATEGORY', lit('Customer Information')) \
              .withColumn('PI_TYPE', lit('Contact')) \
              .withColumn("PI_VALUE", lit(str(df_cust_ph.select("PHONE_NUMBER").distinct().rdd.map(lambda row : row[0]).collect()))) \
              .withColumn('REQ_ID', df_cust_ph.TKT_NBR) \
              .withColumn('REPORT_TYPE', df_cust_ph.LV_FLAG) \
			  .withColumn('APP_ID', lit('DAE')) \
              .withColumn('EVENT_TS', df_cust_ph.TKT_OPEN_DT) \
              .withColumn('COMMENT', lit('')) \
              .withColumn('DP1', lit('')) \
              .withColumn('DP2', lit('')) \
              .withColumn('DP3', lit('')) \
              .withColumn('DP4', lit('')) \
              .withColumn('DP5', lit('')) \
              .drop("BIRTH_DATE", "NAME", "GENDER", "POSTAL_ADDRESS", "EMAIL", "PHONE_NUMBER") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_req_union_tel.show()
df_join_all = df_join_all.union(df_req_union_tel)
#display(df_join_all)

# COMMAND ----------

from pyspark.sql import functions as f
#df_join_all = df_join_all.filter(df_join_all.REQ_ID !='')

df_join_all = df_join_all.withColumn("LENGHT", f.length('PI_VALUE'))\
                          .withColumn("PI_VALUE", when((lower(df_join_all.PI_TYPE)=='last name') | (lower(df_join_all.PI_TYPE)=='middle name') |(lower(df_join_all.PI_TYPE)=='first name') | 
                                                       (lower(df_join_all.PI_TYPE)=='name') |(lower(df_join_all.PI_TYPE)=='email addresses') | (lower(df_join_all.PI_TYPE)=='contact') |     (lower(df_join_all.PI_TYPE)=='postal address') | (lower(df_join_all.PI_TYPE)=='subscription')\
                                                              , f.col('PI_VALUE').substr(f.lit(3), f.col('LENGHT') - f.lit(4)))\
                                                                .otherwise(df_join_all.PI_VALUE)).drop("LENGHT")

df_join_all = df_join_all.withColumn("PI_VALUE",when((lower(df_join_all.PI_TYPE)=='postal address') | (lower(df_join_all.PI_TYPE)=='contact') | (lower(df_join_all.PI_TYPE)=='first name') |
                                                (lower(df_join_all.PI_TYPE)=='last name') | (lower(df_join_all.PI_TYPE)=='name') | (lower(df_join_all.PI_TYPE)=='email addresses')   
                                        , regexp_replace("PI_VALUE", "\'", ""))\
                                                     .otherwise(df_join_all.PI_VALUE))
display(df_join_all)

# COMMAND ----------

#Sales and Tax code for Nested CSV

df_sales_tot = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "SALES_TOTAL", "SALES_IND","TKT_OPEN_DT")
#df_sales = df_req_union.join(df_sales, df_req_union.CUST_SRC_ID==df_sales.CUST_SRC_ID, "full") \
                    #.drop(df_sales.CUST_SRC_ID)
df_sales_tot = df_sales_tot.dropDuplicates()
df_sales_tot = df_sales_tot.filter(df_sales_tot.SALES_TOTAL.isNotNull())
#df_sales_tot.show()

df_sales_tot = df_sales_tot.withColumn("SALES_TOTAL", when(df_sales_tot.SALES_TOTAL.isNull(), "0") \
                                              .otherwise(df_sales_tot.SALES_TOTAL)) \
                  .withColumn("SALES_IND", when(df_sales_tot.SALES_IND.isNull(), "") \
                                              .otherwise(df_sales_tot.SALES_IND)) \
                   .withColumn('REQ_ID', df_sales_tot.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_sales_tot.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_sales_tot.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit(''))

df_sales_tot = df_sales_tot \
              .withColumn('PI_CATEGORY', lit('Sales Transaction Summary')) \
              .withColumn('PI_TYPE', lit('Total amount spent')) \
              .withColumn("PI_VALUE", concat(lit('sales_total:'),df_sales_tot.SALES_TOTAL,lit(','), lit('sales_ind:'),df_sales_tot.SALES_IND )) \
              .drop("SALES_TOTAL", "SALES_IND") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_sales_tot.show()



df_sales_tax = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "SALES_TX_TOTAL", "SALES_TX_IND","TKT_OPEN_DT")
df_sales_tax = df_sales_tax.dropDuplicates()
df_sales_tax = df_sales_tax.filter(df_sales_tax.SALES_TX_TOTAL.isNotNull())
#df_sales_tax.show()

df_sales_tax = df_sales_tax.withColumn("SALES_TOTAL", when(df_sales_tax.SALES_TX_TOTAL.isNull(), "0") \
                                              .otherwise(df_sales_tax.SALES_TX_TOTAL)) \
                  .withColumn("SALES_IND", when(df_sales_tax.SALES_TX_IND.isNull(), "") \
                                              .otherwise(df_sales_tax.SALES_TX_IND)) \
                   .withColumn('REQ_ID', df_sales_tax.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_sales_tax.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_sales_tax.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit(''))

df_sales_tax = df_sales_tax \
              .withColumn('PI_CATEGORY', lit('Sales Transaction Summary')) \
              .withColumn('PI_TYPE', lit('Total tax paid')) \
              .withColumn("PI_VALUE", concat(lit('sales_tx_total:'),df_sales_tax.SALES_TX_TOTAL,lit(','), lit('sales_tx_ind:'),df_sales_tax.SALES_TX_IND )) \
              .drop("SALES_TX_TOTAL", "SALES_TX_IND") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_sales_tax.show()


df_join_all = df_join_all.union(df_sales_tot)
df_join_all = df_join_all.union(df_sales_tax)

df_join_all = df_join_all.drop_duplicates()
#df_join_all.show()
#display(df_join_all)

# COMMAND ----------

#Loyalty Member information code for nested CSV

from pyspark.sql import Window

join_df_loyalty_mem = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT","CUST_SRC_ID", "PROG_CD", "LOYALTY_CARD_NO", "ENROLMENT_DATE", "ENROLMENT_CHANNEL", "MEMBER_PINTS_BALANCE", "TOTAL_POINTS_EARNED_LIFETIME", "TOTAL_POINTS_REDEEMED_LIFETIME")

#join_df_loyalty.show()

join_df_loyalty_mem = join_df_loyalty_mem.filter(join_df_loyalty_mem.LOYALTY_CARD_NO.isNotNull())
join_df_loyalty_mem = join_df_loyalty_mem.dropDuplicates()

#join_df_loyalty.show()


join_df_loyalty_mem = join_df_loyalty_mem.withColumn("PROG_CD", when(join_df_loyalty_mem.PROG_CD.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.PROG_CD)) \
                  .withColumn("LOYALTY_CARD_NO", when(join_df_loyalty_mem.LOYALTY_CARD_NO.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.LOYALTY_CARD_NO)) \
                  .withColumn("ENROLMENT_DATE", when(join_df_loyalty_mem.ENROLMENT_DATE.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.ENROLMENT_DATE)) \
                  .withColumn("ENROLMENT_CHANNEL", when(join_df_loyalty_mem.ENROLMENT_CHANNEL.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.ENROLMENT_CHANNEL)) \
                  .withColumn("MEMBER_PINTS_BALANCE", when(join_df_loyalty_mem.MEMBER_PINTS_BALANCE.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.MEMBER_PINTS_BALANCE)) \
                  .withColumn("TOTAL_POINTS_EARNED_LIFETIME", when(join_df_loyalty_mem.TOTAL_POINTS_EARNED_LIFETIME.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.TOTAL_POINTS_EARNED_LIFETIME)) \
                  .withColumn("TOTAL_POINTS_REDEEMED_LIFETIME", when(join_df_loyalty_mem.TOTAL_POINTS_REDEEMED_LIFETIME.isNull(), "") \
                                              .otherwise(join_df_loyalty_mem.TOTAL_POINTS_REDEEMED_LIFETIME)) \
                                      .withColumn('REQ_ID', join_df_loyalty_mem.TKT_NBR) \
                                      .withColumn('REPORT_TYPE', join_df_loyalty_mem.LV_FLAG) \
                                      .withColumn('APP_ID', lit('DAE')) \
                                      .withColumn('EVENT_TS', join_df_loyalty_mem.TKT_OPEN_DT) \
                                      .withColumn('COMMENT', lit('')) \
                                      .withColumn('DP1', lit('')) \
                                      .withColumn('DP2', lit('')) \
                                      .withColumn('DP3', lit('')) \
                                      .withColumn('DP4', lit('')) \
                                      .withColumn('DP5', lit(''))

join_df_loyalty_mem = join_df_loyalty_mem \
              .withColumn('PI_CATEGORY', lit('Loyalty Information')) \
              .withColumn('PI_TYPE', concat(lit('Loyalty Member Id:'))) \
              .withColumn("PI_VALUE", concat(lit("Loyalty Member Id:"), join_df_loyalty_mem.CUST_SRC_ID, lit(','), \
                                             lit("PROG_CD:"), join_df_loyalty_mem.PROG_CD, lit(','), \
                                             lit('Loyalty Card Number:'),join_df_loyalty_mem.LOYALTY_CARD_NO,lit(','), \
                                             lit('Enrollment Date:'),join_df_loyalty_mem.ENROLMENT_DATE ,lit(','), \
                                             lit('Enrollment Channel:'),join_df_loyalty_mem.ENROLMENT_CHANNEL ,lit(','), \
                                             lit('Current Point Balance:'),join_df_loyalty_mem.MEMBER_PINTS_BALANCE ,lit(','), \
                                             lit('Lifetime Points Earned:'),join_df_loyalty_mem.TOTAL_POINTS_EARNED_LIFETIME ,lit(','), \
                                             lit('Lifetime Points Redeemed:'),join_df_loyalty_mem.TOTAL_POINTS_REDEEMED_LIFETIME \
                                            )) \
              .drop("PROG_CD", "LOYALTY_CARD_NO", "ENROLMENT_DATE", "ENROLMENT_CHANNEL", "MEMBER_PINTS_BALANCE", "TOTAL_POINTS_EARNED_LIFETIME", "TOTAL_POINTS_REDEEMED_LIFETIME" ) \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

join_df_loyalty_mem = join_df_loyalty_mem.filter(join_df_loyalty_mem.PI_VALUE.isNotNull())

window = Window.orderBy("PI_VALUE")
join_df_loyalty_mem = join_df_loyalty_mem \
               .withColumn('PI_TYPE', concat(lit('Loyalty Member Id:'), row_number().over(window)))
#join_df_loyalty_mem.show()

df_join_all = df_join_all.union(join_df_loyalty_mem)

# COMMAND ----------

#Loyalty Offer to the customer information code for nested CSV

join_df_loyalty_offer = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT","CUST_SRC_ID", "CUST_PREF_PROG_NAME", "PROG_START_DATE", "PROG_END_DATE", "PROG_OPTIN_DATE", "PROG_OPTOUT_DATE")

#join_df_loyalty.show()

join_df_loyalty_offer = join_df_loyalty_offer.filter(join_df_loyalty_offer.CUST_PREF_PROG_NAME.isNotNull())
join_df_loyalty_offer = join_df_loyalty_offer.dropDuplicates()

#join_df_loyalty.show()


join_df_loyalty_offer = join_df_loyalty_offer.withColumn("CUST_PREF_PROG_NAME", when(join_df_loyalty_offer.CUST_PREF_PROG_NAME.isNull(), "") \
                                              .otherwise(join_df_loyalty_offer.CUST_PREF_PROG_NAME)) \
                  .withColumn("PROG_START_DATE", when(join_df_loyalty_offer.PROG_START_DATE.isNull(), "") \
                                              .otherwise(join_df_loyalty_offer.PROG_START_DATE)) \
                  .withColumn("PROG_END_DATE", when(join_df_loyalty_offer.PROG_END_DATE.isNull(), "") \
                                              .otherwise(join_df_loyalty_offer.PROG_END_DATE)) \
                  .withColumn("PROG_OPTIN_DATE", when(join_df_loyalty_offer.PROG_OPTIN_DATE.isNull(), "") \
                                              .otherwise(join_df_loyalty_offer.PROG_OPTIN_DATE)) \
                  .withColumn("PROG_OPTOUT_DATE", when(join_df_loyalty_offer.PROG_OPTOUT_DATE.isNull(), "") \
                                              .otherwise(join_df_loyalty_offer.PROG_OPTOUT_DATE)) \
                   .withColumn('REQ_ID', join_df_loyalty_offer.TKT_NBR) \
                                      .withColumn('REPORT_TYPE', join_df_loyalty_offer.LV_FLAG) \
                                      .withColumn('APP_ID', lit('DAE')) \
                                      .withColumn('EVENT_TS', join_df_loyalty_offer.TKT_OPEN_DT) \
                                      .withColumn('COMMENT', lit('')) \
                                      .withColumn('DP1', lit('')) \
                                      .withColumn('DP2', lit('')) \
                                      .withColumn('DP3', lit('')) \
                                      .withColumn('DP4', lit('')) \
                                      .withColumn('DP5', lit(''))

join_df_loyalty_offer = join_df_loyalty_offer \
              .withColumn('PI_CATEGORY', lit('Loyalty offers made to the customer')) \
              .withColumn('PI_TYPE', concat(lit('Loyalty Member Id:'))) \
              .withColumn("PI_VALUE", concat(lit('Loyalty Member Id:'),join_df_loyalty_offer.CUST_SRC_ID ,lit(','), \
                                             lit('Loyalty Offer:'),join_df_loyalty_offer.CUST_PREF_PROG_NAME ,lit(','), \
                                             lit('Offer Opt In Date:'),join_df_loyalty_offer.PROG_START_DATE ,lit(','), \
                                             lit('Offer Opt Out Date:'),join_df_loyalty_offer.PROG_END_DATE ,lit(','), \
                                             lit('Date Opted In:'),join_df_loyalty_offer.PROG_OPTIN_DATE ,lit(','), \
                                             lit('Date Opted out:'),join_df_loyalty_offer.PROG_OPTOUT_DATE \
                                            )) \
              .drop("CUST_PREF_PROG_NAME", "PROG_START_DATE", "PROG_END_DATE", "PROG_OPTIN_DATE", "PROG_OPTOUT_DATE" ) \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

join_df_loyalty_offer = join_df_loyalty_offer.filter(join_df_loyalty_offer.PI_VALUE.isNotNull())

window = Window.orderBy("PI_VALUE")
join_df_loyalty_offer = join_df_loyalty_offer \
               .withColumn('PI_TYPE', concat(lit('Loyalty Member Id:'), row_number().over(window)))
#join_df_loyalty_offer.show()
#display(join_df_loyalty_offer)


df_join_all = df_join_all.union(join_df_loyalty_offer)
df_join_all = df_join_all.drop_duplicates()
#display(df_join_all)

# COMMAND ----------

df_summ_rep = df_join_all
#df_summ_rep.show()

# COMMAND ----------

#In-Store transactions Details

df_ecom_instore = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT", "POS_PURCHASE_DATE", "POS_PRODUCT_DESCRIPTION", "POS_TOTAL_QTY", "POS_TOTAL_SALES", "POS_RETURNS_QTY")

# df_ecom = df_req_union.join(join_ecom_trans_df, df_req_union.CUST_SRC_ID==join_ecom_trans_df.CUST_SRC_ID, "full") \
#                     .drop(join_ecom_trans_df.CUST_SRC_ID)
#df_ecom.show()

df_ecom_instore =df_ecom_instore.dropDuplicates()
df_ecom_instore =df_ecom_instore.filter(df_ecom_instore.POS_PURCHASE_DATE.isNotNull())

df_ecom_instore = df_ecom_instore \
                  .withColumn("POS_PURCHASE_DATE", when(df_ecom_instore.POS_PURCHASE_DATE.isNull(), "") \
                                              .otherwise(df_ecom_instore.POS_PURCHASE_DATE)) \
                  .withColumn("POS_PRODUCT_DESCRIPTION", when(df_ecom_instore.POS_PRODUCT_DESCRIPTION.isNull(), "") \
                                              .otherwise(df_ecom_instore.POS_PRODUCT_DESCRIPTION)) \
                  .withColumn("POS_TOTAL_QTY", when(df_ecom_instore.POS_TOTAL_QTY.isNull(), "") \
                                              .otherwise(df_ecom_instore.POS_TOTAL_QTY)) \
                  .withColumn("POS_TOTAL_SALES", when(df_ecom_instore.POS_TOTAL_SALES.isNull(), "") \
                                              .otherwise(df_ecom_instore.POS_TOTAL_SALES)) \
                  .withColumn("POS_RETURNS_QTY", when(df_ecom_instore.POS_RETURNS_QTY.isNull(), "") \
                                              .otherwise(df_ecom_instore.POS_RETURNS_QTY)) \
                  .withColumn('REQ_ID', df_req_list.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_req_list.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_req_list.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit('')) 
    
         

df_ecom_instore = df_ecom_instore \
              .withColumn('REPORT_TYPE', df_ecom_instore.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('In Store Purchase')) \
              .withColumn('PI_TYPE', concat(lit('In Store Purchase:'))) \
              .withColumn("PI_VALUE", concat(lit("Purchase Date:"), df_ecom_instore.POS_PURCHASE_DATE, lit(','), \
                                             lit('Product Description:'),df_ecom_instore.POS_PRODUCT_DESCRIPTION,lit(','), \
                                             lit('Total Quantity:'),df_ecom_instore.POS_TOTAL_QTY ,lit(','), \
                                             lit('Total Sales ($):'),df_ecom_instore.POS_TOTAL_SALES ,lit(','), \
                                             lit('Return Quantity:'),df_ecom_instore.POS_RETURNS_QTY \
                                            )) \
              .drop("POS_PURCHASE_DATE", "POS_PRODUCT_DESCRIPTION", "POS_TOTAL_QTY", "POS_TOTAL_SALES", "POS_RETURNS_QTY" ) \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

window = Window.orderBy("PI_VALUE")
df_ecom_instore = df_ecom_instore \
               .withColumn('PI_TYPE', concat(lit('In Store Purchase:'), row_number().over(window)))

# df_ecom_instore = df_ecom_instore.drop("TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5")
# df_ecom_instore = df_ecom_instore.join(df_ecom_instore1, df_ecom_instore.REQ_ID==df_ecom_instore1.REQ_ID, "full").drop(df_ecom_instore.REQ_ID) 
#df_ecom_instore.show()

df_join_all = df_join_all.union(df_ecom_instore)
#display(df_join_all)

# COMMAND ----------

# Online Transactions Details
#-------------------------------------------------

df_ecom_pur_online = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT","ECOM_PUR_PURCHASE_DATE", "ECOM_PUR_PROD_DESC", "ECOM_PUR_TOTAL_SALES", "ECOM_PUR_UNIT_QTY" )

df_ecom_pur_online = df_ecom_pur_online.dropDuplicates()
df_ecom_pur_online = df_ecom_pur_online.filter(df_ecom_pur_online.ECOM_PUR_PURCHASE_DATE.isNotNull())

df_ecom_pur_online=df_ecom_pur_online.withColumn("ECOM_PUR_PURCHASE_DATE", when(df_ecom_pur_online.ECOM_PUR_PURCHASE_DATE.isNull(), "") \
                                              .otherwise(df_ecom_pur_online.ECOM_PUR_PURCHASE_DATE)) \
                  .withColumn("ECOM_PUR_PROD_DESC", when(df_ecom_pur_online.ECOM_PUR_PROD_DESC.isNull(), "") \
                                              .otherwise(df_ecom_pur_online.ECOM_PUR_PROD_DESC)) \
                  .withColumn("ECOM_PUR_TOTAL_SALES", when(df_ecom_pur_online.ECOM_PUR_TOTAL_SALES.isNull(), "") \
                                              .otherwise(df_ecom_pur_online.ECOM_PUR_TOTAL_SALES)) \
                  .withColumn("ECOM_PUR_UNIT_QTY", when(df_ecom_pur_online.ECOM_PUR_UNIT_QTY.isNull(), "") \
                                              .otherwise(df_ecom_pur_online.ECOM_PUR_UNIT_QTY)) \
                  .withColumn('REQ_ID', df_req_list.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_req_list.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_req_list.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit(''))

df_ecom_pur_online= df_ecom_pur_online \
              .withColumn('REPORT_TYPE', df_ecom_pur_online.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Online Purchase')) \
              .withColumn('PI_TYPE', concat(lit('Online Purchase:'))) \
              .withColumn("PI_VALUE", concat(lit("Purchase Date:"), df_ecom_pur_online.ECOM_PUR_PURCHASE_DATE, lit(','), \
                                             lit('Product Description:'),df_ecom_pur_online.ECOM_PUR_PROD_DESC,lit(','), \
                                             lit('Total Quantity:'),df_ecom_pur_online.ECOM_PUR_UNIT_QTY ,lit(','), \
                                             lit('Total Sales ($):'),df_ecom_pur_online.ECOM_PUR_TOTAL_SALES \
                                            ))\
              .drop("ECOM_PUR_PURCHASE_DATE", "ECOM_PUR_PROD_DESC", "ECOM_PUR_TOTAL_SALES", "ECOM_PUR_UNIT_QTY"  ) \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

#df_ecom_pur_online.show()

window = Window.orderBy("PI_VALUE")
df_ecom_pur_online = df_ecom_pur_online \
               .withColumn('PI_TYPE', concat(lit('Online Purchase:'), row_number().over(window)))

df_join_all = df_join_all.union(df_ecom_pur_online)
#display(df_join_all)

#df_ecom_pur_online.show()


#df_ecom_pur_online = df_ecom_pur_online.filter(df_ecom_pur_online.CUST_SRC_ID.isNotNull())
# df_ecom_instore.show()

#df_ecom_pur_online1 = df_ecom_pur_online.drop("CUST_SK", "CUST_SRC_ID").drop_duplicates()



# df_ecom_pur_online = df_ecom_pur_online.drop("TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5")
# df_ecom_pur_online = df_ecom_pur_online.join(df_ecom_pur_online1, df_ecom_pur_online.REQ_ID==df_ecom_pur_online1.REQ_ID, "full").drop(df_ecom_pur_online.REQ_ID) 
#                  
#df_ecom_pur_online.show()

# COMMAND ----------

# Online Return Details

df_ecom_ret_online = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT","ECOM_RETURN_REPORTED_DATE", "ECOM_QTY_TO_RETURN", "ECOM_TOT_RETURN_DLRS", "ECOM_PROD_DESC")

df_ecom_ret_online = df_ecom_ret_online.dropDuplicates()
df_ecom_ret_online = df_ecom_ret_online.filter(df_ecom_ret_online.ECOM_RETURN_REPORTED_DATE.isNotNull())

df_ecom_ret_online = df_ecom_ret_online.withColumn("ECOM_RETURN_REPORTED_DATE", when(df_ecom_ret_online.ECOM_RETURN_REPORTED_DATE.isNull(), "") \
                                              .otherwise(df_ecom_ret_online.ECOM_RETURN_REPORTED_DATE)) \
                  .withColumn("ECOM_QTY_TO_RETURN", when(df_ecom_ret_online.ECOM_QTY_TO_RETURN.isNull(), "") \
                                              .otherwise(df_ecom_ret_online.ECOM_QTY_TO_RETURN)) \
                  .withColumn("ECOM_TOT_RETURN_DLRS", when(df_ecom_ret_online.ECOM_TOT_RETURN_DLRS.isNull(), "") \
                                              .otherwise(df_ecom_ret_online.ECOM_TOT_RETURN_DLRS)) \
                  .withColumn("ECOM_PROD_DESC", when(df_ecom_ret_online.ECOM_PROD_DESC.isNull(), "") \
                                              .otherwise(df_ecom_ret_online.ECOM_PROD_DESC)) \
                  .withColumn('REQ_ID', df_req_list.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_req_list.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_req_list.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit(''))

df_ecom_ret_online= df_ecom_ret_online \
              .withColumn('REPORT_TYPE', df_ecom_ret_online.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Online Return')) \
              .withColumn('PI_TYPE', concat(lit('Online Return:'))) \
              .withColumn("PI_VALUE", concat(lit("Return Reported Date:"), df_ecom_ret_online.ECOM_RETURN_REPORTED_DATE, lit(','), \
                                             lit('Product Description:'),df_ecom_ret_online.ECOM_PROD_DESC,lit(','), \
                                             lit('Quantity to Return:'),df_ecom_ret_online.ECOM_QTY_TO_RETURN ,lit(','), \
                                             lit('Total Return Dollars:'),df_ecom_ret_online.ECOM_TOT_RETURN_DLRS  \
                                            )) \
              .drop("ECOM_RETURN_REPORTED_DATE", "ECOM_QTY_TO_RETURN", "ECOM_TOT_RETURN_DLRS", "ECOM_PROD_DESC") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_ecom_ret_online.show()

window = Window.orderBy("PI_VALUE")
df_ecom_ret_online = df_ecom_ret_online \
               .withColumn('PI_TYPE', concat(lit('Online Return:'), row_number().over(window)))


df_join_all = df_join_all.union(df_ecom_ret_online)
#display(df_join_all)

#df_ecom_ret_online = df_ecom_ret_online.filter(df_ecom_ret_online.CUST_SRC_ID.isNotNull())
# df_ecom_instore.show()

#df_ecom_ret_online1 = df_ecom_ret_online.drop("CUST_SK", "CUST_SRC_ID").drop_duplicates()



# df_ecom_ret_online = df_ecom_ret_online.drop("TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5")
# df_ecom_ret_online = df_ecom_ret_online.join(df_ecom_ret_online1, df_ecom_ret_online.REQ_ID==df_ecom_ret_online1.REQ_ID, "full").drop(df_ecom_ret_online.REQ_ID) 
#                  
#df_ecom_ret_online.show()

# COMMAND ----------

#Online payment details code for nested CSV
#--------------------------------------------------------------------------------------------

df_ecom_pay_det = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT","PURCHASE_DATE", "PAYMENT_TYPE", "TENDERS_DOLLARS", "ACCOUNT_NUMBER", "CARD_FIRST_6_DIGITS","CARD_LAST_4_DIGITS", "PURCHASE_TYPE")
df_ecom_pay_det = df_ecom_pay_det.dropDuplicates()
df_ecom_pay_det = df_ecom_pay_det.filter(df_ecom_pay_det.PURCHASE_DATE.isNotNull())

df_ecom_pay_det = df_ecom_pay_det.withColumn("PURCHASE_DATE", when(df_ecom_pay_det.PURCHASE_DATE.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.PURCHASE_DATE)) \
                  .withColumn("PAYMENT_TYPE", when(df_ecom_pay_det.PAYMENT_TYPE.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.PAYMENT_TYPE)) \
                  .withColumn("TENDERS_DOLLARS", when(df_ecom_pay_det.TENDERS_DOLLARS.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.TENDERS_DOLLARS)) \
                  .withColumn("ACCOUNT_NUMBER", when(df_ecom_pay_det.ACCOUNT_NUMBER.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.ACCOUNT_NUMBER)) \
                  .withColumn("CARD_FIRST_6_DIGITS", when(df_ecom_pay_det.CARD_FIRST_6_DIGITS.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.CARD_FIRST_6_DIGITS)) \
                  .withColumn("CARD_LAST_4_DIGITS", when(df_ecom_pay_det.CARD_LAST_4_DIGITS.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.CARD_LAST_4_DIGITS)) \
                  .withColumn("PURCHASE_TYPE", when(df_ecom_pay_det.PURCHASE_TYPE.isNull(), "") \
                                              .otherwise(df_ecom_pay_det.PURCHASE_TYPE)) \
                  .withColumn('REQ_ID', df_req_list.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_req_list.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_req_list.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit(''))

df_ecom_pay_det= df_ecom_pay_det \
              .withColumn('REPORT_TYPE', df_ecom_pay_det.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Payment Details')) \
              .withColumn('PI_TYPE', concat(lit('Payment Details:'))) \
              .withColumn("PI_VALUE", concat(lit("Purchase Date:"), df_ecom_pay_det.PURCHASE_DATE, lit(','), \
                                             lit('Payment Type:'),df_ecom_pay_det.PAYMENT_TYPE,lit(','), \
                                             lit('Tendered Amount ($):'),df_ecom_pay_det.TENDERS_DOLLARS ,lit(','), \
                                             lit('Card Last 4 Digits:'),df_ecom_pay_det.CARD_LAST_4_DIGITS, lit(','), \
                                             lit('Purchase Type:'),df_ecom_pay_det.PURCHASE_TYPE \
                                            )) \
              .drop("PURCHASE_DATE", "PAYMENT_TYPE", "TENDERS_DOLLARS", "ACCOUNT_NUMBER", "CARD_FIRST_6_DIGITS", "CARD_LAST_4_DIGITS", "PURCHASE_TYPE") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
#df_ecom_pay_det.show()


window = Window.orderBy("PI_VALUE")
df_ecom_pay_det = df_ecom_pay_det \
               .withColumn('PI_TYPE', concat(lit('Payment Details:'), row_number().over(window)))

df_join_all = df_join_all.union(df_ecom_pay_det)
#display(df_join_all)           


# COMMAND ----------

# Email Subscription code for Nested CSV

#from pyspark.sql import Window

df_email_subs = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT", "CUST_PREF_TYPE_CD", "CUST_PREF_VAL")
df_email_subs = df_email_subs.dropDuplicates()
df_email_subs = df_email_subs.filter(df_email_subs.CUST_PREF_TYPE_CD.isNotNull())

# df_email = df_req_union.join(df_email_subs, df_req_union.CUST_SK==df_email_subs.CUST_SK, "full") \
#                     .drop(df_req_union.CUST_SK)
#df_ecom.show()

df_email_subs = df_email_subs.withColumn("CUST_PREF_TYPE_CD", when(df_email_subs.CUST_PREF_TYPE_CD.isNull(), "") 
                                               .when(lower(df_email_subs.CUST_PREF_TYPE_CD)=='shopping_wkly_ind', lit('Weekly Add'))
                                               .when(lower(df_email_subs.CUST_PREF_TYPE_CD)=='str_spcl_newsltr_ind', lit('Online Deals and Exclusives'))
                                               .when(lower(df_email_subs.CUST_PREF_TYPE_CD)=='photo_ind', lit('Photo News & Offers'))
                                               .when(lower(df_email_subs.CUST_PREF_TYPE_CD)=='walk_social_ind', lit('Balance Rewards For Healthy Choices'))
                                               .when(lower(df_email_subs.CUST_PREF_TYPE_CD)=='take_care_clinic_subscribe_ind', lit('Healthcare Clinic'))
                                               .when(lower(df_email_subs.CUST_PREF_TYPE_CD)=='balance_rewards', lit('Balance Rewards'))
                                               .otherwise(df_email_subs.CUST_PREF_TYPE_CD)) \
                  .withColumn("CUST_PREF_VAL", when(df_email_subs.CUST_PREF_VAL.isNull(), "") \
                                              .otherwise(df_email_subs.CUST_PREF_VAL)) \
                  .withColumn('REQ_ID', df_req_list.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_req_list.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_req_list.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit(''))

df_email_subs = df_email_subs \
              .withColumn('REPORT_TYPE', df_email_subs.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Email Subscription')) \
              .withColumn('PI_TYPE', concat(lit('Subscription'))) \
              .withColumn("PI_VALUE", lit(str(df_email_subs.select("CUST_PREF_TYPE_CD").distinct().rdd.map(lambda row : row[0]).collect()))) \
              .drop("CUST_PREF_TYPE_CD", "CUST_PREF_VAL") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

#df_email_subs.show()
df_join_all = df_join_all.union(df_email_subs)
#display(df_join_all)


#df_req_union = df_req_union.union(df_email_sub)
#display(df_req_union)

#df_join_all5 = df_req_union.drop("CUST_SK", "CUST_SRC_ID").drop_duplicates()
# df_join_all5 = df_join_all5 \
#                .withColumn('PI_TYPE', concat(lit('Subscription:'), row_number().over(window)))
# df_join_all = df_join_all.union(df_join_all5)
# df_join_all = df_join_all.drop_duplicates()
#display(df_join_all)

# COMMAND ----------

# Inferences code for Summary Nested CSV

#from pyspark.sql import Window

df_infer = df_read.select("TKT_NBR","TASK_ID", "LV_FLAG", "TKT_OPEN_DT","mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs")
df_infer = df_infer.dropDuplicates()
df_infer = df_infer.filter(df_infer.mid.isNotNull())

# display(df_infer)

df_infer = df_infer.withColumn("segment_lifestyle_fos", when(df_infer.segment_lifestyle_fos.isNull(), "") \
                                              .otherwise(df_infer.segment_lifestyle_fos)) \
                  .withColumn("life_cycle_baby_boomers", when(df_infer.life_cycle_baby_boomers.isNull(), "") \
                                              .otherwise(df_infer.life_cycle_baby_boomers)) \
                  .withColumn("life_cycle_dual_incm_no_kids", when(df_infer.life_cycle_dual_incm_no_kids.isNull(), "") \
                                              .otherwise(df_infer.life_cycle_dual_incm_no_kids)) \
                  .withColumn("life_cycle_generation_x", when(df_infer.life_cycle_generation_x.isNull(), "") \
                                              .otherwise(df_infer.life_cycle_generation_x)) \
                  .withColumn("advntg_home_owner", when(df_infer.advntg_home_owner.isNull(), "") \
                                              .otherwise(df_infer.advntg_home_owner)) \
                  .withColumn("advntg_household_edu", when(df_infer.advntg_household_edu.isNull(), "") \
                                              .otherwise(df_infer.advntg_household_edu)) \
                  .withColumn("advntg_household_mrtl_stat", when(df_infer.advntg_household_mrtl_stat.isNull(), "") \
                                              .otherwise(df_infer.advntg_household_mrtl_stat)) \
                  .withColumn("advntg_household_sz", when(df_infer.advntg_household_sz.isNull(), "") \
                                              .otherwise(df_infer.advntg_household_sz)) \
                  .withColumn("advntg_presence_of_child", when(df_infer.advntg_presence_of_child.isNull(), "") \
                                              .otherwise(df_infer.advntg_presence_of_child)) \
                  .withColumn("ethnic_group_cd", when(df_infer.ethnic_group_cd.isNull(), "") \
                                              .otherwise(df_infer.ethnic_group_cd)) \
                  .withColumn("life_cycle_dual_incm_no_kids_flag", when(df_infer.life_cycle_dual_incm_no_kids_flag.isNull(), "") \
                                              .otherwise(df_infer.life_cycle_dual_incm_no_kids_flag)) \
                  .withColumn("median_household_incm", when(df_infer.median_household_incm.isNull(), "") \
                                              .otherwise(df_infer.median_household_incm)) \
                  .withColumn("lang_cd", when(df_infer.lang_cd.isNull(), "") \
                                              .otherwise(df_infer.lang_cd)) \
                  .withColumn("nbr_of_child_in_household", when(df_infer.nbr_of_child_in_household.isNull(), "") \
                                              .otherwise(df_infer.nbr_of_child_in_household)) \
                  .withColumn("Occp", when(df_infer.Occp.isNull(), "") \
                                              .otherwise(df_infer.Occp)) \
                  .withColumn("advntg_tgt_incm", when(df_infer.advntg_tgt_incm.isNull(), "") \
                                              .otherwise(df_infer.advntg_tgt_incm)) \
                  .withColumn("child_age_0_to_2_yrs", when(df_infer.child_age_0_to_2_yrs.isNull(), "") \
                                              .otherwise(df_infer.child_age_0_to_2_yrs)) \
                  .withColumn("child_age_3_to_5_yrs", when(df_infer.child_age_3_to_5_yrs.isNull(), "") \
                                              .otherwise(df_infer.child_age_3_to_5_yrs)) \
                  .withColumn("child_age_6_to_10_yrs", when(df_infer.child_age_6_to_10_yrs.isNull(), "") \
                                              .otherwise(df_infer.child_age_6_to_10_yrs)) \
                  .withColumn("child_age_11_to_15_yrs", when(df_infer.child_age_11_to_15_yrs.isNull(), "") \
                                              .otherwise(df_infer.child_age_11_to_15_yrs)) \
                  .withColumn("child_age_16_to_17_yrs", when(df_infer.child_age_16_to_17_yrs.isNull(), "") \
                                              .otherwise(df_infer.child_age_16_to_17_yrs)) \
                  .withColumn('REQ_ID', df_infer.TKT_NBR) \
                  .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
                  .withColumn('APP_ID', lit('DAE')) \
                  .withColumn('EVENT_TS', df_infer.TKT_OPEN_DT) \
                  .withColumn('COMMENT', lit('')) \
                  .withColumn('DP1', lit('')) \
                  .withColumn('DP2', lit('')) \
                  .withColumn('DP3', lit('')) \
                  .withColumn('DP4', lit('')) \
                  .withColumn('DP5', lit('')) \

                              
                              
            


# display(df_infer)


df_infer_pref= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Preferences'))) \
              .withColumn("PI_VALUE", concat(df_infer.segment_lifestyle_fos)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_char= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Characteristics'))) \
              .withColumn("PI_VALUE", concat(df_infer.life_cycle_dual_incm_no_kids,when(df_infer.life_cycle_dual_incm_no_kids == "","").otherwise(lit(',')), \
                                             df_infer.life_cycle_generation_x,when((df_infer.life_cycle_generation_x == "") | (df_infer.life_cycle_baby_boomers == ""),"").otherwise(lit(',')), \
                                             df_infer.life_cycle_baby_boomers )).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()


df_infer_advntg_home_owner= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Home_Owner'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_home_owner)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_advntg_household_edu= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Household_Education'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_household_edu)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
df_infer_advntg_household_mrtl_stat= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Household_Marital_Status'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_household_mrtl_stat)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()
df_infer_advntg_household_sz= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Household_Size'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_household_sz)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_advntg_presence_of_child= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Presence_of_Children'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_presence_of_child)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_ethnic_group_cd= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Ethnic_Group_Code_Household'))) \
              .withColumn("PI_VALUE", concat(df_infer.ethnic_group_cd)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_life_cycle_dual_incm_no_kids_flag= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Dual_Income_No_Kids'))) \
              .withColumn("PI_VALUE", concat(df_infer.life_cycle_dual_incm_no_kids_flag)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_median_household_incm= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Median_Household_Income'))) \
              .withColumn("PI_VALUE", concat(df_infer.median_household_incm)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_advntg_household_sz= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Household_Size'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_household_sz)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_lang_cd= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Language_Code_Household'))) \
              .withColumn("PI_VALUE", concat(df_infer.lang_cd)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_nbr_of_child_in_household= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Number_of_Children_in_Household'))) \
              .withColumn("PI_VALUE", concat(df_infer.nbr_of_child_in_household)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_Occp= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Occupation'))) \
              .withColumn("PI_VALUE", concat(df_infer.Occp)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_advntg_tgt_incm= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Target_Income'))) \
              .withColumn("PI_VALUE", concat(df_infer.advntg_tgt_incm)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_child_age_0_to_2_yrs= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Children_Age_0_to_2'))) \
              .withColumn("PI_VALUE", concat(df_infer.child_age_0_to_2_yrs)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_child_age_3_to_5_yrs= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Children_Age_3_to_5'))) \
              .withColumn("PI_VALUE", concat(df_infer.child_age_3_to_5_yrs)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_child_age_6_to_10_yrs= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Children_Age_6_to_10'))) \
              .withColumn("PI_VALUE", concat(df_infer.child_age_6_to_10_yrs)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_child_age_11_to_15_yrs= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Children_Age_11_to_15'))) \
              .withColumn("PI_VALUE", concat(df_infer.child_age_11_to_15_yrs)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()

df_infer_child_age_16_to_17_yrs= df_infer \
              .withColumn('REPORT_TYPE', df_infer.LV_FLAG) \
              .withColumn('PI_CATEGORY', lit('Inferences About You')) \
              .withColumn('PI_TYPE', concat(lit('Children_Age_16_to_17'))) \
              .withColumn("PI_VALUE", concat(df_infer.child_age_16_to_17_yrs)).drop("mid","segment_lifestyle_fos","life_cycle_baby_boomers","life_cycle_dual_incm_no_kids","life_cycle_generation_x","advntg_home_owner","advntg_household_edu","advntg_household_mrtl_stat","advntg_household_sz","advntg_presence_of_child","ethnic_group_cd","life_cycle_dual_incm_no_kids_flag","median_household_incm","lang_cd","nbr_of_child_in_household","Occp","advntg_tgt_incm","child_age_0_to_2_yrs","child_age_3_to_5_yrs","child_age_6_to_10_yrs","child_age_11_to_15_yrs","child_age_16_to_17_yrs") \
              .select ("REQ_ID","TASK_ID", "REPORT_TYPE", "PI_CATEGORY", "PI_TYPE", "PI_VALUE", "APP_ID", "EVENT_TS", "COMMENT", "DP1", "DP2", "DP3", "DP4", "DP5") \
              .drop_duplicates()



# display(df_infer_pref)

df_inferences_all = df_infer_pref
df_inferences_all = df_inferences_all.union(df_infer_char)
df_inferences_all = df_inferences_all.union(df_infer_advntg_home_owner)
df_inferences_all = df_inferences_all.union(df_infer_advntg_household_edu)
df_inferences_all = df_inferences_all.union(df_infer_advntg_household_mrtl_stat)
df_inferences_all = df_inferences_all.union(df_infer_advntg_household_sz)
df_inferences_all = df_inferences_all.union(df_infer_advntg_presence_of_child)
df_inferences_all = df_inferences_all.union(df_infer_ethnic_group_cd)
df_inferences_all = df_inferences_all.union(df_infer_life_cycle_dual_incm_no_kids_flag)
df_inferences_all = df_inferences_all.union(df_infer_median_household_incm)
df_inferences_all = df_inferences_all.union(df_infer_lang_cd)
df_inferences_all = df_inferences_all.union(df_infer_nbr_of_child_in_household)
df_inferences_all = df_inferences_all.union(df_infer_Occp)
df_inferences_all = df_inferences_all.union(df_infer_advntg_tgt_incm)
df_inferences_all = df_inferences_all.union(df_infer_child_age_0_to_2_yrs)
df_inferences_all = df_inferences_all.union(df_infer_child_age_3_to_5_yrs)
df_inferences_all = df_inferences_all.union(df_infer_child_age_6_to_10_yrs)
df_inferences_all = df_inferences_all.union(df_infer_child_age_11_to_15_yrs)
df_inferences_all = df_inferences_all.union(df_infer_child_age_16_to_17_yrs)


# # #df_infer.show()

display(df_inferences_all)
df_join_all = df_join_all.union(df_inferences_all)

# COMMAND ----------

df_join_all = df_join_all.withColumn("LENGHT", f.length('PI_VALUE'))\
                          .withColumn("PI_VALUE", when((lower(df_join_all.PI_TYPE)=='subscription')\
                                                              , f.col('PI_VALUE').substr(f.lit(2), f.col('LENGHT') - f.lit(2)))\
                                                               .otherwise(df_join_all.PI_VALUE)).drop("LENGHT")
df_join_all = df_join_all.withColumn("PI_VALUE",when((lower(df_join_all.PI_TYPE)=='subscription')\
                                        , regexp_replace("PI_VALUE", "\'", ""))\
                                                     .otherwise(df_join_all.PI_VALUE))
display(df_join_all)

# COMMAND ----------

#Code for Summary file

df_summ_rep = df_summ_rep.union(df_email_subs)
df_summ_rep = df_summ_rep.union(df_inferences_all)

df_summ_rep = df_summ_rep.withColumn("REPORT_TYPE", lit("RTA_SUMMARY"))


df_summ_rep = df_summ_rep.withColumn("LENGHT", f.length('PI_VALUE'))\
                          .withColumn("PI_VALUE", when((lower(df_summ_rep.PI_TYPE)=='subscription')\
                                                              , f.col('PI_VALUE').substr(f.lit(2), f.col('LENGHT') - f.lit(2)))\
                                                               .otherwise(df_summ_rep.PI_VALUE)).drop("LENGHT")
df_summ_rep = df_summ_rep.withColumn("PI_VALUE",when((lower(df_summ_rep.PI_TYPE)=='subscription')\
                                        , regexp_replace("PI_VALUE", "\'", ""))\
                                                     .otherwise(df_summ_rep.PI_VALUE))

display(df_summ_rep)





# COMMAND ----------

report_type = df_join_all.select("REPORT_TYPE").distinct()
report_type = report_type.filter(report_type.REPORT_TYPE != '')
rt=report_type.first()["REPORT_TYPE"]
# print(rt)

# COMMAND ----------

fname = INPUT_FILENAME.replace('_DEC_','_RES_').replace('.csv','')
print(fname)

# COMMAND ----------

#Creating complete nested CSV file

df_join_all\
.coalesce(1)\
.write\
.format("csv")\
.mode("overwrite")\
.option("header",True)\
.option("sep", '\u0001')\
.option("quoteAll",True)\
.save(OUT_FILEPATH+"/"+fname)



# COMMAND ----------

#data_location = OUT_FILEPATH+"/coalesce-csv/"
data_location = OUT_FILEPATH+"/"+fname+"/"
files = dbutils.fs.ls(data_location)
# csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
for i in files:
    if i.path.endswith(".csv"):
      csv_file = i.path
dbutils.fs.cp(csv_file,data_location.rstrip('/') + '.csv')
dbutils.fs.rm(data_location, recurse = True)

# COMMAND ----------

#Creating only RTA_SUMMARY NESTED CSV file
if rt == 'FULLY_VERIFIED':
  df_summ_rep\
  .coalesce(1)\
  .write\
  .format("csv")\
  .mode("overwrite")\
  .option("header",True)\
  .option("sep", '|')\
  .option("quoteAll",True)\
  .save(OUT_FILEPATH_SUMM+"/"+fname)


# COMMAND ----------

#REMOVING PART AND CRC FILES
if rt == 'FULLY_VERIFIED':
  data_location_summ = OUT_FILEPATH_SUMM+"/"+fname+"/"
  files1 = dbutils.fs.ls(data_location_summ)
  print(files1)

  for i in files1:
      if i.path.endswith(".csv"):
        csv_file1 = i.path

  # csv_file1 = [x.path for x in files1 if x.path.endswith(".csv")][0]
  dbutils.fs.cp(csv_file1, data_location_summ.rstrip('/') + '.csv')
  dbutils.fs.rm(data_location_summ, recurse = True)

# COMMAND ----------

## Exit with REPORT_TYPE

dbutils.notebook.exit(rt)
# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
print(mountPoint)
mountPointfiles=dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_SHELL",60)
print(mountPointfiles)

# COMMAND ----------

# Report Model used in PDF Generation

from dataclasses import dataclass


# Class specific to Details report
@dataclass
class InstorePurchase:
    purchaseDate: str
    productDescription: str
    totalQuantity: str
    totalSales: str
    returnQuatity: str

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class InstorePurchaseList:
    entries: list
    __headingAttributeMap__ = {
        "Purchase Date": "purchaseDate",
        "Product Description": "productDescription",
        "Total Quantity": "totalQuantity",
        "Total Sales ($)": "totalSales",
        "Return Quantity": "returnQuatity",
    }
    __alignmentMap__ = {
        "Total Quantity": "R",
        "Total Sales ($)": "R",
        "Return Quantity": "R",
    }
    __widthMap__ = {
        "Purchase Date": 1,
        "Product Description": 2,
        "Total Quantity": 1,
        "Total Sales ($)": 1,
        "Return Quantity": 1,
    }


@dataclass
class OnlinePurchase:
    purchaseDate: str
    productDescription: str
    totalSales: str
    totalQuantity: str

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class OnlinePurchaseList:
    entries: list
    __headingAttributeMap__ = {
        "Purchase Date": "purchaseDate",
        "Product Description": "productDescription",
        "Total Quantity": "totalQuantity",
        "Total Sales ($)": "totalSales",
        
    }
    __alignmentMap__ = {"Total Sales ($)": "R", "Total Quantity": "R"}
    __widthMap__ = {
        "Purchase Date": 1,
        "Product Description": 2,
        "Total Quantity": 1,
        "Total Sales ($)": 1,
    }


@dataclass
class OnlineReturn:
    returnReportedDate: str
    productDescription: str
    qnantityToReturn: str
    totalReturnDlr: str

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class OnlinReturnList:
    entries: list
    __headingAttributeMap__ = {
        "Return Reported Date": "returnReportedDate",
        "Product Description": "productDescription",
        "Return Quantity": "qnantityToReturn",
        "Return Amount ($)": "totalReturnDlr",
    }
    __alignmentMap__ = {"Return Quantity": "R", "Return Amount ($)": "R"}
    __widthMap__ = {
        "Return Reported Date": 1,
        "Product Description": 2,
        "Return Quantity": 1,
        "Return Amount ($)": 1,
    }


@dataclass
class PaymentDetail:
    purchaseDate: str
    paymentType: str
    tenderedAmount: str
    cardLastFourDigits: str
    purchaseType: str

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class PaymentDetailList:
    entries : list
    __headingAttributeMap__ = {
        "Purchase Date": "purchaseDate",
        "Payment Type": "paymentType",
        "Tendered Amount ($)": "tenderedAmount",
        "Card Last 4 Digits": "cardLastFourDigits",
        "Purchase Type": "purchaseType",
    }
    __alignmentMap__ = {"Tendered Amount ($)": "R", "Card Last 4 Digits": "C"}
    __widthMap__ = {
        "Purchase Date": 1,
        "Payment Type": 1,
        "Tendered Amount ($)": 1,
        "Card Last 4 Digits": 1,
        "Purchase Type": 1,
    }


# class specific to summary


@dataclass
class SalesTransactionSummary:
    totalAmountSpend: str
    totalTaxPaid: str
    __headingAttributeMap__ = {
        "Total amount spent": "totalAmountSpend",
        "Total tax paid": "totalTaxPaid",
    }
    __alignmentMap__ = {}

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class InferenceAboutYou:
    listOfPreferences: list = None
    listOfBehaviour: list = None
    listOfCharacterstics: list = None
    homeOwnerList: list = None
    householdEduList: list = None
    householdMartialStatusList: list = None
    householdSize: list = None
    presenceOfChildren: list = None
    ethicGroupCodelist: list = None
    dualIncomeNoKidsList: list = None
    medianhouseoldIncomeList: list = None
    householdLanguageCode: list = None
    noOfChildrenInHousehold: list = None
    occupationList: list = None
    targetIncomeList: list = None
    childrenAgeZeroToTwoList: list = None
    childrenAgeThreeToFiveList: list = None
    childrenAgesixToTenList: list = None
    childrenAgeElevenToFiftenList: list = None
    childrenAgeSixteenToSeventeenList: list = None

    __headingAttributeMap__ = {
        "Preferences": "listOfPreferences",
        "Characteristics": "listOfBehaviour",
        "Behavior": "listOfCharacterstics",
        "Home Owner": "homeOwnerList",
        "Household Education": "householdEduList",
        "Household Marital Status": "householdMartialStatusList",
        "Household Size": "householdSize",
        "Presence of Children": "presenceOfChildren",
        "Ethnic Group Code - Household": "ethicGroupCodelist",
        "Dual Income No Kids": "dualIncomeNoKidsList",
        "Median Household Income": "medianhouseoldIncomeList",
        "Language Code - Household": "householdLanguageCode",
        "Number of Children in Household": "noOfChildrenInHousehold",
        "Occupation": "occupationList",
        "Target Income": "targetIncomeList",
        "Children Age 0 to 2": "childrenAgeZeroToTwoList",
        "Children Age 3 to 5": "childrenAgeThreeToFiveList",
        "Children Age 6 to 10": "childrenAgesixToTenList",
        "Children Age 11 to 15": "childrenAgeElevenToFiftenList",
        "Children Age 16 to 17": "childrenAgeSixteenToSeventeenList"
    }
    __alignmentMap__ = {}

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class EmailSubscription:
    subs: list


@dataclass
class PSCInfo:
    psdMembershipId: str
    name: str
    dateOfBirth: str
    pscCardId: str
    memberShipCategory: str
    createDate: str
    endDate: str
    phoneNo: str
    email: str
    postalAddress: str
    __sectionName__ = "PSC Information"
    __headingAttributeMap__ = {
        "Member Id": "psdMembershipId",
        "Name": "name",
        "Birth Date": "dateOfBirth",
        "Psc Card Id": "pscCardId",
        "Membership Type": "memberShipCategory",
        "Start Date": "createDate",
        "End Date": "endDate",
        "Phone Number": "phoneNo",
        "Email": "email",
        "Postal Address": "postalAddress",
    }
    __widthMap__ = {
        "Member Id": 6,
        "Name": 3,
        "Birth Date": 3,
        "Psc Card Id": 4,
        "Membership Type": 3,
        "Start Date": 3,
        "End Date": 3,
        "Phone Number": 4,
        "Email": 3,
        "Postal Address": 5,
    }
    __alignmentMap__ = {}

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class LoyaltyOfferMadeToCustomer:
    loyaltyMemberId: str
    loyaltyOffer: str
    offerOptInDate: str
    offerOptOutDate: str
    dateOptIn: str
    dateOptOut: str

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class LoyaltyOfferMadeToCustomerList:
    entries: list
    __headingAttributeMap__ = {
        "Loyalty Member Id": "loyaltyMemberId",
        "Loyalty Offer": "loyaltyOffer",
        "Offer Opt In Date": "offerOptInDate",
        "Offer Opt Out Date": "offerOptOutDate",
        "Date Opt In": "dateOptIn",
        "Date Opt Out": "dateOptOut",
    }
    __widthMap__ = {
        "Loyalty Member Id": 4,
        "Loyalty Offer": 6,
        "Offer Opt In Date": 3,
        "Offer Opt Out Date": 3,
        "Date Opt In": 3,
        "Date Opt Out": 3,
    }
    __alignmentMap__ = {}


@dataclass
class LoyaltyInfo:
    loyaltyMemberId: str
    loyaltyCardNumber: str
    enrollmentDate: str
    enrollmentChannel: str
    currentPointBalance: str
    lifetimePointsEarnerd: str
    lifeTimePointsRedemmed: str

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class LoyatlyInfoList:
    entries: list
    __headingAttributeMap__ = {
        "Loyalty Member Id": "loyaltyMemberId",
        "Loyalty Card Number": "loyaltyCardNumber",
        "Enrollment Date": "enrollmentDate",
        "Enrollment Channel": "enrollmentChannel",
        "Current Point Balance": "currentPointBalance",
        "Lifetime Points Earned": "lifetimePointsEarnerd",
        "Lifetime Points Redemmed": "lifeTimePointsRedemmed",
    }
    __widthMap__ = {
        "Loyalty Member Id": 4,
        "Loyalty Card Number": 4,
        "Enrollment Date": 3,
        "Enrollment Channel": 3,
        "Current Point Balance": 3,
        "Lifetime Points Earned": 3,
        "Lifetime Points Redemmed": 3,
    }
    __alignmentMap__ = {}


@dataclass
class Customer:
    name: list = None
    birthDate: list = None
    gender: list = None
    emailAddresses: list = None
    contacts: list = None
    postalAddresses: list = None
    __headingAttributeMap__ = {
        "Name": "name",
        "Birth Date": "birthDate",
        "Gender": "gender",
        "Email Addresses": "emailAddresses",
        "Contact": "contacts",
        "Postal Address": "postalAddresses",
    }

    def __getitem__(self, item):
        return getattr(self, item)


# class common to both


@dataclass
class Request:
    requesterId: str
    requesterName: str
    reportDate: str


@dataclass
class DetailReport:
    request: Request
    instorePurchases: list = None
    onlinePurcahses: list = None
    onlineReturns: list = None
    paymentDetails: list = None

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class SummaryReport:
    request: Request
    customer: Customer
    loyatlyInformations: LoyatlyInfoList = None
    loyaltyOfferMadeToCustomer: LoyaltyOfferMadeToCustomerList = None
    pSCInfo: PSCInfo = None
    emailSubscription: EmailSubscription = None
    inferenceAboutYou: InferenceAboutYou = None
    salesTransactionSummary: SalesTransactionSummary = None

    def __getitem__(self, item):
        return getattr(self, item)

@dataclass
class LVReport:
    request: Request
    def __getitem__(self, item):
        return getattr(self, item)


# COMMAND ----------

# CSV Reader to create Data Models
from pandas import DataFrame
import re


class ReportData:

    def __init__(self, data: DataFrame) -> None:
        self.data = data
        self.request_number = data["REQ_ID"][0]
        self.request_date = data["EVENT_TS"][0]
        self.__prepareCustomerData__()

    def __prepareList__(self, value):
        result = []
        if value is not None:
            if value.find(",") != -1:
                result = value.split(",")
            else:
                result = value

        return result

    def __getPIValue__(self, category, piType=None) -> str:
        if piType is not None:
            result = self.data.query(
                'PI_CATEGORY == @category  and PI_TYPE == @piType')[["PI_VALUE"]]
        else:
            result = self.data.query(
                'PI_CATEGORY == @category')[["PI_VALUE"]]
        result = result.dropna()
        if len(result["PI_VALUE"]) > 0:
            return result["PI_VALUE"].values.tolist()[0]
        else:
            return None

    def __getPIValueList__(self, category, piType=None) -> list:
        if piType is not None:
            result = self.data.query(
                'PI_CATEGORY == @category  and PI_TYPE == @piType')[["PI_VALUE"]]
        else:
            result = self.data.query(
                'PI_CATEGORY == @category')[["PI_VALUE"]]
        result = result.dropna()
        if len(result["PI_VALUE"]) > 0:
            return result["PI_VALUE"].values.tolist()
        else:
            return None

    def __prepareCustomerData__(self) -> Customer:
        firstName = self.__getPIValue__("Customer Information", "First Name")
        middleName = self.__getPIValue__("Customer Information", "Middle Name")
        lastName = self.__getPIValue__("Customer Information", "Last Name")
        if middleName is not None:
          self.requester = firstName + ' ' + middleName + ' ' + lastName
        else:
          self.requester = firstName + ' ' + lastName
        
        Name = self.__getPIValue__("Customer Information", "Name")
        birthDate = self.__getPIValue__("Customer Information", "Birth Date") ##HERE MF
        gender = self.__getPIValue__("Customer Information", "Gender")
        email = self.__getPIValue__("Customer Information", "Email Addresses")
        phone = self.__getPIValue__("Customer Information", "Contact")
        postAddress = self.__getPIValue__("Customer Information", "Postal Address")
        
        
        NameList = self.__prepareList__(Name)
        birthDateList = self.__prepareList__(birthDate)
        genderList = self.__prepareList__(gender)
        emailList = self.__prepareList__(email)
        phoneAddressList = self.__prepareList__(phone)
        postAddpostAddressresList = self.__prepareList__(postAddress)

        
        if middleName is not None:
          customer = Customer(name=NameList, birthDate=birthDateList, gender=genderList,
                                         emailAddresses=emailList, contacts=phoneAddressList, postalAddresses=postAddpostAddressresList)
        else:
          customer = Customer(name=NameList, birthDate=birthDateList, gender=genderList,
                                         emailAddresses=emailList, contacts=phoneAddressList, postalAddresses=postAddpostAddressresList)
          
        return customer

    def __prepareLoyaltyInformations__(self) -> LoyatlyInfoList:
        loyaltyList = self.__getPIValueList__("Loyalty Information")
        if loyaltyList is None:
          return
        loyaltyRegex = 'Loyalty Member Id:(.*?),PROG_CD:(.*?),Loyalty Card Number:(.*?),Enrollment Date:(.*?),Enrollment Channel:(.*?),Current Point Balance:(.*?),Lifetime Points Earned:(.*?),Lifetime Points Redeemed:(.*)'
        loyaltyInfoList = []
        for info in loyaltyList:
            result = re.search(rf"{loyaltyRegex}", info)
            loyaltyMemeberId = result.group(1)
            progCd = result.group(2)
            loyaltyCardNo = result.group(3)
            enrollmentDate = result.group(4)
            enrollmentChannel = result.group(5)
            pointBalance = result.group(6)
            earnedLifeTime = result.group(7)
            redemmedLifetime = result.group(8)
            loyaltyInfo = LoyaltyInfo(
                loyaltyMemberId=loyaltyMemeberId, loyaltyCardNumber=loyaltyCardNo, enrollmentDate=enrollmentDate, enrollmentChannel=enrollmentChannel, currentPointBalance=pointBalance, lifetimePointsEarnerd=earnedLifeTime, lifeTimePointsRedemmed=redemmedLifetime)
            loyaltyInfoList.append(loyaltyInfo)
        return LoyatlyInfoList(loyaltyInfoList)

    def __prepareLoyaltyOfferMadeToCustomer__(self) -> LoyaltyOfferMadeToCustomerList:
        loyaltyOfferList = self.__getPIValueList__(
            "Loyalty offers made to the customer")
        if loyaltyOfferList is None:
          return
        loyaltyOfferRegex = 'Loyalty Member Id:(.*?),Loyalty Offer:(.*?),Offer Opt In Date:(.*?),Offer Opt Out Date:(.*?),Date Opted In:(.*?),Date Opted out:(.*)'
        loyaltyOfferDataList = []
        for offer in loyaltyOfferList:
            result = re.search(rf"{loyaltyOfferRegex}", offer)
            loayltyMemberId = result.group(1)
            loyaltyOffer = result.group(2)
            prgOptInDate = result.group(3)
            prgOptOutDate = result.group(4)
            prgStartDate = result.group(5)
            prgEndDate = result.group(6)

            loyaltyOfferMade = LoyaltyOfferMadeToCustomer(loyaltyMemberId=loayltyMemberId,
                                                                       loyaltyOffer=loyaltyOffer, offerOptInDate=prgOptInDate, offerOptOutDate=prgOptOutDate, dateOptIn=prgStartDate, dateOptOut=prgEndDate)
            loyaltyOfferDataList.append(loyaltyOfferMade)
        return LoyaltyOfferMadeToCustomerList(loyaltyOfferDataList)

    def __preparePSCInfo__(self):
        pscInformation = self.__getPIValueList__(
            "PSC Information")
        return pscInformation

    def __prepareEmailSubscription__(self):
        emailSubscription = self.__getPIValueList__(
            "Email Subscription")
        return emailSubscription

    def __prepareInferenceAboutYou__(self):
        Preferences = self.__getPIValue__("Inferences About You", "Preferences")
        Characteristics = self.__getPIValue__("Inferences About You", "Characteristics")
        Behavior = self.__getPIValue__("Inferences About You", "Behavior")
        Home_Owner = self.__getPIValue__("Inferences About You", "Home_Owner")
        Household_Education = self.__getPIValue__("Inferences About You", "Household_Education")
        Household_Marital_Status = self.__getPIValue__("Inferences About You", "Household_Marital_Status")
        Household_Size = self.__getPIValue__("Inferences About You", "Household_Size")
        Presence_of_Children = self.__getPIValue__("Inferences About You", "Presence_of_Children")
        Ethnic_Group_Code_Household = self.__getPIValue__("Inferences About You", "Ethnic_Group_Code_Household")
        Dual_Income_No_Kids = self.__getPIValue__("Inferences About You", "Dual_Income_No_Kids")
        Median_Household_Income = self.__getPIValue__("Inferences About You", "Median_Household_Income")
        Language_Code_Household = self.__getPIValue__("Inferences About You", "Language_Code_Household")
        Number_of_Children_in_Household = self.__getPIValue__("Inferences About You", "Number_of_Children_in_Household")
        Occupation = self.__getPIValue__("Inferences About You", "Occupation")
        Target_Income = self.__getPIValue__("Inferences About You", "Target_Income")
        Children_Age_0_to_2 = self.__getPIValue__("Inferences About You", "Children_Age_0_to_2")
        Children_Age_3_to_5 = self.__getPIValue__("Inferences About You", "Children_Age_3_to_5")
        Children_Age_6_to_10 = self.__getPIValue__("Inferences About You", "Children_Age_6_to_10")
        Children_Age_11_to_15 = self.__getPIValue__("Inferences About You", "Children_Age_11_to_15")
        Children_Age_16_to_17 = self.__getPIValue__("Inferences About You", "Children_Age_16_to_17")

        
        
        PreferencesList= self.__prepareList__(Preferences)
        CharacteristicsList= self.__prepareList__(Characteristics)
        BehaviorList= self.__prepareList__(Behavior)
        Home_OwnerList= self.__prepareList__(Home_Owner)
        Household_EducationList= self.__prepareList__(Household_Education)
        Household_Marital_StatusList= self.__prepareList__(Household_Marital_Status)
        Household_SizeList= self.__prepareList__(Household_Size)
        Presence_of_ChildrenList= self.__prepareList__(Presence_of_Children)
        Ethnic_Group_Code_HouseholdList= self.__prepareList__(Ethnic_Group_Code_Household)
        Dual_Income_No_KidsList= self.__prepareList__(Dual_Income_No_Kids)
        Median_Household_IncomeList= self.__prepareList__(Median_Household_Income)
        Language_Code_HouseholdList= self.__prepareList__(Language_Code_Household)
        Number_of_Children_in_HouseholdList= self.__prepareList__(Number_of_Children_in_Household)
        OccupationList= self.__prepareList__(Occupation)
        Target_IncomeList= self.__prepareList__(Target_Income)
        Children_Age_0_to_2List= self.__prepareList__(Children_Age_0_to_2)
        Children_Age_3_to_5List= self.__prepareList__(Children_Age_3_to_5)
        Children_Age_6_to_10List= self.__prepareList__(Children_Age_6_to_10)
        Children_Age_11_to_15List= self.__prepareList__(Children_Age_11_to_15)
        Children_Age_16_to_17List= self.__prepareList__(Children_Age_16_to_17)
        
        
        inerenceAboutYou = InferenceAboutYou(listOfPreferences=PreferencesList,
                                            listOfBehaviour=CharacteristicsList,
                                            listOfCharacterstics=BehaviorList,
                                            homeOwnerList=Home_OwnerList,
                                            householdEduList=Household_EducationList,
                                            householdMartialStatusList=Household_Marital_StatusList,
                                            householdSize=Household_SizeList,
                                            presenceOfChildren=Presence_of_ChildrenList,
                                            ethicGroupCodelist=Ethnic_Group_Code_HouseholdList,
                                            dualIncomeNoKidsList=Dual_Income_No_KidsList,
                                            medianhouseoldIncomeList=Median_Household_Income,
                                            householdLanguageCode=Language_Code_HouseholdList,
                                            noOfChildrenInHousehold=Number_of_Children_in_HouseholdList,
                                            occupationList=OccupationList,
                                            targetIncomeList=Target_Income,
                                            childrenAgeZeroToTwoList=Children_Age_0_to_2List,
                                            childrenAgeThreeToFiveList=Children_Age_3_to_5List,
                                            childrenAgesixToTenList=Children_Age_6_to_10List,
                                            childrenAgeElevenToFiftenList=Children_Age_11_to_15List,
                                            childrenAgeSixteenToSeventeenList=Children_Age_16_to_17List)
        
        return inerenceAboutYou

    def __prepareSalesTransactionSummary__(self):
        salesTotal = self.__getPIValue__(
            "Sales Transaction Summary", "Total amount spent")
        salesTaxTotal = self.__getPIValue__(
            "Sales Transaction Summary", "Total tax paid")
        if salesTotal is None:
          if salesTaxTotal is None:
            return SalesTransactionSummary(str(0), str(0))
          else:
            return SalesTransactionSummary(str(0), str(salesTaxTotal))
          
        if salesTaxTotal is None:
          if salesTotal is None:
            return SalesTransactionSummary(str(0), str(0))
          else:
            return SalesTransactionSummary(str(salesTotal), str(0))
        
        salesTotal = self.__getPIValue__(
            "Sales Transaction Summary", "Total amount spent").split(",")[0].split(":")[1]
        salesTaxTotal = self.__getPIValue__(
            "Sales Transaction Summary", "Total tax paid").split(",")[0].split(":")[1]
        return SalesTransactionSummary(str(salesTotal), str(salesTaxTotal))

    def __prepareInStorePurchaseList__(self):
        instorPurchases = self.__getPIValueList__(
            "In Store Purchase")
        if instorPurchases is None:
          return
        instoreRegex = 'Purchase Date:(.*?),Product Description:(.*?),Total Quantity:(.*?),Total Sales \(\$\):(.*?),Return Quantity:(.*)'
        instorePurchaseList = []
        for instorePurchaseData in instorPurchases:
            result = re.search(rf"{instoreRegex}", instorePurchaseData)
            purchaseDate = result.group(1)
            productDescription = result.group(2)
            totalQuantity = result.group(3)
            totaleSales = result.group(4)
            returnQuantity = result.group(5)

            instorePurcahse = InstorePurchase(
                purchaseDate, productDescription, totalQuantity, totaleSales, returnQuantity)
            instorePurchaseList.append(instorePurcahse)
        return InstorePurchaseList(instorePurchaseList)

    def __prepareOnlinePurchaseList__(self):
        onlinePurchases = self.__getPIValueList__(
            "Online Purchase")
        if onlinePurchases is None:
          return
        onlinePurchaseRegex = 'Purchase Date:(.*?),Product Description:(.*?),Total Quantity:(.*?),Total Sales \(\$\):(.*)'
        onlinePurcahseList = []
        for onlinePurchaseData in onlinePurchases:
            result = re.search(rf"{onlinePurchaseRegex}", onlinePurchaseData)
            purchaseDate = result.group(1)
            productDescription = result.group(2)
            unitQuantity = result.group(3)
            totaleSales = result.group(4)
            

            onlinePurcahse = OnlinePurchase(
                purchaseDate, productDescription, totaleSales, unitQuantity)
            onlinePurcahseList.append(onlinePurcahse)
        return OnlinePurchaseList(onlinePurcahseList)

    def __prepareOnlineReturnList__(self):
        onlineReturns = self.__getPIValueList__(
            "Online Return")
        if onlineReturns is None:
          return
        onlineReturnRegex = 'Return Reported Date:(.*?),Product Description:(.*?),Quantity to Return:(.*?),Total Return Dollars:(.*)'
        onlineReturnsList = []
        for onlineReturnData in onlineReturns:
            result = re.search(rf"{onlineReturnRegex}", onlineReturnData)
            returnReportedDate = result.group(1)
            productDescription = result.group(2)
            quanityToReturn = result.group(3)
            totalReturnDollars = result.group(4)

            onlineReturn = OnlineReturn(
                returnReportedDate, productDescription, quanityToReturn, totalReturnDollars)
            onlineReturnsList.append(onlineReturn)
        return OnlinReturnList(onlineReturnsList)

    def __preparePaymentDetailsList__(self):
        paymentDetails = self.__getPIValueList__(
            "Payment Details")
        if paymentDetails is None:
          return
        paymentDetailRegex = 'Purchase Date:(.*?),Payment Type:(.*?),Tendered Amount \(\$\):(.*?),Card Last 4 Digits:(.*?),Purchase Type:(.*)'
        paymentDetailsList = []
        for paymetDetailsData in paymentDetails:
            result = re.search(rf"{paymentDetailRegex}", paymetDetailsData)
            purchaseDate = result.group(1)
            paymentType = result.group(2)
            tenderedAmount = result.group(3)
            card4Digits = result.group(4)
            purchaseType = result.group(5)

            paymentDetails = PaymentDetail(
                purchaseDate, paymentType, tenderedAmount, card4Digits, purchaseType)
            paymentDetailsList.append(paymentDetails)
        return PaymentDetailList(paymentDetailsList)

    def getSummaryReportObject(self) -> SummaryReport:
        customerData = self.__prepareCustomerData__()
        salesTransactionsData = self.__prepareSalesTransactionSummary__()
        loyaltyInfoList = self.__prepareLoyaltyInformations__()
        loyaltyOfferMadeToCustomer = self.__prepareLoyaltyOfferMadeToCustomer__()
        pscDData = self.__preparePSCInfo__()
        inferenceAboutYouData = self.__prepareInferenceAboutYou__()
        requestData = Request(
            self.request_number, self.requester, self.request_date)
        return SummaryReport(request=requestData, customer=customerData,
                                          loyatlyInformations=loyaltyInfoList, loyaltyOfferMadeToCustomer=loyaltyOfferMadeToCustomer,
                                          pSCInfo=pscDData, inferenceAboutYou=inferenceAboutYouData,
                                          salesTransactionSummary=salesTransactionsData)

    def getDetailReportObject(self):
        instorePurcahseList = self.__prepareInStorePurchaseList__()
        onlinePurchaseList = self.__prepareOnlinePurchaseList__()
        onlineReturnList = self.__prepareOnlineReturnList__()
        paymentDetailsList = self.__preparePaymentDetailsList__()
        requestData = Request(
            self.request_number, self.requester, self.request_date)
        return DetailReport(requestData, instorePurcahseList, onlinePurchaseList, onlineReturnList, paymentDetailsList)

    def getLVReportObject(self):
        requestData = Request(
            self.request_number, self.requester, self.request_date)
        return LVReport(requestData)


# COMMAND ----------

# PDF Creator
from fpdf import FPDF
import logging
import yaml
from yaml.loader import SafeLoader


class PDF(FPDF):
    bullet_character = "\u2022"
    logger = logging.getLogger(__name__)

    def __init__(self, config):
        super().__init__(orientation="L", unit="mm", format="A4")
        fontConfig = config["report"]["config"]["font"]
        self.report_font = fontConfig["name"]
        self.logo = config["report"]["config"]["logo"]["path"]
        self.add_font(
            "Calibri", "", fontConfig["path"]+"calibri.ttf")
        self.add_font(
            "Calibri", "B", fontConfig["path"]+"calibrib.ttf")

        self.set_font_size(fontConfig["size"])
        self.header_font_size = fontConfig["headersize"]
        self.report_font_size = fontConfig["size"]
        self.set_fill_color(255, 255, 0)
        self.set_margins(15, 10)
        self.add_page()

    def __printTableHeader__(
        self, headers, widthMap, alignmentMap, height_multiplier=2
    ):
        self.set_font(self.report_font, "B")
        total = sum(widthMap)
        counter = 0
        unit_width = self.epw / total
        for header in headers:
            width = unit_width * widthMap[counter]
            self.multi_cell(
                w=width,
                h=self.font_size * height_multiplier * 2,
                max_line_height=self.font_size * height_multiplier,
                txt=header,
                border=1,
                new_y="TOP",
                new_x="RIGHT",
                fill=True,
                align=alignmentMap[counter],
            )
            counter = counter + 1
        self.ln(self.font_size * height_multiplier * 2)

    def __printTableValue__(self, values, widthMap, alignmentMap):

        self.set_font(self.report_font, "")
        total = sum(widthMap)
        counter = 0
        unit_width = self.epw / total
        for value in values:
            self.multi_cell(
                w=unit_width * widthMap[counter],
                h=self.font_size * 2,
                max_line_height=self.font_size * 2,
                txt=value,
                border=1,
                new_y="TOP",
                new_x="RIGHT",
                align=alignmentMap[counter],
            )
            counter = counter + 1
        self.ln()

    def __printTableSection__(self, sectionName, tableSectionData, height_multiplier=2):
        if tableSectionData is not None:
            self.ln(self.report_font_size)
            if (self.y + self.b_margin + self.report_font_size * 2) > 210:
                self.add_page()
            headers = tableSectionData.__headingAttributeMap__
            widthMap = list(tableSectionData.__widthMap__.values())

            try:
                alignmentMap = tableSectionData.__alignmentMap__
            except AttributeError:
                alignmentMap = {}

            alignmentData = []
            for header in headers:
                if alignmentMap.get(header) is not None:
                    alignmentData.append(alignmentMap.get(header))
                else:
                    alignmentData.append("L")

            if widthMap is None:
                widthMap = [1 for i in headers]
            headerKeys = headers.keys()
            dataIndexes = headers.values()
            entries = tableSectionData.entries

            self.set_font(self.report_font, "BU")
            self.cell(w=self.epw, h=self.font_size * 2, txt=sectionName, ln=1)
            self.__printTableHeader__(
                headerKeys, widthMap, alignmentData, height_multiplier
            )
            for row in entries:
                data = []
                for dataIndex in dataIndexes:
                    data.append(row[dataIndex])
                self.__printTableValue__(data, widthMap, alignmentData)
            self.ln(self.font_size)
        else:
            self.set_font(self.report_font, "BU")
            self.cell(133, 10, txt=sectionName)
            self.set_font(self.report_font)
            self.cell(133, 10, txt="NA", ln=1)
        self.__horizontalBar__()

    def __horizontalBar__(self):
        self.set_line_width(0.4)
        self.line(self.get_x(), self.get_y(), self.get_x() + 267, self.get_y())
        self.set_line_width(0.2)

    def __printHeadingValueSection__(self, sectionName, sectionData):
        sectionDataValueCounter = 0
        if sectionData is not None:
            self.set_font(self.report_font, "BU")            
            keys = sectionData.__headingAttributeMap__
            
            for key, value in keys.items():
                if (sectionData[value] is not None) and (len(sectionData[value]) > 0):
                  if sectionDataValueCounter == 0:
                    self.cell(133, 10, sectionName, 0, 1)
                  self.__printHeadingAndValue__(key, sectionData[value])
                  sectionDataValueCounter = sectionDataValueCounter + 1
        else:
            sectionDataValueCounter = sectionDataValueCounter + 1
            self.__printHeadingAndValue__(sectionName, "NA", "BU")
            
        if sectionDataValueCounter == 0:
          self.__printHeadingAndValue__(sectionName, "NA", "BU")
        
        self.__horizontalBar__()
        
    def __printHeadingAndValue__(self, header, value, headingFontOptions="B"):
        self.set_font(self.report_font, headingFontOptions)
        self.cell(133, 10, txt=header)
        self.set_font(self.report_font)
        valueCounter = 0
        if value is None:
            self.cell(133, 10, txt="NA", ln=1)
        elif type(value) is not list:
            self.cell(133, 10, txt=value, ln=1)
        else:
            if len(value) > 0:
                for val in value:
                    if valueCounter > 0:
                        self.cell(133)
                    self.cell(133, 10, txt=val.strip(), ln=1)
                    valueCounter = valueCounter + 1
            else:
                self.cell(133, 10, txt="NA", ln=1)

    def header(self):
        # Logo
        # Todo move to resource directory
        self.image(self.logo, x=23, y=2, w=self.epw-20, h=35)
        self.ln(32)

    def save(self, name):
        self.output(
            f'{name}', "F")


class ReportPDF(PDF):
    def __init__(self, report, propertiesPath):

        self.report = report
        with open(propertiesPath) as f:
            config = yaml.load(f, Loader=SafeLoader)

        super().__init__(config=config)
        self.__printRequestDetails__()

    def __printRequestDetails__(self):
        request: Request = self.report.request
        self.set_line_width(0.4)
        self.set_font(self.report_font, "B")
        self.cell(133, h=9, txt="Request Id", border="T,L")
        self.set_font(self.report_font, "")
        self.cell(133, h=9, txt=request.requesterId, border="T,R", ln=1)
        self.set_font(self.report_font, "B")
        self.cell(133, h=9, txt="Requester Name", border="L")
        self.set_font(self.report_font, "")
        self.cell(133, h=9, txt=request.requesterName, border="R", ln=1)
        self.set_font(self.report_font, "B")
        self.cell(133, h=9, txt="Report Date", border="B,L")
        self.set_font(self.report_font, "")
        self.cell(133, h=9, txt=request.reportDate, border="B,R", ln=1)
        self.set_line_width(0.2)

    def __printEndSection__(self, endSection, printhorizontalBarAtEnd=True):
        for section in endSection["sections"]:
            self.set_font(self.report_font, "BU")
            self.cell(w=self.epw, h=self.font_size *
                      2, txt=section["header"], ln=1)
            for subheading in section["subheadings"]:
                self.set_font(self.report_font)
                if subheading["header"] is not None:
                    self.multi_cell(w=self.epw, h=self.font_size * 2,
                                    txt=subheading["header"], ln=1)
                if subheading.get("points") is not None:
                    counter = 1
                    bulletDisplay = subheading["pointDisplay"] == "bullet"
                    for point in subheading["points"]:
                        self.set_font(self.report_font, )
                        self.cell(w=self.epw, h=self.font_size *
                                  2, txt=(self.bullet_character if bulletDisplay else str(counter)+". ")+point, ln=1)
                        counter = counter+1
            if printhorizontalBarAtEnd:
                self.__horizontalBar__()
            self.ln()


class SummaryReportPDF(ReportPDF):
    def __init__(self, summaryReport, propertiesPath):
        super().__init__(summaryReport, propertiesPath)
        self.summaryReport: SummaryReport = summaryReport
        self.requestNumber = summaryReport.request.requesterId
        with open(propertiesPath) as f:
            config = yaml.load(f, Loader=SafeLoader)
            self.endSection = config["report"]["endSectionForSummaryAndDetail"]
            self.filePrefix = config["report"]["config"]["file"]["summaryPrefix"]
            self.fileExtension = config["report"]["config"]["file"]["extension"]
            self.fileDirectory = config["report"]["config"]["file"]["path"]

    def __printCustomerInfo__(self):
        sectionName = "Customer Information"
        sectionData = self.summaryReport.customer
        self.__printHeadingValueSection__(sectionName, sectionData)

    def __printLoyaltyInfo__(self):
        sectionName = "Loyalty Information"
        tabledSection = self.summaryReport.loyatlyInformations
        self.__printTableSection__(sectionName, tabledSection)

    def __printLoyaltyOffersMadeToCustomer__(self):
        sectionName = "Loyalty offers made to the customer"
        tabledSection = self.summaryReport.loyaltyOfferMadeToCustomer
        self.__printTableSection__(sectionName, tabledSection, 1)

    def __printPSCInformation__(self):
        sectionName = "PSC Information"
        tabledSection = self.summaryReport.pSCInfo
        if tabledSection is not None:
            self.__printTableSection__(sectionName, tabledSection)
        else:
            self.set_font(self.report_font, "BU")
            self.cell(133, 10, txt=sectionName)
            self.set_font(self.report_font)
            self.ln()
            self.__printHeadingAndValue__("Membership Id", "NA")
            self.__horizontalBar__()

    def __printEmailSubscription_(self):
        sectionName = "Email Subscription"
        sectionData = self.summaryReport.emailSubscription
        self.__printHeadingValueSection__(sectionName, sectionData)

    def __printInferencesAboutYou__(self):
        sectionName = "Inferences About You"
        sectionData = self.summaryReport.inferenceAboutYou
        self.__printHeadingValueSection__(sectionName, sectionData)

    def __printSalesTransactionSummary__(self):
        sectionName = "Sales Transaction Summary"
        sectionData = self.summaryReport.salesTransactionSummary
        self.__printHeadingValueSection__(sectionName, sectionData)

    def __save__(self):
        self.__printEndSection__(self.endSection)
        self.save(f"{OUT_FILEPATH}/{self.filePrefix}{INPUT_FILENAME}{self.fileExtension}")

    def printReport(self):
        self.__printCustomerInfo__()
        self.__printLoyaltyInfo__()
        self.__printLoyaltyOffersMadeToCustomer__()
        self.__printPSCInformation__()
        self.__printEmailSubscription_()
        self.__printInferencesAboutYou__()
        self.__printSalesTransactionSummary__()
        self.__save__()


class DetailReportPDF(ReportPDF):
    def __init__(self, detailreport, propertiesPath):
        super().__init__(detailreport, propertiesPath)
        self.detailreport: DetailReport = detailreport
        self.requestNumber = detailreport.request.requesterId
        with open(propertiesPath) as f:
            config = yaml.load(f, Loader=SafeLoader)
            self.endSection = config["report"]["endSectionForSummaryAndDetail"]
            self.filePrefix = config["report"]["config"]["file"]["transactionPrefix"]
            self.fileExtension = config["report"]["config"]["file"]["extension"]
            self.fileDirectory = config["report"]["config"]["file"]["path"]

    def __save__(self):
        self.__printEndSection__(self.endSection)
#         self.save(f"{self.fileDirectory}/{self.filePrefix}{self.requestNumber}{self.fileExtension}")
        self.save(f"{OUT_FILEPATH}/{self.filePrefix}{INPUT_FILENAME}{self.fileExtension}")

    def __printInstorePurchaes__(self):
        sectionName = "Instore Purcahses"
        tabledSection = self.detailreport.instorePurchases
        self.__printTableSection__(sectionName, tabledSection, 1)

    def __printOnlinePurchase__(self):
        sectionName = "Online Purcahses"
        tabledSection = self.detailreport.onlinePurcahses
        self.__printTableSection__(sectionName, tabledSection, 1)

    def __printOnlineReturns__(self):
        sectionName = "Online Returns"
        tabledSection = self.detailreport.onlineReturns
        self.__printTableSection__(sectionName, tabledSection, 1)

    def __printPaymentDetails__(self):
        sectionName = "Payment Details"
        tabledSection = self.detailreport.paymentDetails
        self.__printTableSection__(sectionName, tabledSection, 1)

    def printReport(self):
        self.__printInstorePurchaes__()
        self.__printOnlinePurchase__()
        self.__printOnlineReturns__()
        self.__printPaymentDetails__()
        self.__save__()


class LVReportPDF(ReportPDF):
    def __init__(self, lvReportData, propertiesPath):
        super().__init__(lvReportData, propertiesPath)
        self.lvReportData: LVReport = lvReportData
        self.requestNumber = lvReportData.request.requesterId
        with open(propertiesPath) as f:
            config = yaml.load(f, Loader=SafeLoader)
            self.endSection = config["report"]["endSectionForLV"]
            self.filePrefix = config["report"]["config"]["file"]["lvPrefix"]
            self.fileExtension = config["report"]["config"]["file"]["extension"]
            self.fileDirectory = config["report"]["config"]["file"]["path"]

    def __save__(self):
        self.__printEndSection__(self.endSection, False)
        self.save(f"{OUT_FILEPATH}/{self.filePrefix}{INPUT_FILENAME}{self.fileExtension}")
#         self.save(f"/mnt/wrangled/master_data/customer/ccpa/output/pdfReports/{self.filePrefix}{self.requestNumber}{self.fileExtension}")

    def printReport(self):
        self.__save__()


# COMMAND ----------


# dbutils.widgets.text("PAR_DB_OUTPUT_PATH", "master_data/customer/ccpa/output/CompleteNestedCSV/Q4E2SY7TLS__CompleteNestedCSV") #<ticketNumber>_pdfReport
# dbutils.widgets.text("PAR_DB_INPUT_FILENAME", "DAE_OTT_RTA_CMR_APPTEAMREPORT_RES_20221221075105Z_d90df23c-16fe-4b4c-9e2c-0aea03425d0e.csv") #<ticketNumber>_pdfReport
# dbutils.widgets.text("PAR_DB_INPUT_VERIFICATION", "FULLY_VERIFIED") #<ticketNumber>_pdfReport

# COMMAND ----------

# Generate PDF Report
import pandas as pd


#TODO Fix in.csv path
IN_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
INPUT_FILENAME_ORIG = dbutils.widgets.get("PAR_DB_INPUT_FILENAME")
INPUT_LV_FLAG = dbutils.widgets.get("PAR_DB_INPUT_VERIFICATION")

OUTPUT_PATH =  mountPoint+ '/'+ IN_PATH.replace('CompleteNestedCSV','pdfReport')
tkt_nbr = IN_PATH.split('/')[5].split('_')[0]
INPUT_FILENAME = INPUT_FILENAME_ORIG.replace('.csv','').replace('DAE_','')
INPUT_FILENAME = tkt_nbr + '_' + INPUT_FILENAME.split('_')[6] + '_' + INPUT_FILENAME.split('_')[5]

OUT_FILEPATH = mountPoint+ '/'+ IN_PATH 
data = spark.read.csv(OUT_FILEPATH + '/' + INPUT_FILENAME_ORIG, header=True, sep='\u0001').toPandas()

yaml_file_location = r"/dbfs/mnt/utility_shell/ccpa/yaml/reportproperties.yaml"


# COMMAND ----------
reportData = ReportData(data)
summarReportObject = reportData.getSummaryReportObject()
detailReportObject = reportData.getDetailReportObject()
lvReportObject = reportData.getLVReportObject()
print(lvReportObject)

#TODO Fix propertiesPath
if INPUT_LV_FLAG == 'FULLY_VERIFIED':
    SummaryReportPDF(summarReportObject, propertiesPath = yaml_file_location).printReport()
    DetailReportPDF(detailReportObject, propertiesPath = yaml_file_location).printReport()
else :
    LVReportPDF(lvReportObject, propertiesPath = yaml_file_location).printReport()




# COMMAND ----------

print(INPUT_FILENAME)

# COMMAND ----------

files = dbutils.fs.ls(OUT_FILEPATH)
print(files)

for i in files:
    if i.path.endswith(".pdf"):
      print(i.path)
      dbutils.fs.mv(i.path,OUTPUT_PATH + '/' + i.name)


# Databricks notebook source
# Mounting ADLS
from pyspark.sql import *
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)


# COMMAND ----------

#************* Defining ADLS parameters ************

prev_file_path = dbutils.widgets.get("PAR_NB_LKP_DIR")
curr_file_path = dbutils.widgets.get("PAR_NB_IN_DIR")
pre_file_name = dbutils.widgets.get("PAR_NB_IN_PREV_FILE")

Input_Schema  = dbutils.widgets.get("PAR_NB_CDC_DML")
Input_Schema = Input_Schema.replace(" ", "").split(",")
print(Input_Schema)

curr_file_name = dbutils.widgets.get("PAR_NB_IN_CURR_FILE")
cdc_key_string = dbutils.widgets.get("PAR_NB_CDC_KEY")
cdc_key_list=cdc_key_string.split(",")
out_file_cdc_path = dbutils.widgets.get("PAR_NB_OUT_DIR")
out_file_cdc_name = dbutils.widgets.get("PAR_NB_OUT_CDC_FILE")
edw_batch_id = dbutils.widgets.get("PAR_NB_OUT_DAP_BATCH_ID")
fileDelimiter = dbutils.widgets.get("PAR_NB_FILE_DELIMETER")
#table_name = dbutils.widgets.get("PAR_NB_TABLE_NAME")


preFile = mountPoint + '/' + prev_file_path + '/' + pre_file_name
print('preFile :'+preFile)

currFile = mountPoint + '/' + curr_file_name 
print('currFile :'+currFile)

outPutFile = mountPoint + '/' + out_file_cdc_path + '/' + out_file_cdc_name +'/' + edw_batch_id + '/'
print('outPutFile :' + outPutFile)



# COMMAND ----------

from pyspark.sql.functions import *

currDF =spark.read.format("CSV").option("sep","|").load(currFile).toDF(*Input_Schema)
Sourcedf=currDF.select([trim(col(c)).alias(c) for c in currDF.columns])

try:
  dbutils.fs.ls(preFile)
  preDF = spark.read.format("parquet").load(preFile).toDF(*Input_Schema)
  Masterdf = preDF.select([trim(col(c)).alias(c) for c in preDF.columns])
  Masterdf = Masterdf.alias('Masterdf')
  Sourcedf = Sourcedf.alias('Sourcedf')
  innerFinalDF=Sourcedf.join(Masterdf,cdc_key_list,"inner").select('Sourcedf.*')
  #innerFinalDF.count()
  leftFinalDF=Sourcedf.join(Masterdf,cdc_key_list,"leftanti")
  #leftFinalDF.count()
  rightFinalDF=Masterdf.join(Sourcedf,cdc_key_list,"leftanti")
  rightFinalDFFiltered = rightFinalDF.filter((col("wic").rlike("^\d*$")) & (length(col("wic")) > 0))
  UnionDF = innerFinalDF.union(leftFinalDF).union(rightFinalDFFiltered)
  #finalDF.show()
  
except Exception as e:
  if 'java.io.FileNotFoundException' in str(e):
    UnionDF = Sourcedf
    #finalDF.show()
    
  else:
    print(e)

# COMMAND ----------

#Load Ready File
UnionDF.write.format("parquet").mode("overwrite").save(outPutFile)


# COMMAND ----------

#Replacing Master files with today's current files
UnionDF.write.format("parquet").mode("overwrite").save(preFile)

# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

import pyspark
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType
import datetime
import pyspark.sql.column 
from pyspark.sql.types import LongType

# COMMAND ----------

dbutils.widgets.text("PAR_DB_INPUT_PATH","",label="PAR_DB_INPUT_PATH")
dbutils.widgets.text("PAR_DB_INPUT_FILE_NAME","",label="PAR_DB_INPUT_FILE_NAME")
dbutils.widgets.text("PAR_DB_CNT_FILE_PATH","",label="PAR_DB_CNT_FILE_PATH")
dbutils.widgets.text("PAR_DB_CNT_FILE","",label="PAR_DB_CNT_FILE")
adlsInputFolderPath=dbutils.widgets.get("PAR_DB_INPUT_PATH")
adlsInputFileName=dbutils.widgets.get("PAR_DB_INPUT_FILE_NAME")
adlsCntFilePath=dbutils.widgets.get("PAR_DB_CNT_FILE_PATH")
adlsCntFileName=dbutils.widgets.get("PAR_DB_CNT_FILE")
#delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')

# COMMAND ----------

# Get Line Count From Source File
Inputdf = spark.read.text(mountPoint+'/'+adlsInputFolderPath+'/'+adlsInputFileName)
Inputdf=Inputdf.filter(Inputdf.value != '')
InputFileCnt=Inputdf.count()
#print(InputFileCnt)

# COMMAND ----------

#Read Count File
Cntdf=sc.textFile(mountPoint+'/'+adlsCntFilePath+'/'+adlsCntFileName)
CountFromCntFile=Cntdf.collect()[0]
#print(CountFromCntFile)


# COMMAND ----------

#Check Count from Soucre and Cnt File
if int(CountFromCntFile) == int(InputFileCnt):
  dbutils.notebook.exit("SUCCESS")
else:
  dbutils.notebook.exit("FAIL")

# COMMAND ----------


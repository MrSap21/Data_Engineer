// Databricks notebook source
//$"loyalty_member_id",$"question_details_id",$"option_details_id",$"dap_gen_mi_last_update_dttm".desc
//$loyalty_member_id,$question_details_id,$option_details_id,$dap_gen_mi_last_update_dttm.desc
dbutils.widgets.text("PAR_DB_AI_SERIAL","",label="PAR_DB_AI_SERIAL")
dbutils.widgets.text("PAR_DB_IN_FILE","",label="PAR_DB_IN_FILE")
dbutils.widgets.text("PAR_DB_BATCH_ID","",label="PAR_DB_BATCH_ID")
dbutils.widgets.text("PAR_DB_COLOUMN_DELIMITER","",label="PAR_DB_COLOUMN_DELIMITER")
dbutils.widgets.text("PAR_DB_TARGET_DELIMITER","",label="PAR_DB_TARGET_DELIMITER")
dbutils.widgets.text("PAR_DB_ROW_DELIMITER","",label="PAR_DB_ROW_DELIMITER")
dbutils.widgets.text("PAR_DB_INPUT_CONTAINER_NAME","",label="PAR_DB_INPUT_CONTAINER_NAME")
dbutils.widgets.text("PAR_DB_INPUT_FORMAT","",label="PAR_DB_INPUT_FORMAT")
dbutils.widgets.text("PAR_DB_REJ_HDR_GEN_IND","",label="PAR_DB_REJ_HDR_GEN_IND")
dbutils.widgets.text("PAR_DB_NO_OF_REJ_HEADER_COLOUMNS","",label="PAR_DB_NO_OF_REJ_HEADER_COLOUMN")
dbutils.widgets.text("PAR_DB_AI_GRAPH_NAME","",label="PAR_DB_AI_GRAPH_NAME")
dbutils.widgets.text("PAR_DB_CNTRL_FILE_VERIFY_IND","",label="PAR_DB_CNTRL_FILE_VERIFY_IND")
dbutils.widgets.text("PAR_DB_CNTRL_FILE_REJ_IND","",label="PAR_DB_CNTRL_FILE_REJ_IND")
dbutils.widgets.text("PAR_DB_DATE_CHECK","",label="PAR_DB_DATE_CHECK")
dbutils.widgets.text("PAR_DB_IN_FILE_COL_CNT","",label="PAR_DB_IN_FILE_COL_CNT")
dbutils.widgets.text("PAR_DB_DEDUP_DATA_IND","",label="PAR_DB_DEDUP_DATA_IND")
dbutils.widgets.text("PAR_DB_TGT_KEY_LIST","",label="PAR_DB_TGT_KEY_LIST")
dbutils.widgets.text("PAR_DB_TGT_KEY_LIST_ORDER_BY","",label="PAR_DB_TGT_KEY_LIST_ORDER_BY")
dbutils.widgets.text("PAR_DB_REJ_HDR_GEN_SRC_KEY_LIST","",label="PAR_DB_REJ_HDR_GEN_SRC_KEY_LIST")
dbutils.widgets.text("PAR_DB_REJ_HDR_GEN_SRC_KEY_DELIMITER","",label="PAR_DB_REJ_HDR_GEN_SRC_KEY_DELIMITER")
dbutils.widgets.text("PAR_DB_CLEANSE_KEY_FLTR_EXP","",label="PAR_DB_CLEANSE_KEY_FLTR_EXP")
dbutils.widgets.text("PAR_DB_SCHEMA","",label="PAR_DB_SCHEMA")
dbutils.widgets.text("PAR_DB_VALIDATE_DATA_IND","",label="PAR_DB_VALIDATE_DATA_IND")
dbutils.widgets.text("PAR_DB_REJECT_DELIMITER","",label="PAR_DB_REJECT_DELIMITER")


// COMMAND ----------

val adlsInputContainerName=dbutils.widgets.get("PAR_DB_INPUT_CONTAINER_NAME")                   
val adlsInputFilePath = dbutils.widgets.get("PAR_DB_AI_SERIAL")
val adlsInputFileName = dbutils.widgets.get("PAR_DB_IN_FILE")
val adlsInputbatchid = dbutils.widgets.get("PAR_DB_BATCH_ID")
val adlsGraphName = dbutils.widgets.get("PAR_DB_AI_GRAPH_NAME")
val srcColumnDelimiter = dbutils.widgets.get("PAR_DB_COLOUMN_DELIMITER")
val targetColumnDelimiter = dbutils.widgets.get("PAR_DB_TARGET_DELIMITER")
val rowDelimiter=dbutils.widgets.get("PAR_DB_ROW_DELIMITER")
val reformat = dbutils.widgets.get("PAR_PL_REFORMAT_VAR")
val inFormat = dbutils.widgets.get("PAR_DB_INPUT_FORMAT")
val rejHeaderInd= dbutils.widgets.get("PAR_DB_REJ_HDR_GEN_IND")
val rejHeaderCount = dbutils.widgets.get("PAR_DB_NO_OF_REJ_HEADER_COLOUMNS")
var cntrlFileVerifyInd=dbutils.widgets.get("PAR_DB_CNTRL_FILE_VERIFY_IND")
var cntrlFileRejInd=dbutils.widgets.get("PAR_DB_CNTRL_FILE_REJ_IND")
var dateCheckWidget=dbutils.widgets.get("PAR_DB_DATE_CHECK")
var lengthOfSchema=dbutils.widgets.get("PAR_DB_IN_FILE_COL_CNT")
var dfCleanDuplicate=dbutils.widgets.get("PAR_DB_DEDUP_DATA_IND")
var columnToRemoveDuplicatesWidget=dbutils.widgets.get("PAR_DB_TGT_KEY_LIST")
var orderByRemoveDuplicatesWidget=dbutils.widgets.get("PAR_DB_TGT_KEY_LIST_ORDER_BY")
var colNamesRejHdrSrcKeyWidgetList = dbutils.widgets.get("PAR_DB_REJ_HDR_GEN_SRC_KEY_LIST")
var colNamesRejHdrSrcKeyDelimiterWidget=dbutils.widgets.get("PAR_DB_REJ_HDR_GEN_SRC_KEY_DELIMITER")
var cleanseKeySelectColoumnsWidget=dbutils.widgets.get("PAR_DB_CLEANSE_KEY_FLTR_EXP")
var schemaString = dbutils.widgets.get("PAR_DB_SCHEMA")
var validCheckIndicator=dbutils.widgets.get("PAR_DB_VALIDATE_DATA_IND")
var rejectDelimiter= dbutils.widgets.get("PAR_DB_REJECT_DELIMITER")
//pVALIDATE_DATA_IND
//var validCheckIndicator= "Y"
//pCLEANSE_KEY_FLTR_EXP
//var cleanseKeySelectColoumns=List("*")
//TGT_KEY_LIST
//TimestampType@yyyy-MM-dd HH:mm:ss

// COMMAND ----------


import org.apache.spark.sql.types.{StructType, StructField, StringType, IntegerType};
import org.apache.spark.sql.functions._

import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.Window

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import org.apache.spark.sql.Row
import scala.util.{Try, Failure, Success}

// COMMAND ----------

// DBTITLE 1,Global Parameter
//val dateCheck:Long = 10101000000L
//var rejectDelimiter="\\\\x01"
val dateCheck:Long = dateCheckWidget.toLong
//var rejectDelimiter= ","
var flag = 0
//var lengthOfSchema=16
var rejectOutputFormat="rej"


var colNamesRejHdrSrcKey = colNamesRejHdrSrcKeyWidgetList.split(",").toList
var colNamesRejHdrSrcKeyDelimiter= colNamesRejHdrSrcKeyDelimiterWidget
//pCLEANSE_KEY_FLTR_EXP
var cleanseKeySelectColoumns=cleanseKeySelectColoumnsWidget.split(",").toList

 var columnToRemoveDuplicates=columnToRemoveDuplicatesWidget.split(",").toList



var orderByRemoveDuplicatesTemp= orderByRemoveDuplicatesWidget.toString.split(",").toList
var orderBySplitColKey = orderByRemoveDuplicatesTemp.map(x=>x.split("\\|+") match { case Array(i, j) => (i, j) })
var orderByFinalKeys=orderBySplitColKey.map(x=>x).map(c=>if (c._2=="desc") desc(c._1)
                                             else
                                             asc(c._1))

var  lengthMultiFileScehma=0

if(lengthOfSchema!="")
lengthMultiFileScehma = lengthOfSchema.toInt-rejHeaderCount.toInt


// COMMAND ----------

// DBTITLE 1,Common Functions
def writeToADLS(df:DataFrame,containerName:String,filePath:String,fileName:String, intermediateformat:String,FinalForamt:String, delimiter:String,mode:String ="overwrite"):Integer={
  
  df.coalesce(1)
     .write
     .format(intermediateformat)
     .mode(mode)
     .option("delimiter",delimiter)
     .save("/mnt/" + containerName + "/" + filePath + "/" + fileName + "." + intermediateformat)
  
  val partition_path = dbutils.fs.ls("/mnt/" +  containerName+ "/" + filePath + "/"+ fileName + "."+intermediateformat)
                                    .filter(file=>file.name.endsWith(".csv"))(0).path

  print("path "+partition_path)
  dbutils.fs.cp(partition_path,"/mnt/"  + containerName + "/"+filePath + "/"+ fileName + "." + FinalForamt)
  dbutils.fs.rm( "/mnt/" + containerName + "/"+filePath + "/"+ fileName +"."+intermediateformat,recurse=true)
  
  return 0
  
}


def getFromADLS(spark:SparkSession,containerName:String, filePath:String, fileName:String, format:String, delimiter:String=","):DataFrame={
  
  val df = spark.read.format(format)
                .option("header","False")
                .option("delimiter",delimiter)
                .load("/mnt/" + containerName + "/" + filePath + "/" + fileName )
  
  return df
  
}


def getFromADLSGenericOptions(spark:SparkSession, filePath:String, format:String, option1:String="header",option1Value:String = "True",option2:String="delimiter",option2Value:String=","):DataFrame={
  
  val df = spark.read.format(format)
      .option(option1,option1Value) 
      .option(option2,option2Value)
      .load(filePath )
  
  return df
  
}



def getFromADLSFullPath(spark:SparkSession,inputFile:String,format:String):DataFrame={
  
  val df = spark.read.format(format)
      .option("header","False")
      .load("/mnt/" + inputFile )
  
  return df
  
}


def conditionalSplit(df:DataFrame,condition:Column): (DataFrame,DataFrame) =
{
  var dfSuccessReject = df.withColumn("ConditionCheck",
                                      when((condition),"True")
                                      .otherwise("False"))
 
  var dfSuccess=dfSuccessReject.filter($"ConditionCheck"==="True").drop("ConditionCheck")
  var dfReject=dfSuccessReject.filter($"ConditionCheck"==="False").drop("ConditionCheck")
  return (dfSuccess,dfReject)
}


def aliasAllColumnsPrefix(t: DataFrame,p: String = ""): DataFrame = {
  t.select(t.columns.map{c => t.col(c).as (p + c)} : _*)
}
/*

def columnSplitAlias(schemaList:List[String],df:DataFrame,delimiter:String,noOfColumns:Int,requiredColumn:String): DataFrame = {
    
  var linesSplit = df.withColumn("allcolumns",split(df(requiredColumn),delimiter))
  var finalSplit = linesSplit.select(col("*") +:(0 until noOfColumns).map(i =>linesSplit("allcolumns")
                                                            .getItem(i).as(schemaList(i))):_*)
                             .drop("allcolumns")
//                             .drop(requiredColumn)
  return finalSplit
}

*/


def columnSplitAlias(schemaList:List[String],df:DataFrame,delimiter:String,noOfColumns:Int,requiredColumn:String): DataFrame = {
  var requiredColumnTemp=  (requiredColumn+"_temp")
  var linesSplitTemp = df.withColumnRenamed(requiredColumn,requiredColumnTemp)
  var linesSplit =    linesSplitTemp.withColumn("allcolumns",split(linesSplitTemp(requiredColumnTemp),delimiter))
  var finalSplit = linesSplit.select(col("*") +:(0 until noOfColumns).map(i =>linesSplit("allcolumns")
                                                            .getItem(i).as(schemaList(i))):_*)
                             .drop("allcolumns")
                            .drop(requiredColumnTemp)
  return finalSplit
 

}

// Function to select the required  columns from Dataframe 
// Eg: To Select specific coloumns pass List("column1","column2")
//Eg: TO select all columns pass - List("*")

def selectRequiredColoumns(df:DataFrame,ColumnList:List[String]):DataFrame = {

  var dfCleanseSelected=df.select(ColumnList.map(col):_*)
  return(dfCleanseSelected)
}



// Function to select duplicate and not duplicate records
//Declare and pass the below arguments
//columnToRemoveDuplicates=List(column1,column2,...)
//orderByRemoveDuplicates = List(column1.asc,column2.asc,column3.desc)


def duplicatesAndNonduplicate(df:DataFrame,columnToRemoveDuplicates:List[String],
                              orderByRemoveDuplicates:List[Column]):(DataFrame,DataFrame)={
  
//   var window=Window.partitionBy(columnToRemoveDuplicates.map(col):_*).orderBy(orderByRemoveDuplicates.map(col):_*)
   var window=Window.partitionBy(columnToRemoveDuplicates.map(col):_*).orderBy(orderByFinalKeys:_*)
   var dfRowNumber = df.withColumn("row_number",row_number().over(window))
  
   var dfDuplicateRemoved = dfRowNumber.filter($"row_number" === 1).drop("row_number")
   var dfDuplicateRecords = dfRowNumber.filter($"row_number" =!= 1).drop("row_number")
  
   return (dfDuplicateRemoved,dfDuplicateRecords)
  
}

// COMMAND ----------

// DBTITLE 1,Common UDF


var isNullUDF=udf{(columnName: String,nullableCheck:String) => 
            if ( nullableCheck == "nullable" ) true
            else if (columnName == null) false
            else  true     
  
                       }

//var dfNullCheck= duplicateRemoved.withColumn("isNullUDF", isNullUDF(col("loyalty_member_id")))

var lengthCheckUDF=udf{(columnName: String,lengthToCheck: Int) => 
            if (lengthToCheck == 0 ) true 
            else if (columnName.size <= lengthToCheck ) true
            else  false               
                       }

//blankCheck UDF
var blankCheckUDF = udf{(columnName: String,exceptionColumnName: String) => 
            if (exceptionColumnName == "blank") true
            else if (columnName == ("")  ) false
            else  true               
                       }



var specialCharacterCheckUDF = udf{(columnName: String,columnType:String,exceptionColumnName: String) => 
            
            columnType match{
            case "StringType" => if (exceptionColumnName == "specialcharAllow") true
                                 else if(columnName.contains("")||(columnName == null)) true 
                                 else if(!(columnName.contains("^([A-Z]|[0-9]|[a-z])+$" ))) false
 //                              else if(columnName.matches("^[a-zA-Z0-9]*$")) true
                                 else true
            case (("DecimalType")|("IntegerType"))  => if(columnName.contains("")||(columnName == null)) true 
                                                       else if(Try(columnName.toInt).isSuccess || Try(columnName.toLong).isSuccess
                                                               || Try(columnName.toDouble).isSuccess ||  Try(columnName.toFloat).isSuccess
                                                                       ) true
                                  else false
            case _ => true
            }
}





var dataTypeCheckUDF = udf{(columnName: String,columnType:String) => 
            
            columnType match{
            case "StringType" => if (columnName.toString != null) true
                                 else false
  /*          case "DecimalType" =>  Try(columnName.toInt) match {
                                                               case Success(t) => true
                                                               case Failure(_) => false
                                                                                       }*/
            case (("DecimalType")|("IntegerType"))  =>    if(columnName.contains("")||(columnName == null)) true
                                                          else if(Try(columnName.toInt).isSuccess || Try(columnName.toLong).isSuccess
                                                           || Try(columnName.toDouble).isSuccess ||  Try(columnName.toFloat).isSuccess
                                                                       ) true
                                                         else false
              
              
              
             case "TimestampType@yyyy-MM-dd HH:mm:ss" => columnName.trim match {
                                                          case (""|null) => true
                                                          case _ => { 
                                                          var format = new SimpleDateFormat(columnType.split("@")(1))
                                                          Try(new Timestamp(format.parse(columnName).getTime)) match {
                                                               case Success(t) => true
                                                               case Failure(_) => false
                                                                                       }    
                                                                    }
                                                           }
                                  
            case _ => true
            }
}

 





val firstNotNull = udf{(x:String,y:String,z:String) => 
            if (x != null ) x
            else if (y != null) y
            else  z
               
                       }

val firstNotNullType = udf{(x:String,y:String,z:String,a:String,b:String,c:String) => 
            if (x != null ) a
            else if (y != null) b
            else  c
               
                       }

// COMMAND ----------

// DBTITLE 1,Read  File List (graph 1)
//Read Input File lise

val inputFileName = adlsInputFileName+"_"+adlsInputbatchid+".dat"
val dfFileListG1 = getFromADLS(spark, adlsInputContainerName, adlsInputFilePath, inputFileName,"csv",",")

//Get latest File
val dfDateSplit=dfFileListG1.withColumn("DateSplit",concat(substring(substring_index($"_c0","_",-1),1,8),lit("000000")))
                  .withColumn("FileName",substring_index($"_c0","/",-1))
val dfFinalOutLatestFilesG1 = dfDateSplit.filter($"DateSplit".cast(LongType)>dateCheck)
//display(dfFinalOutLatestFilesG1)

//display(dfFileListG1)

// COMMAND ----------

// DBTITLE 1,Verify Record Count (Graph1 -> Graph 3) - Read Multifile Input List 
//Graph 1 multiple input files all read after looping
flag = 0
var dfFinalInputListFileG3 = spark.emptyDataFrame
var dfFinalInputListG1 = dfFinalOutLatestFilesG1.drop($"DateSplit").drop($"FileName")

//To read multiple input files from Graph1 DF
for (row <- dfFinalInputListG1.rdd.collect ){
  var record = row.mkString("/")
  var srcFile = record.substring(record.lastIndexOf("/")+1,record.length())
  var dfRead = getFromADLSFullPath(spark,record,"csv") 
  
  
  var dfTempInputListFile =  dfRead.withColumn("reject_header_src_name",lit(srcFile))
                                    .withColumnRenamed("_c0","read_data")
  //display(dfTempInputListFile)
  if(flag==0)                                    
  dfFinalInputListFileG3=dfTempInputListFile
  
  else
  dfFinalInputListFileG3= dfFinalInputListFileG3.union(dfTempInputListFile)
   
  
  flag=1
 //display (dfFinalInputListFileG3)
}

//display (dfFinalInputListFileG3)

var dfSplitFile = spark.emptyDataFrame
if(rejHeaderInd=="Y" || rejHeaderInd=="y")
dfSplitFile=dfFinalInputListFileG3.withColumn("noOfColumns" , length(regexp_replace(dfFinalInputListFileG3("read_data"), "[^|]", "")) + 1 + rejHeaderCount)
else
dfSplitFile=dfFinalInputListFileG3.withColumn("noOfColumns" , length(regexp_replace(dfFinalInputListFileG3("read_data"), "[^|]", "")) + 1)
//display(dfSplitFile)
//date correct


//date check part dfSplitFile.col("FinalDate")

dfSplitFile=dfSplitFile.withColumn("FinalDate",concat(substring(substring_index($"reject_header_src_name","_",-1),1,8)))
                       .withColumn("FinalDate",concat_ws("-",substring($"FinalDate",1,4),
                                                         substring($"FinalDate",5,2),
                                                         substring($"FinalDate",7,2)))
                        .withColumn("FinalDate",(concat($"FinalDate",lit(" 00:00:00")).cast("timestamp") ))
                         .withColumn("FinalDate",when(!$"FinalDate".isNull,lit(col("FinalDate")))                             
                                   .otherwise(""))
                


//display(dfSplitFile)
//Valid Schema Check -  Length 
val dfValidSchemaCheck = dfSplitFile.withColumn("ErrorCode",when(($"noOfColumns" =!= lengthOfSchema),"201"))
//display(dfValidSchemaCheck)



val dfTargetFile=dfValidSchemaCheck.withColumn("read_data" ,regexp_replace(dfValidSchemaCheck("read_data"), srcColumnDelimiter, targetColumnDelimiter))


//display(dfTargetFile)

// COMMAND ----------

// DBTITLE 1,Verify Record Count (Graph 3) - Read Multifile Input List - Output 

//correct above command need to complete for date
//Add derived columns and add error description
val dfFinalInputListFile =  dfTargetFile.withColumn("reject_header_src_key",lit(""))
                                        .withColumn("reject_header_prty_cd",
                                                    when(($"ErrorCode"===200||$"ErrorCode"===201),
                                                         lit("2"))
                                                     .otherwise(0))
                                        .withColumn("reject_header_err_desc",
                                                     when($"ErrorCode"===200,lit("ERROR: Invalid source file date"))
                                                    .when($"ErrorCode"===201,concat(lit("ERROR: Invalid record layout ("),
                                                                                    lit(rejectDelimiter),
                                                                                    dfTargetFile("noOfColumns").cast(IntegerType),
                                                                                    lit(" columns found out of "),
                                                                                    lit(rejectDelimiter),
                                                                                    lit(lengthOfSchema),
                                                                                    lit(" total expected)"))) 
                                                      .otherwise(0))
                                         .withColumn("reject_header_src_type",lit("F"))
                                         //.withColumn("reject_header_src_name",lit(InputListfileName))
                                         .withColumn("read_data",concat(dfTargetFile("FinalDate"),
                                                                         lit(rejectDelimiter),
                                                                          dfTargetFile("read_data")))
                                        .withColumn("glengthOfSchema",lit(lengthOfSchema))
                                                  
                                                    
 //display(dfFinalInputListFile)


//Conditional Split Success/Reject file based on Error Code

//if(glengthOfSchema)

var condition=($"glengthOfSchema" === "") || (($"reject_header_prty_cd" =!= 1) && ($"reject_header_prty_cd" =!= 2) )

var (dfFilterSuccessFile,dfFilterRejectFile)=conditionalSplit(dfFinalInputListFile,condition)
 

val dfOutInvalidLayoutRejectFile = dfFilterRejectFile.select( $"reject_header_src_name", 
                                                         $"reject_header_src_type", 
                                                         $"reject_header_src_key", 
                                                         $"reject_header_err_desc", 
                                                        $"reject_header_prty_cd",
                                                        $"read_data")


val dfOutValidLayoutSuccessFile = dfFilterSuccessFile.select( $"reject_header_src_name" , 
                                                         $"reject_header_src_type", 
                                                         $"reject_header_src_key", 
                                                         $"reject_header_err_desc", 
                                                        $"reject_header_prty_cd",
                                                        $"read_data")

//display(dfOutValidLayoutSuccessFile)

//OUTF_REJ - Invalid File Layout
var adlsOutInvalidLayoutRejectFileName= "/stdrej_"+ adlsGraphName +"_in_dml"

var writeInd = writeToADLS(dfOutInvalidLayoutRejectFile,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutInvalidLayoutRejectFileName+"_"+adlsInputbatchid,
                           "csv",
                           rejectOutputFormat,
                           rejectDelimiter,
                           "overwrite")

//display(dfOutInvalidLayoutRejectFile)

// COMMAND ----------

// DBTITLE 1,Graph-2 Read Control File List
//Read Input
flag=0
var dfOuterJoinReformatFinal =  spark.emptyDataFrame


if (cntrlFileVerifyInd == "Y")
{

var dfFinalInputControlListFile = spark.emptyDataFrame
val inputFileName = adlsGraphName+"_cntrl_in_list_"+adlsInputbatchid+".dat"
val dfFileListG2 = getFromADLS(spark, adlsInputContainerName, adlsInputFilePath, inputFileName,"csv",",")


//Read Multifiles input Control List
for (row <- dfFileListG2.rdd.collect ){
  var record = row.mkString("/")

  var srcFile = record.substring(record.lastIndexOf("/")+1,record.length())
  var dfRead = getFromADLSFullPath(spark,record,"csv") 
  var dfTempInputListFile =  dfRead.withColumn("reject_header_src_name",lit(srcFile))
                                        .withColumn("reject_header_src_type",lit("F"))
                                        .withColumn("reject_header_src_key",lit(""))
                                        .withColumn("reject_header_err_desc",lit(""))
                                        .withColumn("reject_header_prty_cd",lit(0))
                                        .withColumn("src_filename",lit(""))
                                        .withColumnRenamed("_c0","read_data")
  if(flag==0)                                    
  dfFinalInputControlListFile=dfTempInputListFile
  else
  {dfFinalInputControlListFile= dfFinalInputControlListFile.union(dfTempInputListFile)}
   
  flag=1
 
}




//Filter Control File errors
//inputFileColCount
var condition=(($"reject_header_prty_cd" =!= 1) && ($"reject_header_prty_cd" =!= 2) )
var (dfFilterSuccessFile,dfFilterRejectFile)=conditionalSplit(dfFinalInputControlListFile,condition)


//Select for Reject and sucessfile records
val dfOutInvalidControlLayoutRejectFile = dfFilterRejectFile.select( $"reject_header_src_name", 
                                                         $"reject_header_src_type", 
                                                         $"reject_header_src_key", 
                                                         $"reject_header_err_desc", 
                                                         $"reject_header_prty_cd",
                                                         $"src_filename",    
                                                         $"read_data")

val dfOutValidControlLayoutFile = dfFilterSuccessFile.select( $"reject_header_src_name", 
                                                         $"reject_header_src_type", 
                                                         $"reject_header_src_key", 
                                                         $"reject_header_err_desc", 
                                                         $"reject_header_prty_cd",
                                                         $"src_filename") 
                                                        
//dfFinalMultiOutputs=dfOutValidControlLayoutFile


//OUTF_REJ - Control File error
   
var adlsOutInvalidLayoutRejectFileName1= "/stdrej_"+ adlsGraphName +"_cntrl_file_"

var writeInd = writeToADLS(dfOutInvalidControlLayoutRejectFile,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutInvalidLayoutRejectFileName1+"_"+adlsInputbatchid,
                           "csv",
                           "rej",
                           rejectDelimiter,
                           "overwrite")
  
  
  
  
 //Verify Record Count (Graph 3) - Output Invalid Schema Reject File Input List 
  
  
  
  
//Rollup Invalid Record Layout Count

var windowSpec = Window.partitionBy("reject_header_src_name")
var dfRollupInvalideRecordCount=dfOutInvalidLayoutRejectFile.withColumn("invalid_record_count",
                                                          count($"reject_header_src_name").over(windowSpec))                    

//Rollup Valid Success Record Layout Count


var dfRollupValidRecordCount=dfOutValidLayoutSuccessFile.withColumn("valid_record_count",
                                                          count($"reject_header_src_name").over(windowSpec)) 

//Rollup Valid Success Control Record Layout Count

var dfRollupValideControlLayoutRecordCount=dfOutValidControlLayoutFile.withColumn("exp_record_count",
                                                          count($"reject_header_src_name").over(windowSpec))  

//display(dfRollupValidRecordCount)
  
  
//Join three inputs: Valid record count layout File Graph1, Invalid record count layout File Graph1 , Graph2 output control file output 
  
  
//dfRollupValidRecordCount
//dfRollupInvalideRecordCount
//dfOutValidControlLayoutFile
//Invalid Error records with invalid date and record layout after comparison with Control file wrriten to output

//Call common function to add prefix 
var in0Valid = aliasAllColumnsPrefix(dfRollupValidRecordCount, "in0_valid_")
var in1Invalid = aliasAllColumnsPrefix(dfRollupInvalideRecordCount, "in1_invalid_")
var in2Control = aliasAllColumnsPrefix(dfRollupValideControlLayoutRecordCount, "in2_control_")


//Join Graph3 output(valid and invalid records with Rollup details added extra toDF)  and Graph2 outputs

var dFOuterJoin = in0Valid.join(in1Invalid,
                           in0Valid("in0_valid_reject_header_src_name") ===in1Invalid("in1_invalid_reject_header_src_name"),
                           "outer")
                           .join(in2Control,
                           in0Valid("in0_valid_reject_header_src_name") ===in2Control("in2_control_reject_header_src_name"),
                           "outer")

var dfOuterJoinReformat = dFOuterJoin.withColumn("validRecordCount",
                                                  when($"in0_valid_valid_record_count".isNull,lit(0))
                                                       .otherwise($"in0_valid_valid_record_count"))
                                      .withColumn("invalidRecordCount",
                                                  when($"in1_invalid_invalid_record_count".isNull,lit(0))
                                                       .otherwise($"in1_invalid_invalid_record_count"))
                                      .withColumn("controlRecordCount",
                                                  when($"in2_control_exp_record_count".isNull,lit(0))
                                                       .otherwise($"in2_control_exp_record_count"))
                                       .withColumn("errorCode",
                                                   when(!(($"in2_control_exp_record_count" >= $"in0_valid_valid_record_count") 
                                                          && ($"in2_control_exp_record_count" <= $"in0_valid_valid_record_count" +                                                                                              $"in1_invalid_invalid_record_count")),lit("211"))
                                                   .when($"in2_control_exp_record_count".isNull,lit("210"))
                                                       .otherwise(0)) 
/*
  display(dfOuterJoinReformat.select("in0_valid_reject_header_src_name",
                                     "in1_invalid_reject_header_src_name",
                                     "in2_control_reject_header_src_name",
                                    "in0_valid_valid_record_count",
                                    "in1_invalid_invalid_record_count",
                                    "in2_control_exp_record_count",
                                    "errorCode"))*/
  
 dfOuterJoinReformatFinal =  dfOuterJoinReformat.withColumn("reject_header_src_name",
                                                               firstNotNull($"in0_valid_reject_header_src_name",
                                                                            $"in1_invalid_reject_header_src_name",
                                                                            $"in2_control_reject_header_src_name"))
                                                   .withColumn("reject_header_src_type",
                                                               firstNotNullType($"in0_valid_reject_header_src_name",
                                                                            $"in1_invalid_reject_header_src_name",
                                                                            $"in2_control_reject_header_src_name",
                                                                            $"in0_valid_reject_header_src_type",
                                                                            $"in1_invalid_reject_header_src_type",
                                                                            $"in2_control_reject_header_src_type"))
                                                  .withColumn("reject_header_src_key",lit(""))
                                                  .withColumn("reject_header_err_desc",
                                                     when($"errorCode"===210,lit("ERROR: Control File Not Find"))
                                                    .when($"errorCode"===211,
                                                          concat(lit("Invalid source record count - Expected record read count("),
                                                                      lit(rejectDelimiter),
                                                                      dfOuterJoinReformat("controlRecordCount"),
                                                                      lit(") Valid record read count(" ),
                                                                      lit(rejectDelimiter),
                                                                      dfOuterJoinReformat("validRecordCount"),
                                                                      lit(") Invalid record read count(" ),
                                                                      dfOuterJoinReformat("invalidRecordCount"),
                                                                      lit(")"))) 
                                                      .otherwise(""))
                                                      .withColumn("reject_header_prty_cd",
                                                                 when(($"errorCode"===210) || ($"errorCode"===211),lit(2))
                                                                  .otherwise(0))
  
  dfOuterJoinReformatFinal=dfOuterJoinReformatFinal.select($"reject_header_src_name",
                                                           $"reject_header_src_type",
                                                           $"reject_header_src_key",
                                                           $"reject_header_err_desc",
                                                           $"reject_header_prty_cd")
  
 dfOuterJoinReformatFinal = dfOuterJoinReformatFinal.filter(($"reject_header_prty_cd" === 1) || ($"reject_header_prty_cd" === 2))
  
  
  
//Write Lookup Output File


  
  
 
//display(dfOuterJoinReformatFinal)
var adlsOutInvalidLayoutRejectFileName= adlsGraphName +"_src_cnt_mismatch_"

writeInd = writeToADLS(dfOuterJoinReformatFinal,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutInvalidLayoutRejectFileName+"_"+adlsInputbatchid,
                           "csv",
                           "lkp",
                           rejectDelimiter,
                           "overwrite")  
  



}

//display(dfFinalMultiOutputs)                                             
                                                    


// COMMAND ----------

// DBTITLE 1,Verify Record Count (Graph 2) - Lookup Source File Flagged for Rejection


var dfFilterSuccessFileLookUp=spark.emptyDataFrame
var dfFilterRejectFileLookUp=spark.emptyDataFrame

if ((cntrlFileVerifyInd == "Y") && (cntrlFileRejInd == "Y") )
{

var in0Valid = aliasAllColumnsPrefix(dfOutValidLayoutSuccessFile, "in0_valid_")
var in1lookup = aliasAllColumnsPrefix(dfOuterJoinReformatFinal, "in1_lookup_")

  
 // display(in0Valid)

var dfLookupResult= in0Valid.join(in1lookup,
                                  in0Valid("in0_valid_reject_header_src_name")===in1lookup("in1_lookup_reject_header_src_name"),
                                  "leftouter")


var dfLookupResultSelected=   dfLookupResult.withColumn("reject_header_prty_cd",
                                                      when(!($"in1_lookup_reject_header_prty_cd".isNull),$"in1_lookup_reject_header_prty_cd")
                                                      .otherwise(0))
                                            .withColumn("reject_header_err_desc",
                                                       when(($"reject_header_prty_cd" === 1) || 
                                                            ($"reject_header_prty_cd" === 2),$"in1_lookup_reject_header_err_desc")
                                                       .otherwise(lit("")))
                                            .select($"in0_valid_reject_header_src_name".as("reject_header_src_name"),
                                                    $"in0_valid_reject_header_src_type".as("reject_header_src_type"),
                                                    $"in0_valid_reject_header_src_key".as("reject_header_src_key"),
                                                    $"reject_header_err_desc",
                                                    $"reject_header_prty_cd",
                                                    $"in0_valid_read_data".as("read_data"))
                                          
                                                       
//    display(dfLookupResult)                                               
                                                         

//rever the condition for testing
condition=(($"reject_header_prty_cd" =!= 1) && ($"reject_header_prty_cd" =!= 2) )
//condition=(($"reject_header_prty_cd" =!= 1) && ($"reject_header_prty_cd" =!= 2) )
var (dfFilterSuccessFileLookUpTemp,dfFilterRejectFileLookUpTemp) = conditionalSplit(dfLookupResultSelected,condition)

dfFilterSuccessFileLookUp = dfFilterSuccessFileLookUpTemp
dfFilterRejectFileLookUp =  dfFilterRejectFileLookUpTemp

  //display(dfFilterRejectFileLookUp)


//Write Lookup Output File

adlsOutInvalidLayoutRejectFileName= "stdrej_"+adlsGraphName +"_src_cnt_mismatch_"


writeInd = writeToADLS(dfFilterRejectFileLookUp,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutInvalidLayoutRejectFileName+"_"+adlsInputbatchid,
                           "csv",
                           "lkp",
                           rejectDelimiter,
                           "overwrite")

}else
dfFilterSuccessFileLookUp=dfOutValidLayoutSuccessFile
//display(dfFilterSuccessFileLookUp)

// COMMAND ----------

// DBTITLE 1,Read Input Files (Graph 4)
//Null check for each column


//Reformat -Prepare for Data Read

var dfInputReadData=spark.emptyDataFrame

var schemaReadDataTemp= schemaString.split(",").map(c => c.split("\\|+") match { case Array(a, b, c, d,e,f) => (a, b, c, d,e,f) })

var reqschemaList1=schemaReadDataTemp.map(c => (c._1)).toList
val reqschemaList2String = "dap_gen_mi_last_update_dttm"+","+reqschemaList1(0)
val reqschemaList2 = reqschemaList2String.split(",").toList


 val interSplitDf = columnSplitAlias(reqschemaList1,dfFilterSuccessFileLookUp,"\\^\\|",lengthMultiFileScehma,"read_data")
//  val interSplitDf = columnSplitAlias(reqschemaList1,dfFilterSuccessFileLookUp,targetDelimiter,lengthMultiFileScehma,"read_data")
  var finalSplitDf = columnSplitAlias(reqschemaList2,interSplitDf,rejectDelimiter,2,reqschemaList1(0))



//display(finalSplitDf)


  
//Refromat Generate Reject Header Key
finalSplitDf =finalSplitDf.na.fill("", colNamesRejHdrSrcKey)
                          .withColumn("reject_header_src_key",
                                      concat_ws(colNamesRejHdrSrcKeyDelimiter,colNamesRejHdrSrcKey.map(col):_*))


  //display(finalSplitDf)

if(rejHeaderInd != "Y")
{
finalSplitDf = finalSplitDf.withColumn("reject_header_src_name",lit(""))
                                         .withColumn("reject_header_src_type",lit(""))
                                         .withColumn("reject_header_src_key",lit(""))
                                         .withColumn("reject_header_err_desc",lit(""))
                                         .withColumn("reject_header_prty_cd",lit(""))
 // display(finalSplitDf)
  
}

//display (interSplitDf)



// COMMAND ----------

// DBTITLE 1,Cleansing of Input (Graph5) - Filter and Remove Duplicates


var dfCleanSelected = selectRequiredColoumns(finalSplitDf,cleanseKeySelectColoumns)
var duplicateRemoved=spark.emptyDataFrame
var duplicateRecords=spark.emptyDataFrame


if (dfCleanDuplicate == "Y"){
  var (duplicateRemovedTemp,duplicateRecordsTemp) = duplicatesAndNonduplicate(dfCleanSelected,
                                                                              columnToRemoveDuplicates,
                                                                              orderByFinalKeys)
  duplicateRemoved = duplicateRemovedTemp
  duplicateRecords = duplicateRecordsTemp  
  
  duplicateRecords = duplicateRecords.withColumn("reject_header_err_desc",lit("WARNING: Duplicate record (not within end-of-day snapshot)"))
                                     .withColumn("reject_header_prty_cd",lit("3"))
  
//Write Duplicate Reject Records 

var adlsOutInvalidLayoutRejectFileName= "stdrej_"+adlsGraphName +"_dup_"

writeInd = writeToADLS(duplicateRecords,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutInvalidLayoutRejectFileName+"_"+adlsInputbatchid,
                           "csv",
                           "rej",
                           rejectDelimiter,
                           "overwrite")  
  
}else duplicateRemoved=dfCleanSelected
//display((duplicateRecords.union(duplicateRemoved)).sort(col("reject_header_src_key")))
//display(duplicateRecords)

// COMMAND ----------

// DBTITLE 1,Output Maximum Source File Date (Graph 6)

var validDateChek = duplicateRemoved.withColumn("valid_dap_gen_mi_last_update_dttm",
                                                $"dap_gen_mi_last_update_dttm".cast("timestamp"))
                                    .withColumn("valid_dap_gen_mi_last_update_dttm",
                                                when(!$"valid_dap_gen_mi_last_update_dttm".isNull,
                                                     lit(col("valid_dap_gen_mi_last_update_dttm")))
                                               .otherwise(""))

var maxOuDate= validDateChek.select(max($"valid_dap_gen_mi_last_update_dttm"))

//file:${pTGT_PROC_MAX_DTTM_FILE}

var adlsOutMaxDate= "dap_idl_loyalty_ec_DLEXT001_max_src_file_dttm"

writeInd =  writeToADLS(maxOuDate,
                        adlsInputContainerName,
                        adlsInputFilePath,
                        adlsOutMaxDate+"_"+adlsInputbatchid,
                        "csv",
                        "dat",
                        rejectDelimiter,
                        "overwrite")


//display(maxOuDate)

// COMMAND ----------

// DBTITLE 1,Data Validations (Graph 7)
/*

var schemaString = ("member_question_option_id|StringType|notnull|40|notblank|nospecialchar",
"loyalty_member_id|StringType|notnull|40|notblank|nospecialchar",
"question_details_id|StringType|notnull|40|notblank|nospecialchar",
"option_details_id|StringType|notnull|40|notblank|nospecialchar",
"status|DecimalType|notnull|1|notblank|nospecialchar",
"device_id|StringType|notnull|60|notblank|nospecialchar",
"create_user|StringType|notnull|50|notblank|specialcharAllow",
"update_user|StringType|nullable|50|blank|specialcharAllow",
"created_dttm|TimestampType|notnull|0|notblank|specialcharAllow",
"updated_dttm|TimestampType|notnull|0|notblank|specialcharAllow",
"question_category|StringType|nullable|50|notblank|specialcharAllow")*/

val res = schemaString.split(",").toList

var schema = res.map(x=>x.split("\\|+") match { case Array(a, b, c, d,e,f) => (a, b, c, d,e,f) })

 
  


//Null check for each column
schema.map(c => (c._1,c._3) ).foreach(r => (duplicateRemoved=duplicateRemoved
                                            .withColumn( (r._1)+"_Valid_NonNull",isNullUDF(col(r._1),lit(r._2)))))



//Length check for each column
schema.map(c => (c._1,c._4) ).foreach(r => (duplicateRemoved=duplicateRemoved
                                            .withColumn( (r._1)+"_Valid_length",lengthCheckUDF(col(r._1),lit(r._2)))))


//Blank  check for each column

schema.map(c => (c._1,c._5) ).foreach(r => (duplicateRemoved=duplicateRemoved
                                            .withColumn( (r._1)+"_Valid_NonBlank",
                                            blankCheckUDF(col(r._1),lit(r._2)))))

//Specialcharacter  check for each column

schema.map(c => (c._1,c._2,c._6)).foreach(r => (duplicateRemoved=duplicateRemoved
                                            .withColumn( (r._1)+"_Valid_NonSpecialChar",
                                            specialCharacterCheckUDF(col(r._1),lit(r._2),lit(r._3)))))
  
  
//Datatype Validation for each value
 schema.map(c => (c._1,c._2)).foreach(r => (duplicateRemoved=duplicateRemoved
                                            .withColumn( (r._1)+"_Valid_DataType",
                                            dataTypeCheckUDF(col(r._1),lit(r._2)))))
  
//display (duplicateRemoved)
//display(duplicateRemoved.select("update_user_Valid_NonBlank","updated_dttm_Valid_length","status_Valid_NonSpecialChar"))

// COMMAND ----------



schema.map(c => (c._1) ).foreach(r => (duplicateRemoved=duplicateRemoved
                                            .withColumn( "Valid_"+ (r),
                                                        when((col((r)+"_Valid_NonBlank") === true) &&
                                                            (col((r)+"_Valid_length") === true) &&
                                                            (col((r)+"_Valid_NonNull") === true) &&
                                                            (col((r)+"_Valid_NonSpecialChar") === true)    
                                                             
                                                            ,concat(lit(r),lit("["),col(r),lit("]")) )
                                                            .otherwise(lit("invalid")) )))

//display(duplicateRemoved)


duplicateRemoved = duplicateRemoved.withColumn("v_error_desc",concat(schema.map(c => "Valid_"+(c._1)).map(col):_*))
                                   .withColumn("v_warn_desc",lit(""))  
                                   .withColumn("reject_header_prty_cd",
                                               when($"v_warn_desc" =!= "",lit(3)) 
                                               .when((col("v_error_desc")).contains("invalid"),lit(2))
                                               .otherwise(0) )
                                    .withColumn("reject_header_err_desc",
                                                when($"v_warn_desc" =!= "",concat(lit("Warning:  Substituting values -"),$"v_warn_desc"))
                                               .when((col("v_error_desc")).contains("invalid"),
                                                      concat(lit("ERROR: Invalid values found in input -"),$"v_error_desc"))
                                               .otherwise(lit("")) )


var dfValidRequriredColumns= duplicateRemoved.select(col("reject_header_src_name")+:
                                                     col("reject_header_src_type")+:
                                                     col("reject_header_src_key")+:
                                                     col("reject_header_err_desc")+:
                                                     col("reject_header_prty_cd")+:
//                                                     col("v_error_desc")+:
                                                    
                                                     schema.map(c => (c._1)).map(col):_*)

//var dfValidRequriredColumns= duplicateRemoved.select(schema.map(c => (c._1,c._1+"Valid")).map(col):_*)

//display(dfValidRequriredColumns)

// COMMAND ----------

//"${pVALIDATE_DATA_IND}" != "Y"

//Filter based on valid check indicator



//pVALIDATE_DATA_IND
//var validCheckIndicator= "Y"
var dfValidFilteredReject=spark.emptyDataFrame
var dfValidFilteredSuccess=spark.emptyDataFrame

if(validCheckIndicator=="Y")
{
 dfValidFilteredSuccess =  dfValidRequriredColumns.filter($"reject_header_prty_cd" === 0|| $"reject_header_prty_cd" === 1)
  dfValidFilteredReject =  dfValidRequriredColumns.filter($"reject_header_prty_cd" === 1|| 
                                                          $"reject_header_prty_cd" === 2 || 
                                                          $"reject_header_prty_cd" === 3 )
  
//Write invalid Reject Records 

var adlsOutInvalidDataRecords= "stdrej_"+adlsGraphName +"_val_"

writeInd = writeToADLS(dfValidFilteredReject,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutInvalidDataRecords+"_"+adlsInputbatchid,
                           "csv",
                           "rej",
                           rejectDelimiter,
                           "overwrite")
  
  
  
}else
dfValidFilteredSuccess=dfValidRequriredColumns
//pTGT_FILE
var adlsOutFinalFileName= adlsGraphName+"_extr"


writeInd = writeToADLS(dfValidFilteredSuccess,
                           adlsInputContainerName,
                           adlsInputFilePath,
                           adlsOutFinalFileName+"_"+adlsInputbatchid,
                           "csv",
                           "dat",
                           rejectDelimiter,
                           "overwrite")

//display(dfValidFilteredReject)


// COMMAND ----------

display(dfValidFilteredSuccess)


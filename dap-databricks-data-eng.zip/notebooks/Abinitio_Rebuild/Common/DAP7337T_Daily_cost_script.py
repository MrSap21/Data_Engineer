# Databricks notebook source
import os,json

# Mounting ADLS
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters
#os.environ['scriptPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_SCRIPT_PATH") 
#os.environ['scriptName'] = dbutils.widgets.get("PAR_NB_SCRIPT_NAME")

#Domain=dbutils.widgets.get("PAR_NB_SCRIPT_PATH").split("/")[1]

#Defining Default Variables 
os.environ['mountPoint']=mountPoint
AI_LOAD=AI_PERSIST_SERIAL = mountPoint + "/" + "retail/retail_sales/staging"
#AI_LOAD = mountPoint + "/" + Domain + "retail/retail_sales/staging"

#os.environ['AI_PERSIST_SERIAL']= "/dbfs" + AI_PERSIST_SERIAL
#os.environ['AI_SERIAL_LOG']="/dbfs" + mountPoint+ "/" + "retail/retail_sales/log"
#os.environ['AI_ARCHIVE_SERIAL']="/dbfs" + mountPoint+ "/" +"retail/retail_sales/archive"
#os.environ['AI_LOAD']="/dbfs" + AI_LOAD

#print(os.environ['AI_PERSIST_SERIAL'])

# COMMAND ----------


df = spark.read.text(AI_PERSIST_SERIAL +"/" + "run_date_file")
RUN_DATE = df.collect()[0][0]

from datetime import datetime,timedelta

NDATE = datetime.strptime(RUN_DATE,'%Y%m%d').date() + timedelta(1)
NEXT_DATE=str(NDATE).replace('-','')
RDATE2 = datetime.strptime(RUN_DATE,'%Y%m%d').date() - timedelta(2)
RUN_DATE_2=str(RDATE2).replace('-','')
RDATE3 = datetime.strptime(RUN_DATE,'%Y%m%d').date() - timedelta(3)
RUN_DATE_3=str(RDATE3).replace('-','')

#df1 = spark.read.text(AI_PERSIST_SERIAL +"/" + "pos_old_date")
#POS_OLD_DATE = df1.rdd.map(lambda x:x[0]).collect()


# COMMAND ----------

#%sh -e $scriptPath/$scriptName


# COMMAND ----------

dbutils.notebook.exit([RUN_DATE,RUN_DATE_2,RUN_DATE_3])

# COMMAND ----------


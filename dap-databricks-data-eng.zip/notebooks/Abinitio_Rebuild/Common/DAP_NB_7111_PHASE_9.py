# Databricks notebook source
#dbutils.widgets.text("PAR_NB_DECODEWVALUELOOKUP", "decode_w_value_lookup")
#dbutils.widgets.text("PAR_NB_POSEMPLOYEERFN", "pos_next_gen_rfn/20220119045142")
#dbutils.widgets.text("PAR_NB_DECODELOOKUP", "pos_decode_lookup")
#dbutils.widgets.text("PAR_NB_CYCLEDATELOOKUP", "cycle_date_lookup")
#dbutils.widgets.text("PAR_NB_POSTVOIDTXNLOOKUP", "Int_DF6_DF11_post_void_txn_lookup")
#dbutils.widgets.text("PAR_NB_DIMLOCATIONLOOKUP1", "dim_location_ej_str_lookup_ascii")
#dbutils.widgets.text("PAR_NB_LYLTYEDWIDLNGENPOS", "lyty_edw_idl_ngenpos_xref_rfn_training_ind_file/20220119045142")
#dbutils.widgets.text("PAR_NB_POSEJLINK", "lyty_edw_idl_ngenpos_store_file/20220119045142")
#dbutils.widgets.text("PAR_NB_POSTXNINSERTASCII", "pos_txn_insert_ascii.pipe_delim")
#dbutils.widgets.text("PAR_NB_POSTXNXREFINSERTASCII", "pos_txn_xref_insert_ascii.pipe_delim")
#dbutils.widgets.text("PAR_NB_MAXSYSTEMSURROGATEKEY", "max_system_surrogate_key_interm")
#dbutils.widgets.text("PAR_NB_POSINTRM", "pos_interm")
#dbutils.widgets.text("PAR_NB_POSTVOIDEDTXNLOOKUPFILE", "Int_DF6_DF10_DF11_post_voided_txn_lookup")


# COMMAND ----------


from pyspark.sql.functions import * 
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

posIntrm = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSINTRM")
postvoidedtxnlkpfile = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSTVOIDEDTXNLOOKUPFILE")
postvoidtxnlkpfile = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSTVOIDTXNLOOKUP")
decodeWValueLookup = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DECODEWVALUELOOKUP")
posEmployeeRFN = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEMPLOYEERFN")
decodeLookup = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DECODELOOKUP")
cycleDateLookup = mountPoint + "/" + dbutils.widgets.get("PAR_NB_CYCLEDATELOOKUP")
dim_location_lookup_1 = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DIMLOCATIONLOOKUP1")
lyltyEdwIdlNgenpos = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LYLTYEDWIDLNGENPOS")
posEjLink = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJLINK")
posTxnInsertAscii = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSTXNINSERTASCII")
posTxnXrefInsertAscii = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSTXNXREFINSERTASCII")
maxSystemSurrogateKeyInterm = mountPoint + "/" + dbutils.widgets.get("PAR_NB_MAXSYSTEMSURROGATEKEY")
posIntrmDF = spark.read.format('parquet').load(posIntrm).filter(col('txn_type')  != '99')
postvoidedtxnlkpfileDF = spark.read.format('parquet').load(postvoidedtxnlkpfile)
postvoidtxnlkpfileDF = spark.read.format('parquet').load(postvoidtxnlkpfile)
decodeWValueLookupDF = spark.read.format('parquet').load(decodeWValueLookup)
posEmployeeRFNDF = spark.read.format('parquet').load(posEmployeeRFN)
decodeLookupDF = spark.read.format('parquet').load(decodeLookup)
dim_location_lookup_1DF = spark.read.format('parquet').load(dim_location_lookup_1)
cycleDateLookupDF = spark.read.format('parquet').load(cycleDateLookup).filter(col('dummy_key') == 'A')
lyltyEdwIdlNgenposDF = spark.read.format('parquet').load(lyltyEdwIdlNgenpos)
posEjLinkDF = spark.read.format('parquet').load(posEjLink)     

wspecemp = Window.partitionBy('ej_rfn_value').orderBy(col('employee_id'))
posEmployeeRFNDF = posEmployeeRFNDF.withColumn('ej_rfn_value',trim(col('ej_rfn_value')))\
.withColumn('employee_id',col('employee_id').cast(IntegerType()))\
.withColumn('rn',row_number().over(wspecemp))\
.where(col('rn')==1)\
.drop('rn')

# COMMAND ----------

derive_cols = posIntrmDF.withColumn('is_bottle_deposit', when(
              (col('rcd_type') == 'A') &
              (
                ((col('rec_type_a_upc_tndr') >= 30) & (col('rec_type_a_upc_tndr') <= 33)) |
                ((col('rec_type_a_upc_tndr') >= 7000) & (col('rec_type_a_upc_tndr') <= 8999))
              ) &
              (
                (upper(col('rec_type_a_desc_acct_nbr').substr(1, 14)) == 'BOTTLE DEPOSIT') | 
                (upper(col('rec_type_a_desc_acct_nbr').substr(1, 13)).isin('BOTTLE REFUND', 'CAL-REDMP-VAL')) | 
                (upper(col('rec_type_a_desc_acct_nbr').substr(1, 12)).isin('CA REDMP VAL', 'SODA DEPOSIT')) |
                (upper(col('rec_type_a_desc_acct_nbr').substr(1, 11)).isin('SODA REFUND', 'SODA RETURN', 'SOFT DRINKS')) 
              ), lit(True)).otherwise(lit(False))) \
              .withColumn('is_mfg_coupon', when(
                (col('rcd_type') == 'A') &
                ((col('rec_type_a_special') == "O") |
                ((col('rec_type_a_special') == "F") & 
                (upper(ltrim(col('rec_type_a_desc_acct_nbr')).substr(1, 8)) == "MFG COUP"))
              ), lit(True)).otherwise(lit(False))) \
              .withColumn('is_merch_item', when(
                (col('rcd_type') == 'A') &
                ((col('rec_type_a_upc_tndr').substr(1, 8) == "BIRTHDAY") |
                (col('rec_type_a_tax_exempt_ind') != "N") |
                (col('rec_type_a_tax_exempt_id').isNotNull()) |
                (col('rec_type_a_ecomm_order_ind') != "N") |
                (col('rec_type_a_ecomm_order_nbr').isNotNull())
              ), lit(0)).otherwise(lit(1))) \
              .withColumn('rec_in_txn_cntr', col('rec_in_txn_cntr').cast(IntegerType())) \
              .withColumn('txn_dt', to_date(col('txn_date'), 'yyyyMMdd')).drop('txn_date')

# find out if the transaction was voided
postvoidedtxnlkpfileDF = postvoidedtxnlkpfileDF.distinct() # As of now this contains duplicates for 3 txn_id's
void_trns_join =  derive_cols.join(postvoidedtxnlkpfileDF, derive_cols.txn_cntr == postvoidedtxnlkpfileDF.orig_txn_id , how = "left").select(derive_cols["*"], postvoidedtxnlkpfileDF['orig_txn_id'].alias('orig_txn_id'), postvoidedtxnlkpfileDF['xref_group_nbr'].alias('xref_group_nbr'))
void_trns_join =  void_trns_join.withColumn('is_post_voided', when(col('orig_txn_id').isNotNull(), lit(True)).otherwise(lit(False))).drop(col('orig_txn_id'))                                                                                             
classify_trns = void_trns_join.withColumn('is_normal_item', when(
                (col('rcd_type') == 'A') &
                (col('is_merch_item') == 1) &
                (col('rec_type_a_prc_verify') != "Y") &
                (col('is_mfg_coupon') == False) &
                (col('is_bottle_deposit') == False)
             , lit(True)).otherwise(lit(False))) \
             .withColumn('is_normal_txn_type', when(
                (col('is_post_voided') == False) &
                (col('training_ind') != 'Y') &
                (col('txn_type').isin(10, 11, 12, 13, 16))
             , lit(True)).otherwise(lit(False))) \
             .withColumn('is_discnt_txn_type', when(
                (col('is_post_voided') == False) &
                (col('training_ind') != 'Y') &
                (col('txn_type').isin(11, 12, 13))
             , lit(True)).otherwise(lit(False))) \
             .withColumn('is_return_txn_type', when(
                (col('is_post_voided') == False) &
                (col('txn_type').isin(14, 15))
             , lit(True)).otherwise(lit(False)))


classify_normal_item = classify_trns.withColumn('is_reg_sale', when(
                (col('is_normal_txn_type') == True) &
                (col('is_normal_item') == True) &
                (~(col('rec_type_a_retrnd_item').eqNullSafe("R"))) &
                (col('rec_type_a_emp_disc').eqNullSafe(" "))
             , lit(1)).otherwise(lit(0))) \
              .withColumn('is_reg_return', when(
                (col('is_return_txn_type') == True) &
                (col('is_normal_item') == True) &
                (col('rec_type_a_retrnd_item').eqNullSafe("R")) 
             , lit(1)).otherwise(lit(0))) \
              .withColumn('is_discnt_sale', when(
                (col('is_discnt_txn_type') == True) &
                (col('is_normal_item') == True) &
                (~(col('rec_type_a_retrnd_item').eqNullSafe("R"))) &
                (~(col('rec_type_a_emp_disc').eqNullSafe(" ")))
             , lit(1)).otherwise(lit(0)))



# COMMAND ----------

# # GDE had the data sorted on txn_cntr (major), rec_in_txn_cntr (minor) descending
from pyspark.sql.window import Window
classify_pver = classify_normal_item.withColumn('tmp_pver_seq_nbr', when((col('rcd_type') == 'A') & (col('rec_type_a_prc_verify') == "Y") , col('seq_nbr_by_rec_type')).otherwise(lit(None)))\
.withColumn('tmp_non_pver_seq_nbr', when((col('rcd_type') == 'A') & (col('rec_type_a_prc_verify') != "Y") , col('seq_nbr_by_rec_type')).otherwise(lit(None)))\
.withColumn('rfn_nbr', when((~col('rec_type_M').eqNullSafe(None)) & (col('rec_type_m_rfn_nbr') != ''), col('rec_type_m_rfn_nbr'))
                 .when((~col('rec_type_M').eqNullSafe(None)) & (col('rec_type_m_rfn_nbr') == ''), lit(" "))
                 .when((col('txn_type') == '11') & (col('rec_type_11_rfn_nbr') != ''), col('rec_type_11_rfn_nbr'))
                 .when((col('txn_type')== '12') & (col('rec_type_12_rfn_nbr') != ''), col('rec_type_12_rfn_nbr')))\
 .withColumn('discnt_mode', when(col('txn_type') == '11', col('rec_type_11_disc_mode'))\
                 .when(col('txn_type')== '12', col('rec_type_12_disc_mode')))

# COMMAND ----------

calculate_metrics = classify_pver.groupBy('txn_cntr', 'txn_dt', 'loc_id', 'txn_nbr', 'register_nbr', 'cashier_nbr', 'txn_type', 'offline_txn_ind', 'training_ind',  'is_post_voided', 'post_void_status', 'xref_group_nbr', 'str_nbr').agg(
  round(sum(
    when((col('rec_type_a').isNotNull()) & (col('is_mfg_coupon') == True),
      concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_mfg_coup_dlrs')
,
  round(sum(
    when((col('rec_type_a').isNotNull()) & (col('rec_type_a_wag_cpn') == "C") | (col('rec_type_a_wag_cpn') == "D"),
      concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(0)), 2
  ).alias('txn_tot_wag_coup_dlrs')
,
  round(sum(
    when((col('rec_type_a').isNotNull()) & (col('rec_type_a_retrnd_item') == "R"),
      concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_return_dlrs')
,
  round(sum(
    when((col('rec_type_a').isNotNull()) & (col('rec_type_a_item_void') == "V"),
      concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_void_dlrs')
,
  sum(
    when(col('rec_type_a').isNotNull(), col('rec_type_a_qty')
    ).otherwise(lit(0))
  ).alias('txn_tot_net_qty')
,
  sum(
    when(col('rec_type_a').isNotNull(), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_line_cnt')
,
  sum(
    when((col('rec_type_a').isNotNull()) & (col('rec_type_a_retrnd_item') == "R"), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_return_line_cnt')
,
  sum(
    when((col('rec_type_a').isNotNull()) & (col('rec_type_a_prc_verify') == "Y"), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_price_vrfy_line_cnt')
,  
  sum(
    when((col('rec_type_a').isNotNull()) & ((col('rec_type_a_RX_ind') == "W") | (col('rec_type_a_RX_ind') == "P") | (col('rec_type_a_RX_ind') == "A")), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_rx_line_cnt')
, 
  sum(
    when((col('rec_type_c').isNotNull()) & ((col('rec_type_a_voided_ind') == "F") | (col('rec_type_a_voided_ind') == "P")), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_line_voided_cnt')
, 
  sum(
    when((col('rec_type_c').isNotNull()) & (col('rec_type_a_item_void') == "V"), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_line_voids_cnt')
, 
  round(sum(
    when(col('is_reg_sale') == 1, concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_reg_sale_dlrs')
, 
  sum(
    when(col('is_reg_sale') == 1, lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_reg_line_cnt')
, 
  sum(
    when(col('is_reg_sale') == 1, col('rec_type_a_qty')
    ).otherwise(lit(0))
  ).alias('txn_tot_reg_line_qty')
,  
  round(sum(
    when(col('is_reg_return') == 1, concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_reg_return_dlrs')
, 
  round(sum(
    when(col('is_discnt_sale') == 1, concat(col('rec_type_a_price_sign'), ltrim(col('rec_type_a_selling_price'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_discnt_sale_dlrs')
, 
  sum(
    when((col('is_discnt_sale') == 1), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_discnt_line_cnt')
, 
  sum(
    when((col('is_discnt_sale') == 1), col('rec_type_a_qty')
    ).otherwise(lit(0))
  ).alias('txn_tot_discnt_line_qty')
, 
lit(0).alias( 'txn_tot_discnt_return_dlrs')
,
  round(sum(
    when((col('rec_type_b').isNotNull()) & (col('is_post_voided') == False)
      ,concat(col('rec_type_b_price_sign'), ltrim(col('rec_type_b_tax_amt'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias( 'txn_tot_tax_dlrs')
,
  round(sum(
    when((col('rec_type_c').isNotNull()) & ((trim(col('rec_type_C_p1_tndr_desc')) == "CHECK") | (trim(col('rec_type_C_p1_tndr_desc')) == "ACH")
),
      concat(col('rec_type_C_check_prc_sign'), ltrim(col('rec_type_C_check_selling_prc'))).cast("double"))
    .when(col('rec_type_c').isNotNull(),
      concat(col('rec_type_C_not_check_prc_sign'), ltrim(col('rec_type_C_not_check_selling_prc'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('txn_tot_tndr_dlrs')
,
  sum(
    when(col('rec_type_c').isNotNull(), lit(1)
    ).otherwise(lit(0))
  ).alias('txn_tot_tndr_cnt')
,
  round(sum(
    when(col('rec_type_d').isNotNull(),
      concat(col('rec_type_D_price_sign'), ltrim(col('rec_type_D_sell_prc'))).cast("double")
    ).otherwise(lit(0))), 2
  ).alias('tot_dlrs')
,
  min(col('tmp_pver_seq_nbr').cast(IntegerType())
  ).alias('min_pver_seq_nbr')
,
  max(col('tmp_pver_seq_nbr').cast(IntegerType())
  ).alias('max_pver_seq_nbr')
,
  min(col('tmp_non_pver_seq_nbr').cast(IntegerType())
  ).alias('min_non_pver_seq_nbr')
,
  max(col('tmp_non_pver_seq_nbr').cast(IntegerType())
  ).alias('max_non_pver_seq_nbr')
,
  max(col('rfn_nbr')
  ).alias('rfn_nbr') 
,
  max(col('exchange_cd')
  ).alias('exchange_cd')  
,
  max(col('discnt_mode')
  ).alias('discnt_mode')
,
  min(col('txn_start_dttm')
  ).alias('txn_start_dttm')
,
  max(col('txn_end_dttm')
  ).alias('txn_end_dttm')  
).drop('tmp_pver_seq_nbr', 'tmp_non_pver_seq_nbr')

# COMMAND ----------

calculate_derived_columns = calculate_metrics.withColumn(
  'post_void_status',
  when(col('is_post_voided') == True, 'V').otherwise(col('post_void_status'))
) .withColumn(
  'pver_status',
  when(
    (col('txn_tot_price_vrfy_line_cnt') > 0) & (
      col('max_pver_seq_nbr') < col('min_non_pver_seq_nbr')
    ),
    'L'
  ).when(
    (col('txn_tot_price_vrfy_line_cnt') > 0) & (
      col('min_pver_seq_nbr') > col('max_non_pver_seq_nbr')
    ) & (col('max_non_pver_seq_nbr') > 0),
    'T'
  ).when(
    (col('txn_tot_price_vrfy_line_cnt') > 0) & (
      col('txn_tot_price_vrfy_line_cnt') == col('txn_tot_line_cnt')
    ),
   'S'
  ).when(col('txn_tot_price_vrfy_line_cnt') > 0, 'E').otherwise('--') 
).withColumn('txn_incomplete_ind', when((col('txn_type').isin(10, 11, 12, 13, 14, 15, 16)) & 
                                        ((col('txn_tot_tndr_dlrs').isNull()) | (col('txn_tot_tndr_dlrs') == 0)) & 
                                        ((col('txn_tot_void_dlrs').isNotNull()) & (col('txn_tot_void_dlrs') != 0)), 'Y').otherwise(lit('N'))
).withColumnRenamed(
  'txn_cntr', 'txn_id'
).drop('max_non_pver_seq_nbr', 'max_pver_seq_nbr', 'min_non_pver_seq_nbr', 'min_pver_seq_nbr')

postvoidtxnlkpfileDF = postvoidtxnlkpfileDF.distinct()

final_join = calculate_derived_columns.join(postvoidtxnlkpfileDF, calculate_derived_columns.txn_id == postvoidtxnlkpfileDF.pv_txn_id , how = "left").select(calculate_derived_columns['*'], postvoidtxnlkpfileDF['orig_total_sell_prc'].alias('orig_total_sell_prc'))

final_join = final_join.withColumn('txn_tot_dlrs', when((ltrim(col('post_void_status')) == 'S') &
                                  (col('orig_total_sell_prc').isNotNull()), col('orig_total_sell_prc') * -1).otherwise(col('tot_dlrs'))
            ).drop('is_post_voided',  'orig_total_sell_prc', 'tot_dlrs')

# COMMAND ----------

# Scan
# {loc_id; register_nbr; txn_end_dttm}
partitionByLocIdRegisterNbr = Window.partitionBy('loc_id', 'register_nbr').orderBy("txn_end_dttm")
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY") # getting SparkUpgradeException: You may get a different result due to the upgrading of Spark 3.0: Fail to parse '2022-06-01 22:10:10.296' in the new parser.

df_scan = final_join.withColumn('prev_txn_end_dttm', coalesce(lag('txn_end_dttm').over(partitionByLocIdRegisterNbr), to_timestamp(current_timestamp(),"MM-dd-yyyy HH:mm:ss")))\
.withColumn('prev_cashier_nbr', coalesce(lag('cashier_nbr').over(partitionByLocIdRegisterNbr), lit(-1)))\
.withColumn('prev_txn_id', coalesce(lag('txn_id').over(partitionByLocIdRegisterNbr),lit(-1)))\
.withColumn('prev_txn_nbr', coalesce(lag('txn_nbr').over(partitionByLocIdRegisterNbr),lit(-1)))\
.withColumn('prev_txn_type', coalesce(lag('txn_type').over(partitionByLocIdRegisterNbr),lit(-1)))\
.withColumn('prev_pvoid_status', coalesce(lag('post_void_status').over(partitionByLocIdRegisterNbr),lit(-1)))\
.withColumn('prev_line_cnt', coalesce(lag('txn_tot_line_cnt').over(partitionByLocIdRegisterNbr),lit(-1)))\
.withColumn('prev_pver_line_cnt', coalesce(lag('txn_tot_price_vrfy_line_cnt').over(partitionByLocIdRegisterNbr),lit(-1)))\
.withColumn('prev_within_training_block',lit("N"))\
.withColumn('prev_nosale_ind', when(col('prev_txn_type') == 0, True).otherwise(False))\
.withColumn('prev_pvoid_ind', when(col('prev_txn_type') == 38, True).otherwise(False))\
.withColumn('prev_pver_ind', when(((col('prev_line_cnt') == col('prev_pver_line_cnt')) & (col('prev_line_cnt') > 0)), True).otherwise(False))
            
df_scan = df_scan.withColumn('curr_nosale_ind', when(col('txn_type') == 0, True).otherwise(False))\
.withColumn('curr_pvoid_ind', when(col('txn_type') == 38, True).otherwise(False))\
.withColumn('same_cashier', when(col('prev_cashier_nbr') == col('cashier_nbr'), True).otherwise(False))\
.withColumn('min_diff', round((unix_timestamp(col('txn_start_dttm')) - unix_timestamp(col('prev_txn_end_dttm')))/60))\
.withColumn('training_entry', when(col('txn_type')  == 22, lit('Y')).otherwise(lit('N')))\
.withColumn('training_exit', when((col('txn_type') == 43) | (col('txn_type') == 44) | (col('txn_type') == 45), 'Y').otherwise('N'))\
.withColumn('within_training_block', when(((lag('training_entry').over(partitionByLocIdRegisterNbr) == 'Y') & (col('training_entry') == 'N') & (col('training_exit') == 'N')) | ((col('prev_within_training_block') == 'Y') & (col('training_entry') == 'N') & (col('training_exit') == 'N')), lit('Y')).otherwise(lit('N')))\
.withColumn('pvoid_prcd_by_ind', when((col('prev_nosale_ind')) & (col('curr_pvoid_ind'))  & (col('min_diff') <= 5), lit(1) ).otherwise(lit(0)))\
.withColumn('pvoid_flwd_by_ind', when((col('prev_pvoid_ind')) & (col('curr_nosale_ind'))  & (col('min_diff') <= 5), lit(1)).otherwise(lit(0)))\
.withColumn('pver_flwd_by_ind', when((col('prev_pver_ind')) & (col('curr_nosale_ind'))  & (col('same_cashier'))  & (col('min_diff') <= 5), lit(1)).otherwise(lit(0)))

# COMMAND ----------

df_join = df_scan.join(decodeWValueLookupDF, (df_scan.post_void_status == decodeWValueLookupDF.cd_value) & (decodeWValueLookupDF.cd_type == 'POST_VOID') , how = "left").select(df_scan['*'], decodeWValueLookupDF['cd_id'].alias('post_void_status_cd'))

df_join = df_join.join(decodeWValueLookupDF, (df_join.exchange_cd == decodeWValueLookupDF.cd_value) & (decodeWValueLookupDF.cd_type == 'EXCHANGE') , how = "left").select(df_join['*'], decodeWValueLookupDF['cd_id'].alias('t_exchange_cd')).drop('exchange_cd')

df_join = df_join.join(decodeWValueLookupDF, (df_join.discnt_mode == decodeWValueLookupDF.cd_value) & (decodeWValueLookupDF.cd_type == 'TXN_DISCNT_MODE_CD'), how = "left").select(df_join['*'], decodeWValueLookupDF['cd_id'].alias('discnt_mode_cd'))
default_discnt_mode_cd = decodeLookupDF.where((col('cd_type') == 'TXN_DISCNT_MODE_CD') & (col('cd_value') == '--')).select('cd_id').collect()[0]['cd_id']

create_dttm = cycleDateLookupDF.select('cycle_dttm').collect()[0]['cycle_dttm']
posEmployeeRFNDF = posEmployeeRFNDF.distinct() # as of now there are many duplicates in this table

df_join = df_join.join(posEmployeeRFNDF, (df_join.rfn_nbr == posEmployeeRFNDF.ej_rfn_value), how = "left").select(df_join['*'], posEmployeeRFNDF['employee_id'])
                            
df_join = df_join.join(decodeLookupDF, (df_join.pver_status == decodeLookupDF.cd_value) & (decodeLookupDF.cd_type == 'TXN_PRICE_VERIFY') , how = "left").select(df_join['*'], decodeLookupDF['cd_id'].alias('price_verify_cd'))

spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY") # getting SparkUpgradeException: You may get a different result due to the upgrading of Spark 3.0: Fail to parse '2022-06-01 22:10:10.296' in the new parser.

df_join = df_join.withColumn('training_txn_ind', when(col('training_ind') == 'Y', lit('Y'))
                             .when(col('within_training_block') == 'Y', lit('Y')).otherwise(lit('N')))\
.withColumn('create_dttm', lit(create_dttm))\
.withColumnRenamed('rfn_nbr', 'rfn_value')\
.withColumn('create_id', lit('prdpos'))\
.withColumn('pv_txn_id', when(col('pvoid_prcd_by_ind') == 1, col('txn_id')).otherwise(col('prev_txn_id')))\
.withColumn('xref_txn_id', when(col('pvoid_prcd_by_ind') == 1, col('prev_txn_id')).otherwise(col('txn_id')))\
.withColumn('xref_group_nbr', when(col('xref_group_nbr').isNotNull(), col('xref_group_nbr'))
            .when((col('pvoid_flwd_by_ind') == 1) | (col('pver_flwd_by_ind') == 1), col('prev_txn_id')).otherwise(col('txn_id')))\
.withColumn('discnt_mode_cd', when(col('discnt_mode').isNotNull(), col('discnt_mode_cd'))
            .when((col('txn_type') == '11') & ((col('discnt_mode')== '') | (col('discnt_mode').isNull())), lit('260'))
            .when((col('txn_type') == '12') & ((col('discnt_mode')== '') | (col('discnt_mode').isNull())), lit('261'))
            .when(col('txn_type') == '13', lit('262'))
            .when(((col('txn_type') != '11') | (col('txn_type') != '12') | (col('txn_type') != '13')), lit(default_discnt_mode_cd)))\
.withColumnRenamed('pvoid_prcd_by_ind', 'xref_pvoid_prcd_by_ind')\
.withColumnRenamed('pvoid_flwd_by_ind', 'xref_pvoid_flwd_by_ind')\
.withColumnRenamed('pver_flwd_by_ind', 'xref_pver_flwd_by_ind')\
.withColumnRenamed('min_diff', 'xref_min_diff')\
.withColumnRenamed('t_exchange_cd', 'exchange_cd')


# COMMAND ----------

df_rfmt1 = df_join.join(lyltyEdwIdlNgenposDF, (df_join.rfn_value == lyltyEdwIdlNgenposDF.ej_rfn_value), how = "left").select(df_join['*'], lyltyEdwIdlNgenposDF['ej_rfn_value'].alias('lylty_ej_rfn_value'))
df_rfmt1 = df_rfmt1.join(dim_location_lookup_1DF, (trim(df_rfmt1.loc_id) == dim_location_lookup_1DF.loc_id) , how = "left").select(df_rfmt1['*'], lpad(dim_location_lookup_1DF['str_nbr'], 5, '0').alias('loc_lookup_str_nbr')) # The str nbr is inconsistent in this lookup as of now so left padding it with zero if it is less than length of 5 characters

df_rfmt1 = df_rfmt1.join(posEjLinkDF, (df_rfmt1.loc_lookup_str_nbr == posEjLinkDF.str_nbr), how = "left").select(df_rfmt1['*'], posEjLinkDF['str_nbr'].alias('pos_ej_str_nbr'))
df_rfmt1 = df_rfmt1.withColumn('training_txn_ind', when((col('lylty_ej_rfn_value').isNotNull() & (col('pos_ej_str_nbr').isNotNull())), lit('Y'))
                              .when((col('pos_ej_str_nbr').isNotNull()), lit('N')).otherwise('N')).drop('lylty_ej_rfn_value', 'loc_lookup_str_nbr', 'pos_ej_str_nbr')

df_rfmt_out = df_rfmt1.select(col('txn_id').cast('bigint').cast('string').alias('txn_id'),'txn_dt','loc_id','txn_nbr','register_nbr','cashier_nbr','txn_type','txn_start_dttm','txn_end_dttm','txn_tot_dlrs','txn_tot_tndr_dlrs','txn_tot_tndr_cnt','txn_tot_tax_dlrs','txn_tot_mfg_coup_dlrs','txn_tot_wag_coup_dlrs','txn_tot_return_dlrs','txn_tot_void_dlrs','txn_tot_net_qty','txn_tot_line_cnt','txn_tot_return_line_cnt','txn_tot_price_vrfy_line_cnt','txn_tot_rx_line_cnt','txn_tot_line_voided_cnt','txn_tot_line_voids_cnt','post_void_status_cd','exchange_cd','offline_txn_ind','training_txn_ind','txn_tot_reg_sale_dlrs','txn_tot_reg_line_cnt','txn_tot_reg_line_qty','txn_tot_reg_return_dlrs','txn_tot_discnt_sale_dlrs','txn_tot_discnt_line_cnt','txn_tot_discnt_line_qty','txn_tot_discnt_return_dlrs','create_id','create_dttm','txn_incomplete_ind','employee_id', 'rfn_value','price_verify_cd','discnt_mode_cd')

df_rfmt_out.write.format("parquet").mode("overwrite").save(posTxnInsertAscii)
df_rfmt1_rollup = df_rfmt1.select(lit('A').alias('local_key'), max('txn_id').alias('txn_id'))
df_rfmt1_rollup.write.format("parquet").mode("overwrite").save(maxSystemSurrogateKeyInterm)

# COMMAND ----------

pvoid_prcd_by_dropen_cd = decodeLookupDF.where((col('cd_type') == 'XREF_SCENARIO') & (col('cd_value') == 'PVoid Prcd By DrOpen')).select('cd_id').collect()[0]['cd_id']
pvoid_flwd_by_dropen_cd = decodeLookupDF.where((col('cd_type') == 'XREF_SCENARIO') & (col('cd_value') == 'PVoid Flwd By DrOpen')).select('cd_id').collect()[0]['cd_id']
pver_flwd_by_dropen_cd = decodeLookupDF.where((col('cd_type') == 'XREF_SCENARIO') & (col('cd_value') == 'PVer Flwd By DrOpen')).select('cd_id').collect()[0]['cd_id']
pvoid_txn_cd = decodeLookupDF.where((col('cd_type') == 'XREF_SCENARIO_ROLE') & (col('cd_value') == 'PVoid Txn')).select('cd_id').collect()[0]['cd_id']
pver_txn_cd = decodeLookupDF.where((col('cd_type') == 'XREF_SCENARIO_ROLE') & (col('cd_value') == 'PVer Txn')).select('cd_id').collect()[0]['cd_id']
dr_open_txn_cd = decodeLookupDF.where((col('cd_type') == 'XREF_SCENARIO_ROLE') & (col('cd_value') == 'DrOpen Txn')).select('cd_id').collect()[0]['cd_id']
df_xref1 = df_join.where((col('xref_pvoid_prcd_by_ind') == 1) | (col('xref_pvoid_flwd_by_ind') == 1) | (col('xref_pver_flwd_by_ind') == 1))
df_xref_join = df_xref1.join(postvoidtxnlkpfileDF, df_xref1.pv_txn_id == postvoidtxnlkpfileDF.pv_txn_id , how = "left").select(df_xref1["*"], postvoidtxnlkpfileDF['pv_cashier_nbr'].alias('pvoid_txn_cashier_nbr'))            

# COMMAND ----------

# xref.pvoid_prcd_by_ind || xref.pvoid_flwd_by_ind || xref.pver_flwd_by_ind

df_rfmt2 = df_xref_join.withColumn('potnl_rerung_txn_id', lit(None).cast('string'))\
                              .withColumn('xref_txn_nbr', lit(-1))\
                              .withColumn('match_pct', lit(None).cast('string'))\
                              .withColumn('xref_type_cd', when(col('xref_pvoid_prcd_by_ind') == 1, lit(pvoid_prcd_by_dropen_cd)).when(col('xref_pvoid_flwd_by_ind') == 1, lit(pvoid_flwd_by_dropen_cd)).when(col('xref_pver_flwd_by_ind') == 1, lit(pver_flwd_by_dropen_cd)).otherwise(lit(-1)))\
                               .withColumn('orig_txn_cashier_nbr', lit(None).cast('string'))\
                               .withColumn('txn_extend_status_cd', when((col('xref_pvoid_prcd_by_ind') == 1) | (col('xref_pvoid_flwd_by_ind') == 1), lit(pvoid_txn_cd)).when(col('xref_pver_flwd_by_ind') == 1, lit(pver_txn_cd)).otherwise(lit(-1)) )\
                                         .select(col('pv_txn_id').alias('txn_id'), col('txn_dt'), col('pv_txn_id').alias('xref_txn_id'), col('potnl_rerung_txn_id'), col('xref_txn_nbr'),
col('match_pct'), col('loc_id'),col('xref_type_cd'),col('orig_txn_cashier_nbr'), col('pvoid_txn_cashier_nbr'),col('txn_extend_status_cd'), col('xref_group_nbr').alias('group_nbr'))

# COMMAND ----------

# xref.pvoid_prcd_by_ind || xref.pvoid_flwd_by_ind || xref.pver_flwd_by_ind
df_rfmt3 = df_xref_join.withColumn('potnl_rerung_txn_id', lit(None).cast('string'))\
                              .withColumn('xref_txn_nbr', lit(-1))\
                              .withColumn('match_pct', lit(None).cast('string'))\
                              .withColumn('xref_type_cd', when(col('xref_pvoid_prcd_by_ind') == 1, lit(pvoid_prcd_by_dropen_cd)).when(col('xref_pvoid_flwd_by_ind') == 1, lit(pvoid_flwd_by_dropen_cd)).when(col('xref_pver_flwd_by_ind') == 1, lit(pver_flwd_by_dropen_cd)).otherwise(lit(-1)))\
                               .withColumn('orig_txn_cashier_nbr', lit(None).cast('string'))\
                               .withColumn('txn_extend_status_cd', lit(dr_open_txn_cd))\
                                         .select(col('xref_txn_id').alias('txn_id'), col('txn_dt'), col('pv_txn_id').alias('xref_txn_id'), col('potnl_rerung_txn_id'), col('xref_txn_nbr'),
col('match_pct'), col('loc_id'),col('xref_type_cd'), col('orig_txn_cashier_nbr'), col('pvoid_txn_cashier_nbr'),  col('txn_extend_status_cd'),  col('xref_group_nbr').alias('group_nbr'))

# COMMAND ----------

xref = df_rfmt2.unionByName(df_rfmt3)
df_xref_out = xref.select(col('txn_id').cast('bigint').cast('string').alias('txn_id'),col('txn_dt').cast('string').alias('txn_dt'),col('xref_txn_id').cast('bigint').cast('string').alias('xref_txn_id'),col('potnl_rerung_txn_id').cast('string').alias("potnl_rerung_txn_id"),col('xref_txn_nbr').cast('string').alias('xref_txn_nbr'),
col('match_pct').cast('string').alias("match_pct"),col('loc_id').cast('string').alias("loc_id"),col('xref_type_cd').cast('integer').alias('xref_type_cd'),col('txn_extend_status_cd').cast('integer').alias('txn_extend_status_cd'),col('group_nbr').cast('bigint').cast('string').alias('group_nbr'),col('orig_txn_cashier_nbr').cast('string').alias("orig_txn_cashier_nbr"),col('pvoid_txn_cashier_nbr').cast('string').alias("pvoid_txn_cashier_nbr"))

df_xref_out.write.format("parquet").mode("append").save(posTxnXrefInsertAscii)
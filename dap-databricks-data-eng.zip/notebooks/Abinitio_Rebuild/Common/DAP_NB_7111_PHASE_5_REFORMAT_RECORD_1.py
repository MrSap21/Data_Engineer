# Databricks notebook source
# dbutils.widgets.text("PAR_STAGING_FOLDER", "retail/retail_sales/staging")
# dbutils.widgets.text("PAR_IN_PATH", "Int_DF5_DF6_7111T")
# dbutils.widgets.text("PAR_OUT_PATH", "pos_interm")

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

sc.setJobDescription("Declaring global variables")

from pyspark.sql import Window
from pyspark.sql.functions import *
from pyspark.sql.types import *

PAR_IN_PATH = mountPoint +"/"+ dbutils.widgets.get("PAR_STAGING_FOLDER") +"/"+ dbutils.widgets.get("PAR_IN_PATH")
PAR_OUT_PATH = mountPoint +"/"+ dbutils.widgets.get("PAR_STAGING_FOLDER") +"/"+ dbutils.widgets.get("PAR_OUT_PATH")

# COMMAND ----------

sc.setJobDescription("Load input file and declare auxiliar variables: line 3 to 16")

df_in = spark.read.format("parquet").load(PAR_IN_PATH)

df_in = df_in.withColumn("local_e_comm_ind", lit(None)) \
             .withColumn("local_e_comm_order_nbr", lit(None)) \
             .withColumn("local_tax_exempt_ind", lit(None)) \
             .withColumn("local_tax_exempt_id", lit(None)) \
             .withColumn("s1", trim(col("rec_type_A_upc_tndr"))) \
             .withColumn("s2", trim(col("rec_type_A_desc_acct_nbr"))) \
             .withColumn("local_rx_nbr", lit(None)) \
             .withColumn("local_rx_ind", lit(None)) \
             .withColumn("local_rx_not_on_ic_ind", lit("N")) \
             .withColumn("is_birthday_item", lit("N")) \
             .withColumn("local_birthday", lit(None)) \
             .withColumn("local_age_ind", lit(None)) \
             .withColumn("local_dept_nbr_in_desc", lit(None)) \
             .withColumn("local_dept_hardkey_ind", lit(None))

# COMMAND ----------

sc.setJobDescription("Reformat record A: line 18 to 34")

df_in_step1 = df_in.withColumn("local_e_comm_ind", when((col("rcd_type") == "A") & ((col("str_nbr") == 5995) | (substring(col("s2"), 1, 12) == "E-COMM ORDER")) , lit("Y")).otherwise(lit("N"))) \
                   .withColumn("local_e_comm_order_nbr", when((col("rcd_type") == "A") & (col("local_e_comm_ind") == "E") & (substring(trim(col("s1")), 1, 12).rlike("^[0-9]+$")), substring(trim(col("s1")), 1, 12)).otherwise(lit(None))) \
                   .withColumn("local_tax_exempt_ind", when((col("rcd_type") == "A") & (substring(col("s1"), 1, 10) == "TAX NUMBER"), lit("Y")).otherwise(lit("N"))) \
                   .withColumn("local_tax_exempt_id", when((col("rcd_type") == "A") & (col("local_tax_exempt_ind") == "Y"), col("tax_id")).otherwise(lit(None)))

# COMMAND ----------

sc.setJobDescription("Reformat record A: line 36 to 97")

# separating rcd A
df_in_step2_rec_a = df_in_step1.where(col("rcd_type") == "A")
df_in_step2_rec_not_a = df_in_step1.where(col("rcd_type") != "A")

# Calculate local_rx_ind
df_in_step2_rec_a = df_in_step2_rec_a.withColumn("local_rx_ind", when(((col("s1") == "044999999999") | (col("s1") == "042000000907") | (col("s1") == "049999999999")) | \
                                                                      ((substring(col("s2"), 1, 3) == "RX ") & (substring(trim(col("s2")), 4, 7).rlike("^[0-9]+$"))), lit("W")) \
                                                                .otherwise(when(((col("s1") == "044999999998") | (col("s1") == "042000000957") | (col("s1") == "049999999998")) | \
                                                                                ((substring(col("s2"), 1, 7) == "PET RX ") & (substring(trim(col("s2")), 8, 7).rlike("^[0-9]+$"))), lit("P")) \
                                                                          .otherwise(when((substring(col("s2"), 1, 9) == "CofA RX# ") & (substring(trim(col("s2")), 10, 8).rlike("^[0-9]+$")), lit("A")))))

# Calculate local_rx_nbr
df_in_step2_rec_a = df_in_step2_rec_a.withColumn("local_rx_nbr", when((col("local_rx_ind") == "W") & (substring(trim(col("s2")), 4, 7).rlike("^[0-9]+$")), substring(trim(col("s2")), 4, 7)) \
                                                                 .otherwise(when((col("local_rx_ind") == "P") & (substring(trim(col("s2")), 8, 7).rlike("^[0-9]+$")), substring(trim(col("s2")), 8, 7)) \
                                                                            .otherwise(when(col("local_rx_ind") == "A", substring(trim(col("s2")), 10, 8)))))

# Calculate local_rx_not_on_ic_ind
df_in_step2_rec_a = df_in_step2_rec_a.withColumn("local_rx_not_on_ic_ind", when(((col("local_rx_ind") == "W") & (substring(col("s2"), 12, 2) == "* ")) | ((col("local_rx_ind") == "P") & (substring(col("s2"), 16, 2) == "* ")), lit("Y")) \
                                                                           .otherwise(lit("N")))

df_in_step2_rec_a = df_in_step2_rec_a.unionByName(df_in_step2_rec_not_a)

# COMMAND ----------

sc.setJobDescription("Calculate is_birthday_item and local_birthday: line 100 to 104")

df_in_step3_rec_a = df_in_step2_rec_a.withColumn("is_birthday_item", when((col("rcd_type") == "A") & (substring(col("s1"), 1, 8) == "BIRTHDAY"), lit("Y")).otherwise(lit("N")))
df_in_step3_rec_a = df_in_step3_rec_a.withColumn("local_birthday", when(col("is_birthday_item") == "Y", date_format(substring(col("s2"), 1, 10), "yyyy-MM-dd")).otherwise(lit(None)))

# COMMAND ----------

sc.setJobDescription("Calculate local_age_ind: line 106 to 107")
df_in_step4_rec_a = df_in_step3_rec_a.withColumn("local_age_ind", when((col("is_birthday_item") == "Y") & (substring(trim(col("s2")), 12, 6) != ""), substring(trim(col("s2")), 12, 6)).otherwise("--")) 

# COMMAND ----------

sc.setJobDescription("Calculate local_dept_hardkey_ind: line 109 to 138")

df_in_step5_rec_a = df_in_step4_rec_a.withColumn("local_dept_hardkey_ind", \
                                                 when((col("rcd_type") == "A") & (col("rec_type_A_dept_nbr").rlike("^[0-9]+$")) & (substring(col("s1"), 10, 3).rlike("^[0-9]+$")) & \
                                                      (col("rec_type_A_dept_nbr") == substring(col("s1"), 10, 3)) & \
                                                      (col("rec_type_A_dept_nbr") != 0) & \
	                                                  ((substring(col("s1"), 1, 9) == "200000000") | ((substring(col("s1"), 1, 10) == "0420000009") | (substring(col("s1"), 1, 11) == "00420000009"))), \
                                                      when(upper(substring(col("rec_type_A_desc_acct_nbr"), 1, 2)) == "RX", \
		                                                   when(((substring(col("s1"), 1, 10) == "0420000009") | \
                                                                 (substring(col("s1"), 1, 11) == "00420000009") ) & \
	                                                             (col("rec_type_A_keyed_item") == "K") & \
	                                                             ((substring(upper(col("rec_type_A_desc_acct_nbr")), 1, 18)=='RX                ') | (substring(upper(col("rec_type_A_desc_acct_nbr")), 1, 18)=='RX MISC           ')), \
			                                                     lit("DHK")).otherwise(lit("--"))) \
			                                         .otherwise(when(((substring(col("s1"), 1, 10) == "0420000009") | (substring(col("s1"), 1, 11) == "00420000009")) & (col("rec_type_A_keyed_item") == "K"), lit("DHK")) \
					                                           .otherwise(lit("--")))).otherwise(lit("--")))

df_in_step5_rec_a = df_in_step5_rec_a.withColumn("local_dept_hardkey_ind", \
                                                 when(((col("rcd_type") == "A") & (col("rec_type_A_dept_nbr").rlike("^[0-9]+$")) & (substring(col("s1"), 10, 3).rlike("^[0-9]+$")) & \
                                                       (col("rec_type_A_dept_nbr") == substring(col("s1"), 10, 3)) & \
	                                                   (col("rec_type_A_dept_nbr") != 0) & \
	                                                   ((substring(col("s1"), 1, 9) == "200000000") | \
	                                                   ((substring(col("s1"), 1, 10) == "0420000009") | \
	                                                   (substring(col("s1"), 1, 11) == "00420000009")))) & \
                                                       (substring(col("s1"), 1, 9) == "200000000"), lit("DHK")).otherwise(col("local_dept_hardkey_ind")))

# COMMAND ----------

sc.setJobDescription("Final assignment: line 151 to 162")

df_in_step6_rec_a = df_in_step5_rec_a.withColumn("rec_type_A_RX_ind", col("local_rx_ind")) \
                                     .withColumn("rec_type_A_rx_nbr", col("local_rx_nbr")) \
                                     .withColumn("rec_type_A_rx_not_on_ic_ind", col("local_rx_not_on_ic_ind")) \
                                     .withColumn("rec_type_A_ecomm_order_ind", col("local_e_comm_ind")) \
                                     .withColumn("rec_type_A_ecomm_order_nbr", col("local_e_comm_order_nbr")) \
                                     .withColumn("rec_type_A_tax_exempt_ind", col("local_tax_exempt_ind")) \
                                     .withColumn("rec_type_A_tax_exempt_id", col("local_tax_exempt_id")) \
                                     .withColumn("rec_type_A_overage_ind", when(substring(col("local_age_ind"), 1, 5) == "UNDER", lit("UNDER*")).otherwise(col("local_age_ind"))) \
                                     .withColumn("rec_type_A_birthday", col("local_birthday")) \
                                     .withColumn("rec_type_A_dept_hardkey_ind", col("local_dept_hardkey_ind")) \
                                     .withColumn("post_void_status",col("post_void_status")[0]) \
                                     .withColumn("rec_type_A_remain_dlrs",lit(None))

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------

sc.setJobDescription("Select Output and Write Output pos_interm.dat")

df_final = df_in_step6_rec_a.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","seq_nbr_by_rec_type","partition_nbr","str_nbr","loc_id","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","rcd_type","e_comm_ind","e_comm_order_nbr","total_sell_prc","training_ind","tax_ind","tax_id","offline_txn_ind","post_void_status","retrnd_item_cnt","exchange_cd","per_id","txn_start_dttm","txn_end_dttm","rec_type_A_upc_tndr","rec_type_A_desc_acct_nbr","rec_type_A_item_cost","rec_type_A_item_unit_price","rec_type_A_dept_nbr","rec_type_A_qty","rec_type_A_tax_type","rec_type_A_selling_price","rec_type_A_price_sign","rec_type_A_sale_ind","rec_type_A_wag_cpn","rec_type_A_emp_disc","rec_type_A_item_void","rec_type_A_keyed_item","rec_type_A_retrnd_item","rec_type_A_prc_modify","rec_type_A_prc_verify","rec_type_A_training_item","rec_type_A_special","rec_type_A_voided_ind","rec_type_A_RX_ind","rec_type_A_rx_nbr","rec_type_A_remain_dlrs","rec_type_A_ecomm_order_ind","rec_type_A_ecomm_order_nbr","rec_type_A_rx_not_on_ic_ind","rec_type_A_overage_ind","rec_type_A_birthday","rec_type_A_tax_exempt_ind","rec_type_A_tax_exempt_id","rec_type_A_dept_hardkey_ind","rec_type_A_unused5","rec_type_A_undefined","rec_type_A","rec_type_M_99_unused1","rec_type_M_99_reg_desc","rec_type_M_99_unused5","rec_type_M_99_undefined","rec_type_M_99","rec_type_M_38_not_1st_orig_tran_nbr","rec_type_M_38_not_1st_indicator","rec_type_M_38_not_1st_unused5","rec_type_M_38_not_1st_undefined","rec_type_M_38","rec_type_M_00_not_1st_indicator","rec_type_M_00_not_1st_unused5","rec_type_M_00_not_1st_undefined","rec_type_M_00","rec_type_M_survey_ind","rec_type_M_unused1","rec_type_M_txn_strt_time","rec_type_M_unused2","rec_type_M_txn_stop_time","rec_type_M_unused3","rec_type_M_offline","rec_type_M_rfn_nbr","rec_type_M_unused5","rec_type_M_undefined","rec_type_M","rec_type_11_survey_ind","rec_type_11_unused1","rec_type_11_txn_strt_time","rec_type_11_unused2","rec_type_11_txn_stop_time","rec_type_11_unused3","rec_type_11_disc_mode","rec_type_11_unused4","rec_type_11_offline","rec_type_11_rfn_nbr","rec_type_11_unused5","rec_type_11_undefined","rec_type_11","rec_type_12_survey_ind","rec_type_12_unused1","rec_type_12_txn_strt_time","rec_type_12_unused2","rec_type_12_txn_stop_time","rec_type_12_unused3","rec_type_12_disc_mode","rec_type_12_unused4","rec_type_12_offline","rec_type_12_rfn_nbr","rec_type_12_unused5","rec_type_12_undefined","rec_type_12","rec_type_B_unused_1","rec_type_B_tax_cde","rec_type_B_tax_tbl_desc","rec_type_B_unused_2","rec_type_B_tax_amt","rec_type_B_price_sign","rec_type_B_unused5","rec_type_B_undefined","rec_type_B","rec_type_D_unused_2","rec_type_D_sell_prc","rec_type_D_price_sign","rec_type_D_unused5","rec_type_D_undefined","rec_type_D","rec_type_C_p1_tndr_desc","rec_type_C_check_routing_nbr","rec_type_C_check_unused1","rec_type_C_check_chk_info","rec_type_C_check_selling_prc","rec_type_C_check_prc_sign","rec_type_C_check_unused5","rec_type_C_check_undefined","rec_type_C_check","rec_type_C_not_check_p2_tndr_desc","rec_type_C_not_check_acct_nbr","rec_type_C_not_check_entry_mode_old","rec_type_C_not_check_expire_dte","rec_type_C_not_check_unused2","rec_type_C_not_check_selling_prc","rec_type_C_not_check_prc_sign","rec_type_C_not_check_entry_mode_new","rec_type_C_not_check_unused3","rec_type_C_not_check_unused5","rec_type_C_not_check_undefined","rec_type_C_not_check","rec_type_C","rec_type_E_rcrd_sub_type","rec_type_E_fld_sep","rec_type_E_sub_typ_6_indicator","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_rec_sprtr","rec_type_E_sub_typ_6_mgr_id","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_refund_status","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_unused5","rec_type_E_sub_typ_6_undefined","rec_type_E_sub_typ_6","rec_type_E_sub_typ_19_patient_phn_nbr","rec_type_E_sub_typ_19_patient_id","rec_type_E_sub_typ_19_unused5","rec_type_E_sub_typ_19_undefined","rec_type_E_sub_typ_19","rec_type_E_sub_typ_10_spot_info","rec_type_E_sub_typ_10_unused5","rec_type_E_sub_typ_10","rec_type_E_sub_typ_26_wcard_plan_name","rec_type_E_sub_typ_26_wcard_acct_nbr","rec_type_E_sub_typ_26_wcard_tot_rebt_amt","rec_type_E_sub_typ_26_wcard_rebt_basis","rec_type_E_sub_typ_26_wcard_rebt_rate","rec_type_E_sub_typ_26_unused5","rec_type_E_sub_typ_26","rec_type_E_sub_typ_27_wcard_plan_name","rec_type_E_sub_typ_27_wcard_acct_nbr","rec_type_E_sub_typ_27_wcard_rebt_amt","rec_type_E_sub_typ_27_wcard_upc_nbr","rec_type_E_sub_typ_27_unused5","rec_type_E_sub_typ_27","rec_type_E","stuff")

df_final = df_final.withColumn("txn_start_dttm",concat(substring(df_final.txn_start_dttm,1,4),lit("-"),substring(df_final.txn_start_dttm,5,2),lit("-"),substring(df_final.txn_start_dttm,7,11))) \
.withColumn("txn_end_dttm",concat(substring(df_final.txn_end_dttm,1,4),lit("-"),substring(df_final.txn_end_dttm,5,2),lit("-"),substring(df_final.txn_end_dttm,7,11))) \
.withColumn("seq_nbr_by_rec_type",(df_final.seq_nbr_by_rec_type.cast("integer")).cast("string"))

from functools import reduce

df_final1 = (reduce(
    lambda df_final, col_name: df_final.withColumn(col_name, df_final[col_name]),
    df_final.columns,
    df_final
))

df_final1 = WriteNullParquet(df_final1)

df_final1.distinct().write.format("parquet").mode("overwrite").save(PAR_OUT_PATH)

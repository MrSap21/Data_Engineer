# Databricks notebook source
import os
import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters

os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_INPUT_PATH")
os.environ['logPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_LOG_PATH")
os.environ['pEDWBATCHID'] = dbutils.widgets.get("PAR_NB_EDWBATCHID")
os.environ['inputfile'] = dbutils.widgets.get("PAR_NB_INPUTFILE_NAME")

#os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("inputPath")
#os.environ['logPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("logPath")
#os.environ['pEDWBATCHID'] = dbutils.widgets.get("pEDWBATCHID")
#os.environ['inputfile'] = dbutils.widgets.get("inputfile")
 

# COMMAND ----------

# MAGIC %sh
# MAGIC AI_SERIAL_LOG=$logPath
# MAGIC AI_DIR_FTP_BASE=$inputPath
# MAGIC EDWBATCHID=$pEDWBATCHID
# MAGIC INPUTFILENAME=$inputfile'_'$EDWBATCHID.dat
# MAGIC LOG_FILE=$AI_SERIAL_LOG/aic_plan_edw_idl_customer_ccpa_customer_opt_out_list_load_cif_ccpa_customer_opt_out_list_20120403163612`date +%Y-%m-%d-%H-%M-%S`.log
# MAGIC if  [ -d "$AI_DIR_FTP_BASE/`date +%Y/%m/%d`" ]; then
# MAGIC echo "\n Direcotry is Found for OPT Out Load" > $LOG_FILE
# MAGIC   if ! [[ -s $AI_DIR_FTP_BASE/`date +%Y/%m/%d`/$INPUTFILENAME ]]; then
# MAGIC     sed -i "a File is NOT Found for OPT Out Load" $LOG_FILE
# MAGIC     sed -i "a Creating the Zero byte file for OPt out load" $LOG_FILE
# MAGIC     touch $AI_DIR_FTP_BASE/`date +%Y/%m/%d`/$INPUTFILENAME.dat
# MAGIC RC=$?
# MAGIC     if [ $RC -eq 0 ]
# MAGIC         then
# MAGIC         sed -i "a Zero byte file has been created successful" $LOG_FILE
# MAGIC     else
# MAGIC         sed -i "a Zero byte file has been created is Unsuccessful" $LOG_FILE
# MAGIC     fi
# MAGIC   fi
# MAGIC else
# MAGIC echo " Directory is NOT Found for OPT Out Load" >$LOG_FILE
# MAGIC cd $AI_DIR_FTP_BASE/`date +%Y/%m`
# MAGIC mkdir `date +%d`
# MAGIC touch $AI_DIR_FTP_BASE/`date +%Y/%m/%d`/$INPUTFILENAME.dat
# MAGIC fi

# COMMAND ----------



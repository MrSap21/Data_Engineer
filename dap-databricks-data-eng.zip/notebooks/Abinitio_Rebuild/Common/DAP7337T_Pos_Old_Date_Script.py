# Databricks notebook source
import os,json

# Mounting ADLS
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)


#Defining Default Variables 

os.environ['mountPoint']=mountPoint
AI_LOAD=AI_PERSIST_SERIAL = mountPoint + "/" + "retail/retail_sales/staging"


# COMMAND ----------

from pyspark.sql.functions import *
df1 = spark.read.parquet(AI_PERSIST_SERIAL +"/" + "pos_old_date")
POS_OLD_DATE = df1.rdd.map(lambda x:x[0]).collect()
#df2 = df1.withColumn('POS_OLD_DATE', split(col('value'), '\n')).drop(col('value'))

# COMMAND ----------

df = spark.read.text(AI_PERSIST_SERIAL +"/" + "run_date_file")
RUN_DATE = df.collect()[0][0]

from datetime import datetime,timedelta
 
NDATE = datetime.strptime(RUN_DATE,'%Y%m%d').date() + timedelta(1)
NEXT_DATE=str(NDATE).replace('-','')

RunFile=spark.createDataFrame([(NEXT_DATE)],StringType())

display(RunFile)

RunFile.write.format('text').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/run_date_file')


# COMMAND ----------

#dbutils.notebook.exit(df2)
dbutils.notebook.exit([POS_OLD_DATE])
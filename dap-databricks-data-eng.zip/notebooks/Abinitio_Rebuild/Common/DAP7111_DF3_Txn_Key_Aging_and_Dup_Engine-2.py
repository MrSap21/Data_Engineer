# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import col
import pyspark
from pyspark import Row
from pyspark.sql.window import Window
from pyspark.sql.functions import count

#Calling mount notebook
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",120)

#mountPoint = "/mnt/wrangled"

dbutils.widgets.text("SNOWFLAKE_WAREHOUSE", dbutils.widgets.get("PAR_NB_SNOWFLAKE_WH"))
dbutils.widgets.text("SNOWFLAKE_DATABASE", dbutils.widgets.get("PAR_NB_SNOWFLAKE_DB"))

#SNOWFLAKE_WAREHOUSE = "UAT_HISTORY_MIGRATION_FR_WH"
#SNOWFLAKE_DATABASE = "UAT_STAGING"

#Reading duplicate_reference_old_ascii.pipe_delim
file_dup_ref_old_ascii = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DUP_REF_OLD_PATH")

df_dup_ref_old_ascii  = spark.read.parquet(file_dup_ref_old_ascii)

#Reading FilterByStr5995OrValidFieldsDeselectTmp
file_FilterByStr5995 = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INT_DF2_DF3_PATH")

df_FilterByStr5995  = spark.read.parquet(file_FilterByStr5995).withColumn('txn_cntr',col("txn_cntr").cast("BigInt"))

DUP_DELETE = 14
NOT_DEFINED = -1

curr_dt = current_date()
#curr_dt = "20220401"

#df_dup_ref_old_ascii_dropRecords = df_dup_ref_old_ascii.filter(date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyyMMdd') > date_format(date_sub(to_date(lit(curr_dt),'yyyyMMdd'),DUP_DELETE),'yyyyMMdd'))

df_dup_ref_old_ascii_dropRecords = df_dup_ref_old_ascii.withColumn("curr_dt",current_date()).filter(date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyyMMdd') > date_format(date_sub(to_date(date_format(to_date(col('curr_dt'),'yyyy-MM-dd'),'yyyyMMdd'),'yyyyMMdd'),DUP_DELETE),'yyyyMMdd')).drop(col('curr_dt'))


# COMMAND ----------

from pyspark.sql import functions as f

#Dropping duplicates based on txn_cntr

df_FilterByStr5995_dropDups_txnCntr1 = df_FilterByStr5995.sort('txn_cntr', descending=True).dropDuplicates(['txn_cntr'])

df_FilterByStr5995_dropDups_txnCntr_filePath = mountPoint + "/retail/retail_sales/staging/df_FilterByStr5995_dropDups_txnCntr"

df_FilterByStr5995_dropDups_txnCntr1.write.mode('overwrite').parquet(df_FilterByStr5995_dropDups_txnCntr_filePath)

df_FilterByStr5995_dropDups_txnCntr = spark.read.parquet(df_FilterByStr5995_dropDups_txnCntr_filePath)

#Dropping duplicates based on natural key str_nbr; txn_date; txn_time; cashier_nbr; register_nbr; txn_type; txn_nbr; txn_start_time; txn_stop_time; total_sell_prc

df_FilterByStr5995_dropDups_NatKey_selOne1 = df_FilterByStr5995_dropDups_txnCntr.sort('txn_cntr', descending=True).dropDuplicates(['str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','txn_start_time','txn_stop_time','total_sell_prc'])

df_FilterByStr5995_dropDups_NatKey_selOne_filePath = mountPoint + "/retail/retail_sales/staging/df_FilterByStr5995_dropDups_NatKey_selOne"

df_FilterByStr5995_dropDups_NatKey_selOne1.write.mode('overwrite').parquet(df_FilterByStr5995_dropDups_NatKey_selOne_filePath)

df_FilterByStr5995_dropDups_NatKey_selOne = spark.read.parquet(df_FilterByStr5995_dropDups_NatKey_selOne_filePath)

#Creating duplicate error files

df_FilterByStr5995_dropDups_NatKey_dup = df_FilterByStr5995_dropDups_txnCntr.exceptAll(df_FilterByStr5995_dropDups_NatKey_selOne)

df_updColDupInCycle = df_FilterByStr5995_dropDups_NatKey_dup.withColumn("dup_in_cycle",lit("S")).select("txn_cntr","dup_in_cycle")

### To replace null values to zero for total_sell_prc  ###

df_FilterByStr5995_dropDups_NatKey_selOne = df_FilterByStr5995_dropDups_NatKey_selOne.na.fill(value='0',subset=["total_sell_prc"])

df_join_duplicate_ref_uniq = df_FilterByStr5995_dropDups_NatKey_selOne.alias("uniq").join(df_dup_ref_old_ascii_dropRecords.alias("srcIp"),(col("uniq.str_nbr").cast("Int") == col("srcIp.str_nbr").cast("Int")) & (col("uniq.txn_date") == col("srcIp.txn_date")) & (col("uniq.txn_time") == col("srcIp.txn_time")) & (col("uniq.cashier_nbr") == col("srcIp.cashier_nbr")) & (col("uniq.register_nbr") == col("srcIp.register_nbr")) & (col("uniq.txn_type") == col("srcIp.txn_type")) & (col("uniq.txn_nbr") == col("srcIp.txn_nbr")) & (col("uniq.txn_start_time").cast("Int") == col("srcIp.txn_start_time").cast("Int")) & (col("uniq.txn_stop_time").cast("Int") == col("srcIp.txn_stop_time").cast("Int")) & (col("uniq.total_sell_prc").cast("Decimal") == col("srcIp.total_sell_prc").cast("Decimal")),"full")                                                                                   .select(col("uniq.txn_cntr").alias("uniq_txn_cntr"),col("uniq.str_nbr").alias("uniq_str_nbr"),col("srcIp.str_nbr").alias("dup_ref_str_nbr"),col("uniq.txn_date").alias("uniq_txn_date"),col("srcIp.txn_date").alias("dup_ref_txn_date"),col("uniq.txn_time").alias("uniq_txn_time"),col("srcIp.txn_time").alias("dup_ref_txn_time"),col("uniq.cashier_nbr").alias("uniq_cashier_nbr"),col("srcIp.cashier_nbr").alias("dup_ref_cashier_nbr"),col("uniq.register_nbr").alias("uniq_register_nbr"),col("srcIp.register_nbr").alias("dup_ref_register_nbr"),col("uniq.txn_type").alias("uniq_txn_type"),col("srcIp.txn_type").alias("dup_ref_txn_type"),col("uniq.txn_nbr").alias("uniq_txn_nbr"),col("srcIp.txn_nbr").alias("dup_ref_txn_nbr"),col("uniq.txn_start_time").alias("uniq_txn_start_time"),col("srcIp.txn_start_time").alias("dup_ref_txn_start_time"),col("uniq.txn_stop_time").alias("uniq_txn_stop_time"),col("srcIp.txn_stop_time").alias("dup_ref_txn_stop_time"),col("uniq.total_sell_prc").alias("uniq_txn_total_sell_prc"),col("srcIp.total_sell_prc").alias("dup_ref_total_sell_prc"))

df_join_duplicate_ref_uniq_match = df_join_duplicate_ref_uniq.filter(col("uniq_str_nbr").isNotNull() &  col("dup_ref_str_nbr").isNotNull() & col("uniq_txn_date").isNotNull() & col("dup_ref_txn_date").isNotNull() & col("uniq_txn_time").isNotNull() & col("dup_ref_txn_time").isNotNull() & col("uniq_cashier_nbr").isNotNull() & col("dup_ref_cashier_nbr").isNotNull() & col("uniq_register_nbr").isNotNull() & col("dup_ref_register_nbr").isNotNull() & col("uniq_txn_type").isNotNull() & col("dup_ref_txn_type").isNotNull() & col("uniq_txn_nbr").isNotNull() & col("dup_ref_txn_nbr").isNotNull() & col("uniq_txn_start_time").isNotNull() & col("dup_ref_txn_start_time").isNotNull() & col("uniq_txn_stop_time").isNotNull() & col("dup_ref_txn_stop_time").isNotNull() & col("uniq_txn_total_sell_prc").isNotNull() & col("dup_ref_total_sell_prc").isNotNull())

df_join_duplicate_ref_uniq_in0 = df_join_duplicate_ref_uniq.filter(col("uniq_str_nbr").isNotNull() &  col("dup_ref_str_nbr").isNull() & col("uniq_txn_date").isNotNull() & col("dup_ref_txn_date").isNull() & col("uniq_txn_time").isNotNull() & col("dup_ref_txn_time").isNull() & col("uniq_cashier_nbr").isNotNull() & col("dup_ref_cashier_nbr").isNull() & col("uniq_register_nbr").isNotNull() & col("dup_ref_register_nbr").isNull() & col("uniq_txn_type").isNotNull() & col("dup_ref_txn_type").isNull() & col("uniq_txn_nbr").isNotNull() & col("dup_ref_txn_nbr").isNull() & col("uniq_txn_start_time").isNotNull() & col("dup_ref_txn_start_time").isNull() & col("uniq_txn_stop_time").isNotNull() & col("dup_ref_txn_stop_time").isNull() & col("uniq_txn_total_sell_prc").isNotNull() & col("dup_ref_total_sell_prc").isNull()).select("uniq_str_nbr","uniq_txn_date","uniq_txn_time","uniq_cashier_nbr","uniq_register_nbr","uniq_txn_type","uniq_txn_nbr","uniq_txn_start_time","uniq_txn_stop_time","uniq_txn_total_sell_prc")

df_join_duplicate_ref_uniq_in1 = df_join_duplicate_ref_uniq.filter(col("uniq_str_nbr").isNull() &  col("dup_ref_str_nbr").isNotNull() & col("uniq_txn_date").isNull() & col("dup_ref_txn_date").isNotNull() & col("uniq_txn_time").isNull() & col("dup_ref_txn_time").isNotNull() & col("uniq_cashier_nbr").isNull() & col("dup_ref_cashier_nbr").isNotNull() & col("uniq_register_nbr").isNull() & col("dup_ref_register_nbr").isNotNull() & col("uniq_txn_type").isNull() & col("dup_ref_txn_type").isNotNull() & col("uniq_txn_nbr").isNull() & col("dup_ref_txn_nbr").isNotNull() & col("uniq_txn_start_time").isNull() & col("dup_ref_txn_start_time").isNotNull() & col("uniq_txn_stop_time").isNull() & col("dup_ref_txn_stop_time").isNotNull() & col("uniq_txn_total_sell_prc").isNull() & col("dup_ref_total_sell_prc").isNotNull()).select("dup_ref_str_nbr","dup_ref_txn_date","dup_ref_txn_time","dup_ref_cashier_nbr","dup_ref_register_nbr","dup_ref_txn_type","dup_ref_txn_nbr","dup_ref_txn_start_time","dup_ref_txn_stop_time","dup_ref_total_sell_prc")

#Reading excld_list_lookup 
file_excld_list_lookup = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LKP_EXCLD_PATH")

df_excld_list_lookup  = spark.read.parquet(file_excld_list_lookup)

#Join excld_list_lkp with match and check umatched records

df_excld_join_unmatch = df_join_duplicate_ref_uniq_match.join(df_excld_list_lookup.alias("excldLstLkp"),(col("uniq_str_nbr") != col("excldLstLkp.store_nbr")) & (col("uniq_txn_date") != col("excldLstLkp.sales_txn_dt")) & (col("uniq_cashier_nbr") != col("excldLstLkp.cashier_nbr")) & (col("uniq_register_nbr") != col("excldLstLkp.register_nbr")) & (col("uniq_txn_type") != col("excldLstLkp.txn_type")) & (col("uniq_txn_nbr") != col("excldLstLkp.txn_nbr")),"leftouter")

df_excld_join_unmatch_select = df_excld_join_unmatch.withColumn("dup_in_cycle",lit("P")).select("uniq_txn_cntr","dup_in_cycle")

#Combining records where dup_in_cycle = S or P

df_union_dup_in_cycle = df_excld_join_unmatch_select.union(df_updColDupInCycle)

#Creating Dups files

join_dup_txns = df_FilterByStr5995.join(df_union_dup_in_cycle,col("uniq_txn_cntr") == col("txn_cntr"),"leftouter")

join_dup_txns_dups = join_dup_txns.filter(col("uniq_txn_cntr").isNotNull() & col("txn_cntr").isNotNull())

#Reading pos_file_lookup -- checking for filename

file_pos_file_lookup = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LKP_POS_EJ_PATH")

df_pos_file_lookup  = spark.read.parquet(file_pos_file_lookup)

join_dup_txns_dups_fileName = join_dup_txns_dups.alias("in0").join(df_pos_file_lookup.alias("in1"), col("in0.file_nbr") == col("in1.file_nbr"), "leftouter")

join_dup_txns_dups_fileName = join_dup_txns_dups_fileName.withColumn('file_name', when(col("file_name").isNull(), lit(f.concat(lit("Unknown, "),col("in0.file_nbr")))))

###### Writing the output to POSEJ_Error_Queue_Dup_EJ_ascii.pipe_delim ######
file_path_posej_error_q = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POS_EJ_ERR_QUE_PATH")

join_dup_txns_dups_fileName.select("str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","rcd_type","stuff","file_name","rec_in_file","rec_in_txn_cntr","dup_in_cycle"
).write.mode('overwrite').parquet(file_path_posej_error_q)

###### Writing the output to POSEJ_Error_Queue_Dup_summary.pipe_delim #####

# taking count on the basis of record type

df_initializeCounter = join_dup_txns_dups_fileName.withColumn('cnt_hdr',lit(1)).withColumn('cnt_A',lit(0)).withColumn('cnt_B',lit(0)).withColumn('cnt_C',lit(0)).withColumn('cnt_D',lit(0)).withColumn('cnt_E',lit(0)).withColumn('cnt_other',lit(0))

w_initializeCounter = Window.partitionBy("dup_in_cycle","str_nbr","txn_date","rcd_type").orderBy("dup_in_cycle","str_nbr","txn_date")

df_counter = df_initializeCounter.withColumn('cnt_hdr',when(col('rcd_type')==" ",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_A',when(col('rcd_type')=="A",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_B',when(col('rcd_type')=="B",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_C',when(col('rcd_type')=="C",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_D',when(col('rcd_type')=="D",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_E',when(col('rcd_type')=="E",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_other',when((col('rcd_type')!=" ") & (col('rcd_type')!="A") & (col('rcd_type')!="B") & (col('rcd_type')!="C") & (col('rcd_type')!="D") & (col('rcd_type')!="E") , f.row_number().over(w_initializeCounter))).na.fill(value=0,subset=["cnt_hdr","cnt_A","cnt_B","cnt_C","cnt_D","cnt_E","cnt_other"]).select("dup_in_cycle","str_nbr","txn_date","rcd_type","cnt_hdr","cnt_A","cnt_B","cnt_C","cnt_D","cnt_E","cnt_other")

df_grouped = df_counter.groupBy("dup_in_cycle","str_nbr","txn_date").agg(f.max('cnt_hdr').alias('cnt_hdr') \
      ,f.max('cnt_A').alias('cnt_A') \
      ,f.max('cnt_B').alias('cnt_B')  \
      ,f.max('cnt_C').alias('cnt_C')  \
      ,f.max('cnt_D').alias('cnt_D')  \
      ,f.max('cnt_E').alias('cnt_E') \
      ,f.max('cnt_other').alias('cnt_other')).withColumn('dup_in_cycle', when(col('dup_in_cycle') == "P", lit("Previous cycle")).otherwise(lit("Same cycle")))

file_path_posej_error_q_sum = mountPoint + "/" + dbutils.widgets.get("PAR_NB_ERR_QUE_SUM_PATH")

df_grouped.write.mode('overwrite').parquet(file_path_posej_error_q_sum)



# COMMAND ----------

####    Writing to duplicate_reference_new_ascii.pipe_delim   ####

# Reformat on df_join_duplicate_ref_uniq_in0

df_excld_join_unmatch = df_excld_join_unmatch.select("uniq_str_nbr","uniq_txn_date","uniq_txn_time","uniq_cashier_nbr","uniq_register_nbr","uniq_txn_type","uniq_txn_nbr","uniq_txn_start_time","uniq_txn_stop_time","uniq_txn_total_sell_prc")

df_join_duplicate_ref_uniq_in0_ref = df_join_duplicate_ref_uniq_in0.filter(to_date(col('uniq_txn_date'),'yyyyMMdd') > date_sub(to_date(lit(curr_dt),'yyyyMMdd'),DUP_DELETE))

# Union to all matched and unmatched 

df_duplicate_reference_new_ascii = df_join_duplicate_ref_uniq_in0_ref.union(df_excld_join_unmatch.union(df_join_duplicate_ref_uniq_in1))
file_path_dup_ref_new_ascii = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DUP_REF_NEW_PATH")

df_duplicate_reference_new_ascii.select(col("uniq_str_nbr").alias("str_nbr"),col("uniq_txn_date").alias("txn_date"),col("uniq_txn_time").alias("txn_time"),col("uniq_cashier_nbr").alias("cashier_nbr"),col("uniq_register_nbr").alias("register_nbr"),col("uniq_txn_type").alias("txn_type"),col("uniq_txn_nbr").alias("txn_nbr"),col("uniq_txn_start_time").alias("txn_start_time"),col("uniq_txn_stop_time").alias("txn_stop_time"),col("uniq_txn_total_sell_prc").alias("total_sell_prc")).write.mode('overwrite').parquet(file_path_dup_ref_new_ascii)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions

# COMMAND ----------

#Writing to POS_HEADER_STG table

join_dup_txns_new_ref = join_dup_txns.filter( col("uniq_txn_cntr").isNull())

join_dup_txns_new_ref_fltr = join_dup_txns_new_ref.filter(date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyyMMdd') < date_format(date_sub(to_date(lit(curr_dt),'yyyyMMdd'),DUP_DELETE),'yyyyMMdd'))

#Calculating records NOT older than 14 days

join_dup_txns_new_ref_fltr_not_14days = join_dup_txns_new_ref.filter(date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyyMMdd') >= date_format(date_sub(to_date(lit(curr_dt),'yyyyMMdd'),DUP_DELETE),'yyyyMMdd'))

# Removing records where natural key is same except for total_sell_prc, calculating max(total_sell_prc)

import pyspark.sql.functions as f

join_dup_txns_new_ref_fltr_not_14days = join_dup_txns_new_ref_fltr_not_14days.na.fill(value='0',subset=["total_sell_prc"])

df_dropDups_totalSellPrc = join_dup_txns_new_ref_fltr_not_14days.groupBy('str_nbr', 'txn_date', 'txn_time', 'cashier_nbr', 'register_nbr', 'txn_type', 'txn_nbr', 'txn_start_time', 'txn_stop_time').agg(f.max(col('total_sell_prc').cast('Double')).alias('total_sell_prc'))

join_dup_txns_new_ref_fltr_not_14days = join_dup_txns_new_ref_fltr_not_14days.alias("a").join(df_dropDups_totalSellPrc.alias("b"), (col("a.str_nbr").cast("Int") == col("b.str_nbr").cast("Int")) & (col("a.txn_date") == col("b.txn_date")) & (col("a.txn_time") == col("b.txn_time")) & (col("a.cashier_nbr") == col("b.cashier_nbr")) & (col("a.register_nbr") == col("b.register_nbr")) & (col("a.txn_type") == col("b.txn_type")) & (col("a.txn_nbr") == col("b.txn_nbr")) & (col("a.txn_start_time").cast("Int") == col("b.txn_start_time").cast("Int")) & (col("a.txn_stop_time").cast("Int") == col("b.txn_stop_time").cast("Int")) & (col("a.total_sell_prc").cast("Double") == col("b.total_sell_prc").cast("Double")), "leftsemi")

# Writing to intermediate file for DF5
file_path_not_older_14_days = mountPoint + "/" + dbutils.widgets.get("PAR_NB_PHASE2OUTREADY_PATH")

join_dup_txns_new_ref_fltr_not_14days.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","seq_nbr_by_rec_type","partition_nbr","str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","rcd_type","e_comm_ind","e_comm_order_nbr","txn_start_time","txn_stop_time","total_sell_prc","stuff").write.mode('overwrite').parquet(file_path_not_older_14_days)

#Reading dim_location_lookup
df_dim_loc_lkp_filepath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LKP_DIM_LOC_PATH")

df_dim_loc_lkp = spark.read.parquet(df_dim_loc_lkp_filepath)

df_loc_id = join_dup_txns_new_ref_fltr.alias("new_ref").join(df_dim_loc_lkp.alias("loc_lkp"), col("new_ref.str_nbr").cast("Int") == col("loc_lkp.str_nbr").cast("Int"), "leftouter")

NOT_DEFINED = -1

df_loc_id_ifNull = df_loc_id.withColumn('loc_id', when(col('loc_id').isNull(),lit(NOT_DEFINED)).otherwise(col('loc_id')))

df_loc_id_isDefined = df_loc_id_ifNull.filter(col('loc_id') != NOT_DEFINED)

#/*** Writing dropDupliates into a file ***/

df_loc_id_drpDups1 = df_loc_id_isDefined.dropDuplicates(['txn_date','str_nbr','txn_nbr','register_nbr','cashier_nbr','txn_type'])

df_loc_id_drpDups_filePath = mountPoint + "/retail/retail_sales/staging/df_loc_id_drpDups"

df_loc_id_drpDups1.select("txn_date","loc_id","txn_nbr","register_nbr","cashier_nbr","txn_type",col("new_ref.str_nbr").alias("str_nbr")).write.mode('overwrite').parquet(df_loc_id_drpDups_filePath)

df_loc_id_drpDups = spark.read.parquet(df_loc_id_drpDups_filePath)

#Writing to table
db_pos_hdr_tbl = dbutils.widgets.get("PAR_NB_SNOWFLAKE_DB") + "." + dbutils.widgets.get("PAR_NB_SNOWFLAKE_SCHEMA") + "." + dbutils.widgets.get("PAR_NB_SNOWFLAKE_TABLE")

df_loc_id_drpDups_datatype = df_loc_id_drpDups.withColumn("txn_date",date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyy-MM-dd'))

df_loc_id_drpDups_datatype.select("txn_date","loc_id","txn_nbr","register_nbr","cashier_nbr","txn_type","str_nbr").write \
  .format("snowflake") \
  .options(**options) \
  .option("dbtable", db_pos_hdr_tbl) \
  .option("truncate_table","ON")\
  .mode("overwrite") \
  .save()

#Writing an intermediate file for DF4
file_path_int_DF3_DF4 = mountPoint + "/" + dbutils.widgets.get("PAR_NB_TEMPOUTPHASE2_PATH")

df_loc_id_isDefined.select("txn_cntr","rec_in_txn_cntr","file_nbr","rec_in_file","seq_nbr_by_rec_type","partition_nbr","loc_id",col("new_ref.str_nbr").alias("str_nbr"),"txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","rcd_type","e_comm_ind","e_comm_order_nbr","txn_start_time","txn_stop_time","total_sell_prc","stuff").write.mode('overwrite').parquet(file_path_int_DF3_DF4)
# Databricks notebook source
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",120)

# COMMAND ----------

import os
import shutil

assetLocationPRD=mountPoint+'/'+dbutils.widgets.get("PAR_NB_PRD_PATH")
assetNamePRD=dbutils.widgets.get("PAR_NB_PRD_ASSET")
assetLocationWIC=mountPoint+'/'+dbutils.widgets.get("PAR_NB_WIC_PATH")
assetNameWIC=dbutils.widgets.get("PAR_NB_WIC_ASSET")

# COMMAND ----------

srcPRD=assetLocationPRD+assetNamePRD
destPathPRD=mountPoint+'/'+dbutils.widgets.get("PAR_NB_PRD_DEST_PATH")
destFilePRD=dbutils.widgets.get("PAR_NB_PRD_FILE")
destPRD=destPathPRD+destFilePRD

if not os.path.exists(destPathPRD):
  os.makedirs(destPathPRD)

shutil.copy(srcPRD,destPRD)

# COMMAND ----------

srcWIC=assetLocationWIC+assetNameWIC
destPathWIC=mountPoint+'/'+dbutils.widgets.get("PAR_NB_WIC_DEST_PATH")
destFileWIC=dbutils.widgets.get("PAR_NB_WIC_FILE")
destWIC=destPathWIC+destFileWIC

if not os.path.exists(destPathWIC):
  os.makedirs(destPathWIC)

shutil.copy(srcWIC,destWIC)

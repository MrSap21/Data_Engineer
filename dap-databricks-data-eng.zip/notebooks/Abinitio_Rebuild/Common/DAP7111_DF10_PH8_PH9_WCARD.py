# Databricks notebook source
# dbutils.widgets.text("PAR_POSINTERM_INFILE","pos_interm") #Intermediate in File
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_DECODEWVAL_LKPFILE","Int_DF7_DF8_DF11_decode_w_value_lookup")
# dbutils.widgets.text("PAR_PRODUCT_REPLACE_ASCII","dim_product_replace_ascii_new")
# dbutils.widgets.text("PAR_WCARD_TXN_INSRT_ASCII","pos_wcard_txn_insert_ascii.pipe_delim")
# dbutils.widgets.text("PAR_WCARD_PROD_ID_LOOKUP","wcard_prod_id_lookup_ascii.pipe_delim")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark.sql.types import *

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)
PosInterm_INFile = dbutils.widgets.get("PAR_POSINTERM_INFILE")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")

pos_intermDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+PosInterm_INFile)

# COMMAND ----------

#Filter by Expression
Flow1_filter_out = pos_intermDF.where((col('rcd_type') == 'E') & (col('rec_type_E_rcrd_sub_type') == '0027'))
#display(Flow1_filter_out.where(col('rec_type_E_sub_typ_27_wcard_upc_nbr')==31191719321))
Flow1_filter_deselect = pos_intermDF.subtract(Flow1_filter_out)
#display(Flow1_filter_deselect)

# COMMAND ----------

#ref_E0027
ref_E0027 = Flow1_filter_out.withColumn('wcard_plan_name',trim(col('rec_type_E_sub_typ_27_wcard_plan_name')))\
.withColumn('wcard_acct_nbr',trim(col('rec_type_E_sub_typ_27_wcard_acct_nbr')))\
.withColumn('wcard_rebt_amt',trim(col('rec_type_E_sub_typ_27_wcard_rebt_amt')))\
.withColumn('wcard_upc_nbr',trim(col('rec_type_E_sub_typ_27_wcard_upc_nbr')))\
.select('txn_cntr','loc_id','txn_date','wcard_plan_name','wcard_acct_nbr','wcard_rebt_amt','wcard_upc_nbr')

# COMMAND ----------

#Reformat-validate E0027 rec
ref_E0027_validate = ref_E0027.where((col('txn_cntr').isNotNull()) & (col('loc_id').isNotNull()) & (col('txn_date').isNotNull()) & (col('wcard_plan_name').isNotNull()) & (col('wcard_acct_nbr').isNotNull()) & (col('wcard_upc_nbr').isNotNull()))

ref_E0027_validate_out = ref_E0027_validate.withColumn('txn_id',col('txn_cntr')).drop('txn_cntr')\
.withColumn('txn_dt',date_format((to_date(col('txn_date'),'yyyMMdd')),'yyyy-MM-dd')).drop('txn_date')\
.withColumn('wcard_plan_name',when(col('wcard_plan_name').isNotNull(),trim(col('wcard_plan_name'))).otherwise(lit('UNKNOWN')))\
.withColumn('wcard_acct_nbr',when(trim(col('wcard_acct_nbr')).rlike('^[0-9]\d*(\.\d+)?$'),trim(col('wcard_acct_nbr'))).otherwise(lit('0')))\
.withColumn('wcard_rebt_amt',when(trim(col('wcard_rebt_amt')).rlike('^[0-9]\d*(\.\d+)?$'),(trim(col('wcard_rebt_amt'))).cast(DecimalType(10,2))).otherwise(lit(0.00)))\
.withColumn('wcard_upc_nbr',when(trim(col('wcard_upc_nbr')).rlike('^[0-9]\d*(\.\d+)?$'),trim(col('wcard_upc_nbr'))).otherwise(lit('0')))


# COMMAND ----------

#Scan on {txn_id; wcard_upc_nbr}
wspec = Window.partitionBy('txn_id','wcard_upc_nbr').orderBy(col('wcard_rebt_amt')).rowsBetween(Window.unboundedPreceding,Window.currentRow)

ref_E0027_validate_scan = ref_E0027_validate_out.withColumn('temp_seq_nbr_hdr',when(col('txn_id').isNotNull(),lit(1)).otherwise(0))\
.withColumn('seq_nbr_hdr',(sum('temp_seq_nbr_hdr')).over(wspec))\
.withColumn('upc_item_seq_nbr',when(col('temp_seq_nbr_hdr')==1,col('seq_nbr_hdr')).otherwise(0))\
.withColumn('upc_nbr',(col('wcard_upc_nbr')).cast(DecimalType(12,0)))\
.select('txn_id','loc_id','txn_dt','wcard_plan_name','wcard_acct_nbr','wcard_rebt_amt','upc_nbr','upc_item_seq_nbr')

#display(ref_E0027_validate_scan.where(col('upc_nbr')==31191719321))

# COMMAND ----------

#Ref-Rec_type="A"
# rcd_type == "A" && rec_type_A.item_void !="V" && rec_type_A.training_item !="T"
# && rec_type_A.retrnd_item !="R" && rec_type_A.price_sign !="-" && txn_type != 48 && rec_type_A.prc_verify != "Y"
# && rec_type_A.selling_price>0

Ref_Rec_type_A = Flow1_filter_deselect.where((col('rcd_type')=='A') & (col('rec_type_A_item_void')!='V') & (col('rec_type_A_training_item')!='T') & (col('rec_type_A_retrnd_item')!='R') & (col('rec_type_A_price_sign')!='-') & ((col('txn_type')).cast(IntegerType())!=48) & (col('rec_type_A_prc_verify')!='Y') & (col('rec_type_A_selling_price').cast(DoubleType())>0))\
.withColumn('upc_nbr',(trim(substring(col('rec_type_A_upc_tndr'),1,12))).cast(DecimalType(12,0)))\
.withColumn('qty',col('rec_type_A_qty'))\
.withColumn('selling_price',col('rec_type_A_selling_price'))\
.withColumn('price_sign',col('rec_type_A_price_sign'))\
.withColumn('sale_ind',col('rec_type_A_sale_ind'))\
.select('txn_cntr','seq_nbr_by_rec_type','str_nbr','loc_id','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','total_sell_prc','upc_nbr','qty',(col('selling_price').cast(DecimalType(8,2))).alias('selling_price'),'price_sign','sale_ind')

# COMMAND ----------

#Scan on {txn_cntr; upc_nbr}

wspec = Window.partitionBy('txn_cntr','upc_nbr').orderBy(col('selling_price')).rowsBetween(Window.unboundedPreceding,Window.currentRow)

Ref_Rec_type_A_scan = Ref_Rec_type_A.withColumn('temp_seq_nbr_hdr',when(col('txn_cntr').isNotNull(),lit(1)).otherwise(0))\
.withColumn('seq_nbr_hdr',(sum('temp_seq_nbr_hdr')).over(wspec))\
.withColumn('upc_item_seq_nbr',when(col('temp_seq_nbr_hdr')==1,col('seq_nbr_hdr')).otherwise(0))\
.withColumn('txn_id',(col('txn_cntr')))\
.withColumn('line_item_seq_nbr',(col('seq_nbr_by_rec_type')))\
.select('txn_id','line_item_seq_nbr','loc_id','txn_date','txn_type','rcd_type','total_sell_prc','upc_nbr','upc_item_seq_nbr','qty','selling_price','price_sign','sale_ind')

# COMMAND ----------

#Join on {txn_id; upc_nbr; upc_item_seq_nbr}

Flow1_out = ref_E0027_validate_scan.join(Ref_Rec_type_A_scan,(ref_E0027_validate_scan.txn_id==Ref_Rec_type_A_scan.txn_id) & (ref_E0027_validate_scan.upc_nbr==Ref_Rec_type_A_scan.upc_nbr) & (ref_E0027_validate_scan.upc_item_seq_nbr==Ref_Rec_type_A_scan.upc_item_seq_nbr),how='inner')\
.select(ref_E0027_validate_scan['*'],Ref_Rec_type_A_scan.line_item_seq_nbr)\
.withColumnRenamed('upc_nbr','wcard_upc_nbr')


# COMMAND ----------

#Reformat-E0026 
#rcd_type == "E" && rec_type_E.rcrd_sub_type == "0026"

Reformat_E0026 = pos_intermDF.where((col('rcd_type') == 'E') & (col('rec_type_E_rcrd_sub_type') == '0026'))\
.withColumn('wcard_plan_name',trim(col('rec_type_E_sub_typ_26_wcard_plan_name')))\
.withColumn('wcard_acct_nbr',trim(col('rec_type_E_sub_typ_26_wcard_acct_nbr')))\
.withColumn('wcard_tot_rebt_amt',trim(col('rec_type_E_sub_typ_26_wcard_tot_rebt_amt')))\
.withColumn('wcard_rebt_basis',trim(col('rec_type_E_sub_typ_26_wcard_rebt_basis')))\
.withColumn('wcard_rebt_rate',trim(col('rec_type_E_sub_typ_26_wcard_rebt_rate')))\
.select('txn_cntr','loc_id','txn_date','wcard_plan_name','wcard_acct_nbr','wcard_tot_rebt_amt','wcard_rebt_basis','wcard_rebt_rate')

#display(Reformat_E0026.where(col('txn_cntr')==9295176402703))

# COMMAND ----------

#Ref-validate E0026 rec
#is_valid(txn_cntr) and is_valid(loc_id) and is_valid(txn_date) and is_valid(wcard_plan_name) and is_valid(wcard_acct_nbr)
#and is_valid(wcard_rebt_basis)

lookup_file = dbutils.widgets.get("PAR_DECODEWVAL_LKPFILE")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
lookup_df = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+lookup_file).where(trim(col('cd_type'))=='WCARD_RATE')
default_lookup_val = lookup_df.where((trim(col('cd_value'))=='--')).select('cd_id').collect()[0]['cd_id']
print(default_lookup_val)

Reformat_E0026_validate = Reformat_E0026.where((col('txn_cntr').isNotNull()) & (col('loc_id').isNotNull()) & (col('txn_date').isNotNull()) & (col('wcard_plan_name').isNotNull()) & (col('wcard_acct_nbr').isNotNull()) & (col('wcard_rebt_basis').isNotNull()))\
.withColumnRenamed('txn_cntr','txn_id')\
.withColumn('txn_dt',date_format((to_date(col('txn_date'),'yyyyMMdd')),'yyyy-MM-dd'))\
.withColumn('wcard_plan_name',when(col('wcard_plan_name').isNotNull(),trim(col('wcard_plan_name'))).otherwise(lit('UNKNOWN')))\
.withColumn('wcard_acct_nbr',when(trim(col('wcard_acct_nbr')).rlike('^[0-9]\d*(\.\d+)?$'),trim(col('wcard_acct_nbr'))).otherwise(lit('0')))\
.withColumn('wcard_tot_rebt_amt',when(trim(col('wcard_tot_rebt_amt')).rlike('^[0-9]\d*(\.\d+)?$'),(trim(col('wcard_tot_rebt_amt'))).cast(DecimalType(10,2))).otherwise(lit(0.00)))

Reformat_E0026_validate = Reformat_E0026_validate.join(lookup_df,(trim(Reformat_E0026_validate.wcard_rebt_basis))==(trim(lookup_df.cd_value)),how='left_outer').select(Reformat_E0026_validate['*'],lookup_df.cd_id)\
.withColumn('wcard_rebt_basis_cd',when(length(trim(col('wcard_rebt_basis')))>0,col('cd_id')).otherwise(lit(default_lookup_val)))\
.withColumn('wcard_rebt_rate',when(trim(col('wcard_rebt_rate')).rlike('^[0-9]\d*(\.\d+)?$'),trim(col('wcard_rebt_rate'))).otherwise(lit('0.00')))\
.select('txn_id','loc_id','txn_dt','wcard_plan_name','wcard_acct_nbr','wcard_tot_rebt_amt','wcard_rebt_basis_cd','wcard_rebt_rate')


# COMMAND ----------

#Dedup Sorted to remove duplicates

Flow2_out = Reformat_E0026_validate.distinct()

# COMMAND ----------

#Reformat drop fields
lookup_file = dbutils.widgets.get("PAR_PRODUCT_REPLACE_ASCII")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")


dim_prod_replace_ascii_df = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+lookup_file).select('prod_id','upc_nbr').na.replace('',None,subset=['upc_nbr'])

# COMMAND ----------

#Join on {txn_id; wcard_plan_name}

df_joined = Flow1_out.join(Flow2_out,((trim(Flow1_out.txn_id))==(trim(Flow2_out.txn_id))) & ((trim(Flow1_out.wcard_plan_name))==(trim(Flow2_out.wcard_plan_name))),how='inner')\
.select(Flow2_out['*'],(Flow1_out.wcard_upc_nbr).alias('flow1_wcard_upc_nbr'),(Flow1_out.wcard_rebt_amt).alias('flow1_wcard_rebt_amt'),(Flow1_out.line_item_seq_nbr).alias('flow1_line_item_seq_nbr'))\

df_joined2 = df_joined.join(dim_prod_replace_ascii_df,(df_joined.flow1_wcard_upc_nbr).cast(DoubleType())==(dim_prod_replace_ascii_df.upc_nbr).cast(DoubleType()),how='left_outer')\
.withColumn('wcard_tot_rebt_amt',col('wcard_tot_rebt_amt').cast(DecimalType(7,2)))\
.select(col('txn_id').cast('bigint').cast('string').alias('txn_id'),'txn_dt',(trim(col('loc_id'))).alias('loc_id'),dim_prod_replace_ascii_df.prod_id,(lpad(col('flow1_line_item_seq_nbr'),5,'0')).alias('line_item_seq_nbr'),'wcard_plan_name','wcard_acct_nbr',(col('wcard_tot_rebt_amt')).alias('wcard_tot_amt'),(col('flow1_wcard_rebt_amt')).alias('wcard_amt'),(col('wcard_rebt_basis_cd')).alias('wcard_basis_cd'),(col('wcard_rebt_rate')).alias('wcard_rate'))

# COMMAND ----------

wcard_lookup_file = dbutils.widgets.get("PAR_WCARD_PROD_ID_LOOKUP")
wcard_txn_insert_ascii = dbutils.widgets.get("PAR_WCARD_TXN_INSRT_ASCII")
dim_prod_replace_ascii_df.write.format('parquet').mode('overwrite').save(mountPoint+"/"+Lookup_Folder+"/"+wcard_lookup_file)
df_joined2.write.format('parquet').mode('overwrite').save(mountPoint+"/"+Staging_Folder+"/"+wcard_txn_insert_ascii)
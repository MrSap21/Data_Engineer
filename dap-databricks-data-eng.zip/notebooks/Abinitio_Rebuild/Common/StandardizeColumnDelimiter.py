# Databricks notebook source
from pyspark.sql.functions import *
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType

# COMMAND ----------

dbutils.widgets.text("PAR_DB_INPUT_ACCOUNT_NAME","",label="PAR_DB_INPUT_ACCOUNT_NAME")
dbutils.widgets.text("PAR_DB_INPUT_CONTAINER_NAME","",label="PAR_DB_INPUT_CONTAINER_NAME")
dbutils.widgets.text("PAR_DB_INPUT_PATH","",label="PAR_DB_INPUT_PATH")
dbutils.widgets.text("PAR_DB_DELIMITER","",label="PAR_DB_DELIMITER")

adlsInputAccountName=dbutils.widgets.get("PAR_DB_INPUT_ACCOUNT_NAME")
adlsInputContainerName=dbutils.widgets.get("PAR_DB_INPUT_CONTAINER_NAME")
adlsInputFolderPath=dbutils.widgets.get("PAR_DB_INPUT_PATH")
delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')

# COMMAND ----------

# Python code to mount and access Azure Data Lake Storage Gen2 Account to Azure Databricks with Service Principal and OAuth
# Author: Dhyanendra Singh Rathore
# Define the variables used for creating connection strings
adlsAccountName = adlsInputAccountName
adlsContainerName = adlsInputContainerName
mountPoint = "/mnt/"+adlsInputContainerName

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)
  

# COMMAND ----------

# Load File

df = spark.read.format("csv")\
      .option("header", False)\
      .option("delimiter",delimiter)\
      .load('dbfs:/mnt/'+adlsInputContainerName+'/'+adlsInputFolderPath+'/')

# COMMAND ----------

# Create output path

data_location_output = mountPoint + "/" + str.replace(adlsInputFolderPath, ".dat", "")
  
# Write in ADLS

df.coalesce(1).write.options(header='false', delimiter = "\u0001").format("csv").mode("overwrite").save(data_location_output)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

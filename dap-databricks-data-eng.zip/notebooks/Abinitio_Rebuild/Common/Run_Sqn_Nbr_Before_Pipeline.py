# Databricks notebook source
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions

# COMMAND ----------

dbutils.widgets.text("proj_name","")
dbutils.widgets.text("src_stream_name","")
dbutils.widgets.text("master_pipeline_name","")
dbutils.widgets.text("SNOWFLAKE_DATABASE","")
dbutils.widgets.text("SNOWFLAKE_WAREHOUSE","")
dbutils.widgets.text("schema_name","")

# COMMAND ----------

import sys
from pyspark.sql.types import IntegerType

proj_name = dbutils.widgets.get("proj_name")
src_stream_name = dbutils.widgets.get("src_stream_name")
pipeline_name = dbutils.widgets.get("master_pipeline_name")
SNOWFLAKE_DATABASE = dbutils.widgets.get("SNOWFLAKE_DATABASE")
SNOWFLAKE_WAREHOUSE = dbutils.widgets.get("SNOWFLAKE_WAREHOUSE")
v_schema = dbutils.widgets.get("schema_name")


# proj_name = "pharmacy"
# src_stream_name = "pharmacy"
# pipeline_name = "PL_MSTR_DAP_DRUG_SPECIALTY_LIST"

#Defining schema for table

# v_schema = "prdetlsand01"
# SNOWFLAKE_DATABASE = "dapdevdwh01"

# Return connection details

query = "SELECT MAX(edw_batch_id) as id FROM {3}.{2}.proc_cntrl_batch_detail WHERE proj_name='{0}' AND src_stream_name='{1}' AND batch_status_cd='1'".format(proj_name, src_stream_name,v_schema,SNOWFLAKE_DATABASE)

# Load data to dataframe

df = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("query", query) \
   .load()

maxBatchId = df.first()[0]
#maxBatchId = None

if (maxBatchId == None):
    print("Failed Batch Id cannot be Null, Bypassing the script ")
    sys.exit(1)

query1 = "SELECT concat(TMP2.MAXRSN,'|',TMP1.status_cd) as rsn FROM {5}.{4}.proc_cntrl_pipeline_run_detail TMP1,( SELECT MAX(run_seq_nbr) AS MAXRSN FROM {5}.{4}.proc_cntrl_pipeline_run_detail WHERE edw_batch_id='{2}' AND proj_name='{0}' AND src_stream_name='{1}' AND pipeline_name='{3}') TMP2 WHERE TMP1.edw_batch_id='{2}' AND TMP1.proj_name='{0}' AND TMP1.src_stream_name='{1}' AND TMP1.pipeline_name='{3}' AND TMP1.run_seq_nbr=TMP2.MAXRSN".format(proj_name, src_stream_name, maxBatchId, pipeline_name,v_schema,SNOWFLAKE_DATABASE)

pRUN_SEQ_NBR = 0
rsn_stat_cd = None
# Load data to dataframe

df1 = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", query1) \
  .load()

if(df1.count()>0):
  rsn_stat_cd = df1.first()[0]
print(rsn_stat_cd)
if (rsn_stat_cd != None) :
    print("PREVIOUS EXECUTION FOR CURRENT pipeline FOUND")
    pipeline_STATUS_CD = rsn_stat_cd.split('|')[1]
    if ( pipeline_STATUS_CD == 0 ) :
      {
         print ("PREVIOUS pipeline EXECUTED OK")

       }
    CURR_RSN=rsn_stat_cd.split('|')[0]
    pRUN_SEQ_NBR=int(CURR_RSN) + 1

else :
     print("PREVIOUS EXECUTION FOR CURRENT pipeline NOT FOUND")
     pRUN_SEQ_NBR = 1
    
# Inserting record in table before pipeline execution

query2 = "INSERT INTO {6}.{5}.proc_cntrl_pipeline_run_detail (proj_name, src_stream_name, edw_batch_id, pipeline_name, run_seq_nbr, start_dttm, finish_dttm, status_cd ) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', to_char(CURRENT_TIMESTAMP(), 'YYYY-MM-DD HH:MI:SS'), '1800-01-01 00:00:00', '-1')".format(proj_name, src_stream_name, maxBatchId, pipeline_name, pRUN_SEQ_NBR,v_schema,SNOWFLAKE_DATABASE)

dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : query2, "transaction" : True, "SNOWFLAKE_DATABASE" : SNOWFLAKE_DATABASE,"SNOWFLAKE_WAREHOUSE" : SNOWFLAKE_WAREHOUSE})

# COMMAND ----------


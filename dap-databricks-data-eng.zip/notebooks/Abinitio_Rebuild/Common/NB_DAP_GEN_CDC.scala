// Databricks notebook source


// COMMAND ----------

/** import's **/

import org.apache.spark.sql.types.{StructType, StructField, StringType, IntegerType};
import org.apache.spark.sql.functions._
import com.microsoft.aad.adal4j.{AuthenticationContext, ClientCredential}
import org.apache.spark.sql.SparkSession
import java.util.concurrent.Executors
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}


/************* Defining ADLS parameters ************/

import spark.implicits._

val prev_file_path = dbutils.widgets.get("PAR_NB_LKP_DIR")
val curr_file_path = dbutils.widgets.get("PAR_NB_IN_DIR")
val pre_file_name = dbutils.widgets.get("PAR_NB_IN_PREV_FILE")
val Input_Schema  = dbutils.widgets.get("PAR_NB_CDC_DML")
val curr_file_name = dbutils.widgets.get("PAR_NB_IN_CURR_FILE")
val cdc_key_string = dbutils.widgets.get("PAR_NB_CDC_KEY")
val out_file_cdc_path = dbutils.widgets.get("PAR_NB_OUT_DIR")
val out_file_cdc_name = dbutils.widgets.get("PAR_NB_OUT_CDC_FILE")
val edw_batch_id = dbutils.widgets.get("PAR_NB_OUT_DAP_BATCH_ID")
val fileDelimiter = dbutils.widgets.get("PAR_NB_FILE_DELIMETER")


/* Define the variables used for creating connection strings to ADLS */
//val adlsAccountName = "dapdevadlslnd01"
//val adlsContainerName = "landing"
val adlsAccountName = "dapdevadlswrng01"
val adlsContainerName = "wrangled"

val adlsFolderName = out_file_cdc_path
val mountPoint = "/mnt/" + adlsContainerName + "/" + adlsFolderName

/* Application (Client) ID */
val applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")

/* Application (Client) Secret Key */
val authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")

/* Directory (Tenant) ID */
val tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")

val endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
val source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName
val PreFile = mountPoint + '/' +  pre_file_name
val CurrFile = mountPoint + '/' +  curr_file_name 
val OutPutFile = mountPoint + '/' + out_file_cdc_name + "_" + edw_batch_id + ".dat" 
/* Connecting using Service Principal secrets and OAuth */
val configs = Map("fs.azure.account.auth.type" -> "OAuth",
           "fs.azure.account.oauth.provider.type" -> "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id" -> applicationId,
           "fs.azure.account.oauth2.client.secret" -> authenticationKey,
           "fs.azure.account.oauth2.client.endpoint" -> endpoint)

/* Mounting ADLS Storage to DBFS */
if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(mountPoint))
dbutils.fs.mount(
  source = source,
  mountPoint = mountPoint,
  extraConfigs = configs )

// COMMAND ----------


/** Reading dynamic schema **/

val fields = Input_Schema.split(",")
  .map(fieldName => StructField(fieldName, StringType, nullable = true))
val schema = StructType(fields)
val keyExpr =cdc_key_string.split(",")

/** Reading Input file **/

//Reading Input files//

val PreDF =spark.read.format("csv").option("delimiter",fileDelimiter).schema(schema).option("ignoreTrailingWhiteSpace",true).load(PreFile)
val CurrDF =spark.read.format("csv").option("delimiter",fileDelimiter).schema(schema).option("ignoreTrailingWhiteSpace",true).load(CurrFile)

val filterCond = PreDF.columns.map(x=>PreDF(x).isNotNull).reduce(_ && _)
//val ModifiedandNewDF =CurrDF.except(PreDF.intersect(CurrDF))
//val CDCDF = ModifiedandNewDF
/*val ModifiedandNewDF =PreDF.unionAll(CurrDF).except(PreDF.intersect(CurrDF))
val OldDF = PreDF.join(CurrDF,keyExpr,"inner").select(PreDF.columns.map(c => PreDF(c)): _*)
val CDCDF = ModifiedandNewDF.except(OldDF)
*/

//Reading Input files//

val ModifiedDF = CurrDF.join(PreDF,keyExpr,"inner").select(CurrDF.columns.map(c => CurrDF(c)): _*).distinct()
val ModifiedDFNewDF =ModifiedDF.except(PreDF.intersect(CurrDF)) 
val NewDF = CurrDF.join(PreDF,keyExpr,"leftanti")
//NewDF.show()
val CDCDF = NewDF.unionAll(ModifiedDFNewDF)


//Generating Output cdc file//

CDCDF.coalesce(1).write.format("csv").option("delimiter",fileDelimiter).mode("overwrite").save(OutPutFile + ".tmp")
val partition_path = dbutils.fs.ls(OutPutFile +".tmp/").filter(file=>file.name.endsWith(".csv"))(0).path
dbutils.fs.cp(partition_path,OutPutFile)
dbutils.fs.rm(OutPutFile+".tmp",recurse=true)






// COMMAND ----------


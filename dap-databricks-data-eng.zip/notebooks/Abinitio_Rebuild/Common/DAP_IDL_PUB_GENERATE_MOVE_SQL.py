# Databricks notebook source
p1=dbutils.widgets.text("PAR_PL_OP_FILE_DIR","")
p2=dbutils.widgets.text("PAR_PL_OP_FILE","")

# COMMAND ----------

op_file_path = dbutils.widgets.get('PAR_PL_OP_FILE_DIR')
op_file_name = dbutils.widgets.get('PAR_PL_OP_FILE')
#print(p1)

# COMMAND ----------

# Load File

input_path="/mnt/wrangled/"+ op_file_path + "/" + op_file_name + ".sql"
df = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header", "false")\
      .option("sep", ",")\
      .load(input_path)

#display(df)

# COMMAND ----------

#Order required statements
from pyspark.sql.functions import col
a= (df
   .orderBy(col("_c0"),col("_c1")))
b=(a
  .select("_c2"))

#display(b)

# COMMAND ----------

#Write output file
data_location_output="/mnt/utility/sql/" +op_file_path + "/" + op_file_name
print(data_location_output)
b.coalesce(1).write.mode("overwrite").option("quote"," ").option("escape", " ").format("csv").save(data_location_output)
filesoutput = dbutils.fs.ls(data_location_output)
print(filesoutput) 
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
print(csv_file_output) 
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".sql")
dbutils.fs.rm(data_location_output, recurse = True)
dbutils.fs.rm(input_path, recurse = True)


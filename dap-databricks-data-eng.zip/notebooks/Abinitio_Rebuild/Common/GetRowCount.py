# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 450)

# COMMAND ----------

import pyspark
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType
import datetime
import pyspark.sql.column 

# COMMAND ----------

dbutils.widgets.text("PAR_DB_INPUT_ACCOUNT_NAME","",label="PAR_DB_INPUT_ACCOUNT_NAME")
dbutils.widgets.text("PAR_DB_INPUT_PATH","",label="PAR_DB_INPUT_PATH")
dbutils.widgets.text("PAR_DB_OUTPUT_PATH","",label="PAR_DB_OUTPUT_PATH")
dbutils.widgets.text("PAR_DB_DELIMITER","",label="PAR_DB_DELIMITER")
dbutils.widgets.text("PAR_DB_PROJ_NAME","",label="PAR_DB_PROJ_NAME")
dbutils.widgets.text("PAR_DB_SRC_STREAM_NAME","",label="PAR_DB_SRC_STREAM_NAME")
dbutils.widgets.text("PAR_DB_BATCH_ID","",label="PAR_DB_BATCH_ID")
dbutils.widgets.text("PAR_DB_PSET_FILE_NAME","",label="PAR_DB_PSET_FILE_NAME")
dbutils.widgets.text("PAR_DB_TABLE_NAME","",label="PAR_DB_TABLE_NAME")
dbutils.widgets.text("PAR_DB_EXTR_DTTM","",label="PAR_DB_EXTR_DTTM")

adlsInputAccountName=dbutils.widgets.get("PAR_DB_INPUT_ACCOUNT_NAME")
adlsInputFolderPath=dbutils.widgets.get("PAR_DB_INPUT_PATH")
adlsOutputFolderPath=dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
adlsProjectName=dbutils.widgets.get("PAR_DB_PROJ_NAME")
adlsSrcStreamName=dbutils.widgets.get("PAR_DB_SRC_STREAM_NAME")
adlsBatchId=dbutils.widgets.get("PAR_DB_BATCH_ID")
adlsPsetFileName=dbutils.widgets.get("PAR_DB_PSET_FILE_NAME")
adlsTableName=dbutils.widgets.get("PAR_DB_TABLE_NAME")
adlsExtrDttm=dbutils.widgets.get("PAR_DB_EXTR_DTTM")
delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')

# COMMAND ----------

# Load File

#df = spark.read.format("csv")\
     # .option("header", False)\
     # .option("delimiter",delimiter)\
     # .load('dbfs:/mnt/'+adlsInputContainerName+'/'+adlsInputFolderPath+'/')
# Load File Parquet

df = spark.read.parquet(mountPoint + "/" + dbutils.widgets.get("PAR_DB_INPUT_PATH"))
display(df)

# COMMAND ----------

dfNew = spark.createDataFrame([(df.count(), adlsProjectName, adlsSrcStreamName,adlsBatchId,adlsPsetFileName,adlsTableName,adlsExtrDttm[0:19],adlsOutputFolderPath[adlsOutputFolderPath.rindex('/')+1:len(adlsOutputFolderPath)],datetime.datetime.now())], ['extract_record_cnt', 'proj_name', 'src_stream_name','edw_batch_id','pset_name','extract_table_name','extract_dttm','extract_file_name','extract_create_dt'])
display(dfNew)

# COMMAND ----------

dfNew.show()

# COMMAND ----------

# OUTF_LDR - Target Load Ready
#dfNew.createOrReplaceGlobalTempView("dfNew")
file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("PAR_DB_OUTPUT_PATH"),dbutils.widgets.get("PAR_DB_BATCH_ID"))
print(file_path)


#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 120, {"file_path": file_path  , "view_name": "dfNew"})

dfNew.write.format("parquet").mode("overwrite").save(file_path)

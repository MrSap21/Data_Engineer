# Databricks notebook source
import os
import json

# Mounting ADLS
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

#dbutils.widgets.text("PAR_NB_SCRIPT_PATH", "")
#dbutils.widgets.text("PAR_NB_BATCH_ID", "")

# Defining Pipeline Parameters
#PAR_NB_SCRIPT_PATH=dbutils.widgets.get("PAR_NB_SCRIPT_PATH")
#Domain=PAR_NB_SCRIPT_PATH.split("/")[1]

#os.environ['scriptPath'] =scriptPath=  "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_SCRIPT_PATH") 

#os.environ['scriptName'] = dbutils.widgets.get("PAR_NB_SCRIPT_NAME")
os.environ['batchId'] = dbutils.widgets.get("PAR_NB_BATCH_ID")
AI_LOAD=AI_PERSIST_SERIAL = mountPoint + "/" + "retail/retail_sales/staging"


# COMMAND ----------


df = spark.read.text(AI_PERSIST_SERIAL +"/" + "run_sales_type_date_file")
RUN_DATE = df.collect()[0][0]

from datetime import datetime,timedelta

NDATE = datetime.strptime(RUN_DATE,'%Y%m%d').date() + timedelta(1)
NEXT_DATE=str(NDATE).replace('-','')
NDATE1 = datetime.strptime(RUN_DATE,'%Y%m%d').date() - timedelta(1)
NEXT_DATE_1=str(NDATE1).replace('-','')
RDATE3 = datetime.strptime(RUN_DATE,'%Y%m%d').date() + timedelta(3)
RUN_DATE_3=str(RDATE3).replace('-','')




# COMMAND ----------

#%sh
#pushd $scriptPath
#sh $scriptPath/$scriptName 
dbutils.notebook.exit([RUN_DATE,NEXT_DATE,RUN_DATE_3])
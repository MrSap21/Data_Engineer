# Databricks notebook source
import os
import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters

os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_INPUT_PATH")
os.environ['inputfile'] = dbutils.widgets.get("PAR_NB_INPUTFILE_NAME")
os.environ['inputfile_1'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_INPUTFILE_NAME_1")

#os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("inputPath")
#os.environ['logPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("logPath")
#os.environ['inputfile_1'] = dbutils.widgets.get("inputfile_1")
#os.environ['inputfile'] = dbutils.widgets.get("inputfile")
 

# COMMAND ----------

# MAGIC %sh
# MAGIC AI_MFS=$inputPath
# MAGIC INPUTFILENAME=$inputfile.dat
# MAGIC INPUTFILENAME_1=$inputfile_1.dat.new
# MAGIC #touch $AI_MFS/$INPUTFILENAME
# MAGIC rm -r $AI_MFS/$INPUTFILENAME
# MAGIC mv $AI_MFS/$INPUTFILENAME_1 $AI_MFS/$INPUTFILENAME

# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

'''
dbutils.widgets.text("PAR_DB_BATCH_ID","20220119045142")
dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
dbutils.widgets.text("PAR_POSINTERM_INFILE","pos_interm") #Input in File
dbutils.widgets.text("PAR_DECODEWVALUELKP_FILE","Int_DF7_DF8_DF11_decode_w_value_lookup") #Lookup File
dbutils.widgets.text("PAR_DECODEWNAMELKP_FILE","Int_DF7_DF8_decode_w_name_lookup") #Lookup File
dbutils.widgets.text("PAR_UPCSPECIFICLKP_FILE","upc_specific_lookup.tab_delim") #Lookup File
dbutils.widgets.text("PAR_UPCLKPFORPHOTO_FILE","upc_lookup_for_photo") #Lookup File
dbutils.widgets.text("PAR_PAYOUTLKP_FILE","pos_payout_lookup.dat") #Lookup File
dbutils.widgets.text("PAR_EMPJOBEJLKP_FILE","employee_job_ej_lookup") #Lookup File
dbutils.widgets.text("PAR_POSTAXINSERTASCIIPIPEDELIM_FILE","pos_tax_insert_ascii") #O/P File
dbutils.widgets.text("PAR_POSTENDERORGINSERTASCIIPIPEDELIM_FILE","pos_tender_org_insert_ascii") #O/P File
dbutils.widgets.text("PAR_POSRETURNSRECEIPTINSERTASCIIPIPEDELIM_FILE","pos_returns_receipt_insert_ascii") #O/P File
dbutils.widgets.text("PAR_POSRXCUSTOMERINSERTASCIIPIPEDELIM_FILE","pos_rx_customer_insert_ascii") #O/P File
dbutils.widgets.text("PAR_REDEFINEFORMATRECORDTYPEPARSINGTMP_FILE","INT_DF8_Redefine_Format_Record_Type_Parsing2") #O/P File
dbutils.widgets.text("PAR_REFORMATRECAPARSERTMP_FILE","INT_DF8_DF9_Reformat_Rec_A_Parser") #O/P File'''


# COMMAND ----------

#Detail Parser
from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark.sql.types import *

#retrieving input values from widget parameters
Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
PosInterm_INFile = dbutils.widgets.get("PAR_POSINTERM_INFILE")
DecodeWVal_LKPFile = dbutils.widgets.get("PAR_DECODEWVALUELKP_FILE")
DecodeWName_LKPFile = dbutils.widgets.get("PAR_DECODEWNAMELKP_FILE")
UpcSpecific_LKPFile = dbutils.widgets.get("PAR_UPCSPECIFICLKP_FILE")
UpcLkpForPhoto_LKPFile = dbutils.widgets.get("PAR_UPCLKPFORPHOTO_FILE")
PayOut_LKPFile = dbutils.widgets.get("PAR_PAYOUTLKP_FILE")
EmpJobEJ_LKPFile = dbutils.widgets.get("PAR_EMPJOBEJLKP_FILE")
PosTaxInsAscii_OUTFile = dbutils.widgets.get("PAR_POSTAXINSERTASCIIPIPEDELIM_FILE")
PosTenderOrg_OUTFile = dbutils.widgets.get("PAR_POSTENDERORGINSERTASCIIPIPEDELIM_FILE")
PosReturnsReceipt_OUTFile = dbutils.widgets.get("PAR_POSRETURNSRECEIPTINSERTASCIIPIPEDELIM_FILE")
PosRxCustomer_OUTFile = dbutils.widgets.get("PAR_POSRXCUSTOMERINSERTASCIIPIPEDELIM_FILE")
RedefineFormatRecod_OUTFile = dbutils.widgets.get("PAR_REDEFINEFORMATRECORDTYPEPARSINGTMP_FILE")
ReformatRecAParser_INTFile = dbutils.widgets.get("PAR_REFORMATRECAPARSERTMP_FILE")

# COMMAND ----------

#Detail Parser

from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark.sql.types import *

#Reading Interm File
pos_intermDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+PosInterm_INFile)

#Record Type B

rec_typeBDF = pos_intermDF.filter(col("rcd_type") == "B")

rec_typeBDF = rec_typeBDF.withColumn("txn_id", col("txn_cntr").cast('bigint').cast('string')) \
                          .withColumn("txn_dt", date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyy-MM-dd')) \
                          .withColumn("tax_type", col("rec_type_B_tax_cde")) \
                          .withColumn("tax_dlrs", concat(col("rec_type_B_price_sign"), trim(col("rec_type_B_tax_amt")))) \
                          .withColumn("tax_desc", trim(col("rec_type_B_tax_tbl_desc"))) \
                          .withColumn("tax_seq_nbr", col("seq_nbr_by_rec_type")) \
                          .withColumn("loc_id", col("loc_id")).select("txn_id","txn_dt","tax_type","tax_dlrs","tax_desc","tax_seq_nbr",trim("loc_id").alias("loc_id"))
#rec_typeBDF.count()
rec_typeBDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PosTaxInsAscii_OUTFile)


# COMMAND ----------

#Record Type C

rec_typeCDF = pos_intermDF.filter(col("rcd_type") == "C")

rec_typeCDF = rec_typeCDF.withColumn("local_tndr_name", when(ltrim(rtrim(col("rec_type_C_p1_tndr_desc"))) == "CHECK", ltrim(rtrim(col("rec_type_C_p1_tndr_desc")))) \
                                     .when(ltrim(rtrim(col("rec_type_C_p1_tndr_desc"))) == "ACH", "ACH CHECK")\
                                     .otherwise(ltrim(rtrim(concat(col("rec_type_C_p1_tndr_desc"), col("rec_type_C_not_check_p2_tndr_desc"))))))\
                         .withColumn("local_entry_mode",when((col("local_tndr_name") == "CHECK") | (col("local_tndr_name") == "ACH CHECK"), None)\
                                     .otherwise(col("rec_type_C_not_check_entry_mode_new")))\
                         .withColumn("local_acct_nbr",when((col("local_tndr_name") == "CHECK") | (col("local_tndr_name") == "ACH CHECK"),\
                                                           trim(regexp_replace(col("rec_type_C_check_chk_info"), '[:][0-9| ]+', '')))\
                                     .otherwise(trim(col("rec_type_C_not_check_acct_nbr"))))\
                         .withColumn("local_ck_nbr",when((col("local_tndr_name") == "CHECK") | (col("local_tndr_name") == "ACH CHECK"), \
                                                           trim(regexp_replace(col("rec_type_C_check_chk_info"), '[0-9]+:', '')))\
                                     .otherwise(None))\
                         .withColumn("local_card_token_val",when((col("local_tndr_name") != "CHECK") | (col("local_tndr_name") != "ACH CHECK"),\
                                                            rtrim(ltrim(col("rec_type_C_not_check_unused2")))))\
                         .withColumn("local_entry_mode_name", when((col("local_entry_mode").isNull()) | (col("local_entry_mode") == ''),None)\
                                                             .when(col("local_entry_mode") == "B", "Biometric")\
                                                             .when(col("local_entry_mode") == "E", "Express")\
                                                             .when(col("local_entry_mode") == "K", "Keyed")\
                                                             .when(col("local_entry_mode") == "S", "Swiped")\
                                                             .otherwise(col("local_entry_mode")))
                                     
DecodeWName_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+DecodeWName_LKPFile) 

DecodeWNameTenderTyp_DF = DecodeWName_DF.filter(col("cd_type") == "TENDER_TYPE")

rec_typeCDFJoinDecodeWName = rec_typeCDF.join(DecodeWNameTenderTyp_DF.alias("DecodeWName_DF"), on=[DecodeWName_DF.cd_name == col("local_tndr_name")],how="left_outer").withColumn("tndr_type_cd",DecodeWName_DF.cd_id)

rec_typeCDFJoinDecodeWNameNotNull = rec_typeCDFJoinDecodeWName.filter(col("cd_name").isNotNull())

rec_typeCDFJoinDecodeWNameNull = rec_typeCDFJoinDecodeWName.filter(col("cd_name").isNull()).drop("cd_id","cd_type","cd_value","cd_name","cd_desc").join(DecodeWNameTenderTyp_DF.alias("DecodeWName_DF"), on=[col("DecodeWName_DF.cd_name") == "NOT TENDER TYPE"],how="left_outer").withColumn("tndr_type_cd",col("DecodeWName_DF.cd_id"))

union_tndr_type_cd_df = rec_typeCDFJoinDecodeWNameNotNull.union(rec_typeCDFJoinDecodeWNameNull).select("txn_cntr","txn_date","seq_nbr_by_rec_type","loc_id","rec_type_C_not_check_unused3","local_tndr_name","rec_type_C_check_prc_sign","rec_type_C_check_selling_prc","rec_type_C_not_check_prc_sign","rec_type_C_not_check_selling_prc","local_acct_nbr","local_card_token_val","local_ck_nbr","rec_type_C_check_routing_nbr","rec_type_C_not_check_expire_dte","local_entry_mode_name","tndr_type_cd")

DecodeWNameTenderEntry_DF = DecodeWName_DF.filter(col("cd_type") == "TENDER_ENTRY_MODE")

rec_typeCDFJoinDecodeWName = union_tndr_type_cd_df.join(DecodeWNameTenderEntry_DF.alias("DecodeWName_DF"), on=[col("DecodeWName_DF.cd_name") == col("local_entry_mode_name")],how="left_outer").withColumn("entry_mode_cd",col("DecodeWName_DF.cd_id"))

rec_typeCDFJoinDecodeWNameNotNull = rec_typeCDFJoinDecodeWName.filter(col("DecodeWName_DF.cd_name").isNotNull()).select('txn_cntr','txn_date','seq_nbr_by_rec_type','loc_id','rec_type_C_not_check_unused3','local_tndr_name','rec_type_C_check_prc_sign','rec_type_C_check_selling_prc','rec_type_C_not_check_prc_sign','rec_type_C_not_check_selling_prc','local_acct_nbr','local_card_token_val','local_ck_nbr','rec_type_C_check_routing_nbr','rec_type_C_not_check_expire_dte','local_entry_mode_name','tndr_type_cd','entry_mode_cd','cd_id','cd_type','cd_value','cd_name','cd_desc')

rec_typeCDFJoinDecodeWNameNull = rec_typeCDFJoinDecodeWName.filter(col("cd_name").isNull()).drop("cd_id","cd_type","cd_value","cd_name","cd_desc").join(DecodeWNameTenderEntry_DF.alias("DecodeWName_DF"), on=[col("DecodeWName_DF.cd_name") == "NOT TNDR ENTRY MODE"],how="left_outer").withColumn("entry_mode_cd",col("DecodeWName_DF.cd_id")).select('txn_cntr','txn_date','seq_nbr_by_rec_type','loc_id','rec_type_C_not_check_unused3','local_tndr_name','rec_type_C_check_prc_sign','rec_type_C_check_selling_prc','rec_type_C_not_check_prc_sign','rec_type_C_not_check_selling_prc','local_acct_nbr','local_card_token_val','local_ck_nbr','rec_type_C_check_routing_nbr','rec_type_C_not_check_expire_dte','local_entry_mode_name','tndr_type_cd','entry_mode_cd','cd_id','cd_type','cd_value','cd_name','cd_desc')

union_entry_mode_df = rec_typeCDFJoinDecodeWNameNotNull.union(rec_typeCDFJoinDecodeWNameNull)
  
df_final = union_entry_mode_df.withColumn("txn_id", col("txn_cntr")) \
                          .withColumn("txn_dt", date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyy-MM-dd')) \
                          .withColumn("tndr_seq_nbr", col("seq_nbr_by_rec_type")) \
                          .withColumn("loc_id", trim(col("loc_id"))) \
                          .withColumn("sequence_nbr", col("rec_type_C_not_check_unused3")) \
                          .withColumn("tndr_dlrs",when((col("local_tndr_name") == "CHECK") | (col("local_tndr_name") == "ACH CHECK"),concat(col("rec_type_C_check_prc_sign"), ltrim(col("rec_type_C_check_selling_prc")))).otherwise(concat(col("rec_type_C_not_check_prc_sign"), ltrim(col("rec_type_C_not_check_selling_prc"))))) \
                          .withColumn("acct_nbr",col("local_acct_nbr")) \
                          .withColumn("card_token_val",col("local_card_token_val")) \
                          .withColumn("ck_nbr",col("local_ck_nbr")) \
                          .withColumn("ck_bank_route_nbr",when((col("local_tndr_name") == "CHECK") | (col("local_tndr_name") == "ACH CHECK") & (col("rec_type_C_check_routing_nbr").rlike('^\d*[.]\d*$') == True),col("rec_type_C_check_routing_nbr")).otherwise(None)) \
                          .withColumn("expire_dt",when((col("local_tndr_name") == "CHECK") | (col("local_tndr_name") == "ACH CHECK") ,"").otherwise(col("rec_type_C_not_check_expire_dte"))).select("txn_id","txn_dt","tndr_type_cd","tndr_dlrs","tndr_seq_nbr","entry_mode_cd","acct_nbr","card_token_val","ck_bank_route_nbr","ck_nbr","expire_dt","loc_id","sequence_nbr")

df_final.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PosTenderOrg_OUTFile)

# COMMAND ----------

#Record Type E

rec_typeE0006DF = pos_intermDF.filter((col("rcd_type") == "E") & (col("rec_type_E_rcrd_sub_type") == "0006"))

DecodeWValLkp_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+DecodeWVal_LKPFile)

joinTypeEDecodeWVal_DF = rec_typeE0006DF.join(DecodeWValLkp_DF, on=[DecodeWValLkp_DF.cd_type=="REFUND_STATUS",DecodeWValLkp_DF.cd_value==rec_typeE0006DF.rec_type_E_sub_typ_6_refund_status],how = 'left_outer').withColumn("return_status_cd", DecodeWValLkp_DF.cd_id).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id",trim("loc_id").alias("loc_id"),"txn_start_dttm","return_status_cd")

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.join(DecodeWValLkp_DF, on=[DecodeWValLkp_DF.cd_type=="REFUND_REASON",DecodeWValLkp_DF.cd_value==joinTypeEDecodeWVal_DF.rec_type_E_sub_typ_6_refund_rsn],how = 'left_outer').withColumn("return_reason_cd", col("cd_id")).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id","loc_id","txn_start_dttm","return_status_cd","return_reason_cd")

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.join(DecodeWValLkp_DF, on=[DecodeWValLkp_DF.cd_type=="TENDER_TYPE",DecodeWValLkp_DF.cd_value==joinTypeEDecodeWVal_DF.rec_type_E_sub_typ_6_orig_tndr],how = 'left_outer').withColumn("orig_tndr_type_cd",col("cd_id")).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id","loc_id","txn_start_dttm","return_status_cd","return_reason_cd","orig_tndr_type_cd")

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.join(DecodeWValLkp_DF, on=[DecodeWValLkp_DF.cd_type=="REGISTER_LOCATION",DecodeWValLkp_DF.cd_value==joinTypeEDecodeWVal_DF.rec_type_E_sub_typ_6_register_loc],how = 'left_outer').withColumn("register_loc_cd",when((col("cd_id") !="") & (col("cd_id").isNotNull()), col("cd_id")).otherwise(lit('0'))).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id","loc_id","txn_start_dttm","return_status_cd","return_reason_cd","orig_tndr_type_cd","register_loc_cd")

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.join(DecodeWValLkp_DF, on=[DecodeWValLkp_DF.cd_type=="RECEIPT_ENTRY_MODE",DecodeWValLkp_DF.cd_value==joinTypeEDecodeWVal_DF.rec_type_E_sub_typ_6_rcpt_entry],how = 'left_outer').withColumn("receipt_entry_cd",col("cd_id")).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id","loc_id","txn_start_dttm","return_status_cd","return_reason_cd","orig_tndr_type_cd","register_loc_cd","receipt_entry_cd")

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.join(DecodeWValLkp_DF, on=[DecodeWValLkp_DF.cd_type=="TANDEM_STATUS",DecodeWValLkp_DF.cd_value==joinTypeEDecodeWVal_DF.rec_type_E_sub_typ_6_tandem_stat],how = 'left_outer').withColumn("tandem_status_cd",col("cd_id")).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id","loc_id","txn_start_dttm","return_status_cd","return_reason_cd","orig_tndr_type_cd","register_loc_cd","receipt_entry_cd","tandem_status_cd")

EmpJobEJ_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+EmpJobEJ_LKPFile)

#/* Extra transformation */
w = Window.partitionBy('loc_id','cashier_nbr')
EmpJobEJ_DF = EmpJobEJ_DF.withColumn('maxStartDttm', max('cashier_nbr_start_dttm').over(w))\
    .where(col('cashier_nbr_start_dttm') == col('maxStartDttm'))\
    .drop('maxStartDttm')\

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.join(EmpJobEJ_DF, on=[(EmpJobEJ_DF.loc_id==joinTypeEDecodeWVal_DF.loc_id) & (EmpJobEJ_DF.cashier_nbr.cast(IntegerType())==joinTypeEDecodeWVal_DF.rec_type_E_sub_typ_6_mgr_id.cast(IntegerType())) & (col("txn_start_dttm").between(EmpJobEJ_DF.cashier_nbr_start_dttm,EmpJobEJ_DF.cashier_nbr_end_dttm) )],how = 'left_outer').withColumn("mgr_employee_id",col("employee_id")).select("txn_cntr","txn_date","return_status_cd","rec_type_E_sub_typ_6_refund_rsn","rec_type_E_sub_typ_6_refund_amt","rec_type_E_sub_typ_6_orig_txn_nbr","rec_type_E_sub_typ_6_orig_str","rec_type_E_sub_typ_6_orig_register","rec_type_E_sub_typ_6_orig_trans_amt","rec_type_E_sub_typ_6_orig_dte","rec_type_E_sub_typ_6_orig_tndr","rec_type_E_sub_typ_6_register_loc","rec_type_E_sub_typ_6_rcpt_entry","rec_type_E_sub_typ_6_tandem_stat","rec_type_E_sub_typ_6_mgr_id",joinTypeEDecodeWVal_DF.loc_id,joinTypeEDecodeWVal_DF.txn_start_dttm,"return_status_cd","return_reason_cd","orig_tndr_type_cd","receipt_entry_cd","register_loc_cd","tandem_status_cd","mgr_employee_id")

joinTypeEDecodeWVal_DF = joinTypeEDecodeWVal_DF.withColumn("txn_id", col("txn_cntr").cast('bigint').cast('string')) \
                          .withColumn("txn_dt", date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyy-MM-dd')) \
                          .withColumn("return_dlrs", col("rec_type_E_sub_typ_6_refund_amt")/100) \
                          .withColumn("orig_txn_nbr", trim(col("rec_type_E_sub_typ_6_orig_txn_nbr"))) \
                          .withColumn("orig_str_nbr", col("rec_type_E_sub_typ_6_orig_str")) \
                          .withColumn("orig_register_nbr", col("rec_type_E_sub_typ_6_orig_register")) \
                          .withColumn("orig_txn_dlrs", col("rec_type_E_sub_typ_6_orig_trans_amt")/100) \
                          .withColumn("orig_txn_dt",  date_format(to_date(col("rec_type_E_sub_typ_6_orig_dte"),'yyMMdd'),'yyyy-MM-dd')) \
                          .withColumn("mgr_cashier_nbr", col("rec_type_E_sub_typ_6_mgr_id")) \
.select("txn_id","txn_dt","return_status_cd","return_reason_cd","return_dlrs","orig_txn_nbr","orig_str_nbr","orig_register_nbr","orig_txn_dt","orig_txn_dlrs","orig_tndr_type_cd","register_loc_cd","receipt_entry_cd","tandem_status_cd","mgr_cashier_nbr","mgr_employee_id",trim("loc_id").alias("loc_id"))

joinTypeEDecodeWVal_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PosReturnsReceipt_OUTFile)

# COMMAND ----------

#Record Type A

rec_typeADF = pos_intermDF.filter(col("rcd_type") == "A")

rec_typeADF = rec_typeADF.withColumn("txn_id", col("txn_cntr")) \
                          .withColumn("loc_id", col("loc_id")) \
                          .withColumn("line_item_seq_nbr", col("seq_nbr_by_rec_type")) \
                          .withColumn("per_id", col("per_id")) \
                          .withColumn("upc_desc", ltrim(rtrim(regexp_replace(col('rec_type_A_desc_acct_nbr'), '\\"|\\$|\\!|\\#|\\%|\\�', '')))) \
                          .withColumn("item_unit_price_dlrs", when((col("rec_type_A_item_unit_price") > 0) | (col("rec_type_A_item_unit_price") < 0),(col("rec_type_A_item_unit_price")/100)).otherwise(lit(0.00))) \
                          .withColumn("original_price_dlrs", when((col("rec_type_A_item_unit_price") > 0) | (col("rec_type_A_item_unit_price") < 0),(col("rec_type_A_item_unit_price")/100) * col("rec_type_A_qty")).otherwise(lit(0.00))) \
                          .withColumn("selling_price_dlrs", concat(col("rec_type_A_price_sign"), ltrim(col("rec_type_A_selling_price")))) \
                          .withColumn("tax_type_cd", col("rec_type_A_tax_type")) \
                          .withColumn("unit_qty", when((trim(col("rec_type_A_qty")) != '') & (col("rec_type_A_qty").isNotNull()),trim(col("rec_type_A_qty"))).otherwise(0)) \
                          .withColumn("txn_dt", date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyy-MM-dd')) \
                          .withColumn("rx_nbr", col("rec_type_A_rx_nbr")) \
                          .withColumn("dept_nbr", when(((col("rec_type_A_dept_nbr") != "") & (col("rec_type_A_dept_nbr").isNotNull()) & (col("rec_type_A_dept_nbr") <= 300)),col("rec_type_A_dept_nbr")).otherwise(None)) \
                          .withColumn("ecomm_order_ind", col("rec_type_A_ecomm_order_ind")) \
                          .withColumn("ecomm_order_nbr", col("rec_type_A_ecomm_order_nbr")) \
                          .withColumn("tax_exempt_ind", col("rec_type_A_tax_exempt_ind")) \
                          .withColumn("tax_exempt_id", ltrim(rtrim(col("rec_type_A_tax_exempt_id")))) \
                          .withColumn("birth_date", when(trim(col("rec_type_A_birthday")) != '', col("rec_type_A_birthday"))) \
                          .withColumn("fsa_item_ind", when(((col("rec_type_A_special") == 'F') & ((col("rec_type_A_desc_acct_nbr") != "MFG COUPON") | (col("rec_type_A_price_sign") != "-"))),lit("Y")).otherwise("N")) \
                          .withColumn("rx_not_on_ic_ind", col("rec_type_A_rx_not_on_ic_ind")) \
                          .withColumn("price_verify_ind", when(((trim(col("rec_type_A_prc_verify")) != '') & (col("rec_type_A_prc_verify").isNotNull()) & (col("rec_type_A_prc_verify") != "W")),lit("Y")).otherwise("N")) \
                          .withColumn("return_ind", when(((trim(col("rec_type_A_retrnd_item")) != '') & (col("rec_type_A_retrnd_item").isNotNull()) ),lit("Y")).otherwise("N")) \
                          .withColumn("sale_ind", when(((trim(col("rec_type_A_sale_ind")) != '') & (col("rec_type_A_sale_ind").isNotNull()) ),lit("Y")).otherwise("N")) \
                          .withColumn("regstr_key_nbr", when((col("rec_type_A_dept_nbr") >= 301) & (col("rec_type_A_dept_nbr") <= 320), col("rec_type_A_dept_nbr")).otherwise(None)) \
                          .withColumn("walgreen_brand_ind",  when(((col("rec_type_A_prc_verify") != '') & (col("rec_type_A_prc_verify").isNotNull()) & (col("rec_type_A_prc_verify") == 'W')),lit("Y")).otherwise("N"))
                                      
customschema = StructType([
StructField("non_item_entry", StringType(), True)
,StructField("local_upc_nbr", DecimalType(), True)
])

UpcSpecificLkp_DF = spark.read.format("csv").option('sep', '|').schema(customschema).load(mountPoint+"/"+Lookup_Folder+"/"+UpcSpecific_LKPFile)

rec_typeADF = rec_typeADF.join(UpcSpecificLkp_DF, on=[UpcSpecificLkp_DF.non_item_entry==rtrim(ltrim(rec_typeADF.rec_type_A_upc_tndr))],how='left_outer').withColumn("upc_nbr", when(rtrim(ltrim(col("rec_type_A_upc_tndr"))).rlike('^[0-9]*$'),col("rec_type_A_upc_tndr")) \
.when(col("non_item_entry").isNotNull(),col("local_upc_nbr")) \
.when((col("rec_type_A_keyed_item") == 'K') & (rtrim(ltrim(col("rec_type_A_desc_acct_nbr"))) =='MFG COUPON'), lit("-2")) \
.when((rtrim(ltrim(col("rec_type_A_desc_acct_nbr"))) =='MFG COUPON') & (col("rec_type_A_keyed_item") == ' '),lit("-5")) \
.otherwise(lit("-2")))

# Defined DecodeWValLkp_DF in record type E

DecodeWValAge_DF = DecodeWValLkp_DF.filter(col("cd_type") == "AGE")
DecodeWValAgeDefault_DF = DecodeWValAge_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADF.join(DecodeWValAge_DF.alias("DecodeWValAge_DF"), on=[DecodeWValAge_DF.cd_value == col("rec_type_A_overage_ind")],how="left_outer").withColumn("over_age_cd",when(DecodeWValAge_DF.cd_value.isNotNull(),DecodeWValAge_DF.cd_id).otherwise(DecodeWValAgeDefault_DF)) 

DecodeWValWagCoup_DF = DecodeWValLkp_DF.filter(col("cd_type") == "WAG_COUPON")
DecodeWValWagCoupDefault_DF = DecodeWValWagCoup_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.alias("rec_typeADFJoinDecodeWVal").join(DecodeWValWagCoup_DF.alias("DecodeWValWagCoup_DF"), on=[col("DecodeWValWagCoup_DF.cd_value") == col("rec_typeADFJoinDecodeWVal.rec_type_A_wag_cpn")],how="left_outer").withColumn("wag_coup_cd",when((col("DecodeWValWagCoup_DF.cd_value").isNotNull()) & (col("rec_typeADFJoinDecodeWVal.rec_type_A_wag_cpn") != '') &(col("rec_typeADFJoinDecodeWVal.rec_type_A_wag_cpn").isNotNull()),col("DecodeWValWagCoup_DF.cd_id")).otherwise(DecodeWValWagCoupDefault_DF)) 

DecodeWValMFGCoup_DF = DecodeWValLkp_DF.filter((col("cd_type") == "MFG_COUPON") & (col("cd_value") == "O")).collect()[0]["cd_id"]
DecodeWValDMFGCoup_DF = DecodeWValLkp_DF.filter((col("cd_type") == "D MFG_COUPON") & (col("cd_value") == "D")).collect()[0]["cd_id"]
DecodeWValDEPPMFGCoup_DF = DecodeWValLkp_DF.filter((col("cd_type") == "D_EPP_MFGCPN") & (col("cd_value") == "D")).collect()[0]["cd_id"]
DecodeWValMFGCoupDef_DF = DecodeWValLkp_DF.filter((col("cd_type") == "MFG_COUPON") & (col("cd_value") == "--")).collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.withColumn("mfg_coup_cd",when( (col("rec_type_A_special") == "O") | ((col("rec_type_A_special") == "F") & (ltrim(rtrim(col("rec_type_A_desc_acct_nbr")))=="MFG COUPON")  & (col("rec_type_A_price_sign")=="-")), DecodeWValMFGCoup_DF).otherwise(when( (col("rec_type_A_special") == "D") | ((col("rec_type_A_special") == "F") & (ltrim(rtrim(col("rec_type_A_desc_acct_nbr")))=="D MFG COUPON")  & (col("rec_type_A_price_sign")=="-")), DecodeWValDMFGCoup_DF).otherwise(when((col("rec_type_A_special") == "P") | ((col("rec_type_A_special") == "F") & (ltrim(rtrim(col("rec_type_A_desc_acct_nbr")))=="D EPP MFGCPN")  & (col("rec_type_A_price_sign")=="-")), DecodeWValDEPPMFGCoup_DF).otherwise(DecodeWValMFGCoupDef_DF))))
  
DecodeWValDiscnt_DF = DecodeWValLkp_DF.filter(col("cd_type") == "TXN_DTL_DISCNT_CD")
DecodeWValDiscntDefault_DF = DecodeWValDiscnt_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.join(DecodeWValDiscnt_DF.alias("DecodeWValDiscnt_DF"), on=[col("DecodeWValDiscnt_DF.cd_value") == col("rec_type_A_emp_disc")],how="left_outer").withColumn("discnt_cd",when((col("DecodeWValDiscnt_DF.cd_value").isNotNull()) & (col("rec_typeADFJoinDecodeWVal.rec_type_A_emp_disc") != '') &(col("rec_typeADFJoinDecodeWVal.rec_type_A_emp_disc").isNotNull()),col("DecodeWValDiscnt_DF.cd_id")).otherwise(DecodeWValDiscntDefault_DF))

DecodeWValRX_DF = DecodeWValLkp_DF.filter(col("cd_type") == "RX")
DecodeWValRXDefault_DF = DecodeWValRX_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.join(DecodeWValRX_DF.alias("DecodeWValRX_DF"), on=[col("DecodeWValRX_DF.cd_value") == col("rec_type_A_RX_ind")],how="left_outer").withColumn("rx_type_cd",when((col("DecodeWValRX_DF.cd_value").isNotNull()) & (col("rec_typeADFJoinDecodeWVal.rec_type_A_RX_ind") != '') &(col("rec_typeADFJoinDecodeWVal.rec_type_A_RX_ind").isNotNull()),col("DecodeWValRX_DF.cd_id")).otherwise(DecodeWValRXDefault_DF))

DecodeWValItemVoid_DF = DecodeWValLkp_DF.filter(col("cd_type") == "LINE_VOID")
DecodeWValItemVoiDefault_DF = DecodeWValItemVoid_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.join(DecodeWValItemVoid_DF.alias("DecodeWValItemVoid_DF"), on=[col("DecodeWValItemVoid_DF.cd_value") == rtrim(ltrim(col("rec_type_A_voided_ind")))],how="left_outer").withColumn("item_void_cd",when(col("DecodeWValItemVoid_DF.cd_value").isNotNull(),col("DecodeWValItemVoid_DF.cd_id")).otherwise(DecodeWValItemVoiDefault_DF))

DecodeWValPriceMod_DF = DecodeWValLkp_DF.filter(col("cd_type") == "PRICE_MODIFY")
DecodeWValPriceModDefault_DF = DecodeWValPriceMod_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.join(DecodeWValPriceMod_DF.alias("DecodeWValPriceMod_DF"), on=[col("DecodeWValPriceMod_DF.cd_value") == col("rec_type_A_prc_modify")],how="left_outer").withColumn("price_modify_cd",when((col("DecodeWValPriceMod_DF.cd_value").isNotNull()) & (col("rec_typeADFJoinDecodeWVal.rec_type_A_prc_modify") != '') &(col("rec_typeADFJoinDecodeWVal.rec_type_A_prc_modify").isNotNull()),col("DecodeWValPriceMod_DF.cd_id")).otherwise(DecodeWValPriceModDefault_DF))


DecodeWValUPCHard_DF = DecodeWValLkp_DF.filter(col("cd_type") == "ITEM_ENTRY_MODE")
DecodeWValUPCHardDefault_DF = DecodeWValUPCHard_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.join(DecodeWValUPCHard_DF.alias("DecodeWValUPCHard_DF"), on=[col("DecodeWValUPCHard_DF.cd_value") == col("rec_type_A_keyed_item")],how="left_outer").withColumn("upc_hardkey_cd",when((col("DecodeWValUPCHard_DF.cd_value").isNotNull()) &(col("rec_typeADFJoinDecodeWVal.rec_type_A_keyed_item").isNotNull()),col("DecodeWValUPCHard_DF.cd_id")).otherwise(DecodeWValUPCHardDefault_DF))

DecodeWValDeptHard_DF = DecodeWValLkp_DF.filter(col("cd_type") == "DEPT_ENTRY_MODE")
DecodeWValDeptHardDefault_DF = DecodeWValDeptHard_DF.filter(col("cd_value") == "--").collect()[0]["cd_id"]

rec_typeADFJoinDecodeWVal = rec_typeADFJoinDecodeWVal.join(DecodeWValDeptHard_DF.alias("DecodeWValDeptHard_DF"), on=[ltrim(rtrim(col("DecodeWValDeptHard_DF.cd_value"))) == ltrim(rtrim(col("rec_type_A_dept_hardkey_ind")))],how="left_outer").withColumn("dept_hardkey_cd",when((col("DecodeWValDeptHard_DF.cd_value").isNotNull()) & (col("rec_typeADFJoinDecodeWVal.rec_type_A_dept_hardkey_ind") != '') &(col("rec_typeADFJoinDecodeWVal.rec_type_A_dept_hardkey_ind").isNotNull()),col("DecodeWValDeptHard_DF.cd_id")).otherwise(DecodeWValDeptHardDefault_DF))

customschema = StructType([
StructField("dept", StringType(), True)
,StructField("payout_acct_nbr", StringType(), True)
,StructField("desc", StringType(), True)
])

PayOutLKPFile_DF = spark.read.format("csv").option('sep', '|').schema(customschema).load(mountPoint+"/"+Lookup_Folder+"/"+PayOut_LKPFile)

rec_typeADFJoinPayOut = rec_typeADFJoinDecodeWVal.join(PayOutLKPFile_DF, PayOutLKPFile_DF.dept == rec_typeADFJoinDecodeWVal.rec_type_A_dept_nbr,"leftOuter").withColumn("payout_acct_nbr", when(col("rec_type_A_dept_nbr") > 320, when(col("payout_acct_nbr").isNotNull(),col("payout_acct_nbr")).otherwise(col("rec_type_A_dept_nbr"))).otherwise(None))

rec_UpcLkpForPhotoLKP_DF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+UpcLkpForPhoto_LKPFile)

rec_typeADFJoinPayOut = rec_typeADFJoinPayOut.join(rec_UpcLkpForPhotoLKP_DF.alias("rec_UpcLkpForPhotoLKP_DF"), col("rec_type_A_upc_tndr") == col("rec_UpcLkpForPhotoLKP_DF.upc_tndr"),"leftOuter").withColumn("photo_env_nbr", when((col("rec_type_A_desc_acct_nbr").rlike("HR.*[0-9]{8}") == True) | (col("rec_type_A_desc_acct_nbr").rlike("PHOTO.*[0-9]{8}") == True), substring(col("rec_type_A_desc_acct_nbr"),9,6)).otherwise(None))

rec_typeADFJoinPayOut = rec_typeADFJoinPayOut.join(rec_UpcLkpForPhotoLKP_DF, col("rec_type_A_upc_tndr") == col("rec_UpcLkpForPhotoLKP_DF.upc_tndr"),"leftOuter").withColumn("photo_print_cnt", when((col("rec_type_A_desc_acct_nbr").rlike("HR.*[0-9]{8} [0-9]{3}") == True) | (col("rec_type_A_desc_acct_nbr").rlike("PHOTO.*[0-9]{8} [0-9]{3}") == True), substring(col("rec_type_A_desc_acct_nbr"),16,3)).otherwise(None))

df_final = rec_typeADFJoinPayOut.select("txn_id","txn_dt","line_item_seq_nbr","per_id","upc_nbr","upc_desc","rx_nbr","item_unit_price_dlrs","original_price_dlrs","selling_price_dlrs","tax_type_cd","unit_qty","item_void_cd","dept_nbr","ecomm_order_ind","ecomm_order_nbr","tax_exempt_ind","tax_exempt_id","over_age_cd","birth_date","wag_coup_cd","mfg_coup_cd","discnt_cd","fsa_item_ind","rx_type_cd","rx_not_on_ic_ind","price_modify_cd","price_verify_ind","return_ind","sale_ind","upc_hardkey_cd","dept_hardkey_cd","regstr_key_nbr","payout_acct_nbr","loc_id","photo_env_nbr","photo_print_cnt","walgreen_brand_ind")

df_final.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+ReformatRecAParser_INTFile)

# COMMAND ----------

#Record Type E
rec_typeE0019DF = pos_intermDF.filter((col("rcd_type") == "E") & (col("rec_type_E_rcrd_sub_type") == "0019"))

#rec_typeE0019DF1 = rec_typeE0019DF.withColumn("valid_phone_nbr",when(col("rec_type_E_sub_typ_19_patient_phn_nbr").rlike("^[0-9]*$") == True,lit("1")).otherwise(lit("0")))

#Removing valid Ph number logic as it will always be encrypted

rec_typeE0019DF1 = rec_typeE0019DF.withColumn("valid_phone_nbr",lit("1"))

rec_typeE0019DF = rec_typeE0019DF1.filter(col("valid_phone_nbr") == "1")

#splitting on valid and invalid ph no
rec_typeE0019DF = rec_typeE0019DF.withColumn("txn_id", col("txn_cntr")) \
               .withColumn("txn_dt", date_format(to_date(col("txn_date"),'yyyyMMdd'),'yyyy-MM-dd')) \
               .withColumn("patient_id", ltrim(rtrim(col("rec_type_E_sub_typ_19_patient_id")))) \
               .withColumn("patient_phone_nbr", ltrim(rtrim(col("rec_type_E_sub_typ_19_patient_phn_nbr")))) \
               .withColumn("loc_id", col("loc_id")).select("txn_id","txn_dt","patient_id","patient_phone_nbr","loc_id")

#dropping duplicates

rec_typeE0019DF = rec_typeE0019DF.sort("txn_id","txn_dt","patient_id","patient_phone_nbr").drop_duplicates(["txn_id","txn_dt","patient_id","patient_phone_nbr"])

rec_typeE0019DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+PosRxCustomer_OUTFile)

#Writing to intermediate file for invalid records

rec_typeE0019InValidDF = rec_typeE0019DF1.filter(col("valid_phone_nbr") == "0")

rec_typeE0019InValidDF = rec_typeE0019InValidDF.withColumn("invalid_desc",lit("V6: E0019 invalid phone nbr")).select('txn_cntr','rec_in_txn_cntr','file_nbr','rec_in_file','partition_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','stuff','invalid_desc')
                                                           
rec_typeE0019InValidDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+RedefineFormatRecod_OUTFile)
                                  
# Databricks notebook source
# dbutils.widgets.text("PAR_NB_DIM_LOC_LKP", "retail/retail_sales/lookup/dim_location_ej_lookup_ascii")
# dbutils.widgets.text("PAR_NB_DIM_PERIOD_LKP", "retail/retail_sales/lookup/dim_period_lookup_ascii",)
# dbutils.widgets.text("PAR_NB_INPUT_FILE_INRV1PH2", "retail/retail_sales/staging/Int_DF2_DF5_not_older_than_14_days")
# dbutils.widgets.text("PAR_NB_INPUT_FILE_INRV2PH3", "retail/retail_sales/staging/Int_DF4_DF5_ecdw7111t_main_older_than_14_days_not_in_db")
# dbutils.widgets.text("PAR_NB_POSEJ_ERR_QUEUE", "retail/retail_sales/staging/POSEJ_Error_Queue_ascii_balance_validation")
# dbutils.widgets.text("PAR_NB_POSEJ_ERR_QUEUE1", "retail/retail_sales/staging/INT_DF5_PARSE_REC_REFORMAT_DROP_FIELDS_1")
# dbutils.widgets.text("PAR_NB_RFRM_DROP_FIELDS_1", "retail/retail_sales/staging/INT_DF5_LOC_VALD_RFMT_DROP_FIELDS")
# dbutils.widgets.text("PAR_PL_BATCH_ID", "20220119045142")
# dbutils.widgets.text("PAR_NB_POS_TXN_DTL", "retail/retail_sales/staging/pos_txn_dtl_xref_insert_ascii.pipe_delim/20220119045142")
# dbutils.widgets.text("PAR_NB_INPUT_FILE_INRV1PH2","retail/retail_sales/staging/ecdw7111t_main_older_than_14_days")
# dbutils.widgets.text("PAR_NB_DIM_PERIOD_LKP","retail/retail_sales/lookup/dim_period_lookup_ascii")
# dbutils.widgets.text("PAR_NB_REC_TYPE_LOOKUP","retail/retail_sales/staging/rec_type_lookup")
# dbutils.widgets.text("PAR_NB_OTHER_E_TYPES_OF_DATA","retail/retail_sales/staging/OtherETypesOfData")
# dbutils.widgets.text("PAR_NB_INITIAL_DATE","20050724")
# dbutils.widgets.text("PAR_NB_DATE_SUBTRACTOR","365")
# dbutils.widgets.text("PAR_NB_DATE_ADDER","10")
# dbutils.widgets.text("PAR_PL_BATCH_ID","PKB123") 
# dbutils.widgets.text("PAR_NB_POS_TXN_DTL","retail/retail_sales/staging/pos_txn_dtl_xref_insert_ascii.pipe_delim/PKB123") 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import arrays_zip
from pyspark.sql import functions as F
import datetime

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

filePath_1 = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_FILE_INRV1PH2")

filePath_2 = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_FILE_INRV2PH3")

dim_loc_lkp = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DIM_LOC_LKP")

dim_period_lkp = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DIM_PERIOD_LKP")

# COMMAND ----------

df_ph2 = spark.read.format('parquet').load(filePath_1)

df_ph3 = spark.read.format('parquet').load(filePath_2)

df_input=df_ph2.union(df_ph3)
##DIM_LOCATION
df_dim_loc_lkp=spark.read.parquet(dim_loc_lkp)

df_dim_period_lkp=spark.read.parquet(dim_period_lkp)


# COMMAND ----------

df_input=df_input.withColumn('txn_date',regexp_replace(col('txn_date'),'-',''))\
.withColumn('rec_type_A_upc_tndr',when(col('rcd_type')=='A',substring(col('stuff'),1,12)))\
.withColumn('rec_type_A_desc_acct_nbr',when(col('rcd_type')=='A',substring(col('stuff'),13,18)))\
.withColumn('rec_type_A_item_cost',when(col('rcd_type')=='A',substring(col('stuff'),31,6)))\
.withColumn('rec_type_A_item_unit_price',when(col('rcd_type')=='A',substring(col('stuff'),37,7)))\
.withColumn('rec_type_A_dept_nbr',when(col('rcd_type')=='A',substring(col('stuff'),44,3)))\
.withColumn('rec_type_A_qty',when(col('rcd_type')=='A',substring(col('stuff'),47,5)))\
.withColumn('rec_type_A_tax_type',when(col('rcd_type')=='A',substring(col('stuff'),52,1)))\
.withColumn('rec_type_A_selling_price',when(col('rcd_type')=='A',substring(col('stuff'),53,8)))\
.withColumn('rec_type_A_price_sign',when((col('rcd_type')=='A'),substring(col('stuff'),61,1)))\
.withColumn('rec_type_A_sale_ind',when(col('rcd_type')=='A',substring(col('stuff'),62,1)))\
.withColumn('rec_type_A_wag_cpn',when(col('rcd_type')=='A',substring(col('stuff'),63,1)))\
.withColumn('rec_type_A_emp_disc',when(col('rcd_type')=='A',substring(col('stuff'),64,1)))\
.withColumn('rec_type_A_item_void',when(col('rcd_type')=='A',substring(col('stuff'),65,1)))\
.withColumn('rec_type_A_keyed_item',when(col('rcd_type')=='A',substring(col('stuff'),66,1)))\
.withColumn('rec_type_A_retrnd_item',when(col('rcd_type')=='A',substring(col('stuff'),67,1)))\
.withColumn('rec_type_A_prc_modify',when(col('rcd_type')=='A',substring(col('stuff'),68,1)))\
.withColumn('rec_type_A_prc_verify',when(col('rcd_type')=='A',substring(col('stuff'),69,1)))\
.withColumn('rec_type_A_training_item',when(col('rcd_type')=='A',substring(col('stuff'),70,1)))\
.withColumn('rec_type_A_special',when(col('rcd_type')=='A',substring(col('stuff'),71,1)))\
.withColumn('rec_type_A_unused5',when(col('rcd_type')=='A',substring(col('stuff'),72,9)))\
.withColumn('rec_type_A_undefined',when(col('rcd_type')=='A',substring(col('stuff'),81,1)))\
.withColumn('rec_type_A',concat(col('rec_type_A_dept_nbr'),col('rec_type_A_desc_acct_nbr'),col('rec_type_A_emp_disc'),col('rec_type_A_item_cost'),col('rec_type_A_item_unit_price'),col('rec_type_A_item_void'),col('rec_type_A_keyed_item'),col('rec_type_A_prc_modify'),col('rec_type_A_prc_verify'),col('rec_type_A_price_sign'),col('rec_type_A_qty'),col('rec_type_A_retrnd_item'),col('rec_type_A_sale_ind'),col('rec_type_A_selling_price'),col('rec_type_A_special'),col('rec_type_A_tax_type'),col('rec_type_A_training_item'),col('rec_type_A_undefined'),col('rec_type_A_unused5'),col('rec_type_A_upc_tndr'),col('rec_type_A_wag_cpn')))\
.withColumn('rec_type_M_99_unused1',when((col('rcd_type')==' ') & (col('txn_type')=='99') ,substring(col('stuff'),1,12)))\
.withColumn('rec_type_M_99_reg_desc',when((col('rcd_type')==' ') & (col('txn_type')=='99'),substring(col('stuff'),13,18)))\
.withColumn('rec_type_M_99_unused5',when((col('rcd_type')==' ') & (col('txn_type')=='99'),substring(col('stuff'),31,9)))\
.withColumn('rec_type_M_99_undefined',when((col('rcd_type')==' ') & (col('txn_type')=='99'),substring(col('stuff'),40,42)))\
.withColumn('rec_type_M_99',concat(col('rec_type_M_99_unused1'),col('rec_type_M_99_reg_desc'),col('rec_type_M_99_unused5'),col('rec_type_M_99_undefined')))\
.withColumn('rec_type_M_38_not_1st_orig_tran_nbr',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='38'),substring(col('stuff'),1,4)))\
.withColumn('rec_type_M_38_not_1st_indicator',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='38'),substring(col('stuff'),5,1)))\
.withColumn('rec_type_M_38_not_1st_unused5',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='38'),substring(col('stuff'),6,9)))\
.withColumn('rec_type_M_38_not_1st_undefined',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='38'),substring(col('stuff'),15,67)))\
.withColumn('rec_type_M_38',concat(col('rec_type_M_38_not_1st_orig_tran_nbr'),col('rec_type_M_38_not_1st_indicator'),col('rec_type_M_38_not_1st_unused5'),col('rec_type_M_38_not_1st_undefined')))\
.withColumn('rec_type_M_00_not_1st_indicator',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='00'),substring(col('stuff'),1,6)))\
.withColumn('rec_type_M_00_not_1st_unused5',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='00'),substring(col('stuff'),7,9)))\
.withColumn('rec_type_M_00_not_1st_undefined',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) &(col('txn_type')=='00'),substring(col('stuff'),15,66)))\
.withColumn('rec_type_M_00',concat(col('rec_type_M_00_not_1st_indicator'),col('rec_type_M_00_not_1st_unused5'),col('rec_type_M_00_not_1st_undefined')))\
.withColumn('rec_type_M_survey_ind',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))) ,substring(col('stuff'),1,1)))\
.withColumn('rec_type_M_unused1',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),2,11)))\
.withColumn('rec_type_M_txn_strt_time',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),13,6)))\
.withColumn('rec_type_M_unused2',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),19,1)))\
.withColumn('rec_type_M_txn_stop_time',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),20,6)))\
.withColumn('rec_type_M_unused3',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),26,25)))\
.withColumn('rec_type_M_offline',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),51,1)))\
.withColumn('rec_type_M_rfn_nbr',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),52,20)))\
.withColumn('rec_type_M_unused5',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),72,9)))\
.withColumn('rec_type_M_undefined',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(~(col('txn_type').eqNullSafe('99'))) & (~(col('txn_type').eqNullSafe('11'))) & (~(col('txn_type').eqNullSafe('12'))),substring(col('stuff'),81,1)))\
.withColumn('rec_type_M',concat(col('rec_type_M_survey_ind'),col('rec_type_M_unused1'),col('rec_type_M_txn_strt_time'),col('rec_type_M_unused2'),col('rec_type_M_txn_stop_time'),col('rec_type_M_unused3'),col('rec_type_M_offline'),col('rec_type_M_rfn_nbr'),col('rec_type_M_unused5'),col('rec_type_M_undefined')))\
.withColumn('rec_type_11_survey_ind',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(col('txn_type')=='11') ,substring(col('stuff'),1,1)))\
.withColumn('rec_type_11_unused1',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),2,11)))\
.withColumn('rec_type_11_txn_strt_time',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),13,6)))\
.withColumn('rec_type_11_unused2',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),19,1)))\
.withColumn('rec_type_11_txn_stop_time',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),20,6)))\
.withColumn('rec_type_11_unused3',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),26,1)))\
.withColumn('rec_type_11_disc_mode',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),27,2)))\
.withColumn('rec_type_11_unused4',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),29,22)))\
.withColumn('rec_type_11_offline',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),51,1)))\
.withColumn('rec_type_11_rfn_nbr',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),52,20)))\
.withColumn('rec_type_11_unused5',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),72,9)))\
.withColumn('rec_type_11_undefined',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='11') ,substring(col('stuff'),81,1)))\
.withColumn('rec_type_11',concat(col('rec_type_11_survey_ind'),col('rec_type_11_unused1'),col('rec_type_11_txn_strt_time'),col('rec_type_11_unused2'),col('rec_type_11_txn_stop_time'),col('rec_type_11_unused3'),col('rec_type_11_disc_mode'),col('rec_type_11_unused4'),col('rec_type_11_offline'),col('rec_type_11_rfn_nbr'),col('rec_type_11_unused5'),col('rec_type_11_undefined')))\
.withColumn('rec_type_12_survey_ind',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) &(col('txn_type')=='12') ,substring(col('stuff'),1,1)))\
.withColumn('rec_type_12_unused1',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),2,11)))\
.withColumn('rec_type_12_txn_strt_time',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),13,6)))\
.withColumn('rec_type_12_unused2',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),19,1)))\
.withColumn('rec_type_12_txn_stop_time',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),20,6)))\
.withColumn('rec_type_12_unused3',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),26,1)))\
.withColumn('rec_type_12_disc_mode',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),27,2)))\
.withColumn('rec_type_12_unused4',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),29,22)))\
.withColumn('rec_type_12_offline',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),51,1)))\
.withColumn('rec_type_12_rfn_nbr',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),52,20)))\
.withColumn('rec_type_12_unused5',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),72,9)))\
.withColumn('rec_type_12_undefined',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (col('txn_type')=='12') ,substring(col('stuff'),81,1)))\
.withColumn('rec_type_12',concat(col('rec_type_12_survey_ind'),col('rec_type_12_unused1'),col('rec_type_12_txn_strt_time'),col('rec_type_12_unused2'),col('rec_type_12_txn_stop_time'),col('rec_type_12_unused3'),col('rec_type_12_disc_mode'),col('rec_type_12_unused4'),col('rec_type_12_offline'),col('rec_type_12_rfn_nbr'),col('rec_type_12_unused5'),col('rec_type_12_undefined')))\
.withColumn('rec_type_B_unused_1',when(col('rcd_type')=='B' ,substring(col('stuff'),1,11)))\
.withColumn('rec_type_B_tax_cde',when(col('rcd_type')=='B',substring(col('stuff'),12,1)))\
.withColumn('rec_type_B_tax_tbl_desc',when(col('rcd_type')=='B' ,substring(col('stuff'),13,18)))\
.withColumn('rec_type_B_unused_2',when(col('rcd_type')=='B',substring(col('stuff'),31,18)))\
.withColumn('rec_type_B_tax_amt',when(col('rcd_type')=='B',substring(col('stuff'),49,8)))\
.withColumn('rec_type_B_price_sign',when((col('rcd_type')=='B'),substring(col('stuff'),57,1)))\
.withColumn('rec_type_B_unused5',when(col('rcd_type')=='B',substring(col('stuff'),58,9)))\
.withColumn('rec_type_B_undefined',when(col('rcd_type')=='B',substring(col('stuff'),67,15)))\
.withColumn('rec_type_B',concat(col('rec_type_B_unused_1'),col('rec_type_B_tax_cde'),col('rec_type_B_tax_tbl_desc'),col('rec_type_B_unused_2'),col('rec_type_B_tax_amt'),col('rec_type_B_price_sign'),col('rec_type_B_unused5'),col('rec_type_B_undefined')))\
.withColumn('rec_type_D_unused_2',when(col('rcd_type')=='D',substring(col('stuff'),1,46)))\
.withColumn('rec_type_D_sell_prc',when(col('rcd_type')=='D',substring(col('stuff'),47,10)))\
.withColumn('rec_type_D_price_sign',when((col('rcd_type')=='D'),substring(col('stuff'),57,1)))\
.withColumn('rec_type_D_unused5',when(col('rcd_type')=='D',substring(col('stuff'),58,9)))\
.withColumn('rec_type_D_undefined',when(col('rcd_type')=='D',substring(col('stuff'),67,15)))\
.withColumn('rec_type_D',concat(col('rec_type_D_unused_2'),col('rec_type_D_sell_prc'),col('rec_type_D_price_sign'),col('rec_type_D_unused5'),col('rec_type_D_undefined')))\
.withColumn('rec_type_C_p1_tndr_desc',when(col('rcd_type')=='C' ,substring(col('stuff'),1,6)))\
.withColumn('rec_type_C_check_routing_nbr',when((col('rcd_type')=='C') & ((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ')) ,substring(col('stuff'),7,9)))\
.withColumn('rec_type_C_check_unused1',when((col('rcd_type')=='C') & ((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ')) ,substring(col('stuff'),16,1)))\
.withColumn('rec_type_C_check_chk_info',when((col('rcd_type')=='C') & ((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ')) ,substring(col('stuff'),17,32)))\
.withColumn('rec_type_C_check_selling_prc',when((col('rcd_type')=='C') & ((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ')) ,substring(col('stuff'),49,8)))\
.withColumn('rec_type_C_check_prc_sign',when((col('rcd_type')=='C') & ((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ')),substring(col('stuff'),57,1)))\
.withColumn('rec_type_C_check_unused5',when((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ') ,substring(col('stuff'),58,9)))\
.withColumn('rec_type_C_check_undefined',when((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ') ,substring(col('stuff'),67,15)))\
.withColumn('rec_type_C_check',concat(col('rec_type_C_check_routing_nbr'),col('rec_type_C_check_unused1'),col('rec_type_C_check_chk_info'),col('rec_type_C_check_selling_prc'),col('rec_type_C_check_prc_sign'),col('rec_type_C_check_unused5'),col('rec_type_C_check_undefined')))\
.withColumn('rec_type_C_not_check_p2_tndr_desc',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),7,6)))\
.withColumn('rec_type_C_not_check_acct_nbr',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),13,25)))\
.withColumn('rec_type_C_not_check_entry_mode_old',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),38,1)))\
.withColumn('rec_type_C_not_check_expire_dte',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),39,4)))\
.withColumn('rec_type_C_not_check_unused2',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),43,19)))\
.withColumn('rec_type_C_not_check_selling_prc',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),62,10)))\
.withColumn('rec_type_C_not_check_prc_sign',when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   ')))),substring(col('stuff'),72,1)))\
.withColumn('rec_type_C_not_check_entry_mode_new',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),73,1)))\
.withColumn('rec_type_C_not_check_unused3',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),74,4)))\
.withColumn('rec_type_C_not_check_unused5',when((~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) | (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),78,3)))\
.withColumn('rec_type_C_not_check_undefined',when((col('rcd_type')=='C') & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('CHECK '))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe('ACH   '))),substring(col('stuff'),81,1)))\
.withColumn('rec_type_C_not_check',concat(col('rec_type_C_not_check_p2_tndr_desc'),col('rec_type_C_not_check_acct_nbr'),col('rec_type_C_not_check_entry_mode_old'),col('rec_type_C_not_check_expire_dte'),col('rec_type_C_not_check_unused2'),col('rec_type_C_not_check_selling_prc'),col('rec_type_C_not_check_prc_sign'),col('rec_type_C_not_check_entry_mode_new'),col('rec_type_C_not_check_unused3'),col('rec_type_C_not_check_unused5'),col('rec_type_C_not_check_undefined')))\
.withColumn('rec_type_C',concat(coalesce(col('rec_type_C_p1_tndr_desc'),lit('')),coalesce(col('rec_type_C_check'),lit('')),coalesce(col('rec_type_C_not_check'),lit(''))))\
.withColumn('rec_type_C',when(col('rec_type_C')=='',lit(None)).otherwise(col('rec_type_C')))\
.withColumn('rec_type_E_rcrd_sub_type',when(col('rcd_type')=='E',substring(col('stuff'),1,4)))\
.withColumn('rec_type_E_fld_sep',when(col('rcd_type')=='E',substring(col('stuff'),5,1)))\
.withColumn('rec_type_E_sub_typ_6_indicator',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),6,1)))\
.withColumn('rec_type_E_sub_typ_6_orig_dte',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),7,6)))\
.withColumn('rec_type_E_sub_typ_6_orig_str',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),13,5)))\
.withColumn('rec_type_E_sub_typ_6_orig_register',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),18,2)))\
.withColumn('rec_type_E_sub_typ_6_orig_txn_nbr',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),20,4)))\
.withColumn('rec_type_E_sub_typ_6_orig_trans_amt',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),24,7)))\
.withColumn('rec_type_E_sub_typ_6_refund_amt',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),31,8)))\
.withColumn('rec_type_E_sub_typ_6_orig_tndr',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),39,2)))\
.withColumn('rec_type_E_sub_typ_6_rec_sprtr',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),41,2)))\
.withColumn('rec_type_E_sub_typ_6_mgr_id',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),43,3)))\
.withColumn('rec_type_E_sub_typ_6_register_loc',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),46,2)))\
.withColumn('rec_type_E_sub_typ_6_refund_status',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),48,1)))\
.withColumn('rec_type_E_sub_typ_6_rcpt_entry',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),49,1)))\
.withColumn('rec_type_E_sub_typ_6_tandem_stat',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),50,1)))\
.withColumn('rec_type_E_sub_typ_6_refund_rsn',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),51,1)))\
.withColumn('rec_type_E_sub_typ_6_unused5',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),52,9)))\
.withColumn('rec_type_E_sub_typ_6_undefined',when(col('rec_type_E_rcrd_sub_type')=='0006',substring(col('stuff'),61,21)))\
.withColumn('rec_type_E_sub_typ_6',concat(col('rec_type_E_sub_typ_6_indicator'),col('rec_type_E_sub_typ_6_orig_dte'),col('rec_type_E_sub_typ_6_orig_str'),col('rec_type_E_sub_typ_6_orig_register'),col('rec_type_E_sub_typ_6_orig_txn_nbr'),col('rec_type_E_sub_typ_6_orig_trans_amt'),col('rec_type_E_sub_typ_6_refund_amt'),col('rec_type_E_sub_typ_6_orig_tndr'),col('rec_type_E_sub_typ_6_rec_sprtr'),col('rec_type_E_sub_typ_6_mgr_id'),col('rec_type_E_sub_typ_6_register_loc'),col('rec_type_E_sub_typ_6_refund_status'),col('rec_type_E_sub_typ_6_rcpt_entry'),col('rec_type_E_sub_typ_6_tandem_stat'),col('rec_type_E_sub_typ_6_refund_rsn'),col('rec_type_E_sub_typ_6_unused5'),col('rec_type_E_sub_typ_6_undefined')))\
.withColumn('rec_type_E_sub_typ_19_patient_phn_nbr',when(col('rec_type_E_rcrd_sub_type')=='0019',substring(col('stuff'),6,10)))\
.withColumn('rec_type_E_sub_typ_19_patient_id',when(col('rec_type_E_rcrd_sub_type')=='0019',substring(col('stuff'),16,13)))\
.withColumn('rec_type_E_sub_typ_19_unused5',when(col('rec_type_E_rcrd_sub_type')=='0019',substring(col('stuff'),29,9)))\
.withColumn('rec_type_E_sub_typ_19_undefined',when(col('rec_type_E_rcrd_sub_type')=='0019',substring(col('stuff'),37,44)))\
.withColumn('rec_type_E_sub_typ_19',concat(col('rec_type_E_sub_typ_19_patient_phn_nbr'),col('rec_type_E_sub_typ_19_patient_id'),col('rec_type_E_sub_typ_19_unused5'),col('rec_type_E_sub_typ_19_undefined')))\
.withColumn('rec_type_E_sub_typ_10_spot_info',when(col('rec_type_E_rcrd_sub_type')=='0010',substring(col('stuff'),6,67)))\
.withColumn('rec_type_E_sub_typ_10_unused5',when(col('rec_type_E_rcrd_sub_type')=='0010',substring(col('stuff'),68,9)))\
.withColumn('rec_type_E_sub_typ_10',concat(col('rec_type_E_sub_typ_10_spot_info'),col('rec_type_E_sub_typ_10_unused5')))\
.withColumn('rec_type_E_sub_typ_26_wcard_txn',when(col('rec_type_E_rcrd_sub_type')=='0026',
                                                   
                                                   substring(col('stuff'),6,67)))\
.withColumn('rec_type_E_sub_typ_26_unused5',when(col('rec_type_E_rcrd_sub_type')=='0026',substring(col('stuff'),73,9)))\
.withColumn('rec_type_E_sub_typ_26',concat(col('rec_type_E_sub_typ_26_wcard_txn'),col('rec_type_E_sub_typ_26_unused5')))\
.withColumn('rec_type_E_sub_typ_27_wcard_txn_dtl',when(col('rec_type_E_rcrd_sub_type')=='0027',substring(col('stuff'),6,67)))\
.withColumn('rec_type_E_sub_typ_27_unused5',when(col('rec_type_E_rcrd_sub_type')=='0027',substring(col('stuff'),73,9)))\
.withColumn('rec_type_E_sub_typ_27',concat(col('rec_type_E_sub_typ_27_wcard_txn_dtl'),col('rec_type_E_sub_typ_27_unused5')))\
.withColumn('rec_type_E',concat(col('rec_type_E_rcrd_sub_type'),col('rec_type_E_fld_sep'),col('rec_type_E_sub_typ_6'),col('rec_type_E_sub_typ_19'),col('rec_type_E_sub_typ_10'),col('rec_type_E_sub_typ_26'),col('rec_type_E_sub_typ_27')))

# COMMAND ----------

df_transform = df_input.withColumn('local_A_qty',when((col('rcd_type')=='A') & (col('rec_type_A_qty').isNotNull()), col('rec_type_A_qty'))
                             .when((col('rcd_type')=='A') & (col('rec_type_A_qty').eqNullSafe(' ')),lit(0))
                                .otherwise(col('rec_type_A_qty')))\
.withColumn('local_A_item_unit_price',when((col('rcd_type')=='A') & (col('rec_type_A_item_unit_price').isNotNull()), lpad(col('rec_type_A_item_unit_price'),7,'0'))
                             .when((col('rcd_type')=='A') & (col('rec_type_A_item_unit_price').eqNullSafe('')),lit(0))
                                .otherwise(col('rec_type_A_item_unit_price')))\
.withColumn('local_routing_nbr',when((col('rcd_type')=='C') & ((col('rec_type_C_p1_tndr_desc')=="CHECK ") | (col('rec_type_C_p1_tndr_desc')=="ACH   ")) & (~(substring(col('rec_type_C_check_routing_nbr'),1,1).eqNullSafe(':'))),col('rec_type_C_check_routing_nbr')))\
.withColumn('rec_type_A_qty',col('local_A_qty'))\
.withColumn('tmp_Valid_A_field',when((col('local_A_qty').isNotNull()) & (col('local_A_item_unit_price').isNotNull()) & ((col('rec_type_A_dept_nbr').isNotNull()) | (~(col('rec_type_A_dept_nbr').eqNullSafe(' ')))) & (col('rec_type_A_selling_price').isNotNull()) & ((col('rec_type_A_price_sign')==' ') | (col('rec_type_A_price_sign')=='-')),True).otherwise(False))\
.withColumn('valid_A_field',when(col('rcd_type')=='A',col('tmp_Valid_A_field')).otherwise(True))\
.withColumn('valid_M38_field',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>=2) & (col('txn_type').eqNullSafe(38)),col('rec_type_M_38_not_1st_orig_tran_nbr').isNotNull())\
                                   .otherwise(True))\
.withColumn('tmp_valid_M_field',when(((col('rec_type_M_txn_strt_time').isNull()) | (~(col('rec_type_M_txn_strt_time').rlike('\D+'))) | (col('rec_type_M_txn_strt_time')=='240000')) & ((col('rec_type_M_txn_stop_time').isNull()) | (~(col('rec_type_M_txn_stop_time').rlike('\D+'))) | (col('rec_type_M_txn_stop_time')=='240000')) & ((col('rec_type_M_rfn_nbr').isNull()) | (~(col('rec_type_M_rfn_nbr').rlike('\D+')))),True).otherwise(False))\
.withColumn('valid_M_field',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (~(col('txn_type').eqNullSafe(99))),col('tmp_valid_M_field')).otherwise(True))\
.withColumn('tmp_valid_B_field',when((col('rec_type_B_tax_amt').isNotNull()) & ((col('rec_type_B_price_sign')==' ') | (col('rec_type_B_price_sign')=='-')),True).otherwise(False))\
.withColumn('valid_B_field',when(col('rcd_type')=='B',col('tmp_valid_B_field')).otherwise(True))\
.withColumn('tmp_valid_C_field_1',when(((col('local_routing_nbr').isNotNull()) | (col('local_routing_nbr')==' ')) & (col('rec_type_C_check_selling_prc').isNotNull()) & ((col('rec_type_C_check_prc_sign')==' ') | (col('rec_type_C_check_prc_sign')=='-')),True).otherwise(False))\
.withColumn('tmp_valid_C_field_2',when(((~(((col('rec_type_C_not_check_expire_dte'))).rlike('\D+')) & (length(trim(col('rec_type_C_not_check_expire_dte'))) == 4)) | ((col('rec_type_C_not_check_expire_dte').isNull()) | (length(trim(col('rec_type_C_not_check_expire_dte')))==0))) & (col('rec_type_C_not_check_selling_prc').isNotNull()) & (col('rec_type_C_not_check_prc_sign')==' ') | (col('rec_type_C_not_check_prc_sign')=='-'),True).otherwise(False))\
.withColumn('valid_C_field',when(((col('rec_type_C_p1_tndr_desc')=='CHECK ') | (col('rec_type_C_p1_tndr_desc')=='ACH   ')),col('tmp_valid_C_field_1'))\
            .when((col('rcd_type')=='C'),col('tmp_valid_C_field_2'))\
            .otherwise(True))\
.withColumn('tmp_valid_D_field',when((col('rec_type_D_sell_prc').isNotNull()) & ((col('rec_type_D_price_sign')==' ') | (col('rec_type_D_price_sign')=='-')),True).otherwise(False))\
.withColumn('valid_D_field',when(col('rcd_type')=='D',col('tmp_valid_D_field')).otherwise(True))\
.withColumn('tmp_valid_E_field_1',when((col('rec_type_E_sub_typ_6_orig_dte').isNotNull()) & (col('rec_type_E_sub_typ_6_orig_str').isNotNull()) &(col('rec_type_E_sub_typ_6_orig_register').isNotNull()) &(col('rec_type_E_sub_typ_6_orig_txn_nbr').isNotNull()) &(col('rec_type_E_sub_typ_6_orig_trans_amt').isNotNull()) &(col('rec_type_E_sub_typ_6_refund_amt').isNotNull()) &(col('rec_type_E_sub_typ_6_mgr_id').isNotNull()),True).otherwise(False))\
.withColumn('valid_E_field',when(col('rec_type_E_rcrd_sub_type')=='0006',col('tmp_valid_E_field_1'))\
           .when(col('rec_type_E_rcrd_sub_type')=='0019',(~((trim((col('rec_type_E_sub_typ_19_patient_phn_nbr'))).rlike('\D+'))) & (length(trim(col('rec_type_E_sub_typ_19_patient_phn_nbr'))) == 10)))\
           .otherwise(True))\
.withColumn('rec_type_E_sub_typ_27_wcard_plan_name',substring(col('rec_type_E_sub_typ_27_wcard_txn_dtl'),1,9))\
.withColumn('rec_type_E_sub_typ_27_wcard_acct_nbr',substring(col('rec_type_E_sub_typ_27_wcard_txn_dtl'),11,19))\
.withColumn('rec_type_E_sub_typ_27_wcard_rebt_amt',substring(col('rec_type_E_sub_typ_27_wcard_txn_dtl'),31,8))\
.withColumn('rec_type_E_sub_typ_27_wcard_upc_nbr',substring(col('rec_type_E_sub_typ_27_wcard_txn_dtl'),31,32))\
.withColumn('rec_type_E_sub_typ_26_wcard_plan_name',substring(col('rec_type_E_sub_typ_26_wcard_txn'),1,9))\
.withColumn('rec_type_E_sub_typ_26_wcard_acct_nbr',substring(col('rec_type_E_sub_typ_26_wcard_txn'),11,19))\
.withColumn('rec_type_E_sub_typ_26_wcard_tot_rebt_amt',substring(col('rec_type_E_sub_typ_26_wcard_txn'),31,10))\
.withColumn('rec_type_E_sub_typ_26_wcard_rebt_basis',substring(col('rec_type_E_sub_typ_26_wcard_txn'),31,32))\
.withColumn('rec_type_E_sub_typ_26_wcard_rebt_rate',substring(col('rec_type_E_sub_typ_26_wcard_txn'),31,32))\
.withColumn('rec_type_E_sub_typ_27_wcard_rebt_amt',regexp_replace(expr("""substring(rec_type_E_sub_typ_27_wcard_rebt_amt,1,locate(':',rec_type_E_sub_typ_27_wcard_rebt_amt))"""),':',''))\
.withColumn('rec_type_E_sub_typ_27_wcard_upc_nbr',regexp_replace(expr("""substring(rec_type_E_sub_typ_27_wcard_upc_nbr,locate(':',rec_type_E_sub_typ_27_wcard_upc_nbr),13)"""),':',''))\
.withColumn('rec_type_E_sub_typ_26_wcard_tot_rebt_amt',regexp_replace(expr("""substring(rec_type_E_sub_typ_26_wcard_tot_rebt_amt,1,locate(':',rec_type_E_sub_typ_26_wcard_tot_rebt_amt))"""),':',''))\
.withColumn('rec_type_E_sub_typ_26_wcard_rebt_basis',regexp_replace(expr("""substring(rec_type_E_sub_typ_26_wcard_rebt_basis,locate(':',rec_type_E_sub_typ_26_wcard_rebt_basis),2)"""),':',''))\
.withColumn('rec_type_E_sub_typ_26_wcard_rebt_rate',expr("""substring(rec_type_E_sub_typ_26_wcard_rebt_rate,locate(':',rec_type_E_sub_typ_26_wcard_rebt_rate),13)"""))\
.withColumn('rec_type_E_sub_typ_26_wcard_plan_name',substring(col('rec_type_E_sub_typ_26_wcard_plan_name'),1,9))\
.withColumn('rec_type_E_sub_typ_26_wcard_acct_nbr',when((substring(col('rec_type_E_sub_typ_26_wcard_acct_nbr'),1,19)).isNotNull(),substring(col('rec_type_E_sub_typ_26_wcard_acct_nbr'),1,19)).otherwise(lit('0')))\
.withColumn('rec_type_E_sub_typ_26_wcard_tot_rebt_amt',when((substring(col('rec_type_E_sub_typ_26_wcard_tot_rebt_amt'),1,8)).isNotNull(),substring(col('rec_type_E_sub_typ_26_wcard_tot_rebt_amt'),1,8)).otherwise(lit('0.00')))\
.withColumn('rec_type_E_sub_typ_26_wcard_rebt_basis',substring(col('rec_type_E_sub_typ_26_wcard_rebt_basis'),1,1))\
.withColumn('rec_type_E_sub_typ_26_wcard_rebt_rate',when(trim((substring(col('rec_type_E_sub_typ_26_wcard_rebt_rate'),4,11))).rlike('^[0-9]\d*(\.\d+)?$'),substring(col('rec_type_E_sub_typ_26_wcard_rebt_rate'),4,11)).otherwise(lit('0.00')))\
.withColumn('rec_type_E_sub_typ_27_wcard_plan_name',substring(col('rec_type_E_sub_typ_27_wcard_plan_name'),1,9))\
.withColumn('rec_type_E_sub_typ_27_wcard_acct_nbr',when((substring(col('rec_type_E_sub_typ_27_wcard_acct_nbr'),1,19)).isNotNull(),substring(col('rec_type_E_sub_typ_27_wcard_acct_nbr'),1,19)).otherwise(lit('0')))\
.withColumn('rec_type_E_sub_typ_27_wcard_rebt_amt',when((substring(col('rec_type_E_sub_typ_27_wcard_rebt_amt'),1,8)).isNotNull(),substring(col('rec_type_E_sub_typ_27_wcard_rebt_amt'),1,8)).otherwise(lit('0.00')))\
.withColumn('rec_type_E_sub_typ_27_wcard_upc_nbr',when((substring(col('rec_type_E_sub_typ_27_wcard_upc_nbr'),1,12)).isNotNull(),substring(col('rec_type_E_sub_typ_27_wcard_upc_nbr'),1,12)).otherwise(lit('0')))\
.drop('tmp_Valid_A_field','tmp_valid_M38_field','tmp_valid_B_field','tmp_valid_C_field_1','tmp_valid_C_field_2','tmp_valid_D_field','tmp_valid_E_field_1')

# COMMAND ----------

df_transform = df_transform.withColumn('txn_cntr',(trim(col('txn_cntr'))).cast(DoubleType()))\
.withColumn('rec_in_txn_cntr',(trim(col('rec_in_txn_cntr'))).cast(IntegerType()))

# COMMAND ----------

##scan on txn_cntr

from pyspark.sql.window import Window
wspec = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr').desc()).rowsBetween(Window.unboundedPreceding, Window.currentRow)
wspec2 = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr').desc())
wspec3 = Window.partitionBy('txn_cntr')

df_scan=df_transform.withColumn('local_valid_fields',when((col('rcd_type')==' ') & (~(col('txn_type').eqNullSafe('38'))), col('valid_M_field'))
                               .when((col('rcd_type')==' ') & (col('txn_type').eqNullSafe('38')),col('valid_M38_field'))
                               .when(col('rcd_type')=='A',col('valid_A_field'))
                               .when(col('rcd_type')=='B',col('valid_B_field'))
                               .when(col('rcd_type')=='C',col('valid_C_field'))
                               .when(col('rcd_type')=='D',col('valid_D_field'))
                               .when(col('rcd_type')=='E',col('valid_E_field')))\
.withColumn('valid_more_fields_tmp_bool',(col('valid_A_field') & col('valid_M38_field') & col('valid_M_field') & col('valid_B_field') & col('valid_C_field') & col('valid_D_field') & col('valid_E_field')))\
.withColumn('valid_more_fields_tmp',when(col('valid_more_fields_tmp_bool'),lit(0)).otherwise(lit(1)))\
.withColumn('valid_more_fields',sum(col('valid_more_fields_tmp')).over(wspec3))\
.withColumn('valid_more_fields',when(col('valid_more_fields')>=1,lit(False)).otherwise(lit(True)))\
.withColumn('tmp_err_seq_xref',when(col('local_valid_fields')==False,ltrim(col('rec_in_txn_cntr'))))\
.withColumn('tmp_err_seq_xref_collect',collect_list(col('tmp_err_seq_xref')).over(wspec))\
.withColumn('err_seq_xref',concat_ws(',',reverse(col('tmp_err_seq_xref_collect'))))\
.withColumn('int_rec_type_A_selling_price',when(trim(col('rec_type_A_price_sign')).eqNullSafe('-'),(lit(-1) * col('rec_type_A_selling_price').cast(DecimalType(8,2))))\
           .otherwise(col('rec_type_A_selling_price').cast(DecimalType(8,2))))\
.withColumn('int2_rec_type_A_selling_price',when((col('valid_A_field')) & (col('rec_type_A').isNotNull()) & (~(col('rec_type_A_prc_verify')).eqNullSafe('Y')),col('int_rec_type_A_selling_price')).otherwise(lit(0)))\
.withColumn('prod_sum',sum(col('int2_rec_type_A_selling_price')).over(wspec3))\
.withColumn('int_rec_type_B_tax_amt',when(trim(col('rec_type_B_price_sign')).eqNullSafe('-'),(lit(-1) * col('rec_type_B_tax_amt').cast(DecimalType(8,2))))\
           .otherwise(col('rec_type_B_tax_amt').cast(DecimalType(8,2))))\
.withColumn('int2_rec_type_B_tax_amt',when(col('valid_B_field') & col('rec_type_B').isNotNull(),col('int_rec_type_B_tax_amt')).otherwise(lit(0)))\
.withColumn('tax_sum',sum(col('int2_rec_type_B_tax_amt')).over(wspec3))\
.withColumn('int_rec_type_D_sell_prc',when(trim(col('rec_type_D_price_sign')).eqNullSafe('-'),(lit(-1) * col('rec_type_D_sell_prc').cast(DecimalType(8,2))))\
           .otherwise(col('rec_type_D_sell_prc').cast(DecimalType(8,2))))\
.withColumn('int2_rec_type_D_sell_prc',when(col('valid_D_field') & col('rec_type_D').isNotNull(),col('int_rec_type_D_sell_prc')).otherwise(lit(0)))\
.withColumn('balance',sum(col('int2_rec_type_D_sell_prc')).over(wspec3))\
.drop('valid_more_fields_tmp_bool','valid_more_fields_tmp','tmp_err_seq_xref','tmp_err_seq_xref_collect','temp_prod_sum','temp_prod_sum_col','temp_tax_sum','temp_tax_sum_col','temp_balance','temp_balance_col')

# COMMAND ----------

df_error_queue=df_scan.withColumn('tempsum',col('prod_sum') + col('tax_sum'))\
.filter((~(col('valid_more_fields'))) | ((~(col('balance').eqNullSafe(col('tempsum')))) & (~(col('txn_type').eqNullSafe('48'))) & (~(col('txn_type').eqNullSafe('33')))))\
.withColumn('invalid_desc',when((col('rcd_type')=='A') & (col('rec_type_A_selling_price').isNull()),lit('V2: Rec A invalid selling price'))
           .when((col('rcd_type')=='A') & (~(col('rec_type_A_price_sign').eqNullSafe(" "))) & (~(col('rec_type_A_price_sign').eqNullSafe("-"))),lit('V2: Rec A invalid price sign'))
           .when((col('rcd_type')=='A') & (col('rec_type_A_qty').isNull()),lit('V2: Rec A invalid qty'))
           .when((col('rcd_type')=='A') & (col('rec_type_A_item_unit_price').isNull()),lit('V2: Rec A invalid item unitp rice'))
           .when((col('rcd_type')=='A') & (col('rec_type_A_dept_nbr').isNull()),lit('V2: Rec A invalid dept nbr'))
           .when((col('rcd_type')=='B') & (col('rec_type_B_tax_amt').isNull()),lit('V2: Rec B invalid tax amt'))
           .when(((col('rcd_type')=='B') & ((~(col('rec_type_B_price_sign').eqNullSafe(" "))) & (~(col('rec_type_B_price_sign')).eqNullSafe("-")))),lit('V2: Rec B invalid tax sign'))
           .when((((col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) | ((col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & (col('rec_type_C_check_routing_nbr').isNull()),lit('V2: Rec C invalid routing nbr'))
           .when((((col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) | ((col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & (col('rec_type_C_check_selling_prc').isNull()),lit('V2: Rec C invalid tender amt'))
            
           .when(((((col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) | ((col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   "))))) & ((~(col('rec_type_C_check_prc_sign').eqNullSafe(' '))) & (~(col('rec_type_C_check_prc_sign').eqNullSafe('-')))),lit('V2: Rec C invalid tender sign1'))  
            
           .when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & (col('rec_type_C_not_check_selling_prc').isNull()),lit('V2: Rec C invalid tender amt'))                        
            
            .when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & ((~(col('rec_type_C_not_check_prc_sign').eqNullSafe(' '))) & (~(col('rec_type_C_not_check_prc_sign').eqNullSafe('-')))),lit('V2: Rec C invalid tender sign2'))  
            
           .when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & ((trim((col('rec_type_C_not_check_expire_dte'))).rlike('\D+')) | (length(trim(col('rec_type_C_not_check_expire_dte'))) > 4)),lit('V2: Rec C invalid expir date'))
           .when((col('rcd_type')=='D') & (col('rec_type_D_sell_prc').isNull()),lit('V2: Rec D invalid total amt'))
           .when((col('rcd_type')=='D') & ((~(col('rec_type_D_price_sign').eqNullSafe(" "))) & (~(col('rec_type_D_price_sign').eqNullSafe("-")))),lit('V2: Rec D invalid total amt sign'))    
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_orig_dte').isNull()),lit('V2: E0006 invalid orig date'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_orig_str').isNull()),lit('V2: E0006 invalid orig store nbr'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_orig_register').isNull()),lit('V2: E0006 invalid orig rgstr nbr'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_orig_txn_nbr').isNull()),lit('V2: E0006 invalid orig txn nbr'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_orig_trans_amt').isNull()),lit('V2: E0006 invalid orig txn amt'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_refund_amt').isNull()),lit('V2: E0006 invalid refund amt'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (col('rec_type_E_sub_typ_6_mgr_id').isNull()),lit('V2: E0006 invalid mgr ID'))
           .when((col('rec_type_E_rcrd_sub_type')=='0019') & (col('rec_type_E_sub_typ_19_patient_phn_nbr').isNull()) | ~(trim((col('rec_type_E_sub_typ_19_patient_phn_nbr'))).rlike('^[0-9]{10}$')),lit('V2: E0019 invalid phone nbr'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')=='1') & (~(col('txn_type').eqNullSafe('99'))) &(col('rec_type_M_txn_strt_time').isNull()) & (~(col('rec_type_M_txn_strt_time')==' ')),lit('V2: Hdr invalid start time'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')=='1') & (~(col('txn_type').eqNullSafe('99'))) &(col('rec_type_M_txn_stop_time').isNull()) & (~(col('rec_type_M_txn_stop_time')==' ')),lit('V2: Hdr invalid end time'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')=='1') & (~(col('txn_type').eqNullSafe('99'))) & (((col('rec_type_M_rfn_nbr').rlike('\D+'))) | (col('rec_type_M_rfn_nbr').isNull())),lit('V2: Hdr invalid rfn'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>='2') & (col('txn_type').eqNullSafe('38')) &(col('rec_type_M_38_not_1st_orig_tran_nbr').isNull()),lit('V2: PVoid invalid orig txn nbr'))
           .when((~(col('balance').eqNullSafe((col('prod_sum') + col('tax_sum'))))) & (~(col('txn_type').eqNullSafe('48'))) & (~(col('txn_type').eqNullSafe('33'))),lit('V2: Dtl + Tax != Total'))\
           .otherwise(concat(lit('V2: Err on txn rec# '),col('err_seq_xref')))
           )\
.select(col('txn_cntr'), col('rec_in_txn_cntr'), col('file_nbr'), col('rec_in_file'),\
   col('partition_nbr'), col('str_nbr'), col('txn_date'), col('txn_time'), col('cashier_nbr'), col('register_nbr'),\
   col('txn_type'), col('txn_nbr'), col('rcd_type'), col('stuff'), col('invalid_desc'))

posejerror=mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJ_ERR_QUEUE")

df_error_queue.write.format("parquet").mode("overwrite").save(posejerror)


# COMMAND ----------

df_dropfields_1=df_scan.filter((~(col('valid_more_fields')))==True)\
.withColumn('invalid_desc',when((col('rcd_type')=='A') & (trim(col('rec_type_A_selling_price')).rlike('^\d*[.]\d*$') == False),lit('V2: Rec A invalid selling price'))
           .when((col('rcd_type')=='A') & ((~(col('rec_type_A_price_sign').eqNullSafe(" "))) & (~(col('rec_type_A_price_sign').eqNullSafe("-")))),lit('V2: Rec A invalid price sign'))
           .when((col('rcd_type')=='A') & (trim(col('rec_type_A_qty')).rlike('^\d*$') == False),lit('V2: Rec A invalid qty'))
           .when((col('rcd_type')=='A') & (trim(col('rec_type_A_item_unit_price')).rlike('^\d*$') == False),lit('V2: Rec A invalid item unit price'))
           .when((col('rcd_type')=='A') & (trim(col('rec_type_A_dept_nbr')).rlike('^\d*$') == False),lit('V2: Rec A invalid dept nbr'))
           .when((col('rcd_type')=='B') & (trim(col('rec_type_B_tax_amt')).rlike('^\d*[.]\d*$') == False),lit('V2: Rec B invalid tax amt'))
           .when(((col('rcd_type')=='B') & ((~(col('rec_type_B_price_sign').eqNullSafe(" "))) & (~(col('rec_type_B_price_sign')).eqNullSafe("-")))),lit('V2: Rec B invalid tax sign'))
           .when((((col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) | ((col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & (col('rec_type_C_check_routing_nbr').rlike('^\d*$') == False),lit('V2: Rec C invalid routing nbr'))
           .when((((col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) | ((col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & (col('rec_type_C_check_selling_prc').rlike('^\d*[.]\d*$') == False),lit('V2: Rec C invalid tender amt'))
            
           .when(((((col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) | ((col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   "))))) & ((~(col('rec_type_C_check_prc_sign').eqNullSafe(' '))) & (~(col('rec_type_C_check_prc_sign').eqNullSafe('-')))),lit('V2: Rec C invalid tender sign1'))  
            
           .when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & (trim(col('rec_type_C_not_check_selling_prc')).rlike('^\d*[.]\d*$') == False),lit('V2: Rec C invalid tender amt'))                        
            
            .when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & ((~(col('rec_type_C_not_check_prc_sign').eqNullSafe(' '))) & (~(col('rec_type_C_not_check_prc_sign').eqNullSafe('-')))),lit('V2: Rec C invalid tender sign2'))  
            
           .when((col('rcd_type')=='C') & ((~(col('rec_type_C_p1_tndr_desc').eqNullSafe("CHECK "))) & (~(col('rec_type_C_p1_tndr_desc').eqNullSafe("ACH   ")))) & ((trim(col('rec_type_C_not_check_expire_dte')).rlike('^\d*$') == False) | (length(trim(col('rec_type_C_not_check_expire_dte'))) < 4)) & (trim(col('rec_type_C_not_check_expire_dte')) != ''),lit('V2: Rec C invalid expir date'))
           .when((col('rcd_type')=='D') & (trim(col('rec_type_D_sell_prc')).rlike('^\d*[.]\d*$') == False),lit('V2: Rec D invalid total amt'))
           .when((col('rcd_type')=='D') & ((~(col('rec_type_D_price_sign').eqNullSafe(" "))) & (~(col('rec_type_D_price_sign').eqNullSafe("-")))),lit('V2: Rec D invalid total amt sign'))    
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_orig_dte')).rlike('^\d*$') == False),lit('V2: E0006 invalid orig date'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_orig_str')).rlike('^\d*$') == False),lit('V2: E0006 invalid orig store nbr'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_orig_register')).rlike('^\d*$') == False),lit('V2: E0006 invalid orig rgstr nbr'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_orig_txn_nbr')).rlike('^\d*$') == False),lit('V2: E0006 invalid orig txn nbr'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_orig_trans_amt')).rlike('^\d*$') == False),lit('V2: E0006 invalid orig txn amt'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_refund_amt')).rlike('^\d*$') == False),lit('V2: E0006 invalid refund amt'))
           .when((col('rec_type_E_rcrd_sub_type')=='0006') & (trim(col('rec_type_E_sub_typ_6_mgr_id')).rlike('^\d*$') == False),lit('V2: E0006 invalid mgr ID'))
           .when((col('rec_type_E_rcrd_sub_type')=='0019') & ~(trim((col('rec_type_E_sub_typ_19_patient_phn_nbr'))).rlike('^[0-9]{10}$')),lit('V2: E0019 invalid phone nbr'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')=='1') & (~(col('txn_type').eqNullSafe('99'))) &(trim(col('rec_type_M_txn_strt_time')).rlike('^\d*$') == False) & (~(col('rec_type_M_txn_strt_time')==' ')),lit('V2: Hdr invalid start time'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')=='1') & (~(col('txn_type').eqNullSafe('99'))) &(trim(col('rec_type_M_txn_stop_time')).rlike('^\d*$') == False) & (~(col('rec_type_M_txn_stop_time')==' ')),lit('V2: Hdr invalid end time'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')=='1') & (~(col('txn_type').eqNullSafe('99'))) & ((trim(col('rec_type_M_rfn_nbr')).rlike('^\d*$') == False)),lit('V2: Hdr invalid rfn'))
           .when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')>='2') & (col('txn_type').eqNullSafe('38')) &(trim(col('rec_type_M_38_not_1st_orig_tran_nbr')).rlike('^\d*$') == False),lit('V2: PVoid invalid orig txn nbr'))
           .when((~(col('balance').eqNullSafe((col('prod_sum') + col('tax_sum'))))) & (~(col('txn_type').eqNullSafe('48'))) & (~(col('txn_type').eqNullSafe('33'))),lit('V2: Dtl + Tax != Total'))\
           .otherwise(concat(lit('V2: Err on txn rec# '),col('err_seq_xref')))
           )\
.select(col('txn_cntr'), col('rec_in_txn_cntr'), col('file_nbr'), col('rec_in_file'),\
   col('partition_nbr'), col('str_nbr'), col('txn_date'), col('txn_time'), col('cashier_nbr'), col('register_nbr'),\
   col('txn_type'), col('txn_nbr'), col('rcd_type'), col('stuff'), col('invalid_desc'))

posejerror1=mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJ_ERR_QUEUE1")

df_dropfields_1.write.format("parquet").mode("overwrite").save(posejerror1)

# COMMAND ----------

df_loc_val=df_scan.filter((col('valid_more_fields')==True) & (col('txn_cntr').isNotNull()))
df_loc_val=df_loc_val.join(df_dim_loc_lkp,df_dim_loc_lkp.str_nbr.cast(IntegerType())==df_loc_val.str_nbr.cast(IntegerType()),how='left')\
.select(df_loc_val['*'],'loc_id')\
.withColumn('loc_id',lpad(coalesce(col('loc_id'),lit(None)),7,' '))

##go to error queue

df_dropfields=df_loc_val.filter(col('loc_id').isNull())\
.withColumn('invalid_desc',lit('V3: Store not found on LDB')).drop('loc_id').select(col('txn_cntr'), col('rec_in_txn_cntr'), col('file_nbr'), col('rec_in_file'),col('partition_nbr'), col('str_nbr'), col('txn_date'), col('txn_time'), col('cashier_nbr'), col('register_nbr'),col('txn_type'), col('txn_nbr'), col('rcd_type'), col('stuff'), col('invalid_desc'))

#df_drop_fields=df_dropfields.union(df_dropfields_1)
dropfields=mountPoint + "/" + dbutils.widgets.get("PAR_NB_RFRM_DROP_FIELDS_1") 
df_dropfields.write.format("parquet").mode("overwrite").save(dropfields)


# COMMAND ----------

##scan1

wspec4 = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr'))

df_validloc=df_loc_val.filter(col('loc_id').isNotNull())\
.withColumn('local_start_time',concat(substring(col('rec_type_M_txn_strt_time'),1,2),lit(':'),substring(col('rec_type_M_txn_strt_time'),3,2),lit(':'),substring(col('rec_type_M_txn_strt_time'),5,2)))\
.withColumn('local_stop_time',concat(substring(col('rec_type_M_txn_stop_time'),1,2),lit(':'),substring(col('rec_type_M_txn_stop_time'),3,2),lit(':'),substring(col('rec_type_M_txn_stop_time'),5,2)))\
.withColumn('local_start_time',when((col('rec_type_M').isNotNull()) & (col('local_start_time')==lit('24:00:00')),lit('00:00:00'))
            .otherwise(col('local_start_time')))\
.withColumn('local_stop_time',when((col('rec_type_M').isNotNull()) & (col('local_stop_time')==lit('24:00:00')),lit('00:00:00'))
            .otherwise(col('local_stop_time')))\
.withColumn('temp_training_ind',when((col('rcd_type')=='A') & (length(trim(col('rec_type_A_training_item')))>0), lit(1)).otherwise(lit(0)))\
.withColumn('temp_training_ind',sum(col('temp_training_ind')).over(wspec3))\
.withColumn('training_ind',when(col('temp_training_ind')>0,lit('Y')).otherwise(lit('N')))\
.withColumn('temp_tax_ind',when((col('rcd_type')=='A') & (substring(col('rec_type_A_upc_tndr'),1,10).eqNullSafe('TAX NUMBER')), lit('Y')).otherwise(lit('N')))\
.withColumn('tax_ind',last(col('temp_tax_ind'),True).over(wspec))\
.withColumn('temp_tax_id',when((col('rcd_type')=='A') & (substring(col('rec_type_A_upc_tndr'),1,10).eqNullSafe('TAX NUMBER')) & (substring(col('rec_type_A_desc_acct_nbr'),1,9).isNotNull()),col('rec_type_A_desc_acct_nbr')).otherwise(lit(None)))\
.withColumn('tax_id',last(col('temp_tax_id'),True).over(wspec))\
.withColumn('temp_offline_txn_ind',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==1) & (~(col('txn_type').eqNullSafe('99'))) & (length(trim(col('rec_type_M_offline')))>0),lit(1)).otherwise(lit(0)))\
.withColumn('temp_offline_txn_ind',sum(col('temp_offline_txn_ind')).over(wspec3))\
.withColumn('offline_txn_ind',when(col('temp_offline_txn_ind')>0,lit('Y')).otherwise(lit('N')))\
.withColumn('temp_post_void_status',when((col('rcd_type')==' ') & (col('rec_in_txn_cntr')==2) & (col('txn_type').eqNullSafe('38')) ,col('rec_type_M_38_not_1st_indicator')).otherwise(lit('--')))\
.withColumn('post_void_status',collect_list(col('temp_post_void_status')).over(wspec2))\
.withColumn('retrnd_item_cnt_tmp',when((col('rec_type_A').isNotNull()) & (trim(col('rec_type_A_retrnd_item'))== "R"),col('rec_type_A_qty')).otherwise(0))\
.withColumn('retrnd_item_cnt',sum(col('retrnd_item_cnt_tmp')).over(wspec3))\
.withColumn('temp_txn_start_dttm',when(((col('rec_type_M').isNotNull()) & (length(trim((col('rec_type_M_txn_strt_time'))))==0)) | (col('rec_type_M_99').isNotNull()),concat(col('txn_date'),lit(' '),substring(col('txn_time'),1,2),lit(':'), substring(col('txn_time'),3,2),lit(':'),lit('00')))
           .when(col('rec_type_M').isNotNull(),concat(col('txn_date'),lit(' '),substring(col('txn_start_time'),1,2),lit(':'), substring(col('txn_start_time'),3,2),lit(':'),substring(col('txn_start_time'),5,6)))\
            .otherwise(None))\
.withColumn('temp_txn_start_dttm',last(col('temp_txn_start_dttm'),True).over(wspec2))\
.withColumn('top_column',min(col('rec_in_txn_cntr')).over(wspec4))\
.withColumn('temp_txn_start_dttm',when((col('top_column')==col('rec_in_txn_cntr')),col('temp_txn_start_dttm'))\
            .otherwise(lit(None)))\
.withColumn('temp_txn_start_dttm',last(col('temp_txn_start_dttm'),True).over(wspec4))\
.withColumn('txn_start_dttm',when(col('temp_txn_start_dttm').isNotNull(),col('temp_txn_start_dttm'))\
           .otherwise(concat(col('txn_date'),lit(' '),substring(col('txn_time'),1,2),lit(':'), substring(col('txn_time'),3,2),lit(':'),lit('01'))))\
.withColumn('temp_txn_end_dttm',when(((col('rec_type_M').isNotNull()) & (length(trim((col('rec_type_M_txn_stop_time'))))==0)) | (col('rec_type_M_99').isNotNull()),concat(col('txn_date'),lit(' '),substring(col('txn_time'),1,2),lit(':'), substring(col('txn_time'),3,2),lit(':'),lit('00')))
           .when(col('rec_type_M').isNotNull(),concat(col('txn_date'),lit(' '),substring(col('txn_stop_time'),1,2),lit(':'), substring(col('txn_stop_time'),3,2),lit(':'),substring(col('txn_stop_time'),5,6)))\
            .otherwise(None))\
.withColumn('temp_txn_end_dttm',last(col('temp_txn_end_dttm'),True).over(wspec2))\
.withColumn('temp_txn_end_dttm',when((col('top_column')==col('rec_in_txn_cntr')),col('temp_txn_end_dttm'))\
            .otherwise(lit(None)))\
.withColumn('temp_txn_end_dttm',last(col('temp_txn_end_dttm'),True).over(wspec4))\
.withColumn('txn_end_dttm',when(col('temp_txn_end_dttm').isNotNull(),col('temp_txn_end_dttm'))\
           .otherwise(concat(col('txn_date'),lit(' '),substring(col('txn_time'),1,2),lit(':'), substring(col('txn_time'),3,2),lit(':'),lit('01'))))\
.drop('temp_tax_ind','temp_tax_id','temp_offline_txn_ind','temp_post_void_status','temp_retrnd_item_cnt','retrnd_item_cnt_tmp','temp_txn_start_dttm','temp_txn_end_dttm','top_column')

#'temp_training_ind',
#scan 2
df_validloc=df_validloc.withColumn('top_column',max(col('rec_in_txn_cntr')).over(wspec))\
.withColumn('tax_ind_int',when(col('top_column')==col('rec_in_txn_cntr'),col('tax_ind')).otherwise(None))\
.withColumn('tax_ind',last(col('tax_ind_int'),True).over(wspec))\
.withColumn('tax_id_int',when(col('top_column')==col('rec_in_txn_cntr'),col('tax_id')).otherwise(None))\
.withColumn('tax_id',last(col('tax_id_int'),True).over(wspec))\
.withColumn('post_void_status_int',when(col('top_column')==col('rec_in_txn_cntr'),col('post_void_status')).otherwise(None))\
.withColumn('post_void_status',last(col('post_void_status_int'),True).over(wspec))\
.drop('tax_ind_int','tax_id_int','offline_txn_ind_int','post_void_status_int','txn_start_dttm_int','txn_end_dttm_int')

#df_validloc.filter(col('txn_start_dttm').isNull()).select("txn_cntr","txn_start_dttm","txn_end_dttm","rec_type_M","rec_type_M_txn_strt_time","rec_type_M_txn_stop_time","rec_type_M_99","txn_date","txn_time","txn_date","local_start_time","local_stop_time").show()

# COMMAND ----------

df_validloc=df_validloc.withColumn('upc_and_desc',when(col('rcd_type') == "A",concat(col('rec_type_A_upc_tndr'), col('rec_type_A_desc_acct_nbr'))).otherwise(lit(' ')))

# wspec = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr').desc()).rowsBetween(Window.unboundedPreceding, Window.currentRow)
# wspec2 = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr').desc())
# wspec3 = Window.partitionBy('txn_cntr')
wspec3 = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr'))

###exchange code

df_exchg_code=df_validloc.join(df_dim_period_lkp,df_validloc.txn_date==df_dim_period_lkp.day_date,how='left')\
.select(df_validloc['*'],'per_id')\
.withColumn('is_regular_returned',when((col('rcd_type')=='D') & (col('retrnd_item_cnt')>0) & (~(col('txn_type').isin(14,15,48))),lit('1')).otherwise(lit('0')))\
.withColumn('temp_exchange_cd',when((col('is_regular_returned')=='1') & ((col('rec_type_D_sell_prc').cast(DoubleType())==0) | (col('rec_type_D_sell_prc').isNull())),lit('E'))\
            .when((col('is_regular_returned')=='1') & (col('rec_type_D_sell_prc').isNotNull()) & (col('rec_type_D_price_sign')=='-'),lit('P'))\
            .when((col('is_regular_returned')=='1') & (col('rec_type_D_sell_prc').isNotNull()) & ((col('rec_type_D_sell_prc').cast(DoubleType())!=0)) & (col('rec_type_D_price_sign')==' '),lit('T'))\
            .when(((col('txn_type')=='14') | (col('txn_type')=='15')) & (col('retrnd_item_cnt')>0),lit('F'))\
            .otherwise(lit(None)))\
.withColumn('temp_exchange_cd',last(col('temp_exchange_cd'),True).over(wspec2))\
.withColumn('D_rec_exist_temp',when(col('rcd_type')=='D',lit('1')).otherwise(lit('0')))\
.withColumn('temp_D_rec_exist',sum(col('D_rec_exist_temp')).over(wspec))\
.withColumn('D_rec_exist',when(col('temp_D_rec_exist')>=1,lit('1')).otherwise(lit('0')))\
.withColumn('top_column',min(col('rec_in_txn_cntr')).over(wspec3))\
.withColumn('temp_exchange_cd_int',when((col('top_column')==col('rec_in_txn_cntr')) & (col('temp_exchange_cd').isNotNull()),col('temp_exchange_cd'))\
            .when((col('top_column')==col('rec_in_txn_cntr')) & (col('temp_exchange_cd').isNull()),lit('--'))\
            .otherwise(lit(None)))\
.withColumn('exchange_cd',last(col('temp_exchange_cd_int'),True).over(wspec3))\
#.drop('temp_exchange_cd','is_regular_returned','D_rec_exist_temp','temp_D_rec_exist','exchange_cd_int','temp_exchange_cd_int','top_column')

#display(df_exchg_code)

# COMMAND ----------

# ####Line Void 

df_rollup=df_exchg_code.withColumn('local_sign',when((col('rcd_type')=='A') & (col('rec_type_A_selling_price').isNotNull()), col('rec_type_A_price_sign')).otherwise(lit(' ')))\
.withColumn('local_amt',when((col('rcd_type')=='A') & (col('rec_type_A_selling_price').isNotNull()), col('rec_type_A_selling_price')).otherwise(lit(0)))\
.withColumn('local_amt',when(col('local_sign')=='-',((col('local_amt')*-1).cast(DecimalType(9,2))).cast(StringType())).otherwise((col('local_amt').cast(DecimalType(9,2))).cast(StringType())))\
.withColumn('seq_nbr',when(col('rcd_type')=='A',(col('seq_nbr_by_rec_type').cast(IntegerType())).cast(StringType())).otherwise(lit('0')))\
.withColumn('upc_nbr',when(col('rcd_type')=='A',col('rec_type_A_upc_tndr')).otherwise(lpad(lit(' '),12,' ')))\
.withColumn('upc_desc',when(col('rcd_type')=='A',col('rec_type_A_desc_acct_nbr')).otherwise(lpad(lit(' '),18,' ')))\
.withColumn('dept',when(col('rcd_type')=='A',col('rec_type_A_dept_nbr')).otherwise(lit('   ')))\
.withColumn('void_ind',when(col('rcd_type')=='A',col('rec_type_A_item_void')).otherwise(lit(' ')))\
.withColumn('qty',when(col('rcd_type')=='A',col('rec_type_A_qty')).otherwise(lit('0')))\
.withColumn('price_verify',when((col('rcd_type')=='A') & (trim(col('rec_type_A_prc_verify'))=='Y'),lit('1')).otherwise(lit('0')))\
.withColumn('valid_item',when((col('rcd_type')=='A') & ((locate('BIRTH',col('upc_nbr'))>0) | (locate('TAX',col('upc_nbr'))>0) | (locate('E-COMM',col('upc_desc'))>0) | (col('price_verify')==1)),lit('0'))\
           .when(col('rcd_type')=='A',lit('1')))\
.withColumn('rec_in_txn_cntr_int',col('rec_in_txn_cntr').cast(IntegerType()))\
.withColumn('local_line',when(col('rcd_type')=='A',concat(lpad(coalesce(col('rec_in_txn_cntr'),lit(' ')),5,' '),lpad(coalesce(col('valid_item'),lit(' ')),1,' '),lpad(coalesce(col('seq_nbr'),lit(' ')),4,' '),lpad(coalesce(col('upc_nbr'),lit(' ')),12,' '),lpad(coalesce(col('upc_desc'),lit(' ')),18,' '),lpad(coalesce(col('dept'),lit(' ')),3,' '),lpad(coalesce(col('local_amt'),lit(' ')),9,' '),col('void_ind'),lpad(coalesce(col('qty'),lit(' ')),5,' '))).otherwise(None))\
.withColumn('cnt_dtl_int',when(col('rcd_type')=='A',lit(1)).otherwise(lit(0)))\
.withColumn('cnt_valid_items_int',when(col('valid_item')=='1',lit('1')).otherwise(lit('0')))\
.withColumn('sum_dtl_int',when(((col('rcd_type')=='A') & (col('valid_item')=='1')),col('local_amt')).otherwise(lit('0')))\
.withColumn('rest_vec_int',when((col('rcd_type')=='A') & (col('valid_item')=='1') & (col('cnt_valid_items_int')>=1),(struct(col('rec_in_txn_cntr_int'),col('local_line'))))
           .when((col('rcd_type')=='A') & (col('valid_item')=='1'),(struct(col('rec_in_txn_cntr_int'),col('local_line')))))\
.withColumn('cnt_voids_int',when((col('rcd_type')=='A') & (trim(col('void_ind')).isin('V','1','2','3','4','5','6','7','8','9','a','b','c','d','e')),lit(1)).otherwise(lit(0)))\
.withColumn('rec_in_file',lit('0000'))\
.withColumn('partition_nbr',lit('0'))\
.groupBy('txn_cntr','file_nbr','rec_in_file','partition_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','loc_id')\
.agg((((sum(col('cnt_dtl_int'))).cast(DecimalType(4,0))).cast(StringType())).alias('cnt_dtl'),(((sum(col('cnt_voids_int'))).cast(DecimalType(4,0))).cast(StringType())).alias('cnt_voids'),(((sum(col('cnt_valid_items_int'))).cast(DecimalType(4,0))).cast(StringType())).alias('cnt_valid_items'),(((sum(col('sum_dtl_int'))).cast(DecimalType(10,2))).cast(StringType())).alias('sum_dtl'),(collect_list(col('rest_vec_int'))).alias('rest_vec'))\
.withColumn('rest_vec',array_sort(col('rest_vec')))\
.withColumn('rest_vec',col('rest_vec.local_line'))

df_pseudo_vec=df_rollup.filter(col('cnt_voids')>0)

# COMMAND ----------

def pseudoVector(cnt_valid_items, input_vect):
    def calculate_vectors(j):  
        remain_vec[j]['remaining_amt'] = 0
        remain_vec[j]['void_ind'] = 'F'
        if len(xref_vec[j]['xref']) == 0:
            xref_vec[j]['xref'] = rest_vec[i]['seq_nbr']
            xref_vec[j]['cnt_xrefs'] = xref_vec[j]['cnt_xrefs'] + 1
        else:
            xref_vec[j]['xref'] = xref_vec[j]['xref'] + rest_vec[i]['seq_nbr']        
            xref_vec[j]['cnt_xrefs'] = xref_vec[j]['cnt_xrefs'] + 1
        xref_vec[i]['xref'] = rest_vec[j]['seq_nbr']
        xref_vec[i]['cnt_xrefs'] = xref_vec[i]['cnt_xrefs'] + 1
        remain_vec[i]['remaining_amt'] = 0

    def init_vectors(step, t_match_void_price, t_match_void_qty):
        match_void_price, match_void_qty =  t_match_void_price, t_match_void_qty
        j = 0
        while (j < local_index):
            if step == 'Step-A':
                if (rest_vec[i]['valid_ind'] and rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] and rest_vec[i]['upc_desc'] == rest_vec[j]['upc_desc'] and
                        remain_vec[j]['void_ind'] == ' ' and match_void_price == rest_vec[j]['selling_price']):  
                    calculate_vectors(j)
                    j = local_index
            elif step == 'Step-B':
                if (rest_vec[i]['valid_ind'] and (
                        rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] or rest_vec[i]['upc_desc'] == rest_vec[j][
                    'upc_desc']) and
                        remain_vec[j]['void_ind'] == ' ' and match_void_price == rest_vec[j]['selling_price']):
                    calculate_vectors(j)
                    j = local_index
            else:
                if (rest_vec[i]['valid_ind'] and rest_vec[i]['dept'] == rest_vec[j]['dept'] and 
                        remain_vec[j]['void_ind'] == ' ' and
                        match_void_price == float(format(rest_vec[j]['selling_price'], '.4f'))):
                    calculate_vectors(j)
                    j = local_index
            j = j + 1

            
    def full_void(step, t_match_void_price, t_match_void_qty):
        match_void_price, match_void_qty = t_match_void_price, t_match_void_qty
        k = local_index - 1
        while (k >= 0):
            max_void_price = 0
            max_void_index = -1
            j = 0
            while (j < local_index):
                if step == 'Step-1.1':
                    if (rest_vec[i]['valid_ind'] and rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] and rest_vec[i]['upc_desc'] == rest_vec[j]['upc_desc'] and
                        j != i and (match_void_unit_price == remain_vec[j]['remaining_unit_price']) and (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):
                        if ((match_positive_sign and max_void_price < remain_vec[j]['remaining_amt']) or
                                (((~(match_positive_sign)) and remain_vec[j]['remaining_amt'] < 0) and max_void_price > remain_vec[j]['remaining_amt'])):
                            max_void_price = float(format(remain_vec[j]['remaining_amt'], '.4f'))
                            max_void_index = j
                elif step == 'Step-1.2':
                    if (rest_vec[i]['valid_ind'] and (rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] or rest_vec[i]['upc_desc'] == rest_vec[j]['upc_desc']) and
                        j != i and (match_void_unit_price == remain_vec[j]['remaining_unit_price']) and (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                      
                        if ((match_positive_sign and max_void_price < remain_vec[j]['remaining_amt']) or
                                (((~(match_positive_sign)) and remain_vec[j]['remaining_amt'] < 0) and max_void_price > remain_vec[j]['remaining_amt'])):
                            max_void_price = float(format(remain_vec[j]['remaining_amt'], '.4f'))
                            max_void_index = j
                else:
                    if (rest_vec[i]['valid_ind'] and rest_vec[i]['dept'] == rest_vec[j]['dept'] and j != i and
                        (match_void_unit_price == remain_vec[j]['remaining_unit_price']) and (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):
                        if ((match_positive_sign and max_void_price < remain_vec[j]['remaining_amt']) or
                                (((~(match_positive_sign)) and remain_vec[j]['remaining_amt'] < 0) and max_void_price > remain_vec[j]['remaining_amt'])): 
                            max_void_price = float(format(remain_vec[j]['remaining_amt'], '.4f'))
                            max_void_index = j
                j = j + 1
                
            if (max_void_index >= 0):
                if ((match_void_unit_price == remain_vec[max_void_index]['remaining_unit_price']) and
                    ((match_positive_sign and match_void_price >= remain_vec[max_void_index]['remaining_amt']) or
                     ((~match_positive_sign) and match_void_price <= remain_vec[max_void_index]['remaining_amt'])) and
                    (match_void_qty >= remain_vec[max_void_index]['remaining_qty'])):
                    match_void_price = match_void_price - remain_vec[max_void_index]['remaining_amt']
                    match_void_qty = match_void_qty - remain_vec[max_void_index]['remaining_qty']
                    remain_vec[i]['remaining_amt'] = float(format(remain_vec[i]['remaining_amt'] + remain_vec[max_void_index]['remaining_amt'], '.4f'))
                    remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - remain_vec[max_void_index]['remaining_qty']
                    remain_vec[max_void_index]['remaining_amt'] = 0
                    remain_vec[max_void_index]['remaining_qty'] = 0
                    remain_vec[max_void_index]['void_ind'] = 'F'
                    if (len(xref_vec[max_void_index]['xref']) == 0):                      
                        xref_vec[max_void_index]['xref'] = rest_vec[i]['seq_nbr']
                        xref_vec[max_void_index]['cnt_xrefs'] = xref_vec[max_void_index]['cnt_xrefs'] + 1
                    else:
                        xref_vec[max_void_index]['xref'] = xref_vec[max_void_index]['xref'] + rest_vec[i]['seq_nbr']
                        xref_vec[max_void_index]['cnt_xrefs'] = xref_vec[max_void_index]['cnt_xrefs'] + 1
                    xref_vec[i]['xref'] = xref_vec[i]['xref'] + rest_vec[max_void_index]['seq_nbr']
                    xref_vec[i]['cnt_xrefs'] = xref_vec[i]['cnt_xrefs'] + 1
                    if (match_void_price == 0):
                        k = 0
            k = k - 1
        return (float(format(match_void_price, '.4f')), match_void_qty)
                
    def partial_void_unit_price(step, t_match_void_price, t_match_void_qty):
        match_void_price, match_void_qty = t_match_void_price, t_match_void_qty
        k = local_index - 1
        while (k >= 0):
            updated_match = 0
            max_void_price = 0
            max_void_index = -1
            j = 0
            while (j < local_index):
                if step == 'Step-2.1':
                    if (rest_vec[i]['valid_ind'] and rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] and rest_vec[i][
                        'upc_desc'] == rest_vec[j]['upc_desc'] and
                            j != i and match_void_unit_price == remain_vec[j]['remaining_unit_price'] and (
                                    remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                      
                        if ((match_positive_sign and max_void_price < remain_vec[j]['remaining_amt']) or
                                (((~match_positive_sign) and remain_vec[j]['remaining_amt'] < 0) and max_void_price >
                                 remain_vec[j]['remaining_amt'])):
                            max_void_price = remain_vec[j]['remaining_amt']
                            max_void_index = j
                elif step == 'Step-2.2':
                    if (rest_vec[i]['valid_ind'] and (rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] or
                                                      rest_vec[i]['upc_desc'] == rest_vec[j][
                                                          'upc_desc']) and j != i and match_void_unit_price ==
                            remain_vec[j]['remaining_unit_price'] and
                            (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                      
                        if ((match_positive_sign and max_void_price < remain_vec[j]['remaining_amt']) or
                                (((~match_positive_sign) and remain_vec[j]['remaining_amt'] < 0) and max_void_price >
                                 remain_vec[j]['remaining_amt'])):
                            max_void_price = remain_vec[j]['remaining_amt']
                            max_void_index = j
                else:
                    if (rest_vec[i]['valid_ind'] and rest_vec[i]['dept'] == rest_vec[j]['dept'] and j != i and
                            match_void_unit_price == remain_vec[j]['remaining_unit_price'] and (
                                    remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                      
                        if ((match_positive_sign and max_void_price < remain_vec[j]['remaining_amt']) or
                                (((~match_positive_sign) and remain_vec[j]['remaining_amt'] < 0) and max_void_price >
                                 remain_vec[j]['remaining_amt'])):
                            max_void_price = remain_vec[j]['remaining_amt']
                            max_void_index = j
                j = j + 1
            if (max_void_index >= 0):
                if ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index]['remaining_unit_price'] and
                     (match_void_price >= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty']))) or
                        (((~match_positive_sign) and remain_vec[max_void_index]['remaining_amt'] < 0) and
                         match_void_unit_price == remain_vec[max_void_index]['remaining_unit_price'] and
                         (match_void_price <= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty']))) and (
                                match_void_qty >= remain_vec[max_void_index]['remaining_qty'])):
                    if (remain_vec[max_void_index]['remaining_qty'] == 0 and match_void_unit_price != 0):
                        temp_remaining_qty = floor(remain_vec[max_void_index]['remaining_amt'] / match_void_unit_price)
                    else:
                        temp_remaining_qty = remain_vec[max_void_index]['remaining_qty']
                    if (match_void_qty < temp_remaining_qty):
                        temp_remaining_qty = match_void_qty
                    if (temp_remaining_qty == 0 and (
                            (match_positive_sign and match_void_price >= remain_vec[max_void_index]['remaining_amt']) or
                            ((~match_positive_sign) and match_void_price <= remain_vec[max_void_index]['remaining_amt']))):
                        match_void_price = match_void_price - remain_vec[max_void_index]['remaining_amt']
                        match_void_qty = match_void_qty - temp_remaining_qty
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + remain_vec[max_void_index][
                            'remaining_amt']
                        remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - temp_remaining_qty
                        remain_vec[max_void_index]['remaining_amt'] = 0
                        remain_vec[max_void_index]['remaining_qty'] = 0
                    elif (temp_remaining_qty == 0 and (
                            (match_positive_sign and match_void_price < remain_vec[max_void_index]['remaining_amt']) or
                            ((~match_positive_sign) and match_void_price > remain_vec[max_void_index]['remaining_amt']))):
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index][
                                                                          'remaining_amt'] - match_void_price
                        remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index][
                                                                          'remaining_qty'] - temp_remaining_qty
                        match_void_price = 0
                        match_void_qty = 0
                        remain_vec[i]['remaining_amt'] = 0
                        remain_vec[i]['remaining_qty'] = 0
                    else:
                        match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty
                        match_void_qty = match_void_qty - temp_remaining_qty
                        remain_vec[i]['remaining_amt'] = remain_vec[i][
                                                             'remaining_amt'] + match_void_unit_price * temp_remaining_qty
                        remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - temp_remaining_qty
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index][
                                                                          'remaining_amt'] - match_void_unit_price * temp_remaining_qty
                        remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index][
                                                                          'remaining_qty'] - temp_remaining_qty
                    if (remain_vec[max_void_index]['remaining_amt'] == 0):
                        remain_vec[max_void_index]['remaining_qty'] = 0
                        remain_vec[max_void_index]['void_ind'] = 'F'
                    else:
                        remain_vec[max_void_index]['void_ind'] = 'P'
                    updated_match = 1
                elif ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index][
                    'remaining_unit_price'] and
                       (match_void_price <= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty']))) or
                      (((~match_positive_sign) and remain_vec[max_void_index]['remaining_amt'] < 0) and
                       match_void_unit_price == remain_vec[max_void_index]['remaining_unit_price'] and
                       (match_void_price >= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty'])))):
                    if (match_void_qty > remain_vec[max_void_index]['remaining_qty']):
                        match_void_price = match_void_price - match_void_unit_price * remain_vec[max_void_index][
                            'remaining_qty']
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + match_void_unit_price * \
                                                         remain_vec[max_void_index]['remaining_qty']
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index][
                                                                          'remaining_amt'] - match_void_unit_price * \
                                                                      remain_vec[max_void_index]['remaining_qty']
                        match_void_qty = match_void_qty - remain_vec[max_void_index]['remaining_qty']
                    else:
                        if (match_void_qty == 0):
                            temp_remaining_qty = floor(match_void_price / remain_vec[max_void_index]['remaining_unit_price'])
                        else:
                            temp_remaining_qty = match_void_qty
                        if (temp_remaining_qty == 0 and match_void_price != 0):
                            remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index][
                                                                              'remaining_amt'] - match_void_price
                            remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index][
                                                                              'remaining_qty'] - temp_remaining_qty
                            remain_vec[i]['remaining_amt'] = 0
                            remain_vec[i]['remaining_qty'] = 0
                            match_void_price = 0
                            match_void_qty = 0
                        else:
                            remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index][
                                                                              'remaining_amt'] - match_void_unit_price * temp_remaining_qty
                            remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index][
                                                                              'remaining_qty'] - temp_remaining_qty
                            remain_vec[i]['remaining_amt'] = remain_vec[i][
                                                                 'remaining_amt'] + match_void_unit_price * temp_remaining_qty
                            remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - temp_remaining_qty
                            match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty
                            match_void_qty = 0
                    if (remain_vec[max_void_index]['remaining_amt'] == 0):
                        remain_vec[max_void_index]['remaining_qty'] = 0
                        remain_vec[max_void_index]['void_ind'] = 'F'
                    else:
                        remain_vec[max_void_index]['void_ind'] = 'P'
                    updated_match = 1
                if (updated_match == 1):
                    if ((len(xref_vec[max_void_index]['xref']) == 0)):
                        xref_vec[max_void_index]['xref'] = rest_vec[i]['seq_nbr']
                        xref_vec[max_void_index]['cnt_xrefs'] = xref_vec[max_void_index]['cnt_xrefs'] + 1
                    else:
                        xref_vec[max_void_index]['xref'] = xref_vec[max_void_index]['xref'] + rest_vec[i]['seq_nbr']
                        xref_vec[max_void_index]['cnt_xrefs'] = xref_vec[max_void_index]['cnt_xrefs'] + 1
                    xref_vec[i]['xref'] = xref_vec[i]['xref'] + rest_vec[max_void_index]['seq_nbr']
                    xref_vec[i]['cnt_xrefs'] = xref_vec[i]['cnt_xrefs'] + 1
                    if (match_void_price == 0):
                        k = 0
            k = k - 1            
        return (float(format(match_void_price, '.4f')), match_void_qty)

    def partial_void_amount(step, t_match_void_price, t_match_void_qty):
        match_void_price, match_void_qty = t_match_void_price, t_match_void_qty
        k = local_index - 1
        while (k >= 0):
            updated_match = 0
            max_void_price = 0
            max_void_index = -1
            j = 0
            while (j < local_index):
                if step == 'Step-3.1':
                    if (rest_vec[i]['valid_ind']  and rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr']  and rest_vec[i]['upc_desc'] == rest_vec[j]['upc_desc']  and j != i  and
                            ((match_positive_sign  and match_void_unit_price <= remain_vec[j]['remaining_unit_price'] or
                              (max_void_price < match_void_unit_price  and max_void_price < remain_vec[j]['remaining_amt'])) or
                             ((~match_positive_sign)  and remain_vec[j]['remaining_amt'] < 0)  and match_void_unit_price >= remain_vec[j]['remaining_unit_price'] or
                             (max_void_price > match_void_unit_price  and max_void_price > remain_vec[j]['remaining_amt']))  and
                             (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                      
                        if ((match_positive_sign  and max_void_price < remain_vec[j]['remaining_amt']) or (((~match_positive_sign) and remain_vec[j]['remaining_amt'] < 0)  and
                            max_void_price > remain_vec[j]['remaining_amt'])):
                            max_void_price = remain_vec[j]['remaining_amt']
                            max_void_index = j
                elif step == 'Step-3.2':
                    if (rest_vec[i]['valid_ind']  and (rest_vec[i]['upc_nbr'] == rest_vec[j]['upc_nbr'] or rest_vec[i]['upc_desc'] == rest_vec[j]['upc_desc'])  and
                        j != i  and ((match_positive_sign  and match_void_unit_price <= remain_vec[j]['remaining_unit_price'] or
                              (max_void_price < match_void_unit_price  and max_void_price < remain_vec[j]['remaining_amt'])) or
                             ((~match_positive_sign)  and remain_vec[j]['remaining_amt'] < 0)  and match_void_unit_price >= remain_vec[j]['remaining_unit_price'] or
                             (max_void_price > match_void_unit_price  and max_void_price > remain_vec[j]['remaining_amt']))  and
                             (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                                                           
                        if ((match_positive_sign  and max_void_price < remain_vec[j]['remaining_amt']) or (((~match_positive_sign)  and remain_vec[j]['remaining_amt'] < 0)  and
                              max_void_price > remain_vec[j]['remaining_amt'])):
                            max_void_price = remain_vec[j]['remaining_amt']
                            max_void_index = j
                else:
                    if (rest_vec[i]['valid_ind']  and rest_vec[i]['dept'] == rest_vec[j]['dept']  and j != i  and
                            ((match_positive_sign  and match_void_unit_price <= remain_vec[j]['remaining_unit_price'] or
                              (max_void_price < match_void_unit_price  and max_void_price < remain_vec[j]['remaining_amt'])) or
                             ((~match_positive_sign)  and remain_vec[j]['remaining_amt'] < 0)  and match_void_unit_price >= remain_vec[j]['remaining_unit_price'] 
                             (max_void_price > match_void_unit_price  and max_void_price > remain_vec[j]['remaining_amt']))  and
                             (remain_vec[j]['void_ind'] == ' ' or remain_vec[j]['void_ind'] == 'P')):                                                   
                        if ((match_positive_sign  and max_void_price < remain_vec[j]['remaining_amt']) or (((~match_positive_sign)  and remain_vec[j]['remaining_amt'] < 0)  and
                                 max_void_price > remain_vec[j]['remaining_amt'])):
                            max_void_price = remain_vec[j]['remaining_amt']
                            max_void_index = j
                j = j + 1
            if (max_void_index >= 0):
                if ((match_positive_sign  and match_void_unit_price <= remain_vec[max_void_index]['remaining_unit_price']  and
                     (match_void_price >= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty']))) or
                        (((~match_positive_sign)  and remain_vec[max_void_index]['remaining_amt'] < 0)  and
                         match_void_unit_price >= remain_vec[max_void_index]['remaining_unit_price']  and
                         (match_void_price <= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty'])))  and
                        (match_void_qty >= remain_vec[max_void_index]['remaining_qty'])):
                    if (remain_vec[max_void_index]['remaining_qty'] == 0  and match_void_unit_price != 0):
                        temp_remaining_qty = floor(remain_vec[max_void_index]['remaining_amt'] / match_void_unit_price) 
                    else:
                        temp_remaining_qty = remain_vec[max_void_index]['remaining_qty']
                    if (match_void_qty < temp_remaining_qty):
                        temp_remaining_qty = match_void_qty
                    if (temp_remaining_qty == 0  and ((match_positive_sign  and match_void_price >=remain_vec[max_void_index]['remaining_amt']) or
                        ((~match_positive_sign)  and match_void_price <= remain_vec[max_void_index]['remaining_amt']))):
                        match_void_price = match_void_price - remain_vec[max_void_index]['remaining_amt']
                        match_void_qty = match_void_qty - temp_remaining_qty
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + remain_vec[max_void_index]['remaining_amt']
                        remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - temp_remaining_qty
                        remain_vec[max_void_index]['remaining_amt'] = 0
                        remain_vec[max_void_index]['remaining_qty'] = 0
                    elif (temp_remaining_qty == 0  and ((match_positive_sign  and match_void_price <remain_vec[max_void_index]['remaining_amt']) or
                          ((~match_positive_sign)  and match_void_price > remain_vec[max_void_index]['remaining_amt']))):
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index]['remaining_amt'] - match_void_price
                        remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index]['remaining_qty'] - temp_remaining_qty
                        match_void_price = 0
                        match_void_qty = 0
                        remain_vec[i]['remaining_amt'] = 0
                        remain_vec[i]['remaining_qty'] = 0
                    else:
                        match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty
                        match_void_qty = match_void_qty - temp_remaining_qty
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + match_void_unit_price * temp_remaining_qty
                        remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - temp_remaining_qty
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index]['remaining_amt'] - match_void_unit_price * temp_remaining_qty
                        remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index]['remaining_qty'] - temp_remaining_qty
                    if (remain_vec[max_void_index]['remaining_amt'] == 0):
                        remain_vec[max_void_index]['remaining_qty'] = 0
                        remain_vec[max_void_index]['void_ind'] = 'F'
                    else:
                        remain_vec[max_void_index]['void_ind'] = 'P'
                    updated_match = 1
                elif ((match_positive_sign  and match_void_unit_price <= remain_vec[max_void_index]['remaining_unit_price']  and
                       (match_void_price <= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty']))) or
                      (((~match_positive_sign)  and remain_vec[max_void_index]['remaining_amt'] < 0)  and
                       match_void_unit_price >= remain_vec[max_void_index]['remaining_unit_price']  and
                       (match_void_price >= (match_void_unit_price * remain_vec[max_void_index]['remaining_qty'])))):
                    if (match_void_qty > remain_vec[max_void_index]['remaining_qty']):
                        match_void_price = match_void_price - match_void_unit_price * remain_vec[max_void_index]['remaining_qty']
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + match_void_unit_price * remain_vec[max_void_index]['remaining_qty']
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index]['remaining_amt'] - match_void_unit_price * remain_vec[max_void_index]['remaining_qty']
                        match_void_qty = match_void_qty - remain_vec[max_void_index]['remaining_qty']
                    else:
                        if (match_void_qty == 0):
                            temp_remaining_qty = floor(match_void_price / remain_vec[max_void_index]['remaining_unit_price'])
                        else:
                            temp_remaining_qty = match_void_qty
                        if (temp_remaining_qty == 0  and match_void_price != 0):
                            remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index]['remaining_amt'] - match_void_price
                            remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index]['remaining_qty'] - temp_remaining_qty
                            remain_vec[i]['remaining_amt'] = 0
                            remain_vec[i]['remaining_qty'] = 0
                            match_void_price = 0
                            match_void_qty = 0
                        else:
                            remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index]['remaining_amt'] - match_void_unit_price * temp_remaining_qty
                            remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index]['remaining_qty'] - temp_remaining_qty
                            remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + match_void_unit_price * temp_remaining_qty
                            remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - temp_remaining_qty
                            match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty
                            match_void_qty = 0
                    if (remain_vec[max_void_index]['remaining_amt'] == 0):
                        remain_vec[max_void_index]['remaining_qty'] = 0
                        remain_vec[max_void_index]['void_ind'] = 'F'
                    else:
                        remain_vec[max_void_index]['void_ind'] = 'P'
                    updated_match = 1
                else:
                    if (match_void_qty >= int(remain_vec[max_void_index]['remaining_qty'])):
                        match_void_price = match_void_price - remain_vec[max_void_index]['remaining_amt']
                        match_void_qty = match_void_qty - remain_vec[max_void_index]['remaining_qty']
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + \
                                                         remain_vec[max_void_index]['remaining_amt']
                        remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - \
                                                         remain_vec[max_void_index]['remaining_qty']
                        remain_vec[max_void_index]['remaining_amt'] = 0
                        remain_vec[max_void_index]['remaining_qty'] = 0
                    elif ((match_positive_sign  and match_void_price < remain_vec[max_void_index]['remaining_amt']) or
                          ((~match_positive_sign)  and match_void_price > remain_vec[max_void_index]['remaining_amt'])):                      
                        remain_vec[max_void_index]['remaining_amt'] = remain_vec[max_void_index]['remaining_amt'] - match_void_price
                        remain_vec[max_void_index]['remaining_qty'] = remain_vec[max_void_index]['remaining_qty'] - match_void_qty
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + match_void_price
                        remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - match_void_qty
                        match_void_price = 0
                        match_void_qty = 0
                    else:
                        match_void_price = match_void_price - remain_vec[max_void_index]['remaining_amt']
                        if (match_void_qty < remain_vec[max_void_index]['remaining_qty']):
                            match_void_qty = 0
                        else:
                            match_void_qty = match_void_qty - remain_vec[max_void_index]['remaining_qty']
                        remain_vec[i]['remaining_amt'] = remain_vec[i]['remaining_amt'] + remain_vec[max_void_index]['remaining_amt']
                        if (remain_vec[i]['remaining_qty'] < remain_vec[max_void_index]['remaining_qty']):
                            remain_vec[i]['remaining_qty'] = 0
                        else:
                            remain_vec[i]['remaining_qty'] = remain_vec[i]['remaining_qty'] - remain_vec[max_void_index]['remaining_qty']
                        remain_vec[max_void_index]['remaining_amt'] = 0
                        remain_vec[max_void_index]['remaining_qty'] = 0
                    if (remain_vec[max_void_index]['remaining_amt'] == 0):
                        remain_vec[max_void_index]['remaining_qty'] = 0
                        remain_vec[max_void_index]['void_ind'] = 'F'
                    else:
                        remain_vec[max_void_index]['void_ind'] = 'P'
                    updated_match = 1
                if (updated_match == 1):
                    if ((len(xref_vec[max_void_index]['xref']) == 0)):
                        xref_vec[max_void_index]['xref'] = rest_vec[i]['seq_nbr']
                        xref_vec[max_void_index]['cnt_xrefs'] = xref_vec[max_void_index]['cnt_xrefs'] + 1
                    else:
                        xref_vec[max_void_index]['xref'] = xref_vec[max_void_index]['xref'] + rest_vec[i]['seq_nbr']
                        xref_vec[max_void_index]['cnt_xrefs'] = xref_vec[max_void_index]['cnt_xrefs'] + 1
                    xref_vec[i]['xref'] = xref_vec[i]['xref'] + rest_vec[max_void_index]['seq_nbr']
                    xref_vec[i]['cnt_xrefs'] = xref_vec[i]['cnt_xrefs'] + 1
                    if (match_void_price == 0):
                        k = 0
            k = k - 1
        return (float(format(match_void_price, '.4f')), match_void_qty)
    
    from math import floor
    outDict = {}
    rest_vec = []
    for rest_vec_item in input_vect:
        rest_vec_dict_item = {}
        rest_vec_dict_item['rec_in_txn_cntr'] = rest_vec_item[0:5].strip()
        rest_vec_dict_item['valid_ind'] = int(rest_vec_item[5:6].strip())
        # ,substring(col('rest_vec_explode'),6,1))\
        rest_vec_dict_item['seq_nbr'] = rest_vec_item[6:10].strip()
        # ,substring(col('rest_vec_explode'),7,4))\
        rest_vec_dict_item['upc_nbr'] = rest_vec_item[10:22]
        # ,substring(col('rest_vec_explode'),11,12))\
        rest_vec_dict_item['upc_desc'] = rest_vec_item[22:40]
        # ,substring(col('rest_vec_explode'),23,18))\
        rest_vec_dict_item['dept'] = rest_vec_item[40:43]
        # substring(col('rest_vec_explode'),41,3))\
        rest_vec_dict_item['selling_price'] = float(rest_vec_item[43:52].strip() or 0)
        # ,substring(col('rest_vec_explode'),44,9))\
        rest_vec_dict_item['void_ind'] = rest_vec_item[52:53]
        # ,substring(col('rest_vec_explode'),53,1))\
        rest_vec_dict_item['qty'] = int(rest_vec_item[53:58].strip())      
        # ,substring(col('rest_vec_explode'),54,5))\
        rest_vec.append(rest_vec_dict_item)
    # pseudoVec = RollupRow.asDict()
#     ------
    local_index = 0
    local_seq_nbr = 0
    tmp_match_void_price = 0
    i = 0
    j = 0
    match_positive_sign = 0
    sum_remaining_amt = 0
    tmp_match_void_qty = 0
    match_void_unit_price = 0
    max_void_price = 0
    k = 0
    updated_match = 0
    temp_remaining_qty = 0
    remain_vec = []
    xref_vec = []
    if (cnt_valid_items > 0):
        for i in range(cnt_valid_items):
            remain_vec_dict = {}
            xref_vec_dict = {}
            remain_vec_dict['remaining_amt'] = float(format(rest_vec[i]['selling_price'], '.4f')) or 0
            remain_vec_dict['void_ind'] = rest_vec[i]['void_ind'] or ' '
            remain_vec_dict['remaining_qty'] = rest_vec[i]['qty'] or 0
            if (rest_vec[i]['qty'] != 0):
                remain_vec_dict['remaining_unit_price'] = float(format(rest_vec[i]['selling_price'] / rest_vec[i]['qty'], '.4f'))
            else:
                remain_vec_dict['remaining_unit_price'] = float(format(rest_vec[i]['selling_price'], '.4f'))
            remain_vec.append(remain_vec_dict)
            xref_vec_dict['xref'] = ''
            xref_vec_dict['cnt_xrefs'] = 0
            xref_vec.append(xref_vec_dict)
            local_index = local_index + 1
        for i in range(local_index):
            if (remain_vec[i]['void_ind'] == 'V' or remain_vec[i]['void_ind'] == '1' or remain_vec[i][
                'void_ind'] == '2' or remain_vec[i]['void_ind'] == '3' or remain_vec[i]['void_ind'] == '4' or
                    remain_vec[i]['void_ind'] == '5' or remain_vec[i]['void_ind'] == '6' or remain_vec[i][
                        'void_ind'] == '7' or remain_vec[i]['void_ind'] == '8' or remain_vec[i]['void_ind'] == '9' or
                    remain_vec[i]['void_ind'] == 'a' or remain_vec[i]['void_ind'] == 'b' or remain_vec[i][
                        'void_ind'] == 'c' or remain_vec[i]['void_ind'] == 'd' or remain_vec[i]['void_ind'] == 'e'):
                tmp_match_void_price = float(format(rest_vec[i]['selling_price'] * -1, '.4f'))
                if (tmp_match_void_price >= 0):
                    match_positive_sign = 1
                else:
                    match_positive_sign = 0
                init_vectors('Step-A', tmp_match_void_price, tmp_match_void_qty)
                if (len(xref_vec[i]['xref']) == 0):
                    init_vectors('Step-B', tmp_match_void_price, tmp_match_void_qty)        
                if (len(xref_vec[i]['xref']) == 0):
                    init_vectors('Step-C', tmp_match_void_price, tmp_match_void_qty)        
        for i in range(local_index):
            if ((remain_vec[i]['void_ind'] == 'V' or remain_vec[i]['void_ind'] == '1' or remain_vec[i][
                'void_ind'] == '2' or remain_vec[i]['void_ind'] == '3' or remain_vec[i]['void_ind'] == '4' or
                     remain_vec[i]['void_ind'] == '5' or remain_vec[i]['void_ind'] == '6' or remain_vec[i][
                         'void_ind'] == '7' or remain_vec[i]['void_ind'] == '8' or remain_vec[i]['void_ind'] == '9' or
                     remain_vec[i]['void_ind'] == 'a' or remain_vec[i]['void_ind'] == 'b' or remain_vec[i][
                         'void_ind'] == 'c' or remain_vec[i]['void_ind'] == 'd' or remain_vec[i]['void_ind'] == 'e') and (
                        len(xref_vec[i]['xref']) == 0)):
                tmp_match_void_price = float(format(rest_vec[i]['selling_price'] * -1, '.4f'))
                tmp_match_void_qty = rest_vec[i]['qty']
                if (tmp_match_void_qty != 0):
                    match_void_unit_price = float(format(tmp_match_void_price /tmp_match_void_qty, '.4f'))
                else:
                    match_void_unit_price = match_void_price
                if (tmp_match_void_price >= 0):
                    match_positive_sign = 1
                else:
                    match_positive_sign = 0
                ##1.1 Full void, exact UPC #, UPC desc and amount match.
                tmp_match_void_price, tmp_match_void_qty = full_void('Step-1.1', tmp_match_void_price, tmp_match_void_qty)
                ##1.2 Full void, exact UPC # or UPC desc and exact amount match.
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = full_void('Step-1.2', tmp_match_void_price, tmp_match_void_qty)
                ##1.3 Full void, exact department and exact amount match
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = full_void('Step-1.3', tmp_match_void_price, tmp_match_void_qty)
                ##2.1 Partial void, exact UPC #, UPC desc, void has unit price match original item unit price.
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = partial_void_unit_price('Step-2.1', tmp_match_void_price, tmp_match_void_qty)
                ##2.2 Partial void, exact UPC # or UPC desc, void has unit price match original item unit price.
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = partial_void_unit_price('Step-2.2', tmp_match_void_price, tmp_match_void_qty)
                ##//2.3 Partial void, exact department, void has unit price match original item unit price.
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = partial_void_unit_price('Step-2.3', tmp_match_void_price, tmp_match_void_qty)
                ##//3.1 Partial void, exact UPC #, UPC desc, but void amount or unit price may not match original item.
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = partial_void_amount('Step-3.1', tmp_match_void_price, tmp_match_void_qty)
                ##//3.2 Partial void, exact UPC # or UPC desc, but void amount or unit price may not match original item
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = partial_void_amount('Step-3.2', tmp_match_void_price, tmp_match_void_qty)
                ##//3.3 Partial void, exact department, but void amount or unit price may not match original item.
                if (tmp_match_void_price != 0):
                    tmp_match_void_price, tmp_match_void_qty = partial_void_amount('Step-3.3', tmp_match_void_price, tmp_match_void_qty)
        for i in range(local_index):
            sum_remaining_amt = float(format(sum_remaining_amt + remain_vec[i]['remaining_amt'], '.4f'))

    outDict['sum_remaining_amt'] = sum_remaining_amt
    outDict['xref_vec'] = xref_vec
    outDict['remain_vec'] = remain_vec
    return outDict

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *


returnSchema = StructType([StructField('remain_vec',ArrayType(StructType([StructField('remaining_amt',StringType(),True),
                                                                         StructField('void_ind',StringType(),True),
                                                                         StructField('remaining_qty',StringType(),True),
                                                                         StructField('remaining_unit_price',StringType(),True)])),True),
                          StructField('xref_vec',ArrayType(StructType([StructField('xref',StringType(),True),
                                                                         StructField('cnt_xrefs',StringType(),True)]),True)),
                                     StructField('sum_remaining_amt',FloatType(),True)])

udf_pseudoVector = udf(pseudoVector,returnSchema)

## 15000 lines code &  Normalise Txn
df_out = df_pseudo_vec.withColumn('outCol',udf_pseudoVector(col('cnt_valid_items').cast('Integer'), col('rest_vec')))\
.withColumn('sum_remaining_amt', col('outCol').sum_remaining_amt)\
.withColumn('match_dtl_to_rem', when(col('outCol').sum_remaining_amt == col('sum_dtl'),1).otherwise(0))\
.withColumn('cnt_xrefs',when(col('cnt_voids')>0,expr("""transform(outCol.xref_vec.cnt_xrefs,x->x)""")))\
.withColumn('void_xref',when(col('cnt_voids')>0,expr("""transform(outCol.xref_vec.xref,x->x)""")))\
.withColumn('void_ind',when(col('cnt_voids')>0,expr("""transform(outCol.remain_vec.void_ind,x->x)""")))\
.withColumn('remaining_amt',when(col('cnt_voids')>0,expr("""transform(outCol.remain_vec.remaining_amt,x->x)""")))\
.withColumn('zipped',arrays_zip(col('rest_vec'),col('cnt_xrefs'),col('void_xref'),col('void_ind'),col('remaining_amt')))\
.withColumn('norm',explode_outer(col('zipped')))\

df_out = df_out.withColumn('rec_in_txn_cntr', substring(col('norm').rest_vec, 0, 5))\
.withColumn('rest_vec_valid_ind', substring(col('norm').rest_vec, 6, 1))\
.withColumn('rest_vec_seq_nbr', substring(col('norm').rest_vec, 7, 4))\
.withColumn('rest_vec_upc_nbr', substring(col('norm').rest_vec, 11, 12))\
.withColumn('rest_vec_upc_desc', substring(col('norm').rest_vec, 23, 18))\
.withColumn('rest_vec_dept', substring(col('norm').rest_vec, 41, 3))\
.withColumn('rest_vec_selling_price', substring(col('norm').rest_vec, 44, 9))\
.withColumn('rest_vec_void_ind', substring(col('norm').rest_vec, 53, 1))\
.withColumn('cnt_xrefs', col('norm').cnt_xrefs)\
.withColumn('void_xref', col('norm').void_xref)\
.withColumn('void_ind', col('norm').void_ind)\
.withColumn('remaining_amt', col('norm').remaining_amt)\
.filter(~(col('void_ind').eqNullSafe(None)))


# COMMAND ----------

# Normalizr Line void xrefs
df_void_xrefs = df_out.filter((col('void_ind') == 'V') | (col('void_ind') == '1') | (col('void_ind') == '2') | (col('void_ind') == '3') | (col('void_ind') == '4') | (col('void_ind') == '5') | (col('void_ind') == '6') | (col('void_ind') == '7') | (col('void_ind') == '8') | (col('void_ind') == '9') | (col('void_ind') == 'a') | (col('void_ind') == 'b') | (col('void_ind') == 'c') | (col('void_ind') == 'd') | (col('void_ind') == 'e'))\
.select(col('txn_cntr').alias('txn_id').cast('bigint'), col('txn_date').alias('txn_dt'), col('rest_vec_seq_nbr').alias('line_item_seq_nbr'), col('rest_vec_selling_price').alias('voiding_dlrs'), col('void_xref').alias('xref_line_item_seq_nbr'), col('loc_id'))

for c in df_void_xrefs.columns:
  df_void_xrefs = df_void_xrefs.withColumn(c,trim(col(c)))
  
df_void_xrefs = df_void_xrefs.withColumn('txn_dt',date_format(to_date(col('txn_dt'),'yyyyMMdd'),'yyyy-MM-dd'))\
.withColumn('line_item_seq_nbr',(col('line_item_seq_nbr').cast(IntegerType())).cast(StringType()))\
.withColumn('voiding_dlrs',(col('voiding_dlrs').cast(DecimalType(9,2))).cast(StringType()))\
.withColumn('xref_line_item_seq_nbr',(col('xref_line_item_seq_nbr').cast(IntegerType())).cast(StringType()))

pos_xrefs=mountPoint + "/" + dbutils.widgets.get("PAR_NB_POS_TXN_DTL")

df_void_xrefs.write.format('parquet').mode("overwrite").save(pos_xrefs)

# COMMAND ----------

# Rfrmt txns for failed 2nd balance check

df_filter_second_balance_check = df_out.filter((col('match_dtl_to_rem') == 0) & (col('txn_type') != 48) & (col('txn_type') != 33))

df_filter_second_balance_check = df_filter_second_balance_check.withColumn('rcd_type', lit('A'))\
.withColumn('item_unit_price', lit(0))\
.withColumn('item_cost', lit(0))\
.withColumn('qty', lit(0))\
.withColumn('tax_type', lit(' '))\
.withColumn('selling_price', when(col('rest_vec_selling_price') < 0, regexp_replace(col('rest_vec_selling_price'), '-', '')).otherwise(col('rest_vec_selling_price')))\
.withColumn('price_sign', when(col('rest_vec_selling_price') < 0, '-').otherwise(' '))\
.withColumn('sale_ind', lit(' '))\
.withColumn('wag_cpn', lit(' '))\
.withColumn('emp_disc', lit(' '))\
.withColumn('keyed_item', lit(' '))\
.withColumn('retrnd_item', lit(' '))\
.withColumn('prc_modify', lit(' '))\
.withColumn('prc_verify', lit(' '))\
.withColumn('training_item', lit(' '))\
.withColumn('special', lit(' '))\
.withColumn('undefined', lit('|'))\
.withColumn('invalid_desc', lit('V5: 2nd BALANCE CHECK FAILED'))\
.select('txn_cntr','rec_in_txn_cntr','file_nbr','rec_in_file','partition_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type',lit(' ').alias('stuff'),'invalid_desc')

#inter_PH7=mountPoint + "/" + dbutils.widgets.get("PAR_NB_DF5_DF8_INT_PART_3") 

df_filter_second_balance_check.write.format('parquet').mode("overwrite").save('/mnt/wrangled/retail/retail_sales/staging/Int_DF5_DF8_Part3')

# COMMAND ----------

df_out_join =df_out.select('txn_cntr','rec_in_txn_cntr','void_ind').withColumn('rec_in_txn_cntr',col('rec_in_txn_cntr').cast(IntegerType()))

# COMMAND ----------

df_Join=df_exchg_code.join(df_out_join,((df_exchg_code.txn_cntr==df_out_join.txn_cntr) & (df_exchg_code.rec_in_txn_cntr==df_out_join.rec_in_txn_cntr)),'leftouter')\
.select(df_exchg_code['*'],'void_ind').withColumn('rec_type_A_voided_ind',col('void_ind'))


#inter_PH5=mountPoint + "/" + dbutils.widgets.get("PAR_NB_DF5_DF6_INT") 

df_Join.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/Int_DF5_DF6_7111T')
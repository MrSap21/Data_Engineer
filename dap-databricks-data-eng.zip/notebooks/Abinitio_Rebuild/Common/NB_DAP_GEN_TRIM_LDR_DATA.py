# Databricks notebook source
# Mounting ADLS
from pyspark.sql import *
 
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#************* Defining ADLS parameters ************


file_path = dbutils.widgets.get("PAR_NB_FILE_PATH")
edw_batch_id = dbutils.widgets.get("PAR_NB_BATCH_ID")

ldrFile = mountPoint + '/' + file_path + '/' + edw_batch_id + '/'
print('ldrFile :'+ldrFile)

# COMMAND ----------

from pyspark.sql.functions import trim,col

#Reading parquet file
ldrDf = spark.read.format("parquet").load(ldrFile)
trimDf = ldrDf.select([trim(col(c)).alias(c) for c in ldrDf.columns])

#overwrite trimmed data
trimDf.write.format("parquet").mode("overwrite").save(ldrFile)
# Databricks notebook source
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_NB_POS_TXN_INS_ERECORDS_ASCII","pos_txn_erecords_insert_ascii")
# dbutils.widgets.text("PAR_NB_POS_TXN_INSERT_ASCII","pos_txn_insert_ascii")
# dbutils.widgets.text("PAR_PL_BATCH_ID","PKB123")
# dbutils.widgets.text("PAR_NB_MAX_SRGT_KEY_INTRM","max_system_surrogate_key_interm")
# dbutils.widgets.text("PAR_NB_MAX_SRGT_KEY_TEMP","max_system_surrogate_key.temp")
# dbutils.widgets.text("PAR_NB_MAX_SRGT_KEY","max_system_surrogate_key")


# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
staging_folder = dbutils.widgets.get('PAR_STAGING_FOLDER')
pos_txn_insert_ascii = dbutils.widgets.get('PAR_NB_POS_TXN_INSERT_ASCII')
df_phase9 = spark.read.format('parquet').load(mountPoint + '/' + staging_folder + '/' + pos_txn_insert_ascii).withColumn('txn_id',col('txn_id').cast(DoubleType())).select('txn_id').distinct()
df_phase1 = spark.read.format('parquet').load(mountPoint + '/' + staging_folder + '/' + 'Int_DF2_DF11_interFile')
#display(df_phase1)

# COMMAND ----------

df_pos_txn_ins_erecords_ascii = df_phase1.join(df_phase9,df_phase1.txn_id==df_phase9.txn_id,how='leftsemi')
df_pos_txn_ins_erecords_ascii = df_pos_txn_ins_erecords_ascii.withColumn('txn_id', col('txn_id').cast('bigint').cast('string'))

# COMMAND ----------

pos_txn_ins_erecords_ascii = mountPoint + "/" + staging_folder + "/" + dbutils.widgets.get("PAR_NB_POS_TXN_INS_ERECORDS_ASCII")
df_pos_txn_ins_erecords_ascii.write.format('parquet').mode('overwrite').save(pos_txn_ins_erecords_ascii)

# COMMAND ----------

max_srgt_interm_file = dbutils.widgets.get('PAR_NB_MAX_SRGT_KEY_INTRM')
maxsgt_interm_arr = spark.read.format('parquet').load(mountPoint + '/' + staging_folder + '/' + max_srgt_interm_file).distinct().where(col('local_key')=='A').select('txn_id').collect()
if len(maxsgt_interm_arr)>0:
  maxsgt_interm = maxsgt_interm_arr[0]['txn_id']
else:
  maxsgt_interm = ''
print(maxsgt_interm)

# COMMAND ----------

max_srgt_file = dbutils.widgets.get('PAR_NB_MAX_SRGT_KEY')
max_srgt_temp_file = dbutils.widgets.get('PAR_NB_MAX_SRGT_KEY_TEMP')
max_srgt_df = spark.read.format('parquet').load(mountPoint + '/' + staging_folder + '/' + max_srgt_file)\
.withColumn('local_key',lit('A'))\
.withColumn('txn_id_temp',lit(maxsgt_interm))\
.withColumn('txn_id',when(col('txn_id_temp')=='',col('txn_id')).otherwise(col('txn_id_temp')))\
.select('local_key','txn_id')
max_srgt_df.write.format('parquet').mode('overwrite').save(mountPoint + '/' + staging_folder + '/' + max_srgt_temp_file)
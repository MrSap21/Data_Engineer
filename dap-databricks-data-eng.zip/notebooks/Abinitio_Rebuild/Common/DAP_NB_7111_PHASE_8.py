# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Declaring global variable")

from pyspark.sql import Window
from pyspark.sql.functions import *
from pyspark.sql.types import *

PAR_IN0_POS_INTERM_path = mountPoint + '/' +dbutils.widgets.get("PAR_POSiNTRM")
PAR_OUTPUT_PATH = mountPoint + '/' + dbutils.widgets.get("PAR_APPENDReRingsToTxnXref")
post_voided_txn_lookup_path = mountPoint + '/' + dbutils.widgets.get("PAR_PostVoidedTxnLookup")
decode_lookup = mountPoint + '/' + dbutils.widgets.get("PAR_DecodeLkp")
RERUNG_PERIOD = 10
RERUNG_RANGE = 3

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Rfrmt to get all detail records")

df_in0 = spark.read.format("parquet").load(PAR_IN0_POS_INTERM_path)
df_in0 = df_in0.filter(((col("rcd_type") == "A") & (trim(col("rec_type_A_prc_verify")) == "")) & ((col("rec_type_A_voided_ind").isNull()) | (ltrim(col("rec_type_A_voided_ind")) == "--") | (trim(col("rec_type_A_voided_ind")) == "")) & ((ltrim(col("rec_type_A_overage_ind")) == "--") | (trim(col("rec_type_A_overage_ind")) == "")))
df_in0 = df_in0.select("txn_cntr","rec_in_txn_cntr","seq_nbr_by_rec_type","partition_nbr","str_nbr","loc_id","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","rcd_type","post_void_status","per_id","rec_type_A_upc_tndr","rec_type_A_desc_acct_nbr","rec_type_A_item_cost","rec_type_A_item_unit_price","rec_type_A_dept_nbr","rec_type_A_qty","rec_type_A_tax_type","rec_type_A_selling_price","rec_type_A_price_sign","rec_type_A_sale_ind","rec_type_A_wag_cpn","rec_type_A_emp_disc","rec_type_A_item_void","rec_type_A_keyed_item","rec_type_A_retrnd_item","rec_type_A_prc_modify","rec_type_A_prc_verify","rec_type_A_training_item","rec_type_A_special","rec_type_A_RX_ind","rec_type_A_voided_ind","rec_type_A_remain_dlrs","rec_type_A_undefined")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Reformat detail items for XREF match")

df_in0_ITEMS_FOR_XREF_MATCH = df_in0.withColumn("txn_id", col("txn_cntr")) \
.withColumn("str_nbr", col("str_nbr")) \
.withColumn("txn_dt", col("txn_date")) \
.withColumn("txn_time", col("txn_time")) \
.withColumn("register_nbr", col("register_nbr")) \
.withColumn("txn_nbr", col("txn_nbr")) \
.withColumn("post_void_status", col("post_void_status")) \
.withColumn("rec_A_upc_tndr", col("rec_type_A_upc_tndr")) \
.withColumn("voiding_txn_id", lit(None)) \
.withColumn("voiding_txn_nbr", lit(None)) \
.withColumn("is_post_void", lit(0)) \
.withColumn("loc_id", col("loc_id"))

df_in0_ITEMS_FOR_XREF_MATCH = df_in0_ITEMS_FOR_XREF_MATCH.select("txn_id","str_nbr","loc_id","txn_dt","txn_time","register_nbr","txn_nbr","post_void_status","rec_A_upc_tndr","voiding_txn_id","voiding_txn_nbr","is_post_void")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Sort on str, register, date, time &&  ABINITIO COMPONENT: Scan on {str_nbr; register_nbr}")

df_post_voided_txn_lookup = spark.read.format("parquet").load(post_voided_txn_lookup_path).select("orig_txn_id", "pv_txn_id", "pv_txn_nbr", "pv_cashier_nbr", "xref_group_nbr", "orig_cashier_nbr", "pv_cashier_nbr")

df_in0_PRE_JOIN = df_in0_ITEMS_FOR_XREF_MATCH.withColumn("local_post_void_status", ltrim(col("post_void_status"))) \
                                             .withColumn("local_voiding_txn_id", lit(None)) \
                                             .withColumn("local_voiding_txn_nbr", lit(None)) \
                                             .withColumn("local_voiding_cashier_nbr", lit(None))

df_in0_voided_txn_lookup = df_in0_PRE_JOIN.join(df_post_voided_txn_lookup, df_in0_PRE_JOIN.txn_id == df_post_voided_txn_lookup.orig_txn_id, "left")

df_in0_voided_txn_lookup = df_in0_voided_txn_lookup.withColumn("local_post_void_status", when(col("orig_txn_id").isNotNull(), lit("V")).otherwise(col("local_post_void_status"))) \
                                                   .withColumn("local_voiding_txn_id", when(col("orig_txn_id").isNotNull(), col("pv_txn_id")).otherwise(col("local_voiding_txn_id"))) \
                                                   .withColumn("local_voiding_txn_nbr", when(col("orig_txn_id").isNotNull(), col("pv_txn_nbr")).otherwise(col("local_voiding_txn_nbr"))) \
                                                   .withColumn("local_voiding_cashier_nbr", when(col("orig_txn_id").isNotNull(), col("pv_cashier_nbr")).otherwise(col("local_voiding_txn_nbr")))

# Mark each dtl record as in post voided if txn has been post voided.

df_in0_voided_txn_lookup = df_in0_voided_txn_lookup.withColumn("in_post_void_grp", when(col("local_post_void_status") == "V", lit(1)).otherwise(lit(0))) \
                                                   .withColumn("post_void_status", when(col("local_post_void_status") == "V", lit("V")).otherwise(col("post_void_status"))) \
                                                   .withColumn("orig_txn_found", when(col("local_post_void_status") == "V", lit(1)).otherwise(lit(0))) \
                                                   .withColumn("voiding_txn_id", col("local_voiding_txn_id")) \
                                                   .withColumn("voiding_txn_nbr", col("local_voiding_txn_nbr")) \
                                                   .withColumn("voiding_cashier_nbr", col("local_voiding_cashier_nbr"))

# Certain sort order is required to establish sequence of txns on each register.
# Isn't this already established with the txn_cntr?

windowSpec  = Window.partitionBy("str_nbr", "register_nbr").orderBy("txn_id")
df_in0_voided_txn_lookup = df_in0_voided_txn_lookup.withColumn("txn_seq_on_regist", dense_rank().over(windowSpec))

# Create output record

df_in0_voided_txn_lookup = df_in0_voided_txn_lookup.select("txn_id","txn_nbr","loc_id","txn_dt","txn_time","str_nbr","register_nbr","post_void_status","rec_A_upc_tndr","orig_txn_found","voiding_txn_id","voiding_txn_nbr","voiding_cashier_nbr","txn_seq_on_regist","in_post_void_grp")

# COMMAND ----------

sc.setJobDescription("ABINITO COMPONENT: Fltr for post voided dtl items")

df_in0_in_post_void_grp_1 = df_in0_voided_txn_lookup.filter("in_post_void_grp == 1")
df_in0_in_post_void_grp_not_1 = df_in0_voided_txn_lookup.filter("in_post_void_grp != 1")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Dedup Sorted on {txn_id; rec_A_upc_tndr}")

df_in0_in_post_void_grp_1_step1 = df_in0_in_post_void_grp_1.dropDuplicates(["txn_id", "rec_A_upc_tndr"])

df_in0_in_post_void_grp_1_step1_filePath = mountPoint + "/retail/retail_sales/staging/INT_df11_Duplicates_in0_in_post_void_grp_1_step1_filePath"

df_in0_in_post_void_grp_1_step1.write.mode('overwrite').parquet(df_in0_in_post_void_grp_1_step1_filePath)

df_in0_in_post_void_grp_1_step1 = spark.read.parquet(df_in0_in_post_void_grp_1_step1_filePath)

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Dedup Sorted on {txn_id; rec_A_upc_tndr}-1")

df_in0_in_post_void_grp_not_1_step1 = df_in0_in_post_void_grp_not_1.dropDuplicates(["txn_id", "rec_A_upc_tndr"])

df_in0_in_post_void_grp_not_1_step1_filePath = mountPoint + "/retail/retail_sales/staging/INT_df11_Duplicates_in0_in_post_void_grp_not_1_step1_filePath"

df_in0_in_post_void_grp_not_1_step1.write.mode('overwrite').parquet(df_in0_in_post_void_grp_not_1_step1_filePath)

df_in0_in_post_void_grp_not_1_step1 = spark.read.parquet(df_in0_in_post_void_grp_not_1_step1_filePath)

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Filter - rec_A_upc_tndr is not blank")

df_in0_in_post_void_grp_1_step2 = df_in0_in_post_void_grp_1_step1.where(col("rec_A_upc_tndr") != "")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Filter - rec_A_upc_tndr is not blank-1")

df_in0_in_post_void_grp_not_1_step2 = df_in0_in_post_void_grp_not_1_step1.where(col("rec_A_upc_tndr") != "")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Rollup - Emulate 'Denormalize'-1")

df_in0_in_post_void_grp_1_step3 = df_in0_in_post_void_grp_1_step2.groupBy("txn_id").agg(collect_list("rec_A_upc_tndr").alias("vorig_vec"), count("rec_A_upc_tndr").alias("vorig_entries"), first("str_nbr").alias("str_nbr"), first("loc_id").alias("loc_id"), first("txn_dt").alias("txn_dt"), first("txn_time").alias("txn_time"), first("register_nbr").alias("register_nbr"), first("txn_nbr").alias("txn_nbr"), first("post_void_status").alias("post_void_status"), first("voiding_txn_id").alias("voiding_txn_id"), first("voiding_txn_nbr").alias("voiding_txn_nbr"), first("txn_seq_on_regist").alias("txn_seq_on_regist"))

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Rollup - Emulate 'Denormalize'")

df_in0_in_post_void_grp_not_1_step3 = df_in0_in_post_void_grp_not_1_step2.groupBy("txn_id").agg(collect_list("rec_A_upc_tndr").alias("other_vec"), count("rec_A_upc_tndr").alias("other_entries"), first("str_nbr").alias("str_nbr"), first("loc_id").alias("loc_id"), first("txn_dt").alias("txn_dt"), first("txn_time").alias("txn_time"), first("register_nbr").alias("register_nbr"), first("txn_nbr").alias("txn_nbr"), first("post_void_status").alias("post_void_status"), first("txn_seq_on_regist").alias("txn_seq_on_regist"))

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: L-Out-Join on {txn_dt; str_nbr}")

df_left = df_in0_in_post_void_grp_1_step3.withColumn("txn_id_l", col("txn_id")).drop("txn_id")
df_right = df_in0_in_post_void_grp_not_1_step3.withColumn("txn_id_r", col("txn_id")).drop("txn_id")
df_join = df_left.join(df_right, ["txn_dt", "str_nbr"], "left") \
                 .select(df_left.str_nbr.alias("str_nbr"), df_left.loc_id.alias("loc_id"), df_left.txn_dt.alias("txn_dt"), df_left.post_void_status.alias("post_void_status"), df_left.voiding_txn_id.alias("voiding_txn_id"), df_left.voiding_txn_nbr.alias("voiding_txn_nbr"), df_left.txn_time.alias("vorig_txn_time"), df_right.txn_time.alias("other_txn_time"), df_left.txn_id_l.alias("vorig_txn_id"), df_right.txn_id_r.alias("other_txn_id"), df_left.register_nbr.alias("vorig_register_nbr"), df_right.register_nbr.alias("other_register_nbr"), df_left.txn_nbr.alias("vorig_txn_nbr"), df_right.txn_nbr.alias("other_txn_nbr"), df_left.vorig_entries.alias("vorig_entries"), df_right.other_entries.alias("other_entries"), df_left.vorig_vec.alias("vorig_vec"), df_right.other_vec.alias("other_vec"), df_left.txn_seq_on_regist.alias("vorig_txn_seq_on_regist"), df_right.txn_seq_on_regist.alias("other_txn_seq_on_regist"))

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Reformat - Calculate match rate")

df_match_rate = df_join.withColumn("local_vorig_txn_time", floor(col("vorig_txn_time")/100) * 60 + (col("vorig_txn_time") -  floor(col("vorig_txn_time")/100) * 100 )) \
                       .withColumn("local_other_txn_time", when(col("other_txn_time").isNotNull(), (floor(col("other_txn_time")/100) * 60) + (col("other_txn_time") -  floor(col("other_txn_time")/100) * 100 )).otherwise(lit(None))) \
                       .withColumn("local_good_sequence", when((col("other_txn_id").isNotNull()) & (((col("vorig_register_nbr") == col("other_register_nbr")) & (col("vorig_txn_seq_on_regist") < col("other_txn_seq_on_regist")) & (col("vorig_txn_seq_on_regist") + RERUNG_RANGE >= col("other_txn_seq_on_regist"))) | ((col("vorig_register_nbr") != col("other_register_nbr")) & (col("local_vorig_txn_time") < col("local_other_txn_time")) & (col("local_vorig_txn_time") + RERUNG_PERIOD >= col("local_other_txn_time")))), lit(True)).otherwise(False))

# Calculate match rate

df_match_rate = df_match_rate.withColumn("local_match_rate", when(col("local_good_sequence") == True, (100 * size(array_intersect(col("vorig_vec"), col("other_vec")))) / size(col("vorig_vec"))).otherwise(lit(0))) \
                       .withColumn("local_good_match_rate", when(col("local_match_rate") >= 50, lit(True)).otherwise(False)) \
                       .withColumn("txn_id", col("voiding_txn_id")) \
                       .withColumn("xref_txn_id", col("vorig_txn_id")) \
                       .withColumn("xref_txn_nbr", col("vorig_txn_nbr")) \
                       .withColumn("potnl_rerung_txn_id", col("other_txn_id")) \
                       .withColumn("match_rate", col("local_match_rate")) \
                       .withColumn("is_potnl_rerung", col("local_good_match_rate") & col("local_good_sequence"))

df_match_rate = df_match_rate.select("txn_id","txn_dt","loc_id","xref_txn_id","xref_txn_nbr","potnl_rerung_txn_id","match_rate","is_potnl_rerung","vorig_txn_time","other_txn_time")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Scan on {txn_id} - count potnl rerung txns")

windowSpec  = Window.partitionBy("txn_id").orderBy(col("potnl_rerung_txn_id").desc()).rowsBetween(Window.unboundedPreceding, Window.currentRow)

df_scan_1 = df_match_rate.withColumn("aux_1", when(col("is_potnl_rerung"), 1).otherwise(0)) \
                         .withColumn("cnt_potnl_rerung_txn", sum("aux_1").over(windowSpec)).drop("aux_1")

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Scan on {txn_id} - assign to group")

windowSpec  = Window.partitionBy("txn_id").orderBy("potnl_rerung_txn_id")
df_scan_2 = df_scan_1.withColumn("cnt_seq", row_number().over(windowSpec)) \
                     .withColumn("cnt_potnl_rerung_txn", first(col("cnt_potnl_rerung_txn")).over(windowSpec))

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Reformat - keep potnl rerung")

df_rfmt = df_scan_2.withColumn("txn_id", when((col("cnt_potnl_rerung_txn") > 0) | (col("cnt_seq") > 1), col("potnl_rerung_txn_id")).otherwise(col("txn_id"))) \
                   .withColumn("potnl_rerung_txn_id", when((col("cnt_potnl_rerung_txn") > 0) | (col("cnt_seq") > 1), col("potnl_rerung_txn_id")).otherwise(lit(None))) \
                   .withColumn("match_pct", when((col("cnt_potnl_rerung_txn") > 0) | (col("cnt_seq") > 1), col("match_rate")).otherwise(None))

df_decode_lookup = spark.read.format("parquet").load(decode_lookup)

xref_type_cd = df_decode_lookup.where((col("cd_type") == "XREF_SCENARIO") & (col("cd_value") == "Post Void")).collect()[0]["cd_id"]
txn_extend_status_cd = df_decode_lookup.where((col("cd_type") == "XREF_SCENARIO_ROLE") & (col("cd_value") == "Rering Txn")).collect()[0]["cd_id"]

df_rfmt = df_rfmt.withColumn("xref_type_cd", lit(xref_type_cd)) \
                     .withColumn("txn_extend_status_cd", lit(txn_extend_status_cd))

df_post_voided_txn_lookup = df_post_voided_txn_lookup.dropDuplicates()

df_rfmt = df_rfmt.join(df_post_voided_txn_lookup, df_rfmt.xref_txn_id == df_post_voided_txn_lookup.orig_txn_id, "left")

df_rfmt = df_rfmt.withColumn("group_nbr", when(col("orig_txn_id").isNotNull(), col("xref_group_nbr")).otherwise(lit(-1))) \
                     .withColumn("orig_txn_cashier_nbr", when(col("orig_txn_id").isNotNull(), col("orig_cashier_nbr")).otherwise(lit(None))) \
                     .withColumn("pvoid_txn_cashier_nbr", when(col("orig_txn_id").isNotNull(), col("pv_cashier_nbr")).otherwise(lit(None)))

df_rfmt = df_rfmt.where((col("is_potnl_rerung") == True) | ((col("cnt_potnl_rerung_txn") == 0) & (col("cnt_seq") == 1)))

# COMMAND ----------

sc.setJobDescription("ABINITIO COMPONENT: Filter by Expression")

df_final = df_rfmt.where(col("match_pct") > 0).withColumn("txn_dt",date_format(to_date(col("txn_dt"),'yyyyMMdd'),'yyyy-MM-dd')).select(col('txn_id').cast('bigint').cast('string').alias('txn_id'),col('txn_dt').cast('string').alias('txn_dt'),col('xref_txn_id').cast('bigint').cast('string').alias('xref_txn_id'),col('potnl_rerung_txn_id').cast('string').alias("potnl_rerung_txn_id"),col('xref_txn_nbr').cast('string').alias('xref_txn_nbr'),round("match_pct").cast('string').alias("match_pct"),col('loc_id').cast('string').alias("loc_id"),col('xref_type_cd').cast('integer').alias('xref_type_cd'),col('txn_extend_status_cd').cast('integer').alias('txn_extend_status_cd'),col('group_nbr').cast('bigint').cast('string').alias('group_nbr'),col('orig_txn_cashier_nbr').cast('string').alias("orig_txn_cashier_nbr"),col('pvoid_txn_cashier_nbr').cast('string').alias("pvoid_txn_cashier_nbr"))

# COMMAND ----------

sc.setJobDescription("APPEND re-rings to txn xref")

df_final.write.mode("append").format("parquet").save(PAR_OUTPUT_PATH)
# Databricks notebook source
# # # #Widgets for passing required parameters values

# dbutils.widgets.text("PAR_IN0_ADR4_Product_Data","/master_data/product/adr7/2022/05/19/mn872p20220401_20220519092523.dat")
# dbutils.widgets.text("PAR_IN1_Detail_Parser","retail/retail_sales/staging/Reformat_Rec_A_Parser")
# dbutils.widgets.text("PAR_IN3_DIM_Product_Replace","retail/retail_sales/staging/dim_product_replace_ascii.pipe_delim")
# dbutils.widgets.text("PAR_max_prod_id_loookup","retail/retail_sales/staging/max_dim_product_surrogate_key")
# dbutils.widgets.text("PAR_OUT0_Max_Prod_ID_Lookup_New","retail/retail_sales/staging/max_dim_product_surrogate_key_temp")
# dbutils.widgets.text("PAR_OUT1_DIM_Product_New","retail/retail_sales/staging/dim_product_replace_ascii")
# dbutils.widgets.text("PAR_OUT2_pos_txn_dtl_insert","retail/retail_sales/staging/pos_txn_dtl_insert_ascii")
# dbutils.widgets.text("PAR_OUT3_ADR4_Error_Queue","retail/retail_sales/staging/ADR4_Error_Queue_ascii/20220119045142")

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import *

PAR_IN0_ADR4_Product_Data = mountPoint + '/'+ dbutils.widgets.get("PAR_IN0_ADR4_Product_Data")
PAR_IN1_Detail_Parser = mountPoint + '/'+ dbutils.widgets.get("PAR_IN1_Detail_Parser")
PAR_IN3_DIM_Product_Replace = mountPoint + '/'+ dbutils.widgets.get("PAR_IN3_DIM_Product_Replace")
PAR_LKP_max_prod_id_loookup = mountPoint + '/'+ dbutils.widgets.get("PAR_max_prod_id_loookup")
PAR_OUT0_Max_Prod_ID_Lookup_New = mountPoint + '/'+ dbutils.widgets.get("PAR_OUT0_Max_Prod_ID_Lookup_New")
PAR_OUT1_DIM_Product_New = mountPoint + '/'+ dbutils.widgets.get("PAR_OUT1_DIM_Product_New")
PAR_OUT2_pos_txn_dtl_insert = mountPoint + '/'+ dbutils.widgets.get("PAR_OUT2_pos_txn_dtl_insert")
PAR_OUT3_ADR4_Error_Queue = mountPoint + '/'+ dbutils.widgets.get("PAR_OUT3_ADR4_Error_Queue")

# COMMAND ----------

with open(PAR_IN0_ADR4_Product_Data,'rb') as f:
    contents = f.read()
s = contents.decode('utf-8',errors='replace')
z = s.split('\n')
rd = sc.parallelize(z)
df_in0_pre = spark.createDataFrame(rd,StringType())
#display(df_in0)

# COMMAND ----------

# Load Input in0

#df_in0 = spark.read.text(PAR_IN0_ADR4_Product_Data)
df_in0_pre1 = df_in0_pre.select(df_in0_pre.value.substr(1,6).alias('wic'), \
              df_in0_pre.value.substr(7,14).alias('upc'), \
              df_in0_pre.value.substr(21,50).alias('desc'), \
              df_in0_pre.value.substr(71,3).alias('dept'), \
              df_in0_pre.value.substr(74,2).alias('multiplier'), \
              df_in0_pre.value.substr(76,7).alias('price'), \
              df_in0_pre.value.substr(83,7).alias('single_unit_rtl'), \
              df_in0_pre.value.substr(90,1).alias('wag_brand_ind'), \
              df_in0_pre.value.substr(91,2).alias('item_svc_type'), \
              df_in0_pre.value.substr(93,1).alias('fsa_ind'), \
              df_in0_pre.value.substr(94,10).alias('profile_id'), \
              df_in0_pre.value.substr(104,3).alias('item_catg_cd'), \
              df_in0_pre.value.substr(107,30).alias('item_catg_cd_desc'), \
              df_in0_pre.value.substr(137,3).alias('item_sales_catg_cd'), \
              df_in0_pre.value.substr(140,200).alias('item_epos_cd_desc'))


df_in0_pre2 = df_in0_pre1.where((trim(col("desc")) != "TEST ITEM") & ((col("wic").rlike("^[0-9]+$"))))


# COMMAND ----------

df_in0_malformed = df_in0_pre2.where(((col('single_unit_rtl')[-1:1]).rlike("[a-zA-z]")))
df_in0_wellformed = df_in0_pre2.subtract(df_in0_malformed)
malformed_columns = [i for i in df_in0_malformed.columns if i not in ['wic','upc']]

for i in range(12,0,-1):
  c1 = malformed_columns[i] 
  c2 = malformed_columns[i-1]
  exp = "concat(substring(" + c2 + ",length(" + c2 + "),length(" + c2 + ")),substring(" + c1 + ",1,length(" + c1 + ")-1))"
  df_in0_malformed = df_in0_malformed.withColumn(c1,expr(exp))
df_in0_malformed = df_in0_malformed.withColumn('desc',expr('substring(desc,1,length(desc)-1)'))

df_in0= df_in0_wellformed.union(df_in0_malformed)
#display(df_in0_malformed.where(col('wic')==334413))

# COMMAND ----------

# Load Input in1

df_in1 = spark.read.parquet(PAR_IN1_Detail_Parser)
#display(df_in1)

# COMMAND ----------

# Load Input in3

df_in3 = spark.read.parquet(PAR_IN3_DIM_Product_Replace)
#display(df_in3.where(col('upc_nbr')==84775000179))

# COMMAND ----------

# Load lookup max prod_id lookup
df_max_prod_id_loookup = spark.read.parquet(PAR_LKP_max_prod_id_loookup)

# COMMAND ----------

# in0 -> Reformat - Trim

df_in0_trim = df_in0.withColumn("wic", trim(col("wic"))) \
               .withColumn("upc", trim(col("upc"))) \
               .withColumn("desc", regexp_replace(trim(col("desc")), '\|', '-')) \
               .withColumn("dept", trim(col("dept"))) \
               .withColumn("multiplier", trim(col("multiplier"))) \
               .withColumn('price',((col("price"))/100).cast(DecimalType(7,2)))\
               .withColumn("single_unit_rtl", trim(col("single_unit_rtl")))\
               .na.fill({'price':0})

df_in0_trim = df_in0_trim.select("wic", "upc", "desc", "dept", "multiplier", "price","single_unit_rtl")
#display(df_in0_trim.where(col('wic').contains('LIGHT')))
#display(df_in0_trim.where(((col('upc'))==4279953685)))
#.withColumn("price2", (((lpad((trim(col("price"))),1,'0')).cast(IntegerType()))/100).cast(DecimalType(7,2))) \

# COMMAND ----------

# in0 -> Filter by validating each field

#df_in0_checked = df_in0_trim.withColumn("valid_record", (col("wic").rlike("^[0-9]+$")) & (col("upc").rlike("^[0-9]+$")) & (col("dept").rlike("^[0-9]+$")) & (col("multiplier").rlike("^[0-9]+$")) & (col("price").rlike("^[0-9]\d*(\.\d+)?$")) & (col("single_unit_rtl").rlike("^[0-9]+$")))

df_in0_checked = df_in0_trim.withColumn("valid_record", (col("wic").isNotNull()) & (col("upc").isNotNull()) & (col("dept").isNotNull()) & (col("multiplier").isNotNull()) & (col("price").isNotNull()) & (col("single_unit_rtl").isNotNull()))


df_in0_valid = df_in0_checked.where(col("valid_record") == True).withColumn('wic',col('wic').cast(DoubleType())).withColumnRenamed('upc','upc_str').withColumn('upc',col('upc_str').cast(DoubleType()))
df_in0_not_valid = df_in0_checked.where(col("valid_record") == False)
#display(df_in0_valid.where(col('upc1').isNull()))
#display(df_in0_not_valid)

# COMMAND ----------

# in0 -> Dedup
wspec = Window.partitionBy('upc').orderBy(col('wic').desc(),col('desc').desc(),col('upc_str').desc())
df_in0_valid_temp = df_in0_valid.withColumn('row_nbr',row_number().over(wspec)).where(col('row_nbr')==1).drop('row_nbr')
df_in0_valid_temp.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/ph7/temp1')
df_in0_final = spark.read.format('parquet').load('/mnt/wrangled/retail/retail_sales/staging/ph7/temp1').drop('upc_str')
#display(df_in0_valid_temp)

# COMMAND ----------

from pyspark.sql.window import *

# L-Join: upc  Match ADR4 with dim_product (Join in3 and in0)

df_in3 = df_in3.withColumn('upc_nbr',col('upc_nbr').cast(DoubleType()))

in0_in3_join = df_in3.join(df_in0_final, df_in0_final.upc == df_in3.upc_nbr, how = 'left_outer')

#display(in0_in3_join)

in0_in3_join_used = in0_in3_join
in0_in3_join_used = in0_in3_join_used.withColumn("upc_desc", when(col("desc").isNotNull(),col('desc')).otherwise(col('prod_desc'))) \
                                     .withColumn("retail_price30_dlrs", when(col("price").isNotNull(),col('price')).otherwise(col('retail_price30_dlrs'))) \
                                     .withColumn("ops_dept_nbr", when(col("dept").isNotNull(),col('dept')).otherwise(col('ops_dept_nbr'))) \
                                     .withColumn("wic_nbr", when(col("wic").isNotNull(),col('wic')).otherwise(col('wic_nbr')))\
                                     .select("prod_id", "upc_nbr", "upc_desc", "wic_nbr", "retail_price30_dlrs", "prod_level_name", "ops_dept_nbr")

in0_in3_join_unused = df_in0_final.join(df_in3, df_in0_final.upc == df_in3.upc_nbr, how = 'left_anti').select('wic','upc','desc','dept','multiplier','price','single_unit_rtl')

# # Fetch max prod id
max_prod_id = int(df_max_prod_id_loookup.where(col("local_key") == "A").collect()[0]["max_prod_id"])

wspec = Window.orderBy(col('upc').asc(),col('wic').desc(),col('desc').desc())

in0_in3_join_unused = in0_in3_join_unused.withColumn('prod_id', row_number().over(wspec) + max_prod_id)\
                                         .withColumn("upc_nbr", col("upc")) \
                                         .withColumn("upc_desc", col("desc")) \
                                         .withColumn("wic_nbr", col("wic")) \
                                         .withColumn("retail_price30_dlrs", col("price")) \
                                         .withColumn("prod_level_name", lit("ADR4-MN610")) \
                                         .withColumn("ops_dept_nbr", col("dept")) \
                                         .select("prod_id", "upc_nbr", "upc_desc", "wic_nbr", "retail_price30_dlrs", "prod_level_name", "ops_dept_nbr")
                        

in0_in3_final = in0_in3_join_used.union(in0_in3_join_unused).withColumn("prod_id", col("prod_id").cast(IntegerType()))
#in0_in3_join_used.select('upc_nbr').distinct().count()#2639023
#in0_in3_join_unused.count()#162
#display(in0_in3_join_unused.where(col('upc_nbr')=='8659876542'))
#display(in0_in3_join_unused)

# COMMAND ----------

# in1 -> Dedup and reformat
df_in1.dropDuplicates(["upc_nbr"]).write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/ph7/temp2')
df_in1_final = spark.read.format('parquet').load('/mnt/wrangled/retail/retail_sales/staging/ph7/temp2')
df_in1_final = df_in1_final.withColumn("ops_dept_nbr", col("dept_nbr")).withColumn('upc_nbr',col('upc_nbr').cast(DoubleType())).select("upc_nbr", "upc_desc", "ops_dept_nbr")
#display(df_in1_final)

# COMMAND ----------

# R-Join: Seek new UPC for POS

df_new_UPC = in0_in3_final.join(df_in1_final, in0_in3_final.upc_nbr == df_in1_final.upc_nbr, "left_outer").select(in0_in3_final['*'])

df_new_UPC_unused = df_in1_final.join(in0_in3_final, df_in1_final.upc_nbr == in0_in3_final.upc_nbr, "left_anti")

#display(df_new_UPC)
#display(df_new_UPC_unused)

# COMMAND ----------

# L-Join: Assign max_prod_id to each new POS' UPC + Scan - Assign prod_id to POS's UPC

# Fetch max prod id
max_prod_id = in0_in3_final.agg({"prod_id": "max"}).collect()[0][0]

df_new_UPC_unused = df_new_UPC_unused.withColumn('max_prod_id',lit(max_prod_id))


wspec = Window.orderBy(col('upc_nbr'))

df_max_prod_id_POS_UPC = df_new_UPC_unused.withColumn('prod_id', row_number().over(wspec) + max_prod_id)\
                                         .withColumn("wic_nbr", lit(0)) \
                                         .withColumn("retail_price30_dlrs", (lit(0)/100).cast(DecimalType(7,2))) \
                                         .withColumn("prod_level_name", lit("EJ-ITEM")) \
                                         .select("prod_id", "upc_nbr", "upc_desc", "wic_nbr", "retail_price30_dlrs", "prod_level_name", "ops_dept_nbr")

#display(df_max_prod_id_POS_UPC)
#print(max_prod_id)

# COMMAND ----------

# Rollup - Seek max prod_id for new POS, ADR4 & dim_product

#columns = ["prod_id", "local_key"]

max_prod_id = df_max_prod_id_POS_UPC.agg({"prod_id": "max"}).collect()[0][0] or max_prod_id

schema = StructType([
       StructField("local_key",StringType(), True),
       StructField("max_prod_id", IntegerType(), True)])
data = [('A',max_prod_id)]

#rdd = spark.sparkContext.parallelize(data)
#df_max_prod_id = rdd.toDF(columns, sampleRatio=0.01)

df_max_prod_id = spark.createDataFrame(data,schema=schema)
#display(df_max_prod_id)

# COMMAND ----------

# Merge on {upc_nbr}

df_merged = df_max_prod_id_POS_UPC.union(df_new_UPC)
df_merged_out = df_merged.withColumn("prod_desc", col("upc_desc")).drop("upc_desc")\
.withColumn('wic_nbr',when(col('wic_nbr').rlike('^[0-9]*$'), lpad(col('wic_nbr').cast(DecimalType(6,0)),6,'0')).otherwise(col('wic_nbr')))\
.na.replace('',None)
#display(df_merged_out.where(col('retail_price30_dlrs2').isNull()))
#df_merged_out.count()
#.na.fill({'retail_price30_dlrs':0})\
#.withColumn('retail_price30_dlrs',(col('retail_price30_dlrs')/100).cast(DecimalType(7,2)))\

# COMMAND ----------

# Dedup Sorted {upc_nbr}

wspec = Window.partitionBy('upc_nbr').orderBy(col('prod_id'))
df_merged_temp = df_merged.withColumn('row_nbr',row_number().over(wspec)).where(col('row_nbr')==1).drop('row_nbr')
df_merged_temp.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/ph7/temp3')
df_merged_final = spark.read.format('parquet').load('/mnt/wrangled/retail/retail_sales/staging/ph7/temp3')

# COMMAND ----------

# L-Join: Assign prod_id to each Rec A

df_final = df_in1.join(df_merged_final,df_in1.upc_nbr==df_merged_final.upc_nbr, "left").select(df_in1['*'],(df_merged_final.prod_id).alias('prod_id'))\
.withColumn('line_item_seq_nbr',lpad(col('line_item_seq_nbr'),5,'0'))\
.withColumn('original_price_dlrs',col('original_price_dlrs').cast(DecimalType(7,2)))\
.select(col('txn_id').cast('bigint').cast('string').alias('txn_id'), 'txn_dt', 'line_item_seq_nbr', 'prod_id', 'upc_desc', 'rx_nbr', 'item_unit_price_dlrs', 'original_price_dlrs', 'selling_price_dlrs', 'tax_type_cd', 'unit_qty', 'item_void_cd', 'ecomm_order_ind', 'ecomm_order_nbr', 'tax_exempt_ind', 'tax_exempt_id', 'over_age_cd', 'birth_date', 'wag_coup_cd', 'mfg_coup_cd', 'discnt_cd', 'fsa_item_ind', 'rx_type_cd', 'rx_not_on_ic_ind', 'price_modify_cd', 'price_verify_ind', 'return_ind', 'sale_ind', 'upc_hardkey_cd', 'dept_hardkey_cd', 'regstr_key_nbr', 'payout_acct_nbr', 'loc_id', 'photo_env_nbr', 'photo_print_cnt', 'walgreen_brand_ind')

#df_final.distinct().count()

# COMMAND ----------

# Write output

df_max_prod_id.write.format("parquet").mode("overwrite").save(PAR_OUT0_Max_Prod_ID_Lookup_New)
df_merged_out.write.format("parquet").mode("overwrite").save(PAR_OUT1_DIM_Product_New)
df_final.distinct().write.format("parquet").mode("overwrite").save(PAR_OUT2_pos_txn_dtl_insert)
df_in0_not_valid.write.format("parquet").mode("overwrite").save(PAR_OUT3_ADR4_Error_Queue)
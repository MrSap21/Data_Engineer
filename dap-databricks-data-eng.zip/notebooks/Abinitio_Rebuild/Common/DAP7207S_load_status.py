# Databricks notebook source
import datetime
import os
from pyspark.sql.types import StructType,StructField, StringType

# COMMAND ----------

dbutils.widgets.text("AI_LOG","",label="AI_LOG")
dbutils.widgets.text("AI_LOAD","",label="AI_LOAD")
dbutils.widgets.text("PROJECT_DIR","",label="PROJECT_DIR")
dbutils.widgets.text("AI_RECYCLE","",label="AI_RECYCLE")
dbutils.widgets.text("AI_INBOUND","",label="AI_INBOUND")
dbutils.widgets.text("AI_PERSIST_SERIAL","",label="AI_PERSIST_SERIAL")

AI_LOG=dbutils.widgets.get("AI_LOG")
AI_LOAD=dbutils.widgets.get("AI_LOAD")
PROJECT_DIR=dbutils.widgets.get("PROJECT_DIR")
AI_RECYCLE=dbutils.widgets.get("AI_RECYCLE")
AI_INBOUND=dbutils.widgets.get("AI_INBOUND")
AI_PERSIST_SERIAL=dbutils.widgets.get("AI_PERSIST_SERIAL")

# COMMAND ----------

JOB_NAME = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split('/')[-1]
LOG_FILE=AI_LOG+'/'+JOB_NAME+'.log.'+datetime.datetime.now().strftime("%m%d%H%M")
HIST_FILE=AI_LOAD+'/job_phase_history_insert_ascii.pipe_delim'
STATS_PARM_FILE=PROJECT_DIR+'/bin/DAP7207_stats.parm'
TEMP_FILE=AI_RECYCLE+'/'+JOB_NAME+'.temp.txt'
INPUT_REC_FILE=AI_RECYCLE+'/'+JOB_NAME+'.input.txt'
E1_REC_FILE=AI_RECYCLE+'/'+JOB_NAME+'.e1.txt'
E2_REC_FILE=AI_RECYCLE+'/'+JOB_NAME+'.e2.txt'
STG_INSRT_REC_FILE=AI_RECYCLE+'/'+JOB_NAME+'.stg_insrt.txt'
DUP_REC_FILE=AI_RECYCLE+'/'+JOB_NAME+'.dup.txt'
TGT_INSRT_REC_FILE=AI_RECYCLE+'/'+JOB_NAME+'.tgt_insrt.txt'
CYCLE_DATE_FILE=AI_INBOUND+'/cycle_date.pipe_delim'
MAX_TXN_KEY_FILE=AI_PERSIST_SERIAL+'/max_system_surrogate_key.dat'
RC=0
RUN_DAY=datetime.datetime.now().strftime("%Y%m%d")

# print(JOB_NAME)
# print(LOG_FILE)
# print(HIST_FILE)
# print(STATS_PARM_FILE)
# print(TEMP_FILE)
# print(INPUT_REC_FILE)
# print(E1_REC_FILE)
# print(E2_REC_FILE)
# print(STG_INSRT_REC_FILE)
# print(DUP_REC_FILE)
# print(TGT_INSRT_REC_FILE)
# print(CYCLE_DATE_FILE)
# print(MAX_TXN_KEY_FILE)

# Load File
dfStatsParm = spark.read.format("csv")\
      .option("header", True)\
      .option("delimiter","|")\
      .load('dbfs:/mnt/wrangled/'+STATS_PARM_FILE)

dfCycleDate = spark.read.format("csv")\
      .option("header", False)\
      .option("delimiter","|")\
      .load('dbfs:/mnt/wrangled/'+CYCLE_DATE_FILE)

dfMaxTxn = spark.read.format("csv")\
      .option("header", False)\
      .option("delimiter","\t")\
      .load('dbfs:/mnt/wrangled/'+MAX_TXN_KEY_FILE)

def file_exists(filename):
  try:
    if dbutils.fs.ls('dbfs:/mnt/wrangled/'+filename)[0][-1]>0:
      return True
    else:
      return False
  except:
    return False
  
def get_latest_file(path,pattern):
  files=[]
  for file in os.listdir(path):
    if file.startswith(pattern):
      files.append(file)
  latest_file=files[0]
  latest=latest_file
  for file in files:
    if os.path.getctime(path+file)>os.path.getctime(path+latest_file):
      latest=file
  return latest

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+".dat")
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

log=[]
log.append(datetime.datetime.now().strftime("%m/%d/%y %H:%M:%S %p")+' Start of '+JOB_NAME)
log.append('Run day = '+RUN_DAY)
log.append(datetime.datetime.now().strftime("%m/%d/%y %H:%M:%S %p")+' Get job_phase parameters')

APPL_ID=dfStatsParm.first()["Appl ID"]
SUBJ_AREA_ID=dfStatsParm.first()["Subject Area"]
JOB_ID=dfStatsParm.first()["Job ID"]
OBJ_NAME=dfStatsParm.first()["Object Name"]
STATUS_CD=dfStatsParm.first()["Status Code"]
CYCLE_BATCH_ID=dfCycleDate.first()[1]
START_TXN_ID=dfCycleDate.first()[2]
END_TXN_ID=dfMaxTxn.first()[1]

log.append(datetime.datetime.now().strftime("%m/%d/%y %H:%M:%S %p")+' Get statistics from POS EJ files')

EJ_CNT_FILE=AI_RECYCLE+'/pos_ej_total_line_cnt.pipe_delime.'+RUN_DAY
ERRQ_DUP_FILE=AI_RECYCLE+'/POSEJ_Error_Queue_Dup*.'+RUN_DAY
ERRQ_LEN_FILE=AI_RECYCLE+'/POSEJ_Error_Queue_invalid_rec*.'+RUN_DAY
ERRQ_WRAP_FILE=AI_RECYCLE+'/POSEJ_Error_Queue_invalid_lead*.'+RUN_DAY
ERRQ_FMT_FILE=AI_RECYCLE+'/POSEJ_Error_Queue_ascii.pipe_delim.'+RUN_DAY
MISC_FILE=AI_RECYCLE+'/Other_E_types_ascii.pipe_delim'

ej_input_rec_cnt=0
errq_dup_rec_cnt=0
errq_len_rec_cnt=0
errq_wrap_rec_cnt=0
errq_fmt_rec_cnt=0
misc_rec_cnt=0

if(file_exists(EJ_CNT_FILE)):
  ej_input_rec_cnt=spark.read.format("csv")\
    .option("header", False)\
    .load('dbfs:/mnt/wrangled/'+EJ_CNT_FILE+'/').first()[0]

if(file_exists(ERRQ_DUP_FILE)):
  errq_dup_rec_cnt=spark.read.format("csv")\
    .option("header", True)\
    .load('dbfs:/mnt/wrangled/'+ERRQ_DUP_FILE+'/').count()

if(file_exists(ERRQ_LEN_FILE)):
  errq_len_rec_cnt=spark.read.format("csv")\
    .option("header", True)\
    .load('dbfs:/mnt/wrangled/'+ERRQ_LEN_FILE+'/').count()

if(file_exists(ERRQ_WRAP_FILE)):
   errq_wrap_rec_cnt=spark.read.format("csv")\
    .option("header", True)\
    .load('dbfs:/mnt/wrangled/'+ERRQ_WRAP_FILE+'/').count()

if(file_exists(ERRQ_FMT_FILE)):
   errq_fmt_rec_cnt=spark.read.format("csv")\
    .option("header", True)\
    .load('dbfs:/mnt/wrangled/'+ERRQ_FMT_FILE+'/').count()

if(file_exists(MISC_FILE)):
   misc_rec_cnt=spark.read.format("csv")\
    .option("header", True)\
    .load('dbfs:/mnt/wrangled/'+MISC_FILE+'/').count()

log.append("ej_input_rec_cnt = "+str(ej_input_rec_cnt))
log.append("errq_dup_rec_cnt = "+str(errq_dup_rec_cnt))
log.append("errq_len_rec_cnt = "+str(errq_len_rec_cnt))
log.append("errq_wrap_rec_cnt = "+str(errq_wrap_rec_cnt))
log.append("errq_fmt_rec_cnt = "+str(errq_fmt_rec_cnt))
log.append("misc_rec_cnt = "+str(misc_rec_cnt))

log.append(datetime.datetime.now().strftime("%m/%d/%y %H:%M:%S %p")+' Create load-ready record for POS EJ stats')

PHASE_ID=1
RUN_NBR=1
OBJ_TYPE="Transform"
TOT_INPUT_CNT=ej_input_rec_cnt
TOT_REJCT_CNT=(( errq_len_rec_cnt + errq_wrap_rec_cnt + errq_fmt_rec_cnt ))
TOT_DUPS_CNT=errq_dup_rec_cnt
TOT_OUTPUT_CNT=misc_rec_cnt
START_DTTM=''
END_DTTM=''

try:
  FILE_START_END_DTTM=get_latest_file('/dbfs/mnt/wrangled/'+AI_LOG+'/','ECDW7111T_main_parser.log')
  log_line=sc.textFile('dbfs:/mnt/wrangled/'+AI_LOG+'/'+FILE_START_END_DTTM)\
            .filter(lambda x: "End of ECDW7111T_main_parser.ksh - successful" in x)
  if(log_line.first()):
    log.append('This Log file - '+FILE_START_END_DTTM+' is not a Successful Log File, so no start_dttm and end_dttm script called for Phase 1')
except:    
  print("Create FILE_START_END_DTTM as separate function")

log.append('Phase '+str(PHASE_ID))
log.append('Object_type = '+str(OBJ_TYPE))
log.append('TOT_INPUT_CNT = '+str(TOT_INPUT_CNT))
log.append('TOT_REJCT_CNT = '+str(TOT_REJCT_CNT))
log.append('TOT_DUPS_CNT = '+str(TOT_DUPS_CNT))
log.append('TOT_OUTPUT_CNT = '+str(TOT_OUTPUT_CNT))

hist = []
hist.append(str(APPL_ID)+'|'+str(SUBJ_AREA_ID)+'|'+str(JOB_ID)+'|'+str(PHASE_ID)+'|'+str(CYCLE_BATCH_ID)+'|'+str(RUN_NBR)+'|'+str(OBJ_NAME)+'|'+str(OBJ_TYPE)+'|'+str(START_DTTM)+'|'+str(END_DTTM)+'|'+str(STATUS_CD)+'|'+str(TOT_INPUT_CNT)+'|'+str(TOT_REJCT_CNT)+'|'+str(TOT_DUPS_CNT)+'|'+str(TOT_OUTPUT_CNT)+'|'+str(START_TXN_ID)+'|'+str(END_TXN_ID)+'|')
dfHist = spark.createDataFrame(hist,StringType())
dfHist.coalesce(1).write.options(header='false',delimiter=',').format("csv").mode("overwrite").save('dbfs:/mnt/wrangled/'+HIST_FILE)
removePartFiles('dbfs:/mnt/wrangled/'+HIST_FILE)

# log.append(datetime.datetime.now().strftime("%m/%d/%y %H:%M:%S %p")+' Create load-ready record for POS EJ stats')
# LOAD_FILE_LIST=['pos_txn','pos_txn_xref','pos_txn_dtl_xref','pos_taxpos_tender','pos_customer_spot','pos_returns_receipt','pos_rx_customer','str_register','pos_txn_dtl']
           
# for FN in LOAD_FILE_LIST:
#   log.append(datetime.datetime.now().strftime("%m/%d/%y %H:%M:%S %p")+' Get stats for '+FN)
#   PHASE_ID = PHASE_ID+1
#   RUN_NBR = RUN_NBR+1
#   OBJ_TYPE=FN

# COMMAND ----------



# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import arrays_zip
from pyspark.sql import functions as F

spark.conf.set("spark.sql.caseSensitive","true")
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
LoyaltyInput_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LOYALTY_INPUT") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
LoyaltyInputFile = spark.read.format('parquet').load(LoyaltyInput_loc)

# COMMAND ----------

#LoyaltyInputFile.cache()

# COMMAND ----------

PCMSEvent=LoyaltyInputFile.withColumn('RetailTransaction_pcms_PCMSEvent',explode_outer('RetailTransaction.pcms:PCMSEvent'))

# COMMAND ----------

############## dap_idl_ngenpos_tran_event ############################### 
LoyaltyTransEvent=PCMSEvent.withColumn('wag_RFN',col('pcms:PCMSTransaction.wag:RFN'))\
                           .withColumn('pcms_ItemLink',col('RetailTransaction_pcms_PCMSEvent.pcms:ItemLink'))\
                           .withColumn('pcms_ApplicationEvent',col('RetailTransaction_pcms_PCMSEvent.pcms:ApplicationEvent'))\
                           .withColumn('DetailNumber',col('RetailTransaction_pcms_PCMSEvent.pcms:DetailNumber._VALUE'))\
                           .withColumn('RetailStoreID',col('Transaction.RetailStoreID'))\
                           .withColumn('SequenceNumber',col('Transaction.SequenceNumber'))\
                           .where(col('pcms_ApplicationEvent').isNotNull())

#dbutils.widgets.text("PAR_NB_NGENPOS_TRAN_EVENT_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_tran_event')
transevent = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_TRAN_EVENT_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

LoyaltyTransEvent=LoyaltyTransEvent.select('RetailStoreID','SequenceNumber','DetailNumber','pcms_ApplicationEvent','pcms_ItemLink','wag_RFN')
#print(LoyaltyTransEvent.count())#67729
LoyaltyTransEvent=LoyaltyTransEvent.dropDuplicates()
#print(LoyaltyTransEvent.count())#67708
#Write to ADLS
LoyaltyTransEvent.write.format('parquet').mode("overwrite").save(transevent)

#######################Encounter file################################
DetailNumber=PCMSEvent.withColumn('wag_SystemOfReference',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:SystemOfReference'))\
                      .withColumn('wag_PaymentType',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PaymentType'))\
                      .withColumn('wag_ServiceLineNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ServiceLineNumber'))\
                      .withColumn('wag_RFN',col('pcms:PCMSTransaction.wag:RFN'))\
                      .withColumn('wag_ClaimIdNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ClaimIdNumber'))\
                     .withColumn('wag_ItemNumberWithDescription', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ItemNumberWithDescription'))\
                     .withColumn('pcms_ItemLink',col('RetailTransaction_pcms_PCMSEvent.pcms:ItemLink'))\
                     .withColumn('SequenceNumber',col('Transaction.SequenceNumber'))


DetailNumber=DetailNumber.where((col('pcms_ItemLink').isNotNull()) | (col('wag_ServiceLineNumber').isNotNull()) | (col('wag_SystemOfReference').isNotNull()) | (col('wag_PaymentType').isNotNull()) | (col('wag_ClaimIdNumber').isNotNull()) | (col(
'wag_ItemNumberWithDescription').isNotNull()))\
                         .select('SequenceNumber','wag_RFN','wag_ServiceLineNumber','wag_SystemOfReference','wag_PaymentType', 'wag_ClaimIdNumber','wag_ItemNumberWithDescription','pcms_ItemLink')

#dbutils.widgets.text("PAR_NB_NGENPOS_ENCOUNTER_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_encounter')
encounter = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_ENCOUNTER_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

#Write to ADLS
DetailNumber.write.format('parquet').mode("overwrite").save(encounter)

#print(DetailNumber.count())--7953

# COMMAND ----------

###################################Loyalty Event ######################
########1. Normalize Loyalty Event ##################
LoyaltyEvent=PCMSEvent.withColumn('valcSubType',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow._valcSubType'))\
                      .withColumn('wag_firstName',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:firstName'))\
                      .withColumn('wag_lookupSucessful', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:lookupSucessful'))\
                      .withColumn('wag_redemptionDisabled', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:redemptionDisabled'))\
                      .withColumn('wag_pinpadOffline', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:pinpadOffline'))\
                      .withColumn('wag_idMethod',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:idMethod'))\
                      .withColumn('wag_zipCodeBy',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:zipCodeBy'))\
                      .withColumn('wag_phoneBy',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:phoneBy'))\
                      .withColumn('wag_lastName',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:lastName'))\
                      .withColumn('wag_seqNum',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:seqNum'))\
                      .withColumn('wag_cardNumber',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:cardNumber'))\
                      .withColumn('wag_memberStatus',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:memberStatus'))\
                      .withColumn('wag_zipCode',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:zipCode'))\
                      .withColumn('wag_loyaltyMbrId',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:loyaltyMbrId'))\
                      .withColumn('wag_phone',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:phone'))\
                      .withColumn('namespace',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow._namespace'))\
                      .withColumn('valc',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow._valc'))\
                      .withColumn('wag_PANEncryptedExternalCardNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PANEncryptedExternalCardNumber'))\
                      .withColumn('wag_HashedCardNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:HashedCardNumber'))\
                      .withColumn('wag_MaskedCardNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:MaskedCardNumber'))\
                      .withColumn('wag_CreditCardBlocked', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:CreditCardBlocked'))\
                      .withColumn('wag_OnlineIndicator',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:onlineIndicator'))\
                      .withColumn('wag_openAcctType',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:openAcctType'))\
                      .withColumn('wag_dobBy',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:dobBy'))\
                      .withColumn('wag_openAcctId',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:openAcctId'))\
                      .withColumn('wag_cardType',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:cardType'))\
                      .withColumn('DetailNumber',col('RetailTransaction_pcms_PCMSEvent.pcms:DetailNumber._VALUE'))\
                      .withColumn('wag_FillNumber',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:FillNumber'))\
                      .withColumn('wag_GovtFundIndicatorForPrimaryPlan', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:GovtFundIndicatorForPrimaryPlan'))\
                      .withColumn('wag_GovtFundIndicatorForCobPlan', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:GovtFundIndicatorForCobPlan'))\
                      .withColumn('wag_PartialFillCode', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PartialFillCode'))\
                      .withColumn('wag_conversion30dayTo90Day', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:conversion30dayTo90Day'))\
                      .withColumn('wag_PinPadFunctional', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PinPadFunctional'))\
                      .withColumn('wag_EmvEnabled',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:EmvEnabled'))\
                      .withColumn('wag_managerId',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:managerId'))\
                      .withColumn('wag_employeeId',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:employeeId'))\
                      .withColumn('wag_RFN',col('rfn'))\
                      .withColumn('ItemLink',col('RetailTransaction_pcms_PCMSEvent.pcms:ItemLink'))\
                      .withColumn('wag_limitApproved', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:limitApproved'))\
                      .withColumn('wag_limitNum',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:limitNum'))\
                      .withColumn('wag_verifyType',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:verifyType'))\
                      .withColumn('wag_providedZipCode', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:providedZipCode'))\
                      .withColumn('wag_actualZipCode', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:actualZipCode'))\
                      .withColumn('wag_success',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:success'))\
                      .withColumn('wag_discInd',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:discInd'))\
                      .withColumn('pcms_ItemLink',col('RetailTransaction_pcms_PCMSEvent.pcms:ItemLink'))\
                      .withColumn('pcms_ApplicationEvent',col('RetailTransaction_pcms_PCMSEvent.pcms:ApplicationEvent'))\
                      .withColumn('wag_SaleLookupStatus', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:SaleLookupStatus'))\
                      .withColumn('wag_MaskedPaymentCard', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:MaskedPaymentCard'))\
                      .withColumn('wag_BalanceRewardCard', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:BalanceRewardCard'))\
                      .withColumn('wag_programCode',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:programCode'))\
                      .withColumn('wag_LastName1',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:LastName'))\
                      .withColumn('wag_FirstName1',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:FirstName'))\
                      .withColumn('wag_EmailID',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:EmailID'))\
                      .withColumn('wag_EcommerceLookupStatus', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:EcommerceLookupStatus'))\
                      .withColumn('wag_BalanceRewardCardNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:BalanceRewardCardNumber'))\
                      .withColumn('wag_ServRecRewardPtsMgrAuth', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ServRecRewardPtsMgrAuth'))\
                      .withColumn('wag_BalanceRewardNumberOfpointsAwarded', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:BalanceRewardNumberOfpointsAwarded'))\
                      .withColumn('wag_BalanceRewardpointsAwarded', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:BalanceRewardpointsAwarded'))\
                      .withColumn('wag_ServRecPercentangeAdjustmentMgrAuth', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ServRecPercentangeAdjustmentMgrAuth'))\
                      .withColumn('wag_ServRecPercentageAdjApplied', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ServRecPercentageAdjApplied'))\
                      .withColumn('wag_ServRecGiftCardMgrAuth', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ServRecGiftCardMgrAuth'))\
                      .withColumn('wag_ServRecGiftCardActivation', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ServRecGiftCardActivation'))\
                      .withColumn('wag_ManagerCashierNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ManagerCashierNumber'))\
                      .withColumn('wag_ManagerEmpID',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ManagerEmpID'))\
                      .withColumn('wag_patientId',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:patientId'))\
                      .withColumn('wag_languageUsed',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:languageUsed'))\
                      .withColumn('wag_numberOfOptOutWindowDisplayed', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:numberOfOptOutWindowDisplayed'))\
                      .withColumn('wag_consentCaptureOutcome', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:consentCaptureOutcome'))\
                      .withColumn('wag_timetakenForConsentCapture', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:timetakenForConsentCapture'))\
                      .withColumn('wag_ScriptID',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:ScriptID'))\
                      .withColumn('wag_Status',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:Status'))\
                      .withColumn('wag_VerificationMode', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:VerificationMode'))\
                      .withColumn('wag_NumberOfIncorrectAttempts', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:NumberOfIncorrectAttempts'))\
                      .withColumn('wag_textEnrollmentCaptureOutcome', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:textEnrollmentCaptureOutcome'))\
                      .withColumn('wag_Data', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:Data'))\
                      .withColumn('wag_InputMethod', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:InputMethod'))\
                      .withColumn('wag_MemberId', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:MemberId'))\
                      .withColumn('wag_WalletCardToken', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:WalletCardToken'))\
                      .withColumn('wag_AuthStatus', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:AuthStatus'))\
                      .withColumn('wag_TxnId', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:TxnId'))\
                      .withColumn('wag_RegisterType', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:RegisterType'))\
                      .withColumn('wag_RxNumber', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:RxNumber'))\
                      .withColumn('wag_Amount', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:Amount'))\
                      .withColumn('wag_PaymentToken', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PaymentToken'))\
                      .withColumn('wag_DeliveryType', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:DeliveryType'))\
                      .withColumn('wag_PointsRedeemed', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PointsRedeemed'))\
                      .withColumn('wag_TotalPointsEarned', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:TotalPointsEarned'))\
                      .withColumn('wag_additionalGMDCall', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:additionalGMDCall'))\
                      .withColumn('wag_OrderNumber',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:OrderNumber'))\
                      .withColumn('wag_Type',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:Type'))\
                      .withColumn('wag_PickupLocation', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PickupLocation'))\
                      .withColumn('wag_LookupMethod',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:LookupMethod'))\
                      .withColumn('wag_EPPId',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:EPPId'))\
                      .withColumn('wag_optInOfferedType', col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:optInOfferedType'))\
                      .withColumn('pcms_BeginDateTime',col('RetailTransaction_pcms_PCMSEvent.pcms:BeginDateTime'))
########1. Normalize Loyalty Event Completed ##################

# COMMAND ----------

######## Reformat Tranform 0 ################
LoyaltyEventPhone = LoyaltyEvent.withColumn('wag_PhoneNumber',col('RetailTransaction_pcms_PCMSEvent.pcms:POSAuditFlow.wag:PhoneNumber'))\
#.withColumn('wag_PhoneNumber',when((~(col('wag_PhoneNumber').rlike('\D+'))),col('wag_PhoneNumber')))


#Writes 2 output files ###############
###### 1. dap_idl_ngenpos_event.dat with DML #########
dap_idl_ngenpos_event = LoyaltyEventPhone.select(col('Transaction.RetailStoreID').alias('RetailStoreID'),
                                         col('Transaction.SequenceNumber').alias('SequenceNumber'),
                                         col('RetailTransaction_pcms_PCMSEvent.pcms:DetailNumber._VALUE').alias('DetailNumber'),
                                         'ItemLink','valcSubType','wag_cardType','wag_firstName','wag_lookupSucessful',
                                          'wag_redemptionDisabled','wag_pinpadOffline','wag_idMethod','wag_zipCodeBy','wag_phoneBy',
                                          'wag_lastName','wag_seqNum','wag_limitApproved','wag_limitNum','wag_cardNumber',
                                          'wag_memberStatus','wag_zipCode','wag_loyaltyMbrId','wag_phone','wag_managerId',
                                          'wag_employeeId','wag_verifyType','wag_providedZipCode','wag_actualZipCode',
                                          'wag_success','wag_discInd','wag_ServRecRewardPtsMgrAuth','wag_BalanceRewardNumberOfpointsAwarded',
                                          'wag_BalanceRewardpointsAwarded','wag_ServRecPercentangeAdjustmentMgrAuth',
                                          'wag_ServRecPercentageAdjApplied','wag_ServRecGiftCardMgrAuth','wag_ServRecGiftCardActivation',
                                          'wag_ManagerCashierNumber','wag_ManagerEmpID','pcms_BeginDateTime','wag_patientId',
                                          'wag_languageUsed','wag_numberOfOptOutWindowDisplayed','wag_consentCaptureOutcome',
                                          'wag_timetakenForConsentCapture','wag_RFN','namespace','valc','wag_OnlineIndicator',
                                          'wag_programCode','wag_optInOfferedType','wag_PhoneNumber','wag_SaleLookupStatus',
                                          'wag_MaskedPaymentCard','wag_BalanceRewardCard','wag_BalanceRewardCardNumber',
                                          'wag_LastName1','wag_FirstName1','wag_EmailID','wag_EcommerceLookupStatus','wag_openAcctType',
                                          'wag_dobBy','wag_openAcctId','wag_FillNumber','wag_GovtFundIndicatorForPrimaryPlan',
                                          'wag_GovtFundIndicatorForCobPlan','wag_PartialFillCode','wag_conversion30dayTo90Day',
                                          'pcms_ApplicationEvent','pcms_ItemLink','wag_PinPadFunctional','wag_EmvEnabled','wag_ScriptID',
                                          'wag_Status','wag_VerificationMode','wag_NumberOfIncorrectAttempts',
                                          'wag_textEnrollmentCaptureOutcome','wag_PointsRedeemed','wag_TotalPointsEarned',
                                          'wag_additionalGMDCall','wag_OrderNumber','wag_Type','wag_PickupLocation','wag_LookupMethod',
                                          'wag_EPPId','wag_InputMethod','wag_Data','wag_MemberId','wag_WalletCardToken','wag_Amount',
                                          'wag_PaymentToken','wag_DeliveryType','wag_AuthStatus','wag_TxnId','wag_RegisterType',
                                          'wag_RxNumber'
                                         )
#dbutils.widgets.text("PAR_NB_NGENPOS_EVENT_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_event')
event = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_EVENT_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
dap_idl_ngenpos_event=dap_idl_ngenpos_event
#Write to ADLS
dap_idl_ngenpos_event.write.format('parquet').mode("overwrite").save(event)
 

# ######### 2.dap_idl_ngenpos_event_work.dat with DML ###############
# dap_idl_ngenpos_event_work = dap_idl_ngenpos_event.drop('wag_AuthStatus','wag_TxnId','wag_RegisterType','wag_RxNumber')

#dbutils.widgets.text("PAR_NB_NGENPOS_EVENT_WORK_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_event_work')
event_work = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_EVENT_WORK_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

#dap_idl_ngenpos_event_work.write.format('parquet').mode("overwrite").save(event_work)

dbutils.fs.rm(event_work,True)

dbutils.fs.cp(event,event_work,True)

# COMMAND ----------

###########Reformat Tranform 1 ######
######Filter by ################
LoyaltyEventHardKey=LoyaltyEvent.filter((col('valcSubType') == 'HardKeyManualEntryCreditCardBlock') & \
                                        (col('wag_CreditCardBlocked').isNotNull()))\
                                .select('Transaction.RetailStoreID','Transaction.SequenceNumber','DetailNumber','ItemLink', 'valcSubType','wag_cardType','wag_seqNum','wag_cardNumber','wag_RFN','namespace','valc','wag_PANEncryptedExternalCardNumber','wag_HashedCardNumber','wag_MaskedCardNumber','wag_CreditCardBlocked','wag_OnlineIndicator','wag_SaleLookupStatus','wag_MaskedPaymentCard','wag_BalanceRewardCard','pcms_ApplicationEvent','pcms_ItemLink')

#dbutils.widgets.text("PAR_NB_NGENPOS_HARDKEY_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_hardkey')
hardkey = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_HARDKEY_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

#######dap_idl_ngenpos_hardkey #####

LoyaltyEventHardKey.write.format('parquet').mode("overwrite").save(hardkey)

# COMMAND ----------

#######Loyalty Retail Transaction Address ##################
RTCustomer=LoyaltyInputFile.withColumn('Customer',explode_outer('RetailTransaction.Customer'))\
                          .withColumn('wag_RFN',col('rfn'))\
                          .withColumn('FullName',col('Customer.CustomerName.FullName'))\
                          .withColumn('Customer_Address',explode_outer('Customer.Address'))\
                          .withColumn('AddrTypeCode',col('Customer_Address._TypeCode'))\
                          .withColumn('AddressLine',explode_outer('Customer_Address.AddressLine'))\
                          .withColumn('PostalCode',col('Customer_Address.PostalCode'))\
                          .withColumn('eMail',col('Customer.eMail'))\
                          .withColumn('CustomerID',col('RetailTransaction.LoyaltyAccount.CustomerID'))\
                          .withColumn('LoyaltyAccountID',col('RetailTransaction.LoyaltyAccount.LoyaltyProgram.LoyaltyAccountID'))\
                          .withColumn('LoyaltyProgramID',col('RetailTransaction.LoyaltyAccount.LoyaltyProgram.LoyaltyProgramID'))\
                          .withColumn('TelTypeCode',col('Customer.Telephone._TypeCode'))\
                          .withColumn('FullTelephoneNumber',col('Customer.Telephone.FullTelephoneNumber'))

#RTCustomer.display()

# COMMAND ----------

RTAddress=RTCustomer.select('Transaction.RetailStoreID','Transaction.SequenceNumber','FullName','AddrTypeCode','AddressLine','PostalCode','eMail','CustomerID','LoyaltyAccountID','LoyaltyProgramID','Transaction.WorkstationID','wag_RFN')

# COMMAND ----------

########## RT Telephone #########

RTTelephone=RTCustomer.withColumn('FullTelephoneNumber',col('FullTelephoneNumber')[-10:10])\
#.withColumn('FullTelephoneNumber',when((~(col('FullTelephoneNumber').rlike('\D+'))),col('FullTelephoneNumber')))

RTTelephone=RTTelephone.select('TelTypeCode','FullTelephoneNumber','wag_RFN')

# COMMAND ----------

############Retail Transaction Event,Workstation & Location ##############
############ Transform 0 ########

RTTransform1 = LoyaltyInputFile.withColumn('wag_CashierNumber',col('pcms:PCMSTransaction.wag:CashierNumber'))\
                              .withColumn('wag_CashierEmployeeID',col('pcms:PCMSTransaction.wag:CashierEmployeeID'))\
                              .withColumn('wag_RFN',col('pcms:PCMSTransaction.wag:RFN'))\
                              .withColumn('Reason',col('RetailTransaction.Reason'))

RTTransform1=RTTransform1.select('Transaction.RetailStoreID','Transaction.SequenceNumber','wag_RFN','wag_CashierEmployeeID','wag_CashierNumber','Reason','Transaction.BusinessDayDate')

#####dap_idl_ngenpos_cashier
#dbutils.widgets.text("PAR_NB_NGENPOS_CASHIER_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_cashier')
cashier = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_CASHIER_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

RTTransform1.write.format("parquet").mode("overwrite").save(cashier)

############ Transform 1 ########

RTTransform2=LoyaltyInputFile.withColumn('pcms_TransactionType',col('pcms:PCMSTransaction.pcms:TransactionType'))\
                             .withColumn('pcms_WorkstationLocation',col('pcms:PCMSTransaction.pcms:WorkstationLocation'))\
                             .withColumn('wag_RFN',col('pcms:PCMSTransaction.wag:RFN'))
RTTransform2=RTTransform2.select('pcms_TransactionType','pcms_WorkstationLocation','wag_RFN')

####dap_idl_ngenpos_workstationloc.dat
#dbutils.widgets.text("PAR_NB_NGENPOS_WORKSTNLOC_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_workstationloc')
workstationloc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_WORKSTNLOC_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

RTTransform2.write.format("parquet").mode("overwrite").save(workstationloc)

############ Transform 2 ########
RTTransform3=RTCustomer.select('Transaction.RetailStoreID','Transaction.SequenceNumber','FullName','AddrTypeCode','AddressLine','PostalCode','TelTypeCode','FullTelephoneNumber','eMail','CustomerID','LoyaltyAccountID','LoyaltyProgramID','Transaction.WorkstationID','wag_RFN')

RTTransform3=RTTransform3.dropDuplicates(['wag_RFN'])

#dbutils.widgets.text("PAR_NB_TELEPHONE_DEDUP_TEMP_FILE_PATH",'retail/retail_sales/staging/DAP7252_Intermediate')
deduptemp = mountPoint + "/" + dbutils.widgets.get("PAR_NB_TELEPHONE_DEDUP_TEMP_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

RTTransform3.write.format("parquet").mode("overwrite").save(deduptemp)


# COMMAND ----------

RTTransform3Load=spark.read.format('parquet').load(deduptemp)


#####JOIN  #####

RTJoin1=RTTransform3Load.join(RTAddress, RTTransform3Load.wag_RFN == RTAddress.wag_RFN,"leftouter").select(RTTransform3Load.RetailStoreID,RTTransform3Load.SequenceNumber,RTTransform3Load.FullName,RTAddress.AddrTypeCode,RTAddress.AddressLine,RTAddress.PostalCode,RTTransform3Load.eMail,RTTransform3Load.CustomerID,RTTransform3Load.LoyaltyAccountID,RTTransform3Load.LoyaltyProgramID,RTTransform3Load.WorkstationID,RTTransform3Load.wag_RFN)

#RTJoin1=RTJoin1.dropDuplicates()

### Join RTTelephone and RTJoin1  on wag_RFN
RTJoin2=RTJoin1.join(RTTelephone,RTJoin1.wag_RFN == RTTelephone.wag_RFN,"inner").select(RTJoin1['*'],RTTelephone.TelTypeCode,RTTelephone.FullTelephoneNumber)

# File 1 dap_idl_ngenpos_header 
dap_idl_ngenpos_header = RTJoin2.select('RetailStoreID','SequenceNumber','FullName','AddrTypeCode','AddressLine','PostalCode','TelTypeCode','FullTelephoneNumber','eMail','CustomerID','LoyaltyAccountID','LoyaltyProgramID','WorkstationID','wag_RFN').dropDuplicates()


#dbutils.widgets.text("PAR_NB_NGENPOS_HEADER_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_header')
header = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_HEADER_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

dap_idl_ngenpos_header.write.format('parquet').mode("overwrite").save(header)

##### 2 File dap_idl_ngenpos_header_work same DML we will verify once again  this one ########
#dbutils.widgets.text("PAR_NB_NGENPOS_HEADER_WORK_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_header_work')
header_work = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_HEADER_WORK_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

dbutils.fs.rm(header_work,True)

dbutils.fs.cp(header,header_work,True)

# COMMAND ----------

####LoyaltyInputFile.columns
RTLineItem=LoyaltyInputFile.withColumn('LineItem',explode_outer(col('RetailTransaction.LineItem')))\
                     .withColumn('SequenceNumber',col('LineItem.SequenceNumber'))

# 4 Tranform ####
RTLineItem_4=RTLineItem.withColumn('LineItem_pcms:PCMSLineItem_pcms:DetailNumber', explode_outer('LineItem.pcms:PCMSLineItem.pcms:DetailNumber'))\
                     .withColumn('DetailNumber',col('LineItem_pcms:PCMSLineItem_pcms:DetailNumber._VALUE'))\
                     .withColumn('wag_LoyaltyEligibilityInd',col('LineItem.wag:LoyaltyEligibilityInd'))\
                     .withColumn('wag_RFN',col('rfn'))\
                     .withColumn('wag_AdvertisedPriceIndicator',col('LineItem.wag:AdvertisedPriceIndicator'))\
                     .withColumn('DetailType',col('LineItem_pcms:PCMSLineItem_pcms:DetailNumber._TxnType'))\
                     .withColumn('wag_EwicInd',col('LineItem.wag:EwicInd'))\
                     .withColumn('category_name',col('LineItem.pcms:PCMSCustomData._Name'))\
                     .withColumn('category_code',col('LineItem.pcms:PCMSCustomData._VALUE'))\
                     .withColumn('pcms_LineType',col('LineItem._LineType'))\
                     .withColumn('pcms_ItemLink',col('LineItem.pcms:PCMSLineItem.pcms:ItemLink'))\
                     .withColumn('Description',col('LineItem.Sale.Description'))\
                     .withColumn('SerialNumber',col('LineItem.Sale.SerialNumber'))\
                     .withColumn('wag_AccountNumber',col('LineItem.wag:AccountNumber'))\
                     .withColumn('wag_ActivationStatus',col('LineItem.wag:ActivationStatus'))\
                     .withColumn('wag_CardType',col('LineItem.wag:CardType'))\
                     .withColumn('wag_Reloadable',col('LineItem.wag:Reloadable'))\
                     .withColumn('EntryMethod',col('LineItem._EntryMethod'))\
                     .withColumn('LoyaltyAccountID',col('RetailTransaction.LoyaltyAccount.LoyaltyProgram.LoyaltyAccountID'))\
                     .withColumn('LoyaltyProgramID',col('RetailTransaction.LoyaltyAccount.LoyaltyProgram.LoyaltyProgramID'))\
                     .withColumn('wag_OrigRfn',col('LineItem.wag:OrigRfn'))\
                     .withColumn('wag_OrigAmt',col('LineItem.wag:OrigAmt'))\
                     .withColumn('wag_RefundStatus',col('LineItem.wag:RefundStatus'))\
                     .withColumn('return_price',col('LineItem.Return.ExtendedAmount'))\
                     .withColumn('pcms_ReasonCode',col('LineItem.Sale.pcms:PCMSSale.pcms:ReasonCode'))\
                     .withColumn('pcms_PriceDiscountable',col('LineItem.Sale.pcms:PCMSSale.pcms:PriceDiscountable'))\
                     .withColumn('ActualSalesUnitPrice',col('LineItem.Sale.ActualSalesUnitPrice'))\
                     .withColumn('ServiceCode',col('LineItem.Tender.CreditDebit.ServiceCode'))\
                     .withColumn('CancelFlag',col('LineItem._CancelFlag'))\
                     .withColumn('wag_SerialNumber',col('LineItem.pcms:PCMSRefusedSale.wag_SerialNumber'))\
                     .withColumn('wag_LotNumber',col('LineItem.pcms:PCMSRefusedSale.wag_LotNumber'))\
                     .withColumn('wag_ExpiredItem',col('LineItem.pcms:PCMSRefusedSale.wag_ExpiredItem'))\
                     .withColumn('wag_GTIN',col('LineItem.pcms:PCMSRefusedSale.wag_GTIN'))\
                     .withColumn('wag_MfgDate',col('LineItem.pcms:PCMSRefusedSale.wag_MfgDate'))\
                     .withColumn('wag_ExpirationDate',col('LineItem.pcms:PCMSRefusedSale.wag_ExpirationDate'))\
                     .withColumn('PrimaryLabel',col('LineItem.Tender.Coupon.PrimaryLabel'))\
                     .withColumn('wag_GS1Barcode',col('LineItem.wag:GS1Barcode'))\
                     .withColumn('MerchandiseHierarchy',when((col('LineItem.Sale.MerchandiseHierarchy._VALUE').isNotNull()), col('LineItem.Sale.MerchandiseHierarchy._VALUE'))
                                          .when(col('LineItem.Return.MerchandiseHierarchy._VALUE').isNotNull(), col('LineItem.Return.MerchandiseHierarchy._VALUE')))


RTLineItem_4=RTLineItem_4.filter((col('DetailType')=='TxnDetail') | (col('DetailType')=='TxnMedia'))\
                         .select('wag_RFN','SequenceNumber','DetailNumber','pcms_LineType','pcms_ItemLink','DetailType', 'wag_AccountNumber','wag_ActivationStatus','wag_CardType','wag_Reloadable','EntryMethod','LoyaltyAccountID','LoyaltyProgramID','return_price','wag_OrigRfn','wag_OrigAmt','wag_RefundStatus','wag_EwicInd','category_name','category_code','wag_LoyaltyEligibilityInd','wag_AdvertisedPriceIndicator','Description','SerialNumber','pcms_ReasonCode','pcms_PriceDiscountable','ActualSalesUnitPrice','ServiceCode','CancelFlag','MerchandiseHierarchy','wag_SerialNumber','wag_LotNumber','wag_ExpiredItem','wag_GTIN','wag_MfgDate','wag_ExpirationDate','PrimaryLabel','wag_GS1Barcode')

####  dap_idl_ngenpos_lineitem  ######

#dbutils.widgets.text("PAR_NB_NGENPOS_LINEITEM_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_lineitem')
lineitem = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_LINEITEM_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

RTLineItem_4.write.format('parquet').mode("overwrite").save(lineitem)

# COMMAND ----------

###### 3 Transform

RTLineItem_3=RTLineItem.withColumn('RetailPriceModifier',explode_outer('LineItem.Sale.RetailPriceModifier'))\
                        .withColumn('MethodCode',col('RetailPriceModifier._MethodCode'))\
                        .withColumn('PromotionID',col('RetailPriceModifier.PromotionID'))\
                        .withColumn('ReasonCode',col('RetailPriceModifier.ReasonCode'))\
                        .withColumn('Amount',col('RetailPriceModifier.Amount._VALUE'))\
                        .withColumn('Action',col('RetailPriceModifier.Amount._Action'))\
                        .withColumn('DiscountText',col('RetailPriceModifier.pcms:PCMSRetailPriceModifier.pcms:DiscountText'))\
                        .withColumn('wag_RFN',col('pcms:PCMSTransaction.wag:RFN'))\
                        .withColumn('pcms_LineType',col('LineItem._LineType')).filter((col('ReasonCode').isNotNull()))\
.select('wag_RFN','SequenceNumber','pcms_LineType','MethodCode','PromotionID','ReasonCode','Amount', 'Action','DiscountText')

##dap_idl_ngenpos_promotion_id.dat

#dbutils.widgets.text("PAR_NB_NGENPOS_PROMOTION_ID_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_promotion_id')
promotion_id = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_PROMOTION_ID_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

RTLineItem_3.write.format('parquet').mode("overwrite").save(promotion_id)

# COMMAND ----------

####### 2 Transform #################

RTLineItem_2=RTLineItem.withColumn('SequenceNumber',col('LineItem.SequenceNumber'))\
                       .withColumn('EntryMethod',col('LineItem._EntryMethod'))\
                       .withColumn('pcms_LineType',col('LineItem._LineType'))\
                       .withColumn('pcms_ItemLink',col('LineItem.pcms:PCMSLineItem.pcms:ItemLink'))\
                       .withColumn('wag_RFN',col('rfn'))\
                       .withColumn('DetailNumber',col('detail_nbr'))\
                       .filter((col('pcms_LineType')=='214') & (col('pcms_ItemLink').isNotNull()))\
                       .select('wag_RFN','SequenceNumber','DetailNumber','pcms_LineType','pcms_ItemLink','EntryMethod')

#dbutils.widgets.text("PAR_NB_NGENPOS_ITR_ENTRY_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_itr_entry_method_code')
itr_entry = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_ITR_ENTRY_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

RTLineItem_2.write.format('parquet').mode("overwrite").save(itr_entry)

# COMMAND ----------

###### 1 Transform 

RTLineItem_T=RTLineItem.withColumn('POSIdentity',explode_outer(col('LineItem.Sale.POSIdentity')))\
                       .withColumn('DetailNumber',explode_outer(col('LineItem.pcms:PCMSLineItem.pcms:DetailNumber')))\
                       .withColumn('barcode',when(((col('POSIdentity._POSIDType') == 'OriginalBarcode') & (length(col('POSIdentity.POSItemID')) <=45)),col('POSIdentity.POSItemID')).otherwise(lit(None).cast(StringType())))
                      


### Tranform 0 
dap_idl_ngenpos_immunization_encounter = RTLineItem_T.select(col('LineItem.SequenceNumber').alias('SequenceNumber'),
                              trim(col('DetailNumber._VALUE')).alias('DetailNumber'),
                              col('LineItem.pcms:PCMSLineItem.pcms:ItemLink').alias('pcms_ItemLink'),
                              col('rfn').alias('wag_RFN'),
                              col('LineItem._LineType').alias('pcms_LineType'),
                              col('LineItem.Sale.ExtendedAmount').alias('service_dlrs'),
                              (lit(None).cast(StringType())).alias('sales_ord_src_type'),
                              (lit(None).cast(StringType())).alias('src_sys_cd'),
                              col('txn_date').alias('txn_date'),
                              col('LineItem.SequenceNumber').alias('line_item_seq_nbr'),
                              col('barcode').alias('barcode'),
                              col('LineItem.Sale.ItemID').alias('upc_nbr'))\
.filter((col('service_dlrs').isNotNull()))

#dbutils.widgets.text("PAR_NB_NGENPOS_IMMUNIZATION_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_immunization')
immunization = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_IMMUNIZATION_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
dap_idl_ngenpos_immunization_encounter.write.format('parquet').mode("overwrite").save(immunization)

##Tranform1  RTLineItem_1 dataframe to a file edw_idl_ngenpos_item_id.dat
dap_idl_ngenpos_item_id = RTLineItem_T.select(col('LineItem.SequenceNumber').alias('SequenceNumber'),
                              col('DetailNumber._VALUE').alias('DetailNumber'),
                              col('LineItem.pcms:PCMSLineItem.pcms:ItemLink').alias('pcms_ItemLink'),
                              col('rfn').alias('wag_RFN'),
                              col('LineItem._LineType').alias('pcms_LineType'),
                              col('LineItem._EntryMethod').alias('EntryMethod'),
                              col('LineItem.Sale.ItemID').alias('Item_Id'),
                              col('POSIdentity._POSIDType').alias('POSID_Type'),
                              col('POSIdentity.POSItemID').alias('POSItemID'),    
                              col('LineItem.Sale.pcms:PCMSSale.pcms:DocumentReference').alias('pcms_DocumentReference'),
                              col('LineItem.Sale.Description').alias('Description'))\
.filter(col('POSID_Type').isNotNull())


#dbutils.widgets.text("PAR_NB_NGENPOS_ITEM_ID_OUTPUT_FILE_PATH",'retail/retail_sales/staging/dap_idl_ngenpos_item_id')
item_id = mountPoint + "/" + dbutils.widgets.get("PAR_NB_NGENPOS_ITEM_ID_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
dap_idl_ngenpos_item_id.write.format('parquet').mode("overwrite").save(item_id)


# COMMAND ----------

#RTLineItem.unpersist()
# Databricks notebook source
# dbutils.widgets.text("PAR_NB_INPUT_FILE_PATH","retail/retail_sales/staging/pos_ej_ux_sort/20220918143042")
# dbutils.widgets.text("PAR_NB_DATE_ADDER","10")
# dbutils.widgets.text("PAR_NB_DATE_SUBTRACTOR","365")
# dbutils.widgets.text("PAR_NB_INITIAL_DATE","20050724")
# dbutils.widgets.text("PAR_NB_OTHER_E_TYPES_OF_DATA","retail/retail_sales/staging/Other_E_types_ascii")
# dbutils.widgets.text("PAR_NB_REC_TYPE_LOOKUP","retail/retail_sales/lookup/Rec_Type_Validations.dat")
# dbutils.widgets.text("PAR_NB_VERIFIED_RUNTIME_PARAMS","retail/retail_sales/staging/verified_run_time_params")
# dbutils.widgets.text("PAR_PL_BATCH_ID","20220918143042")
# dbutils.widgets.text("PAR_NB_NOT_DEFINED","-1")
# dbutils.widgets.text("PAR_NB_DIM_LOCATION_EJ_LOOKUP","retail/retail_sales/lookup/dim_location_ej_lookup_ascii")
# dbutils.widgets.text("PAR_NB_POS_EJ_LINK","retail/retail_sales/staging/lyty_edw_idl_ngenpos_store_file")

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import arrays_zip
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import datetime

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_FILE_PATH")

# COMMAND ----------

df_source = spark.read.format('parquet').load(filePath)

# COMMAND ----------

df_filtered = df_source.where(length(col('line'))==110).withColumn('rec_in_file',col('rec_in_file').cast(IntegerType()))
#display(df_filtered)

# COMMAND ----------

lookup1_filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_VERIFIED_RUNTIME_PARAMS")
collected = spark.read.format('parquet').load(lookup1_filePath).where(col('lkup_dummy_key')=='A').collect()
max_surrogate_key = collected[0][2]
parm_current_date = collected[0][1]
print(max_surrogate_key)
print(parm_current_date)
#display(collected)

# COMMAND ----------

lookup2_filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_REC_TYPE_LOOKUP")
with open('/dbfs' + lookup2_filePath,'rb') as f:
    contents = f.read()
    decoded = contents.decode('utf-8')
    rec_lookup = decoded.split('\n')
    rec_lookup_list = [i.replace('\r','') for i in rec_lookup if len(i)>0]
#print(rec_lookup_list)
#print(rec_lookup)

# COMMAND ----------

INITIAL_DATE = dbutils.widgets.get("PAR_NB_INITIAL_DATE")
DATE_SUBTRACTOR = int(dbutils.widgets.get("PAR_NB_DATE_SUBTRACTOR"))
DATE_ADDER = int(dbutils.widgets.get("PAR_NB_DATE_ADDER"))
print(INITIAL_DATE)
print(DATE_SUBTRACTOR)
print(DATE_ADDER)

# COMMAND ----------

# DBTITLE 1,Assign txn id to each block
dfl =df_filtered.withColumn('txn_id_info',col('line')[1:29])\
        .withColumn('txn_type',col('line')[24:2])\
       .withColumn('rcd_type',col('line')[30:1])\
       .withColumn('stuff',substring(col('line'),31,100))\
       .withColumn('local_1st_M',when(((col('rcd_type')==" ") & (col('txn_type') != 38) & (col('txn_type') != 0)),lit('Y')).otherwise(lit('N')))\
       .withColumn('local_1st_M38_00',when(((col('rcd_type')==" ") & (((col('txn_type') == 38) & (substring(col('stuff'),5,1) != 'F') & (substring(col('stuff'),5,1) != 'S')) | ((col('txn_type') == 0) & (substring(col('stuff'),1,6) != 'NOSALE')))),lit('Y')).otherwise(lit('N')))\
       .withColumn('local_is_header',when((col('local_1st_M')=='Y') | (col('local_1st_M38_00')=='Y'),lit('1')).otherwise(lit(0)))\
       .withColumn('key',md5(concat(coalesce(trim(col('rec_in_file')),lit(' ')),coalesce(trim(col('txn_id_info')),lit(' ')))))

def scanner(inp):
  ou =[]
  rec_ctr = 0
  part_num = 0
  for i in inp:
    if i['local_is_header'] == '1':
      rec_ctr = 1
      part_num = part_num + 1
    else:
      rec_ctr = rec_ctr + 1
    ou_item = {'rec_in_file':i['rec_in_file'],'rcd_type':i['rcd_type'],'header':i['local_is_header'],'local_rec_in_txn_cntr':str(rec_ctr),'subPart':part_num}
    ou.append(ou_item)
  return({'oj':ou})

ret_sch = StructType([StructField('oj',ArrayType(StructType([StructField('rec_in_file',StringType(),True),StructField('rcd_type',StringType(),True),StructField('header',StringType(),True),StructField('local_rec_in_txn_cntr',StringType(),True),StructField('subPart',IntegerType(),True)])),True)])
#ret_sch = StructType([StructField('rec_in_file',StringType(),True),StructField('rcd_type',StringType(),True),StructField('rec_ctr',StringType(),True)])

udf_scanner = udf(scanner,ret_sch)

dfl2 = dfl.withColumn('rec_in_file',col('rec_in_file').cast(IntegerType()))\
.withColumn('comp',struct(col('rec_in_file'),col('rcd_type'),col('local_is_header')))\
.groupBy(col('txn_id_info')).agg((array_sort(collect_list(col('comp')))).alias('arr_comp')).withColumn('ou',udf_scanner(col('arr_comp')))\
.withColumn('ou_exploded',explode_outer(col('ou.oj')))\
.withColumn('rec_in_file2',col('ou_exploded.rec_in_file'))\
.withColumn('rcd_type2',col('ou_exploded.rcd_type'))\
.withColumn('local_rec_in_txn_cntr',col('ou_exploded.local_rec_in_txn_cntr'))\
.withColumn('subPart',col('ou_exploded.subPart'))\
.withColumn('key2',md5(concat(coalesce(trim(col('rec_in_file2')),lit(' ')),coalesce(trim(col('txn_id_info')),lit(' ')))))

# COMMAND ----------

# DBTITLE 1,Assign txn id to each block
dflJoined = dfl.join(dfl2,dfl.key==dfl2.key2,how='inner').select(dfl['*'],dfl2['local_rec_in_txn_cntr'],dfl2['subPart'])

# COMMAND ----------

# DBTITLE 1,Assign txn id to each block
wspec2 = Window.orderBy('file_nbr','txn_id_info','subPart')
#wspec3 = Window.partitionBy('file_nbr','txn_id_info')
df3 =dflJoined.withColumn('partition_cntr_int',lit(max_surrogate_key))\
       .withColumn('part_num',dense_rank().over(wspec2))\
       .withColumn('local_txn_cntr',lit(col('partition_cntr_int') + col('part_num')))\
       .withColumn('surrogate_key',(col('local_txn_cntr')))\
       .withColumn('local_end_hhmm',when((substring(col('line'),14,4)) == '2400',lit('0000')).otherwise((substring(col('line'),14,4))))\
       .withColumn('local_end_hhmm',when(((col('local_end_hhmm')[1:2]) >=0) & ((col('local_end_hhmm')[1:2]) <=24) & ((col('local_end_hhmm')[3:4]) >=0) & ((col('local_end_hhmm')[3:4]) <=60),col('local_end_hhmm')).otherwise(lit(None)))\
       .select(col('surrogate_key').alias('txn_cntr'),
              (col('local_rec_in_txn_cntr').cast(IntegerType())).alias('rec_in_txn_cntr'),
              col('file_nbr'),
              col('rec_in_file'),
              (substring(col('line'),1,5)).alias('str_nbr'),
              (substring(col('line'),6,8)).alias('txn_date'),
              col('local_end_hhmm').alias('txn_time'),
              (substring(col('line'),18,3)).alias('cashier_nbr'),
              (substring(col('line'),21,3)).alias('register_nbr'),
              (substring(col('line'),24,2)).alias('txn_type'),
              (substring(col('line'),26,4)).alias('txn_nbr'),
              col('rcd_type'),
              col('stuff'),
              spark_partition_id().alias('partition_nbr'))\
      .withColumn('valid_str_nbr',length(trim(coalesce(col('str_nbr'),lit(' '))))>0)\
      .withColumn('valid_txn_date',length(trim(coalesce(col('txn_date'),lit(' '))))>0)\
      .withColumn('valid_txn_time',length(trim(coalesce(col('txn_time'),lit(' '))))>0)\
      .withColumn('valid_cashier_nbr',length(trim(coalesce(col('cashier_nbr'),lit(' '))))>0)\
      .withColumn('valid_register_nbr',length(trim(coalesce(col('register_nbr'),lit(' '))))>0)\
      .withColumn('valid_txn_type',length(trim(coalesce(col('txn_type'),lit(' '))))>0)\
      .withColumn('valid_txn_nbr',length(trim(coalesce(col('txn_nbr'),lit(' '))))>0)\
      .withColumn('txn_date_oor',when((to_date(col('txn_date'),'yyyyMMdd') >= to_date(lit(INITIAL_DATE),'yyyyMMdd')) & (to_date(col('txn_date'),'yyyyMMdd') >= date_sub(to_date(lit(parm_current_date),'yyyyMMdd'),DATE_SUBTRACTOR)) & (to_date(col('txn_date'),'yyyyMMdd') <= date_add(to_date(lit(parm_current_date),'yyyyMMdd'),DATE_ADDER)),lit(1)).otherwise(lit(0)))\
      .withColumn('valid_rcd_type',when(col('rcd_type').isin(*(rec_lookup_list)),1).otherwise(0))

# COMMAND ----------

df4 = df3.where(((trim(col('rcd_type')))=='E') & ((substring(col('stuff'),1,4))!='0006') & ((substring(col('stuff'),1,4))!='0019') & ((substring(col('stuff'),1,4))!='0010') & ((substring(col('stuff'),1,4))!='0026') & ((substring(col('stuff'),1,4))!='0027'))
#df4.count()

# COMMAND ----------

df_other_e_typesOfData = df4.select(col('txn_cntr'),col('rec_in_txn_cntr'),col('str_nbr'),col('txn_date'),col('txn_time'),col('cashier_nbr'),col('register_nbr'),col('txn_type'),col('txn_nbr'),col('rcd_type'),col('stuff'))
#display(df_other_e_typesOfData)

# COMMAND ----------

# DBTITLE 1,Pos txn erecords - other e types of data
other_e_typesOfData= mountPoint + "/" + dbutils.widgets.get("PAR_NB_OTHER_E_TYPES_OF_DATA") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
df_other_e_typesOfData.write.format('parquet').mode('overwrite').save(other_e_typesOfData)

# COMMAND ----------

lookup4_filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_DIM_LOCATION_EJ_LOOKUP")
df_location_ej = spark.read.format('parquet').load(lookup4_filePath).withColumnRenamed('str_nbr','str_nbr_lookup')
#display(df_location_ej)

# COMMAND ----------

NOT_DEFINED = dbutils.widgets.get("PAR_NB_NOT_DEFINED")

df_other_e_typesOfData_joined = df_other_e_typesOfData.join(df_location_ej,df_other_e_typesOfData.str_nbr.cast(IntegerType())==df_location_ej.str_nbr_lookup.cast(IntegerType()),how='left').select(df_other_e_typesOfData['*'],df_location_ej['loc_id'])

df_other_e_typesOfData_reformat= df_other_e_typesOfData_joined.withColumn('txn_id',col('txn_cntr'))\
.withColumn('txn_dt',date_format(to_date(col('txn_date'),'yyyyMMdd'),'yyyy-MM-dd'))\
.withColumn('loc_id',when(length(trim(coalesce(col('str_nbr'),lit(' '))))>0,col('loc_id')).otherwise(NOT_DEFINED))\
.withColumn('e_sub_type',concat(trim(coalesce(col('rcd_type'),lit(' '))),trim(coalesce(substring(col('stuff'),1,4),lit(' ')))))\
.withColumn('sub_type_dtl',regexp_replace(trim(substring(col('stuff'),6,75)),'[|]','-'))\
.select('txn_id','txn_dt','loc_id','e_sub_type','sub_type_dtl')\
.where((col('txn_dt').isNotNull()) | (col('loc_id') != NOT_DEFINED))

#display(df_other_e_typesOfData_reformat)

# COMMAND ----------

# DBTITLE 1,Pos txn erecords - Output to phase 10
wspec16a = Window.partitionBy('txn_id','e_sub_type').orderBy(col('e_sub_type')).rowsBetween(Window.unboundedPreceding,Window.currentRow)

df_other_e_typesOfData_scan = df_other_e_typesOfData_reformat.withColumn('rec_seq_nbr_int',when(length(trim(col('txn_id')))>0,lit(1)).otherwise(lit(0)))\
.withColumn('rec_seq_nbr_int2',sum(col('rec_seq_nbr_int')).over(wspec16a))\
.withColumn('rec_seq_nbr',when(col('rec_seq_nbr_int')==0,lit(0)).otherwise(col('rec_seq_nbr_int2')))\
.select('txn_id','txn_dt','loc_id','e_sub_type','rec_seq_nbr','sub_type_dtl')

df_other_e_typesOfData_scan.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/Int_DF2_DF11_interFile')

# COMMAND ----------

box1_out4 = df3.where(~(((trim(col('rcd_type')))=='E') & ((substring(col('stuff'),1,4))!='0006') & ((substring(col('stuff'),1,4))!='0019') & ((substring(col('stuff'),1,4))!='0010') & ((substring(col('stuff'),1,4))!='0026') & ((substring(col('stuff'),1,4))!='0027'))).select('txn_cntr', 'rec_in_txn_cntr', 'file_nbr', 'rec_in_file', 'partition_nbr', 'str_nbr', 'valid_str_nbr', 'txn_date', 'valid_txn_date', 'txn_date_oor' ,'txn_time', 'valid_txn_time', 'cashier_nbr', 'valid_cashier_nbr', 'register_nbr', 'valid_register_nbr', 'txn_type', 'valid_txn_type', 'txn_nbr', 'valid_txn_nbr', 'rcd_type', 'valid_rcd_type', 'stuff')
#df5.count()

# COMMAND ----------

# DBTITLE 1,Find ecom and split invalid records and add more txn fields - OUT1
box2_filter1_select = box1_out4.where(((col('valid_str_nbr') == False) | (col('valid_txn_date') == False) | (col('valid_txn_time') == False) | (col('valid_cashier_nbr') == False) | (col('valid_register_nbr') == False) | (col('valid_txn_type') == False) | (col('valid_txn_nbr') == False) | (col('valid_rcd_type') == False) | (col('txn_date_oor') == 0)))

df_RfrmtInvalidForErrqSink = box2_filter1_select.withColumn('invalid_desc',when(col('valid_str_nbr')==False,lit('V1: Invalid store nbr'))\
                                             .when(col('valid_txn_date')==False,lit('V1: Invalid txn date'))\
                                             .when(col('txn_date_oor')==0,lit('V1: Txn date out of range'))\
                                             .when(col('valid_txn_time')==False,lit('V1: Invalid txn time'))\
                                             .when(col('valid_cashier_nbr')==False,lit('V1: Invalid cashier nbr'))\
                                             .when(col('valid_register_nbr')==False,lit('V1: Invalid register nbr'))\
                                             .when(col('valid_txn_type')==False,lit('V1: Invalid txn type'))\
                                             .when(col('valid_txn_nbr')==False,lit('V1: Invalid txn nbr'))\
                                             .when(col('valid_rcd_type')==False,lit('V1: Invalid record type'))\
                                             .otherwise(lit('V1: Invalid txn ID info')))\
                                  .select('txn_cntr', 'rec_in_txn_cntr', 'file_nbr', 'rec_in_file', 'partition_nbr', 'str_nbr', 'txn_date', 'txn_time', 'cashier_nbr', 'register_nbr', 'txn_type', 'txn_nbr', 'rcd_type', 'stuff', 'invalid_desc')

df_RfrmtInvalidForErrqSink.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/Int_DF2_DF8_RfrmtInvalidForErrqSink')

# COMMAND ----------

box2_filter1_deselect = box1_out4.where(~((col('valid_str_nbr') == False) | (col('valid_txn_date') == False) | (col('valid_txn_time') == False) | (col('valid_cashier_nbr') == False) | (col('valid_register_nbr') == False) | (col('valid_txn_type') == False) | (col('valid_txn_nbr') == False) | (col('valid_rcd_type') == False) | (col('txn_date_oor') == 0)))

# COMMAND ----------

df_add_ecom_ind = box2_filter1_deselect.withColumn('local_e_comm_order_nbr',coalesce(substring(col('stuff'), 1, 12),lit(' ')))\
.withColumn('e_comm_ind',when((col('str_nbr')==5995) | ((col('rcd_type')=='A') & (substring(col('stuff'), 13, 12)=='E-COMM ORDER')),lit('Y')).otherwise('N'))\
.withColumn('e_comm_order_nbr',when((col('e_comm_ind')=='Y') & (length(trim(col('local_e_comm_order_nbr')))>0),col('local_e_comm_order_nbr')).otherwise(lit(None)))\
.withColumn('valid_e_comm',when((locate('@@',col('stuff')))>0,lit(0)).otherwise(lit(1)))\
.drop('local_e_comm_order_nbr')
#display(df_add_ecom_ind)

# COMMAND ----------

df_add_ecom_ind = df_add_ecom_ind.repartition('txn_cntr')

# COMMAND ----------

wspec18a = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr').desc()).rowsBetween(Window.unboundedPreceding,Window.currentRow)
wspec18b = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr').desc())
df_valid_ecom = df_add_ecom_ind.withColumn('local_start_time',when((col('rec_in_txn_cntr')==1) & (length(trim(coalesce(substring(col('stuff'),13,6),lit(' '))))>0) & (~(substring(col('stuff'),13,6).rlike('\D+'))),substring(col('stuff'),13,6))\
                                           .when((col('rec_in_txn_cntr')==1) & ((length(trim(coalesce(substring(col('stuff'),13,6),lit(' '))))==0) | ((substring(col('stuff'),13,6).rlike('\D+')))),rpad(col('txn_time'),6,'0')))\
                                .withColumn('local_start_time',when((col('rec_in_txn_cntr')==1) & (col('local_start_time')=='240000'),lit('0')).otherwise(col('local_start_time')))\
                                .withColumn('local_stop_time',when((col('rec_in_txn_cntr')==1) & (length(trim(coalesce(substring(col('stuff'),20,6),lit(' '))))>0) & (~(substring(col('stuff'),20,6).rlike('\D+'))),substring(col('stuff'),20,6))\
                                           .when((col('rec_in_txn_cntr')==1) & ((length(trim(coalesce(substring(col('stuff'),20,6),lit(' '))))==0) | ((substring(col('stuff'),20,6).rlike('\D+')))),rpad(col('txn_time'),6,'0')))\
                                .withColumn('local_stop_time',when((col('rec_in_txn_cntr')==1) & (col('local_stop_time')=='240000'),lit('0')).otherwise(col('local_stop_time')))\
                                .withColumn('local_price_sign',when(trim(col('rcd_type'))=='D',substring(col('stuff'),57,1)).otherwise(lit(None)))\
                                .withColumn('local_price_value',when(trim(col('rcd_type'))=='D',substring(col('stuff'),49,8)).otherwise(lit(None)))\
                                .withColumn('local_valid_D',when((trim(col('rcd_type'))=='D') & (length(trim(concat(coalesce(col('local_price_sign'),lit(' ')),coalesce(ltrim(col('local_price_value')),lit(' ')))))==0),lit(0)).otherwise(lit(1)))\
                                .withColumn('local_curr_valid',col('valid_str_nbr') & col('valid_txn_date') & col('txn_date_oor').cast(BooleanType()) & col('valid_txn_time') & col('valid_cashier_nbr') & col('valid_register_nbr') & col('valid_txn_type') & col('valid_txn_nbr') & col('valid_rcd_type').cast(BooleanType()) & col('valid_e_comm').cast(BooleanType()) & col('local_valid_D').cast(BooleanType()))\
                                .withColumn('local_curr_valid_int',when(col('local_curr_valid')==True,lit(0)).otherwise(lit(1)))\
                                .withColumn('temp_valid_fields_int',sum(col('local_curr_valid_int')).over(wspec18a))\
                                .withColumn('valid_fields',when(col('temp_valid_fields_int')==0,True).otherwise(False))\
                                .withColumn('total_sell_prc_int1',when(col('local_valid_D').cast(BooleanType()),concat(col('local_price_sign'),ltrim(col('local_price_value'))))\
                                           .when(trim(col('rcd_type'))=='D',lit('0'))\
                                           .otherwise(lit(None)))\
                                .withColumn('total_sell_prc',last(col('total_sell_prc_int1'),True).over(wspec18b))\
                                .withColumn('err_seq_int1',when(col('local_curr_valid')==False,ltrim(col('rec_in_txn_cntr'))).otherwise(lit(None)))\
                                .withColumn('err_seq_int2',collect_list(col('err_seq_int1')).over(wspec18a))\
                                .withColumn('err_seq_xref',concat_ws(',',reverse(col('err_seq_int2'))))\
                                .withColumn('e_comm_ind_int1',when(trim(col('e_comm_ind'))=='Y',lit('Y')).otherwise(lit(None)))\
                                .withColumn('e_comm_ind',last(col('e_comm_ind_int1'),True).over(wspec18b))\
                                .withColumn('max_rec_int',max(col('rec_in_txn_cntr')).over(wspec18b))\
                                .withColumn('txn_time_int1',when(col('max_rec_int')==col('rec_in_txn_cntr'),col('txn_time')).otherwise(lit(None)))\
                                .withColumn('txn_time_int2',last(col('txn_time_int1'),True).over(wspec18a))\
                                .withColumn('txn_start_time',when(col('rec_in_txn_cntr')=='1',col('local_start_time')).otherwise(col('txn_time_int2')))\
                                .withColumn('txn_stop_time',when(col('rec_in_txn_cntr')=='1',col('local_stop_time')).otherwise(col('txn_time_int2')))\
                                .withColumn('valid_D_int1',when(col('local_valid_D')=='1',lit('0')).when(col('local_valid_D')=='0',lit('1')))\
                                .withColumn('valid_D_int2',sum(col('valid_D_int1')).over(wspec18a))\
                                .withColumn('valid_D',when(col('valid_D_int2')=='0',lit('1')).when(col('valid_D_int2')>0,lit('0')))\
                                .select('txn_cntr', 'rec_in_txn_cntr', 'file_nbr', 'rec_in_file', 'partition_nbr','err_seq_xref', 'str_nbr', 'valid_str_nbr', 'txn_date', 'valid_txn_date', 'txn_date_oor', 'txn_time', 'valid_txn_time', 'cashier_nbr', 'valid_cashier_nbr', 'register_nbr', 'valid_register_nbr', 'txn_type', 'valid_txn_type', 'txn_nbr', 'valid_txn_nbr', 'rcd_type', 'valid_rcd_type', 'e_comm_ind', 'e_comm_order_nbr', 'valid_e_comm','valid_fields','txn_start_time','txn_stop_time','total_sell_prc','valid_D','stuff')
#display(df_valid_ecom.where((col('str_nbr')=='00014') & (col('txn_date')=='20220330')))

# COMMAND ----------

lookup3_filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POS_EJ_LINK")
df_pos_ej_link = spark.read.format('parquet').load(lookup3_filePath).withColumnRenamed('str_nbr','lookup_str_nbr')
#display(df_pos_ej_link)

# COMMAND ----------

wspec19a = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr')).rowsBetween(Window.unboundedPreceding,Window.currentRow)
wspec19b = Window.partitionBy('txn_cntr').orderBy(col('rec_in_txn_cntr'))
wspec19c = Window.partitionBy('txn_cntr','seq_A_grp').orderBy(col('rec_in_txn_cntr')).rowsBetween(Window.unboundedPreceding,Window.currentRow)
df_overall_result = df_valid_ecom.withColumn('seq_B',when(trim(col('rcd_type'))=='B',lit(1)).otherwise(lit(0)))\
        .withColumn('seq_C',when(trim(col('rcd_type'))=='C',lit(1)).otherwise(lit(0)))\
        .withColumn('seq_D',when(trim(col('rcd_type'))=='D',lit(1)).otherwise(lit(0)))\
        .withColumn('seq_E',when(trim(col('rcd_type'))=='E',lit(1)).otherwise(lit(0)))\
        .withColumn('seq_H',when(col('rcd_type')==' ',lit(1)).otherwise(lit(0)))\
        .withColumn('seq_nbr_tax',sum(col('seq_B')).over(wspec19a))\
        .withColumn('seq_nbr_tnd',sum(col('seq_C')).over(wspec19a))\
        .withColumn('seq_nbr_tot',sum(col('seq_D')).over(wspec19a))\
        .withColumn('seq_nbr_misc',sum(col('seq_E')).over(wspec19a))\
        .withColumn('seq_nbr_hdr',sum(col('seq_H')).over(wspec19a))\
        .withColumn('seq_nbr_by_rec_type',when(trim(col('rcd_type'))=='B',col('seq_nbr_tax'))\
                                         .when(trim(col('rcd_type'))=='C',col('seq_nbr_tnd'))\
                                         .when(trim(col('rcd_type'))=='D',col('seq_nbr_tot'))\
                                         .when(trim(col('rcd_type'))=='E',col('seq_nbr_misc'))\
                                         .when(col('rcd_type')==' ',col('seq_nbr_hdr')))\
        .withColumn('top_column',min(col('rec_in_txn_cntr')).over(wspec19b))\
        .withColumn('valid_fields_int',when(col('top_column')==col('rec_in_txn_cntr'),col('valid_fields')).otherwise(None))\
        .withColumn('valid_fields',last(col('valid_fields_int'),True).over(wspec19b))\
        .withColumn('txn_start_time_int',when(col('top_column')==col('rec_in_txn_cntr'),col('txn_start_time')).otherwise(None))\
        .withColumn('txn_start_time',last(col('txn_start_time_int'),True).over(wspec19b))\
        .withColumn('txn_stop_time_int',when(col('top_column')==col('rec_in_txn_cntr'),col('txn_stop_time')).otherwise(None))\
        .withColumn('txn_stop_time',last(col('txn_stop_time_int'),True).over(wspec19b))\
        .withColumn('total_sell_prc_int',when(col('top_column')==col('rec_in_txn_cntr'),col('total_sell_prc')).otherwise(None))\
        .withColumn('total_sell_prc',last(col('total_sell_prc_int'),True).over(wspec19b))\
        .withColumn('valid_D_int',when(col('top_column')==col('rec_in_txn_cntr'),col('valid_D')).otherwise(None))\
        .withColumn('valid_D',last(col('valid_D_int'),True).over(wspec19b))\
        .withColumn('e_comm_ind_int',when(col('top_column')==col('rec_in_txn_cntr'),col('e_comm_ind')).otherwise(None))\
        .withColumn('e_comm_ind_int2',last(col('e_comm_ind_int'),True).over(wspec19b))\
        .withColumn('err_seq_xref_int',when(col('top_column')==col('rec_in_txn_cntr'),col('err_seq_xref')).otherwise(None))\
        .withColumn('err_seq_xref',last(col('err_seq_xref_int'),True).over(wspec19b))\
        .withColumn('valid_e_comm_int',when(((col('e_comm_ind')=='Y') | (col('e_comm_ind_int2')=='Y')) & (locate('@@',col('stuff'))>0),lit('0'))\
                   .when(col('top_column')==col('rec_in_txn_cntr'),col('valid_e_comm'))\
                   .otherwise(None))\
        .withColumn('valid_e_comm_j',last(col('valid_e_comm_int'),True).over(wspec19b))\
        .drop('e_comm_ind')\
        .withColumnRenamed('e_comm_ind_int2','e_comm_ind')

df_overall_result2 = df_overall_result.join(df_pos_ej_link,(df_overall_result.str_nbr).cast(IntegerType())==(df_pos_ej_link.lookup_str_nbr).cast(IntegerType()),how='left').select( df_overall_result['*'],df_pos_ej_link.lookup_str_nbr)

df_overall_result3 = df_overall_result2.withColumn('tmp_link_nbr',when((col('rcd_type')=='A') & (length(trim(coalesce(substring(col('stuff'),32,5),lit(' '))))>0) & (col('lookup_str_nbr').isNotNull()),substring(col('stuff'),32,5)).otherwise(lit('0')))\
.withColumn('seq_A_int1',when((col('tmp_link_nbr')>0) & (col('rcd_type')=='A'),concat(col('rec_in_txn_cntr'),col('tmp_link_nbr'))))\
.withColumn('seq_A_grp',last(col('seq_A_int1'),True).over(wspec19b))\
.withColumn('mark_A',when((col('rcd_type')=='A') & (col('tmp_link_nbr')>0),col('tmp_link_nbr'))\
                  .when((col('rcd_type')=='A') & (col('seq_A_int1').isNull()),lit(1))\
                  .otherwise(lit(0)))\
.withColumn('seq_nbr_dtl',sum(col('mark_A')).over(wspec19c))\
.withColumn('seq_nbr_by_rec_type',when(trim(col('rcd_type'))=='A',col('seq_nbr_dtl')).otherwise(col('seq_nbr_by_rec_type')))

# COMMAND ----------

df_overall_result3.cache()

# COMMAND ----------

# DBTITLE 1,Find ecom and split invalid records and add more txn fields - OUT0
df_RfrmatInvalidAndEcommForErrqTMP = df_overall_result3.where(((col('str_nbr')==5995) | (col('valid_fields')==False)))\
.withColumn('invalid_desc',when(col('valid_e_comm')==False,lit('V1: Invalid e-comm rec'))\
            .when((col('valid_D')==False) & (trim(col('rcd_type')) == "D"),lit('V1: Invalid total amt'))\
            .when(col('valid_D')==5995,lit('V1: Store 5995 not loaded'))\
            .otherwise(concat(lit('V1: Err on txn rec# '),coalesce(col('err_seq_xref'),lit(' ')))))\
.select('txn_cntr','rec_in_txn_cntr','file_nbr','rec_in_file','partition_nbr','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','stuff','invalid_desc')    

df_RfrmatInvalidAndEcommForErrqTMP.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/Int_DF2_DF8_RfrmatInvalidAndEcommForErrqTMP')

# COMMAND ----------

# DBTITLE 1,Find ecom and split invalid records and add more txn fields - OUT3
df_FilterByStr5995OrValidFieldsDeselectTmp = df_overall_result3.where(~((col('str_nbr')==5995) | (col('valid_fields')==False)))\
.select('txn_cntr', 'rec_in_txn_cntr', 'file_nbr', 'rec_in_file','seq_nbr_by_rec_type','partition_nbr','err_seq_xref','str_nbr', 'valid_str_nbr', 'txn_date', 'valid_txn_date', 'txn_date_oor', 'txn_time', 'valid_txn_time', 'cashier_nbr', 'valid_cashier_nbr', 'register_nbr', 'valid_register_nbr', 'txn_type', 'valid_txn_type', 'txn_nbr', 'valid_txn_nbr', 'rcd_type', 'valid_rcd_type','e_comm_ind', 'e_comm_order_nbr', 'valid_e_comm','valid_fields', 'txn_start_time', 'txn_stop_time', 'total_sell_prc','valid_D','stuff')

df_FilterByStr5995OrValidFieldsDeselectTmp.write.format('parquet').mode('overwrite').save('/mnt/wrangled/retail/retail_sales/staging/Int_DF2_DF3_FilterByStr5995OrValidFieldsDeselectTmp')

# COMMAND ----------

# from pyspark.sql.functions import *
# from pyspark.sql.types import *
# df = spark.read.format('parquet').load('/mnt/wrangled/retail/retail_sales/staging/Int_DF2_DF3_FilterByStr5995OrValidFieldsDeselectTmp')
# display(df.where((col('str_nbr')=='00013') & (col('txn_date')=='20220331') & (col('cashier_nbr')=='380') & (col('register_nbr')=='025') & (col('txn_type')=='10') & (col('txn_nbr')=='8804')))
# #display(df.where((col('str_nbr')=='10470') & (col('txn_date')=='20220331') & (col('cashier_nbr')=='336') & (col('txn_time')=='1143')).orderBy(col('rec_in_file')))

# COMMAND ----------

# display(df_source.where(col('line').startswith('00013202203310414380025108804')))

# COMMAND ----------

df_overall_result3.unpersist()

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

#display(df3.where(col('txn_id_info')=='00013202203310159275071113237'))

# COMMAND ----------

# dd = spark.read.format('parquet').load('/mnt/wrangled/master_data/Test/Other_E_types_ascii')
# display(dd.withColumn('key',concat(col('str_nbr'),col('txn_date'),col('txn_time'),col('cashier_nbr'),col('txn_type'),col('txn_nbr'))).where(col('key').isin('07687202203311824805112933','07688202203311857211106087')))
# #display(dd.orderBy('rec_in_txn_cntr'))
# #'07687202203311824805112933',

# Databricks notebook source

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)


# COMMAND ----------


par_file_path = dbutils.widgets.get("par_file_path")
par_input_file = dbutils.widgets.get("par_input_file")
par_output_file = dbutils.widgets.get("par_output_file")
sheet_row_limit = dbutils.widgets.get("sheet_row_limit")

InputFile  = mountPoint + par_file_path + "/" + par_input_file
outputFile = mountPoint + par_file_path + "/" + par_output_file

# COMMAND ----------

from pyspark.sql.types import (StringType,IntegerType,StructType,StructField)
from pyspark.sql.functions import lit,row_number,col
from pyspark.sql.window import Window

#This function will use the Data and sheet# as input and append the new sheet into existing Output Excel File
def write_to_sheet(df,sheet_num):
      Sheet_Name ={"SheetName":sheet_num}
      df.write.format("com.crealytics.spark.excel")\
              .option("header", True)\
              .options(**Sheet_Name)\
              .mode("append")\
              .save(outputFile) 

#Define Schema for Input File
excelschema = StructType([StructField("NDC_11", StringType(), True),
                          StructField("PRODUCT_NAME", StringType(), True),
                          StructField("PATIENT_ID", StringType(), True),
                          StructField("STORE_NBR", StringType(), True),
                          StructField("STORE_MAILING_STATE", StringType(), True),
                          StructField("CREATE_DT", StringType(), True)])

#Read Input File using the schema defined
df = spark.read.format("csv").option("header", True).schema(excelschema).load(InputFile)

#Apply window function to define row_number and use it to split rows into multiple sheets of same excel
w = Window().partitionBy(lit('a')).orderBy(lit('a'))
df1 = df.withColumn("row_num", row_number().over(w))

#Create Temporary View for Input 
df1.createOrReplaceTempView("dfTable")

#Logic to Split data from Input based on specified sheet row limit for a sheet
max_rows = int(sheet_row_limit)
count = 1
for i in range(0,df1.count(),max_rows):
  #print(i)
  if i==0:
    if df.count() <= max_rows:
      end = df.count
    else:
      end = max_rows 
      #print("writing record 1 and ",end)
      df2 = df1.filter(col("row_num").between(1,end)).drop(col("row_num"))
      sheet_num = 1
      write_to_sheet(df2,sheet_num)
      count += 1
  else:
    start = i +1
    end = max_rows*count  
    #print("writing record from ",start," to ",end)
    df3 = df1.filter(col("row_num").between(start,end)).drop(col("row_num"))
    sheet_num = count
    write_to_sheet(df3,sheet_num) 
    count += 1


# COMMAND ----------

#Delete the Input file used
dbutils.fs.rm(InputFile)

#df.count()

# COMMAND ----------


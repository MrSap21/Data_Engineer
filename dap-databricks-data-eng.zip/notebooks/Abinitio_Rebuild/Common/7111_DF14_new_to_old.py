# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DECODEREPLACE","pos_decode_replace_ascii")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_IN3_DIM_Product_Replace","retail/retail_sales/staging/dim_product_replace_ascii")
# dbutils.widgets.text("PAR_STRREGREPLACE_INFILE","str_register_replace_ascii")
# dbutils.widgets.text("PAR_OUT0_Max_Prod_ID_Lookup_New","retail/retail_sales/staging/max_dim_product_surrogate_key_temp")
# dbutils.widgets.text("PAR_max_prod_id_loookup","retail/retail_sales/staging/max_dim_product_surrogate_key")
# dbutils.widgets.text("PAR_NB_DUP_REF_NEW_PATH","retail/retail_sales/staging/duplicate_reference_new_ascii")
# dbutils.widgets.text("PAR_NB_DUP_REF_OLD_PATH","retail/retail_sales/staging/duplicate_reference_old_ascii")
#dbutils.widgets.text("PAR_PREVDAY_POSTXN_INFILE","prev_day_pos_txn")
#dbutils.widgets.text("PAR_NB_POSTXNINSERTASCII", "pos_txn_insert_ascii.pipe_delim")

# COMMAND ----------

DecodeReplace = dbutils.widgets.get("PAR_DECODEREPLACE")
staging_folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
PAR_IN3_DIM_Product_Replace = mountPoint + '/'+ dbutils.widgets.get("PAR_IN3_DIM_Product_Replace")
StrRegReplace_INFile = dbutils.widgets.get("PAR_STRREGREPLACE_INFILE")
PAR_OUT0_Max_Prod_ID_Lookup_New = mountPoint + '/'+ dbutils.widgets.get("PAR_OUT0_Max_Prod_ID_Lookup_New")
PAR_LKP_max_prod_id_loookup = mountPoint + '/'+ dbutils.widgets.get("PAR_max_prod_id_loookup")
PAR_NB_DUP_REF_NEW_PATH = mountPoint + '/'+ dbutils.widgets.get("PAR_NB_DUP_REF_NEW_PATH")
PAR_NB_DUP_REF_OLD_PATH = mountPoint + '/'+ dbutils.widgets.get("PAR_NB_DUP_REF_OLD_PATH")
PrevDayPosTxn_INFile = dbutils.widgets.get("PAR_PREVDAY_POSTXN_INFILE")
posTxnInsertAscii = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSTXNINSERTASCII")

# COMMAND ----------

posDecodeReplaceDF = spark.read.format("parquet").load(mountPoint+"/"+staging_folder+"/"+DecodeReplace)
posDecodeReplaceDF.write.format('parquet').mode('overwrite').save(mountPoint+"/"+staging_folder+"/"+DecodeReplace)

# COMMAND ----------

df_in3 = spark.read.parquet(PAR_IN3_DIM_Product_Replace+'_new')
df_in3.write.format('parquet').mode('overwrite').save(PAR_IN3_DIM_Product_Replace)

# COMMAND ----------

strRegReplaceDF = spark.read.format("parquet").load(mountPoint+"/"+staging_folder+"/"+StrRegReplace_INFile+'_new')
strRegReplaceDF.write.format('parquet').mode('overwrite').save(mountPoint+"/"+staging_folder+"/"+StrRegReplace_INFile)

# COMMAND ----------

max_srgt_df = spark.read.format('parquet').load(mountPoint + '/' + staging_folder + '/' + 'max_system_surrogate_key.temp')
max_srgt_df.write.format('parquet').mode('overwrite').save(mountPoint + '/' + staging_folder + '/' + 'max_system_surrogate_key')

# COMMAND ----------

dim_prod_max_id = spark.read.format('parquet').load(PAR_OUT0_Max_Prod_ID_Lookup_New)
dim_prod_max_id.write.format('parquet').mode('overwrite').save(PAR_LKP_max_prod_id_loookup)

# COMMAND ----------

dup_ref_new = spark.read.format('parquet').load(PAR_NB_DUP_REF_NEW_PATH)
dup_ref_new.write.format('parquet').mode('overwrite').save(PAR_NB_DUP_REF_OLD_PATH)

# COMMAND ----------

pos_txn_insert_ascii = spark.read.format('parquet').load(posTxnInsertAscii)
pos_txn_insert_ascii.write.format('parquet').mode('overwrite').save(mountPoint+"/"+staging_folder+"/"+PrevDayPosTxn_INFile)
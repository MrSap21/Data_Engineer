# Databricks notebook source
import os
import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters

os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_INPUT_PATH")
os.environ['inputfile'] = dbutils.widgets.get("PAR_NB_INPUTFILE_NAME")

#os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("inputPath")
#os.environ['logPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("logPath")
#os.environ['pEDWBATCHID'] = dbutils.widgets.get("pEDWBATCHID")
#os.environ['inputfile'] = dbutils.widgets.get("inputfile")
 

# COMMAND ----------

# MAGIC %sh
# MAGIC AI_DIR_FTP_BASE=$inputPath
# MAGIC INPUTFILENAME=$inputfile.dat
# MAGIC   if ! [[ -s $AI_DIR_FTP_BASE/$INPUTFILENAME ]]; then
# MAGIC     touch $AI_DIR_FTP_BASE/$INPUTFILENAME
# MAGIC else
# MAGIC exit
# MAGIC fi

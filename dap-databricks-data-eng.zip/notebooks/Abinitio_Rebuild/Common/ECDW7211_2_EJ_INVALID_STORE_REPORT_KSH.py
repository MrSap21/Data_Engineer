# Databricks notebook source
import os
import json

# Mounting ADLS

#mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

mountPoint="/mnt/"+dbutils.widgets.get("PAR_DB_MOUNT_POINT")

# Defining Pipeline Parameters

dbutils.widgets.text("PAR_DB_BASENAME","",label="PAR_DB_BASENAME")
dbutils.widgets.text("PAR_DB_AI_LOG","",label="PAR_DB_AI_LOG")
dbutils.widgets.text("PAR_DB_AI_RECYCLE","",label="PAR_DB_AI_RECYCLE")
dbutils.widgets.text("PAR_DB_MOUNT_POINT","",label="PAR_DB_MOUNT_POINT")


os.environ['basename'] = dbutils.widgets.get("PAR_DB_BASENAME")
os.environ['AI_LOG'] = "/dbfs/mnt/" + dbutils.widgets.get("PAR_DB_AI_LOG")
os.environ['AI_RECYCLE'] = "/dbfs/mnt/" +  dbutils.widgets.get("PAR_DB_AI_RECYCLE")
#os.environ['logPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_LOG_PATH")


 

# COMMAND ----------

# MAGIC %sh
# MAGIC JOB_NAME=`basename ${0} | sed 's/.ksh//g'`
# MAGIC LOG_FILE=${AI_LOG}/$JOB_NAME.log.`date +%m%d%H%M`
# MAGIC ERR_FILE=${AI_LOG}/$JOB_NAME.err.`date +%m%d%H%M`
# MAGIC export start_time=`date '+%m/%d/%Y.%R:%S'`
# MAGIC 
# MAGIC echo $LOG_FILE

# COMMAND ----------

# MAGIC %sh
# MAGIC 
# MAGIC #!/bin/ksh
# MAGIC #------------------------------------------------------------------------------
# MAGIC #
# MAGIC #------------------------------------------------------------------------------
# MAGIC #  Author:           Amit Garg
# MAGIC #  File name:        ECDW7211_2_EJ_INVALID_STORE_REPORT.ksh
# MAGIC #  Date:             02-04-2011
# MAGIC #  Description:      Job to create EJ invalid store Report
# MAGIC #------------------------------------------------------------------------------
# MAGIC #                      M A I N T E N A N C E   H I S T O R Y
# MAGIC #------------------------------------------------------------------------------
# MAGIC # Revision|                Description                |    Name    | Date
# MAGIC #---------+-------------------------------------------+------------+-----------
# MAGIC #   1.0   |               Initial release.            | Amit Garg  | 02-04-2011
# MAGIC #------------------------------------------------------------------------------
# MAGIC 
# MAGIC #cd ${MSS_SUB_HOME}
# MAGIC #. ./ab_project_setup.ksh $PWD
# MAGIC 
# MAGIC 
# MAGIC JOB_NAME=`basename ${0} | sed 's/.ksh//g'`
# MAGIC LOG_FILE=${AI_LOG}/$JOB_NAME.log.`date +%m%d%H%M`
# MAGIC ERR_FILE=${AI_LOG}/$JOB_NAME.err.`date +%m%d%H%M`
# MAGIC export start_time=`date '+%m/%d/%Y.%R:%S'`
# MAGIC 
# MAGIC #------------------------------------------------------------------------------
# MAGIC # Start of shell
# MAGIC #------------------------------------------------------------------------------
# MAGIC echo "`date +'%D %r'` Start of $JOB_NAME.ksh" > $LOG_FILE
# MAGIC 
# MAGIC ########  Finding out the latest available file for processing #####################################################
# MAGIC 
# MAGIC EJ_FILE=$(ls -ltr $AI_RECYCLE/POSEJ_Error_Queue_Desc_ascii.pipe_delim.* | tail -1 | awk '{print $9}')
# MAGIC sed -i "a The latest POSEJ file is :$EJ_FILE \n" $LOG_FILE
# MAGIC 
# MAGIC 
# MAGIC latest_file_date=$(echo $EJ_FILE | cut -d '.' -f 3)
# MAGIC sed -i "a The latest available file date is :$latest_file_date \n" $LOG_FILE
# MAGIC 
# MAGIC today_date=`date '+%Y%m%d'`
# MAGIC sed -i "a Today's date is :$today_date  " $LOG_FILE
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC #------------------------------------------------------------------------------
# MAGIC # Create EJ invalid  Store Report
# MAGIC #------------------------------------------------------------------------------
# MAGIC if [[ ! -f $AI_LOG/ej_invalid_store_report_successful.dat ]] 
# MAGIC then
# MAGIC    if [[ -s $EJ_FILE ]] 
# MAGIC    then
# MAGIC        grep "Invalid store nbr" $EJ_FILE  | cut -c 6-13,1-5 > $AI_LOG/ECDW7211_2_ej_invalid_store_report_result.dat
# MAGIC        cat $AI_LOG/ECDW7211_2_ej_invalid_store_report_result.dat | sort | uniq -c | awk -F' ' '{ print $3,$2,$1}' > $AI_LOG/ECDW7211_2_ej_invalid_store_report_final.dat
# MAGIC        RC=$? 
# MAGIC    else
# MAGIC #      echo "\n Latest available EJ file - $EJ_FILE is of 0 size \n" >> $LOG_FILE
# MAGIC        sed -i "a \n Latest available EJ file - $EJ_FILE is of 0 size \n " $LOG_FILE
# MAGIC        > $AI_LOG/ECDW7211_2_ej_invalid_store_report_final.dat      
# MAGIC       RC=$? 
# MAGIC    fi
# MAGIC  fi
# MAGIC 
# MAGIC    if [ $RC -eq 0 ]
# MAGIC    then
# MAGIC #       	echo "\n EJ invalid Store report Creation - successful \n " >> $LOG_FILE
# MAGIC         sed -i "a \n EJ invalid Store report Creation - successful \n " $LOG_FILE
# MAGIC     fi
# MAGIC     
# MAGIC     

# COMMAND ----------

# MAGIC %scala
# MAGIC /* To be handled using common frameworks for mail, archive
# MAGIC 
# MAGIC  if [[ -s $AI_LOG/ECDW7211_2_ej_invalid_store_report_final.dat ]] then
# MAGIC         	my_out_file_body=$AI_LOG/ECDW7211_2_ej_invalid_store_report_email_body.dat
# MAGIC         	rm -f ${my_out_file_body} >/dev/null 2>&1
# MAGIC      	        echo "EJ INVALID STORE NBR REPORT IS AS BELOW \n \n" > ${my_out_file_body}  
# MAGIC                 printf '%-20s %-30s %-20s \n' ` echo "TRANSACTION_DATE" "INVALID_STORE_NBR" "NO_OF_TRANSACTIONS ` >> ${my_out_file_body}
# MAGIC                 printf '%-20s %-30s %-20s \n' ` echo "-------------------" "----------------------" "--------------------------"` >> ${my_out_file_body} 
# MAGIC                 printf '%-20s %-30s %-25s \n' ` cat $AI_LOG/ECDW7211_2_ej_invalid_store_report_final.dat ` >> ${my_out_file_body}
# MAGIC        	        echo " \n \n ***END OF REPORT***" >> ${my_out_file_body}
# MAGIC                 touch $AI_LOG/ej_invalid_store_report_successful.dat
# MAGIC                 cat ${my_out_file_body} |mailx -s "EJ invalid report for Today" viral.mehta@walgreens.com,amit.c.garg@walgreens.com
# MAGIC                 cat ${my_out_file_body} |mailx -s "EJ invalid report for Today" EJ_EXCEPTIONS@walgreens.com 
# MAGIC            else 
# MAGIC                  if [[ `grep "0 size" $LOG_FILE | wc -l` -eq 1 ]] then
# MAGIC                        echo " \n As latest available file is of 0 size , no email will be send to EJ_EXCEPTIONS@walgreens.com \n" >> $LOG_FILE 
# MAGIC                        echo "Latest available EJ file - $EJ_FILE is of 0 size. So mail won't be send to EJ_EXCEPTIONS@walgreens.com " | mailx -s "EJ invalid report for Today" viral.mehta@walgreens.com,amit.c.garg@walgreens.com  >> $LOG_FILE 2>> $ERR_FILE
# MAGIC                  else 
# MAGIC                       echo "The email generated is blank and so mail won't be send to the EJ_EXCEPTIONS@walgreens.com " >> $LOG_FILE 
# MAGIC                      echo "No invalid store found in $EJ_FILE. So mail won't be send to EJ_EXCEPTIONS@walgreens.com " | mailx -s "EJ invalid report for Today"  amit.c.garg@walgreens.com,viral.mehta@walgreens.com  >> $LOG_FILE 2>> $ERR_FILE
# MAGIC                  fi 
# MAGIC            fi
# MAGIC    else  
# MAGIC         echo "\n EJ invalid Store report Creation - failed , RC=$RC " >> $LOG_FILE 
# MAGIC         exit 1 
# MAGIC    fi
# MAGIC 
# MAGIC fi
# MAGIC 
# MAGIC RC=$?
# MAGIC if [ $RC -eq 0 ]
# MAGIC         then
# MAGIC               echo " \n Deleting the touch file in order to reset it for the new run " >> $LOG_FILE
# MAGIC               echo "\n Report mailed successfully" >> $LOG_FILE
# MAGIC               rm -f  $AI_LOG/ej_invalid_store_report_successful.dat  >> $LOG_FILE 2>> $ERR_FILE
# MAGIC       else
# MAGIC               echo " \n Mailing process  failed.Check error file RC=$RC" $ERR_FILE   >> $LOG_FILE
# MAGIC               exit 1
# MAGIC fi
# MAGIC 
# MAGIC #------------------------------------------------------------------------------
# MAGIC # Delete files older than 7 days that were created by this script.
# MAGIC #------------------------------------------------------------------------------
# MAGIC 
# MAGIC echo "\n Cleaning up the files older than 7 days created by the script" >> ${LOG_FILE}
# MAGIC find ${AI_LOG}/${JOB_NAME}* -mtime +7 -exec rm -f {} \; >> ${LOG_FILE} 2>> $ERR_FILE
# MAGIC RC=$?
# MAGIC 
# MAGIC #------------------------------------------------------------------------------
# MAGIC # End of shell.
# MAGIC #------------------------------------------------------------------------------
# MAGIC if [ $RC -eq 0 ]
# MAGIC then
# MAGIC         echo "\n`date +'%D %r'` Script End - successful" >> $LOG_FILE
# MAGIC else
# MAGIC         echo "\n`date +'%D %r'` Script failed with errors.Check the error file.The return code is :  RC=$RC" >> $LOG_FILE
# MAGIC fi
# MAGIC 
# MAGIC exit $RC
# MAGIC */

# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)
mountPointSchema=dbutils.notebook.run(dbutils.widgets.get("pSCHEMA_MOUNT_PATH"),60)
#mountPointSchema=dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_SHELL",60)

# COMMAND ----------

# DBTITLE 1,Unprocessed Input and Control files
#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

#Input File List
inputFileList= dbutils.widgets.get("pIN_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfFileList)

#Control File List
ControlFileList= dbutils.widgets.get("pIN_CNTRL_FILE_LIST")
rddjsonCntrl = sc.parallelize([ControlFileList])
#print(rddjsonCntrl.collect())

dfFileListCntl = sqlContext.read.json(rddjsonCntrl)
dfRawCnrtl = dfFileListCntl.select(concat(lit('/'),dfFileListCntl.assetcurrentlocation,lit('/'),dfFileListCntl.assetname).alias('full_filename'))

#display(dfFileListCntl)


#Create list of asset id's of input list file to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
#print(dfAssetIdStr)

#Create list of asset id's of cntlr list file to return for WriteAPI
dfAssetIdCntrl = dfFileListCntl.select(dfFileListCntl.assetid).alias('assetid')
dfAssetIdArrayCntrl = [int(row['assetid']) for row in dfAssetIdCntrl.collect()]
dfAssetIdStrCntrl=str(dfAssetIdArrayCntrl).replace("[","").replace("]","")

dfAssetIdStr=dfAssetIdStr+","+dfAssetIdStrCntrl

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

dfNamePathCntrl = dfRawCnrtl\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)
#display(dfNamePathCntrl)

# COMMAND ----------

# DBTITLE 1,Filter latest Input files
# Filter the latest files

from pyspark.sql.functions import col

EXTR_DTTM = dbutils.widgets.get("pEXTR_DTTM")

#For diffferent format of datettime stamp update the add additional if staments here

if(dbutils.widgets.get("FORMAT_FILE_NAME")=="FILENAME_DATETIMESTAMP"):
  dfFiltered = dfNamePath\
               .withColumn("filedate", unix_timestamp(regexp_replace(split(col("filename"), "_")[0], ".dat", ""), "yyyyMMdd").cast("timestamp"))\
               .withColumn("lastExtractDate", unix_timestamp(lit(EXTR_DTTM), "yyyy-MM-dd HH:MM:SS").cast("timestamp"))

  dfFiltered = dfFiltered.filter(col("filedate") > col("lastExtractDate")).drop("filedate", "lastExtractDate")
  
if(dbutils.widgets.get("FORMAT_FILE_NAME")=="FILENAME_DATE_TIMESTAMP"):

  dfFiltered = dfNamePath\
               .withColumn("filedate", unix_timestamp(regexp_replace(reverse(split(reverse(col("filename")), "_")[1]), ".dat", ""), "yyyyMMdd").cast("timestamp"))\
               .withColumn("lastExtractDate", unix_timestamp(lit(EXTR_DTTM), "yyyy-MM-dd HH:MM:SS").cast("timestamp"))

  dfFiltered = dfFiltered.filter(col("filedate") > col("lastExtractDate")).drop("filedate", "lastExtractDate")

#display(dfFiltered)

# COMMAND ----------

# DBTITLE 1,Control Files
#Read Control Files:
from pyspark.sql.functions import *

readList=[mountPoint + row[0] + '/' + row[1] for row in dfNamePathCntrl.select('filepath','filename').collect()]

readFileSchema = (
  StructType([
    StructField("read_data", StringType(), False)
  ])
)

dfMultiCntrl = spark.read.csv(readList).withColumn("filename", substring_index(input_file_name(),"/",-1))

#dfMultiCntrl =   dfMultiCntrl.withColumn("filenameAlone",substring_index(col("filename"),"/",-1))

# Add Reject Header
dfMultiCntrl = dfMultiCntrl\
                           .withColumn("src_type", lit("F"))\
                           .withColumn("src_key", lit(""))\
                           .withColumn("err_desc",lit(""))\
                           .withColumn("prty_cd", lit(0))\
                           .withColumn("src_name",regexp_replace(dfMultiCntrl.filename, '.ok', '.dat')) \
                           .withColumnRenamed("_c0","exp_record_count")

#                             .withColumn("src_name", lit(dfMultiCntrl.filename))\

# Moving reject header to front
dfMultiCntrl = dfMultiCntrl.filter(col("prty_cd") == 0)
dfMultiCntrl = dfMultiCntrl.select("src_name", "src_type", "src_key", "err_desc", "prty_cd","exp_record_count")

#display(dfMultiCntrl)


# Save OUTF_REJ - Invalid Control files
dfMultiCntrlInvalid = dfMultiCntrl.filter(col("prty_cd") != 0)
dfMultiCntrlInvalid.createOrReplaceGlobalTempView("dfMultiCntrlInvalid")
file_path = "{0}/{1}/stdrej_{2}_cntrl_file/{3}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEDW_BATCH_ID"))
#print(file_path)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfMultiCntrlInvalid"})


# COMMAND ----------

# Reading files content


readList=[mountPoint + row[0] + '/' + row[1] for row in dfFiltered.select('filepath','filename').collect()]

readFileSchema = (
  StructType([
    StructField("read_data", StringType(), False)
  ])
)

dfMulti = spark.read.csv(readList).withColumn("filename", input_file_name())

#display(dfMulti)

# COMMAND ----------

# DBTITLE 1,Invalid Layout files
# Validation

# Validate Number of Columns
import re
import datetime

delimiter = re.escape(dbutils.widgets.get("pIN_FILE_DELIM"))
newDelimiter = re.escape("\x01")
rejHeaderIndicator = dbutils.widgets.get("pREJ_HDR_GEN_IND")
expectedColumnCount = 0 if dbutils.widgets.get("pIN_FILE_COL_CNT") == "" else int(dbutils.widgets.get("pIN_FILE_COL_CNT"))

dfMultiValidated = dfMulti\
                   .withColumn("numberOfColumns", size(split(col("_c0"), delimiter)))

dfMultiValidated = dfMultiValidated\
                   .withColumn("numberOfColumnsWithHeader", when(lit(rejHeaderIndicator) == "Y", col("numberOfColumns") + 5).otherwise(col("numberOfColumns")))

dfMultiValidated = dfMultiValidated\
                   .withColumn("numberOfColumnsValidation", when((lit(expectedColumnCount) > 0) & (lit(expectedColumnCount) != col("numberOfColumnsWithHeader")), concat(lit("Invalid record layout ("), col("numberOfColumnsWithHeader"), lit(" columns found out of "), lit(expectedColumnCount), lit(" total expected)"))).otherwise(lit("")))

# Validate Extract DT
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", split(col("filename"), "_"))

#For diffferent format of datettime stamp update the add additional if staments here
if(dbutils.widgets.get("FORMAT_FILE_NAME")=="FILENAME_DATE_TIMESTAMP"):
  dfMultiValidated = dfMultiValidated\
                     .withColumn("edw_gen_mi_last_update_dttm", col("edw_gen_mi_last_update_dttm")[size(col("edw_gen_mi_last_update_dttm")) - 2])

dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", split(col("edw_gen_mi_last_update_dttm"), "\.")[0])
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", unix_timestamp(col("edw_gen_mi_last_update_dttm"), "yyyyMMdd").cast("timestamp"))
dfMultiValidated = dfMultiValidated\
                   .withColumn("ExtractDTValidation", when(col("edw_gen_mi_last_update_dttm").isNull(), "Invalid source file date [{0}]".format(col("edw_gen_mi_last_update_dttm"))).otherwise(lit("")))


# Add Reject Header
dfMultiValidated = dfMultiValidated\
                             .withColumn("src_name", substring_index(input_file_name(),"/",-1))\
                             .withColumn("src_type", lit("F"))\
                             .withColumn("src_key", lit(""))\
                             .withColumn("err_desc", when((col("numberOfColumnsValidation") != "") | (col("ExtractDTValidation") != ""), trim(concat(lit("ERROR: "), col("numberOfColumnsValidation"), lit(" "), col("ExtractDTValidation")))))\
                             .withColumn("prty_cd", when((col("numberOfColumnsValidation") != "") | (col("ExtractDTValidation") != ""), 2).otherwise(0))\
                             .withColumn("read_data", concat(when(col("edw_gen_mi_last_update_dttm").isNull(), lit("")).otherwise(col("edw_gen_mi_last_update_dttm")), lit(newDelimiter) ,regexp_replace(col("_c0"), delimiter, newDelimiter)))\
                             .drop("numberOfColumns", "numberOfColumnsWithHeader", "numberOfColumnsValidation", "ExtractDTValidation", "_c0")

# Moving reject header to front
dfMultiValidated = dfMultiValidated.select("src_name", "src_type", "src_key", "err_desc", "prty_cd", "read_data")

#display(dfMultiValidated)

# COMMAND ----------

# DBTITLE 1,Write Invalid Input Layout files
# Filter Invalid Layout

dfInvalidLayout = dfMultiValidated\
                             .filter(col("prty_cd") != 0)

dfValid = dfMultiValidated\
                              .filter(col("prty_cd") == 0)

# Save OUTF_REJ - Invalid File Layout
dfInvalidLayout.createOrReplaceGlobalTempView("dfInvalidLayoutWrite")
file_path = "{0}/{1}/stdrej_{2}_in_dml/{3}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEDW_BATCH_ID"))
#print(file_path)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfInvalidLayoutWrite"})




# COMMAND ----------

# DBTITLE 1,Verify Record Count
#Create lookup file with mismatch of total records(valid + invalid layout) from  control file

if(dbutils.widgets.get("pCNTRL_FILE_VERIFY_IND")=="Y"):

  dfInvalidLayoutRollup = dfInvalidLayout.groupBy(col("src_name"))\
                                        .count()\
                                        .withColumn("src_type_invalid", lit("F"))\
                                        .withColumn("src_key_invalid", lit(""))\
                                        .withColumn("err_desc_invalid",lit(""))\
                                        .withColumn("prty_cd_invalid", lit(2))\
                                        .withColumnRenamed("count","invalid_record_count")
                        
  dfValidRollup = dfValid.groupBy(col("src_name"))\
                        .count()\
                        .withColumn("src_type_valid", lit("F"))\
                        .withColumn("src_key_valid", lit(""))\
                        .withColumn("err_desc_valid",lit(""))\
                        .withColumn("prty_cd_valid", lit(0))\
                        .withColumnRenamed("count","valid_record_count")


  dfOuterJoin = dfValidRollup.join(dfInvalidLayoutRollup,\
                           on=["src_name"],how="outer")\
                           .join(dfMultiCntrl,\
                            on=["src_name"],how ="outer")

  #display(dfOuterJoin)



#Update Null values to zero for record counts and check if counts are in required limit

  dfOuterJoinReformat = dfOuterJoin.withColumn("valid_record_count",\
                                                  when(col("valid_record_count").isNull(),lit(0))\
                                                  .otherwise(col("valid_record_count")))\
                                  .withColumn("invalid_record_count",\
                                                  when(col("invalid_record_count").isNull(),lit(0))\
                                                  .otherwise(col("invalid_record_count")))\
                                  .withColumn("exp_record_count",\
                                                  when(col("exp_record_count").isNull(),lit(0))\
                                                  .otherwise(col("exp_record_count")))\
                                  .withColumn("errorCode",\
                                                   when(~( (col("exp_record_count") >= col("valid_record_count")) &\
                                                          (col("exp_record_count") <= col("valid_record_count") + col("invalid_record_count"))),                                                                             lit("211"))\
                                                   .when(col("exp_record_count").isNull(),lit("210"))\
                                                   .otherwise(lit(0))) 

#from pyspark.sql.functions import first

  dfOuterJoinReformatFinal =  dfOuterJoinReformat.withColumn("reject_header_src_key",lit(""))\
                                                  .withColumn("reject_header_err_desc",\
                                                     when(col("errorCode")==210,lit("ERROR: Control File Not Find"))\
                                                    .when(col("errorCode")==211,\
                                                          concat(lit("Invalid source record count - Expected record read count("),\
                                                                      lit(newDelimiter),\
                                                                      col("exp_record_count"),\
                                                                      lit(") Valid record read count(" ),\
                                                                      lit(newDelimiter),\
                                                                      col("valid_record_count"),\
                                                                      lit(") Invalid record read count(" ),\
                                                                      col("invalid_record_count"),\
                                                                      lit(")"))) \
                                                      .otherwise(""))\
                                                      .withColumn("prty_cd",\
                                                                 when((col("errorCode")==210) | (col("errorCode")==211),lit(2))\
                                                                  .otherwise(0))

  dfOuterJoinReformatFinal= dfOuterJoinReformatFinal.filter((col("prty_cd")==2) | (col("prty_cd")==1))
  dfOuterJoinReformatFinal=dfOuterJoinReformatFinal.select("src_name", "src_type", "src_key", "err_desc", "prty_cd")
#  display(dfOuterJoinReformatFinal)



  # Output Lookup - Count Mismatches
  dfOuterJoinReformatFinal.createOrReplaceGlobalTempView("dfOuterJoinReformatFinal")
  file_path = "{0}/{1}/{2}_src_cnt_mismatch/{3}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_LOOKUP"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEDW_BATCH_ID"))
#print(file_path)

  dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path, "view_name": "dfOuterJoinReformatFinal"})


# COMMAND ----------

# DBTITLE 1,Filter Source Count Mismatch Files
if((dbutils.widgets.get("pCNTRL_FILE_VERIFY_IND")=="Y") & (dbutils.widgets.get("pCNTRL_FILE_REJ_IND")=="Y")):

  dfValid1 = dfValid.select([F.col(c).alias("Input_file_"+c) for c in dfMultiValidated.columns])
  dfOuterJoinReformatFinal1 = dfOuterJoinReformatFinal.select([F.col(c).alias("Lookup_file_"+c) for c in dfOuterJoinReformatFinal.columns])

  dfLookupResult= dfValid1.join(dfOuterJoinReformatFinal1,
                                    col("Input_file_src_name")==col("Lookup_file_src_name"),
                                    how ="leftouter")

  dfLookupResultSelected =   dfLookupResult.withColumn("prty_cd",\
                                                      when(~(col("Lookup_file_prty_cd").isNull()),col("Lookup_file_prty_cd"))\
                                                      .otherwise(0))\
                                          .withColumn("err_desc",\
                                                       when((col("prty_cd") == 1) | \
                                                            (col("prty_cd") == 2),col("Lookup_file_err_desc"))\
                                                       .otherwise(lit("")))\
                                            .select(col("Input_file_src_name").alias("src_name"),\
                                                    col("Input_file_src_type").alias("src_type"),\
                                                    col("Input_file_src_key").alias("src_key"),\
                                                    col("err_desc"),\
                                                    col("prty_cd"),\
                                                    col("Input_file_read_data").alias("read_data"))


#Invalid Count mismatch files filter
  dfInvalidCount = dfLookupResultSelected.filter(col("prty_cd") != 0)
  dfValidSelect = dfLookupResultSelected.filter(col("prty_cd") == 0)
# Output Reject - Count Mismatches records by control file
  dfInvalidCount.createOrReplaceGlobalTempView("dfInvalidCount")
  file_path = "{0}/{1}/stdrej_{2}_src_cnt_mismatch/{3}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"),dbutils.widgets.get("pEDW_BATCH_ID"))

  dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path, "view_name": "dfInvalidCount"})
  
else:
  dfValidSelect = dfValid
  

  
#display(dfValidSelect)

# COMMAND ----------

#  RFMT - Prepare for Data Read

dataReadDF = dfValidSelect

if rejHeaderIndicator != "Y":
  dataReadDF = dfValidSelect.drop("src_name", "src_type", "src_key", "err_desc", "prty_cd")
else:
  dataReadDF = dfValidSelect.withColumn("src_key", lit(dbutils.widgets.get("pTGT_KEY_LIST")))
  
#display(dataReadDF)

# COMMAND ----------

# DBTITLE 1,Input Schema
# Apply Schema

import json
from functools import reduce

dfFormated = dataReadDF.withColumn("read_data", split(col("read_data"), newDelimiter))

if rejHeaderIndicator == "Y":
  dfFormated = dfFormated.select(['src_name', 'src_type', 'src_key', 'err_desc', 'prty_cd'] + [expr('read_data[' + str(x) + ']') for x in range(0, expectedColumnCount - 4)])
else:
  dfFormated = dfFormated.select([expr('read_data[' + str(x) + ']') for x in range(0, expectedColumnCount - 4)])



#Add new schema here

schema = mountPointSchema + dbutils.widgets.get("pGEN_IN_FILE_SCHEMA")
dfFileList =spark.read.option("multiline","true").json(schema)
#display(dfFileList)

schemaList=dfFileList.select('ColumnName').rdd.flatMap(lambda x: x).collect()

#print(schemaList)


oldColumns = dfFormated.schema.names

dfFormated = reduce(lambda dfFormated, idx: dfFormated.withColumnRenamed(oldColumns[idx], schemaList[idx]), range(len(oldColumns)), dfFormated)

#display(dfFormated)



# COMMAND ----------

###########################################################################################################################################################################################
# In case $pCLEANSE_KEY_XFR and $pCLEANSE_KEY_FLTR_EXP have implmentation defined at Plan Level, this cell should be used to handle the different types of logic for these two parameters #
###########################################################################################################################################################################################

# COMMAND ----------

# DBTITLE 1,Duplicate Removal
# Perform Dedup based on pDEDUP_DATA_IND. Expecting pTGT_KEY_LIST to be in the format "col1, col2, col3..."

dfBeforeDedup = dfFormated.withColumn("UID", monotonically_increasing_id())

keysSortDedupList = [x.strip(' ') for x in dbutils.widgets.get("pTGT_KEY_LIST").split(",")]

dfDedup = None

if dbutils.widgets.get("pDEDUP_DATA_IND") == "Y":
  dfDedup = dfBeforeDedup.sort(keysSortDedupList)
  dfDedup = dfDedup.dropDuplicates(keysSortDedupList)
  dfDuplicated = dfBeforeDedup.alias("t1").join(dfDedup.alias("t2"), col("t1.UID") == col("t2.UID"), how='left')\
                 .filter(col("t2.UID").isNull()).select("t1.*")\
                 .withColumn("err_desc", lit("WARNING: Duplicate record (not within end-of-day snapshot)"))\
                 .withColumn("prty_cd", lit(3))\
                 .drop("UID")
  dfDedup = dfDedup.drop("UID")
  dfFormated = dfDedup
  
  # Write OUTF_REJ - Duplicates  
  dfDuplicated.createOrReplaceGlobalTempView("dfDuplicated")

  file_path = "{0}/{1}/stdrej_{2}_dup/{3}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"),dbutils.widgets.get("pEDW_BATCH_ID"))
#  print(file_path)
  
#  display(dfDuplicated)
  dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfDuplicated"})

#display(dfFormated)

# COMMAND ----------

# DBTITLE 1,Max Src File Date
# Output Max src_file_dttm

dfEOFSnapshot = dfFormated

dfMaxFileDTTM = dfEOFSnapshot.agg(max("edw_gen_mi_last_update_dttm").alias("src_file_dttm")).select("src_file_dttm")

# Write OUTF_INT - Max src_file_dttm
dfMaxFileDTTM.createOrReplaceGlobalTempView("dfMaxFileDTTM")
file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pTGT_PROC_MAX_DTTM_FILE"),dbutils.widgets.get("pEDW_BATCH_ID"))

#print(file_path)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfMaxFileDTTM"})

#display(dfMaxFileDTTM)

# COMMAND ----------

##################################################################################################################################################################
# In case $pTGT_XFORM_REJ_XFR have implmentation defined at Plan Level, this cell should be used to handle the different types of logic for these two parameters #
##################################################################################################################################################################

# COMMAND ----------

# DBTITLE 1,Schema For Validation
from pyspark.sql.functions import UserDefinedFunction
from pyspark.sql.functions import split
from pyspark.sql.types import *


col_list=dfFileList.schema.names
#print(col_list)
dfFileList=dfFileList.withColumn('concatenated_cols',concat_ws('|',*col_list))
#display(dfFileList)




schemaList=dfFileList.select('concatenated_cols').\
      rdd.flatMap(lambda x: x).collect()
#print(schemaList)


schemaListSplit=[]
for col in schemaList:
  schemaListSplit.append(col.split("|"))
  
#print(schemaListSplit)
#display(dfFormated)



# COMMAND ----------

# DBTITLE 1,All Validations
from pyspark.sql import functions as F
import re
from datetime import datetime



#------------Null Check------------
def is_bad_null(value,check):
   if ((check=="False") & ((value != value) | (value is None))):
       return False
   else:return True

isBadNullUDF= UserDefinedFunction(lambda x,y: is_bad_null(x,y),BooleanType())

for col in schemaListSplit:
  dfFormated = dfFormated.withColumn( col[0]+"_Valid_NonNull",isBadNullUDF(F.col(col[0]),lit(col[3]))  )




#-------------Length Check -----------
def is_bad_length(columnValue,lengthToCheck):
   if (  (lengthToCheck == "") | (str(columnValue)=="NA")) :return True         
   elif (len(str(columnValue)) <= int(lengthToCheck)):return True
   else:  return False

isBadLengthUDF= UserDefinedFunction(lambda x,y: is_bad_length(x,y),BooleanType())

for col in schemaListSplit:
  dfFormated = dfFormated.withColumn( col[0]+"_Valid_Length",isBadLengthUDF(F.col(col[0]),lit(col[2]))  )
  
  

##------------Special Character------------------

regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')

def is_bad_spcl_char(columnValue,spclCharCheck):
        if((spclCharCheck == "")|(spclCharCheck == "False")):return True
        elif (regex.search(columnValue) == None): return True
        else: return False 

isBadSpclCharUDF= UserDefinedFunction(lambda x,y: is_bad_spcl_char(x,y),BooleanType())

for col in schemaListSplit:
  dfFormated = dfFormated.withColumn( col[0]+"_Valid_Spcl_Char",isBadSpclCharUDF(F.col(col[0]),lit(col[4]))  )

  
##-------------Number CHeck-----------------
def is_number(n):
       try:
          float(n)   
       except ValueError:
          return False
       return True

  


##------------Datecheck function--------------
def datetime_format(value,format):
        try:
            datetime.strptime(value, format)
        except ValueError:
            return False
        return True

#------------Data Type Check---------------

def is_bad_data_type(columnValue,dataType,dateFormat):
       if((dataType=="StringType")|(dataType=="")) :return True         
       elif( ((dataType=="IntegerType")|(dataType=="DecimalType")|(dataType=="DateType")) & (len(str(columnValue) )==0)) :return True
       elif( (dataType=="IntegerType") & (is_number(str(columnValue))==True) ): return True
       elif( (dataType=="DecimalType") & (is_number(str(columnValue))==True) ): return True
       elif( (dataType=="DateType") & (datetime_format(str(columnValue),dateFormat)==True) ): return True
       else : return False
              

isBadDataTypeUDF= UserDefinedFunction(lambda x,y,z: is_bad_data_type(x,y,z),BooleanType())

for col in schemaListSplit:
  dfFormated = dfFormated.withColumn( col[0]+"_Valid_Data_Type",isBadDataTypeUDF(F.col(col[0]),lit(col[5]),lit(col[1]))  )
  
  
#display(dfFormated)

# COMMAND ----------

# DBTITLE 1,Addition of Party_codes and Error_desc for invalid records
#Add column reject party header code based on invalid records*****

for col in schemaListSplit:
  dfFormated = dfFormated.withColumn("Valid_"+col[0],  when( (F.col(col[0]+"_Valid_NonNull") == True) &\
                                                            (F.col(col[0]+"_Valid_Length") == True) &\
                                                            (F.col(col[0]+"_Valid_Spcl_Char") == True) &\
                                                            (F.col(col[0]+"_Valid_Data_Type") == True)\
                                                            ,lit("")  )
                                                            .otherwise(concat(lit(col[0]),lit("["),col[0],lit(":- invalid"),lit("],"))) )

  


#Select the "Valid_" columns to concatenate 
cols = [c for c in dfFormated.columns if c.startswith("Valid_")]
#print(cols)
dfFormated = dfFormated.withColumn("v_error_desc",concat(*cols))
#display(dfFormated)


#Addition of error Description & party code
dfFormated = dfFormated.withColumn("warn_desc",lit("")) \
                       .withColumn("prty_cd",\
                                             when(F.col("warn_desc") != "",lit(3)) 
                                             .when(dfFormated.v_error_desc.contains('invalid'),lit(2))\
                                             .otherwise(lit(0)) )\
                        .withColumn("err_desc",\
                                             when(F.col("warn_desc") != "",concat(lit("Warning:  Substituting values -"),F.col("warn_desc")))\
                                             .when(dfFormated.v_error_desc.contains('invalid'),\
                                                      concat(lit("ERROR: Invalid values found in input -"),F.col("v_error_desc")))\
                                             .otherwise(lit("")) )
                                    
  
#display(dfFormated)


# COMMAND ----------

# DBTITLE 1,Output Write Valid And Invalid Records
# !!TO BE REVIEWED WITH KIRAN: WHAT TYPES OF $pTGT_XFORM_REJ_XFR are among the plans!! (To be developed as part of the Plan development)
# !!TO BE REVIEWED WITH KIRAN: IF VALIDATION IS ENABLED WHY ARE WE JOINING THE RESULT BACK THE FULL DATASET? THIS WILL CREATE REPETITION

# Data Validations

dfFinal = dfFormated
schemaList=dfFileList.select('ColumnName').rdd.flatMap(lambda x: x).collect()

if dbutils.widgets.get("pVALIDATE_DATA_IND") == "Y":
    dfValidationRejects = dfFinal.filter((F.col("prty_cd") == 1) | (F.col("prty_cd") == 2))
    dfFinal=dfFinal.filter((F.col("prty_cd") != 1) & (F.col("prty_cd") != 2))
    #Selecting Target schema
    dfValidationRejects = dfValidationRejects.select(schemaList)
    dfValidationRejects = dfValidationRejects.drop("edw_gen_mi_last_update_dttm")
    dfValidationRejects.createOrReplaceGlobalTempView("dfValidationRejects")
    file_path_val_rej = "{0}/{1}/stdrej_{2}_val/{3}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"),dbutils.widgets.get("pEDW_BATCH_ID"))
    #print(file_path_val_rej)
    dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path_val_rej  , "view_name": "dfValidationRejects"})
  


dfFinal = dfFinal.select(schemaList)
dfFinal = dfFinal.drop("edw_gen_mi_last_update_dttm")
#display(dfFinal)
#display(dfValidationRejects)
# OUTF_LDR - Target Load Ready
dfFinal.createOrReplaceGlobalTempView("dfFinal")
file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pTGT_FILE"),dbutils.widgets.get("pEDW_BATCH_ID"))
#print(file_path)
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfFinal"})

# COMMAND ----------

# DBTITLE 1,Assetid for Write API Closure
dbutils.notebook.exit(dfAssetIdStr)

# Databricks notebook source
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions

# COMMAND ----------

# dbutils.widgets.text("proj_name","")
# dbutils.widgets.text("src_stream_name","")
# dbutils.widgets.text("SNOWFLAKE_DATABASE","")
# dbutils.widgets.text("schema_name","")
# dbutils.widgets.text("SNOWFLAKE_WAREHOUSE","")

# COMMAND ----------

import os

proj_name = dbutils.widgets.get("proj_name")
src_stream_name = dbutils.widgets.get("src_stream_name")
SNOWFLAKE_DATABASE = dbutils.widgets.get("SNOWFLAKE_DATABASE")
v_schema = dbutils.widgets.get("schema_name")
SNOWFLAKE_WAREHOUSE = dbutils.widgets.get("SNOWFLAKE_WAREHOUSE")
# Defining schema for table

# SNOWFLAKE_DATABASE = "dapdevdwh01"
# v_schema = "prdetlsand01"

query = "UPDATE {3}.{2}.proc_cntrl_batch_detail SET batch_status_cd='0' WHERE edw_batch_id = ( SELECT MAX(edw_batch_id) FROM {3}.{2}.proc_cntrl_batch_detail WHERE batch_status_cd='1' AND proj_name='{0}' AND src_stream_name='{1}' ) AND proj_name='{0}' AND src_stream_name='{1}'".format(proj_name, src_stream_name,v_schema,SNOWFLAKE_DATABASE)

dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : query, "transaction" : True, "SNOWFLAKE_DATABASE" : SNOWFLAKE_DATABASE,"SNOWFLAKE_WAREHOUSE" : SNOWFLAKE_WAREHOUSE})

query1 = "INSERT INTO {3}.{2}.proc_cntrl_batch_detail (proj_name, src_stream_name, edw_batch_id, batch_status_cd) VALUES ('{0}', '{1}', to_decimal(to_char(CURRENT_TIMESTAMP(), 'YYYYMMDDHHMISS')), 1)".format(proj_name, src_stream_name,v_schema,SNOWFLAKE_DATABASE)

dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : query1, "transaction" : True, "SNOWFLAKE_DATABASE" : SNOWFLAKE_DATABASE,"SNOWFLAKE_WAREHOUSE" : SNOWFLAKE_WAREHOUSE})

query2 = "SELECT MAX(edw_batch_id) as id FROM {3}.{2}.proc_cntrl_batch_detail WHERE proj_name='{0}' AND src_stream_name='{1}' AND batch_status_cd='1'".format(proj_name, src_stream_name,v_schema,SNOWFLAKE_DATABASE)

# Load data to dataframe

df = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", query2) \
  .load()

dbutils.notebook.exit(df.first()[0])
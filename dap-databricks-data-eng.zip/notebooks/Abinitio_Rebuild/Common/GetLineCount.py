# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

import pyspark
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType
import datetime
import pyspark.sql.column 

# COMMAND ----------

dbutils.widgets.text("PAR_DB_INPUT_PATH","",label="PAR_DB_INPUT_DIR")
dbutils.widgets.text("PAR_DB_INPUT_FILE_NAME","",label="PAR_DB_INPUT_FILE_NAME")
adlsInputFolderPath=dbutils.widgets.get("PAR_DB_INPUT_PATH")
adlsInputFileName=dbutils.widgets.get("PAR_DB_INPUT_FILE_NAME")
delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')

# COMMAND ----------

# Load File
df = spark.read.text(mountPoint+'/'+adlsInputFolderPath+'/'+adlsInputFileName)

# COMMAND ----------

# Get Line Count
dbutils.notebook.exit(df.count())
# Databricks notebook source
#dbutils.widgets.text("PAR_NB_POSEJ_ERR_QUEUE1", "retail/retail_sales/staging/INT_DF5_PARSE_REC_REFORMAT_DROP_FIELDS_1")
#dbutils.widgets.text("PAR_NB_RFRM_DROP_FIELDS_1", "retail/retail_sales/staging/INT_DF5_LOC_VALD_RFMT_DROP_FIELDS")
#dbutils.widgets.text("PAR_NB_DF5_DF8_INT_PART_3", "retail/retail_sales/staging/Int_DF5_DF8_Part3")
#dbutils.widgets.text("PAR_REDEFINEFORMATRECORDTYPEPARSINGTMP_FILE", "retail/retail_sales/staging/INT_DF8_Redefine_Format_Record_Type_Parsing2")
#dbutils.widgets.text("PAR_NB_POSEJ_ERR_QUEUE_ASCII", "retail/retail_sales/staging/POSEJ_Error_Queue_ascii")
#dbutils.widgets.text("PAR_NB_POSEJ_ERR_QUEUE_DESC_ASCII", "retail/retail_sales/staging/POSEJ_Error_Queue_Desc_ascii")
#dbutils.widgets.text("PAR_NB_POSEJ_ERR_QUEUE_SUMMARY", "retail/retail_sales/staging/POSEJ_Error_Queue_summary")
#dbutils.widgets.text("PAR_NB_LKP_POS_EJ_PATH", "retail/retail_sales/lookup/pos_file_lookup")


# COMMAND ----------

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as f
from pyspark.sql.window import Window

filePath_DF2_Invalid = mountPoint + "/" + "retail/retail_sales/staging/Int_DF2_DF8_RfrmtInvalidForErrqSink"
filePath_DF2_Ecomm = mountPoint + "/" + "retail/retail_sales/staging/Int_DF2_DF8_RfrmatInvalidAndEcommForErrqTMP"
filePath_DF5_ParseRec_DropFields1 = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJ_ERR_QUEUE1")
filePath_DF5_Loc_Val_DropFields = mountPoint + "/" + dbutils.widgets.get("PAR_NB_RFRM_DROP_FIELDS_1")
filePath_DF5_Line_Void_2nd_Balance_check = mountPoint + "/" + "retail/retail_sales/staging/Int_DF5_DF8_Part3"
filePath_DF8_Detail_Parser_InvalidPhNumber = mountPoint + "/" + dbutils.widgets.get("PAR_REDEFINEFORMATRECORDTYPEPARSINGTMP_FILE")
filePath_POSEJ_ERR_QUEUE_ASCII = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJ_ERR_QUEUE_ASCII")
filePath_POSEJ_ERR_QUEUE_DESC_ASCII = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJ_ERR_QUEUE_DESC_ASCII")
filePath_POSEJ_ERR_QUEUE_SUMMARY = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POSEJ_ERR_QUEUE_SUMMARY")

# COMMAND ----------

df_DF2_Invalid = spark.read.format('parquet').load(filePath_DF2_Invalid)
df_DF2_Ecomm = spark.read.format('parquet').load(filePath_DF2_Ecomm)
df_DF5_ParseRec_DropFields1 = spark.read.format('parquet').load(filePath_DF5_ParseRec_DropFields1)
df_DF5_Loc_Val_DropFields = spark.read.format('parquet').load(filePath_DF5_Loc_Val_DropFields)
df_DF5_Line_Void_2nd_Balance_check = spark.read.format('parquet').load(filePath_DF5_Line_Void_2nd_Balance_check)
df_DF8_Detail_Parser_InvalidPhNumber = spark.read.format('parquet').load(filePath_DF8_Detail_Parser_InvalidPhNumber)


# COMMAND ----------

#Merge all Error files

Error_Files_df = df_DF2_Invalid.union(df_DF2_Ecomm.union(df_DF5_ParseRec_DropFields1                                                                     .union(df_DF5_Loc_Val_DropFields.union(df_DF5_Line_Void_2nd_Balance_check.union(df_DF8_Detail_Parser_InvalidPhNumber)))))

# COMMAND ----------

#Write to Error Queue File

Error_Queue_df = Error_Files_df.withColumn('stuff', substring(col('stuff'), 1, 71)).select('str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','rcd_type','stuff')

Error_Queue_df.write.format('parquet').mode('overwrite').save(filePath_POSEJ_ERR_QUEUE_ASCII)

# COMMAND ----------

#Write to Error Queue Desc File

Error_Desc_df = Error_Files_df.withColumn('stuff', substring(col('stuff'), 1, 71))

file_pos_file_lookup = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LKP_POS_EJ_PATH")

df_pos_file_lookup  = spark.read.parquet(file_pos_file_lookup)

join_fileName = Error_Desc_df.join(df_pos_file_lookup, trim(Error_Desc_df.file_nbr) == trim(df_pos_file_lookup.file_nbr), "leftouter")

join_fileName = join_fileName.withColumn('file_name', when(col("file_name").isNull(), lit(concat(lit("Unknown, "),Error_Desc_df.file_nbr))).otherwise(df_pos_file_lookup.file_name)).select("str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","rcd_type","stuff","file_name","rec_in_file","rec_in_txn_cntr","invalid_desc")

join_fileName.write.format('parquet').mode('overwrite').save(filePath_POSEJ_ERR_QUEUE_DESC_ASCII)

# COMMAND ----------

#Write to Error Queue Summ File

Error_Desc_df = Error_Files_df.withColumn('sort_desc', when( col('invalid_desc').contains("Err on txn rec"), lit("Error on related rec")).otherwise(f.expr("substring(invalid_desc, 5)")))

#Rollup 

df_initializeCounter = Error_Desc_df.withColumn('cnt_hdr',lit(0)).withColumn('cnt_A',lit(0)).withColumn('cnt_B',lit(0)).withColumn('cnt_C',lit(0)).withColumn('cnt_D',lit(0)).withColumn('cnt_E',lit(0)).withColumn('cnt_other',lit(0))

w_initializeCounter = Window.partitionBy("txn_cntr","str_nbr","rcd_type","txn_date").orderBy("sort_desc","str_nbr","txn_date")

df_counter = df_initializeCounter.withColumn('cnt_hdr',when(col('rcd_type')==" ",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_A',when(col('rcd_type')=="A",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_B',when(col('rcd_type')=="B",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_C',when(col('rcd_type')=="C",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_D',when(col('rcd_type')=="D",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_E',when(col('rcd_type')=="E",f.row_number().over(w_initializeCounter))) \
    .withColumn('cnt_other',when((col('rcd_type')!=" ") & (col('rcd_type')!="A") & (col('rcd_type')!="B") & (col('rcd_type')!="C") & (col('rcd_type')!="D") & (col('rcd_type')!="E") , f.row_number().over(w_initializeCounter))).na.fill(value=0,subset=["cnt_hdr","cnt_A","cnt_B","cnt_C","cnt_D","cnt_E","cnt_other"]) \
    .withColumn('invalid_desc', col('sort_desc')) \
    .withColumn('str_nbr', when(col("invalid_desc") == "Store not found", col("str_nbr")).otherwise(lit('')))

df_grouped = df_counter.groupBy("txn_cntr","str_nbr","txn_date","invalid_desc").agg(f.max('cnt_hdr').alias('cnt_hdr') \
      ,f.max('cnt_A').alias('cnt_A') \
      ,f.max('cnt_B').alias('cnt_B')  \
      ,f.max('cnt_C').alias('cnt_C')  \
      ,f.max('cnt_D').alias('cnt_D')  \
      ,f.max('cnt_E').alias('cnt_E') \
      ,f.max('cnt_other').alias('cnt_other'))

df_counter_dist = df_counter.select("str_nbr","invalid_desc").distinct()

df_join_cnt_group = df_grouped.join(df_counter_dist, df_grouped.str_nbr == df_counter_dist.str_nbr,"leftOuter").select(df_grouped.invalid_desc,df_grouped.str_nbr,"cnt_hdr","cnt_A","cnt_B","cnt_C","cnt_D","cnt_E","cnt_other").distinct()

df_join_cnt_group = df_join_cnt_group.withColumn('str_nbr', when((trim(col('str_nbr'))=='') | (col('str_nbr').isNull()),None).otherwise(col('str_nbr')))

df_join_cnt_group.write.format('parquet').mode('overwrite').save(filePath_POSEJ_ERR_QUEUE_SUMMARY)
# Databricks notebook source
staging_folder = dbutils.widgets.get('PAR_PL_STAGING_FOLDER')
input_folder = dbutils.widgets.get('PAR_PL_INPUT_FOLDER')
lookup_folder = dbutils.widgets.get('PAR_PL_LOOKUP_FOLDER')
batch_id=dbutils.widgets.get('PAR_PL_BATCH_ID')

# COMMAND ----------

import os
import json
from pyspark.sql.types import *
from pyspark.sql.functions import *


# Mounting ADLS
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
os.environ['mountPoint']=mountPoint
os.environ['Script_Path']="/dbfs" + mountPoint + "/common/dap7101s"
os.environ['mountPoint']=mountPoint
max_surrogate=mountPoint + '/' + dbutils.widgets.get('PAR_PL_STAGING_FOLDER') +'/' +'max_system_surrogate_key' 
os.environ['AI_FTP']="/dbfs" + mountPoint + '/' + input_folder
os.environ['AI_RECYCLE']=os.environ['AI_LOAD']=os.environ['AI_PERSIST_SERIAL']=os.environ['AI_INBOUND']=os.environ['AI_ACCESSIBLE']=AI_INBOUND="/dbfs" + mountPoint + '/' + dbutils.widgets.get('PAR_PL_STAGING_FOLDER')
os.environ['AI_LOOKUP']="/dbfs" + mountPoint + '/' + lookup_folder

os.environ['BATCH_ID']=batch_id
Max_Surrogate_key_Val_df= spark.read.format("parquet").load(max_surrogate)
#.select("col2")

Max_surrogate=Max_Surrogate_key_Val_df.withColumn('txn_id',trim(col('txn_id')).cast(DecimalType(18, 0))+1).select('txn_id').dropDuplicates().collect()[0][0]
print(Max_surrogate)
#Max_surrogate=regexp_replace(to_str(Max_surrogate),'','')
Max_surrogate=to_str(Max_surrogate)


# COMMAND ----------

from datetime import *

CYCLE_DATE_FILE=AI_INBOUND+'/'+'cycle_date'+'/'+'cycle_date.pipe_delim'
CURR_DATE=datetime.today()

CURR_DATE1=CURR_DATE.strftime('%Y%m%d%H%M%j')
CYCLE_DTTM=CURR_DATE.strftime('%Y-%m-%d %H:%M')
CYCLE_BATCH_ID=CURR_DATE.strftime('%y%j%H%M')

#print(CURR_DATE1)
#print(CYCLE_DTTM)
#print(CYCLE_BATCH_ID)

text=CYCLE_DTTM + '|' + CYCLE_BATCH_ID + '|' + Max_surrogate
print(text)
cycled=open(CYCLE_DATE_FILE,"w")
cycled.write(text)
cycled.close()

# COMMAND ----------

#%sh 
#mkdir $AI_PERSIST_SERIAL/max_system_surrogate_key/$BATCH_ID
#MAX_TXN_KEY_FILE=$AI_PERSIST_SERIAL/max_system_surrogate_key/$BATCH_ID/max_system_surrogate_key.dat
#mkdir $AI_INBOUND/cycle_date/$BATCH_ID
#CYCLE_DATE_FILE=$AI_INBOUND/cycle_date/$BATCH_ID/cycle_date.pipe_delim
#CURR_DATE=`date +%Y%m%d%H%M%j`
#echo $CURR_DATE
#CURR_YR=`echo $CURR_DATE | awk '{print substr($1,3,2)}'`
#echo $CURR_YR
#CURR_HR=`echo $CURR_DATE | awk '{print substr($1,9,2)}'`
#echo $
#CURR_MI=`echo $CURR_DATE | awk '{print substr($1,11,2)}'`
#JUL_DAY=`echo $CURR_DATE | awk '{print substr($1,13,3)}'`
#echo $JUL_DAY
#FORMATTED_DATE=`echo $CURR_DATE | awk '{printf("%s-%s-%s",substr($1,1,4),substr($1,5,2),substr($1,7,2))}'`
#CYCLE_DTTM=$FORMATTED_DATE" "$CURR_HR":"$CURR_MI
#echo $CYCLE_DTTM
#CYCLE_BATCH_ID=$CURR_YR""$JUL_DAY""$CURR_HR""$CURR_MI
#echo ${CYCLE_BATCH_ID}
#echo $CYCLE_BATCH_ID &> $CYCLE_DATE_FILE
#echo ${CYCLE_DTTM}|${CYCLE_BATCH_ID}|$START_TXN_ID| > $CYCLE_DATE_FILE

# COMMAND ----------


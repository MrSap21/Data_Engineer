# Databricks notebook source
# dbutils.widgets.text("PAR_DB_WAREHOUSE","PREPROD_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_DB_DATABASE","PREPROD_STAGING")
# dbutils.widgets.text("PAR_DB_TABLE","PATIENT_SERVICES.CIF_SM_DRUG_CLAIM_STG")
# dbutils.widgets.text("PAR_DB_FILE_PATH","pharmacy_healthcare/patient_services/staging/edw_cif_sm_drug_claim_ldr/20220525134045")
# dbutils.widgets.text("PAR_DB_TRUNCATE_TABLE","True")

# COMMAND ----------

SNFL_DB=dbutils.widgets.get('PAR_DB_DATABASE')
SNFL_WH=dbutils.widgets.get('PAR_DB_WAREHOUSE')
SNFL_TBL=dbutils.widgets.get('PAR_DB_TABLE')
PATH=dbutils.widgets.get('PAR_DB_FILE_PATH')
TRUNCATE_TABLE=dbutils.widgets.get('PAR_DB_TRUNCATE_TABLE')

# COMMAND ----------

import os
import json
from pyspark.sql.types import *
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)



# COMMAND ----------

from pyspark.sql.functions import *

lkp=mountPoint+'/'+PATH
df=spark.read.parquet(lkp)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

for col in df.columns:
    df = df.withColumn(col, when(ltrim(rtrim(df[col])) == "",None).otherwise(ltrim(rtrim(df[col]))))

for col in df.columns:
    if 'dttm' in col or 'DTTM' in col:
        df=df.withColumn(col,to_timestamp(df[col]))

# COMMAND ----------

if TRUNCATE_TABLE=='True':
    Truncate_Tbl = "Truncate table {0}.{1}".format(SNFL_DB,SNFL_TBL)
    dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : Truncate_Tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

df.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL) \
    .option("truncate_columns","on") \
    .option("continue_on_error","on") \
    .mode("append") \
    .save()

# COMMAND ----------



# Databricks notebook source
#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

#Widgets for passing required parameters values:

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220810190554")
# dbutils.widgets.text("PAR_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_SNFK_DB1","UAT_RETAIL")
# dbutils.widgets.text("PAR_SNFK_DB2","UAT_STAGING")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_PROGRAM_ACCOUNT_PROFILE")
# dbutils.widgets.text("PAR_SNFK_TBL2","RETAIL_SALES.WCARD_TANDEM_TXN_STG")
# dbutils.widgets.text("PAR_SNFK_TBL3","RETAIL_SALES.WCARD_LAST_TRANSACTION")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_REJECT_FOLDER","retail/retail_sales/reject")
# dbutils.widgets.text("PAR_WCARD_PROG_ACCT_PROF_UNLOAD","wcard_program_account_profile_unload")
# dbutils.widgets.text("PAR_WCARD_LAST_TRANS_UNLOAD","wcard_last_transaction_unload")
#dbutils.widgets.text("PAR_PREV_RECYCLE_TXN","wcard_prev_recycle_txn")

# COMMAND ----------

Batch_Id = dbutils.widgets.get("PAR_DB_BATCH_ID")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_DB2 = dbutils.widgets.get("PAR_SNFK_DB2")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
SNFL_TBL_NAME2 = dbutils.widgets.get("PAR_SNFK_TBL2")
SNFL_TBL_NAME3 = dbutils.widgets.get("PAR_SNFK_TBL3")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
WcardProgAcctProfUnload = dbutils.widgets.get("PAR_WCARD_PROG_ACCT_PROF_UNLOAD")
WcardLastTransUnload = dbutils.widgets.get("PAR_WCARD_LAST_TRANS_UNLOAD")

# COMMAND ----------

#Defining schema for CT Input source file:

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

Source_Schema = ['STORE_NUM',
                 'REGISTER_NUM',
                 'CASHIER_NUM',
                 'TRANSACTION',
                 'ACCOUNT_NUM',
                 'PLAN_ID',
                 'REQUEST_TYPE',
                 'ACTION_TYPE',
                 'APPROVAL_NUMBER',
                 'ORIGINATOR',
                 'APPROVED_AMOUNT',
                 'STARTING_BALANCE',
                 'ENDING_BALANCE',
                 'VENDOR_ID',
                 'STORE_DATE_TIME',
                 'RESPONSE_CODE',
                 'TRANSACTION_AMOUNT',
                 'REBATE_AGAINST_AMOUNT',
                 'REBATE_AMOUNT',
                 'REBATE_TYPE',
                 'USER_ID',
                 'TANDEM_TIMESTEMP']

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema)))
#print(schema)

#Reading file for the readList path
CTSrcFile_Path = mountPoint + "/retail/retail_sales/wcard/CT/*"

CTInputFileDF = spark.read.format("csv").option("delimiter","|").schema(schema).load(CTSrcFile_Path)

#display(CTInputFileDF)
print("Combined CT Files Count:{}".format(CTInputFileDF.count()))

#Writing Combined CT file to Staging Folder:

CTInputFileDF.write.format("parquet").mode("overwrite").save(mountPoint+"/retail/retail_sales/staging/CT_COMBINED")

# COMMAND ----------

#FBE: Invalid Tandem ts & Store Date Time & Vendor 
FBE_CheckDF = CTInputFileDF.filter(((trim(col("STORE_DATE_TIME")).isNotNull()) & (col("STORE_DATE_TIME")!='')) & ((trim(col("TANDEM_TIMESTEMP")).isNotNull()) & (col("TANDEM_TIMESTEMP")!='')) & ((col("VENDOR_ID").isNotNull()) & (trim(col("VENDOR_ID"))!='')))

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

###Staging Table for profile and last transaction

#Defining schema for wcard_prev_recycle_txn.dat file:
Source_Schema1 = ['store_number',
                 'register_number',
                 'cashier_number',
                 'transaction_number',
                 'account_number',
                 'plan_id',
                 'request_type',
                 'action_type',
                 'approval_number',
                 'originator',
                 'approved_amount',
                 'starting_balance',
                 'ending_balance',
                 'vendor_id',
                 'store_date',
                 'store_time',
                 'response_code',
                 'transaction_amount',
                 'rebate_against_amount',
                 'rebate_amount',
                 'rebate_type',
                 'user_id',
                 'tandem_tstmp']

schema1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema1)))
#print(schema1)

wcard_prev_recycle=mountPoint + '/' + Reject_Folder + '/' + dbutils.widgets.get('PAR_PREV_RECYCLE_TXN') + ".dat"

WCARD_PREV_CYL = spark.read.format("csv").option("delimiter","|").schema(schema1).load(wcard_prev_recycle)

WCARD_PREV_CYL=WCARD_PREV_CYL.select("store_number","register_number","cashier_number","transaction_number","account_number","plan_id","request_type","action_type","approval_number","originator","approved_amount","starting_balance","ending_balance","vendor_id","store_date","store_time","response_code","transaction_amount","rebate_against_amount","rebate_amount","rebate_type","user_id","tandem_tstmp")
#display(WCARD_PREV_CYL)
#print(WCARD_PREV_CYL.count())

##RFT: Incoming Dates-2
RftCheckDF=FBE_CheckDF.withColumn("STORE_DATE",substring(FBE_CheckDF.STORE_DATE_TIME,1,6))  \
.withColumn("store_number",FBE_CheckDF.STORE_NUM) \
.withColumn("register_number",FBE_CheckDF.REGISTER_NUM) \
.withColumn("cashier_number",FBE_CheckDF.CASHIER_NUM) \
.withColumn("transaction_number",FBE_CheckDF.TRANSACTION) \
.withColumn("store_time",substring(FBE_CheckDF.STORE_DATE_TIME,7,6))  \
.withColumn("tandem_tstmp",FBE_CheckDF.TANDEM_TIMESTEMP) \
.withColumn("account_number" ,FBE_CheckDF.ACCOUNT_NUM) \
.withColumn("approved_amount", lpad(FBE_CheckDF.APPROVED_AMOUNT,7,'0'))\
.withColumn("starting_balance", lpad(FBE_CheckDF.STARTING_BALANCE,7,'0')) \
.withColumn("ending_balance", lpad(FBE_CheckDF.ENDING_BALANCE,7,'0')) \
.withColumn("transaction_amount", lpad(FBE_CheckDF.TRANSACTION_AMOUNT,7,'0')) \
.withColumn("rebate_against_amount", lpad(FBE_CheckDF.REBATE_AGAINST_AMOUNT,7,'0')) \
.withColumn("rebate_amount", lpad(FBE_CheckDF.REBATE_AMOUNT,7,'0')) \
.select("store_number","register_number","cashier_number","transaction_number","account_number","plan_id","request_type","action_type","approval_number","originator","approved_amount","starting_balance","ending_balance","vendor_id","store_date","store_time","response_code","transaction_amount","rebate_against_amount","rebate_amount","rebate_type","user_id","tandem_tstmp")

WCARD_TNDEM_STG=WCARD_PREV_CYL.union(RftCheckDF).filter((col('store_number').isNotNull()) & (col('register_number').isNotNull()) & (col('transaction_number').isNotNull()) & (col('store_date').isNotNull())) \
.withColumn('str_nbr',col('store_number')) \
.withColumn('txn_nbr',col('transaction_number')) \
.withColumn('reg_nbr',col('register_number')) \
.withColumn('txn_dt',to_date(col('store_date'))) \
.withColumn('acct_id',col('account_number').cast(StringType())) \
.withColumn('profile_id',col('plan_id').cast(IntegerType())) \
.withColumn('prog_id',col('vendor_id').cast(IntegerType())) \
.select('str_nbr','txn_dt','txn_nbr','reg_nbr','acct_id','prog_id','profile_id').dropDuplicates(['acct_id','prog_id','profile_id'])
Wcard_Tandem_Txn_Stg_DF = WCARD_TNDEM_STG
Wcard_Tandem_Txn_Stg_DF.cache()

WCARD_TNDEM_STG.write \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase",SNFL_DB2) \
  .option("dbtable", SNFL_TBL_NAME2) \
  .option("truncate_table","ON")\
  .mode("overwrite") \
  .save()

# COMMAND ----------

#Read Wcard_Program_Account_Profile Table
SEL_WCARD_PGM_TBL="Select * FROM {0}".format(SNFL_TBL_NAME1)

Wcard_Program_Account_Profile_DF = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase",SNFL_DB1) \
  .option("query", SEL_WCARD_PGM_TBL) \
  .load()

Wcard_Program_Account_Profile_DF = Wcard_Program_Account_Profile_DF.withColumn("ACCT_ID",col("ACCT_ID").cast(StringType())) \
.withColumn("PROFILE_ID",col("PROFILE_ID").cast(IntegerType())) \
.withColumn("PROG_ID",col("PROG_ID").cast(IntegerType()))

# COMMAND ----------

#Join on Wcard_Program_Account_Profile Table and Wcard_Tandem_Txn_STG Table

Wcard_Program_Account_Profile_DF.createOrReplaceTempView("wcard_program_account_profile")
Wcard_Tandem_Txn_Stg_DF.createOrReplaceTempView("wcard_tandem_txn_stg")
Wcard_Program_Account_Profile_Join_DF = spark.sql("select * from wcard_program_account_profile a INNER JOIN wcard_tandem_txn_stg d on a.acct_id = d.acct_id and a.prog_id = d.prog_id and a.profile_id = d.profile_id where a.prog_acct_profile_end_dt is NULL").select ("a.acct_id","a.profile_id","prog_acct_profile_eff_dt","a.prog_id","prog_acct_profile_end_dt","acct_profile_stat_cd","create_dttm").distinct()

print("wcard_program_account_profile_unload: {}".format(Wcard_Program_Account_Profile_Join_DF.count()))

Wcard_Program_Account_Profile_Join_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WcardProgAcctProfUnload+"/"+Batch_Id)

# COMMAND ----------

#Read Wcard_Last_Transaction Table
SEL_Wcard_Txn_TBL="Select * FROM {0}".format(SNFL_TBL_NAME3)

Wcard_Last_Transaction_DF = spark.read \
  .format("snowflake")\
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase",SNFL_DB1) \
  .option("query", SEL_Wcard_Txn_TBL) \
  .load()

Wcard_Last_Transaction_DF = Wcard_Last_Transaction_DF.withColumn("ACCT_ID",col("ACCT_ID").cast(StringType())) \
.withColumn("PROFILE_ID",col("PROFILE_ID").cast(IntegerType())) \
.withColumn("PROG_ID",col("PROG_ID").cast(IntegerType()))

# COMMAND ----------

#Join on Wcard_Last_Transaction Table and Wcard_Tandem_Txn_STG Table

Wcard_Last_Transaction_DF.createOrReplaceTempView("wcard_last_transaction")
Wcard_Last_Transaction_Join_DF = spark.sql("select * from wcard_last_transaction a INNER JOIN wcard_tandem_txn_stg d on a.acct_id = d.acct_id and a.prog_id = d.prog_id and a.profile_id = d.profile_id").select ("a.acct_id","a.profile_id","a.prog_id","a.tandem_txn_dt","a.tandem_txn_tm","a.str_nbr","a.register_nbr","a.tandem_txn_nbr","a.tandem_str_txn_dt","a.tandem_str_txn_tm","a.tandem_cashier_nbr","a.tandem_req_type","a.tandem_actn_type","a.tandem_aprv_nbr","a.tandem_orig","a.tandem_aprv_dlrs","a.tandem_response_cd","a.tandem_rbt_type","a.tandem_rbt_dlrs","a.tandem_rbt_pctg","a.tandem_rbt_against_dlrs","a.tandem_starting_bal_dlrs","a.tandem_end_bal_dlrs","a.tandem_txn_dlrs","a.tandem_clnt_name","a.tandem_user_id","a.txn_type_cd","a.create_dttm").distinct()

# output for Join on Wcard_Program_Account_Profile Table and Wcard_Tandem_Txn_STG Table
print("wcard_last_transaction_unload: {}".format(Wcard_Last_Transaction_Join_DF.count()))
Wcard_Last_Transaction_Join_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WcardLastTransUnload+"/"+Batch_Id)

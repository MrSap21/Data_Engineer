# Databricks notebook source
# dbutils.widgets.text("PAR_NB_EDW_BATCH_ID","20220922143042")
# dbutils.widgets.text("STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("SRC_FILE_PATH","master_data/decode/pos/fct")

# COMMAND ----------

# Mounting ADLS
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",120)

# COMMAND ----------

import os

BatchID = dbutils.widgets.get("PAR_NB_EDW_BATCH_ID")
path = mountPoint+"/"+dbutils.widgets.get("SRC_FILE_PATH")
Staging_Folder = dbutils.widgets.get("STAGING_FOLDER")

#print(path)
#we shall store all the file names in this list"
filelist = []

for root, dirs, files in os.walk(path):
  for file in files:
    if file.__contains__('fct_day_str_upc'):
      filelist.append(os.path.join(root,file))
        
#print all the file names
for name in filelist:
    print(name)

# COMMAND ----------

#Read Run Date File
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime,timedelta
from pyspark.sql import Row
from pyspark.sql.window import Window

df = spark.read.parquet(mountPoint+"/"+Staging_Folder+"/run_sales_type_date_file")
RUN_DATE = df.collect()[0][0]
print("RUN_DATE:{}".format(RUN_DATE))

#calc next date ,RUN_DATE_4

NDATE = datetime.strptime(RUN_DATE,'%Y%m%d').date() + timedelta(1)
NEXT_DATE=str(NDATE).replace('-','')
print("NEXT_DATE:{}".format(NEXT_DATE))

RDATE4 = datetime.strptime(RUN_DATE,'%Y%m%d').date() + timedelta(3)
RUN_DATE_4=str(RDATE4).replace('-','')
print("RUN_DATE_4:{}".format(RUN_DATE_4))

#collecting the required file paths for generating this "combined_fct_day_str_upc.dat" file 
combinedFilePaths=[]
for file in filelist:
  fileName=file.split('/')[-1]
  fileDate=fileName.split('.')[0]
  
  if((fileDate >= RUN_DATE and fileDate < NEXT_DATE) or fileDate == RUN_DATE_4):
    combinedFilePaths.append(file)
    
WSpec = Window.partitionBy('FileDate').orderBy(col('FileUpdateTimeStamp').desc())

combinedFilePathsRDD = sc.parallelize(combinedFilePaths)

combinedFilePathsRDD = combinedFilePathsRDD.map(lambda x: Row(x))

FileListDF=spark.createDataFrame(combinedFilePathsRDD,['FilePath']) \
.withColumn("FileDate",split(col('FilePath'),"/")[7][0:8]) \
.withColumn("FileName",split(col('FilePath'),"/")[7]) \
.withColumn("FileUpdateTimeStamp",split(col('FileName'),"_")[4][0:14]) \
.withColumn("UpdateSeq",row_number().over(WSpec)) \
.filter(col('UpdateSeq')==1).select('FilePath')

FinalFctFileList = FileListDF.rdd.flatMap(lambda x:x).collect()
print(FinalFctFileList)

#loading the files to data frame
COMBINED_NEWFILE_DF = spark.read.format("text").load(FinalFctFileList).dropDuplicates()
print("COMBINED FCT FILE Count: {}".format(COMBINED_NEWFILE_DF.count()))

#saving the file 
pathToSaveFile = mountPoint+"/"+Staging_Folder+"/combined_fct_day_str_upc/"+ BatchID
print(pathToSaveFile)
COMBINED_NEWFILE_DF.write.format("parquet").mode("overwrite").save(pathToSaveFile)

# COMMAND ----------

#Flipping run_sales_type_date_file value to RUN_DATE + 1 for next day's run use:

df = df.withColumn("value",lit(str(NDATE).replace('-','')))

df.coalesce(1).write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/run_sales_type_date_file")

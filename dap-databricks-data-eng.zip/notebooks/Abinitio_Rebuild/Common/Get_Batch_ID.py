# Databricks notebook source
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions

# COMMAND ----------

# dbutils.widgets.text("proj_name","")
# dbutils.widgets.text("src_stream_name","")
# dbutils.widgets.text("SNOWFLAKE_DATABASE","")
# dbutils.widgets.text("SNOWFLAKE_WAREHOUSE","")
# dbutils.widgets.text("schema_name","")

# COMMAND ----------

import os
# Defining schema for table

proj_name = dbutils.widgets.get("proj_name")
src_stream_name = dbutils.widgets.get("src_stream_name")
SNOWFLAKE_DATABASE = dbutils.widgets.get("SNOWFLAKE_DATABASE")
SNOWFLAKE_WAREHOUSE = dbutils.widgets.get("SNOWFLAKE_WAREHOUSE")
v_schema = dbutils.widgets.get("schema_name")

# v_database = "dapdevdwh01"

# Return connection details

query = "SELECT MAX(edw_batch_id) as id FROM {3}.{2}.proc_cntrl_batch_detail WHERE proj_name='{0}' AND src_stream_name='{1}' AND batch_status_cd='1'".format(proj_name, src_stream_name,v_schema,SNOWFLAKE_DATABASE)

# Load data to dataframe

df = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", query) \
  .load()

dbutils.notebook.exit(df.first()[0])


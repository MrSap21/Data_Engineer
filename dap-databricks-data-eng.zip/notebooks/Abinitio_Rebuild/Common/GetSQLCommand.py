# Databricks notebook source
# Mounting ADLS

#mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_SQL", 450)

# COMMAND ----------

from pyspark.sql.functions import * 
import pandas as pd 

snowSQLQuery = spark.read.text("/mnt/utility_sql" + "/" + dbutils.widgets.get("sql_file_path"))
parStr = dbutils.widgets.get("parameters_list")

# Remove hidden characters from Paramters
from string import printable
parStr = ''.join(char for char in parStr if char in printable)

parList = parStr.split(";")

for parValue in parList:
  par = parValue.split("=")  
  parName = par[0].replace("$", "").replace("{", "").replace("}", "")
  parValue = par[1]
  pattern = "\\$" + parName + "|\\$\\{" + parName + "\\}"
  snowSQLQuery = snowSQLQuery.withColumn("value", regexp_replace("value", pattern, par[1]))

snowSQLQuery = snowSQLQuery.withColumn("id", lit(1)).groupby("id").agg(concat_ws("\\n", collect_list("value")).alias("query")).drop("id")
snowSQLQuerySTR = snowSQLQuery.collect()[0]["query"]

snowSQLQuerySTR = snowSQLQuerySTR.replace("'", "\\'")
snowSQLQuerySTR = snowSQLQuerySTR.replace('"','\\"')

# Remove hidden characters from SQL statement
from string import printable
snowSQLQuerySTR = ''.join(char for char in snowSQLQuerySTR if char in printable)

dbutils.notebook.exit(snowSQLQuerySTR)

# COMMAND ----------


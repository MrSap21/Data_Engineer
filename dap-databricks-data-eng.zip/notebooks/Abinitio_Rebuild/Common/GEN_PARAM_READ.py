# Databricks notebook source
import os
import json
from configparser import ConfigParser
from pathlib import Path


#Defining Default Variables 

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

dbutils.widgets.get("PAR_NB_SCRIPT_PATH")
PAR_NB_SCRIPT_PATH=getArgument("PAR_NB_SCRIPT_PATH")

dbutils.widgets.get("PAR_NB_SCRIPT_NAME")
PAR_NB_SCRIPT_NAME=getArgument("PAR_NB_SCRIPT_NAME")

dbutils.widgets.get("PAR_NB_PARAMETER_LIST")
PAR_NB_PARAMETER_LIST=getArgument("PAR_NB_PARAMETER_LIST")

Domain=PAR_NB_SCRIPT_PATH.split("/")[1]


os.environ['PAR_NB_SCRIPT_PATH']="/dbfs" + mountPoint + PAR_NB_SCRIPT_PATH
os.environ['PAR_NB_SCRIPT_NAME']=dbutils.widgets.get("PAR_NB_SCRIPT_NAME")

os.environ['PAR_NB_PARAMETER_LIST']=PAR_NB_PARAMETER_LIST

os.environ['mountPoint']=mountPoint
os.environ['AI_FTP']="/dbfs" + mountPoint + "/" + Domain + "/ftp"
os.environ['AI_INBOUND']="/dbfs" + mountPoint + "/" + Domain+ "/input"
os.environ['AI_LOG']="/dbfs" + mountPoint + "/" + Domain + "/log"
os.environ['AI_ACCESSIBLE']="/dbfs" + mountPoint + "/" +Domain + "/accessible"
os.environ['AI_PERSIST_SERIAL']="/dbfs" + mountPoint + "/" + Domain + "/persist/serial"
os.environ['AI_RECYCLE']="/dbfs" + mountPoint+ "/" + Domain  + "/recycle"
os.environ['AI_SERIAL_LOG']="/dbfs" + mountPoint+ "/" + Domain  + "/log"
os.environ['AI_ARCHIVE']="/dbfs" + mountPoint+ "/" + Domain  + "/archive"
os.environ['AI_WORK_SERIAL']="/dbfs" + mountPoint+ "/" + Domain  + "/work/serial"
os.environ['AI_PERSIST_MFS']="/dbfs" + mountPoint+ "/" + Domain  + "/persist/mfs"
os.environ['AI_SERIAL']="/dbfs" + mountPoint+ "/" + Domain + "/" + "serial"


#Creating property file for parameters


path = "/dbfs"+mountPoint + "/" + Domain + "/propertyFiles/"
script_name = PAR_NB_SCRIPT_NAME.replace('.sh','.properties').replace('.ksh','.properties')
propertyFilePath = path + script_name
Path(propertyFilePath).touch()
print("File created successfully" + propertyFilePath)
config = ConfigParser()
param_list = PAR_NB_PARAMETER_LIST.split("~^#")
try:
  file = open(propertyFilePath, mode='w')
  file.write("[PARAMETERS]\n")
except:
  print("File not found OR incorrect path")
for param in param_list:
  file.write(param + "\n")
file.close() 
try:
  config.read(propertyFilePath)
except:
  print("Error while trying to open file.")
  
#Setting Environment variable for parameters

separator = "="
pKeys = {}
with open(propertyFilePath) as f:
    for line in f:
        if separator in line:
            name, value = line.split(separator, 1)
            pKeys[name.strip()] = value.strip()
            
for section in config.sections():
  sec = section
  
for en in pKeys:
  key = en
  val = config.get(sec,key)
  os.environ[key] = val 

if Path(propertyFilePath).is_file():
  os.remove(propertyFilePath)
  print("Property file removed successfully!")


# COMMAND ----------

# MAGIC 
# MAGIC %sh
# MAGIC pushd $PAR_NB_SCRIPT_PATH
# MAGIC echo $PAR_NB_EXCL_TYPE
# MAGIC $PAR_NB_SCRIPT_PATH/$PAR_NB_SCRIPT_NAME
# MAGIC 
# MAGIC popd
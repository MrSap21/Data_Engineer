# Databricks notebook source
#Widgets for passing required parameters values:

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220823062450")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_DELETE_LKP_FILE","wcard_prog_acct_profile_delete_lkp")
# dbutils.widgets.text("PAR_WCARD_PROG_ACC_PROFILE_FILE","wcard_program_account_profile")
# dbutils.widgets.text("PAR_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_SNFK_DB1","UAT_STAGING")
# dbutils.widgets.text("PAR_SNFK_DB2","UAT_RETAIL")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_PROGRAM_ACCOUNT_PROFILE")
# dbutils.widgets.text("PAR_SNFK_TBL2","RETAIL_SALES.WCARD_ACCT_ID_STG")
# dbutils.widgets.text("PAR_WCARD_UPDATE_FILE","wcard_program_account_profile_update_ascii.pipe_delim")
# dbutils.widgets.text("PAR_WCARD_INSERT_FILE","wcard_program_account_profile_insert_ascii.pipe_delim")
# dbutils.widgets.text("PAR_TANDEM_CREATE_DTTM","wcard_tandem_create_dttm_lkp1")

# COMMAND ----------

#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

Batch_id = dbutils.widgets.get("PAR_DB_BATCH_ID")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
Delete_LKPFile = dbutils.widgets.get("PAR_DELETE_LKP_FILE")
Wcard_Prog_Acc_Input_File = dbutils.widgets.get("PAR_WCARD_PROG_ACC_PROFILE_FILE")
SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_DB2 = dbutils.widgets.get("PAR_SNFK_DB2")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
SNFL_TBL_NAME2 = dbutils.widgets.get("PAR_SNFK_TBL2")
Wcard_Update_File = dbutils.widgets.get("PAR_WCARD_UPDATE_FILE")
Wcard_Insert_File = dbutils.widgets.get("PAR_WCARD_INSERT_FILE")
Wcard_Tandem_dttm = dbutils.widgets.get("PAR_TANDEM_CREATE_DTTM")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# wcard_program_account_profile.dat file read:
Wcard_Prog_Acc_ProfileDF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+Wcard_Prog_Acc_Input_File+"/"+Batch_id)

#Sort and Dedup:
DedupSortDF = Wcard_Prog_Acc_ProfileDF.dropDuplicates(['acct_id','profile_id','prog_id'])

#FBE:Only pass Valid Key:
FBEValidKeyDF = DedupSortDF.filter(((trim(col("acct_id")).isNotNull()) & (col("acct_id")!='')) & ((trim(col("prog_id")).isNotNull()) & (col("prog_id")!='')) & ((col("profile_id").isNotNull()) & (trim(col("profile_id"))!='')))

# wcard_prog_acct_profile_delete_lkp file read:
wcard_prog_del_lkpDF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+Delete_LKPFile+"/"+Batch_id)

FBEValidKeySelAcctId_DF = FBEValidKeyDF.select("acct_id")
wcard_prog_del_selAcct_idDF = wcard_prog_del_lkpDF.select("acct_id")

#Dedup Sorted on acct_id
GatherDF = FBEValidKeySelAcctId_DF.unionByName(wcard_prog_del_selAcct_idDF).dropDuplicates(['acct_id'])

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Delete stg table:
delete_WcardAccIDstg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB1, SNFL_TBL_NAME2)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_WcardAccIDstg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB1,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

GatherDF.cache()
GatherDF.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("truncate","true")\
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB1) \
        .option("dbtable", SNFL_TBL_NAME2) \
        .option("continue_on_error","on")\
        .save()

# COMMAND ----------

RFT_TransformDF = FBEValidKeyDF.withColumn("compare_col_concatenated",concat(col('acct_id'),col('prog_id'),col('profile_id'),coalesce(trim(col('acct_profile_stat_cd')),lit("Test1"))))

#Reading tables:

sel_wcard_prog_acc_table = "Select * FROM {0}".format(SNFL_TBL_NAME1)

wcard_prog_acc_tbl_df=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFL_DB2) \
     .option("query",sel_wcard_prog_acc_table) \
     .load()

wcard_prog_acc_tbl_df.createOrReplaceTempView("wcard_program_account_profile")
GatherDF.createOrReplaceTempView("stg_wcard_acct_id")

JoinTableDF = spark.sql("select * from wcard_program_account_profile a inner join stg_wcard_acct_id b on a.acct_id=b.acct_id").select("a.ACCT_ID","PROFILE_ID","PROG_ACCT_PROFILE_EFF_DT","PROG_ID","PROG_ACCT_PROFILE_END_DT","ACCT_PROFILE_STAT_CD","CREATE_DTTM")

#FBE:Only record with a null end dt:
FBERecordNullEndDF = JoinTableDF.filter(col("PROG_ACCT_PROFILE_END_DT").isNull())

RFT_Trans1DF = FBERecordNullEndDF.withColumn("compare_col_concatenated",concat(col('acct_id'),col('prog_id'),col('profile_id'),coalesce(trim(col('acct_profile_stat_cd')),lit("Test1"))))

#Join-5:
Join5DF = RFT_TransformDF.join(RFT_Trans1DF,on=[RFT_TransformDF.acct_id==RFT_Trans1DF.ACCT_ID,RFT_TransformDF.profile_id==RFT_Trans1DF.PROFILE_ID,RFT_TransformDF.prog_id==RFT_Trans1DF.PROG_ID],how='inner')

Join5DF1 = Join5DF.withColumn("update_flag",when(((RFT_TransformDF.acct_profile_stat_cd.isNotNull()) & (RFT_Trans1DF.ACCT_PROFILE_STAT_CD.isNotNull()) & (RFT_TransformDF.acct_profile_stat_cd==RFT_Trans1DF.ACCT_PROFILE_STAT_CD)),lit("N")).when((((RFT_TransformDF.acct_profile_stat_cd.isNull()) & (RFT_Trans1DF.ACCT_PROFILE_STAT_CD.isNull())) | ((RFT_TransformDF.acct_profile_stat_cd=='') & (RFT_Trans1DF.ACCT_PROFILE_STAT_CD==''))),lit("N")).when(((RFT_TransformDF.compare_col_concatenated.isNotNull()) & (RFT_Trans1DF.compare_col_concatenated.isNotNull()) & (RFT_TransformDF.compare_col_concatenated==RFT_Trans1DF.compare_col_concatenated)),lit("N")).otherwise(lit("Y"))) \
.withColumn("prog_acct_profile_end_dt1",date_sub(to_date(RFT_TransformDF.prog_acct_profile_eff_dt),1)).select(RFT_TransformDF.acct_id,RFT_TransformDF.profile_id,RFT_TransformDF.prog_acct_profile_eff_dt,RFT_TransformDF.prog_id,col("prog_acct_profile_end_dt1").alias("prog_acct_profile_end_dt"),RFT_TransformDF.acct_profile_stat_cd,RFT_TransformDF.create_dttm,"update_flag")

# COMMAND ----------

#FBE:Only pass where update flag = "Y":

FBEPassUpdateFlagDF = Join5DF1.filter(col("update_flag")=='Y')

RFT_TransLkpDF = RFT_Trans1DF.join(wcard_prog_del_lkpDF,on=[RFT_Trans1DF.ACCT_ID==wcard_prog_del_lkpDF.acct_id],how='left_outer').filter(wcard_prog_del_lkpDF.acct_id.isNotNull()).withColumn("temp_dt",wcard_prog_del_lkpDF.prog_acct_profile_eff_dt).select(RFT_Trans1DF["*"],"temp_dt")

RFT_TransLkpDF = RFT_TransLkpDF.withColumn("PROG_ACCT_PROFILE_END_DT",date_sub(to_date(RFT_TransLkpDF.temp_dt),1)).select("acct_id","profile_id","prog_acct_profile_eff_dt","prog_id","prog_acct_profile_end_dt","acct_profile_stat_cd","create_dttm")

#Drop update flag column:
DropUpdateFlagDF = FBEPassUpdateFlagDF.drop("update_flag")
Gather1DF = RFT_TransLkpDF.unionByName(DropUpdateFlagDF)

#FBE: filetr out profile_id 0 and Status:
FinalUpdateDF = Gather1DF.filter((col("profile_id").cast(IntegerType())!=0) & (col("acct_profile_stat_cd").isNotNull()) & ((col("acct_profile_stat_cd")=='AC') | (col("acct_profile_stat_cd")=='IA') | (col("acct_profile_stat_cd")=='DL'))) \
.withColumn("prog_acct_profile_eff_dt",to_date(col('prog_acct_profile_eff_dt'))) \
.withColumn("prog_acct_profile_end_dt",to_date(col('prog_acct_profile_end_dt'))) \
.withColumn("create_dttm",to_timestamp(col('create_dttm'))).distinct()

#Program Account Profile Update File:
print("wcard_program_account_profile_update_ascii.pipe_delim count: {}".format(FinalUpdateDF.count()))
FinalUpdateDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Wcard_Update_File+"/"+Batch_id)

# COMMAND ----------

#RFT: Create insert record for updated row:
InsertNewRowDF = FBEPassUpdateFlagDF.withColumn("prog_acct_profile_end_dt",lit("")).select("acct_id","profile_id","prog_acct_profile_eff_dt","prog_id","prog_acct_profile_end_dt","acct_profile_stat_cd","create_dttm")

#Join-5 unused-0:
Join5UnUsed0DF = RFT_TransformDF.join(RFT_Trans1DF,on=[RFT_TransformDF.acct_id==RFT_Trans1DF.ACCT_ID,RFT_TransformDF.profile_id==RFT_Trans1DF.PROFILE_ID,RFT_TransformDF.prog_id==RFT_Trans1DF.PROG_ID],how='left_anti').select("acct_id","profile_id","prog_acct_profile_eff_dt","prog_id","prog_acct_profile_end_dt","acct_profile_stat_cd","create_dttm")

#FBE:Only pass where acct_id is non blank:
FBEValidDF = Join5UnUsed0DF.filter(((trim(col("acct_id")).isNotNull()) & (col("acct_id")!='')) & ((trim(col("prog_id")).isNotNull()) & (col("prog_id")!='')) & ((col("profile_id").isNotNull()) & (trim(col("profile_id"))!='')))

WcardTandemCreateDttmLkpDF = spark.read.format("parquet").load(mountPoint+"/"+Lookup_Folder+"/"+Wcard_Tandem_dttm+"/"+Batch_id)

var_create_dttm = WcardTandemCreateDttmLkpDF.filter(WcardTandemCreateDttmLkpDF.create_dttm_key=="Create_Tandem_DTTM").select("create_dttm").collect()

if len(var_create_dttm)!=0:
  var_create_dttm = var_create_dttm[0].create_dttm
else:
  var_create_dttm = None

# COMMAND ----------

RFT_Trans1LKP_DF = RFT_Trans1DF.join(wcard_prog_del_lkpDF,on = [RFT_Trans1DF.ACCT_ID==wcard_prog_del_lkpDF.acct_id],how = 'left_outer') \
.filter(wcard_prog_del_lkpDF.acct_id.isNotNull()) \
.withColumn("TempCol",wcard_prog_del_lkpDF.prog_acct_profile_eff_dt) \
.select(RFT_Trans1DF["*"],"TempCol")

RFT_Trans1LKP_DF = RFT_Trans1LKP_DF.withColumn("prog_acct_profile_end_dt",lit("")) \
.withColumn("acct_profile_stat_cd",lit("DL")) \
.withColumn("prog_acct_profile_eff_dt",col("TempCol")) \
.withColumn("create_dttm",lit(var_create_dttm)).select("acct_id","profile_id","prog_acct_profile_eff_dt","prog_id","prog_acct_profile_end_dt","acct_profile_stat_cd","create_dttm")

GatherFinalDF = InsertNewRowDF.unionByName(FBEValidDF).unionByName(RFT_Trans1LKP_DF)

#FBE: filetr out profile_id 0 and Status-1:

GatherFinalDF1 = GatherFinalDF.filter((col("profile_id").cast(IntegerType())!=0) & (col("acct_profile_stat_cd").isNotNull()) & ((col("acct_profile_stat_cd")=='AC') | (col("acct_profile_stat_cd")=='IA') | (col("acct_profile_stat_cd")=='DL'))) \
.withColumn("prog_acct_profile_eff_dt",to_date(col('prog_acct_profile_eff_dt'))) \
.withColumn("prog_acct_profile_end_dt",to_date(col('prog_acct_profile_end_dt'))) \
.withColumn("create_dttm",to_timestamp(lit(var_create_dttm))).distinct()
GatherFinalDF1.cache()

#wcard_program_account_profile_insert_ascii.pipe_delim:
print("wcard_program_account_profile_insert_ascii.pipe_delim count: {}".format(GatherFinalDF1.count()))
GatherFinalDF1.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+Wcard_Insert_File+"/"+Batch_id)

# COMMAND ----------

#Wcard Program Acct Profile Special delete-1:
AppendDelLKPDF = wcard_prog_del_lkpDF.join(GatherFinalDF1,on=[wcard_prog_del_lkpDF.acct_id==GatherFinalDF1.acct_id,
                                                             wcard_prog_del_lkpDF.profile_id==GatherFinalDF1.profile_id,
                                                             wcard_prog_del_lkpDF.prog_id==GatherFinalDF1.prog_id],how='left_outer').filter((GatherFinalDF1.acct_id.isNull()) & (GatherFinalDF1.profile_id.isNull()) & (GatherFinalDF1.prog_id.isNull())).select(wcard_prog_del_lkpDF["*"]) \
.filter((col("profile_id").cast(IntegerType())!=0) & (col("acct_profile_stat_cd").isNotNull()) & ((col("acct_profile_stat_cd")=='AC') | (col("acct_profile_stat_cd")=='IA') | (col("acct_profile_stat_cd")=='DL'))).distinct()

#Program Account Profile Load File-1:
AppendDelLKPDF.write.format("parquet").mode("append").save(mountPoint+"/"+Staging_Folder+"/"+Wcard_Insert_File+"/"+Batch_id)

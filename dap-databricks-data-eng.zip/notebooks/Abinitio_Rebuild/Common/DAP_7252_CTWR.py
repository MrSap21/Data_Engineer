# Databricks notebook source
# Mount ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import arrays_zip
from pyspark.sql import functions as F

# Checking the response from the Ingestion Framework and selecting the folders which will be read by this job

# ingestion_framework_respoinse = spark.read.format("delta").load(mountPoint + "/" + dbutils.widgets.get("PAR_INGESTION_FRAMEWORK_OUTPUT_LOCATION")) \
#                                                           .withColumn("asset_directory", concat(lit("dbfs:/"), lit(mountPoint), lit("/"), col("assetcurrentlocation"))) \
#                                                           .withColumn("asset_full_path", concat(col("asset_directory"), lit("/"), col("assetname"))) \
#                                                           .withColumn("asset_directory", trim(regexp_replace(col("asset_directory"), "//", "/"))) \
#                                                           .withColumn("asset_full_path", trim(regexp_replace(col("asset_full_path"), "//", "/"))) \
#                                                           .select("asset_directory", "asset_full_path") \

# folders_path = ",".join(ingestion_framework_respoinse.select("asset_directory").dropDuplicates() \
#                                                              .select(collect_list("asset_directory").alias("asset_directory")) \
#                                                              .collect()[0]["asset_directory"])

#mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

filePath = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_FILE_PATH")

#filePath = "/mnt/wrangled/master_data/product/pos/cpio/2021/10/22"

# COMMAND ----------

# # Loading all XML files inside the folders indicates by the Ingestion Framework response
# spark.conf.set("spark.sql.caseSensitive","true")
# xml_parquet= mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_XML_PARQUET") + dbutils.widgets.get("PAR_PL_BATCH_ID")

# # df_sourceXML.write.format('parquet').mode('overwrite').save(xml_parquet)

# df_sourceXML = spark.read.format("com.databricks.spark.xml").option("rowTag", "Transaction").option('inferSchema','False').load(folders_path).withColumn("asset_full_path", input_file_name())

# # Filter assets based on the Ingestion Framework response
# assets_list = ingestion_framework_respoinse.select("asset_full_path").dropDuplicates()
# df_sourceXML = df_sourceXML.join(broadcast(assets_list), "asset_full_path", "inner").drop("asset_full_path")

# COMMAND ----------

spark.conf.set("spark.sql.caseSensitive","true")
 
df_sourceXML = spark.read.format("com.databricks.spark.xml").option("rowTag", "Transaction").option('inferSchema','False').load(filePath)

dbutils.widgets.text("PAR_NB_INPUT_XML_PARQUET","retail/retail_sales/staging/7252_xml_parquet")

xml_parquet= mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_XML_PARQUET") +'/'+ dbutils.widgets.get("PAR_PL_BATCH_ID")

df_sourceXML.write.format('parquet').mode('overwrite').save(xml_parquet)

# COMMAND ----------

spark.conf.set("spark.sql.caseSensitive","true")
df_source = spark.read.format('parquet').load(xml_parquet)
df_source = df_source.withColumn('TrainingModeFlag', F.lit(' '))

# COMMAND ----------

def add_missing_tags(df,columnlist):
  not_found_cols = []
  found_cols = []
  for i in columnlist:
    try:
      dummy_df = df.select(i)
      found_cols.append(i)
    except:
      not_found_cols.append(i)
  return [found_cols,not_found_cols]

# COMMAND ----------

retail_txn_schema =         StructType([StructField('_TransactionStatus',StringType(),True),
                              StructField('_Version',StringType(),True),
                              StructField('LineItem',ArrayType(StructType(
                                          [StructField('_EntryMethod',StringType(),True),
                                           StructField('_LineType',StringType(),True),
                                           StructField('_LineItemStatus',StringType(),True),
                                           StructField('_CancelFlag',StringType(),True),
                                           StructField('SequenceNumber',StringType(),True),
                                           StructField('BeginDateTime',StringType(),True),
                                           StructField('Sale',StructType(
                                                       [StructField('ActualSalesUnitPrice',StringType(),True),
                                                        StructField('SerialNumber',StringType(),True),
                                                        StructField('_ItemSubType',StringType(),True),
                                                        StructField('_ItemType',StringType(),True),
                                                        StructField('ItemID',StringType(),True),
                                                        StructField('POSIdentity',ArrayType(StructType([
                                                                     StructField('_POSIDType',StringType(),True),
                                                                     StructField('POSItemID',StringType(),True),
                                                                     ])),True),
                                                        StructField('Description',StringType(),True),
                                                        StructField('RegularSalesUnitPrice',StringType(),True),
                                                        StructField('ExtendedAmount',StringType(),True),
                                                        StructField('Quantity',StringType(),True),
                                                        StructField('SellingLocation',StringType(),True),
                                                        StructField('Tax',ArrayType(StructType([
                                                                     StructField('Amount',StringType(),True),
                                                                     StructField('Percent',StringType(),True),
                                                                     StructField('SequenceNumber',StringType(),True),
                                                                     StructField('TaxRuleID',StringType(),True),
                                                                     StructField('TaxableAmount',StringType(),True),
                                                                     StructField('_TaxStatus',StringType(),True),
                                                                     StructField('pcms:PCMSTax',StructType([
                                                                       StructField('pcms:TaxRuleName',StringType(),True)
                                                                     ]),True),
                                                        ])),True),
                                                        StructField('pcms:PCMSSale',StructType([
                                                                     StructField('pcms:ReasonCode',StringType(),True),
                                                                     StructField('pcms:ExternalReference',StringType(),True),
                                                                     StructField('pcms:SelfScanType',StringType(),True),
                                                                     StructField('pcms:Manufacturer',StringType(),True),
                                                                     StructField('pcms_ItemStatus',StringType(),True),
                                                                     StructField('pcms:DocumentReference',StringType(),True),
                                                                     StructField('pcms:Supplier',StringType(),True),
                                                                     StructField('pcms:LinkedItemLevel',StringType(),True),
                                                                     StructField('pcms:PriceDiscountable',StringType(),True),
                                                        ]),True),
                                                        StructField('RetailPriceModifier',ArrayType(StructType([
                                                                     StructField('_MethodCode',StringType(),True),
                                                                     StructField('PromotionID',StringType(),True),
                                                                     StructField('ReasonCode',StringType(),True),
                                                                     StructField('SequenceNumber',StringType(),True),
                                                                     StructField('Amount',StructType([
                                                                       StructField('_Action',StringType(),True),
                                                                       StructField('_VALUE',StringType(),True)
                                                                     ]),True),
                                                                     StructField('pcms:PCMSRetailPriceModifier',StructType([
                                                                       StructField('pcms:DetailDiscountNumber',StringType(),True),
                                                                       StructField('pcms:DiscountText',StringType(),True),
                                                                       StructField('pcms:Quantity',StringType(),True),
                                                                       StructField('pcms:CanBeRecalled',StringType(),True),
                                                                       StructField('pcms:DiscountDate',StringType(),True),
                                                                       StructField('pcms:NoTaxEffect',StringType(),True),
                                                                       StructField('pcms:PromotionCampaignName',StringType(),True),
                                                                       StructField('pcms:PromotionUserType',StringType(),True)
                                                                     ]),True),
                                                        ])),True),
                                                        StructField('ItemLink',StringType(),True),
                                                        StructField('GiftReceiptFlag',StringType(),True),
                                                        StructField('Associate',StructType([
                                                                       StructField('AssociateID',StringType(),True)
                                                                     ]),True),
                                                        StructField('MerchandiseHierarchy',StructType([
                                                                       StructField('_Level',StringType(),True),
                                                                       StructField('_VALUE',StringType(),True)
                                                                     ]),True),
                                                       ]),True),
                                           StructField('pcms:PCMSLineItem',StructType([
                                                                       StructField('pcms:ItemLink',StringType(),True),
                                                                       StructField('pcms:DetailNumber',ArrayType(StructType([
                                                                         StructField('_TxnType',StringType(),True),
                                                                         StructField('_VALUE',StringType(),True)
                                                                       ])),True)
                                                                     ]),True),
                                            StructField('pcms:PCMSRefusedSale',StructType([
                                                                       StructField('pcms:RefusalType',StringType(),True),
                                                                       StructField('pcms:ItemType',StringType(),True),
                                                                       StructField('pcms:ItemSubType',StringType(),True),
                                                                       StructField('pcms:ItemID',StringType(),True),
                                                                       StructField('wag_SerialNumber',StringType(),True),
                                                                       StructField('wag_LotNumber',StringType(),True),
                                                                       StructField('wag_ExpiredItem',StringType(),True),
                                                                       StructField('wag_GTIN',StringType(),True),
                                                                       StructField('wag_MfgDate',StringType(),True),
                                                                       StructField('wag_ExpirationDate',StringType(),True)
                                                                     ]),True),
                                            StructField('EndDateTime',StringType(),True),
                                            StructField('Tender',StructType([
                                                                       StructField('TenderID',StringType(),True),
                                                                       StructField('Cashback',StringType(),True),
                                                                       StructField('_TypeCode',StringType(),True),
                                                                       StructField('_TenderType',StringType(),True),
                                                                       StructField('Amount',StructType([
                                                                         StructField('_ForeignAmount',StringType(),True),
                                                                         StructField('_VALUE',StringType(),True),
                                                                       ]),True),
                                                                       StructField('pcms:PCMSTender',StructType([
                                                                         StructField('pcms:PANEncryptedExternal',StringType(),True),
                                                                         StructField('pcms:PANHashed',StringType(),True),
                                                                         StructField('pcms:PANToken',StringType(),True),
                                                                         StructField('pcms:TenderID',StringType(),True),
                                                                         StructField('pcms:TenderType',StringType(),True),
                                                                         StructField('pcms:EntryMethod',StringType(),True),
                                                                         StructField('pcms:MediaType',StringType(),True),
                                                                         StructField('pcms:State',StringType(),True)
                                                                       ]),True),
                                                                       StructField('Authorization',StructType([
                                                                         StructField('AuthorizationCode',StringType(),True),
                                                                         StructField('AuthorizingTermID',StringType(),True),
                                                                         StructField('MerchantNumber',StringType(),True),
                                                                         StructField('_HostAuthorized',StringType(),True),
                                                                         StructField('_AuthorizedOnline',StringType(),True),
                                                                         StructField('EMVDebug',StructType([
                                                                           StructField('ApplicationIdentifier',StringType(),True)
                                                                         ]),True),
                                                                         StructField('Reversal',StructType([
                                                                           StructField('AdjudicationCode',StringType(),True)
                                                                         ]),True),
                                                                       ]),True),
                                                                       StructField('GiftCard',StructType([
                                                                         StructField('CardNumber',StringType(),True),
                                                                         StructField('CurrentBalance',StringType(),True),
                                                                       ]),True),
                                                                       StructField('TenderChange',StructType([
                                                                         StructField('_TenderType',StringType(),True),
                                                                         StructField('TenderID',StringType(),True),
                                                                         StructField('Amount',StringType(),True),
                                                                         StructField('pcms:PCMSTender',StructType([
                                                                           StructField('pcms:PANEncryptedExternal',StringType(),True),
                                                                           StructField('pcms:PANHashed',StringType(),True),
                                                                           StructField('pcms:PANToken',StringType(),True),
                                                                           StructField('pcms:TenderID',StringType(),True),
                                                                           StructField('pcms:TenderType',StringType(),True),
                                                                           StructField('pcms:EntryMethod',StringType(),True),
                                                                           StructField('pcms:MediaType',StringType(),True),
                                                                           StructField('pcms:State',StringType(),True)
                                                                         ]),True),
                                                                         StructField('GiftCard',StructType([
                                                                           StructField('CardNumber',StringType(),True),
                                                                           StructField('CurrentBalance',StringType(),True),
                                                                         ]),True),
                                                                       ]),True),
                                                                       StructField('LoyaltyRedemption',StructType([
                                                                         StructField('PointsRedeemed',StringType(),True),
                                                                         StructField('LoyaltyProgram',StructType([
                                                                           StructField('LoyaltyAccountID',StringType(),True),
                                                                           StructField('LoyaltyProgramID',StringType(),True)
                                                                         ]),True),
                                                                       ]),True),
                                                                       StructField('CreditDebit',StructType([
                                                                         StructField('_TypeCode',StringType(),True),
                                                                         StructField('_CardType',StringType(),True),
                                                                         StructField('PrimaryAccountNumber',StringType(),True),
                                                                         StructField('ExpirationDate',StringType(),True),
                                                                         StructField('ServiceCode',StringType(),True)
                                                                       ]),True),
                                                                       StructField('Check',StructType([
                                                                         StructField('_TypeCode',StringType(),True),
                                                                         StructField('_CheckType',StringType(),True),
                                                                         StructField('BankID',StringType(),True),
                                                                         StructField('CheckNumber',StringType(),True),
                                                                         StructField('AccountNumber',StringType(),True)
                                                                       ]),True),
                                                                       StructField('Voucher',StructType([
                                                                         StructField('_TypeCode',StringType(),True),
                                                                         StructField('_VALUE',StringType(),True)
                                                                       ]),True),
                                                                       StructField('StoreAccount',StructType([
                                                                         StructField('_AccountID',StringType(),True),
                                                                         StructField('_VALUE',StringType(),True)
                                                                       ]),True),
                                                                       StructField('Coupon',StructType([
                                                                         StructField('PrimaryLabel',StringType(),True),
                                                                         StructField('_CouponType',StringType(),True)
                                                                       ]),True)
                                              ]),True),
                                             StructField('Tax',StructType([
                                                                   StructField('_NegativeValue',StringType(),True),
                                                                   StructField('TaxStatus',StringType(),True),
                                                                   StructField('TaxableAmount',StringType(),True),
                                                                   StructField('SequenceNumber',StringType(),True),
                                                                   StructField('Amount',StringType(),True),
                                                                   StructField('Percent',StringType(),True),
                                                                   StructField('TaxRuleID',StringType(),True),
                                                                   StructField('pcms:PCMSTax',StructType([
                                                                         StructField('pcms:TaxRuleName',StringType(),True),
                                                                         StructField('_CouponType',StringType(),True)
                                                                    ]),True)
                                              ]),True),
                                           StructField('OperatorBypassApproval',StructType([
                                                                         StructField('SequenceNumber',StringType(),True),
                                                                         StructField('ApproverID',StructType([
                                                                            StructField('_OperatorType',StringType(),True),
                                                                            StructField('_VALUE',StringType(),True)
                                                                         ]),True)
                                             ]),True),
                                           StructField('Return',StructType([
                                                                    StructField('_ItemSubType',StringType(),True),
                                                                    StructField('_ItemType',StringType(),True),
                                                                    StructField('ItemID',StringType(),True),
                                                                    StructField('MerchandiseHierarchy',StructType([
                                                                       StructField('_Level',StringType(),True),
                                                                       StructField('_VALUE',StringType(),True)
                                                                     ]),True),
                                                                    StructField('POSIdentity',ArrayType(StructType([
                                                                     StructField('_POSIDType',StringType(),True),
                                                                     StructField('POSItemID',StringType(),True),
                                                                     ])),True), 
                                                                     StructField('Description',StringType(),True),
                                                                     StructField('RegularSalesUnitPrice',StringType(),True),
                                                                     StructField('ActualSalesUnitPrice',StringType(),True),
                                                                     StructField('ExtendedAmount',StringType(),True),
                                                                     StructField('Quantity',StringType(),True),
                                                                     StructField('SellingLocation',StringType(),True),
                                                                     StructField('Tax',ArrayType(StructType([
                                                                         StructField('_NegativeValue',StringType(),True),
                                                                         StructField('Percent',StringType(),True),
                                                                         StructField('SequenceNumber',StringType(),True),
                                                                         StructField('TaxRuleID',StringType(),True),
                                                                         StructField('TaxableAmount',StringType(),True),
                                                                         StructField('Amount',StringType(),True),
                                                                         StructField('_TaxStatus',StringType(),True),
                                                                         StructField('pcms:PCMSTax',StructType([
                                                                           StructField('pcms:TaxRuleName',StringType(),True)
                                                                         ]),True)
                                                                     ])),True),
                                                                     StructField('pcms:PCMSReturn',StructType([
                                                                         StructField('pcms:ReasonCode',StringType(),True),
                                                                         StructField('pcms:Manufacturer',StringType(),True),
                                                                         StructField('pcms:PriceDiscountable',StringType(),True),
                                                                         StructField('pcms:Resaleable',StringType(),True)
                                                                     ]),True),
                                                                     StructField('ItemLink',StringType(),True),
                                                                     StructField('RetailPriceModifier',StructType([
                                                                         StructField('MethodCode',StringType(),True),
                                                                         StructField('SequenceNumber',StringType(),True),
                                                                         StructField('Amount',StringType(),True),
                                                                         StructField('ReasonCode',StringType(),True),
                                                                         StructField('pcms:PCMSRetailPriceModifier',StructType([
                                                                             StructField('pcms:DetailDiscountNumber',StringType(),True),
                                                                             StructField('pcms:DiscountText',StringType(),True),
                                                                             StructField('pcms:Quantity',StringType(),True),
                                                                             StructField('pcms:Resaleable',StringType(),True)
                                                                         ]),True),
                                                                         StructField('PromotionID',StringType(),True)
                                                                     ]),True),
                                             ]),True),
                                             StructField('LoyaltyReward',ArrayType(StructType([
                                                    StructField('LoyaltyID',StringType(),True),
                                                    StructField('PointsAwarded',StructType([
                                                      StructField('_Type',StringType(),True),
                                                      StructField('_VALUE',StringType(),True),
                                                      StructField('_type0',StringType(),True)
                                                    ]),True),
                                               ])),True),
                                             StructField('Reason',StringType(),True),
                                             StructField('wag:FSA',StringType(),True),
                                             StructField('wag:LoyaltyEligibilityInd',StringType(),True),
                                             StructField('wag:FoodStampEligible',StringType(),True),
                                             StructField('wag:DealQty',StringType(),True),
                                             StructField('wag:ElectronicCard',StringType(),True),
                                             StructField('wag:DealPrice',StringType(),True),
                                             StructField('wag:WCardPlanID',StringType(),True),
                                             StructField('wag:AdvertisedPriceIndicator',StringType(),True),
                                             StructField('wag:OrigRfn',StringType(),True),
                                             StructField('wag:OrigAmt',StringType(),True),
                                             StructField('wag:OrigTenderType',StringType(),True),
                                             StructField('wag:RefundStatus',StringType(),True),
                                             StructField('wag:ReceiptEntry',StringType(),True),
                                             StructField('wag:TandemStatus',StringType(),True),
                                             StructField('wag:ManagerNumber',StringType(),True),
                                             StructField('wag:RebateReceipt',StringType(),True),
                                             StructField('wag:patientPhoneNumber',StringType(),True),
                                             StructField('wag:patientId',StringType(),True),
                                             StructField('wag:patientType',StringType(),True),
                                             StructField('wag:ManagerEmployeeID',StringType(),True),
                                             StructField('wag:EwicInd',StringType(),True),
                                             StructField('pcms:PCMSCustomData',StructType([
                                                      StructField('_Name',StringType(),True),
                                                      StructField('_VALUE',StringType(),True)
                                             ]),True),
                                             StructField('pcms:PCMSCouponEndorsement',StructType([
                                                      StructField('_ItemSubType',StringType(),True),
                                                      StructField('_ItemType',StringType(),True),
                                                      StructField('pcms:SerialNumber',StringType(),True),
                                                      StructField('pcms:PCMSSale',StructType([
                                                                     StructField('pcms:ReasonCode',StringType(),True),
                                                                     StructField('pcms:ExternalReference',StringType(),True),
                                                                     StructField('pcms:SelfScanType',StringType(),True),
                                                                     StructField('pcms:Manufacturer',StringType(),True),
                                                                     StructField('pcms_ItemStatus',StringType(),True),
                                                                     StructField('pcms:DocumentReference',StringType(),True),
                                                                     StructField('pcms:Supplier',StringType(),True),
                                                                     StructField('pcms:PriceDiscountable',StringType(),True),
                                                        ]),True),
                                                        StructField('pcms:ItemID',StringType(),True),
                                                        StructField('pcms:POSIdentity',ArrayType(StructType([
                                                                     StructField('_POSIDType',StringType(),True),
                                                                     StructField('POSItemID',StringType(),True),
                                                                     ])),True),
                                                        StructField('pcms:SellingLocation',StringType(),True),
                                                        StructField('pcms:ItemLink',StringType(),True)
                                             ]),True),
                                             StructField('wag:DMCAccountNumber',StringType(),True),
                                             StructField('wag:DMCCheckNumber',StringType(),True),
                                             StructField('wag:DMCRoutingNumber',StringType(),True),
                                             StructField('wag:RejectedPrintCount',StringType(),True),
                                             StructField('wag:OrigTenderID',StringType(),True),
                                             StructField('wag:ECommOrderNumber',StringType(),True),
                                             StructField('wag:PhotoOrderDetails',StringType(),True),
                                             StructField('wag:CustomerAgeRestriction',StringType(),True),
                                             StructField('wag:DrugQuantity',StringType(),True),
                                             StructField('wag:DrugPills',StringType(),True),
                                             StructField('wag:ApprovalCode',ArrayType(StringType()),True),
                                             StructField('wag:AccountNumber',StringType(),True),
                                             StructField('wag:ActivationStatus',StringType(),True),
                                             StructField('wag:Reloadable',StringType(),True),
                                             StructField('wag:ChargeAmount',StringType(),True),
                                             StructField('wag:PlanId',StringType(),True),
                                             StructField('wag:CardType',StringType(),True),
                                             StructField('wag:ExpiryDate',StringType(),True),
                                             StructField('wag:GS1Barcode',StringType(),True),
                                             StructField('Discount',StructType([
                                               StructField('_VALUE',StringType(),True),
                                               StructField('DiscountBenefit',StringType(),True),
                                               StructField('PriceDerivationRule',StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('PriceDerivationRuleID',StringType(),True)
                                               ]),True),
                                               StructField('pcms:PCMSDiscount',StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('pcms:TriggerDetailNumber',StringType(),True)
                                               ]),True),
                                             ]),True)
                                           ]),True),
                                 True),
                                StructField('Total',ArrayType(StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('_NegativeValue',StringType(),True),
                                                 StructField('_TotalType',StringType(),True)
                                ])),True),
                                StructField('pcms:PCMSRetailTransaction',StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('pcms:ExternalSystem',StructType([
                                                   StructField('_VALUE',StringType(),True),
                                                   StructField('ProcessingType',StringType(),True),
                                                   StructField('pcms:SequenceNumber',StringType(),True)
                                                 ]),True),
                                ]),True),
                                StructField('pcms:PCMSEvent',ArrayType(StructType([
                                                 StructField('pcms:BeginDateTime',StringType(),True),
                                                 StructField('pcms:OperatorBypassApproval',StructType([
                                                     StructField('_VALUE',StringType(),True),
                                                     StructField('_ApproverID',StringType(),True),
                                                    StructField('pcms:ApproverID',StringType(),True)
                                                 ]),True),
                                                 StructField('pcms:OperatorUnLock',StringType(),True),
                                                 StructField('pcms:ApplicationEvent',StringType(),True),
                                                 StructField('pcms:PCMSProductInformation',StructType([
                                                       StructField('_ItemSubType',StringType(),True),
                                                       StructField('pcms:POSIdentity',ArrayType(StructType([
                                                           StructField('POSItemID',StringType(),True),
                                                           StructField('_POSIDType',StringType(),True),
                                                           StructField('_VALUE',StringType(),True)
                                                       ])),True),
                                                       StructField('pcms:ItemID',StringType(),True),
                                                       StructField('pcms:RegularSalesUnitPrice',StringType(),True),
                                                       StructField('pcms:Description',StringType(),True),
                                                       StructField('pcms:MerchandiseHierarchy',StructType([
                                                           StructField('_Level',StringType(),True),
                                                           StructField('_VALUE',StringType(),True),
                                                       ]),True),
                                                       StructField('pcms:ItemNotOnFileFlag',StringType(),True)
                                                 ]),True),
                                                 StructField('pcms:ItemLink',StringType(),True),
                                                 StructField('pcms:DetailNumber',StructType([
                                                           StructField('_TxnType',StringType(),True),
                                                           StructField('_VALUE',StringType(),True),
                                                 ]),True),
                                                 StructField('pcms:POSAuditFlow',StructType([
                                                           StructField('_VALUE',StringType(),True),
                                                           StructField('_namespace',StringType(),True),
                                                           StructField('_valcSubType',StringType(),True),
                                                           StructField('_valc',StringType(),True),
                                                           StructField('wag:firstName',StringType(),True),
                                                           StructField('wag:SystemOfReference',StringType(),True),
                                                           StructField('wag:PaymentType',StringType(),True),
                                                           StructField('wag:ServiceLineNumber',StringType(),True),
                                                           StructField('wag:ClaimIdNumber',StringType(),True),
                                                           StructField('wag:ItemNumberWithDescription',StringType(),True),
                                                           StructField('wag:PANEncryptedExternalCardNumber',StringType(),True),
                                                           StructField('wag:HashedCardNumber',StringType(),True),
                                                           StructField('wag:MaskedCardNumber',StringType(),True),
                                                           StructField('wag:CreditCardBlocked',StringType(),True),
                                                           StructField('wag:onlineIndicator',StringType(),True),
                                                           StructField('wag:lookupSucessful',StringType(),True),
                                                           StructField('wag:redemptionDisabled',StringType(),True),
                                                           StructField('wag:pinpadOffline',StringType(),True),
                                                           StructField('wag:idMethod',StringType(),True),
                                                           StructField('wag:zipCodeBy',StringType(),True),
                                                           StructField('wag:phoneBy',StringType(),True),
                                                           StructField('wag:lastName',StringType(),True),
                                                           StructField('wag:seqNum',StringType(),True),
                                                           StructField('wag:limitApproved',StringType(),True),
                                                           StructField('wag:limitNum',StringType(),True),
                                                           StructField('wag:cardNumber',StringType(),True),
                                                           StructField('wag:memberStatus',StringType(),True),
                                                           StructField('wag:zipCode',StringType(),True),
                                                           StructField('wag:loyaltyMbrId',StringType(),True),
                                                           StructField('wag:phone',StringType(),True),
                                                           StructField('wag:managerId',StringType(),True),
                                                           StructField('wag:employeeId',StringType(),True),
                                                           StructField('wag:verifyType',StringType(),True),
                                                           StructField('wag:providedZipCode',StringType(),True),
                                                           StructField('wag:actualZipCode',StringType(),True),
                                                           StructField('wag:success',StringType(),True),
                                                           StructField('wag:discInd',StringType(),True),
                                                           StructField('wag:ServRecRewardPtsMgrAuth',StringType(),True),
                                                           StructField('wag:BalanceRewardNumberOfpointsAwarded',StringType(),True),
                                                           StructField('wag:BalanceRewardpointsAwarded',StringType(),True),
                                                           StructField('wag:ServRecPercentangeAdjustmentMgrAuth',StringType(),True),
                                                           StructField('wag:ServRecPercentageAdjApplied',StringType(),True),
                                                           StructField('wag:ServRecGiftCardMgrAuth',StringType(),True),
                                                           StructField('wag:ServRecGiftCardActivation',StringType(),True),
                                                           StructField('wag:ManagerCashierNumber',StringType(),True),
                                                           StructField('wag:ManagerEmpID',StringType(),True),
                                                           StructField('wag:patientId',StringType(),True),
                                                           StructField('wag:languageUsed',StringType(),True),
                                                           StructField('wag:numberOfOptOutWindowDisplayed',StringType(),True),
                                                           StructField('wag:consentCaptureOutcome',StringType(),True),
                                                           StructField('wag:timetakenForConsentCapture',StringType(),True),
                                                           StructField('wag:RFN',StringType(),True),
                                                           StructField('wag:programCode',StringType(),True),
                                                           StructField('wag:PhoneNumber',StringType(),True),
                                                           StructField('wag:SaleLookupStatus',StringType(),True),
                                                           StructField('wag:MaskedPaymentCard',StringType(),True),
                                                           StructField('wag:BalanceRewardCard',StringType(),True),
                                                           StructField('wag:BalanceRewardCardNumber',StringType(),True),
                                                           StructField('wag:LastName',StringType(),True),
                                                           StructField('wag:FirstName',StringType(),True),
                                                           StructField('wag:EmailID',StringType(),True),
                                                           StructField('wag:EcommerceLookupStatus',StringType(),True),
                                                           StructField('wag:openAcctType',StringType(),True),
                                                           StructField('wag:dobBy',StringType(),True),
                                                           StructField('wag:openAcctId',StringType(),True),
                                                           StructField('wag:cardType',StringType(),True),
                                                           StructField('wag:FillNumber',StringType(),True),
                                                           StructField('wag:GovtFundIndicatorForPrimaryPlan',StringType(),True),
                                                           StructField('wag:GovtFundIndicatorForCobPlan',StringType(),True),
                                                           StructField('wag:PartialFillCode',StringType(),True),
                                                           StructField('wag:conversion30dayTo90Day',StringType(),True),
                                                           StructField('wag:PinPadFunctional',StringType(),True),
                                                           StructField('wag:EmvEnabled',StringType(),True),
                                                           StructField('wag:ScriptID',StringType(),True),
                                                           StructField('wag:Status',StringType(),True),
                                                           StructField('wag:VerificationMode',StringType(),True),
                                                           StructField('wag:NumberOfIncorrectAttempts',StringType(),True),
                                                           StructField('wag:textEnrollmentCaptureOutcome',StringType(),True),
                                                           StructField('wag:PointsRedeemed',StringType(),True),
                                                           StructField('wag:TotalPointsEarned',StringType(),True),
                                                           StructField('wag:additionalGMDCall',StringType(),True),
                                                           StructField('wag:OrderNumber',StringType(),True),
                                                           StructField('wag:Type',StringType(),True),
                                                           StructField('wag:PickupLocation',StringType(),True),
                                                           StructField('wag:LookupMethod',StringType(),True),
                                                           StructField('wag:EPPId',StringType(),True),
                                                           StructField('wag:InputMethod',StringType(),True),
                                                           StructField('wag:Data',StringType(),True),
                                                           StructField('wag:MemberId',StringType(),True),
                                                           StructField('wag:WalletCardToken',StringType(),True),
                                                           StructField('wag:Amount',StringType(),True),
                                                           StructField('wag:PaymentToken',StringType(),True),
                                                           StructField('wag:DeliveryType',StringType(),True),
                                                           StructField('wag:AuthStatus',StringType(),True),
                                                           StructField('wag:TxnId',StringType(),True),
                                                           StructField('wag:RegisterType',StringType(),True),
                                                           StructField('wag:RxNumber',StringType(),True),
                                                           StructField('wag:optInOfferedType',StringType(),True)
                                                 ]),True),
                                ])),True),
                                StructField('Customer',ArrayType(StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('_CustomerID',StringType(),True),
                                                 StructField('CustomerName',StructType([
                                                     StructField('FullName',StringType(),True),
                                                     StructField('Name',ArrayType(StructType([
                                                         StructField('_VALUE',StringType(),True),
                                                         StructField('_TypeCode',StringType(),True)
                                                         ])),True)
                                                 ]),True),
                                                 StructField('LocalRequirements',ArrayType(StructType([
                                                     StructField('_VALUE',StringType(),True),
                                                     StructField('Name',ArrayType(StructType([
                                                         StructField('_VALUE',StringType(),True),
                                                         StructField('_TypeCode',StringType(),True)
                                                         ])),True)
                                                 ])),True),
                                                 StructField('Address',ArrayType(StructType([
                                                     StructField('_VALUE',StringType(),True),
                                                     StructField('_TypeCode',StringType(),True),
                                                     StructField('AddressLine',ArrayType(StringType()),True),
                                                     StructField('PostalCode',StringType(),True)
                                                 ])),True),
                                                 StructField('Telephone',StructType([
                                                     StructField('_TypeCode',StringType(),True),
                                                     StructField('FullTelephoneNumber',StringType(),True)
                                                 ]),True),
                                                 StructField('eMail',StringType(),True),
                                                 StructField('Privacy',ArrayType(StringType()),True),
                                                 StructField('PCMSCustomer',StructType([
                                                     StructField('_VALUE',StringType(),True),
                                                     StructField('pcms:AddressID',StringType(),True),
                                                     StructField('pcms:Status',StringType(),True),
                                                     StructField('pcms:SubType',StringType(),True),
                                                     StructField('pcms:Type',StringType(),True)
                                                 ]),True),
                                                 StructField('TaxCertificate',StringType(),True)
                                ])),True),
                                StructField('LoyaltyAccount',StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('CustomerID',StringType(),True),
                                                 StructField('LoyaltyProgram',StructType([
                                                     StructField('LoyaltyAccountID',StringType(),True),
                                                     StructField('LoyaltyProgramID',StringType(),True)
                                                 ]),True)
                                ]),True),
                                StructField('Reason',StringType(),True),
                                StructField('TransactionLink',StructType([
                                                 StructField('_VALUE',StringType(),True),
                                                 StructField('_ReasonCode',StringType(),True),
                                                 StructField('RetailStoreID',StringType(),True),
                                                 StructField('WorkstationID',StringType(),True),
                                                 StructField('SequenceNumber',StringType(),True),
                                                 StructField('pcms:PCMSTransactionLink',StructType([
                                                     StructField('pcms:BusinessUnit',StructType([
                                                         StructField('UnitID',StringType(),True)
                                                     ]),True)
                                                 ]),True)
                                ]),True)
                     ])


# COMMAND ----------

# DBTITLE 1,Write POS Tracking File & Corrupt File
# Writing second output
df_TTrack = df_source.withColumn('txn_dt',when((col('BeginDateTime') == None) | (col('BeginDateTime') == ''), lit('0001-01-01')) \
                    .otherwise(substring(col('BeginDateTime'),1,10)))\
                    .withColumn('str_nbr',lpad(col('RetailStoreID'),5,'0'))\
                    .withColumn('register_nbr',lpad(col('WorkstationID'),3,''))\
                    .withColumn('txn_nbr',when(col('ReceiptNumber')>0,lpad(col('ReceiptNumber'),4,'')))\
                    .withColumn('wag_rfn',col('pcms:PCMSTransaction.wag:RFN'))\
                    .withColumn('edw_create_dttm',current_timestamp())\
                    .withColumn('edw_create_dttm',concat(substring(col('edw_create_dttm'),1,10),lit(' '), substring(col('edw_create_dttm'),12,8)))\
                    .withColumn('txn_type',lpad(col('pcms:PCMSTransaction.pcms:TransactionType'),3,'0'))\
                    .withColumn('txn_business_dt',col('BusinessDayDate'))

OutputTransactionTracking = df_TTrack.select("txn_dt",'wag_rfn',"txn_type","str_nbr","register_nbr","txn_nbr","txn_business_dt","edw_create_dttm")
#OutputTransactionTracking.show()
# Create output path 

data_pos_trans_location_output = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POS_TRANS_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
#data_pos_trans_location_output = "/mnt/wrangled/common/ecdw7252/pos_transaction_tracking"

# Write in ADLS 
OutputTransactionTracking.write.format("parquet").mode("overwrite").save(data_pos_trans_location_output) 

# Writing corrupted records to a file
if "_corrupt_record" in df_source.columns:
  CorruptDF = df_source.select("_corrupt_record").where(col('_corrupt_record').isNotNull())
  
  # Create output path 
  data_location_error_output = mountPoint + "/" + dbutils.widgets.get("PAR_NB_ERROR_OUTPUT_FILE_PATH") 
  #data_location_error_output = "/mnt/wrangled/common/ecdw7252/error_record"
  # Write in ADLS 
  CorruptDF.write.format("parquet").mode("overwrite").save(data_location_error_output) 

# COMMAND ----------

if "_corrupt_record" in df_source.columns:
  selectNonCorruptRecords_pre = df_source.where("_corrupt_record is null").drop("_corrupt_record")
  selectCorruptRecords = df_source.select("_corrupt_record").where("_corrupt_record is not null AND _corrupt_record LIKE '%TrainingModeFlag%'")
  
  # Dropping corrupted column
  #dropCorruptDF = df_source.where("_corrupt_record is null").drop("_corrupt_record")

else:
  selectNonCorruptRecords_pre = df_source
  #selectCorruptRecords = df_source
  # Dropping corrupted column
  #dropCorruptDF = df_source


# COMMAND ----------

selectNonCorruptRecords=selectNonCorruptRecords_pre.withColumn('str_nbr',lpad(col('RetailStoreID'),5,'0'))\
                    .withColumn('register_nbr',lpad(col('WorkstationID'),3,'0'))\
                    .withColumn('txn_nbr',when(col('ReceiptNumber')>0,lpad(col('ReceiptNumber'),4,'0')))\
                    .withColumn('detail_nbr',lit(999).cast(IntegerType()))\
                    .withColumn('detail_type',lit(9).cast(IntegerType()))\
                    .withColumn('record_type',lit(None).cast(StringType()))\
                    .withColumn('ej_rfn_value',lit(None).cast(StringType()))\
                    .withColumn('txn_date',date_format(to_date(substring(col('BeginDateTime'),1,10),'yyyy-MM-dd'),'yyyyMMdd')) \
                    .withColumn('txn_time',regexp_replace(substring(col('BeginDateTime'),12,6),':',''))\
                    .withColumn('txn_type',lpad(col('pcms:PCMSTransaction.pcms:TransactionType'),3,'0'))\
                    .withColumn('cashier_nbr',lpad(col('pcms:PCMSTransaction.wag:CashierNumber'),3,'0'))\
                    .withColumn('rfn',col('pcms:PCMSTransaction.wag:RFN'))\
                    .withColumn('workstation_location',col('pcms:PCMSTransaction.pcms:WorkstationLocation'))


# COMMAND ----------

selectNonCorruptRecords = selectNonCorruptRecords.withColumn('RetailTransaction',from_json(to_json(col('RetailTransaction')),retail_txn_schema))

# COMMAND ----------

selectNonCorruptRecords.cache()

# COMMAND ----------

try:
    selectNonCorruptRecords_E_pre = selectNonCorruptRecords.withColumn('reject_reason',when(col('txn_date').isNull(),concat(lit('Invalid date in BeginDateTime with value'),coalesce(col('txn_date'),lit(' '))))\
                                                                .when(length(trim(col('OperatorID')))>8,concat(lit('OperatorID cant be longer than 8 bytes. Value is '),coalesce(col('OperatorID'),lit(' '))))\
                                                                .when((col('TenderControlTransaction.wag:EmployeeID').isNotNull()) & (length(trim(col('TenderControlTransaction.wag:EmployeeID')))>11),concat(lit('TenderControlTransaction.wag:EmployeeID cant be longer than 11 bytes. Value is '),coalesce(col('TenderControlTransaction.wag:EmployeeID'),lit(' '))))\
                                                                 .when((col('RetailTransaction.LineItem.Return.ItemID').isNotNull()) & (array_contains(transform('RetailTransaction.LineItem.Return.ItemID',lambda x: length(trim(x))>14),True)),concat(lit('RetailTransaction.LineItem.Return.ItemID cant be longer than 14 bytes. Value is '),coalesce((filter('RetailTransaction.LineItem.Return.ItemID',lambda x: length(trim(x))>14))[0],lit(' '))))\
                                                                  .when((col('RetailTransaction.Customer.TaxCertificate').isNotNull()) & (array_contains(transform('RetailTransaction.Customer.TaxCertificate',lambda x: length(trim(x))>18),True)),concat(lit('RetailTransaction.Customer.TaxCertificate cant be longer than 18 bytes. Value is '),coalesce((filter('RetailTransaction.Customer.TaxCertificate',lambda x: length(trim(x))>18))[0],lit(' '))))
                                                                .otherwise(lit(None)))
except:
     selectNonCorruptRecords_E_pre = selectNonCorruptRecords.withColumn('reject_reason',when(col('txn_date').isNull(),concat(lit('Invalid date in BeginDateTime with value'),coalesce(col('txn_date'),lit(' '))))\
                                                                .when(length(trim(col('OperatorID')))>8,concat(lit('OperatorID cant be longer than 8 bytes. Value is '),coalesce(col('OperatorID'),lit(' '))))\
                                                                 .when((col('RetailTransaction.LineItem.Return.ItemID').isNotNull()) & (array_contains(transform('RetailTransaction.LineItem.Return.ItemID',lambda x: length(trim(x))>14),True)),concat(lit('RetailTransaction.LineItem.Return.ItemID cant be longer than 14 bytes. Value is '),coalesce((filter('RetailTransaction.LineItem.Return.ItemID',lambda x: length(trim(x))>14))[0],lit(' '))))\
                                                                  .when((col('RetailTransaction.Customer.TaxCertificate').isNotNull()) & (array_contains(transform('RetailTransaction.Customer.TaxCertificate',lambda x: length(trim(x))>18),True)),concat(lit('RetailTransaction.Customer.TaxCertificate cant be longer than 18 bytes. Value is '),coalesce((filter('RetailTransaction.Customer.TaxCertificate',lambda x: length(trim(x))>18))[0],lit(' '))))
                                                                .otherwise(lit(None)))

errorRecords1 = selectNonCorruptRecords_E_pre.where(col('reject_reason').isNotNull())

selectNonCorruptRecords_E = selectNonCorruptRecords_E_pre.where(~(col('reject_reason').isNotNull()))
                                                          

# COMMAND ----------

import json

def validate_RtlTxn(RtlTxnRow):
  RtlTxn = RtlTxnRow.asDict()
  bad_elements = []
  
  ################Line Item Validation##########################
  try:
    LineItem = RtlTxn['LineItem']
  except:
    LineItem = None
  
  if LineItem != None:
    goodli = []
    for li in LineItem:
      badli_flag = False
      
      ###Sale.ExtendedAmount
      if badli_flag == False:
        try:
          SaleExtAmt = li['Sale']['ExtendedAmount']
        except:
          SaleExtAmt = None
        if SaleExtAmt != None:
          if float(SaleExtAmt) >= 100000:
            badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Sale.ExtendedAmount~|^'+str(SaleExtAmt)}
            bad_elements.append(badli)
            badli_flag = True
          
      ##Return.ExtendedAmount
      if badli_flag == False:
        try:
          ReturnExtAmt = li['Return']['ExtendedAmount']
        except:
          ReturnExtAmt = None
        if ReturnExtAmt != None:
          if float(ReturnExtAmt) >= 100000:
            badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Return.ExtendedAmount~|^'+str(ReturnExtAmt)}
            bad_elements.append(badli)
            badli_flag = True       
      
      ##Sale.Quantity
      if badli_flag == False:
        try:
          SaleQty = li['Sale']['Quantity']
        except:
          SaleQty = None
        try:
          CancelFlag = li['_CancelFlag']
        except:
          CancelFlag = False
        if SaleQty != None:
          if (float(SaleQty) >= 100000) & (CancelFlag != True):
            badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Sale.Quantity~|^'+str(SaleQty)}
            bad_elements.append(badli)
            badli_flag = True          
      
      ##Sale.RegularSalesUnitPrice
      if badli_flag == False:
        try:
          SaleRegSalesPrc = li['Sale']['RegularSalesUnitPrice']
        except:
          SaleRegSalesPrc = None
        if SaleRegSalesPrc != None:
          if (float(SaleRegSalesPrc) >= 100000) & (CancelFlag != True):
            badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Sale.RegularSalesUnitPrice~|^'+str(SaleRegSalesPrc)}
            bad_elements.append(badli)
            badli_flag = True
                   
      ##Sale.SellingLocation
      if badli_flag == False:
        try:
          SellingLoc = li['Sale']['SellingLocation'] or ''
        except:
          SellingLoc = ''        
        if (len(SellingLoc.strip()) >0):
          if SellingLoc[0:1] != 'D':
            badli = {"element" : str(li.asDict()), "reason" : '107~|^LineItem.Sale.SellingLocation~|^'+str(SellingLoc)}
            bad_elements.append(badli)
            badli_flag = True
          
      ##Tender.Amount._VALUE
      if badli_flag == False:
        try:
          TenderAmtVal = li['Tender']['Amount']['_VALUE']
        except:
          TenderAmtVal = None
        if TenderAmtVal != None:
          if float(TenderAmtVal) >= 100000:
            badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Tender.Amount._VALUE~|^'+str(TenderAmtVal)}
            bad_elements.append(badli)
            badli_flag = True
          
      ###Tender.TenderChange.Amount
      if badli_flag == False:
        try:
          TenderChgAmt = li['Tender']['TenderChange']['Amount']
        except:
          TenderChgAmt = None
        if TenderChgAmt != None:
          if float(TenderChgAmt) >= 100000:
            badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Tender.TenderChange.Amount~|^'+str(TenderChgAmt)}
            bad_elements.append(badli)
            badli_flag = True
          
      ###Tender.Check.AccountNumber
      if badli_flag == False:
        try:
          TenderChkNbr = li['Tender']['Check']['CheckNumber'] or ''
        except:
          TenderChkNbr = ''
        try:
          TenderChkActNbr = li['Tender']['Check']['AccountNumber'] or ''
        except:
          TenderChkActNbr = ''
        if (TenderChkNbr != None) | (TenderChkActNbr != None):
          if len(TenderChkNbr + TenderChkActNbr) >= 31:
            badli = {"element" : str(li.asDict()), "reason" : '103~|^LineItem.Tender.Check.AccountNumber~|^'+str(TenderChkActNbr)}
            bad_elements.append(badli)
            badli_flag = True
            
      ###Return.Quantity
      if badli_flag == False:
        try:
          RtnQty = li['Return']['Quantity']
        except:
          RtnQty = None
        if RtnQty != None:
          if (float(RtnQty) >= 100000) & (CancelFlag != True):
            badli = {"element" : str(li.asDict()), "reason" : '103~|^LineItem.Return.Quantity~|^'+str(RtnQty)}
            bad_elements.append(badli)
            badli_flag = True
            
      ###Return.RegularSalesUnitPrice
      if badli_flag == False:
        try:
          RtnRegSalePrc = li['Return']['RegularSalesUnitPrice']
        except:
          RtnRegSalePrc = None
        if RtnRegSalePrc != None:
          if (float(RtnRegSalePrc) >= 100000) & (CancelFlag != True):
            badli = {"element" : str(li.asDict()), "reason" : '103~|^LineItem.Return.RegularSalesUnitPrice~|^'+str(RtnRegSalePrc)}
            bad_elements.append(badli)
            badli_flag = True
            
      ###Sale.POSIdentity
      if badli_flag == False:
        try:
          POSIdentity = li['Sale']['POSIdentity']
        except:
          POSIdentity = None
        if POSIdentity != None:
          for pi in POSIdentity:
            try:
              POSIDType = pi['_POSIDType'] or ''
            except:
              POSIDType = ''
            try:
              POSItemID = pi['POSItemID'] or ''
            except:
              POSItemID = ''
            if (POSIDType != 'OriginalBarcode') & (len(POSItemID) > 20):
              badli = {"element" : str(li.asDict()), "reason" : '110~|^LineItem.Sale.POSIdentity.POSItemID~|^'+str(POSItemID)}
              bad_elements.append(badli)
              badli_flag = True
              break
              
      ###Sale.Tax
      if badli_flag == False:
        try:
          SaleTax = li['Sale']['Tax']
        except:
          SaleTax = None
        if SaleTax != None:
          for st in SaleTax:
            try:
              SaleTaxAmt = st['Amount']
            except:
              SaleTaxAmt = None
            if SaleTaxAmt != None:
              if float(SaleTaxAmt) >= 10000:
                badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Sale.Tax.Amount~|^'+str(SaleTaxAmt)}
                bad_elements.append(badli)
                badli_flag = True
                break                
            try:
              SaleTaxPct = st['Percent']
            except:
              SaleTaxPct = None
            if SaleTaxPct != None:
              if float(SaleTaxPct) >= 100:
                badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Sale.Tax.Percent~|^'+str(SaleTaxPct)}
                bad_elements.append(badli)
                badli_flag = True
                break
                
      ###Tax
      if badli_flag == False:
        try:
          Tax = li['Tax']
        except:
          Tax = None
        if Tax != None:
          try:
            TaxAmt = Tax['Amount']
          except:
            TaxAmt = None
          if TaxAmt != None:
            if float(TaxAmt) >= 10000:
              badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Tax.Amount~|^'+str(TaxAmt)}
              bad_elements.append(badli)
              badli_flag = True
              break                
          try:
            TaxPct = Tax['Percent']
          except:
            TaxPct = None
          if TaxPct != None:
            if float(TaxPct) >= 100:
              badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Tax.Percent~|^'+str(TaxPct)}
              bad_elements.append(badli)
              badli_flag = True
              break
                
      ###Return.POSIdentity
      if badli_flag == False:
        try:
          POSIdentity = li['Return']['POSIdentity']
        except:
          POSIdentity = None
        if POSIdentity != None:
          for pi in POSIdentity:
            try:
              POSIDType = pi['_POSIDType'] or ''
            except:
              POSIDType = ''
            try:
              POSItemID = pi['POSItemID'] or ''
            except:
              POSItemID = ''
            if (POSIDType != 'OriginalBarcode') & (len(POSItemID) > 20):
              badli = {"element" : str(li.asDict()), "reason" : '110~|^LineItem.Return_POSIdentity.POSItemID~|^'+str(POSItemID)}
              bad_elements.append(badli)
              badli_flag = True
              break
              
      ###Return.Tax
      if badli_flag == False:
        try:
          ReturnTax = li['Return']['Tax']
        except:
          ReturnTax = None
        if ReturnTax != None:
          for rt in ReturnTax:
            try:
              ReturnTaxAmt = rt['Amount']
            except:
              ReturnTaxAmt = None
            if ReturnTaxAmt != None:
              if float(ReturnTaxAmt) >= 10000:
                badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Return.Tax.Amount~|^'+str(vAmt)}
                bad_elements.append(badli)
                badli_flag = True
                break                
            try:
              ReturnTaxPct = rt['Percent']
            except:
              ReturnTaxPct = None
            if ReturnTaxPct != None:
              if float(ReturnTaxPct) >= 100:
                badli = {"element" : str(li.asDict()), "reason" : '109~|^LineItem.Return.Tax.Percent~|^'+str(ReturnTaxPct)}
                bad_elements.append(badli)
                badli_flag = True
                break
                
      ###pcms:PCMSCouponEndorsement.pcms:POSIdentity
      if badli_flag == False:
        try:
          POSIdentity = li['pcms:PCMSCouponEndorsement']['pcms:POSIdentity']
        except:
          POSIdentity = None
        if POSIdentity != None:
          for pi in POSIdentity:
            try:
              POSIDType = pi['_POSIDType'] or ''
            except:
              POSIDType = ''
            try:
              POSItemID = pi['POSItemID'] or ''
            except:
              POSItemID = ''
            if (POSIDType != 'OriginalBarcode') & (len(POSItemID) > 20):
              badli = {"element" : str(li.asDict()), "reason" : '110~|^LineItem_pcms:PCMSCouponEndorsement_pcms:POSIdentity.POSItemID~|^'+str(POSItemID)}
              bad_elements.append(badli)
              badli_flag = True
              break
                
      ###LI passed all validations                    
      if badli_flag == False:
        goodli.append(li) 
      ####end of li loop  
    RtlTxn['LineItem'] = goodli
    
  ################Total Validation##########################
  try:
    Total = RtlTxn['Total']
  except:
    Total = None
  
  if Total != None:
    goodTotal = []
    for t in Total:
      badt_flag = False
      
      ###Total._VALUE
      if badt_flag == False:
        try:
          TotalVal = t['_VALUE']
        except:
          TotalVal = None
        if TotalVal != None:
          if float(TotalVal) >= 100000:
            badt = {"element" : str(t.asDict()), "reason" : '109~|^Total._VALUE~|^'+str(TotalVal)}
            bad_elements.append(badt)
            badt_flag = True
        
      if badt_flag == False:
        goodTotal.append(t) 
    ###end of total loop
    RtlTxn['Total'] = goodTotal
    
  ################pcms:PCMSEvent Validation##########################
  try:
    PCMSEvent = RtlTxn['pcms:PCMSEvent']
  except:
    PCMSEvent = None
  
  if PCMSEvent != None:
    goodPCMSEvent = []
    for pe in PCMSEvent:
      badpe_flag = False
      
      ###pcms:PCMSProductInformation.pcms:POSIdentity
      if badpe_flag == False:
        try:
          POSIdentity = pe['pcms:PCMSProductInformation']['pcms:POSIdentity']
        except:
          POSIdentity = None
        if POSIdentity != None:
          for pi in POSIdentity:
            try:
              POSIDType = pi['_POSIDType'] or ''
            except:
              POSIDType = ''
            try:
              POSItemID = pi['POSItemID'] or ''
            except:
              POSItemID = ''
            if (POSIDType != 'OriginalBarcode') & (len(POSItemID) > 20):
              badpe = {"element" : str(pe.asDict()), "reason" : '110~|^pcmsEvents.pcms:PCMSProductInformation.pcms:POSIdentity.POSItemID~|^'+str(POSItemID)}
              bad_elements.append(badpe)
              badpe_flag = True
              break
              
      if badpe_flag == False:
        try:
          EventRegSaleUnitPrc = pe['pcms:PCMSProductInformation']['pcms:RegularSalesUnitPrice']
        except:
          EventRegSaleUnitPrc = None
        if EventRegSaleUnitPrc != None:
          if float(EventRegSaleUnitPrc) > 10000:
            badpe = {"element" : str(pe.asDict()), "reason" : '110~|^pcmsEvents.pcms:PCMSProductInformation.pcms:RegularSalesUnitPrice~|^'+str(EventRegSaleUnitPrc)}
            bad_elements.append(badpe)
            badpe_flag = True
            break
        
      if badpe_flag == False:
        goodPCMSEvent.append(pe) 
    ###end of pcmsEvent loop
    RtlTxn['pcms:PCMSEvent'] = goodPCMSEvent
    
  out = {'rtl' : RtlTxn, 'bad_elements' : bad_elements}
  return(out)

return_schema = StructType([StructField("rtl",retail_txn_schema,True)
                            ,StructField('bad_elements',ArrayType(StructType([StructField('element',StringType(),True),
                                                                             StructField('reason',StringType(),True)]))
                                         ,True)])
udf_vrtl = udf(validate_RtlTxn,return_schema)
#udf_vrtl = udf(validate_RtlTxn,StringType())

df_validated_pre = selectNonCorruptRecords_E.where(col('RetailTransaction._Version').isNotNull())

selectNonCorruptRecords_EV = selectNonCorruptRecords_E.where(~(col('RetailTransaction._Version').isNotNull()))

df_validated = df_validated_pre.withColumn('t1',udf_vrtl(col('RetailTransaction'))).withColumn('reject_reason',when((col('t1.bad_elements.reason')[0]).isNotNull(),col('t1.bad_elements.reason')[0]).otherwise(lit(None))).drop(col('t1'))\

errorRecords2 = df_validated.where(col('reject_reason').isNotNull())

df_validated_post = df_validated.where(~(col('reject_reason').isNotNull()))

# COMMAND ----------

errorRecords = errorRecords1.unionByName(errorRecords2).withColumnRenamed('reject_reason','rep_vald')
reject_cols =['pcms:PCMSTransaction.wag:RFN','BusinessDayDate','BeginDateTime','pcms:PCMSTransaction.pcms:TransactionType','rep_vald']
df_rejects2 = errorRecords.select(*reject_cols)

# COMMAND ----------

pos_transaction_tracking_invalid_reject = df_rejects2.withColumn('split_rep_vald',split(col('rep_vald'),'\~\|\^'))\
                    .withColumn('reject_reason_cd',when(length(col('split_rep_vald')[0]) == 3, col('split_rep_vald')[0])\
                               .when(length(col('split_rep_vald')[0]) == 1, lit('111'))\
                               .otherwise(lit(None).cast(StringType())))\
                    .withColumn('reject_fld_name',when(length(col('split_rep_vald')[0]) == 3, col('split_rep_vald')[1])\
                               .otherwise(lit(None).cast(StringType())))\
                    .withColumn('reject_fld_val',when(length(col('split_rep_vald')[0]) == 3, col('split_rep_vald')[2])\
                               .when(length(col('split_rep_vald')[0]) == 1, col('split_rep_vald')[0])\
                               .otherwise(lit(None).cast(StringType())))\
                    .withColumn('txn_dt',when((col('BeginDateTime') == None) | (col('BeginDateTime') == ''), lit('0001-01-01'))\
                    .otherwise(substring(col('BeginDateTime'),1,10)))\
                    .select((substring(col('wag:RFN'),1,10)).alias('str_nbr'),
                           (substring(col('wag:RFN'),6,2)).alias('register_nbr'),
                           (substring(col('wag:RFN'),8,4)).alias('txn_nbr'),
                           col('wag:RFN').alias('wag_rfn'),
                           current_timestamp().alias('edw_create_dttm'),
                           (lpad(col('pcms:TransactionType'),2,'0')).alias('txn_type'),
                           col('BusinessDayDate').alias('txn_business_dt'),
                           col('reject_reason_cd'),
                           col('reject_fld_name'),
                           col('reject_fld_val'))

#dbutils.widgets.text("PAR_NB_TRANSACTION_INVALID_FILE_PATH",'retail/retail_sales/Puspak/7252/reject/transaction_invalid')
transaction_invalid = mountPoint + "/" + dbutils.widgets.get("PAR_NB_TRANSACTION_INVALID_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

pos_transaction_tracking_invalid_reject.write.format("parquet").mode("overwrite").save(transaction_invalid)


#dbutils.widgets.text("PAR_NB_INVALID_LEADER_FILE_PATH",'retail/retail_sales/Puspak/7252/reject/invalid_leader')
invalid_leader = mountPoint + "/" + dbutils.widgets.get("PAR_NB_INVALID_LEADER_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
                    
errorRecords.write.format("parquet").mode("overwrite").save(invalid_leader)

# COMMAND ----------

selectNonCorruptRecords_Post_Validated = selectNonCorruptRecords_EV.unionByName(df_validated_post)

from pyspark.sql.window import Window
wspec = Window.partitionBy(col('str_nbr')).orderBy(col('txn_date'))
selectNonCorruptRecords_Post_Validated = selectNonCorruptRecords_Post_Validated.withColumn('record_nbr',row_number().over(wspec))

#selectNonCorruptRecords_Post_Validated.count()

# COMMAND ----------

# DBTITLE 1,POS LOG RETAIL TXN FILE(1st flow of abinitio)
RetailTransactionValid = selectNonCorruptRecords_Post_Validated.where(col('RetailTransaction._Version').isNotNull()).withColumn('pcms_BuildNumber',col('pcms:PCMSTransaction.pcms:BuildNumber'))\
                    .withColumn('Transaction',struct(col('TrainingModeFlag'),(lpad(col('RetailStoreID'),5,'0')).alias('RetailStoreID')\
                                                     ,(lpad(col('WorkstationID'),3,'')).alias('WorkstationID'),col('SequenceNumber')\
                                                     ,col('EndDateTime'),col('BeginDateTime'),col('BusinessDayDate')\
                                                    ,col('OperatorID'),col('ReceiptNumber')))

PosLogRetailTxnColumns = ['record_nbr','detail_nbr','detail_type','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','record_type','workstation_location','rfn','pcms_BuildNumber','TrainingModeFlag','SequenceNumber','EndDateTime','BeginDateTime','OperatorID','ReceiptNumber','WorkstationID','RetailTransaction','pcms:PCMSTransaction']

PosLogFile = RetailTransactionValid.select(*PosLogRetailTxnColumns)

#dbutils.widgets.text("PAR_NB_RETAIL_TRAN_OUTPUT_FILE_PATH",'retail/retail_sales/Puspak/7252/poslog_RetailTransaction')
pslog_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_RETAIL_TRAN_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

#PosLogFile.select(col('txn_type')).distinct().display()
# Write in ADLS 
PosLogFile.write.format("parquet").mode("overwrite").save(pslog_loc) 

# COMMAND ----------

# DBTITLE 1,POS POST FILES(2nd flow of abinitio)
PostVoidedRejectionColumns = ['record_nbr','detail_nbr','detail_type','ej_rfn_value','str_nbr','txn_date','txn_time','cashier_nbr','register_nbr','txn_type','txn_nbr','record_type','workstation_location','rfn','Transaction','RetailTransaction','pcms:PCMSTransaction','ControlTransaction','TenderControlTransaction']

df_Good_Retail = RetailTransactionValid.where((trim(col('RetailTransaction.TransactionLink._ReasonCode')) == 'Voided') &  (trim(col('RetailTransaction._TransactionStatus')) == 'PostVoided'))

###################WRITE pos_post_void_rejects file#############################################
df_pos_post_void_rejects = RetailTransactionValid.where(~((trim(col('RetailTransaction.TransactionLink._ReasonCode')) == 'Voided') &  (trim(col('RetailTransaction._TransactionStatus')) == 'PostVoided'))).select(*PostVoidedRejectionColumns).dropDuplicates()

#dbutils.widgets.text("PAR_NB_POS_POST_RJCT",'retail/retail_sales/Puspak/7252/pos_post_void_rejects')
PosPostRJCT_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POS_POST_RJCT") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
# Write in ADLS 
df_pos_post_void_rejects.write.format("parquet").mode("overwrite").save(PosPostRJCT_loc) 
################################################################################################



###################WRITE pos_post_void_w_orig_rfns file#############################################
df_pos_post_void_w_orig_rfns = df_Good_Retail.select((col('RetailTransaction.pcms:PCMSEvent.pcms:POSAuditFlow.wag:RFN')).alias('arr_wagRFN'),\
                                                    (col('pcms:PCMSTransaction.wag:RFN').alias('post_void_rfn')))\
        .withColumn('arr_len',size(col('arr_wagRFN')))\
        .withColumn('orig_rfn',when((col('post_void_rfn').isNull()) & (array_contains(col('arr_wagRFN'),(lit(None)).cast(StringType()))),lit(None))\
                   .otherwise(expr("""arr_wagRFN[size(arr_wagRFN) - 1]""")))\
       .select((lpad(col('orig_rfn'),20,"0")).alias('orig_rfn')\
                                                      ,(lpad(col('post_void_rfn'),20,"0")).alias('post_void_rfn'))

#dbutils.widgets.text("PAR_NB_POS_POST_RFNS",'retail/retail_sales/Puspak/7252/pos_post_w_orig_rfn')
PosPostRFNS_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_POS_POST_RFNS") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")

df_pos_post_void_w_orig_rfns.write.format("parquet").mode("overwrite").save(PosPostRFNS_loc)
#####################################################################################################


# COMMAND ----------

# DBTITLE 1,Write Loyalty Files(3rd abinitio flow)
#Write Deduplicated file
LoyaltyInputFile = RetailTransactionValid.select(*PostVoidedRejectionColumns).dropDuplicates(['rfn'])
#dbutils.widgets.text("PAR_NB_LOYALTY_INPUT",'retail/retail_sales/Puspak/7252/LoyaltyInput')
LoyaltyInput_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_LOYALTY_INPUT") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
LoyaltyInputFile.write.format("parquet").mode("overwrite").save(LoyaltyInput_loc)

#Write duplicate records
LoyaltyInput = spark.read.format('parquet').load(LoyaltyInput_loc)
loyalty_event_dups = RetailTransactionValid.select(*PostVoidedRejectionColumns).subtract(LoyaltyInput)
loyalty_event_dups=loyalty_event_dups.drop('ej_rfn_value')
#dbutils.widgets.text("PAR_NB_loyalty_event_dups",'retail/retail_sales/Puspak/7252/Loyalty_dups')
LoyaltyDups_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_loyalty_event_dups") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
loyalty_event_dups.write.format("parquet").mode("overwrite").save(LoyaltyDups_loc)

# COMMAND ----------

selectNonCorruptRecords_non_retail = selectNonCorruptRecords_Post_Validated.where(~(col('RetailTransaction._Version').isNotNull()))\
.withColumn('Action',col('ControlTransaction.TillMovement._Action'))
#selectNonCorruptRecords_non_retail.count() 3063409

# COMMAND ----------

# DBTITLE 1,Control Transaction File Write
ControlColumns=["record_nbr","detail_nbr","detail_type","ej_rfn_value","str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","record_type","workstation_location","rfn","SequenceNumber","EndDateTime","BeginDateTime","OperatorID","ReceiptNumber","WorkstationID","pcms:PCMSTransaction.pcms:TransactionType","pcms:PCMSTransaction.pcms:WorkstationLocation","pcms:PCMSTransaction.wag:CashierNumber","pcms:PCMSTransaction.wag:RFN","pcms:PCMSTransaction.pcms:OperatorBypassApproval.ApproverID","pcms:PCMSTransaction.pcms:OperatorBypassApproval.pcms:ApprovalDateTime","pcms:PCMSTransaction.pcms:OperatorBypassApproval.pcms:ApprovalID","pcms:PCMSTransaction.pcms:ExternalSystem.ProcessingType","pcms:PCMSTransaction.pcms:ExternalSystem.pcms:SequenceNumber","pcms:PCMSTransaction.pcms:SourceSystem","pcms:PCMSTransaction.wag:CashierEmployeeID","pcms:PCMSTransaction.wag:ManagerEmployeeID","pcms:PCMSTransaction.wag:ManagerNumber","pcms:PCMSTransaction.pcms:OnlineStatus","ControlTransaction.POSStartup","ControlTransaction.OperatorSignOn.StartDateTimestamp","ControlTransaction.OperatorSignOff.EndDateTimestamp","ControlTransaction.ReasonCode","ControlTransaction.NoSale","ControlTransaction.POSShutdown","Action","ControlTransaction.POSEOD","ControlTransaction.SetCashierMode"] 
 
dfControl=selectNonCorruptRecords_non_retail.filter(col('ControlTransaction._Version').isNotNull()).select("record_nbr","detail_nbr","detail_type","ej_rfn_value","str_nbr","txn_date","txn_time","cashier_nbr",
                "register_nbr","txn_type","txn_nbr","record_type","workstation_location","rfn","SequenceNumber","EndDateTime", "BeginDateTime","OperatorID","ReceiptNumber","WorkstationID","ControlTransaction","pcms:PCMSTransaction","Action")

Found_NotFound = add_missing_tags(dfControl,ControlColumns)
Control_Final = dfControl.select(*Found_NotFound[0])
for c in Found_NotFound[1]:
  Control_Final = Control_Final.withColumn(c.replace('.','_'),lit(None).cast(StringType()))
#display(Control_Final)

#dbutils.widgets.text("PAR_NB_CONTROL_TRANS_OUTPUT_FILE_PATH",'retail/retail_sales/Puspak/7252/POSLog_Control_Transaction')
control_transaction = mountPoint + "/" + dbutils.widgets.get("PAR_NB_CONTROL_TRANS_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
#data_pos_control_trans_output = "/mnt/wrangled/common/ecdw7252/pos_transaction_tracking"
print("Writing Control Transaction File")
# # Write in ADLS 
Control_Final.write.format("parquet").mode("overwrite").save(control_transaction) 
print("Completed writing Control Transaction File")


# COMMAND ----------

selectNonCorruptRecords_non_control = selectNonCorruptRecords_non_retail.where(~(col('ControlTransaction._Version').isNotNull()))
#selectNonCorruptRecords_non_control.count() 103440

# COMMAND ----------

# DBTITLE 1,TenderControlTransaction File Write
TCColumns=["record_nbr","detail_nbr","detail_type","ej_rfn_value","str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","record_type","workstation_location","rfn","SequenceNumber","EndDateTime","BeginDateTime","OperatorID","ReceiptNumber","WorkstationID","pcms:PCMSTransaction.pcms:TransactionType","pcms:PCMSTransaction.pcms:WorkstationLocation","pcms:PCMSTransaction.wag:CashierNumber","pcms:PCMSTransaction.wag:RFN","pcms:PCMSTransaction.OperatorBypassApproval.ApproverID","pcms:PCMSTransaction.OperatorBypassApproval.pcms:ApprovalDateTime","pcms:PCMSTransaction.OperatorBypassApproval.pcms:ApproverID","pcms:PCMSTransaction.ExternalSystem.ProcessingType","pcms:PCMSTransaction.pcms:ExternalSystem.pcms:SequenceNumber","pcms:PCMSTransaction.pcms:SourceSystem","pcms:PCMSTransaction.wag:CashierEmployeeID","pcms:PCMSTransaction.wag:ManagerEmployeeID","pcms:PCMSTransaction.wag:ManagerNumber","pcms:PCMSTransaction.pcms:OnlineStatus","pcms:PCMSTransaction.pcms:CashSessionID","TenderControlTransaction.TenderPickup._TenderType","TenderControlTransaction.TenderPickup.SafeID","TenderControlTransaction.TenderPickup.Totals.Amount","TenderControlTransaction.TenderPickup.Totals.Amount.ForeignAmount","TenderControlTransaction.TenderPickup.Totals.Amount.Action","TenderControlTransaction.TenderPickup.ReasonCode","TenderControlTransaction.TenderLoan._TenderType","TenderControlTransaction.TenderLoan.Amount.ForeignAmount","TenderControlTransaction.TenderLoan.Amount.Action","TenderControlTransaction.TenderLoan.SafeID","TenderControlTransaction.TenderLoan.Amount","TenderControlTransaction.TenderLoan.Totals.Amount","TenderControlTransaction.TenderLoan.Totals.Amount.ForeignAmount","TenderControlTransaction.TenderLoan.Totals.Amount.Action","TenderControlTransaction.TenderLoan.ReasonCode","TenderControlTransaction.PaidOut.Amount","TenderControlTransaction.PaidOut.Reason","TenderControlTransaction.wag:EmployeeName","TenderControlTransaction.wag:EmployeeID","TenderControlTransaction.wag:EmployeeSSN","TenderControlTransaction.PaidIn.Amount","TenderControlTransaction.PaidIn.Reason","TenderControlTransaction.wag:ReasonDescription","TenderControlTransaction.wag:SKU","TenderControlTransaction.wag:MerchandiseHierarchy","TenderControlTransaction.pcms:PCMSSpotCheck","TenderControlTransaction.wag:TenderCountTotalAmount","TenderControlTransaction.Withdrawal.Amount","TenderControlTransaction.Withdrawal.Amount.ForeignAmount","TenderControlTransaction.Withdrawal.Amount.Action","TenderControlTransaction.Withdrawal.Check.TypeCode","TenderControlTransaction.Withdrawal.Check.BankID","TenderControlTransaction.Withdrawal.Check.CheckNumber","TenderControlTransaction.Withdrawal.Check.AccountNumber","TenderControlTransaction.pcms:PCMSTender.pcms:MediaType","TenderControlTransaction.pcms:PCMSTender.pcms:State","TenderControlTransaction.pcms:PCMSTender.pcms:PANEncryptedExternal","TenderControlTransaction.pcms:PCMSTender.pcms:PANHashed","TenderControlTransaction.pcms:PCMSTender.pcms:TenderID","TenderControlTransaction.pcms:PCMSTender.pcms:TenderType","TenderControlTransaction.pcms:PCMSTender.pcms:EntryMethod","TenderControlTransaction.StoredValueTransaction.Action","TenderControlTransaction.StoredValueTransaction.StoredValueFund.ItemID","TenderControlTransaction.StoredValueTransaction.StoredValueFund.ExtendedAmount.ForeignAmount","TenderControlTransaction.StoredValueTransaction.StoredValueFund.Instrument.TypeCode","TenderControlTransaction.StoredValueTransaction.StoredValueFund.Instrument.SerialNumber","TenderControlTransaction.StoredValueTransaction.StoredValueFund.Instrument.UnspentAmount","TenderControlTransaction.StoredValueTransaction.Tender.TypeCode","TenderControlTransaction.StoredValueTransaction.Tender._TenderType","TenderControlTransaction.StoredValueTransaction.Tender.TenderID","TenderControlTransaction.StoredValueTransaction.Tender.Amount.ForeignAmount","TenderControlTransaction.StoredValueTransaction.Tender.Amount.Action","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:MediaType","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:State","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:PANEncryptedExternal","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:PANHashed","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:TenderID","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:TenderType","TenderControlTransaction.StoredValueTransaction.Tender.pcms:PCMSTender.pcms:EntryMethod","TenderControlTransaction.StoredValueTransaction.Tender.Authorization.HostAuthorized","TenderControlTransaction.StoredValueTransaction.Tender.Authorization.pcms:AuthorizedOnline","TenderControlTransaction.StoredValueTransaction.Tender.Authorization.AuthorizationCode","TenderControlTransaction.StoredValueTransaction.Tender.Authorization.AuthorizingTermID","TenderControlTransaction.StoredValueTransaction.Tender.Authorization.MerchantNumber","TenderControlTransaction.StoredValueTransaction.Tender.Authorization.Reversal.AdjudicationCode","TenderControlTransaction.StoredValueTransaction.Tender.GiftCard.CardNumber","TenderControlTransaction.StoredValueTransaction.Tender.GiftCard.CurrentBalance","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange._TenderType","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.TenderID","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.Amount","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.Amount.ForeignAmount","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.Amount.Action","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:MediaType","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:State","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:PANEncryptedExternal","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:PANHashed","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:TenderID","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:TenderType","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.pcms:PCMSTender.pcms:EntryMethod","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.GiftCard.CardNumber","TenderControlTransaction.StoredValueTransaction.Tender.TenderChange.GiftCard.CurrentBalance","TenderControlTransaction.StoredValueTransaction.Tender.LoyaltyRedemption.PointsRedeemed","TenderControlTransaction.StoredValueTransaction.Tender.LoyaltyRedemption.LoyaltyProgram.LoyaltyAccountID","TenderControlTransaction.StoredValueTransaction.Tender.LoyaltyRedemption.LoyaltyProgram.LoyaltyProgramID","TenderControlTransaction.StoredValueTransaction.Tender.ReasonCode","TenderControlTransaction.StoredValueTransaction.Tender.CreditDebit.TypeCode","TenderControlTransaction.StoredValueTransaction.Tender.CreditDebit.CardType","TenderControlTransaction.StoredValueTransaction.Tender.CreditDebit.PrimaryAccountNumber","TenderControlTransaction.StoredValueTransaction.Tender.CreditDebit.ExpirationDate","TenderControlTransaction.StoredValueTransaction.Tender.CreditDebit.ServiceCode","TenderControlTransaction.StoredValueTransaction.Tender.Check.TypeCode","TenderControlTransaction.StoredValueTransaction.Tender.Check.BankID","TenderControlTransaction.StoredValueTransaction.Tender.Check.CheckNumber","TenderControlTransaction.StoredValueTransaction.Tender.Check.AccountNumber","TenderControlTransaction.StoredValueTransaction.Tender.Voucher","TenderControlTransaction.StoredValueTransaction.Tender.Voucher.TypeCode","TenderControlTransaction.StoredValueTransaction.Tender.StoreAccount.AccountID","TenderControlTransaction.StoredValueTransaction.Tender.Coupon.CouponType","TenderControlTransaction.StoredValueTransaction.Tender.Coupon.PrimaryLabel","TenderControlTransaction.StoredValueTransaction.Tender.Cashback","TenderControlTransaction.PCMSSession","TenderControlTransaction.PCMSSession.pcms:WorkstationID","TenderControlTransaction.PCMSSession.pcms:OperatorID","TenderControlTransaction.PCMSSession.pcms:SequenceNumber","TenderControlTransaction.PCMSSession.pcms:StartDateTime","TenderControlTransaction.PCMSSession.pcms:LastSequenceNumber","TenderControlTransaction.PCMSSession.pcms:Event","TenderControlTransaction.PCMSSession.pcms:Event.pcms:SequenceNumber","TenderControlTransaction.PCMSSession.pcms:Event.pcms:EndDateTime","TenderControlTransaction.PCMSSession.pcms:Event.pcms:OperatorID","TenderControlTransaction.PCMSSession.pcms:Event.pcms:Reference","TenderControlTransaction.PCMSSession.pcms:Event.pcms:Media","TenderControlTransaction.PCMSSession.pcms:Event.pcms:Media._NegativeValue","TenderControlTransaction.PCMSSession.pcms:Event.pcms:Media.pcms:MediaNumber","TenderControlTransaction.PCMSSession.pcms:Event.pcms:Media.pcms:Quantity","TenderControlTransaction.PCMSSession.pcms:Event.pcms:Media.pcms:Amount"]

dfTC=selectNonCorruptRecords_non_control.filter((col('TenderControlTransaction._Version').isNotNull()))\
.select("record_nbr","detail_nbr","detail_type","str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","record_type","workstation_location","rfn","RetailStoreID","WorkstationID","SequenceNumber","EndDateTime","BeginDateTime","BusinessDayDate","OperatorID","ReceiptNumber","pcms:PCMSTransaction","TenderControlTransaction")

ColsAnalysis = add_missing_tags(dfTC,TCColumns)
for c in ColsAnalysis[0]:
   dfTC = dfTC.withColumn(c.replace('.','_'),col(c))
for c in ColsAnalysis[1]:
   dfTC = dfTC.withColumn(c.replace('.','_'),lit(None).cast(StringType()))
  
TCColumnsRenamed = [x.replace('.','_') for x in TCColumns]
dfTCFinal = dfTC.select(*TCColumnsRenamed)
#display(dfTCFinal)
print("Dropping Duplicates")
dfTCFinal=dfTCFinal.dropDuplicates()
#dbutils.widgets.text("PAR_NB_TCONTROL_TRANS_OUTPUT_FILE_PATH",'retail/retail_sales/Puspak/7252/POSLog_TenderControlTransaction')
#dbutils.widgets.text("PAR_NB_OTHER_TRANS_OUTPUT_FILE_PATH",'retail/retail_sales/Puspak/7252/POSLog_OtherTransaction')
other_transaction = mountPoint + "/" + dbutils.widgets.get("PAR_NB_OTHER_TRANS_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
tc_transaction = mountPoint + "/" + dbutils.widgets.get("PAR_NB_TCONTROL_TRANS_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")


df_deselect=selectNonCorruptRecords_non_control.where(~(col('TenderControlTransaction._Version').isNotNull()))

#print(df_deselect.count())

print("dfTCFinal write started")
# Write in ADLS 
dfTCFinal.write.format("parquet").mode("overwrite").save(tc_transaction) 
print("dfTCFinal write completed")
print("df_deselect write started")
df_deselect.write.format("parquet").mode("overwrite").save(other_transaction) 
print("df_deselect write completed")


# COMMAND ----------

# DBTITLE 1,WorkStation Location File Write
WSColumns =["record_nbr","detail_nbr","detail_type","str_nbr","txn_date","txn_time","cashier_nbr","register_nbr","txn_type","txn_nbr","record_type","workstation_location","rfn","value","TrainingModeFlag","RetailStoreID","WorkstationID","SequenceNumber","EndDateTime","BeginDateTime","OperatorID","ReceiptNumber","pcms:PCMSTransaction.pcms:TransactionType","pcms:PCMSTransaction.pcms:WorkstationLocation","pcms:PCMSTransaction.wag:CashierNumber","pcms:PCMSTransaction.wag:RFN","pcms:PCMSTransaction.pcms:OperatorBypassApproval.ApproverID","pcms:PCMSTransaction.pcms:OperatorBypassApproval.pcms:ApprovalID","pcms:PCMSTransaction.pcms:OperatorBypassApproval.pcms:ApprovalDateTime","pcms:PCMSTransaction.pcms:ExternalSystem.ProcessingType","pcms:PCMSTransaction.pcms:ExternalSystem.pcms:SequenceNumber","pcms:PCMSTransaction.pcms:SourceSystem","pcms:PCMSTransaction.wag:CashierEmployeeID","pcms:PCMSTransaction.wag:ManagerEmployeeID","pcms:PCMSTransaction.wag:ManagerNumber","pcms:PCMSTransaction.pcms:OnlineStatus"] 

dfWS=selectNonCorruptRecords_Post_Validated.filter(length(trim(col('pcms:PCMSTransaction.pcms:WorkstationLocation')))>0)\
                      .select("record_nbr","detail_nbr","detail_type","str_nbr","txn_date","txn_time", "cashier_nbr","register_nbr","txn_type","txn_nbr","record_type","workstation_location","rfn","TrainingModeFlag","RetailStoreID","WorkstationID","EndDateTime","BeginDateTime","OperatorID","ReceiptNumber","pcms:PCMSTransaction")
                           
Found_NotFound = add_missing_tags(dfWS,WSColumns)
WS_Final = dfWS.select(*Found_NotFound[0])
for c in Found_NotFound[1]:
   WS_Final = WS_Final.withColumn(c.replace('.','_'),lit(None).cast(StringType()))
    
print("Dropping Duplicates")
WS_Final=WS_Final.dropDuplicates()
#display(dfWS)
#print(dfWS.count())
#dbutils.widgets.text("PAR_NB_WS_LOC_OUTPUT_FILE_PATH",'retail/retail_sales/Puspak/7252/POSLog_WorkstationLocation')
ws_loc = mountPoint + "/" + dbutils.widgets.get("PAR_NB_WS_LOC_OUTPUT_FILE_PATH") + "/" + dbutils.widgets.get("PAR_PL_BATCH_ID")
#data_pos_control_trans_output = "/mnt/wrangled/common/ecdw7252/pos_transaction_tracking"
print("WS_Final write started")
# # Write in ADLS 
WS_Final.write.format("parquet").mode("overwrite").save(ws_loc) 
print("dfWS write completed")

# COMMAND ----------

selectNonCorruptRecords.unpersist()
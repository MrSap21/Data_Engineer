# Databricks notebook source
staging_folder = dbutils.widgets.get('PAR_PL_STAGING_FOLDER')
input_folder = dbutils.widgets.get('PAR_PL_INPUT_FOLDER')
lookup_folder = dbutils.widgets.get('PAR_PL_LOOKUP_FOLDER')
input_file=dbutils.widgets.get('PAR_PL_INPUT_FILE')
batch_id=dbutils.widgets.get('PAR_PL_BATCH_ID')

# COMMAND ----------

import os
import json

# Mounting ADLS
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
os.environ['mountPoint']=mountPoint
os.environ['Script_Path']="/dbfs" + mountPoint + "/common/dap7101s"
os.environ['mountPoint']=mountPoint
os.environ['AI_FTP']="/dbfs" + mountPoint + '/' + input_folder
os.environ['AI_RECYCLE']=os.environ['AI_LOAD']=os.environ['AI_PERSIST_SERIAL']=os.environ['AI_INBOUND']=os.environ['AI_ACCESSIBLE']="/dbfs" + mountPoint + '/' + staging_folder
os.environ['AI_LOOKUP']="/dbfs" + mountPoint + '/' + lookup_folder
os.environ['INPUT_FILE']=input_file
os.environ['BATCH_ID']=batch_id

# COMMAND ----------

# MAGIC %sh 
# MAGIC JOB_NAME='dap7101s_chk_ej'
# MAGIC #LOG_FILE=${AI_LOG}/$JOB_NAME.log.`date +%m%d%H%M`
# MAGIC CYCLE_DATE_FILE=$AI_INBOUND/cycle_date.pipe_delim
# MAGIC FILE_NBR=0
# MAGIC MAX_TXN_KEY_FILE=$AI_PERSIST_SERIAL/max_system_surrogate_key.dat
# MAGIC INPUT_FILE_NAME=$AI_FTP/$INPUT_FILE
# MAGIC echo $INPUT_FILE_NAME
# MAGIC INFILE_FLAG=`echo $INPUT_FILE_NAME | cut -d"." -f1 | cut -d"_" -f4`
# MAGIC echo $INFILE_FLAG
# MAGIC 
# MAGIC export ERRQ_NOHDR_FILE=$AI_RECYCLE/POSEJ_Error_Queue_nohdr.txt.$RUN_DAY
# MAGIC mkdir -p $AI_LOOKUP/pos_file_lookup/source
# MAGIC mkdir -p $AI_INBOUND/pos_ej_ux/$BATCH_ID
# MAGIC 
# MAGIC export POS_FILE_LOOKUP=$AI_LOOKUP/pos_file_lookup/source/pos_file_lookup.dat
# MAGIC RC=0
# MAGIC 
# MAGIC dttm=`basename $INPUT_FILE_NAME | cut -d"." -f1 | cut -d"_" -f4`
# MAGIC echo $dttm
# MAGIC IN_FILE_NAME=$INPUT_FILE
# MAGIC EJ_FILE=$AI_FTP/$IN_FILE_NAME
# MAGIC echo $IN_FILE_NAME,$EJ_FILE
# MAGIC FILE_NBR=$(( $FILE_NBR + 1 ))
# MAGIC echo  "$FILE_NBR|$IN_FILE_NAME" > $POS_FILE_LOOKUP
# MAGIC 
# MAGIC if [ "$INFILE_FLAG" != "mf" ]
# MAGIC then
# MAGIC   echo $IN_FILE_NAME
# MAGIC   UNSORTED_FILE=$AI_INBOUND/pos_ej_ux/temp/$IN_FILE_NAME
# MAGIC   mkdir -p $UNSORTED_FILE
# MAGIC   echo $UNSORTED_FILE
# MAGIC   cp $EJ_FILE $UNSORTED_FILE
# MAGIC fi

# COMMAND ----------

#conversion to parquet files:

from pyspark.sql.functions import *
from pyspark.sql.types import *

AI_FTP= mountPoint + "/" + input_folder
AI_LOOKUP= mountPoint + "/" + lookup_folder
INPUT_FILE=input_file
BATCH_ID=batch_id
INPUT_FILE_NAME=AI_FTP+"/"+INPUT_FILE
AI_INBOUND= mountPoint + "/" + staging_folder
POS_FILE_LOOKUP_COLS=['file_nbr','file_name']
POS_LOOKUP_SCHEMA = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,POS_FILE_LOOKUP_COLS)))

INFILE_FLAG=INPUT_FILE_NAME.split("/")[-1].split("_")[-1].split(".")[-2] 
if(INFILE_FLAG!="mf"): 
  POS_FILE_LOOKUP_DIR=AI_LOOKUP+"/pos_file_lookup/"
  POS_FILE_LOOKUP=POS_FILE_LOOKUP_DIR+"/source/pos_file_lookup.dat"
  POS_FILE_PARQUET=POS_FILE_LOOKUP_DIR+BATCH_ID
  UNSORTED_FILE=AI_INBOUND+"/pos_ej_ux/temp"+"/"+INPUT_FILE
  #print (AI_INBOUND+"/pos_ej_ux/temp"+"/"+INPUT_FILE)
  UNSORTED_FILE_PARQUET=AI_INBOUND+"/pos_ej_ux/"+BATCH_ID
  dfUnsorted = spark.read.csv(UNSORTED_FILE)
  dfLookup = spark.read.format("csv").option("delimiter","|").option("inferSchema","true").schema(POS_LOOKUP_SCHEMA).load(POS_FILE_LOOKUP)
  #display(dfUnsorted)
  #print(UNSORTED_FILE_PARQUET)
  dfUnsorted.write.format("parquet").mode("overwrite").save(UNSORTED_FILE_PARQUET)
  dfLookup.write.format("parquet").mode("overwrite").save(POS_FILE_PARQUET)


# COMMAND ----------

if(INFILE_FLAG!="mf"):
  dbutils.fs.rm(UNSORTED_FILE,True)
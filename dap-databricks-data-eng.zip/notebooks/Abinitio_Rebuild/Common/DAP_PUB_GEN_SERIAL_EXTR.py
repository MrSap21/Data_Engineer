# Databricks notebook source
dbutils.widgets.text('PAR_DB_AI_SERIAL','',label='PAR_DB_AI_SERIAL')
dbutils.widgets.text('PAR_DB_OUT_FILE','',label='PAR_DB_OUT_FILE')
dbutils.widgets.text('PAR_DB_BATCH_ID','',label='PAR_DB_BATCH_ID')
dbutils.widgets.text('PAR_DB_DELIMITER','',label='PAR_DB_DELIMITER')
dbutils.widgets.text('PAR_DB_TRANSFORM_TRUE_FALSE','',label='PAR_DB_TRANSFORM_TRUE_FALSE')
dbutils.widgets.text('PAR_DB_QUERY','',label='PAR_DB_QUERY')
dbutils.widgets.text('PAR_DB_TRANSFOMATION','',label='PAR_DB_TRANSFOMATION')
dbutils.widgets.text('PAR_PL_REFORMAT_VAR','',label='PAR_PL_REFORMAT_VAR')

# COMMAND ----------

                    
varInputFilePath = dbutils.widgets.get('PAR_DB_AI_SERIAL')
varInputFileName = dbutils.widgets.get('PAR_DB_OUT_FILE')
varInputbatchid = dbutils.widgets.get('PAR_DB_BATCH_ID')
varDelimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')
varTransformRequired = dbutils.widgets.get('PAR_DB_TRANSFORM_TRUE_FALSE')
varQuery = dbutils.widgets.get('PAR_DB_QUERY')
varTransformation = dbutils.widgets.get('PAR_DB_TRANSFOMATION')
varReformat = dbutils.widgets.get('PAR_PL_REFORMAT_VAR')
varOutputFilePath = '/mnt/curated/'+varInputFilePath+'/'+varInputFileName+'_'+varInputbatchid

# COMMAND ----------

# MAGIC %scala
# MAGIC //For using in scala
# MAGIC dbutils.widgets.text("PAR_DB_QUERY","",label="PAR_DB_QUERY")
# MAGIC val varQuery = dbutils.widgets.get("PAR_DB_QUERY")

# COMMAND ----------

# MAGIC %scala
# MAGIC import com.microsoft.aad.adal4j.{AuthenticationContext, ClientCredential}
# MAGIC import org.apache.spark.sql.SparkSession
# MAGIC import java.util.concurrent.Executors

# COMMAND ----------

# MAGIC %scala
# MAGIC val url = "jdbc:sqlserver://dapdevsqldwhsrv01.database.windows.net:1433;databaseName=dapdevdwh01"
# MAGIC val dbTable = "dbo.DNADEVEDWDB01__PATIENT_ADDRESS_bkp" //Replace with your database table
# MAGIC 
# MAGIC val principalClientId = "3c3353bc-a254-4cb0-abbc-51ec3852c7c5"
# MAGIC val principalSecret = dbutils.secrets.get(scope = "dapdevdataenggscope", key = "devdnasynapse")
# MAGIC val TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
# MAGIC 
# MAGIC val authority = "https://login.windows.net/" + TenantId
# MAGIC val resourceAppIdURI = "https://database.windows.net/"

# COMMAND ----------

# MAGIC %scala
# MAGIC val service = Executors.newFixedThreadPool(1)
# MAGIC val context = new AuthenticationContext(authority, true, service);
# MAGIC val ClientCred = new ClientCredential(principalClientId, principalSecret)
# MAGIC val authResult = context.acquireToken(resourceAppIdURI, ClientCred, null)
# MAGIC val accessToken = authResult.get().getAccessToken

# COMMAND ----------

# MAGIC %scala
# MAGIC 
# MAGIC val jdbcDF = spark.read
# MAGIC     .format("com.microsoft.sqlserver.jdbc.spark")
# MAGIC     .option("url", url)
# MAGIC     .option("accessToken", accessToken)
# MAGIC     .option("encrypt", "true")
# MAGIC     .option("hostNameInCertificate", "*.database.windows.net")
# MAGIC     .option("query",varQuery)
# MAGIC     .load()

# COMMAND ----------

# MAGIC %scala
# MAGIC val tempView = jdbcDF.createOrReplaceTempView("reformatTable")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import SparkSession

# COMMAND ----------

reformatDf = spark.sql('select * from reformatTable')

# COMMAND ----------


replacedStr=varReformat.replace('(','').replace(')','')
print(replacedStr)

varList = list(replacedStr.split(","))

print(varList)



# COMMAND ----------

#reformattedDf=reformatDf.withColumn('maint_drug_cd',F.when(F.col('maint_drug_cd').isNull(),'O').when(F.col('maint_drug_cd')=='X','M').otherwise(F.col('maint_drug_cd')))# 
from pyspark.sql import functions as F

reformattedDf=reformatDf.withColumn(varList[1],F.when(F.col(varList[1]).isNull(),varList[3]).when(F.col(varList[1])==varList[4],varList[5]).otherwise(F.col(varList[7])))

# COMMAND ----------

#Write in ADLS

reformattedDf.coalesce(1).write.options(header="false", delimiter = varDelimiter).format("csv").mode("overwrite").save(varOutputFilePath)

# COMMAND ----------

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(varOutputFilePath)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, varOutputFilePath.rstrip('/') + ".dat")
dbutils.fs.rm(varOutputFilePath, recurse = True)

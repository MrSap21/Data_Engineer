# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
import pyspark
import pandas,numpy
input_array=[[9212345678977,1,5785,[[2,1,1],[3,1,2],[4,1,]]]]
input_schema=["type_cntr","file_nbr","rec_inline","rec_in_txn_cntr"]
#RAWDATA#
dfRaw=spark.createDataFrame(data=input_array,schema=input_schema)
dfRaw.printSchema() 
dfRaw.show()  
#Fixed column dataframe
df=dfRaw.select(dfRaw.type_cntr,dfRaw.file_nbr,dfRaw.rec_inline) #Fixed columns
df.show()

# COMMAND ----------

df2=dfRaw.select(dfRaw.type_cntr,dfRaw.file_nbr,dfRaw.rec_inline,explode(dfRaw.rec_in_txn_cntr)).withColumnRenamed("col","items") ##EXPLODED Data
df2.printSchema()
df2.show()
#df3=df2.select((0 until 3).map(i=>df2.items.getItem(i).alias("col")): _*)
df3=df2.select(df2.items.getItem(0).alias("rec_in_txn_cntr"),df2.items.getItem(1).alias("valid_ind"),\
          df2.items.getItem(2).alias("seq_nbr"))

df3.show()
#df3.printSchema()

# COMMAND ----------

#Array Dataframe to a List
rest_vect_input=df3.rdd.map(lambda x: x).collect()
print(rest_vect_input)

rest_vect_schema=['rec_in_txn_cntr','valid_ind','seq_nbr']

#convert list to dataframe
dfarray=spark.createDataFrame(data=rest_vect_input,schema=rest_vect_schema)
dfarray.show()

# COMMAND ----------

#Join 2 dataframe
union_df=df.join(dfarray)
union_df.show()

# COMMAND ----------

test=[[1,2,4,"ACVB"],[1,2,2,"AB"],[1,22,3,"ACB1"],[1,2,4,"ACVB"],[2,4,0,"ACVB"],[2,2,2,"ACB"],[3,22,3,"ACB1"],[3,2,4,"ACVB"]]

dfTest=spark.createDataFrame(data=test)
vec_in=dfTest.rdd.map(lambda x:x[0]).distinct().collect()

d = []
#print(test[0])
for row in test:
#print(row)
  for i in range(len(vec_in)):
    if vec_in[i]==row[0]:
      if row[0] not in d:
#     d[row[0]]=[]
        d.append(row[1:])
    break
#     scenario1(d)
  
    
print(d)


# COMMAND ----------

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark import Row
filePath = mountPoint + "/" + "/retail/ECDW7111T_MAIN/" + "/" + "Input_reformat.csv"

fileschema=(
    StructType([
      StructField("txn_cntr", LongType(), False),
      StructField("file_nbr", LongType(), False),
      StructField("rec_in_file", IntegerType(), False),
      StructField("partition_nbr", IntegerType(), False),
      StructField("str_nbr", IntegerType(), False),
      StructField("txn_date", IntegerType(), False),
      StructField("txn_time", IntegerType(), False),
      StructField("cashier_nbr", IntegerType(), False),
      StructField("register_nbr", IntegerType(), False),
      StructField("txn_type", IntegerType(), False),
      StructField("txn_nbr", IntegerType(), False),
      StructField("loc_id", IntegerType(), False),
      StructField("cnt_dtl", IntegerType(), False),
      StructField("cnt_voids", IntegerType(), False),
      StructField("cnt_valid_items", IntegerType(), False),
      StructField("sum_dtl", DoubleType(), False),
      StructField("rec_in_txn_cntr", IntegerType(), False),
      StructField("valid_ind", IntegerType(), False),
      StructField("seq_nbr", IntegerType(), False),
      StructField("upc_nbr", StringType(), False),
      StructField("upc_desc", StringType(), True),
      StructField("dept", IntegerType(), False),
      StructField("selling_price", DoubleType(), False),
      StructField("void_ind", StringType(), False),
      StructField("qty", IntegerType(), False)
      ])
)
filedata = spark.read.format("csv").option("delimiter",',').schema(fileschema).load(filePath)
input_vector=filedata.rdd.map(lambda x: x).collect()
print(input_vector)
txncntr=filedata.rdd.map(lambda x:x[0]).distinct().collect()
print(txncntr[0])
vector_data =[]
#vectordata=filedata.select(filedata.columns[16:])
          #vectordata.show()
for row in filedata:
#print(row)
  for i in range(len(txncntr)):
    print(txncntr[i])
    print(filedata[0].txn_cntr)
    if txncntr[i]==input_vector[0]:
      if row[0] not in vector_data:
        vector_data.append(row[16:])
    break
rest_vec_input=vector_data
rest_vec=rest_vec_input
#print(rest_vec)
xref_vec=[]
remain_vec=[]
#xref_vec_col=("cnt_xrefs","xref")
#remain_vec_col=("void_ind","remaining_amt","remaining_qty","remaining_unit_price")


# COMMAND ----------

class remain_vec_record: 
    def __init__(self, void_ind,remaining_amt,remaining_qty,remaining_unit_price): 
        self.void_ind = void_ind 
        self.remaining_amt = remaining_amt
        self.remaining_qty = remaining_qty
        self.remaining_unit_price = remaining_unit_price
        
class xref_vec_record: 
    def __init__(self, cnt_xrefs,xref): 
        self.cnt_xrefs = cnt_xrefs
        self.xref = xref     
        
local_index=0

for i in rest_vec_input:
  #rest_vec.append(rest_vec_record(i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8]))
  xref_vec.append(xref_vec_record(0,""))
#for i in range(len(rest_vec)):
#      print(rest_vec[i].upc_nbr)
#      print(match_void)
#len(rest_vec)
#print(xref_vec)


# COMMAND ----------

#First Scenario UPCID,UPC Desc and Price match
#def scenario1(rest_vec):
local_index=0
cnt_valid_items=len(rest_vec)
print(cnt_valid_items)
i=0
if (cnt_valid_items > 0):
     sum_remaining_amt=0
     for i in range(len(rest_vec)):
                 if(rest_vec[i].qty != 0) :
                          remaining_unit_price = rest_vec[i].selling_price/rest_vec[i].qty
                 else:
                          remaining_unit_price = rest_vec[i].selling_price;
                 remain_vec.append(remain_vec_record(rest_vec[i].void_ind,rest_vec[i].selling_price,rest_vec[i].qty,remaining_unit_price))
               #remain_vec.append(remain_vec_record(rest_vec[i].void_ind,rest_vec[i].selling_price,rest_vec[i].qty,remaining_unit_price))
                 local_index = local_index +1
     print(local_index)
     for i in range(0,len(remain_vec)):
        if (remain_vec[i].void_ind in ('V',1,2,3,4,5,6,7,8,9,'a','b','c','d','e')):
            match_void_price = rest_vec[i].selling_price * -1
            if (match_void_price >= 0):
              match_positive_sign = 1;
            else:
              match_positive_sign = 0;
            j=0;
            while (j < local_index):
              if ( rest_vec[i].valid_ind and  rest_vec[i].upc_nbr == rest_vec[j].upc_nbr and
                                          rest_vec[i].upc_desc == rest_vec[j].upc_desc and not str(remain_vec[j].void_ind) and 
                                           match_void_price == rest_vec[j].selling_price):
                print ("line 79")
                remain_vec[j].remaining_amt = 0;
                remain_vec[j].void_ind = "F";
                print (rest_vec[i].seq_nbr)
                if (not xref_vec[j].xref ):
                        xref_vec[j].xref = rest_vec[i].seq_nbr;
                        xref_vec[j].cnt_xrefs = xref_vec[j].cnt_xrefs + 1;
                else:
                        xref_vec[j].xref = string_concat(xref_vec[j].xref,rest_vec[i].seq_nbr);
                        xref_vec[j].cnt_xrefs = xref_vec[j].cnt_xrefs + 1;
                xref_vec[i].xref = rest_vec[j].seq_nbr;
                xref_vec[i].cnt_xrefs = xref_vec[i].cnt_xrefs + 1;
                remain_vec[i].remaining_amt = 0;   
                j = local_index;
                j = j + 1;
            if(not (xref_vec[i].xref)):
                                         j=0;
                                         while (j < local_index):
                                                if ( rest_vec[i].valid_ind and  (rest_vec[i].upc_nbr == rest_vec[j].upc_nbr or 
                                                     rest_vec[i].upc_desc == rest_vec[j].upc_desc) and not str(remain_vec[j].void_ind) and 
                                                     match_void_price == rest_vec[j].selling_price):
                                                       remain_vec[j].remaining_amt = 0;
                                                       remain_vec[j].void_ind = "F";
                                                       print ("line 102")
                                                       if (not xref_vec[j].xref ):
                                                            xref_vec[j].xref = rest_vec[i].seq_nbr;
                                                            xref_vec[j].cnt_xrefs = xref_vec[j].cnt_xrefs + 1;
                                                       else:
                                                            xref_vec[j].xref = string_concat(xref_vec[j].xref,rest_vec[i].seq_nbr);
                                                            xref_vec[j].cnt_xrefs = xref_vec[j].cnt_xrefs + 1;
                                                       xref_vec[i].xref = rest_vec[j].seq_nbr;
                                                       xref_vec[i].cnt_xrefs = xref_vec[i].cnt_xrefs + 1;
                                                       remain_vec[i].remaining_amt = 0;   
                                                       j = local_index;
                                                j = j + 1;
            if(not (xref_vec[i].xref)):
                                         j=0;
                                         while (j < local_index):
                                                if ( rest_vec[i].valid_ind and  
                                                     rest_vec[i].dept == rest_vec[j].dept and not str(remain_vec[j].void_ind) and 
                                                     match_void_price == rest_vec[j].selling_price):
                                                       remain_vec[j].remaining_amt = 0;
                                                       remain_vec[j].void_ind = "F";
                                                       print ("line 122")
                                                       if (not xref_vec[j].xref ):
                                                            xref_vec[j].xref = rest_vec[i].seq_nbr;
                                                            xref_vec[j].cnt_xrefs = xref_vec[j].cnt_xrefs + 1;
                                                       else:
                                                            xref_vec[j].xref = string_concat(xref_vec[j].xref,rest_vec[i].seq_nbr);
                                                            xref_vec[j].cnt_xrefs = xref_vec[j].cnt_xrefs + 1;
                                                       xref_vec[i].xref = rest_vec[j].seq_nbr;
                                                       xref_vec[i].cnt_xrefs = xref_vec[i].cnt_xrefs + 1;
                                                       remain_vec[i].remaining_amt = 0;   
                                                       j = local_index;
                                                j = j + 1;
     for i in range(0,len(remain_vec)):
       if (remain_vec[i].void_ind in ('V',1,2,3,4,5,6,7,8,9,'a','b','c','d','e') and not (xref_vec[i].xref)):
                               match_void_price = rest_vec[i].selling_price * -1
                               match_void_qty = rest_vec[i].qty
                               if (match_void_qty != 0):
                                     match_void_unit_price = match_void_price / match_void_qty;
                               else:
                                     match_void_unit_price = match_void_price
                               if (match_void_price >= 0):
                                     match_positive_sign = 1;
                               else:
                                     match_positive_sign = 0;
  #1.1 Full void, exact UPC #, UPC desc and amount match.
                               k = local_index - 1;
                               while (k >=0):
                                         max_void_price = 0;
                                         max_void_index = -1;
                                         j = 0; 
                                         while (j < local_index):
                                                print(i,j,"unit price match 1.1",rest_vec[i].valid_ind,rest_vec[i].upc_nbr,rest_vec[j].upc_nbr,rest_vec[i].upc_desc , rest_vec[j].upc_desc,remain_vec[j].void_ind,match_void_unit_price,remain_vec[j].remaining_unit_price)  
                                                if ( rest_vec[i].valid_ind and  rest_vec[i].upc_nbr == rest_vec[j].upc_nbr and j!=1 and                                                                                                      (match_void_unit_price == remain_vec[j].remaining_unit_price) and
                                                     (str(remain_vec[j].void_ind)=="" or remain_vec[j].void_ind == "P") ):
                                                       print ("line 154")
                                                       if ((match_positive_sign and  max_void_price < remain_vec[j].remaining_amt) or
                                                          (not match_positive_sign and remain_vec[j].remaining_amt < 0) and
                                                           max_void_price > remain_vec[j].remaining_amt):
                                                             max_void_price = remain_vec[j].remaining_amt;
                                                             max_void_index = j;
                                                j = j + 1;
                                         if(max_void_index >= 0):
                                                if ( (match_void_unit_price == remain_vec[max_void_index].remaining_unit_price) and
                                                     ((match_positive_sign and match_void_price >= remain_vec[max_void_index].remaining_amt) or
                                                     (not match_positive_sign and match_void_price <= remain_vec[max_void_index].remaining_amt)) and 
                                                     (match_void_qty >= remain_vec[max_void_index].remaining_qty)):
                                                       match_void_price = match_void_price - remain_vec[max_void_index].remaining_amt;
                                                       match_void_qty = match_void_qty - remain_vec[max_void_index].remaining_qty;
                                                       remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + remain_vec[max_void_index].remaining_amt;
                                                       remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - remain_vec[max_void_index].remaining_qty;
                                                       remain_vec[max_void_index].remaining_amt = 0;
                                                       remain_vec[max_void_index].remaining_qty = 0;
                                                       remain_vec[max_void_index].void_ind = "F";
                                                       if (not xref_vec[max_void_index].xref ):
                                                            xref_vec[max_void_index].xref = rest_vec[i].seq_nbr;
                                                            xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                                       else:
                                                            xref_vec[max_void_index].xref = string_concat(xref_vec[max_void_index].xref,rest_vec[i].seq_nbr);
                                                            xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                                       if (match_void_price == 0 ):
                                                            k=0;   
                                         k=k-1;
  #1.2 Full void, exact UPC # or UPC desc and exact amount match.
                               if (match_void_price != 0):
                                        k = local_index - 1;
                                        while (k >=0):
                                                  max_void_price = 0;
                                                  max_void_index = -1;
                                                  j = 0; 
                                                  while (j < local_index):
                                                         if ( rest_vec[i].valid_ind and  (rest_vec[i].upc_nbr == rest_vec[j].upc_nbr or 
                                                              rest_vec[i].upc_desc == rest_vec[j].upc_desc ) and j!=1 and                                                                                                      (match_void_unit_price == remain_vec[j].remaining_unit_price) and
                                                              (not str(remain_vec[j].void_ind) or remain_vec[j].void_ind == "P") ):
                                                                print ("line 194")
                                                                if ((match_positive_sign and  max_void_price < remain_vec[j].remaining_amt) or
                                                                   (not match_positive_sign and remain_vec[j].remaining_amt < 0) and
                                                                    max_void_price > remain_vec[j].remaining_amt):
                                                                      max_void_price = remain_vec[j].remaining_amt;
                                                                      max_void_index = j;
                                                         j = j + 1;
                                                  if(max_void_index >= 0):
                                                         if ( (match_void_unit_price == remain_vec[max_void_index].remaining_unit_price) and
                                                              ((match_positive_sign and match_void_price >= remain_vec[max_void_index].remaining_amt) or
                                                              (not match_positive_sign and match_void_price <= remain_vec[max_void_index].remaining_amt)) and 
                                                              (match_void_qty >= remain_vec[max_void_index].remaining_qty)):
                                                                match_void_price = match_void_price - remain_vec[max_void_index].remaining_amt;
                                                                match_void_qty = match_void_qty - remain_vec[max_void_index].remaining_qty;
                                                                remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + remain_vec[max_void_index].remaining_amt;
                                                                remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - remain_vec[max_void_index].remaining_qty;
                                                                remain_vec[max_void_index].remaining_amt = 0;
                                                                remain_vec[max_void_index].remaining_qty = 0;
                                                                remain_vec[max_void_index].void_ind = "F";
                                                                if (not xref_vec[max_void_index].xref ):
                                                                     xref_vec[max_void_index].xref = rest_vec[i].seq_nbr;
                                                                     xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                                                else:
                                                                     xref_vec[max_void_index].xref = string_concat(xref_vec[max_void_index].xref,rest_vec[i].seq_nbr);
                                                                     xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                                                if (match_void_price == 0 ):
                                                                     k=0;   
                                                  k=k-1;
  #1.3 Full void, exact department and exact amount match.
                               if (match_void_price != 0):
                                        k = local_index - 1;
                                        while (k >=0):
                                                  max_void_price = 0;
                                                  max_void_index = -1;
                                                  j = 0; 
                                                  while (j < local_index):
                                                         if ( rest_vec[i].valid_ind and  rest_vec[i].dept == rest_vec[j].dept and j!=1 and                                                                                                      (match_void_unit_price == remain_vec[j].remaining_unit_price) and
                                                              (not str(remain_vec[j].void_ind) or remain_vec[j].void_ind == "P") ):
                                                                print ("line 235")
                                                                if ((match_positive_sign and  max_void_price < remain_vec[j].remaining_amt) or
                                                                   (not match_positive_sign and remain_vec[j].remaining_amt < 0) and
                                                                    max_void_price > remain_vec[j].remaining_amt):
                                                                      max_void_price = remain_vec[j].remaining_amt;
                                                                      max_void_index = j;
                                                         j = j + 1;
                                                  if(max_void_index >= 0):
                                                         if ( (match_void_unit_price == remain_vec[max_void_index].remaining_unit_price) and
                                                              ((match_positive_sign and match_void_price >= remain_vec[max_void_index].remaining_amt) or
                                                              (not match_positive_sign and match_void_price <= remain_vec[max_void_index].remaining_amt)) and 
                                                              (match_void_qty >= remain_vec[max_void_index].remaining_qty)):
                                                                match_void_price = match_void_price - remain_vec[max_void_index].remaining_amt;
                                                                match_void_qty = match_void_qty - remain_vec[max_void_index].remaining_qty;
                                                                remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + remain_vec[max_void_index].remaining_amt;
                                                                remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - remain_vec[max_void_index].remaining_qty;
                                                                remain_vec[max_void_index].remaining_amt = 0;
                                                                remain_vec[max_void_index].remaining_qty = 0;
                                                                remain_vec[max_void_index].void_ind = "F";
                                                                if (not xref_vec[max_void_index].xref ):
                                                                     xref_vec[max_void_index].xref = rest_vec[i].seq_nbr;
                                                                     xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                                                else:
                                                                     xref_vec[max_void_index].xref = string_concat(xref_vec[max_void_index].xref,rest_vec[i].seq_nbr);
                                                                     xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                                                if (match_void_price == 0 ):
                                                                     k=0;   
                                                  k=k-1;
  #2.1 Partial void, exact UPC #, UPC desc, void has unit price match original item unit price.
                               if (match_void_price != 0):
                                   k = local_index - 1;
                                   while (k >= 0):
                                       updated_match = 0;
                                       max_void_price = 0;
                                       max_void_index = -1;
                                       j = 0;
                                       while (j < local_index):
                                           if (rest_vec[i].valid_ind and
                                               rest_vec[i].upc_nbr == rest_vec[j].upc_nbr and
                                               rest_vec[i].upc_desc == rest_vec[j].upc_desc and  j != i and
                                               match_void_unit_price == remain_vec[j].remaining_unit_price and
                                               (not (remain_vec[j].void_ind) or remain_vec[j].void_ind == "P")):
                                               if ((match_positive_sign and max_void_price < remain_vec[j].remaining_amt) or
                                                   (( not match_positive_sign and remain_vec[j].remaining_amt < 0) or max_void_price > remain_vec[j].remaining_amt)):
                                                   max_void_price = remain_vec[j].remaining_amt;
                                                   max_void_index = j;
                                           j = j + 1;
                                       if (max_void_index >= 0):
                                           if ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price 
                                                and (match_void_price >=(match_void_unit_price * remain_vec[max_void_index].remaining_qty))) or
                                                ((not match_positive_sign and remain_vec[max_void_index].remaining_amt < 0) 
                                                and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price and
                                                (match_void_price <= (match_void_unit_price * remain_vec[max_void_index].remaining_qty))) and
                                                (match_void_qty >= remain_vec[max_void_index].remaining_qty)):
                                               if (remain_vec[max_void_index].remaining_qty == 0 and match_void_unit_price != 0):
                                                   temp_remaining_qty = floor(remain_vec[max_void_index].remaining_amt / match_void_unit_price);
                                               else:
                                                   temp_remaining_qty = remain_vec[max_void_index].remaining_qty;
                                               if (match_void_qty < temp_remaining_qty):
                                                   temp_remaining_qty = match_void_qty;
                                               if (temp_remaining_qty == 0 and ((match_positive_sign and 
                                                   match_void_price >= remain_vec[max_void_index].remaining_amt) or 
                                                   (not match_positive_sign and match_void_price <= remain_vec[max_void_index].remaining_amt))):
                                                     match_void_price = match_void_price - remain_vec[max_void_index].remaining_amt;
                                                     match_void_qty = match_void_qty - temp_remaining_qty;
                                                     remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + remain_vec[max_void_index].remaining_amt;
                                                     remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                     remain_vec[max_void_index].remaining_amt = 0;
                                                     remain_vec[max_void_index].remaining_qty = 0;
                                               elif (temp_remaining_qty == 0 and ((match_positive_sign and 
                                                        match_void_price < remain_vec[max_void_index].remaining_amt) 
                                                        or (not match_positive_sign and match_void_price > remain_vec[max_void_index].remaining_amt))):
                                                     remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_price;
                                                     remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                     match_void_price = 0;
                                                     match_void_qty = 0;
                                                     remain_vec[i].remaining_amt = 0;
                                                     remain_vec[i].remaining_qty = 0;
                                               else:
                                                   match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty;
                                                   match_void_qty = match_void_qty - temp_remaining_qty;
                                                   remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * temp_remaining_qty;
                                                   remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                   remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * temp_remaining_qty;
                                                   remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                               if (remain_vec[max_void_index].remaining_amt == 0):
                                                   remain_vec[max_void_index].remaining_qty = 0;
                                                   remain_vec[max_void_index].void_ind = "F";
                                               else:
                                                   remain_vec[max_void_index].void_ind = "P";
                                               updated_match = 1;
                                           elif ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price 
                                                  and (match_void_price <= (match_void_unit_price * remain_vec[max_void_index].remaining_qty))) or
                                                  ((not match_positive_sign and remain_vec[max_void_index].remaining_amt < 0) 
                                                   and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price and
                                                   (match_void_price >= (match_void_unit_price * remain_vec[max_void_index].remaining_qty)))):
                                               if (match_void_qty > remain_vec[max_void_index].remaining_qty):
                                                   match_void_price = match_void_price - match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   match_void_qty = match_void_qty - remain_vec[max_void_index].remaining_qty;
                                               else:
                                                   if (match_void_qty == 0):
                                                       temp_remaining_qty = floor(match_void_price / remain_vec[max_void_index].remaining_unit_price);
                                                   else:
                                                       temp_remaining_qty = match_void_qty;
                                                   if (temp_remaining_qty == 0 and match_void_price != 0):
                                                       remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_price;
                                                       remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                       remain_vec[i].remaining_amt = 0;
                                                       remain_vec[i].remaining_qty = 0;
                                                       match_void_price = 0;
                                                       match_void_qty = 0;
                                                   else:
                                                       remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * temp_remaining_qty;
                                                       remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                       remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * temp_remaining_qty;
                                                       remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                       match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty;
                                                       match_void_qty = 0;
                                               if (remain_vec[max_void_index].remaining_amt == 0):
                                                   remain_vec[max_void_index].remaining_qty = 0;
                                                   remain_vec[max_void_index].void_ind = "F";
                                               else:
                                                   remain_vec[max_void_index].void_ind = "P";
                                               updated_match = 1;
                                           if (updated_match == 1):
                                               if (is_blank(xref_vec[max_void_index].xref)):
                                                   xref_vec[max_void_index].xref = rest_vec[i].seq_nbr;
                                                   xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                               else:
                                                   xref_vec[max_void_index].xref = string_concat(xref_vec[max_void_index].xref, rest_vec[i].seq_nbr);
                                                   xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                               xref_vec[i].xref = string_concat(xref_vec[i].xref, rest_vec[max_void_index].seq_nbr);
                                               xref_vec[i].cnt_xrefs = xref_vec[i].cnt_xrefs + 1;
                                               if (match_void_price == 0):
                                                   k = 0;
                                       k = k - 1;
  #2.2 Partial void, exact UPC # or UPC desc, void has unit price match original item unit price.
                               if (match_void_price != 0):
                                   k = local_index - 1;
                                   while (k >= 0):
                                       updated_match = 0;
                                       max_void_price = 0;
                                       max_void_index = -1;
                                       j = 0;
                                       while (j < local_index):
                                           if (rest_vec[i].valid_ind and
                                               (rest_vec[i].upc_nbr == rest_vec[j].upc_nbr or
                                               rest_vec[i].upc_desc == rest_vec[j].upc_desc) and  j != i and
                                               match_void_unit_price == remain_vec[j].remaining_unit_price and
                                               (not (remain_vec[j].void_ind) or remain_vec[j].void_ind == "P")):
                                               if ((match_positive_sign and max_void_price < remain_vec[j].remaining_amt) or
                                                   (( not match_positive_sign and remain_vec[j].remaining_amt < 0) or max_void_price > remain_vec[j].remaining_amt)):
                                                   max_void_price = remain_vec[j].remaining_amt;
                                                   max_void_index = j;
                                           j = j + 1;
                                       if (max_void_index >= 0):
                                           if ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price 
                                                and (match_void_price >=(match_void_unit_price * remain_vec[max_void_index].remaining_qty))) or
                                                ((not match_positive_sign and remain_vec[max_void_index].remaining_amt < 0) 
                                                and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price and
                                                (match_void_price <= (match_void_unit_price * remain_vec[max_void_index].remaining_qty))) and
                                                (match_void_qty >= remain_vec[max_void_index].remaining_qty)):
                                               if (remain_vec[max_void_index].remaining_qty == 0 and match_void_unit_price != 0):
                                                   temp_remaining_qty = floor(remain_vec[max_void_index].remaining_amt / match_void_unit_price);
                                               else:
                                                   temp_remaining_qty = remain_vec[max_void_index].remaining_qty;
                                               if (match_void_qty < temp_remaining_qty):
                                                   temp_remaining_qty = match_void_qty;
                                               if (temp_remaining_qty == 0 and ((match_positive_sign and 
                                                   match_void_price >= remain_vec[max_void_index].remaining_amt) or 
                                                   (not match_positive_sign and match_void_price <= remain_vec[max_void_index].remaining_amt))):
                                                     match_void_price = match_void_price - remain_vec[max_void_index].remaining_amt;
                                                     match_void_qty = match_void_qty - temp_remaining_qty;
                                                     remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + remain_vec[max_void_index].remaining_amt;
                                                     remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                     remain_vec[max_void_index].remaining_amt = 0;
                                                     remain_vec[max_void_index].remaining_qty = 0;
                                               elif (temp_remaining_qty == 0 and ((match_positive_sign and 
                                                        match_void_price < remain_vec[max_void_index].remaining_amt) 
                                                        or (not match_positive_sign and match_void_price > remain_vec[max_void_index].remaining_amt))):
                                                     remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_price;
                                                     remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                     match_void_price = 0;
                                                     match_void_qty = 0;
                                                     remain_vec[i].remaining_amt = 0;
                                                     remain_vec[i].remaining_qty = 0;
                                               else:
                                                   match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty;
                                                   match_void_qty = match_void_qty - temp_remaining_qty;
                                                   remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * temp_remaining_qty;
                                                   remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                   remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * temp_remaining_qty;
                                                   remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                               if (remain_vec[max_void_index].remaining_amt == 0):
                                                   remain_vec[max_void_index].remaining_qty = 0;
                                                   remain_vec[max_void_index].void_ind = "F";
                                               else:
                                                   remain_vec[max_void_index].void_ind = "P";
                                               updated_match = 1;
                                           elif ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price 
                                                  and (match_void_price <= (match_void_unit_price * remain_vec[max_void_index].remaining_qty))) or
                                                  ((not match_positive_sign and remain_vec[max_void_index].remaining_amt < 0) 
                                                   and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price and
                                                   (match_void_price >= (match_void_unit_price * remain_vec[max_void_index].remaining_qty)))):
                                               if (match_void_qty > remain_vec[max_void_index].remaining_qty):
                                                   match_void_price = match_void_price - match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   match_void_qty = match_void_qty - remain_vec[max_void_index].remaining_qty;
                                               else:
                                                   if (match_void_qty == 0):
                                                       temp_remaining_qty = floor(match_void_price / remain_vec[max_void_index].remaining_unit_price);
                                                   else:
                                                       temp_remaining_qty = match_void_qty;
                                                   if (temp_remaining_qty == 0 and match_void_price != 0):
                                                       remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_price;
                                                       remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                       remain_vec[i].remaining_amt = 0;
                                                       remain_vec[i].remaining_qty = 0;
                                                       match_void_price = 0;
                                                       match_void_qty = 0;
                                                   else:
                                                       remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * temp_remaining_qty;
                                                       remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                       remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * temp_remaining_qty;
                                                       remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                       match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty;
                                                       match_void_qty = 0;
                                               if (remain_vec[max_void_index].remaining_amt == 0):
                                                   remain_vec[max_void_index].remaining_qty = 0;
                                                   remain_vec[max_void_index].void_ind = "F";
                                               else:
                                                   remain_vec[max_void_index].void_ind = "P";
                                               updated_match = 1;
                                           if (updated_match == 1):
                                               if (is_blank(xref_vec[max_void_index].xref)):
                                                   xref_vec[max_void_index].xref = rest_vec[i].seq_nbr;
                                                   xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                               else:
                                                   xref_vec[max_void_index].xref = string_concat(xref_vec[max_void_index].xref, rest_vec[i].seq_nbr);
                                                   xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                               xref_vec[i].xref = string_concat(xref_vec[i].xref, rest_vec[max_void_index].seq_nbr);
                                               xref_vec[i].cnt_xrefs = xref_vec[i].cnt_xrefs + 1;
                                               if (match_void_price == 0):
                                                   k = 0;
                                       k = k - 1;
 #2.3 Partial void, exact department, void has unit price match original item unit price.
                               if (match_void_price != 0):
                                   k = local_index - 1;
                                   while (k >= 0):
                                       updated_match = 0;
                                       max_void_price = 0;
                                       max_void_index = -1;
                                       j = 0;
                                       while (j < local_index):
                                           if (rest_vec[i].valid_ind and
                                               rest_vec[i].dept == rest_vec[j].dept and  j != i and
                                               match_void_unit_price == remain_vec[j].remaining_unit_price and
                                               (not (remain_vec[j].void_ind) or remain_vec[j].void_ind == "P")):
                                               if ((match_positive_sign and max_void_price < remain_vec[j].remaining_amt) or
                                                   (( not match_positive_sign and remain_vec[j].remaining_amt < 0) or max_void_price > remain_vec[j].remaining_amt)):
                                                   max_void_price = remain_vec[j].remaining_amt;
                                                   max_void_index = j;
                                           j = j + 1;
                                       if (max_void_index >= 0):
                                           if ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price 
                                                and (match_void_price >=(match_void_unit_price * remain_vec[max_void_index].remaining_qty))) or
                                                ((not match_positive_sign and remain_vec[max_void_index].remaining_amt < 0) 
                                                and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price and
                                                (match_void_price <= (match_void_unit_price * remain_vec[max_void_index].remaining_qty))) and
                                                (match_void_qty >= remain_vec[max_void_index].remaining_qty)):
                                               if (remain_vec[max_void_index].remaining_qty == 0 and match_void_unit_price != 0):
                                                   temp_remaining_qty = floor(remain_vec[max_void_index].remaining_amt / match_void_unit_price);
                                               else:
                                                   temp_remaining_qty = remain_vec[max_void_index].remaining_qty;
                                               if (match_void_qty < temp_remaining_qty):
                                                   temp_remaining_qty = match_void_qty;
                                               if (temp_remaining_qty == 0 and ((match_positive_sign and 
                                                   match_void_price >= remain_vec[max_void_index].remaining_amt) or 
                                                   (not match_positive_sign and match_void_price <= remain_vec[max_void_index].remaining_amt))):
                                                     match_void_price = match_void_price - remain_vec[max_void_index].remaining_amt;
                                                     match_void_qty = match_void_qty - temp_remaining_qty;
                                                     remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + remain_vec[max_void_index].remaining_amt;
                                                     remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                     remain_vec[max_void_index].remaining_amt = 0;
                                                     remain_vec[max_void_index].remaining_qty = 0;
                                               elif (temp_remaining_qty == 0 and ((match_positive_sign and 
                                                        match_void_price < remain_vec[max_void_index].remaining_amt) 
                                                        or (not match_positive_sign and match_void_price > remain_vec[max_void_index].remaining_amt))):
                                                     remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_price;
                                                     remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                     match_void_price = 0;
                                                     match_void_qty = 0;
                                                     remain_vec[i].remaining_amt = 0;
                                                     remain_vec[i].remaining_qty = 0;
                                               else:
                                                   match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty;
                                                   match_void_qty = match_void_qty - temp_remaining_qty;
                                                   remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * temp_remaining_qty;
                                                   remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                   remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * temp_remaining_qty;
                                                   remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                               if (remain_vec[max_void_index].remaining_amt == 0):
                                                   remain_vec[max_void_index].remaining_qty = 0;
                                                   remain_vec[max_void_index].void_ind = "F";
                                               else:
                                                   remain_vec[max_void_index].void_ind = "P";
                                               updated_match = 1;
                                           elif ((match_positive_sign and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price 
                                                  and (match_void_price <= (match_void_unit_price * remain_vec[max_void_index].remaining_qty))) or
                                                  ((not match_positive_sign and remain_vec[max_void_index].remaining_amt < 0) 
                                                   and match_void_unit_price == remain_vec[max_void_index].remaining_unit_price and
                                                   (match_void_price >= (match_void_unit_price * remain_vec[max_void_index].remaining_qty)))):
                                               if (match_void_qty > remain_vec[max_void_index].remaining_qty):
                                                   match_void_price = match_void_price - match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * remain_vec[max_void_index].remaining_qty;
                                                   match_void_qty = match_void_qty - remain_vec[max_void_index].remaining_qty;
                                               else:
                                                   if (match_void_qty == 0):
                                                       temp_remaining_qty = floor(match_void_price / remain_vec[max_void_index].remaining_unit_price);
                                                   else:
                                                       temp_remaining_qty = match_void_qty;
                                                   if (temp_remaining_qty == 0 and match_void_price != 0):
                                                       remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_price;
                                                       remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                       remain_vec[i].remaining_amt = 0;
                                                       remain_vec[i].remaining_qty = 0;
                                                       match_void_price = 0;
                                                       match_void_qty = 0;
                                                   else:
                                                       remain_vec[max_void_index].remaining_amt = remain_vec[max_void_index].remaining_amt - match_void_unit_price * temp_remaining_qty;
                                                       remain_vec[max_void_index].remaining_qty = remain_vec[max_void_index].remaining_qty - temp_remaining_qty;
                                                       remain_vec[i].remaining_amt = remain_vec[i].remaining_amt + match_void_unit_price * temp_remaining_qty;
                                                       remain_vec[i].remaining_qty = remain_vec[i].remaining_qty - temp_remaining_qty;
                                                       match_void_price = match_void_price - match_void_unit_price * temp_remaining_qty;
                                                       match_void_qty = 0;
                                               if (remain_vec[max_void_index].remaining_amt == 0):
                                                   remain_vec[max_void_index].remaining_qty = 0;
                                                   remain_vec[max_void_index].void_ind = "F";
                                               else:
                                                   remain_vec[max_void_index].void_ind = "P";
                                               updated_match = 1;
                                           if (updated_match == 1):
                                               if (is_blank(xref_vec[max_void_index].xref)):
                                                   xref_vec[max_void_index].xref = rest_vec[i].seq_nbr;
                                                   xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                               else:
                                                   xref_vec[max_void_index].xref = string_concat(xref_vec[max_void_index].xref, rest_vec[i].seq_nbr);
                                                   xref_vec[max_void_index].cnt_xrefs = xref_vec[max_void_index].cnt_xrefs + 1;
                                               xref_vec[i].xref = string_concat(xref_vec[i].xref, rest_vec[max_void_index].seq_nbr);
                                               xref_vec[i].cnt_xrefs = xref_vec[i].cnt_xrefs + 1;
                                               if (match_void_price == 0):
                                                   k = 0;
                                       k = k - 1;                                     
    for i in range(0,len(remain_vec)):
        sum_remaining_amt = sum_remaining_amt + remain_vec[i].remaining_amt;       
     print(sum_remaining_amt)
for i,j in zip(xref_vec,remain_vec):
  print(i.xref ,i.cnt_xrefs,j.remaining_amt,j.void_ind)
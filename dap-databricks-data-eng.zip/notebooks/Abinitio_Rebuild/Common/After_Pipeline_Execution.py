# Databricks notebook source
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions

# COMMAND ----------

dbutils.widgets.text("proj_name","")
dbutils.widgets.text("src_stream_name","")
dbutils.widgets.text("master_pipeline_name","")
dbutils.widgets.text("pipeline_run_stat_cd","")
dbutils.widgets.text("finish_dttm","")
dbutils.widgets.text("SNOWFLAKE_DATABASE","")
dbutils.widgets.text("SNOWFLAKE_WAREHOUSE","")
dbutils.widgets.text("schema_name","")

# COMMAND ----------

proj_name = dbutils.widgets.get("proj_name")
src_stream_name = dbutils.widgets.get("src_stream_name")
pipeline_name = dbutils.widgets.get("master_pipeline_name")
pipeline_run_stat_cd = dbutils.widgets.get("pipeline_run_stat_cd")
finish_dttm = dbutils.widgets.get("finish_dttm")
SNOWFLAKE_DATABASE = dbutils.widgets.get("SNOWFLAKE_DATABASE")
SNOWFLAKE_WAREHOUSE = dbutils.widgets.get("SNOWFLAKE_WAREHOUSE")
v_schema = dbutils.widgets.get("schema_name")
# Defining schema for table

# v_schema = "prdetlsand01"
# SNOWFLAKE_DATABASE = "dapdevdwh01"


query = "SELECT MAX(edw_batch_id) as id FROM {3}.{2}.proc_cntrl_batch_detail WHERE proj_name='{0}' AND src_stream_name='{1}' AND batch_status_cd='1'".format(proj_name, src_stream_name,v_schema,SNOWFLAKE_DATABASE)

# Load data to dataframe

df = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", query) \
  .load()

maxBatchId = df.first()[0]

query1 = "select MAX(run_seq_nbr) as run_sqn_nbr from {4}.{3}.proc_cntrl_pipeline_run_detail where proj_name = '{0}' and src_stream_name = '{1}' and pipeline_name = '{2}' and edw_batch_id = (SELECT MAX(edw_batch_id) as id FROM {4}.{3}.proc_cntrl_batch_detail WHERE proj_name='{0}' AND src_stream_name='{1}' AND batch_status_cd='1')".format(proj_name, src_stream_name, pipeline_name,v_schema,SNOWFLAKE_DATABASE)

# Load data to dataframe

df1 = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", query1) \
  .load()

run_sqn_nbr = df1.first()[0]

print("Run Sequence Nbr is " ,run_sqn_nbr)

query2 = "UPDATE {8}.{7}.proc_cntrl_pipeline_run_detail SET status_cd = '{6}' , finish_dttm = to_char(CURRENT_TIMESTAMP(), 'YYYY-MM-DD HH:MI:SS') WHERE proj_name = '{0}' AND src_stream_name = '{1}' AND pipeline_name = '{3}' AND edw_batch_id = '{2}' AND run_seq_nbr = '{4}'".format(proj_name, src_stream_name, maxBatchId, pipeline_name, run_sqn_nbr, finish_dttm, pipeline_run_stat_cd,v_schema,SNOWFLAKE_DATABASE)

dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : query2, "transaction" : True, "SNOWFLAKE_DATABASE" : SNOWFLAKE_DATABASE, "SNOWFLAKE_WAREHOUSE" : SNOWFLAKE_WAREHOUSE})
  
# Databricks notebook source
#dbutils.widgets.text("pIN_FILE_LIST",")
#dbutils.widgets.text("pFILE_EXP","")

# COMMAND ----------

inputFileList=dbutils.widgets.get("pIN_FILE_LIST")
fileExp=dbutils.widgets.get("pFILE_EXP").split(",")
print(inputFileList)

# COMMAND ----------

import json
import datetime

format="%Y%m%d"
finalDict={}

def process_file(inputJson,exp,feed):
  if type(inputJson) is list :  
      filteredJson=[x for x in inputJson if exp in x['assetname']]
      finalJson=[]
      print(filteredJson)
      for asset in filteredJson:
        datestr=asset['assetname'][len(exp)+1:len(exp)+9]
        try:
          datetime.datetime.strptime(datestr,format)
          finalJson.append(asset)
        except:
          pass
      if len(finalJson)>0:
        finalDict[feed]=finalJson
        return 1
      else:
        return 0
  else :
    datestr= inputJson['assetname'][len(exp)+1:len(exp)+9]
    finalJson=[]
    try:
        datetime.datetime.strptime(datestr,format)
        finalJson.append(inputJson)
    except:
        pass
    if len(finalJson)>0:      
    
      debt = dict({feed:finalJson})
      finalDict.update(debt)
      #print(finalDict)
      return 1
    else:
      return 0
print(inputFileList)
fileListJson=json.loads(inputFileList)
for exp in fileExp:
  flag=0
  for feed in fileListJson:
    if process_file(fileListJson[feed],exp,feed)==1:
      flag=1
      break
  if flag==0:
    raise Exception("No files found for "+exp)

# COMMAND ----------

#print(finalJson)
dbutils.notebook.exit(finalDict)

# Databricks notebook source
#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

# #Widgets for passing required parameters values:
# dbutils.widgets.text("PAR_SNFK_DB1","UAT_RETAIL")
# dbutils.widgets.text("PAR_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_SNFK_DB2","UAT_STAGING")
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220530190731")
# #dbutils.widgets.text("PAR_INPUT_FILELIST","{\"CT\":[{\"assetid\":72026,\"assetname\":\"CT200101_20220610043004\",\"assetcurrentlocation\":\"/retail/retail_sales/wcard/2022/06/10/\"},{\"assetid\":72027,\"assetname\":\"CT200104_20220610043005\",\"assetcurrentlocation\":\"/retail/retail_sales/wcard/2022/06/10/\"},{\"assetid\":72028,\"assetname\":\"CT200102_20220610043004\",\"assetcurrentlocation\":\"/retail/retail_sales/wcard/2022/06/10/\"},{\"assetid\":72029,\"assetname\":\"CT200103_20220610043004\",\"assetcurrentlocation\":\"/retail/retail_sales/wcard/2022/06/10/\"}]}")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_REJECT_FOLDER","retail/retail_sales/reject")
# dbutils.widgets.text("PAR_SNFK_TBL1","RETAIL_SALES.WCARD_PROGRAM_ACCOUNT_PROFILE")
# dbutils.widgets.text("PAR_SNFK_TBL2","RETAIL_SALES.WCARD_TANDEM_TXN_STG")
# dbutils.widgets.text("PAR_DIM_LOCATION_REPLACE_ASCII_PIPE_DELIM","dim_location_replace_ascii.pipe_delim")
# dbutils.widgets.text("PAR_WCARD_TANDEM_CREATE_DTTM_LKP1","wcard_tandem_create_dttm_lkp1")
# dbutils.widgets.text("PAR_WCARD_TANDEM_CREATE_DTTM_LKP","wcard_tandem_create_dttm_lkp")
# dbutils.widgets.text("PAR_CT_COMBINED_ACTN_REQ_TYPE_REJECT","wcard_rejected_type_recycle_txn")
# dbutils.widgets.text("PAR_CT_COMBINED_REQ_TYPE_REJECT","CT_COMBINED_REQ_TYPE_REJECT.rej")
# dbutils.widgets.text("PAR_WCARD_PROG_ACCT_PROF_UNLOAD","wcard_program_account_profile_unload")
# dbutils.widgets.text("PAR_WCARD_LAST_TRANS_UNLOAD","wcard_last_transaction_unload")
# dbutils.widgets.text("PAR_PREV_CT_COMBINED_ACTN_REQ_TYPE_REJECT","wcard_prev_rejected_type_recycle_txn")
# dbutils.widgets.text("PAR_CT_COMBINED_DUP","CT_COMBINED.dup")
# dbutils.widgets.text("PAR_CT_COMBINED_REJ","CT_COMBINED.rej")
# dbutils.widgets.text("PAR_WCARD_TXN","wcard_transaction")
# dbutils.widgets.text("PAR_WCARD_ACC_PROF_STATUS","wcard_account_profile_status")
# dbutils.widgets.text("PAR_WCARD_TXN_TYPE","wcard_transaction_type")
# dbutils.widgets.text("PAR_WCARD_TANDEM_ORIG","wcard_tandem_originator")
# dbutils.widgets.text("PAR_WCARD_TANDEM_REBATE_TYPE","wcard_tandem_rebate_type")
# dbutils.widgets.text("PAR_WCARD_TANDEM_ACTION_TYPE","wcard_tandem_action_type")
# dbutils.widgets.text("PAR_WCARD_TANDEM_REQ_TYPE","wcard_tandem_request_type")
# dbutils.widgets.text("PAR_WCARD_TANDEM_RESPONSE","wcard_tandem_response")
# dbutils.widgets.text("PAR_WCARD_LAST_TXN_DEL_LKP","wcard_last_transaction_delete_lkp")
# dbutils.widgets.text("PAR_WCARD_STATUS_DEL_LKP","wcard_profile_status_delete_eff_dt_lkp")
# dbutils.widgets.text("PAR_WCARD_LAST_TRANSACTION","wcard_last_transaction")
# dbutils.widgets.text("PAR_WCARD_ACC_PROFILE","wcard_program_account_profile")
# dbutils.widgets.text("PAR_WCARD_ACC_PROF_DEL_LKP","wcard_prog_acct_profile_delete_lkp")
# dbutils.widgets.text("PAR_FEED_NAME","CT")
# dbutils.widgets.text("PAR_SNFK_TBL3","RETAIL_SALES.WCARD_LAST_TRANSACTION")
# dbutils.widgets.text("PAR_PREV_RECYCLE_TXN","wcard_prev_recycle_txn")

# COMMAND ----------

SNFL_WH = dbutils.widgets.get("PAR_SNFK_WH")
SNFL_DB1 = dbutils.widgets.get("PAR_SNFK_DB1")
SNFL_TBL_NAME1 = dbutils.widgets.get("PAR_SNFK_TBL1")
SNFL_DB2 = dbutils.widgets.get("PAR_SNFK_DB2")
SNFL_TBL_NAME2 = dbutils.widgets.get("PAR_SNFK_TBL2")
SNFL_TBL_NAME3 = dbutils.widgets.get("PAR_SNFK_TBL3")
Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
Batch_Id = dbutils.widgets.get("PAR_DB_BATCH_ID")
WcardProgAcctProfUnload = dbutils.widgets.get("PAR_WCARD_PROG_ACCT_PROF_UNLOAD")
WcardLastTransUnload = dbutils.widgets.get("PAR_WCARD_LAST_TRANS_UNLOAD")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
WcardTandemCreateDttmLkp = dbutils.widgets.get("PAR_WCARD_TANDEM_CREATE_DTTM_LKP")
WcardTandemCreateDttmLkp1 = dbutils.widgets.get("PAR_WCARD_TANDEM_CREATE_DTTM_LKP1")
#DimLocationReplaceAsciiPipeDelim = dbutils.widgets.get("PAR_DIM_LOCATION_REPLACE_ASCII_PIPE_DELIM")
#CTInputFile = dbutils.widgets.get("PAR_INPUT_FILELIST")
#CTInputFile = "{\"CT\":[{\"assetid\":76303,\"assetname\":\"CT_COMBINED_20220624033612.20220624025537\",\"assetcurrentlocation\":\"/retail/retail_sales/wcard/2022/06/24/\"},{\"assetid\":76309,\"assetname\":\"CT199120_20220623091004\",\"assetcurrentlocation\":\"/retail/retail_sales/wcard/2022/06/23/\"}]}"
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
CTRejFile = dbutils.widgets.get("PAR_CT_COMBINED_REJ")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
CTCombinedReqTypeRej = dbutils.widgets.get("PAR_CT_COMBINED_REQ_TYPE_REJECT")

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------

# Generate Records

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

Data = [("Create_Tandem_DTTM","")]

Schema = StructType([ \
                    StructField("create_dttm_key",StringType(),True), \
                    StructField("create_dttm",StringType(),True)])

WcardTandemCreateDttmLkpDF = spark.createDataFrame(data=Data,schema=Schema)

WcardTandemCreateDttmLkpDF = WcardTandemCreateDttmLkpDF.withColumn("create_dttm",date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss"))

# Standard value for create dttm will be used through out the tandem process
WcardTandemCreateDttmLkpDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+WcardTandemCreateDttmLkp1+"/"+Batch_Id)

# COMMAND ----------

#Convert json asset location/filname to FIle Name List
# import json
# import os
# from pyspark.sql.functions import *
# from pyspark.sql.types import *
# from pyspark.sql.window import Window

# rddjson = sc.parallelize([CTInputFile])

# dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(FEED_NAME))) \
#                                          .select(f"{FEED_NAME}.assetcurrentlocation",
#                                                  f"{FEED_NAME}.assetid",
#                                                  f"{FEED_NAME}.assetname")
# #dfFileList.printSchema()
# dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

# #display(dfRaw)

# # Extracting File Name and Path
# getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
# getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

# dfNamePath = dfRaw\
#              .withColumn("filepath", getPathUDF("full_filename"))\
#              .withColumn("filename", getNameUDF("full_filename"))\
#              .drop("full_filename")

# readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]
# print(readList)

# COMMAND ----------

#Defining schema for CT Input source file:
Source_Schema = ['STORE_NUM',
                 'REGISTER_NUM',
                 'CASHIER_NUM',
                 'TRANSACTION',
                 'ACCOUNT_NUM',
                 'PLAN_ID',
                 'REQUEST_TYPE',
                 'ACTION_TYPE',
                 'APPROVAL_NUMBER',
                 'ORIGINATOR',
                 'APPROVED_AMOUNT',
                 'STARTING_BALANCE',
                 'ENDING_BALANCE',
                 'VENDOR_ID',
                 'STORE_DATE_TIME',
                 'RESPONSE_CODE',
                 'TRANSACTION_AMOUNT',
                 'REBATE_AGAINST_AMOUNT',
                 'REBATE_AMOUNT',
                 'REBATE_TYPE',
                 'USER_ID',
                 'TANDEM_TIMESTEMP']

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema)))
#print(schema)

#Reading file for the readList path
CTSrcFile_Path = mountPoint + "/retail/retail_sales/wcard/CT/*"

CTInputFileDF = spark.read.format("csv").option("delimiter","|").schema(schema).load(CTSrcFile_Path)

#display(CTInputFileDF)
#print(CTInputFileDF.count())

# COMMAND ----------

#FBE: Invalid Tandem ts & Store Date Time & Vendor 
FBE_CheckDF = CTInputFileDF.filter(((trim(col("STORE_DATE_TIME")).isNotNull()) & (col("STORE_DATE_TIME")!='')) & ((trim(col("TANDEM_TIMESTEMP")).isNotNull()) & (col("TANDEM_TIMESTEMP")!='')) & ((col("VENDOR_ID").isNotNull()) & (trim(col("VENDOR_ID"))!='')))

#CT_COMBINED Rejcet

CT_Combined_Reject_DF = CTInputFileDF.subtract(FBE_CheckDF)
#display(CT_Combined_Reject_DF)

#Rejected records with invalid timestamp or invalid vendor id
#CT_Combined_Reject_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Reject_Folder+"/"+CTRejFile+"/"+Batch_Id)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB1 $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

###Staging Table for profile and last transaction

#Defining schema for wcard_prev_recycle_txn.dat file:
Source_Schema1 = ['store_number',
                 'register_number',
                 'cashier_number',
                 'transaction_number',
                 'account_number',
                 'plan_id',
                 'request_type',
                 'action_type',
                 'approval_number',
                 'originator',
                 'approved_amount',
                 'starting_balance',
                 'ending_balance',
                 'vendor_id',
                 'store_date',
                 'store_time',
                 'response_code',
                 'transaction_amount',
                 'rebate_against_amount',
                 'rebate_amount',
                 'rebate_type',
                 'user_id',
                 'tandem_tstmp']

schema1 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema1)))
#print(schema1)

wcard_prev_recycle=mountPoint + '/' + Reject_Folder + '/' + dbutils.widgets.get('PAR_PREV_RECYCLE_TXN') + ".dat"

WCARD_PREV_CYL = spark.read.format("csv").option("delimiter","|").schema(schema1).load(wcard_prev_recycle)

WCARD_PREV_CYL=WCARD_PREV_CYL.select("store_number","register_number","cashier_number","transaction_number","account_number","plan_id","request_type","action_type","approval_number","originator","approved_amount","starting_balance","ending_balance","vendor_id","store_date","store_time","response_code","transaction_amount","rebate_against_amount","rebate_amount","rebate_type","user_id","tandem_tstmp")
#display(WCARD_PREV_CYL)
#print(WCARD_PREV_CYL.count())

##RFT: Incoming Dates-2
RftCheckDF=FBE_CheckDF.withColumn("STORE_DATE",substring(FBE_CheckDF.STORE_DATE_TIME,1,6))  \
.withColumn("store_number",FBE_CheckDF.STORE_NUM) \
.withColumn("register_number",FBE_CheckDF.REGISTER_NUM) \
.withColumn("cashier_number",FBE_CheckDF.CASHIER_NUM) \
.withColumn("transaction_number",FBE_CheckDF.TRANSACTION) \
.withColumn("store_time",substring(FBE_CheckDF.STORE_DATE_TIME,7,6))  \
.withColumn("tandem_tstmp",FBE_CheckDF.TANDEM_TIMESTEMP) \
.withColumn("account_number" ,FBE_CheckDF.ACCOUNT_NUM) \
.withColumn("approved_amount", lpad(FBE_CheckDF.APPROVED_AMOUNT,7,'0'))\
.withColumn("starting_balance", lpad(FBE_CheckDF.STARTING_BALANCE,7,'0')) \
.withColumn("ending_balance", lpad(FBE_CheckDF.ENDING_BALANCE,7,'0')) \
.withColumn("transaction_amount", lpad(FBE_CheckDF.TRANSACTION_AMOUNT,7,'0')) \
.withColumn("rebate_against_amount", lpad(FBE_CheckDF.REBATE_AGAINST_AMOUNT,7,'0')) \
.withColumn("rebate_amount", lpad(FBE_CheckDF.REBATE_AMOUNT,7,'0')) \
.select("store_number","register_number","cashier_number","transaction_number","account_number","plan_id","request_type","action_type","approval_number","originator","approved_amount","starting_balance","ending_balance","vendor_id","store_date","store_time","response_code","transaction_amount","rebate_against_amount","rebate_amount","rebate_type","user_id","tandem_tstmp")

WCARD_TNDEM_STG=WCARD_PREV_CYL.union(RftCheckDF).filter((col('store_number').isNotNull()) & (col('register_number').isNotNull()) & (col('transaction_number').isNotNull()) & (col('store_date').isNotNull())) \
.withColumn('str_nbr',col('store_number')) \
.withColumn('txn_nbr',col('transaction_number')) \
.withColumn('reg_nbr',col('register_number')) \
.withColumn('txn_dt',to_date(col('store_date'))) \
.withColumn('acct_id',col('account_number').cast(StringType())) \
.withColumn('profile_id',col('plan_id').cast(IntegerType())) \
.withColumn('prog_id',col('vendor_id').cast(IntegerType())) \
.select('str_nbr','txn_dt','txn_nbr','reg_nbr','acct_id','prog_id','profile_id')
Wcard_Tandem_Txn_Stg_DF = WCARD_TNDEM_STG
Wcard_Tandem_Txn_Stg_DF.cache()

WCARD_TNDEM_STG.write \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase",SNFL_DB2) \
  .option("dbtable", SNFL_TBL_NAME2) \
  .option("truncate_table","ON")\
  .mode("overwrite") \
  .save()

# COMMAND ----------

#Read Wcard_Program_Account_Profile Table
SEL_WCARD_PGM_TBL="Select * FROM {0}".format(SNFL_TBL_NAME1)

Wcard_Program_Account_Profile_DF = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase",SNFL_DB1) \
  .option("query", SEL_WCARD_PGM_TBL) \
  .load()

Wcard_Program_Account_Profile_DF = Wcard_Program_Account_Profile_DF.withColumn("ACCT_ID",col("ACCT_ID").cast(StringType())) \
.withColumn("PROFILE_ID",col("PROFILE_ID").cast(IntegerType())) \
.withColumn("PROG_ID",col("PROG_ID").cast(IntegerType()))

# COMMAND ----------

#Join on Wcard_Program_Account_Profile Table and Wcard_Tandem_Txn_STG Table
Wcard_Program_Account_Profile_DF.createOrReplaceTempView("wcard_program_account_profile")
Wcard_Tandem_Txn_Stg_DF.createOrReplaceTempView("wcard_tandem_txn_stg")
Wcard_Program_Account_Profile_Join_DF = spark.sql("select * from wcard_program_account_profile a INNER JOIN wcard_tandem_txn_stg d on a.acct_id = d.acct_id and a.prog_id = d.prog_id and a.profile_id = d.profile_id where a.prog_acct_profile_end_dt is NULL").select ("a.acct_id","a.profile_id","prog_acct_profile_eff_dt","a.prog_id","prog_acct_profile_end_dt","acct_profile_stat_cd","create_dttm")
Wcard_Program_Account_Profile_Join_DF.cache()

#Wcard_Program_Account_Profile_Join_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WcardProgAcctProfUnload+"/"+Batch_Id)

# COMMAND ----------

#Read Wcard_Last_Transaction Table
SEL_Wcard_Txn_TBL="Select * FROM {0}".format(SNFL_TBL_NAME3)

Wcard_Last_Transaction_DF = spark.read \
  .format("snowflake")\
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("sfDatabase",SNFL_DB1) \
  .option("query", SEL_Wcard_Txn_TBL) \
  .load()

Wcard_Last_Transaction_DF = Wcard_Last_Transaction_DF.withColumn("ACCT_ID",col("ACCT_ID").cast(StringType())) \
.withColumn("PROFILE_ID",col("PROFILE_ID").cast(IntegerType())) \
.withColumn("PROG_ID",col("PROG_ID").cast(IntegerType()))

# COMMAND ----------

#Join on Wcard_Last_Transaction Table and Wcard_Tandem_Txn_STG Table
Wcard_Last_Transaction_DF.createOrReplaceTempView("wcard_last_transaction")
Wcard_Last_Transaction_Join_DF = spark.sql("select * from wcard_last_transaction a INNER JOIN wcard_tandem_txn_stg d on a.acct_id = d.acct_id and a.prog_id = d.prog_id and a.profile_id = d.profile_id").select ("a.acct_id","a.profile_id","a.prog_id","a.tandem_txn_dt","a.tandem_txn_tm","a.str_nbr","a.register_nbr","a.tandem_txn_nbr","a.tandem_str_txn_dt","a.tandem_str_txn_tm","a.tandem_cashier_nbr","a.tandem_req_type","a.tandem_actn_type","a.tandem_aprv_nbr","a.tandem_orig","a.tandem_aprv_dlrs","a.tandem_response_cd","a.tandem_rbt_type","a.tandem_rbt_dlrs","a.tandem_rbt_pctg","a.tandem_rbt_against_dlrs","a.tandem_starting_bal_dlrs","a.tandem_end_bal_dlrs","a.tandem_txn_dlrs","a.tandem_clnt_name","a.tandem_user_id","a.txn_type_cd","a.create_dttm")
Wcard_Last_Transaction_Join_DF.cache()
#display(Wcard_Last_Transaction_Join_DF)
# output for Join on Wcard_Program_Account_Profile Table and Wcard_Tandem_Txn_STG Table

#Wcard_Last_Transaction_Join_DF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Staging_Folder+"/"+WcardLastTransUnload+"/"+Batch_Id)

# COMMAND ----------

#RFT: Incoming Dates-3
RfmtFbeCheckDF = FBE_CheckDF.withColumn("STORE_DATE",substring(FBE_CheckDF.STORE_DATE_TIME,1,6))  \
.withColumn("store_number",FBE_CheckDF.STORE_NUM) \
.withColumn("register_number",FBE_CheckDF.REGISTER_NUM) \
.withColumn("cashier_number",FBE_CheckDF.CASHIER_NUM) \
.withColumn("transaction_number",FBE_CheckDF.TRANSACTION) \
.withColumn("store_time",substring(FBE_CheckDF.STORE_DATE_TIME,7,6))  \
.withColumn("tandem_tstmp",FBE_CheckDF.TANDEM_TIMESTEMP) \
.withColumn("account_number" ,FBE_CheckDF.ACCOUNT_NUM) \
.withColumn("txn_id",lit("0")) \
.withColumn("approved_amount", lpad(FBE_CheckDF.APPROVED_AMOUNT,7,'0')) \
.withColumn("starting_balance", lpad(FBE_CheckDF.STARTING_BALANCE,7,'0')) \
.withColumn("ending_balance", lpad(FBE_CheckDF.ENDING_BALANCE,7,'0')) \
.withColumn("transaction_amount", lpad(FBE_CheckDF.TRANSACTION_AMOUNT,7,'0')) \
.withColumn("rebate_against_amount", lpad(FBE_CheckDF.REBATE_AGAINST_AMOUNT,7,'0')) \
.withColumn("rebate_amount", lpad(FBE_CheckDF.REBATE_AMOUNT,7,'0')) 

RfmtFbeCheckDF1 = RfmtFbeCheckDF.select("txn_id","store_number","register_number","cashier_number","transaction_number","account_number","plan_id","request_type","action_type","approval_number","originator","approved_amount","starting_balance","ending_balance","vendor_id","store_date","store_time","response_code","transaction_amount","rebate_against_amount","rebate_amount","rebate_type","user_id","tandem_tstmp")

# COMMAND ----------

#This logic is writtem for cmd 18 for last column create_dttm.

var_create_dttm = WcardTandemCreateDttmLkpDF.filter(WcardTandemCreateDttmLkpDF.create_dttm_key=="Create_Tandem_DTTM").select("create_dttm").collect()

if len(var_create_dttm)!=0:
  var_create_dttm = var_create_dttm[0].create_dttm
else:
  var_create_dttm = None

# COMMAND ----------

#RFT: Convert to PRFL TXN Table
RFT_Convert_to_PRFL_TXN_Table_DF = RfmtFbeCheckDF1.withColumn("tandem_txn_dt",(substring(RfmtFbeCheckDF1.tandem_tstmp,1,10).cast(DateType())))  \
.withColumn("tandem_txn_tm",concat(substring(RfmtFbeCheckDF1.tandem_tstmp,12,2),lit(":"),(substring(RfmtFbeCheckDF1.tandem_tstmp,15,2)),lit(":"),(substring(RfmtFbeCheckDF1.tandem_tstmp,18,5)))) \
.withColumn("tandem_txn_nbr",RfmtFbeCheckDF1.transaction_number)  \
.withColumn("tandem_req_type",RfmtFbeCheckDF1.request_type)  \
.withColumn("tandem_actn_type",RfmtFbeCheckDF1.action_type)  \
.withColumn("tandem_aprv_nbr",RfmtFbeCheckDF1.approval_number)  \
.withColumn("tandem_orig",RfmtFbeCheckDF1.originator)  \
.withColumn("tandem_aprv_dlrs",RfmtFbeCheckDF1.approved_amount)  \
.withColumn("tandem_response_cd",RfmtFbeCheckDF1.response_code)  \
.withColumn("tandem_user_id",RfmtFbeCheckDF1.user_id)  \
.withColumn("tandem_rbt_type",RfmtFbeCheckDF1.rebate_type)  \
.withColumn("tandem_cashier_nbr",RfmtFbeCheckDF1.cashier_number)  \
.withColumn("tandem_starting_bal_dlrs",RfmtFbeCheckDF1.starting_balance)  \
.withColumn("tandem_end_bal_dlrs",RfmtFbeCheckDF1.ending_balance)  \
.withColumn("str_nbr",RfmtFbeCheckDF1.store_number)  \
.withColumn("register_nbr",RfmtFbeCheckDF1.register_number)  \
.withColumn("profile_id",RfmtFbeCheckDF1.plan_id)  \
.withColumn("tandem_txn_dlrs",RfmtFbeCheckDF1.transaction_amount)  \
.withColumn("acct_id",RfmtFbeCheckDF1.account_number)  \
.withColumn("tandem_rbt_against_dlrs",RfmtFbeCheckDF1.rebate_against_amount)  \
.withColumn("prog_id",lpad(RfmtFbeCheckDF1.vendor_id,5,'0'))  \
.withColumn("tandem_str_txn_tm",concat(substring(RfmtFbeCheckDF1.store_time,1,2),lit(":"),(substring(RfmtFbeCheckDF1.store_time,3,2)),lit(":"),(substring(RfmtFbeCheckDF1.store_time,5,2)))) \
.withColumn("txn_id",RfmtFbeCheckDF1.txn_id) \
.withColumn("tandem_str_txn_dt",RfmtFbeCheckDF1.store_date) \
.withColumn("tandem_rbt_dlrs", when(((RfmtFbeCheckDF1.rebate_type=='A')|(RfmtFbeCheckDF1.rebate_type=='X')),RfmtFbeCheckDF1.rebate_amount).otherwise(lit(None)))  \
.withColumn("tandem_rbt_pctg", when((RfmtFbeCheckDF1.rebate_type=='P'),RfmtFbeCheckDF1.rebate_amount).otherwise(lit(None))) \
.withColumn("txn_type_cd",lit(' ')) \
.withColumn("create_dttm",lit(var_create_dttm))\
.withColumn('tandem_clnt_name',lit(''))

# COMMAND ----------

#Filter invalid Req Type
#Filters data records according to a specified DML expression.

Filter_invalid_Req_Type_DF = RFT_Convert_to_PRFL_TXN_Table_DF.filter((RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "C") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "F") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "H") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "I") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "L"))

Filter_valid_Req_Type_DF = RFT_Convert_to_PRFL_TXN_Table_DF.subtract(Filter_invalid_Req_Type_DF)

## Filter by Valid Combination
##True condition
Filter_valid_Comb_DF=Filter_valid_Req_Type_DF.filter(((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='A') &(col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='D')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='D')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='D')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='S')) | ((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='S')) | ((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='X')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='X')) | ((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Y')))

Filter_valid_Comb_DF1 = Filter_valid_Comb_DF.withColumn('create_dttm',col('create_dttm').cast(TimestampType())).select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd','create_dttm')

#display(Filter_valid_Comb_DF1)

# COMMAND ----------

##False condition
Filter_invalid_Comb_DF = Filter_valid_Req_Type_DF.subtract(Filter_valid_Comb_DF).select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd','create_dttm')

#Gather the invalid records 
# Writing to Invalid file
Filter_invalid_Req_Type_DF = Filter_invalid_Req_Type_DF.select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd',col('create_dttm').cast(TimestampType()))

Filter_invalid_df=Filter_invalid_Comb_DF.unionByName(Filter_invalid_Req_Type_DF).select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd',col('create_dttm').cast(TimestampType()))

CT_COM_ACTN_REQ_INVALID=mountPoint + '/' + Reject_Folder + '/' + dbutils.widgets.get('PAR_CT_COMBINED_ACTN_REQ_TYPE_REJECT') + '/' + Batch_Id
#Filter_invalid_df.write.format('parquet').mode("overwrite").save(CT_COM_ACTN_REQ_INVALID)

## RFT logic
REQ_Reject_RFT_df = Filter_invalid_df.select(col('acct_id').alias('account_num'),col('profile_id').alias('plan_id'),col('prog_id').alias('vendor_id'),concat(col('tandem_txn_dt'),lit(' '),col('tandem_txn_tm')).alias('tandem_timestamp'),concat(col('tandem_str_txn_dt'),lit(' '),col('tandem_str_txn_tm')).alias('store_date_time'),col('tandem_txn_nbr').alias('transaction'),col('register_nbr').alias('register_num'),col('str_nbr').alias('store_num'),col('tandem_req_type').alias('request_type'),col('tandem_actn_type').alias('action_type'),'create_dttm')

CT_COM_REQ_INVALID=mountPoint + '/' + Reject_Folder + '/' + CTCombinedReqTypeRej + '/' + Batch_Id
#REQ_Reject_RFT_df.write.format('parquet').mode("overwrite").save(CT_COM_REQ_INVALID)

# COMMAND ----------

#Defining schema for wcard_prev_rejected_type_recycle_txn.dat file:
Source_Schema2 = ['txn_id',
                 'acct_id',
                 'profile_id',
                 'prog_id',
                 'tandem_txn_dt',
                 'tandem_txn_tm',
                 'tandem_str_txn_dt',
                 'tandem_txn_nbr',
                 'register_nbr',
                 'str_nbr',
                 'tandem_str_txn_tm',
                 'tandem_cashier_nbr',
                 'tandem_req_type',
                 'tandem_actn_type',
                 'tandem_aprv_nbr',
                 'tandem_orig',
                 'tandem_aprv_dlrs',
                 'tandem_response_cd',
                 'tandem_rbt_type',
                 'tandem_rbt_dlrs',
                 'tandem_rbt_pctg',
                 'tandem_rbt_against_dlrs',
                 'tandem_starting_bal_dlrs',
                 'tandem_end_bal_dlrs',
                 'tandem_txn_dlrs',
                 'tandem_clnt_name',
                 'tandem_user_id',
                 'txn_type_cd',
                 'create_dttm']

schema2 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema2)))
#print(schema2)

# COMMAND ----------

##Read Previoud Day File
Prev_CT_COM_ACTN_REQ_PATH = mountPoint + '/' + Reject_Folder + '/' +dbutils.widgets.get('PAR_PREV_CT_COMBINED_ACTN_REQ_TYPE_REJECT') + ".dat"

PREV_CT_COM_ACTN_REQ_DF = spark.read.format("csv").option("delimiter","|").schema(schema2).load(Prev_CT_COM_ACTN_REQ_PATH)

##Join Previous day file and Valid combination data and apply sort
CT_COM_DF=Filter_valid_Comb_DF1.union(PREV_CT_COM_ACTN_REQ_DF)

## wcard_program_profile_unload Read
#wcard_pgm_prof_unload=mountPoint + '/' + Staging_Folder + '/' +WcardProgAcctProfUnload + '/' + Batch_Id

WCARD_PGM_ACC_PROF_UNLOAD_DF = Wcard_Program_Account_Profile_Join_DF
#display(WCARD_PGM_ACC_PROF_UNLOAD_DF)

# COMMAND ----------

### Join Code 

WCARD_PGM_ACC_JOIN=CT_COM_DF.join(WCARD_PGM_ACC_PROF_UNLOAD_DF,on = [trim(CT_COM_DF.acct_id).cast(StringType())==trim(WCARD_PGM_ACC_PROF_UNLOAD_DF.acct_id).cast(StringType()),
                                                                    trim(CT_COM_DF.profile_id).cast(IntegerType())==trim(WCARD_PGM_ACC_PROF_UNLOAD_DF.profile_id).cast(IntegerType()),
                                                                    trim(CT_COM_DF.prog_id).cast(IntegerType())==trim(WCARD_PGM_ACC_PROF_UNLOAD_DF.prog_id).cast(IntegerType())],how = 'left_outer').select(CT_COM_DF['*'],WCARD_PGM_ACC_PROF_UNLOAD_DF['acct_profile_stat_cd'])

WCARD_PGM_ACC_JOIN_Dedup=WCARD_PGM_ACC_JOIN.sort(['acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm']).dropDuplicates(['acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm'])

WCARD_PGM_ACC_JOIN1=WCARD_PGM_ACC_JOIN_Dedup.withColumn('tandem_bal_temp',(col('tandem_end_bal_dlrs').cast(IntegerType()))-(col('tandem_starting_bal_dlrs').cast(IntegerType())))\
.withColumn('txn_type_cd',when((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S')) & (col('tandem_actn_type')=='X'),'IA')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='R')) & (col('tandem_actn_type')=='S'),'FR')\
.when((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'),'DL')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='J') | (col('tandem_actn_type')=='K')),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_actn_type')=='W')) & ((col('tandem_actn_type')=='I')),'IA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())>0),'FA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())<0),'FR')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())==0),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='D'),'DL')\
.when(col('tandem_req_type')=='O','MM')\
.when((col('tandem_req_type')=='E') & ((col('tandem_actn_type')=='B') | (col('tandem_actn_type')=='F') | (col('tandem_actn_type')=='M') | (col('tandem_actn_type')=='N') | (col('tandem_actn_type')=='O') | (col('tandem_actn_type')=='P') | (col('tandem_actn_type')=='Q') | (col('tandem_actn_type')=='T') | (col('tandem_actn_type')=='V') | (col('tandem_actn_type')=='Z')),'MM')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A'),'FR')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd')=='AC') & (~(col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0))),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd')=='AC') & (col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0)),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd')=='IA') & (~(col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0))),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd')=='IA') & (col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0)),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd').isNull()) & (col('tandem_aprv_dlrs').isNotNull()),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd').isNull()) & (col('tandem_aprv_dlrs').isNull()),col('txn_type_cd'))).drop('tandem_bal_temp')                                   

# Write Duplicates 
CT_COMBINED_DUPLICATES=WCARD_PGM_ACC_JOIN.subtract(WCARD_PGM_ACC_JOIN_Dedup)

ct_combined_dup=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_CT_COMBINED_DUP') + '/' + Batch_Id
#CT_COMBINED_DUPLICATES.write.format('parquet').mode("overwrite").save(ct_combined_dup)

# COMMAND ----------

from pyspark.sql.window import Window
wspec = Window.partitionBy(col('acct_id'),col('profile_id'),col('prog_id')).orderBy(col('tandem_txn_dt'),col('tandem_txn_tm'))
WCARD_PGM_ACC_SCAN = WCARD_PGM_ACC_JOIN1.withColumn('group_change_key',row_number().over(wspec)) \
.withColumn('temp_acct_profile_stat_cd',
            when(((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A')) & col('acct_profile_stat_cd').isNull(),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S')) & (col('tandem_actn_type')=='X'),'IA')\
.when(((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S')) & col('acct_profile_stat_cd').isNull(),'AC')\
.when((((col('tandem_req_type')=='A') |  (col('tandem_req_type')=='R')) & (col('tandem_actn_type')=='S')) & col('acct_profile_stat_cd').isNull(),'AC')\
.when((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'),'DL')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') |  (col('tandem_req_type')=='S') |  (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='I'),'IA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('acct_profile_stat_cd').isNull()),'AC')\
.when(((col('tandem_req_type')=='A') |  (col('tandem_req_type')=='S') |  (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='D'),'DL')\
.when(((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A')) & (col('acct_profile_stat_cd').isNull()),'AC')\
.when(((col('tandem_req_type')=='A') |  (col('tandem_req_type')=='E') |  (col('tandem_req_type')=='S') |  (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')),'AC'))\
.withColumn('acct_profile_stat_cd',last(col('temp_acct_profile_stat_cd'),True).over(wspec))\
.withColumn('tandem_bal_temp',(col('tandem_end_bal_dlrs').cast(IntegerType()))-(col('tandem_starting_bal_dlrs').cast(IntegerType())))\
.withColumn('temp_txn_type_cd',when((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S')) & (col('tandem_actn_type')=='X'),'IA')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='R')) & (col('tandem_actn_type')=='S'),'FR')\
.when((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'),'DL')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='J') | (col('tandem_actn_type')=='K')),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='I'),'IA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())>0),'FA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())<0),'FR')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())==0),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='D'),'DL')\
.when(col('tandem_req_type')=='O','MM')\
.when((col('tandem_req_type')=='E') & ((col('tandem_actn_type')=='B') | (col('tandem_actn_type')=='F') | (col('tandem_actn_type')=='M') | (col('tandem_actn_type')=='N') | (col('tandem_actn_type')=='O') | (col('tandem_actn_type')=='P') | (col('tandem_actn_type')=='Q') | (col('tandem_actn_type')=='T') | (col('tandem_actn_type')=='V') | (col('tandem_actn_type')=='Z')),'MM')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A'),'FR')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('temp_acct_profile_stat_cd')=='AC') & (~(col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0))),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('temp_acct_profile_stat_cd')=='AC') & ((col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0))),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('temp_acct_profile_stat_cd')=='IA') & (~(col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0))),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('temp_acct_profile_stat_cd')=='IA') & ((col('tandem_aprv_dlrs').cast(IntegerType()).eqNullSafe(0))),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('temp_acct_profile_stat_cd').isNull()) & (col('tandem_aprv_dlrs').isNotNull()),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('temp_acct_profile_stat_cd').isNull()) & (col('tandem_aprv_dlrs').isNull()),col('txn_type_cd')))\
.withColumn('txn_type_cd',last(col('temp_txn_type_cd'),True).over(wspec))\
.drop('temp_acct_profile_stat_cd','tandem_bal_temp','temp_txn_type_cd')

#display(WCARD_PGM_ACC_SCAN)
#print(WCARD_PGM_ACC_SCAN.count())

# COMMAND ----------

#Defined TXN_TYPE_CD  only

WCARD_TXN_REF_TABLES_DF =WCARD_PGM_ACC_SCAN.filter(col('txn_type_cd').isNotNull())

##WCARD TRANSACTION FILE

WCARD_TXN_DF=WCARD_TXN_REF_TABLES_DF.withColumn('prog_id',lpad(col('prog_id'),5,'0')).drop('acct_profile_stat_cd','group_change_key','txn_id') \
.withColumn("tandem_str_txn_dt",concat(lit("20"),substring(WCARD_TXN_REF_TABLES_DF.tandem_str_txn_dt,1,2),lit("-"),substring(WCARD_TXN_REF_TABLES_DF.tandem_str_txn_dt,3,2),lit("-"),substring(WCARD_TXN_REF_TABLES_DF.tandem_str_txn_dt,5,2))) \
.withColumn("tandem_rbt_dlrs",col("tandem_rbt_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_rbt_against_dlrs",col("tandem_rbt_against_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_aprv_dlrs_1",regexp_replace('tandem_aprv_dlrs', r'^[0]*', '')) \
.withColumn("tandem_starting_bal_dlrs_1",regexp_replace('tandem_starting_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_end_bal_dlrs_1",regexp_replace('tandem_end_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_txn_dlrs_1",regexp_replace('tandem_txn_dlrs', r'^[0]*', ''))

WCARD_TXN_DF = WCARD_TXN_DF.withColumn("tandem_aprv_dlrs",when((length(trim(col("tandem_aprv_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,1))).when((length(trim(col("tandem_aprv_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,2,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_starting_bal_dlrs",when((length(trim(col("tandem_starting_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,1))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,2,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_end_bal_dlrs",when((length(trim(col("tandem_end_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,1))).when((length(trim(col("tandem_end_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,2,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_txn_dlrs",when((length(trim(col("tandem_txn_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,1))).when((length(trim(col("tandem_txn_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,2))).when((length(trim(col("tandem_txn_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,2,2))).when((length(trim(col("tandem_txn_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,3,2))).otherwise(lit("0.00"))).drop("tandem_aprv_dlrs_1","tandem_starting_bal_dlrs_1","tandem_end_bal_dlrs_1","tandem_txn_dlrs_1")
#display(WCARD_TXN_DF)
#print(WCARD_TXN_DF.count())
wcard_txn=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TXN') + '/' + Batch_Id
WCARD_TXN_DF.write.format('parquet').mode("overwrite").save(wcard_txn)

# COMMAND ----------

## WCARD ACCOUNT PROFILE STATUS

WCARD_ACCOUNT_PROFILE_STATUS_DF=WCARD_TXN_REF_TABLES_DF.filter((col('txn_type_cd')=='AC') | (col('txn_type_cd')=='IA') | (col('txn_type_cd')=='DL'))\
.groupBy('txn_type_cd').agg(sum(col('txn_type_cd')))\
.withColumn('acct_profile_stat_desc',when(col('txn_type_cd')=='AC','ACTIVE')
           .when(col('txn_type_cd')=='IA','INACTIVE')
           .when(col('txn_type_cd')=='DL','DELETED')
           .otherwise('Unknown'))\
.withColumn('acct_profile_stat_cd',col('txn_type_cd')).select('acct_profile_stat_cd','acct_profile_stat_desc')\

wcard_acc_prof_status=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_ACC_PROF_STATUS') + '/' + Batch_Id
#WCARD_ACCOUNT_PROFILE_STATUS_DF.write.format('parquet').mode("overwrite").save(wcard_acc_prof_status)

###Transaction Type
WCARD_TRANSACTION_TYPE_DF=WCARD_TXN_REF_TABLES_DF.groupBy('txn_type_cd').agg(sum(col('txn_type_cd')))\
.withColumn('txn_type_desc',when(col('txn_type_cd')=='AC','ACTIVATION').when(col('txn_type_cd')=='DL','DELETION')\
.when(col('txn_type_cd')=='IA','INACTIVATION').when(col('txn_type_cd')=='FA','FUNDS ADDED')\
.when(col('txn_type_cd')=='FR','FUNDS REMOVED').when(col('txn_type_cd')=='MM','MEMO').otherwise('unknown'))\
.select('txn_type_cd','txn_type_desc')

wcard_txn_type=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TXN_TYPE') + '/' + Batch_Id
#WCARD_TRANSACTION_TYPE_DF.write.format('parquet').mode("overwrite").save(wcard_txn_type)

## WCARD TANDEM ORIGINATOR
WCARD_TNDM_ORIG_DF=WCARD_TXN_REF_TABLES_DF.groupBy('tandem_orig').agg(sum(col('tandem_orig')))\
.withColumn('tandem_orig_desc',when(col('tandem_orig')=='M','Stores: Manual').when(col('tandem_orig')=='S','Stores: Swiped')\
.when(col('tandem_orig')=='F','Stores: Force Post').when(col('tandem_orig')=='I','POS Online CRDT - Intranet')\
.when(col('tandem_orig')=='L','Batch File').when(col('tandem_orig')=='C','eCommerce')\
.when(col('tandem_orig')=='E','Web Services').when(col('tandem_orig')=='T','Tandem').otherwise('Unknown'))\
.select('tandem_orig','tandem_orig_desc')

wcard_tndm_orig=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TANDEM_ORIG') + '/' + Batch_Id
#WCARD_TNDM_ORIG_DF.write.format('parquet').mode("overwrite").save(wcard_tndm_orig)

## WCARD TANDEM REBATE TYPE
WCARD_TNDM_REB_TYPE_DF=WCARD_TXN_REF_TABLES_DF.groupBy('tandem_rbt_type').agg(sum(col('tandem_rbt_type')))\
.withColumn('tandem_rbt_type_desc',when(col('tandem_rbt_type')=='A','Fixed Amount')\
.when(col('tandem_rbt_type')=='P','Percentage').when(col('tandem_rbt_type')=='X','Invalid').otherwise('Unknown'))\
.select('tandem_rbt_type','tandem_rbt_type_desc')

wcard_tndm_reb_type=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TANDEM_REBATE_TYPE') + '/' + Batch_Id
#WCARD_TNDM_REB_TYPE_DF.write.format('parquet').mode("overwrite").save(wcard_tndm_reb_type)

##WCARD TANDEM ACTION TYPE
WCARD_TNDM_ACTION_TYPE_DF=WCARD_TXN_REF_TABLES_DF.groupBy('tandem_actn_type').agg(sum(col('tandem_actn_type')))\
.withColumn('tandem_actn_type_desc',when(col('tandem_actn_type')=='A','Add Amount to Plan / Activate Plan')\
.when(col('tandem_actn_type')=='B','Cancel Enrollment Request').when(col('tandem_actn_type')=='C','Activate (Old Action)')\
.when(col('tandem_actn_type')=='D','Plan Delete Request').when(col('tandem_actn_type')=='E','Expire Enrollment Request')
.when(col('tandem_actn_type')=='I','Inactivate Plan').when(col('tandem_actn_type')=='J','Activate Card')
.when(col('tandem_actn_type')=='K','Deactivate Card').when(col('tandem_actn_type')=='M','Enrollment Renewal Request')\
.when(col('tandem_actn_type')=='N','Enrollment Refund Request').when(col('tandem_actn_type')=='O','Upgrade Enrollment Request')
.when(col('tandem_actn_type')=='P','Plan Enrolled – Savings Program').when(col('tandem_actn_type')=='Q','Customer Enrolled Paid Request')
.when(col('tandem_actn_type')=='R','Replace Card Request').when(col('tandem_actn_type')=='S','Subtract Amount from Plan')
.when(col('tandem_actn_type')=='T','Enrollment Renewal Paid Request').when(col('tandem_actn_type')=='U','Upload Records from File')
.when(col('tandem_actn_type')=='V','Enrollment Upgrade Paid Request').when(col('tandem_actn_type')=='Z','Enrollment Declined by Customer')\
.when(col('tandem_actn_type')=='X','Deplete / Deactivate Plan').otherwise('Unknown'))\
.select('tandem_actn_type','tandem_actn_type_desc')

wcard_tndm_action_type=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TANDEM_ACTION_TYPE') + '/' + Batch_Id
#WCARD_TNDM_ACTION_TYPE_DF.write.format('parquet').mode("overwrite").save(wcard_tndm_action_type)

##WCARD TANDEM REQUEST TYPE
WCARD_TNDM_REQ_TYPE_DF=WCARD_TXN_REF_TABLES_DF.groupBy('tandem_req_type').agg(sum(col('tandem_req_type')))\
.withColumn('tandem_req_type_desc',when(col('tandem_req_type')=='A','Plan Update')\
.when(col('tandem_req_type')=='O','Admin / Miscellaneous Update (Non Plan Update)').when(col('tandem_req_type')=='I','Inquiry')\
.when(col('tandem_req_type')=='L','Logon').when(col('tandem_req_type')=='V','Void of Transaction')
.when(col('tandem_req_type')=='R','Reverse (Communication Error)').when(col('tandem_req_type')=='C','Reverse (Controller Generated Reversal)')
.when(col('tandem_req_type')=='H','Account History').when(col('tandem_req_type')=='S','Loader Process')\
.when(col('tandem_req_type')=='E','Enrollment').when(col('tandem_req_type')=='F','Forced Post')
.when(col('tandem_req_type')=='W','WCARD Replacement Request').otherwise('Unknown'))\
.select('tandem_req_type','tandem_req_type_desc')

wcard_tndm_req_type=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TANDEM_REQ_TYPE') + '/' + Batch_Id
#WCARD_TNDM_REQ_TYPE_DF.write.format('parquet').mode("overwrite").save(wcard_tndm_req_type)

##WCARD TANDEM RESPONSE
WCARD_TNDM_RESPONSE_DF=WCARD_TXN_REF_TABLES_DF.groupBy('tandem_response_cd').agg(sum(col('tandem_response_cd')))\
.withColumn('tandem_response_cd_desc',when(col('tandem_response_cd')=='120','Gift Card Restriction Error (CLDR)')\
.when(col('tandem_response_cd')=='121','LPC/Vendor Add Error (CLDR)')\
.when(col('tandem_response_cd')=='400','Default Approval Code (CRDT')\
.when(col('tandem_response_cd')=='401','New CRDT Account Added')\
.when(col('tandem_response_cd')=='402','Request Amount > Available Amount')
.when(col('tandem_response_cd')=='403','Transaction Done from Tandem Maintenance Screen')\
.when(col('tandem_response_cd')=='404','Default Approval Code (CLDR)')
.when(col('tandem_response_cd')=='405','Plan Active as Family')
.when(col('tandem_response_cd')=='406','Plan Active as Individual')\
.when(col('tandem_response_cd')=='407','Approved Reload (CLDR/CRDT)')
.when(col('tandem_response_cd')=='408','Successful Redemption (CRDT)')
.when(col('tandem_response_cd')=='409','Successful Activation (CLDR)')
.when(col('tandem_response_cd')=='410','Successful Reactivation (CLDR)')
.when(col('tandem_response_cd')=='484','Conversion Table Error (CRDT)')
.when(col('tandem_response_cd')=='485','Gift Card Restriction Error (CRDT)').otherwise('Unknown'))\
.select('tandem_response_cd','tandem_response_cd_desc')

wcard_tndm_response=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TANDEM_RESPONSE') + '/' + Batch_Id
#WCARD_TNDM_RESPONSE_DF.write.format('parquet').mode("overwrite").save(wcard_tndm_response)

# COMMAND ----------

### FBE NON-FINANCIAL TXN

FILTER_NON_FINAN_TXN=WCARD_PGM_ACC_SCAN.filter(~(((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K'))))

##Last Transaction Filter
FILTER_NON_FINAN_TXN1 = FILTER_NON_FINAN_TXN.withColumn("txn_type_cd",coalesce(FILTER_NON_FINAN_TXN.txn_type_cd,lit(" ")))

LAST_TRANS_DF=FILTER_NON_FINAN_TXN1.filter(~(col('txn_type_cd').eqNullSafe('MM')))\
.filter(~(((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='I'))))
## Program  Account Profile Filter

PGM_ACC_DF=FILTER_NON_FINAN_TXN.filter(~(((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') &(col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K')))).filter(col('acct_profile_stat_cd').isNotNull())

# COMMAND ----------

#WCARD LAST TRANSACTION (TANDEM TABLE)
wspec1 = Window.partitionBy(col('acct_id'),col('profile_id'),col('prog_id')).orderBy(col('acct_id'),col('profile_id'),col('prog_id'))
WCARD_LAST_TXN_ROLLUP_DF = LAST_TRANS_DF.withColumn('group_change_key',max(col('group_change_key')).over(wspec1)) \
.filter(col('txn_type_cd').isNotNull()) 

for c in WCARD_LAST_TXN_ROLLUP_DF.columns:
  WCARD_LAST_TXN_ROLLUP_DF = WCARD_LAST_TXN_ROLLUP_DF.withColumnRenamed(c,c + '_left')

WCARD_LAST_JOIN_DF = WCARD_LAST_TXN_ROLLUP_DF.join(FILTER_NON_FINAN_TXN,on = [trim(WCARD_LAST_TXN_ROLLUP_DF.acct_id_left).cast(StringType())==trim(FILTER_NON_FINAN_TXN.acct_id).cast(StringType()),
                                                                             trim(WCARD_LAST_TXN_ROLLUP_DF.profile_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.profile_id).cast(IntegerType()),
                                                                             trim(WCARD_LAST_TXN_ROLLUP_DF.prog_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.prog_id).cast(IntegerType()),
                                                                             (WCARD_LAST_TXN_ROLLUP_DF.group_change_key_left)==(FILTER_NON_FINAN_TXN.group_change_key)],how = 'inner').select(FILTER_NON_FINAN_TXN['*'],WCARD_LAST_TXN_ROLLUP_DF.group_change_key_left.alias("group_change_key")).drop(FILTER_NON_FINAN_TXN.group_change_key)

#display(WCARD_LAST_JOIN_DF)

#LKP with wcard_last_transaction
WCARD_LAST_LKP_JOIN_DF = WCARD_LAST_JOIN_DF.join(Wcard_Last_Transaction_Join_DF,on = [trim(WCARD_LAST_JOIN_DF.acct_id).cast(StringType())==trim(Wcard_Last_Transaction_Join_DF.acct_id).cast(StringType()),
                                                                               trim(WCARD_LAST_JOIN_DF.profile_id).cast(IntegerType())==trim(Wcard_Last_Transaction_Join_DF.profile_id).cast(IntegerType()),
                                                                               trim(WCARD_LAST_JOIN_DF.prog_id).cast(IntegerType())==trim(Wcard_Last_Transaction_Join_DF.prog_id).cast(IntegerType())], how = 'left_outer')

# COMMAND ----------

#Filter Condition True in Join ##FBE Valid entry in wcard_last_transaction

WCARD_LAST_LKP_JOIN_FIL_DF=WCARD_LAST_LKP_JOIN_DF.filter((Wcard_Last_Transaction_Join_DF.acct_id.isNotNull()) & (Wcard_Last_Transaction_Join_DF.profile_id.isNotNull()) & (Wcard_Last_Transaction_Join_DF.prog_id.isNotNull())).distinct() \
.filter(datediff(to_date(Wcard_Last_Transaction_Join_DF.tandem_txn_dt),to_date(WCARD_LAST_JOIN_DF.tandem_txn_dt))<0).select(WCARD_LAST_JOIN_DF['*'])

###Filter Condition False in Join ##FBE Valid entry in wcard_last_transaction
WCARD_LAST_LKP_JOIN_FALSE_DF=WCARD_LAST_LKP_JOIN_DF.filter((Wcard_Last_Transaction_Join_DF.acct_id.isNull()) & (Wcard_Last_Transaction_Join_DF.profile_id.isNull()) & (Wcard_Last_Transaction_Join_DF.prog_id.isNull())).select(WCARD_LAST_JOIN_DF['*']).distinct()

##Gather component
WCARD_LAST_TXN_GATHER_DF=WCARD_LAST_LKP_JOIN_FIL_DF.unionByName(WCARD_LAST_LKP_JOIN_FALSE_DF)
#print(WCARD_LAST_TXN_GATHER_DF.count())

WCARD_LAST_TXN_GATHER_DF = WCARD_LAST_TXN_GATHER_DF.withColumn("tandem_str_txn_dt",concat(lit("20"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_str_txn_dt,1,2),lit("-"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_str_txn_dt,3,2),lit("-"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_str_txn_dt,5,2))) \
.withColumn("tandem_rbt_dlrs",col("tandem_rbt_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_rbt_against_dlrs",col("tandem_rbt_against_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_aprv_dlrs_1",regexp_replace('tandem_aprv_dlrs', r'^[0]*', '')) \
.withColumn("tandem_starting_bal_dlrs_1",regexp_replace('tandem_starting_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_end_bal_dlrs_1",regexp_replace('tandem_end_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_txn_dlrs_1",regexp_replace('tandem_txn_dlrs', r'^[0]*', ''))

WCARD_LAST_TXN_GATHER_DF = WCARD_LAST_TXN_GATHER_DF.withColumn("tandem_aprv_dlrs",when((length(trim(col("tandem_aprv_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,1))).when((length(trim(col("tandem_aprv_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,2,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_starting_bal_dlrs",when((length(trim(col("tandem_starting_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,1))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,2,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_end_bal_dlrs",when((length(trim(col("tandem_end_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,1))).when((length(trim(col("tandem_end_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,2,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_txn_dlrs",when((length(trim(col("tandem_txn_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,1))).when((length(trim(col("tandem_txn_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,2))).when((length(trim(col("tandem_txn_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,2,2))).when((length(trim(col("tandem_txn_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,3,2))).otherwise(lit("0.00"))).drop("tandem_aprv_dlrs_1","tandem_starting_bal_dlrs_1","tandem_end_bal_dlrs_1","tandem_txn_dlrs_1")

# COMMAND ----------

##FBE W/R
WCARD_FBE_LAST_TXN=WCARD_LAST_TXN_GATHER_DF.filter((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'))

for c in WCARD_FBE_LAST_TXN.columns:
  WCARD_FBE_LAST_TXN = WCARD_FBE_LAST_TXN.withColumnRenamed(c, c+'_left')

#Join Inner
WCARD_JOIN_LAST_TXN_DF=WCARD_FBE_LAST_TXN.join(WCARD_LAST_TXN_GATHER_DF,trim(WCARD_FBE_LAST_TXN.acct_id_left).cast(StringType())==trim(WCARD_LAST_TXN_GATHER_DF.acct_id).cast(StringType()),'inner').select(WCARD_LAST_TXN_GATHER_DF['*']).distinct()

##wcard_last_transaction_delete_lkp
wcard_last_txn_del_lkp=mountPoint + '/' + Lookup_Folder + '/' + dbutils.widgets.get('PAR_WCARD_LAST_TXN_DEL_LKP') + '/' + Batch_Id
WCARD_JOIN_LAST_TXN_DF.cache()

WCARD_JOIN_LAST_TXN_DF.write.format('parquet').mode("overwrite").save(wcard_last_txn_del_lkp)

##FBE only W/R

WCARD_STATUS_DEL_LKP_DF=WCARD_JOIN_LAST_TXN_DF.filter((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R')).distinct()

##wcard_profile_status_delete_eff_dt_lkp

wcard_last_txn_sts_lkp=mountPoint + '/' + Lookup_Folder + '/' + dbutils.widgets.get('PAR_WCARD_STATUS_DEL_LKP') + '/' + Batch_Id
WCARD_STATUS_DEL_LKP_DF.write.format('parquet').mode("overwrite").save(wcard_last_txn_sts_lkp)

## left  outer join
WCARD_LAST_TXN_FINAL=WCARD_LAST_TXN_GATHER_DF.join(WCARD_FBE_LAST_TXN,WCARD_FBE_LAST_TXN.acct_id_left==WCARD_LAST_TXN_GATHER_DF.acct_id,'left_anti').drop("txn_id","acct_profile_stat_cd","group_change_key").distinct()

WCARD_LAST_TXN_FINAL = WCARD_LAST_TXN_FINAL.select('acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','str_nbr','register_nbr','tandem_txn_nbr','tandem_str_txn_dt','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd','create_dttm')

##WCARD_LAST_TRANSACTION
wcard_last_txn=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_LAST_TRANSACTION') + '/' + Batch_Id
WCARD_LAST_TXN_FINAL.write.format('parquet').mode("overwrite").save(wcard_last_txn)

# COMMAND ----------

### WCARD PROGRAM ACCOUNT PROFILE
##Program Account Filter
PGM_ACC_FILTER=FILTER_NON_FINAN_TXN1.filter(~(((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') &(col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K')))).filter(col('acct_profile_stat_cd').isNotNull())

PGM_ACC_ROLLUP_DF=PGM_ACC_FILTER.withColumn('group_change_key',max(col('group_change_key')).over(wspec1))

for c in PGM_ACC_ROLLUP_DF.columns:
  PGM_ACC_ROLLUP_DF = PGM_ACC_ROLLUP_DF.withColumnRenamed(c,c+'_left')

# COMMAND ----------

## Join 4

PGM_ACC_JOIN_DF=PGM_ACC_ROLLUP_DF.join(PGM_ACC_FILTER,on =[trim(PGM_ACC_ROLLUP_DF.acct_id_left).cast(StringType())==trim(PGM_ACC_FILTER.acct_id).cast(StringType()), trim(PGM_ACC_ROLLUP_DF.profile_id_left).cast(IntegerType())==trim(PGM_ACC_FILTER.profile_id).cast(IntegerType()), trim(PGM_ACC_ROLLUP_DF.prog_id_left).cast(IntegerType())==trim(PGM_ACC_FILTER.prog_id).cast(IntegerType()),(PGM_ACC_ROLLUP_DF.group_change_key_left)==(PGM_ACC_FILTER.group_change_key)],how='inner').select(PGM_ACC_FILTER['*'],PGM_ACC_ROLLUP_DF.group_change_key_left.alias("group_change_key")).drop(PGM_ACC_FILTER.group_change_key).distinct()

#OLD TANDEM TS LKP with Program Account Profile
PGM_OLD_TANDEM_JOIN_DF=PGM_ACC_JOIN_DF.join(Wcard_Program_Account_Profile_Join_DF,[trim(PGM_ACC_JOIN_DF.acct_id).cast(StringType())==trim(Wcard_Program_Account_Profile_Join_DF.acct_id).cast(StringType()),
                                                                              (PGM_ACC_JOIN_DF.profile_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.profile_id).cast(IntegerType()), trim(PGM_ACC_JOIN_DF.prog_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.prog_id).cast(IntegerType())],how = 'left_outer')

###Filter Condition True in Join ##FBE Valid entry in Program Account Profile

PGM_OLD_TANDEM_TRUE_DF=PGM_OLD_TANDEM_JOIN_DF.filter((Wcard_Program_Account_Profile_Join_DF.acct_id.isNotNull()) & (Wcard_Program_Account_Profile_Join_DF.profile_id.isNotNull()) & (Wcard_Program_Account_Profile_Join_DF.prog_id.isNotNull()))\
.filter(datediff(to_date(Wcard_Program_Account_Profile_Join_DF.prog_acct_profile_eff_dt),to_date(PGM_ACC_JOIN_DF.tandem_txn_dt))<0).select(PGM_ACC_JOIN_DF['*'])

###Filter Condition False in Join ##FBE Valid entry in Program Account Profile
PGM_OLD_TANDEM_FALSE_DF=PGM_OLD_TANDEM_JOIN_DF.filter((Wcard_Program_Account_Profile_Join_DF.acct_id.isNull()) & (Wcard_Program_Account_Profile_Join_DF.profile_id.isNull()) & (Wcard_Program_Account_Profile_Join_DF.prog_id.isNull()))\
.select(PGM_ACC_JOIN_DF['*'])

##GATHER

PGM_OLD_TANDEM_DF=PGM_OLD_TANDEM_TRUE_DF.union(PGM_OLD_TANDEM_FALSE_DF)\
.withColumn('prog_acct_profile_end_dt',lit(None)) \
.withColumn('acct_profile_stat_cd',coalesce(col("acct_profile_stat_cd"),lit("AC"))) \
.select('acct_id','profile_id',col('tandem_txn_dt').alias('prog_acct_profile_eff_dt'),(lpad(col('prog_id'),5,'0')).alias('prog_id'),'prog_acct_profile_end_dt','acct_profile_stat_cd','create_dttm')\
.filter((col('acct_profile_stat_cd').isNotNull()) & ((col('acct_profile_stat_cd')=='AC') | (col('acct_profile_stat_cd')=='IA') | (col('acct_profile_stat_cd')=='DL'))).distinct()

## Rollup Min on PGM_ACC_DF
PGM_ACC_MIN_DF=PGM_ACC_DF.withColumn('group_change_key',min(col('group_change_key')).over(wspec1)).filter(col('txn_type_cd').isNotNull())

for c in PGM_ACC_MIN_DF.columns:
  PGM_ACC_MIN_DF = PGM_ACC_MIN_DF.withColumnRenamed(c,c+'_left')

# COMMAND ----------

## JOIN 1

PGM_ACC_MIN_JOIN_DF =PGM_ACC_MIN_DF.join(FILTER_NON_FINAN_TXN,on =[trim(PGM_ACC_MIN_DF.acct_id_left).cast(StringType())==trim(FILTER_NON_FINAN_TXN.acct_id).cast(StringType()), trim(PGM_ACC_MIN_DF.profile_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.profile_id).cast(IntegerType()), 
trim(PGM_ACC_MIN_DF.prog_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.prog_id).cast(IntegerType()), 
(PGM_ACC_MIN_DF.group_change_key_left)==(FILTER_NON_FINAN_TXN.group_change_key)],how = 'inner').select(FILTER_NON_FINAN_TXN['*'],PGM_ACC_MIN_DF.group_change_key_left.alias("group_change_key")).drop(FILTER_NON_FINAN_TXN.group_change_key)

#OLD TANDEM TS LKP with Program Account Profile
PGM_OLD_TANDEM_JOIN_1_DF=PGM_ACC_MIN_JOIN_DF.join(Wcard_Program_Account_Profile_Join_DF,on =[trim(PGM_ACC_MIN_JOIN_DF.acct_id).cast(StringType())==trim(Wcard_Program_Account_Profile_Join_DF.acct_id).cast(StringType()),
                                                                                       trim(PGM_ACC_MIN_JOIN_DF.profile_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.profile_id).cast(IntegerType()), trim(PGM_ACC_MIN_JOIN_DF.prog_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.prog_id).cast(IntegerType())],how = 'left_outer')

###Filter Condition True in Join ##FBE Valid entry in Wcard Program_account_profile

PGM_OLD_TANDEM_1_TRUE_DF=PGM_OLD_TANDEM_JOIN_1_DF.filter((Wcard_Program_Account_Profile_Join_DF.acct_id.isNotNull()) & (Wcard_Program_Account_Profile_Join_DF.profile_id.isNotNull()) & (Wcard_Program_Account_Profile_Join_DF.prog_id.isNotNull())) \
.filter(datediff(to_date(Wcard_Program_Account_Profile_Join_DF.prog_acct_profile_eff_dt),to_date(PGM_ACC_MIN_JOIN_DF.tandem_txn_dt))<0).select(PGM_ACC_MIN_JOIN_DF['*'])

###Filter Condition False in Join ##FBE Valid entry in Wcard Program_account_profile
PGM_OLD_TANDEM_1_FALSE_DF=PGM_OLD_TANDEM_JOIN_1_DF.filter((Wcard_Program_Account_Profile_Join_DF.acct_id.isNull()) & (Wcard_Program_Account_Profile_Join_DF.profile_id.isNull()) & (Wcard_Program_Account_Profile_Join_DF.prog_id.isNull()))\
.select(PGM_ACC_MIN_JOIN_DF['*'])

##GATHER

PGM_OLD_TANDEM_1_DF=PGM_OLD_TANDEM_1_TRUE_DF.union(PGM_OLD_TANDEM_1_FALSE_DF).distinct()

#Renaming columns 
for i in PGM_OLD_TANDEM_1_DF.columns:
  PGM_OLD_TANDEM_1_DF=PGM_OLD_TANDEM_1_DF.withColumnRenamed(i,'OLD_'+i)

#Renaming columns 
for i in WCARD_JOIN_LAST_TXN_DF.columns:
  WCARD_JOIN_LAST_TXN_DF=WCARD_JOIN_LAST_TXN_DF.withColumnRenamed(i,'DELETED_'+i)
  
for i in WCARD_STATUS_DEL_LKP_DF.columns:
  WCARD_STATUS_DEL_LKP_DF=WCARD_STATUS_DEL_LKP_DF.withColumnRenamed(i,'DELETED_1_'+i)

# COMMAND ----------

PGM_ACC_JOIN_FINAL_DF=PGM_OLD_TANDEM_DF.join(PGM_OLD_TANDEM_1_DF,on = [trim(PGM_OLD_TANDEM_DF.acct_id).cast(StringType())==trim(PGM_OLD_TANDEM_1_DF.OLD_acct_id).cast(StringType()), trim(PGM_OLD_TANDEM_DF.profile_id).cast(IntegerType())==trim(PGM_OLD_TANDEM_1_DF.OLD_profile_id).cast(IntegerType()),
trim(PGM_OLD_TANDEM_DF.prog_id).cast(IntegerType())==trim(PGM_OLD_TANDEM_1_DF.OLD_prog_id).cast(IntegerType())],how  = 'inner')\
.select(PGM_OLD_TANDEM_DF['*'],col('OLD_tandem_txn_dt').alias('TANDEM_1_tandem_txn_dt'))

PGM_ACC_JOIN_FINAL_1_DF=PGM_ACC_JOIN_FINAL_DF.join(WCARD_JOIN_LAST_TXN_DF,on =[trim(PGM_ACC_JOIN_FINAL_DF.acct_id).cast(StringType())==trim(WCARD_JOIN_LAST_TXN_DF.DELETED_acct_id).cast(StringType())],how = 'left_outer').select(PGM_ACC_JOIN_FINAL_DF['*'],'DELETED_acct_id')\
.withColumn('temp_acct_profile_stat_cd',when((col('DELETED_acct_id').isNotNull()),lit('DL')).otherwise(lit(None)))\
.withColumn('acct_profile_stat_cd',when(col('temp_acct_profile_stat_cd').isNotNull(),col('temp_acct_profile_stat_cd')).otherwise(col('acct_profile_stat_cd'))).drop('temp_acct_profile_stat_cd')

PGM_ACC_JOIN_FINAL_LKP_DF=PGM_ACC_JOIN_FINAL_1_DF.join(WCARD_STATUS_DEL_LKP_DF,on =[(PGM_ACC_JOIN_FINAL_1_DF.acct_id).cast(StringType())==trim(WCARD_STATUS_DEL_LKP_DF.DELETED_1_acct_id).cast(StringType())],how = 'left_outer').select(PGM_ACC_JOIN_FINAL_1_DF['*'],'DELETED_1_acct_id','DELETED_1_tandem_txn_dt') \
.withColumn('prog_acct_profile_eff_dt',when(col('DELETED_1_acct_id').isNotNull(),col('DELETED_1_tandem_txn_dt')).otherwise(col('TANDEM_1_tandem_txn_dt'))).drop('TANDEM_1_tandem_txn_dt','DELETED_1_tandem_txn_dt','DELETED_1_tandem_txn_dt','DELETED_1_acct_id')

###FBE W/R
PGM_ACC_JOIN_FINAL_LKP_DF1 = PGM_ACC_JOIN_FINAL_LKP_DF.filter(col('DELETED_acct_id').isNotNull()).drop('DELETED_acct_id').distinct()
PGM_ACC_JOIN_FINAL_LKP_DF1 = WriteNullParquet(PGM_ACC_JOIN_FINAL_LKP_DF1)

## wcard_prog_acct_profile_delete_lkp
wcard_pgm_acc_del_lkp=mountPoint + '/' + Lookup_Folder + '/' + dbutils.widgets.get('PAR_WCARD_ACC_PROF_DEL_LKP') + '/' + Batch_Id
PGM_ACC_JOIN_FINAL_LKP_DF1.write.format('parquet').mode("overwrite").save(wcard_pgm_acc_del_lkp)

##FBE PROFILE_ID is 0
PGM_ACC_FINAL_DF=PGM_ACC_JOIN_FINAL_LKP_DF.filter(col('DELETED_acct_id').isNull()).drop('DELETED_acct_id')
PGM_ACC_FINAL_DF1=PGM_ACC_FINAL_DF.filter((col('profile_id').cast(IntegerType())!=0) & (col('acct_profile_stat_cd').isNotNull()) & ((trim(col('acct_profile_stat_cd'))=='AC') | (col('acct_profile_stat_cd')=='IA') | (col('acct_profile_stat_cd')=='DL'))).distinct()
PGM_ACC_FINAL_DF1 = WriteNullParquet(PGM_ACC_FINAL_DF1)

##WCARD Program Account Profile
wcard_pgm_acc=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_ACC_PROFILE') + '/' + Batch_Id
PGM_ACC_FINAL_DF1.write.format('parquet').mode("overwrite").save(wcard_pgm_acc)

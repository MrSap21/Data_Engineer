# Databricks notebook source
#Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 120)

# COMMAND ----------

# #Widgets for passing required parameters values:
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220530190731")
# dbutils.widgets.text("PAR_STAGING_FOLDER","retail/retail_sales/staging")
# dbutils.widgets.text("PAR_LOOKUP_FOLDER","retail/retail_sales/lookup")
# dbutils.widgets.text("PAR_REJECT_FOLDER","retail/retail_sales/reject")
# dbutils.widgets.text("PAR_WCARD_TANDEM_CREATE_DTTM_LKP1","wcard_tandem_create_dttm_lkp1")
# dbutils.widgets.text("PAR_WCARD_TANDEM_CREATE_DTTM_LKP","wcard_tandem_create_dttm_lkp")
# dbutils.widgets.text("PAR_CT_COMBINED_ACTN_REQ_TYPE_REJECT","wcard_rejected_type_recycle_txn")
# dbutils.widgets.text("PAR_CT_COMBINED_REQ_TYPE_REJECT","CT_COMBINED_REQ_TYPE_REJECT.rej")
# dbutils.widgets.text("PAR_WCARD_PROG_ACCT_PROF_UNLOAD","wcard_program_account_profile_unload")
# dbutils.widgets.text("PAR_WCARD_LAST_TRANS_UNLOAD","wcard_last_transaction_unload")
# dbutils.widgets.text("PAR_PREV_CT_COMBINED_ACTN_REQ_TYPE_REJECT","wcard_prev_rejected_type_recycle_txn")
# dbutils.widgets.text("PAR_CT_COMBINED_DUP","CT_COMBINED.dup")
# dbutils.widgets.text("PAR_CT_COMBINED_REJ","CT_COMBINED.rej")
# dbutils.widgets.text("PAR_WCARD_TXN","wcard_transaction")
# dbutils.widgets.text("PAR_WCARD_LAST_TXN_DEL_LKP","wcard_last_transaction_delete_lkp")
# dbutils.widgets.text("PAR_WCARD_STATUS_DEL_LKP","wcard_profile_status_delete_eff_dt_lkp")
# dbutils.widgets.text("PAR_WCARD_LAST_TRANSACTION","wcard_last_transaction")
# dbutils.widgets.text("PAR_WCARD_ACC_PROFILE","wcard_program_account_profile")
# dbutils.widgets.text("PAR_WCARD_ACC_PROF_DEL_LKP","wcard_prog_acct_profile_delete_lkp")
# dbutils.widgets.text("PAR_FEED_NAME","CT")
# dbutils.widgets.text("PAR_PREV_RECYCLE_TXN","wcard_prev_recycle_txn")

# COMMAND ----------

Staging_Folder = dbutils.widgets.get("PAR_STAGING_FOLDER")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
Batch_Id = dbutils.widgets.get("PAR_DB_BATCH_ID")
WcardProgAcctProfUnload = dbutils.widgets.get("PAR_WCARD_PROG_ACCT_PROF_UNLOAD")
WcardLastTransUnload = dbutils.widgets.get("PAR_WCARD_LAST_TRANS_UNLOAD")
Lookup_Folder = dbutils.widgets.get("PAR_LOOKUP_FOLDER")
WcardTandemCreateDttmLkp = dbutils.widgets.get("PAR_WCARD_TANDEM_CREATE_DTTM_LKP")
WcardTandemCreateDttmLkp1 = dbutils.widgets.get("PAR_WCARD_TANDEM_CREATE_DTTM_LKP1")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
CTRejFile = dbutils.widgets.get("PAR_CT_COMBINED_REJ")
Reject_Folder = dbutils.widgets.get("PAR_REJECT_FOLDER")
CTCombinedReqTypeRej = dbutils.widgets.get("PAR_CT_COMBINED_REQ_TYPE_REJECT")

# COMMAND ----------

def WriteNullParquet(df):
    my_schema = list(df.schema)
    null_cols = []

# iterate over schema list to filter for NullType columns
    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

# cast null type columns to string
    for ncol in null_cols:
        mycolname = str(ncol.name)
        df = df.withColumn(mycolname,df[mycolname].cast('string'))
    return df

# COMMAND ----------

# Generate Records

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

Data = [("Create_Tandem_DTTM","")]

Schema = StructType([ \
                    StructField("create_dttm_key",StringType(),True), \
                    StructField("create_dttm",StringType(),True)])

WcardTandemCreateDttmLkpDF = spark.createDataFrame(data=Data,schema=Schema)

WcardTandemCreateDttmLkpDF = WcardTandemCreateDttmLkpDF.withColumn("create_dttm",date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss"))

# Standard value for create dttm will be used through out the tandem process
WcardTandemCreateDttmLkpDF.write.format("parquet").mode("overwrite").save(mountPoint+"/"+Lookup_Folder+"/"+WcardTandemCreateDttmLkp1+"/"+Batch_Id)

# COMMAND ----------

#Reading CT_COMBINED file from the staging folder:
CTSrcFile_Path = mountPoint + "/" + Staging_Folder + "/CT_COMBINED"

CTInputFileDF = spark.read.format("parquet").load(CTSrcFile_Path)

#display(CTInputFileDF)
print("Combined CT Files Count:{}".format(CTInputFileDF.count()))

# COMMAND ----------

#FBE: Invalid Tandem ts & Store Date Time & Vendor 
FBE_CheckDF = CTInputFileDF.filter(((trim(col("STORE_DATE_TIME")).isNotNull()) & (col("STORE_DATE_TIME")!='')) & ((trim(col("TANDEM_TIMESTEMP")).isNotNull()) & (col("TANDEM_TIMESTEMP")!='')) & ((col("VENDOR_ID").isNotNull()) & (trim(col("VENDOR_ID"))!='')))

# COMMAND ----------

# Reading wcard_program_account_profile_unload and wcard_last_transaction_unload files from staging folder:

Wcard_Program_Account_Profile_Join_DF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+WcardProgAcctProfUnload+"/"+Batch_Id)
Wcard_Last_Transaction_Join_DF = spark.read.format("parquet").load(mountPoint+"/"+Staging_Folder+"/"+WcardLastTransUnload+"/"+Batch_Id)

# COMMAND ----------

#RFT: Incoming Dates-3
RfmtFbeCheckDF = FBE_CheckDF.withColumn("STORE_DATE",substring(FBE_CheckDF.STORE_DATE_TIME,1,6))  \
.withColumn("store_number",FBE_CheckDF.STORE_NUM) \
.withColumn("register_number",FBE_CheckDF.REGISTER_NUM) \
.withColumn("cashier_number",FBE_CheckDF.CASHIER_NUM) \
.withColumn("transaction_number",FBE_CheckDF.TRANSACTION) \
.withColumn("store_time",substring(FBE_CheckDF.STORE_DATE_TIME,7,6))  \
.withColumn("tandem_tstmp",FBE_CheckDF.TANDEM_TIMESTEMP) \
.withColumn("account_number" ,FBE_CheckDF.ACCOUNT_NUM) \
.withColumn("txn_id",lit("0")) \
.withColumn("approved_amount", lpad(FBE_CheckDF.APPROVED_AMOUNT,7,'0')) \
.withColumn("starting_balance", lpad(FBE_CheckDF.STARTING_BALANCE,7,'0')) \
.withColumn("ending_balance", lpad(FBE_CheckDF.ENDING_BALANCE,7,'0')) \
.withColumn("transaction_amount", lpad(FBE_CheckDF.TRANSACTION_AMOUNT,7,'0')) \
.withColumn("rebate_against_amount", lpad(FBE_CheckDF.REBATE_AGAINST_AMOUNT,7,'0')) \
.withColumn("rebate_amount", lpad(FBE_CheckDF.REBATE_AMOUNT,7,'0')) 

RfmtFbeCheckDF1 = RfmtFbeCheckDF.select("txn_id","store_number","register_number","cashier_number","transaction_number","account_number","plan_id","request_type","action_type","approval_number","originator","approved_amount","starting_balance","ending_balance","vendor_id","store_date","store_time","response_code","transaction_amount","rebate_against_amount","rebate_amount","rebate_type","user_id","tandem_tstmp")

# COMMAND ----------

#This logic is writtem for cmd 18 for last column create_dttm.

var_create_dttm = WcardTandemCreateDttmLkpDF.filter(WcardTandemCreateDttmLkpDF.create_dttm_key=="Create_Tandem_DTTM").select("create_dttm").collect()

if len(var_create_dttm)!=0:
  var_create_dttm = var_create_dttm[0].create_dttm
else:
  var_create_dttm = None

# COMMAND ----------

#RFT: Convert to PRFL TXN Table
RFT_Convert_to_PRFL_TXN_Table_DF = RfmtFbeCheckDF1.withColumn("tandem_txn_dt",(substring(RfmtFbeCheckDF1.tandem_tstmp,1,10).cast(DateType())))  \
.withColumn("tandem_txn_tm",concat(substring(RfmtFbeCheckDF1.tandem_tstmp,12,2),lit(":"),(substring(RfmtFbeCheckDF1.tandem_tstmp,15,2)),lit(":"),(substring(RfmtFbeCheckDF1.tandem_tstmp,18,5)))) \
.withColumn("tandem_txn_nbr",RfmtFbeCheckDF1.transaction_number)  \
.withColumn("tandem_req_type",RfmtFbeCheckDF1.request_type)  \
.withColumn("tandem_actn_type",RfmtFbeCheckDF1.action_type)  \
.withColumn("tandem_aprv_nbr",RfmtFbeCheckDF1.approval_number)  \
.withColumn("tandem_orig",RfmtFbeCheckDF1.originator)  \
.withColumn("tandem_aprv_dlrs",RfmtFbeCheckDF1.approved_amount)  \
.withColumn("tandem_response_cd",RfmtFbeCheckDF1.response_code)  \
.withColumn("tandem_user_id",RfmtFbeCheckDF1.user_id)  \
.withColumn("tandem_rbt_type",RfmtFbeCheckDF1.rebate_type)  \
.withColumn("tandem_cashier_nbr",RfmtFbeCheckDF1.cashier_number)  \
.withColumn("tandem_starting_bal_dlrs",RfmtFbeCheckDF1.starting_balance)  \
.withColumn("tandem_end_bal_dlrs",RfmtFbeCheckDF1.ending_balance)  \
.withColumn("str_nbr",RfmtFbeCheckDF1.store_number)  \
.withColumn("register_nbr",RfmtFbeCheckDF1.register_number)  \
.withColumn("profile_id",RfmtFbeCheckDF1.plan_id)  \
.withColumn("tandem_txn_dlrs",RfmtFbeCheckDF1.transaction_amount)  \
.withColumn("acct_id",RfmtFbeCheckDF1.account_number)  \
.withColumn("tandem_rbt_against_dlrs",RfmtFbeCheckDF1.rebate_against_amount)  \
.withColumn("prog_id",lpad(RfmtFbeCheckDF1.vendor_id,5,'0'))  \
.withColumn("tandem_str_txn_tm",concat(substring(RfmtFbeCheckDF1.store_time,1,2),lit(":"),(substring(RfmtFbeCheckDF1.store_time,3,2)),lit(":"),(substring(RfmtFbeCheckDF1.store_time,5,2)))) \
.withColumn("txn_id",RfmtFbeCheckDF1.txn_id) \
.withColumn("tandem_str_txn_dt",RfmtFbeCheckDF1.store_date) \
.withColumn("tandem_rbt_dlrs", when(((RfmtFbeCheckDF1.rebate_type=='A')|(RfmtFbeCheckDF1.rebate_type=='X')),RfmtFbeCheckDF1.rebate_amount).otherwise(lit(None)))  \
.withColumn("tandem_rbt_pctg", when((RfmtFbeCheckDF1.rebate_type=='P'),RfmtFbeCheckDF1.rebate_amount).otherwise(lit(None))) \
.withColumn("txn_type_cd",lit(' ')) \
.withColumn("create_dttm",lit(var_create_dttm))\
.withColumn('tandem_clnt_name',lit(''))

# COMMAND ----------

#Filter invalid Req Type
#Filters data records according to a specified DML expression.

Filter_invalid_Req_Type_DF = RFT_Convert_to_PRFL_TXN_Table_DF.filter((RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "C") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "F") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "H") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "I") | (RFT_Convert_to_PRFL_TXN_Table_DF.tandem_req_type == "L"))

Filter_valid_Req_Type_DF = RFT_Convert_to_PRFL_TXN_Table_DF.subtract(Filter_invalid_Req_Type_DF)

## Filter by Valid Combination
##True condition
Filter_valid_Comb_DF=Filter_valid_Req_Type_DF.filter(((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='A') &(col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='C')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='G')) | ((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='D')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='D')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='D')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='S')) | ((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='S')) | ((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='X')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='X')) | ((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Y')))

Filter_valid_Comb_DF1 = Filter_valid_Comb_DF.withColumn('create_dttm',col('create_dttm').cast(TimestampType())).select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd','create_dttm')

#display(Filter_valid_Comb_DF1)

# COMMAND ----------

##False condition
Filter_invalid_Comb_DF = Filter_valid_Req_Type_DF.subtract(Filter_valid_Comb_DF).select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd','create_dttm')

#Gather the invalid records 
# Writing to Invalid file
Filter_invalid_Req_Type_DF = Filter_invalid_Req_Type_DF.select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd',col('create_dttm').cast(TimestampType()))

Filter_invalid_df=Filter_invalid_Comb_DF.unionByName(Filter_invalid_Req_Type_DF).select('txn_id','acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm','tandem_str_txn_dt','tandem_txn_nbr','register_nbr','str_nbr','tandem_str_txn_tm','tandem_cashier_nbr','tandem_req_type','tandem_actn_type','tandem_aprv_nbr','tandem_orig','tandem_aprv_dlrs','tandem_response_cd','tandem_rbt_type','tandem_rbt_dlrs','tandem_rbt_pctg','tandem_rbt_against_dlrs','tandem_starting_bal_dlrs','tandem_end_bal_dlrs','tandem_txn_dlrs','tandem_clnt_name','tandem_user_id','txn_type_cd',col('create_dttm').cast(TimestampType()))

CT_COM_ACTN_REQ_INVALID=mountPoint + '/' + Reject_Folder + '/' + dbutils.widgets.get('PAR_CT_COMBINED_ACTN_REQ_TYPE_REJECT') + '/' + Batch_Id
#Filter_invalid_df.write.format('parquet').mode("overwrite").save(CT_COM_ACTN_REQ_INVALID)

## RFT logic
REQ_Reject_RFT_df = Filter_invalid_df.select(col('acct_id').alias('account_num'),col('profile_id').alias('plan_id'),col('prog_id').alias('vendor_id'),concat(col('tandem_txn_dt'),lit(' '),col('tandem_txn_tm')).alias('tandem_timestamp'),concat(col('tandem_str_txn_dt'),lit(' '),col('tandem_str_txn_tm')).alias('store_date_time'),col('tandem_txn_nbr').alias('transaction'),col('register_nbr').alias('register_num'),col('str_nbr').alias('store_num'),col('tandem_req_type').alias('request_type'),col('tandem_actn_type').alias('action_type'),'create_dttm')

CT_COM_REQ_INVALID=mountPoint + '/' + Reject_Folder + '/' + CTCombinedReqTypeRej + '/' + Batch_Id
#REQ_Reject_RFT_df.write.format('parquet').mode("overwrite").save(CT_COM_REQ_INVALID)

# COMMAND ----------

#Defining schema for wcard_prev_rejected_type_recycle_txn.dat file:
Source_Schema2 = ['txn_id',
                 'acct_id',
                 'profile_id',
                 'prog_id',
                 'tandem_txn_dt',
                 'tandem_txn_tm',
                 'tandem_str_txn_dt',
                 'tandem_txn_nbr',
                 'register_nbr',
                 'str_nbr',
                 'tandem_str_txn_tm',
                 'tandem_cashier_nbr',
                 'tandem_req_type',
                 'tandem_actn_type',
                 'tandem_aprv_nbr',
                 'tandem_orig',
                 'tandem_aprv_dlrs',
                 'tandem_response_cd',
                 'tandem_rbt_type',
                 'tandem_rbt_dlrs',
                 'tandem_rbt_pctg',
                 'tandem_rbt_against_dlrs',
                 'tandem_starting_bal_dlrs',
                 'tandem_end_bal_dlrs',
                 'tandem_txn_dlrs',
                 'tandem_clnt_name',
                 'tandem_user_id',
                 'txn_type_cd',
                 'create_dttm']

schema2 = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,Source_Schema2)))
#print(schema2)

# COMMAND ----------

##Read Previoud Day File
Prev_CT_COM_ACTN_REQ_PATH = mountPoint + '/' + Reject_Folder + '/' +dbutils.widgets.get('PAR_PREV_CT_COMBINED_ACTN_REQ_TYPE_REJECT') + ".dat"

PREV_CT_COM_ACTN_REQ_DF = spark.read.format("csv").option("delimiter","|").schema(schema2).load(Prev_CT_COM_ACTN_REQ_PATH)

##Join Previous day file and Valid combination data and apply sort
CT_COM_DF=Filter_valid_Comb_DF1.union(PREV_CT_COM_ACTN_REQ_DF)

WCARD_PGM_ACC_PROF_UNLOAD_DF = Wcard_Program_Account_Profile_Join_DF
#display(WCARD_PGM_ACC_PROF_UNLOAD_DF)

# COMMAND ----------

### Join Code 

WCARD_PGM_ACC_JOIN=CT_COM_DF.join(WCARD_PGM_ACC_PROF_UNLOAD_DF,on = [trim(CT_COM_DF.acct_id).cast(StringType())==trim(WCARD_PGM_ACC_PROF_UNLOAD_DF.acct_id).cast(StringType()),
                                                                    trim(CT_COM_DF.profile_id).cast(IntegerType())==trim(WCARD_PGM_ACC_PROF_UNLOAD_DF.profile_id).cast(IntegerType()),
                                                                    trim(CT_COM_DF.prog_id).cast(IntegerType())==trim(WCARD_PGM_ACC_PROF_UNLOAD_DF.prog_id).cast(IntegerType())],how = 'left_outer').select(CT_COM_DF['*'],WCARD_PGM_ACC_PROF_UNLOAD_DF['acct_profile_stat_cd'])

WCARD_PGM_ACC_JOIN_Dedup=WCARD_PGM_ACC_JOIN.sort(['acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm']).dropDuplicates(['acct_id','profile_id','prog_id','tandem_txn_dt','tandem_txn_tm'])

WCARD_PGM_ACC_JOIN1=WCARD_PGM_ACC_JOIN_Dedup.withColumn('tandem_bal_temp',(col('tandem_end_bal_dlrs').cast(IntegerType()))-(col('tandem_starting_bal_dlrs').cast(IntegerType())))\
.withColumn('txn_type_cd',when((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S')) & (col('tandem_actn_type')=='X'),'IA')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='R')) & (col('tandem_actn_type')=='S'),'FR')\
.when((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'),'DL')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='J') | (col('tandem_actn_type')=='K')),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_actn_type')=='W')) & ((col('tandem_actn_type')=='I')),'IA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())>0),'FA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())<0),'FR')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())==0),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='D'),'DL')\
.when(col('tandem_req_type')=='O','MM')\
.when((col('tandem_req_type')=='E') & ((col('tandem_actn_type')=='B') | (col('tandem_actn_type')=='F') | (col('tandem_actn_type')=='M') | (col('tandem_actn_type')=='N') | (col('tandem_actn_type')=='O') | (col('tandem_actn_type')=='P') | (col('tandem_actn_type')=='Q') | (col('tandem_actn_type')=='T') | (col('tandem_actn_type')=='V') | (col('tandem_actn_type')=='Z')),'MM')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A'),'FR')\
.when((((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G'))) & (col('acct_profile_stat_cd')=='AC') & (col('tandem_aprv_dlrs').cast(IntegerType())!=0),'FA')\
.when((((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G'))) & (col('acct_profile_stat_cd')=='AC') & (col('tandem_aprv_dlrs').cast(IntegerType())==0),'MM')\
.when((((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G'))) & (col('acct_profile_stat_cd')=='IA') & (col('tandem_aprv_dlrs').cast(IntegerType())!=0),'AC')\
.when((((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G'))) & (col('acct_profile_stat_cd')=='IA') & (col('tandem_aprv_dlrs').cast(IntegerType())==0),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd').isNull()) & (col('tandem_aprv_dlrs').isNotNull()),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd').isNull()) & (col('tandem_aprv_dlrs').isNull()),col('txn_type_cd'))).drop('tandem_bal_temp')                                   

# Write Duplicates 
CT_COMBINED_DUPLICATES=WCARD_PGM_ACC_JOIN.subtract(WCARD_PGM_ACC_JOIN_Dedup)

ct_combined_dup=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_CT_COMBINED_DUP') + '/' + Batch_Id
#CT_COMBINED_DUPLICATES.write.format('parquet').mode("overwrite").save(ct_combined_dup)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import *
wspec = Window.partitionBy(col('acct_id'),col('profile_id'),col('prog_id')).orderBy(col('tandem_txn_dt'),col('tandem_txn_tm')).rowsBetween(Window.unboundedPreceding, Window.currentRow)
WCARD_PGM_ACC_SCAN = WCARD_PGM_ACC_JOIN1.withColumn("temp_acct_profile_stat_cd",lit(None)) \
.withColumn("temp_txn_type_cd",lit(None))

WCARD_PGM_ACC_SCAN = WCARD_PGM_ACC_SCAN.withColumn('group_change_key',row_number().over(wspec)) \
.withColumn('temp_acct_profile_stat_cd',
            when(((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A')) & col('acct_profile_stat_cd').isNull(),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S')) & (col('tandem_actn_type')=='X'),'IA')\
.when(((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S')) & col('acct_profile_stat_cd').isNull(),'AC') \
.when((((col('tandem_req_type')=='A') | (col('tandem_req_type')=='R')) & (col('tandem_actn_type')=='S')) & col('acct_profile_stat_cd').isNull(),'AC')\
.when((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'),'DL') \
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') |  (col('tandem_req_type')=='S') |  (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='I'),'IA')\
.when((((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F')) & (col('acct_profile_stat_cd').isNull()) ,'AC')\
.when(((col('tandem_req_type')=='A') |  (col('tandem_req_type')=='S') |  (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='D'),'DL')\
.when(((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A')) & (col('acct_profile_stat_cd').isNull()),'AC') \
.when(((col('tandem_req_type')=='A') |  (col('tandem_req_type')=='E') |  (col('tandem_req_type')=='S') |  (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')),'AC')) \
.withColumn('temp_acct_profile_stat_cd1',last(col('temp_acct_profile_stat_cd'),True).over(wspec)) \
.withColumn('acct_profile_stat_cd',coalesce(col('temp_acct_profile_stat_cd1'),col('acct_profile_stat_cd')))

wspec1 = Window.partitionBy(col('acct_id'),col('profile_id'),col('prog_id')).orderBy(col('tandem_txn_dt'),col('tandem_txn_tm'))

WCARD_PGM_ACC_SCAN = WCARD_PGM_ACC_SCAN \
.withColumn("acct_profile_stat_cd_prev", lag(WCARD_PGM_ACC_SCAN.acct_profile_stat_cd).over(wspec1)) \
.withColumn('tandem_bal_temp',(col('tandem_end_bal_dlrs').cast(IntegerType()))-(col('tandem_starting_bal_dlrs').cast(IntegerType())))\
.withColumn('temp_txn_type_cd',when((col('tandem_req_type')=='R') & (col('tandem_actn_type')=='A'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S')) & (col('tandem_actn_type')=='X'),'IA')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='S'),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='R')) & (col('tandem_actn_type')=='S'),'FR')\
.when((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'),'DL')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='J') | (col('tandem_actn_type')=='K')),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='I'),'IA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())>0),'FA')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())<0),'FR')\
.when(((col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='F') & (col('tandem_bal_temp').cast(IntegerType())==0),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & (col('tandem_actn_type')=='D'),'DL')\
.when(col('tandem_req_type')=='O','MM')\
.when((col('tandem_req_type')=='E') & ((col('tandem_actn_type')=='B') | (col('tandem_actn_type')=='F') | (col('tandem_actn_type')=='M') | (col('tandem_actn_type')=='N') | (col('tandem_actn_type')=='O') | (col('tandem_actn_type')=='P') | (col('tandem_actn_type')=='Q') | (col('tandem_actn_type')=='T') | (col('tandem_actn_type')=='V') | (col('tandem_actn_type')=='Z')),'MM')\
.when((col('tandem_req_type')=='V') & (col('tandem_actn_type')=='A'),'FR')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd_prev')=='AC') & ((col('tandem_aprv_dlrs').cast(IntegerType())!=0)),'FA')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd_prev')=='AC') & ((col('tandem_aprv_dlrs').cast(IntegerType())==0)),'MM')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd_prev')=='IA') & ((col('tandem_aprv_dlrs').cast(IntegerType())!=0)),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd_prev')=='IA') & ((col('tandem_aprv_dlrs').cast(IntegerType())==0)),'AC')\
            .when((((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G'))) & (((col('acct_profile_stat_cd_prev')!='IA') & (col('acct_profile_stat_cd_prev')!='AC')) | (col('acct_profile_stat_cd_prev').isNull())),col('txn_type_cd')) \
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd_prev').isNull()) & (col('tandem_aprv_dlrs').isNotNull()),'AC')\
.when(((col('tandem_req_type')=='A') | (col('tandem_req_type')=='E') | (col('tandem_req_type')=='S') | (col('tandem_req_type')=='W')) & ((col('tandem_actn_type')=='A') | (col('tandem_actn_type')=='C') | (col('tandem_actn_type')=='G')) & (col('acct_profile_stat_cd_prev').isNull()) & (col('tandem_aprv_dlrs').isNull()),col('txn_type_cd'))) \
.withColumn('txn_type_cd',col('temp_txn_type_cd')) \
.drop('temp_acct_profile_stat_cd','tandem_bal_temp','temp_txn_type_cd','temp_acct_profile_stat_cd1','acct_profile_stat_cd_prev')

# COMMAND ----------

#Defined TXN_TYPE_CD  only

WCARD_TXN_REF_TABLES_DF =WCARD_PGM_ACC_SCAN.filter(col('txn_type_cd').isNotNull())

##WCARD TRANSACTION FILE

WCARD_TXN_DF=WCARD_TXN_REF_TABLES_DF.withColumn('prog_id',lpad(col('prog_id'),5,'0')).drop('acct_profile_stat_cd','group_change_key','txn_id') \
.withColumn("tandem_str_txn_dt",concat(lit("20"),substring(WCARD_TXN_REF_TABLES_DF.tandem_str_txn_dt,1,2),lit("-"),substring(WCARD_TXN_REF_TABLES_DF.tandem_str_txn_dt,3,2),lit("-"),substring(WCARD_TXN_REF_TABLES_DF.tandem_str_txn_dt,5,2))) \
.withColumn("tandem_rbt_dlrs",col("tandem_rbt_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_rbt_against_dlrs",col("tandem_rbt_against_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_aprv_dlrs_1",regexp_replace('tandem_aprv_dlrs', r'^[0]*', '')) \
.withColumn("tandem_starting_bal_dlrs_1",regexp_replace('tandem_starting_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_end_bal_dlrs_1",regexp_replace('tandem_end_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_txn_dlrs_1",regexp_replace('tandem_txn_dlrs', r'^[0]*', ''))

WCARD_TXN_DF = WCARD_TXN_DF.withColumn("tandem_aprv_dlrs",when((length(trim(col("tandem_aprv_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,1))).when((length(trim(col("tandem_aprv_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,2,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_aprv_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_starting_bal_dlrs",when((length(trim(col("tandem_starting_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,1))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,2,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_starting_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_end_bal_dlrs",when((length(trim(col("tandem_end_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,1))).when((length(trim(col("tandem_end_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,2,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_end_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_txn_dlrs",when((length(trim(col("tandem_txn_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,1))).when((length(trim(col("tandem_txn_dlrs_1")))==2),concat(lit("0."),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,2))).when((length(trim(col("tandem_txn_dlrs_1")))==3),concat(substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,1),lit("."),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,2,2))).when((length(trim(col("tandem_txn_dlrs_1")))==4),concat(substring(WCARD_TXN_DF.tandem_txn_dlrs_1,1,2),lit("."),substring(WCARD_TXN_DF.tandem_txn_dlrs_1,3,2))).otherwise(lit("0.00"))).drop("tandem_aprv_dlrs_1","tandem_starting_bal_dlrs_1","tandem_end_bal_dlrs_1","tandem_txn_dlrs_1")

wcard_txn=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_TXN') + '/' + Batch_Id
print("wcard_transaction: {}".format(WCARD_TXN_DF.count()))
WCARD_TXN_DF.write.format('parquet').mode("overwrite").save(wcard_txn)

# COMMAND ----------

### FBE NON-FINANCIAL TXN

FILTER_NON_FINAN_TXN=WCARD_PGM_ACC_SCAN.filter(~(((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K'))))

##Last Transaction Filter
FILTER_NON_FINAN_TXN1 = FILTER_NON_FINAN_TXN.withColumn("txn_type_cd",coalesce(FILTER_NON_FINAN_TXN.txn_type_cd,lit("  ")))

LAST_TRANS_DF=FILTER_NON_FINAN_TXN1.filter(col('txn_type_cd')!='MM')

LAST_TRANS_DF = LAST_TRANS_DF.filter(~(((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='I')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='I'))))
## Program  Account Profile Filter

PGM_ACC_DF=FILTER_NON_FINAN_TXN.filter(~(((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') &(col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K')))).filter(col('acct_profile_stat_cd').isNotNull())

# COMMAND ----------

#WCARD LAST TRANSACTION (TANDEM TABLE)
wspec2 = Window.partitionBy(col('acct_id'),col('profile_id'),col('prog_id')).orderBy(col('acct_id'),col('profile_id'),col('prog_id'))
WCARD_LAST_TXN_ROLLUP_DF = LAST_TRANS_DF.withColumn('group_change_key',max(col('group_change_key')).over(wspec2)) \
.filter(col('txn_type_cd').isNotNull()) 
WCARD_LAST_TXN_ROLLUP_DF = WCARD_LAST_TXN_ROLLUP_DF.dropDuplicates(['acct_id','profile_id','prog_id','group_change_key'])

for c in WCARD_LAST_TXN_ROLLUP_DF.columns:
  WCARD_LAST_TXN_ROLLUP_DF = WCARD_LAST_TXN_ROLLUP_DF.withColumnRenamed(c,c + '_left')

WCARD_LAST_JOIN_DF = WCARD_LAST_TXN_ROLLUP_DF.join(FILTER_NON_FINAN_TXN,on = [trim(WCARD_LAST_TXN_ROLLUP_DF.acct_id_left).cast(StringType())==trim(FILTER_NON_FINAN_TXN.acct_id).cast(StringType()),
                                                                             trim(WCARD_LAST_TXN_ROLLUP_DF.profile_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.profile_id).cast(IntegerType()),
                                                                             trim(WCARD_LAST_TXN_ROLLUP_DF.prog_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.prog_id).cast(IntegerType()),
                                                                             (WCARD_LAST_TXN_ROLLUP_DF.group_change_key_left)==(FILTER_NON_FINAN_TXN.group_change_key)],how = 'inner').select(FILTER_NON_FINAN_TXN['*'],WCARD_LAST_TXN_ROLLUP_DF.group_change_key_left.alias("group_change_key")).drop(FILTER_NON_FINAN_TXN.group_change_key)

for c in Wcard_Last_Transaction_Join_DF.columns:
  Wcard_Last_Transaction_Join_DF = Wcard_Last_Transaction_Join_DF.withColumnRenamed(c,c + '_right')

#LKP with wcard_last_transaction:
WCARD_LAST_LKP_JOIN_DF = WCARD_LAST_JOIN_DF.join(Wcard_Last_Transaction_Join_DF,on = [trim(WCARD_LAST_JOIN_DF.acct_id).cast(StringType())==trim(Wcard_Last_Transaction_Join_DF.acct_id_right).cast(StringType()),
                                                                               trim(WCARD_LAST_JOIN_DF.profile_id).cast(IntegerType())==trim(Wcard_Last_Transaction_Join_DF.profile_id_right).cast(IntegerType()),
                                                                               trim(WCARD_LAST_JOIN_DF.prog_id).cast(IntegerType())==trim(Wcard_Last_Transaction_Join_DF.prog_id_right).cast(IntegerType())], how = 'left_outer').dropDuplicates(['acct_id','profile_id','prog_id'])

# COMMAND ----------

#Filter Condition True in Join ##FBE Valid entry in wcard_last_transaction

WCARD_LAST_LKP_JOIN_FIL_DF=WCARD_LAST_LKP_JOIN_DF.filter((WCARD_LAST_LKP_JOIN_DF.acct_id_right.isNotNull()) & (WCARD_LAST_LKP_JOIN_DF.profile_id_right.isNotNull()) & (WCARD_LAST_LKP_JOIN_DF.prog_id_right.isNotNull())) \
.filter(datediff(to_date(WCARD_LAST_LKP_JOIN_DF.tandem_txn_dt_right),to_date(WCARD_LAST_LKP_JOIN_DF.tandem_txn_dt))<0).select(WCARD_LAST_JOIN_DF['*'])

###Filter Condition False in Join ##FBE Valid entry in wcard_last_transaction
WCARD_LAST_LKP_JOIN_FALSE_DF=WCARD_LAST_LKP_JOIN_DF.filter((WCARD_LAST_LKP_JOIN_DF.acct_id_right.isNull()) & (WCARD_LAST_LKP_JOIN_DF.profile_id_right.isNull()) & (WCARD_LAST_LKP_JOIN_DF.prog_id_right.isNull())).select(WCARD_LAST_JOIN_DF['*'])

##Gather component
WCARD_LAST_TXN_GATHER_DF=WCARD_LAST_LKP_JOIN_FIL_DF.unionByName(WCARD_LAST_LKP_JOIN_FALSE_DF)

WCARD_LAST_TXN_GATHER_DF = WCARD_LAST_TXN_GATHER_DF.withColumn("tandem_str_txn_dt",concat(lit("20"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_str_txn_dt,1,2),lit("-"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_str_txn_dt,3,2),lit("-"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_str_txn_dt,5,2))) \
.withColumn("tandem_rbt_dlrs",col("tandem_rbt_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_rbt_against_dlrs",col("tandem_rbt_against_dlrs").cast(DecimalType(8,2))) \
.withColumn("tandem_aprv_dlrs_1",regexp_replace('tandem_aprv_dlrs', r'^[0]*', '')) \
.withColumn("tandem_starting_bal_dlrs_1",regexp_replace('tandem_starting_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_end_bal_dlrs_1",regexp_replace('tandem_end_bal_dlrs', r'^[0]*', '')) \
.withColumn("tandem_txn_dlrs_1",regexp_replace('tandem_txn_dlrs', r'^[0]*', ''))

WCARD_LAST_TXN_GATHER_DF = WCARD_LAST_TXN_GATHER_DF.withColumn("tandem_aprv_dlrs",when((length(trim(col("tandem_aprv_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,1))).when((length(trim(col("tandem_aprv_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,2,2))).when((length(trim(col("tandem_aprv_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_aprv_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_starting_bal_dlrs",when((length(trim(col("tandem_starting_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,1))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,2,2))).when((length(trim(col("tandem_starting_bal_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_starting_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_end_bal_dlrs",when((length(trim(col("tandem_end_bal_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,1))).when((length(trim(col("tandem_end_bal_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,2,2))).when((length(trim(col("tandem_end_bal_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_end_bal_dlrs_1,3,2))).otherwise(lit("0.00"))) \
.withColumn("tandem_txn_dlrs",when((length(trim(col("tandem_txn_dlrs_1")))==1),concat(lit("0.0"),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,1))).when((length(trim(col("tandem_txn_dlrs_1")))==2),concat(lit("0."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,2))).when((length(trim(col("tandem_txn_dlrs_1")))==3),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,1),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,2,2))).when((length(trim(col("tandem_txn_dlrs_1")))==4),concat(substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,1,2),lit("."),substring(WCARD_LAST_TXN_GATHER_DF.tandem_txn_dlrs_1,3,2))).otherwise(lit("0.00"))).drop("tandem_aprv_dlrs_1","tandem_starting_bal_dlrs_1","tandem_end_bal_dlrs_1","tandem_txn_dlrs_1")

# COMMAND ----------

##FBE W/R
WCARD_FBE_LAST_TXN=WCARD_LAST_TXN_GATHER_DF.filter((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R'))

for c in WCARD_FBE_LAST_TXN.columns:
  WCARD_FBE_LAST_TXN = WCARD_FBE_LAST_TXN.withColumnRenamed(c, c+'_left')

#Join Inner
WCARD_JOIN_LAST_TXN_DF=WCARD_FBE_LAST_TXN.join(WCARD_LAST_TXN_GATHER_DF,trim(WCARD_FBE_LAST_TXN.acct_id_left).cast(StringType())==trim(WCARD_LAST_TXN_GATHER_DF.acct_id).cast(StringType()),'inner').select(WCARD_LAST_TXN_GATHER_DF['*']).distinct()

##wcard_last_transaction_delete_lkp
wcard_last_txn_del_lkp=mountPoint + '/' + Lookup_Folder + '/' + dbutils.widgets.get('PAR_WCARD_LAST_TXN_DEL_LKP') + '/' + Batch_Id
WCARD_JOIN_LAST_TXN_DF.cache()
print("wcard_last_transaction_delete_lkp: {}".format(WCARD_JOIN_LAST_TXN_DF.count()))
WCARD_JOIN_LAST_TXN_DF.write.format('parquet').mode("overwrite").save(wcard_last_txn_del_lkp)

##FBE only W/R

WCARD_STATUS_DEL_LKP_DF=WCARD_JOIN_LAST_TXN_DF.filter((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='R')).distinct()

##wcard_profile_status_delete_eff_dt_lkp

wcard_last_txn_sts_lkp=mountPoint + '/' + Lookup_Folder + '/' + dbutils.widgets.get('PAR_WCARD_STATUS_DEL_LKP') + '/' + Batch_Id
print("wcard_profile_status_delete_eff_dt_lkp: {}".format(WCARD_STATUS_DEL_LKP_DF.count()))
WCARD_STATUS_DEL_LKP_DF.write.format('parquet').mode("overwrite").save(wcard_last_txn_sts_lkp)

## left anti join
WCARD_LAST_TXN_FINAL=WCARD_LAST_TXN_GATHER_DF.join(WCARD_FBE_LAST_TXN,WCARD_FBE_LAST_TXN.acct_id_left==WCARD_LAST_TXN_GATHER_DF.acct_id,'left_anti').drop("txn_id","acct_profile_stat_cd","group_change_key").distinct()

##WCARD_LAST_TRANSACTION
wcard_last_txn=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_LAST_TRANSACTION') + '/' + Batch_Id
print("wcard_last_transaction: {}".format(WCARD_LAST_TXN_FINAL.count()))
WCARD_LAST_TXN_FINAL.write.format('parquet').mode("overwrite").save(wcard_last_txn)

# COMMAND ----------

### WCARD PROGRAM ACCOUNT PROFILE
##Program Account Filter
PGM_ACC_FILTER=FILTER_NON_FINAN_TXN1.filter(~(((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='B')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='F')) | ((col('tandem_req_type')=='E') &(col('tandem_actn_type')=='M')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='N')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='O')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='P')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Q')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='T')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='V')) | ((col('tandem_req_type')=='E') & (col('tandem_actn_type')=='Z')) | (col('tandem_req_type')=='O') | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='A') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='S') & (col('tandem_actn_type')=='K')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='J')) | ((col('tandem_req_type')=='W') & (col('tandem_actn_type')=='K')))).filter(col('acct_profile_stat_cd').isNotNull())

PGM_ACC_ROLLUP_DF=PGM_ACC_FILTER.withColumn('group_change_key',max(col('group_change_key')).over(wspec2))
PGM_ACC_ROLLUP_DF = PGM_ACC_ROLLUP_DF.dropDuplicates(['acct_id','profile_id','prog_id','group_change_key'])

for c in PGM_ACC_ROLLUP_DF.columns:
  PGM_ACC_ROLLUP_DF = PGM_ACC_ROLLUP_DF.withColumnRenamed(c,c+'_left')

for colmn in Wcard_Program_Account_Profile_Join_DF.columns:
  Wcard_Program_Account_Profile_Join_DF = Wcard_Program_Account_Profile_Join_DF.withColumnRenamed(colmn,colmn+'_right')

# COMMAND ----------

## Join 4

PGM_ACC_JOIN_DF=PGM_ACC_ROLLUP_DF.join(PGM_ACC_FILTER,on =[trim(PGM_ACC_ROLLUP_DF.acct_id_left).cast(StringType())==trim(PGM_ACC_FILTER.acct_id).cast(StringType()), trim(PGM_ACC_ROLLUP_DF.profile_id_left).cast(IntegerType())==trim(PGM_ACC_FILTER.profile_id).cast(IntegerType()), trim(PGM_ACC_ROLLUP_DF.prog_id_left).cast(IntegerType())==trim(PGM_ACC_FILTER.prog_id).cast(IntegerType()),(PGM_ACC_ROLLUP_DF.group_change_key_left)==(PGM_ACC_FILTER.group_change_key)],how='inner').select(PGM_ACC_FILTER['*'],PGM_ACC_ROLLUP_DF.group_change_key_left.alias("group_change_key")).drop(PGM_ACC_FILTER.group_change_key)

#OLD TANDEM TS LKP with Program Account Profile
PGM_OLD_TANDEM_JOIN_DF=PGM_ACC_JOIN_DF.join(Wcard_Program_Account_Profile_Join_DF,[trim(PGM_ACC_JOIN_DF.acct_id).cast(StringType())==trim(Wcard_Program_Account_Profile_Join_DF.acct_id_right).cast(StringType()),
                                                                              (PGM_ACC_JOIN_DF.profile_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.profile_id_right).cast(IntegerType()), trim(PGM_ACC_JOIN_DF.prog_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.prog_id_right).cast(IntegerType())],how = 'left_outer').dropDuplicates(['acct_id','profile_id','prog_id'])

###Filter Condition True in Join ##FBE Valid entry in Program Account Profile
PGM_OLD_TANDEM_TRUE_DF=PGM_OLD_TANDEM_JOIN_DF.filter((PGM_OLD_TANDEM_JOIN_DF.acct_id_right.isNotNull()) & (PGM_OLD_TANDEM_JOIN_DF.profile_id_right.isNotNull()) & (PGM_OLD_TANDEM_JOIN_DF.prog_id_right.isNotNull())) \
.filter(datediff(to_date(PGM_OLD_TANDEM_JOIN_DF.prog_acct_profile_eff_dt_right),to_date(PGM_OLD_TANDEM_JOIN_DF.tandem_txn_dt))<0).select(PGM_ACC_JOIN_DF['*'])

###Filter Condition False in Join ##FBE Valid entry in Program Account Profile
PGM_OLD_TANDEM_FALSE_DF=PGM_OLD_TANDEM_JOIN_DF.filter((PGM_OLD_TANDEM_JOIN_DF.acct_id_right.isNull()) & (PGM_OLD_TANDEM_JOIN_DF.profile_id_right.isNull()) & (PGM_OLD_TANDEM_JOIN_DF.prog_id_right.isNull())) \
.select(PGM_ACC_JOIN_DF['*'])

##GATHER

PGM_OLD_TANDEM_DF=PGM_OLD_TANDEM_TRUE_DF.union(PGM_OLD_TANDEM_FALSE_DF)\
.withColumn('prog_acct_profile_end_dt',lit(None)) \
.withColumn('acct_profile_stat_cd',coalesce(col("acct_profile_stat_cd"),lit("AC"))) \
.select('acct_id','profile_id',col('tandem_txn_dt').alias('prog_acct_profile_eff_dt'),(lpad(col('prog_id'),5,'0')).alias('prog_id'),'prog_acct_profile_end_dt','acct_profile_stat_cd','create_dttm')\
.filter((col('acct_profile_stat_cd').isNotNull()) & ((col('acct_profile_stat_cd')=='AC') | (col('acct_profile_stat_cd')=='IA') | (col('acct_profile_stat_cd')=='DL')))

## Rollup Min on PGM_ACC_DF
PGM_ACC_MIN_DF=PGM_ACC_DF.withColumn('group_change_key',min(col('group_change_key')).over(wspec2))#.filter(col('txn_type_cd').isNotNull())
PGM_ACC_MIN_DF = PGM_ACC_MIN_DF.dropDuplicates(['acct_id','profile_id','prog_id','group_change_key'])

for c in PGM_ACC_MIN_DF.columns:
  PGM_ACC_MIN_DF = PGM_ACC_MIN_DF.withColumnRenamed(c,c+'_left')

# COMMAND ----------

## JOIN 1

PGM_ACC_MIN_JOIN_DF =PGM_ACC_MIN_DF.join(FILTER_NON_FINAN_TXN,on =[trim(PGM_ACC_MIN_DF.acct_id_left).cast(StringType())==trim(FILTER_NON_FINAN_TXN.acct_id).cast(StringType()), trim(PGM_ACC_MIN_DF.profile_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.profile_id).cast(IntegerType()), 
trim(PGM_ACC_MIN_DF.prog_id_left).cast(IntegerType())==trim(FILTER_NON_FINAN_TXN.prog_id).cast(IntegerType()), 
(PGM_ACC_MIN_DF.group_change_key_left)==(FILTER_NON_FINAN_TXN.group_change_key)],how = 'inner').select(FILTER_NON_FINAN_TXN['*'],PGM_ACC_MIN_DF.group_change_key_left.alias("group_change_key")).drop(FILTER_NON_FINAN_TXN.group_change_key)

#OLD TANDEM TS LKP with Program Account Profile
PGM_OLD_TANDEM_JOIN_1_DF=PGM_ACC_MIN_JOIN_DF.join(Wcard_Program_Account_Profile_Join_DF,on =[trim(PGM_ACC_MIN_JOIN_DF.acct_id).cast(StringType())==trim(Wcard_Program_Account_Profile_Join_DF.acct_id_right).cast(StringType()),
                                                                                       trim(PGM_ACC_MIN_JOIN_DF.profile_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.profile_id_right).cast(IntegerType()), trim(PGM_ACC_MIN_JOIN_DF.prog_id).cast(IntegerType())==trim(Wcard_Program_Account_Profile_Join_DF.prog_id_right).cast(IntegerType())],how = 'left_outer').dropDuplicates(['acct_id','profile_id','prog_id'])

###Filter Condition True in Join ##FBE Valid entry in Wcard Program_account_profile

PGM_OLD_TANDEM_1_TRUE_DF=PGM_OLD_TANDEM_JOIN_1_DF.filter((PGM_OLD_TANDEM_JOIN_1_DF.acct_id_right.isNotNull()) & (PGM_OLD_TANDEM_JOIN_1_DF.profile_id_right.isNotNull()) & (PGM_OLD_TANDEM_JOIN_1_DF.prog_id_right.isNotNull())) \
.filter(datediff(to_date(PGM_OLD_TANDEM_JOIN_1_DF.prog_acct_profile_eff_dt_right),to_date(PGM_OLD_TANDEM_JOIN_1_DF.tandem_txn_dt))<0).select(PGM_ACC_MIN_JOIN_DF['*'])

###Filter Condition False in Join ##FBE Valid entry in Wcard Program_account_profile
PGM_OLD_TANDEM_1_FALSE_DF=PGM_OLD_TANDEM_JOIN_1_DF.filter((PGM_OLD_TANDEM_JOIN_1_DF.acct_id_right.isNull()) & (PGM_OLD_TANDEM_JOIN_1_DF.profile_id_right.isNull()) & (PGM_OLD_TANDEM_JOIN_1_DF.prog_id_right.isNull()))\
.select(PGM_ACC_MIN_JOIN_DF['*'])

##GATHER

PGM_OLD_TANDEM_1_DF=PGM_OLD_TANDEM_1_TRUE_DF.union(PGM_OLD_TANDEM_1_FALSE_DF)

#Renaming columns 
for i in PGM_OLD_TANDEM_1_DF.columns:
  PGM_OLD_TANDEM_1_DF=PGM_OLD_TANDEM_1_DF.withColumnRenamed(i,'OLD_'+i)

#Renaming columns 
for i in WCARD_JOIN_LAST_TXN_DF.columns:
  WCARD_JOIN_LAST_TXN_DF=WCARD_JOIN_LAST_TXN_DF.withColumnRenamed(i,'DELETED_'+i)
  
for i in WCARD_STATUS_DEL_LKP_DF.columns:
  WCARD_STATUS_DEL_LKP_DF=WCARD_STATUS_DEL_LKP_DF.withColumnRenamed(i,'DELETED_1_'+i)

# COMMAND ----------

PGM_ACC_JOIN_FINAL_DF=PGM_OLD_TANDEM_DF.join(PGM_OLD_TANDEM_1_DF,on = [trim(PGM_OLD_TANDEM_DF.acct_id).cast(StringType())==trim(PGM_OLD_TANDEM_1_DF.OLD_acct_id).cast(StringType()), trim(PGM_OLD_TANDEM_DF.profile_id).cast(IntegerType())==trim(PGM_OLD_TANDEM_1_DF.OLD_profile_id).cast(IntegerType()),
trim(PGM_OLD_TANDEM_DF.prog_id).cast(IntegerType())==trim(PGM_OLD_TANDEM_1_DF.OLD_prog_id).cast(IntegerType())],how  = 'inner')\
.select(PGM_OLD_TANDEM_DF['*'],col('OLD_tandem_txn_dt').alias('TANDEM_1_tandem_txn_dt'))

PGM_ACC_JOIN_FINAL_1_DF=PGM_ACC_JOIN_FINAL_DF.join(WCARD_JOIN_LAST_TXN_DF,on =[trim(PGM_ACC_JOIN_FINAL_DF.acct_id).cast(StringType())==trim(WCARD_JOIN_LAST_TXN_DF.DELETED_acct_id).cast(StringType())],how = 'left_outer').select(PGM_ACC_JOIN_FINAL_DF['*'],'DELETED_acct_id')\
.withColumn('temp_acct_profile_stat_cd',when((col('DELETED_acct_id').isNotNull()),lit('DL')).otherwise(lit(None)))\
.withColumn('acct_profile_stat_cd',when(col('temp_acct_profile_stat_cd').isNotNull(),col('temp_acct_profile_stat_cd')).otherwise(col('acct_profile_stat_cd'))).drop('temp_acct_profile_stat_cd')

PGM_ACC_JOIN_FINAL_LKP_DF=PGM_ACC_JOIN_FINAL_1_DF.join(WCARD_STATUS_DEL_LKP_DF,on =[(PGM_ACC_JOIN_FINAL_1_DF.acct_id).cast(StringType())==trim(WCARD_STATUS_DEL_LKP_DF.DELETED_1_acct_id).cast(StringType())],how = 'left_outer').select(PGM_ACC_JOIN_FINAL_1_DF['*'],'DELETED_1_acct_id','DELETED_1_tandem_txn_dt') \
.withColumn('prog_acct_profile_eff_dt',when(col('DELETED_1_acct_id').isNotNull(),col('DELETED_1_tandem_txn_dt')).otherwise(col('TANDEM_1_tandem_txn_dt'))).drop('TANDEM_1_tandem_txn_dt','DELETED_1_tandem_txn_dt','DELETED_1_tandem_txn_dt','DELETED_1_acct_id')

###FBE W/R
PGM_ACC_JOIN_FINAL_LKP_DF1 = PGM_ACC_JOIN_FINAL_LKP_DF.filter(col('DELETED_acct_id').isNotNull()).drop('DELETED_acct_id').distinct()
PGM_ACC_JOIN_FINAL_LKP_DF1 = WriteNullParquet(PGM_ACC_JOIN_FINAL_LKP_DF1)

## wcard_prog_acct_profile_delete_lkp
wcard_pgm_acc_del_lkp=mountPoint + '/' + Lookup_Folder + '/' + dbutils.widgets.get('PAR_WCARD_ACC_PROF_DEL_LKP') + '/' + Batch_Id
print("wcard_prog_acct_profile_delete_lkp:{}".format(PGM_ACC_JOIN_FINAL_LKP_DF1.count()))
PGM_ACC_JOIN_FINAL_LKP_DF1.write.format('parquet').mode("overwrite").save(wcard_pgm_acc_del_lkp)

##FBE PROFILE_ID is 0
PGM_ACC_FINAL_DF=PGM_ACC_JOIN_FINAL_LKP_DF.filter(col('DELETED_acct_id').isNull()).drop('DELETED_acct_id')
PGM_ACC_FINAL_DF1=PGM_ACC_FINAL_DF.filter((col('profile_id').cast(IntegerType())!=0) & (col('acct_profile_stat_cd').isNotNull()) & ((trim(col('acct_profile_stat_cd'))=='AC') | (col('acct_profile_stat_cd')=='IA') | (col('acct_profile_stat_cd')=='DL'))).distinct()
PGM_ACC_FINAL_DF1 = WriteNullParquet(PGM_ACC_FINAL_DF1)

##WCARD Program Account Profile
wcard_pgm_acc=mountPoint + '/' + Staging_Folder + '/' + dbutils.widgets.get('PAR_WCARD_ACC_PROFILE') + '/' + Batch_Id
print("wcard_program_account_profile:{}".format(PGM_ACC_FINAL_DF1.count()))
PGM_ACC_FINAL_DF1.write.format('parquet').mode("overwrite").save(wcard_pgm_acc)

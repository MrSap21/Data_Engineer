# Databricks notebook source
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
mountPoint = "/mnt/DAP_IDL_ACCOUNT_EC_CIF_EC_SUBSCR_PREF_LAST_ACTV_XFORM"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

# Load Input File

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("src_name", StringType(), False),
    StructField("src_type", StringType(), False),
    StructField("src_key", StringType(), False),
    StructField("err_desc", StringType(), False),
    StructField("prty_cd", StringType(), False),
    StructField("email", StringType(), False),
    StructField("property_name", StringType(), False),
    StructField("new_value", StringType(), False),
    StructField("create_dttm", StringType(), False)
  ])
)

inputFileFullPath = mountPoint + "/" + dbutils.widgets.get('AI_SERIAL') + "/edw_idl_account_ec_PHEXT021_extr_" + dbutils.widgets.get('pDAP_BATCH_ID') + ".dat"

dfInput = spark.read.format("csv").options(header='false', delimiter = '\x01').schema(inputSchema).load(inputFileFullPath)

# COMMAND ----------

# Partition data based on logic

from pyspark.sql.functions import *

in0 = dfInput.groupBy("email").agg(max(col("src_name")).alias("src_name"), max(col("src_type")).alias("src_type"), max(col("src_key")).alias("src_key"), max(col("err_desc")).alias("err_desc"), max(col("prty_cd")).alias("prty_cd"), max(col("property_name")).alias("property_name"), max(col("new_value")).alias("new_value"), max(col("create_dttm")).alias("create_dttm"))

in1 = dfInput.filter((upper(col("property_name")) == "STORESPECIALIND") & (upper(col("new_value")) == "Y"))

in2 = dfInput.filter((upper(col("property_name")) == "STORESPECIALIND") & (upper(col("new_value")) == "N"))

in3 = dfInput.filter((upper(col("property_name")) == "WEEKLYADIND") & (upper(col("new_value")) == "Y"))

in4 = dfInput.filter((upper(col("property_name")) == "WEEKLYADIND") & (upper(col("new_value")) == "N"))

in5 = dfInput.filter((upper(col("property_name")) == "PHOTOIND") & (upper(col("new_value")) == "Y"))

in6 = dfInput.filter((upper(col("property_name")) == "PHOTOIND") & (upper(col("new_value")) == "N"))

in7 = dfInput.filter((upper(col("property_name")) == "NEWSLETTERIND") & (upper(col("new_value")) == "Y"))

in8 = dfInput.filter((upper(col("property_name")) == "NEWSLETTERIND") & (upper(col("new_value")) == "N"))

in9 = dfInput.filter((upper(col("property_name")) == "DIABETESIND") & (upper(col("new_value")) == "Y"))

in10 = dfInput.filter((upper(col("property_name")) == "DIABETESIND") & (upper(col("new_value")) == "N"))

in11 = dfInput.filter((upper(col("property_name")) == "STEPSIND") & (upper(col("new_value")) == "Y"))

in12 = dfInput.filter((upper(col("property_name")) == "STEPSIND") & (upper(col("new_value")) == "N"))

in13 = dfInput.filter((upper(col("property_name")) == "HEALTHCAREIND") & (upper(col("new_value")) == "Y"))

in14 = dfInput.filter((upper(col("property_name")) == "HEALTHCAREIND") & (upper(col("new_value")) == "N"))

in0.createOrReplaceTempView("in0")
in1.createOrReplaceTempView("in1")
in2.createOrReplaceTempView("in2")
in3.createOrReplaceTempView("in3")
in4.createOrReplaceTempView("in4")
in5.createOrReplaceTempView("in5")
in6.createOrReplaceTempView("in6")
in7.createOrReplaceTempView("in7")
in8.createOrReplaceTempView("in8")
in9.createOrReplaceTempView("in9")
in10.createOrReplaceTempView("in10")
in11.createOrReplaceTempView("in11")
in12.createOrReplaceTempView("in12")
in13.createOrReplaceTempView("in13")
in14.createOrReplaceTempView("in14")

OUTF_REJ_UNKNOW_SUBSCRPTION = dfInput.filter(((col("property_name").isNull()) | (~upper(col("property_name")).isin(["STORESPECIALIND", "WEEKLYADIND", "PHOTOIND", "NEWSLETTERIND", "DIABETESIND", "STEPSIND", "HEALTHCAREIND"]))) \
                      | ((col("new_value").isNull()) | (~upper(col("new_value")).isin(["N", "Y"])))) \
              .withColumn("err_desc", concat(lit("ERROR: Unhandled subscription date found in input - property_name["), when(col("property_name").isNull(), lit("")).otherwise(col("property_name")), lit("]"),lit(" new_value["), when(col("new_value").isNull(), lit("")).otherwise(col("new_value")), lit("]"))) \
              .withColumn("prty_cd", lit("2"))

# COMMAND ----------

# JOIN - Denormalize Subscription Dates

dfJoined = spark.sql("select in0.src_name,  \
                             in0.src_type,  \
                             in0.src_key,  \
                             in0.err_desc,  \
                             in0.prty_cd,  \
                             in0.email as eml_addr, \
                             'EC' as src_sys_cd, \
                             (case WHEN TRIM(in1.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in1.create_dttm) END) as store_spcl_last_optin_dttm, \
                             (case WHEN TRIM(in2.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in2.create_dttm) END) as store_spcl_last_optout_dttm, \
                             (case WHEN TRIM(in3.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in3.create_dttm) END) as wkly_ad_last_optin_dttm, \
                             (case WHEN TRIM(in4.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in4.create_dttm) END) as wkly_ad_last_optout_dttm, \
                             (case WHEN TRIM(in5.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in5.create_dttm) END) as photo_last_optin_dttm, \
                             (case WHEN TRIM(in6.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in6.create_dttm) END) as photo_last_optout_dttm, \
                             (case WHEN TRIM(in7.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in7.create_dttm) END) as newsltr_last_optin_dttm, \
                             (case WHEN TRIM(in8.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in8.create_dttm) END) as newsltr_last_optout_dttm, \
                             (case WHEN TRIM(in9.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in9.create_dttm) END) as diabetes_last_optin_dttm, \
                             (case WHEN TRIM(in10.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in10.create_dttm) END) as diabetes_last_optout_dttm, \
                             (case WHEN TRIM(in11.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in11.create_dttm) END) as steps_last_optin_dttm, \
                             (case WHEN TRIM(in12.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in12.create_dttm) END) as steps_last_optout_dttm, \
                             (case WHEN TRIM(in13.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in13.create_dttm) END) as hlth_care_last_optin_dttm, \
                             (case WHEN TRIM(in14.create_dttm) IS NULL THEN '<#>' ELSE TRIM(in14.create_dttm) END) as hlth_care_last_optout_dttm, \
                             '0001-01-01 00:00:00' as edw_maxupd_dttm\
                      from in0 \
                      left join in1 on in0.email = in1.email \
                      left join in2 on in0.email = in2.email \
                      left join in3 on in0.email = in3.email \
                      left join in4 on in0.email = in4.email \
                      left join in5 on in0.email = in5.email \
                      left join in6 on in0.email = in6.email \
                      left join in7 on in0.email = in7.email \
                      left join in8 on in0.email = in8.email \
                      left join in9 on in0.email = in9.email \
                      left join in10 on in0.email = in10.email \
                      left join in11 on in0.email = in11.email \
                      left join in12 on in0.email = in12.email \
                      left join in13 on in0.email = in13.email \
                      left join in14 on in0.email = in14.email")

# COMMAND ----------

# RFMT Validate Records

dfValidated = dfJoined.withColumn("v_error_desc", concat(when((col("eml_addr").isNull()) | (col("eml_addr") == "#") | (length(col("eml_addr")) > 100), concat(lit("eml_addr["), col("eml_addr"), lit("]"))).otherwise(lit("")),\
                                                         when((col("src_sys_cd").isNull()) | (col("src_sys_cd") == "#") | (length(col("src_sys_cd")) > 20), concat(lit("src_sys_cd["), col("src_sys_cd"), lit("]"))).otherwise(lit("")),\
                                                         when((col("store_spcl_last_optin_dttm").isNull()) | (col("store_spcl_last_optin_dttm") == "<#>"), concat(lit("store_spcl_last_optin_dttm["), col("store_spcl_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("store_spcl_last_optout_dttm").isNull()) | (col("store_spcl_last_optout_dttm") == "<#>"), concat(lit("store_spcl_last_optout_dttm["), col("store_spcl_last_optout_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("wkly_ad_last_optin_dttm").isNull()) | (col("wkly_ad_last_optin_dttm") == "<#>"), concat(lit("wkly_ad_last_optin_dttm["), col("wkly_ad_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("wkly_ad_last_optout_dttm").isNull()) | (col("wkly_ad_last_optout_dttm") == "<#>"), concat(lit("wkly_ad_last_optout_dttm["), col("wkly_ad_last_optout_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("photo_last_optin_dttm").isNull()) | (col("photo_last_optin_dttm") == "<#>"), concat(lit("photo_last_optin_dttm["), col("photo_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("photo_last_optout_dttm").isNull()) | (col("photo_last_optout_dttm") == "<#>"), concat(lit("photo_last_optout_dttm["), col("photo_last_optout_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("newsltr_last_optin_dttm").isNull()) | (col("newsltr_last_optin_dttm") == "<#>"), concat(lit("newsltr_last_optin_dttm["), col("newsltr_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("newsltr_last_optout_dttm").isNull()) | (col("newsltr_last_optout_dttm") == "<#>"), concat(lit("newsltr_last_optout_dttm["), col("newsltr_last_optout_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("diabetes_last_optin_dttm").isNull()) | (col("diabetes_last_optin_dttm") == "<#>"), concat(lit("diabetes_last_optin_dttm["), col("diabetes_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("diabetes_last_optout_dttm").isNull()) | (col("diabetes_last_optout_dttm") == "<#>"), concat(lit("diabetes_last_optout_dttm["), col("diabetes_last_optout_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("steps_last_optin_dttm").isNull()) | (col("steps_last_optin_dttm") == "<#>"), concat(lit("steps_last_optin_dttm["), col("steps_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("steps_last_optout_dttm").isNull()) | (col("steps_last_optout_dttm") == "<#>"), concat(lit("steps_last_optout_dttm["), col("steps_last_optout_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("hlth_care_last_optin_dttm").isNull()) | (col("hlth_care_last_optin_dttm") == "<#>"), concat(lit("hlth_care_last_optin_dttm["), col("hlth_care_last_optin_dttm"), lit("]"))).otherwise(lit("")),\
                                                         when((col("hlth_care_last_optout_dttm").isNull()) | (col("hlth_care_last_optout_dttm") == "<#>"), concat(lit("hlth_care_last_optout_dttm["), col("hlth_care_last_optout_dttm"), lit("]"))).otherwise(lit(""))))

dfValidated = dfValidated.withColumn("err_desc", when(col("v_error_desc").isNotNull(), concat(lit("ERROR:"), col("v_error_desc"))).otherwise(lit("")))\
                         .withColumn("prty_cd", when(col("v_error_desc").isNotNull(), lit(2)).otherwise(lit(0)))\
                         .drop("v_error_desc")

# COMMAND ----------

# Partition by Expression - Split by Error Code

p0 = dfValidated.filter(col("prty_cd") == 0)
p1 = dfValidated.filter(col("prty_cd") == 3)
p2 = dfValidated.filter(col("prty_cd") == 1)
p3 = dfValidated.filter(col("prty_cd") == 2)

# COMMAND ----------

# Generate output dataset 

OUTF_LDR_CIF_Subscription_Preference_Last_Activity = p0.union(p1) #OUTF_LDR - CIF Subscription Preference Last Activity
OUTF_REJ_CIF_Subscription_Preference_Last_Activity = p1.union(p2.union(p3)) #OUTF_REJ - CIF Subscription Preference Last Activity

# COMMAND ----------

# Write output

OUTF_REJ_UNKNOW_SUBSCRPTION_Location = "{0}/{1}/stdrej_{2}_unkn_subscr_{3}".format(mountPoint, dbutils.widgets.get('AI_SERIAL_REJECT'), dbutils.widgets.get('AI_GRAPH_NAME'), dbutils.widgets.get('pDAP_BATCH_ID'))
OUTF_LDR_CIF_Subscription_Preference_Last_Activity_Location = "{0}/{1}/edw_idl_account_ec_cif_ec_subscr_pref_last_actv_ldr_{2}".format(mountPoint, dbutils.widgets.get('AI_SERIAL'), dbutils.widgets.get('pDAP_BATCH_ID'))
OUTF_REJ_CIF_Subscription_Preference_Last_Activity_Location = "{0}/{1}/stdrej_{2}_{3}".format(mountPoint, dbutils.widgets.get('AI_SERIAL_REJECT'), dbutils.widgets.get('AI_GRAPH_NAME'), dbutils.widgets.get('pDAP_BATCH_ID'))

OUTF_REJ_UNKNOW_SUBSCRPTION.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(OUTF_REJ_UNKNOW_SUBSCRPTION_Location)
OUTF_LDR_CIF_Subscription_Preference_Last_Activity.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(OUTF_LDR_CIF_Subscription_Preference_Last_Activity_Location)
OUTF_REJ_CIF_Subscription_Preference_Last_Activity.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(OUTF_REJ_CIF_Subscription_Preference_Last_Activity_Location)

# Renaming output and adding the correct extention

output1 = dbutils.fs.ls(OUTF_REJ_UNKNOW_SUBSCRPTION_Location)
csv_file_output1 = [x.path for x in output1 if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output1, OUTF_REJ_UNKNOW_SUBSCRPTION_Location.rstrip('/') + ".rej")
dbutils.fs.rm(OUTF_REJ_UNKNOW_SUBSCRPTION_Location, recurse = True)

output2 = dbutils.fs.ls(OUTF_LDR_CIF_Subscription_Preference_Last_Activity_Location)
csv_file_output2 = [x.path for x in output2 if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output2, OUTF_LDR_CIF_Subscription_Preference_Last_Activity_Location.rstrip('/') + ".dat")
dbutils.fs.rm(OUTF_LDR_CIF_Subscription_Preference_Last_Activity_Location, recurse = True)

output3 = dbutils.fs.ls(OUTF_REJ_CIF_Subscription_Preference_Last_Activity_Location)
csv_file_output3 = [x.path for x in output3 if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output3, OUTF_REJ_CIF_Subscription_Preference_Last_Activity_Location.rstrip('/') + ".rej")
dbutils.fs.rm(OUTF_REJ_CIF_Subscription_Preference_Last_Activity_Location, recurse = True)

# COMMAND ----------


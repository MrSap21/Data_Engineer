# Databricks notebook source
#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Schema","")
#dbutils.widgets.text("table","")
#dbutils.widgets.remove("Output FilePath")
#dbutils.widgets.text("src_stream_name","")
#dbutils.widgets.text("proj_name","")
#dbutils.widgets.text("extract_name","")
#dbutils.widgets.text("file_start_name","")
#dbutils.widgets.text("CONNECTION_STR","")
#dbutils.widgets.text("ACCOUNT_NAME","")
#dbutils.widgets.text("ACCOUNT_KEY","")
#dbutils.widgets.text("CONTAINER_NAME","")
#dbutils.widgets.text("ENDPOINT_SUFFIX","")

#dbutils.widgets.remove("CONTAINER_NAME")
#dbutils.widgets.remove("ENDPOINT_SUFFIX")
#dbutils.widgets.text("name_starts_with","")
#dbutils.widgets.text("file_extention","")
#dbutils.widgets.text("STORAGE_ACCOUNT","")
#dbutils.widgets.text("CONTAINER_NAME","")


# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data_Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase_Name")
SQL_FP = dbutils.widgets.get("SQL_File_path")
PAR_LIST = dbutils.widgets.get("Parameters_List")
#OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
SCHEMA=dbutils.widgets.get("Schema")
Table=dbutils.widgets.get("table")
EXTRACT_NM=dbutils.widgets.get("extract_name")
FILE_ST_NM=dbutils.widgets.get("file_start_name")
PROJ_NM=dbutils.widgets.get("proj_name")
SRC_STREAM=dbutils.widgets.get("src_stream_name")
NAME_STARTS_WITH=dbutils.widgets.get("name_starts_with")
FILE_EXTENSION=dbutils.widgets.get("file_extention")
CONTAINER_NAME=dbutils.widgets.get("CONTAINER_NAME")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")

# COMMAND ----------

#!pip install cryptography

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

etl_query = "SELECT * FROM {0}.{1}.{2}".format(SNFL_DB,SCHEMA,Table)

# COMMAND ----------

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",etl_query)\
   .load()

# COMMAND ----------

cutoff_records_output.createOrReplaceTempView('staging')

# COMMAND ----------

df_pSQL_PARM_1=spark.sql("SELECT cast(max(extract_date) as string) as extract_date from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]

# COMMAND ----------

df_pPARM_2 = str('{:0>8}'.format(spark.sql("SELECT cast(max(EXTRACT_SEQ) as string) as seq_nbr from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]))

# COMMAND ----------


df_PARM_3=spark.sql("SELECT concat('{0}',max(extract_date),'_',{4},'.dat.gz') as File_name from staging WHERE src_stream_name='{1}' AND proj_name='{2}' and extract_name ='{3}'".format(FILE_ST_NM,SRC_STREAM,PROJ_NM,EXTRACT_NM,str(df_pPARM_2))).collect()[0][0]
b=df_PARM_3.split("_")

# COMMAND ----------

def sep(sub):
  filename_list=sub.split(".")
  filename=sub.split(".")[0]
  
  length =len(filename)  
  if (length<8):
    diff =8-length
    substring=""
    for i in range (diff):
      substring =substring+"0"
    filename=substring+filename
  
  filename_list[0]=filename
  name=""
  for i in filename_list:
    if name=="":
       name=name+i 
    else: 
      name=name+"."+i 
      
    
  return name    

# COMMAND ----------

df_pSQL_PARM_3_list=df_PARM_3.split("_")
df_pSQL_PARM_3_var=df_PARM_3.split("_")[-1]
df_pSQL_PARM_3_var=sep(df_pSQL_PARM_3_var)
df_pSQL_PARM_3=""
df_pSQL_PARM_3_list[-1]=df_pSQL_PARM_3_var
for i in df_pSQL_PARM_3_list:
  if df_pSQL_PARM_3=="":
      df_pSQL_PARM_3=df_pSQL_PARM_3+i 
  else: 
      df_pSQL_PARM_3=df_pSQL_PARM_3+"_"+i    

# COMMAND ----------

df_pPARM_4=spark.sql("SELECT cast(max(EXTRACT_SEQ) as string) as seq_nbr from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]


# COMMAND ----------

import datetime
import os
from pyspark.sql.types import StructType,StructField, StringType

# COMMAND ----------

def file_exists(filename):
  try:
    if dbutils.fs.ls('dbfs:/mnt/wrangled/'+filename)[0][-1]>0:
      return True
    else:
      return False
  except:
    return False
  
def get_latest_file(path,pattern,extension):
 
  files=[]
 
 
  for file in dbutils.fs.ls(path):
    if file.startswith(pattern) and file.endswith(extension):
      files.append(file)
  latest_file=files[0]
  latest=latest_file
  for file in files:
    if os.path.getctime(path+file)>os.path.getctime(path+latest_file):
      latest=file
  return latest 

# COMMAND ----------



var=str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+NAME_STARTS_WITH))


# COMMAND ----------

#var.split("FileInfo")[-1].replace(",","")
x=var.split("FileInfo")
y=[]
for i in range(1,len(x)):
  if FILE_EXTENSION in x[i]:
    y.append(x[i].replace(",",""))
  
LATEST_FILE = y[-1].split(' ')[1].split('name=')[-1].replace("'","")
last='abfss://'+CONTAINER_NAME+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+NAME_STARTS_WITH+LATEST_FILE
df = spark.read.format("csv").option("header", "false").option("delimiter", "|").load(last)
df_pSQL_PARM_5=df.count()

# COMMAND ----------

from pyspark.sql.functions import *
PAR_LIST=PAR_LIST+"pSQL_PARM_1="+df_pSQL_PARM_1+";pSQL_PARM_3="+df_pSQL_PARM_3+";pSQL_PARM_4="+df_pPARM_4+";pSQL_PARM_5="+str(0)

# COMMAND ----------

snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 300, 
                 {"parameters_list":PAR_LIST,
                  "sql_file_path":SQL_FP
                  });
snow_query=snow_query.replace('\\n',' ').replace('\\','')
print(snow_query)
snow_query_update="update {0}.{1}.{2} set EXTRACT_RECORD_CNT={3} where EXTRACT_DATE=(select max(EXTRACT_DATE) from {0}.{1}.{2} where src_stream_name='{4}' AND proj_name='{5}' and extract_name ='{6}') AND src_stream_name='{4}' AND proj_name='{5}' and extract_name ='{6}'".format(SNFL_DB,SCHEMA,Table,str(df_pSQL_PARM_5),SRC_STREAM,PROJ_NM,EXTRACT_NM)
print(snow_query_update)

# COMMAND ----------

options = {
"sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
"sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
"pem_private_key" : pkb,
"sfDatabase" :SNFL_DB,
"sfSchema" : SCHEMA,
"sfWarehouse" : SNFL_WH,
}

sfUtils=sc._jvm.net.snowflake.spark.snowflake.Utils
queryobject1 =sfUtils.runQuery(options, snow_query_update)
queryobject =sfUtils.runQuery(options, snow_query)
# Databricks notebook source
import datetime
import os
from pyspark.sql.types import StructType,StructField, StringType
import pyspark.sql.utils

# COMMAND ----------

#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Schema","")
#dbutils.widgets.text("table","")
#dbutils.widgets.remove("Output FilePath")
#dbutils.widgets.text("src_stream_name","")
#dbutils.widgets.text("proj_name","")
#dbutils.widgets.text("extract_name","")
#dbutils.widgets.text("file_start_name","")
#dbutils.widgets.text("CONNECTION_STR","")
#dbutils.widgets.text("ACCOUNT_NAME","")
#dbutils.widgets.text("ACCOUNT_KEY","")
#dbutils.widgets.text("CONTAINER_NAME","")
#dbutils.widgets.text("ENDPOINT_SUFFIX","")

#dbutils.widgets.remove("CONTAINER_NAME")
#dbutils.widgets.remove("ENDPOINT_SUFFIX")
#dbutils.widgets.text("name_starts_with","")
#dbutils.widgets.text("file_extention","")
#dbutils.widgets.text("STORAGE_ACCOUNT","")
#dbutils.widgets.text("CONTAINER_NAME","")
# dbutils.widgets.text("Batch_ID","")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data_Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase_Name")
SQL_FP = dbutils.widgets.get("SQL_File_path")
PAR_LIST = dbutils.widgets.get("Parameters_List")
#OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
SCHEMA=dbutils.widgets.get("Schema")
Table=dbutils.widgets.get("table")
EXTRACT_NM=dbutils.widgets.get("extract_name")
FILE_ST_NM=dbutils.widgets.get("file_start_name")
PROJ_NM=dbutils.widgets.get("proj_name")
SRC_STREAM=dbutils.widgets.get("src_stream_name")
NAME_STARTS_WITH=dbutils.widgets.get("name_starts_with")
FILE_EXTENSION=dbutils.widgets.get("file_extention")
CONTAINER_NAME=dbutils.widgets.get("CONTAINER_NAME")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")
batch_id = dbutils.widgets.get("Batch_ID")

# COMMAND ----------

#!pip install cryptography

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

etl_query = "SELECT * FROM {0}.{1}.{2}".format(SNFL_DB,SCHEMA,Table)


# COMMAND ----------

print("etll--- ",etl_query)

# COMMAND ----------

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",etl_query)\
   .load()

# COMMAND ----------

cutoff_records_output.createOrReplaceTempView('staging')

# COMMAND ----------

cutoff_records_output

# COMMAND ----------

extract_query = "select * from staging where src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)
print(extract_query)

# COMMAND ----------

df_stg = spark.sql(extract_query)

# COMMAND ----------

df_stg.count()

# COMMAND ----------

# int(df_stg.first()['EDW_BATCH_ID'])

# COMMAND ----------

# df_stg

# COMMAND ----------

# temp_map = {}
# par_list = (PAR_LIST.split(';'))
# for i in par_list[:-1]:
#   print(i.split('=')[0],i.split('=')[1])
#   temp_map[i.split('=')[0]] = i.split('=')[1]

# COMMAND ----------

# df_stg_extracts = df_stg.select("EXTRACT_NAME").rdd.flatMap(lambda x: x).collect()


# COMMAND ----------

def cal_param_1():
  df_pSQL_PARM_1=spark.sql("SELECT cast(max(extract_date) as string) as extract_date from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]
  return df_pSQL_PARM_1



# COMMAND ----------

#df_pPARM_2 = str('{:0>8}'.format(spark.sql("SELECT cast(max(EXTRACT_SEQ) as string) as seq_nbr from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]))
def cal_param_2():
  df_pPARM_2 = spark.sql("SELECT cast(max(EXTRACT_SEQ) as string) as seq_nbr from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]
  return df_pPARM_2

# COMMAND ----------

def cal_param_3():
  df_pPARM_2 = cal_param_2()
  df_pSQL_PARM_3=spark.sql("SELECT concat('{0}',max(extract_date),'_',{4},'.dat.gz') as File_name from staging WHERE src_stream_name='{1}' AND proj_name='{2}' and extract_name ='{3}'".format(FILE_ST_NM,SRC_STREAM,PROJ_NM,EXTRACT_NM,str(df_pPARM_2))).collect()[0][0]
  return df_pSQL_PARM_3

# COMMAND ----------

def cal_param_4():
  df_pPARM_4=spark.sql("SELECT cast(max(EXTRACT_SEQ) as string) as seq_nbr from staging WHERE src_stream_name='{0}' AND proj_name='{1}' and extract_name ='{2}'".format(SRC_STREAM,PROJ_NM,EXTRACT_NM)).collect()[0][0]
  return df_pPARM_4


# COMMAND ----------

# def file_exists(filename):
#   try:
#     if dbutils.fs.ls('dbfs:/mnt/wrangled/'+filename)[0][-1]>0:
#       return True
#     else:
#       return False
#   except:
#     return False
  
# def get_latest_file(path,pattern,extension):

#   files=[]

#   for file in dbutils.fs.ls(path):
#     if file.startswith(pattern) and file.endswith(extension):
#       files.append(file)
#   latest_file=files[0]
#   latest=latest_file
#   for file in files:
#     if os.path.getctime(path+file)>os.path.getctime(path+latest_file):
#       latest=file
#   return latest

# COMMAND ----------

def create_parameter_list(PAR_LIST):
  df_pSQL_PARM_1 = cal_param_1()
  df_pSQL_PARM_3 = cal_param_3()
  df_pPARM_4 = cal_param_4()
  var =  str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+NAME_STARTS_WITH))
 
  x=var.split("FileInfo")
  y=[]
  for i in range(1,len(x)):
  #   print("----",x[i])
    if FILE_EXTENSION in x[i]:
      y.append(x[i].replace(",",""))

  LATEST_FILE = y[-1].split(' ')[1].split('name=')[-1].replace("'","")
  last='abfss://'+CONTAINER_NAME+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+NAME_STARTS_WITH+LATEST_FILE
  df = spark.read.format("csv").option("header", "true").option("delimiter", "|").load(last)
  df_pSQL_PARM_5=df.count()
  print(df_pSQL_PARM_5)
  print(LATEST_FILE,NAME_STARTS_WITH)
  
  PAR_LIST=PAR_LIST+"pEDW_BATCH_ID="+batch_id+";pSQL_PARM_1="+df_pSQL_PARM_1+";pSQL_PARM_3="+df_pSQL_PARM_3+";pSQL_PARM_4="+df_pPARM_4+";pSQL_PARM_5="+str(df_pSQL_PARM_5)
  return PAR_LIST



# COMMAND ----------

# print(create_parameter_list(PAR_LIST))

# COMMAND ----------

from pyspark.sql.functions import *

# PAR_LIST=PAR_LIST+"pSQL_PARM_1="+df_pSQL_PARM_1+";pSQL_PARM_3="+df_pSQL_PARM_3+";pSQL_PARM_4="+df_pPARM_4+";pSQL_PARM_5="+str(0)

# COMMAND ----------

def create_snow_query(PAR_LIST,SQL_FP):
  snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 300, 
                   {"parameters_list":PAR_LIST,
                    "sql_file_path":SQL_FP
                    });
  snow_query=snow_query.replace('\\n',' ').replace('\\','')
  print(snow_query)
  return snow_query
# snow_query_update="update {0}.{1}.{2} set EXTRACT_RECORD_CNT={3} where EXTRACT_DATE=(select max(EXTRACT_DATE) from {0}.{1}.{2} where src_stream_name='{4}' AND proj_name='{5}' and extract_name ='{6}') AND src_stream_name='{4}' AND proj_name='{5}' and extract_name ='{6}'".format(SNFL_DB,SCHEMA,Table,str(df_pSQL_PARM_5),SRC_STREAM,PROJ_NM,EXTRACT_NM)
# print(snow_query_update)

# COMMAND ----------

def create_update_query():
  query = "update {}.{}.{} set EDW_BATCH_ID = {} where extract_name='{}'".format(SNFL_DB,SCHEMA,Table,batch_id,EXTRACT_NM)
  return query

# COMMAND ----------

# def create_first_record(temp_map):
#   proj_name = PROJ_NM
#   src_stream_name = SRC_STREAM
#   batch_id = 0
#   pset_name = temp_map['pPSET_NAME']
#   extract_name = EXTRACT_NM
#   extract_dttm = temp_map['pEXTRACT_DTTM']
#   extract_date = temp_map['pEXTRACT_DATE']
#   extract_range = temp_map['pEXTRACT_RANGE']
#   extract_record_cnt = 0
#   extract_seq = 1
#   extract_file_name = FILE_ST_NM+'_'+str(extract_date)+str(extract_seq)+'.dat.gz'
#   extract_create_dt = temp_map['pEXTRACT_CREATE_DATE']
  
#   query = "insert into {0}.{1}.{2} values ('{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')".format(SNFL_DB,SCHEMA,Table,proj_name,src_stream_name,batch_id,pset_name,extract_name,extract_dttm,extract_date,extract_range,extract_file_name,extract_record_cnt,extract_seq,extract_create_dt)
#   print("queryyyy----- ",query)
#   return query
  

# COMMAND ----------

options = {
"sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
"sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
"pem_private_key" : pkb,
"sfDatabase" :SNFL_DB,
"sfSchema" : SCHEMA,
"sfWarehouse" : SNFL_WH,
}

sfUtils=sc._jvm.net.snowflake.spark.snowflake.Utils
# queryobject1 =sfUtils.runQuery(options, snow_query_update)

# if EXTRACT_NM in df_stg_extracts:

# if int(df_stg.first()['EDW_BATCH_ID']) > 0 and df_stg.count ==1:
if df_stg.count() == 1 and int(df_stg.first()['EDW_BATCH_ID']) == 0:
  print("inside iff  ")
  snow_query = create_update_query()
  queryobject =sfUtils.runQuery(options, snow_query)
  
else:
  print("inside else")
  param_list = create_parameter_list(PAR_LIST)
  snow_query = create_snow_query(param_list,SQL_FP)
  queryobject =sfUtils.runQuery(options, snow_query)
  
#snow_query_update
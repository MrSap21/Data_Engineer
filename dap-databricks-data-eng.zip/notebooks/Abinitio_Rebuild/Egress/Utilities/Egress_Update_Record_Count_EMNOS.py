# Databricks notebook source
# dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("DataBase_Name","")
# dbutils.widgets.text("Schema","")
# dbutils.widgets.text("table","")
# dbutils.widgets.text("src_stream_name","")
# dbutils.widgets.text("proj_name","")
# dbutils.widgets.text("extract_name","")
# dbutils.widgets.text("CONTAINER_NAME","")
# dbutils.widgets.remove("ACCOUNT_NAME")
# dbutils.widgets.text("name_starts_with","")
# dbutils.widgets.text("STORAGE_ACCOUNT","")
# dbutils.widgets.text("file_extention","")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data_Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase_Name")
# SQL_FP = dbutils.widgets.get("SQL_File_path")
# PAR_LIST = dbutils.widgets.get("Parameters_List")
#OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
SCHEMA=dbutils.widgets.get("Schema")
Table=dbutils.widgets.get("table")
EXTRACT_NM=dbutils.widgets.get("extract_name")
# FILE_ST_NM=dbutils.widgets.get("file_start_name")
PROJ_NM=dbutils.widgets.get("proj_name")
SRC_STREAM=dbutils.widgets.get("src_stream_name")
NAME_STARTS_WITH=dbutils.widgets.get("name_starts_with")
FILE_EXTENSION=dbutils.widgets.get("file_extention")
CONTAINER_NAME=dbutils.widgets.get("CONTAINER_NAME")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# EXTRACT_NM=dbutils.widgets.get("extract_name")
# # FILE_ST_NM=dbutils.widgets.get("file_start_name")
# PROJ_NM=dbutils.widgets.get("proj_name")
# SRC_STREAM=dbutils.widgets.get("src_stream_name")

# COMMAND ----------

var =  str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+NAME_STARTS_WITH))
 
x=var.split("FileInfo")
y=[]
for i in range(1,len(x)):
#   print("----",x[i])
  if FILE_EXTENSION in x[i]:
    if (EXTRACT_NM == "IRI_transaction_file" or EXTRACT_NM == "IRI_etransaction_file") and (SRC_STREAM == "transaction_file_ext" or SRC_STREAM == "etransaction_file_ext") and (PROJ_NM == "IRI_extracts") :
      if "_add" in x[i]:
        pass
      else:
        y.append(x[i].replace(",",""))
    else:
        y.append(x[i].replace(",",""))
        
LATEST_FILE = y[-1].split(' ')[1].split('name=')[-1].replace("'","")
last='abfss://'+CONTAINER_NAME+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+NAME_STARTS_WITH+LATEST_FILE
df = spark.read.format("csv").option("header", "false").option("multiline","true").option("delimiter", "|").load(last)
df_pSQL_PARM_5=df.count()
print(df_pSQL_PARM_5)

# COMMAND ----------

# print(last)

# COMMAND ----------

curr_date = spark.sql("select current_date()") 
curr_date_str = str(curr_date.first()['current_date()'])
print(curr_date_str)

# COMMAND ----------

curr_timestamp = spark.sql("select current_timestamp()")
curr_timestamp_str = str(curr_timestamp.first()['current_timestamp()'])
print(curr_timestamp_str)

# COMMAND ----------

snow_query_update="update {0}.{1}.{2} set EXTRACT_RECORD_CNT={3},EXTRACT_CREATE_DT = '{4}',EXTRACT_DTTM='{5}' where EXTRACT_DATE=(select max(EXTRACT_DATE) from {0}.{1}.{2} where src_stream_name='{6}' AND proj_name='{7}' and extract_name ='{8}') AND src_stream_name='{6}' AND proj_name='{7}' and extract_name ='{8}'".format(SNFL_DB,SCHEMA,Table,str(df_pSQL_PARM_5),curr_date_str,curr_timestamp_str,SRC_STREAM,PROJ_NM,EXTRACT_NM)
print(snow_query_update)

# COMMAND ----------



# COMMAND ----------

options = {
"sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
"sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
"pem_private_key" : pkb,
"sfDatabase" :SNFL_DB,
"sfSchema" : SCHEMA,
"sfWarehouse" : SNFL_WH,
}

sfUtils=sc._jvm.net.snowflake.spark.snowflake.Utils
queryobject1 =sfUtils.runQuery(options, snow_query_update)
# Databricks notebook source
# Mounting ADLS
# mountPoint = dbutils.notebook.run("/Egress/Utilities/MOUNT_ADLS_OUTBOUND_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Output File Extension","")
#dbutils.widgets.text("Output File Delimeter","")
#dbutils.widgets.text("Output File Header","")
#dbutils.widgets.text("MountPoint_Notebook_Path","")
#dbutils.widgets.text("STORAGE_ACCOUNT","")
# dbutils.widgets.text("CONTAINER","retail-nonsnstv")
# dbutils.widgets.text("Output_Lookup_FileName","")

# COMMAND ----------

# dbutils.widgets.remove('Output_FilePath_CHK')

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase Name")
SQL_FP = dbutils.widgets.get("SQL File path")
PAR_LIST = dbutils.widgets.get("Parameters List")
OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
OUTPUT_FILEEXTENSION=dbutils.widgets.get("Output File Extension")
OUTPUT_FILEDELIMETER=dbutils.widgets.get("Output File Delimeter")
OUTPUT_FILEHEADER=dbutils.widgets.get("Output File Header")
MOUNTPOINT_NOTEBOOK_PATH=dbutils.widgets.get("MountPoint_Notebook_Path")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")
OUTPUT_FILENAME = dbutils.widgets.get("Output_Lookup_FileName")
CONTAINER = dbutils.widgets.get("CONTAINER")

# COMMAND ----------

#mountPoint = dbutils.notebook.run(MOUNTPOINT_NOTEBOOK_PATH, 60)

# COMMAND ----------

SNFL_DB_list=SNFL_DB.split(";")
for i in SNFL_DB_list:
  SNFL_DB
  
  print(i)

# COMMAND ----------

import os

for i in range(len(SNFL_DB_list)):
  os.system("%run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#etl_query = "SELECT * FROM {0}.{1}".format(SNFL_DB,TBL_NAME)
#Putting parameter values in SQL and storing it.
snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 300, 
                 {"parameters_list":PAR_LIST,
                  "sql_file_path":SQL_FP
                  });
snow_query=snow_query.replace('\\n',' ').replace('\\','')
print(snow_query)
#running the sql in snowflake and storing the nresult in a dataframe
cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",snow_query)\
   .load()

# COMMAND ----------

#Displaying the data.
display(cutoff_records_output)

# COMMAND ----------

cutoff_records_output_1 = cutoff_records_output.select("LOYALTY_MBR_ID","PROG_ID")

# COMMAND ----------

cutoff_records_output_1.count()
# NUMBER = cutoff_records_output.select(count('PROG_ID'))

# COMMAND ----------

OUTPUT_FILEPATH_FINAL = 'abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_FILEPATH + OUTPUT_FILENAME.replace('.dat.gz','')

# COMMAND ----------

# OUTPUT_FILEPATH_FINAL_CHK= "/mnt/egress/retail_and_supply_chain/iri/br_crossref/wagus_iri_BR_crossref_20210605_00000001.chk"

# OUTPUT_FILEPATH_FINAL_CHK = "abfss://retail-nonsnstv@dlxdevsemprtoutsa01.dfs.core.windows.net//"+"retail_and_supply_chain/iri/br_crossref/wagus_iri_BR_crossref_20210605_00000001.chk"

OUTPUT_FILEPATH_FINAL_CHK = OUTPUT_FILEPATH_FINAL +".chk"
print(OUTPUT_FILEPATH_FINAL_CHK)

# COMMAND ----------

dbutils.fs.put(OUTPUT_FILEPATH_FINAL_CHK, str(cutoff_records_output_1.count()),True)

# COMMAND ----------

cutoff_records_output_1.coalesce(1).write.format("com.databricks.spark.csv").option("codec", "org.apache.hadoop.io.compress.GzipCodec").option("delimiter",OUTPUT_FILEDELIMETER).save(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

def removePartFilesGz(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv.gz")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+OUTPUT_FILEEXTENSION)
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

removePartFilesGz(OUTPUT_FILEPATH_FINAL)
# Databricks notebook source
# Mounting ADLS
# mountPoint = dbutils.notebook.run("/Egress/Utilities/MOUNT_ADLS_OUTBOUND_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Output File Extension","")
#dbutils.widgets.text("Output File Delimeter","")
#dbutils.widgets.text("Output File Header","")
#dbutils.widgets.text("MountPoint_Notebook_Path","")
#dbutils.widgets.text("STORAGE_ACCOUNT","")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase Name")
SQL_FP = dbutils.widgets.get("SQL File path")
PAR_LIST = dbutils.widgets.get("Parameters List")
OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
OUTPUT_FILEEXTENSION=dbutils.widgets.get("Output File Extension")
OUTPUT_FILEDELIMETER=dbutils.widgets.get("Output File Delimeter")
OUTPUT_FILEHEADER=dbutils.widgets.get("Output File Header")
MOUNTPOINT_NOTEBOOK_PATH=dbutils.widgets.get("MountPoint_Notebook_Path")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")

# COMMAND ----------

PAR_LIST.split(';')
parameter_list_map = {}
for i in PAR_LIST.split(';'):
  key = i.split('=')[0]
  value = i.split('=')[1]
  parameter_list_map[key] = value

# COMMAND ----------

parameter_list_map

# COMMAND ----------

#mountPoint = dbutils.notebook.run(MOUNTPOINT_NOTEBOOK_PATH, 60)

# COMMAND ----------

SNFL_DB_list=SNFL_DB.split(";")
for i in SNFL_DB_list:
  SNFL_DB
  
  print(i)

# COMMAND ----------

import os

for i in range(len(SNFL_DB_list)):
  os.system("%run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

query1 = """
create or replace table hive_metastore.staging__marketing__campaign.cmp7_sub_v1
select total_no_attempt, disposition_code as disp,store_nbr as store, response_dttm,response_channel,response_id
from {}.{}.campaign_resp 
where campaign_cd = 'C000000375' 
and response_channel in ('OUTBOUND', 'EMAIL', 'TEXT')
and cast(response_dttm as date) >= cast('{}' as date) 
    and cast(response_dttm as date) <= '{}' 
    and disposition_code in (38, 39, 40, 41, 51, 9, 20, 22, 30, 34);
""".format(parameter_list_map['pTD_DATABASE_MASTER_DATA'],parameter_list_map['pTD_DB_MARKETING'],parameter_list_map['extDttm1'],parameter_list_map['extDt2'])

query2 = """
create or replace table hive_metastore.staging__marketing__campaign.cmpgn_7_v1
SELECT /*+ BROADCASTJOIN (r) */ 
                c.audience_id,
                r.total_no_attempt,
                r.disp,
                r.store,
                c.rx_nbr,
                r.response_channel,
                c.response_id,
                r.response_dttm
         FROM   hive_metastore.staging__marketing__campaign.cmp7_sub_v1 r
                JOIN {}.{}.campaign_resp_cust c
                  ON c.response_id = r.response_id
""".format(parameter_list_map['pTD_DATABASE_MASTER_DATA'],parameter_list_map['pTD_DB_MARKETING'])

query3 = """
create or replace table hive_metastore.staging__marketing__campaign.cmpgn_final_v1
with stg_payer_scripts_tst_22
     AS (SELECT disp,
                store,
                a.rx_nbr,
                response_channel,
                response_id,
                fill_sold_dt,
                payer,
                payer2,
                response_dttm,
                dspn_fill_nbr
         FROM   hive_metastore.staging__marketing__campaign.cmpgn_7_v1 a
                LEFT JOIN (SELECT p.rx_nbr,
                                  p.relocate_fm_str_nbr AS str_nbr,
                                  p.rx_fill_nbr,
                                  p.rx_partial_fill_nbr,
                                  p.dspn_fill_nbr,
                                  p.fill_sold_dt,
                                  pat_id,
                CASE
                  WHEN plan_type IN ( 'Medicare Part D' ) THEN
                  'Med D'
                  WHEN plan_type NOT IN
                       ( 'Cash', 'Discount Card',
                         'Medicare Part D',
                         'State Medicaid',
                                'Managed Medicaid'
                       )
                THEN
                  'Commercial'
                  WHEN plan_type IN ( 'Managed Medicaid',
                                      'State Medicaid' )
                                  THEN
                  'Medicaid'
                  WHEN plan_type IN ( 'Discount Card' )
                       AND plan_name IN (
                           'Walgreens Prescription Savings Club' )
                        OR plan_name IN ( 'Walgreens WAGPlus' )
                THEN
                  'Prescription saving Club /WAG +'
                  WHEN ( plan_type IN ( 'Discount Card' )
                         AND plan_name NOT IN (
                             'Walgreens Prescription Savings Club'
                                              )
                       )
                        OR plan_type IN ( 'Cash' ) THEN
                  'Discount_Cards_Cash'
                  ELSE 'Unknown'
                END                   AS payer,
                CASE
                  WHEN plan_type IN ( 'Discount Card', 'Cash' )
                THEN
                  'CPRx'
                END                   AS payer2
                           FROM   (SELECT rx_nbr,
                                          relocate_fm_str_nbr,
                                          str_nbr,
                                          rx_fill_nbr,
                                          rx_partial_fill_nbr,
                                          dspn_fill_nbr,
                                          fill_sold_dt,
                                          fill_enter_dt,
                                          pat_id,
                                          fill_sold_yr,
                                          fill_enter_mnth
                                   FROM
     {0}.{1}.prescription_fill p
           WHERE  ( partial_fill_cd IS NULL
                     OR partial_fill_cd = 'P' )
                  AND fill_sold_yr IN {4}
                  AND fill_sold_dt BETWEEN '{5}' AND '{6}'
                  AND fill_stat_cd = 'SD'
                  AND fill_del_dt IS NULL
                  AND fill_sold_dt IS NOT NULL
                  AND fill_sold_dlrs IS NOT NULL)p
          LEFT OUTER JOIN (SELECT pfp.*,
                                  plan_type,
                                  plan_name,
                                  pc.plan_catg_eff_dt,
                                  pc.plan_catg_end_dt
                           FROM   (SELECT *
                                   FROM
{0}.{1}.prescription_fill_plan
WHERE  cob_ind = 'N'
     AND fill_adjud_cd IN ( 'A', 'L', 'X' )
      OR fill_adjud_cd IS NULL
      OR fill_adjud_cd = '') pfp
LEFT JOIN (SELECT plan_catg_id,
               edw_eff_dt,
               third_party_plan_id,
               bin_nbr,
               prcs_ctrl_nbr,
               plan_group_nbr,
               plan_name,
               plan_type,
               plan_catg_eff_dt,
               plan_catg_end_dt
        FROM   {0}.{2}.plan_category
        WHERE  Trim(history_seq_cd) = 'C'
               AND src_sys_cd = 'IC'
               AND Trim(del_ind) = 'N') pc
    ON COALESCE(pfp.third_party_plan_id, '#$#') =
                 COALESCE(Trim(pc.third_party_plan_id), '#$#')
       AND COALESCE(pfp.bin_nbr, '#$#') = COALESCE(Trim(pc.bin_nbr), '#$#')
       AND COALESCE(pfp.prcs_ctrl_nbr, '#$#') =
           COALESCE(Trim(pc.prcs_ctrl_nbr), '#$#')
       AND COALESCE(pfp.plan_group_nbr, '#$#') =
           COALESCE(Trim(pc.plan_group_nbr), '#$#')
WHERE  ( pfp.fill_enter_dt BETWEEN pc.plan_catg_eff_dt AND
     COALESCE(pc.plan_catg_end_dt, '9999-12-31')
     OR pc.third_party_plan_id IS NULL )) PFP
          ON p.rx_nbr = pfp.rx_nbr
             AND p.str_nbr = pfp.str_nbr
             AND p.rx_fill_nbr = pfp.rx_fill_nbr
             AND p.rx_partial_fill_nbr = pfp.rx_partial_fill_nbr
             AND p.fill_sold_yr = pfp.fill_sold_yr
             AND p.fill_enter_mnth = pfp.fill_enter_mnth
             AND pfp.fill_adjud_cd IN ( 'A', 'L', 'X', NULL, '' )
GROUP  BY p.rx_nbr,
        p.relocate_fm_str_nbr,
        p.rx_fill_nbr,
        p.rx_partial_fill_nbr,
        p.dspn_fill_nbr,
        p.fill_sold_dt,
        pat_id,
        plan_type,
        plan_name)b
       ON a.rx_nbr = b.rx_nbr
          AND a.store = b.str_nbr
 WHERE  ( fill_sold_dt < To_date(response_dttm)
           OR fill_sold_dt IS NULL )),
     stg_1_payer_scripts_22
     AS (SELECT disp,
                store,
                rx_nbr,
                response_channel,
                fill_sold_dt,
                payer,
                payer2,
                response_dttm
         FROM   (SELECT disp,
                        store,
                        a.rx_nbr,
                        response_channel,
                        a.fill_sold_dt,
                        payer,
                        payer2,
                        response_dttm,
                        Row_number()
                          OVER (
                            partition BY response_id, store, rx_nbr
                            ORDER BY fill_sold_dt DESC, dspn_fill_nbr DESC) AS
                        last_fill
                 FROM   stg_payer_scripts_tst_22 a)p
         WHERE  last_fill = 1
         GROUP  BY disp,
                   store,
                   rx_nbr,
                   response_channel,
                   fill_sold_dt,
                   payer,
                   payer2,
                   response_dttm),
     stg_2_payer_scripts_22
     AS (SELECT disp,
                store,
                rx_nbr,
                response_channel,
                fill_sold_dt,
                payer,
                response_dttm
         FROM   (SELECT disp,
                        store,
                        rx_nbr,
                        response_channel,
                        fill_sold_dt,
                        payer,
                        response_dttm
                 FROM   stg_1_payer_scripts_22 p
                 UNION
                 SELECT disp,
                        store,
                        rx_nbr,
                        response_channel,
                        fill_sold_dt,
                        payer2,
                        response_dttm
                 FROM   stg_1_payer_scripts_22 p
                 WHERE  payer2 IS NOT NULL)x
         GROUP  BY disp,
                   store,
                   rx_nbr,
                   response_channel,
                   fill_sold_dt,
                   payer,
                   response_dttm),
     outbound_base_22
     AS (SELECT disp,
                store,
                store_name,
                rx_nbr,
                response_channel,
                CASE
                  WHEN payer IS NULL THEN 'Unknown'
                  ELSE payer
                END AS payer
         FROM   (SELECT r.disp,
                        r.store,
                        loc.store_name,
                        r.rx_nbr,
                        'IVR_OUTBOUND'                         AS
                        response_channel,
                        payer,
                        Row_number()
                          OVER (
                            partition BY audience_id, r.store, r.rx_nbr
                            ORDER BY r.total_no_attempt DESC ) AS rnk
                 FROM   hive_metastore.staging__marketing__campaign.cmpgn_7_v1 r
                        LEFT JOIN stg_2_payer_scripts_22 p
                               ON r.store = p.store
                                  AND r.rx_nbr = p.rx_nbr
                        LEFT JOIN
                        {0}.{3}.location_store
                        loc
                               ON r.store = loc.store_nbr
                                  AND '{6}' BETWEEN loc.edw_rec_begin_dt
                                                           AND
                                                           loc.edw_rec_end_dt
                 WHERE  r.disp IN ( 38, 39, 40, 41, 51 )
                        AND r.response_channel = 'OUTBOUND'
                        AND payer <> 'CPRx')x
         WHERE  rnk = 1
         UNION
         SELECT r.disp,
                r.store,
                loc.store_name,
                r.rx_nbr,
                'IVR_OUTBOUND' AS response_channel,
                payer
         FROM   hive_metastore.staging__marketing__campaign.cmpgn_7_v1 r
                LEFT JOIN stg_2_payer_scripts_22 p
                       ON r.store = p.store
                          AND r.rx_nbr = p.rx_nbr
                LEFT JOIN {0}.{3}.location_store
                          loc
                       ON r.store = loc.store_nbr
                          AND '{6}' BETWEEN loc.edw_rec_begin_dt AND
                                                   loc.edw_rec_end_dt
         WHERE  r.response_channel IN ( 'OUTBOUND' )
                AND r.disp IN ( 38, 39, 40, 41, 51 )
                AND payer = 'CPRx'),
     eml_8
     AS (SELECT p.disp,
                a.store,
                store_name,
                a.rx_nbr,
                a.response_channel,
                CASE
                  WHEN payer IS NULL THEN 'Unknown'
                  ELSE payer
                END AS payer
         FROM   hive_metastore.staging__marketing__campaign.cmpgn_7_v1 a
                JOIN stg_2_payer_scripts_22 p
                  ON a.store = p.store
                     AND a.rx_nbr = p.rx_nbr
                     AND a.response_dttm = p.response_dttm
                LEFT JOIN {0}.{3}.location_store
                          loc
                       ON a.store = loc.store_nbr
                          AND '{6}' BETWEEN loc.edw_rec_begin_dt AND
                                                   loc.edw_rec_end_dt
         WHERE  a.response_channel IN ( 'EMAIL', 'TEXT' )
                AND p.disp IN ( 9, 20, 22, 30, 34 ))
SELECT ad_week,
       store,
       store_name,
       campaign,
       response_channel,
       CASE
         WHEN payer IS NULL THEN 'Unknown'
         ELSE payer
       END                         AS payer,
       Sum(distinct_count)         AS distinct_count,
       Sum(delivered_counts)       AS delivered_counts,
       Sum(refills_ordered_counts) AS refills_ordered_counts,
       Sum(do_not_refill_counts)   AS do_not_refill_counts,
       Sum(refills_failure_counts) AS refills_failure_counts
FROM   (SELECT From_unixtime(Unix_timestamp('{6}', 'yyyy-MM-dd'),
               'yyyyMMdd') AS
                      ad_week
                       ,
               store,
               store_name,
               'CIT Refill Reminder Integration (RRI)'
               AS
                       campaign,
               response_channel,
               payer,
               Count(DISTINCT rx_nbr)
               AS
                       distinct_count,
               Sum(CASE
                     WHEN disp IN ( 38, 39, 40, 41, 51 )
                          AND response_channel IN ( 'IVR_OUTBOUND' ) THEN 1
                     ELSE 0
                   END)
               AS
                       delivered_counts,
               Sum(CASE
                     WHEN disp = 39
                          AND response_channel IN ( 'IVR_OUTBOUND' ) THEN 1
                     ELSE 0
                   END)
               AS
                       refills_ordered_counts,
               Sum(CASE
                     WHEN disp = 40
                          AND response_channel IN ( 'IVR_OUTBOUND' ) THEN 1
                     ELSE 0
                   END)
               AS
                       do_not_refill_counts,
               Sum(CASE
                     WHEN disp = 51
                          AND response_channel IN ( 'IVR_OUTBOUND' ) THEN 1
                     ELSE 0
                   END)
               AS
                       refills_failure_counts
        FROM   outbound_base_22 a
        GROUP  BY From_unixtime(Unix_timestamp('{6}', 'yyyy-MM-dd'),
                  'yyyyMMdd')
               ,
                  store,
                  store_name,
                  'CIT Refill Reminder Integration (RRI)',
                  response_channel,
                  payer
        UNION
        SELECT ad_week,
               x.store,
               x.store_name,
               x.campaign,
               x.channel,
               x.payer,
               CASE
                 WHEN distinct_count IS NULL THEN 0
                 ELSE distinct_count
               END AS distinct_count,
               delivered_counts,
               refills_ordered_counts,
               do_not_refill_counts,
               refills_failure_counts
        FROM   (SELECT From_unixtime(Unix_timestamp('{6}', 'yyyy-MM-dd'),
                       'yyyyMMdd') AS
                              ad_week
                              ,
                       a.store,
                       a.store_name,
                       'CIT Refill Reminder Integration (RRI)'
                       AS
                              campaign,
                       a.response_channel
                       AS
                              Channel,
                       a.payer,
                       Sum(CASE
                             WHEN a.disp IN ( 9 )
                                  AND a.response_channel IN ( 'TEXT', 'EMAIL' )
                           THEN 1
                             ELSE 0
                           END)
                       AS
                              delivered_counts,
                       Sum(CASE
                             WHEN a.disp IN ( 20, 22 )
                                  AND a.response_channel IN ( 'EMAIL' ) THEN 1
                             ELSE 0
                           END)
                       AS
                              refills_ordered_counts,
                       Sum(CASE
                             WHEN a.disp = 34
                                  AND a.response_channel IN ( 'EMAIL' ) THEN 1
                             ELSE 0
                           END)
                       AS
                              do_not_refill_counts,
                       Sum(CASE
                             WHEN a.disp = 30
                                  AND a.response_channel IN ( 'EMAIL' ) THEN 1
                             ELSE 0
                           END)
                       AS
                              refills_failure_counts
                FROM   eml_8 a
                GROUP  BY From_unixtime(Unix_timestamp('{6}',
                                        'yyyy-MM-dd'),
                          'yyyyMMdd')
               ,
                          a.store,
                          a.store_name,
                          'CIT Refill Reminder Integration (RRI)',
                          a.response_channel,
                          a.payer) x
               LEFT JOIN (SELECT Count(DISTINCT rx_nbr) AS distinct_count,
                                 b.store,
                                 b.response_channel,
                                 b.payer
                          FROM   eml_8 b
                          WHERE  disp = 9
                                 AND response_channel IN ( 'TEXT', 'EMAIL' )
                          GROUP  BY b.store,
                                    b.response_channel,
                                    b.payer) b
                      ON x.store = b.store
                         AND x.payer = b.payer
                         AND x.channel = b.response_channel)x
GROUP  BY ad_week,
          store,
          store_name,
          campaign,
          response_channel,
          CASE
            WHEN payer IS NULL THEN 'Unknown'
            ELSE payer
          END; 
""".format(parameter_list_map['pTD_DATABASE_MASTER_DATA'],parameter_list_map['pTD_DB_PHARMACY'],parameter_list_map['pTD_DB_PHARMACY_PLAN'],parameter_list_map['pTD_DB_LOCATION'],parameter_list_map['fillsldyr'],parameter_list_map['extDt1'],parameter_list_map['extDt2'])


# COMMAND ----------

# %sql
# query1
x = spark.sql(query1)
y = spark.sql(query2)
z = spark.sql(query3)


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from hive_metastore.staging__marketing__campaign.cmp7_sub_v1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from hive_metastore.staging__marketing__campaign.cmpgn_7_v1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from hive_metastore.staging__marketing__campaign.cmpgn_final_v1;

# COMMAND ----------

cutoff_records_output = spark.sql("select * from hive_metastore.staging__marketing__campaign.cmpgn_final_v1")

# COMMAND ----------

cutoff_records_output.count()

# COMMAND ----------

cnt=0
index3=0
CONTAINER=''
index2=0
for i,c in enumerate(OUTPUT_FILEPATH):
  if(c=='/'):
    cnt=cnt+1
  if(cnt==2 and c=='/'):
    index2=i
  if(cnt==3):
    index3=i
    break
CONTAINER=OUTPUT_FILEPATH[index2+1:index3]
#print(CONTAINER)
OUTPUT_PATH=OUTPUT_FILEPATH[index3+1:]
#print(OUTPUT_PATH)
#OUTPUT_PATH='retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy'
OUTPUT_FILEPATH_FINAL='abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_PATH
#OUTPUT_FILEPATH_FINAL='abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net//egress/retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy'
cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER,multiline=True).format('csv').save(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

# print(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

#outpath='/mnt/wrangled/tmp/Egress'
#cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER).format('csv').save(OUTPUT_FILEPATH)

# COMMAND ----------

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+OUTPUT_FILEEXTENSION)
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

removePartFiles(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table staging__marketing__campaign.cmp7_sub_v1

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table staging__marketing__campaign.cmpgn_7_v1

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table staging__marketing__campaign.cmpgn_final_v1
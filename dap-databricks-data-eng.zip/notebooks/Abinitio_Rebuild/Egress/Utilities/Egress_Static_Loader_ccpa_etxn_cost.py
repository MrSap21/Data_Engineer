# Databricks notebook source
# dbutils.widgets.text("Data_Warehouse_Static","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("DataBase_Name_Static","DEV_STAGING")
# dbutils.widgets.text("Input_File_Static","/egress/static/wagus_iri_transactions_add_20220515_00001802.dat")
# dbutils.widgets.text("Format_Static","csv")
# dbutils.widgets.text("Header_Static","false")
# dbutils.widgets.text("Delimiter_Static","|")
# dbutils.widgets.text("Schema_Static", "RETAIL_SALES")
# dbutils.widgets.text("DBtable_Static", "STG_IRI_POS_TRANSACTION_COST")
# dbutils.widgets.text("MountPoint_Notebook_Path_Static", "/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP")
# dbutils.widgets.text("STORAGE_ACCOUNT", "dapdevadlsutl02")
# dbutils.widgets.text("CONTAINER", "sql")
# dbutils.widgets.text("FILE_CONTAINS", "_add")
# dbutils.widgets.text("CCPA_Table", "_add")
# dbutils.widgets.text("current_file_name", "")

# COMMAND ----------

SNFL_WH = dbutils.widgets.get("Data_Warehouse_Static")
SNFL_DB = dbutils.widgets.get("DataBase_Name_Static")
File_Path = dbutils.widgets.get("Input_File_Static")
File_Format = dbutils.widgets.get("Format_Static")
Header = dbutils.widgets.get("Header_Static")
Delimiter = dbutils.widgets.get("Delimiter_Static")
Schema = dbutils.widgets.get("Schema_Static")
dbtable = dbutils.widgets.get("DBtable_Static")
mount_path = dbutils.widgets.get("MountPoint_Notebook_Path_Static")
STORAGE_ACCOUNT = dbutils.widgets.get("STORAGE_ACCOUNT")
CONTAINER_NAME = dbutils.widgets.get("CONTAINER")
file_contains = dbutils.widgets.get("FILE_CONTAINS")
ccpa_table = dbutils.widgets.get("CCPA_Table")
current_file_name = dbutils.widgets.get("current_file_name")

# COMMAND ----------

# mountPoint = dbutils.notebook.run(mount_path, 60)

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# import glob

# COMMAND ----------

# path = 'abfss://retail-nonsnstv@dlxdevsemprtoutsa01.dfs.core.windows.net//retail_and_supply_chain/iri/etransactions/archive/*.dat.gz'
# file = glob.glob(glob.escape(path))
# print(file)

# COMMAND ----------

# print(str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+File_Path)))

# COMMAND ----------

var=str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+File_Path))

# COMMAND ----------

add_file_name = current_file_name.split('cost')[0]+'add_'+current_file_name.split('_')[-2]
print(add_file_name)
x=var.split("FileInfo")
y=[]
date = []
date_file = {}
for i in range(1,len(x)):
  gg = x[i].replace(",","")
  gg = gg.split(" ")[1].replace("'","").replace(",","")
#   print("ggggggggg----------------",gg)
  if add_file_name in gg:
    print("inside    iffff --------- 13 line")
    date_file[str(gg).split('=')[-1]] = gg.split("_")[-1].split(".")[0]
    break

# COMMAND ----------

# file_seq_nbr = list(date_file.values())
# file_seq_nbr.sort()
# latest_file_seq = file_seq_nbr[-4]

# COMMAND ----------

latest_file = list(date_file.keys())[list(date_file.values()).index(list(date_file.values())[0])]
print('=-----',latest_file)

# COMMAND ----------

File_Path = File_Path+'/'+latest_file
print(File_Path)

# COMMAND ----------

from pyspark.sql.functions import * 
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.functions import col

# STORAGE_ACCOUNT = 'dapdevadlsutl02'
# CONTAINER='sql'
STATIC_FILE_PATH='abfss://'+CONTAINER_NAME+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+File_Path
print(STATIC_FILE_PATH)

df_stg = spark.read.format(File_Format).option("header", Header).option("delimiter", Delimiter).load(STATIC_FILE_PATH)#'/egress/static/wagus_iri_transactions_add_20220515_00001802.dat'

# COMMAND ----------

# df_stg.count()

# COMMAND ----------

# df_stg.display()

# COMMAND ----------

options = {
"sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
"sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
"pem_private_key" : pkb,
"sfDatabase" :SNFL_DB,
"sfSchema" : Schema,
"sfWarehouse" : SNFL_WH,
}

sfUtils=sc._jvm.net.snowflake.spark.snowflake.Utils

snow_query_ccpa_1 = "select * from {0}.{1}.{2} where COMPOSITE_TYPE_CD = 'M' and MSG_TYPE_CD = '1' and SRC_SYS_CD = 'LR'".format(SNFL_DB,Schema,ccpa_table)

snow_query_ccpa_2 = "select * from {0}.{1}.{2} where COMPOSITE_TYPE_CD = 'A' and MSG_TYPE_CD = '2' and SRC_SYS_CD = 'CDI'".format(SNFL_DB,Schema,ccpa_table)

# COMMAND ----------

ccpa_ids_1 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",snow_query_ccpa_1)\
   .load()

ccpa_ids_2 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",snow_query_ccpa_2)\
   .load()


# COMMAND ----------

#  ccpa_ids_2.count()

# COMMAND ----------

columns = ["transaction_date","transaction_time","transaction_number","sales_txn_type","src_sys_cd","store_number","loyalty_card_number","selling_price","upc","retailer_product_identifier","item_list_price","item_net_price","line_item_seq_nbr","item_quantity","weighted_item_weight","weighted_item_count","item_deal_quantity","item_sale_quantity","item_net_amount","item_gross_amount","return_indicator","mid","card_id","cost_dlrs","cost_adj_dlrs","loyalty_cost_adj_dlrs","gross_profit","wic","sale_ind"]

# columns =["transaction_date","transaction_time","transaction_number","sales_txn_type","src_sys_cd","store_number","loyalty_card_number","selling_price","mid","card_id","upc","wic","retailer_product_identifier","item_list_price","item_net_price","line_item_seq_nbr","item_quantity","weighted_item_weight","weighted_item_count","item_deal_quantity","item_sale_quantity","item_net_amount","item_gross_amount","return_indicator","cost_dlrs","cost_adj_dlrs","loyalty_cost_adj_dlrs","gross_profit","sale_ind"]

# COMMAND ----------

# len(columns)

# COMMAND ----------

#df_stg.display()
if df_stg.count() != 0:
  for column in df_stg.columns:
    count = column.replace("_c","")
    df_stg = df_stg.withColumnRenamed(column, columns[int(count)])
    
else:
    print("staging table is empty")

# COMMAND ----------

# df_stg.display()

# COMMAND ----------

if df_stg.count() != 0:
#   for column in df_stg.columns:
#     count = column.replace("_c","")
#   #   print(int(count)
#     df_stg = df_stg.withColumnRenamed(column, columns[int(count)])
    a1 = F.concat(
      F.lit("E"),
      F.col("CUST_SRC_ID"),
  ).alias("CUST_SRC_ID_new")
    ccpa_ids_2_new = ccpa_ids_2.select("CUST_SRC_ID","SRC_SYS_CD","COMPOSITE_TYPE_CD","MSG_TYPE_CD","OPT_OUT_BEGIN_DT","OPT_OUT_END_DT",a1)
    
else:
    print("staging table is empty")

# COMMAND ----------

# ccpa_ids_2_new.display()

# COMMAND ----------

# ccpa_ids_2_new.display()

# COMMAND ----------

# select("transaction_date","transaction_time","transaction_number","sales_txn_type","src_sys_cd","store_number","loyalty_card_number","selling_price","mid","card_id","upc","wic","retailer_product_identifier","item_list_price","item_net_price","line_item_seq_nbr","item_quantity","weighted_item_weight","weighted_item_count","item_deal_quantity","item_sale_quantity","item_net_amount","item_gross_amount","return_indicator","cost_dlrs","cost_adj_dlrs","loyalty_cost_adj_dlrs","gross_profit","sale_ind",a1)
  

# COMMAND ----------



# COMMAND ----------

# a1 = F.concat(
#     F.col("mid"),
#     F.lit("E"),
# ).alias("mid_new")

# df_stg_new = df_stg.select("transaction_date","transaction_time","transaction_number","sales_txn_type","src_sys_cd","store_number","loyalty_card_number","selling_price","mid","card_id","upc","wic","retailer_product_identifier","item_list_price","item_net_price","item_quantity","weighted_item_weight","weighted_item_count","item_deal_quantity","item_sale_quantity","item_net_amount","item_gross_amount","return_indicator","cost_dlrs","cost_adj_dlrs","loyalty_cost_adj_dlrs","gross_profit","sale_ind","line_item_seq_nbr",a1)

# COMMAND ----------

# df_stg_new.filter(df_stg_new.mid.isNull()).count()

# COMMAND ----------

# df_stg_new = df_stg_new.withColumn("mid_new",lit("201203393359379"))

# COMMAND ----------

#ccpa_ids_1.display()

# COMMAND ----------

#df_stg_new.display()

# COMMAND ----------

#ccpa_ids_2 = ccpa_ids_2.withColumn("CUST_SRC_ID",lit("1070085866"))
#ccpa_ids_1 = ccpa_ids_1.withColumn("CUST_SRC_ID",lit("201203155527512"))

# COMMAND ----------

#df_stg.display()

# COMMAND ----------

#ccpa_ids_2.display()

# COMMAND ----------

#ccpa_ids_2.count()

# COMMAND ----------

if df_stg.count() != 0:
  df_add_ccp1 =  df_stg.join(ccpa_ids_1,df_stg.loyalty_card_number ==  ccpa_ids_1.CUST_SRC_ID,"inner")
  df_add_ccp2 = df_stg.join(ccpa_ids_2_new,df_stg.mid == ccpa_ids_2_new.CUST_SRC_ID_new,"inner")
else:
  print("stagging table is empty")

# COMMAND ----------

# df_add_ccp1.count()
# df_add_ccp2.count()

# COMMAND ----------

# df_stg_new.filter(df_stg_new.mid == '1070085866').count()

# COMMAND ----------

#20+36


# COMMAND ----------

#df_stg.filter(df_stg.mid == '1070085866').count()
#df_stg.filter(df_stg.loyalty_card_number == '201203155527512').count()

# COMMAND ----------

2476048-56

# COMMAND ----------

# df_add_ccp2.columns

# COMMAND ----------

# df_stg_new.columns

# COMMAND ----------

#df_add_ccp1.display()

# COMMAND ----------

#df_stg.count()

# COMMAND ----------

#df_stg.filter(df_stg.loyalty_card_number == '201203155527512').display()

# COMMAND ----------

#df_add_ccp1.display()

# COMMAND ----------

#print(df_stg.count(),"---",df_add_ccp1.count())

# COMMAND ----------

#2476028 -36

# COMMAND ----------

#df_stg.filter(df_stg.loyalty_card_number.isNull()).count()

# COMMAND ----------

if df_stg.count() != 0:
#   rows_to_delete_11 = df_stg.filter(df_stg.loyalty_card_number != "201203155527512" )  #df_add_ccp1.loyalty_card_number 
  df_stg = df_stg.join(df_add_ccp1, on=["loyalty_card_number"], how='left_anti')
else:
  print("stagging table is empty")

# COMMAND ----------

#df_stg.count()

# COMMAND ----------

#df_add_ccp2.display()
# df_stg.filter(df_stg.mid == '1070085866').count()

# COMMAND ----------

if df_stg.count() != 0:
#   rows_to_delete22 = rows_to_delete_11.filter(rows_to_delete_11.mid == '1070085866')
  df_stg = df_stg.join(df_add_ccp2, on=["mid"], how='left_anti')
else:
  print("stagging table is empty")

# COMMAND ----------

#df_stg.count()

# COMMAND ----------

# df_with_rows_deleted.display()
# df_with_rows_deleted.display()

# COMMAND ----------

if df_stg.count() != 0:
  df_stg = df_stg.select(
 'transaction_date',
 'transaction_time',
 'transaction_number',
 'sales_txn_type',
 'src_sys_cd',
 'store_number',
 'loyalty_card_number',
 'selling_price',
 'mid',
 'card_id',
 'upc',
 'wic',
 'retailer_product_identifier',
 'item_list_price',
 'item_net_price',
 'line_item_seq_nbr',
 'item_quantity',
 'weighted_item_weight',
 'weighted_item_count',
 'item_deal_quantity',
 'item_sale_quantity',
 'item_net_amount',
 'item_gross_amount',
 'return_indicator',
 'cost_dlrs',
 'cost_adj_dlrs',
 'loyalty_cost_adj_dlrs',
 'gross_profit',
 'sale_ind')
else:
  print("stagging table is empty")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField, StringType,DecimalType

# COMMAND ----------

if df_stg.count() != 0:
  df_stg.write.format("net.snowflake.spark.snowflake") \
        .mode("overwrite") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("Schema", Schema) \
        .option("dbtable", dbtable) \
        .save()
else: 
  schema = StructType([StructField('transaction_date', StringType(), True),
  StructField('transaction_time', StringType(), True),
  StructField('transaction_number', StringType(), True),
  StructField('sales_txn_type', StringType(), True),
  StructField('src_sys_cd', StringType(), True),
  StructField('store_number', DecimalType(), True),
  StructField('loyalty_card_number', StringType(), True),
  StructField('selling_price', DecimalType(), True),
  StructField('mid', DecimalType(), True),
  StructField('card_id', DecimalType(), True),
  StructField('upc', DecimalType(), True),
  StructField('wic', DecimalType(), True),
  StructField('retailer_product_identifier', DecimalType(), True),
  StructField('item_list_price', DecimalType(), True),
  StructField('item_net_price', DecimalType(), True),
  StructField('line_item_seq_nbr', DecimalType(), True),
  StructField('item_quantity', DecimalType(), True),
  StructField('weighted_item_weight', DecimalType(), True),
  StructField('weighted_item_count', DecimalType(), True),
  StructField('item_deal_quantity', DecimalType(), True), 
  StructField('item_sale_quantity', DecimalType(), True),
  StructField('item_net_amount', DecimalType(), True),
  StructField('item_gross_amount', DecimalType(), True),
  StructField('return_indicator', StringType(), True),
  StructField('cost_dlrs', DecimalType(), True),
  StructField('cost_adj_dlrs', DecimalType(), True),
  StructField('loyalty_cost_adj_dlrs', DecimalType(), True),
  StructField('gross_profit', DecimalType(), True),
  StructField('sale_ind', StringType(), True),

    ])

  df_stg = spark.createDataFrame(data = [],
                           schema = schema)
  
  df_stg.write.format("net.snowflake.spark.snowflake") \
        .mode("overwrite") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("Schema", Schema) \
        .option("dbtable", dbtable) \
        .save()


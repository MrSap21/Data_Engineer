# Databricks notebook source
# Mounting ADLS
# mountPoint = dbutils.notebook.run("/Egress/Utilities/MOUNT_ADLS_OUTBOUND_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Output File Extension","")
#dbutils.widgets.text("Output File Delimeter","")
#dbutils.widgets.text("Output File Header","")
#dbutils.widgets.text("MountPoint_Notebook_Path","")
#dbutils.widgets.text("STORAGE_ACCOUNT","")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase Name")
SQL_FP = dbutils.widgets.get("SQL File path")
PAR_LIST = dbutils.widgets.get("Parameters List")
OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
OUTPUT_FILEEXTENSION=dbutils.widgets.get("Output File Extension")
OUTPUT_FILEDELIMETER=dbutils.widgets.get("Output File Delimeter")
OUTPUT_FILEHEADER=dbutils.widgets.get("Output File Header")
MOUNTPOINT_NOTEBOOK_PATH=dbutils.widgets.get("MountPoint_Notebook_Path")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")

# COMMAND ----------

#mountPoint = dbutils.notebook.run(MOUNTPOINT_NOTEBOOK_PATH, 60)

# COMMAND ----------

SNFL_DB_list=SNFL_DB.split(";")
for i in SNFL_DB_list:
  SNFL_DB
  
  print(i)

# COMMAND ----------

import os

for i in range(len(SNFL_DB_list)):
  os.system("%run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH")


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#etl_query = "SELECT * FROM {0}.{1}".format(SNFL_DB,TBL_NAME)
#Putting parameter values in SQL and storing it.
snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 3000, 
                 {"parameters_list":PAR_LIST,
                  "sql_file_path":SQL_FP
                  });
snow_query=snow_query.replace('\\n',' ').replace('\\','')
print(snow_query)
#running the sql in snowflake and storing the result in a dataframe
cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",snow_query)\
   .load()

# COMMAND ----------

#Displaying the data.
# display(cutoff_records_output)
cutoff_records_output.count()

# COMMAND ----------

#cutoff_records_output.write.format('com.databricks.spark.csv').save('/mnt/wrangled/master_data/Egress_test2.dat')

# COMMAND ----------

#cutoff_records_output.repartition(1).write.mode("overwrite").csv('/mnt/wrangled/tmp/Egress_test')
#dbutils.fs.cp('/mnt/wrangled/tmp/Egress_test/*.csv','/mnt/wrangled/tmp/output/Egress_test2.dat')

# COMMAND ----------


#Test POC
#cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER).format('csv').save('abfss://egress@dapdevadlsoutb01.dfs.core.windows.net//retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy')
#CONTAINER='egress'
#STORAGE_ACCOUNT='dapdevadlsoutb01'
cnt=0
index3=0
CONTAINER=''
index2=0
for i,c in enumerate(OUTPUT_FILEPATH):
  if(c=='/'):
    cnt=cnt+1
  if(cnt==2 and c=='/'):
    index2=i
  if(cnt==3):
    index3=i
    break
CONTAINER=OUTPUT_FILEPATH[index2+1:index3]
#print(CONTAINER)
OUTPUT_PATH=OUTPUT_FILEPATH[index3+1:]
#print(OUTPUT_PATH)
#OUTPUT_PATH='retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy'
OUTPUT_FILEPATH_FINAL='abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_PATH
#OUTPUT_FILEPATH_FINAL='abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net//egress/retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy'
cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER,multiline=True).format('csv').save(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

# print(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

#outpath='/mnt/wrangled/tmp/Egress'
#cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER).format('csv').save(OUTPUT_FILEPATH)

# COMMAND ----------

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+OUTPUT_FILEEXTENSION)
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

removePartFiles(OUTPUT_FILEPATH_FINAL)
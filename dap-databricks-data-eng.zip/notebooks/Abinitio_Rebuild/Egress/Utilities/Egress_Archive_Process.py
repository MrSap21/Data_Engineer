# Databricks notebook source
# dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("DataBase_Name","")
# dbutils.widgets.text("Schema","")
# dbutils.widgets.text("table","")
# dbutils.widgets.text("src_stream_name","")
# dbutils.widgets.text("proj_name","")
# dbutils.widgets.text("extract_name","")
# dbutils.widgets.text("CONTAINER_NAME","")
# dbutils.widgets.remove("ACCOUNT_NAME")
# dbutils.widgets.text("name_starts_with","")
# dbutils.widgets.text("STORAGE_ACCOUNT","")
# dbutils.widgets.remove("DataBase_Name")
# dbutils.widgets.remove("Data_Warehouse")
# dbutils.widgets.remove("Schema")
# dbutils.widgets.remove("extract_name")
# dbutils.widgets.remove("file_extention")
# dbutils.widgets.remove("name_starts_with")
# dbutils.widgets.remove("proj_name")
# dbutils.widgets.remove("src_stream_name")
# dbutils.widgets.remove("table")
dbutils.widgets.text("BASE_PATH","")
dbutils.widgets.text("FILE_PATH","")

# COMMAND ----------

#Creating Parameters for widgets.
# SNFL_WH = dbutils.widgets.get("Data_Warehouse")
# SNFL_DB = dbutils.widgets.get("DataBase_Name")
# SQL_FP = dbutils.widgets.get("SQL_File_path")
# PAR_LIST = dbutils.widgets.get("Parameters_List")
#OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
# SCHEMA=dbutils.widgets.get("Schema")
# Table=dbutils.widgets.get("table")
# EXTRACT_NM=dbutils.widgets.get("extract_name")
# # FILE_ST_NM=dbutils.widgets.get("file_start_name")
# PROJ_NM=dbutils.widgets.get("proj_name")
# SRC_STREAM=dbutils.widgets.get("src_stream_name")
BASE_PATH=dbutils.widgets.get("BASE_PATH")
FILE_PATH=dbutils.widgets.get("FILE_PATH")
CONTAINER_NAME=dbutils.widgets.get("CONTAINER_NAME")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")

# COMMAND ----------

FILE_PATH_LIST=FILE_PATH.split(";")
print(FILE_PATH_LIST)

# COMMAND ----------

for ele in FILE_PATH_LIST:
  FILE_PATH_ELE=ele.split("~")[0]
  number_of_files_list=ele.split("~")[1]
  print(FILE_PATH_ELE,number_of_files_list)
  exptn_occ_at_folder_level = False
  try:
    var =  str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+BASE_PATH+FILE_PATH_ELE))
#     print(var)
  except Exception as e:
    print("inside exception - ")
    exptn_occ_at_folder_level = True
  if exptn_occ_at_folder_level:
    print("insnie continue")
    continue

  x=var.split("FileInfo")
  y=[]
  file_holder={}
  for i in range(1,len(x)):
     first_level_split=x[i].split("=")
     #print(first_level_split)
     #print(len(first_level_split))
     key_=first_level_split[1].replace("'","")
     key=key_.replace('"',"")
     key=str(key.split(",")[0])
     value_=first_level_split[4].replace("'","")
     value=value_.replace(")","")
     value=value.replace(",","")
     value=value.replace("size","")
     value=value.replace("]","")
     value=int(value.strip())
     file_holder[key]=value
  # print(file_holder)
  # print("============================================")
  file_holder = sorted(file_holder.items(), key=lambda x:x[1])
  sortdict = dict(file_holder)
  print(sortdict)
  number_of_files_list=int(number_of_files_list)
  number_of_files_list=(-number_of_files_list)
  sortdict_files_org=list(sortdict.keys())
  sortdict_files=sortdict_files_org[0:number_of_files_list]
  print('len --- ',len(sortdict_files_org),'number--',number_of_files_list)
  if len(sortdict_files_org) == abs(number_of_files_list)+1:
    print('if conditon is true for latest archive')
    continue
  for element in sortdict_files:
    print(element,"--------")
    try:
      dbutils.fs.mkdirs("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+BASE_PATH+FILE_PATH_ELE+"/archive")
      dbutils.fs.mv(element,"abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+BASE_PATH+FILE_PATH_ELE+"/archive")
    except Exception as e:
      print("exception occured in the last")



# COMMAND ----------

# m={'key1':1,'key2':2}
# print(m.keys())
# l=list(m.keys())
# print(type(l))

# COMMAND ----------

# print(first_level_split[0])
# print(first_level_split[1])
# print(first_level_split[2])
# print(first_level_split[3])
# for i in first_level_split:
#   print(i)
#   print("---")


# COMMAND ----------

# var =  str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+NAME_STARTS_WITH))
# #print(var) 
# x=var.split("FileInfo")
# y=[]
# for i in range(1,len(x)):
# #   print("----",x[i])
#   if FILE_EXTENSION in x[i]:
#     y.append(x[i].replace(",",""))
# print(y)
# LATEST_FILE = y[-1].split(' ')[1].split('name=')[-1].replace("'","")
# last='abfss://'+CONTAINER_NAME+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+NAME_STARTS_WITH+LATEST_FILE
# df = spark.read.format("csv").option("header", "true").option("multiline","true").option("delimiter", "|").load(last)
# df_pSQL_PARM_5=df.count()
# print(df_pSQL_PARM_5)
# Databricks notebook source
# Mounting ADLS
# mountPoint = dbutils.notebook.run("/Egress/Utilities/MOUNT_ADLS_OUTBOUND_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Output File Extension","")
#dbutils.widgets.text("Output File Delimeter","")
#dbutils.widgets.text("Output File Header","")
#dbutils.widgets.text("MountPoint_Notebook_Path","")
#dbutils.widgets.remove("OUTPUT_FILEPATH_LOOKUP")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase Name")
SQL_FP = dbutils.widgets.get("SQL File path")
PAR_LIST = dbutils.widgets.get("Parameters List")
OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
OUTPUT_FILEEXTENSION=dbutils.widgets.get("Output File Extension")
OUTPUT_FILEDELIMETER=dbutils.widgets.get("Output File Delimeter")
OUTPUT_FILEHEADER=dbutils.widgets.get("Output File Header")
MOUNTPOINT_NOTEBOOK_PATH=dbutils.widgets.get("MountPoint_Notebook_Path")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")
#OUTPUT_FILEPATH_LOOKUP=dbutils.widgets.get("OUTPUT_FILEPATH_LOOKUP")
TIMESTAMP=dbutils.widgets.get("TIMESTAMP")

# COMMAND ----------

#mountPoint = dbutils.notebook.run(MOUNTPOINT_NOTEBOOK_PATH, 60)

# COMMAND ----------

SNFL_DB_list=SNFL_DB.split(";")
for i in SNFL_DB_list:
  SNFL_DB
  
  print(i)

# COMMAND ----------

import os

for i in range(len(SNFL_DB_list)):
  os.system("%run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH")


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#etl_query = "SELECT * FROM {0}.{1}".format(SNFL_DB,TBL_NAME)
#Putting parameter values in SQL and storing it.
snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 3000, 
                 {"parameters_list":PAR_LIST,
                  "sql_file_path":SQL_FP
                  });
snow_query=snow_query.replace('\\n',' ').replace('\\','')
print(snow_query)
#running the sql in snowflake and storing the result in a dataframe
cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",snow_query)\
   .load()

# COMMAND ----------

#cutoff_records_output.length()

# COMMAND ----------

# import pandas as pd
# import pyspark.sql.functions as F
# from pyspark.sql.functions import col
# cnt=0
# index3=0
# CONTAINER=''
# index2=0
# for i,c in enumerate(OUTPUT_FILEPATH_LOOKUP):
#   if(c=='/'):
#     cnt=cnt+1
#   if(cnt==2 and c=='/'):
#     index2=i
#   if(cnt==3):
#     index3=i
#     break
# CONTAINER=OUTPUT_FILEPATH_LOOKUP[index2+1:index3]
# #print(CONTAINER)
# OUTPUT_PATH=OUTPUT_FILEPATH_LOOKUP[index3+1:]
# # STORAGE_ACCOUNT = 'dapdevadlsutl02'
# # CONTAINER='sql'
# LOOKUP_FILE_PATH='abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_PATH+OUTPUT_FILEEXTENSION
# print(LOOKUP_FILE_PATH)

# df_stg = spark.read.format("csv").option("header", OUTPUT_FILEHEADER).option("delimiter", OUTPUT_FILEDELIMETER).load(LOOKUP_FILE_PATH)

# COMMAND ----------

# cutoff_records_output.count()
# cutoff_records_output.show()

# COMMAND ----------

# if df_stg.count() != 0:
# #   rows_to_delete22 = rows_to_delete_11.filter(rows_to_delete_11.mid == '1070085866')
#   cutoff_records_output = cutoff_records_output.join(df_stg, on=["MAST_CUST_ID"], how='left_anti')
# else:
#   print("stagging table is empty")

# COMMAND ----------

# cutoff_records_output.count()
# cutoff_records_output.show()

# COMMAND ----------

#Displaying the data.
# display(cutoff_records_output)
#cutoff_records_output.count()

# COMMAND ----------

#cutoff_records_output.write.format('com.databricks.spark.csv').save('/mnt/wrangled/master_data/Egress_test2.dat')

# COMMAND ----------

#cutoff_records_output.repartition(1).write.mode("overwrite").csv('/mnt/wrangled/tmp/Egress_test')
#dbutils.fs.cp('/mnt/wrangled/tmp/Egress_test/*.csv','/mnt/wrangled/tmp/output/Egress_test2.dat')

# COMMAND ----------


#Test POC
#cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER).format('csv').save('abfss://egress@dapdevadlsoutb01.dfs.core.windows.net//retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy')
#CONTAINER='egress'
#STORAGE_ACCOUNT='dapdevadlsoutb01'
cnt=0
index3=0
CONTAINER=''
index2=0
for i,c in enumerate(OUTPUT_FILEPATH):
  if(c=='/'):
    cnt=cnt+1
  if(cnt==2 and c=='/'):
    index2=i
  if(cnt==3):
    index3=i
    break
CONTAINER=OUTPUT_FILEPATH[index2+1:index3]
#print(CONTAINER)
OUTPUT_PATH=OUTPUT_FILEPATH[index3+1:]
#print(OUTPUT_PATH)
#OUTPUT_PATH='retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy'
OUTPUT_FILEPATH_FINAL='abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_PATH+'_'+TIMESTAMP
#OUTPUT_FILEPATH_FINAL='abfss://wrangled@dapdevadlswrng01.dfs.core.windows.net//egress/retail_and_supply_chain/ipsos_mma_iri/product_hierarchy/wag_IPSOS_product_hierarchy'
cutoff_records_output.repartition(1).write.mode('overwrite').option("codec", "org.apache.hadoop.io.compress.GzipCodec").options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER,multiline=True).format('csv').save(OUTPUT_FILEPATH_FINAL,compression="gzip")

# COMMAND ----------

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv.gz")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+OUTPUT_FILEEXTENSION+'.gz')
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

removePartFiles(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------


# Chk generation
EXTRACT_FILE_NAME='edw_segmentation_household_data_'+TIMESTAMP+'.dat'
cutoff_records_output.createOrReplaceTempView('df_dat_file')


# COMMAND ----------

df_chk = spark.sql("select '{0}' as extract_file_name,nvl(sum(length(MAST_CUST_ID)+length(MEAS_BEGIN_DT)+length(SEGMENT_CD_CATG)+length(SEGMENT_CD_CATG_DESC)+length(SEGMENT_CD)+length(SEGMENT_CD_DESC)+length(MEAS_END_DT)+length(HEADRM_POTENTIAL_AMT)+length(FOS_LIFESTY_DISTANCE)+length(TRND_CD)+length(TRND_CD_DESC)+length(TRND_CD_CATG)+length(TRND_CD_CATG_DESC)+length(STAT_CD)+length(EDW_CREATE_DTTM)+length(EDW_UPDATE_DTTM)+length(EDW_BATCH_ID)),0)+249+count(1)*16 as byte_size,count(1) as extract_record_cnt from df_dat_file".format(EXTRACT_FILE_NAME))
#df_chk.display()
df_chk.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER,multiline=True).format('csv').save(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

def removePartFilesChk(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+'.chk')
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

removePartFilesChk(OUTPUT_FILEPATH_FINAL)
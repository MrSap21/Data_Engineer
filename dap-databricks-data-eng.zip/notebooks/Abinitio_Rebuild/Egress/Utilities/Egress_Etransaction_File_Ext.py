# Databricks notebook source
#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Output File Extension","")
#dbutils.widgets.text("Output File Delimeter","")
#dbutils.widgets.text("Output File Header","")
#dbutils.widgets.text("MountPoint_Notebook_Path","")
#dbutils.widgets.text("STORAGE_ACCOUNT","")
#dbutils.widgets.text("container","")
#dbutils.widgets.remove("Parameters List")



# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase Name")
# SQL_FP = dbutils.widgets.get("SQL File path")
# PAR_LIST = dbutils.widgets.get("Parameters List")
OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
OUTPUT_FILEEXTENSION=dbutils.widgets.get("Output File Extension")
OUTPUT_FILEDELIMETER=dbutils.widgets.get("Output File Delimeter")
OUTPUT_FILEHEADER=dbutils.widgets.get("Output File Header")
MOUNTPOINT_NOTEBOOK_PATH=dbutils.widgets.get("MountPoint_Notebook_Path")
STORAGE_ACCOUNT=dbutils.widgets.get("STORAGE_ACCOUNT")
CONTAINER=dbutils.widgets.get("container")
OUTPUT_FILENAME=dbutils.widgets.get("output_file_name")

# COMMAND ----------

#mountPoint = dbutils.notebook.run(MOUNTPOINT_NOTEBOOK_PATH, 60)

# COMMAND ----------

SNFL_DB_list=SNFL_DB.split(";")
for i in SNFL_DB_list:
  SNFL_DB
  
  print(i)

# COMMAND ----------

import os

for i in range(len(SNFL_DB_list)):
  os.system("%run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH")


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#etl_query = "SELECT * FROM {0}.{1}".format(SNFL_DB,TBL_NAME)
etl_query_addl = "SELECT * FROM {0}.retail_sales.iri_etransaction_addl_stg;".format(SNFL_DB)
etl_query_dat = "SELECT * FROM {0}.retail_sales.CCPA_iri_etransactions_stg;".format(SNFL_DB)

#Putting parameter values in SQL and storing it.
# snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 300, 
#                  {"parameters_list":PAR_LIST,
#                   "sql_file_path":SQL_FP
#                   });
# snow_query=snow_query.replace('\\n',' ').replace('\\','')
# print(snow_query)
#running the sql in snowflake and storing the result in a dataframe
iri_etransaction_addl_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",etl_query_addl)\
   .load()

iri_etransaction_dat_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",etl_query_dat)\
   .load()

# COMMAND ----------

# cutoff_records_output.count()

# COMMAND ----------

OUTPUT_FILEPATH_FINAL = 'abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_FILEPATH + OUTPUT_FILENAME.replace('.dat.gz','')
OUTPUT_FILEPATH_ADDL_FINAL = 'abfss://'+CONTAINER+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+OUTPUT_FILEPATH + (OUTPUT_FILENAME[0:24]+"add_"+OUTPUT_FILENAME[24:]).replace('.dat.gz','')
OUTPUT_FILEPATH_FINAL_CHK = OUTPUT_FILEPATH_FINAL +".chk"
print(OUTPUT_FILEPATH_ADDL_FINAL)
print(OUTPUT_FILEPATH_FINAL)
dbutils.fs.put(OUTPUT_FILEPATH_FINAL_CHK, str(iri_etransaction_dat_output.count()),True)


# COMMAND ----------

iri_etransaction_dat_output.coalesce(1).replace('', None).write.format("com.databricks.spark.csv").option("codec", "org.apache.hadoop.io.compress.GzipCodec").option("delimiter",OUTPUT_FILEDELIMETER).option("nullValue",None).save(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

iri_etransaction_addl_output.coalesce(1).replace('', None).write.format("com.databricks.spark.csv").option("codec", "org.apache.hadoop.io.compress.GzipCodec").option("delimiter",OUTPUT_FILEDELIMETER).option("nullValue",None).save(OUTPUT_FILEPATH_ADDL_FINAL)

# COMMAND ----------

# a="wagus_iri_etransactions_20220703_00000002.dat.gz"[0:24]+"add_"+"wagus_iri_etransactions_20220703_00000002.dat.gz"[24:]
# print(a)

# COMMAND ----------

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv.gz")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+OUTPUT_FILEEXTENSION+'.gz')
  dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

removePartFiles(OUTPUT_FILEPATH_FINAL)

# COMMAND ----------

removePartFiles(OUTPUT_FILEPATH_ADDL_FINAL)
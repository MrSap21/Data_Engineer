# Databricks notebook source
# dbutils.widgets.text("Data_Warehouse_Static","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("DataBase_Name_Static","DEV_STAGING")
# dbutils.widgets.text("Input_File_Static","/egress/static/wagus_iri_transactions_add_20220515_00001802.dat")
# dbutils.widgets.text("Format_Static","csv")
# dbutils.widgets.text("Header_Static","false")
# dbutils.widgets.text("Delimiter_Static","|")
# dbutils.widgets.text("Schema_Static", "RETAIL_SALES")
# dbutils.widgets.text("DBtable_Static", "STG_IRI_POS_TRANSACTION_COST")
# dbutils.widgets.text("MountPoint_Notebook_Path_Static", "/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP")
# dbutils.widgets.text("STORAGE_ACCOUNT", "dapdevadlsutl02")
# dbutils.widgets.text("CONTAINER", "sql")
# dbutils.widgets.text("FILE_CONTAINS", "_add")


# COMMAND ----------

SNFL_WH = dbutils.widgets.get("Data_Warehouse_Static")
SNFL_DB = dbutils.widgets.get("DataBase_Name_Static")
File_Path = dbutils.widgets.get("Input_File_Static")
File_Format = dbutils.widgets.get("Format_Static")
Header = dbutils.widgets.get("Header_Static")
Delimiter = dbutils.widgets.get("Delimiter_Static")
Schema = dbutils.widgets.get("Schema_Static")
dbtable = dbutils.widgets.get("DBtable_Static")
mount_path = dbutils.widgets.get("MountPoint_Notebook_Path_Static")
STORAGE_ACCOUNT = dbutils.widgets.get("STORAGE_ACCOUNT")
CONTAINER_NAME = dbutils.widgets.get("CONTAINER")
file_contains = dbutils.widgets.get("FILE_CONTAINS")

# COMMAND ----------

# mountPoint = dbutils.notebook.run(mount_path, 60)

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

print("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+File_Path)

# COMMAND ----------

print(str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+File_Path)))

# COMMAND ----------

#add logic for picking latest file-
var=str(dbutils.fs.ls("abfss://"+CONTAINER_NAME+"@"+STORAGE_ACCOUNT+".dfs.core.windows.net//"+File_Path))

# COMMAND ----------

var

# COMMAND ----------

var.split("FileInfo")

# COMMAND ----------

# x=var.split("FileInfo")`
# y=[]
x=var.split("FileInfo")
y=[]
date = []
date_file = {}
for i in range(1,len(x)):
  gg = x[i].replace(",","")
  gg = gg.split(" ")[1].replace("'","").replace(",","")
#   print("8888  ",gg)
  if file_contains != 'None':
    if file_contains in gg:
      print("inside    iffff --------- 13 line")
      date_file[str(gg)] = gg.split("_")[-1].split(".")[0]
  else:
    if ".dat.gz" in gg and len(gg.split('_')) ==5:
      print("inside else  ----------- 16")
      date_file[str(gg)] = gg.split("_")[-1].split(".")[0]
      

# COMMAND ----------

print(date_file)

# COMMAND ----------

import pyspark.sql.functions as f
import builtins as p


# COMMAND ----------

max_value = p.max(list(date_file.values()))
latest_file = list(date_file.keys())[list(date_file.values()).index(max_value)].replace("name=","")
print('=-----',latest_file)


# COMMAND ----------

File_Path = File_Path+'/'+latest_file
print(File_Path)

# COMMAND ----------

from pyspark.sql.functions import * 
import pandas as pd

# STORAGE_ACCOUNT = 'dapdevadlsutl02'
# CONTAINER='sql'
STATIC_FILE_PATH='abfss://'+CONTAINER_NAME+'@'+STORAGE_ACCOUNT+'.dfs.core.windows.net//'+File_Path
print(STATIC_FILE_PATH)

df = spark.read.format(File_Format).option("header", Header).option("delimiter", Delimiter).load(STATIC_FILE_PATH)#'/egress/static/wagus_iri_transactions_add_20220515_00001802.dat'

# COMMAND ----------

# SELECT    
# transaction_date, 
# transaction_time, 
# transaction_number,
# sales_txn_type,
# src_sys_cd,
# store_number, 
# loyalty_card_number,
# selling_price, 
# mid,
# card_id, 
# upc, 
# wic, 
# retailer_product_identifier,
# item_list_price, 
# item_net_price, 
# line_item_seq_nbr,
# item_quantity,
# weighted_item_weight,
# weighted_item_count,
# item_deal_quantity, 
# item_sale_quantity,
# item_net_amount,
# item_gross_amount,
# return_indicator,
# cost_dlrs,
# cost_adj_dlrs, 
# loyalty_cost_adj_dlrs,
# gross_profit, 
# sale_ind
# FROM    prdoutstgcif.stg_CCPA_iri_add_etransactions iri_stg
# where not exists (select 1 from prdoutstgcif.ccpa_stage_optout_table opt_out
#  where
#  ( (iri_stg.loyalty_card_number = opt_out.cust_src_id
# and opt_out.composite_type_cd = 'M'
#  and opt_out.msg_type_cd = '1'
#  and opt_out.src_sys_cd = 'LR')
# or
# (iri_stg.mid = 'E'||opt_out.cust_src_id
# and opt_out.composite_type_cd = 'A'
#  and opt_out.msg_type_cd = '2'
#  and opt_out.src_sys_cd = 'CDI



# COMMAND ----------

df.display()

# COMMAND ----------

# File_Name
df.count()

# COMMAND ----------

df.write.format("net.snowflake.spark.snowflake") \
    .mode("append") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("Schema", Schema) \
    .option("dbtable", dbtable) \
    .save()

# COMMAND ----------



# COMMAND ----------


# Databricks notebook source
# Mounting ADLSupply_chain/ipsos_mma
# mountPoint = dbutils.notebook.run("/Egress/Utilities/MOUNT_ADLS_OUTBOUND_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("SQL_File_path","")
#dbutils.widgets.text("Parameters_List","$1=1")
#dbutils.widgets.text("Output FilePath","")
#dbutils.widgets.text("Output File Extension","")
#dbutils.widgets.text("Output File Delimeter","")
#dbutils.widgets.text("Output File Header","")
#dbutils.widgets.text("MountPoint_Notebook_Path","")
#dbutils.widgets.text("schema","")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data Warehouse")
SCHEMA=dbutils.widgets.get("schema")
SNFL_DB = dbutils.widgets.get("DataBase Name")
SQL_FP = dbutils.widgets.get("SQL File path")
PAR_LIST = dbutils.widgets.get("Parameters List")
OUTPUT_FILEPATH=dbutils.widgets.get("Output FilePath")
OUTPUT_FILEEXTENSION=dbutils.widgets.get("Output File Extension")
OUTPUT_FILEDELIMETER=dbutils.widgets.get("Output File Delimeter")
OUTPUT_FILEHEADER=dbutils.widgets.get("Output File Header")
# MOUNTPOINT_NOTEBOOK_PATH=dbutils.widgets.get("MountPoint_Notebook_Path")

# COMMAND ----------

# mountPoint = dbutils.notebook.run(MOUNTPOINT_NOTEBOOK_PATH, 60)

# COMMAND ----------

SNFL_DB_list=SNFL_DB.split(";")
for i in SNFL_DB_list:
  SNFL_DB
  
  print(i)

# COMMAND ----------

import os

for i in range(len(SNFL_DB_list)):
  os.system("%run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=i[0] $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#etl_query = "SELECT * FROM {0}.{1}".format(SNFL_DB,TBL_NAME)
#Putting parameter values in SQL and storing it.
snow_query = dbutils.notebook.run("/Abinitio_Rebuild/Common/GetSQLCommand", 3000, 
                 {"parameters_list":PAR_LIST,
                  "sql_file_path":SQL_FP
                  });
snow_query=snow_query.replace('\\n',' ').replace('\\','')
print(snow_query)
query = snow_query.split(';')
#running the sql in snowflake and storing the result in a dataframe
#cutoff_records_output = spark.sql \
#   .format("snowflake") \
#   .options(**options) \
#  .option("sfDatabase", SNFL_DB) \
#   .option("query",snow_query)\
#   .load()

# COMMAND ----------

len(query)

# COMMAND ----------

for i in query[0:-1]:
  if i == 'begin transaction':
    pass
    
  else:
    print('got query--',i)

# COMMAND ----------

options = {
"sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
"sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
"pem_private_key" : pkb,
"sfDatabase" :SNFL_DB,
"sfSchema" : SCHEMA,
"sfWarehouse" : SNFL_WH,
}
sfUtils=sc._jvm.net.snowflake.spark.snowflake.Utils
# print(SCHEMA)
# print(SNFL_DB)
for i in query[0:-1]:
  if i == 'begin transaction':
    pass
  else:
    q = str(i)+';'
    queryobject =sfUtils.runQuery(options, q)
    print("query---------------   ",i)
#   try:
#     queryobject =sfUtils.runQuery(options, i)
#   except Exception as e:
#     raise e("error occured while running line 14",e)
#     print("error occured while running line 14",e)
  

# COMMAND ----------

#Displaying the data.
#display(cutoff_records_output)

# COMMAND ----------

#cutoff_records_output.write.format('com.databricks.spark.csv').save('/mnt/wrangled/master_data/Egress_test2.dat')

# COMMAND ----------

#cutoff_records_output.repartition(1).write.mode("overwrite").csv('/mnt/wrangled/tmp/Egress_test')
#dbutils.fs.cp('/mnt/wrangled/tmp/Egress_test/*.csv','/mnt/wrangled/tmp/output/Egress_test2.dat')

# COMMAND ----------

#outpath='/mnt/wrangled/tmp/Egress'
#cutoff_records_output.repartition(1).write.mode('overwrite').options(header=OUTPUT_FILEHEADER,delimiter=OUTPUT_FILEDELIMETER).format('csv').save(OUTPUT_FILEPATH)

# COMMAND ----------

#def removePartFiles(ls_path):
#  files = dbutils.fs.ls(ls_path)
#  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
#  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+OUTPUT_FILEEXTENSION)
 # dbutils.fs.rm(ls_path, recurse = True)

# COMMAND ----------

#removePartFiles(OUTPUT_FILEPATH)
# Databricks notebook source
#dbutils.widgets.text("Data_Warehouse","WBADEVDBENGINEER_WH")
#dbutils.widgets.text("DataBase_Name","")
#dbutils.widgets.text("Schema","")
#dbutils.widgets.text("table","")
#dbutils.widgets.text("extract_name","")
#dbutils.widgets.text("file_start_name","")
#dbutils.widgets.text("extract_seq","")

#dbutils.widgets.remove("src_stream_name")

# COMMAND ----------

#Creating Parameters for widgets.
SNFL_WH = dbutils.widgets.get("Data_Warehouse")
SNFL_DB = dbutils.widgets.get("DataBase_Name")
SCHEMA=dbutils.widgets.get("Schema")
Table=dbutils.widgets.get("table")
EXTRACT_NM=dbutils.widgets.get("extract_name")
extract_seq = dbutils.widgets.get("extract_seq")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

etl_query = "DELETE FROM {0}.{1}.{2} WHERE EXTRACT_NAME = \'{3}\' AND EXTRACT_SEQ = {4}".format(SNFL_DB,SCHEMA,Table,EXTRACT_NM,extract_seq)

# COMMAND ----------

print(etl_query)

# COMMAND ----------

options = {
"sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
"sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
"pem_private_key" : pkb,
"sfDatabase" :SNFL_DB,
"sfSchema" : SCHEMA,
"sfWarehouse" : SNFL_WH,
}

sfUtils=sc._jvm.net.snowflake.spark.snowflake.Utils
queryobject1 =sfUtils.runQuery(options, etl_query)
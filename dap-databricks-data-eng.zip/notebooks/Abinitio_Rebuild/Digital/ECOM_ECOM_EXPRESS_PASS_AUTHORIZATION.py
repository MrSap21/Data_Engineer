# Databricks notebook source
'''
dbutils.widgets.text("PAR_NB_BATCH_ID","20220629000000")
dbutils.widgets.text("PAR_PL_INPUT_FILE_NAME","/digital/ecom/ecom/2022/06/22/RXEXT016_20220626_20220626113515.dat")
dbutils.widgets.text("PAR_PL_SNOWFLAKE_DIGITAL_DATABASE","DEV_DIGITAL")
dbutils.widgets.text("PAR_PL_SNOWFLAKE_STAGING_DATABASE","DEV_STAGING")
dbutils.widgets.text("PAR_PL_STAGING_TBL","ECOM.ECOM_EXPRESS_PASS_AUTHORIZATION_STG")
dbutils.widgets.text("PAR_PL_TARGET_TBL","ECOM.ECOM_EXPRESS_PASS_AUTHORIZATION")
dbutils.widgets.text("PAR_PL_SNOWFLAKE_WAREHOUSE","WBADEVDBENGINEER_WH")
'''

# COMMAND ----------

import os
from pyspark.sql.functions import *

PAR_DB_BATCH_ID = dbutils.widgets.get("PAR_NB_BATCH_ID")
PAR_RXEXT016 = dbutils.widgets.get("PAR_PL_INPUT_FILE_NAME")
PAR_DB_DIG_SNFK_DB = dbutils.widgets.get("PAR_PL_SNOWFLAKE_DIGITAL_DATABASE")
PAR_DB_STG_SNFK_DB = dbutils.widgets.get("PAR_PL_SNOWFLAKE_STAGING_DATABASE")
PAR_STG_TABLE_NAME = dbutils.widgets.get("PAR_PL_STAGING_TBL")
PAR_DB_SNFK_TBL_NAME = dbutils.widgets.get("PAR_PL_TARGET_TBL")
PAR_DB_SNFK_WH = dbutils.widgets.get("PAR_PL_SNOWFLAKE_WAREHOUSE")

# COMMAND ----------

# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

inputFileList= PAR_RXEXT016
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())
 
dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

# COMMAND ----------

# Extracting File Name and Path
 
getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())
 
dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")
display(dfNamePath)
readList=[mountPoint + row[0] + '/' + row[1] for row in dfNamePath.select('filepath','filename').collect()]
print(readList)

# COMMAND ----------

'''
# initializing variables
PAR_DB_BATCH_ID = "202207010101"
PAR_RXEXT016 = "/digital/ecom/ecom/2022/06/22/RXEXT016_20220626_20220626113515.dat"
PAR_DB_SNFK_DB="DEV_DIGITAL"
PAR_DB_STG_SNFK_DB="DEV_STAGING"
PAR_STG_TABLE_NAME="ECOM.exp_pass_auth"
PAR_DB_SNFK_TBL_NAME="ECOM.ECOM_EXPRESS_PASS_AUTHORIZATION"
# PAR_DB_SNFK_TEST_TBL_NAME="PATIENT.ETL_PROC_TEST_PATIENT_STG"
PAR_DB_SNFK_WH="WBADEVDBENGINEER_WH"
'''

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=PAR_DB_STG_SNFK_DB $SNOWFLAKE_WAREHOUSE=PAR_DB_SNFK_WH

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

fieldList = ['expresspass_payment_id','rxorder_id','preauth_store_number','preauth_terminal_number','preauth_message_type','preauth_message_subtype','preauth_amount','preauth_completion_amount','preauth_resp_approval_code','preauth_card_type','preauth_invoice_number','preauth_postal_code','preauth_resp_address_code','preauth_customer_pin','preauth_resp_payment_token','preauth_resp_expiration_month','preauth_resp_expiration_year',
'preauth_resp_ps2000_data','preauth_product_subfid','status','created_dttm','updated_dttm','payment_method','status_code','preauth_resp_seq_num','os_version','device_type','browser_type','expired_dttm','order_action_dttm','rxpickup_expired_dttm','qrcode_expired_dttm']

# COMMAND ----------

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

df_readFile = spark.read.format("csv").schema(schema).option("delimiter","\u0001").option("header", False).load(readList)


# COMMAND ----------

df_hiveTemp_insert=df_readFile.withColumn("expresspass_payment_id",coalesce(col("expresspass_payment_id"),lit(""))) \
.withColumn("rxorder_id",coalesce(col("rxorder_id"),lit(""))) \
.withColumn("created_dttm",to_timestamp(col("created_dttm"))) \
.withColumn("updated_dttm",to_timestamp(col("updated_dttm"))) \
.withColumn("expired_dttm",to_timestamp(col("expired_dttm"))) \
.withColumn("order_action_dttm",to_timestamp(col("order_action_dttm"))) \
.withColumn("rxpickup_expired_dttm",to_timestamp(col("rxpickup_expired_dttm"))) \
.withColumn("qrcode_expired_dttm",to_timestamp(col("qrcode_expired_dttm"))) \
.withColumn("idh_ingestion_dt",current_date())

# COMMAND ----------

query1="""select *,to_varchar(src_create_dt,'yyyymm') as src_create_yrmnth from {0}.{1}""".format(PAR_DB_DIG_SNFK_DB,PAR_DB_SNFK_TBL_NAME)

df_q1_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", PAR_DB_SNFK_WH) \
   .option("sfDatabase", PAR_DB_DIG_SNFK_DB) \
   .option("query",query1)\
   .load()
df_q1_out.createOrReplaceTempView("ECOM_EXPRESS_PASS_AUTHORIZATION")

# COMMAND ----------

df_hiveTemp_insert.createOrReplaceTempView("exp_pass_auth")

# COMMAND ----------

spark.sql("SELECT expresspass_payment_id, rxorder_id, preauth_store_number, preauth_terminal_number, preauth_message_type, preauth_message_subtype, preauth_amount, preauth_completion_amount, preauth_resp_approval_code, preauth_card_type, preauth_invoice_number, preauth_postal_code, preauth_resp_address_code, preauth_customer_pin, preauth_resp_payment_token, preauth_resp_expiration_month, preauth_resp_expiration_year, preauth_resp_ps2000_data, preauth_product_subfid, status, created_dttm, updated_dttm, payment_method, status_code, preauth_resp_seq_num, os_version, device_type, browser_type, expired_dttm, order_action_dttm, rxpickup_expired_dttm, qrcode_expired_dttm, idh_ingestion_dt from (SELECT expresspass_payment_id, rxorder_id, preauth_store_number, preauth_terminal_number, preauth_message_type, preauth_message_subtype, preauth_amount, preauth_completion_amount, preauth_resp_approval_code, preauth_card_type, preauth_invoice_number, preauth_postal_code, preauth_resp_address_code, preauth_customer_pin, preauth_resp_payment_token, preauth_resp_expiration_month, preauth_resp_expiration_year, preauth_resp_ps2000_data, preauth_product_subfid, status, created_dttm, updated_dttm, payment_method, status_code, preauth_resp_seq_num, os_version, device_type, browser_type, expired_dttm, order_action_dttm, rxpickup_expired_dttm, qrcode_expired_dttm, idh_ingestion_dt, ROW_NUMBER() OVER (PARTITION BY expresspass_payment_id,created_dttm ORDER BY updated_dttm DESC) AS ROW_NUM FROM exp_pass_auth WHERE idh_ingestion_dt=current_date()) a where ROW_NUM=1").createOrReplaceTempView("exp_pass_auth_dedup")

# COMMAND ----------

query_FULL_OUTER="""SELECT
B.expresspass_payment_id as raw_expresspass_payment_id ,
B.rxorder_id AS raw_rxorder_id,
B.preauth_store_number AS raw_preauth_store_number,
B.preauth_terminal_number as raw_preauth_terminal_number,
B.preauth_message_type AS raw_preauth_message_type,
B.preauth_message_subtype AS raw_preauth_message_subtype,
B.preauth_amount AS raw_preauth_amount,
B.preauth_completion_amount AS raw_preauth_completion_amount,
B.preauth_resp_approval_code AS raw_preauth_resp_approval_code,
B.preauth_card_type AS raw_preauth_card_type ,
B.preauth_invoice_number AS raw_preauth_invoice_number ,
B.preauth_postal_code  AS raw_preauth_postal_code ,
B.preauth_resp_address_code AS raw_preauth_resp_address_code ,
B.preauth_customer_pin AS raw_preauth_customer_pin,
B.preauth_resp_payment_token AS raw_preauth_resp_payment_token  ,
B.preauth_resp_expiration_month AS raw_preauth_resp_expiration_month ,
B.preauth_resp_expiration_year AS raw_preauth_resp_expiration_year ,
B.preauth_resp_ps2000_data AS raw_preauth_resp_ps2000_data ,
B.preauth_product_subfid AS raw_preauth_product_subfid ,
B.status AS raw_status ,
B.created_dttm AS raw_created_dttm ,
B.updated_dttm AS raw_updated_dttm ,
B.payment_method AS raw_payment_method ,
B.status_code AS raw_status_code    ,
B.preauth_resp_seq_num AS raw_preauth_resp_seq_num ,
B.os_version AS raw_os_version,
B.device_type AS raw_device_type ,
B.browser_type AS raw_browser_type ,
B.expired_dttm  AS raw_expired_dttm  ,
B.order_action_dttm AS raw_order_action_dttm ,
B.rxpickup_expired_dttm AS raw_rxpickup_expired_dttm ,
B.qrcode_expired_dttm AS raw_qrcode_expired_dttm ,
CASE WHEN A.ord_id IS NULL AND B.rxorder_id IS NOT NULL THEN 'I'
WHEN A.ord_id IS NOT NULL AND B.rxorder_id IS NOT NULL AND A.end_dt <> '9999-12-31' THEN 'OU'
WHEN A.ord_id IS NOT NULL AND B.rxorder_id IS NOT NULL THEN 'U'
WHEN A.ord_id IS NOT NULL AND B.rxorder_id IS NULL THEN 'NC' END AS PRCS_C,
A.express_pass_payment_id     as tgt_express_pass_payment_id,
A.src_create_dttm             as tgt_src_create_dttm,
A.eff_dt                      as tgt_eff_dt,
A.eff_tm                      as tgt_eff_tm,
A.end_dt                      as tgt_end_dt,
A.end_tm                      as tgt_end_tm,
A.ord_id                      as tgt_ord_id,
A.ord_src_type_cd             as tgt_ord_src_type_cd,
A.preauth_str_nbr             as tgt_preauth_str_nbr,
A.preauth_terminal_nbr        as tgt_preauth_terminal_nbr,
A.preauth_msg_type_cd         as tgt_preauth_msg_type_cd,
A.preauth_msg_subtype_cd      as tgt_preauth_msg_subtype_cd,
A.preauth_amt                 as tgt_preauth_amt,
A.preauth_complete_amt        as tgt_preauth_complete_amt,
A.preauth_resp_aprv_cd        as tgt_preauth_resp_aprv_cd,
A.preauth_card_type           as tgt_preauth_card_type,
A.preauth_inv_nbr             as tgt_preauth_inv_nbr,
A.preauth_pstl_cd             as tgt_preauth_pstl_cd,
A.preauth_resp_addr_cd        as tgt_preauth_resp_addr_cd,
A.preauth_cust_pin            as tgt_preauth_cust_pin,
A.preauth_resp_payment_token  as tgt_preauth_resp_payment_token,
A.preauth_resp_expire_mo      as tgt_preauth_resp_expire_mo,
A.preauth_resp_expire_yr      as tgt_preauth_resp_expire_yr,
A.preauth_resp_ps2000_data    as tgt_preauth_resp_ps2000_data,
A.preauth_prod_sub_fid        as tgt_preauth_prod_sub_fid,
A.src_update_dttm             as tgt_src_update_dttm,
A.payment_stat_cd             as tgt_payment_stat_cd,
A.payment_stat_desc           as tgt_payment_stat_desc,
A.payment_method_cd           as tgt_payment_method_cd,
A.preauth_resp_seq_nbr        as tgt_preauth_resp_seq_nbr,
A.os_vers                     as tgt_os_vers,
A.devc_type                   as tgt_devc_type,
A.browser_type                as tgt_browser_type,
A.expired_dttm                as tgt_expired_dttm,
A.ord_actn_dttm               as tgt_ord_actn_dttm,
A.rx_pickup_expired_dttm      as tgt_rx_pickup_expired_dttm,
A.qr_cd_expired_dttm          as tgt_qr_cd_expired_dttm,
A.src_create_dt               as tgt_src_create_dt,
A.create_dttm                 as tgt_create_dttm,
A.update_dttm                 as tgt_update_dttm,
COALESCE(A.edw_batch_id,'{pEDWBatchId}')  as tgt_edw_batch_id,
A.src_create_yrmnth          as tgt_src_create_yrmnth
FROM
ECOM_EXPRESS_PASS_AUTHORIZATION A
FULL OUTER JOIN
exp_pass_auth_dedup B
ON
A.express_pass_payment_id= B.expresspass_payment_id AND
A.src_create_dttm=B.created_dttm""".format(pEDWBatchId=PAR_DB_BATCH_ID)
print(query_FULL_OUTER)
spark.sql(query_FULL_OUTER).createOrReplaceTempView("ecom_express_pass_authorization_view")

# COMMAND ----------

ECOM_EXPRESS_PASS_AUTHORIZATION_rem=spark.sql("""select * from ECOM_EXPRESS_PASS_AUTHORIZATION a where not exists (select 1 from ecom_express_pass_authorization_view b where (PRCS_C IN ('I','U')) or ( PRCS_C = 'U' and tgt_end_dt='9999-12-31') or (PRCS_C IN ('NC','OU')) and a.src_create_yrmnth=b.tgt_src_create_yrmnth )
""")

# COMMAND ----------

query_cdc="""
SELECT
raw_expresspass_payment_id as express_pass_payment_id,
raw_created_dttm as src_create_dttm,
DATE_FORMAT(current_date(),'yyyy-MM-dd') as eff_dt,
date_format(current_timestamp(),'HH:mm:ss') as eff_tm,
'9999-12-31'  as end_dt,
'00:00:00'   as end_tm, 
raw_rxorder_id as ord_id,
'R'  as ord_src_type_cd,
raw_preauth_store_number  as preauth_str_nbr,
raw_preauth_terminal_number  as preauth_terminal_nbr,
raw_preauth_message_type  as preauth_msg_type_cd,
raw_preauth_message_subtype as preauth_msg_subtype_cd,
raw_preauth_amount as preauth_amt,
raw_preauth_completion_amount as preauth_complete_amt,
raw_preauth_resp_approval_code as preauth_resp_aprv_cd,
raw_preauth_card_type as preauth_card_type,
raw_preauth_invoice_number as preauth_inv_nbr,
raw_preauth_postal_code as preauth_pstl_cd,
raw_preauth_resp_address_code as preauth_resp_addr_cd,
raw_preauth_customer_pin as preauth_cust_pin,
raw_preauth_resp_payment_token as preauth_resp_payment_token,
raw_preauth_resp_expiration_month as preauth_resp_expire_mo,
raw_preauth_resp_expiration_year  as preauth_resp_expire_yr,
raw_preauth_resp_ps2000_data as preauth_resp_ps2000_data,
raw_preauth_product_subfid as preauth_prod_sub_fid,
raw_updated_dttm as src_update_dttm,
raw_status_code as payment_stat_cd,
raw_status  as payment_stat_desc,
raw_payment_method as payment_method_cd,
raw_preauth_resp_seq_num as preauth_resp_seq_nbr,
raw_os_version as os_vers,
raw_device_type as devc_type,
raw_browser_type as browser_type,
raw_expired_dttm as expired_dttm,
raw_order_action_dttm as ord_actn_dttm,
raw_rxpickup_expired_dttm as rx_pickup_expired_dttm,
raw_qrcode_expired_dttm as qr_cd_expired_dttm,
DATE_FORMAT(raw_created_dttm,'yyyy-MM-dd') AS   src_create_dt,
CASE WHEN PRCS_C == 'I' THEN from_unixtime(to_unix_timestamp (current_timestamp(),'yyyy-MM-dd HH:mm:ss')) WHEN PRCS_C == 'U' THEN from_unixtime(to_unix_timestamp (tgt_create_dttm,'yyyy-MM-dd HH:mm:ss')) END as create_dttm,
from_unixtime(to_unix_timestamp (current_timestamp(),'yyyy-MM-dd HH:mm:ss')) as update_dttm,
'{pEDWBatchId}' as edw_batch_id,
DATE_FORMAT(raw_created_dttm,'yyyyMM')  as src_create_yrmnth
from ecom_express_pass_authorization_view where PRCS_C IN ('I','U')

union all
----------------RETAINING HISTORY RECORDS------------
SELECT
tgt_express_pass_payment_id as express_pass_payment_id,
tgt_src_create_dttm as src_create_dttm,
tgt_eff_dt as eff_dt,
tgt_eff_tm as eff_tm,
DATE_FORMAT(date_sub(current_date(),1),'yyyy-MM-dd')  as end_dt,
date_format(current_timestamp(),'HH:mm:ss')  as end_tm, 
tgt_ord_id as ord_id,
tgt_ord_src_type_cd as ord_src_type_cd,
tgt_preauth_str_nbr  as preauth_str_nbr,
tgt_preauth_terminal_nbr as preauth_terminal_nbr,
tgt_preauth_msg_type_cd  as preauth_msg_type_cd,
tgt_preauth_msg_subtype_cd  as preauth_msg_subtype_cd,
tgt_preauth_amt as preauth_amt, 
tgt_preauth_complete_amt as preauth_complete_amt,
tgt_preauth_resp_aprv_cd  as preauth_resp_aprv_cd,
tgt_preauth_card_type as preauth_card_type,
tgt_preauth_inv_nbr as preauth_inv_nbr,
tgt_preauth_pstl_cd as preauth_pstl_cd,
tgt_preauth_resp_addr_cd as preauth_resp_addr_cd,
tgt_preauth_cust_pin as preauth_cust_pin,
tgt_preauth_resp_payment_token as preauth_resp_payment_token,
tgt_preauth_resp_expire_mo as preauth_resp_expire_mo,
tgt_preauth_resp_expire_yr as preauth_resp_expire_yr,
tgt_preauth_resp_ps2000_data as preauth_resp_ps2000_data,
tgt_preauth_prod_sub_fid as preauth_prod_sub_fid,
tgt_src_update_dttm as src_update_dttm,
tgt_payment_stat_cd as payment_stat_cd,
tgt_payment_stat_desc as payment_stat_desc,
tgt_payment_method_cd as payment_method_cd,
tgt_preauth_resp_seq_nbr as preauth_resp_seq_nbr,
tgt_os_vers as os_vers,
tgt_devc_type as devc_type,
tgt_browser_type as browser_type,
tgt_expired_dttm as expired_dttm,
tgt_ord_actn_dttm as ord_actn_dttm,
tgt_rx_pickup_expired_dttm as rx_pickup_expired_dttm,
tgt_qr_cd_expired_dttm as qr_cd_expired_dttm,
tgt_src_create_dt as src_create_dt,
tgt_create_dttm as create_dttm,
from_unixtime(to_unix_timestamp (current_timestamp(),'yyyy-MM-dd HH:mm:ss')) as update_dttm,
tgt_edw_batch_id as edw_batch_id,
tgt_src_create_yrmnth as src_create_yrmnth
from ecom_express_pass_authorization_view where PRCS_C = 'U' and tgt_end_dt='9999-12-31'

union all

----Inserting UNMODIFIED RECORDS------------
SELECT
tgt_express_pass_payment_id as express_pass_payment_id,
tgt_src_create_dttm as src_create_dttm,
tgt_eff_dt as eff_dt,
tgt_eff_tm as eff_tm,
tgt_end_dt as end_dt,
tgt_end_tm  as end_tm, 
tgt_ord_id as ord_id,
tgt_ord_src_type_cd  as ord_src_type_cd,
tgt_preauth_str_nbr  as preauth_str_nbr,
tgt_preauth_terminal_nbr  as preauth_terminal_nbr,
tgt_preauth_msg_type_cd  as preauth_msg_type_cd,
tgt_preauth_msg_subtype_cd as preauth_msg_subtype_cd,
tgt_preauth_amt as preauth_amt,
tgt_preauth_complete_amt as preauth_complete_amt,
tgt_preauth_resp_aprv_cd  as preauth_resp_aprv_cd,
tgt_preauth_card_type as preauth_card_type,
tgt_preauth_inv_nbr as preauth_inv_nbr,
tgt_preauth_pstl_cd as preauth_pstl_cd,
tgt_preauth_resp_addr_cd as preauth_resp_addr_cd,
tgt_preauth_cust_pin as preauth_cust_pin,
tgt_preauth_resp_payment_token as preauth_resp_payment_token,
tgt_preauth_resp_expire_mo as preauth_resp_expire_mo,
tgt_preauth_resp_expire_yr as preauth_resp_expire_yr,
tgt_preauth_resp_ps2000_data as preauth_resp_ps2000_data,
tgt_preauth_prod_sub_fid as preauth_prod_sub_fid,
tgt_src_update_dttm as src_update_dttm,
tgt_payment_stat_cd as payment_stat_cd,
tgt_payment_stat_desc as payment_stat_desc,
tgt_payment_method_cd as payment_method_cd,
tgt_preauth_resp_seq_nbr as preauth_resp_seq_nbr,
tgt_os_vers as os_vers,
tgt_devc_type as devc_type,
tgt_browser_type as browser_type,
tgt_expired_dttm as expired_dttm,
tgt_ord_actn_dttm as ord_actn_dttm,
tgt_rx_pickup_expired_dttm as rx_pickup_expired_dttm,
tgt_qr_cd_expired_dttm as qr_cd_expired_dttm,
tgt_src_create_dt as src_create_dt,
tgt_create_dttm as create_dttm,
tgt_update_dttm as update_dttm,
tgt_edw_batch_id  as edw_batch_id,
tgt_src_create_yrmnth  as src_create_yrmnth 
from ecom_express_pass_authorization_view where PRCS_C IN ('NC','OU')""".format(pEDWBatchId=PAR_DB_BATCH_ID)
ECOM_EXPRESS_PASS_AUTHORIZATION_cdc=spark.sql(query_cdc)

# COMMAND ----------

df=ECOM_EXPRESS_PASS_AUTHORIZATION_cdc.unionAll(ECOM_EXPRESS_PASS_AUTHORIZATION_rem)

# COMMAND ----------

df1=df.filter( coalesce(df.src_create_yrmnth,lit(date_format(current_date(),'yyyyMM'))) >=  lit(date_format(add_months(current_date() , -24),'yyyyMM') ) )

# COMMAND ----------

df_final=df1.select(col("express_pass_payment_id"), \
to_timestamp(col("src_create_dttm")).alias("src_create_dttm"), \
col("eff_dt"), \
col("eff_tm"), \
col("end_dt"), \
col("end_tm"), \
col("ord_id"), \
col("ord_src_type_cd"), \
col("preauth_str_nbr"), \
col("preauth_terminal_nbr"), \
col("preauth_msg_type_cd"), \
col("preauth_msg_subtype_cd"), \
col("preauth_amt"), \
col("preauth_complete_amt"), \
col("preauth_resp_aprv_cd"), \
col("preauth_card_type"), \
col("preauth_inv_nbr"), \
col("preauth_pstl_cd"), \
col("preauth_resp_addr_cd"), \
col("preauth_cust_pin"), \
col("preauth_resp_payment_token"), \
col("preauth_resp_expire_mo"), \
col("preauth_resp_expire_yr"), \
col("preauth_resp_ps2000_data"), \
col("preauth_prod_sub_fid"), \
to_timestamp(col("src_update_dttm")).alias("src_update_dttm"), \
col("payment_stat_cd"), \
col("payment_stat_desc"), \
col("payment_method_cd"), \
col("preauth_resp_seq_nbr"), \
col("os_vers"), \
col("devc_type"), \
col("browser_type"), \
to_timestamp(col("expired_dttm")).alias("expired_dttm"), \
to_timestamp(col("ord_actn_dttm")).alias("ord_actn_dttm"), \
to_timestamp(col("rx_pickup_expired_dttm")).alias("rx_pickup_expired_dttm"), \
to_timestamp(col("qr_cd_expired_dttm")).alias("qr_cd_expired_dttm"), \
to_date(col("src_create_dt")).alias("src_create_dt"),
to_timestamp(col("create_dttm")).alias("create_dttm"), \
to_timestamp(col("update_dttm")).alias("update_dttm"), \
col("edw_batch_id"))

# COMMAND ----------


delete_ECOM_EXPRESS_PASS_AUTHORIZATION_STG_tbl = "Truncate table {0}.{1}".format(PAR_DB_STG_SNFK_DB,PAR_STG_TABLE_NAME)
 
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_ECOM_EXPRESS_PASS_AUTHORIZATION_STG_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : PAR_DB_STG_SNFK_DB,"SNOWFLAKE_WAREHOUSE" : PAR_DB_SNFK_WH})

# COMMAND ----------


df_final.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", PAR_DB_SNFK_WH) \
   .option("sfDatabase", PAR_DB_STG_SNFK_DB) \
   .option("dbtable", PAR_STG_TABLE_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------


delete_ECOM_EXPRESS_PASS_AUTHORIZATION_tbl = "Truncate table {0}.{1}".format(PAR_DB_DIG_SNFK_DB,PAR_DB_SNFK_TBL_NAME)
 
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_ECOM_EXPRESS_PASS_AUTHORIZATION_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : PAR_DB_DIG_SNFK_DB,"SNOWFLAKE_WAREHOUSE" : PAR_DB_SNFK_WH})

insert_ECOM_EXPRESS_PASS_AUTHORIZATION_tbl = "insert into {0}.{1} select * from {2}.{3}".format(PAR_DB_DIG_SNFK_DB,PAR_DB_SNFK_TBL_NAME,PAR_DB_STG_SNFK_DB,PAR_STG_TABLE_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : insert_ECOM_EXPRESS_PASS_AUTHORIZATION_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : PAR_DB_DIG_SNFK_DB,"SNOWFLAKE_WAREHOUSE" : PAR_DB_SNFK_WH})


# COMMAND ----------

'''
df_final.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", PAR_DB_SNFK_WH) \
   .option("sfDatabase", PAR_DB_DIG_SNFK_DB) \
   .option("dbtable", PAR_DB_SNFK_TBL_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()
   '''

# COMMAND ----------


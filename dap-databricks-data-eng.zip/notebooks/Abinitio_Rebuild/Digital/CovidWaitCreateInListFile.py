# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# COMMAND ----------

import datetime
import os
from pyspark.sql.types import StructType,StructField, StringType
from pyspark.sql.functions import *
import pandas as pd


# COMMAND ----------

dbutils.widgets.text("AI_SERIAL","",label="AI_SERIAL")
dbutils.widgets.text("FILE_NAME","",label="FILE_NAME")
dbutils.widgets.text("FILE_LIST","",label="FILE_LIST")

AI_SERIAL=dbutils.widgets.get("AI_SERIAL")
FILE_EXTENSION=dbutils.widgets.get("FILE_NAME")
FILE_LIST=dbutils.widgets.get("FILE_LIST") 
#changes needed

# COMMAND ----------

rddjson = sc.parallelize([FILE_LIST])
dfFileList = sqlContext.read.json(rddjson)
# dfFileList.display()
dfCreateInList=spark.read.format("csv").option("header",True).load("/mnt/wrangled/digital/ecom/staging/Covid_input_filelist/")

dfMainList=dfFileList.join(dfCreateInList, dfCreateInList.Asset_Name==dfFileList.assetname[0:34],"anti")
dfMainList.show()
dfMainList.createOrReplaceTempView("dfListFinal")
distinct_dfRaw=spark.sql('select assetcurrentlocation,assetid,assetname from (select *,row_number() over(partition by  substring(assetname,0,34) order by assetcurrentlocation desc) as Rank from dfListFinal)temp where Rank=1')

# add to the list
dfCreateInList.createOrReplaceTempView("dfView1")
distinct_dfRaw.createOrReplaceTempView("dfView2")
distinct_dfRaw.display()
dfNewCreateInList=spark.sql('select Asset_Name from dfView1 union select substring(assetname,0,34) from dfView2')
#dfNewCreateInList.display()
#dfNewCreateInList.write.csv(path="mnt/wrangled/digital/ecom/staging/Covid_input_filelist",header=True,mode="overwrite")
dfRaw = distinct_dfRaw.select(concat(distinct_dfRaw.assetcurrentlocation,distinct_dfRaw.assetname).alias('full_filename'))
display(dfRaw)
file_path = "{0}/{1}/{2}".format(mountPoint, AI_SERIAL, dbutils.widgets.get("FILE_NAME"))
#print(file_path)
data_location_output=file_path
print(data_location_output)
# df1=spark.read.format("csv").option("header",True).load(data_location_output)
# df1.display()
dfRaw.coalesce(1).write.options(header="false", delimiter = ",").format("csv").mode("overwrite").save(data_location_output)
filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + "." + "dat")
dbutils.fs.rm(data_location_output, recurse = True)

# COMMAND ----------

dfNewCreateInList.write.csv(path="mnt/wrangled/digital/ecom/staging/Covid_input_filelist",header=True,mode="overwrite")

# COMMAND ----------

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
dbutils.notebook.exit(dfAssetIdStr)

# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Import Python libs
import random
import json
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("DELTA_FILE_NAME","",label="DELTA_FILE_NAME")
dbutils.widgets.text("DELTA_FILE_DIR","",label="DELTA_FILE_DIR")

dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")

output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")
delta_file_name = dbutils.widgets.get("DELTA_FILE_NAME")
delta_file_dir = dbutils.widgets.get("DELTA_FILE_DIR")

delta_file_path = mount_point + '/' + delta_file_dir + '/' + delta_file_name + '/' + batch_id
output_file_path = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir + '/' + batch_id

# COMMAND ----------

# Define column values in List((tuple0,tuple1)) -- List((columnnamewithrelativetags,onlycolumnname))
col_list_medicaid = [("messageInfo_updateDTTM","updateDTTM"), ("messageInfo_updateUserId","updateUserId"), ("messageInfo_createDTTM","createDTTM"), ("messageInfo_createUserId","createUserId"), ("providerInfo_entityID","entityID"), ("providerInfo_professionalInfo_medicaid_idNumber","mediidNumber"), ("providerInfo_professionalInfo_medicaid_issuingAuthority","mediissuingAuthority")]

col_list_foreign = [("messageInfo_updateDTTM","updateDTTM"), ("messageInfo_updateUserId","updateUserId"), ("messageInfo_createDTTM","createDTTM"), ("messageInfo_createUserId","createUserId"), ("providerInfo_entityID","entityID"), ("providerInfo_professionalInfo_foreign_idNumber","foreignidNumber"), ("providerInfo_professionalInfo_foreign_country","country")]


col_list_controlledSubstance = [("messageInfo_updateDTTM","updateDTTM"), ("messageInfo_updateUserId","updateUserId"), ("messageInfo_createDTTM","createDTTM"), ("messageInfo_createUserId","createUserId"), ("providerInfo_entityID","entityID"), ("providerInfo_professionalInfo_controlledSubstance_number","subnumber"), ("providerInfo_professionalInfo_controlledSubstance_issuingState","issuingState"), ("providerInfo_professionalInfo_controlledSubstance_issueDate","substissueDate"), ("providerInfo_professionalInfo_controlledSubstance_expirationDate","substexpirationDate"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted2","substschedulePermitted2"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted2N","substschedulePermitted2N"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted3","substschedulePermitted3"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted3N","substschedulePermitted3N"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted4","substschedulePermitted4"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted5","substschedulePermitted5")]

selected_medicaid  = [col(j) for k, j in col_list_medicaid]
selected_foreign  = [col(j) for k, j in col_list_foreign]
selected_controlledSubstance  = [col(j) for k, j in col_list_controlledSubstance]

# COMMAND ----------

#Read from delta
delta_df = spark.read.format("delta").load(delta_file_path)

# COMMAND ----------

df2_medicaid=delta_df.select(*selected_medicaid)
df2_foreign=delta_df.select(*selected_foreign)
df2_controlledSubstance=delta_df.select(*selected_controlledSubstance)

# COMMAND ----------

df2_medicaid = df2_medicaid.withColumn("id_type",lit("MEDICAID")).withColumn("id_sub_type",lit("ISSUING AUTHORITY"))\
                             .withColumnRenamed("mediidNumber","id_type_val")\
                             .withColumnRenamed("mediissuingAuthority","id_sub_type_val")
df2_foreign = df2_foreign.withColumn("id_type",lit("FOREIGN")).withColumn("id_sub_type",lit("COUNTRY"))\
                            .withColumnRenamed("foreignidNumber","id_type_val")\
                            .withColumnRenamed("country","id_sub_type_val") 
df2_controlledSubstance = df2_controlledSubstance.withColumn("id_type",lit("CONTROLLEDSUBSTANCE"))\
                                                   .withColumn("id_sub_type",lit("ISSUING STATE"))\
                                                   .withColumnRenamed("subnumber","id_type_val")\
                                                   .withColumnRenamed("substissueDate","issueDate")\
                                                   .withColumnRenamed("substexpirationDate","expirationDate")\
                                                   .withColumnRenamed("substschedulePermitted2","stschedulePermitted2")\
                                                   .withColumnRenamed("substschedulePermitted2N","stschedulePermitted2N")\
                                                   .withColumnRenamed("substschedulePermitted3","stschedulePermitted3")\
                                                   .withColumnRenamed("substschedulePermitted3N","stschedulePermitted3N")\
                                                   .withColumnRenamed("substschedulePermitted4","stschedulePermitted4")\
                                                   .withColumnRenamed("substschedulePermitted5","stschedulePermitted5")
df3_medicaid=df2_medicaid.dropDuplicates()
df3_foreign=df2_foreign.dropDuplicates()
df3_controlledSubstance=df2_controlledSubstance.dropDuplicates()
df4 = custom_union(df3_medicaid,df3_foreign)
union_df = custom_union(df4,df3_controlledSubstance)

# COMMAND ----------

# filter to remove unnecesary records
df_final = union_df.filter("id_type_val is not null")

# COMMAND ----------

# Write output (parquet)
write_data(df_final,output_file_path)

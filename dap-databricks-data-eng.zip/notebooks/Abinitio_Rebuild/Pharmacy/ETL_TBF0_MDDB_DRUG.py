# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
readList=readList.split(',')
print(readList)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'ndc_upc_hri',
'ndc_upc_hri_after',
'id_form_cd',
'id_form_cd_after',
'drug_status_cd',
'drug_status_cd_after',
'seq_cd',
'seq_cd_after',
'labeler_cd',
'labeler_cd_after',
'gen_type_cd',
'gen_type_cd_after',
'gen_id_no',
'gen_id_no_after',
'dea_class',
'dea_class_after',
'thera_class',
'thera_class_after',
'thera_equiv',
'thera_equiv_after',
'form_id_no',
'form_id_no_after',
'rx_otc_ind',
'rx_otc_ind_after',
'third_party',
'third_party_after',
'maint_drug',
'maint_drug_after',
'disp_unit',
'disp_unit_after',
'ud_uu_pkg',
'ud_uu_pkg_after',
'route_admin',
'route_admin_after',
'form_type',
'form_type_after',
'dollar_rank',
'dollar_rank_after',
'rx_rank',
'rx_rank_after',
'sec_id_fmt_cd',
'sec_id_fmt_cd_after',
'sec_ndc_upc_hri',
'sec_ndc_upc_hri_after',
'gen_cd',
'gen_cd_after',
'brand_name_cd',
'brand_name_cd_after',
'int_ext',
'int_ext_after',
'single_comb',
'single_comb_after',
'stor_cond',
'stor_cond_after',
'lim_stabil',
'lim_stabil_after',
'a_last_change_dttm',
'a_last_change_dttm_after',
'old_fmt_cd',
'old_fmt_cd_after',
'old_ndc_upc_hri',
'old_ndc_upc_hri_after',
'old_fmt_no',
'old_fmt_no_after',
'old_dttm',
'old_dttm_after',
'new_fmt_cd',
'new_fmt_cd_after',
'new_ndc_upc_hri',
'new_ndc_upc_hri_after',
'new_fmt_no',
'new_fmt_no_after',
'new_dttm',
'new_dttm_after',
'c_last_change_dttm',
'c_last_change_dttm_after',
'prod_name',
'prod_name_after',
'prod_name_ext',
'prod_name_ext_after',
'dpc',
'dpc_after',
'ppc',
'ppc_after',
'apc',
'apc_after',
'ppg_cd',
'ppg_cd_after',
'hfpg_cd',
'hfpg_cd_after',
'e_last_change_dttm',
'e_last_change_dttm_after',
'gpi',
'gpi_after',
'gpi_name',
'gpi_name_after',
'g_last_change_dttm',
'g_last_change_dttm_after',
'manuf_name',
'manuf_name_after',
'manuf_name_abbr',
'manuf_name_abbr_after',
'prod_descr_abbr',
'prod_desc_abbr_after',
'drug_name_cd',
'drug_name_cd_after',
'gppc',
'gppc_after',
'j_last_change_dttm',
'j_last_change_dttm_after',
'mt_strn',
'mt_strn_after',
'strn_u_m',
'strn_u_m_after',
'dosage_form',
'dosage_form_after',
'pack_size',
'pack_size_after',
'size_u_m',
'size_u_m_after',
'pack_qty',
'pack_qty_after',
'repack',
'repack_after',
'total_package_qty',
'total_package_qty_after',
'desi',
'desi_after',
'pack_descr',
'pack_descr_after',
'legend_change_dttm',
'legend_change_dttm_aftr',
'next_smlr_suffix',
'next_smlr_suffix_aftr',
'next_lrgr_suffix',
'next_lrgr_suffix_aftr',
'l_last_change_dttm',
'l_last_change_dttm_aftr',
'awp_cd_1_3',
'awp_cd_1_3_aftr',
'awp_pack_price',
'awp_pack_price_aftr',
'awp_unit_price',
'awp_unit_price_aftr',
'awp_dttm',
'awp_dttm_aftr',
'wholesale_unit_price',
'wholesale_unit_price_aftr',
'r1_last_change_dttm',
'r1_last_change_dttm_aftr',
'awp_cd_4_6',
'awp_cd_4_6_aftr',
'awp_reported_ind',
'awp_reported_ind_aftr',
'r11_last_change_dttm',
'r11_last_change_dttm_aftr',
'dp_pack_price',
'dp_pack_price_aftr',
'dp_unit_price',
'dp_unit_price_aftr',
'dp_dttm',
'dp_dttm_aftr',
's1_last_change_dttm',
's1_last_change_dttm_aftr',
's11_last_change_dttm',
's11_last_change_dttm_after',
'hcfa_ffp_limit',
'hcfa_ffp_limit_aftr',
'hcfa_ffp_dttm',
'hcfa_ffp_dttm_after',
't_last_change_dttm',
't_last_change_dttm_after',
'mddb_dur_kdc_nbr',
'mddb_dur_kdc_nbr_after',
'whac_dttm',
'whac_dttm_aftr',
'whac_pack_price',
'whac_pack_price_aftr',
'hzrds_lvl_cd',
'hzrds_lvl_cd_after',
'auth_generic_cd',
'auth_generic_cd_after',
'fda_ind',
'fda_ind_after',
'fda_ind_value',
'fda_ind_value_after',
'auth_ndc_upc_hri',
'auth_ndc_upc_hri_after',
'ddid',
'ddid_after',
'rxcui_type',
'rxcui_type_after',
'rxcui',
'rxcui_after'      
]

#col_len = len(fieldList)
#print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 207 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 208:
      return True
  else:
    if val_len != 208:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len =208

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 208
print(f"Bad records count {rd_bad.count()}") # != 208


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_mddb_drug")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_mddb_drug where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")

display(dfBad)

print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_mddb_drug"))\
          .withColumnRenamed("legend_change_dttm_aftr","legend_change_dttm_after")\
          .withColumnRenamed("next_smlr_suffix_aftr","next_smlr_suffix_after")\
          .withColumnRenamed("next_lrgr_suffix_aftr","next_lrgr_suffix_after")\
          .withColumnRenamed("l_last_change_dttm_aftr","l_last_change_dttm_after")\
          .withColumnRenamed("awp_cd_1_3_aftr","awp_cd_1_3_after")\
          .withColumnRenamed("awp_pack_price_aftr","awp_pack_price_after")\
          .withColumnRenamed("awp_unit_price_aftr","awp_unit_price_after")\
          .withColumnRenamed("awp_dttm_aftr","awp_dttm_after")\
          .withColumnRenamed("wholesale_unit_price_aftr","wholesale_unit_price_after")\
          .withColumnRenamed("r1_last_change_dttm_aftr","r1_last_change_dttm_after")\
          .withColumnRenamed("awp_cd_4_6_aftr","awp_cd_4_6_after")\
          .withColumnRenamed("awp_reported_ind_aftr","awp_reported_ind_after")\
          .withColumnRenamed("r11_last_change_dttm_aftr","r11_last_change_dttm_after")\
          .withColumnRenamed("dp_pack_price_aftr","dp_pack_price_after")\
          .withColumnRenamed("dp_unit_price_aftr","dp_unit_price_after")\
          .withColumnRenamed("dp_dttm_aftr","dp_dttm_after")\
          .withColumnRenamed("s1_last_change_dttm_aftr","s1_last_change_dttm_after")\
          .withColumnRenamed("hcfa_ffp_limit_aftr","hcfa_ffp_limit_after")\
          .withColumnRenamed("whac_dttm_aftr","whac_dttm_after")\
          .withColumnRenamed("whac_pack_price_aftr","whac_pack_price_after")\
          .withColumnRenamed("cdc_operation_type_cd_before","cdc_operation_type_cd")\
          .withColumnRenamed("gen_type_cd","gen_typ_cd")\
          .withColumnRenamed("gen_type_cd_after","gen_typ_cd_after")\
          .withColumnRenamed("prod_desc_abbr_after","prod_descr_abbr_after")


display(df_gg)

df_gg.createOrReplaceTempView("raw_src_gg_table")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

#pRxCutoffTableCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR table_name == 'gg_tbf0_rx_consult_hist' OR  table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_lis')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

#pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR table_name  == 'gg_tbf0_rx_consult_actv' OR  table_name  == 'gg_tbf0_dur_history' OR table_name  == 'gg_tbf0_rx_consult_adhoc'   OR  table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_lis')"

#pSrcCleanseXfr

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND ndc_upc_hri == ndc_upc_hri_after AND ndc_upc_hri IS NOT NULL AND ndc_upc_hri_after IS NOT NULL AND  id_form_cd == id_form_cd_after AND id_form_cd IS NOT NULL AND id_form_cd_after IS NOT NULL AND  cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL AND  cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL AND  cdc_txn_commit_dttm == cdc_txn_commit_dttm_after  AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL AND   ( (drug_status_cd == drug_status_cd_after AND drug_status_cd IS NOT NULL AND drug_status_cd_after IS NOT NULL) OR ( drug_status_cd IS NULL AND  drug_status_cd_after IS NULL ) ) AND  ( (seq_cd == seq_cd_after AND seq_cd IS NOT NULL AND seq_cd_after IS NOT NULL) OR ( seq_cd IS NULL AND  seq_cd_after IS NULL ) ) AND  ( (labeler_cd == labeler_cd_after AND labeler_cd IS NOT NULL AND labeler_cd_after IS NOT NULL ) OR ( labeler_cd IS NULL AND  labeler_cd_after IS NULL ) ) AND  ( (gen_typ_cd == gen_typ_cd_after AND gen_typ_cd IS NOT NULL AND gen_typ_cd_after IS NOT NULL) OR ( gen_typ_cd IS NULL AND  gen_typ_cd_after IS NULL ) ) AND  ( (gen_id_no == gen_id_no_after AND gen_id_no IS NOT NULL AND gen_id_no_after IS NOT NULL ) OR ( gen_id_no IS NULL AND  gen_id_no_after IS NULL ) ) AND  ( (dea_class == dea_class_after AND dea_class IS NOT NULL AND dea_class_after IS NOT NULL ) OR ( dea_class IS NULL AND  dea_class_after IS NULL ) ) AND  ( (thera_class == thera_class_after AND thera_class IS NOT NULL AND thera_class_after IS NOT NULL ) OR ( thera_class IS NULL AND  thera_class_after IS NULL ) ) AND  ( (thera_equiv == thera_equiv_after AND thera_equiv IS NOT NULL AND thera_equiv_after IS NOT NULL) OR ( thera_equiv IS NULL AND  thera_equiv_after IS NULL ) ) AND  ( (form_id_no == form_id_no_after AND form_id_no IS NOT NULL AND form_id_no_after IS NOT NULL ) OR ( form_id_no IS NULL AND  form_id_no_after IS NULL ) ) AND  ( (rx_otc_ind == rx_otc_ind_after AND rx_otc_ind IS NOT NULL AND rx_otc_ind_after IS NOT NULL ) OR ( rx_otc_ind IS NULL AND  rx_otc_ind_after IS NULL ) ) AND  ( (third_party == third_party_after AND third_party IS NOT NULL AND third_party_after IS NOT NULL) OR ( third_party IS NULL AND  third_party_after IS NULL ) ) AND  ( (maint_drug == maint_drug_after AND maint_drug IS NOT NULL AND maint_drug_after IS NOT NULL) OR ( maint_drug IS NULL AND  maint_drug_after IS NULL ) ) AND  ( (disp_unit == disp_unit_after AND disp_unit IS NOT NULL AND disp_unit_after IS NOT NULL) OR ( disp_unit IS NULL AND  disp_unit_after IS NULL ) ) AND  ( (ud_uu_pkg == ud_uu_pkg_after AND ud_uu_pkg IS NOT NULL AND ud_uu_pkg_after IS NOT NULL) OR ( ud_uu_pkg IS NULL AND  ud_uu_pkg_after IS NULL ) ) AND   ( (route_admin == route_admin_after AND route_admin IS NOT NULL AND route_admin_after IS NOT NULL ) OR ( route_admin IS NULL AND  route_admin_after IS NULL ) ) AND  ( (form_type == form_type_after AND form_type IS NOT NULL AND form_type_after IS NOT NULL ) OR ( form_type IS NULL AND  form_type_after IS NULL ) ) AND  ( (dollar_rank == dollar_rank_after AND dollar_rank IS NOT NULL AND dollar_rank_after IS NOT NULL) OR ( dollar_rank IS NULL AND  dollar_rank_after IS NULL ) ) AND  ( (rx_rank == rx_rank_after AND rx_rank IS NOT NULL AND rx_rank_after IS NOT NULL ) OR ( rx_rank IS NULL AND  rx_rank_after IS NULL ) ) AND  ( (sec_id_fmt_cd == sec_id_fmt_cd_after AND sec_id_fmt_cd IS NOT NULL AND sec_id_fmt_cd_after IS NOT NULL ) OR ( sec_id_fmt_cd IS NULL AND  sec_id_fmt_cd_after IS NULL ) ) AND  ( (sec_ndc_upc_hri == sec_ndc_upc_hri_after AND sec_ndc_upc_hri IS NOT NULL AND sec_ndc_upc_hri_after IS NOT NULL) OR ( sec_ndc_upc_hri IS NULL AND  sec_ndc_upc_hri_after IS NULL ) ) AND  ( (gen_cd == gen_cd_after AND gen_cd IS NOT NULL AND gen_cd_after IS NOT NULL ) OR ( gen_cd IS NULL AND  gen_cd_after IS NULL ) ) AND  ( (brand_name_cd == brand_name_cd_after AND brand_name_cd IS NOT NULL AND brand_name_cd_after IS NOT NULL) OR ( brand_name_cd IS NULL AND  brand_name_cd_after IS NULL ) ) AND  ( (int_ext == int_ext_after AND int_ext IS NOT NULL AND int_ext_after IS NOT NULL) OR ( int_ext IS NULL AND  int_ext_after IS NULL ) ) AND  ( (single_comb == single_comb_after AND single_comb IS NOT NULL AND single_comb_after IS NOT NULL) OR ( single_comb IS NULL AND  single_comb_after IS NULL ) ) AND  ( (stor_cond == stor_cond_after AND stor_cond IS NOT NULL AND stor_cond_after IS NOT NULL ) OR ( stor_cond IS NULL AND  stor_cond_after IS NULL ) ) AND  ( (lim_stabil == lim_stabil_after AND lim_stabil IS NOT NULL AND lim_stabil_after IS NOT NULL ) OR ( lim_stabil IS NULL AND  lim_stabil_after IS NULL ) ) AND  ( (a_last_change_dttm == a_last_change_dttm_after AND a_last_change_dttm IS NOT NULL AND a_last_change_dttm_after IS NOT NULL ) OR ( a_last_change_dttm IS NULL AND  a_last_change_dttm_after IS NULL ) ) AND  ( (old_fmt_cd == old_fmt_cd_after AND old_fmt_cd IS NOT NULL AND old_fmt_cd_after IS NOT NULL ) OR ( old_fmt_cd IS NULL AND  old_fmt_cd_after IS NULL ) ) AND  ( (old_ndc_upc_hri == old_ndc_upc_hri_after AND old_ndc_upc_hri IS NOT NULL AND old_ndc_upc_hri_after IS NOT NULL) OR ( old_ndc_upc_hri IS NULL AND  old_ndc_upc_hri_after IS NULL ) ) AND  ( (old_fmt_no == old_fmt_no_after AND old_fmt_no IS NOT NULL AND old_fmt_no_after IS NOT NULL) OR ( old_fmt_no IS NULL AND  old_fmt_no_after IS NULL ) ) AND  ( (old_dttm == old_dttm_after AND old_dttm IS NOT NULL AND old_dttm_after IS NOT NULL) OR ( old_dttm IS NULL AND  old_dttm_after IS NULL ) ) AND  ( (new_fmt_cd == new_fmt_cd_after AND new_fmt_cd IS NOT NULL AND new_fmt_cd_after IS NOT NULL) OR ( new_fmt_cd IS NULL AND  new_fmt_cd_after IS NULL ) ) AND  ( (new_ndc_upc_hri == new_ndc_upc_hri_after AND new_ndc_upc_hri IS NOT NULL AND new_ndc_upc_hri_after IS NOT NULL) OR ( new_ndc_upc_hri IS NULL AND  new_ndc_upc_hri_after IS NULL ) ) AND  ( (new_fmt_no == new_fmt_no_after AND new_fmt_no IS NOT NULL AND new_fmt_no_after IS NOT NULL) OR ( new_fmt_no IS NULL AND  new_fmt_no_after IS NULL ) ) AND  ( (new_dttm == new_dttm_after AND new_dttm IS NOT NULL AND new_dttm_after IS NOT NULL) OR ( new_dttm IS NULL AND  new_dttm_after IS NULL ) ) AND  ( (c_last_change_dttm == c_last_change_dttm_after AND c_last_change_dttm IS NOT NULL AND c_last_change_dttm_after IS NOT NULL) OR ( c_last_change_dttm IS NULL AND  c_last_change_dttm_after IS NULL ) ) AND  ( (prod_name == prod_name_after AND prod_name IS NOT NULL AND prod_name_after IS NOT NULL) OR ( prod_name IS NULL AND  prod_name_after IS NULL ) ) AND  ( (prod_name_ext == prod_name_ext_after AND prod_name_ext IS NOT NULL AND prod_name_ext_after IS NOT NULL ) OR ( prod_name_ext IS NULL AND  prod_name_ext_after IS NULL ) ) AND  ( (dpc == dpc_after AND dpc IS NOT NULL AND dpc_after IS NOT NULL) OR ( dpc IS NULL AND  dpc_after IS NULL ) ) AND  ( (ppc == ppc_after AND ppc IS NOT NULL AND ppc_after IS NOT NULL) OR ( ppc IS NULL AND  ppc_after IS NULL ) ) AND  ( (apc == apc_after AND apc IS NOT NULL AND apc_after IS NOT NULL) OR ( apc IS NULL AND  apc_after IS NULL ) ) AND  ( (ppg_cd == ppg_cd_after AND ppg_cd IS NOT NULL AND ppg_cd_after IS NOT NULL) OR ( ppg_cd IS NULL AND  ppg_cd_after IS NULL ) ) AND  ( (hfpg_cd == hfpg_cd_after AND hfpg_cd IS NOT NULL AND hfpg_cd_after IS NOT NULL) OR ( hfpg_cd IS NULL AND  hfpg_cd_after IS NULL ) ) AND  ( (e_last_change_dttm == e_last_change_dttm_after AND e_last_change_dttm IS NOT NULL AND e_last_change_dttm_after IS NOT NULL) OR ( e_last_change_dttm IS NULL AND  e_last_change_dttm_after IS NULL ) ) AND  ( (gpi == gpi_after AND gpi IS NOT NULL AND gpi_after IS NOT NULL) OR ( gpi IS NULL AND  gpi_after IS NULL ) ) AND  ( (gpi_name == gpi_name_after AND gpi_name IS NOT NULL AND gpi_name_after IS NOT NULL) OR ( gpi_name IS NULL AND  gpi_name_after IS NULL ) ) AND  ( (g_last_change_dttm == g_last_change_dttm_after AND g_last_change_dttm IS NOT NULL AND g_last_change_dttm_after IS NOT NULL ) OR ( g_last_change_dttm IS NULL AND  g_last_change_dttm_after IS NULL ) ) AND  ( (manuf_name == manuf_name_after AND manuf_name IS NOT NULL AND manuf_name_after IS NOT NULL) OR ( manuf_name IS NULL AND  manuf_name_after IS NULL ) ) AND  ( (manuf_name_abbr == manuf_name_abbr_after AND manuf_name_abbr IS NOT NULL AND manuf_name_abbr_after IS NOT NULL) OR ( manuf_name_abbr IS NULL AND  manuf_name_abbr_after IS NULL ) ) AND  ( (prod_descr_abbr == prod_descr_abbr_after AND prod_descr_abbr IS NOT NULL AND prod_descr_abbr_after IS NOT NULL) OR ( prod_descr_abbr IS NULL AND  prod_descr_abbr_after IS NULL ) ) AND  ( (drug_name_cd == drug_name_cd_after AND drug_name_cd IS NOT NULL AND drug_name_cd_after IS NOT NULL) OR ( drug_name_cd IS NULL AND  drug_name_cd_after IS NULL ) ) AND  ( (gppc == gppc_after AND gppc IS NOT NULL AND gppc_after IS NOT NULL) OR ( gppc IS NULL AND  gppc_after IS NULL ) ) AND  ( (j_last_change_dttm == j_last_change_dttm_after AND j_last_change_dttm IS NOT NULL AND j_last_change_dttm_after IS NOT NULL) OR ( j_last_change_dttm IS NULL AND  j_last_change_dttm_after IS NULL ) ) AND  ( (mt_strn == mt_strn_after AND mt_strn IS NOT NULL AND mt_strn_after IS NOT NULL) OR ( mt_strn IS NULL AND  mt_strn_after IS NULL ) ) AND  ( (strn_u_m == strn_u_m_after AND strn_u_m IS NOT NULL AND strn_u_m_after IS NOT NULL) OR ( strn_u_m IS NULL AND  strn_u_m_after IS NULL ) ) AND  ( (dosage_form == dosage_form_after AND dosage_form IS NOT NULL AND dosage_form_after IS NOT NULL) OR ( dosage_form IS NULL AND  dosage_form_after IS NULL ) ) AND  ( (pack_size == pack_size_after AND pack_size IS NOT NULL AND pack_size_after IS NOT NULL) OR ( pack_size IS NULL AND  pack_size_after IS NULL ) ) AND  ( (size_u_m == size_u_m_after AND size_u_m IS NOT NULL AND size_u_m_after IS NOT NULL) OR ( size_u_m IS NULL AND  size_u_m_after IS NULL ) ) AND  ( (pack_qty == pack_qty_after AND pack_qty IS NOT NULL AND pack_qty_after IS NOT NULL) OR ( pack_qty IS NULL AND  pack_qty_after IS NULL ) ) AND  ( (repack == repack_after AND repack IS NOT NULL AND repack_after IS NOT NULL ) OR ( repack IS NULL AND  repack_after IS NULL ) ) AND  ( (total_package_qty == total_package_qty_after AND total_package_qty IS NOT NULL AND total_package_qty_after IS NOT NULL) OR ( total_package_qty IS NULL AND  total_package_qty_after IS NULL ) ) AND  ( (desi == desi_after AND desi IS NOT NULL AND desi_after IS NOT NULL) OR ( desi IS NULL AND  desi_after IS NULL ) ) AND  ( (pack_descr == pack_descr_after AND pack_descr IS NOT NULL AND pack_descr_after IS NOT NULL) OR ( pack_descr IS NULL AND  pack_descr_after IS NULL ) ) AND  ( (legend_change_dttm == legend_change_dttm_after AND legend_change_dttm IS NOT NULL AND legend_change_dttm_after IS NOT NULL) OR ( legend_change_dttm IS NULL AND  legend_change_dttm_after IS NULL ) ) AND  ( (next_smlr_suffix == next_smlr_suffix_after AND next_smlr_suffix IS NOT NULL AND next_smlr_suffix_after IS NOT NULL) OR ( next_smlr_suffix IS NULL AND  next_smlr_suffix_after IS NULL ) ) AND  ( (next_lrgr_suffix == next_lrgr_suffix_after AND next_lrgr_suffix IS NOT NULL AND next_lrgr_suffix_after IS NOT NULL) OR ( next_lrgr_suffix IS NULL AND  next_lrgr_suffix_after IS NULL ) ) AND  ( (l_last_change_dttm == l_last_change_dttm_after AND l_last_change_dttm IS NOT NULL AND l_last_change_dttm_after IS NOT NULL) OR ( l_last_change_dttm IS NULL AND  l_last_change_dttm_after IS NULL ) ) AND  ( (awp_cd_1_3 == awp_cd_1_3_after AND awp_cd_1_3 IS NOT NULL AND awp_cd_1_3_after IS NOT NULL) OR ( awp_cd_1_3 IS NULL AND  awp_cd_1_3_after IS NULL ) ) AND  ( (awp_pack_price == awp_pack_price_after AND awp_pack_price IS NOT NULL AND awp_pack_price_after IS NOT NULL) OR ( awp_pack_price IS NULL AND  awp_pack_price_after IS NULL ) ) AND  ( (awp_unit_price == awp_unit_price_after AND awp_unit_price IS NOT NULL AND awp_unit_price_after IS NOT NULL) OR ( awp_unit_price IS NULL AND  awp_unit_price_after IS NULL ) ) AND  ( (awp_dttm == awp_dttm_after AND awp_dttm IS NOT NULL AND awp_dttm_after IS NOT NULL) OR ( awp_dttm IS NULL AND  awp_dttm_after IS NULL ) ) AND  ( (wholesale_unit_price == wholesale_unit_price_after AND wholesale_unit_price IS NOT NULL AND wholesale_unit_price_after IS NOT NULL) OR ( wholesale_unit_price IS NULL AND  wholesale_unit_price_after IS NULL ) ) AND  ( (r1_last_change_dttm == r1_last_change_dttm_after AND r1_last_change_dttm IS NOT NULL AND r1_last_change_dttm_after IS NOT NULL) OR ( r1_last_change_dttm IS NULL AND  r1_last_change_dttm_after IS NULL ) ) AND  ( (awp_cd_4_6 == awp_cd_4_6_after AND awp_cd_4_6 IS NOT NULL AND awp_cd_4_6_after IS NOT NULL) OR ( awp_cd_4_6 IS NULL AND  awp_cd_4_6_after IS NULL ) ) AND  ( (awp_reported_ind == awp_reported_ind_after AND awp_reported_ind IS NOT NULL AND awp_reported_ind_after IS NOT NULL) OR ( awp_reported_ind IS NULL AND  awp_reported_ind_after IS NULL ) ) AND  ( (r11_last_change_dttm == r11_last_change_dttm_after AND r11_last_change_dttm IS NOT NULL AND r11_last_change_dttm_after IS NOT NULL) OR ( r11_last_change_dttm IS NULL AND  r11_last_change_dttm_after IS NULL ) ) AND  ( (dp_pack_price == dp_pack_price_after AND dp_pack_price IS NOT NULL AND dp_pack_price_after IS NOT NULL) OR ( dp_pack_price IS NULL AND  dp_pack_price_after IS NULL ) ) AND  ( (dp_unit_price == dp_unit_price_after AND dp_unit_price IS NOT NULL AND dp_unit_price_after IS NOT NULL) OR ( dp_unit_price IS NULL AND  dp_unit_price_after IS NULL ) ) AND  ( (dp_dttm == dp_dttm_after AND dp_dttm IS NOT NULL AND dp_dttm_after IS NOT NULL) OR ( dp_dttm IS NULL AND  dp_dttm_after IS NULL ) ) AND  ( (s1_last_change_dttm == s1_last_change_dttm_after AND s1_last_change_dttm IS NOT NULL AND s1_last_change_dttm_after IS NOT NULL) OR ( s1_last_change_dttm IS NULL AND  s1_last_change_dttm_after IS NULL ) ) AND  ( (s11_last_change_dttm == s11_last_change_dttm_after AND s11_last_change_dttm IS NOT NULL AND s11_last_change_dttm_after IS NOT NULL) OR ( s11_last_change_dttm IS NULL AND  s11_last_change_dttm_after IS NULL ) ) AND  ( (hcfa_ffp_limit == hcfa_ffp_limit_after AND hcfa_ffp_limit IS NOT NULL AND hcfa_ffp_limit_after IS NOT NULL) OR ( hcfa_ffp_limit IS NULL AND  hcfa_ffp_limit_after IS NULL ) ) AND  ( (hcfa_ffp_dttm == hcfa_ffp_dttm_after AND hcfa_ffp_dttm IS NOT NULL AND hcfa_ffp_dttm_after IS NOT NULL) OR ( hcfa_ffp_dttm IS NULL AND  hcfa_ffp_dttm_after IS NULL ) ) AND  ( (t_last_change_dttm == t_last_change_dttm_after AND t_last_change_dttm IS NOT NULL AND t_last_change_dttm_after IS NOT NULL) OR ( t_last_change_dttm IS NULL AND  t_last_change_dttm_after IS NULL ) ) AND  ( (mddb_dur_kdc_nbr == mddb_dur_kdc_nbr_after AND mddb_dur_kdc_nbr IS NOT NULL AND mddb_dur_kdc_nbr_after IS NOT NULL) OR ( mddb_dur_kdc_nbr IS NULL AND  mddb_dur_kdc_nbr_after IS NULL ) ) AND  ( (hzrds_lvl_cd == hzrds_lvl_cd_after AND hzrds_lvl_cd IS NOT NULL AND hzrds_lvl_cd_after IS NOT NULL) OR ( hzrds_lvl_cd IS NULL AND  hzrds_lvl_cd_after IS NULL ) ) AND ( ( auth_generic_cd  == auth_generic_cd_after AND  auth_generic_cd  is NOT NULL AND  auth_generic_cd_after  is NOT NULL ) OR ( auth_generic_cd  IS NULL AND auth_generic_cd_after  IS NULL ) ) AND ( ( fda_ind  == fda_ind_after AND  fda_ind  is NOT NULL AND  fda_ind_after  is NOT NULL ) OR ( fda_ind  IS NULL AND fda_ind_after  IS NULL ) ) AND ( ( fda_ind_value  == fda_ind_value_after AND  fda_ind_value  is NOT NULL AND  fda_ind_value_after  is NOT NULL ) OR ( fda_ind_value  IS NULL AND fda_ind_value_after  IS NULL ) ) AND ( ( auth_ndc_upc_hri  == auth_ndc_upc_hri_after AND  auth_ndc_upc_hri  is NOT NULL AND  auth_ndc_upc_hri_after  is NOT NULL ) OR ( auth_ndc_upc_hri  IS NULL AND auth_ndc_upc_hri_after  IS NULL ) ) AND ( ( ddid  == ddid_after AND  ddid  is NOT NULL AND  ddid_after  is NOT NULL ) OR ( ddid  IS NULL AND ddid_after  IS NULL ) ) AND ( ( rxcui_type  == rxcui_type_after AND  rxcui_type  is NOT NULL AND  rxcui_type_after  is NOT NULL ) OR ( rxcui_type  IS NULL AND rxcui_type_after  IS NULL ) ) AND ( ( rxcui  == rxcui_after AND  rxcui  is NOT NULL AND  rxcui_after  is NOT NULL ) OR ( rxcui  IS NULL AND rxcui_after  IS NULL ) ))" 

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

#pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, ndc_upc_hri, id_form_cd, drug_status_cd, seq_cd, labeler_cd, gen_typ_cd, gen_id_no, dea_class, thera_class, thera_equiv, form_id_no, rx_otc_ind, third_party, maint_drug, disp_unit, ud_uu_pkg, route_admin, form_type, dollar_rank, rx_rank, sec_id_fmt_cd, sec_ndc_upc_hri, gen_cd, brand_name_cd, int_ext, single_comb, stor_cond, lim_stabil, CONCAT(a_last_change_dttm,'.000000') AS a_last_change_dttm, old_fmt_cd, old_ndc_upc_hri, old_fmt_no, CONCAT(old_dttm,'.000000') AS old_dttm, new_fmt_cd, new_ndc_upc_hri, new_fmt_no, CONCAT(new_dttm,'.000000') AS new_dttm, CONCAT(c_last_change_dttm,'.000000') AS c_last_change_dttm, prod_name, prod_name_ext, dpc, ppc, apc, ppg_cd, hfpg_cd, CONCAT(e_last_change_dttm,'.000000') AS e_last_change_dttm, gpi, gpi_name, CONCAT(g_last_change_dttm,'.000000') AS g_last_change_dttm, manuf_name, manuf_name_abbr, prod_descr_abbr, drug_name_cd, gppc, CONCAT(j_last_change_dttm,'.000000') AS j_last_change_dttm, mt_strn, strn_u_m, dosage_form, pack_size, size_u_m, pack_qty, repack, total_package_qty, desi, pack_descr, CONCAT(legend_change_dttm,'.000000') AS legend_change_dttm, next_smlr_suffix, next_lrgr_suffix, CONCAT(l_last_change_dttm,'.000000') AS l_last_change_dttm, awp_cd_1_3, awp_pack_price, awp_unit_price, CONCAT(awp_dttm,'.000000') AS awp_dttm, wholesale_unit_price, CONCAT(r1_last_change_dttm,'.000000') AS r1_last_change_dttm, awp_cd_4_6, awp_reported_ind, CONCAT(r11_last_change_dttm,'.000000') AS r11_last_change_dttm, dp_pack_price, dp_unit_price, CONCAT(dp_dttm,'.000000') AS dp_dttm, CONCAT(s1_last_change_dttm,'.000000') AS s1_last_change_dttm, CONCAT(s11_last_change_dttm,'.000000') AS s11_last_change_dttm, hcfa_ffp_limit, CONCAT(hcfa_ffp_dttm,'.000000') AS hcfa_ffp_dttm, CONCAT(t_last_change_dttm,'.000000') AS t_last_change_dttm, mddb_dur_kdc_nbr, hzrds_lvl_cd, auth_generic_cd, fda_ind, fda_ind_value, auth_ndc_upc_hri, ddid, rxcui_type, rxcui"
#, tracking_id, partition_column"


# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

BATCH_ID_CHK = """'""" + BATCH_ID + """'"""
PROJ_ID_CHK = """'""" + PROJ_ID + """'"""

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_output.PROJ_NAME == PROJ_ID_CHK))
#display(cutoff_records_filter)


#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_rx)
rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_trans)
rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_src_gg_table where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_src_gg_table where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_src_gg_table where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  #display(nr_input_file_filter_rx)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual)
  nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck)
  nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual)
  nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

display(ded)


# COMMAND ----------

dedup_group.printSchema()

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim( ndc_upc_hri )) ==0) then ndc_upc_hri else trim(ndc_upc_hri) end) as ndc_upc_hri,
(case when (LENGTH(trim( ndc_upc_hri_after )) ==0) then ndc_upc_hri_after else trim(ndc_upc_hri_after) end) as ndc_upc_hri_after,
(case when (LENGTH(trim( id_form_cd )) ==0) then id_form_cd else trim(id_form_cd) end) as id_form_cd,
(case when (LENGTH(trim( id_form_cd_after )) ==0) then id_form_cd_after else trim(id_form_cd_after) end) as id_form_cd_after,
(case when (LENGTH(trim( drug_status_cd )) ==0) then drug_status_cd else trim(drug_status_cd) end) as drug_status_cd,
(case when (LENGTH(trim( drug_status_cd_after )) ==0) then drug_status_cd_after else trim(drug_status_cd_after) end) as drug_status_cd_after,
(case when (LENGTH(trim( seq_cd )) ==0) then seq_cd else trim(seq_cd) end) as seq_cd,
(case when (LENGTH(trim( seq_cd_after )) ==0) then seq_cd_after else trim(seq_cd_after) end) as seq_cd_after,
(case when (LENGTH(trim( labeler_cd )) ==0) then labeler_cd else trim(labeler_cd) end) as labeler_cd,
(case when (LENGTH(trim( labeler_cd_after )) ==0) then labeler_cd_after else trim(labeler_cd_after) end) as labeler_cd_after,
(case when (LENGTH(trim( gen_typ_cd )) ==0) then gen_typ_cd else trim(gen_typ_cd) end) as gen_typ_cd,
(case when (LENGTH(trim( gen_typ_cd_after )) ==0) then gen_typ_cd_after else trim(gen_typ_cd_after) end) as gen_typ_cd_after,
(case when (LENGTH(trim( gen_id_no )) ==0) then gen_id_no else trim(gen_id_no) end) as gen_id_no,
(case when (LENGTH(trim( gen_id_no_after )) ==0) then gen_id_no_after else trim(gen_id_no_after) end) as gen_id_no_after,
(case when (LENGTH(trim( dea_class )) ==0) then dea_class else trim(dea_class) end) as dea_class,
(case when (LENGTH(trim( dea_class_after )) ==0) then dea_class_after else trim(dea_class_after) end) as dea_class_after,
(case when (LENGTH(trim( thera_class )) ==0) then thera_class else trim(thera_class) end) as thera_class,
(case when (LENGTH(trim( thera_class_after )) ==0) then thera_class_after else trim(thera_class_after) end) as thera_class_after,
(case when (LENGTH(trim( thera_equiv )) ==0) then thera_equiv else trim(thera_equiv) end) as thera_equiv,
(case when (LENGTH(trim( thera_equiv_after )) ==0) then thera_equiv_after else trim(thera_equiv_after) end) as thera_equiv_after,
(case when (LENGTH(trim( form_id_no )) ==0) then form_id_no else trim(form_id_no) end) as form_id_no,
(case when (LENGTH(trim( form_id_no_after )) ==0) then form_id_no_after else trim(form_id_no_after) end) as form_id_no_after,
(case when (LENGTH(trim( rx_otc_ind )) ==0) then rx_otc_ind else trim(rx_otc_ind) end) as rx_otc_ind,
(case when (LENGTH(trim( rx_otc_ind_after )) ==0) then rx_otc_ind_after else trim(rx_otc_ind_after) end) as rx_otc_ind_after,
(case when (LENGTH(trim( third_party )) ==0) then third_party else trim(third_party) end) as third_party,
(case when (LENGTH(trim( third_party_after )) ==0) then third_party_after else trim(third_party_after) end) as third_party_after,
(case when (LENGTH(trim( maint_drug )) ==0) then maint_drug else trim(maint_drug) end) as maint_drug,
(case when (LENGTH(trim( maint_drug_after )) ==0) then maint_drug_after else trim(maint_drug_after) end) as maint_drug_after,
(case when (LENGTH(trim( disp_unit )) ==0) then disp_unit else trim(disp_unit) end) as disp_unit,
(case when (LENGTH(trim( disp_unit_after )) ==0) then disp_unit_after else trim(disp_unit_after) end) as disp_unit_after,
(case when (LENGTH(trim( ud_uu_pkg )) ==0) then ud_uu_pkg else trim(ud_uu_pkg) end) as ud_uu_pkg,
(case when (LENGTH(trim( ud_uu_pkg_after )) ==0) then ud_uu_pkg_after else trim(ud_uu_pkg_after) end) as ud_uu_pkg_after,
(case when (LENGTH(trim( route_admin )) ==0) then route_admin else trim(route_admin) end) as route_admin,
(case when (LENGTH(trim( route_admin_after )) ==0) then route_admin_after else trim(route_admin_after) end) as route_admin_after,
(case when (LENGTH(trim( form_type )) ==0) then form_type else trim(form_type) end) as form_type,
(case when (LENGTH(trim( form_type_after )) ==0) then form_type_after else trim(form_type_after) end) as form_type_after,
(case when (LENGTH(trim( dollar_rank )) ==0) then dollar_rank else trim(dollar_rank) end) as dollar_rank,
(case when (LENGTH(trim( dollar_rank_after )) ==0) then dollar_rank_after else trim(dollar_rank_after) end) as dollar_rank_after,
(case when (LENGTH(trim( rx_rank )) ==0) then rx_rank else trim(rx_rank) end) as rx_rank,
(case when (LENGTH(trim( rx_rank_after )) ==0) then rx_rank_after else trim(rx_rank_after) end) as rx_rank_after,
(case when (LENGTH(trim( sec_id_fmt_cd )) ==0) then sec_id_fmt_cd else trim(sec_id_fmt_cd) end) as sec_id_fmt_cd,
(case when (LENGTH(trim( sec_id_fmt_cd_after )) ==0) then sec_id_fmt_cd_after else trim(sec_id_fmt_cd_after) end) as sec_id_fmt_cd_after,
(case when (LENGTH(trim( sec_ndc_upc_hri )) ==0) then sec_ndc_upc_hri else trim(sec_ndc_upc_hri) end) as sec_ndc_upc_hri,
(case when (LENGTH(trim( sec_ndc_upc_hri_after )) ==0) then sec_ndc_upc_hri_after else trim(sec_ndc_upc_hri_after) end) as sec_ndc_upc_hri_after,
(case when (LENGTH(trim( gen_cd )) ==0) then gen_cd else trim(gen_cd) end) as gen_cd,
(case when (LENGTH(trim( gen_cd_after )) ==0) then gen_cd_after else trim(gen_cd_after) end) as gen_cd_after,
(case when (LENGTH(trim( brand_name_cd )) ==0) then brand_name_cd else trim(brand_name_cd) end) as brand_name_cd,
(case when (LENGTH(trim( brand_name_cd_after )) ==0) then brand_name_cd_after else trim(brand_name_cd_after) end) as brand_name_cd_after,
(case when (LENGTH(trim( int_ext )) ==0) then int_ext else trim(int_ext) end) as int_ext,
(case when (LENGTH(trim( int_ext_after )) ==0) then int_ext_after else trim(int_ext_after) end) as int_ext_after,
(case when (LENGTH(trim( single_comb )) ==0) then single_comb else trim(single_comb) end) as single_comb,
(case when (LENGTH(trim( single_comb_after )) ==0) then single_comb_after else trim(single_comb_after) end) as single_comb_after,
(case when (LENGTH(trim( stor_cond )) ==0) then stor_cond else trim(stor_cond) end) as stor_cond,
(case when (LENGTH(trim( stor_cond_after )) ==0) then stor_cond_after else trim(stor_cond_after) end) as stor_cond_after,
(case when (LENGTH(trim( lim_stabil )) ==0) then lim_stabil else trim(lim_stabil) end) as lim_stabil,
(case when (LENGTH(trim( lim_stabil_after )) ==0) then lim_stabil_after else trim(lim_stabil_after) end) as lim_stabil_after,
(case when (LENGTH(trim(a_last_change_dttm )) ==0) then  a_last_change_dttm else concat(substring(a_last_change_dttm,1,10),' ',substring(a_last_change_dttm,12,8))  end) as a_last_change_dttm,
(case when (LENGTH(trim(a_last_change_dttm_after )) ==0) then  a_last_change_dttm_after else concat(substring(a_last_change_dttm_after,1,10),' ',substring(a_last_change_dttm_after,12,8))  end) as a_last_change_dttm_after,
(case when (LENGTH(trim( old_fmt_cd )) ==0) then old_fmt_cd else trim(old_fmt_cd) end) as old_fmt_cd,
(case when (LENGTH(trim( old_fmt_cd_after )) ==0) then old_fmt_cd_after else trim(old_fmt_cd_after) end) as old_fmt_cd_after,
(case when (LENGTH(trim( old_ndc_upc_hri )) ==0) then old_ndc_upc_hri else trim(old_ndc_upc_hri) end) as old_ndc_upc_hri,
(case when (LENGTH(trim( old_ndc_upc_hri_after )) ==0) then old_ndc_upc_hri_after else trim(old_ndc_upc_hri_after) end) as old_ndc_upc_hri_after,
(case when (LENGTH(trim( old_fmt_no )) ==0) then old_fmt_no else trim(old_fmt_no) end) as old_fmt_no,
(case when (LENGTH(trim( old_fmt_no_after )) ==0) then old_fmt_no_after else trim(old_fmt_no_after) end) as old_fmt_no_after,
(case when (LENGTH(trim(old_dttm )) ==0) then  old_dttm else concat(substring(old_dttm,1,10),' ',substring(old_dttm,12,8))  end) as old_dttm,
(case when (LENGTH(trim( old_dttm_after )) ==0) then old_dttm_after else concat(substring(old_dttm_after,1,10),' ',substring(old_dttm_after,12,8)) end) as old_dttm_after,
(case when (LENGTH(trim( new_fmt_cd )) ==0) then new_fmt_cd else trim(new_fmt_cd) end) as new_fmt_cd,
(case when (LENGTH(trim( new_fmt_cd_after )) ==0) then new_fmt_cd_after else trim(new_fmt_cd_after) end) as new_fmt_cd_after,
(case when (LENGTH(trim( new_ndc_upc_hri )) ==0) then new_ndc_upc_hri else trim(new_ndc_upc_hri) end) as new_ndc_upc_hri,
(case when (LENGTH(trim( new_ndc_upc_hri_after )) ==0) then new_ndc_upc_hri_after else trim(new_ndc_upc_hri_after) end) as new_ndc_upc_hri_after,
(case when (LENGTH(trim( new_fmt_no )) ==0) then new_fmt_no else trim(new_fmt_no) end) as new_fmt_no,
(case when (LENGTH(trim( new_fmt_no_after )) ==0) then new_fmt_no_after else trim(new_fmt_no_after) end) as new_fmt_no_after,
(case when (LENGTH(trim(new_dttm )) ==0) then  new_dttm else concat(substring(new_dttm,1,10),' ',substring(new_dttm,12,8))  end) as new_dttm,
(case when (LENGTH(trim( new_dttm_after )) ==0) then new_dttm_after else concat(substring(new_dttm_after,1,10),' ',substring(new_dttm_after,12,8)) end) as new_dttm_after,
(case when (LENGTH(trim(c_last_change_dttm )) ==0) then  c_last_change_dttm else concat(substring(c_last_change_dttm,1,10),' ',substring(c_last_change_dttm,12,8))  end) as c_last_change_dttm,
(case when (LENGTH(trim( c_last_change_dttm_after )) ==0) then c_last_change_dttm_after else concat(substring(c_last_change_dttm_after,1,10),' ',substring(c_last_change_dttm_after,12,8)) end) as c_last_change_dttm_after,
(case when (LENGTH(trim( prod_name )) ==0) then prod_name else trim(prod_name) end) as prod_name,
(case when (LENGTH(trim( prod_name_after )) ==0) then prod_name_after else trim(prod_name_after) end) as prod_name_after,
(case when (LENGTH(trim( prod_name_ext )) ==0) then prod_name_ext else trim(prod_name_ext) end) as prod_name_ext,
(case when (LENGTH(trim( prod_name_ext_after )) ==0) then prod_name_ext_after else trim(prod_name_ext_after) end) as prod_name_ext_after,
(case when (LENGTH(trim( dpc )) ==0) then dpc else trim(dpc) end) as dpc,
(case when (LENGTH(trim( dpc_after )) ==0) then dpc_after else trim(dpc_after) end) as dpc_after,
(case when (LENGTH(trim( ppc )) ==0) then ppc else trim(ppc) end) as ppc,
(case when (LENGTH(trim( ppc_after )) ==0) then ppc_after else trim(ppc_after) end) as ppc_after,
(case when (LENGTH(trim( apc )) ==0) then apc else trim(apc) end) as apc,
(case when (LENGTH(trim( apc_after )) ==0) then apc_after else trim(apc_after) end) as apc_after,
(case when (LENGTH(trim( ppg_cd )) ==0) then ppg_cd else trim(ppg_cd) end) as ppg_cd,
(case when (LENGTH(trim( ppg_cd_after )) ==0) then ppg_cd_after else trim(ppg_cd_after) end) as ppg_cd_after,
(case when (LENGTH(trim( hfpg_cd )) ==0) then hfpg_cd else trim(hfpg_cd) end) as hfpg_cd,
(case when (LENGTH(trim( hfpg_cd_after )) ==0) then hfpg_cd_after else trim(hfpg_cd_after) end) as hfpg_cd_after,
(case when (LENGTH(trim(e_last_change_dttm )) ==0) then  e_last_change_dttm else concat(substring(e_last_change_dttm,1,10),' ',substring(e_last_change_dttm,12,8))  end) as e_last_change_dttm,
(case when (LENGTH(trim( e_last_change_dttm_after )) ==0) then e_last_change_dttm_after else concat(substring(e_last_change_dttm_after,1,10),' ',substring(e_last_change_dttm_after,12,8)) end) as e_last_change_dttm_after,
(case when (LENGTH(trim( gpi )) ==0) then gpi else trim(gpi) end) as gpi,
(case when (LENGTH(trim( gpi_after )) ==0) then gpi_after else trim(gpi_after) end) as gpi_after,
(case when (LENGTH(trim( gpi_name )) ==0) then gpi_name else trim(gpi_name) end) as gpi_name,
(case when (LENGTH(trim( gpi_name_after )) ==0) then gpi_name_after else trim(gpi_name_after) end) as gpi_name_after,
(case when (LENGTH(trim(g_last_change_dttm )) ==0) then  g_last_change_dttm else concat(substring(g_last_change_dttm,1,10),' ',substring(g_last_change_dttm,12,8))  end) as g_last_change_dttm,
(case when (LENGTH(trim( g_last_change_dttm_after )) ==0) then g_last_change_dttm_after else concat(substring(g_last_change_dttm_after,1,10),' ',substring(g_last_change_dttm_after,12,8)) end) as g_last_change_dttm_after,
(case when (LENGTH(trim( manuf_name )) ==0) then manuf_name else trim(manuf_name) end) as manuf_name,
(case when (LENGTH(trim( manuf_name_after )) ==0) then manuf_name_after else trim(manuf_name_after) end) as manuf_name_after,
(case when (LENGTH(trim( manuf_name_abbr )) ==0) then manuf_name_abbr else trim(manuf_name_abbr) end) as manuf_name_abbr,
(case when (LENGTH(trim( manuf_name_abbr_after )) ==0) then manuf_name_abbr_after else trim(manuf_name_abbr_after) end) as manuf_name_abbr_after,
(case when (LENGTH(trim( prod_descr_abbr )) ==0) then prod_descr_abbr else trim(prod_descr_abbr) end) as prod_descr_abbr,
(case when (LENGTH(trim( prod_descr_abbr_after )) ==0) then prod_descr_abbr_after else trim(prod_descr_abbr_after) end) as prod_descr_abbr_after,
(case when (LENGTH(trim( drug_name_cd )) ==0) then drug_name_cd else trim(drug_name_cd) end) as drug_name_cd,
(case when (LENGTH(trim( drug_name_cd_after )) ==0) then drug_name_cd_after else trim(drug_name_cd_after) end) as drug_name_cd_after,
(case when (LENGTH(trim( gppc )) ==0) then gppc else trim(gppc) end) as gppc,
(case when (LENGTH(trim( gppc_after )) ==0) then gppc_after else trim(gppc_after) end) as gppc_after,
(case when (LENGTH(trim(j_last_change_dttm )) ==0) then  j_last_change_dttm else concat(substring(j_last_change_dttm,1,10),' ',substring(j_last_change_dttm,12,8))  end) as j_last_change_dttm,
(case when (LENGTH(trim( j_last_change_dttm_after )) ==0) then j_last_change_dttm_after else concat(substring(j_last_change_dttm_after,1,10),' ',substring(j_last_change_dttm_after,12,8)) end) as j_last_change_dttm_after,
(case when (LENGTH(trim( mt_strn )) ==0) then mt_strn else trim(mt_strn) end) as mt_strn,
(case when (LENGTH(trim( mt_strn_after )) ==0) then mt_strn_after else trim(mt_strn_after) end) as mt_strn_after,
(case when (LENGTH(trim( strn_u_m )) ==0) then strn_u_m else trim(strn_u_m) end) as strn_u_m,
(case when (LENGTH(trim( strn_u_m_after )) ==0) then strn_u_m_after else trim(strn_u_m_after) end) as strn_u_m_after,
(case when (LENGTH(trim( dosage_form )) ==0) then dosage_form else trim(dosage_form) end) as dosage_form,
(case when (LENGTH(trim( dosage_form_after )) ==0) then dosage_form_after else trim(dosage_form_after) end) as dosage_form_after,
(case when (LENGTH(trim( pack_size )) ==0) then pack_size else trim(pack_size) end) as pack_size,
(case when (LENGTH(trim( pack_size_after )) ==0) then pack_size_after else trim(pack_size_after) end) as pack_size_after,
(case when (LENGTH(trim( size_u_m )) ==0) then size_u_m else trim(size_u_m) end) as size_u_m,
(case when (LENGTH(trim( size_u_m_after )) ==0) then size_u_m_after else trim(size_u_m_after) end) as size_u_m_after,
(case when (LENGTH(trim( pack_qty )) ==0) then pack_qty else trim(pack_qty) end) as pack_qty,
(case when (LENGTH(trim( pack_qty_after )) ==0) then pack_qty_after else trim(pack_qty_after) end) as pack_qty_after,
(case when (LENGTH(trim( repack )) ==0) then repack else trim(repack) end) as repack,
(case when (LENGTH(trim( repack_after )) ==0) then repack_after else trim(repack_after) end) as repack_after,
(case when (LENGTH(trim( total_package_qty )) ==0) then total_package_qty else trim(total_package_qty) end) as total_package_qty,
(case when (LENGTH(trim( total_package_qty_after )) ==0) then total_package_qty_after else trim(total_package_qty_after) end) as total_package_qty_after,
(case when (LENGTH(trim( desi )) ==0) then desi else trim(desi) end) as desi,
(case when (LENGTH(trim( desi_after )) ==0) then desi_after else trim(desi_after) end) as desi_after,
(case when (LENGTH(trim( pack_descr )) ==0) then pack_descr else trim(pack_descr) end) as pack_descr,
(case when (LENGTH(trim( pack_descr_after )) ==0) then pack_descr_after else trim(pack_descr_after) end) as pack_descr_after,
(case when (LENGTH(trim(legend_change_dttm )) ==0) then  legend_change_dttm else concat(substring(legend_change_dttm,1,10),' ',substring(legend_change_dttm,12,8))  end) as legend_change_dttm,
(case when (LENGTH(trim( legend_change_dttm_after )) ==0) then legend_change_dttm_after else concat(substring(legend_change_dttm_after,1,10),' ',substring(legend_change_dttm_after,12,8)) end) as legend_change_dttm_after,
(case when (LENGTH(trim( next_smlr_suffix )) ==0) then next_smlr_suffix else trim(next_smlr_suffix) end) as next_smlr_suffix,
(case when (LENGTH(trim( next_smlr_suffix_after )) ==0) then next_smlr_suffix_after else trim(next_smlr_suffix_after) end) as next_smlr_suffix_after,
(case when (LENGTH(trim( next_lrgr_suffix )) ==0) then next_lrgr_suffix else trim(next_lrgr_suffix) end) as next_lrgr_suffix,
(case when (LENGTH(trim( next_lrgr_suffix_after )) ==0) then next_lrgr_suffix_after else trim(next_lrgr_suffix_after) end) as next_lrgr_suffix_after,
(case when (LENGTH(trim(l_last_change_dttm )) ==0) then  l_last_change_dttm else concat(substring(l_last_change_dttm,1,10),' ',substring(l_last_change_dttm,12,8))  end) as l_last_change_dttm,
(case when (LENGTH(trim( l_last_change_dttm_after )) ==0) then l_last_change_dttm_after else concat(substring(l_last_change_dttm_after,1,10),' ',substring(l_last_change_dttm_after,12,8)) end) as l_last_change_dttm_after,
(case when (LENGTH(trim( awp_cd_1_3 )) ==0) then awp_cd_1_3 else trim(awp_cd_1_3) end) as awp_cd_1_3,
(case when (LENGTH(trim( awp_cd_1_3_after )) ==0) then awp_cd_1_3_after else trim(awp_cd_1_3_after) end) as awp_cd_1_3_after,
(case when (LENGTH(trim( awp_pack_price )) ==0) then awp_pack_price else trim(awp_pack_price) end) as awp_pack_price,
(case when (LENGTH(trim( awp_pack_price_after )) ==0) then awp_pack_price_after else trim(awp_pack_price_after) end) as awp_pack_price_after,
(case when (LENGTH(trim( awp_unit_price )) ==0) then awp_unit_price else trim(awp_unit_price) end) as awp_unit_price,
(case when (LENGTH(trim( awp_unit_price_after )) ==0) then awp_unit_price_after else trim(awp_unit_price_after) end) as awp_unit_price_after,
(case when (LENGTH(trim(awp_dttm )) ==0) then  awp_dttm else concat(substring(awp_dttm,1,10),' ',substring(awp_dttm,12,8))  end) as awp_dttm,
(case when (LENGTH(trim( awp_dttm_after )) ==0) then awp_dttm_after else concat(substring(awp_dttm_after,1,10),' ',substring(awp_dttm_after,12,8)) end) as awp_dttm_after,
(case when (LENGTH(trim( wholesale_unit_price )) ==0) then wholesale_unit_price else trim(wholesale_unit_price) end) as wholesale_unit_price,
(case when (LENGTH(trim( wholesale_unit_price_after )) ==0) then wholesale_unit_price_after else trim(wholesale_unit_price_after) end) as wholesale_unit_price_after,
(case when (LENGTH(trim(whac_dttm )) ==0) then  whac_dttm else concat(substring(whac_dttm,1,10),' ',substring(whac_dttm,12,8))  end) as whac_dttm,
(case when (LENGTH(trim( whac_dttm_after )) ==0) then whac_dttm_after else concat(substring(whac_dttm_after,1,10),' ',substring(whac_dttm_after,12,8)) end) as whac_dttm_after,
(case when (LENGTH(trim( whac_pack_price )) ==0) then whac_pack_price else trim(whac_pack_price) end) as whac_pack_price,
(case when (LENGTH(trim( whac_pack_price_after )) ==0) then whac_pack_price_after else trim(whac_pack_price_after) end) as whac_pack_price_after,
(case when (LENGTH(trim(r1_last_change_dttm )) ==0) then  r1_last_change_dttm else concat(substring(r1_last_change_dttm,1,10),' ',substring(r1_last_change_dttm,12,8))  end) as r1_last_change_dttm,
(case when (LENGTH(trim( r1_last_change_dttm_after )) ==0) then r1_last_change_dttm_after else concat(substring(r1_last_change_dttm_after,1,10),' ',substring(r1_last_change_dttm_after,12,8)) end) as r1_last_change_dttm_after,
(case when (LENGTH(trim( awp_cd_4_6 )) ==0) then awp_cd_4_6 else trim(awp_cd_4_6) end) as awp_cd_4_6,
(case when (LENGTH(trim( awp_cd_4_6_after )) ==0) then awp_cd_4_6_after else trim(awp_cd_4_6_after) end) as awp_cd_4_6_after,
(case when (LENGTH(trim( awp_reported_ind )) ==0) then awp_reported_ind else trim(awp_reported_ind) end) as awp_reported_ind,
(case when (LENGTH(trim( awp_reported_ind_after )) ==0) then awp_reported_ind_after else trim(awp_reported_ind_after) end) as awp_reported_ind_after,
(case when (LENGTH(trim(r11_last_change_dttm )) ==0) then  r11_last_change_dttm else concat(substring(r11_last_change_dttm,1,10),' ',substring(r11_last_change_dttm,12,8))  end) as r11_last_change_dttm,
(case when (LENGTH(trim( r11_last_change_dttm_after )) ==0) then r11_last_change_dttm_after else concat(substring(r11_last_change_dttm_after,1,10),' ',substring(r11_last_change_dttm_after,12,8)) end) as r11_last_change_dttm_after,
(case when (LENGTH(trim( dp_pack_price )) ==0) then dp_pack_price else trim(dp_pack_price) end) as dp_pack_price,
(case when (LENGTH(trim( dp_pack_price_after )) ==0) then dp_pack_price_after else trim(dp_pack_price_after) end) as dp_pack_price_after,
(case when (LENGTH(trim( dp_unit_price )) ==0) then dp_unit_price else trim(dp_unit_price) end) as dp_unit_price,
(case when (LENGTH(trim( dp_unit_price_after )) ==0) then dp_unit_price_after else trim(dp_unit_price_after) end) as dp_unit_price_after,
(case when (LENGTH(trim(dp_dttm )) ==0) then  dp_dttm else concat(substring(dp_dttm,1,10),' ',substring(dp_dttm,12,8))  end) as dp_dttm,
(case when (LENGTH(trim( dp_dttm_after )) ==0) then dp_dttm_after else concat(substring(dp_dttm_after,1,10),' ',substring(dp_dttm_after,12,8)) end) as dp_dttm_after,
(case when (LENGTH(trim(s1_last_change_dttm )) ==0) then  s1_last_change_dttm else concat(substring(s1_last_change_dttm,1,10),' ',substring(s1_last_change_dttm,12,8))  end) as s1_last_change_dttm,
(case when (LENGTH(trim( s1_last_change_dttm_after )) ==0) then s1_last_change_dttm_after else concat(substring(s1_last_change_dttm_after,1,10),' ',substring(s1_last_change_dttm_after,12,8)) end) as s1_last_change_dttm_after,
(case when (LENGTH(trim(s11_last_change_dttm )) ==0) then  s11_last_change_dttm else concat(substring(s11_last_change_dttm,1,10),' ',substring(s11_last_change_dttm,12,8))  end) as s11_last_change_dttm,
(case when (LENGTH(trim( s11_last_change_dttm_after )) ==0) then s11_last_change_dttm_after else concat(substring(s11_last_change_dttm_after,1,10),' ',substring(s11_last_change_dttm_after,12,8)) end) as s11_last_change_dttm_after,
(case when (LENGTH(trim( hcfa_ffp_limit )) ==0) then hcfa_ffp_limit else trim(hcfa_ffp_limit) end) as hcfa_ffp_limit,
(case when (LENGTH(trim( hcfa_ffp_limit_after )) ==0) then hcfa_ffp_limit_after else trim(hcfa_ffp_limit_after) end) as hcfa_ffp_limit_after,
(case when (LENGTH(trim(hcfa_ffp_dttm )) ==0) then  hcfa_ffp_dttm else concat(substring(hcfa_ffp_dttm,1,10),' ',substring(hcfa_ffp_dttm,12,8))  end) as hcfa_ffp_dttm,
(case when (LENGTH(trim( hcfa_ffp_dttm_after )) ==0) then hcfa_ffp_dttm_after else concat(substring(hcfa_ffp_dttm_after,1,10),' ',substring(hcfa_ffp_dttm_after,12,8)) end) as hcfa_ffp_dttm_after,
(case when (LENGTH(trim(t_last_change_dttm )) ==0) then  t_last_change_dttm else concat(substring(t_last_change_dttm,1,10),' ',substring(t_last_change_dttm,12,8))  end) as t_last_change_dttm,
(case when (LENGTH(trim( t_last_change_dttm_after )) ==0) then t_last_change_dttm_after else concat(substring(t_last_change_dttm_after,1,10),' ',substring(t_last_change_dttm_after,12,8)) end) as t_last_change_dttm_after,
(case when (LENGTH(trim( mddb_dur_kdc_nbr )) ==0) then mddb_dur_kdc_nbr else trim(mddb_dur_kdc_nbr) end) as mddb_dur_kdc_nbr,
(case when (LENGTH(trim( mddb_dur_kdc_nbr_after )) ==0) then mddb_dur_kdc_nbr_after else trim(mddb_dur_kdc_nbr_after) end) as mddb_dur_kdc_nbr_after,
(case when (LENGTH(trim( hzrds_lvl_cd )) ==0) then hzrds_lvl_cd else trim(hzrds_lvl_cd) end) as hzrds_lvl_cd, 
(case when (LENGTH(trim( hzrds_lvl_cd_after )) ==0) then hzrds_lvl_cd_after else trim(hzrds_lvl_cd_after) end) as hzrds_lvl_cd_after,
(case when (LENGTH(trim( auth_generic_cd )) ==0) then auth_generic_cd else trim( auth_generic_cd ) end) as auth_generic_cd, 
(case when (LENGTH(trim( auth_generic_cd_after )) ==0) then auth_generic_cd_after else trim( auth_generic_cd_after ) end ) as auth_generic_cd_after, 
(case when (LENGTH(trim( fda_ind )) ==0) then fda_ind else trim( fda_ind ) end) as fda_ind, 
(case when (LENGTH(trim( fda_ind_after )) ==0) then fda_ind_after else trim( fda_ind_after ) end ) as fda_ind_after, 
(case when (LENGTH(trim( fda_ind_value )) ==0) then fda_ind_value else trim( fda_ind_value ) end) as fda_ind_value, 
(case when (LENGTH(trim( fda_ind_value_after )) ==0) then fda_ind_value_after else trim( fda_ind_value_after ) end ) as fda_ind_value_after, 
(case when (LENGTH(trim( auth_ndc_upc_hri )) ==0) then auth_ndc_upc_hri else trim( auth_ndc_upc_hri ) end) as auth_ndc_upc_hri, 
(case when (LENGTH(trim( auth_ndc_upc_hri_after )) ==0) then auth_ndc_upc_hri_after else trim( auth_ndc_upc_hri_after ) end ) as auth_ndc_upc_hri_after,
(case when (LENGTH(trim( ddid )) ==0) then ddid else trim( ddid ) end) as ddid, 
(case when (LENGTH(trim( ddid_after )) ==0) then ddid_after else trim( ddid_after ) end ) as ddid_after, 
(case when (LENGTH(trim( rxcui_type )) ==0) then rxcui_type else trim( rxcui_type ) end) as rxcui_type, 
(case when (LENGTH(trim( rxcui_type_after )) ==0) then rxcui_type_after else trim( rxcui_type_after ) end ) as rxcui_type_after, 
(case when (LENGTH(trim( rxcui )) ==0) then rxcui else trim( rxcui ) end) as rxcui,
(case when (LENGTH(trim( rxcui_after )) ==0) then rxcui_after else trim( rxcui_after ) end ) as rxcui_after from dedup_group"""


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
ndc_upc_hri_after AS ndc_upc_hri , id_form_cd_after AS id_form_cd , drug_status_cd_after AS drug_status_cd , seq_cd_after AS seq_cd , labeler_cd_after AS labeler_cd , gen_typ_cd_after AS gen_typ_cd , gen_id_no_after AS gen_id_no , dea_class_after AS dea_class , thera_class_after AS thera_class , thera_equiv_after AS thera_equiv , form_id_no_after AS form_id_no , rx_otc_ind_after AS rx_otc_ind , third_party_after AS third_party , maint_drug_after AS maint_drug , disp_unit_after AS disp_unit , ud_uu_pkg_after AS ud_uu_pkg , route_admin_after AS route_admin , form_type_after AS form_type , dollar_rank_after AS dollar_rank , rx_rank_after AS rx_rank , sec_id_fmt_cd_after AS sec_id_fmt_cd , sec_ndc_upc_hri_after AS sec_ndc_upc_hri , gen_cd_after AS gen_cd , brand_name_cd_after AS brand_name_cd , int_ext_after AS int_ext , single_comb_after AS single_comb , stor_cond_after AS stor_cond , lim_stabil_after AS lim_stabil , a_last_change_dttm_after AS a_last_change_dttm , old_fmt_cd_after AS old_fmt_cd , old_ndc_upc_hri_after AS old_ndc_upc_hri , old_fmt_no_after AS old_fmt_no , old_dttm_after AS old_dttm , new_fmt_cd_after AS new_fmt_cd , new_ndc_upc_hri_after AS new_ndc_upc_hri , new_fmt_no_after                 AS new_fmt_no , new_dttm_after AS new_dttm , c_last_change_dttm_after AS c_last_change_dttm , prod_name_after AS prod_name , prod_name_ext_after AS prod_name_ext , dpc_after AS dpc , ppc_after AS ppc , apc_after AS apc , ppg_cd_after AS ppg_cd , hfpg_cd_after AS hfpg_cd , e_last_change_dttm_after AS e_last_change_dttm , gpi_after AS gpi , gpi_name_after AS gpi_name , g_last_change_dttm_after AS g_last_change_dttm , manuf_name_after AS manuf_name , manuf_name_abbr_after AS manuf_name_abbr , prod_descr_abbr_after AS prod_descr_abbr , drug_name_cd_after AS drug_name_cd , gppc_after AS gppc , j_last_change_dttm_after AS j_last_change_dttm , mt_strn_after AS mt_strn , strn_u_m_after AS strn_u_m , dosage_form_after AS dosage_form , pack_size_after AS pack_size , size_u_m_after AS size_u_m , pack_qty_after AS pack_qty , repack_after AS repack , total_package_qty_after AS total_package_qty , desi_after AS desi , pack_descr_after AS pack_descr , legend_change_dttm_after AS legend_change_dttm , next_smlr_suffix_after AS next_smlr_suffix , next_lrgr_suffix_after AS next_lrgr_suffix , l_last_change_dttm_after AS l_last_change_dttm , awp_cd_1_3_after AS awp_cd_1_3 , awp_pack_price_after AS awp_pack_price , awp_unit_price_after AS awp_unit_price , awp_dttm_after AS awp_dttm , wholesale_unit_price_after AS wholesale_unit_price , r1_last_change_dttm_after AS r1_last_change_dttm , awp_cd_4_6_after AS awp_cd_4_6 , awp_reported_ind_after AS awp_reported_ind , r11_last_change_dttm_after AS r11_last_change_dttm , dp_pack_price_after AS dp_pack_price , dp_unit_price_after AS dp_unit_price , dp_dttm_after AS dp_dttm , s1_last_change_dttm_after AS s1_last_change_dttm , s11_last_change_dttm_after AS s11_last_change_dttm , hcfa_ffp_limit_after AS hcfa_ffp_limit , hcfa_ffp_dttm_after AS hcfa_ffp_dttm , t_last_change_dttm_after AS t_last_change_dttm , mddb_dur_kdc_nbr_after AS mddb_dur_kdc_nbr , whac_dttm_after AS whac_dttm , whac_pack_price_after AS whac_pack_price , hzrds_lvl_cd_after AS hzrds_lvl_cd , auth_generic_cd_after As auth_generic_cd , fda_ind_after As fda_ind , fda_ind_value_after As fda_ind_value , auth_ndc_upc_hri_after As auth_ndc_upc_hri , ddid_after As ddid , rxcui_type_after As rxcui_type , rxcui_after As rxcui,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """




# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,
ndc_upc_hri AS ndc_upc_hri , id_form_cd AS id_form_cd , drug_status_cd AS drug_status_cd , seq_cd AS seq_cd , labeler_cd AS labeler_cd , gen_typ_cd AS gen_typ_cd , gen_id_no AS gen_id_no , dea_class AS dea_class , thera_class AS thera_class , thera_equiv AS thera_equiv , form_id_no AS form_id_no , rx_otc_ind AS rx_otc_ind , third_party AS third_party , maint_drug AS maint_drug , disp_unit AS disp_unit , ud_uu_pkg AS ud_uu_pkg , route_admin AS route_admin , form_type AS form_type , dollar_rank AS dollar_rank , rx_rank AS rx_rank , sec_id_fmt_cd AS sec_id_fmt_cd , sec_ndc_upc_hri AS sec_ndc_upc_hri , gen_cd AS gen_cd , brand_name_cd AS brand_name_cd , int_ext AS int_ext , single_comb AS single_comb , stor_cond AS stor_cond , lim_stabil AS lim_stabil , a_last_change_dttm AS a_last_change_dttm , old_fmt_cd AS old_fmt_cd , old_ndc_upc_hri AS old_ndc_upc_hri , old_fmt_no AS old_fmt_no , old_dttm AS old_dttm , new_fmt_cd AS new_fmt_cd , new_ndc_upc_hri AS new_ndc_upc_hri , new_fmt_no AS new_fmt_no , new_dttm AS new_dttm , c_last_change_dttm AS c_last_change_dttm , prod_name AS prod_name , prod_name_ext AS prod_name_ext , dpc AS dpc , ppc AS ppc , apc AS apc , ppg_cd AS ppg_cd , hfpg_cd AS hfpg_cd , e_last_change_dttm AS e_last_change_dttm , gpi AS gpi , gpi_name AS gpi_name , g_last_change_dttm AS g_last_change_dttm , manuf_name AS manuf_name , manuf_name_abbr AS manuf_name_abbr , prod_descr_abbr AS prod_descr_abbr , drug_name_cd AS drug_name_cd , gppc AS gppc , j_last_change_dttm AS j_last_change_dttm , mt_strn AS mt_strn , strn_u_m AS strn_u_m , dosage_form AS dosage_form , pack_size AS pack_size , size_u_m AS size_u_m , pack_qty AS pack_qty , repack AS repack , total_package_qty AS total_package_qty , desi AS desi , pack_descr AS pack_descr , legend_change_dttm AS legend_change_dttm , next_smlr_suffix AS next_smlr_suffix , next_lrgr_suffix AS next_lrgr_suffix , l_last_change_dttm AS l_last_change_dttm , awp_cd_1_3 AS awp_cd_1_3 , awp_pack_price AS awp_pack_price , awp_unit_price AS awp_unit_price , awp_dttm AS awp_dttm , wholesale_unit_price AS wholesale_unit_price , r1_last_change_dttm AS r1_last_change_dttm , awp_cd_4_6 AS awp_cd_4_6 , awp_reported_ind AS awp_reported_ind , r11_last_change_dttm AS r11_last_change_dttm , dp_pack_price AS dp_pack_price , dp_unit_price AS dp_unit_price , dp_dttm AS dp_dttm , s1_last_change_dttm AS s1_last_change_dttm , s11_last_change_dttm AS s11_last_change_dttm , hcfa_ffp_limit AS hcfa_ffp_limit , hcfa_ffp_dttm AS hcfa_ffp_dttm , t_last_change_dttm AS t_last_change_dttm , mddb_dur_kdc_nbr AS mddb_dur_kdc_nbr , whac_dttm AS whac_dttm , whac_pack_price AS whac_pack_price , hzrds_lvl_cd AS hzrds_lvl_cd , auth_generic_cd As auth_generic_cd , fda_ind As fda_ind , fda_ind_value As fda_ind_value , auth_ndc_upc_hri As auth_ndc_upc_hri , ddid As ddid , rxcui_type As rxcui_type , rxcui As rxcui ,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd, 
""" + BATCH_ID + """ as edw_batch_id,
ndc_upc_hri_after AS ndc_upc_hri , id_form_cd_after AS id_form_cd , drug_status_cd_after AS drug_status_cd , seq_cd_after AS seq_cd , labeler_cd_after AS labeler_cd , gen_typ_cd_after AS gen_typ_cd , gen_id_no_after AS gen_id_no , dea_class_after AS dea_class , thera_class_after AS thera_class , thera_equiv_after AS thera_equiv , form_id_no_after AS form_id_no , rx_otc_ind_after AS rx_otc_ind , third_party_after AS third_party , maint_drug_after AS maint_drug , disp_unit_after AS disp_unit , ud_uu_pkg_after AS ud_uu_pkg , route_admin_after AS route_admin , form_type_after AS form_type , dollar_rank_after AS dollar_rank , rx_rank_after AS rx_rank , sec_id_fmt_cd_after AS sec_id_fmt_cd , sec_ndc_upc_hri_after AS sec_ndc_upc_hri , gen_cd_after AS gen_cd , brand_name_cd_after AS brand_name_cd , int_ext_after AS int_ext , single_comb_after AS single_comb , stor_cond_after AS stor_cond , lim_stabil_after AS lim_stabil , a_last_change_dttm_after AS a_last_change_dttm , old_fmt_cd_after AS old_fmt_cd , old_ndc_upc_hri_after AS old_ndc_upc_hri , old_fmt_no_after AS old_fmt_no , old_dttm_after AS old_dttm , new_fmt_cd_after AS new_fmt_cd , new_ndc_upc_hri_after AS new_ndc_upc_hri , new_fmt_no_after                 AS new_fmt_no , new_dttm_after AS new_dttm , c_last_change_dttm_after AS c_last_change_dttm , prod_name_after AS prod_name , prod_name_ext_after AS prod_name_ext , dpc_after AS dpc , ppc_after AS ppc , apc_after AS apc , ppg_cd_after AS ppg_cd , hfpg_cd_after AS hfpg_cd , e_last_change_dttm_after AS e_last_change_dttm , gpi_after AS gpi , gpi_name_after AS gpi_name , g_last_change_dttm_after AS g_last_change_dttm , manuf_name_after AS manuf_name , manuf_name_abbr_after AS manuf_name_abbr , prod_descr_abbr_after AS prod_descr_abbr , drug_name_cd_after AS drug_name_cd , gppc_after AS gppc , j_last_change_dttm_after AS j_last_change_dttm , mt_strn_after AS mt_strn , strn_u_m_after AS strn_u_m , dosage_form_after AS dosage_form , pack_size_after AS pack_size , size_u_m_after AS size_u_m , pack_qty_after AS pack_qty , repack_after AS repack , total_package_qty_after AS total_package_qty , desi_after AS desi , pack_descr_after AS pack_descr , legend_change_dttm_after AS legend_change_dttm , next_smlr_suffix_after AS next_smlr_suffix , next_lrgr_suffix_after AS next_lrgr_suffix , l_last_change_dttm_after AS l_last_change_dttm , awp_cd_1_3_after AS awp_cd_1_3 , awp_pack_price_after AS awp_pack_price , awp_unit_price_after AS awp_unit_price , awp_dttm_after AS awp_dttm , wholesale_unit_price_after AS wholesale_unit_price , r1_last_change_dttm_after AS r1_last_change_dttm , awp_cd_4_6_after AS awp_cd_4_6 , awp_reported_ind_after AS awp_reported_ind , r11_last_change_dttm_after AS r11_last_change_dttm , dp_pack_price_after AS dp_pack_price , dp_unit_price_after AS dp_unit_price , dp_dttm_after AS dp_dttm , s1_last_change_dttm_after AS s1_last_change_dttm , s11_last_change_dttm_after AS s11_last_change_dttm , hcfa_ffp_limit_after AS hcfa_ffp_limit , hcfa_ffp_dttm_after AS hcfa_ffp_dttm , t_last_change_dttm_after AS t_last_change_dttm , mddb_dur_kdc_nbr_after AS mddb_dur_kdc_nbr , whac_dttm_after AS whac_dttm , whac_pack_price_after AS whac_pack_price , hzrds_lvl_cd_after AS hzrds_lvl_cd , auth_generic_cd_after As auth_generic_cd , fda_ind_after As fda_ind , fda_ind_value_after As fda_ind_value , auth_ndc_upc_hri_after As auth_ndc_upc_hri , ddid_after As ddid , rxcui_type_after As rxcui_type , rxcui_after As rxcui,
'""" + SRC_TBL_NAME +  """' as table_name
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)



# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
display(etl_tbf0_file)
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm", to_timestamp(etl_tbf0_reformat_cdc_check_notnull["cdc_txn_commit_dttm"]))\
           .withColumn("a_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["a_last_change_dttm"]))\
           .withColumn("old_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["old_dttm"]))\
           .withColumn("new_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["new_dttm"]))\
           .withColumn("c_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["c_last_change_dttm"]))\
           .withColumn("g_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["g_last_change_dttm"]))\
           .withColumn("e_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["e_last_change_dttm"]))\
           .withColumn("j_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["j_last_change_dttm"]))\
           .withColumn("legend_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["legend_change_dttm"]))\
           .withColumn("l_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["l_last_change_dttm"]))\
           .withColumn("awp_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["awp_dttm"]))\
           .withColumn("r1_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["r1_last_change_dttm"]))\
           .withColumn("r11_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["r11_last_change_dttm"]))\
           .withColumn("dp_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["dp_dttm"]))\
           .withColumn("s1_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["s1_last_change_dttm"]))\
           .withColumn("s11_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["s11_last_change_dttm"]))\
           .withColumn("hcfa_ffp_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["hcfa_ffp_dttm"]))\
           .withColumn("t_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["t_last_change_dttm"]))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_cdc_check_notnull.columns])

display(etl_tbf0_reformat_cdc_check_notnull)



# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()


# COMMAND ----------

# # ReadAPI Call to fetch asset file names with current location:  
# WRITEAPI_URL = dbutils.widgets.get("PAR_WRITEAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 60, 
#                   {"PAR_WRITEAPI_URL":WRITEAPI_URL,
#                    "PAR_WRITEAPI_KEY1":"statusId",
#                    "PAR_WRITEAPI_VALUE1":"200",
#                    "PAR_WRITEAPI_KEY2":"assetId",
#                    "PAR_WRITEAPI_VALUE2":dfAssetIdStr});

# print("Write API successfully executed...")

# COMMAND ----------

dbutils.notebook.exit("ETL_TBF0_MDDB_DRUG LOADED SUCCESSFULLY")
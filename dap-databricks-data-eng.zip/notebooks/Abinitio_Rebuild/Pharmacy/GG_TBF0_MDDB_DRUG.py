# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'


print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'ndc_upc_hri',
'ndc_upc_hri_after',
'id_form_cd',
'id_form_cd_after',
'drug_status_cd',
'drug_status_cd_after',
'seq_cd',
'seq_cd_after',
'labeler_cd',
'labeler_cd_after',
'gen_type_cd',
'gen_type_cd_after',
'gen_id_no',
'gen_id_no_after',
'dea_class',
'dea_class_after',
'thera_class',
'thera_class_after',
'thera_equiv',
'thera_equiv_after',
'form_id_no',
'form_id_no_after',
'rx_otc_ind',
'rx_otc_ind_after',
'third_party',
'third_party_after',
'maint_drug',
'maint_drug_after',
'disp_unit',
'disp_unit_after',
'ud_uu_pkg',
'ud_uu_pkg_after',
'route_admin',
'route_admin_after',
'form_type',
'form_type_after',
'dollar_rank',
'dollar_rank_after',
'rx_rank',
'rx_rank_after',
'sec_id_fmt_cd',
'sec_id_fmt_cd_after',
'sec_ndc_upc_hri',
'sec_ndc_upc_hri_after',
'gen_cd',
'gen_cd_after',
'brand_name_cd',
'brand_name_cd_after',
'int_ext',
'int_ext_after',
'single_comb',
'single_comb_after',
'stor_cond',
'stor_cond_after',
'lim_stabil',
'lim_stabil_after',
'a_last_change_dttm',
'a_last_change_dttm_after',
'old_fmt_cd',
'old_fmt_cd_after',
'old_ndc_upc_hri',
'old_ndc_upc_hri_after',
'old_fmt_no',
'old_fmt_no_after',
'old_dttm',
'old_dttm_after',
'new_fmt_cd',
'new_fmt_cd_after',
'new_ndc_upc_hri',
'new_ndc_upc_hri_after',
'new_fmt_no',
'new_fmt_no_after',
'new_dttm',
'new_dttm_after',
'c_last_change_dttm',
'c_last_change_dttm_after',
'prod_name',
'prod_name_after',
'prod_name_ext',
'prod_name_ext_after',
'dpc',
'dpc_after',
'ppc',
'ppc_after',
'apc',
'apc_after',
'ppg_cd',
'ppg_cd_after',
'hfpg_cd',
'hfpg_cd_after',
'e_last_change_dttm',
'e_last_change_dttm_after',
'gpi',
'gpi_after',
'gpi_name',
'gpi_name_after',
'g_last_change_dttm',
'g_last_change_dttm_after',
'manuf_name',
'manuf_name_after',
'manuf_name_abbr',
'manuf_name_abbr_after',
'prod_descr_abbr',
'prod_desc_abbr_after',
'drug_name_cd',
'drug_name_cd_after',
'gppc',
'gppc_after',
'j_last_change_dttm',
'j_last_change_dttm_after',
'mt_strn',
'mt_strn_after',
'strn_u_m',
'strn_u_m_after',
'dosage_form',
'dosage_form_after',
'pack_size',
'pack_size_after',
'size_u_m',
'size_u_m_after',
'pack_qty',
'pack_qty_after',
'repack',
'repack_after',
'total_package_qty',
'total_package_qty_after',
'desi',
'desi_after',
'pack_descr',
'pack_descr_after',
'legend_change_dttm',
'legend_change_dttm_aftr',
'next_smlr_suffix',
'next_smlr_suffix_aftr',
'next_lrgr_suffix',
'next_lrgr_suffix_aftr',
'l_last_change_dttm',
'l_last_change_dttm_aftr',
'awp_cd_1_3',
'awp_cd_1_3_aftr',
'awp_pack_price',
'awp_pack_price_aftr',
'awp_unit_price',
'awp_unit_price_aftr',
'awp_dttm',
'awp_dttm_aftr',
'wholesale_unit_price',
'wholesale_unit_price_aftr',
'r1_last_change_dttm',
'r1_last_change_dttm_aftr',
'awp_cd_4_6',
'awp_cd_4_6_aftr',
'awp_reported_ind',
'awp_reported_ind_aftr',
'r11_last_change_dttm',
'r11_last_change_dttm_aftr',
'dp_pack_price',
'dp_pack_price_aftr',
'dp_unit_price',
'dp_unit_price_aftr',
'dp_dttm',
'dp_dttm_aftr',
's1_last_change_dttm',
's1_last_change_dttm_aftr',
's11_last_change_dttm',
's11_last_change_dttm_after',
'hcfa_ffp_limit',
'hcfa_ffp_limit_aftr',
'hcfa_ffp_dttm',
'hcfa_ffp_dttm_after',
't_last_change_dttm',
't_last_change_dttm_after',
'mddb_dur_kdc_nbr',
'mddb_dur_kdc_nbr_after',
'whac_dttm',
'whac_dttm_aftr',
'whac_pack_price',
'whac_pack_price_aftr',
'hzrds_lvl_cd',
'hzrds_lvl_cd_after',
'auth_generic_cd',
'auth_generic_cd_after',
'fda_ind',
'fda_ind_after',
'fda_ind_value',
'fda_ind_value_after',
'auth_ndc_upc_hri',
'auth_ndc_upc_hri_after',
'ddid',
'ddid_after',
'rxcui_type',
'rxcui_type_after',
'rxcui',
'rxcui_after'      
]

#col_len = len(fieldList)
#print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 207 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 208:
      return True
  else:
    if val_len != 208:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len =208

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 208
print(f"Bad records count {rd_bad.count()}") # != 208


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_mddb_drug")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id,
(case when (LENGTH(trim( ndc_upc_hri )) ==0) then ndc_upc_hri else trim(ndc_upc_hri) end) as ndc_upc_hri,
(case when (LENGTH(trim( id_form_cd )) ==0) then id_form_cd else trim(id_form_cd) end) as id_form_cd,
(case when (LENGTH(trim( drug_status_cd )) ==0) then drug_status_cd else trim(drug_status_cd) end) as drug_status_cd,
(case when (LENGTH(trim( seq_cd )) ==0) then seq_cd else trim(seq_cd) end) as seq_cd,
(case when (LENGTH(trim( labeler_cd )) ==0) then labeler_cd else trim(labeler_cd) end) as labeler_cd,
(case when (LENGTH(trim( gen_type_cd )) ==0) then gen_type_cd else trim(gen_type_cd) end) as gen_typ_cd,
(case when (LENGTH(trim( gen_id_no )) ==0) then gen_id_no else trim(gen_id_no) end) as gen_id_no,
(case when (LENGTH(trim( dea_class )) ==0) then dea_class else trim(dea_class) end) as dea_class,
(case when (LENGTH(trim( thera_class )) ==0) then thera_class else trim(thera_class) end) as thera_class,
(case when (LENGTH(trim( thera_equiv )) ==0) then thera_equiv else trim(thera_equiv) end) as thera_equiv,
(case when (LENGTH(trim( form_id_no )) ==0) then form_id_no else trim(form_id_no) end) as form_id_no,
(case when (LENGTH(trim( rx_otc_ind )) ==0) then rx_otc_ind else trim(rx_otc_ind) end) as rx_otc_ind,
(case when (LENGTH(trim( third_party )) ==0) then third_party else trim(third_party) end) as third_party,
(case when (LENGTH(trim( maint_drug )) ==0) then maint_drug else trim(maint_drug) end) as maint_drug,
(case when (LENGTH(trim( disp_unit )) ==0) then disp_unit else trim(disp_unit) end) as disp_unit,
(case when (LENGTH(trim( ud_uu_pkg )) ==0) then ud_uu_pkg else trim(ud_uu_pkg) end) as ud_uu_pkg,
(case when (LENGTH(trim( route_admin )) ==0) then route_admin else trim(route_admin) end) as route_admin,
(case when (LENGTH(trim( form_type )) ==0) then form_type else trim(form_type) end) as form_type,
(case when (LENGTH(trim( dollar_rank )) ==0) then dollar_rank else trim(dollar_rank) end) as dollar_rank,
(case when (LENGTH(trim( rx_rank )) ==0) then rx_rank else trim(rx_rank) end) as rx_rank,
(case when (LENGTH(trim( sec_id_fmt_cd )) ==0) then sec_id_fmt_cd else trim(sec_id_fmt_cd) end) as sec_id_fmt_cd,
(case when (LENGTH(trim( sec_ndc_upc_hri )) ==0) then sec_ndc_upc_hri else trim(sec_ndc_upc_hri) end) as sec_ndc_upc_hri,
(case when (LENGTH(trim( gen_cd )) ==0) then gen_cd else trim(gen_cd) end) as gen_cd,
(case when (LENGTH(trim( brand_name_cd )) ==0) then brand_name_cd else trim(brand_name_cd) end) as brand_name_cd,
(case when (LENGTH(trim( int_ext )) ==0) then int_ext else trim(int_ext) end) as int_ext,
(case when (LENGTH(trim( single_comb )) ==0) then single_comb else trim(single_comb) end) as single_comb,
(case when (LENGTH(trim( stor_cond )) ==0) then stor_cond else trim(stor_cond) end) as stor_cond,
(case when (LENGTH(trim( lim_stabil )) ==0) then lim_stabil else trim(lim_stabil) end) as lim_stabil,
(case when (LENGTH(trim(a_last_change_dttm )) ==0) then  a_last_change_dttm else concat(substring(a_last_change_dttm,1,10),' ',substring(a_last_change_dttm,12,8),'.000000')  end) as a_last_change_dttm,
(case when (LENGTH(trim( old_fmt_cd )) ==0) then old_fmt_cd else trim(old_fmt_cd) end) as old_fmt_cd,
(case when (LENGTH(trim( old_ndc_upc_hri )) ==0) then old_ndc_upc_hri else trim(old_ndc_upc_hri) end) as old_ndc_upc_hri,
(case when (LENGTH(trim( old_fmt_no )) ==0) then old_fmt_no else trim(old_fmt_no) end) as old_fmt_no,
(case when (LENGTH(trim(old_dttm )) ==0) then  old_dttm else concat(substring(old_dttm,1,10),' ',substring(old_dttm,12,8),'.000000')  end) as old_dttm,
(case when (LENGTH(trim( new_fmt_cd )) ==0) then new_fmt_cd else trim(new_fmt_cd) end) as new_fmt_cd,
(case when (LENGTH(trim( new_ndc_upc_hri )) ==0) then new_ndc_upc_hri else trim(new_ndc_upc_hri) end) as new_ndc_upc_hri,
(case when (LENGTH(trim( new_fmt_no )) ==0) then new_fmt_no else trim(new_fmt_no) end) as new_fmt_no,
(case when (LENGTH(trim(new_dttm )) ==0) then  new_dttm else concat(substring(new_dttm,1,10),' ',substring(new_dttm,12,8),'.000000')  end) as new_dttm,
(case when (LENGTH(trim(c_last_change_dttm )) ==0) then  c_last_change_dttm else concat(substring(c_last_change_dttm,1,10),' ',substring(c_last_change_dttm,12,8),'.000000')  end) as c_last_change_dttm,
(case when (LENGTH(trim( prod_name )) ==0) then prod_name else trim(prod_name) end) as prod_name,
(case when (LENGTH(trim( prod_name_ext )) ==0) then prod_name_ext else trim(prod_name_ext) end) as prod_name_ext,
(case when (LENGTH(trim( dpc )) ==0) then dpc else trim(dpc) end) as dpc,
(case when (LENGTH(trim( ppc )) ==0) then ppc else trim(ppc) end) as ppc,
(case when (LENGTH(trim( apc )) ==0) then apc else trim(apc) end) as apc,
(case when (LENGTH(trim( ppg_cd )) ==0) then ppg_cd else trim(ppg_cd) end) as ppg_cd,
(case when (LENGTH(trim( hfpg_cd )) ==0) then hfpg_cd else trim(hfpg_cd) end) as hfpg_cd,
(case when (LENGTH(trim(e_last_change_dttm )) ==0) then  e_last_change_dttm else concat(substring(e_last_change_dttm,1,10),' ',substring(e_last_change_dttm,12,8),'.000000')  end) as e_last_change_dttm,
(case when (LENGTH(trim( gpi )) ==0) then gpi else trim(gpi) end) as gpi,
(case when (LENGTH(trim( gpi_name )) ==0) then gpi_name else trim(gpi_name) end) as gpi_name,
(case when (LENGTH(trim(g_last_change_dttm )) ==0) then  g_last_change_dttm else concat(substring(g_last_change_dttm,1,10),' ',substring(g_last_change_dttm,12,8),'.000000')  end) as g_last_change_dttm,
(case when (LENGTH(trim( manuf_name )) ==0) then manuf_name else trim(manuf_name) end) as manuf_name,
(case when (LENGTH(trim( manuf_name_abbr )) ==0) then manuf_name_abbr else trim(manuf_name_abbr) end) as manuf_name_abbr,
(case when (LENGTH(trim( prod_descr_abbr )) ==0) then prod_descr_abbr else trim(prod_descr_abbr) end) as prod_descr_abbr,
(case when (LENGTH(trim( drug_name_cd )) ==0) then drug_name_cd else trim(drug_name_cd) end) as drug_name_cd,
(case when (LENGTH(trim( gppc )) ==0) then gppc else trim(gppc) end) as gppc,
(case when (LENGTH(trim(j_last_change_dttm )) ==0) then  j_last_change_dttm else concat(substring(j_last_change_dttm,1,10),' ',substring(j_last_change_dttm,12,8),'.000000')  end) as j_last_change_dttm,
(case when (LENGTH(trim( mt_strn )) ==0) then mt_strn else trim(mt_strn) end) as mt_strn,
(case when (LENGTH(trim( strn_u_m )) ==0) then strn_u_m else trim(strn_u_m) end) as strn_u_m,
(case when (LENGTH(trim( dosage_form )) ==0) then dosage_form else trim(dosage_form) end) as dosage_form,
(case when (LENGTH(trim( pack_size )) ==0) then pack_size else trim(pack_size) end) as pack_size,
(case when (LENGTH(trim( size_u_m )) ==0) then size_u_m else trim(size_u_m) end) as size_u_m,
(case when (LENGTH(trim( pack_qty )) ==0) then pack_qty else trim(pack_qty) end) as pack_qty,
(case when (LENGTH(trim( repack )) ==0) then repack else trim(repack) end) as repack,
(case when (LENGTH(trim( total_package_qty )) ==0) then total_package_qty else trim(total_package_qty) end) as total_package_qty,
(case when (LENGTH(trim( desi )) ==0) then desi else trim(desi) end) as desi,
(case when (LENGTH(trim( pack_descr )) ==0) then pack_descr else trim(pack_descr) end) as pack_descr,
(case when (LENGTH(trim(legend_change_dttm )) ==0) then  legend_change_dttm else concat(substring(legend_change_dttm,1,10),' ',substring(legend_change_dttm,12,8),'.000000')  end) as legend_change_dttm,
(case when (LENGTH(trim( next_smlr_suffix )) ==0) then next_smlr_suffix else trim(next_smlr_suffix) end) as next_smlr_suffix,
(case when (LENGTH(trim( next_lrgr_suffix )) ==0) then next_lrgr_suffix else trim(next_lrgr_suffix) end) as next_lrgr_suffix,
(case when (LENGTH(trim(l_last_change_dttm )) ==0) then  l_last_change_dttm else concat(substring(l_last_change_dttm,1,10),' ',substring(l_last_change_dttm,12,8),'.000000')  end) as l_last_change_dttm,
(case when (LENGTH(trim( awp_cd_1_3 )) ==0) then awp_cd_1_3 else trim(awp_cd_1_3) end) as awp_cd_1_3,
(case when (LENGTH(trim( awp_pack_price )) ==0) then awp_pack_price else trim(awp_pack_price) end) as awp_pack_price,
(case when (LENGTH(trim( awp_unit_price )) ==0) then awp_unit_price else trim(awp_unit_price) end) as awp_unit_price,
(case when (LENGTH(trim(awp_dttm )) ==0) then  awp_dttm else concat(substring(awp_dttm,1,10),' ',substring(awp_dttm,12,8),'.000000')  end) as awp_dttm,
(case when (LENGTH(trim( wholesale_unit_price )) ==0) then wholesale_unit_price else trim(wholesale_unit_price) end) as wholesale_unit_price,
(case when (LENGTH(trim(whac_dttm )) ==0) then  whac_dttm else concat(substring(whac_dttm,1,10),' ',substring(whac_dttm,12,8),'.000000')  end) as whac_dttm,
(case when (LENGTH(trim( whac_pack_price )) ==0) then whac_pack_price else trim(whac_pack_price) end) as whac_pack_price,
(case when (LENGTH(trim(r1_last_change_dttm )) ==0) then  r1_last_change_dttm else concat(substring(r1_last_change_dttm,1,10),' ',substring(r1_last_change_dttm,12,8),'.000000')  end) as r1_last_change_dttm,
(case when (LENGTH(trim( awp_cd_4_6 )) ==0) then awp_cd_4_6 else trim(awp_cd_4_6) end) as awp_cd_4_6,
(case when (LENGTH(trim( awp_reported_ind )) ==0) then awp_reported_ind else trim(awp_reported_ind) end) as awp_reported_ind,
(case when (LENGTH(trim(r11_last_change_dttm )) ==0) then  r11_last_change_dttm else concat(substring(r11_last_change_dttm,1,10),' ',substring(r11_last_change_dttm,12,8),'.000000')  end) as r11_last_change_dttm,
(case when (LENGTH(trim( dp_pack_price )) ==0) then dp_pack_price else trim(dp_pack_price) end) as dp_pack_price,
(case when (LENGTH(trim( dp_unit_price )) ==0) then dp_unit_price else trim(dp_unit_price) end) as dp_unit_price,
(case when (LENGTH(trim(dp_dttm )) ==0) then  dp_dttm else concat(substring(dp_dttm,1,10),' ',substring(dp_dttm,12,8),'.000000')  end) as dp_dttm,
(case when (LENGTH(trim(s1_last_change_dttm )) ==0) then  s1_last_change_dttm else concat(substring(s1_last_change_dttm,1,10),' ',substring(s1_last_change_dttm,12,8),'.000000')  end) as s1_last_change_dttm,
(case when (LENGTH(trim(s11_last_change_dttm )) ==0) then  s11_last_change_dttm else concat(substring(s11_last_change_dttm,1,10),' ',substring(s11_last_change_dttm,12,8),'.000000')  end) as s11_last_change_dttm,
(case when (LENGTH(trim( hcfa_ffp_limit )) ==0) then hcfa_ffp_limit else trim(hcfa_ffp_limit) end) as hcfa_ffp_limit,
(case when (LENGTH(trim(hcfa_ffp_dttm )) ==0) then  hcfa_ffp_dttm else concat(substring(hcfa_ffp_dttm,1,10),' ',substring(hcfa_ffp_dttm,12,8),'.000000')  end) as hcfa_ffp_dttm,
(case when (LENGTH(trim(t_last_change_dttm )) ==0) then  t_last_change_dttm else concat(substring(t_last_change_dttm,1,10),' ',substring(t_last_change_dttm,12,8),'.000000')  end) as t_last_change_dttm,
(case when (LENGTH(trim( mddb_dur_kdc_nbr )) ==0) then mddb_dur_kdc_nbr else trim(mddb_dur_kdc_nbr) end) as mddb_dur_kdc_nbr,
(case when (LENGTH(trim( hzrds_lvl_cd )) ==0) then hzrds_lvl_cd else trim(hzrds_lvl_cd) end) as hzrds_lvl_cd, 
(case when (LENGTH(trim( auth_generic_cd )) ==0) then auth_generic_cd else trim( auth_generic_cd ) end) as auth_generic_cd, 
(case when (LENGTH(trim( fda_ind )) ==0) then fda_ind else trim( fda_ind ) end) as fda_ind, 
(case when (LENGTH(trim( fda_ind_value )) ==0) then fda_ind_value else trim( fda_ind_value ) end) as fda_ind_value, 
(case when (LENGTH(trim( auth_ndc_upc_hri )) ==0) then auth_ndc_upc_hri else trim( auth_ndc_upc_hri ) end) as auth_ndc_upc_hri, 
(case when (LENGTH(trim( ddid )) ==0) then ddid else trim( ddid ) end) as ddid, 
(case when (LENGTH(trim( rxcui_type )) ==0) then rxcui_type else trim( rxcui_type ) end) as rxcui_type, 
(case when (LENGTH(trim( rxcui )) ==0) then rxcui else trim( rxcui ) end) as rxcui,
'000000' as tracking_id
from gg_tbf0_mddb_drug where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql2 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( ndc_upc_hri_after )) ==0) then ndc_upc_hri_after else trim(ndc_upc_hri_after) end) as ndc_upc_hri,
(case when (LENGTH(trim( id_form_cd_after )) ==0) then id_form_cd_after else trim(id_form_cd_after) end) as id_form_cd,
(case when (LENGTH(trim( drug_status_cd_after )) ==0) then drug_status_cd_after else trim(drug_status_cd_after) end) as drug_status_cd,
(case when (LENGTH(trim( seq_cd_after )) ==0) then seq_cd_after else trim(seq_cd_after) end) as seq_cd,
(case when (LENGTH(trim( labeler_cd_after )) ==0) then labeler_cd_after else trim(labeler_cd_after) end) as labeler_cd,
(case when (LENGTH(trim( gen_type_cd_after )) ==0) then gen_type_cd_after else trim(gen_type_cd_after) end) as gen_typ_cd,
(case when (LENGTH(trim( gen_id_no_after )) ==0) then gen_id_no_after else trim(gen_id_no_after) end) as gen_id_no,
(case when (LENGTH(trim( dea_class_after )) ==0) then dea_class_after else trim(dea_class_after) end) as dea_class,
(case when (LENGTH(trim( thera_class_after )) ==0) then thera_class_after else trim(thera_class_after) end) as thera_class,
(case when (LENGTH(trim( thera_equiv_after )) ==0) then thera_equiv_after else trim(thera_equiv_after) end) as thera_equiv,
(case when (LENGTH(trim( form_id_no_after )) ==0) then form_id_no_after else trim(form_id_no_after) end) as form_id_no,
(case when (LENGTH(trim( rx_otc_ind_after )) ==0) then rx_otc_ind_after else trim(rx_otc_ind_after) end) as rx_otc_ind,
(case when (LENGTH(trim( third_party_after )) ==0) then third_party_after else trim(third_party_after) end) as third_party,
(case when (LENGTH(trim( maint_drug_after )) ==0) then maint_drug_after else trim(maint_drug_after) end) as maint_drug,
(case when (LENGTH(trim( disp_unit_after )) ==0) then disp_unit_after else trim(disp_unit_after) end) as disp_unit,
(case when (LENGTH(trim( ud_uu_pkg_after )) ==0) then ud_uu_pkg_after else trim(ud_uu_pkg_after) end) as ud_uu_pkg,
(case when (LENGTH(trim( route_admin_after )) ==0) then route_admin_after else trim(route_admin_after) end) as route_admin,
(case when (LENGTH(trim( form_type_after )) ==0) then form_type_after else trim(form_type_after) end) as form_type,
(case when (LENGTH(trim( dollar_rank_after )) ==0) then dollar_rank_after else trim(dollar_rank_after) end) as dollar_rank,
(case when (LENGTH(trim( rx_rank_after )) ==0) then rx_rank_after else trim(rx_rank_after) end) as rx_rank,
(case when (LENGTH(trim( sec_id_fmt_cd_after )) ==0) then sec_id_fmt_cd_after else trim(sec_id_fmt_cd_after) end) as sec_id_fmt_cd,
(case when (LENGTH(trim( sec_ndc_upc_hri_after )) ==0) then sec_ndc_upc_hri_after else trim(sec_ndc_upc_hri_after) end) as sec_ndc_upc_hri,
(case when (LENGTH(trim( gen_cd_after )) ==0) then gen_cd_after else trim(gen_cd_after) end) as gen_cd,
(case when (LENGTH(trim( brand_name_cd_after )) ==0) then brand_name_cd_after else trim(brand_name_cd_after) end) as brand_name_cd,
(case when (LENGTH(trim( int_ext_after )) ==0) then int_ext_after else trim(int_ext_after) end) as int_ext,
(case when (LENGTH(trim( single_comb_after )) ==0) then single_comb_after else trim(single_comb_after) end) as single_comb,
(case when (LENGTH(trim( stor_cond_after )) ==0) then stor_cond_after else trim(stor_cond_after) end) as stor_cond,
(case when (LENGTH(trim( lim_stabil_after )) ==0) then lim_stabil_after else trim(lim_stabil_after) end) as lim_stabil,
(case when (LENGTH(trim( a_last_change_dttm_after )) ==0) then a_last_change_dttm_after else concat(substring(a_last_change_dttm_after,1,10),' ',substring(a_last_change_dttm_after,12,8),'.000000') end) as a_last_change_dttm,
(case when (LENGTH(trim( old_fmt_cd_after )) ==0) then old_fmt_cd_after else trim(old_fmt_cd_after) end) as old_fmt_cd,
(case when (LENGTH(trim( old_ndc_upc_hri_after )) ==0) then old_ndc_upc_hri_after else trim(old_ndc_upc_hri_after) end) as old_ndc_upc_hri,
(case when (LENGTH(trim( old_fmt_no_after )) ==0) then old_fmt_no_after else trim(old_fmt_no_after) end) as old_fmt_no,
(case when (LENGTH(trim( old_dttm_after )) ==0) then old_dttm_after else concat(substring(old_dttm_after,1,10),' ',substring(old_dttm_after,12,8),'.000000') end) as old_dttm,
(case when (LENGTH(trim( new_fmt_cd_after )) ==0) then new_fmt_cd_after else trim(new_fmt_cd_after) end) as new_fmt_cd,
(case when (LENGTH(trim( new_ndc_upc_hri_after )) ==0) then new_ndc_upc_hri_after else trim(new_ndc_upc_hri_after) end) as new_ndc_upc_hri,
(case when (LENGTH(trim( new_fmt_no_after )) ==0) then new_fmt_no_after else trim(new_fmt_no_after) end) as new_fmt_no,
(case when (LENGTH(trim( new_dttm_after )) ==0) then new_dttm_after else concat(substring(new_dttm_after,1,10),' ',substring(new_dttm_after,12,8),'.000000') end) as new_dttm,
(case when (LENGTH(trim( c_last_change_dttm_after )) ==0) then c_last_change_dttm_after else concat(substring(c_last_change_dttm_after,1,10),' ',substring(c_last_change_dttm_after,12,8),'.000000') end) as c_last_change_dttm,
(case when (LENGTH(trim( prod_name_after )) ==0) then prod_name_after else trim(prod_name_after) end) as prod_name,
(case when (LENGTH(trim( prod_name_ext_after )) ==0) then prod_name_ext_after else trim(prod_name_ext_after) end) as prod_name_ext,
(case when (LENGTH(trim( dpc_after )) ==0) then dpc_after else trim(dpc_after) end) as dpc,
(case when (LENGTH(trim( ppc_after )) ==0) then ppc_after else trim(ppc_after) end) as ppc,
(case when (LENGTH(trim( apc_after )) ==0) then apc_after else trim(apc_after) end) as apc,
(case when (LENGTH(trim( ppg_cd_after )) ==0) then ppg_cd_after else trim(ppg_cd_after) end) as ppg_cd,
(case when (LENGTH(trim( hfpg_cd_after )) ==0) then hfpg_cd_after else trim(hfpg_cd_after) end) as hfpg_cd,
(case when (LENGTH(trim( e_last_change_dttm_after )) ==0) then e_last_change_dttm_after else concat(substring(e_last_change_dttm_after,1,10),' ',substring(e_last_change_dttm_after,12,8),'.000000') end) as e_last_change_dttm,
(case when (LENGTH(trim( gpi_after )) ==0) then gpi_after else trim(gpi_after) end) as gpi,
(case when (LENGTH(trim( gpi_name_after )) ==0) then gpi_name_after else trim(gpi_name_after) end) as gpi_name,
(case when (LENGTH(trim( g_last_change_dttm_after )) ==0) then g_last_change_dttm_after else concat(substring(g_last_change_dttm_after,1,10),' ',substring(g_last_change_dttm_after,12,8),'.000000') end) as g_last_change_dttm,
(case when (LENGTH(trim( manuf_name_after )) ==0) then manuf_name_after else trim(manuf_name_after) end) as manuf_name,
(case when (LENGTH(trim( manuf_name_abbr_after )) ==0) then manuf_name_abbr_after else trim(manuf_name_abbr_after) end) as manuf_name_abbr,
(case when (LENGTH(trim( prod_desc_abbr_after )) ==0) then prod_desc_abbr_after else trim(prod_desc_abbr_after) end) as prod_descr_abbr,
(case when (LENGTH(trim( drug_name_cd_after )) ==0) then drug_name_cd_after else trim(drug_name_cd_after) end) as drug_name_cd,
(case when (LENGTH(trim( gppc_after )) ==0) then gppc_after else trim(gppc_after) end) as gppc,
(case when (LENGTH(trim( j_last_change_dttm_after )) ==0) then j_last_change_dttm_after else concat(substring(j_last_change_dttm_after,1,10),' ',substring(j_last_change_dttm_after,12,8),'.000000') end) as j_last_change_dttm,
(case when (LENGTH(trim( mt_strn_after )) ==0) then mt_strn_after else trim(mt_strn_after) end) as mt_strn,
(case when (LENGTH(trim( strn_u_m_after )) ==0) then strn_u_m_after else trim(strn_u_m_after) end) as strn_u_m,
(case when (LENGTH(trim( dosage_form_after )) ==0) then dosage_form_after else trim(dosage_form_after) end) as dosage_form,
(case when (LENGTH(trim( pack_size_after )) ==0) then pack_size_after else trim(pack_size_after) end) as pack_size,
(case when (LENGTH(trim( size_u_m_after )) ==0) then size_u_m_after else trim(size_u_m_after) end) as size_u_m,
(case when (LENGTH(trim( pack_qty_after )) ==0) then pack_qty_after else trim(pack_qty_after) end) as pack_qty,
(case when (LENGTH(trim( repack_after )) ==0) then repack_after else trim(repack_after) end) as repack,
(case when (LENGTH(trim( total_package_qty_after )) ==0) then total_package_qty_after else trim(total_package_qty_after) end) as total_package_qty,
(case when (LENGTH(trim( desi_after )) ==0) then desi_after else trim(desi_after) end) as desi,
(case when (LENGTH(trim( pack_descr_after )) ==0) then pack_descr_after else trim(pack_descr_after) end) as pack_descr,
(case when (LENGTH(trim( legend_change_dttm_aftr )) ==0) then legend_change_dttm_aftr else concat(substring(legend_change_dttm_aftr,1,10),' ',substring(legend_change_dttm_aftr,12,8),'.000000') end) as legend_change_dttm,
(case when (LENGTH(trim( next_smlr_suffix_aftr )) ==0) then next_smlr_suffix_aftr else trim(next_smlr_suffix_aftr) end) as next_smlr_suffix,
(case when (LENGTH(trim( next_lrgr_suffix_aftr )) ==0) then next_lrgr_suffix_aftr else trim(next_lrgr_suffix_aftr) end) as next_lrgr_suffix,
(case when (LENGTH(trim( l_last_change_dttm_aftr )) ==0) then l_last_change_dttm_aftr else concat(substring(l_last_change_dttm_aftr,1,10),' ',substring(l_last_change_dttm_aftr,12,8),'.000000') end) as l_last_change_dttm,
(case when (LENGTH(trim( awp_cd_1_3_aftr )) ==0) then awp_cd_1_3_aftr else trim(awp_cd_1_3_aftr) end) as awp_cd_1_3,
(case when (LENGTH(trim( awp_pack_price_aftr )) ==0) then awp_pack_price_aftr else trim(awp_pack_price_aftr) end) as awp_pack_price,
(case when (LENGTH(trim( awp_unit_price_aftr )) ==0) then awp_unit_price_aftr else trim(awp_unit_price_aftr) end) as awp_unit_price,
(case when (LENGTH(trim( awp_dttm_aftr )) ==0) then awp_dttm_aftr else concat(substring(awp_dttm_aftr,1,10),' ',substring(awp_dttm_aftr,12,8),'.000000') end) as awp_dttm,
(case when (LENGTH(trim( wholesale_unit_price_aftr )) ==0) then wholesale_unit_price_aftr else trim(wholesale_unit_price_aftr) end) as wholesale_unit_price,
(case when (LENGTH(trim( whac_dttm_aftr )) ==0) then whac_dttm_aftr else concat(substring(whac_dttm_aftr,1,10),' ',substring(whac_dttm_aftr,12,8),'.000000') end) as whac_dttm,
(case when (LENGTH(trim( whac_pack_price_aftr )) ==0) then whac_pack_price_aftr else trim(whac_pack_price_aftr) end) as whac_pack_price,
(case when (LENGTH(trim( r1_last_change_dttm_aftr )) ==0) then r1_last_change_dttm_aftr else concat(substring(r1_last_change_dttm_aftr,1,10),' ',substring(r1_last_change_dttm_aftr,12,8),'.000000') end) as r1_last_change_dttm,
(case when (LENGTH(trim( awp_cd_4_6_aftr )) ==0) then awp_cd_4_6_aftr else trim(awp_cd_4_6_aftr) end) as awp_cd_4_6,
(case when (LENGTH(trim( awp_reported_ind_aftr )) ==0) then awp_reported_ind_aftr else trim(awp_reported_ind_aftr) end) as awp_reported_ind,
(case when (LENGTH(trim( r11_last_change_dttm_aftr )) ==0) then r11_last_change_dttm_aftr else concat(substring(r11_last_change_dttm_aftr,1,10),' ',substring(r11_last_change_dttm_aftr,12,8),'.000000') end) as r11_last_change_dttm,
(case when (LENGTH(trim( dp_pack_price_aftr )) ==0) then dp_pack_price_aftr else trim(dp_pack_price_aftr) end) as dp_pack_price,
(case when (LENGTH(trim( dp_unit_price_aftr )) ==0) then dp_unit_price_aftr else trim(dp_unit_price_aftr) end) as dp_unit_price,
(case when (LENGTH(trim( dp_dttm_aftr )) ==0) then dp_dttm_aftr else concat(substring(dp_dttm_aftr,1,10),' ',substring(dp_dttm_aftr,12,8),'.000000') end) as dp_dttm,
(case when (LENGTH(trim( s1_last_change_dttm_aftr )) ==0) then s1_last_change_dttm_aftr else concat(substring(s1_last_change_dttm_aftr,1,10),' ',substring(s1_last_change_dttm_aftr,12,8),'.000000') end) as s1_last_change_dttm,
(case when (LENGTH(trim( s11_last_change_dttm_after )) ==0) then s11_last_change_dttm_after else concat(substring(s11_last_change_dttm_after,1,10),' ',substring(s11_last_change_dttm_after,12,8),'.000000') end) as s11_last_change_dttm,
(case when (LENGTH(trim( hcfa_ffp_limit_aftr )) ==0) then hcfa_ffp_limit_aftr else trim(hcfa_ffp_limit_aftr) end) as hcfa_ffp_limit,
(case when (LENGTH(trim( hcfa_ffp_dttm_after )) ==0) then hcfa_ffp_dttm_after else concat(substring(hcfa_ffp_dttm_after,1,10),' ',substring(hcfa_ffp_dttm_after,12,8),'.000000') end) as hcfa_ffp_dttm,
(case when (LENGTH(trim( t_last_change_dttm_after )) ==0) then t_last_change_dttm_after else concat(substring(t_last_change_dttm_after,1,10),' ',substring(t_last_change_dttm_after,12,8),'.000000') end) as t_last_change_dttm,
(case when (LENGTH(trim( mddb_dur_kdc_nbr_after )) ==0) then mddb_dur_kdc_nbr_after else trim(mddb_dur_kdc_nbr_after) end) as mddb_dur_kdc_nbr,
(case when (LENGTH(trim( hzrds_lvl_cd_after )) ==0) then hzrds_lvl_cd_after else trim(hzrds_lvl_cd_after) end) as hzrds_lvl_cd,
(case when (LENGTH(trim( auth_generic_cd_after )) ==0) then auth_generic_cd_after else trim( auth_generic_cd_after ) end ) as auth_generic_cd, 
(case when (LENGTH(trim( fda_ind_after )) ==0) then fda_ind_after else trim( fda_ind_after ) end ) as fda_ind, 
(case when (LENGTH(trim( fda_ind_value_after )) ==0) then fda_ind_value_after else trim( fda_ind_value_after ) end ) as fda_ind_value, 
(case when (LENGTH(trim( auth_ndc_upc_hri_after )) ==0) then auth_ndc_upc_hri_after else trim( auth_ndc_upc_hri_after ) end ) as auth_ndc_upc_hri, 
(case when (LENGTH(trim( ddid_after )) ==0) then ddid_after else trim( ddid_after ) end ) as ddid, 
(case when (LENGTH(trim( rxcui_type_after )) ==0) then rxcui_type_after else trim( rxcui_type_after ) end ) as rxcui_type, 
(case when (LENGTH(trim( rxcui_after )) ==0) then rxcui_after else trim( rxcui_after ) end ) as rxcui,  
'000000' as tracking_id
from gg_tbf0_mddb_drug where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000')  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( ndc_upc_hri_after )) ==0) then ndc_upc_hri_after else trim(ndc_upc_hri_after) end) as ndc_upc_hri,
(case when (LENGTH(trim( id_form_cd_after )) ==0) then id_form_cd_after else trim(id_form_cd_after) end) as id_form_cd,
(case when (LENGTH(trim( drug_status_cd_after )) ==0) then drug_status_cd_after else trim(drug_status_cd_after) end) as drug_status_cd,
(case when (LENGTH(trim( seq_cd_after )) ==0) then seq_cd_after else trim(seq_cd_after) end) as seq_cd,
(case when (LENGTH(trim( labeler_cd_after )) ==0) then labeler_cd_after else trim(labeler_cd_after) end) as labeler_cd,
(case when (LENGTH(trim( gen_type_cd_after )) ==0) then gen_type_cd_after else trim(gen_type_cd_after) end) as gen_typ_cd,
(case when (LENGTH(trim( gen_id_no_after )) ==0) then gen_id_no_after else trim(gen_id_no_after) end) as gen_id_no,
(case when (LENGTH(trim( dea_class_after )) ==0) then dea_class_after else trim(dea_class_after) end) as dea_class,
(case when (LENGTH(trim( thera_class_after )) ==0) then thera_class_after else trim(thera_class_after) end) as thera_class,
(case when (LENGTH(trim( thera_equiv_after )) ==0) then thera_equiv_after else trim(thera_equiv_after) end) as thera_equiv,
(case when (LENGTH(trim( form_id_no_after )) ==0) then form_id_no_after else trim(form_id_no_after) end) as form_id_no,
(case when (LENGTH(trim( rx_otc_ind_after )) ==0) then rx_otc_ind_after else trim(rx_otc_ind_after) end) as rx_otc_ind,
(case when (LENGTH(trim( third_party_after )) ==0) then third_party_after else trim(third_party_after) end) as third_party,
(case when (LENGTH(trim( maint_drug_after )) ==0) then maint_drug_after else trim(maint_drug_after) end) as maint_drug,
(case when (LENGTH(trim( disp_unit_after )) ==0) then disp_unit_after else trim(disp_unit_after) end) as disp_unit,
(case when (LENGTH(trim( ud_uu_pkg_after )) ==0) then ud_uu_pkg_after else trim(ud_uu_pkg_after) end) as ud_uu_pkg,
(case when (LENGTH(trim( route_admin_after )) ==0) then route_admin_after else trim(route_admin_after) end) as route_admin,
(case when (LENGTH(trim( form_type_after )) ==0) then form_type_after else trim(form_type_after) end) as form_type,
(case when (LENGTH(trim( dollar_rank_after )) ==0) then dollar_rank_after else trim(dollar_rank_after) end) as dollar_rank,
(case when (LENGTH(trim( rx_rank_after )) ==0) then rx_rank_after else trim(rx_rank_after) end) as rx_rank,
(case when (LENGTH(trim( sec_id_fmt_cd_after )) ==0) then sec_id_fmt_cd_after else trim(sec_id_fmt_cd_after) end) as sec_id_fmt_cd,
(case when (LENGTH(trim( sec_ndc_upc_hri_after )) ==0) then sec_ndc_upc_hri_after else trim(sec_ndc_upc_hri_after) end) as sec_ndc_upc_hri,
(case when (LENGTH(trim( gen_cd_after )) ==0) then gen_cd_after else trim(gen_cd_after) end) as gen_cd,
(case when (LENGTH(trim( brand_name_cd_after )) ==0) then brand_name_cd_after else trim(brand_name_cd_after) end) as brand_name_cd,
(case when (LENGTH(trim( int_ext_after )) ==0) then int_ext_after else trim(int_ext_after) end) as int_ext,
(case when (LENGTH(trim( single_comb_after )) ==0) then single_comb_after else trim(single_comb_after) end) as single_comb,
(case when (LENGTH(trim( stor_cond_after )) ==0) then stor_cond_after else trim(stor_cond_after) end) as stor_cond,
(case when (LENGTH(trim( lim_stabil_after )) ==0) then lim_stabil_after else trim(lim_stabil_after) end) as lim_stabil,
(case when (LENGTH(trim( a_last_change_dttm_after )) ==0) then a_last_change_dttm_after else concat(substring(a_last_change_dttm_after,1,10),' ',substring(a_last_change_dttm_after,12,8),'.000000') end) as a_last_change_dttm,
(case when (LENGTH(trim( old_fmt_cd_after )) ==0) then old_fmt_cd_after else trim(old_fmt_cd_after) end) as old_fmt_cd,
(case when (LENGTH(trim( old_ndc_upc_hri_after )) ==0) then old_ndc_upc_hri_after else trim(old_ndc_upc_hri_after) end) as old_ndc_upc_hri,
(case when (LENGTH(trim( old_fmt_no_after )) ==0) then old_fmt_no_after else trim(old_fmt_no_after) end) as old_fmt_no,
(case when (LENGTH(trim( old_dttm_after )) ==0) then old_dttm_after else concat(substring(old_dttm_after,1,10),' ',substring(old_dttm_after,12,8),'.000000') end) as old_dttm,
(case when (LENGTH(trim( new_fmt_cd_after )) ==0) then new_fmt_cd_after else trim(new_fmt_cd_after) end) as new_fmt_cd,
(case when (LENGTH(trim( new_ndc_upc_hri_after )) ==0) then new_ndc_upc_hri_after else trim(new_ndc_upc_hri_after) end) as new_ndc_upc_hri,
(case when (LENGTH(trim( new_fmt_no_after )) ==0) then new_fmt_no_after else trim(new_fmt_no_after) end) as new_fmt_no,
(case when (LENGTH(trim( new_dttm_after )) ==0) then new_dttm_after else concat(substring(new_dttm_after,1,10),' ',substring(new_dttm_after,12,8),'.000000') end) as new_dttm,
(case when (LENGTH(trim( c_last_change_dttm_after )) ==0) then c_last_change_dttm_after else concat(substring(c_last_change_dttm_after,1,10),' ',substring(c_last_change_dttm_after,12,8),'.000000') end) as c_last_change_dttm,
(case when (LENGTH(trim( prod_name_after )) ==0) then prod_name_after else trim(prod_name_after) end) as prod_name,
(case when (LENGTH(trim( prod_name_ext_after )) ==0) then prod_name_ext_after else trim(prod_name_ext_after) end) as prod_name_ext,
(case when (LENGTH(trim( dpc_after )) ==0) then dpc_after else trim(dpc_after) end) as dpc,
(case when (LENGTH(trim( ppc_after )) ==0) then ppc_after else trim(ppc_after) end) as ppc,
(case when (LENGTH(trim( apc_after )) ==0) then apc_after else trim(apc_after) end) as apc,
(case when (LENGTH(trim( ppg_cd_after )) ==0) then ppg_cd_after else trim(ppg_cd_after) end) as ppg_cd,
(case when (LENGTH(trim( hfpg_cd_after )) ==0) then hfpg_cd_after else trim(hfpg_cd_after) end) as hfpg_cd,
(case when (LENGTH(trim( e_last_change_dttm_after )) ==0) then e_last_change_dttm_after else concat(substring(e_last_change_dttm_after,1,10),' ',substring(e_last_change_dttm_after,12,8),'.000000') end) as e_last_change_dttm,
(case when (LENGTH(trim( gpi_after )) ==0) then gpi_after else trim(gpi_after) end) as gpi,
(case when (LENGTH(trim( gpi_name_after )) ==0) then gpi_name_after else trim(gpi_name_after) end) as gpi_name,
(case when (LENGTH(trim( g_last_change_dttm_after )) ==0) then g_last_change_dttm_after else concat(substring(g_last_change_dttm_after,1,10),' ',substring(g_last_change_dttm_after,12,8),'.000000') end) as g_last_change_dttm,
(case when (LENGTH(trim( manuf_name_after )) ==0) then manuf_name_after else trim(manuf_name_after) end) as manuf_name,
(case when (LENGTH(trim( manuf_name_abbr_after )) ==0) then manuf_name_abbr_after else trim(manuf_name_abbr_after) end) as manuf_name_abbr,
(case when (LENGTH(trim( prod_desc_abbr_after )) ==0) then prod_desc_abbr_after else trim(prod_desc_abbr_after) end) as prod_descr_abbr,
(case when (LENGTH(trim( drug_name_cd_after )) ==0) then drug_name_cd_after else trim(drug_name_cd_after) end) as drug_name_cd,
(case when (LENGTH(trim( gppc_after )) ==0) then gppc_after else trim(gppc_after) end) as gppc,
(case when (LENGTH(trim( j_last_change_dttm_after )) ==0) then j_last_change_dttm_after else concat(substring(j_last_change_dttm_after,1,10),' ',substring(j_last_change_dttm_after,12,8),'.000000') end) as j_last_change_dttm,
(case when (LENGTH(trim( mt_strn_after )) ==0) then mt_strn_after else trim(mt_strn_after) end) as mt_strn,
(case when (LENGTH(trim( strn_u_m_after )) ==0) then strn_u_m_after else trim(strn_u_m_after) end) as strn_u_m,
(case when (LENGTH(trim( dosage_form_after )) ==0) then dosage_form_after else trim(dosage_form_after) end) as dosage_form,
(case when (LENGTH(trim( pack_size_after )) ==0) then pack_size_after else trim(pack_size_after) end) as pack_size,
(case when (LENGTH(trim( size_u_m_after )) ==0) then size_u_m_after else trim(size_u_m_after) end) as size_u_m,
(case when (LENGTH(trim( pack_qty_after )) ==0) then pack_qty_after else trim(pack_qty_after) end) as pack_qty,
(case when (LENGTH(trim( repack_after )) ==0) then repack_after else trim(repack_after) end) as repack,
(case when (LENGTH(trim( total_package_qty_after )) ==0) then total_package_qty_after else trim(total_package_qty_after) end) as total_package_qty,
(case when (LENGTH(trim( desi_after )) ==0) then desi_after else trim(desi_after) end) as desi,
(case when (LENGTH(trim( pack_descr_after )) ==0) then pack_descr_after else trim(pack_descr_after) end) as pack_descr,
(case when (LENGTH(trim( legend_change_dttm_aftr )) ==0) then legend_change_dttm_aftr else concat(substring(legend_change_dttm_aftr,1,10),' ',substring(legend_change_dttm_aftr,12,8),'.000000') end) as legend_change_dttm,
(case when (LENGTH(trim( next_smlr_suffix_aftr )) ==0) then next_smlr_suffix_aftr else trim(next_smlr_suffix_aftr) end) as next_smlr_suffix,
(case when (LENGTH(trim( next_lrgr_suffix_aftr )) ==0) then next_lrgr_suffix_aftr else trim(next_lrgr_suffix_aftr) end) as next_lrgr_suffix,
(case when (LENGTH(trim( l_last_change_dttm_aftr )) ==0) then l_last_change_dttm_aftr else concat(substring(l_last_change_dttm_aftr,1,10),' ',substring(l_last_change_dttm_aftr,12,8),'.000000') end) as l_last_change_dttm,
(case when (LENGTH(trim( awp_cd_1_3_aftr )) ==0) then awp_cd_1_3_aftr else trim(awp_cd_1_3_aftr) end) as awp_cd_1_3,
(case when (LENGTH(trim( awp_pack_price_aftr )) ==0) then awp_pack_price_aftr else trim(awp_pack_price_aftr) end) as awp_pack_price,
(case when (LENGTH(trim( awp_unit_price_aftr )) ==0) then awp_unit_price_aftr else trim(awp_unit_price_aftr) end) as awp_unit_price,
(case when (LENGTH(trim( awp_dttm_aftr )) ==0) then awp_dttm_aftr else concat(substring(awp_dttm_aftr,1,10),' ',substring(awp_dttm_aftr,12,8),'.000000') end) as awp_dttm,
(case when (LENGTH(trim( wholesale_unit_price_aftr )) ==0) then wholesale_unit_price_aftr else trim(wholesale_unit_price_aftr) end) as wholesale_unit_price,
(case when (LENGTH(trim( whac_dttm_aftr )) ==0) then whac_dttm_aftr else concat(substring(whac_dttm_aftr,1,10),' ',substring(whac_dttm_aftr,12,8),'.000000') end) as whac_dttm,
(case when (LENGTH(trim( whac_pack_price_aftr )) ==0) then whac_pack_price_aftr else trim(whac_pack_price_aftr) end) as whac_pack_price,
(case when (LENGTH(trim( r1_last_change_dttm_aftr )) ==0) then r1_last_change_dttm_aftr else concat(substring(r1_last_change_dttm_aftr,1,10),' ',substring(r1_last_change_dttm_aftr,12,8),'.000000') end) as r1_last_change_dttm,
(case when (LENGTH(trim( awp_cd_4_6_aftr )) ==0) then awp_cd_4_6_aftr else trim(awp_cd_4_6_aftr) end) as awp_cd_4_6,
(case when (LENGTH(trim( awp_reported_ind_aftr )) ==0) then awp_reported_ind_aftr else trim(awp_reported_ind_aftr) end) as awp_reported_ind,
(case when (LENGTH(trim( r11_last_change_dttm_aftr )) ==0) then r11_last_change_dttm_aftr else concat(substring(r11_last_change_dttm_aftr,1,10),' ',substring(r11_last_change_dttm_aftr,12,8),'.000000') end) as r11_last_change_dttm,
(case when (LENGTH(trim( dp_pack_price_aftr )) ==0) then dp_pack_price_aftr else trim(dp_pack_price_aftr) end) as dp_pack_price,
(case when (LENGTH(trim( dp_unit_price_aftr )) ==0) then dp_unit_price_aftr else trim(dp_unit_price_aftr) end) as dp_unit_price,
(case when (LENGTH(trim( dp_dttm_aftr )) ==0) then dp_dttm_aftr else concat(substring(dp_dttm_aftr,1,10),' ',substring(dp_dttm_aftr,12,8),'.000000') end) as dp_dttm,
(case when (LENGTH(trim( s1_last_change_dttm_aftr )) ==0) then s1_last_change_dttm_aftr else concat(substring(s1_last_change_dttm_aftr,1,10),' ',substring(s1_last_change_dttm_aftr,12,8),'.000000') end) as s1_last_change_dttm,
(case when (LENGTH(trim( s11_last_change_dttm_after )) ==0) then s11_last_change_dttm_after else concat(substring(s11_last_change_dttm_after,1,10),' ',substring(s11_last_change_dttm_after,12,8),'.000000') end) as s11_last_change_dttm,
(case when (LENGTH(trim( hcfa_ffp_limit_aftr )) ==0) then hcfa_ffp_limit_aftr else trim(hcfa_ffp_limit_aftr) end) as hcfa_ffp_limit,
(case when (LENGTH(trim( hcfa_ffp_dttm_after )) ==0) then hcfa_ffp_dttm_after else concat(substring(hcfa_ffp_dttm_after,1,10),' ',substring(hcfa_ffp_dttm_after,12,8),'.000000') end) as hcfa_ffp_dttm,
(case when (LENGTH(trim( t_last_change_dttm_after )) ==0) then t_last_change_dttm_after else concat(substring(t_last_change_dttm_after,1,10),' ',substring(t_last_change_dttm_after,12,8),'.000000') end) as t_last_change_dttm,
(case when (LENGTH(trim( mddb_dur_kdc_nbr_after )) ==0) then mddb_dur_kdc_nbr_after else trim(mddb_dur_kdc_nbr_after) end) as mddb_dur_kdc_nbr,
(case when (LENGTH(trim( hzrds_lvl_cd_after )) ==0) then hzrds_lvl_cd_after else trim(hzrds_lvl_cd_after) end) as hzrds_lvl_cd,
(case when (LENGTH(trim( auth_generic_cd_after )) ==0) then auth_generic_cd_after else trim( auth_generic_cd_after ) end ) as auth_generic_cd, 
(case when (LENGTH(trim( fda_ind_after )) ==0) then fda_ind_after else trim( fda_ind_after ) end ) as fda_ind, 
(case when (LENGTH(trim( fda_ind_value_after )) ==0) then fda_ind_value_after else trim( fda_ind_value_after ) end ) as fda_ind_value, 
(case when (LENGTH(trim( auth_ndc_upc_hri_after )) ==0) then auth_ndc_upc_hri_after else trim( auth_ndc_upc_hri_after ) end ) as auth_ndc_upc_hri, 
(case when (LENGTH(trim( ddid_after )) ==0) then ddid_after else trim( ddid_after ) end ) as ddid, 
(case when (LENGTH(trim( rxcui_type_after )) ==0) then rxcui_type_after else trim( rxcui_type_after ) end ) as rxcui_type, 
(case when (LENGTH(trim( rxcui_after )) ==0) then rxcui_after else trim( rxcui_after ) end ) as rxcui,
'000000' as tracking_id
from gg_tbf0_mddb_drug where cdc_operation_type_cd_before ='INSERT'"""

# COMMAND ----------



# COMMAND ----------

df1 = spark.sql(sql1)

display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)

dfFinal.createOrReplaceTempView("gg_tbf0_mddb_drug_final")

# drop columns
df_final = dfFinal.drop("tracking_id")

# triming spaces in all columns 
df_final = df_final.select([trim(col(c)).alias(c) for c in df_final.columns])

# convert date and number columns
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
           .withColumn("a_last_change_dttm",to_timestamp(df_final["a_last_change_dttm"]))\
           .withColumn("old_dttm",to_timestamp(df_final["old_dttm"]))\
           .withColumn("new_dttm",to_timestamp(df_final["new_dttm"]))\
           .withColumn("c_last_change_dttm",to_timestamp(df_final["c_last_change_dttm"]))\
           .withColumn("g_last_change_dttm",to_timestamp(df_final["g_last_change_dttm"]))\
           .withColumn("e_last_change_dttm",to_timestamp(df_final["e_last_change_dttm"]))\
           .withColumn("j_last_change_dttm",to_timestamp(df_final["j_last_change_dttm"]))\
           .withColumn("legend_change_dttm",to_timestamp(df_final["legend_change_dttm"]))\
           .withColumn("l_last_change_dttm",to_timestamp(df_final["l_last_change_dttm"]))\
           .withColumn("awp_dttm",to_timestamp(df_final["awp_dttm"]))\
           .withColumn("r1_last_change_dttm",to_timestamp(df_final["r1_last_change_dttm"]))\
           .withColumn("r11_last_change_dttm",to_timestamp(df_final["r11_last_change_dttm"]))\
           .withColumn("dp_dttm",to_timestamp(df_final["dp_dttm"]))\
           .withColumn("s1_last_change_dttm",to_timestamp(df_final["s1_last_change_dttm"]))\
           .withColumn("s11_last_change_dttm",to_timestamp(df_final["s11_last_change_dttm"]))\
           .withColumn("hcfa_ffp_dttm",to_timestamp(df_final["hcfa_ffp_dttm"]))\
           .withColumn("t_last_change_dttm",to_timestamp(df_final["t_last_change_dttm"]))\
           .withColumn("whac_dttm",to_timestamp(df_final["whac_dttm"]))\
           .withColumn("gen_id_no",when(col("gen_id_no") == "",None).otherwise(col("gen_id_no")))\
           .withColumn("pack_size",when(col("pack_size") == "",None).otherwise(col("pack_size")))\
           .withColumn("thera_class",when(col("thera_class") == "",None).otherwise(col("thera_class")))\
           .withColumn("labeler_cd",when(col("labeler_cd") == "",None).otherwise(col("labeler_cd")))\
           .withColumn("pack_qty",when(col("pack_qty") == "",None).otherwise(col("pack_qty")))\
           .withColumn("ppc",when(col("ppc") == "",None).otherwise(col("ppc")))\
           .withColumn("apc",when(col("apc") == "",None).otherwise(col("apc")))\
           .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr")))\
           .withColumn("dpc",when(col("dpc") == "",None).otherwise(col("dpc")))\
           .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr")))\
           .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id")))\
           .withColumn("mt_strn",when(col("mt_strn") == "",None).otherwise(col("mt_strn")))\
           .withColumn("wholesale_unit_price",when(col("wholesale_unit_price") == "",None).otherwise(col("wholesale_unit_price")))\
           .withColumn("dp_unit_price",when(col("dp_unit_price") == "",None).otherwise(col("dp_unit_price")))\
           .withColumn("total_package_qty",when(col("total_package_qty") == "",None).otherwise(col("total_package_qty")))\
           .withColumn("awp_unit_price",when(col("awp_unit_price") == "",None).otherwise(col("awp_unit_price")))\
           .withColumn("hcfa_ffp_limit",when(col("hcfa_ffp_limit") == "",None).otherwise(col("hcfa_ffp_limit")))\
           .withColumn("awp_pack_price",when(col("awp_pack_price") == "",None).otherwise(col("awp_pack_price")))\
           .withColumn("whac_pack_price",when(col("whac_pack_price") == "",None).otherwise(col("whac_pack_price")))\
           .withColumn("dp_pack_price",when(col("dp_pack_price") == "",None).otherwise(col("dp_pack_price")))\
           .withColumn("id_form_cd",when(col("id_form_cd") == "",None).otherwise(col("id_form_cd")))\
           .withColumn("dollar_rank",when(col("dollar_rank") == "",None).otherwise(col("dollar_rank")))\
           .withColumn("rx_rank",when(col("rx_rank") == "",None).otherwise(col("rx_rank")))\
           .withColumn("old_fmt_cd",when(col("old_fmt_cd") == "",None).otherwise(col("old_fmt_cd")))\
           .withColumn("new_fmt_cd",when(col("new_fmt_cd") == "",None).otherwise(col("new_fmt_cd")))

			
#Update Varchar columns to null
from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",sel_snfl_tbl)\
   .load()

# display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
#print(str_cols)


for col in str_cols:
  df_final = df_final.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))


#final df to load
display(df_final)
print(f"Final count after union {df_final.count()}")





# COMMAND ----------

#Bad records 
dfBad = spark.sql("select * from gg_tbf0_mddb_drug where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")
display(dfBad)
print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

# WRITING DATA IN OUTPUT AND RJECT FOLDER
df_final.write.mode('overwrite').parquet(OUT_FILEPATH)

dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)



# COMMAND ----------

# delete records from snfk table
delete_gg_snowflake = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})



# COMMAND ----------

#Writing to the Snowflakes Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
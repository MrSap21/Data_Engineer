# Databricks notebook source
# Create the notebook parameters

# dbutils.widgets.text("SNOWFLAKE_WAREHOUSE", "")
# dbutils.widgets.text("SNOWFLAKE_DATABASE", "")
# dbutils.widgets.text("SNOWFLAKE_TABLE_NAME", "")
# dbutils.widgets.text("transaction", "")
# dbutils.widgets.text("SNOWFLAKE_SCHEMA", "")

# COMMAND ----------

query1 = "DROP TABLE " + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get("SNOWFLAKE_SCHEMA") + "." + dbutils.widgets.get("SNOWFLAKE_TABLE_NAME")

# COMMAND ----------

query2 = "CREATE TABLE " + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get('SNOWFLAKE_SCHEMA') + "." + dbutils.widgets.get('SNOWFLAKE_TABLE_NAME') + "( \
Mail_Group varchar(20), \
Successfull_Y_N Char (1), \
Reason_Code_For_Unsuccessful Char (1), \
Patient_Last_Name varchar(20), \
Patient_First_Name varchar(20), \
DOB date, \
Patient_Phone varchar(100), \
Patient_Address varchar(60), \
Patient_City varchar(30), \
Patient_State Char(2), \
Patient_Zip Char(5), \
Doctor_Name varchar(40), \
Doctor_Phone varchar(10), \
Doctor_Fax varchar(10), \
Doctor_Address varchar(40), \
Prescription_Number integer, \
Delete_Ind Char (1), \
RX_Create_Date date, \
Last_Adjud_DTTM timestamp(0), \
Fill_Enter_Dt Date, \
NDC11 char (11), \
Drug_Name varchar(40), \
Store_Number integer, \
Store_Number_Phone varchar(100), \
Store_State char(2), \
Store_Tax_ID varchar(5), \
Insurance_Name varchar(60), \
Plan_ID_Phone_Number varchar(10), \
Primary_Reject_Message varchar(80), \
Processor_Additional_Messages char(1), \
Secondary_Reject_Message char(1), \
DR_Ind char (1), \
pat_id decimal(13), \
drug_id integer, \
fill_stat_cd char(2), \
PRIMARY KEY ( Patient_Last_Name,Patient_First_Name, DOB,NDC11 ))"

# COMMAND ----------

query3 =  """
INSERT INTO """ + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get("SNOWFLAKE_SCHEMA") + "." + dbutils.widgets.get("SNOWFLAKE_TABLE_NAME") + """ WITH fillrejprim AS (

  select rx_nbr, str_nbr, rx_fill_nbr, reject_nbr, dl_reject_cd, third_party_plan_id, fill_enter_dt, cob_ind ,fill_sold_dt, rx_create_dt
from DNADEVEDWDB01.prescription_fill_plan_reject 
where (rx_nbr, str_nbr, rx_fill_nbr, fill_enter_dt, reject_nbr) in 
		(select rx_nbr, str_nbr, max(rx_fill_nbr), max(fill_enter_dt),max(reject_nbr) 
		from DNADEVEDWDB01.prescription_fill_plan_reject
		where fill_sold_dt is null and fill_enter_dt = (current_date() - 1)                 
		group by 1,2) 
 AND cob_ind = 'N' and fill_sold_dt is null and  fill_enter_dt = (current_date() - 1)
  
),
fill AS (
select rx_nbr, str_nbr, max(rx_fill_nbr) as rx_fill_nbr, fill_enter_dt, rx_create_dt, fill_stat_cd, fill_sold_dt, dspn_fill_nbr,pat_id,pbr_id,drug_id, pbr_loc_id,fill_vrfy_dt
 from DNADEVEDWDB01.prescription_fill
  GROUP BY 1,2,4,5,6,7,8,9,10, 11, 12, 13
  )
 
 select
srxndc.SRx_Group as Mail_Group,
Null as Successfull_Y_N,
Null as Reason_Code_For_Unsuccessful,
pat.last_name as Patient_Last_Name,
pat.first_name as Patient_First_Name,
pat.brth_dt as DOB,
patcomm.comm_channel_val as Patient_Phone,
pa.addr_line as Patient_Address,
pa.city as Patient_City,
pa.state_cd as Patient_State,
pa.zip_cd_5 as Patient_Zip,
pbr.first_name || ' ' || pbr.last_name as Doctor_Name,
pbrloc.phone_area_cd || pbrloc.phone_nbr as Doctor_Phone,
pbrloc.fax_area_cd || pbrloc.fax_nbr as Doctor_Fax,
pbrloc.addr_line_1 as Doctor_Address,
fill.rx_nbr as Prescription_Number,
case when fill.fill_stat_cd = 'DL' then 'Y' else 'N' end as Delete_Ind,
fill.rx_create_dt as RX_Create_Date,
CAST ( pfp.fill_adjud_dt AS CHAR(10 )) || ' ' || CAST ( pfp.fill_adjud_tm AS CHAR(08 )) AS Last_Adjud_DTTM ,
fill.fill_enter_dt as Fill_Enter_Dt,
d.ndc_mfgr_nbr || d.ndc_prod_nbr || d.ndc_pkg_cd  as NDC11,
d.prod_name_abbr as Drug_Name,
fill.str_nbr as Store_Number,
strcomm.comm_channel_val as Store_Number_Phone,
lsa.state_cd as Store_State,
ls.str_tax_id as Store_Tax_ID,
tp.plan_name as Insurance_Name,
(tp.phone_area_cd || tp.phone_nbr) as Plan_ID_Phone_Number,
primrejcd.primary_decode as Primary_Reject_Message,
Null as Processor_Additional_Messages,
Null as Secondary_Reject_Message,
case when ls.str_name like '%Duane Reade%' then 'Y' else 'N' end as DR_Ind,
fill.pat_id as pat_id,
fill.drug_id as drug_id,
fill.fill_stat_cd
 
from fill
RIGHT JOIN FILLREJPRIM
LEFT join DNADEVEDWDB01.prescription_fill_plan pfp
left join DNADEVEDWDB01.patient pat
left join DNADEVEDWDB01.patient_communication_channel patcomm
left join DNADEVEDWDB01.patient_address pa
left join DNADEVEDWDB01.prescriber pbr
join DNADEVEDWDB01.prescriber_specialty pbs
left join DNADEVEDWDB01.prescriber_location pbrloc
join DNADEVEDWDB01.drug d
join DNADEVETL01.SRx_NDC_NEW srxndc
join DNADEVETL01.NDC11_2803 ndc
left join DNADEVEDWDB01.location_store_comm_channel strcomm
left join DNADEVEDWDB01.third_party_plan tp
join DNADEVEDWDB01.location_store_address lsa
left join DNADEVEDWDB01.code_detail primrejcd
join DNADEVEDWDB01.location_store ls
 where fill.fill_enter_dt between (current_date() -8) and (current_date() -1) and fill.fill_stat_cd <> 'SD'
AND fill.rx_nbr = fillrejprim.rx_nbr and fill.str_nbr = fillrejprim.str_nbr and fill.rx_fill_nbr = fillrejprim.rx_fill_nbr
and fill.fill_enter_dt = fillrejprim.fill_enter_dt 
and coalesce(fill.fill_sold_dt, '1900-01-01') = coalesce(fillrejprim.fill_sold_dt, '1900-01-01')
and fill.fill_enter_dt = (current_date() - 1) 
and fill.fill_sold_dt is null  and  fill.fill_vrfy_dt is null 
and pfp.rx_nbr = fill.rx_nbr and pfp.str_nbr = fill.str_nbr and pfp.rx_fill_nbr = fill.rx_fill_nbr 
and pfp.fill_enter_dt = fill.fill_enter_dt and pfp.fill_sold_dt is null and pfp.cob_ind = 'N' 
and pfp.fill_enter_dt = (current_date() - 1)
and fill.pat_id = pat.pat_id
and pat.pat_id = patcomm.pat_id and patcomm.channel_type_cd = 'PRIM' and patcomm.history_seq_cd = 'C'
and	pat.pat_id = pa.pat_id and pa.addr_type_cd = 'PRI' and pa.history_seq_cd = 'C'
and (pbr.pbr_id = fill.pbr_id and pbr.pbr_loc_id = fill.pbr_loc_id and pbr.history_seq_cd = 'C' )
and pbs.pbr_id =pbr.pbr_id and pbr.pbr_loc_id=pbs.pbr_loc_id and pbs.history_seq_cd='C' and pbs.spclty_cd not in ('RHE', 'RHU')
and pbr.pbr_id = pbrloc.pbr_id and pbr.pbr_loc_id = pbrloc.pbr_loc_id and pbrloc.history_seq_cd = 'C'
and d.drug_id = fill.drug_id and d.history_seq_cd = 'C'
and ndc.ndc11 = srxndc.ndc11 and srxndc.srx_group in ('HUMIRA')
and strcomm.str_nbr = fill.str_nbr and strcomm.channel_type_cd = 'Str Ph  ' and strcomm.src_end_dt is null
and pfp.third_party_plan_id = tp.third_party_plan_id and tp.history_seq_cd = 'C'
and lsa.str_nbr = fill.str_nbr and lsa.src_end_dt is null and lsa.addr_type_cd = 'STR'
and primrejcd.decode_cd = fillrejprim.dl_reject_cd and primrejcd.catg_cd = 38
and primrejcd.history_seq_cd = 'C'
and ls.str_nbr = fill.str_nbr
and fill.pat_id not in ( select pfill.pat_id  from DNADEVEDWDB01.prescription_fill pfill,
(Select pf.rx_nbr, pf.str_nbr,max(pf.rx_fill_nbr) as rx_fill_nbr from DNADEVEDWDB01.prescription_fill pf 
where pf.fill_sold_dt between (current_date() - 373) and (current_date() - 1) and pf.drug_id  in 
(Select d.drug_id from DNADEVEDWDB01.drug d, DNADEVETL01.SRx_NDC_NEW s, DNADEVETL01.NDC11_2803 ndc  where  Srx_Group = 'HUMIRA' and s.ndc11 = ndc.ndc11) group by 1,2) s 
 where pfill.fill_sold_dt between (current_date - 373) and (current_date - 1) and s.rx_nbr=pfill.rx_nbr and s.str_nbr = pfill.str_nbr and s.rx_fill_nbr = pfill.rx_fill_nbr)
group by 1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35"""

# COMMAND ----------

dbutils.notebook.run("../Utilities/RunSnowSQL", 120, { "query" : query1, "query": query2, "query": query3, "SNOWFLAKE_DATABASE" : dbutils.widgets.get("SNOWFLAKE_DATABASE"), "SNOWFLAKE_WAREHOUSE" : dbutils.widgets.get("SNOWFLAKE_WAREHOUSE"),"transaction" : dbutils.widgets.get("transaction")})

# COMMAND ----------

# OLD_query3 = "insert into " + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get('SNOWFLAKE_SCHEMA') + "." + dbutils.widgets.get('SNOWFLAKE_TABLE_NAME') + \
# " WITH fillrejprim AS ( select rx_nbr, str_nbr, rx_fill_nbr, \
# reject_nbr, dl_reject_cd, third_party_plan_id, fill_enter_dt, cob_ind ,fill_sold_dt, rx_create_dt \
# from DNADEVEDWDB01.prescription_fill_plan_reject \
# where (rx_nbr, str_nbr, rx_fill_nbr, fill_enter_dt, reject_nbr) in \
# 		(select rx_nbr, str_nbr, max(rx_fill_nbr), max(fill_enter_dt),max(reject_nbr) \
# 		from DNADEVEDWDB01.prescription_fill_plan_reject \
# 		where fill_sold_dt is null and fill_enter_dt = (current_date() - 1) group by 1,2) \
#  AND cob_ind = 'N' and fill_sold_dt is null and  fill_enter_dt = (current_date() - 1) ), \
# fill AS ( \
# select rx_nbr, str_nbr, max(rx_fill_nbr) as rx_fill_nbr, fill_enter_dt, rx_create_dt, fill_stat_cd, fill_sold_dt, dspn_fill_nbr,pat_id,pbr_id,drug_id, pbr_loc_id,fill_vrfy_dt \
#  from DNADEVEDWDB01.prescription_fill \
#   GROUP BY 1,2,4,5,6,7,8,9,10, 11, 12, 13) \
#  select srxndc.SRx_Group as Mail_Group, \
# Null as Successfull_Y_N, \
# Null as Reason_Code_For_Unsuccessful, \
# pat.last_name as Patient_Last_Name, \
# pat.first_name as Patient_First_Name, \
# pat.brth_dt as DOB, \
# patcomm.comm_channel_val as Patient_Phone, \
# pa.addr_line as Patient_Address, \
# pa.city as Patient_City, \
# pa.state_cd as Patient_State, \
# pa.zip_cd_5 as Patient_Zip, \
# pbr.first_name || ' ' || pbr.last_name as Doctor_Name, \
# pbrloc.phone_area_cd || pbrloc.phone_nbr as Doctor_Phone, \
# pbrloc.fax_area_cd || pbrloc.fax_nbr as Doctor_Fax, \
# pbrloc.addr_line_1 as Doctor_Address, \
# fill.rx_nbr as Prescription_Number, \
# case when fill.fill_stat_cd = 'DL' then 'Y' else 'N' end as Delete_Ind, \
# fill.rx_create_dt as RX_Create_Date, \
# CAST ( pfp.fill_adjud_dt AS CHAR(10 )) || ' ' || CAST ( pfp.fill_adjud_tm AS CHAR(08 )) AS Last_Adjud_DTTM , \
# fill.fill_enter_dt as Fill_Enter_Dt, \
# d.ndc_mfgr_nbr || d.ndc_prod_nbr || d.ndc_pkg_cd  as NDC11, \
# d.prod_name_abbr as Drug_Name, \
# fill.str_nbr as Store_Number, \
# strcomm.comm_channel_val as Store_Number_Phone, \
# lsa.state_cd as Store_State, \
# ls.str_tax_id as Store_Tax_ID, \
# tp.plan_name as Insurance_Name, \
# (tp.phone_area_cd || tp.phone_nbr) as Plan_ID_Phone_Number, \
# primrejcd.primary_decode as Primary_Reject_Message, \
# Null as Processor_Additional_Messages, \
# Null as Secondary_Reject_Message, \
# case when ls.str_name like '%Duane Reade%' then 'Y' else 'N' end as DR_Ind, \
# fill.pat_id as pat_id, \
# fill.drug_id as drug_id, \
# fill.fill_stat_cd \
# from fill \
# RIGHT JOIN FILLREJPRIM \
# LEFT join DNADEVEDWDB01.prescription_fill_plan pfp \
# left join DNADEVEDWDB01.patient pat \
# left join DNADEVEDWDB01.patient_communication_channel patcomm \
# left join DNADEVEDWDB01.patient_address pa \
# left join DNADEVEDWDB01.prescriber pbr \
# join DNADEVEDWDB01.prescriber_specialty pbs \
# left join DNADEVEDWDB01.prescriber_location pbrloc \
# join DNADEVEDWDB01.drug d \
# join DNADEVETL01.SRx_NDC_NEW srxndc \
# join DNADEVETL01.NDC11_2803 ndc \
# left join DNADEVEDWDB01.location_store_comm_channel strcomm \
# left join DNADEVEDWDB01.third_party_plan tp \
# join DNADEVEDWDB01.location_store_address lsa \
# left join DNADEVEDWDB01.code_detail primrejcd \
# join DNADEVEDWDB01.location_store ls \
#  where fill.fill_enter_dt between (current_date() -8) and (current_date() -1) and fill.fill_stat_cd <> 'SD' \
# AND fill.rx_nbr = fillrejprim.rx_nbr and fill.str_nbr = fillrejprim.str_nbr and fill.rx_fill_nbr = fillrejprim.rx_fill_nbr \
# and fill.fill_enter_dt = fillrejprim.fill_enter_dt \
# and coalesce(fill.fill_sold_dt, '1900-01-01') = coalesce(fillrejprim.fill_sold_dt, '1900-01-01') \
# and fill.fill_enter_dt = (current_date() - 1) \
# and fill.fill_sold_dt is null  and  fill.fill_vrfy_dt is null \
# and pfp.rx_nbr = fill.rx_nbr and pfp.str_nbr = fill.str_nbr and pfp.rx_fill_nbr = fill.rx_fill_nbr \
# and pfp.fill_enter_dt = fill.fill_enter_dt and pfp.fill_sold_dt is null and pfp.cob_ind = 'N' \
# and pfp.fill_enter_dt = (current_date() - 1) \
# and fill.pat_id = pat.pat_id \
# and pat.pat_id = patcomm.pat_id and patcomm.channel_type_cd = 'PRIM' and patcomm.history_seq_cd = 'C' \
# and	pat.pat_id = pa.pat_id and pa.addr_type_cd = 'PRI' and pa.history_seq_cd = 'C' \
# and (pbr.pbr_id = fill.pbr_id and pbr.pbr_loc_id = fill.pbr_loc_id and pbr.history_seq_cd = 'C' ) \
# and pbs.pbr_id =pbr.pbr_id and pbr.pbr_loc_id=pbs.pbr_loc_id and pbs.history_seq_cd='C' and pbs.spclty_cd not in ('RHE', 'RHU') \
# and pbr.pbr_id = pbrloc.pbr_id and pbr.pbr_loc_id = pbrloc.pbr_loc_id and pbrloc.history_seq_cd = 'C' \
# and d.drug_id = fill.drug_id and d.history_seq_cd = 'C' \
# and ndc.ndc11 = srxndc.ndc11 and srxndc.srx_group in ('HUMIRA') \
# and strcomm.str_nbr = fill.str_nbr and strcomm.channel_type_cd = 'Str Ph  ' and strcomm.src_end_dt is null \
# and pfp.third_party_plan_id = tp.third_party_plan_id and tp.history_seq_cd = 'C' \
# and lsa.str_nbr = fill.str_nbr and lsa.src_end_dt is null and lsa.addr_type_cd = 'STR' \
# and primrejcd.decode_cd = fillrejprim.dl_reject_cd and primrejcd.catg_cd = 38 \
# and primrejcd.history_seq_cd = 'C' \
# and ls.str_nbr = fill.str_nbr \
# and fill.pat_id not in ( select pfill.pat_id  from DNADEVEDWDB01.prescription_fill pfill, \
# (Select pf.rx_nbr, pf.str_nbr,max(pf.rx_fill_nbr) as rx_fill_nbr from DNADEVEDWDB01.prescription_fill pf \
# where pf.fill_sold_dt between (current_date() - 373) and (current_date() - 1) and pf.drug_id  in \
# (Select d.drug_id from DNADEVEDWDB01.drug d, DNADEVETL01.SRx_NDC_NEW s, DNADEVETL01.NDC11_2803 ndc  where  Srx_Group = 'HUMIRA' and s.ndc11 = ndc.ndc11) group by 1,2) s \
#  where pfill.fill_sold_dt between (current_date - 373) and (current_date - 1) and s.rx_nbr=pfill.rx_nbr and s.str_nbr = pfill.str_nbr and s.rx_fill_nbr = pfill.rx_fill_nbr) \
# group by 1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35"

# COMMAND ----------

# dbutils.notebook.run("../Utilities/RunSnowSQL", 120, { "query" : query1, "query": query2, "query": query3, "SNOWFLAKE_DATABASE" : dbutils.widgets.get("SNOWFLAKE_DATABASE"), "SNOWFLAKE_WAREHOUSE" : dbutils.widgets.get("SNOWFLAKE_WAREHOUSE"),"transaction" : dbutils.widgets.get("transaction")})

# COMMAND ----------

# #ALTERNATIVE WAY TO RUN THE COMMANDS DIRECTLY IN THIS NOTEBOOK AND NOT USE THE DBUTILS.NOTEBOOK.RUN CELL ABOVE 

# # import the snowflake.connector package
# import snowflake.connector
# import os
# import re
# from cryptography.hazmat.backends import default_backend
# from cryptography.hazmat.primitives.asymmetric import rsa
# from cryptography.hazmat.primitives.asymmetric import dsa
# from cryptography.hazmat.primitives import serialization

# password=dbutils.secrets.get(scope = "dapadbscope", key = "dapdevdbrauthn")

# val1 = bytearray(re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",password).replace("\\n","\n").encode())

# p_key = serialization.load_pem_private_key(
#     val1,
#     password = 'devsnowcli'.encode(),   
#     backend = default_backend()
#     )

# pkb = p_key.private_bytes(
#   encoding = serialization.Encoding.DER,
#   format = serialization.PrivateFormat.PKCS8,
#   encryption_algorithm = serialization.NoEncryption()
#   )

# v_autocommit = False 

# if dbutils.widgets.get("transaction").lower() == "false":
#   print("Auto Commit True")
#   v_autocommit = True

# with snowflake.connector.connect(
#   user="DEVSNOWCLI_USER",
#   account="wba_rpu_nprod_datainsight_01.east-us-2.privatelink",
#   private_key=pkb,
#   warehouse= dbutils.widgets.get("SNOWFLAKE_WAREHOUSE"),
#   database=dbutils.widgets.get("SNOWFLAKE_DATABASE"),
#   autocommit=v_autocommit
#   ) as con:
#   con.execute_string(query1)
#   con.execute_string(query2)
#   con.execute_string(query3)
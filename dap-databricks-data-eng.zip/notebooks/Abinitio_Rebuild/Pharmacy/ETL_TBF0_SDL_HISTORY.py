# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220111183013")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_rx")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_STG")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","master_data/location/output")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","master_data/location/reject")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_RX,GG_TBF0_RX_control")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL",'https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate')
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_PIPELINE_NAME","employee_xform_pharmacy_staff")
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
# dbutils.widgets.text("PAR_UnprocessedFiles","1")  
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS") 
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","GG_TBF0_RX_CMPND_INGRDNT") 
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG") 


# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPINative", 600,  
                  {"PAR_READAPI_KEY":"feedNames",
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_READAPI_VALUE":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A"});


print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")


readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'src_partition_nbr',
'src_partition_nbr_after',
'sdl_msg_id',
'sdl_msg_id_after',
'pat_id',
'pat_id_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_qty_dispensed',
'fill_qty_dispensed_after',
'fill_days_supply',
'fill_days_supply_after',
'fill_enter_dttm',
'fill_enter_dttm_after',
'fill_nbr_dispensed',
'fill_nbr_dispensed_after',
'drug_name',
'drug_name_after',
'drug_ndc_nbr',
'drug_ndc_nbr_after',
'rx_written_dttm',
'rx_written_dttm_after',
'general_pbr_nbr',
'general_pbr_nbr_after',
'submitted_user_id',
'submitted_user_id_after',
'submitted_dttm',
'submitted_dttm_after',
'plan_id',
'plan_id_after',
'plan_group_nbr',
'plan_group_nbr_after',
'general_recipient_nbr',
'general_recipient_nbr_after',
'prior_auth_cd',
'prior_auth_cd_after',
'prior_auth_nbr',
'prior_auth_nbr_after',
'rx_denial_override_cd',
'rx_denial_override_cd_after',
'eligibility_override_cd',
'eligibility_override_cd_after',
'diagnosis_cd',
'diagnosis_cd_after',
'pay_cd',
'pay_cd_after',
'dl_reject_cd_01',
'dl_reject_cd_01_after',
'dl_reject_reason_01',
'dl_reject_reason_01_after',
'dl_reject_cd_02',
'dl_reject_cd_02_after',
'dl_reject_reason_02',
'dl_reject_reason_02_after',
'dl_reject_cd_03',
'dl_reject_cd_03_after',
'dl_reject_reason_03',
'dl_reject_reason_03_after',
'dl_reject_cd_04',
'dl_reject_cd_04_after',
'dl_reject_reason_04',
'dl_reject_reason_04_after',
'dl_reject_cd_05',
'dl_reject_cd_05_after',
'dl_reject_reason_05',
'dl_reject_reason_05_after',
'dl_proc_msg',
'dl_proc_msg_after',
'dl_additional_msg',
'dl_additional_msg_after',
'dur_conflict_cd',
'dur_conflict_cd_after',
'dur_intervention_cd',
'dur_intervention_cd_after',
'dur_outcome_cd',
'dur_outcome_cd_after',
'other_payer_reject_cd',
'other_payer_reject_cd_after',
'other_coverage_cd',
'other_coverage_cd_after',
'other_payer_cvrg_type',
'other_payer_cvrg_type_after',
'plan_other_amt_paid_type',
'plan_other_amt_paid_type_after',
'plan_other_amt_paid',
'plan_other_amt_paid_after',
'other_payer_id',
'other_payer_id_after',
'other_payer_id_qualifier',
'other_payer_id_qualifier_after',
'first_provider_paid_amt',
'first_provider_paid_amt_after',
'plan_total_paid_amt',
'plan_total_paid_amt_after',
'plan_returnd_cost_amt',
'plan_returnd_cost_amt_after',
'plan_returnd_fee_amt',
'plan_returnd_fee_amt_after',
'plan_incentive_paid_amt',
'plan_incentive_paid_amt_after',
'fill_retail_price_amt',
'fill_retail_price_amt_after',
'pat_rem_ded_amt',
'pat_rem_ded_amt_after',
'pat_rem_ben_amt',
'pat_rem_ben_amt_after',
'pat_acc_ded_amt',
'pat_acc_ded_amt_after',
'pat_ded_applied_amt',
'pat_ded_applied_amt_after',
'fill_del_adjudication_cd',
'fill_del_adjudication_cd_after',
'fill_adjudication_cd',
'fill_adjudication_cd_after',
'claim_reference_nbr',
'claim_reference_nbr_after',
'plan_returnd_copay_amt',
'plan_returnd_copay_amt_after',
'plan_returnd_tax_amt',
'plan_returnd_tax_amt_after',
'fill_sold_amt',
'fill_sold_amt_after',
'sales_adj_cd',
'sales_adj_cd_after',
'rx_daw_ind',
'rx_daw_ind_after',
'claim_reversal_ind',
'claim_reversal_ind_after',
'place_of_service',
'place_of_service_after',
'rx_denial_override_cd_2',
'rx_denial_override_cd_2_after',
'rx_denial_override_cd_3',
'rx_denial_override_cd_3_after',
'delay_reason_cd',
'delay_reason_cd_after',
'plan_returnd_grp_nbr',
'plan_returnd_grp_nbr_after',
'plan_id_returnd',
'plan_id_returnd_after',
'ntwk_reimb_id_returnd',
'ntwk_reimb_id_returnd_after',
'proc_fee_amt',
'proc_fee_amt_after',
'prvd_ntwk_amt',
'prvd_ntwk_amt_after',
'prd_brnd_drug_amt',
'prd_brnd_drug_amt_after',
'npref_prd_form_amt',
'npref_prd_form_amt_after',
'cov_gap_amt',
'cov_gap_amt_after',
'plan_fund_assist_amt',
'plan_fund_assist_amt_after',
'ingrd_cost_contract_amt',
'ingrd_cost_contract_amt_after',
'disp_fee_contract_amt',
'disp_fee_contract_amt_after',
'plan_sales_tax_amt',
'plan_sales_tax_amt_after',
'pat_sales_tax_amt',
'pat_sales_tax_amt_after',
'other_payer_recognzd_amt',
'other_payer_recognzd_amt_after',
'ben_stg_ded_amt',
'ben_stg_ded_amt_after',
'ben_stg_init_cov_amt',
'ben_stg_init_cov_amt_after',
'ben_stg_cov_gap_amt',
'ben_stg_cov_gap_amt_after',
'ben_stg_cat_amt',
'ben_stg_cat_amt_after',
'plan_returnd_coins_amt',
'plan_returnd_coins_amt_after',
'plan_other_amt_paid_typ2',
'plan_other_amt_paid_typ2_after',
'plan_other_amt_paid_typ3',
'plan_other_amt_paid_typ3_after',
'plan_other_amt_paid_2',
'plan_other_amt_paid_2_after',
'plan_other_amt_paid_3',
'plan_other_amt_paid_3_after',
'phrm_svc_type_cd',
'phrm_svc_type_cd_after',
'npref_brnd_prd_amt',
'npref_brnd_prd_amt_after',
'basis_of_reimb_determ',
'basis_of_reimb_determ_after',
'plan_rtrnd_coins_amt',
'plan_rtrnd_coins_amt_after',
'plan_incent_amt_submtd',
'plan_incent_amt_submtd_after',
'plan_gross_due_amt',
'plan_gross_due_amt_after',
'ben_stg_qualifier_1',
'ben_stg_qualifier_1_after',
'ben_stg_qualifier_2',
'ben_stg_qualifier_2_after',
'ben_stg_qualifier_3',
'ben_stg_qualifier_3_after',
'ben_stg_qualifier_4',
'ben_stg_qualifier_4_after',
'ben_stg_amount_1',
'ben_stg_amount_1_after',
'ben_stg_amount_2',
'ben_stg_amount_2_after',
'ben_stg_amount_3',
'ben_stg_amount_3_after',
'ben_stg_amount_4',
'ben_stg_amount_4_after',
'ws_pipe_id',
'ws_pipe_id_after',
'coupon_drug_id',
'coupon_drug_id_after',
'coupon_ind',
'coupon_ind_after'
]

#col_len = len(fieldList)
#print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 233 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 234:
      return True
  else:
    if val_len != 234:
      return True


# COMMAND ----------

#spliting the assets to 4 partitions based on src_partition_nbr on asset name
readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[7]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[7]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[7]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[7]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

# Read files based on partitions
in1_text = spark.read.text(readList_src_1)
in2_text = spark.read.text(readList_src_2)
in3_text = spark.read.text(readList_src_3)
in4_text = spark.read.text(readList_src_4)

in1_text = in1_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in2_text = in2_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in3_text = in3_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in4_text = in4_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

rdb1 = in1_text.filter(lambda x: checkbad(x[0]))
rdb2 = in2_text.filter(lambda x: checkbad(x[0]))
rdb3 = in3_text.filter(lambda x: checkbad(x[0]))
rdb4 = in4_text.filter(lambda x: checkbad(x[0]))

rdb_count = rdb1.count()+ rdb2.count()+ rdb3.count()+ rdb4.count()
rdb = rdb1+rdb2+rdb3+rdb4

if rdb_count>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len =234

rd1 = in1_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd2 = in2_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd3 = in3_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd4 = in4_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd1_good = rd1.filter(lambda x: x[0] == col_len)
rd2_good = rd2.filter(lambda x: x[0] == col_len)
rd3_good = rd3.filter(lambda x: x[0] == col_len)
rd4_good = rd4.filter(lambda x: x[0] == col_len)

rd_bad_all = rd1+rd2+rd3+rd4
rd_bad = rd_bad_all.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------
#add schema to df for each partition
df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

#splitted df to one df
df_split = df_g1.union(df_g2).union(df_g3).union(df_g4)

##Extarct filename
#from pyspark.sql.functions import input_file_name
#df = spark.createDataFrame(rd_good, schema)
#df_fileName = df.withColumn("fileName",input_file_name())

##Extract partition number from file name
#df_split = df_fileName.withColumn("src_partition_nbr",concat(split(col("fileName"),"_")[7]))
#df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
#df_split = df_split.drop("fileName")
#display(df_split)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df_split = df_split.drop('row_length')
# df_split = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df_split.columns,
#     df_split
# ))

# COMMAND ----------

# display(df_split)
print(f"Total source count {df_split.count()}")

# COMMAND ----------

df_split.createOrReplaceTempView("gg_tbf0_sdl_history")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_sdl_history where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")



print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_sdl_history"))
          
df_gg.createOrReplaceTempView("raw_gg_tbf0_sdl_history")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="((sdl_msg_id == sdl_msg_id_after AND sdl_msg_id IS NOT NULL AND sdl_msg_id_after IS NOT NULL) AND  (store_nbr == store_nbr_after AND store_nbr IS NOT NULL AND store_nbr_after IS NOT NULL) AND (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND (rx_nbr == rx_nbr_after AND rx_nbr IS NOT NULL AND rx_nbr_after IS NOT NULL )AND  (fill_nbr ==fill_nbr_after AND fill_nbr IS NOT NULL AND fill_nbr_after IS NOT NULL) AND  (fill_enter_dttm ==fill_enter_dttm_after AND fill_enter_dttm IS NOT NULL AND fill_enter_dttm_after IS NOT NULL) AND  (cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL) AND  (cdc_rba_nbr ==cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL) AND   (cdc_txn_commit_dttm==cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL) AND  ((pat_id==pat_id_after AND pat_id IS NOT NULL AND pat_id_after IS NOT NULL) OR (pat_id IS NULL AND  pat_id_after IS NULL)) AND  ((fill_qty_dispensed==fill_qty_dispensed_after AND fill_qty_dispensed IS NOT NULL AND fill_qty_dispensed_after IS NOT NULL ) OR (fill_qty_dispensed IS NULL AND  fill_qty_dispensed_after IS NULL)) AND  ((fill_days_supply==fill_days_supply_after AND fill_days_supply IS NOT NULL AND fill_days_supply_after IS NOT NULL ) OR (fill_days_supply IS NULL AND  fill_days_supply_after IS NULL)) AND  ((submitted_user_id==submitted_user_id_after AND submitted_user_id IS NOT NULL AND submitted_user_id_after IS NOT NULL ) OR (submitted_user_id IS NULL AND  submitted_user_id_after IS NULL)) AND  ((submitted_dttm==submitted_dttm_after AND submitted_dttm IS NOT NULL AND submitted_dttm_after IS NOT NULL) OR (submitted_dttm IS NULL AND  submitted_dttm_after IS NULL)) AND  ((fill_nbr_dispensed==fill_nbr_dispensed_after AND fill_nbr_dispensed IS NOT NULL AND fill_nbr_dispensed_after IS NOT NULL ) OR (fill_nbr_dispensed IS NULL AND  fill_nbr_dispensed_after IS NULL)) AND  ((drug_name==drug_name_after AND drug_name IS NOT NULL AND drug_name_after IS NOT NULL ) OR (drug_name IS NULL AND  drug_name_after IS NULL)) AND  ((drug_ndc_nbr==drug_ndc_nbr_after AND drug_ndc_nbr IS NOT NULL AND drug_ndc_nbr_after IS NOT NULL) OR (drug_ndc_nbr IS NULL AND  drug_ndc_nbr_after IS NULL)) AND  ((rx_written_dttm==rx_written_dttm_after AND rx_written_dttm IS NOT NULL AND rx_written_dttm_after IS NOT NULL ) OR (rx_written_dttm IS NULL AND  rx_written_dttm_after IS NULL)) AND  ((general_pbr_nbr==general_pbr_nbr_after AND general_pbr_nbr IS NOT NULL AND general_pbr_nbr_after IS NOT NULL ) OR (general_pbr_nbr IS NULL AND  general_pbr_nbr_after IS NULL)) AND  ((plan_id==plan_id_after AND plan_id IS NOT NULL AND plan_id_after IS NOT NULL ) OR (plan_id IS NULL AND  plan_id_after IS NULL)) AND  ((plan_group_nbr==plan_group_nbr_after AND plan_group_nbr IS NOT NULL AND plan_group_nbr_after IS NOT NULL ) OR (plan_group_nbr IS NULL AND  plan_group_nbr_after IS NULL)) AND  ((general_recipient_nbr==general_recipient_nbr_after AND general_recipient_nbr IS NOT NULL AND general_recipient_nbr_after IS NOT NULL ) OR (general_recipient_nbr IS NULL AND  general_recipient_nbr_after IS NULL)) AND  ((prior_auth_cd==prior_auth_cd_after AND prior_auth_cd IS NOT NULL AND prior_auth_cd_after IS NOT NULL) OR (prior_auth_cd IS NULL AND  prior_auth_cd_after IS NULL)) AND  ((prior_auth_nbr==prior_auth_nbr_after AND prior_auth_nbr IS NOT NULL AND prior_auth_nbr_after IS NOT NULL) OR (prior_auth_nbr IS NULL AND  prior_auth_nbr_after IS NULL)) AND  ((rx_denial_override_cd==rx_denial_override_cd_after AND rx_denial_override_cd IS NOT NULL AND rx_denial_override_cd_after IS NOT NULL ) OR (rx_denial_override_cd IS NULL AND  rx_denial_override_cd_after IS NULL)) AND  ((eligibility_override_cd==eligibility_override_cd_after AND eligibility_override_cd IS NOT NULL AND  eligibility_override_cd_after IS NOT NULL ) OR (eligibility_override_cd IS NULL AND  eligibility_override_cd_after IS NULL)) AND  ((diagnosis_cd==diagnosis_cd_after AND diagnosis_cd IS NOT NULL AND diagnosis_cd_after IS NOT NULL ) OR (diagnosis_cd IS NULL AND  diagnosis_cd_after IS NULL)) AND  ((pay_cd==pay_cd_after AND pay_cd IS NOT NULL AND pay_cd_after IS NOT NULL ) OR (pay_cd IS NULL AND  pay_cd_after IS NULL)) AND  ((dl_reject_cd_01==dl_reject_cd_01_after AND dl_reject_cd_01 IS NOT NULL AND dl_reject_cd_01_after IS NOT NULL ) OR (dl_reject_cd_01 IS NULL AND  dl_reject_cd_01_after IS NULL)) AND  ((dl_reject_reason_01==dl_reject_reason_01_after AND dl_reject_reason_01 IS NOT NULL AND  dl_reject_reason_01_after IS NOT NULL ) OR (dl_reject_reason_01 IS NULL AND  dl_reject_reason_01_after IS NULL)) AND  ((dl_reject_cd_02==dl_reject_cd_02_after AND dl_reject_cd_02 IS NOT NULL AND dl_reject_cd_02_after IS NOT NULL ) OR (dl_reject_cd_02 IS NULL AND  dl_reject_cd_02_after IS NULL)) AND  ((dl_reject_reason_02==dl_reject_reason_02_after AND dl_reject_reason_02 IS NOT NULL AND dl_reject_reason_02_after IS NOT NULL ) OR (dl_reject_reason_02 IS NULL AND  dl_reject_reason_02_after IS NULL)) AND   ((dl_reject_cd_03==dl_reject_cd_03_after AND dl_reject_cd_03 IS NOT NULL AND dl_reject_cd_03_after IS NOT NULL ) OR (dl_reject_cd_03 IS NULL AND  dl_reject_cd_03_after IS NULL)) AND  ((dl_reject_reason_03==dl_reject_reason_03_after AND dl_reject_reason_03 IS NOT NULL AND dl_reject_reason_03_after IS NOT NULL ) OR (dl_reject_reason_03 IS NULL AND  dl_reject_reason_03_after IS NULL)) AND  ((dl_reject_cd_04==dl_reject_cd_04_after AND dl_reject_cd_04 IS NOT NULL AND dl_reject_cd_04_after IS NOT NULL ) OR (dl_reject_cd_04 IS NULL AND  dl_reject_cd_04_after IS NULL)) AND  ((dl_reject_reason_04==dl_reject_reason_04_after AND dl_reject_reason_04 IS NOT NULL AND dl_reject_reason_04_after IS NOT NULL ) OR (dl_reject_reason_04 IS NULL AND  dl_reject_reason_04_after IS NULL)) AND  ((dl_reject_cd_05==dl_reject_cd_05_after AND dl_reject_cd_05 IS NOT NULL AND dl_reject_cd_05_after IS NOT NULL ) OR (dl_reject_cd_05 IS NULL AND  dl_reject_cd_05_after IS NULL)) AND  ((dl_reject_reason_05==dl_reject_reason_05_after AND dl_reject_reason_05 IS NOT NULL AND dl_reject_reason_05_after IS NOT NULL) OR (dl_reject_reason_05 IS NULL AND  dl_reject_reason_05_after IS NULL)) AND  ((dl_proc_msg==dl_proc_msg_after AND dl_proc_msg IS NOT NULL AND dl_proc_msg_after IS NOT NULL ) OR (dl_proc_msg IS NULL AND  dl_proc_msg_after IS NULL)) AND  ((dl_additional_msg==dl_additional_msg_after AND dl_additional_msg IS NOT NULL AND dl_additional_msg_after IS NOT NULL ) OR (dl_additional_msg IS NULL AND  dl_additional_msg_after IS NULL)) AND  ((dur_conflict_cd==dur_conflict_cd_after AND dur_conflict_cd IS NOT NULL AND  dur_conflict_cd_after IS NOT NULL ) OR (dur_conflict_cd IS NULL AND  dur_conflict_cd_after IS NULL)) AND  ((dur_intervention_cd==dur_intervention_cd_after AND dur_intervention_cd IS NOT NULL AND  dur_intervention_cd_after IS NOT NULL ) OR (dur_intervention_cd IS NULL AND  dur_intervention_cd_after IS NULL)) AND  ((dur_outcome_cd==dur_outcome_cd_after AND dur_outcome_cd IS NOT NULL AND dur_outcome_cd_after IS NOT NULL ) OR (dur_outcome_cd IS NULL AND  dur_outcome_cd_after IS NULL)) AND  ((other_payer_reject_cd==other_payer_reject_cd_after AND other_payer_reject_cd IS NOT NULL AND other_payer_reject_cd_after IS NOT NULL ) OR (other_payer_reject_cd IS NULL AND  other_payer_reject_cd_after IS NULL)) AND  ((other_coverage_cd==other_coverage_cd_after AND other_coverage_cd IS NOT NULL AND other_coverage_cd_after IS NOT NULL) OR (other_coverage_cd IS NULL AND  other_coverage_cd_after IS NULL)) AND  ((other_payer_cvrg_type==other_payer_cvrg_type_after AND other_payer_cvrg_type IS NOT NULL AND other_payer_cvrg_type_after IS NOT NULL) OR (other_payer_cvrg_type IS NULL AND  other_payer_cvrg_type_after IS NULL)) AND  ((plan_other_amt_paid_type==plan_other_amt_paid_type_after AND plan_other_amt_paid_type IS NOT NULL AND plan_other_amt_paid_type_after IS NOT NULL ) OR (plan_other_amt_paid_type IS NULL AND  plan_other_amt_paid_type_after IS NULL)) AND  ((plan_other_amt_paid==plan_other_amt_paid_after AND plan_other_amt_paid IS NOT NULL AND plan_other_amt_paid_after IS NOT NULL ) OR (plan_other_amt_paid IS NULL AND  plan_other_amt_paid_after IS NULL)) AND  ((other_payer_id==other_payer_id_after AND other_payer_id IS NOT NULL AND other_payer_id_after IS NOT NULL ) OR (other_payer_id IS NULL AND  other_payer_id_after IS NULL)) AND  ((other_payer_id_qualifier==other_payer_id_qualifier_after AND other_payer_id_qualifier IS NOT NULL AND other_payer_id_qualifier_after IS NOT NULL ) OR (other_payer_id_qualifier IS NULL AND  other_payer_id_qualifier_after IS NULL)) AND  ((first_provider_paid_amt==first_provider_paid_amt_after AND first_provider_paid_amt IS NOT NULL AND first_provider_paid_amt_after IS NOT NULL ) OR (first_provider_paid_amt IS NULL AND  first_provider_paid_amt_after IS NULL)) AND  ((plan_total_paid_amt==plan_total_paid_amt_after AND plan_total_paid_amt IS NOT NULL AND plan_total_paid_amt_after IS NOT NULL ) OR (plan_total_paid_amt IS NULL AND  plan_total_paid_amt_after IS NULL)) AND  ((plan_returnd_cost_amt==plan_returnd_cost_amt_after AND plan_returnd_cost_amt IS NOT NULL AND plan_returnd_cost_amt_after IS NOT NULL ) OR (plan_returnd_cost_amt IS NULL AND  plan_returnd_cost_amt_after IS NULL)) AND  ((plan_returnd_fee_amt==plan_returnd_fee_amt_after AND plan_returnd_fee_amt IS NOT NULL AND plan_returnd_fee_amt_after IS NOT NULL ) OR (plan_returnd_fee_amt IS NULL AND  plan_returnd_fee_amt_after IS NULL)) AND  ((plan_incentive_paid_amt==plan_incentive_paid_amt_after AND plan_incentive_paid_amt IS NOT NULL AND plan_incentive_paid_amt_after IS NOT NULL ) OR (plan_incentive_paid_amt IS NULL AND  plan_incentive_paid_amt_after IS NULL)) AND  ((fill_retail_price_amt==fill_retail_price_amt_after AND fill_retail_price_amt IS NOT NULL AND fill_retail_price_amt_after IS NOT NULL ) OR (fill_retail_price_amt IS NULL AND  fill_retail_price_amt_after IS NULL)) AND  ((pat_rem_ded_amt==pat_rem_ded_amt_after AND pat_rem_ded_amt IS NOT NULL AND pat_rem_ded_amt_after IS NOT NULL ) OR (pat_rem_ded_amt IS NULL AND  pat_rem_ded_amt_after IS NULL)) AND  ((pat_rem_ben_amt==pat_rem_ben_amt_after AND pat_rem_ben_amt IS NOT NULL AND pat_rem_ben_amt_after IS NOT NULL ) OR (pat_rem_ben_amt IS NULL AND  pat_rem_ben_amt_after IS NULL)) AND  ((pat_acc_ded_amt==pat_acc_ded_amt_after AND pat_acc_ded_amt IS NOT NULL AND pat_acc_ded_amt_after IS NOT NULL ) OR (pat_acc_ded_amt IS NULL AND  pat_acc_ded_amt_after IS NULL)) AND  ((pat_ded_applied_amt==pat_ded_applied_amt_after AND pat_ded_applied_amt IS NOT NULL AND pat_ded_applied_amt_after IS NOT NULL ) OR (pat_ded_applied_amt IS NULL AND  pat_ded_applied_amt_after IS NULL)) AND  ((fill_del_adjudication_cd==fill_del_adjudication_cd_after AND fill_del_adjudication_cd IS NOT NULL AND fill_del_adjudication_cd_after IS NOT NULL ) OR (fill_del_adjudication_cd IS NULL AND  fill_del_adjudication_cd_after IS NULL)) AND  ((fill_adjudication_cd==fill_adjudication_cd_after AND fill_adjudication_cd IS NOT NULL AND fill_adjudication_cd_after IS NOT NULL ) OR (fill_adjudication_cd IS NULL AND  fill_adjudication_cd_after IS NULL)) AND  ((claim_reference_nbr==claim_reference_nbr_after AND claim_reference_nbr IS NOT NULL AND claim_reference_nbr_after IS NOT NULL ) OR (claim_reference_nbr IS NULL AND  claim_reference_nbr_after IS NULL)) AND  ((plan_returnd_copay_amt==plan_returnd_copay_amt_after AND plan_returnd_copay_amt IS NOT NULL AND plan_returnd_copay_amt_after IS NOT NULL ) OR (plan_returnd_copay_amt IS NULL AND  plan_returnd_copay_amt_after IS NULL)) AND  ((plan_returnd_tax_amt==plan_returnd_tax_amt_after AND plan_returnd_tax_amt IS NOT NULL AND plan_returnd_tax_amt_after IS NOT NULL ) OR (plan_returnd_tax_amt IS NULL AND  plan_returnd_tax_amt_after IS NULL)) AND  ((fill_sold_amt==fill_sold_amt_after AND fill_sold_amt IS NOT NULL AND fill_sold_amt_after IS NOT NULL ) OR (fill_sold_amt IS NULL AND  fill_sold_amt_after IS NULL)) AND  ((sales_adj_cd==sales_adj_cd_after AND sales_adj_cd IS NOT NULL AND sales_adj_cd_after IS NOT NULL ) OR (sales_adj_cd IS NULL AND  sales_adj_cd_after IS NULL)) AND  ((rx_daw_ind==rx_daw_ind_after AND rx_daw_ind IS NOT NULL AND rx_daw_ind_after IS NOT NULL ) OR (rx_daw_ind IS NULL AND  rx_daw_ind_after IS NULL)) AND  ((claim_reversal_ind==claim_reversal_ind_after AND claim_reversal_ind IS NOT NULL AND claim_reversal_ind_after IS NOT NULL ) OR (claim_reversal_ind IS NULL AND  claim_reversal_ind_after IS NULL)) AND  ((place_of_service==place_of_service_after AND place_of_service IS NOT NULL AND place_of_service_after IS NOT NULL ) OR (place_of_service IS NULL AND  place_of_service_after IS NULL)) AND  ((rx_denial_override_cd_2==rx_denial_override_cd_2_after AND rx_denial_override_cd_2 IS NOT NULL AND rx_denial_override_cd_2_after IS NOT NULL) OR (rx_denial_override_cd_2 IS NULL AND  rx_denial_override_cd_2_after IS NULL)) AND  ((rx_denial_override_cd_3==rx_denial_override_cd_3_after AND rx_denial_override_cd_3 IS NOT NULL AND  rx_denial_override_cd_3_after IS NOT NULL ) OR (rx_denial_override_cd_3 IS NULL AND  rx_denial_override_cd_3_after IS NULL)) AND  ((delay_reason_cd==delay_reason_cd_after AND delay_reason_cd IS NOT NULL AND delay_reason_cd_after IS NOT NULL ) OR (delay_reason_cd IS NULL AND  delay_reason_cd_after IS NULL)) AND  ((plan_returnd_grp_nbr==plan_returnd_grp_nbr_after AND plan_returnd_grp_nbr IS NOT NULL AND plan_returnd_grp_nbr_after IS NOT NULL) OR (plan_returnd_grp_nbr IS NULL AND  plan_returnd_grp_nbr_after IS NULL)) AND  ((plan_id_returnd==plan_id_returnd_after AND plan_id_returnd IS NOT NULL AND plan_id_returnd_after IS NOT NULL ) OR (plan_id_returnd IS NULL AND  plan_id_returnd_after IS NULL)) AND  ((ntwk_reimb_id_returnd==ntwk_reimb_id_returnd_after AND ntwk_reimb_id_returnd IS NOT NULL AND  ntwk_reimb_id_returnd_after IS NOT NULL ) OR (ntwk_reimb_id_returnd IS NULL AND  ntwk_reimb_id_returnd_after IS NULL)) AND  ((proc_fee_amt==proc_fee_amt_after AND proc_fee_amt IS NOT NULL AND proc_fee_amt_after IS NOT NULL) OR (proc_fee_amt IS NULL AND  proc_fee_amt_after IS NULL)) AND  ((prvd_ntwk_amt==prvd_ntwk_amt_after AND prvd_ntwk_amt IS NOT NULL AND prvd_ntwk_amt_after IS NOT NULL) OR (prvd_ntwk_amt IS NULL AND  prvd_ntwk_amt_after IS NULL)) AND  ((prd_brnd_drug_amt==prd_brnd_drug_amt_after AND prd_brnd_drug_amt IS NOT NULL AND prd_brnd_drug_amt_after IS NOT NULL) OR (prd_brnd_drug_amt IS NULL AND  prd_brnd_drug_amt_after IS NULL)) AND  ((npref_prd_form_amt==npref_prd_form_amt_after AND npref_prd_form_amt IS NOT NULL AND npref_prd_form_amt_after IS NOT NULL ) OR (npref_prd_form_amt IS NULL AND  npref_prd_form_amt_after IS NULL)) AND  ((cov_gap_amt==cov_gap_amt_after AND cov_gap_amt IS NOT NULL AND cov_gap_amt_after IS NOT NULL) OR (cov_gap_amt IS NULL AND  cov_gap_amt_after IS NULL)) AND  ((plan_fund_assist_amt==plan_fund_assist_amt_after AND plan_fund_assist_amt IS NOT NULL AND plan_fund_assist_amt_after IS NOT NULL ) OR (plan_fund_assist_amt IS NULL AND  plan_fund_assist_amt_after IS NULL)) AND  ((ingrd_cost_contract_amt==ingrd_cost_contract_amt_after AND ingrd_cost_contract_amt IS NOT NULL AND ingrd_cost_contract_amt_after IS NOT NULL ) OR (ingrd_cost_contract_amt IS NULL AND  ingrd_cost_contract_amt_after IS NULL)) AND  ((disp_fee_contract_amt==disp_fee_contract_amt_after AND disp_fee_contract_amt IS NOT NULL AND disp_fee_contract_amt_after IS NOT NULL ) OR (disp_fee_contract_amt IS NULL AND  disp_fee_contract_amt_after IS NULL)) AND  ((plan_sales_tax_amt==plan_sales_tax_amt_after AND plan_sales_tax_amt IS NOT NULL AND plan_sales_tax_amt_after IS NOT NULL ) OR (plan_sales_tax_amt IS NULL AND  plan_sales_tax_amt_after IS NULL)) AND  ((pat_sales_tax_amt==pat_sales_tax_amt_after AND pat_sales_tax_amt IS NOT NULL AND pat_sales_tax_amt_after IS NOT NULL ) OR (pat_sales_tax_amt IS NULL AND  pat_sales_tax_amt_after IS NULL)) AND  ((other_payer_recognzd_amt==other_payer_recognzd_amt_after AND other_payer_recognzd_amt IS NOT NULL AND other_payer_recognzd_amt_after IS NOT NULL ) OR (other_payer_recognzd_amt IS NULL AND  other_payer_recognzd_amt_after IS NULL)) AND  ((ben_stg_ded_amt==ben_stg_ded_amt_after AND ben_stg_ded_amt IS NOT NULL AND ben_stg_ded_amt_after IS NOT NULL ) OR (ben_stg_ded_amt IS NULL AND  ben_stg_ded_amt_after IS NULL)) AND  ((ben_stg_init_cov_amt==ben_stg_init_cov_amt_after AND ben_stg_init_cov_amt IS NOT NULL AND ben_stg_init_cov_amt_after IS NOT NULL ) OR (ben_stg_init_cov_amt IS NULL AND  ben_stg_init_cov_amt_after IS NULL)) AND   ((ben_stg_cov_gap_amt==ben_stg_cov_gap_amt_after AND ben_stg_cov_gap_amt IS NOT NULL AND ben_stg_cov_gap_amt_after IS NOT NULL ) OR (ben_stg_cov_gap_amt IS NULL AND  ben_stg_cov_gap_amt_after IS NULL)) AND  ((ben_stg_cat_amt==ben_stg_cat_amt_after AND ben_stg_cat_amt IS NOT NULL AND ben_stg_cat_amt_after IS NOT NULL ) OR (ben_stg_cat_amt IS NULL AND  ben_stg_cat_amt_after IS NULL)) AND   ((plan_returnd_coins_amt==plan_returnd_coins_amt_after AND plan_returnd_coins_amt IS NOT NULL AND plan_returnd_coins_amt_after IS NOT NULL ) OR (plan_returnd_coins_amt IS NULL AND  plan_returnd_coins_amt_after IS NULL)) AND  ((plan_other_amt_paid_typ2==plan_other_amt_paid_typ2_after AND plan_other_amt_paid_typ2 IS NOT NULL AND plan_other_amt_paid_typ2_after IS NOT NULL ) OR (plan_other_amt_paid_typ2 IS NULL AND  plan_other_amt_paid_typ2_after IS NULL)) AND  ((plan_other_amt_paid_typ3==plan_other_amt_paid_typ3_after AND plan_other_amt_paid_typ3 IS NOT NULL AND plan_other_amt_paid_typ3_after IS NOT NULL ) OR (plan_other_amt_paid_typ3 IS NULL AND  plan_other_amt_paid_typ3_after IS NULL)) AND  ((plan_other_amt_paid_2 == plan_other_amt_paid_2_after AND plan_other_amt_paid_2 IS NOT NULL AND plan_other_amt_paid_2_after IS NOT NULL ) OR (plan_other_amt_paid_2 IS NULL AND  plan_other_amt_paid_2_after IS NULL)) AND   ((plan_other_amt_paid_3 == plan_other_amt_paid_3_after AND plan_other_amt_paid_3 IS NOT NULL AND plan_other_amt_paid_3_after IS NOT NULL ) OR (plan_other_amt_paid_3 IS NULL AND  plan_other_amt_paid_3_after IS NULL)) AND   ((phrm_svc_type_cd==phrm_svc_type_cd_after AND phrm_svc_type_cd IS NOT NULL AND phrm_svc_type_cd_after IS NOT NULL ) OR (phrm_svc_type_cd IS NULL AND  phrm_svc_type_cd_after IS NULL)) AND   ((npref_brnd_prd_amt==npref_brnd_prd_amt_after AND npref_brnd_prd_amt IS NOT NULL AND npref_brnd_prd_amt_after IS NOT NULL ) OR (npref_brnd_prd_amt IS NULL AND  npref_brnd_prd_amt_after IS NULL)) AND  ((basis_of_reimb_determ==basis_of_reimb_determ_after AND basis_of_reimb_determ IS NOT NULL AND basis_of_reimb_determ_after IS NOT NULL ) OR (basis_of_reimb_determ IS NULL AND  basis_of_reimb_determ_after IS NULL)) AND  ((plan_rtrnd_coins_amt == plan_rtrnd_coins_amt_after AND plan_rtrnd_coins_amt IS NOT NULL AND plan_rtrnd_coins_amt_after IS NOT NULL) OR (plan_rtrnd_coins_amt IS NULL AND  plan_rtrnd_coins_amt_after IS NULL)) AND  ((plan_incent_amt_submtd==plan_incent_amt_submtd_after AND plan_incent_amt_submtd IS NOT NULL AND plan_incent_amt_submtd_after IS NOT NULL) OR (plan_incent_amt_submtd IS NULL AND  plan_incent_amt_submtd_after IS NULL)) AND  ((plan_gross_due_amt==plan_gross_due_amt_after AND plan_gross_due_amt IS NOT NULL AND plan_gross_due_amt_after IS NOT NULL) OR (plan_gross_due_amt IS NULL AND  plan_gross_due_amt_after IS NULL)) AND   ((ben_stg_qualifier_1 == ben_stg_qualifier_1_after AND ben_stg_qualifier_1 IS NOT NULL AND ben_stg_qualifier_1_after IS NOT NULL ) OR (ben_stg_qualifier_1 IS NULL AND  ben_stg_qualifier_1_after IS NULL)) AND  ((ben_stg_qualifier_2==ben_stg_qualifier_2_after AND ben_stg_qualifier_2 IS NOT NULL AND ben_stg_qualifier_2_after IS NOT NULL) OR (ben_stg_qualifier_2 IS NULL AND  ben_stg_qualifier_2_after IS NULL)) AND  ((ben_stg_qualifier_3==ben_stg_qualifier_3_after AND ben_stg_qualifier_3 IS NOT NULL AND ben_stg_qualifier_3_after IS NOT NULL ) OR (ben_stg_qualifier_3 IS NULL AND  ben_stg_qualifier_3_after IS NULL)) AND  ((ben_stg_qualifier_4==ben_stg_qualifier_4_after AND ben_stg_qualifier_4 IS NOT NULL AND ben_stg_qualifier_4_after IS NOT NULL ) OR (ben_stg_qualifier_4 IS NULL AND  ben_stg_qualifier_4_after IS NULL)) AND  ((ben_stg_amount_1==ben_stg_amount_1_after AND ben_stg_amount_1 IS NOT NULL AND ben_stg_amount_1_after IS NOT NULL ) OR (ben_stg_amount_1 IS NULL AND  ben_stg_amount_1_after IS NULL)) AND  ((ben_stg_amount_2==ben_stg_amount_2_after AND ben_stg_amount_2 IS NOT NULL AND ben_stg_amount_2_after IS NOT NULL ) OR (ben_stg_amount_2 IS NULL AND  ben_stg_amount_2_after IS NULL)) AND  ((ben_stg_amount_3==ben_stg_amount_3_after AND ben_stg_amount_3 IS NOT NULL AND ben_stg_amount_3_after IS NOT NULL) OR (ben_stg_amount_3 IS NULL AND  ben_stg_amount_3_after IS NULL)) AND  ((ben_stg_amount_4==ben_stg_amount_4_after AND ben_stg_amount_4 IS NOT NULL AND ben_stg_amount_4_after IS NOT NULL ) OR (ben_stg_amount_4 IS NULL AND  ben_stg_amount_4_after IS NULL)) AND  ((ws_pipe_id==ws_pipe_id_after AND ws_pipe_id IS NOT NULL AND ws_pipe_id_after IS NOT NULL) OR (ws_pipe_id IS NULL AND  ws_pipe_id_after IS NULL)) AND  ((coupon_drug_id==coupon_drug_id_after AND coupon_drug_id IS NOT NULL AND coupon_drug_id_after IS NOT NULL ) OR (coupon_drug_id IS NULL AND  coupon_drug_id_after IS NULL)) AND  ((coupon_ind==coupon_ind_after AND coupon_ind IS NOT NULL AND  coupon_ind_after IS NOT NULL ) OR (coupon_ind IS NULL AND  coupon_ind_after IS NULL)))" 

pPatIdModCheck=" (table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, src_partition_nbr, sdl_msg_id, pat_id, store_nbr, rx_nbr, fill_nbr, fill_qty_dispensed, fill_days_supply, CONCAT(fill_enter_dttm,'.000000') AS fill_enter_dttm, fill_nbr_dispensed, drug_name, drug_ndc_nbr, CONCAT(rx_written_dttm,'.000000') AS rx_written_dttm, general_pbr_nbr, submitted_user_id, CONCAT(submitted_dttm,'.000000') AS submitted_dttm, plan_id, plan_group_nbr, general_recipient_nbr, prior_auth_cd, prior_auth_nbr, rx_denial_override_cd, eligibility_override_cd, diagnosis_cd, pay_cd, dl_reject_cd_01, dl_reject_reason_01, dl_reject_cd_02, dl_reject_reason_02, dl_reject_cd_03, dl_reject_reason_03, dl_reject_cd_04, dl_reject_reason_04, dl_reject_cd_05, dl_reject_reason_05, dl_proc_msg, dl_additional_msg, dur_conflict_cd, dur_intervention_cd, dur_outcome_cd, other_payer_reject_cd, other_coverage_cd, other_payer_cvrg_type, plan_other_amt_paid_type, plan_other_amt_paid, other_payer_id, other_payer_id_qualifier, first_provider_paid_amt, plan_total_paid_amt, plan_returnd_cost_amt, plan_returnd_fee_amt, plan_incentive_paid_amt, fill_retail_price_amt, pat_rem_ded_amt, pat_rem_ben_amt, pat_acc_ded_amt, pat_ded_applied_amt, fill_del_adjudication_cd, fill_adjudication_cd, claim_reference_nbr, plan_returnd_copay_amt, plan_returnd_tax_amt, fill_sold_amt, sales_adj_cd, rx_daw_ind, claim_reversal_ind, place_of_service, rx_denial_override_cd_2, rx_denial_override_cd_3, delay_reason_cd, plan_returnd_grp_nbr, plan_id_returnd, ntwk_reimb_id_returnd, proc_fee_amt, prvd_ntwk_amt, prd_brnd_drug_amt, npref_prd_form_amt, cov_gap_amt, plan_fund_assist_amt, ingrd_cost_contract_amt, disp_fee_contract_amt, plan_sales_tax_amt, pat_sales_tax_amt, other_payer_recognzd_amt, ben_stg_ded_amt, ben_stg_init_cov_amt, ben_stg_cov_gap_amt, ben_stg_cat_amt, plan_returnd_coins_amt, plan_other_amt_paid_typ2, plan_other_amt_paid_typ3, plan_other_amt_paid_2, plan_other_amt_paid_3, phrm_svc_type_cd, npref_brnd_prd_amt, basis_of_reimb_determ, plan_rtrnd_coins_amt, plan_incent_amt_submtd, plan_gross_due_amt, ben_stg_qualifier_1, ben_stg_qualifier_2, ben_stg_qualifier_3, ben_stg_qualifier_4, ben_stg_amount_1, ben_stg_amount_2, ben_stg_amount_3, ben_stg_amount_4, ws_pipe_id, coupon_drug_id, coupon_ind, tracking_id, partition_column"


# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

# BATCH_ID_CHK =  BATCH_ID 
# PROJ_ID_CHK =  PROJ_ID 

# cutoff_records_filter = cutoff_records_output.withColumn("EDW_BATCH_ID",concat(lit("'"),col("EDW_BATCH_ID"),lit("'")))\
#                                              .withColumn("PROJ_NAME",concat(lit("'"),col("PROJ_NAME"),lit("'")))

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == PROJ_ID))
#display(cutoff_records_filter)

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))

rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_sdl_history where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_sdl_history where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_sdl_history where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  
  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])
  
  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  
  #Remove duplicates
dedup_group = nr_input_file_final.distinct()



dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

#display(ded)


# COMMAND ----------

dedup_group.printSchema()

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim(src_partition_nbr))==0) then src_partition_nbr else TRIM(src_partition_nbr) end) as src_partition_nbr , (case when (LENGTH(trim(src_partition_nbr_after))==0) then src_partition_nbr_after else TRIM(src_partition_nbr_after) end) as src_partition_nbr_after , (case when (LENGTH(trim(sdl_msg_id))==0) then sdl_msg_id else TRIM(sdl_msg_id) end) as sdl_msg_id , (case when (LENGTH(trim(sdl_msg_id_after))==0) then sdl_msg_id_after else TRIM(sdl_msg_id_after) end) as sdl_msg_id_after , (case when (LENGTH(trim(pat_id))==0) then pat_id else TRIM(pat_id) end) as pat_id , (case when (LENGTH(trim(pat_id_after))==0) then pat_id_after else TRIM(pat_id_after) end) as pat_id_after , (case when (LENGTH(trim(store_nbr))==0) then store_nbr else TRIM(store_nbr) end) as store_nbr , (case when (LENGTH(trim(store_nbr_after))==0) then store_nbr_after else TRIM(store_nbr_after) end) as store_nbr_after , (case when (LENGTH(trim(rx_nbr))==0) then rx_nbr else TRIM(rx_nbr) end) as rx_nbr , (case when (LENGTH(trim(rx_nbr_after))==0) then rx_nbr_after else TRIM(rx_nbr_after) end) as rx_nbr_after , (case when (LENGTH(trim(fill_nbr))==0) then fill_nbr else TRIM(fill_nbr) end) as fill_nbr , (case when (LENGTH(trim(fill_nbr_after))==0) then fill_nbr_after else TRIM(fill_nbr_after) end) as fill_nbr_after , (case when (LENGTH(trim(fill_qty_dispensed))==0) then fill_qty_dispensed else TRIM(fill_qty_dispensed) end) as fill_qty_dispensed , (case when (LENGTH(trim(fill_qty_dispensed_after))==0) then fill_qty_dispensed_after else TRIM(fill_qty_dispensed_after) end) as fill_qty_dispensed_after , (case when (LENGTH(trim(fill_days_supply))==0) then fill_days_supply else TRIM(fill_days_supply) end) as fill_days_supply , (case when (LENGTH(trim(fill_days_supply_after))==0) then fill_days_supply_after else TRIM(fill_days_supply_after) end) as fill_days_supply_after , CONCAT(CONCAT(SUBSTRING(fill_enter_dttm,0,10),' '),SUBSTRING(fill_enter_dttm,11,19)) as fill_enter_dttm, CONCAT(CONCAT(SUBSTRING(fill_enter_dttm_after,0,10),' '),SUBSTRING(fill_enter_dttm_after,11,19)) as fill_enter_dttm_after, (case when (LENGTH(trim(fill_nbr_dispensed))==0) then fill_nbr_dispensed else TRIM(fill_nbr_dispensed) end) as fill_nbr_dispensed , (case when (LENGTH(trim(fill_nbr_dispensed_after))==0) then fill_nbr_dispensed_after else TRIM(fill_nbr_dispensed_after) end) as fill_nbr_dispensed_after , (case when (LENGTH(trim(drug_name))==0) then drug_name else TRIM(drug_name) end) as drug_name , (case when (LENGTH(trim(drug_name_after))==0) then drug_name_after else TRIM(drug_name_after) end) as drug_name_after , (case when (LENGTH(trim(drug_ndc_nbr))==0) then drug_ndc_nbr else TRIM(drug_ndc_nbr) end) as drug_ndc_nbr , (case when (LENGTH(trim(drug_ndc_nbr_after))==0) then drug_ndc_nbr_after else TRIM(drug_ndc_nbr_after) end) as drug_ndc_nbr_after , CONCAT(CONCAT(SUBSTRING(rx_written_dttm,0,10),' '),SUBSTRING(rx_written_dttm,11,19)) as rx_written_dttm, CONCAT(CONCAT(SUBSTRING(rx_written_dttm_after,0,10),' '),SUBSTRING(rx_written_dttm_after,11,19)) as rx_written_dttm_after, (case when (LENGTH(trim(general_pbr_nbr))==0) then general_pbr_nbr else TRIM(general_pbr_nbr) end) as general_pbr_nbr , (case when (LENGTH(trim(general_pbr_nbr_after))==0) then general_pbr_nbr_after else TRIM(general_pbr_nbr_after) end) as general_pbr_nbr_after , (case when (LENGTH(trim(submitted_user_id))==0) then submitted_user_id else TRIM(submitted_user_id) end) as submitted_user_id , (case when (LENGTH(trim(submitted_user_id_after))==0) then submitted_user_id_after else TRIM(submitted_user_id_after) end) as submitted_user_id_after , CONCAT(CONCAT(SUBSTRING(submitted_dttm,0,10),' '),SUBSTRING(submitted_dttm,11,19)) as submitted_dttm, CONCAT(CONCAT(SUBSTRING(submitted_dttm_after,0,10),' '),SUBSTRING(submitted_dttm_after,11,19)) as submitted_dttm_after, (case when (LENGTH(trim(plan_id))==0) then plan_id else TRIM(plan_id) end) as plan_id , (case when (LENGTH(trim(plan_id_after))==0) then plan_id_after else TRIM(plan_id_after) end) as plan_id_after , (case when (LENGTH(trim(plan_group_nbr))==0) then plan_group_nbr else TRIM(plan_group_nbr) end) as plan_group_nbr , (case when (LENGTH(trim(plan_group_nbr_after))==0) then plan_group_nbr_after else TRIM(plan_group_nbr_after) end) as plan_group_nbr_after , (case when (LENGTH(trim(general_recipient_nbr))==0) then general_recipient_nbr else TRIM(general_recipient_nbr) end) as general_recipient_nbr , (case when (LENGTH(trim(general_recipient_nbr_after))==0) then general_recipient_nbr_after else TRIM(general_recipient_nbr_after) end) as general_recipient_nbr_after , (case when (LENGTH(trim(prior_auth_cd))==0) then prior_auth_cd else TRIM(prior_auth_cd) end) as prior_auth_cd , (case when (LENGTH(trim(prior_auth_cd_after))==0) then prior_auth_cd_after else TRIM(prior_auth_cd_after) end) as prior_auth_cd_after , (case when (LENGTH(trim(prior_auth_nbr))==0) then prior_auth_nbr else TRIM(prior_auth_nbr) end) as prior_auth_nbr , (case when (LENGTH(trim(prior_auth_nbr_after))==0) then prior_auth_nbr_after else TRIM(prior_auth_nbr_after) end) as prior_auth_nbr_after , (case when (LENGTH(trim(rx_denial_override_cd))==0) then rx_denial_override_cd else TRIM(rx_denial_override_cd) end) as rx_denial_override_cd , (case when (LENGTH(trim(rx_denial_override_cd_after))==0) then rx_denial_override_cd_after else TRIM(rx_denial_override_cd_after) end) as rx_denial_override_cd_after , (case when (LENGTH(trim(eligibility_override_cd))==0) then eligibility_override_cd else TRIM(eligibility_override_cd) end) as eligibility_override_cd , (case when (LENGTH(trim(eligibility_override_cd_after))==0) then eligibility_override_cd_after else TRIM(eligibility_override_cd_after) end) as eligibility_override_cd_after , (case when (LENGTH(trim(diagnosis_cd))==0) then diagnosis_cd else TRIM(diagnosis_cd) end) as diagnosis_cd , (case when (LENGTH(trim(diagnosis_cd_after))==0) then diagnosis_cd_after else TRIM(diagnosis_cd_after) end) as diagnosis_cd_after , (case when (LENGTH(trim(pay_cd))==0) then pay_cd else TRIM(pay_cd) end) as pay_cd , (case when (LENGTH(trim(pay_cd_after))==0) then pay_cd_after else TRIM(pay_cd_after) end) as pay_cd_after , (case when (LENGTH(trim(dl_reject_cd_01))==0) then dl_reject_cd_01 else TRIM(dl_reject_cd_01) end) as dl_reject_cd_01 , (case when (LENGTH(trim(dl_reject_cd_01_after))==0) then dl_reject_cd_01_after else TRIM(dl_reject_cd_01_after) end) as dl_reject_cd_01_after , (case when (LENGTH(trim(dl_reject_reason_01))==0) then dl_reject_reason_01 else TRIM(dl_reject_reason_01) end) as dl_reject_reason_01 , (case when (LENGTH(trim(dl_reject_reason_01_after))==0) then dl_reject_reason_01_after else TRIM(dl_reject_reason_01_after) end) as dl_reject_reason_01_after , (case when (LENGTH(trim(dl_reject_cd_02))==0) then dl_reject_cd_02 else TRIM(dl_reject_cd_02) end) as dl_reject_cd_02 , (case when (LENGTH(trim(dl_reject_cd_02_after))==0) then dl_reject_cd_02_after else TRIM(dl_reject_cd_02_after) end) as dl_reject_cd_02_after , (case when (LENGTH(trim(dl_reject_reason_02))==0) then dl_reject_reason_02 else TRIM(dl_reject_reason_02) end) as dl_reject_reason_02 , (case when (LENGTH(trim(dl_reject_reason_02_after))==0) then dl_reject_reason_02_after else TRIM(dl_reject_reason_02_after) end) as dl_reject_reason_02_after , (case when (LENGTH(trim(dl_reject_cd_03))==0) then dl_reject_cd_03 else TRIM(dl_reject_cd_03) end) as dl_reject_cd_03 , (case when (LENGTH(trim(dl_reject_cd_03_after))==0) then dl_reject_cd_03_after else TRIM(dl_reject_cd_03_after) end) as dl_reject_cd_03_after , (case when (LENGTH(trim(dl_reject_reason_03))==0) then dl_reject_reason_03 else TRIM(dl_reject_reason_03) end) as dl_reject_reason_03 , (case when (LENGTH(trim(dl_reject_reason_03_after))==0) then dl_reject_reason_03_after else TRIM(dl_reject_reason_03_after) end) as dl_reject_reason_03_after , (case when (LENGTH(trim(dl_reject_cd_04))==0) then dl_reject_cd_04 else TRIM(dl_reject_cd_04) end) as dl_reject_cd_04 , (case when (LENGTH(trim(dl_reject_cd_04_after))==0) then dl_reject_cd_04_after else TRIM(dl_reject_cd_04_after) end) as dl_reject_cd_04_after , (case when (LENGTH(trim(dl_reject_reason_04))==0) then dl_reject_reason_04 else TRIM(dl_reject_reason_04) end) as dl_reject_reason_04 , (case when (LENGTH(trim(dl_reject_reason_04_after))==0) then dl_reject_reason_04_after else TRIM(dl_reject_reason_04_after) end) as dl_reject_reason_04_after , (case when (LENGTH(trim(dl_reject_cd_05))==0) then dl_reject_cd_05 else TRIM(dl_reject_cd_05) end) as dl_reject_cd_05 , (case when (LENGTH(trim(dl_reject_cd_05_after))==0) then dl_reject_cd_05_after else TRIM(dl_reject_cd_05_after) end) as dl_reject_cd_05_after , (case when (LENGTH(trim(dl_reject_reason_05))==0) then dl_reject_reason_05 else TRIM(dl_reject_reason_05) end) as dl_reject_reason_05 , (case when (LENGTH(trim(dl_reject_reason_05_after))==0) then dl_reject_reason_05_after else TRIM(dl_reject_reason_05_after) end) as dl_reject_reason_05_after , (case when (LENGTH(trim(dl_proc_msg))==0) then dl_proc_msg else TRIM(dl_proc_msg) end) as dl_proc_msg , (case when (LENGTH(trim(dl_proc_msg_after))==0) then dl_proc_msg_after else TRIM(dl_proc_msg_after) end) as dl_proc_msg_after , (case when (LENGTH(trim(dl_additional_msg))==0) then dl_additional_msg else TRIM(dl_additional_msg) end) as dl_additional_msg , (case when (LENGTH(trim(dl_additional_msg_after))==0) then dl_additional_msg_after else TRIM(dl_additional_msg_after) end) as dl_additional_msg_after , (case when (LENGTH(trim(dur_conflict_cd))==0) then dur_conflict_cd else TRIM(dur_conflict_cd) end) as dur_conflict_cd , (case when (LENGTH(trim(dur_conflict_cd_after))==0) then dur_conflict_cd_after else TRIM(dur_conflict_cd_after) end) as dur_conflict_cd_after , (case when (LENGTH(trim(dur_intervention_cd))==0) then dur_intervention_cd else TRIM(dur_intervention_cd) end) as dur_intervention_cd , (case when (LENGTH(trim(dur_intervention_cd_after))==0) then dur_intervention_cd_after else TRIM(dur_intervention_cd_after) end) as dur_intervention_cd_after , (case when (LENGTH(trim(dur_outcome_cd))==0) then dur_outcome_cd else TRIM(dur_outcome_cd) end) as dur_outcome_cd , (case when (LENGTH(trim(dur_outcome_cd_after))==0) then dur_outcome_cd_after else TRIM(dur_outcome_cd_after) end) as dur_outcome_cd_after , (case when (LENGTH(trim(other_payer_reject_cd))==0) then other_payer_reject_cd else TRIM(other_payer_reject_cd) end) as other_payer_reject_cd , (case when (LENGTH(trim(other_payer_reject_cd_after))==0) then other_payer_reject_cd_after else TRIM(other_payer_reject_cd_after) end) as other_payer_reject_cd_after , (case when (LENGTH(trim(other_coverage_cd))==0) then other_coverage_cd else TRIM(other_coverage_cd) end) as other_coverage_cd , (case when (LENGTH(trim(other_coverage_cd_after))==0) then other_coverage_cd_after else TRIM(other_coverage_cd_after) end) as other_coverage_cd_after , (case when (LENGTH(trim(other_payer_cvrg_type))==0) then other_payer_cvrg_type else TRIM(other_payer_cvrg_type) end) as other_payer_cvrg_type , (case when (LENGTH(trim(other_payer_cvrg_type_after))==0) then other_payer_cvrg_type_after else TRIM(other_payer_cvrg_type_after) end) as other_payer_cvrg_type_after , (case when (LENGTH(trim(plan_other_amt_paid_type))==0) then plan_other_amt_paid_type else TRIM(plan_other_amt_paid_type) end) as plan_other_amt_paid_type , (case when (LENGTH(trim(plan_other_amt_paid_type_after))==0) then plan_other_amt_paid_type_after else TRIM(plan_other_amt_paid_type_after) end) as plan_other_amt_paid_type_after , (case when (LENGTH(trim(plan_other_amt_paid))==0) then plan_other_amt_paid else TRIM(plan_other_amt_paid) end) as plan_other_amt_paid , (case when (LENGTH(trim(plan_other_amt_paid_after))==0) then plan_other_amt_paid_after else TRIM(plan_other_amt_paid_after) end) as plan_other_amt_paid_after , (case when (LENGTH(trim(other_payer_id))==0) then other_payer_id else TRIM(other_payer_id) end) as other_payer_id , (case when (LENGTH(trim(other_payer_id_after))==0) then other_payer_id_after else TRIM(other_payer_id_after) end) as other_payer_id_after , (case when (LENGTH(trim(other_payer_id_qualifier))==0) then other_payer_id_qualifier else TRIM(other_payer_id_qualifier) end) as other_payer_id_qualifier , (case when (LENGTH(trim(other_payer_id_qualifier_after))==0) then other_payer_id_qualifier_after else TRIM(other_payer_id_qualifier_after) end) as other_payer_id_qualifier_after , (case when (LENGTH(trim(first_provider_paid_amt))==0) then first_provider_paid_amt else TRIM(first_provider_paid_amt) end) as first_provider_paid_amt , (case when (LENGTH(trim(first_provider_paid_amt_after))==0) then first_provider_paid_amt_after else TRIM(first_provider_paid_amt_after) end) as first_provider_paid_amt_after , (case when (LENGTH(trim(plan_total_paid_amt))==0) then plan_total_paid_amt else TRIM(plan_total_paid_amt) end) as plan_total_paid_amt , (case when (LENGTH(trim(plan_total_paid_amt_after))==0) then plan_total_paid_amt_after else TRIM(plan_total_paid_amt_after) end) as plan_total_paid_amt_after , (case when (LENGTH(trim(plan_returnd_cost_amt))==0) then plan_returnd_cost_amt else TRIM(plan_returnd_cost_amt) end) as plan_returnd_cost_amt , (case when (LENGTH(trim(plan_returnd_cost_amt_after))==0) then plan_returnd_cost_amt_after else TRIM(plan_returnd_cost_amt_after) end) as plan_returnd_cost_amt_after , (case when (LENGTH(trim(plan_returnd_fee_amt))==0) then plan_returnd_fee_amt else TRIM(plan_returnd_fee_amt) end) as plan_returnd_fee_amt , (case when (LENGTH(trim(plan_returnd_fee_amt_after))==0) then plan_returnd_fee_amt_after else TRIM(plan_returnd_fee_amt_after) end) as plan_returnd_fee_amt_after , (case when (LENGTH(trim(plan_incentive_paid_amt))==0) then plan_incentive_paid_amt else TRIM(plan_incentive_paid_amt) end) as plan_incentive_paid_amt , (case when (LENGTH(trim(plan_incentive_paid_amt_after))==0) then plan_incentive_paid_amt_after else TRIM(plan_incentive_paid_amt_after) end) as plan_incentive_paid_amt_after , (case when (LENGTH(trim(fill_retail_price_amt))==0) then fill_retail_price_amt else TRIM(fill_retail_price_amt) end) as fill_retail_price_amt , (case when (LENGTH(trim(fill_retail_price_amt_after))==0) then fill_retail_price_amt_after else TRIM(fill_retail_price_amt_after) end) as fill_retail_price_amt_after , (case when (LENGTH(trim(pat_rem_ded_amt))==0) then pat_rem_ded_amt else TRIM(pat_rem_ded_amt) end) as pat_rem_ded_amt , (case when (LENGTH(trim(pat_rem_ded_amt_after))==0) then pat_rem_ded_amt_after else TRIM(pat_rem_ded_amt_after) end) as pat_rem_ded_amt_after , (case when (LENGTH(trim(pat_rem_ben_amt))==0) then pat_rem_ben_amt else TRIM(pat_rem_ben_amt) end) as pat_rem_ben_amt , (case when (LENGTH(trim(pat_rem_ben_amt_after))==0) then pat_rem_ben_amt_after else TRIM(pat_rem_ben_amt_after) end) as pat_rem_ben_amt_after , (case when (LENGTH(trim(pat_acc_ded_amt))==0) then pat_acc_ded_amt else TRIM(pat_acc_ded_amt) end) as pat_acc_ded_amt , (case when (LENGTH(trim(pat_acc_ded_amt_after))==0) then pat_acc_ded_amt_after else TRIM(pat_acc_ded_amt_after) end) as pat_acc_ded_amt_after , (case when (LENGTH(trim(pat_ded_applied_amt))==0) then pat_ded_applied_amt else TRIM(pat_ded_applied_amt) end) as pat_ded_applied_amt , (case when (LENGTH(trim(pat_ded_applied_amt_after))==0) then pat_ded_applied_amt_after else TRIM(pat_ded_applied_amt_after) end) as pat_ded_applied_amt_after , (case when (LENGTH(trim(fill_del_adjudication_cd))==0) then fill_del_adjudication_cd else TRIM(fill_del_adjudication_cd) end) as fill_del_adjudication_cd , (case when (LENGTH(trim(fill_del_adjudication_cd_after))==0) then fill_del_adjudication_cd_after else TRIM(fill_del_adjudication_cd_after) end) as fill_del_adjudication_cd_after , (case when (LENGTH(trim(fill_adjudication_cd))==0) then fill_adjudication_cd else TRIM(fill_adjudication_cd) end) as fill_adjudication_cd , (case when (LENGTH(trim(fill_adjudication_cd_after))==0) then fill_adjudication_cd_after else TRIM(fill_adjudication_cd_after) end) as fill_adjudication_cd_after , (case when (LENGTH(trim(claim_reference_nbr))==0) then claim_reference_nbr else TRIM(claim_reference_nbr) end) as claim_reference_nbr , (case when (LENGTH(trim(claim_reference_nbr_after))==0) then claim_reference_nbr_after else TRIM(claim_reference_nbr_after) end) as claim_reference_nbr_after , (case when (LENGTH(trim(plan_returnd_copay_amt))==0) then plan_returnd_copay_amt else TRIM(plan_returnd_copay_amt) end) as plan_returnd_copay_amt , (case when (LENGTH(trim(plan_returnd_copay_amt_after))==0) then plan_returnd_copay_amt_after else TRIM(plan_returnd_copay_amt_after) end) as plan_returnd_copay_amt_after , (case when (LENGTH(trim(plan_returnd_tax_amt))==0) then plan_returnd_tax_amt else TRIM(plan_returnd_tax_amt) end) as plan_returnd_tax_amt , (case when (LENGTH(trim(plan_returnd_tax_amt_after))==0) then plan_returnd_tax_amt_after else TRIM(plan_returnd_tax_amt_after) end) as plan_returnd_tax_amt_after , (case when (LENGTH(trim(fill_sold_amt))==0) then fill_sold_amt else TRIM(fill_sold_amt) end) as fill_sold_amt , (case when (LENGTH(trim(fill_sold_amt_after))==0) then fill_sold_amt_after else TRIM(fill_sold_amt_after) end) as fill_sold_amt_after , (case when (LENGTH(trim(sales_adj_cd))==0) then sales_adj_cd else TRIM(sales_adj_cd) end) as sales_adj_cd , (case when (LENGTH(trim(sales_adj_cd_after))==0) then sales_adj_cd_after else TRIM(sales_adj_cd_after) end) as sales_adj_cd_after , (case when (LENGTH(trim(rx_daw_ind))==0) then rx_daw_ind else TRIM(rx_daw_ind) end) as rx_daw_ind , (case when (LENGTH(trim(rx_daw_ind_after))==0) then rx_daw_ind_after else TRIM(rx_daw_ind_after) end) as rx_daw_ind_after , (case when (LENGTH(trim(claim_reversal_ind))==0) then claim_reversal_ind else TRIM(claim_reversal_ind) end) as claim_reversal_ind , (case when (LENGTH(trim(claim_reversal_ind_after))==0) then claim_reversal_ind_after else TRIM(claim_reversal_ind_after) end) as claim_reversal_ind_after , (case when (LENGTH(trim(place_of_service))==0) then place_of_service else TRIM(place_of_service) end) as place_of_service , (case when (LENGTH(trim(place_of_service_after))==0) then place_of_service_after else TRIM(place_of_service_after) end) as place_of_service_after , (case when (LENGTH(trim(rx_denial_override_cd_2))==0) then rx_denial_override_cd_2 else TRIM(rx_denial_override_cd_2) end) as rx_denial_override_cd_2 , (case when (LENGTH(trim(rx_denial_override_cd_2_after))==0) then rx_denial_override_cd_2_after else TRIM(rx_denial_override_cd_2_after) end) as rx_denial_override_cd_2_after , (case when (LENGTH(trim(rx_denial_override_cd_3))==0) then rx_denial_override_cd_3 else TRIM(rx_denial_override_cd_3) end) as rx_denial_override_cd_3 , (case when (LENGTH(trim(rx_denial_override_cd_3_after))==0) then rx_denial_override_cd_3_after else TRIM(rx_denial_override_cd_3_after) end) as rx_denial_override_cd_3_after , (case when (LENGTH(trim(delay_reason_cd))==0) then delay_reason_cd else TRIM(delay_reason_cd) end) as delay_reason_cd , (case when (LENGTH(trim(delay_reason_cd_after))==0) then delay_reason_cd_after else TRIM(delay_reason_cd_after) end) as delay_reason_cd_after , (case when (LENGTH(trim(plan_returnd_grp_nbr))==0) then plan_returnd_grp_nbr else TRIM(plan_returnd_grp_nbr) end) as plan_returnd_grp_nbr , (case when (LENGTH(trim(plan_returnd_grp_nbr_after))==0) then plan_returnd_grp_nbr_after else TRIM(plan_returnd_grp_nbr_after) end) as plan_returnd_grp_nbr_after , (case when (LENGTH(trim(plan_id_returnd))==0) then plan_id_returnd else TRIM(plan_id_returnd) end) as plan_id_returnd , (case when (LENGTH(trim(plan_id_returnd_after))==0) then plan_id_returnd_after else TRIM(plan_id_returnd_after) end) as plan_id_returnd_after , (case when (LENGTH(trim(ntwk_reimb_id_returnd))==0) then ntwk_reimb_id_returnd else TRIM(ntwk_reimb_id_returnd) end) as ntwk_reimb_id_returnd , (case when (LENGTH(trim(ntwk_reimb_id_returnd_after))==0) then ntwk_reimb_id_returnd_after else TRIM(ntwk_reimb_id_returnd_after) end) as ntwk_reimb_id_returnd_after , (case when (LENGTH(trim(proc_fee_amt))==0) then proc_fee_amt else TRIM(proc_fee_amt) end) as proc_fee_amt , (case when (LENGTH(trim(proc_fee_amt_after))==0) then proc_fee_amt_after else TRIM(proc_fee_amt_after) end) as proc_fee_amt_after , (case when (LENGTH(trim(prvd_ntwk_amt))==0) then prvd_ntwk_amt else TRIM(prvd_ntwk_amt) end) as prvd_ntwk_amt , (case when (LENGTH(trim(prvd_ntwk_amt_after))==0) then prvd_ntwk_amt_after else TRIM(prvd_ntwk_amt_after) end) as prvd_ntwk_amt_after , (case when (LENGTH(trim(prd_brnd_drug_amt))==0) then prd_brnd_drug_amt else TRIM(prd_brnd_drug_amt) end) as prd_brnd_drug_amt , (case when (LENGTH(trim(prd_brnd_drug_amt_after))==0) then prd_brnd_drug_amt_after else TRIM(prd_brnd_drug_amt_after) end) as prd_brnd_drug_amt_after , (case when (LENGTH(trim(npref_prd_form_amt))==0) then npref_prd_form_amt else TRIM(npref_prd_form_amt) end) as npref_prd_form_amt , (case when (LENGTH(trim(npref_prd_form_amt_after))==0) then npref_prd_form_amt_after else TRIM(npref_prd_form_amt_after) end) as npref_prd_form_amt_after , (case when (LENGTH(trim(cov_gap_amt))==0) then cov_gap_amt else TRIM(cov_gap_amt) end) as cov_gap_amt , (case when (LENGTH(trim(cov_gap_amt_after))==0) then cov_gap_amt_after else TRIM(cov_gap_amt_after) end) as cov_gap_amt_after , (case when (LENGTH(trim(plan_fund_assist_amt))==0) then plan_fund_assist_amt else TRIM(plan_fund_assist_amt) end) as plan_fund_assist_amt , (case when (LENGTH(trim(plan_fund_assist_amt_after))==0) then plan_fund_assist_amt_after else TRIM(plan_fund_assist_amt_after) end) as plan_fund_assist_amt_after , (case when (LENGTH(trim(ingrd_cost_contract_amt))==0) then ingrd_cost_contract_amt else TRIM(ingrd_cost_contract_amt) end) as ingrd_cost_contract_amt , (case when (LENGTH(trim(ingrd_cost_contract_amt_after))==0) then ingrd_cost_contract_amt_after else TRIM(ingrd_cost_contract_amt_after) end) as ingrd_cost_contract_amt_after , (case when (LENGTH(trim(disp_fee_contract_amt))==0) then disp_fee_contract_amt else TRIM(disp_fee_contract_amt) end) as disp_fee_contract_amt , (case when (LENGTH(trim(disp_fee_contract_amt_after))==0) then disp_fee_contract_amt_after else TRIM(disp_fee_contract_amt_after) end) as disp_fee_contract_amt_after , (case when (LENGTH(trim(plan_sales_tax_amt))==0) then plan_sales_tax_amt else TRIM(plan_sales_tax_amt) end) as plan_sales_tax_amt , (case when (LENGTH(trim(plan_sales_tax_amt_after))==0) then plan_sales_tax_amt_after else TRIM(plan_sales_tax_amt_after) end) as plan_sales_tax_amt_after , (case when (LENGTH(trim(pat_sales_tax_amt))==0) then pat_sales_tax_amt else TRIM(pat_sales_tax_amt) end) as pat_sales_tax_amt , (case when (LENGTH(trim(pat_sales_tax_amt_after))==0) then pat_sales_tax_amt_after else TRIM(pat_sales_tax_amt_after) end) as pat_sales_tax_amt_after , (case when (LENGTH(trim(other_payer_recognzd_amt))==0) then other_payer_recognzd_amt else TRIM(other_payer_recognzd_amt) end) as other_payer_recognzd_amt , (case when (LENGTH(trim(other_payer_recognzd_amt_after))==0) then other_payer_recognzd_amt_after else TRIM(other_payer_recognzd_amt_after) end) as other_payer_recognzd_amt_after , (case when (LENGTH(trim(ben_stg_ded_amt))==0) then ben_stg_ded_amt else TRIM(ben_stg_ded_amt) end) as ben_stg_ded_amt , (case when (LENGTH(trim(ben_stg_ded_amt_after))==0) then ben_stg_ded_amt_after else TRIM(ben_stg_ded_amt_after) end) as ben_stg_ded_amt_after , (case when (LENGTH(trim(ben_stg_init_cov_amt))==0) then ben_stg_init_cov_amt else TRIM(ben_stg_init_cov_amt) end) as ben_stg_init_cov_amt , (case when (LENGTH(trim(ben_stg_init_cov_amt_after))==0) then ben_stg_init_cov_amt_after else TRIM(ben_stg_init_cov_amt_after) end) as ben_stg_init_cov_amt_after , (case when (LENGTH(trim(ben_stg_cov_gap_amt))==0) then ben_stg_cov_gap_amt else TRIM(ben_stg_cov_gap_amt) end) as ben_stg_cov_gap_amt , (case when (LENGTH(trim(ben_stg_cov_gap_amt_after))==0) then ben_stg_cov_gap_amt_after else TRIM(ben_stg_cov_gap_amt_after) end) as ben_stg_cov_gap_amt_after , (case when (LENGTH(trim(ben_stg_cat_amt))==0) then ben_stg_cat_amt else TRIM(ben_stg_cat_amt) end) as ben_stg_cat_amt , (case when (LENGTH(trim(ben_stg_cat_amt_after))==0) then ben_stg_cat_amt_after else TRIM(ben_stg_cat_amt_after) end) as ben_stg_cat_amt_after , (case when (LENGTH(trim(plan_returnd_coins_amt))==0) then plan_returnd_coins_amt else TRIM(plan_returnd_coins_amt) end) as plan_returnd_coins_amt , (case when (LENGTH(trim(plan_returnd_coins_amt_after))==0) then plan_returnd_coins_amt_after else TRIM(plan_returnd_coins_amt_after) end) as plan_returnd_coins_amt_after , (case when (LENGTH(trim(plan_other_amt_paid_typ2))==0) then plan_other_amt_paid_typ2 else TRIM(plan_other_amt_paid_typ2) end) as plan_other_amt_paid_typ2 , (case when (LENGTH(trim(plan_other_amt_paid_typ2_after))==0) then plan_other_amt_paid_typ2_after else TRIM(plan_other_amt_paid_typ2_after) end) as plan_other_amt_paid_typ2_after , (case when (LENGTH(trim(plan_other_amt_paid_typ3))==0) then plan_other_amt_paid_typ3 else TRIM(plan_other_amt_paid_typ3) end) as plan_other_amt_paid_typ3 , (case when (LENGTH(trim(plan_other_amt_paid_typ3_after))==0) then plan_other_amt_paid_typ3_after else TRIM(plan_other_amt_paid_typ3_after) end) as plan_other_amt_paid_typ3_after , (case when (LENGTH(trim(plan_other_amt_paid_2))==0) then plan_other_amt_paid_2 else TRIM(plan_other_amt_paid_2) end) as plan_other_amt_paid_2 , (case when (LENGTH(trim(plan_other_amt_paid_2_after))==0) then plan_other_amt_paid_2_after else TRIM(plan_other_amt_paid_2_after) end) as plan_other_amt_paid_2_after , (case when (LENGTH(trim(plan_other_amt_paid_3))==0) then plan_other_amt_paid_3 else TRIM(plan_other_amt_paid_3) end) as plan_other_amt_paid_3 , (case when (LENGTH(trim(plan_other_amt_paid_3_after))==0) then plan_other_amt_paid_3_after else TRIM(plan_other_amt_paid_3_after) end) as plan_other_amt_paid_3_after , (case when (LENGTH(trim(phrm_svc_type_cd))==0) then phrm_svc_type_cd else TRIM(phrm_svc_type_cd) end) as phrm_svc_type_cd , (case when (LENGTH(trim(phrm_svc_type_cd_after))==0) then phrm_svc_type_cd_after else TRIM(phrm_svc_type_cd_after) end) as phrm_svc_type_cd_after , (case when (LENGTH(trim(npref_brnd_prd_amt))==0) then npref_brnd_prd_amt else TRIM(npref_brnd_prd_amt) end) as npref_brnd_prd_amt , (case when (LENGTH(trim(npref_brnd_prd_amt_after))==0) then npref_brnd_prd_amt_after else TRIM(npref_brnd_prd_amt_after) end) as npref_brnd_prd_amt_after , (case when (LENGTH(trim(basis_of_reimb_determ))==0) then basis_of_reimb_determ else TRIM(basis_of_reimb_determ) end) as basis_of_reimb_determ , (case when (LENGTH(trim(basis_of_reimb_determ_after))==0) then basis_of_reimb_determ_after else TRIM(basis_of_reimb_determ_after) end) as basis_of_reimb_determ_after , (case when (LENGTH(trim(plan_rtrnd_coins_amt))==0) then plan_rtrnd_coins_amt else TRIM(plan_rtrnd_coins_amt) end) as plan_rtrnd_coins_amt , (case when (LENGTH(trim(plan_rtrnd_coins_amt_after))==0) then plan_rtrnd_coins_amt_after else TRIM(plan_rtrnd_coins_amt_after) end) as plan_rtrnd_coins_amt_after , (case when (LENGTH(trim(plan_incent_amt_submtd))==0) then plan_incent_amt_submtd else TRIM(plan_incent_amt_submtd) end) as plan_incent_amt_submtd , (case when (LENGTH(trim(plan_incent_amt_submtd_after))==0) then plan_incent_amt_submtd_after else TRIM(plan_incent_amt_submtd_after) end) as plan_incent_amt_submtd_after , (case when (LENGTH(trim(plan_gross_due_amt))==0) then plan_gross_due_amt else TRIM(plan_gross_due_amt) end) as plan_gross_due_amt , (case when (LENGTH(trim(plan_gross_due_amt_after))==0) then plan_gross_due_amt_after else TRIM(plan_gross_due_amt_after) end) as plan_gross_due_amt_after , (case when (LENGTH(trim(ben_stg_qualifier_1))==0) then ben_stg_qualifier_1 else TRIM(ben_stg_qualifier_1) end) as ben_stg_qualifier_1 , (case when (LENGTH(trim(ben_stg_qualifier_1_after))==0) then ben_stg_qualifier_1_after else TRIM(ben_stg_qualifier_1_after) end) as ben_stg_qualifier_1_after , (case when (LENGTH(trim(ben_stg_qualifier_2))==0) then ben_stg_qualifier_2 else TRIM(ben_stg_qualifier_2) end) as ben_stg_qualifier_2 , (case when (LENGTH(trim(ben_stg_qualifier_2_after))==0) then ben_stg_qualifier_2_after else TRIM(ben_stg_qualifier_2_after) end) as ben_stg_qualifier_2_after , (case when (LENGTH(trim(ben_stg_qualifier_3))==0) then ben_stg_qualifier_3 else TRIM(ben_stg_qualifier_3) end) as ben_stg_qualifier_3 , (case when (LENGTH(trim(ben_stg_qualifier_3_after))==0) then ben_stg_qualifier_3_after else TRIM(ben_stg_qualifier_3_after) end) as ben_stg_qualifier_3_after , (case when (LENGTH(trim(ben_stg_qualifier_4))==0) then ben_stg_qualifier_4 else TRIM(ben_stg_qualifier_4) end) as ben_stg_qualifier_4 , (case when (LENGTH(trim(ben_stg_qualifier_4_after))==0) then ben_stg_qualifier_4_after else TRIM(ben_stg_qualifier_4_after) end) as ben_stg_qualifier_4_after , (case when (LENGTH(trim(ben_stg_amount_1))==0) then ben_stg_amount_1 else TRIM(ben_stg_amount_1) end) as ben_stg_amount_1 , (case when (LENGTH(trim(ben_stg_amount_1_after))==0) then ben_stg_amount_1_after else TRIM(ben_stg_amount_1_after) end) as ben_stg_amount_1_after , (case when (LENGTH(trim(ben_stg_amount_2))==0) then ben_stg_amount_2 else TRIM(ben_stg_amount_2) end) as ben_stg_amount_2 , (case when (LENGTH(trim(ben_stg_amount_2_after))==0) then ben_stg_amount_2_after else TRIM(ben_stg_amount_2_after) end) as ben_stg_amount_2_after , (case when (LENGTH(trim(ben_stg_amount_3))==0) then ben_stg_amount_3 else TRIM(ben_stg_amount_3) end) as ben_stg_amount_3 , (case when (LENGTH(trim(ben_stg_amount_3_after))==0) then ben_stg_amount_3_after else TRIM(ben_stg_amount_3_after) end) as ben_stg_amount_3_after , (case when (LENGTH(trim(ben_stg_amount_4))==0) then ben_stg_amount_4 else TRIM(ben_stg_amount_4) end) as ben_stg_amount_4 , (case when (LENGTH(trim(ben_stg_amount_4_after))==0) then ben_stg_amount_4_after else TRIM(ben_stg_amount_4_after) end) as ben_stg_amount_4_after , (case when (LENGTH(trim(ws_pipe_id))==0) then ws_pipe_id else TRIM(ws_pipe_id) end) as ws_pipe_id , (case when (LENGTH(trim(ws_pipe_id_after))==0) then ws_pipe_id_after else TRIM(ws_pipe_id_after) end) as ws_pipe_id_after , (case when (LENGTH(trim(coupon_drug_id))==0) then coupon_drug_id else TRIM(coupon_drug_id) end) as coupon_drug_id , (case when (LENGTH(trim(coupon_drug_id_after))==0) then coupon_drug_id_after else TRIM(coupon_drug_id_after) end) as coupon_drug_id_after , (case when (LENGTH(trim(coupon_ind))==0) then coupon_ind else TRIM(coupon_ind) end) as coupon_ind , (case when (LENGTH(trim(coupon_ind_after))==0) then coupon_ind_after else TRIM(coupon_ind_after) end) as coupon_ind_after from dedup_group""" 

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
# display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 


gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
src_partition_nbr_after AS src_partition_nbr , sdl_msg_id_after AS sdl_msg_id , pat_id_after AS pat_id , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_qty_dispensed_after AS fill_qty_dispensed , fill_days_supply_after AS fill_days_supply , fill_enter_dttm_after AS fill_enter_dttm , fill_nbr_dispensed_after AS fill_nbr_dispensed , drug_name_after AS drug_name , drug_ndc_nbr_after AS drug_ndc_nbr , rx_written_dttm_after AS rx_written_dttm , general_pbr_nbr_after AS general_pbr_nbr , submitted_user_id_after AS submitted_user_id , submitted_dttm_after AS submitted_dttm , plan_id_after AS plan_id , plan_group_nbr_after AS plan_group_nbr , general_recipient_nbr_after AS general_recipient_nbr , prior_auth_cd_after AS prior_auth_cd , prior_auth_nbr_after AS prior_auth_nbr , rx_denial_override_cd_after AS rx_denial_override_cd , eligibility_override_cd_after AS eligibility_override_cd , diagnosis_cd_after AS diagnosis_cd , pay_cd_after AS pay_cd , dl_reject_cd_01_after AS dl_reject_cd_01 , dl_reject_reason_01_after AS dl_reject_reason_01 , dl_reject_cd_02_after AS dl_reject_cd_02 , dl_reject_reason_02_after AS dl_reject_reason_02 , dl_reject_cd_03_after AS dl_reject_cd_03 , dl_reject_reason_03_after AS dl_reject_reason_03 , dl_reject_cd_04_after AS dl_reject_cd_04 , dl_reject_reason_04_after AS dl_reject_reason_04 , dl_reject_cd_05_after AS dl_reject_cd_05 , dl_reject_reason_05_after AS dl_reject_reason_05 , dl_proc_msg_after AS dl_proc_msg , dl_additional_msg_after AS dl_additional_msg , dur_conflict_cd_after AS dur_conflict_cd , dur_intervention_cd_after AS dur_intervention_cd , dur_outcome_cd_after AS dur_outcome_cd , other_payer_reject_cd_after AS other_payer_reject_cd , other_coverage_cd_after AS other_coverage_cd , other_payer_cvrg_type_after AS other_payer_cvrg_type , plan_other_amt_paid_type_after AS plan_other_amt_paid_type , plan_other_amt_paid_after AS plan_other_amt_paid , other_payer_id_after AS other_payer_id , other_payer_id_qualifier_after AS other_payer_id_qualifier , first_provider_paid_amt_after AS first_provider_paid_amt , plan_total_paid_amt_after AS plan_total_paid_amt , plan_returnd_cost_amt_after AS plan_returnd_cost_amt , plan_returnd_fee_amt_after AS plan_returnd_fee_amt , plan_incentive_paid_amt_after AS plan_incentive_paid_amt , fill_retail_price_amt_after AS fill_retail_price_amt , pat_rem_ded_amt_after AS pat_rem_ded_amt , pat_rem_ben_amt_after AS pat_rem_ben_amt , pat_acc_ded_amt_after AS pat_acc_ded_amt , pat_ded_applied_amt_after AS pat_ded_applied_amt , fill_del_adjudication_cd_after AS fill_del_adjudication_cd , fill_adjudication_cd_after AS fill_adjudication_cd , claim_reference_nbr_after AS claim_reference_nbr , plan_returnd_copay_amt_after AS plan_returnd_copay_amt , plan_returnd_tax_amt_after AS plan_returnd_tax_amt , fill_sold_amt_after AS fill_sold_amt , sales_adj_cd_after AS sales_adj_cd , rx_daw_ind_after AS rx_daw_ind , claim_reversal_ind_after AS claim_reversal_ind , place_of_service_after AS place_of_service , rx_denial_override_cd_2_after AS rx_denial_override_cd_2 , rx_denial_override_cd_3_after AS rx_denial_override_cd_3 , delay_reason_cd_after AS delay_reason_cd , plan_returnd_grp_nbr_after AS plan_returnd_grp_nbr , plan_id_returnd_after AS plan_id_returnd , ntwk_reimb_id_returnd_after AS ntwk_reimb_id_returnd , proc_fee_amt_after AS proc_fee_amt , prvd_ntwk_amt_after AS prvd_ntwk_amt , prd_brnd_drug_amt_after AS prd_brnd_drug_amt , npref_prd_form_amt_after AS npref_prd_form_amt , cov_gap_amt_after AS cov_gap_amt , plan_fund_assist_amt_after AS plan_fund_assist_amt , ingrd_cost_contract_amt_after AS ingrd_cost_contract_amt , disp_fee_contract_amt_after AS disp_fee_contract_amt , plan_sales_tax_amt_after AS plan_sales_tax_amt , pat_sales_tax_amt_after AS pat_sales_tax_amt , other_payer_recognzd_amt_after AS other_payer_recognzd_amt , ben_stg_ded_amt_after AS ben_stg_ded_amt , ben_stg_init_cov_amt_after AS ben_stg_init_cov_amt , ben_stg_cov_gap_amt_after AS ben_stg_cov_gap_amt , ben_stg_cat_amt_after AS ben_stg_cat_amt , plan_returnd_coins_amt_after AS plan_returnd_coins_amt , plan_other_amt_paid_typ2_after AS plan_other_amt_paid_typ2 , plan_other_amt_paid_typ3_after AS plan_other_amt_paid_typ3 , plan_other_amt_paid_2_after AS plan_other_amt_paid_2 , plan_other_amt_paid_3_after AS plan_other_amt_paid_3 , phrm_svc_type_cd_after AS phrm_svc_type_cd , npref_brnd_prd_amt_after AS npref_brnd_prd_amt , basis_of_reimb_determ_after AS basis_of_reimb_determ , plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt , plan_incent_amt_submtd_after AS plan_incent_amt_submtd , plan_gross_due_amt_after AS plan_gross_due_amt , ben_stg_qualifier_1_after AS ben_stg_qualifier_1 , ben_stg_qualifier_2_after AS ben_stg_qualifier_2 , ben_stg_qualifier_3_after AS ben_stg_qualifier_3 , ben_stg_qualifier_4_after AS ben_stg_qualifier_4 , ben_stg_amount_1_after AS ben_stg_amount_1 , ben_stg_amount_2_after AS ben_stg_amount_2 , ben_stg_amount_3_after AS ben_stg_amount_3 , ben_stg_amount_4_after AS ben_stg_amount_4 , ws_pipe_id_after AS ws_pipe_id , coupon_drug_id_after AS coupon_drug_id , coupon_ind_after AS coupon_ind , 
'000000' AS tracking_id ,
'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,
src_partition_nbr AS src_partition_nbr , sdl_msg_id AS sdl_msg_id , pat_id AS pat_id , store_nbr AS store_nbr , rx_nbr AS rx_nbr , fill_nbr AS fill_nbr , fill_qty_dispensed AS fill_qty_dispensed , fill_days_supply AS fill_days_supply , fill_enter_dttm AS fill_enter_dttm , fill_nbr_dispensed AS fill_nbr_dispensed , drug_name AS drug_name , drug_ndc_nbr AS drug_ndc_nbr , rx_written_dttm AS rx_written_dttm , general_pbr_nbr AS general_pbr_nbr , submitted_user_id AS submitted_user_id , submitted_dttm AS submitted_dttm , plan_id AS plan_id , plan_group_nbr AS plan_group_nbr , general_recipient_nbr AS general_recipient_nbr , prior_auth_cd AS prior_auth_cd , prior_auth_nbr AS prior_auth_nbr , rx_denial_override_cd AS rx_denial_override_cd , eligibility_override_cd AS eligibility_override_cd , diagnosis_cd AS diagnosis_cd , pay_cd AS pay_cd , dl_reject_cd_01 AS dl_reject_cd_01 , dl_reject_reason_01 AS dl_reject_reason_01 , dl_reject_cd_02 AS dl_reject_cd_02 , dl_reject_reason_02 AS dl_reject_reason_02 , dl_reject_cd_03 AS dl_reject_cd_03 , dl_reject_reason_03 AS dl_reject_reason_03 , dl_reject_cd_04 AS dl_reject_cd_04 , dl_reject_reason_04 AS dl_reject_reason_04 , dl_reject_cd_05 AS dl_reject_cd_05 , dl_reject_reason_05 AS dl_reject_reason_05 , dl_proc_msg AS dl_proc_msg , dl_additional_msg AS dl_additional_msg , dur_conflict_cd AS dur_conflict_cd , dur_intervention_cd AS dur_intervention_cd , dur_outcome_cd AS dur_outcome_cd , other_payer_reject_cd AS other_payer_reject_cd , other_coverage_cd AS other_coverage_cd , other_payer_cvrg_type AS other_payer_cvrg_type , plan_other_amt_paid_type AS plan_other_amt_paid_type , plan_other_amt_paid AS plan_other_amt_paid , other_payer_id AS other_payer_id , other_payer_id_qualifier AS other_payer_id_qualifier , first_provider_paid_amt AS first_provider_paid_amt , plan_total_paid_amt AS plan_total_paid_amt , plan_returnd_cost_amt AS plan_returnd_cost_amt , plan_returnd_fee_amt AS plan_returnd_fee_amt , plan_incentive_paid_amt AS plan_incentive_paid_amt , fill_retail_price_amt AS fill_retail_price_amt , pat_rem_ded_amt AS pat_rem_ded_amt , pat_rem_ben_amt AS pat_rem_ben_amt , pat_acc_ded_amt AS pat_acc_ded_amt , pat_ded_applied_amt AS pat_ded_applied_amt , fill_del_adjudication_cd AS fill_del_adjudication_cd , fill_adjudication_cd AS fill_adjudication_cd , claim_reference_nbr AS claim_reference_nbr , plan_returnd_copay_amt AS plan_returnd_copay_amt , plan_returnd_tax_amt AS plan_returnd_tax_amt , fill_sold_amt AS fill_sold_amt , sales_adj_cd AS sales_adj_cd , rx_daw_ind AS rx_daw_ind , claim_reversal_ind AS claim_reversal_ind , place_of_service AS place_of_service , rx_denial_override_cd_2 AS rx_denial_override_cd_2 , rx_denial_override_cd_3 AS rx_denial_override_cd_3 , delay_reason_cd AS delay_reason_cd , plan_returnd_grp_nbr AS plan_returnd_grp_nbr , plan_id_returnd AS plan_id_returnd , ntwk_reimb_id_returnd AS ntwk_reimb_id_returnd , proc_fee_amt AS proc_fee_amt , prvd_ntwk_amt AS prvd_ntwk_amt , prd_brnd_drug_amt AS prd_brnd_drug_amt , npref_prd_form_amt AS npref_prd_form_amt , cov_gap_amt AS cov_gap_amt , plan_fund_assist_amt AS plan_fund_assist_amt , ingrd_cost_contract_amt AS ingrd_cost_contract_amt , disp_fee_contract_amt AS disp_fee_contract_amt , plan_sales_tax_amt AS plan_sales_tax_amt , pat_sales_tax_amt AS pat_sales_tax_amt , other_payer_recognzd_amt AS other_payer_recognzd_amt , ben_stg_ded_amt AS ben_stg_ded_amt , ben_stg_init_cov_amt AS ben_stg_init_cov_amt , ben_stg_cov_gap_amt AS ben_stg_cov_gap_amt , ben_stg_cat_amt AS ben_stg_cat_amt , plan_returnd_coins_amt AS plan_returnd_coins_amt , plan_other_amt_paid_typ2 AS plan_other_amt_paid_typ2 , plan_other_amt_paid_typ3 AS plan_other_amt_paid_typ3 , plan_other_amt_paid_2 AS plan_other_amt_paid_2 , plan_other_amt_paid_3 AS plan_other_amt_paid_3 , phrm_svc_type_cd AS phrm_svc_type_cd , npref_brnd_prd_amt AS npref_brnd_prd_amt , basis_of_reimb_determ AS basis_of_reimb_determ , plan_rtrnd_coins_amt AS plan_rtrnd_coins_amt , plan_incent_amt_submtd AS plan_incent_amt_submtd , plan_gross_due_amt AS plan_gross_due_amt , ben_stg_qualifier_1 AS ben_stg_qualifier_1 , ben_stg_qualifier_2 AS ben_stg_qualifier_2 , ben_stg_qualifier_3 AS ben_stg_qualifier_3 , ben_stg_qualifier_4 AS ben_stg_qualifier_4 , ben_stg_amount_1 AS ben_stg_amount_1 , ben_stg_amount_2 AS ben_stg_amount_2 , ben_stg_amount_3 AS ben_stg_amount_3 , ben_stg_amount_4 AS ben_stg_amount_4 , ws_pipe_id AS ws_pipe_id , coupon_drug_id AS coupon_drug_id , coupon_ind AS coupon_ind ,
'000000' AS tracking_id ,
'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
 src_partition_nbr_after AS src_partition_nbr , sdl_msg_id_after AS sdl_msg_id , pat_id_after AS pat_id , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_qty_dispensed_after AS fill_qty_dispensed , fill_days_supply_after AS fill_days_supply , fill_enter_dttm_after AS fill_enter_dttm , fill_nbr_dispensed_after AS fill_nbr_dispensed , drug_name_after AS drug_name , drug_ndc_nbr_after AS drug_ndc_nbr , rx_written_dttm_after AS rx_written_dttm , general_pbr_nbr_after AS general_pbr_nbr , submitted_user_id_after AS submitted_user_id , submitted_dttm_after AS submitted_dttm , plan_id_after AS plan_id , plan_group_nbr_after AS plan_group_nbr , general_recipient_nbr_after AS general_recipient_nbr , prior_auth_cd_after AS prior_auth_cd , prior_auth_nbr_after AS prior_auth_nbr , rx_denial_override_cd_after AS rx_denial_override_cd , eligibility_override_cd_after AS eligibility_override_cd , diagnosis_cd_after AS diagnosis_cd , pay_cd_after AS pay_cd , dl_reject_cd_01_after AS dl_reject_cd_01 , dl_reject_reason_01_after AS dl_reject_reason_01 , dl_reject_cd_02_after AS dl_reject_cd_02 , dl_reject_reason_02_after AS dl_reject_reason_02 , dl_reject_cd_03_after AS dl_reject_cd_03 , dl_reject_reason_03_after AS dl_reject_reason_03 , dl_reject_cd_04_after AS dl_reject_cd_04 , dl_reject_reason_04_after AS dl_reject_reason_04 , dl_reject_cd_05_after AS dl_reject_cd_05 , dl_reject_reason_05_after AS dl_reject_reason_05 , dl_proc_msg_after AS dl_proc_msg , dl_additional_msg_after AS dl_additional_msg , dur_conflict_cd_after AS dur_conflict_cd , dur_intervention_cd_after AS dur_intervention_cd , dur_outcome_cd_after AS dur_outcome_cd , other_payer_reject_cd_after AS other_payer_reject_cd , other_coverage_cd_after AS other_coverage_cd , other_payer_cvrg_type_after AS other_payer_cvrg_type , plan_other_amt_paid_type_after AS plan_other_amt_paid_type , plan_other_amt_paid_after AS plan_other_amt_paid , other_payer_id_after AS other_payer_id , other_payer_id_qualifier_after AS other_payer_id_qualifier , first_provider_paid_amt_after AS first_provider_paid_amt , plan_total_paid_amt_after AS plan_total_paid_amt , plan_returnd_cost_amt_after AS plan_returnd_cost_amt , plan_returnd_fee_amt_after AS plan_returnd_fee_amt , plan_incentive_paid_amt_after AS plan_incentive_paid_amt , fill_retail_price_amt_after AS fill_retail_price_amt , pat_rem_ded_amt_after AS pat_rem_ded_amt , pat_rem_ben_amt_after AS pat_rem_ben_amt , pat_acc_ded_amt_after AS pat_acc_ded_amt , pat_ded_applied_amt_after AS pat_ded_applied_amt , fill_del_adjudication_cd_after AS fill_del_adjudication_cd , fill_adjudication_cd_after AS fill_adjudication_cd , claim_reference_nbr_after AS claim_reference_nbr , plan_returnd_copay_amt_after AS plan_returnd_copay_amt , plan_returnd_tax_amt_after AS plan_returnd_tax_amt , fill_sold_amt_after AS fill_sold_amt , sales_adj_cd_after AS sales_adj_cd , rx_daw_ind_after AS rx_daw_ind , claim_reversal_ind_after AS claim_reversal_ind , place_of_service_after AS place_of_service , rx_denial_override_cd_2_after AS rx_denial_override_cd_2 , rx_denial_override_cd_3_after AS rx_denial_override_cd_3 , delay_reason_cd_after AS delay_reason_cd , plan_returnd_grp_nbr_after AS plan_returnd_grp_nbr , plan_id_returnd_after AS plan_id_returnd , ntwk_reimb_id_returnd_after AS ntwk_reimb_id_returnd , proc_fee_amt_after AS proc_fee_amt , prvd_ntwk_amt_after AS prvd_ntwk_amt , prd_brnd_drug_amt_after AS prd_brnd_drug_amt , npref_prd_form_amt_after AS npref_prd_form_amt , cov_gap_amt_after AS cov_gap_amt , plan_fund_assist_amt_after AS plan_fund_assist_amt , ingrd_cost_contract_amt_after AS ingrd_cost_contract_amt , disp_fee_contract_amt_after AS disp_fee_contract_amt , plan_sales_tax_amt_after AS plan_sales_tax_amt , pat_sales_tax_amt_after AS pat_sales_tax_amt , other_payer_recognzd_amt_after AS other_payer_recognzd_amt , ben_stg_ded_amt_after AS ben_stg_ded_amt , ben_stg_init_cov_amt_after AS ben_stg_init_cov_amt , ben_stg_cov_gap_amt_after AS ben_stg_cov_gap_amt , ben_stg_cat_amt_after AS ben_stg_cat_amt , plan_returnd_coins_amt_after AS plan_returnd_coins_amt , plan_other_amt_paid_typ2_after AS plan_other_amt_paid_typ2 , plan_other_amt_paid_typ3_after AS plan_other_amt_paid_typ3 , plan_other_amt_paid_2_after AS plan_other_amt_paid_2 , plan_other_amt_paid_3_after AS plan_other_amt_paid_3 , phrm_svc_type_cd_after AS phrm_svc_type_cd , npref_brnd_prd_amt_after AS npref_brnd_prd_amt , basis_of_reimb_determ_after AS basis_of_reimb_determ , plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt , plan_incent_amt_submtd_after AS plan_incent_amt_submtd , plan_gross_due_amt_after AS plan_gross_due_amt , ben_stg_qualifier_1_after AS ben_stg_qualifier_1 , ben_stg_qualifier_2_after AS ben_stg_qualifier_2 , ben_stg_qualifier_3_after AS ben_stg_qualifier_3 , ben_stg_qualifier_4_after AS ben_stg_qualifier_4 , ben_stg_amount_1_after AS ben_stg_amount_1 , ben_stg_amount_2_after AS ben_stg_amount_2 , ben_stg_amount_3_after AS ben_stg_amount_3 , ben_stg_amount_4_after AS ben_stg_amount_4 , ws_pipe_id_after AS ws_pipe_id , coupon_drug_id_after AS coupon_drug_id , coupon_ind_after AS coupon_ind ,
'000000' AS tracking_id ,
'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name 
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)



# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)
#display(etl_tbf0_file)
etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")

  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
# print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))


etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())


#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 
#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

df_correct_time_format = etl_tbf0_reformat_cdc_check_notnull.withColumn("fill_enter_dttm",trim("fill_enter_dttm"))\
                                                            .withColumn("rx_written_dttm",trim("rx_written_dttm"))\
                                                            .withColumn("submitted_dttm",trim("submitted_dttm"))
#display(df_correct_time_format)
df_time_format_corrected = df_correct_time_format.withColumn("fill_enter_dttm",concat(split(col("fill_enter_dttm"),":")[0],split(col("fill_enter_dttm"),":")[1],lit(":"),split(col("fill_enter_dttm"),":")[2],lit(":"),split(col("fill_enter_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("rx_written_dttm",concat(split(col("rx_written_dttm"),":")[0],split(col("rx_written_dttm"),":")[1],lit(":"),split(col("rx_written_dttm"),":")[2],lit(":"),split(col("rx_written_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("submitted_dttm",concat(split(col("submitted_dttm"),":")[0],split(col("submitted_dttm"),":")[1],lit(":"),split(col("submitted_dttm"),":")[2],lit(":"),split(col("submitted_dttm"),":")[3]))
#display(df_time_format_corrected)

# COMMAND ----------

etl_tbf0_reformat_typeCast = df_time_format_corrected.withColumn("cdc_txn_commit_dttm",to_timestamp(df_time_format_corrected["cdc_txn_commit_dttm"]))\
			.withColumn("fill_enter_dttm",to_timestamp(df_time_format_corrected["fill_enter_dttm"]))\
			.withColumn("rx_written_dttm",to_timestamp(df_time_format_corrected["rx_written_dttm"]))\
			.withColumn("submitted_dttm",to_timestamp(df_time_format_corrected["submitted_dttm"]))\
			.withColumn("cdc_operation_type_cd",substring(col("cdc_operation_type_cd"),0,20))\
			.withColumn("cdc_before_after_cd",substring(col("cdc_before_after_cd"),0,10))\
			.withColumn("cdc_txn_position_cd",substring(col("cdc_txn_position_cd"),0,10))\
			.withColumn("sdl_msg_id",substring(col("sdl_msg_id"),0,6))\
			.withColumn("drug_name",substring(col("drug_name"),0,35))\
			.withColumn("drug_ndc_nbr",substring(col("drug_ndc_nbr"),0,11))\
			.withColumn("general_pbr_nbr",substring(col("general_pbr_nbr"),0,15))\
			.withColumn("plan_id",substring(col("plan_id"),0,8))\
			.withColumn("plan_group_nbr",substring(col("plan_group_nbr"),0,15))\
			.withColumn("general_recipient_nbr",substring(col("general_recipient_nbr"),0,21))\
			.withColumn("prior_auth_cd",substring(col("prior_auth_cd"),0,1))\
			.withColumn("prior_auth_nbr",substring(col("prior_auth_nbr"),0,11))\
			.withColumn("rx_denial_override_cd",substring(col("rx_denial_override_cd"),0,2))\
			.withColumn("eligibility_override_cd",substring(col("eligibility_override_cd"),0,1))\
			.withColumn("diagnosis_cd",substring(col("diagnosis_cd"),0,15))\
			.withColumn("pay_cd",substring(col("pay_cd"),0,1))\
			.withColumn("dl_reject_cd_01",substring(col("dl_reject_cd_01"),0,3))\
			.withColumn("dl_reject_reason_01",substring(col("dl_reject_reason_01"),0,100))\
			.withColumn("dl_reject_cd_02",substring(col("dl_reject_cd_02"),0,3))\
			.withColumn("dl_reject_reason_02",substring(col("dl_reject_reason_02"),0,100))\
			.withColumn("dl_reject_cd_03",substring(col("dl_reject_cd_03"),0,3))\
			.withColumn("dl_reject_reason_03",substring(col("dl_reject_reason_03"),0,100))\
			.withColumn("dl_reject_cd_04",substring(col("dl_reject_cd_04"),0,3))\
			.withColumn("dl_reject_reason_04",substring(col("dl_reject_reason_04"),0,100))\
			.withColumn("dl_reject_cd_05",substring(col("dl_reject_cd_05"),0,3))\
			.withColumn("dl_reject_reason_05",substring(col("dl_reject_reason_05"),0,100))\
			.withColumn("dl_proc_msg",substring(col("dl_proc_msg"),0,200))\
			.withColumn("dl_additional_msg",substring(col("dl_additional_msg"),0,1000))\
			.withColumn("dur_conflict_cd",substring(col("dur_conflict_cd"),0,2))\
			.withColumn("dur_intervention_cd",substring(col("dur_intervention_cd"),0,2))\
			.withColumn("dur_outcome_cd",substring(col("dur_outcome_cd"),0,2))\
			.withColumn("other_payer_reject_cd",substring(col("other_payer_reject_cd"),0,3))\
			.withColumn("other_payer_cvrg_type",substring(col("other_payer_cvrg_type"),0,2))\
			.withColumn("plan_other_amt_paid_type",substring(col("plan_other_amt_paid_type"),0,2))\
			.withColumn("other_payer_id",substring(col("other_payer_id"),0,10))\
			.withColumn("other_payer_id_qualifier",substring(col("other_payer_id_qualifier"),0,2))\
			.withColumn("fill_del_adjudication_cd",substring(col("fill_del_adjudication_cd"),0,1))\
			.withColumn("fill_adjudication_cd",substring(col("fill_adjudication_cd"),0,1))\
			.withColumn("claim_reference_nbr",substring(col("claim_reference_nbr"),0,20))\
			.withColumn("sales_adj_cd",substring(col("sales_adj_cd"),0,1))\
			.withColumn("rx_daw_ind",substring(col("rx_daw_ind"),0,1))\
			.withColumn("claim_reversal_ind",substring(col("claim_reversal_ind"),0,1))\
			.withColumn("rx_denial_override_cd_2",substring(col("rx_denial_override_cd_2"),0,2))\
			.withColumn("rx_denial_override_cd_3",substring(col("rx_denial_override_cd_3"),0,2))\
			.withColumn("plan_returnd_grp_nbr",substring(col("plan_returnd_grp_nbr"),0,15))\
			.withColumn("plan_id_returnd",substring(col("plan_id_returnd"),0,8))\
			.withColumn("ntwk_reimb_id_returnd",substring(col("ntwk_reimb_id_returnd"),0,10))\
			.withColumn("plan_other_amt_paid_typ2",substring(col("plan_other_amt_paid_typ2"),0,2))\
			.withColumn("plan_other_amt_paid_typ3",substring(col("plan_other_amt_paid_typ3"),0,2))\
			.withColumn("basis_of_reimb_determ",substring(col("basis_of_reimb_determ"),0,2))\
			.withColumn("ben_stg_qualifier_1",substring(col("ben_stg_qualifier_1"),0,2))\
			.withColumn("ben_stg_qualifier_2",substring(col("ben_stg_qualifier_2"),0,2))\
			.withColumn("ben_stg_qualifier_3",substring(col("ben_stg_qualifier_3"),0,2))\
			.withColumn("ben_stg_qualifier_4",substring(col("ben_stg_qualifier_4"),0,2))\
			.withColumn("coupon_ind",substring(col("coupon_ind"),0,1))
#display(etl_tbf0_reformat_typeCast)			

etl_tbf0_reformat_check_blank = etl_tbf0_reformat_typeCast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_typeCast.columns])
#display(etl_tbf0_reformat_check_blank)


# COMMAND ----------

#drop columns to map table schema
etl_tbf0_reformat_drop_columns = etl_tbf0_reformat_check_blank.drop("tracking_id","partition_column")
#display(etl_tbf0_reformat_drop_columns)

# COMMAND ----------

df_drop_nulls = etl_tbf0_reformat_drop_columns.filter("sdl_msg_id is not null and store_nbr is not null and rx_nbr is not null and fill_nbr is not null and fill_qty_dispensed is not null and fill_days_supply is not null and fill_enter_dttm is not null and submitted_user_id is not null and submitted_dttm is not null")
df_final = df_drop_nulls.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","src_partition_nbr","sdl_msg_id","pat_id","store_nbr","rx_nbr","fill_nbr","fill_qty_dispensed","fill_days_supply","fill_enter_dttm","fill_nbr_dispensed","drug_name","drug_ndc_nbr","rx_written_dttm","general_pbr_nbr","submitted_user_id","submitted_dttm","plan_id","plan_group_nbr","general_recipient_nbr","prior_auth_cd","prior_auth_nbr","rx_denial_override_cd","eligibility_override_cd","diagnosis_cd","pay_cd","dl_reject_cd_01","dl_reject_reason_01","dl_reject_cd_02","dl_reject_reason_02","dl_reject_cd_03","dl_reject_reason_03","dl_reject_cd_04","dl_reject_reason_04","dl_reject_cd_05","dl_reject_reason_05","dl_proc_msg","dl_additional_msg","dur_conflict_cd","dur_intervention_cd","dur_outcome_cd","other_payer_reject_cd","other_coverage_cd","other_payer_cvrg_type","plan_other_amt_paid_type","plan_other_amt_paid","other_payer_id","other_payer_id_qualifier","first_provider_paid_amt","plan_total_paid_amt","plan_returnd_cost_amt","plan_returnd_fee_amt","plan_incentive_paid_amt","fill_retail_price_amt","pat_rem_ded_amt","pat_rem_ben_amt","pat_acc_ded_amt","pat_ded_applied_amt","fill_del_adjudication_cd","fill_adjudication_cd","claim_reference_nbr","plan_returnd_copay_amt","plan_returnd_tax_amt","fill_sold_amt","sales_adj_cd","rx_daw_ind","claim_reversal_ind","place_of_service","rx_denial_override_cd_2","rx_denial_override_cd_3","delay_reason_cd","plan_returnd_grp_nbr","plan_id_returnd","ntwk_reimb_id_returnd","proc_fee_amt","prvd_ntwk_amt","prd_brnd_drug_amt","npref_prd_form_amt","cov_gap_amt","plan_fund_assist_amt","ingrd_cost_contract_amt","disp_fee_contract_amt","plan_sales_tax_amt","pat_sales_tax_amt","other_payer_recognzd_amt","ben_stg_ded_amt","ben_stg_init_cov_amt","ben_stg_cov_gap_amt","ben_stg_cat_amt","plan_returnd_coins_amt","plan_other_amt_paid_typ2","plan_other_amt_paid_typ3","plan_other_amt_paid_2","plan_other_amt_paid_3","phrm_svc_type_cd","npref_brnd_prd_amt","basis_of_reimb_determ","plan_rtrnd_coins_amt","plan_incent_amt_submtd","plan_gross_due_amt","ben_stg_qualifier_1","ben_stg_qualifier_2","ben_stg_qualifier_3","ben_stg_qualifier_4","ben_stg_amount_1","ben_stg_amount_2","ben_stg_amount_3","ben_stg_amount_4","ws_pipe_id","coupon_drug_id","coupon_ind")

# COMMAND ----------

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]
delete_tl_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, TL_SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_tl_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

df_final.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", SNFL_TBL_NAME) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()

TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]
df_final.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", TL_SNFL_TBL_NAME) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()


# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit(PAR_WRITEAPI_VALUE2);
                   
print("Write API successfully executed...")
dbutils.notebook.exit("ETL_TBF0_SDL_HISTORY_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")

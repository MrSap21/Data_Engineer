# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","19981117163100")
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_fill")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","PREPROD_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","PREPROD_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_FILL_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","PREPROD_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","GG_TBF0_FILL")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_FILL,GG_TBF0_FILL_control")
# dbutils.widgets.text("PAR_PIPELINE_NAME","PL_MSTR_PHARMACY_AND_HEALTHCARE_PATIENT_SERVICES_ETL_TBF0_FILL_LOAD")
# dbutils.widgets.text("PAR_READAPI_URL","https://dappreprodappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_SQL_SERVER","dappreprodsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","preproddnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dappreprodsqldb01")
# dbutils.widgets.text("PAR_UnprocessedFiles","1")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dappreprodappservice-appserver.azurewebsites.net/assetUpdate")


# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPINative", 600, 
                  {"PAR_READAPI_KEY":"feedNames",
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_READAPI_VALUE":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A"});


print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]


# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length','cdc_txn_commit_dttm'
,'cdc_txn_commit_dttm_after'
,'cdc_seq_nbr'
,'cdc_seq_nbr_after'
,'cdc_rba_nbr'
,'cdc_rba_nbr_after'
,'cdc_operation_type_cd'
,'cdc_operation_type_cd_after'
,'cdc_before_after_cd'
,'cdc_before_after_cd_after'
,'cdc_txn_position_cd'
,'cdc_txn_position_cd_after'
,'edw_batch_id'
,'edw_batch_id_after'
,'src_partition_nbr'
,'src_partition_nbr_after'
,'store_nbr'
,'store_nbr_after'
,'rx_nbr'
,'rx_nbr_after'
,'fill_nbr'
,'fill_nbr_after'
,'fill_partial_nbr'
,'fill_partial_nbr_after'
,'fill_status_cd'
,'fill_status_cd_after'
,'fill_qty_dispensed'
,'fill_qty_dispensed_after'
,'fill_days_supply'
,'fill_days_supply_after'
,'fill_pay_method_cd'
,'fill_pay_method_cd_after'
,'fill_awp_cost_amt'
,'fill_awp_cost_amt_after'
,'fill_discount_cd'
,'fill_discount_cd_after'
,'fill_discount_amt'
,'fill_discount_amt_after'
,'fill_retail_price_amt'
,'fill_retail_price_amt_after'
,'fill_label_price_amt'
,'fill_label_price_amt_after'
,'fill_price_override_amt'
,'fill_price_override_amt_after'
,'fill_sold_amt'
,'fill_sold_amt_after'
,'fill_savings_amt'
,'fill_savings_amt_after'
,'fill_enter_user_id'
,'fill_enter_user_id_after'
,'fill_enter_dttm'
,'fill_enter_dttm_after'
,'fill_verified_user_id'
,'fill_verified_user_id_after'
,'fill_verified_dttm'
,'fill_verified_dttm_after'
,'fill_sold_dttm'
,'fill_sold_dttm_after'
,'fill_prorated_price_ind'
,'fill_prorated_price_ind_after'
,'fill_adjudication_cd'
,'fill_adjudication_cd_after'
,'plan_id'
,'plan_id_after'
,'claim_reference_nbr'
,'claim_reference_nbr_after'
,'plan_ar_amt'
,'plan_ar_amt_after'
,'plan_copay_amt'
,'plan_copay_amt_after'
,'fill_type_cd'
,'fill_type_cd_after'
,'general_recipient_nbr'
,'general_recipient_nbr_after'
,'plan_tax_amt'
,'plan_tax_amt_after'
,'update_user_id'
,'update_user_id_after'
,'update_dttm'
,'update_dttm_after'
,'partial_fill_cd'
,'partial_fill_cd_after'
,'accept_consult_ind'
,'accept_consult_ind_after'
,'plan_other_amt'
,'plan_other_amt_after'
,'cob_fill_adjudication_cd'
,'cob_fill_adjudication_cd_after'
,'cob_plan_id'
,'cob_plan_id_after'
,'cob_claim_ref_nbr'
,'cob_claim_ref_nbr_after'
,'cob_plan_copay_amt'
,'cob_plan_copay_amt_after'
,'cob_gen_recipient_nbr'
,'cob_gen_recipient_nbr_after'
,'cob_plan_tax_amt'
,'cob_plan_tax_amt_after'
,'cob_plan_ar_amt'
,'cob_plan_ar_amt_after'
,'cash_disc_sav_amt'
,'cash_disc_sav_amt_after'
,'fill_deleted_dttm'
,'fill_deleted_dttm_after'
,'routing_store_tech_inits'
,'routing_store_tech_inits_after'
,'fill_data_rev_id'
,'fill_data_rev_id_after'
,'fill_data_rev_dttm'
,'fill_data_rev_dttm_after'
,'filling_user_id'
,'filling_user_id_after'
,'filling_dttm'
,'filling_dttm_after'
,'override_user_id'
,'override_user_id_after'
,'override_dttm'
,'override_dttm_after'
,'entered_store_nbr'
,'entered_store_nbr_after'
,'reviewed_store_nbr'
,'reviewed_store_nbr_after'
,'fill_nbr_dispensed'
,'fill_nbr_dispensed_after'
,'fax_image_id'
,'fax_image_id_after'
,'dl_reject_cd_01'
,'dl_reject_cd_01_after'
,'cob_dl_reject_cd_01'
,'cob_dl_reject_cd_01_after'
,'fill_adjudication_dttm'
,'fill_adjudication_dttm_after'
,'cob_fill_adj_dttm'
,'cob_fill_adj_dttm_after'
,'data_rev_spec_id'
,'data_rev_spec_id_after'
,'data_rev_spec_dttm'
,'data_rev_spec_dttm_after'
,'data_rev_spec_store_nbr'
,'data_rev_spec_store_nbr_after'
,'fill_rph_of_record_id'
,'fill_rph_of_record_id_after'
,'cob_dl_reject_cd_02'
,'cob_dl_reject_cd_02_after'
,'cob_dl_reject_cd_03'
,'cob_dl_reject_cd_03_after'
,'cob_dl_reject_cd_04'
,'cob_dl_reject_cd_04_after'
,'cob_dl_reject_cd_05'
,'cob_dl_reject_cd_05_after'
,'amt_attributed_to_tax'
,'amt_attributed_to_tax_after'
,'cob_plan_gross_due_amt'
,'cob_plan_gross_due_amt_after'
,'cob_pln_incnt_amt_submtd'
,'cob_pln_incnt_amt_submtd_after'
,'plan_gross_due_amt'
,'plan_gross_due_amt_after'
,'plan_incent_amt_submtd'
,'plan_incent_amt_submtd_after'
,'plan_incentive_paid_amt'
,'plan_incentive_paid_amt_after'
,'plan_other_amt_paid'
,'plan_other_amt_paid_after'
,'plan_returnd_coins_amt'
,'plan_returnd_coins_amt_after'
,'plan_returnd_copay_amt'
,'plan_returnd_copay_amt_after'
,'plan_returnd_cost_amt'
,'plan_returnd_cost_amt_after'
,'plan_returnd_fee_amt'
,'plan_returnd_fee_amt_after'
,'plan_returnd_tax_amt'
,'plan_returnd_tax_amt_after'
,'plan_rtrnd_coins_amt'
,'plan_rtrnd_coins_amt_after'
,'plan_total_paid_amt'
,'plan_total_paid_amt_after'
,'plan_other_amt_paid_type'
,'plan_other_amt_paid_type_after'
,'med_partd_notice_ind'
,'med_partd_notice_ind_after'
,'med_partd_print_dttm'
,'med_partd_print_dttm_after'
,'ben_stg_qualifier_1'
,'ben_stg_qualifier_1_after'
,'ben_stg_qualifier_2'
,'ben_stg_qualifier_2_after'
,'ben_stg_qualifier_3'
,'ben_stg_qualifier_3_after'
,'ben_stg_qualifier_4'
,'ben_stg_qualifier_4_after'
,'ben_stg_amount_1'
,'ben_stg_amount_1_after'
,'ben_stg_amount_2'
,'ben_stg_amount_2_after'
,'ben_stg_amount_3'
,'ben_stg_amount_3_after'
,'ben_stg_amount_4'
,'ben_stg_amount_4_after'
,'coupon_drug_id'
,'coupon_drug_id_after'
,'cob_coupon_drug_id'
,'cob_coupon_drug_id_after'
,'coupon_ind'
,'coupon_ind_after'
,'cob_coupon_ind'
,'cob_coupon_ind_after'
,'other_coverage_cd'
,'other_coverage_cd_after'
,'cob_other_coverage_cd'
,'cob_other_coverage_cd_after'
,'cob_place_of_service'
,'cob_place_of_service_after'
,'cob_rx_denial_ovride_cd'
,'cob_rx_denial_ovride_cd_after'
,'cob_rx_denial_ovride_cd2'
,'cob_rx_denial_ovride_cd2_after'
,'cob_rx_denial_ovride_cd3'
,'cob_rx_denial_ovride_cd3_after'
,'medigap_id'
,'medigap_id_after'
,'pat_pickup_gov_auth_id'
,'pat_pickup_gov_auth_id_after'
,'pat_pickup_rel_cd'
,'pat_pickup_rel_cd_after'
,'place_of_service'
,'place_of_service_after'
,'prior_auth_cd'
,'prior_auth_cd_after'
,'prior_auth_nbr'
,'prior_auth_nbr_after'
,'rx_denial_override_cd'
,'rx_denial_override_cd_after'
,'rx_denial_override_cd_2'
,'rx_denial_override_cd_2_after'
,'rx_denial_override_cd_3'
,'rx_denial_override_cd_3_after'
,'pat_pickup_id_qlfr'
,'pat_pickup_id_qlfr_after'
,'db_bin_nbr'
,'db_bin_nbr_after'
,'db_cob_bin_nbr'
,'db_cob_bin_nbr_after'
,'db_proc_ctrl_nbr'
,'db_proc_ctrl_nbr_after'
,'db_cob_proc_ctrl_nbr'
,'db_cob_proc_ctrl_nbr_after'
,'db_plan_group_nbr'
,'db_plan_group_nbr_after'
,'db_cob_plan_group_nbr'
,'db_cob_plan_group_nbr_after'
,'source_system_name'
,'source_system_name_after'
,'source_sys_trans_id'
,'source_sys_trans_id_after'
,'org_entered_dttm'
,'org_entered_dttm_after'
,'wo_correlation_id'
,'wo_correlation_id_after'
,'wo_rx_count'
,'wo_rx_count_after'
,'short_fill_ind'
,'short_fill_ind_after'
,'pay_cd'
,'pay_cd_after'
,'filling_store_nbr'
,'filling_store_nbr_after'
,'fill_verified_store_nbr'
,'fill_verified_store_nbr_after'
,'mult_prod_review_ind'
,'mult_prod_review_ind_after'
,'pat_selct_user_id'
,'pat_selct_user_id_after'
,'pbr_selct_user_id'
,'pbr_selct_user_id_after'
,'pat_selct_dttm'
,'pat_selct_dttm_after'
,'pbr_selct_dttm'
,'pbr_selct_dttm_after'
,'pat_selct_str_nbr'
,'pat_selct_str_nbr_after'
,'pbr_selct_str_nbr'
,'pbr_selct_str_nbr_after'
,'ntt_ind'
,'ntt_ind_after'
,'multiple_tech_fill_ind'
,'multiple_tech_fill_ind_after'
,'cf_fill_type'
,'cf_fill_type_after'
,'pdmp_sel_ind'
,'pdmp_sel_ind_after'
,'pdmp_click_store_nbr'
,'pdmp_click_store_nbr_after'
,'pdmp_click_user_id'
,'pdmp_click_user_id_after'
,'pdmp_click_dttm'
,'pdmp_click_dttm_after']


print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 297 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 298:
      return True
  else:
    if val_len != 298:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))



if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
#col_len = 290
col_len = 298

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print("Good Records:"+str(rd_good.count()))
print("Bad Records:"+str(rd_bad.count()))

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

#Extarct filename
from pyspark.sql.functions import input_file_name
df = spark.createDataFrame(rd_good, schema)
df_fileName = df.withColumn("fileName",input_file_name())
#Extract partition number from file name



# COMMAND ----------

df_split = df_fileName.withColumn("src_partition_nbr",concat(split(col("fileName"),"_")[6]))
df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df_split = df_split.drop("fileName") 

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df_split = df_split.drop('row_length')
# df_split = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df_split.columns,
#     df_split
#  ))

# COMMAND ----------

df_split.createOrReplaceTempView("gg_tbf0_fill")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_fill where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_fill"))
df_gg.createOrReplaceTempView("raw_gg_tbf0_fill")


# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcGgTbf0Schema

pUpdateReform="(store_nbr == store_nbr_after  AND  store_nbr IS NOT NULL AND  store_nbr_after IS NOT NULL AND   rx_nbr == rx_nbr_after  AND  rx_nbr IS NOT NULL AND  rx_nbr_after IS NOT NULL AND  fill_nbr == fill_nbr_after  AND  fill_nbr IS NOT NULL AND  fill_nbr_after IS NOT NULL AND  fill_partial_nbr == fill_partial_nbr_after  AND  fill_partial_nbr IS NOT NULL AND  fill_partial_nbr_after IS NOT NULL AND  cdc_seq_nbr == cdc_seq_nbr_after  AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL AND  cdc_rba_nbr == cdc_rba_nbr_after  AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL AND  cdc_txn_commit_dttm == cdc_txn_commit_dttm_after   AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL AND  cdc_before_after_cd_after =='AFTER' AND  cdc_before_after_cd_after IS NOT NULL AND  cdc_operation_type_cd_after =='SQL COMPUPDATE' AND  cdc_operation_type_cd_after IS NOT NULL AND   cdc_before_after_cd == 'BEFORE'  AND  cdc_before_after_cd IS NOT NULL AND   cdc_operation_type_cd == 'SQL COMPUPDATE'   AND  cdc_operation_type_cd IS NOT NULL AND  (( RTRIM(LOWER(fill_status_cd)) == RTRIM(LOWER(fill_status_cd_after ))  AND fill_status_cd IS NOT NULL AND fill_status_cd_after IS NOT NULL ) OR ( fill_status_cd IS NULL AND fill_status_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_qty_dispensed)) == RTRIM(LOWER(fill_qty_dispensed_after ))  AND fill_qty_dispensed IS NOT NULL AND fill_qty_dispensed_after IS NOT NULL ) OR ( fill_qty_dispensed IS NULL AND fill_qty_dispensed_after IS NULL )) AND  (( RTRIM(LOWER(fill_days_supply)) == RTRIM(LOWER(fill_days_supply_after ))  AND fill_days_supply IS NOT NULL AND fill_days_supply_after IS NOT NULL ) OR ( fill_days_supply IS NULL AND fill_days_supply_after IS NULL )) AND  (( RTRIM(LOWER(fill_pay_method_cd)) == RTRIM(LOWER(fill_pay_method_cd_after ))  AND fill_pay_method_cd IS NOT NULL AND fill_pay_method_cd_after IS NOT NULL ) OR ( fill_pay_method_cd IS NULL AND fill_pay_method_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_awp_cost_amt)) == RTRIM(LOWER(fill_awp_cost_amt_after ))  AND fill_awp_cost_amt IS NOT NULL AND fill_awp_cost_amt_after IS NOT NULL ) OR ( fill_awp_cost_amt IS NULL AND fill_awp_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_discount_cd)) == RTRIM(LOWER(fill_discount_cd_after ))  AND fill_discount_cd IS NOT NULL AND fill_discount_cd_after IS NOT NULL ) OR ( fill_discount_cd IS NULL AND fill_discount_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_discount_amt)) == RTRIM(LOWER(fill_discount_amt_after ))  AND fill_discount_amt IS NOT NULL AND fill_discount_amt_after IS NOT NULL ) OR ( fill_discount_amt IS NULL AND fill_discount_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_retail_price_amt)) == RTRIM(LOWER(fill_retail_price_amt_after ))  AND fill_retail_price_amt IS NOT NULL AND fill_retail_price_amt_after IS NOT NULL ) OR ( fill_retail_price_amt IS NULL AND fill_retail_price_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_label_price_amt)) == RTRIM(LOWER(fill_label_price_amt_after ))  AND fill_label_price_amt IS NOT NULL AND fill_label_price_amt_after IS NOT NULL ) OR ( fill_label_price_amt IS NULL AND fill_label_price_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_price_override_amt)) == RTRIM(LOWER(fill_price_override_amt_after ))  AND fill_price_override_amt IS NOT NULL AND fill_price_override_amt_after IS NOT NULL ) OR ( fill_price_override_amt IS NULL AND fill_price_override_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_sold_amt)) == RTRIM(LOWER(fill_sold_amt_after ))  AND fill_sold_amt IS NOT NULL AND fill_sold_amt_after IS NOT NULL ) OR ( fill_sold_amt IS NULL AND fill_sold_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_enter_user_id)) == RTRIM(LOWER(fill_enter_user_id_after ))  AND fill_enter_user_id IS NOT NULL AND fill_enter_user_id_after IS NOT NULL ) OR ( fill_enter_user_id IS NULL AND fill_enter_user_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_enter_dttm)) == RTRIM(LOWER(fill_enter_dttm_after ))  AND fill_enter_dttm IS NOT NULL AND fill_enter_dttm_after IS NOT NULL ) OR ( fill_enter_dttm IS NULL AND fill_enter_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_verified_user_id)) == RTRIM(LOWER(fill_verified_user_id_after ))  AND fill_verified_user_id IS NOT NULL AND fill_verified_user_id_after IS NOT NULL ) OR ( fill_verified_user_id IS NULL AND fill_verified_user_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_verified_dttm)) == RTRIM(LOWER(fill_verified_dttm_after ))  AND fill_verified_dttm IS NOT NULL AND fill_verified_dttm_after IS NOT NULL ) OR ( fill_verified_dttm IS NULL AND fill_verified_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_sold_dttm)) == RTRIM(LOWER(fill_sold_dttm_after ))  AND fill_sold_dttm IS NOT NULL AND fill_sold_dttm_after IS NOT NULL ) OR ( fill_sold_dttm IS NULL AND fill_sold_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_adjudication_cd)) == RTRIM(LOWER(fill_adjudication_cd_after ))  AND fill_adjudication_cd IS NOT NULL AND fill_adjudication_cd_after IS NOT NULL ) OR ( fill_adjudication_cd IS NULL AND fill_adjudication_cd_after IS NULL )) AND  (( RTRIM(LOWER(plan_id)) == RTRIM(LOWER(plan_id_after ))  AND plan_id IS NOT NULL AND plan_id_after IS NOT NULL ) OR ( plan_id IS NULL AND plan_id_after IS NULL )) AND  (( RTRIM(LOWER(claim_reference_nbr)) == RTRIM(LOWER(claim_reference_nbr_after ))  AND claim_reference_nbr IS NOT NULL AND claim_reference_nbr_after IS NOT NULL ) OR ( claim_reference_nbr IS NULL AND claim_reference_nbr_after IS NULL )) AND  (( RTRIM(LOWER(plan_ar_amt)) == RTRIM(LOWER(plan_ar_amt_after ))  AND plan_ar_amt IS NOT NULL AND plan_ar_amt_after IS NOT NULL ) OR ( plan_ar_amt IS NULL AND plan_ar_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_copay_amt)) == RTRIM(LOWER(plan_copay_amt_after ))  AND plan_copay_amt IS NOT NULL AND plan_copay_amt_after IS NOT NULL ) OR ( plan_copay_amt IS NULL AND plan_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_type_cd)) == RTRIM(LOWER(fill_type_cd_after ))  AND fill_type_cd IS NOT NULL AND fill_type_cd_after IS NOT NULL ) OR ( fill_type_cd IS NULL AND fill_type_cd_after IS NULL )) AND  (( RTRIM(LOWER(general_recipient_nbr)) == RTRIM(LOWER(general_recipient_nbr_after ))  AND general_recipient_nbr IS NOT NULL AND general_recipient_nbr_after IS NOT NULL ) OR ( general_recipient_nbr IS NULL AND general_recipient_nbr_after IS NULL )) AND  (( RTRIM(LOWER(plan_tax_amt)) == RTRIM(LOWER(plan_tax_amt_after ))  AND plan_tax_amt IS NOT NULL AND plan_tax_amt_after IS NOT NULL ) OR ( plan_tax_amt IS NULL AND plan_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(partial_fill_cd)) == RTRIM(LOWER(partial_fill_cd_after ))  AND partial_fill_cd IS NOT NULL AND partial_fill_cd_after IS NOT NULL ) OR ( partial_fill_cd IS NULL AND partial_fill_cd_after IS NULL )) AND  (( RTRIM(LOWER(accept_consult_ind)) == RTRIM(LOWER(accept_consult_ind_after ))  AND accept_consult_ind IS NOT NULL AND accept_consult_ind_after IS NOT NULL ) OR ( accept_consult_ind IS NULL AND accept_consult_ind_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt)) == RTRIM(LOWER(plan_other_amt_after ))  AND plan_other_amt IS NOT NULL AND plan_other_amt_after IS NOT NULL ) OR ( plan_other_amt IS NULL AND plan_other_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_fill_adjudication_cd)) == RTRIM(LOWER(cob_fill_adjudication_cd_after ))  AND cob_fill_adjudication_cd IS NOT NULL AND cob_fill_adjudication_cd_after IS NOT NULL ) OR ( cob_fill_adjudication_cd IS NULL AND cob_fill_adjudication_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_id)) == RTRIM(LOWER(cob_plan_id_after ))  AND cob_plan_id IS NOT NULL AND cob_plan_id_after IS NOT NULL ) OR ( cob_plan_id IS NULL AND cob_plan_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_claim_ref_nbr)) == RTRIM(LOWER(cob_claim_ref_nbr_after ))  AND cob_claim_ref_nbr IS NOT NULL AND cob_claim_ref_nbr_after IS NOT NULL ) OR ( cob_claim_ref_nbr IS NULL AND cob_claim_ref_nbr_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_copay_amt)) == RTRIM(LOWER(cob_plan_copay_amt_after ))  AND cob_plan_copay_amt IS NOT NULL AND cob_plan_copay_amt_after IS NOT NULL ) OR ( cob_plan_copay_amt IS NULL AND cob_plan_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_gen_recipient_nbr)) == RTRIM(LOWER(cob_gen_recipient_nbr_after ))  AND cob_gen_recipient_nbr IS NOT NULL AND cob_gen_recipient_nbr_after IS NOT NULL ) OR ( cob_gen_recipient_nbr IS NULL AND cob_gen_recipient_nbr_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_tax_amt)) == RTRIM(LOWER(cob_plan_tax_amt_after ))  AND cob_plan_tax_amt IS NOT NULL AND cob_plan_tax_amt_after IS NOT NULL ) OR ( cob_plan_tax_amt IS NULL AND cob_plan_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_ar_amt)) == RTRIM(LOWER(cob_plan_ar_amt_after ))  AND cob_plan_ar_amt IS NOT NULL AND cob_plan_ar_amt_after IS NOT NULL ) OR ( cob_plan_ar_amt IS NULL AND cob_plan_ar_amt_after IS NULL )) AND  (( RTRIM(LOWER(cash_disc_sav_amt)) == RTRIM(LOWER(cash_disc_sav_amt_after ))  AND cash_disc_sav_amt IS NOT NULL AND cash_disc_sav_amt_after IS NOT NULL ) OR ( cash_disc_sav_amt IS NULL AND cash_disc_sav_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_deleted_dttm)) == RTRIM(LOWER(fill_deleted_dttm_after ))  AND fill_deleted_dttm IS NOT NULL AND fill_deleted_dttm_after IS NOT NULL ) OR ( fill_deleted_dttm IS NULL AND fill_deleted_dttm_after IS NULL )) AND  (( RTRIM(LOWER(routing_store_tech_inits)) == RTRIM(LOWER(routing_store_tech_inits_after ))  AND routing_store_tech_inits IS NOT NULL AND routing_store_tech_inits_after IS NOT NULL ) OR ( routing_store_tech_inits IS NULL AND routing_store_tech_inits_after IS NULL )) AND  (( RTRIM(LOWER(fill_data_rev_id)) == RTRIM(LOWER(fill_data_rev_id_after ))  AND fill_data_rev_id IS NOT NULL AND fill_data_rev_id_after IS NOT NULL ) OR ( fill_data_rev_id IS NULL AND fill_data_rev_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_data_rev_dttm)) == RTRIM(LOWER(fill_data_rev_dttm_after ))  AND fill_data_rev_dttm IS NOT NULL AND fill_data_rev_dttm_after IS NOT NULL ) OR ( fill_data_rev_dttm IS NULL AND fill_data_rev_dttm_after IS NULL )) AND  (( RTRIM(LOWER(filling_user_id)) == RTRIM(LOWER(filling_user_id_after ))  AND filling_user_id IS NOT NULL AND filling_user_id_after IS NOT NULL ) OR ( filling_user_id IS NULL AND filling_user_id_after IS NULL )) AND  (( RTRIM(LOWER(filling_dttm)) == RTRIM(LOWER(filling_dttm_after ))  AND filling_dttm IS NOT NULL AND filling_dttm_after IS NOT NULL ) OR ( filling_dttm IS NULL AND filling_dttm_after IS NULL )) AND  (( RTRIM(LOWER(override_user_id)) == RTRIM(LOWER(override_user_id_after ))  AND override_user_id IS NOT NULL AND override_user_id_after IS NOT NULL ) OR ( override_user_id IS NULL AND override_user_id_after IS NULL )) AND  (( RTRIM(LOWER(override_dttm)) == RTRIM(LOWER(override_dttm_after ))  AND override_dttm IS NOT NULL AND override_dttm_after IS NOT NULL ) OR ( override_dttm IS NULL AND override_dttm_after IS NULL )) AND  (( RTRIM(LOWER(entered_store_nbr)) == RTRIM(LOWER(entered_store_nbr_after ))  AND entered_store_nbr IS NOT NULL AND entered_store_nbr_after IS NOT NULL ) OR ( entered_store_nbr IS NULL AND entered_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(reviewed_store_nbr)) == RTRIM(LOWER(reviewed_store_nbr_after ))  AND reviewed_store_nbr IS NOT NULL AND reviewed_store_nbr_after IS NOT NULL ) OR ( reviewed_store_nbr IS NULL AND reviewed_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(fill_nbr_dispensed)) == RTRIM(LOWER(fill_nbr_dispensed_after ))  AND fill_nbr_dispensed IS NOT NULL AND fill_nbr_dispensed_after IS NOT NULL ) OR ( fill_nbr_dispensed IS NULL AND fill_nbr_dispensed_after IS NULL )) AND  (( RTRIM(LOWER(fax_image_id)) == RTRIM(LOWER(fax_image_id_after ))  AND fax_image_id IS NOT NULL AND fax_image_id_after IS NOT NULL ) OR ( fax_image_id IS NULL AND fax_image_id_after IS NULL )) AND  (( RTRIM(LOWER(dl_reject_cd_01)) == RTRIM(LOWER(dl_reject_cd_01_after ))  AND dl_reject_cd_01 IS NOT NULL AND dl_reject_cd_01_after IS NOT NULL ) OR ( dl_reject_cd_01 IS NULL AND dl_reject_cd_01_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_01)) == RTRIM(LOWER(cob_dl_reject_cd_01_after ))  AND cob_dl_reject_cd_01 IS NOT NULL AND cob_dl_reject_cd_01_after IS NOT NULL ) OR ( cob_dl_reject_cd_01 IS NULL AND cob_dl_reject_cd_01_after IS NULL )) AND  (( RTRIM(LOWER(fill_adjudication_dttm)) == RTRIM(LOWER(fill_adjudication_dttm_after ))  AND fill_adjudication_dttm IS NOT NULL AND fill_adjudication_dttm_after IS NOT NULL ) OR ( fill_adjudication_dttm IS NULL AND fill_adjudication_dttm_after IS NULL )) AND  (( RTRIM(LOWER(cob_fill_adj_dttm)) == RTRIM(LOWER(cob_fill_adj_dttm_after ))  AND cob_fill_adj_dttm IS NOT NULL AND cob_fill_adj_dttm_after IS NOT NULL ) OR ( cob_fill_adj_dttm IS NULL AND cob_fill_adj_dttm_after IS NULL )) AND  (( RTRIM(LOWER(data_rev_spec_id)) == RTRIM(LOWER(data_rev_spec_id_after ))  AND data_rev_spec_id IS NOT NULL AND data_rev_spec_id_after IS NOT NULL ) OR ( data_rev_spec_id IS NULL AND data_rev_spec_id_after IS NULL )) AND  (( RTRIM(LOWER(data_rev_spec_dttm)) == RTRIM(LOWER(data_rev_spec_dttm_after ))  AND data_rev_spec_dttm IS NOT NULL AND data_rev_spec_dttm_after IS NOT NULL ) OR ( data_rev_spec_dttm IS NULL AND data_rev_spec_dttm_after IS NULL )) AND  (( RTRIM(LOWER(data_rev_spec_store_nbr)) == RTRIM(LOWER(data_rev_spec_store_nbr_after ))  AND data_rev_spec_store_nbr IS NOT NULL AND data_rev_spec_store_nbr_after IS NOT NULL ) OR ( data_rev_spec_store_nbr IS NULL AND data_rev_spec_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(fill_rph_of_record_id)) == RTRIM(LOWER(fill_rph_of_record_id_after ))  AND fill_rph_of_record_id IS NOT NULL AND fill_rph_of_record_id_after IS NOT NULL ) OR ( fill_rph_of_record_id IS NULL AND fill_rph_of_record_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_02)) == RTRIM(LOWER(cob_dl_reject_cd_02_after ))  AND cob_dl_reject_cd_02 IS NOT NULL AND cob_dl_reject_cd_02_after IS NOT NULL ) OR ( cob_dl_reject_cd_02 IS NULL AND cob_dl_reject_cd_02_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_03)) == RTRIM(LOWER(cob_dl_reject_cd_03_after ))  AND cob_dl_reject_cd_03 IS NOT NULL AND cob_dl_reject_cd_03_after IS NOT NULL ) OR ( cob_dl_reject_cd_03 IS NULL AND cob_dl_reject_cd_03_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_04)) == RTRIM(LOWER(cob_dl_reject_cd_04_after ))  AND cob_dl_reject_cd_04 IS NOT NULL AND cob_dl_reject_cd_04_after IS NOT NULL ) OR ( cob_dl_reject_cd_04 IS NULL AND cob_dl_reject_cd_04_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_05)) == RTRIM(LOWER(cob_dl_reject_cd_05_after ))  AND cob_dl_reject_cd_05 IS NOT NULL AND cob_dl_reject_cd_05_after IS NOT NULL ) OR ( cob_dl_reject_cd_05 IS NULL AND cob_dl_reject_cd_05_after IS NULL )) AND  (( RTRIM(LOWER(amt_attributed_to_tax)) == RTRIM(LOWER(amt_attributed_to_tax_after ))  AND amt_attributed_to_tax IS NOT NULL AND amt_attributed_to_tax_after IS NOT NULL ) OR ( amt_attributed_to_tax IS NULL AND amt_attributed_to_tax_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_gross_due_amt)) == RTRIM(LOWER(cob_plan_gross_due_amt_after ))  AND cob_plan_gross_due_amt IS NOT NULL AND cob_plan_gross_due_amt_after IS NOT NULL ) OR ( cob_plan_gross_due_amt IS NULL AND cob_plan_gross_due_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_pln_incnt_amt_submtd)) == RTRIM(LOWER(cob_pln_incnt_amt_submtd_after ))  AND cob_pln_incnt_amt_submtd IS NOT NULL AND cob_pln_incnt_amt_submtd_after IS NOT NULL ) OR ( cob_pln_incnt_amt_submtd IS NULL AND cob_pln_incnt_amt_submtd_after IS NULL )) AND  (( RTRIM(LOWER(plan_gross_due_amt)) == RTRIM(LOWER(plan_gross_due_amt_after ))  AND plan_gross_due_amt IS NOT NULL AND plan_gross_due_amt_after IS NOT NULL ) OR ( plan_gross_due_amt IS NULL AND plan_gross_due_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_incent_amt_submtd)) == RTRIM(LOWER(plan_incent_amt_submtd_after ))  AND plan_incent_amt_submtd IS NOT NULL AND plan_incent_amt_submtd_after IS NOT NULL ) OR ( plan_incent_amt_submtd IS NULL AND plan_incent_amt_submtd_after IS NULL )) AND  (( RTRIM(LOWER(plan_incentive_paid_amt)) == RTRIM(LOWER(plan_incentive_paid_amt_after ))  AND plan_incentive_paid_amt IS NOT NULL AND plan_incentive_paid_amt_after IS NOT NULL ) OR ( plan_incentive_paid_amt IS NULL AND plan_incentive_paid_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid)) == RTRIM(LOWER(plan_other_amt_paid_after ))  AND plan_other_amt_paid IS NOT NULL AND plan_other_amt_paid_after IS NOT NULL ) OR ( plan_other_amt_paid IS NULL AND plan_other_amt_paid_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_coins_amt)) == RTRIM(LOWER(plan_returnd_coins_amt_after ))  AND plan_returnd_coins_amt IS NOT NULL AND plan_returnd_coins_amt_after IS NOT NULL ) OR ( plan_returnd_coins_amt IS NULL AND plan_returnd_coins_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_copay_amt)) == RTRIM(LOWER(plan_returnd_copay_amt_after ))  AND plan_returnd_copay_amt IS NOT NULL AND plan_returnd_copay_amt_after IS NOT NULL ) OR ( plan_returnd_copay_amt IS NULL AND plan_returnd_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_cost_amt)) == RTRIM(LOWER(plan_returnd_cost_amt_after ))  AND plan_returnd_cost_amt IS NOT NULL AND plan_returnd_cost_amt_after IS NOT NULL ) OR ( plan_returnd_cost_amt IS NULL AND plan_returnd_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_fee_amt)) == RTRIM(LOWER(plan_returnd_fee_amt_after ))  AND plan_returnd_fee_amt IS NOT NULL AND plan_returnd_fee_amt_after IS NOT NULL ) OR ( plan_returnd_fee_amt IS NULL AND plan_returnd_fee_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_tax_amt)) == RTRIM(LOWER(plan_returnd_tax_amt_after ))  AND plan_returnd_tax_amt IS NOT NULL AND plan_returnd_tax_amt_after IS NOT NULL ) OR ( plan_returnd_tax_amt IS NULL AND plan_returnd_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_rtrnd_coins_amt)) == RTRIM(LOWER(plan_rtrnd_coins_amt_after ))  AND plan_rtrnd_coins_amt IS NOT NULL AND plan_rtrnd_coins_amt_after IS NOT NULL ) OR ( plan_rtrnd_coins_amt IS NULL AND plan_rtrnd_coins_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_total_paid_amt)) == RTRIM(LOWER(plan_total_paid_amt_after ))  AND plan_total_paid_amt IS NOT NULL AND plan_total_paid_amt_after IS NOT NULL ) OR ( plan_total_paid_amt IS NULL AND plan_total_paid_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid_type)) == RTRIM(LOWER(plan_other_amt_paid_type_after ))  AND plan_other_amt_paid_type IS NOT NULL AND plan_other_amt_paid_type_after IS NOT NULL ) OR ( plan_other_amt_paid_type IS NULL AND plan_other_amt_paid_type_after IS NULL )) AND  (( RTRIM(LOWER(med_partd_notice_ind)) == RTRIM(LOWER(med_partd_notice_ind_after ))  AND med_partd_notice_ind IS NOT NULL AND med_partd_notice_ind_after IS NOT NULL ) OR ( med_partd_notice_ind IS NULL AND med_partd_notice_ind_after IS NULL )) AND  (( RTRIM(LOWER(med_partd_print_dttm)) == RTRIM(LOWER(med_partd_print_dttm_after ))  AND med_partd_print_dttm IS NOT NULL AND med_partd_print_dttm_after IS NOT NULL ) OR ( med_partd_print_dttm IS NULL AND med_partd_print_dttm_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_1)) == RTRIM(LOWER(ben_stg_qualifier_1_after ))  AND ben_stg_qualifier_1 IS NOT NULL AND ben_stg_qualifier_1_after IS NOT NULL ) OR ( ben_stg_qualifier_1 IS NULL AND ben_stg_qualifier_1_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_2)) == RTRIM(LOWER(ben_stg_qualifier_2_after ))  AND ben_stg_qualifier_2 IS NOT NULL AND ben_stg_qualifier_2_after IS NOT NULL ) OR ( ben_stg_qualifier_2 IS NULL AND ben_stg_qualifier_2_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_3)) == RTRIM(LOWER(ben_stg_qualifier_3_after ))  AND ben_stg_qualifier_3 IS NOT NULL AND ben_stg_qualifier_3_after IS NOT NULL ) OR ( ben_stg_qualifier_3 IS NULL AND ben_stg_qualifier_3_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_4)) == RTRIM(LOWER(ben_stg_qualifier_4_after ))  AND ben_stg_qualifier_4 IS NOT NULL AND ben_stg_qualifier_4_after IS NOT NULL ) OR ( ben_stg_qualifier_4 IS NULL AND ben_stg_qualifier_4_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_1)) == RTRIM(LOWER(ben_stg_amount_1_after ))  AND ben_stg_amount_1 IS NOT NULL AND ben_stg_amount_1_after IS NOT NULL ) OR ( ben_stg_amount_1 IS NULL AND ben_stg_amount_1_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_2)) == RTRIM(LOWER(ben_stg_amount_2_after ))  AND ben_stg_amount_2 IS NOT NULL AND ben_stg_amount_2_after IS NOT NULL ) OR ( ben_stg_amount_2 IS NULL AND ben_stg_amount_2_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_3)) == RTRIM(LOWER(ben_stg_amount_3_after ))  AND ben_stg_amount_3 IS NOT NULL AND ben_stg_amount_3_after IS NOT NULL ) OR ( ben_stg_amount_3 IS NULL AND ben_stg_amount_3_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_4)) == RTRIM(LOWER(ben_stg_amount_4_after ))  AND ben_stg_amount_4 IS NOT NULL AND ben_stg_amount_4_after IS NOT NULL ) OR ( ben_stg_amount_4 IS NULL AND ben_stg_amount_4_after IS NULL )) AND  (( RTRIM(LOWER(coupon_drug_id)) == RTRIM(LOWER(coupon_drug_id_after ))  AND coupon_drug_id IS NOT NULL AND coupon_drug_id_after IS NOT NULL ) OR ( coupon_drug_id IS NULL AND coupon_drug_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_coupon_drug_id)) == RTRIM(LOWER(cob_coupon_drug_id_after ))  AND cob_coupon_drug_id IS NOT NULL AND cob_coupon_drug_id_after IS NOT NULL ) OR ( cob_coupon_drug_id IS NULL AND cob_coupon_drug_id_after IS NULL )) AND  (( RTRIM(LOWER(coupon_ind)) == RTRIM(LOWER(coupon_ind_after ))  AND coupon_ind IS NOT NULL AND coupon_ind_after IS NOT NULL ) OR ( coupon_ind IS NULL AND coupon_ind_after IS NULL )) AND  (( RTRIM(LOWER(cob_coupon_ind)) == RTRIM(LOWER(cob_coupon_ind_after ))  AND cob_coupon_ind IS NOT NULL AND cob_coupon_ind_after IS NOT NULL ) OR ( cob_coupon_ind IS NULL AND cob_coupon_ind_after IS NULL )) AND  (( RTRIM(LOWER(other_coverage_cd)) == RTRIM(LOWER(other_coverage_cd_after ))  AND other_coverage_cd IS NOT NULL AND other_coverage_cd_after IS NOT NULL ) OR ( other_coverage_cd IS NULL AND other_coverage_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_other_coverage_cd)) == RTRIM(LOWER(cob_other_coverage_cd_after ))  AND cob_other_coverage_cd IS NOT NULL AND cob_other_coverage_cd_after IS NOT NULL ) OR ( cob_other_coverage_cd IS NULL AND cob_other_coverage_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_gov_auth_id)) == RTRIM(LOWER(pat_pickup_gov_auth_id_after ))  AND pat_pickup_gov_auth_id IS NOT NULL AND pat_pickup_gov_auth_id_after IS NOT NULL ) OR ( pat_pickup_gov_auth_id IS NULL AND pat_pickup_gov_auth_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_rel_cd)) == RTRIM(LOWER(pat_pickup_rel_cd_after ))  AND pat_pickup_rel_cd IS NOT NULL AND pat_pickup_rel_cd_after IS NOT NULL ) OR ( pat_pickup_rel_cd IS NULL AND pat_pickup_rel_cd_after IS NULL )) AND  (( RTRIM(LOWER(prior_auth_cd)) == RTRIM(LOWER(prior_auth_cd_after ))  AND prior_auth_cd IS NOT NULL AND prior_auth_cd_after IS NOT NULL ) OR ( prior_auth_cd IS NULL AND prior_auth_cd_after IS NULL )) AND  (( RTRIM(LOWER(prior_auth_nbr)) == RTRIM(LOWER(prior_auth_nbr_after ))  AND prior_auth_nbr IS NOT NULL AND prior_auth_nbr_after IS NOT NULL ) OR ( prior_auth_nbr IS NULL AND prior_auth_nbr_after IS NULL )) AND  (( RTRIM(LOWER(rx_denial_override_cd)) == RTRIM(LOWER(rx_denial_override_cd_after ))  AND rx_denial_override_cd IS NOT NULL AND rx_denial_override_cd_after IS NOT NULL ) OR ( rx_denial_override_cd IS NULL AND rx_denial_override_cd_after IS NULL )) AND (( RTRIM(LOWER(rx_denial_override_cd_2)) == RTRIM(LOWER(rx_denial_override_cd_2_after ))  AND rx_denial_override_cd_2 IS NOT NULL AND rx_denial_override_cd_2_after IS NOT NULL ) OR ( rx_denial_override_cd_2 IS NULL AND rx_denial_override_cd_2_after IS NULL )) AND (( RTRIM(LOWER(rx_denial_override_cd_3)) == RTRIM(LOWER(rx_denial_override_cd_3_after ))  AND rx_denial_override_cd_3 IS NOT NULL AND rx_denial_override_cd_3_after IS NOT NULL ) OR ( rx_denial_override_cd_3 IS NULL AND rx_denial_override_cd_3_after IS NULL )) AND (( RTRIM(LOWER(pat_pickup_id_qlfr)) == RTRIM(LOWER(pat_pickup_id_qlfr_after ))  AND pat_pickup_id_qlfr IS NOT NULL AND pat_pickup_id_qlfr_after IS NOT NULL ) OR ( pat_pickup_id_qlfr IS NULL AND pat_pickup_id_qlfr_after IS NULL )) AND  (( RTRIM(LOWER(source_system_name)) == RTRIM(LOWER(source_system_name_after ))  AND source_system_name IS NOT NULL AND source_system_name_after IS NOT NULL ) OR ( source_system_name IS NULL AND source_system_name_after IS NULL )) AND  (( RTRIM(LOWER(source_sys_trans_id)) == RTRIM(LOWER(source_sys_trans_id_after ))  AND source_sys_trans_id IS NOT NULL AND source_sys_trans_id_after IS NOT NULL ) OR ( source_sys_trans_id IS NULL AND source_sys_trans_id_after IS NULL )) AND  (( RTRIM(LOWER(org_entered_dttm)) == RTRIM(LOWER(org_entered_dttm_after ))  AND org_entered_dttm IS NOT NULL AND org_entered_dttm_after IS NOT NULL ) OR ( org_entered_dttm IS NULL AND org_entered_dttm_after IS NULL )) AND  (( RTRIM(LOWER(wo_correlation_id)) == RTRIM(LOWER(wo_correlation_id_after ))  AND wo_correlation_id IS NOT NULL AND wo_correlation_id_after IS NOT NULL ) OR ( wo_correlation_id IS NULL AND wo_correlation_id_after IS NULL )) AND  (( RTRIM(LOWER(wo_rx_count)) == RTRIM(LOWER(wo_rx_count_after ))  AND wo_rx_count IS NOT NULL AND wo_rx_count_after IS NOT NULL ) OR ( wo_rx_count IS NULL AND wo_rx_count_after IS NULL )) AND  (( RTRIM(LOWER(short_fill_ind)) == RTRIM(LOWER(short_fill_ind_after ))  AND short_fill_ind IS NOT NULL AND short_fill_ind_after IS NOT NULL ) OR ( short_fill_ind IS NULL AND short_fill_ind_after IS NULL )) AND  (( RTRIM(LOWER(pay_cd)) == RTRIM(LOWER(pay_cd_after ))  AND pay_cd IS NOT NULL AND pay_cd_after IS NOT NULL ) OR ( pay_cd IS NULL AND pay_cd_after IS NULL )) AND  (( RTRIM(LOWER(filling_store_nbr)) == RTRIM(LOWER(filling_store_nbr_after )) AND filling_store_nbr IS NOT NULL AND filling_store_nbr_after IS NOT NULL ) OR ( filling_store_nbr IS NULL AND filling_store_nbr_after IS NULL )) AND (( RTRIM(LOWER(fill_verified_store_nbr)) == RTRIM(LOWER(fill_verified_store_nbr_after ))  AND fill_verified_store_nbr IS NOT NULL AND fill_verified_store_nbr_after IS NOT NULL ) OR ( fill_verified_store_nbr IS NULL AND fill_verified_store_nbr_after IS NULL )) AND (( RTRIM(LOWER(mult_prod_review_ind)) == RTRIM(LOWER(mult_prod_review_ind_after ))  AND mult_prod_review_ind IS NOT NULL AND mult_prod_review_ind_after IS NOT NULL ) OR ( mult_prod_review_ind IS NULL AND mult_prod_review_ind_after IS NULL )) AND (( RTRIM(LOWER(pat_selct_user_id)) == RTRIM(LOWER(pat_selct_user_id_after )) AND pat_selct_user_id IS NOT NULL AND pat_selct_user_id_after IS NOT NULL ) OR ( pat_selct_user_id IS NULL AND pat_selct_user_id_after IS NULL )) AND (( RTRIM(LOWER(pbr_selct_user_id)) == RTRIM(LOWER(pbr_selct_user_id_after )) AND pbr_selct_user_id IS NOT NULL AND pbr_selct_user_id_after IS NOT NULL ) OR ( pbr_selct_user_id IS NULL AND pbr_selct_user_id_after IS NULL )) AND (( RTRIM(LOWER(pat_selct_dttm)) == RTRIM(LOWER(pat_selct_dttm_after )) AND pat_selct_dttm IS NOT NULL AND pat_selct_dttm_after IS NOT NULL ) OR ( pat_selct_dttm IS NULL AND pat_selct_dttm_after IS NULL )) AND (( RTRIM(LOWER(pbr_selct_dttm)) == RTRIM(LOWER(pbr_selct_dttm_after )) AND pbr_selct_dttm IS NOT NULL AND pbr_selct_dttm_after IS NOT NULL ) OR ( pbr_selct_dttm IS NULL AND pbr_selct_dttm_after IS NULL )) AND (( RTRIM(LOWER(pat_selct_str_nbr)) == RTRIM(LOWER(pat_selct_str_nbr_after )) AND pat_selct_str_nbr IS NOT NULL AND pat_selct_str_nbr_after IS NOT NULL ) OR ( pat_selct_str_nbr IS NULL AND pat_selct_str_nbr_after IS NULL )) AND (( RTRIM(LOWER(pbr_selct_str_nbr)) == RTRIM(LOWER(pbr_selct_str_nbr_after )) AND pbr_selct_str_nbr IS NOT NULL AND pbr_selct_str_nbr_after IS NOT NULL ) OR ( pbr_selct_str_nbr IS NULL AND pbr_selct_str_nbr_after IS NULL )) AND (( RTRIM(LOWER(ntt_ind)) == RTRIM(LOWER(ntt_ind_after )) AND ntt_ind IS NOT NULL AND ntt_ind_after IS NOT NULL ) OR ( ntt_ind IS NULL AND ntt_ind_after IS NULL )) )"


#pSrcCleanseXfr

#pTgtUpdBfrXfr

#pTgtUpdAftXfr

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm , cdc_seq_nbr , cdc_rba_nbr , cdc_operation_type_cd , cdc_before_after_cd , cdc_txn_position_cd , edw_batch_id , store_nbr , rx_nbr , fill_nbr , fill_partial_nbr , fill_status_cd , fill_qty_dispensed , fill_awp_cost_amt , fill_discount_cd , fill_discount_amt , fill_retail_price_amt , fill_sold_amt , fill_enter_user_id , CONCAT(fill_enter_dttm,'.000000') AS fill_enter_dttm , fill_verified_user_id , CONCAT(fill_verified_dttm,'.000000') AS fill_verified_dttm , CONCAT(fill_sold_dttm,'.000000') AS fill_sold_dttm , plan_id , fill_type_cd , partial_fill_cd , CONCAT(fill_deleted_dttm,'.000000') AS fill_deleted_dttm , fill_data_rev_id , CONCAT(fill_data_rev_dttm,'.000000') AS fill_data_rev_dttm , filling_user_id , CONCAT(filling_dttm,'.000000') AS filling_dttm, entered_store_nbr , reviewed_store_nbr , fill_nbr_dispensed , CONCAT(fill_adjudication_dttm,'.000000') AS fill_adjudication_dttm , fill_adjudication_cd , cob_claim_ref_nbr , claim_reference_nbr , update_user_id , CONCAT(update_dttm,'.000000') AS update_dttm, cob_fill_adjudication_cd , cob_plan_id , override_user_id , CONCAT(override_dttm,'.000000') AS override_dttm , CONCAT(cob_fill_adj_dttm,'.000000') AS cob_fill_adj_dttm , src_partition_nbr , fill_days_supply , fill_label_price_amt , fill_pay_method_cd , plan_ar_amt , plan_copay_amt , plan_tax_amt , cob_plan_ar_amt , cob_plan_copay_amt , cob_plan_tax_amt , fill_price_override_amt, general_recipient_nbr , accept_consult_ind , plan_other_amt , cash_disc_sav_amt , routing_store_tech_inits , fax_image_id , dl_reject_cd_01 , cob_dl_reject_cd_01 , data_rev_spec_id, data_rev_spec_store_nbr , fill_rph_of_record_id , CONCAT(data_rev_spec_dttm,'.000000') AS data_rev_spec_dttm, (CASE WHEN (cdc_operation_type_cd=='INSERT') THEN store_nbr ELSE '' END) AS relocate_fm_str_nbr , cob_gen_recipient_nbr , cob_dl_reject_cd_02 , cob_dl_reject_cd_03 , cob_dl_reject_cd_04 , cob_dl_reject_cd_05 , amt_attributed_to_tax , cob_plan_gross_due_amt , cob_pln_incnt_amt_submtd , plan_gross_due_amt , plan_incent_amt_submtd , plan_incentive_paid_amt , plan_other_amt_paid , plan_returnd_coins_amt , plan_returnd_copay_amt , plan_returnd_cost_amt , plan_returnd_fee_amt , plan_returnd_tax_amt , plan_rtrnd_coins_amt , plan_total_paid_amt , plan_other_amt_paid_type , med_partd_notice_ind , CONCAT(med_partd_print_dttm,'.000000') AS med_partd_print_dttm, ben_stg_qualifier_1 , ben_stg_qualifier_2 , ben_stg_qualifier_3 , ben_stg_qualifier_4 , ben_stg_amount_1 , ben_stg_amount_2 , ben_stg_amount_3 , ben_stg_amount_4 , coupon_drug_id , cob_coupon_drug_id , coupon_ind , cob_coupon_ind , other_coverage_cd , cob_other_coverage_cd , CONCAT(org_entered_dttm,'.000000') AS org_entered_dttm , pat_pickup_gov_auth_id , pat_pickup_id_qlfr , pat_pickup_rel_cd , source_system_name , source_sys_trans_id , prior_auth_cd , prior_auth_nbr , TRIM(db_bin_nbr) AS db_bin_nbr , TRIM(db_cob_bin_nbr) AS db_cob_bin_nbr , TRIM(db_plan_group_nbr) AS db_plan_group_nbr , TRIM(db_cob_plan_group_nbr) AS db_cob_plan_group_nbr , TRIM(db_proc_ctrl_nbr) AS db_proc_ctrl_nbr , TRIM(db_cob_proc_ctrl_nbr) AS db_cob_proc_ctrl_nbr , wo_correlation_id , wo_rx_count , short_fill_ind , TRIM(rx_denial_override_cd) AS rx_denial_override_cd , TRIM(rx_denial_override_cd_2) AS rx_denial_override_cd_2 , TRIM(rx_denial_override_cd_3) AS rx_denial_override_cd_3 , TRIM(pay_cd) as pay_cd, TRIM(filling_store_nbr) as filling_store_nbr, TRIM(fill_verified_store_nbr) as fill_verified_store_nbr, TRIM(mult_prod_review_ind) as mult_prod_review_ind, TRIM(pat_selct_user_id) as pat_selct_user_id, TRIM(pbr_selct_user_id) as pbr_selct_user_id, CONCAT(substring(pat_selct_dttm,0,10),' ',substring(pat_selct_dttm,12,19),'.000') as pat_selct_dttm, CONCAT(substring(pbr_selct_dttm,0,10),' ',substring(pbr_selct_dttm,12,19),'.000') AS pbr_selct_dttm, TRIM(pat_selct_str_nbr) as pat_selct_str_nbr, TRIM(pbr_selct_str_nbr) as pbr_selct_str_nbr, TRIM(ntt_ind) as ntt_ind, tracking_id, partition_column" 



# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == PROJ_ID))

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
rx_trans_max = cutoff_range_trans.select("rx_trans_max")



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_fill where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_fill where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_fill where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) 
  #rx_max = to_timestamxp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)


  #Remove duplicates
dedup_group = nr_input_file_final.distinct()


dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")


# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim(src_partition_nbr)) ==0) then  src_partition_nbr else trim(src_partition_nbr) end) as src_partition_nbr ,
(case when (LENGTH(trim(src_partition_nbr_after)) ==0) then  src_partition_nbr_after else trim(src_partition_nbr_after) end) as src_partition_nbr_after ,
(case when (LENGTH(trim(store_nbr)) ==0) then  store_nbr else trim(store_nbr) end) as store_nbr ,
(case when (LENGTH(trim(store_nbr_after)) ==0) then  store_nbr_after else trim(store_nbr_after) end) as store_nbr_after ,
(case when (LENGTH(trim(rx_nbr)) ==0) then  rx_nbr else trim(rx_nbr) end) as rx_nbr ,
(case when (LENGTH(trim(rx_nbr_after)) ==0) then  rx_nbr_after else trim(rx_nbr_after) end) as rx_nbr_after ,
(case when (LENGTH(trim(fill_nbr)) ==0) then  fill_nbr else trim(fill_nbr) end) as fill_nbr ,
(case when (LENGTH(trim(fill_nbr_after)) ==0) then  fill_nbr_after else trim(fill_nbr_after) end) as fill_nbr_after ,
(case when (LENGTH(trim(fill_partial_nbr)) ==0) then  fill_partial_nbr else trim(fill_partial_nbr) end) as fill_partial_nbr ,
(case when (LENGTH(trim(fill_partial_nbr_after)) ==0) then  fill_partial_nbr_after else trim(fill_partial_nbr_after) end) as fill_partial_nbr_after ,
(case when (LENGTH(trim(fill_status_cd)) ==0) then  fill_status_cd else trim(fill_status_cd) end) as fill_status_cd ,
(case when (LENGTH(trim(fill_status_cd_after)) ==0) then  fill_status_cd_after else trim(fill_status_cd_after) end) as fill_status_cd_after ,
(case when (LENGTH(trim(fill_qty_dispensed)) ==0) then  fill_qty_dispensed else trim(fill_qty_dispensed) end) as fill_qty_dispensed ,
(case when (LENGTH(trim(fill_qty_dispensed_after)) ==0) then  fill_qty_dispensed_after else trim(fill_qty_dispensed_after) end) as fill_qty_dispensed_after ,
(case when (LENGTH(trim(fill_days_supply)) ==0) then  fill_days_supply else trim(fill_days_supply) end) as fill_days_supply ,
(case when (LENGTH(trim(fill_days_supply_after)) ==0) then  fill_days_supply_after else trim(fill_days_supply_after) end) as fill_days_supply_after ,
(case when (LENGTH(trim(fill_pay_method_cd)) ==0) then  fill_pay_method_cd else trim(fill_pay_method_cd) end) as fill_pay_method_cd ,
(case when (LENGTH(trim(fill_pay_method_cd_after)) ==0) then  fill_pay_method_cd_after else trim(fill_pay_method_cd_after) end) as fill_pay_method_cd_after ,
(case when (LENGTH(trim(fill_awp_cost_amt)) ==0) then  fill_awp_cost_amt else trim(fill_awp_cost_amt) end) as fill_awp_cost_amt ,
(case when (LENGTH(trim(fill_awp_cost_amt_after)) ==0) then  fill_awp_cost_amt_after else trim(fill_awp_cost_amt_after) end) as fill_awp_cost_amt_after ,
(case when (LENGTH(trim(fill_discount_cd)) ==0) then  fill_discount_cd else trim(fill_discount_cd) end) as fill_discount_cd ,
(case when (LENGTH(trim(fill_discount_cd_after)) ==0) then  fill_discount_cd_after else trim(fill_discount_cd_after) end) as fill_discount_cd_after ,
(case when (LENGTH(trim(fill_discount_amt)) ==0) then  fill_discount_amt else trim(fill_discount_amt) end) as fill_discount_amt ,
(case when (LENGTH(trim(fill_discount_amt_after)) ==0) then  fill_discount_amt_after else trim(fill_discount_amt_after) end) as fill_discount_amt_after ,
(case when (LENGTH(trim(fill_retail_price_amt)) ==0) then  fill_retail_price_amt else trim(fill_retail_price_amt) end) as fill_retail_price_amt ,
(case when (LENGTH(trim(fill_retail_price_amt_after)) ==0) then  fill_retail_price_amt_after else trim(fill_retail_price_amt_after) end) as fill_retail_price_amt_after ,
(case when (LENGTH(trim(fill_label_price_amt)) ==0) then  fill_label_price_amt else trim(fill_label_price_amt) end) as fill_label_price_amt ,
(case when (LENGTH(trim(fill_label_price_amt_after)) ==0) then  fill_label_price_amt_after else trim(fill_label_price_amt_after) end) as fill_label_price_amt_after ,
(case when (LENGTH(trim(fill_price_override_amt)) ==0) then  fill_price_override_amt else trim(fill_price_override_amt) end) as fill_price_override_amt ,
(case when (LENGTH(trim(fill_price_override_amt_after)) ==0) then  fill_price_override_amt_after else trim(fill_price_override_amt_after) end) as fill_price_override_amt_after ,
(case when (LENGTH(trim(fill_sold_amt)) ==0) then  fill_sold_amt else trim(fill_sold_amt) end) as fill_sold_amt ,
(case when (LENGTH(trim(fill_sold_amt_after)) ==0) then  fill_sold_amt_after else trim(fill_sold_amt_after) end) as fill_sold_amt_after , fill_savings_amt AS fill_savings_amt , fill_savings_amt_after AS fill_savings_amt_after ,
(case when (LENGTH(trim(fill_enter_user_id)) ==0) then  fill_enter_user_id else trim(fill_enter_user_id) end) as fill_enter_user_id ,
(case when (LENGTH(trim(fill_enter_user_id_after)) ==0) then  fill_enter_user_id_after else trim(fill_enter_user_id_after) end) as fill_enter_user_id_after , CONCAT(CONCAT(SUBSTRING(fill_enter_dttm,0,10),' '),SUBSTRING(fill_enter_dttm,11,19)) as fill_enter_dttm , CONCAT(CONCAT(SUBSTRING(fill_enter_dttm_after,0,10),' '),SUBSTRING(fill_enter_dttm_after,11,19)) as fill_enter_dttm_after ,
(case when (LENGTH(trim(fill_verified_user_id)) ==0) then  fill_verified_user_id else trim(fill_verified_user_id) end) as fill_verified_user_id ,
(case when (LENGTH(trim(fill_verified_user_id_after)) ==0) then  fill_verified_user_id_after else trim(fill_verified_user_id_after) end) as fill_verified_user_id_after , CONCAT(CONCAT(SUBSTRING(fill_verified_dttm,0,10),' '),SUBSTRING(fill_verified_dttm,11,19)) as fill_verified_dttm , CONCAT(CONCAT(SUBSTRING(fill_verified_dttm_after,0,10),' '),SUBSTRING(fill_verified_dttm_after,11,19)) as fill_verified_dttm_after , CONCAT(CONCAT(SUBSTRING(fill_sold_dttm,0,10),' '),SUBSTRING(fill_sold_dttm,11,19)) as fill_sold_dttm , CONCAT(CONCAT(SUBSTRING(fill_sold_dttm_after,0,10),' '),SUBSTRING(fill_sold_dttm_after,11,19)) as fill_sold_dttm_after , fill_prorated_price_ind AS fill_prorated_price_ind , fill_prorated_price_ind_after AS fill_prorated_price_ind_after ,
(case when (LENGTH(trim(fill_adjudication_cd)) ==0) then  fill_adjudication_cd else trim(fill_adjudication_cd) end) as fill_adjudication_cd ,
(case when (LENGTH(trim(fill_adjudication_cd_after)) ==0) then  fill_adjudication_cd_after else trim(fill_adjudication_cd_after) end) as fill_adjudication_cd_after ,
(case when (LENGTH(trim(plan_id)) ==0) then  plan_id else trim(plan_id) end) as plan_id ,
(case when (LENGTH(trim(plan_id_after)) ==0) then  plan_id_after else trim(plan_id_after) end) as plan_id_after ,
(case when (LENGTH(trim(claim_reference_nbr)) ==0) then  claim_reference_nbr else trim(claim_reference_nbr) end) as claim_reference_nbr ,
(case when (LENGTH(trim(claim_reference_nbr_after)) ==0) then  claim_reference_nbr_after else trim(claim_reference_nbr_after) end) as claim_reference_nbr_after ,
(case when (LENGTH(trim(plan_ar_amt)) ==0) then  plan_ar_amt else trim(plan_ar_amt) end) as plan_ar_amt ,
(case when (LENGTH(trim(plan_ar_amt_after)) ==0) then  plan_ar_amt_after else trim(plan_ar_amt_after) end) as plan_ar_amt_after ,
(case when (LENGTH(trim(plan_copay_amt)) ==0) then  plan_copay_amt else trim(plan_copay_amt) end) as plan_copay_amt ,
(case when (LENGTH(trim(plan_copay_amt_after)) ==0) then  plan_copay_amt_after else trim(plan_copay_amt_after) end) as plan_copay_amt_after ,
(case when (LENGTH(trim(fill_type_cd)) ==0) then  fill_type_cd else trim(fill_type_cd) end) as fill_type_cd ,
(case when (LENGTH(trim(fill_type_cd_after)) ==0) then  fill_type_cd_after else trim(fill_type_cd_after) end) as fill_type_cd_after ,
(case when (LENGTH(trim(general_recipient_nbr)) ==0) then  general_recipient_nbr else trim(general_recipient_nbr) end) as general_recipient_nbr ,
(case when (LENGTH(trim(general_recipient_nbr_after)) ==0) then  general_recipient_nbr_after else trim(general_recipient_nbr_after) end) as general_recipient_nbr_after ,
(case when (LENGTH(trim(plan_tax_amt)) ==0) then  plan_tax_amt else trim(plan_tax_amt) end) as plan_tax_amt ,
(case when (LENGTH(trim(plan_tax_amt_after)) ==0) then  plan_tax_amt_after else trim(plan_tax_amt_after) end) as plan_tax_amt_after ,
(case when (LENGTH(trim(update_user_id)) ==0) then  update_user_id else trim(update_user_id) end) as update_user_id ,
(case when (LENGTH(trim(update_user_id_after)) ==0) then  update_user_id_after else trim(update_user_id_after) end) as update_user_id_after , CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm,11,19)) as update_dttm , CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after,11,19)) as update_dttm_after ,
(case when (LENGTH(trim(partial_fill_cd)) ==0) then  partial_fill_cd else trim(partial_fill_cd) end) as partial_fill_cd ,
(case when (LENGTH(trim(partial_fill_cd_after)) ==0) then  partial_fill_cd_after else trim(partial_fill_cd_after) end) as partial_fill_cd_after ,
(case when (LENGTH(trim(accept_consult_ind)) ==0) then  accept_consult_ind else trim(accept_consult_ind) end) as accept_consult_ind ,
(case when (LENGTH(trim(accept_consult_ind_after)) ==0) then  accept_consult_ind_after else trim(accept_consult_ind_after) end) as accept_consult_ind_after ,
(case when (LENGTH(trim(plan_other_amt)) ==0) then  plan_other_amt else trim(plan_other_amt) end) as plan_other_amt ,
(case when (LENGTH(trim(plan_other_amt_after)) ==0) then  plan_other_amt_after else trim(plan_other_amt_after) end) as plan_other_amt_after ,
(case when (LENGTH(trim(cob_fill_adjudication_cd)) ==0) then  cob_fill_adjudication_cd else trim(cob_fill_adjudication_cd) end) as cob_fill_adjudication_cd ,
(case when (LENGTH(trim(cob_fill_adjudication_cd_after)) ==0) then  cob_fill_adjudication_cd_after else trim(cob_fill_adjudication_cd_after) end) as cob_fill_adjudication_cd_after ,
(case when (LENGTH(trim(cob_plan_id)) ==0) then  cob_plan_id else trim(cob_plan_id) end) as cob_plan_id ,
(case when (LENGTH(trim(cob_plan_id_after)) ==0) then  cob_plan_id_after else trim(cob_plan_id_after) end) as cob_plan_id_after ,
(case when (LENGTH(trim(cob_claim_ref_nbr)) ==0) then  cob_claim_ref_nbr else trim(cob_claim_ref_nbr) end) as cob_claim_ref_nbr ,
(case when (LENGTH(trim(cob_claim_ref_nbr_after)) ==0) then  cob_claim_ref_nbr_after else trim(cob_claim_ref_nbr_after) end) as cob_claim_ref_nbr_after ,
(case when (LENGTH(trim(cob_plan_copay_amt)) ==0) then  cob_plan_copay_amt else trim(cob_plan_copay_amt) end) as cob_plan_copay_amt ,
(case when (LENGTH(trim(cob_plan_copay_amt_after)) ==0) then  cob_plan_copay_amt_after else trim(cob_plan_copay_amt_after) end) as cob_plan_copay_amt_after ,
(case when (LENGTH(trim(cob_gen_recipient_nbr)) ==0) then  cob_gen_recipient_nbr else trim(cob_gen_recipient_nbr) end) as cob_gen_recipient_nbr ,
(case when (LENGTH(trim(cob_gen_recipient_nbr_after)) ==0) then  cob_gen_recipient_nbr_after else trim(cob_gen_recipient_nbr_after) end) as cob_gen_recipient_nbr_after ,
(case when (LENGTH(trim(cob_plan_tax_amt)) ==0) then  cob_plan_tax_amt else trim(cob_plan_tax_amt) end) as cob_plan_tax_amt ,
(case when (LENGTH(trim(cob_plan_tax_amt_after)) ==0) then  cob_plan_tax_amt_after else trim(cob_plan_tax_amt_after) end) as cob_plan_tax_amt_after ,
(case when (LENGTH(trim(cob_plan_ar_amt)) ==0) then  cob_plan_ar_amt else trim(cob_plan_ar_amt) end) as cob_plan_ar_amt ,
(case when (LENGTH(trim(cob_plan_ar_amt_after)) ==0) then  cob_plan_ar_amt_after else trim(cob_plan_ar_amt_after) end) as cob_plan_ar_amt_after ,
(case when (LENGTH(trim(cash_disc_sav_amt)) ==0) then  cash_disc_sav_amt else trim(cash_disc_sav_amt) end) as cash_disc_sav_amt ,
(case when (LENGTH(trim(cash_disc_sav_amt_after)) ==0) then  cash_disc_sav_amt_after else trim(cash_disc_sav_amt_after) end) as cash_disc_sav_amt_after , CONCAT(CONCAT(SUBSTRING(fill_deleted_dttm,0,10),' '),SUBSTRING(fill_deleted_dttm,11,19)) as fill_deleted_dttm , CONCAT(CONCAT(SUBSTRING(fill_deleted_dttm_after,0,10),' '),SUBSTRING(fill_deleted_dttm_after,11,19)) as fill_deleted_dttm_after ,
(case when (LENGTH(trim(routing_store_tech_inits)) ==0) then  routing_store_tech_inits else trim(routing_store_tech_inits) end) as routing_store_tech_inits ,
(case when (LENGTH(trim(routing_store_tech_inits_after)) ==0) then  routing_store_tech_inits_after else trim(routing_store_tech_inits_after) end) as routing_store_tech_inits_after ,
(case when (LENGTH(trim(fill_data_rev_id)) ==0) then  fill_data_rev_id else trim(fill_data_rev_id) end) as fill_data_rev_id ,
(case when (LENGTH(trim(fill_data_rev_id_after)) ==0) then  fill_data_rev_id_after else trim(fill_data_rev_id_after) end) as fill_data_rev_id_after , CONCAT(CONCAT(SUBSTRING(fill_data_rev_dttm,0,10),' '),SUBSTRING(fill_data_rev_dttm,11,19)) as fill_data_rev_dttm , CONCAT(CONCAT(SUBSTRING(fill_data_rev_dttm_after,0,10),' '),SUBSTRING(fill_data_rev_dttm_after,11,19)) as fill_data_rev_dttm_after ,
(case when (LENGTH(trim(filling_user_id)) ==0) then  filling_user_id else trim(filling_user_id) end) as filling_user_id ,
(case when (LENGTH(trim(filling_user_id_after)) ==0) then  filling_user_id_after else trim(filling_user_id_after) end) as filling_user_id_after , CONCAT(CONCAT(SUBSTRING(filling_dttm,0,10),' '),SUBSTRING(filling_dttm,11,19)) as filling_dttm , CONCAT(CONCAT(SUBSTRING(filling_dttm_after,0,10),' '),SUBSTRING(filling_dttm_after,11,19)) as filling_dttm_after ,
(case when (LENGTH(trim(override_user_id)) ==0) then  override_user_id else trim(override_user_id) end) as override_user_id ,
(case when (LENGTH(trim(override_user_id_after)) ==0) then  override_user_id_after else trim(override_user_id_after) end) as override_user_id_after , CONCAT(CONCAT(SUBSTRING(override_dttm,0,10),' '),SUBSTRING(override_dttm,11,19)) as override_dttm , CONCAT(CONCAT(SUBSTRING(override_dttm_after,0,10),' '),SUBSTRING(override_dttm_after,11,19)) as override_dttm_after ,
(case when (LENGTH(trim(entered_store_nbr)) ==0) then  entered_store_nbr else trim(entered_store_nbr) end) as entered_store_nbr ,
(case when (LENGTH(trim(entered_store_nbr_after)) ==0) then  entered_store_nbr_after else trim(entered_store_nbr_after) end) as entered_store_nbr_after ,
(case when (LENGTH(trim(reviewed_store_nbr)) ==0) then  reviewed_store_nbr else trim(reviewed_store_nbr) end) as reviewed_store_nbr ,
(case when (LENGTH(trim(reviewed_store_nbr_after)) ==0) then  reviewed_store_nbr_after else trim(reviewed_store_nbr_after) end) as reviewed_store_nbr_after ,
(case when (LENGTH(trim(fill_nbr_dispensed)) ==0) then  fill_nbr_dispensed else trim(fill_nbr_dispensed) end) as fill_nbr_dispensed ,
(case when (LENGTH(trim(fill_nbr_dispensed_after)) ==0) then  fill_nbr_dispensed_after else trim(fill_nbr_dispensed_after) end) as fill_nbr_dispensed_after ,
(case when (LENGTH(trim(fax_image_id)) ==0) then  fax_image_id else trim(fax_image_id) end) as fax_image_id ,
(case when (LENGTH(trim(fax_image_id_after)) ==0) then  fax_image_id_after else trim(fax_image_id_after) end) as fax_image_id_after ,
(case when (LENGTH(trim(dl_reject_cd_01)) ==0) then  dl_reject_cd_01 else trim(dl_reject_cd_01) end) as dl_reject_cd_01 ,
(case when (LENGTH(trim(dl_reject_cd_01_after)) ==0) then  dl_reject_cd_01_after else trim(dl_reject_cd_01_after) end) as dl_reject_cd_01_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_01)) ==0) then  cob_dl_reject_cd_01 else trim(cob_dl_reject_cd_01) end) as cob_dl_reject_cd_01 ,
(case when (LENGTH(trim(cob_dl_reject_cd_01_after)) ==0) then  cob_dl_reject_cd_01_after else trim(cob_dl_reject_cd_01_after) end) as cob_dl_reject_cd_01_after , CONCAT(CONCAT(SUBSTRING(fill_adjudication_dttm,0,10),' '),SUBSTRING(fill_adjudication_dttm,11,19)) as fill_adjudication_dttm , CONCAT(CONCAT(SUBSTRING(fill_adjudication_dttm_after,0,10),' '),SUBSTRING(fill_adjudication_dttm_after,11,19)) as fill_adjudication_dttm_after , CONCAT(CONCAT(SUBSTRING(cob_fill_adj_dttm,0,10),' '),SUBSTRING(cob_fill_adj_dttm,11,19)) as cob_fill_adj_dttm , CONCAT(CONCAT(SUBSTRING(cob_fill_adj_dttm_after,0,10),' '),SUBSTRING(cob_fill_adj_dttm_after,11,19)) as cob_fill_adj_dttm_after ,
(case when (LENGTH(trim(data_rev_spec_id)) ==0) then  data_rev_spec_id else trim(data_rev_spec_id) end) as data_rev_spec_id ,
(case when (LENGTH(trim(data_rev_spec_id_after)) ==0) then  data_rev_spec_id_after else trim(data_rev_spec_id_after) end) as data_rev_spec_id_after , CONCAT(CONCAT(SUBSTRING(data_rev_spec_dttm,0,10),' '),SUBSTRING(data_rev_spec_dttm,11,19)) as data_rev_spec_dttm , CONCAT(CONCAT(SUBSTRING(data_rev_spec_dttm_after,0,10),' '),SUBSTRING(data_rev_spec_dttm_after,11,19)) as data_rev_spec_dttm_after ,
(case when (LENGTH(trim(data_rev_spec_store_nbr)) ==0) then  data_rev_spec_store_nbr else trim(data_rev_spec_store_nbr) end) as data_rev_spec_store_nbr ,
(case when (LENGTH(trim(data_rev_spec_store_nbr_after)) ==0) then  data_rev_spec_store_nbr_after else trim(data_rev_spec_store_nbr_after) end) as data_rev_spec_store_nbr_after ,
(case when (LENGTH(trim(fill_rph_of_record_id)) ==0) then  fill_rph_of_record_id else trim(fill_rph_of_record_id) end) as fill_rph_of_record_id ,
(case when (LENGTH(trim(fill_rph_of_record_id_after)) ==0) then  fill_rph_of_record_id_after else trim(fill_rph_of_record_id_after) end) as fill_rph_of_record_id_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_02)) ==0) then  cob_dl_reject_cd_02 else trim(cob_dl_reject_cd_02) end) as cob_dl_reject_cd_02 ,
(case when (LENGTH(trim(cob_dl_reject_cd_02_after)) ==0) then  cob_dl_reject_cd_02_after else trim(cob_dl_reject_cd_02_after) end) as cob_dl_reject_cd_02_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_03)) ==0) then  cob_dl_reject_cd_03 else trim(cob_dl_reject_cd_03) end) as cob_dl_reject_cd_03 ,
(case when (LENGTH(trim(cob_dl_reject_cd_03_after)) ==0) then  cob_dl_reject_cd_03_after else trim(cob_dl_reject_cd_03_after) end) as cob_dl_reject_cd_03_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_04)) ==0) then  cob_dl_reject_cd_04 else trim(cob_dl_reject_cd_04) end) as cob_dl_reject_cd_04 ,
(case when (LENGTH(trim(cob_dl_reject_cd_04_after)) ==0) then  cob_dl_reject_cd_04_after else trim(cob_dl_reject_cd_04_after) end) as cob_dl_reject_cd_04_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_05)) ==0) then  cob_dl_reject_cd_05 else trim(cob_dl_reject_cd_05) end) as cob_dl_reject_cd_05 ,
(case when (LENGTH(trim(cob_dl_reject_cd_05_after)) ==0) then  cob_dl_reject_cd_05_after else trim(cob_dl_reject_cd_05_after) end) as cob_dl_reject_cd_05_after ,
(case when (LENGTH(trim(amt_attributed_to_tax)) ==0) then  amt_attributed_to_tax else trim(amt_attributed_to_tax) end) as amt_attributed_to_tax ,
(case when (LENGTH(trim(amt_attributed_to_tax_after)) ==0) then  amt_attributed_to_tax_after else trim(amt_attributed_to_tax_after) end) as amt_attributed_to_tax_after ,
(case when (LENGTH(trim(cob_plan_gross_due_amt)) ==0) then  cob_plan_gross_due_amt else trim(cob_plan_gross_due_amt) end) as cob_plan_gross_due_amt ,
(case when (LENGTH(trim(cob_plan_gross_due_amt_after)) ==0) then  cob_plan_gross_due_amt_after else trim(cob_plan_gross_due_amt_after) end) as cob_plan_gross_due_amt_after ,
(case when (LENGTH(trim(cob_pln_incnt_amt_submtd)) ==0) then  cob_pln_incnt_amt_submtd else trim(cob_pln_incnt_amt_submtd) end) as cob_pln_incnt_amt_submtd ,
(case when (LENGTH(trim(cob_pln_incnt_amt_submtd_after)) ==0) then  cob_pln_incnt_amt_submtd_after else trim(cob_pln_incnt_amt_submtd_after) end) as cob_pln_incnt_amt_submtd_after ,
(case when (LENGTH(trim(plan_gross_due_amt)) ==0) then  plan_gross_due_amt else trim(plan_gross_due_amt) end) as plan_gross_due_amt ,
(case when (LENGTH(trim(plan_gross_due_amt_after)) ==0) then  plan_gross_due_amt_after else trim(plan_gross_due_amt_after) end) as plan_gross_due_amt_after ,
(case when (LENGTH(trim(plan_incent_amt_submtd)) ==0) then  plan_incent_amt_submtd else trim(plan_incent_amt_submtd) end) as plan_incent_amt_submtd ,
(case when (LENGTH(trim(plan_incent_amt_submtd_after)) ==0) then  plan_incent_amt_submtd_after else trim(plan_incent_amt_submtd_after) end) as plan_incent_amt_submtd_after ,
(case when (LENGTH(trim(plan_incentive_paid_amt)) ==0) then  plan_incentive_paid_amt else trim(plan_incentive_paid_amt) end) as plan_incentive_paid_amt ,
(case when (LENGTH(trim(plan_incentive_paid_amt_after)) ==0) then  plan_incentive_paid_amt_after else trim(plan_incentive_paid_amt_after) end) as plan_incentive_paid_amt_after ,
(case when (LENGTH(trim(plan_other_amt_paid)) ==0) then  plan_other_amt_paid else trim(plan_other_amt_paid) end) as plan_other_amt_paid ,
(case when (LENGTH(trim(plan_other_amt_paid_after)) ==0) then  plan_other_amt_paid_after else trim(plan_other_amt_paid_after) end) as plan_other_amt_paid_after ,
(case when (LENGTH(trim(plan_returnd_coins_amt)) ==0) then  plan_returnd_coins_amt else trim(plan_returnd_coins_amt) end) as plan_returnd_coins_amt ,
(case when (LENGTH(trim(plan_returnd_coins_amt_after)) ==0) then  plan_returnd_coins_amt_after else trim(plan_returnd_coins_amt_after) end) as plan_returnd_coins_amt_after ,
(case when (LENGTH(trim(plan_returnd_copay_amt)) ==0) then  plan_returnd_copay_amt else trim(plan_returnd_copay_amt) end) as plan_returnd_copay_amt ,
(case when (LENGTH(trim(plan_returnd_copay_amt_after)) ==0) then  plan_returnd_copay_amt_after else trim(plan_returnd_copay_amt_after) end) as plan_returnd_copay_amt_after ,
(case when (LENGTH(trim(plan_returnd_cost_amt)) ==0) then  plan_returnd_cost_amt else trim(plan_returnd_cost_amt) end) as plan_returnd_cost_amt ,
(case when (LENGTH(trim(plan_returnd_cost_amt_after)) ==0) then  plan_returnd_cost_amt_after else trim(plan_returnd_cost_amt_after) end) as plan_returnd_cost_amt_after ,
(case when (LENGTH(trim(plan_returnd_fee_amt)) ==0) then  plan_returnd_fee_amt else trim(plan_returnd_fee_amt) end) as plan_returnd_fee_amt ,
(case when (LENGTH(trim(plan_returnd_fee_amt_after)) ==0) then  plan_returnd_fee_amt_after else trim(plan_returnd_fee_amt_after) end) as plan_returnd_fee_amt_after ,
(case when (LENGTH(trim(plan_returnd_tax_amt)) ==0) then  plan_returnd_tax_amt else trim(plan_returnd_tax_amt) end) as plan_returnd_tax_amt ,
(case when (LENGTH(trim(plan_returnd_tax_amt_after)) ==0) then  plan_returnd_tax_amt_after else trim(plan_returnd_tax_amt_after) end) as plan_returnd_tax_amt_after ,
(case when (LENGTH(trim(plan_rtrnd_coins_amt)) ==0) then  plan_rtrnd_coins_amt else trim(plan_rtrnd_coins_amt) end) as plan_rtrnd_coins_amt ,
(case when (LENGTH(trim(plan_rtrnd_coins_amt_after)) ==0) then  plan_rtrnd_coins_amt_after else trim(plan_rtrnd_coins_amt_after) end) as plan_rtrnd_coins_amt_after ,
(case when (LENGTH(trim(plan_total_paid_amt)) ==0) then  plan_total_paid_amt else trim(plan_total_paid_amt) end) as plan_total_paid_amt ,
(case when (LENGTH(trim(plan_total_paid_amt_after)) ==0) then  plan_total_paid_amt_after else trim(plan_total_paid_amt_after) end) as plan_total_paid_amt_after ,
(case when (LENGTH(trim(plan_other_amt_paid_type)) ==0) then  plan_other_amt_paid_type else trim(plan_other_amt_paid_type) end) as plan_other_amt_paid_type ,
(case when (LENGTH(trim(plan_other_amt_paid_type_after)) ==0) then  plan_other_amt_paid_type_after else trim(plan_other_amt_paid_type_after) end) as plan_other_amt_paid_type_after ,
(case when (LENGTH(trim(med_partd_notice_ind)) ==0) then  med_partd_notice_ind else trim(med_partd_notice_ind) end) as med_partd_notice_ind ,
(case when (LENGTH(trim(med_partd_notice_ind_after)) ==0) then  med_partd_notice_ind_after else trim(med_partd_notice_ind_after) end) as med_partd_notice_ind_after , CONCAT(CONCAT(SUBSTRING(med_partd_print_dttm,0,10),' '),SUBSTRING(med_partd_print_dttm,11,19)) as med_partd_print_dttm , CONCAT(CONCAT(SUBSTRING(med_partd_print_dttm_after,0,10),' '),SUBSTRING(med_partd_print_dttm_after,11,19)) as med_partd_print_dttm_after ,
(case when (LENGTH(trim(ben_stg_qualifier_1)) ==0) then  ben_stg_qualifier_1 else trim(ben_stg_qualifier_1) end) as ben_stg_qualifier_1 ,
(case when (LENGTH(trim(ben_stg_qualifier_1_after)) ==0) then  ben_stg_qualifier_1_after else trim(ben_stg_qualifier_1_after) end) as ben_stg_qualifier_1_after ,
(case when (LENGTH(trim(ben_stg_qualifier_2)) ==0) then  ben_stg_qualifier_2 else trim(ben_stg_qualifier_2) end) as ben_stg_qualifier_2 ,
(case when (LENGTH(trim(ben_stg_qualifier_2_after)) ==0) then  ben_stg_qualifier_2_after else trim(ben_stg_qualifier_2_after) end) as ben_stg_qualifier_2_after ,
(case when (LENGTH(trim(ben_stg_qualifier_3)) ==0) then  ben_stg_qualifier_3 else trim(ben_stg_qualifier_3) end) as ben_stg_qualifier_3 ,
(case when (LENGTH(trim(ben_stg_qualifier_3_after)) ==0) then  ben_stg_qualifier_3_after else trim(ben_stg_qualifier_3_after) end) as ben_stg_qualifier_3_after ,
(case when (LENGTH(trim(ben_stg_qualifier_4)) ==0) then  ben_stg_qualifier_4 else trim(ben_stg_qualifier_4) end) as ben_stg_qualifier_4 ,
(case when (LENGTH(trim(ben_stg_qualifier_4_after)) ==0) then  ben_stg_qualifier_4_after else trim(ben_stg_qualifier_4_after) end) as ben_stg_qualifier_4_after ,
(case when (LENGTH(trim(ben_stg_amount_1)) ==0) then  ben_stg_amount_1 else trim(ben_stg_amount_1) end) as ben_stg_amount_1 ,
(case when (LENGTH(trim(ben_stg_amount_1_after)) ==0) then  ben_stg_amount_1_after else trim(ben_stg_amount_1_after) end) as ben_stg_amount_1_after ,
(case when (LENGTH(trim(ben_stg_amount_2)) ==0) then  ben_stg_amount_2 else trim(ben_stg_amount_2) end) as ben_stg_amount_2 ,
(case when (LENGTH(trim(ben_stg_amount_2_after)) ==0) then  ben_stg_amount_2_after else trim(ben_stg_amount_2_after) end) as ben_stg_amount_2_after ,
(case when (LENGTH(trim(ben_stg_amount_3)) ==0) then  ben_stg_amount_3 else trim(ben_stg_amount_3) end) as ben_stg_amount_3 ,
(case when (LENGTH(trim(ben_stg_amount_3_after)) ==0) then  ben_stg_amount_3_after else trim(ben_stg_amount_3_after) end) as ben_stg_amount_3_after ,
(case when (LENGTH(trim(ben_stg_amount_4)) ==0) then  ben_stg_amount_4 else trim(ben_stg_amount_4) end) as ben_stg_amount_4 ,
(case when (LENGTH(trim(ben_stg_amount_4_after)) ==0) then  ben_stg_amount_4_after else trim(ben_stg_amount_4_after) end) as ben_stg_amount_4_after ,
(case when (LENGTH(trim(coupon_drug_id)) ==0) then  coupon_drug_id else trim(coupon_drug_id) end) as coupon_drug_id ,
(case when (LENGTH(trim(coupon_drug_id_after)) ==0) then  coupon_drug_id_after else trim(coupon_drug_id_after) end) as coupon_drug_id_after ,
(case when (LENGTH(trim(cob_coupon_drug_id)) ==0) then  cob_coupon_drug_id else trim(cob_coupon_drug_id) end) as cob_coupon_drug_id ,
(case when (LENGTH(trim(cob_coupon_drug_id_after)) ==0) then  cob_coupon_drug_id_after else trim(cob_coupon_drug_id_after) end) as cob_coupon_drug_id_after ,
(case when (LENGTH(trim(coupon_ind)) ==0) then  coupon_ind else trim(coupon_ind) end) as coupon_ind ,
(case when (LENGTH(trim(coupon_ind_after)) ==0) then  coupon_ind_after else trim(coupon_ind_after) end) as coupon_ind_after ,
(case when (LENGTH(trim(cob_coupon_ind)) ==0) then  cob_coupon_ind else trim(cob_coupon_ind) end) as cob_coupon_ind ,
(case when (LENGTH(trim(cob_coupon_ind_after)) ==0) then  cob_coupon_ind_after else trim(cob_coupon_ind_after) end) as cob_coupon_ind_after ,
(case when (LENGTH(trim(other_coverage_cd)) ==0) then  other_coverage_cd else trim(other_coverage_cd) end) as other_coverage_cd ,
(case when (LENGTH(trim(other_coverage_cd_after)) ==0) then  other_coverage_cd_after else trim(other_coverage_cd_after) end) as other_coverage_cd_after ,
(case when (LENGTH(trim(cob_other_coverage_cd)) ==0) then  cob_other_coverage_cd else trim(cob_other_coverage_cd) end) as cob_other_coverage_cd ,
(case when (LENGTH(trim(cob_other_coverage_cd_after)) ==0) then  cob_other_coverage_cd_after else trim(cob_other_coverage_cd_after) end) as cob_other_coverage_cd_after , cob_place_of_service AS cob_place_of_service , cob_place_of_service_after AS cob_place_of_service_after ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd)) ==0) then  cob_rx_denial_ovride_cd else trim(cob_rx_denial_ovride_cd) end) as cob_rx_denial_ovride_cd ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd_after)) ==0) then  cob_rx_denial_ovride_cd_after else trim(cob_rx_denial_ovride_cd_after) end) as cob_rx_denial_ovride_cd_after ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd2)) ==0) then  cob_rx_denial_ovride_cd2 else trim(cob_rx_denial_ovride_cd2) end) as cob_rx_denial_ovride_cd2 ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd2_after)) ==0) then  cob_rx_denial_ovride_cd2_after else trim(cob_rx_denial_ovride_cd2_after) end) as cob_rx_denial_ovride_cd2_after ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd3)) ==0) then  cob_rx_denial_ovride_cd3 else trim(cob_rx_denial_ovride_cd3) end) as cob_rx_denial_ovride_cd3 ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd3_after)) ==0) then  cob_rx_denial_ovride_cd3_after else trim(cob_rx_denial_ovride_cd3_after) end) as cob_rx_denial_ovride_cd3_after ,
(case when (LENGTH(trim(medigap_id)) ==0) then  medigap_id else trim(medigap_id) end) as medigap_id ,
(case when (LENGTH(trim(medigap_id_after)) ==0) then  medigap_id_after else trim(medigap_id_after) end) as medigap_id_after ,
(case when (LENGTH(trim(pat_pickup_gov_auth_id)) ==0) then  pat_pickup_gov_auth_id else trim(pat_pickup_gov_auth_id) end) as pat_pickup_gov_auth_id ,
(case when (LENGTH(trim(pat_pickup_gov_auth_id_after)) ==0) then  pat_pickup_gov_auth_id_after else trim(pat_pickup_gov_auth_id_after) end) as pat_pickup_gov_auth_id_after ,
(case when (LENGTH(trim(pat_pickup_rel_cd)) ==0) then  pat_pickup_rel_cd else trim(pat_pickup_rel_cd) end) as pat_pickup_rel_cd ,
(case when (LENGTH(trim(pat_pickup_rel_cd_after)) ==0) then  pat_pickup_rel_cd_after else trim(pat_pickup_rel_cd_after) end) as pat_pickup_rel_cd_after ,
(case when (LENGTH(trim(place_of_service)) ==0) then  place_of_service else trim(place_of_service) end) as place_of_service ,
(case when (LENGTH(trim(place_of_service_after)) ==0) then  place_of_service_after else trim(place_of_service_after) end) as place_of_service_after ,
(case when (LENGTH(trim(prior_auth_cd)) ==0) then  prior_auth_cd else trim(prior_auth_cd) end) as prior_auth_cd ,
(case when (LENGTH(trim(prior_auth_cd_after)) ==0) then  prior_auth_cd_after else trim(prior_auth_cd_after) end) as prior_auth_cd_after ,
(case when (LENGTH(trim(prior_auth_nbr)) ==0) then  prior_auth_nbr else trim(prior_auth_nbr) end) as prior_auth_nbr ,
(case when (LENGTH(trim(prior_auth_nbr_after)) ==0) then  prior_auth_nbr_after else trim(prior_auth_nbr_after) end) as prior_auth_nbr_after ,
(case when (LENGTH(trim(rx_denial_override_cd)) ==0) then  rx_denial_override_cd else trim(rx_denial_override_cd) end) as rx_denial_override_cd ,
(case when (LENGTH(trim(rx_denial_override_cd_after)) ==0) then  rx_denial_override_cd_after else trim(rx_denial_override_cd_after) end) as rx_denial_override_cd_after ,
(case when (LENGTH(trim(rx_denial_override_cd_2)) ==0) then  rx_denial_override_cd_2 else trim(rx_denial_override_cd_2) end) as rx_denial_override_cd_2 ,
(case when (LENGTH(trim(rx_denial_override_cd_2_after)) ==0) then  rx_denial_override_cd_2_after else trim(rx_denial_override_cd_2_after) end) as rx_denial_override_cd_2_after ,
(case when (LENGTH(trim(rx_denial_override_cd_3)) ==0) then  rx_denial_override_cd_3 else trim(rx_denial_override_cd_3) end) as rx_denial_override_cd_3 ,
(case when (LENGTH(trim(rx_denial_override_cd_3_after)) ==0) then  rx_denial_override_cd_3_after else trim(rx_denial_override_cd_3_after) end) as rx_denial_override_cd_3_after ,
(case when (LENGTH(trim(pat_pickup_id_qlfr)) ==0) then  pat_pickup_id_qlfr else trim(pat_pickup_id_qlfr) end) as pat_pickup_id_qlfr ,
(case when (LENGTH(trim(pat_pickup_id_qlfr_after)) ==0) then  pat_pickup_id_qlfr_after else trim(pat_pickup_id_qlfr_after) end) as pat_pickup_id_qlfr_after ,
(case when (LENGTH(trim(db_bin_nbr)) ==0) then  db_bin_nbr else trim(db_bin_nbr) end) as db_bin_nbr ,
(case when (LENGTH(trim(db_bin_nbr_after)) ==0) then  db_bin_nbr_after else trim(db_bin_nbr_after) end) as db_bin_nbr_after ,
(case when (LENGTH(trim(db_cob_bin_nbr)) ==0) then  db_cob_bin_nbr else trim(db_cob_bin_nbr) end) as db_cob_bin_nbr ,
(case when (LENGTH(trim(db_cob_bin_nbr_after)) ==0) then  db_cob_bin_nbr_after else trim(db_cob_bin_nbr_after) end) as db_cob_bin_nbr_after ,
(case when (LENGTH(trim(db_proc_ctrl_nbr)) ==0) then  db_proc_ctrl_nbr else trim(db_proc_ctrl_nbr) end) as db_proc_ctrl_nbr ,
(case when (LENGTH(trim(db_proc_ctrl_nbr_after)) ==0) then  db_proc_ctrl_nbr_after else trim(db_proc_ctrl_nbr_after) end) as db_proc_ctrl_nbr_after ,
(case when (LENGTH(trim(db_cob_proc_ctrl_nbr)) ==0) then  db_cob_proc_ctrl_nbr else trim(db_cob_proc_ctrl_nbr) end) as db_cob_proc_ctrl_nbr ,
(case when (LENGTH(trim(db_cob_proc_ctrl_nbr_after)) ==0) then  db_cob_proc_ctrl_nbr_after else trim(db_cob_proc_ctrl_nbr_after) end) as db_cob_proc_ctrl_nbr_after ,
(case when (LENGTH(trim(db_plan_group_nbr)) ==0) then  db_plan_group_nbr else trim(db_plan_group_nbr) end) as db_plan_group_nbr ,
(case when (LENGTH(trim(db_plan_group_nbr_after)) ==0) then  db_plan_group_nbr_after else trim(db_plan_group_nbr_after) end) as db_plan_group_nbr_after ,
(case when (LENGTH(trim(db_cob_plan_group_nbr)) ==0) then  db_cob_plan_group_nbr else trim(db_cob_plan_group_nbr) end) as db_cob_plan_group_nbr ,
(case when (LENGTH(trim(db_cob_plan_group_nbr_after)) ==0) then  db_cob_plan_group_nbr_after else trim(db_cob_plan_group_nbr_after) end) as db_cob_plan_group_nbr_after ,
(case when (LENGTH(trim(source_system_name)) ==0) then  source_system_name else trim(source_system_name) end) as source_system_name ,
(case when (LENGTH(trim(source_system_name_after)) ==0) then  source_system_name_after else trim(source_system_name_after) end) as source_system_name_after ,
(case when (LENGTH(trim(source_sys_trans_id)) ==0) then  source_sys_trans_id else trim(source_sys_trans_id) end) as source_sys_trans_id ,
(case when (LENGTH(trim(source_sys_trans_id_after)) ==0) then  source_sys_trans_id_after else trim(source_sys_trans_id_after) end) as source_sys_trans_id_after , CONCAT(CONCAT(SUBSTRING(org_entered_dttm,0,10),' '),SUBSTRING(org_entered_dttm,11,19)) as org_entered_dttm , CONCAT(CONCAT(SUBSTRING(org_entered_dttm_after,0,10),' '),SUBSTRING(org_entered_dttm_after,11,19)) as org_entered_dttm_after ,
(case when (LENGTH(trim(wo_correlation_id)) ==0) then  wo_correlation_id else trim(wo_correlation_id) end) as wo_correlation_id ,
(case when (LENGTH(trim(wo_correlation_id_after)) ==0) then  wo_correlation_id_after else trim(wo_correlation_id_after) end) as wo_correlation_id_after  ,
(case when (LENGTH(trim(wo_rx_count)) ==0) then  wo_rx_count else trim(wo_rx_count) end) as wo_rx_count ,
(case when (LENGTH(trim(wo_rx_count_after)) ==0) then  wo_rx_count_after else trim(wo_rx_count_after) end) as wo_rx_count_after  ,
(case when (LENGTH(trim(short_fill_ind)) ==0) then  short_fill_ind else trim(short_fill_ind) end) as short_fill_ind ,
(case when (LENGTH(trim(short_fill_ind_after)) ==0) then  short_fill_ind_after else trim(short_fill_ind_after) end) as short_fill_ind_after ,
(case when (LENGTH(trim(pay_cd)) ==0) then  pay_cd else trim(pay_cd) end) as pay_cd ,
(case when (LENGTH(trim(pay_cd_after)) ==0) then  pay_cd_after else trim(pay_cd_after) end) as pay_cd_after ,
(case when (LENGTH(trim(filling_store_nbr)) ==0) then  filling_store_nbr else trim(filling_store_nbr) end) as filling_store_nbr ,
(case when (LENGTH(trim(filling_store_nbr_after)) ==0) then  filling_store_nbr_after else trim(filling_store_nbr_after) end) as filling_store_nbr_after ,(case when (LENGTH(trim(fill_verified_store_nbr)) ==0) then  fill_verified_store_nbr else trim(fill_verified_store_nbr) end) as fill_verified_store_nbr ,(case when (LENGTH(trim(fill_verified_store_nbr_after)) ==0) then  fill_verified_store_nbr_after else trim(fill_verified_store_nbr_after) end) as fill_verified_store_nbr_after ,
(case when (LENGTH(trim(mult_prod_review_ind)) ==0) then  mult_prod_review_ind else trim(mult_prod_review_ind) end) as mult_prod_review_ind,
(case when (LENGTH(trim(mult_prod_review_ind_after)) ==0) then  mult_prod_review_ind_after else trim(mult_prod_review_ind_after) end) as mult_prod_review_ind_after,
(case when (LENGTH(trim(pat_selct_user_id)) ==0) then  pat_selct_user_id else trim(pat_selct_user_id) end) as pat_selct_user_id,
(case when (LENGTH(trim(pat_selct_user_id_after)) ==0) then  pat_selct_user_id_after else trim(pat_selct_user_id_after) end) as pat_selct_user_id_after,
(case when (LENGTH(trim(pbr_selct_user_id)) ==0) then  pbr_selct_user_id else trim(pbr_selct_user_id) end) as pbr_selct_user_id,
(case when (LENGTH(trim(pbr_selct_user_id_after)) ==0) then  pbr_selct_user_id_after else trim(pbr_selct_user_id_after) end) as pbr_selct_user_id_after,
(case when (LENGTH(trim(pat_selct_dttm)) ==0) then  pat_selct_dttm else trim(pat_selct_dttm) end) as pat_selct_dttm,
(case when (LENGTH(trim(pat_selct_dttm_after)) ==0) then  pat_selct_dttm_after else trim(pat_selct_dttm_after) end) as pat_selct_dttm_after,
(case when (LENGTH(trim(pbr_selct_dttm)) ==0) then  pbr_selct_dttm else trim(pbr_selct_dttm) end) as pbr_selct_dttm,
(case when (LENGTH(trim(pbr_selct_dttm_after)) ==0) then  pbr_selct_dttm_after else trim(pbr_selct_dttm_after) end) as pbr_selct_dttm_after,
(case when (LENGTH(trim(pat_selct_str_nbr)) ==0) then  pat_selct_str_nbr else trim(pat_selct_str_nbr) end) as pat_selct_str_nbr,
(case when (LENGTH(trim(pat_selct_str_nbr_after)) ==0) then  pat_selct_str_nbr_after else trim(pat_selct_str_nbr_after) end) as pat_selct_str_nbr_after,
(case when (LENGTH(trim(pbr_selct_str_nbr)) ==0) then  pbr_selct_str_nbr else trim(pbr_selct_str_nbr) end) as pbr_selct_str_nbr,
(case when (LENGTH(trim(pbr_selct_str_nbr_after)) ==0) then  pbr_selct_str_nbr_after else trim(pbr_selct_str_nbr_after) end) as pbr_selct_str_nbr_after,
(case when (LENGTH(trim(ntt_ind)) ==0) then  ntt_ind else trim(ntt_ind) end) as ntt_ind,
(case when (LENGTH(trim(ntt_ind_after)) ==0) then  ntt_ind_after else trim(ntt_ind_after) end) as ntt_ind_after from dedup_group"""


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

#display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdBfrXfr="""Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id, src_partition_nbr AS src_partition_nbr , store_nbr AS store_nbr , rx_nbr AS rx_nbr , fill_nbr AS fill_nbr , fill_partial_nbr AS fill_partial_nbr , fill_status_cd AS fill_status_cd , fill_qty_dispensed AS fill_qty_dispensed , fill_days_supply AS fill_days_supply , fill_pay_method_cd AS fill_pay_method_cd , fill_awp_cost_amt AS fill_awp_cost_amt , fill_discount_cd AS fill_discount_cd , fill_discount_amt AS fill_discount_amt , fill_retail_price_amt AS fill_retail_price_amt , fill_label_price_amt AS fill_label_price_amt , fill_price_override_amt AS fill_price_override_amt , fill_sold_amt AS fill_sold_amt , fill_savings_amt AS fill_savings_amt , fill_enter_user_id AS fill_enter_user_id , fill_enter_dttm AS fill_enter_dttm , fill_verified_user_id AS fill_verified_user_id , fill_verified_dttm AS fill_verified_dttm , fill_sold_dttm AS fill_sold_dttm , fill_prorated_price_ind AS fill_prorated_price_ind , fill_adjudication_cd AS fill_adjudication_cd , plan_id AS plan_id , claim_reference_nbr AS claim_reference_nbr , plan_ar_amt AS plan_ar_amt , plan_copay_amt AS plan_copay_amt , fill_type_cd AS fill_type_cd , general_recipient_nbr AS general_recipient_nbr , plan_tax_amt AS plan_tax_amt , update_user_id AS update_user_id , update_dttm AS update_dttm , partial_fill_cd AS partial_fill_cd , accept_consult_ind AS accept_consult_ind , plan_other_amt AS plan_other_amt , cob_fill_adjudication_cd AS cob_fill_adjudication_cd , cob_plan_id AS cob_plan_id , cob_claim_ref_nbr AS cob_claim_ref_nbr , cob_plan_copay_amt AS cob_plan_copay_amt , cob_gen_recipient_nbr AS cob_gen_recipient_nbr , cob_plan_tax_amt AS cob_plan_tax_amt , cob_plan_ar_amt AS cob_plan_ar_amt , cash_disc_sav_amt AS cash_disc_sav_amt , fill_deleted_dttm AS fill_deleted_dttm , routing_store_tech_inits AS routing_store_tech_inits , fill_data_rev_id AS fill_data_rev_id , fill_data_rev_dttm AS fill_data_rev_dttm , filling_user_id AS filling_user_id , filling_dttm AS filling_dttm , override_user_id AS override_user_id , override_dttm AS override_dttm , entered_store_nbr AS entered_store_nbr , reviewed_store_nbr AS reviewed_store_nbr , fill_nbr_dispensed AS fill_nbr_dispensed , fax_image_id AS fax_image_id , dl_reject_cd_01 AS dl_reject_cd_01 , cob_dl_reject_cd_01 AS cob_dl_reject_cd_01 , fill_adjudication_dttm AS fill_adjudication_dttm , cob_fill_adj_dttm AS cob_fill_adj_dttm , data_rev_spec_id AS data_rev_spec_id , data_rev_spec_dttm AS data_rev_spec_dttm , data_rev_spec_store_nbr AS data_rev_spec_store_nbr , fill_rph_of_record_id AS fill_rph_of_record_id , cob_dl_reject_cd_02 AS cob_dl_reject_cd_02 , cob_dl_reject_cd_03 AS cob_dl_reject_cd_03 , cob_dl_reject_cd_04 AS cob_dl_reject_cd_04 , cob_dl_reject_cd_05 AS cob_dl_reject_cd_05 , amt_attributed_to_tax AS amt_attributed_to_tax , cob_plan_gross_due_amt AS cob_plan_gross_due_amt , cob_pln_incnt_amt_submtd AS cob_pln_incnt_amt_submtd , plan_gross_due_amt AS plan_gross_due_amt , plan_incent_amt_submtd AS plan_incent_amt_submtd , plan_incentive_paid_amt AS plan_incentive_paid_amt , plan_other_amt_paid AS plan_other_amt_paid , plan_returnd_coins_amt AS plan_returnd_coins_amt , plan_returnd_copay_amt AS plan_returnd_copay_amt , plan_returnd_cost_amt AS plan_returnd_cost_amt , plan_returnd_fee_amt AS plan_returnd_fee_amt , plan_returnd_tax_amt AS plan_returnd_tax_amt , plan_rtrnd_coins_amt AS plan_rtrnd_coins_amt , plan_total_paid_amt AS plan_total_paid_amt , plan_other_amt_paid_type AS plan_other_amt_paid_type , med_partd_notice_ind AS med_partd_notice_ind , med_partd_print_dttm AS med_partd_print_dttm , ben_stg_qualifier_1 AS ben_stg_qualifier_1 , ben_stg_qualifier_2 AS ben_stg_qualifier_2 , ben_stg_qualifier_3 AS ben_stg_qualifier_3 , ben_stg_qualifier_4 AS ben_stg_qualifier_4 , ben_stg_amount_1 AS ben_stg_amount_1 , ben_stg_amount_2 AS ben_stg_amount_2 , ben_stg_amount_3 AS ben_stg_amount_3 , ben_stg_amount_4 AS ben_stg_amount_4 , coupon_drug_id AS coupon_drug_id , cob_coupon_drug_id AS cob_coupon_drug_id , coupon_ind AS coupon_ind , cob_coupon_ind AS cob_coupon_ind , other_coverage_cd AS other_coverage_cd , cob_other_coverage_cd AS cob_other_coverage_cd , cob_place_of_service AS cob_place_of_service , cob_rx_denial_ovride_cd AS cob_rx_denial_ovride_cd , cob_rx_denial_ovride_cd2 AS cob_rx_denial_ovride_cd2 , cob_rx_denial_ovride_cd3 AS cob_rx_denial_ovride_cd3 , medigap_id AS medigap_id , pat_pickup_gov_auth_id AS pat_pickup_gov_auth_id , pat_pickup_rel_cd AS pat_pickup_rel_cd , place_of_service  AS place_of_service  , prior_auth_cd AS prior_auth_cd , prior_auth_nbr AS prior_auth_nbr , rx_denial_override_cd AS rx_denial_override_cd , rx_denial_override_cd_2 AS rx_denial_override_cd_2 , rx_denial_override_cd_3 AS rx_denial_override_cd_3 , pat_pickup_id_qlfr AS pat_pickup_id_qlfr , db_bin_nbr AS db_bin_nbr , db_cob_bin_nbr AS db_cob_bin_nbr , db_proc_ctrl_nbr AS db_proc_ctrl_nbr , db_cob_proc_ctrl_nbr AS db_cob_proc_ctrl_nbr , db_plan_group_nbr AS db_plan_group_nbr , db_cob_plan_group_nbr AS db_cob_plan_group_nbr , source_system_name AS source_system_name , source_sys_trans_id AS source_sys_trans_id , org_entered_dttm AS org_entered_dttm , wo_correlation_id AS wo_correlation_id , wo_rx_count AS wo_rx_count , short_fill_ind AS short_fill_ind , pay_cd AS pay_cd , filling_store_nbr as filling_store_nbr,fill_verified_store_nbr as fill_verified_store_nbr, mult_prod_review_ind as mult_prod_review_ind, pat_selct_user_id as pat_selct_user_id, pbr_selct_user_id as pbr_selct_user_id, pat_selct_dttm as pat_selct_dttm, pbr_selct_dttm as pbr_selct_dttm, pat_selct_str_nbr as pat_selct_str_nbr, pbr_selct_str_nbr as pbr_selct_str_nbr, ntt_ind as ntt_ind, '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from gg_tbf0_update """ 



pTgtUpdAftXfr="""Select 
cdc_txn_commit_dttm_after  as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id , src_partition_nbr_after AS src_partition_nbr , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , fill_status_cd_after AS fill_status_cd , fill_qty_dispensed_after AS fill_qty_dispensed , fill_days_supply_after AS fill_days_supply , fill_pay_method_cd_after AS fill_pay_method_cd , fill_awp_cost_amt_after AS fill_awp_cost_amt , fill_discount_cd_after AS fill_discount_cd , fill_discount_amt_after AS fill_discount_amt , fill_retail_price_amt_after AS fill_retail_price_amt , fill_label_price_amt_after AS fill_label_price_amt , fill_price_override_amt_after AS fill_price_override_amt , fill_sold_amt_after AS fill_sold_amt , fill_savings_amt_after AS fill_savings_amt , fill_enter_user_id_after AS fill_enter_user_id , fill_enter_dttm_after AS fill_enter_dttm , fill_verified_user_id_after AS fill_verified_user_id , fill_verified_dttm_after AS fill_verified_dttm , fill_sold_dttm_after AS fill_sold_dttm , fill_prorated_price_ind_after AS fill_prorated_price_ind , fill_adjudication_cd_after AS fill_adjudication_cd , plan_id_after AS plan_id , claim_reference_nbr_after AS claim_reference_nbr , plan_ar_amt_after AS plan_ar_amt , plan_copay_amt_after AS plan_copay_amt , fill_type_cd_after AS fill_type_cd , general_recipient_nbr_after AS general_recipient_nbr , plan_tax_amt_after AS plan_tax_amt , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , partial_fill_cd_after AS partial_fill_cd , accept_consult_ind_after AS accept_consult_ind , plan_other_amt_after AS plan_other_amt , cob_fill_adjudication_cd_after AS cob_fill_adjudication_cd , cob_plan_id_after AS cob_plan_id , cob_claim_ref_nbr_after AS cob_claim_ref_nbr , cob_plan_copay_amt_after AS cob_plan_copay_amt , cob_gen_recipient_nbr_after AS cob_gen_recipient_nbr , cob_plan_tax_amt_after AS cob_plan_tax_amt , cob_plan_ar_amt_after AS cob_plan_ar_amt , cash_disc_sav_amt_after AS cash_disc_sav_amt , fill_deleted_dttm_after AS fill_deleted_dttm , routing_store_tech_inits_after AS routing_store_tech_inits , fill_data_rev_id_after AS fill_data_rev_id , fill_data_rev_dttm_after AS fill_data_rev_dttm , filling_user_id_after AS filling_user_id , filling_dttm_after AS filling_dttm , override_user_id_after AS override_user_id , override_dttm_after AS override_dttm , entered_store_nbr_after AS entered_store_nbr , reviewed_store_nbr_after AS reviewed_store_nbr , fill_nbr_dispensed_after AS fill_nbr_dispensed , fax_image_id_after AS fax_image_id , dl_reject_cd_01_after AS dl_reject_cd_01 , cob_dl_reject_cd_01_after AS cob_dl_reject_cd_01 , fill_adjudication_dttm_after AS fill_adjudication_dttm , cob_fill_adj_dttm_after AS cob_fill_adj_dttm , data_rev_spec_id_after AS data_rev_spec_id , data_rev_spec_dttm_after AS data_rev_spec_dttm , data_rev_spec_store_nbr_after AS data_rev_spec_store_nbr , fill_rph_of_record_id_after AS fill_rph_of_record_id , cob_dl_reject_cd_02_after AS cob_dl_reject_cd_02 , cob_dl_reject_cd_03_after AS cob_dl_reject_cd_03 , cob_dl_reject_cd_04_after AS cob_dl_reject_cd_04 , cob_dl_reject_cd_05_after AS cob_dl_reject_cd_05 , amt_attributed_to_tax_after AS amt_attributed_to_tax , cob_plan_gross_due_amt_after AS cob_plan_gross_due_amt , cob_pln_incnt_amt_submtd_after AS cob_pln_incnt_amt_submtd , plan_gross_due_amt_after AS plan_gross_due_amt , plan_incent_amt_submtd_after AS plan_incent_amt_submtd , plan_incentive_paid_amt_after AS plan_incentive_paid_amt , plan_other_amt_paid_after AS plan_other_amt_paid , plan_returnd_coins_amt_after AS plan_returnd_coins_amt , plan_returnd_copay_amt_after AS plan_returnd_copay_amt , plan_returnd_cost_amt_after AS plan_returnd_cost_amt , plan_returnd_fee_amt_after AS plan_returnd_fee_amt , plan_returnd_tax_amt_after AS plan_returnd_tax_amt , plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt , plan_total_paid_amt_after AS plan_total_paid_amt , plan_other_amt_paid_type_after AS plan_other_amt_paid_type , med_partd_notice_ind_after AS med_partd_notice_ind , med_partd_print_dttm_after AS med_partd_print_dttm , ben_stg_qualifier_1_after AS ben_stg_qualifier_1 , ben_stg_qualifier_2_after AS ben_stg_qualifier_2 , ben_stg_qualifier_3_after AS ben_stg_qualifier_3 , ben_stg_qualifier_4_after AS ben_stg_qualifier_4 , ben_stg_amount_1_after AS ben_stg_amount_1 , ben_stg_amount_2_after AS ben_stg_amount_2 , ben_stg_amount_3_after AS ben_stg_amount_3 , ben_stg_amount_4_after AS ben_stg_amount_4 , coupon_drug_id_after AS coupon_drug_id , cob_coupon_drug_id_after AS cob_coupon_drug_id , coupon_ind_after AS coupon_ind , cob_coupon_ind_after AS cob_coupon_ind , other_coverage_cd_after AS other_coverage_cd , cob_other_coverage_cd_after AS cob_other_coverage_cd , cob_place_of_service_after AS cob_place_of_service , cob_rx_denial_ovride_cd_after AS cob_rx_denial_ovride_cd , cob_rx_denial_ovride_cd2_after AS cob_rx_denial_ovride_cd2 , cob_rx_denial_ovride_cd3_after AS cob_rx_denial_ovride_cd3 , medigap_id_after AS medigap_id , pat_pickup_gov_auth_id_after AS pat_pickup_gov_auth_id , pat_pickup_rel_cd_after AS pat_pickup_rel_cd , place_of_service_after AS place_of_service  , prior_auth_cd_after  AS prior_auth_cd , prior_auth_nbr_after AS prior_auth_nbr , rx_denial_override_cd_after AS rx_denial_override_cd , rx_denial_override_cd_2_after AS rx_denial_override_cd_2 , rx_denial_override_cd_3_after AS rx_denial_override_cd_3 , pat_pickup_id_qlfr_after AS pat_pickup_id_qlfr , db_bin_nbr_after AS db_bin_nbr , db_cob_bin_nbr_after AS db_cob_bin_nbr , db_proc_ctrl_nbr_after AS db_proc_ctrl_nbr , db_cob_proc_ctrl_nbr_after AS db_cob_proc_ctrl_nbr , db_plan_group_nbr_after AS db_plan_group_nbr , db_cob_plan_group_nbr_after AS db_cob_plan_group_nbr , source_system_name_after AS source_system_name , source_sys_trans_id_after AS source_sys_trans_id , org_entered_dttm_after AS org_entered_dttm , wo_correlation_id_after AS wo_correlation_id , wo_rx_count_after AS wo_rx_count , short_fill_ind_after AS short_fill_ind , pay_cd_after AS pay_cd , filling_store_nbr_after as filling_store_nbr, fill_verified_store_nbr_after as fill_verified_store_nbr, mult_prod_review_ind_after as mult_prod_review_ind, pat_selct_user_id_after as pat_selct_user_id, pbr_selct_user_id_after as pbr_selct_user_id, pat_selct_dttm_after as pat_selct_dttm, pbr_selct_dttm_after as pbr_selct_dttm, pat_selct_str_nbr_after as pat_selct_str_nbr, pbr_selct_str_nbr_after as pbr_selct_str_nbr, ntt_ind_after as ntt_ind, '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from gg_tbf0_update"""




pTgtInsBfrAftXfr = """Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id , src_partition_nbr_after AS src_partition_nbr , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , fill_status_cd_after AS fill_status_cd , fill_qty_dispensed_after AS fill_qty_dispensed , fill_days_supply_after AS fill_days_supply , fill_pay_method_cd_after AS fill_pay_method_cd , fill_awp_cost_amt_after AS fill_awp_cost_amt , fill_discount_cd_after AS fill_discount_cd , fill_discount_amt_after AS fill_discount_amt , fill_retail_price_amt_after AS fill_retail_price_amt , fill_label_price_amt_after AS fill_label_price_amt , fill_price_override_amt_after AS fill_price_override_amt , fill_sold_amt_after AS fill_sold_amt , fill_savings_amt_after AS fill_savings_amt , fill_enter_user_id_after AS fill_enter_user_id , fill_enter_dttm_after AS fill_enter_dttm , fill_verified_user_id_after AS fill_verified_user_id , fill_verified_dttm_after AS fill_verified_dttm , fill_sold_dttm_after AS fill_sold_dttm , fill_prorated_price_ind_after AS fill_prorated_price_ind , fill_adjudication_cd_after AS fill_adjudication_cd , plan_id_after AS plan_id , claim_reference_nbr_after AS claim_reference_nbr , plan_ar_amt_after AS plan_ar_amt , plan_copay_amt_after AS plan_copay_amt , fill_type_cd_after AS fill_type_cd , general_recipient_nbr_after AS general_recipient_nbr , plan_tax_amt_after AS plan_tax_amt , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , partial_fill_cd_after AS partial_fill_cd , accept_consult_ind_after AS accept_consult_ind , plan_other_amt_after AS plan_other_amt , cob_fill_adjudication_cd_after AS cob_fill_adjudication_cd , cob_plan_id_after AS cob_plan_id , cob_claim_ref_nbr_after AS cob_claim_ref_nbr , cob_plan_copay_amt_after AS cob_plan_copay_amt , cob_gen_recipient_nbr_after AS cob_gen_recipient_nbr , cob_plan_tax_amt_after AS cob_plan_tax_amt , cob_plan_ar_amt_after AS cob_plan_ar_amt , cash_disc_sav_amt_after AS cash_disc_sav_amt , fill_deleted_dttm_after AS fill_deleted_dttm , routing_store_tech_inits_after AS routing_store_tech_inits , fill_data_rev_id_after AS fill_data_rev_id , fill_data_rev_dttm_after AS fill_data_rev_dttm , filling_user_id_after AS filling_user_id , filling_dttm_after AS filling_dttm , override_user_id_after AS override_user_id , override_dttm_after AS override_dttm , entered_store_nbr_after AS entered_store_nbr , reviewed_store_nbr_after AS reviewed_store_nbr , fill_nbr_dispensed_after AS fill_nbr_dispensed , fax_image_id_after AS fax_image_id , dl_reject_cd_01_after AS dl_reject_cd_01 , cob_dl_reject_cd_01_after AS cob_dl_reject_cd_01 , fill_adjudication_dttm_after AS fill_adjudication_dttm , cob_fill_adj_dttm_after AS cob_fill_adj_dttm , data_rev_spec_id_after AS data_rev_spec_id , data_rev_spec_dttm_after AS data_rev_spec_dttm , data_rev_spec_store_nbr_after AS data_rev_spec_store_nbr , fill_rph_of_record_id_after AS fill_rph_of_record_id , cob_dl_reject_cd_02_after AS cob_dl_reject_cd_02 , cob_dl_reject_cd_03_after AS cob_dl_reject_cd_03 , cob_dl_reject_cd_04_after AS cob_dl_reject_cd_04 , cob_dl_reject_cd_05_after AS cob_dl_reject_cd_05 , amt_attributed_to_tax_after AS amt_attributed_to_tax , cob_plan_gross_due_amt_after AS cob_plan_gross_due_amt , cob_pln_incnt_amt_submtd_after AS cob_pln_incnt_amt_submtd , plan_gross_due_amt_after AS plan_gross_due_amt , plan_incent_amt_submtd_after AS plan_incent_amt_submtd , plan_incentive_paid_amt_after AS plan_incentive_paid_amt , plan_other_amt_paid_after AS plan_other_amt_paid , plan_returnd_coins_amt_after AS plan_returnd_coins_amt , plan_returnd_copay_amt_after AS plan_returnd_copay_amt , plan_returnd_cost_amt_after AS plan_returnd_cost_amt , plan_returnd_fee_amt_after AS plan_returnd_fee_amt , plan_returnd_tax_amt_after AS plan_returnd_tax_amt , plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt , plan_total_paid_amt_after AS plan_total_paid_amt , plan_other_amt_paid_type_after AS plan_other_amt_paid_type , med_partd_notice_ind_after AS med_partd_notice_ind , med_partd_print_dttm_after AS med_partd_print_dttm , ben_stg_qualifier_1_after AS ben_stg_qualifier_1 , ben_stg_qualifier_2_after AS ben_stg_qualifier_2 , ben_stg_qualifier_3_after AS ben_stg_qualifier_3 , ben_stg_qualifier_4_after AS ben_stg_qualifier_4 , ben_stg_amount_1_after AS ben_stg_amount_1 , ben_stg_amount_2_after AS ben_stg_amount_2 , ben_stg_amount_3_after AS ben_stg_amount_3 , ben_stg_amount_4_after AS ben_stg_amount_4 , coupon_drug_id_after AS coupon_drug_id , cob_coupon_drug_id_after AS cob_coupon_drug_id , coupon_ind_after AS coupon_ind , cob_coupon_ind_after AS cob_coupon_ind , other_coverage_cd_after AS other_coverage_cd , cob_other_coverage_cd_after AS cob_other_coverage_cd , cob_place_of_service_after AS cob_place_of_service , cob_rx_denial_ovride_cd_after AS cob_rx_denial_ovride_cd , cob_rx_denial_ovride_cd2_after AS cob_rx_denial_ovride_cd2 , cob_rx_denial_ovride_cd3_after AS cob_rx_denial_ovride_cd3 , medigap_id_after AS medigap_id , pat_pickup_gov_auth_id_after AS pat_pickup_gov_auth_id , pat_pickup_rel_cd_after AS pat_pickup_rel_cd , place_of_service_after AS place_of_service  , prior_auth_cd_after  AS prior_auth_cd , prior_auth_nbr_after AS prior_auth_nbr , rx_denial_override_cd_after AS rx_denial_override_cd , rx_denial_override_cd_2_after AS rx_denial_override_cd_2 , rx_denial_override_cd_3_after AS rx_denial_override_cd_3 , pat_pickup_id_qlfr_after AS pat_pickup_id_qlfr , db_bin_nbr_after AS db_bin_nbr , db_cob_bin_nbr_after AS db_cob_bin_nbr , db_proc_ctrl_nbr_after AS db_proc_ctrl_nbr , db_cob_proc_ctrl_nbr_after AS db_cob_proc_ctrl_nbr , db_plan_group_nbr_after AS db_plan_group_nbr , db_cob_plan_group_nbr_after AS db_cob_plan_group_nbr , source_system_name_after AS source_system_name , source_sys_trans_id_after AS source_sys_trans_id , org_entered_dttm_after AS org_entered_dttm , wo_correlation_id_after AS wo_correlation_id , wo_rx_count_after AS wo_rx_count , short_fill_ind_after AS short_fill_ind , pay_cd_after AS pay_cd , filling_store_nbr_after as filling_store_nbr, fill_verified_store_nbr_after as fill_verified_store_nbr, mult_prod_review_ind_after as mult_prod_review_ind, pat_selct_user_id_after as pat_selct_user_id, pbr_selct_user_id_after as pbr_selct_user_id, pat_selct_dttm_after as pat_selct_dttm, pbr_selct_dttm_after as pbr_selct_dttm, pat_selct_str_nbr_after as pat_selct_str_nbr, pbr_selct_str_nbr_after as pbr_selct_str_nbr, ntt_ind_after as ntt_ind, '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from nr_insert_check"""


# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)


# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 


gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)
 
#display(etl_tbf0_reformat)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))

#display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
#display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ENTER_DTTM",trim("FILL_ENTER_DTTM"))\
.withColumn("FILL_VERIFIED_DTTM",trim("FILL_VERIFIED_DTTM"))\
.withColumn("FILL_SOLD_DTTM",trim("FILL_SOLD_DTTM"))\
.withColumn("FILL_DELETED_DTTM",trim("FILL_DELETED_DTTM"))\
.withColumn("FILL_DATA_REV_DTTM",trim("FILL_DATA_REV_DTTM"))\
.withColumn("FILLING_DTTM",trim("FILLING_DTTM"))\
.withColumn("FILL_ADJUDICATION_DTTM",trim("FILL_ADJUDICATION_DTTM"))\
.withColumn("UPDATE_DTTM",trim("UPDATE_DTTM"))\
.withColumn("OVERRIDE_DTTM",trim("OVERRIDE_DTTM"))\
.withColumn("COB_FILL_ADJ_DTTM",trim("COB_FILL_ADJ_DTTM"))\
.withColumn("DATA_REV_SPEC_DTTM",trim("DATA_REV_SPEC_DTTM"))\
.withColumn("MED_PARTD_PRINT_DTTM",trim("MED_PARTD_PRINT_DTTM"))\
.withColumn("ORG_ENTERED_DTTM",trim("ORG_ENTERED_DTTM"))


#display(etl_tbf0_reformat_cdc_check_notnull)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ENTER_DTTM",concat(split(col("FILL_ENTER_DTTM"),":")[0],split(col("FILL_ENTER_DTTM"),":")[1],lit(":"),split(col("FILL_ENTER_DTTM"),":")[2],lit(":"),split(col("FILL_ENTER_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_VERIFIED_DTTM",concat(split(col("FILL_VERIFIED_DTTM"),":")[0],split(col("FILL_VERIFIED_DTTM"),":")[1],lit(":"),split(col("FILL_VERIFIED_DTTM"),":")[2],lit(":"),split(col("FILL_VERIFIED_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_SOLD_DTTM",concat(split(col("FILL_SOLD_DTTM"),":")[0],split(col("FILL_SOLD_DTTM"),":")[1],lit(":"),split(col("FILL_SOLD_DTTM"),":")[2],lit(":"),split(col("FILL_SOLD_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_DELETED_DTTM",concat(split(col("FILL_DELETED_DTTM"),":")[0],split(col("FILL_DELETED_DTTM"),":")[1],lit(":"),split(col("FILL_DELETED_DTTM"),":")[2],lit(":"),split(col("FILL_DELETED_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_DATA_REV_DTTM",concat(split(col("FILL_DATA_REV_DTTM"),":")[0],split(col("FILL_DATA_REV_DTTM"),":")[1],lit(":"),split(col("FILL_DATA_REV_DTTM"),":")[2],lit(":"),split(col("FILL_DATA_REV_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILLING_DTTM",concat(split(col("FILLING_DTTM"),":")[0],split(col("FILLING_DTTM"),":")[1],lit(":"),split(col("FILLING_DTTM"),":")[2],lit(":"),split(col("FILLING_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ADJUDICATION_DTTM",concat(split(col("FILL_ADJUDICATION_DTTM"),":")[0],split(col("FILL_ADJUDICATION_DTTM"),":")[1],lit(":"),split(col("FILL_ADJUDICATION_DTTM"),":")[2],lit(":"),split(col("FILL_ADJUDICATION_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("UPDATE_DTTM",concat(split(col("UPDATE_DTTM"),":")[0],split(col("UPDATE_DTTM"),":")[1],lit(":"),split(col("UPDATE_DTTM"),":")[2],lit(":"),split(col("UPDATE_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("OVERRIDE_DTTM",concat(split(col("OVERRIDE_DTTM"),":")[0],split(col("OVERRIDE_DTTM"),":")[1],lit(":"),split(col("OVERRIDE_DTTM"),":")[2],lit(":"),split(col("OVERRIDE_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("COB_FILL_ADJ_DTTM",concat(split(col("COB_FILL_ADJ_DTTM"),":")[0],split(col("COB_FILL_ADJ_DTTM"),":")[1],lit(":"),split(col("COB_FILL_ADJ_DTTM"),":")[2],lit(":"),split(col("COB_FILL_ADJ_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("DATA_REV_SPEC_DTTM",concat(split(col("DATA_REV_SPEC_DTTM"),":")[0],split(col("DATA_REV_SPEC_DTTM"),":")[1],lit(":"),split(col("DATA_REV_SPEC_DTTM"),":")[2],lit(":"),split(col("DATA_REV_SPEC_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("MED_PARTD_PRINT_DTTM",concat(split(col("MED_PARTD_PRINT_DTTM"),":")[0],split(col("MED_PARTD_PRINT_DTTM"),":")[1],lit(":"),split(col("MED_PARTD_PRINT_DTTM"),":")[2],lit(":"),split(col("MED_PARTD_PRINT_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("ORG_ENTERED_DTTM",concat(split(col("ORG_ENTERED_DTTM"),":")[0],split(col("ORG_ENTERED_DTTM"),":")[1],lit(":"),split(col("ORG_ENTERED_DTTM"),":")[2],lit(":"),split(col("ORG_ENTERED_DTTM"),":")[3]))
# etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("pat_selct_dttm",concat(split(col("pat_selct_dttm"),":")[0],split(col("pat_selct_dttm"),":")[1],lit(":"),split(col("pat_selct_dttm"),":")[2],lit(":"),split(col("pat_selct_dttm"),":")[3]))
# etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("pbr_selct_dttm",concat(split(col("pbr_selct_dttm"),":")[0],split(col("pbr_selct_dttm"),":")[1],lit(":"),split(col("pbr_selct_dttm"),":")[2],lit(":"),split(col("pbr_selct_dttm"),":")[3]))

#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

df_final = etl_tbf0_reformat_cdc_check_notnull.drop("tracking_id","partition_column")
df_final_typeCast = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
  .withColumn("fill_enter_dttm", to_timestamp(df_final["fill_enter_dttm"]))\
  .withColumn("fill_verified_dttm", to_timestamp(df_final["fill_verified_dttm"]))\
  .withColumn("fill_sold_dttm", to_timestamp(df_final["fill_sold_dttm"]))\
  .withColumn("fill_deleted_dttm", to_timestamp(df_final["fill_deleted_dttm"]))\
  .withColumn("fill_data_rev_dttm", to_timestamp(df_final["fill_data_rev_dttm"]))\
  .withColumn("filling_dttm", to_timestamp(df_final["filling_dttm"]))\
  .withColumn("fill_adjudication_dttm", to_timestamp(df_final["fill_adjudication_dttm"]))\
  .withColumn("update_dttm", to_timestamp(df_final["update_dttm"]))\
  .withColumn("override_dttm", to_timestamp(df_final["override_dttm"]))\
  .withColumn("cob_fill_adj_dttm", to_timestamp(df_final["cob_fill_adj_dttm"]))\
  .withColumn("data_rev_spec_dttm", to_timestamp(df_final["data_rev_spec_dttm"]))\
  .withColumn("med_partd_print_dttm", to_timestamp(df_final["med_partd_print_dttm"]))\
  .withColumn("org_entered_dttm", to_timestamp(df_final["org_entered_dttm"]))\
  .withColumn("cdc_operation_type_cd", substring(col("cdc_operation_type_cd"),0,20))\
  .withColumn("cdc_before_after_cd", substring(col("cdc_before_after_cd"),0,10))\
  .withColumn("cdc_txn_position_cd", substring(col("cdc_txn_position_cd"),0,10))\
  .withColumn("fill_status_cd", substring(col("fill_status_cd"),0,2))\
  .withColumn("fill_discount_cd", substring(col("fill_discount_cd"),0,1))\
  .withColumn("plan_id", substring(col("plan_id"),0,8))\
  .withColumn("fill_type_cd", substring(col("fill_type_cd"),0,1))\
  .withColumn("partial_fill_cd", substring(col("partial_fill_cd"),0,1))\
  .withColumn("fill_adjudication_cd", substring(col("fill_adjudication_cd"),0,1))\
  .withColumn("cob_claim_ref_nbr", substring(col("cob_claim_ref_nbr"),0,20))\
  .withColumn("claim_reference_nbr", substring(col("claim_reference_nbr"),0,20))\
  .withColumn("cob_fill_adjudication_cd", substring(col("cob_fill_adjudication_cd"),0,1))\
  .withColumn("cob_plan_id", substring(col("cob_plan_id"),0,8))\
  .withColumn("fill_pay_method_cd", substring(col("fill_pay_method_cd"),0,1))\
  .withColumn("general_recipient_nbr", substring(col("general_recipient_nbr"),0,21))\
  .withColumn("accept_consult_ind", substring(col("accept_consult_ind"),0,1))\
  .withColumn("routing_store_tech_inits", substring(col("routing_store_tech_inits"),0,3))\
  .withColumn("fax_image_id", substring(col("fax_image_id"),0,20))\
  .withColumn("dl_reject_cd_01", substring(col("dl_reject_cd_01"),0,3))\
  .withColumn("cob_dl_reject_cd_01", substring(col("cob_dl_reject_cd_01"),0,3))\
  .withColumn("cob_gen_recipient_nbr", substring(col("cob_gen_recipient_nbr"),0,21))\
  .withColumn("cob_dl_reject_cd_02", substring(col("cob_dl_reject_cd_02"),0,3))\
  .withColumn("cob_dl_reject_cd_03", substring(col("cob_dl_reject_cd_03"),0,3))\
  .withColumn("cob_dl_reject_cd_04", substring(col("cob_dl_reject_cd_04"),0,3))\
  .withColumn("cob_dl_reject_cd_05", substring(col("cob_dl_reject_cd_05"),0,3))\
  .withColumn("plan_other_amt_paid_type", substring(col("plan_other_amt_paid_type"),0,2))\
  .withColumn("med_partd_notice_ind", substring(col("med_partd_notice_ind"),0,1))\
  .withColumn("ben_stg_qualifier_1", substring(col("ben_stg_qualifier_1"),0,2))\
  .withColumn("ben_stg_qualifier_2", substring(col("ben_stg_qualifier_2"),0,2))\
  .withColumn("ben_stg_qualifier_3", substring(col("ben_stg_qualifier_3"),0,2))\
  .withColumn("ben_stg_qualifier_4", substring(col("ben_stg_qualifier_4"),0,2))\
  .withColumn("coupon_ind", substring(col("coupon_ind"),0,1))\
  .withColumn("cob_coupon_ind", substring(col("cob_coupon_ind"),0,1))\
  .withColumn("pat_pickup_gov_auth_id", substring(col("pat_pickup_gov_auth_id"),0,3))\
  .withColumn("pat_pickup_id_qlfr", substring(col("pat_pickup_id_qlfr"),0,2))\
  .withColumn("pat_pickup_rel_cd", substring(col("pat_pickup_rel_cd"),0,2))\
  .withColumn("source_system_name", substring(col("source_system_name"),0,10))\
  .withColumn("source_sys_trans_id", substring(col("source_sys_trans_id"),0,35))\
  .withColumn("prior_auth_cd", substring(col("prior_auth_cd"),0,1))\
  .withColumn("prior_auth_nbr", substring(col("prior_auth_nbr"),0,11))\
  .withColumn("db_bin_nbr", substring(col("db_bin_nbr"),0,6))\
  .withColumn("db_cob_bin_nbr", substring(col("db_cob_bin_nbr"),0,6))\
  .withColumn("db_proc_ctrl_nbr", substring(col("db_proc_ctrl_nbr"),0,10))\
  .withColumn("db_cob_proc_ctrl_nbr", substring(col("db_cob_proc_ctrl_nbr"),0,10))\
  .withColumn("db_plan_group_nbr", substring(col("db_plan_group_nbr"),0,15))\
  .withColumn("db_cob_plan_group_nbr", substring(col("db_cob_plan_group_nbr"),0,15))\
  .withColumn("wo_correlation_id", substring(col("wo_correlation_id"),0,35))\
  .withColumn("short_fill_ind", substring(col("short_fill_ind"),0,1))\
  .withColumn("pay_cd", trim(col("pay_cd")))
  #.withColumn("pat_selct_dttm", to_timestamp(df_final["pat_selct_dttm"]))\
  #.withColumn("pbr_selct_dttm", to_timestamp(df_final["pbr_selct_dttm"]))

df_final_typeCast = df_final_typeCast.withColumn("fill_sold_yr", lit("")) \
                                     .withColumn("fill_enter_mnth", lit(""))

df_final_check_blank = df_final_typeCast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in df_final_typeCast.columns])

df_final_notNull = df_final_check_blank.filter("store_nbr is not null and rx_nbr is not null")
#drop columns to match TL_ETL_TBF0_FILL
#df_final_drop_columns = df_final_notNull.drop("rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind")

df_final_columns = df_final_notNull.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","store_nbr","rx_nbr","fill_nbr","fill_partial_nbr","fill_status_cd","fill_qty_dispensed","fill_awp_cost_amt","fill_discount_cd","fill_discount_amt","fill_retail_price_amt","fill_sold_amt","fill_enter_user_id","fill_enter_dttm","fill_verified_user_id","fill_verified_dttm","fill_sold_dttm","plan_id","fill_type_cd","partial_fill_cd","fill_deleted_dttm","fill_data_rev_id","fill_data_rev_dttm","filling_user_id","filling_dttm","entered_store_nbr","reviewed_store_nbr","fill_nbr_dispensed","fill_adjudication_dttm","fill_adjudication_cd","cob_claim_ref_nbr","claim_reference_nbr","update_user_id","update_dttm","cob_fill_adjudication_cd","cob_plan_id","override_user_id","override_dttm","cob_fill_adj_dttm","src_partition_nbr","fill_days_supply","fill_label_price_amt","fill_pay_method_cd","plan_ar_amt","plan_copay_amt","plan_tax_amt","cob_plan_ar_amt","cob_plan_copay_amt","cob_plan_tax_amt","fill_price_override_amt","general_recipient_nbr","accept_consult_ind","plan_other_amt","cash_disc_sav_amt","routing_store_tech_inits","fax_image_id","dl_reject_cd_01","cob_dl_reject_cd_01","data_rev_spec_id","data_rev_spec_store_nbr","fill_rph_of_record_id","data_rev_spec_dttm","relocate_fm_str_nbr","cob_gen_recipient_nbr","cob_dl_reject_cd_02","cob_dl_reject_cd_03","cob_dl_reject_cd_04","cob_dl_reject_cd_05","amt_attributed_to_tax","cob_plan_gross_due_amt","cob_pln_incnt_amt_submtd","plan_gross_due_amt","plan_incent_amt_submtd","plan_incentive_paid_amt","plan_other_amt_paid","plan_returnd_coins_amt","plan_returnd_copay_amt","plan_returnd_cost_amt","plan_returnd_fee_amt","plan_returnd_tax_amt","plan_rtrnd_coins_amt","plan_total_paid_amt","plan_other_amt_paid_type","med_partd_notice_ind","med_partd_print_dttm","ben_stg_qualifier_1","ben_stg_qualifier_2","ben_stg_qualifier_3","ben_stg_qualifier_4","ben_stg_amount_1","ben_stg_amount_2","ben_stg_amount_3","ben_stg_amount_4","coupon_drug_id","cob_coupon_drug_id","coupon_ind","cob_coupon_ind","other_coverage_cd","cob_other_coverage_cd","org_entered_dttm","pat_pickup_gov_auth_id","pat_pickup_id_qlfr","pat_pickup_rel_cd","source_system_name","source_sys_trans_id","prior_auth_cd","prior_auth_nbr","db_bin_nbr","db_cob_bin_nbr","db_proc_ctrl_nbr","db_cob_proc_ctrl_nbr","db_plan_group_nbr","db_cob_plan_group_nbr","wo_correlation_id","wo_rx_count","short_fill_ind","pay_cd","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind","pat_selct_user_id","pbr_selct_user_id","pat_selct_dttm","pbr_selct_dttm","pat_selct_str_nbr","pbr_selct_str_nbr","ntt_ind","fill_sold_yr","fill_enter_mnth","rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3")

TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+'.TL_'+SNFL_TBL_NAME.split(".")[1]

delete_TL_table_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, TL_SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_TL_table_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

df_final_columns.write \
    .format("net.snowflake.spark.snowflake") \
    .mode("append") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", TL_SNFL_TBL_NAME) \
    .option("ON_ERROR","SKIP_FILE")\
    .save()   
    
    

# COMMAND ----------

df_final_cons_columns= df_final_notNull.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","store_nbr","rx_nbr","fill_nbr","fill_partial_nbr","fill_status_cd","fill_qty_dispensed","fill_awp_cost_amt","fill_discount_cd","fill_discount_amt","fill_retail_price_amt","fill_sold_amt","fill_enter_user_id","fill_enter_dttm","fill_verified_user_id","fill_verified_dttm","fill_sold_dttm","plan_id","fill_type_cd","partial_fill_cd","fill_deleted_dttm","fill_data_rev_id","fill_data_rev_dttm","filling_user_id","filling_dttm","entered_store_nbr","reviewed_store_nbr","fill_nbr_dispensed","fill_adjudication_dttm","fill_adjudication_cd","cob_claim_ref_nbr","claim_reference_nbr","update_user_id","update_dttm","cob_fill_adjudication_cd","cob_plan_id","override_user_id","override_dttm","cob_fill_adj_dttm","src_partition_nbr","fill_days_supply","fill_label_price_amt","fill_pay_method_cd","plan_ar_amt","plan_copay_amt","plan_tax_amt","cob_plan_ar_amt","cob_plan_copay_amt","cob_plan_tax_amt","fill_price_override_amt","general_recipient_nbr","accept_consult_ind","plan_other_amt","cash_disc_sav_amt","routing_store_tech_inits","fax_image_id","dl_reject_cd_01","cob_dl_reject_cd_01","data_rev_spec_id","data_rev_spec_store_nbr","fill_rph_of_record_id","data_rev_spec_dttm","relocate_fm_str_nbr","cob_gen_recipient_nbr","cob_dl_reject_cd_02","cob_dl_reject_cd_03","cob_dl_reject_cd_04","cob_dl_reject_cd_05","amt_attributed_to_tax","cob_plan_gross_due_amt","cob_pln_incnt_amt_submtd","plan_gross_due_amt","plan_incent_amt_submtd","plan_incentive_paid_amt","plan_other_amt_paid","plan_returnd_coins_amt","plan_returnd_copay_amt","plan_returnd_cost_amt","plan_returnd_fee_amt","plan_returnd_tax_amt","plan_rtrnd_coins_amt","plan_total_paid_amt","plan_other_amt_paid_type","med_partd_notice_ind","med_partd_print_dttm","ben_stg_qualifier_1","ben_stg_qualifier_2","ben_stg_qualifier_3","ben_stg_qualifier_4","ben_stg_amount_1","ben_stg_amount_2","ben_stg_amount_3","ben_stg_amount_4","coupon_drug_id","cob_coupon_drug_id","coupon_ind","cob_coupon_ind","other_coverage_cd","cob_other_coverage_cd","org_entered_dttm","pat_pickup_gov_auth_id","pat_pickup_id_qlfr","pat_pickup_rel_cd","source_system_name","source_sys_trans_id","prior_auth_cd","prior_auth_nbr","db_bin_nbr","db_cob_bin_nbr","db_proc_ctrl_nbr","db_cob_proc_ctrl_nbr","db_plan_group_nbr","db_cob_plan_group_nbr","wo_correlation_id","wo_rx_count","short_fill_ind",
"pay_cd")

CONS_TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+'.CONS_TL_'+SNFL_TBL_NAME.split(".")[1]

delete_CONS_TL_table_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, CONS_TL_SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_CONS_TL_table_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

df_final_cons_columns.write \
    .format("net.snowflake.spark.snowflake") \
    .mode("append") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", CONS_TL_SNFL_TBL_NAME) \
    .option("ON_ERROR","SKIP_FILE")\
    .save()

# COMMAND ----------

#drop columns to map table schema
#df_final_drop_columns = df_final_notNull.drop("rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3","pay_cd","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind")
df_final_etl_columns = df_final_notNull.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","store_nbr","rx_nbr","fill_nbr","fill_partial_nbr","fill_status_cd","fill_qty_dispensed","fill_awp_cost_amt","fill_discount_cd","fill_discount_amt","fill_retail_price_amt","fill_sold_amt","fill_enter_user_id","fill_enter_dttm","fill_verified_user_id","fill_verified_dttm","fill_sold_dttm","plan_id","fill_type_cd","partial_fill_cd","fill_deleted_dttm","fill_data_rev_id","fill_data_rev_dttm","filling_user_id","filling_dttm","entered_store_nbr","reviewed_store_nbr","fill_nbr_dispensed","fill_adjudication_dttm","fill_adjudication_cd","cob_claim_ref_nbr","claim_reference_nbr","update_user_id","update_dttm","cob_fill_adjudication_cd","cob_plan_id","override_user_id","override_dttm","cob_fill_adj_dttm","src_partition_nbr","fill_days_supply","fill_label_price_amt","fill_pay_method_cd","plan_ar_amt","plan_copay_amt","plan_tax_amt","cob_plan_ar_amt","cob_plan_copay_amt","cob_plan_tax_amt","fill_price_override_amt","general_recipient_nbr","accept_consult_ind","plan_other_amt","cash_disc_sav_amt","routing_store_tech_inits","fax_image_id","dl_reject_cd_01","cob_dl_reject_cd_01","data_rev_spec_id","data_rev_spec_store_nbr","fill_rph_of_record_id","data_rev_spec_dttm","relocate_fm_str_nbr","cob_gen_recipient_nbr","cob_dl_reject_cd_02","cob_dl_reject_cd_03","cob_dl_reject_cd_04","cob_dl_reject_cd_05","amt_attributed_to_tax","cob_plan_gross_due_amt","cob_pln_incnt_amt_submtd","plan_gross_due_amt","plan_incent_amt_submtd","plan_incentive_paid_amt","plan_other_amt_paid","plan_returnd_coins_amt","plan_returnd_copay_amt","plan_returnd_cost_amt","plan_returnd_fee_amt","plan_returnd_tax_amt","plan_rtrnd_coins_amt","plan_total_paid_amt","plan_other_amt_paid_type","med_partd_notice_ind","med_partd_print_dttm","ben_stg_qualifier_1","ben_stg_qualifier_2","ben_stg_qualifier_3","ben_stg_qualifier_4","ben_stg_amount_1","ben_stg_amount_2","ben_stg_amount_3","ben_stg_amount_4","coupon_drug_id","cob_coupon_drug_id","coupon_ind","cob_coupon_ind","other_coverage_cd","cob_other_coverage_cd","org_entered_dttm","pat_pickup_gov_auth_id","pat_pickup_id_qlfr","pat_pickup_rel_cd","source_system_name","source_sys_trans_id","prior_auth_cd","prior_auth_nbr","db_bin_nbr","db_cob_bin_nbr","db_proc_ctrl_nbr","db_cob_proc_ctrl_nbr","db_plan_group_nbr","db_cob_plan_group_nbr","wo_correlation_id","wo_rx_count","short_fill_ind","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind","pat_selct_user_id","pbr_selct_user_id","pat_selct_dttm","pbr_selct_dttm","pat_selct_str_nbr","pbr_selct_str_nbr","ntt_ind","fill_sold_yr","fill_enter_mnth","rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3")

# COMMAND ----------

#display(df_final_etl_columns)

# COMMAND ----------

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

df_final_etl_columns.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", SNFL_TBL_NAME) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit(PAR_WRITEAPI_VALUE2);
                   
print("Write API successfully executed...")
dbutils.notebook.exit("ETL_TBF0_FILL_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")

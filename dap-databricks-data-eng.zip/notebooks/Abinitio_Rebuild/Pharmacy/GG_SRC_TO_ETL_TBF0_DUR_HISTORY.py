# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220725183013")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","/pharmacy_healthcare/patient/output")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_dur_history")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","/pharmacy_healthcare/patient/reject")
# dbutils.widgets.text("PAR_DB_FEED_NAME","GG_TBF0_DUR_HISTORY_dat,GG_TBF0_DUR_HISTORY_control")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_DUR_HISTORY_STG")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_FILE_LIST","{\"GG_TBF0_DUR_HISTORY_control\":[{\"assetid\":821302,\"assetname\":\"PRDRX2STAGE.GG_TBF0_DUR_HISTORY_1.control\",\"assetcurrentlocation\":\"/pharmacy_healthcare/patient_services/icplus/2022/05/11/\"}],\"GG_TBF0_DUR_HISTORY_dat\":[{\"assetid\":125090,\"assetname\":\"PRDRX2STAGE_GG_TBF0_DUR_HISTORY_1_2022-05-09_23-39-36_01824_data.dsv\",\"assetcurrentlocation\":\"/pharmacy_healthcare/patient_services/icplus/2022/05/11/\"}]}")

# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL",'https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate')

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")
FEED_NAME = dbutils.widgets.get("PAR_DB_FEED_NAME")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

# print (OUT_FILEPATH)
# print (REJ_FILE_NOISE_RMV)
# print(REJ_FILE_PAT_MOD)
# print(REJ_FILE_UPD_NULL)
# print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

Input_File_List = dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

#Define Input File Schema
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'src_partition_nbr',
'src_partition_nbr_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_partial_nbr',
'fill_partial_nbr_after',
'dur_interaction_nbr',
'dur_interaction_nbr_after',
'dur_type_cd',
'dur_type_cd_after',
'dur_severity_cd',
'dur_severity_cd_after',
'dur_overridden_ind',
'dur_overridden_ind_after',
'dur_source_cd',
'dur_source_cd_after',
'dur_intervention_cd',
'dur_intervention_cd_after',
'dur_outcome_cd',
'dur_outcome_cd_after',
'dur_comment',
'dur_comment_after',
'dur_override_dttm',
'dur_override_dttm_after',
'dur_override_user_id',
'dur_override_user_id_after',
'dur_comment_cd',
'dur_comment_cd_after',
'clinical_review_str_nbr',
'clinical_review_str_nbr_after',
'dur_opv_source_cd',
'dur_opv_source_cd_after',
'dur_description',
'dur_description_after',
'dose_values',                  
'dose_values_after',             
'icplus_update_dttm',           
'icplus_update_dttm_after']

print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 55:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 56:
      return True
  else:
    if val_len != 56:
      return True

# COMMAND ----------

# Read input files
in_text = spark.read.text(readList)
in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd


# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len = 56

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 53
print(f"Bad records count {rd_bad.count()}") # != 53

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
#Extarct filename
from pyspark.sql.functions import input_file_name
df = spark.createDataFrame(rd_good, schema)
df = df.withColumn("fileName",input_file_name())

#Extract partition number from file name
df = df.withColumn("src_partition_nbr",split("fileName","_")[7])
df = df.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df = df.drop("fileName")

#display(df)

# COMMAND ----------

#function to remove "" & \\ <Only when the file is encrypted?
def handlEscpeQuotes(val):
 if not val:
   return ""
  
  #remove rightmost "
 outval = val[0:-1]
  #remove leftmost "
 outval = outval.lstrip("\"")
  #replace double \\ with \
 outval = outval.replace("\\\\","\\")
  #replace double \" with "
 outval = outval.replace("\\\"","\"")
 return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

from functools import reduce
df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
#     df.columns,
#     df
# ))

df_gg = df.withColumn("table_name",lit("gg_tbf0_dur_history")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 

df_gg.createOrReplaceTempView("raw_gg_dur_history")


# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"


# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_dur_history where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_gg_dur_history where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual
nr_input_filter_nopartition_sql = "select * from raw_gg_dur_history where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#Fetching rx_max and rx_trans_max as values
# rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
# rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max



# #Applying rx_cutoff range on rx related tables
nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)

# #Applying trans_cutoff range on trans related tables
nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)

nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)


#Remove duplicates
dedup_group = nr_input_file_final.distinct()
dedup_group.createOrReplaceTempView("dedup_group")

#display(dedup_group)

#nr spacetrim
for col in dedup_group.columns:
    nr_spacetrim = dedup_group.withColumn(col, when(ltrim(rtrim(dedup_group[col])) == "",None).otherwise(ltrim(rtrim(dedup_group[col]))))

nr_spacetrim.createOrReplaceTempView("nr_spacetrim")

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from raw_gg_dur_history where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_gg_dur_history where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_dur_history where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)


if nr_input_filter_rxpartition.count()==0 and  nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition

else:  
  sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0} where EDW_BATCH_ID='{1}'".format(ETL_HIVE_CUTOFF_TBL,BATCH_ID)
  df_cutoff_records_output=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFK_ETL_DB) \
     .option("query",sel_ETL_Hive_Cutoff_tbl) \
     .load()


  #cutoff_records_filter = df_cutoff_records_output.filter(col("EDW_BATCH_ID") == BATCH_ID & col("PROJ_NAME") == "WALGREENS")
  df_cutoff_records_output.createOrReplaceTempView("cutoff_records_filter")
  
  #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
  cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
  RX_CUT_OFF_MAX_DTTM as rx_max,
  CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
  CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
  from cutoff_records_filter""" 
  cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
 
  

  #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
  cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
  RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
  from cutoff_records_filter"""
  cutoff_range_trans = spark.sql(cutoff_range_trans_sql)


  #Fetching rx_max and rx_trans_max as values
  rx_max = cutoff_range_rx.select("rx_max")
  rx_trans_max = cutoff_range_trans.select("rx_trans_max")
  
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  
  #Applying rx_cutoff range on rx related tables
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck).filter(nr_input_filter_rxpartition.cdc_txn_commit_dttm < rx_max.collect()[0][0])
  
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual).filter(nr_input_filter_rxpartition.cdc_txn_commit_dttm <= rx_max.collect()[0][0])

  #Applying trans_cutoff range on trans related tables
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck).filter(nr_input_filter_transpartition.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0])
  
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual).filter(nr_input_filter_transpartition.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])
  
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)
  
#Remove duplicates
dedup_group = nr_input_file_final.distinct()

#nr spacetrim
for col in dedup_group.columns:
    nr_spacetrim = dedup_group.withColumn(col, when(ltrim(rtrim(dedup_group[col])) == "",None).otherwise(ltrim(rtrim(dedup_group[col]))))

nr_spacetrim.createOrReplaceTempView("nr_spacetrim")



# COMMAND ----------

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL) AND ( cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND cdc_operation_type_cd_after IS NOT NULL) AND  (cdc_before_after_cd== 'BEFORE' AND cdc_before_after_cd IS NOT NULL )AND  ( cdc_operation_type_cd == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL) AND (cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL ) AND (cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL ) AND (cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL ) AND (dur_interaction_nbr == dur_interaction_nbr_after AND dur_interaction_nbr IS NOT NULL AND dur_interaction_nbr_after IS NOT NULL ) AND (fill_nbr == fill_nbr_after AND fill_nbr IS NOT NULL AND fill_nbr_after IS NOT NULL ) AND (fill_partial_nbr == fill_partial_nbr_after AND fill_partial_nbr IS NOT NULL AND fill_partial_nbr_after IS NOT NULL ) AND (rx_nbr == rx_nbr_after AND rx_nbr IS NOT NULL AND rx_nbr_after IS NOT NULL ) AND (store_nbr == store_nbr_after AND store_nbr IS NOT NULL AND store_nbr_after IS NOT NULL ) AND ( (dur_type_cd == dur_type_cd_after AND dur_type_cd IS NOT NULL AND dur_type_cd_after IS NOT NULL ) OR (  dur_type_cd IS NULL AND dur_type_cd_after IS NULL )) AND ( (dur_severity_cd == dur_severity_cd_after AND dur_severity_cd IS NOT NULL AND dur_severity_cd_after IS NOT NULL ) OR (  dur_severity_cd IS NULL AND dur_severity_cd_after IS NULL )) AND ( (dur_overridden_ind == dur_overridden_ind_after AND dur_overridden_ind IS NOT NULL AND dur_overridden_ind_after IS NOT NULL ) OR (  dur_overridden_ind IS NULL AND dur_overridden_ind_after IS NULL )) AND ( (dur_source_cd == dur_source_cd_after AND dur_source_cd IS NOT NULL AND dur_source_cd_after IS NOT NULL ) OR (  dur_source_cd IS NULL AND dur_source_cd_after IS NULL )) AND ( (dur_intervention_cd == dur_intervention_cd_after AND dur_intervention_cd IS NOT NULL AND dur_intervention_cd_after IS NOT NULL ) OR (  dur_intervention_cd IS NULL AND dur_intervention_cd_after IS NULL )) AND ( (dur_outcome_cd == dur_outcome_cd_after AND dur_outcome_cd IS NOT NULL AND dur_outcome_cd_after IS NOT NULL ) OR (  dur_outcome_cd IS NULL AND dur_outcome_cd_after IS NULL )) AND ( (dur_comment == dur_comment_after AND dur_comment IS NOT NULL AND dur_comment_after IS NOT NULL ) OR (  dur_comment IS NULL AND dur_comment_after IS NULL )) AND ( (dur_override_dttm == dur_override_dttm_after AND dur_override_dttm IS NOT NULL AND dur_override_dttm_after IS NOT NULL ) OR (  dur_override_dttm IS NULL AND dur_override_dttm_after IS NULL )) AND ( (dur_override_user_id == dur_override_user_id_after AND dur_override_user_id IS NOT NULL AND dur_override_user_id_after IS NOT NULL ) OR (  dur_override_user_id IS NULL AND dur_override_user_id_after IS NULL )) AND ( (dur_comment_cd == dur_comment_cd_after AND dur_comment_cd IS NOT NULL AND dur_comment_cd_after IS NOT NULL ) OR (  dur_comment_cd IS NULL AND dur_comment_cd_after IS NULL )) AND ( (clinical_review_str_nbr == clinical_review_str_nbr_after AND clinical_review_str_nbr IS NOT NULL AND clinical_review_str_nbr_after IS NOT NULL ) OR (  clinical_review_str_nbr IS NULL AND clinical_review_str_nbr_after IS NULL )) AND ( (dur_opv_source_cd == dur_opv_source_cd_after AND dur_opv_source_cd IS NOT NULL AND dur_opv_source_cd_after IS NOT NULL ) OR (  dur_opv_source_cd IS NULL AND dur_opv_source_cd_after IS NULL )) AND ( (dur_description == dur_description_after AND dur_description IS NOT NULL AND dur_description_after IS NOT NULL ) OR (  dur_description IS NULL AND dur_description_after IS NULL )) AND ( (dose_values == dose_values_after AND dose_values IS NOT NULL AND dose_values_after IS NOT NULL ) OR ( dose_values IS NULL AND dose_values_after IS NULL )) AND ( (icplus_update_dttm == icplus_update_dttm_after AND icplus_update_dttm IS NOT NULL AND icplus_update_dttm_after IS NOT NULL ) OR ( icplus_update_dttm IS NULL AND icplus_update_dttm_after IS NULL )) )" 


# COMMAND ----------

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

gg_tbf0_rejected_query = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(gg_tbf0_rejected_query)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 
  
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")


# COMMAND ----------

gg_tbf0_update_afr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm_after.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr_after.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr_after.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd_after.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id_after.alias("edw_batch_id"), \
                                           gg_tbf0_update.src_partition_nbr_after.alias("src_partition_nbr"), \
                                           gg_tbf0_update.store_nbr_after.alias("store_nbr"), \
                                           gg_tbf0_update.rx_nbr_after.alias("rx_nbr"), \
                                           gg_tbf0_update.fill_nbr_after.alias("fill_nbr"), \
                                           gg_tbf0_update.fill_partial_nbr_after.alias("fill_partial_nbr"), \
                                           gg_tbf0_update.dur_interaction_nbr_after.alias("dur_interaction_nbr"), \
                                           gg_tbf0_update.dur_type_cd_after.alias("dur_type_cd"), \
                                           gg_tbf0_update.dur_severity_cd_after.alias("dur_severity_cd"), \
                                           gg_tbf0_update.dur_overridden_ind_after.alias("dur_overridden_ind"), \
                                           gg_tbf0_update.dur_source_cd_after.alias("dur_source_cd"), \
                                           gg_tbf0_update.dur_intervention_cd_after.alias("dur_intervention_cd"), \
                                           gg_tbf0_update.dur_outcome_cd_after.alias("dur_outcome_cd"), \
                                           gg_tbf0_update.dur_comment_after.alias("dur_comment"), \
                                           gg_tbf0_update.dur_override_dttm_after.alias("dur_override_dttm"), \
                                           gg_tbf0_update.dur_override_user_id_after.alias("dur_override_user_id"), \
                                           gg_tbf0_update.dur_comment_cd_after.alias("dur_comment_cd"), \
                                           gg_tbf0_update.clinical_review_str_nbr_after.alias("clinical_review_str_nbr"), \
                                           gg_tbf0_update.dur_opv_source_cd_after.alias("dur_opv_source_cd"), \
                                           gg_tbf0_update.dur_description_after.alias("dur_description"), \
                                           gg_tbf0_update.dose_values_after.alias("dose_values"), \
                                           gg_tbf0_update.icplus_update_dttm_after.alias("icplus_update_dttm"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_update_bfr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm_after.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr_after.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr_after.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd_after.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id_after.alias("edw_batch_id"), \
                                           gg_tbf0_update.src_partition_nbr_after.alias("src_partition_nbr"), \
                                           gg_tbf0_update.store_nbr_after.alias("store_nbr"), \
                                           gg_tbf0_update.rx_nbr_after.alias("rx_nbr"), \
                                           gg_tbf0_update.fill_nbr_after.alias("fill_nbr"), \
                                           gg_tbf0_update.fill_partial_nbr_after.alias("fill_partial_nbr"), \
                                           gg_tbf0_update.dur_interaction_nbr_after.alias("dur_interaction_nbr"), \
                                           gg_tbf0_update.dur_type_cd_after.alias("dur_type_cd"), \
                                           gg_tbf0_update.dur_severity_cd_after.alias("dur_severity_cd"), \
                                           gg_tbf0_update.dur_overridden_ind_after.alias("dur_overridden_ind"), \
                                           gg_tbf0_update.dur_source_cd_after.alias("dur_source_cd"), \
                                           gg_tbf0_update.dur_intervention_cd_after.alias("dur_intervention_cd"), \
                                           gg_tbf0_update.dur_outcome_cd_after.alias("dur_outcome_cd"), \
                                           gg_tbf0_update.dur_comment_after.alias("dur_comment"), \
                                           gg_tbf0_update.dur_override_dttm_after.alias("dur_override_dttm"), \
                                           gg_tbf0_update.dur_override_user_id_after.alias("dur_override_user_id"), \
                                           gg_tbf0_update.dur_comment_cd_after.alias("dur_comment_cd"), \
                                           gg_tbf0_update.clinical_review_str_nbr_after.alias("clinical_review_str_nbr"), \
                                           gg_tbf0_update.dur_opv_source_cd_after.alias("dur_opv_source_cd"), \
                                           gg_tbf0_update.dur_description_after.alias("dur_description"), \
                                           gg_tbf0_update.dose_values_after.alias("dose_values"), \
                                           gg_tbf0_update.icplus_update_dttm_after.alias("icplus_update_dttm"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_insert_afr = nr_insert_check.select(nr_insert_check.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                            nr_insert_check.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                            nr_insert_check.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                            nr_insert_check.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                            nr_insert_check.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                            nr_insert_check.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                            nr_insert_check.edw_batch_id_after.alias("edw_batch_id"), \
                                            nr_insert_check.src_partition_nbr_after.alias("src_partition_nbr"), \
                                            nr_insert_check.store_nbr_after.alias("store_nbr"), \
                                            nr_insert_check.rx_nbr_after.alias("rx_nbr"), \
                                            nr_insert_check.fill_nbr_after.alias("fill_nbr"), \
                                            nr_insert_check.fill_partial_nbr_after.alias("fill_partial_nbr"), \
                                            nr_insert_check.dur_interaction_nbr_after.alias("dur_interaction_nbr"), \
                                            nr_insert_check.dur_type_cd_after.alias("dur_type_cd"), \
                                            nr_insert_check.dur_severity_cd_after.alias("dur_severity_cd"), \
                                            nr_insert_check.dur_overridden_ind_after.alias("dur_overridden_ind"), \
                                            nr_insert_check.dur_source_cd_after.alias("dur_source_cd"), \
                                            nr_insert_check.dur_intervention_cd_after.alias("dur_intervention_cd"), \
                                            nr_insert_check.dur_outcome_cd_after.alias("dur_outcome_cd"), \
                                            nr_insert_check.dur_comment_after.alias("dur_comment"), \
                                            nr_insert_check.dur_override_dttm_after.alias("dur_override_dttm"), \
                                            nr_insert_check.dur_override_user_id_after.alias("dur_override_user_id"), \
                                            nr_insert_check.dur_comment_cd_after.alias("dur_comment_cd"), \
                                            nr_insert_check.clinical_review_str_nbr_after.alias("clinical_review_str_nbr"), \
                                            nr_insert_check.dur_opv_source_cd_after.alias("dur_opv_source_cd"), \
                                            nr_insert_check.dur_description_after.alias("dur_description"), \
                                            nr_insert_check.dose_values_after.alias("dose_values"), \
                                            nr_insert_check.icplus_update_dttm_after.alias("icplus_update_dttm"), \
                                            nr_insert_check.table_name)


# COMMAND ----------

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"


pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"


# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")


# COMMAND ----------

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, store_nbr, rx_nbr, fill_nbr, fill_partial_nbr, dur_interaction_nbr, dur_type_cd, dur_severity_cd, dur_overridden_ind, dur_comment, CONCAT(substring(dur_override_dttm,0,10),' ',substring(dur_override_dttm,12,19),'.000000') AS dur_override_dttm, dur_comment_cd, dur_intervention_cd, dur_outcome_cd, src_partition_nbr, dur_source_cd, dur_override_user_id, (CASE WHEN (cdc_operation_type_cd=='INSERT') THEN store_nbr ELSE '' END) AS relocate_fm_str_nbr , clinical_review_str_nbr, dur_description, dur_opv_source_cd,dose_values, CONCAT(substring(icplus_update_dttm,0,10),' ',substring(icplus_update_dttm,12,19),'.000000') AS icplus_update_dttm "
#CONCAT(icplus_update_dttm,'.000000') AS icplus_update_dttm
#concat(substring(icplus_update_dttm,1,10),' ',substring(icplus_update_dttm,12,8),'.000000') as icplus_update_dttm


# COMMAND ----------

etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Remove Blank Values
for col in etl_tbf0_reformat.columns:
    etl_tbf0_reformat = etl_tbf0_reformat.withColumn(col, when(ltrim(rtrim(etl_tbf0_reformat[col])) == "",None).otherwise(ltrim(rtrim(etl_tbf0_reformat[col]))))
    
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())\
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
.withColumn("dur_override_dttm",to_timestamp(etl_tbf0_reformat["dur_override_dttm"])) \
.withColumn("icplus_update_dttm",to_timestamp(etl_tbf0_reformat["icplus_update_dttm"]))

etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)


# COMMAND ----------

#display(etl_tbf0_reformat)

# COMMAND ----------

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

#Load ETL_TBF0_PATIENT_MERGE formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", SNFL_TBL_NAME) \
        .option("truncate_columns","on")\
        .option("continue_on_error","on")\
        .save()



TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, TL_SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


etl_tbf0_reformat_cdc_check_notnull.write \
.format("snowflake") \
.options(**options) \
.option("sfWarehouse", SNFL_WH) \
.option("sfDatabase", SNFL_DB) \
.option("dbtable", TL_SNFL_TBL_NAME)\
.option("truncate_columns","on")\
.option("continue_on_error", "on") \
.mode("append") \
.save()



# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
#REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/short_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'


#print (IN_DATAFILE)
print (OUT_FILEPATH)
print (REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

#Columns List for Schema

fieldList = [
'row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'tc_cd',
'tc_cd_after',
'rec_type',
'rec_type_after',
'tc_name',
'tc_name_after',
'last_change_dttm',
'last_change_dttm_after']
#'tracking_id']
#'partition_column']

col_len = len(fieldList)
print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 22 :
      print('insert')
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 23:
      print('compute')
      return True
  else:
    if val_len != 23:
      return True

# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
#display (in_text)
in_text = in_text.rdd

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len = 22

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 22
print(f"Bad records count {rd_bad.count()}") # != 22


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

dfb = spark.createDataFrame(rd_bad, schema)

#display(dfb)

# COMMAND ----------

#Creating RD and assigning Schema to it

df = spark.createDataFrame(rd_good, schema)

#display(df)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

# df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df.columns,
#     df
# ))
# display(df)

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_thera_class")

#df_test1 = spark.sql("select * from gg_tbf0_patient_phone where pat_text_msg_ind ='û'")

# df_test1 = spark.sql("select * from gg_tbf0_patient_phone where pat_id =50004304208")
# display(df_test1)


# COMMAND ----------

SQL1 = """(select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm ,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( tc_cd )) ==0) then tc_cd else trim(tc_cd)end) as tc_cd,
(case when (LENGTH(trim( rec_type )) ==0) then rec_type else trim(rec_type)end) as rec_type,
(case when (LENGTH(trim( tc_name )) ==0) then tc_name else trim(tc_name)end) as tc_name,
(case when (LENGTH(trim(last_change_dttm )) ==0) then  last_change_dttm else concat(substring(last_change_dttm,1,10),' ',substring(last_change_dttm,12,8),'.000000') end) as last_change_dttm ,
'000000' as tracking_id
from gg_tbf0_thera_class where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd='PK UPDATE'))"""


# COMMAND ----------

SQL2 = """(select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm ,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( tc_cd_after )) ==0) then tc_cd_after else trim(tc_cd_after)end) as tc_cd,
(case when (LENGTH(trim( rec_type_after )) ==0) then rec_type_after else trim(rec_type_after)end) as rec_type,
(case when (LENGTH(trim( tc_name_after )) ==0) then tc_name_after else trim(tc_name_after)end) as tc_name,
(case when (LENGTH(trim(last_change_dttm_after )) ==0) then  last_change_dttm_after else concat(substring(last_change_dttm_after,1,10),' ',substring(last_change_dttm_after,12,8),'.000000') end) as last_change_dttm ,
'000000' as tracking_id
from gg_tbf0_thera_class where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd='PK UPDATE'))"""

# COMMAND ----------

SQL3 = """(select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm ,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( tc_cd_after )) ==0) then tc_cd_after else trim(tc_cd_after)end) as tc_cd,
(case when (LENGTH(trim( rec_type_after )) ==0) then rec_type_after else trim(rec_type_after)end) as rec_type,
(case when (LENGTH(trim( tc_name_after )) ==0) then tc_name_after else trim(tc_name_after)end) as tc_name,
(case when (LENGTH(trim(last_change_dttm_after )) ==0) then  last_change_dttm_after else concat(substring(last_change_dttm_after,1,10),' ',substring(last_change_dttm_after,12,8),'.000000') end) as last_change_dttm ,
'000000' as tracking_id
from gg_tbf0_thera_class where cdc_operation_type_cd ='INSERT')"""

# COMMAND ----------

#Creating dataframes for queries

df1 = spark.sql(SQL1)
#df1.show()

df2 = spark.sql(SQL2)
#df2.show()

df3 = spark.sql(SQL3)
#df3.show()

# COMMAND ----------

#Union of three dataframes 

df_union1 = df1.union(df2)
#display (df_union1)

df_final = df_union1.union(df3)
df_final.dropDuplicates()
#display(df_final)

df_final.createOrReplaceTempView("gg_tbf0_thera_class_final")
df_final = df_final.drop("tracking_id")

df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
           .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr")))\
           .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr")))\
           .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id")))\
           .withColumn("last_change_dttm", to_timestamp(df_final["last_change_dttm"]))
           #.withColumn("pat_id",when(col("pat_id") == "",None).otherwise(col("pat_id")))
#display(df_final)



# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Update Varchar columns to null
from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",sel_snfl_tbl)\
   .load()

#display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
#print(str_cols)


for col in str_cols:
  df_final = df_final.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))
  
#display(df_final)
print(f"Final good after union {df_final.count()}")

# COMMAND ----------

# df_test = spark.sql("select * from gg_tbf0_patient_phone_final where pat_text_msg_ind = 'N'")
# display(df_test)

# COMMAND ----------

#Getting bad data

df_bad = spark.sql("select * from gg_tbf0_thera_class where cdc_operation_type_cd = '' or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")
df_bad = df_bad.drop("row_length")
#df_bad = df_bad.unionByName(bad_df_1)
display(df_bad)

# COMMAND ----------

#WRITING DATA IN OUTPUT AND RJECT FOLDER

df_final.write.mode('overwrite').parquet(OUT_FILEPATH)

df_bad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Deleting data from the Snowflakes table

del_snfl_tbl = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#Writing to the Snowflakes Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "CONTINUE") \
    .mode("append") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
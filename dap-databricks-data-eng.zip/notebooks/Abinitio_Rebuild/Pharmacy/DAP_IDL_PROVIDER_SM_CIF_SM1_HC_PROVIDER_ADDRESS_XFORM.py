# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# Load Data - (INF - INFILE)

from pyspark.sql.types import *
from pyspark.sql.functions import *

inputSchema = (
  StructType([
    StructField("hc_provider_src_id", StringType(), True),
    StructField("hc_provider_addr_src_id", StringType(), True),
    StructField("src_sys_cd", StringType(), True),
    StructField("prac_name", StringType(), True),
    StructField("addr_line_1", StringType(), True),
    StructField("addr_line_2", StringType(), True),
    StructField("addr_line_3", StringType(), True),
    StructField("pobox_nbr", StringType(), True),
    StructField("city", StringType(), True),
    StructField("state_cd", StringType(), True),
    StructField("zip_cd_5", StringType(), True),
    StructField("zip_cd_4", StringType(), True),
    StructField("cntry", StringType(), True),
    StructField("latitude", StringType(), True),
    StructField("longitude", StringType(), True),
    StructField("addr_rank", StringType(), True),
    StructField("addr_std_cd", StringType(), True),
    StructField("addr_vld_cd", StringType(), True),
    StructField("replace_by_provider_id", StringType(), True),
    StructField("replace_by_provider_addr_id", StringType(), True),
    StructField("e_prescribe_cd", StringType(), True),
    StructField("e_prescribe_hub_nbr", StringType(), True),
    StructField("src_create_user_id", StringType(), True),
    StructField("src_create_dttm", StringType(), True),
    StructField("src_update_user_id", StringType(), True),
    StructField("src_update_dttm", StringType(), True),
    StructField("etl_change_cd", StringType(), True)
  ])
)

filePath = mountPoint + "/" + dbutils.widgets.get("pSRC_DIR") + "/" + dbutils.widgets.get("pFILE_PATTERN") + "*" + ".dat"

dbutils.notebook.run("../Utilities/TRANSFORM_SINGLE_ROW_FILE_INTERNAL", 60, {"PAR_DB_DELIMITER": "\x01", "PAR_DB_INPUT_PATH": filePath, "PAR_DB_NUMBER_OF_COLUMNS": 27, "PAR_RESULT_VIEW": "dfRaw"})

global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")

dfRaw = table(global_temp_db + ".dfRaw")

dfRaw = sqlContext.createDataFrame(dfRaw.collect(), inputSchema)

# COMMAND ----------

if dfRaw.count() != int(dbutils.widgets.get("pCNTL_FILE_CNT")) :
  raise Exception("Record Count Mismatch in Source file and Cntl File. Aborting Graph")
else:
  dfRecordCount = spark.createDataFrame([dfRaw.count()], IntegerType()).withColumn("count", col("value")).drop("value")
  
  # Save Record Count - (OUTF-Record Count SRC file)
  dfRecordCount.createOrReplaceGlobalTempView("dfRecordCount")
  file_path = "{0}/{1}/{2}_temp_cnt".format(mountPoint, dbutils.widgets.get("AI_SERIAL_TEMP"), dbutils.widgets.get("pFILE_PATTERN"))
  dbutils.notebook.run("../Utilities/WRITE_TO_STORAGE", 60, {"file_path": file_path, "file_extention": "dat", "view_name": "dfRecordCount", "delimiter": "\n", "has_header": "false"})

# COMMAND ----------

# Validation  - (RFMT-VALIDATE)

pSRC_SYS_CD = dbutils.widgets.get("pSRC_SYS_CD").upper()

dfValidated = dfRaw\
             .withColumn("ValidRecord", when((trim(col("hc_provider_src_id")) == "") | (col("hc_provider_src_id").isNull()) | (trim(col("hc_provider_addr_src_id")) == "") | (col("hc_provider_addr_src_id").isNull()), "N"))

if pSRC_SYS_CD == "SM":
  dfValidated = dfValidated.withColumn("ValidRecord", lit("N"))

# RFMT

if pSRC_SYS_CD == "SM1":
  dfValidated = dfValidated.withColumn("hc_provider_addr_src_id", lit("#"))

dfValidated = dfValidated.withColumn("src_sys_cd", lit(pSRC_SYS_CD))
  
dfFinal = dfValidated.filter(col("ValidRecord").isNull()).drop("ValidRecord")

# COMMAND ----------

# RFMT-ERR MSG

dfInvalid = dfValidated.filter(col("ValidRecord").isNotNull()).drop("ValidRecord")

dfInvalid = dfInvalid.na.fill("")

# Create error message
dfInvalid = dfInvalid\
            .withColumn("error_desc", when((trim(col("hc_provider_src_id")) == ""), lit("hc_provider_src_id is NULL or Blank: ")).otherwise(lit("")))\
            .withColumn("error_desc", when((trim(col("hc_provider_addr_src_id")) == ""), concat(col("error_desc"), lit("hc_provider_addr_src_id is NULL or Blank: "))).otherwise(col("error_desc")))

pIN_FILE = dbutils.widgets.get("pIN_FILE")
pSRC_DIR = dbutils.widgets.get("pSRC_DIR")
src_file = pIN_FILE.split(pSRC_DIR + "/")[1]
tgt_table = "cif_" + dbutils.widgets.get("pSRC_SYS_CD") + "_hc_provider_address"

# Populate remaining fields
dfInvalid = dfInvalid\
            .withColumn("src_file", lit(src_file))\
            .withColumn("src_type", lit("File"))\
            .withColumn("src_key", concat(col("hc_provider_src_id"), lit("~"), col("hc_provider_addr_src_id"), lit("~"), col("src_sys_cd")))\
            .withColumn("tgt_table", lit(tgt_table))\
            .withColumn("priority_cd", when(col("error_desc").isNotNull(), lit(1)).otherwise(2))\
            .withColumn("src_data", concat(col("hc_provider_src_id"), lit("~"),col("hc_provider_addr_src_id"), lit("~"),col("src_sys_cd"), lit("~"),col("prac_name"), lit("~"),col("addr_line_1"), lit("~"),col("addr_line_2"), lit("~"),col("addr_line_3"), lit("~"),col("pobox_nbr"), lit("~"),col("city"), lit("~"),col("state_cd"), lit("~"),col("zip_cd_5"), lit("~"),col("zip_cd_4"), lit("~"),col("cntry"), lit("~"),col("latitude"), lit("~"),col("longitude"), lit("~"),col("addr_rank"), lit("~"),col("addr_std_cd"), lit("~"),col("addr_vld_cd"), lit("~"),col("replace_by_provider_id"), lit("~"),col("replace_by_provider_addr_id"), lit("~"),col("e_prescribe_cd"), lit("~"),col("e_prescribe_hub_nbr"), lit("~"),col("src_create_user_id"), lit("~"),col("src_create_dttm"), lit("~"),col("src_update_user_id"), lit("~"),col("src_update_dttm"), lit("~"),col("etl_change_cd"), lit("~")))\
            .withColumn("edw_batch_id", lit(dbutils.widgets.get("pEDW_BATCH_ID")))\
            .withColumn("edw_batch_dt", lit(dbutils.widgets.get("pEDW_BATCH_DATE")))

# Format output
dfInvalid = dfInvalid.select("src_file", "src_type", "src_key", "tgt_table", "error_desc", "priority_cd", "src_data", "edw_batch_id", "edw_batch_dt")

# COMMAND ----------

# Write outputs

# Main output
dfFinal.createOrReplaceGlobalTempView("dfFinal")
file_path_output = "{0}/{1}/edw_idl_provider_cif_sm1_hc_provider_address_ldr_{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL"), dbutils.widgets.get("pEDW_BATCH_ID"))
dbutils.notebook.run("../Utilities/WRITE_TO_STORAGE", 60, {"file_path": file_path_output, "file_extention": "dat", "view_name": "dfFinal", "delimiter": "\x01", "has_header": "false"})

# Rejected Recrods
dfInvalid.createOrReplaceGlobalTempView("dfInvalid")
file_path_reject = "{0}/{1}/edw_idl_provider_cif_sm1_hc_provider_address_{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("pEDW_BATCH_ID"))
dbutils.notebook.run("../Utilities/WRITE_TO_STORAGE", 60, {"file_path": file_path_reject, "file_extention": "rej", "view_name": "dfInvalid", "delimiter": "\x01", "has_header": "false"})

# COMMAND ----------


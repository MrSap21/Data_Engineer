# Databricks notebook source
import os
import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters

os.environ['EXEC_WK_START_DATE'] = dbutils.widgets.get("EXEC_WK_START_DATE")
os.environ['EXEC_WK_END_DATE'] = dbutils.widgets.get("EXEC_WK_END_DATE")
os.environ['inputPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_INPUT_PATH")
os.environ['logPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_LOG_PATH")


 

# COMMAND ----------

# MAGIC %sh
# MAGIC #!/bin/ksh
# MAGIC #---------------------------------------------------------------------------
# MAGIC #  Author:          TCS
# MAGIC #  File name:       edw_out_satr_src_file_copy.ksh
# MAGIC #  Parameters:      none
# MAGIC #  Purpose:         This script copies SATR source files from RxR
# MAGIC #                   from FTP directory to SATR source file processing place.
# MAGIC #----------------------------------------------------------------------------
# MAGIC #    M A I N T E N A N C E   H I S T O R Y
# MAGIC #----------------------------------------------------------------------------
# MAGIC # Revision|             Description                            Name       Date
# MAGIC #---------+----------------------------------------------------------------
# MAGIC #   1.0   |  Initial release.                               |  Shephali     | 2018-09-28
# MAGIC #         |
# MAGIC #---------+----------------------------------------------------------------
# MAGIC 
# MAGIC #----------------------------------------------------------------------------
# MAGIC 
# MAGIC AI_SERIAL_LOG=$logPath
# MAGIC AI_DIR_FTP_BASE=$inputPath
# MAGIC 
# MAGIC EXEC_WK_START_DT1=$EXEC_WK_START_DATE
# MAGIC EXEC_WK_END_DT1=$EXEC_WK_END_DATE
# MAGIC 
# MAGIC LOG_FILE=${AI_SERIAL_LOG}/edw_out_satr_src_file_copy_`date +%Y%m%d%H%M`.log
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC echo "Validating files for each date between $EXEC_WK_START_DT1 and $EXEC_WK_END_DT1" > $LOG_FILE
# MAGIC 
# MAGIC UNIQ_DATE_LST_FILE=${AI_SERIAL_LOG}/SATR_src_files_`date +%Y%m%d%H%M`.list
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC cd $AI_DIR_FTP_BASE
# MAGIC ls -1 SATR_*.dat.pgp|cut -c6-13|sort|uniq > $UNIQ_DATE_LST_FILE
# MAGIC 
# MAGIC cd -
# MAGIC 
# MAGIC DISTINCT_DATE_CNT=$(cat $UNIQ_DATE_LST_FILE|wc -l)
# MAGIC 
# MAGIC sed -i "a count of uniq date files recived from RxR is $DISTINCT_DATE_CNT" $LOG_FILE
# MAGIC 
# MAGIC MIN_FILE_DT=$(cat $UNIQ_DATE_LST_FILE|head -1)
# MAGIC MAX_FILE_DT=$(cat $UNIQ_DATE_LST_FILE|tail -1)
# MAGIC 
# MAGIC sed -i "a count of uniq date files recived from RxR is ${MIN_FILE_DT} and ${MAX_FILE_DT}" $LOG_FILE
# MAGIC if [[ $MIN_FILE_DT -lt $EXEC_WK_START_DT1 || $MAX_FILE_DT -gt $EXEC_WK_END_DT1 ]]; then
# MAGIC 
# MAGIC   sed -i '$ a SATR files present for previous or future week, remove the old files and start the execution' $LOG_FILE
# MAGIC   exit 1
# MAGIC else
# MAGIC   if [[ $DISTINCT_DATE_CNT -eq 7 ]]; then
# MAGIC      sed -i '$ a All days source files present for current week execution,start moving files to inbound directory' $LOG_FILE
# MAGIC   else
# MAGIC      sed -i '$ a Not all days source files present,check for ftp job execution status for missing days' $LOG_FILE
# MAGIC      exit 1
# MAGIC   fi
# MAGIC fi
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC sed -i '$ a Copying the files to SATR processing directory' $LOG_FILE
# MAGIC 
# MAGIC 
# MAGIC mv $AI_DIR_FTP_BASE/SATR_*.dat.pgp $AI_DIR_FTP_BASE/SATR_inbound_files/  
# MAGIC 
# MAGIC RC=$?
# MAGIC if [[ $RC -eq 0 ]]; then
# MAGIC    sed -i '$ a SATR source file copying successful to SATR inbound drectory date\n' $LOG_FILE
# MAGIC else
# MAGIC    sed -i '$ a edw_out_satr_src_file_copy.ksh failed at date Please retry source files copying to inbound directory' $LOG_FILE
# MAGIC    exit 1
# MAGIC fi
# MAGIC 
# MAGIC sed -i '$ a Done Copying the files to SATR inbound directory date' $LOG_FILE
# MAGIC exit 0

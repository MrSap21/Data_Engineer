# Databricks notebook source
# DBTITLE 1,Include Common Utility Functions
# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

inputs_dict={'AI_SERIAL':dbutils.widgets.get("AI_SERIAL"),'AI_SERIAL_REJECT':dbutils.widgets.get("AI_SERIAL_REJECT"),'AI_SERIAL_TEMP':dbutils.widgets.get("AI_SERIAL_TEMP"),'pCNTL_FILE_CNT':dbutils.widgets.get("pCNTL_FILE_CNT"),'pEDW_BATCH_DATE':dbutils.widgets.get("pEDW_BATCH_DATE"),'pEDW_BATCH_ID':dbutils.widgets.get("pEDW_BATCH_ID"),'pFILE_PATTERN':dbutils.widgets.get("pFILE_PATTERN"),'pIN_FILE':dbutils.widgets.get("pIN_FILE"),'pSRC_DIR':dbutils.widgets.get("pSRC_DIR"),'pSRC_SYS_CD':dbutils.widgets.get("pSRC_SYS_CD")}
validate_inputs(inputs_dict)

# COMMAND ----------

# Load Data - (INF - INFILE)

from pyspark.sql.types import *
from pyspark.sql.functions import *

inputSchema = (
  StructType([
    StructField("hc_provider_src_id", StringType(), True),
    StructField("hc_provider_addr_src_id", StringType(), True),
    StructField("src_sys_cd", StringType(), True),
    StructField("cntc_channel_type", StringType(), True),
    StructField("cntc_channel_type_cd", StringType(), True),
    StructField("cntc_channel_type_val", StringType(), True),
    StructField("cntc_ext", StringType(), True),
    StructField("cntc_rank", StringType(), True),
    StructField("cntc_stat_cd", StringType(), True),
    StructField("cntc_cmnts", StringType(), True),
    StructField("src_create_user_id", StringType(), True),
    StructField("src_create_dttm", StringType(), True),
    StructField("src_update_user_id", StringType(), True),
    StructField("src_update_dttm", StringType(), True),
    StructField("etl_change_cd", StringType(), True),
    StructField("newline_last_col", StringType(), True)
  ])
)

#filePath = mountPoint + "/" + dbutils.widgets.get("pSRC_DIR") + "/" + dbutils.widgets.get("pFILE_PATTERN") + "*" + ".dat"

#Replacing *.dat with IN_FILE param to process specific input file and to match row count
filePath = mountPoint + "/" + dbutils.widgets.get("pIN_FILE")

# Read the data into DF with schema & other required options
df = spark.read.format("csv")\
       .option("header", False)\
       .option("delimiter", "\x01")\
       .option("quote", "\"")\
       .schema(inputSchema)\
       .load(filePath)

# Drop the last columns as it is just a record end indicator used in Abinitio
dfRaw = df.drop("newline_last_col")


# COMMAND ----------

if dfRaw.count() != int(dbutils.widgets.get("pCNTL_FILE_CNT")) :
  raise Exception("Record Count Mismatch in Source file and Cntl File. Aborting Graph")
else:
  dfRecordCount = spark.createDataFrame([dfRaw.count()], IntegerType()).withColumn("count", col("value")).drop("value")
  
  # Save Record Count - (OUTF-Record Count SRC file)
  file_path = "{0}/{1}/{2}_temp_cnt".format(mountPoint, dbutils.widgets.get("AI_SERIAL_TEMP"), dbutils.widgets.get("pFILE_PATTERN"))
  write_data(dfRecordCount,file_path)

# COMMAND ----------

# Validation  - (RFMT-VALIDATE)

pSRC_SYS_CD = dbutils.widgets.get("pSRC_SYS_CD").upper()

dfValidated = dfRaw\
             .withColumn("ValidRecord", when((trim(col("hc_provider_src_id")) == "") | (col("hc_provider_src_id").isNull()) | (trim(col("cntc_channel_type")) == "") | (col("cntc_channel_type").isNull()) | (trim(col("cntc_channel_type_cd")) == "") | (col("cntc_channel_type_cd").isNull()) | (trim(col("hc_provider_addr_src_id")) == "") | (col("hc_provider_addr_src_id").isNull()) , "N"))

# Apply default values to src_create_user_id and src_update_user_id according to DML
dfValidated = dfValidated \
              .withColumn("src_create_user_id", when(col("src_create_user_id").isNull(), lit("#")).otherwise(col("src_create_user_id"))) \
              .withColumn("src_update_user_id", when(col("src_update_user_id").isNull(), lit("#")).otherwise(col("src_update_user_id")))

# if pSRC_SYS_CD == "SM":
#   dfValidated = dfValidated.withColumn("ValidRecord", lit("N"))

# # RFMT

if pSRC_SYS_CD == "SM1":
  dfValidated = dfValidated.withColumn("hc_provider_addr_src_id", lit("#"))

dfValidated = dfValidated.withColumn("src_sys_cd", lit(pSRC_SYS_CD))
  
dfFinal = dfValidated.filter(col("ValidRecord").isNull()).drop("ValidRecord")

# COMMAND ----------

# RFMT-ERR MSG

dfInvalid = dfValidated.filter(col("ValidRecord").isNotNull()).drop("ValidRecord")

dfInvalid = dfInvalid.na.fill("")

# Create error message
dfInvalid = dfInvalid\
            .withColumn("error_desc", when((trim(col("hc_provider_src_id")) == ""), lit("hc_provider_src_id is NULL or Blank: ")).otherwise(lit("")))\
            .withColumn("error_desc", when((trim(col("hc_provider_addr_src_id")) == ""), concat(col("error_desc"), lit("hc_provider_addr_src_id is NULL or Blank: "))).otherwise(col("error_desc")))\
            .withColumn("error_desc", when((trim(col("cntc_channel_type")) == ""), concat(col("error_desc"), lit("cntc_channel_type is NULL or Blank: "))).otherwise(col("error_desc")))\
            .withColumn("error_desc", when((trim(col("cntc_channel_type_cd")) == ""), concat(col("error_desc"), lit("cntc_channel_type_cd is NULL or Blank: "))).otherwise(col("error_desc")))

pIN_FILE = dbutils.widgets.get("pIN_FILE")
pSRC_DIR = dbutils.widgets.get("pSRC_DIR")
src_file = pIN_FILE.split(pSRC_DIR + "/")[1]
tgt_table = "cif_" + dbutils.widgets.get("pSRC_SYS_CD") + "_hc_prov_addr_cont_chnl"

# Populate remaining fields
dfInvalid = dfInvalid\
            .withColumn("src_file", lit(src_file))\
            .withColumn("src_type", lit("File"))\
            .withColumn("src_key", concat(col("hc_provider_src_id"), lit("~"), col("hc_provider_addr_src_id"), lit("~"), col("cntc_channel_type"), lit("~"), col("cntc_channel_type_cd"), lit("~"), col("src_sys_cd")))\
            .withColumn("tgt_table", lit(tgt_table))\
            .withColumn("priority_cd", when(col("error_desc").isNotNull(), lit(1)).otherwise(2))\
            .withColumn("src_data", concat(col("hc_provider_src_id"), lit("~"), col("hc_provider_addr_src_id"), lit("~"), col("src_sys_cd"), lit("~"), col("cntc_channel_type"), lit("~"), col("cntc_channel_type_cd"), lit("~"), col("cntc_channel_type_val"), lit("~"), col("cntc_ext"), lit("~"), col("cntc_rank"), lit("~"), col("cntc_stat_cd"), lit("~"), col("cntc_cmnts"), lit("~"), col("src_create_user_id"), lit("~"), col("src_create_dttm"), lit("~"), col("src_update_user_id"), lit("~"), col("src_update_dttm"), lit("~"), col("etl_change_cd")))\
            .withColumn("edw_batch_id", lit(dbutils.widgets.get("pEDW_BATCH_ID")))\
            .withColumn("edw_batch_dt", lit(dbutils.widgets.get("pEDW_BATCH_DATE")))

# Format output
dfInvalid = dfInvalid.select("src_file", "src_type", "src_key", "tgt_table", "error_desc", "priority_cd", "src_data", "edw_batch_id", "edw_batch_dt")

# COMMAND ----------

# Write outputs

# Main output
dfFinal = trim_column(dfFinal)
dfFinal = escape_slash(dfFinal)
file_path_output = "{0}/{1}/edw_idl_provider_cif_sm_hc_prov_addr_cont_chnl_ldr/{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL"), dbutils.widgets.get("pEDW_BATCH_ID"))
write_data(dfFinal,file_path_output)

# Rejected Recrods
dfInvalid = trim_column(dfInvalid)
dfInvalid = escape_slash(dfInvalid)
file_path_reject = "{0}/{1}/edw_idl_provider_cif_sm_hc_prov_addr_cont_chnl/{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("pEDW_BATCH_ID"))
write_data(dfInvalid,file_path_reject)

# COMMAND ----------


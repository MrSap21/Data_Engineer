# Databricks notebook source
dbutils.widgets.text("PAR_NB_SNFK_STG_DB","UAT_STAGING")
dbutils.widgets.text("PAR_NB_SNFK_TGT_DB","UAT_PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_NB_DELTA_TABLE","staging__pharmacy_healthcare__patient_services.prescription_fill_data_migration")
dbutils.widgets.text("PAR_NB_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
dbutils.widgets.text("PAR_NB_SNFK_TGT_TBL_NAME","PRESCRIPTION_FILL")
dbutils.widgets.text("PAR_NB_SNFK_STG_TBL_NAME","PRESCRIPTION_FILL_DATA_MIGRATION")
dbutils.widgets.text("PAR_NB_SNFK_SCHEMA_NAME","PATIENT_SERVICES")
dbutils.widgets.text("PAR_NB_PARTITION_COLUMN","fill_sold_yr")
dbutils.widgets.text("PAR_NB_PARTITION_value","2020")

# COMMAND ----------

PAR_SNFK_STG_DB=dbutils.widgets.get("PAR_NB_SNFK_STG_DB")
PAR_SNFK_TGT_DB=dbutils.widgets.get("PAR_NB_SNFK_TGT_DB")
PAR_DELTA_TABLE=dbutils.widgets.get("PAR_NB_DELTA_TABLE")
PAR_SNFK_WH=dbutils.widgets.get("PAR_NB_SNFK_WH")
PAR_SNFK_TGT_TBL_NAME=dbutils.widgets.get("PAR_NB_SNFK_TGT_TBL_NAME")
PAR_SNFK_STG_TBL_NAME=dbutils.widgets.get("PAR_NB_SNFK_STG_TBL_NAME")
PAR_SNFK_SCHEMA_NAME=dbutils.widgets.get("PAR_NB_SNFK_SCHEMA_NAME")
PAR_PARTITION_COLUMN=dbutils.widgets.get("PAR_NB_PARTITION_COLUMN")
PAR_PARTITION_value=dbutils.widgets.get("PAR_NB_PARTITION_value")

# COMMAND ----------

df=spark.table(PAR_DELTA_TABLE)
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
df_filter=df.filter(col(PAR_PARTITION_COLUMN)==lit(PAR_PARTITION_value))
display(df_filter)
df_filter.count()

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=PAR_SNFK_STG_DB $SNOWFLAKE_WAREHOUSE=PAR_SNFK_WH

# COMMAND ----------

create_stg_snowflake = """create table if not exists {0}.{1}.{2} as  select * from {3}.{1}.{4} where 1=2""".format(PAR_SNFK_STG_DB,PAR_SNFK_SCHEMA_NAME,
PAR_SNFK_STG_TBL_NAME,PAR_SNFK_TGT_DB,PAR_SNFK_TGT_TBL_NAME)
print(create_stg_snowflake)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : create_stg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" :PAR_SNFK_STG_DB,"SNOWFLAKE_WAREHOUSE" : PAR_SNFK_WH})

# COMMAND ----------

df_filter.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("overwrite") \
        .options(**options) \
        .option("sfWarehouse", PAR_SNFK_WH) \
        .option("sfDatabase", PAR_SNFK_STG_DB) \
        .option("dbtable",PAR_SNFK_SCHEMA_NAME+"."+PAR_SNFK_STG_TBL_NAME) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()

# COMMAND ----------

'''
update_tgt_snowflake = """
update "UAT_PHARMACY_HEALTHCARE"."PATIENT_SERVICES"."PRESCRIPTION_FILL" TGT set 
filling_store_nbr = STG.filling_store_nbr
    ,fill_verified_store_nbr = STG.fill_verified_store_nbr
    ,mult_prod_review_ind = STG.mult_prod_review_ind
    ,pat_selct_user_id = STG.pat_selct_user_id
    ,pbr_selct_user_id = STG.pbr_selct_user_id
    ,pat_selct_dttm = STG.pat_selct_dttm
    ,pbr_selct_dttm = STG.pbr_selct_dttm
    ,pat_selct_str_nbr = STG.pat_selct_str_nbr
    ,pbr_selct_str_nbr = STG.pbr_selct_str_nbr
    ,ntt_ind = STG.ntt_ind
    ,fill_sold_yr = STG.fill_sold_yr
    ,fill_enter_mnth = STG.fill_enter_mnth
from UAT_STAGING.PATIENT_SERVICES.PRESCRIPTION_FILL_DATA_MIGRATION  STG
where  TGT.rx_nbr=STG.rx_nbr
  and TGT.str_nbr=STG.str_nbr
  and TGT.rx_fill_nbr=STG.rx_fill_nbr
  and TGT.rx_partial_fill_nbr=STG.rx_partial_fill_nbr
  and TGT.fill_enter_dt=STG.fill_enter_dt
  and TGT.fill_enter_tm=STG.fill_enter_tm"""
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",14400, { "query" : update_tgt_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : 'UAT_PHARMACY_HEALTHCARE',"SNOWFLAKE_WAREHOUSE" : 'UAT_HISTORY_MIGRATION_FR_WH'})
'''
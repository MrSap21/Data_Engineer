# Databricks notebook source
# DBTITLE 1,Include Common Utility Functions
# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

dDate = dbutils.widgets.get("pEDW_BATCH_DATE")
#dDate = to_date(dDate, 'yyyy-MM-dd')
#print(dDate).collect()

# COMMAND ----------

#dbutils.widgets.text("pOUTPUT_FILE", 'edw_idl_customer_opv_cif_opv_ntfcn_txn_ldr')
#dbutils.widgets.text("pOUTPUT_PATH", 'pharmacy_healthcare/patient_services/output/')

# COMMAND ----------

IN_PATH = mountPoint+'/'+dbutils.widgets.get("pSRC_DIR")+dbutils.widgets.get("pIN_FILE")+'/'+dbutils.widgets.get("pEDW_BATCH_ID")
REJ_PATH = mountPoint+'/'+dbutils.widgets.get("AI_SERIAL_REJECT")+'/'+dbutils.widgets.get("pEDW_BATCH_ID")
OUT_PATH = mountPoint+'/'+dbutils.widgets.get("pOUTPUT_PATH")+dbutils.widgets.get("pOUTPUT_FILE")+'/'+dbutils.widgets.get("pEDW_BATCH_ID")
print(IN_PATH)
print(REJ_PATH)
print(OUT_PATH)

# COMMAND ----------

#function to remove Double Quotes and Backward Slashes ("" & \\)

def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  if (val.find('"') != -1):
    #print ("Contains given substring ")
 
    #remove rightmost "
    outval = val[0:-1]
    #remove leftmost "
    outval = outval.lstrip("\"")
    #replace double \\ with \
    outval = outval.replace("\\\\","\\")
    #replace double \" with "
    outval = outval.replace("\\\"","\"")
    return outval
  else:
    return val

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

dfRaw = spark.read.parquet(IN_PATH)
display(dfRaw)

# COMMAND ----------

#Removing double quotes from the data

from functools import reduce
dfRaw = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    dfRaw.columns,
    dfRaw
))
display(dfRaw)

# COMMAND ----------

# Validation  - (RFMT-SRC TO CIF)

pSRC_SYS_CD = dbutils.widgets.get("pSRC_SYS_CD").upper()

dfValidated = dfRaw\
              .withColumn("ntfcn_txn_src_id", col("notification_id"))\
              .withColumn("src_sys_cd", lit(pSRC_SYS_CD))\
              .withColumn("cust_src_id", when((col("source_system_id").isNull()) | (trim(col("source_system_id")) == ""), lit("#")).otherwise(col("source_system_id")))\
              .withColumn("cust_src_cd", when((col("source_system_name").isNull()) | (trim(col("source_system_name")) == ""), lit("#")).otherwise(col("source_system_name")))\
              .withColumn("composite_type_cd", when((col("cust_src_cd")=="LR"), lit("M")).otherwise(lit("#")))\
              .withColumn("msg_type_cd", when((col("cust_src_cd")=="LR"), lit("1")).otherwise(lit("#")))\
              .withColumn("rx_nbr", when((col("entity_type") =='RX'), col("entity_value")).otherwise(None))\
              .withColumn("store_nbr", col("store_number"))\
              .withColumn("fill_enter_dt", substring(col("fill_enter_dttm"),1,10))\
              .withColumn("fill_dspn_nbr", col("fill_nbr_dispensed"))\
              .withColumn("channel_cd", col("channel"))\
              .withColumn("ntfcn_create_dt", substring(col("notf_dttm"),1,10))\
              .withColumn("offer_90day_cd", col("offer_90day_ind"))\
              .withColumn("rx_image_cnt", col("rx_image_cnt"))\
              .withColumn("satr_pat_enroll_ind", col("satr_pat_enroll_ind"))\
              .withColumn("satr_wo_ord_id", col("satr_wo_ord_id"))\
              .withColumn("satr_wo_rx_cnt", col("satr_wo_rx_cnt"))\
              .withColumn("satr_short_fill_ind", col("satr_short_fill_ind"))\
              .withColumn("adv_refill_elig_ind", col("adv_refill_elig_ind"))
              
              

dfValidated = dfValidated.select ("ntfcn_txn_src_id",
                                 "src_sys_cd",
                                 "cust_src_id",
                                 "cust_src_cd",
                                 "composite_type_cd",
                                 "msg_type_cd",
                                 "rx_nbr",
                                 "store_nbr",
                                 "fill_enter_dt",
                                 "fill_dspn_nbr",
                                 "channel_cd",
                                 "ntfcn_create_dt",
                                 "offer_90day_cd",
                                 "rx_image_cnt",
                                 "satr_pat_enroll_ind",
                                 "satr_wo_ord_id",
                                 "satr_wo_rx_cnt",
                                 "satr_short_fill_ind",
                                 "adv_refill_elig_ind")
display(dfValidated)  
  
  

# COMMAND ----------

dfValidRecord = dfValidated\
              .withColumn("v_ntfcn_txn_src_id", when((col("ntfcn_txn_src_id").isNull()) | (trim(col("ntfcn_txn_src_id")) == "") | (length(trim(col("ntfcn_txn_src_id"))) >32), concat(lit("ntfcn_txn_src_id["),col("ntfcn_txn_src_id") , lit("]"))).otherwise(lit("")))\
.withColumn("v_src_sys_cd", when((col("src_sys_cd").isNull()) | (trim(col("src_sys_cd")) == "") | (length(trim(col("src_sys_cd"))) >20), concat(lit("src_sys_cd["),col("src_sys_cd") , lit("]"))).otherwise(lit("")))\
.withColumn("v_cust_src_id", when((col("cust_src_id").isNull()) | (trim(col("cust_src_id")) == "") | (length(trim(col("cust_src_id"))) >80), concat(lit("cust_src_id["),col("cust_src_id") , lit("]"))).otherwise(lit("")))\
.withColumn("v_cust_src_cd", when((col("cust_src_cd").isNull()) | (trim(col("cust_src_cd")) == "") | (length(trim(col("cust_src_cd"))) >20), concat(lit("cust_src_cd["),col("cust_src_cd") , lit("]"))).otherwise(lit("")))\
.withColumn("v_composite_type_cd", when((col("composite_type_cd").isNull()) | (trim(col("composite_type_cd")) == "") | (length(trim(col("composite_type_cd"))) >2), concat(lit("composite_type_cd["),col("composite_type_cd") , lit("]"))).otherwise(lit("")))\
.withColumn("v_msg_type_cd", when((col("msg_type_cd").isNull()) | (trim(col("msg_type_cd")) == "") | (length(trim(col("msg_type_cd"))) >1), concat(lit("msg_type_cd["),col("msg_type_cd") , lit("]"))).otherwise(lit("")))\
.withColumn("v_Error_Desc", concat("v_ntfcn_txn_src_id","v_src_sys_cd","v_cust_src_id","v_cust_src_cd","v_composite_type_cd","v_msg_type_cd"))\
.withColumn("v_Warning_Desc", lit(""))\
.withColumn("Valid_Record", when((col("v_Error_Desc").isNull()) | (trim(col("v_Error_Desc")) == "") , lit("")).otherwise(lit("N")))

# .withColumn("v_rx_nbr", when((col("rx_nbr").isNotNull()) & (trim(col("rx_nbr")) == ""), concat(lit("rx_nbr["),col("rx_nbr") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_aggr_src_id", when((col("aggr_src_id").isNull()) | (trim(col("aggr_src_id")) == "") | (length(trim(col("aggr_src_id"))) >32), concat(lit("aggr_src_id["),col("aggr_src_id") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_Error_Desc", concat("v_ntfcn_txn_src_id","v_src_sys_cd","v_cust_src_id","v_cust_src_cd","v_composite_type_cd","v_msg_type_cd","v_aggr_src_id"))\
# .withColumn("v_Warning_Desc", lit(""))\
# .withColumn("Valid_Record", when((col("v_Error_Desc").isNull()) | (trim(col("v_Error_Desc")) == "") , lit("")).otherwise(lit("N")))

#display(dfValidRecord)

dfFinal = dfValidRecord.filter(col("Valid_Record").isNull() | (col("Valid_Record")=="")).drop("Valid_Record","v_ntfcn_txn_src_id","v_src_sys_cd","v_cust_src_id","v_cust_src_cd","v_composite_type_cd","v_msg_type_cd","v_Error_Desc","v_Warning_Desc") 
#display(dfFinal)

# COMMAND ----------

dfInValidated = dfValidRecord.filter(col("Valid_Record")=='N').drop("Valid_Record","v_ntfcn_txn_src_id","v_src_sys_cd","v_cust_src_id","v_cust_src_cd","v_composite_type_cd","v_msg_type_cd","v_aggr_src_id","v_Warning_Desc") 

src_file = dbutils.widgets.get("pIN_FILE")
tgt_table = "CIF_OPV_NTFCN_TXN_STG"


dfInValidated = dfInValidated\
            .withColumn("src_file", lit(src_file))\
            .withColumn("src_type", lit("File"))\
            .withColumn("src_key", concat(col("ntfcn_txn_src_id"), lit("~"), col("src_sys_cd"), lit("~"), col("cust_src_id")))\
            .withColumn("tgt_table", lit(tgt_table))\
            .withColumn("priority_cd", when(col("v_Error_Desc").isNotNull(), lit(1)).otherwise(2))\
            .withColumn("src_data", concat(col("ntfcn_txn_src_id"), lit("~"),col("src_sys_cd"), lit("~"),col("cust_src_id"), lit("~"),col("cust_src_cd"), lit("~"),col("composite_type_cd"), lit("~"),col("msg_type_cd"), lit("~"),col("rx_nbr"), lit("~"),col("store_nbr"), lit("~"),col("fill_enter_dt"), lit("~"),col("fill_dspn_nbr"), lit("~"),col("channel_cd"), lit("~"),col("ntfcn_create_dt"), lit("~"),col("offer_90day_cd"), lit("~")))\
            .withColumn("edw_batch_id", lit(dbutils.widgets.get("pEDW_BATCH_ID")))\
            .withColumn("edw_batch_dt", lit(dbutils.widgets.get("pEDW_BATCH_DATE")))

# Format output
dfInValidated = dfInValidated.select("src_file", "src_type", "src_key", "tgt_table", "v_Error_Desc", "priority_cd", "src_data", "edw_batch_id", "edw_batch_dt")

display(dfInValidated)

# COMMAND ----------

# dfInValidated = dfInValidated\
#             .withColumn("edw_batch_id", lit(dbutils.widgets.get("pEDW_BATCH_ID")))\
#             .withColumn("edw_batch_dt", to_timestamp(lit(dbutils.widgets.get("pEDW_BATCH_DATE")).cast('date'),'yyyyMMdd HH:mm:ss'))

# display(dfInValidated)

# COMMAND ----------

# Write outputs

# Main output
dfFinal = trim_column(dfFinal)
dfFinal = escape_slash(dfFinal)
file_path_output = OUT_PATH
write_data(dfFinal,OUT_PATH)

display(dfFinal)

# Rejected Recrods
dfInValidated = trim_column(dfInValidated)
dfInValidated = escape_slash(dfInValidated)
file_path_reject = REJ_PATH
#file_path_reject = "{0}/{1}/edw_idl_provider_cif_sm_hc_provider_address/{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("pEDW_BATCH_ID"))
write_data(dfInValidated,REJ_PATH)
#display(dfInValidated)

# COMMAND ----------

#RMT - IN-VALID RECORDS



#drop("Valid_Record","v_ntfcn_txn_src_id","v_src_sys_cd","v_cust_src_id","v_cust_src_cd","v_composite_type_cd","v_msg_type_cd","v_aggr_src_id","v_Error_Desc","v_Warning_Desc") 







# .withColumn("v_enty_type_cd", when((col("enty_type_cd").isNull()) | (trim(col("enty_type_cd")) == "") | (length(trim(col("enty_type_cd"))) >10), concat(lit("enty_type_cd["),col("enty_type_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_enty_type_val", when((col("enty_type_val").isNull()) | (trim(col("enty_type_val")) == "") | (length(trim(col("enty_type_val"))) >25), concat(lit("enty_type_val["),col("enty_type_val") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_rx_nbr", when((col("rx_nbr").isNull()) | (trim(col("rx_nbr")) == ""), concat(lit("rx_nbr["),col("rx_nbr") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_store_nbr", when((col("store_nbr").isNull()) | (trim(col("store_nbr")) == ""), concat(lit("store_nbr["),col("store_nbr") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_rx_fill_nbr", when((col("rx_fill_nbr").isNull()) | (trim(col("rx_fill_nbr")) == "") , concat(lit("rx_fill_nbr["),col("rx_fill_nbr") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_fill_enter_dt", when((col("fill_enter_dt").isNull()) | (trim(col("fill_enter_dt")) == "") , concat(lit("fill_enter_dt["),col("fill_enter_dt") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_fill_enter_tm", when((col("fill_enter_tm").isNull()) | (trim(col("fill_enter_tm")) == ""), concat(lit("fill_enter_tm["),col("fill_enter_tm") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_fill_dspn_nbr", when((col("fill_dspn_nbr").isNull()) | (trim(col("fill_dspn_nbr")) == ""), concat(lit("fill_dspn_nbr["),col("fill_dspn_nbr") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_aggr_type", when((col("aggr_type").isNull()) | (trim(col("aggr_type")) == "") | (length(trim(col("aggr_type"))) >10), concat(lit("aggr_type["),col("aggr_type") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_aggr_priority_seq", when((col("aggr_priority_seq").isNull()) | (trim(col("aggr_priority_seq")) == "") , concat(lit("aggr_priority_seq["),col("aggr_priority_seq") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_ntfcn_subtype_cd", when((col("ntfcn_subtype_cd").isNull()) | (trim(col("ntfcn_subtype_cd")) == "") | (length(trim(col("ntfcn_subtype_cd"))) >20), concat(lit("ntfcn_subtype_cd["),col("ntfcn_subtype_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_channel_cd", when((col("channel_cd").isNull()) | (trim(col("channel_cd")) == "") | (length(trim(col("channel_cd"))) >20), concat(lit("channel_cd["),col("channel_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_cntc_pnt_val", when((col("cntc_pnt_val").isNull()) | (trim(col("cntc_pnt_val")) == "") | (length(trim(col("cntc_pnt_val"))) >128), concat(lit("cntc_pnt_val["),col("cntc_pnt_val") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_bypass_cd", when((col("bypass_cd").isNull()) | (trim(col("bypass_cd")) == "") | (length(trim(col("bypass_cd"))) >20), concat(lit("bypass_cd["),col("bypass_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_cmnt_txt", when((col("cmnt_txt").isNull()) | (trim(col("cmnt_txt")) == "") | (length(trim(col("cmnt_txt"))) >500), concat(lit("cmnt_txt["),col("cmnt_txt") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_ntfcn_stat_cd", when((col("ntfcn_stat_cd").isNull()) | (trim(col("ntfcn_stat_cd")) == "") | (length(trim(col("ntfcn_stat_cd"))) >20), concat(lit("ntfcn_stat_cd["),col("ntfcn_stat_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_ntfcn_create_dttm", when((col("ntfcn_create_dttm").isNull()) | (trim(col("ntfcn_create_dttm")) == "") , concat(lit("ntfcn_create_dttm["),col("ntfcn_create_dttm") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_ntfcn_create_dt", when((col("ntfcn_create_dt").isNull()) | (trim(col("ntfcn_create_dt")) == ""), concat(lit("ntfcn_create_dt["),col("ntfcn_create_dt") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_ntfcn_update_dttm", when((col("ntfcn_update_dttm").isNull()) | (trim(col("ntfcn_update_dttm")) == ""), concat(lit("ntfcn_update_dttm["),col("ntfcn_update_dttm") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_ntfcn_expire_dttm", when((col("ntfcn_expire_dttm").isNull()) | (trim(col("ntfcn_expire_dttm")) == ""), concat(lit("ntfcn_expire_dttm["),col("ntfcn_expire_dttm") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_cco_store_cd", when((col("cco_store_cd").isNull()) | (trim(col("cco_store_cd")) == "") | (length(trim(col("cco_store_cd"))) >20), concat(lit("cco_store_cd["),col("cco_store_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_fill_wtg_cd", when((col("fill_wtg_cd").isNull()) | (trim(col("fill_wtg_cd")) == "") | (length(trim(col("fill_wtg_cd"))) >20), concat(lit("fill_wtg_cd["),col("fill_wtg_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_dl_reject_additional_msg", when((col("dl_reject_additional_msg").isNull()) | (trim(col("dl_reject_additional_msg")) == "") | (length(trim(col("dl_reject_additional_msg"))) >1000), concat(lit("dl_reject_additional_msg["),col("dl_reject_additional_msg") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_pilot_cd", when((col("pilot_cd").isNull()) | (trim(col("pilot_cd")) == "") | (length(trim(col("pilot_cd"))) >20), concat(lit("pilot_cd["),col("pilot_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_rx_immunization_cd", when((col("rx_immunization_cd").isNull()) | (trim(col("rx_immunization_cd")) == "") | (length(trim(col("rx_immunization_cd"))) >20), concat(lit("rx_immunization_cd["),col("rx_immunization_cd") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_src_create_dttm", when((col("src_create_dttm").isNull()) | (trim(col("src_create_dttm")) == "") , concat(lit("src_create_dttm["),col("src_create_dttm") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_src_create_user_id", when((col("src_create_user_id").isNull()) | (trim(col("src_create_user_id")) == "") | (length(trim(col("src_create_user_id"))) >32), concat(lit("src_create_user_id["),col("src_create_user_id") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_src_update_dttm", when((col("src_update_dttm").isNull()) | (trim(col("src_update_dttm")) == "") , concat(lit("src_update_dttm["),col("src_update_dttm") , lit("]"))).otherwise(lit("")))\
# .withColumn("v_src_update_user_id", when((col("src_update_user_id").isNull()) | (trim(col("src_update_user_id")) == "") | (length(trim(col("src_update_user_id"))) >32), concat(lit("src_update_user_id["),col("src_update_user_id") , lit("]"))).otherwise(lit("")))

# dfInValidated = dfInValidated.select("v_ntfcn_txn_src_id",
#                                  "v_src_sys_cd",
#                                  "v_cust_src_id",
#                                  "v_cust_src_cd",
#                                  "v_composite_type_cd",
#                                  "v_msg_type_cd",
#                                  "v_aggr_src_id",
#                                  "v_Error_Desc",
#                                  "v_Warning_Desc",
#                                  "Valid_Record"    
#                                  "v_enty_type_cd",
#                                  "v_enty_type_val",
#                                  "v_rx_nbr",
#                                  "v_ntfcn_txn_src_id",
#                                  "v_store_nbr",
#                                  "v_rx_fill_nbr",
#                                  "v_fill_enter_dt",
#                                  "v_fill_enter_tm",
#                                  "v_fill_dspn_nbr",
#                                  "v_aggr_type",
#                                  "v_aggr_priority_seq",
#                                  "v_ntfcn_subtype_cd",
#                                  "v_channel_cd",
#                                  "v_cntc_pnt_val",
#                                  "v_bypass_cd",
#                                  "v_cmnt_txt",
#                                  "v_ntfcn_stat_cd",
#                                  "v_ntfcn_create_dttm",
#                                  "v_ntfcn_create_dt",
#                                  "v_ntfcn_update_dttm",
#                                  "v_ntfcn_expire_dttm",
#                                  "v_cco_store_cd",
#                                  "v_fill_wtg_cd",
#                                  "v_dl_reject_additional_msg",
#                                  "v_pilot_cd",
#                                  "v_rx_immunization_cd",
#                                  "v_src_create_dttm",
#                                  "v_src_create_user_id",
#                                  "v_src_update_dttm",
#                                  "v_src_update_user_id"

#          )

#display(dfInValidated)
#.withColumn("v_dl_reject_prcs_msg", when((col("dl_reject_prcs_msg").isNull()) | (trim(col("dl_reject_prcs_msg")) == "") | (length(trim(col("dl_reject_prcs_msg"))) >32), concat(lit("dl_reject_prcs_msg["),col("dl_reject_prcs_msg") , lit("]"))).otherwise(lit("")))\

# let string("\x01")v_error_desc = v_ntfcn_txn_src_id + v_src_sys_cd  + v_cust_src_id  + v_cust_src_cd  + v_composite_type_cd  + v_msg_type_cd  + v_aggr_src_id  + v_enty_type_cd  + v_enty_type_val  + v_rx_nbr  + v_store_nbr  + v_rx_fill_nbr  + v_fill_enter_dt  + v_fill_enter_tm  + v_fill_dspn_nbr  + v_aggr_type  + v_aggr_priority_seq  + v_ntfcn_subtype_cd  + v_channel_cd  + v_cntc_pnt_val  + v_bypass_cd  + v_cmnt_txt  + v_ntfcn_stat_cd  + v_ntfcn_create_dttm  + v_ntfcn_create_dt  + v_ntfcn_update_dttm  + v_ntfcn_expire_dttm + v_cco_store_cd + v_fill_wtg_cd + v_dl_reject_additional_msg + v_dl_reject_prcs_msg + v_pilot_cd + v_rx_immunization_cd + v_src_create_dttm  + v_src_create_user_id  + v_src_update_dttm  + v_src_update_user_id;
# let string("\x01")v_warn_desc = "";
  
#   out.reject_header.src_name :: in.reject_header.src_name;
#   out.reject_header.src_type :: in.reject_header.src_type;
#   out.reject_header.src_key :: in.reject_header.src_key;
#   out.reject_header.err_desc:: (if(v_error_desc != "") "ERROR:" else if(v_warn_desc != "") "WARNING:" else "")
#  + (if(v_error_desc != "") " Invalid values found in input - " + v_error_desc else "")
#  + (if(v_warn_desc != "") " Substituting values - " + v_warn_desc else "");
#   out.reject_header.prty_cd:: if(v_error_desc != "") 2 else if(v_warn_desc != "") 3 else 0;
#   out.* :2: in.*;
# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'


print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'drug_id',
'drug_id_after',
'ndc_mfg',
'ndc_mfg_after',
'ndc_prod',
'ndc_prod_after',
'ndc_pkg',
'ndc_pkg_after',
'sims_upc',
'sims_upc_after',
'repack_nbr',
'repack_nbr_after',
'ndc_form_cd',
'ndc_form_cd_after',
'ndc_prev_mfg',
'ndc_prev_mfg_after',
'ndc_prev_prod',
'ndc_prev_prod_after',
'ndc_prev_pkg',
'ndc_prev_pkg_after',
'prev_repack_nbr',
'prev_repack_nbr_after',
'ndc_prev_form_cd',
'ndc_prev_form_cd_after',
'id_form_cd',
'id_form_cd_after',
'ndc_upc_hri',
'ndc_upc_hri_after',
'dur_ndc',
'dur_ndc_after',
'prev_ndc_upc_hri',
'prev_ndc_upc_hri_after',
'prev_id_form_cd',
'prev_id_form_cd_after',
'drug_class',
'drug_class_after',
'drug_orange_book_rating',
'drug_orange_book_rating_after',
'drug_name_cd',
'drug_name_cd_after',
'gppc',
'gppc_after',
'gen_typ_cd',
'gen_typ_cd_after',
'gen_id_no',
'gen_id_no_after',
'thera_class',
'thera_class_after',
'lim_stabil',
'lim_stabil_after',
'pack_descr',
'pack_descr_after',
'rx_otc_cd',
'rx_otc_cd_after',
'maint_drug_ind',
'maint_drug_ind_after',
'route_of_admin_cd',
'route_of_admin_cd_after',
'drug_generic_cd',
'drug_generic_cd_after',
'drug_type_cd',
'drug_type_cd_after',
'drug_single_comb_cd',
'drug_single_comb_cd_after',
'drug_storage_cond_cd',
'drug_storage_cond_cd_after',
'a_last_change_dttm',
'a_last_change_dttm_after',
'a_protect_ind',
'a_protect_ind_after',
'product_name',
'product_name_after',
'product_name_suffix',
'product_name_suffix_after',
'product_name_ext',
'product_name_ext_after',
'product_mddb_abbr',
'product_mddb_abbr_after',
'e_last_change_dttm',
'e_last_change_dttm_after',
'e_protect_ind',
'e_protect_ind_after',
'gpi',
'gpi_after',
'gpi_name',
'gpi_name_after',
'g_last_change_dttm',
'g_last_change_dttm_after',
'g_protect_ind',
'g_protect_ind_after',
'mfg_name',
'mfg_name_after',
'mfg_name_abbr',
'mfg_name_abbr_after',
'mfg_mddb_abbr',
'mfg_mddb_abbr_after',
'mfg_name_suffix',
'mfg_name_suffix_after',
'j_last_change_dttm',
'j_last_change_dttm_after',
'j_protect_ind',
'j_protect_ind_after',
'drug_strength',
'drug_strength_after',
'drug_strength_uom',
'drug_strength_uom_after',
'drug_dosage_form_cd',
'drug_dosage_form_cd_after',
'package_size',
'package_size_after',
'package_size_uom',
'package_size_uom_after',
'package_qty',
'package_qty_after',
'rx_to_otc_dttm',
'rx_to_otc_dttm_after',
'l_last_change_dttm',
'l_last_change_dttm_after',
'l_protect_ind',
'l_protect_ind_after',
'awp_dttm',
'awp_dttm_after',
'drug_counting_cell_id',
'drug_counting_cell_id_after',
'awp_unit_price',
'awp_unit_price_after',
'r_last_change_dttm',
'r_last_change_dttm_after',
'r_protect_ind',
'r_protect_ind_after',
'hcfa_dttm',
'hcfa_dttm_after',
'hcfa_unit_limit',
'hcfa_unit_limit_after',
't_last_change_dttm',
't_last_change_dttm_after',
't_protect_ind',
't_protect_ind_after',
'product_name_abbr',
'product_name_abbr_after',
'drug_status_cd',
'drug_status_cd_after',
'drug_disc_dttm',
'drug_disc_dttm_after',
'mfp_nbr',
'mfp_nbr_after',
'wic_nbr',
'wic_nbr_after',
'drug_ppi_ind',
'drug_ppi_ind_after',
'drug_min_disp_qty',
'drug_min_disp_qty_after',
'default_sig',
'default_sig_after',
'default_days_supply',
'default_days_supply_after',
'expiration_days',
'expiration_days_after',
'drug_class_except_ind',
'drug_class_except_ind_after',
'ops_study_dept_nbr',
'ops_study_dept_nbr_after',
'drug_warehouse_ind',
'drug_warehouse_ind_after',
'pricing_protect_ind',
'pricing_protect_ind_after',
'pr_daco_ind',
'pr_daco_ind_after',
'pricing_override_drug',
'pricing_override_drug_after',
'pricing_type',
'pricing_type_after',
'aac_unit_price',
'aac_unit_price_after',
'wac_unit_price',
'wac_unit_price_after',
'prorated_quantity',
'prorated_quantity_after',
'pricing_quantity',
'pricing_quantity_after',
'drug_shape_cd',
'drug_shape_cd_after',
'drug_color_1_cd',
'drug_color_1_cd_after',
'drug_color_2_cd',
'drug_color_2_cd_after',
'drug_side_1',
'drug_side_1_after',
'drug_side_2',
'drug_side_2_after',
'billing_ndc',
'billing_ndc_after',
'drug_comment_cd',
'drug_comment_cd_after',
'default_smart_sig',
'default_smart_sig_after',
'drug_location_cd',
'drug_location_cd_after',
'drug_multihit_disp_ind',
'drug_multihit_disp_ind_after',
'substitution_drug_id',
'substitution_drug_id_after',
'drug_volume',
'drug_volume_after',
'precount_ind',
'precount_ind_after',
'precount_qty_1',
'precount_qty_1_after',
'precount_qty_2',
'precount_qty_2_after',
'dur_kdc_nbr',
'dur_kdc_nbr_after',
'ud_uu_pkg_cd',
'ud_uu_pkg_cd_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'lbl_cmt_cd',
'lbl_cmt_cd_after',
'substitution_prod_type',
'substitution_prod_type_after',
'recon_water_qty',
'recon_water_qty_after',
'drug_spec_cmt_cd',
'drug_spec_cmt_cd_after',
'fax_pbr_cmt_cd',
'fax_pbr_cmt_cd_after',
'promise_sub_drug_id',
'promise_sub_drug_id_after',
'specialty_drug_ind',
'specialty_drug_ind_after',
'cash_disc_qty',
'cash_disc_qty_after',
'piece_weight',
'piece_weight_after',
'stock_bottle_barcode',
'stock_bottle_barcode_after',
'doses_per_pkg',
'doses_per_pkg_after',
'pct_tot_disc_card',
'pct_tot_disc_card_after',
'pet_med_ind',
'pet_med_ind_after',
'ltd_dist_cd',
'ltd_dist_cd_after',
'complicated_supplies_ind',
'complicated_supplies_ind_after',
'specialty_review_ind',
'specialty_review_ind_after',
'clinical_value_ind',
'clinical_value_ind_after',
'required_supplies_ind',
'required_supplies_ind_after',
'hcp_drug_mltht_disp_ind',
'hcp_drug_mltht_disp_ind_after',
'mix_ind',
'mix_ind_after',
'drug_image_file_name',
'drug_image_file_name_after',
'top_drug_ind',
'top_drug_ind_after',
'quality_alert_message',
'quality_alert_message_after',
'quality_alert_keywords',
'quality_alert_keywords_after',
'quality_alert_rule_ind',
'quality_alert_rule_ind_after',
'quality_alert_screen_ind',
'quality_alert_screen_ind_after',
'cash_disc_qty2',
'cash_disc_qty2_after',
'cash_disc_qty3',
'cash_disc_qty3_after',
'tip_ind',
'tip_ind_after',
'ref_drug_id',
'ref_drug_id_after',
'hcpc',
'hcpc_after',
'pref_mfr_ind',
'pref_mfr_ind_after',
'med_guide_filename',
'med_guide_filename_after',
'med_guide_ind',
'med_guide_ind_after',
'item_class',
'item_class_after',
'item_group',
'item_group_after',
'item_formulary_ind',
'item_formulary_ind_after',
'item_category',
'item_category_after',
'item_lob',
'item_lob_after',
'item_conv_factor',
'item_conv_factor_after',
'item_list_price_sale',
'item_list_price_sale_after',
'item_retail_price',
'item_retail_price_after',
'item_pum',
'item_pum_after',
'item_sub_group',
'item_sub_group_after',
'item_sub_category',
'item_sub_category_after',
'item_sum',
'item_sum_after',
'primary_vendor_item_cost',
'primary_vendor_item_cost_after',
'primary_vendor_item_nbr',
'primary_vendor_item_nbr_after',
'secndry_vendor_item_cost',
'secndry_vendor_item_cost_after',
'secndry_vendor_item_nbr',
'secndry_vendor_item_nbr_after',
'tertry_vendor_item_cost',
'tertry_vendor_item_cost_after',
'tertry_vendor_item_nbr',
'tertry_vendor_item_nbr_after',
'specific_gravity',
'specific_gravity_after',
'concentration_nbr',
'concentration_nbr_after',
'concentration_units',
'concentration_units_after',
'lipids_ind',
'lipids_ind_after',
'amino_acid_ind',
'amino_acid_ind_after',
'poolable_ind',
'poolable_ind_after',
'trace_element_ind',
'trace_element_ind_after',
'electrolyte_ind',
'electrolyte_ind_after',
'container_material_cd',
'container_material_cd_after',
'container_max_capacity',
'container_max_capacity_after',
'vehicle_ind',
'vehicle_ind_after',
'vehicle',
'vehicle_after',
'cocktail_ind',
'cocktail_ind_after',
'primary_vendor_nbr',
'primary_vendor_nbr_after',
'secondary_vendor_nbr',
'secondary_vendor_nbr_after',
'tertiary_vendor_nbr',
'tertiary_vendor_nbr_after',
'base_ind',
'base_ind_after',
'item_type',
'item_type_after',
'conc_dextrose_ind',
'conc_dextrose_ind_after',
'container_ind',
'container_ind_after',
'container_type',
'container_type_after',
'primary_vendor_name',
'primary_vendor_name_after',
'secondary_vendor_name',
'secondary_vendor_name_after',
'tertiary_vendor_name',
'tertiary_vendor_name_after',
'plx_drug_ind',
'plx_drug_ind_after',
'item_size',
'item_size_after',
'item_size_units',
'item_size_units_after',
'item_long_desc',
'item_long_desc_after',
'item_short_desc',
'item_short_desc_after',
'item_awp',
'item_awp_after',
'billing_multiplier',
'billing_multiplier_after',
'track_inventory_ind',
'track_inventory_ind_after',
'disease_state_ind',
'disease_state_ind_after',
'drug_min_price',
'drug_min_price_after',
'drug_inference_cd',
'drug_inference_cd_after',
'excl_drug_automation_ind',
'excl_drug_automation_ind_after',
'excl_tbltp_count_ind',
'excl_tbltp_count_ind_after',
'require_tbltp_clean',
'require_tbltp_clean_after',
'thera_class_extd',
'thera_class_extd_after',
'hzrds_lvl_cd',
'hzrds_lvl_cd_after',
'auth_generic_cd',
'auth_generic_cd_after',
'fda_ind',
'fda_ind_after',
'fda_ind_value',
'fda_ind_value_after',
'auth_ndc_upc_hri',
'auth_ndc_upc_hri_after',
'auth_gen_override_ind',
'auth_gen_override_ind_after',
'ddid',
'ddid_after',
'rxcui_type',
'rxcui_type_after',
'rxcui',
'rxcui_after',
'elsevier_pack_id',
'elsevier_pack_id_after',
'elsevier_prod_id',
'elsevier_prod_id_after',
'med_dosage_unit',
'med_dosage_unit_after',
'med_conv_factor',
'med_conv_factor_after',
'mme_calc_factor',
'mme_calc_factor_after'     
]

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 445 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 446:
      return True
  else:
    if val_len != 446:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len =446

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 208
print(f"Bad records count {rd_bad.count()}") # != 208


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = df.withColumn('hzrds_lvl_cd', substring('hzrds_lvl_cd', 1,2)).withColumn('hzrds_lvl_cd_after', substring('hzrds_lvl_cd_after', 1,2))
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_drug")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm)) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd_before,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id,
(case when (LENGTH(trim( drug_id )) ==0) then drug_id else trim(drug_id)end) as drug_id,
(case when (LENGTH(trim( ndc_mfg )) ==0) then ndc_mfg else trim(ndc_mfg)end) as ndc_mfg,
(case when (LENGTH(trim( ndc_prod )) ==0) then ndc_prod else trim(ndc_prod)end) as ndc_prod,
(case when (LENGTH(trim( ndc_pkg )) ==0) then ndc_pkg else trim(ndc_pkg)end) as ndc_pkg,
(case when (LENGTH(trim( sims_upc )) ==0) then sims_upc else trim(sims_upc)end) as sims_upc,
(case when (LENGTH(trim( repack_nbr )) ==0) then repack_nbr else trim(repack_nbr)end) as repack_nbr,
(case when (LENGTH(trim( ndc_form_cd )) ==0) then ndc_form_cd else trim(ndc_form_cd)end) as ndc_form_cd,
(case when (LENGTH(trim( ndc_prev_mfg )) ==0) then ndc_prev_mfg else trim(ndc_prev_mfg)end) as ndc_prev_mfg,
(case when (LENGTH(trim( ndc_prev_prod )) ==0) then ndc_prev_prod else trim(ndc_prev_prod)end) as ndc_prev_prod,
(case when (LENGTH(trim( ndc_prev_pkg )) ==0) then ndc_prev_pkg else trim(ndc_prev_pkg)end) as ndc_prev_pkg,
(case when (LENGTH(trim( prev_repack_nbr )) ==0) then prev_repack_nbr else trim(prev_repack_nbr)end) as prev_repack_nbr,
(case when (LENGTH(trim( ndc_prev_form_cd )) ==0) then ndc_prev_form_cd else trim(ndc_prev_form_cd)end) as ndc_prev_form_cd,
(case when (LENGTH(trim( id_form_cd )) ==0) then id_form_cd else trim(id_form_cd)end) as id_form_cd,
(case when (LENGTH(trim( ndc_upc_hri )) ==0) then ndc_upc_hri else trim(ndc_upc_hri)end) as ndc_upc_hri,
(case when (LENGTH(trim( dur_ndc )) ==0) then dur_ndc else trim(dur_ndc)end) as dur_ndc,
(case when (LENGTH(trim( prev_ndc_upc_hri )) ==0) then prev_ndc_upc_hri else trim(prev_ndc_upc_hri)end) as prev_ndc_upc_hri,
(case when (LENGTH(trim( prev_id_form_cd )) ==0) then prev_id_form_cd else trim(prev_id_form_cd)end) as prev_id_form_cd,
(case when (LENGTH(trim( drug_class )) ==0) then drug_class else trim(drug_class)end) as drug_class,
(case when (LENGTH(trim( drug_orange_book_rating )) ==0) then drug_orange_book_rating else trim(drug_orange_book_rating)end) as drug_orange_book_rating,
(case when (LENGTH(trim( drug_name_cd )) ==0) then drug_name_cd else trim(drug_name_cd)end) as drug_name_cd,
(case when (LENGTH(trim( gppc )) ==0) then gppc else trim(gppc)end) as gppc,
(case when (LENGTH(trim( gen_typ_cd )) ==0) then gen_typ_cd else trim(gen_typ_cd)end) as gen_typ_cd,
(case when (LENGTH(trim( gen_id_no )) ==0) then gen_id_no else trim(gen_id_no)end) as gen_id_no,
(case when (LENGTH(trim( thera_class )) ==0) then thera_class else trim(thera_class)end) as thera_class,
(case when (LENGTH(trim( lim_stabil )) ==0) then lim_stabil else trim(lim_stabil)end) as lim_stabil,
(case when (LENGTH(trim( pack_descr )) ==0) then pack_descr else trim(pack_descr)end) as pack_descr,
(case when (LENGTH(trim( rx_otc_cd )) ==0) then rx_otc_cd else trim(rx_otc_cd)end) as rx_otc_cd,
(case when (LENGTH(trim( maint_drug_ind )) ==0) then maint_drug_ind else trim(maint_drug_ind)end) as maint_drug_ind,
(case when (LENGTH(trim( route_of_admin_cd )) ==0) then route_of_admin_cd else trim(route_of_admin_cd)end) as route_of_admin_cd,
(case when (LENGTH(trim( drug_generic_cd )) ==0) then drug_generic_cd else trim(drug_generic_cd)end) as drug_generic_cd,
(case when (LENGTH(trim( drug_type_cd )) ==0) then drug_type_cd else trim(drug_type_cd)end) as drug_type_cd,
(case when (LENGTH(trim( drug_single_comb_cd )) ==0) then drug_single_comb_cd else trim(drug_single_comb_cd)end) as drug_single_comb_cd,
(case when (LENGTH(trim( drug_storage_cond_cd )) ==0) then drug_storage_cond_cd else trim(drug_storage_cond_cd)end) as drug_storage_cond_cd,
(case when (LENGTH(trim( a_last_change_dttm )) ==0) then a_last_change_dttm else concat(substring(a_last_change_dttm,1,10),' ',substring(a_last_change_dttm,12,8),'.000000')end) as a_last_change_dttm,
(case when (LENGTH(trim( a_protect_ind )) ==0) then a_protect_ind else trim(a_protect_ind)end) as a_protect_ind,
(case when (LENGTH(trim( product_name )) ==0) then product_name else trim(product_name)end) as product_name,
(case when (LENGTH(trim( product_name_suffix )) ==0) then product_name_suffix else trim(product_name_suffix)end) as product_name_suffix,
(case when (LENGTH(trim( product_name_ext )) ==0) then product_name_ext else trim(product_name_ext)end) as product_name_ext,
(case when (LENGTH(trim( product_mddb_abbr )) ==0) then product_mddb_abbr else trim(product_mddb_abbr)end) as product_mddb_abbr,
(case when (LENGTH(trim( e_last_change_dttm )) ==0) then e_last_change_dttm else concat(substring(e_last_change_dttm,1,10),' ',substring(e_last_change_dttm,12,8),'.000000')end) as e_last_change_dttm,
(case when (LENGTH(trim( e_protect_ind )) ==0) then e_protect_ind else trim(e_protect_ind)end) as e_protect_ind,
(case when (LENGTH(trim( gpi )) ==0) then gpi else trim(gpi)end) as gpi,
(case when (LENGTH(trim( gpi_name )) ==0) then gpi_name else trim(gpi_name)end) as gpi_name,
(case when (LENGTH(trim( g_last_change_dttm )) ==0) then g_last_change_dttm else concat(substring(g_last_change_dttm,1,10),' ',substring(g_last_change_dttm,12,8),'.000000')end) as g_last_change_dttm,
(case when (LENGTH(trim( g_protect_ind )) ==0) then g_protect_ind else trim(g_protect_ind)end) as g_protect_ind,
(case when (LENGTH(trim( mfg_name )) ==0) then mfg_name else trim(mfg_name)end) as mfg_name,
(case when (LENGTH(trim( mfg_name_abbr )) ==0) then mfg_name_abbr else trim(mfg_name_abbr)end) as mfg_name_abbr,
(case when (LENGTH(trim( mfg_mddb_abbr )) ==0) then mfg_mddb_abbr else trim(mfg_mddb_abbr)end) as mfg_mddb_abbr,
(case when (LENGTH(trim( mfg_name_suffix )) ==0) then mfg_name_suffix else trim(mfg_name_suffix)end) as mfg_name_suffix,
(case when (LENGTH(trim( j_last_change_dttm )) ==0) then j_last_change_dttm else concat(substring(j_last_change_dttm,1,10),' ',substring(j_last_change_dttm,12,8),'.000000')end) as j_last_change_dttm,
(case when (LENGTH(trim( j_protect_ind )) ==0) then j_protect_ind else trim(j_protect_ind)end) as j_protect_ind,
(case when (LENGTH(trim( drug_strength )) ==0) then drug_strength else trim(drug_strength)end) as drug_strength,
(case when (LENGTH(trim( drug_strength_uom )) ==0) then drug_strength_uom else trim(drug_strength_uom)end) as drug_strength_uom,
(case when (LENGTH(trim( drug_dosage_form_cd )) ==0) then drug_dosage_form_cd else trim(drug_dosage_form_cd)end) as drug_dosage_form_cd,
(case when (LENGTH(trim( package_size )) ==0) then package_size else trim(package_size)end) as package_size,
(case when (LENGTH(trim( package_size_uom )) ==0) then package_size_uom else trim(package_size_uom)end) as package_size_uom,
(case when (LENGTH(trim( package_qty )) ==0) then package_qty else trim(package_qty)end) as package_qty,
(case when (LENGTH(trim( rx_to_otc_dttm )) ==0) then rx_to_otc_dttm else concat(substring(rx_to_otc_dttm,1,10),' ',substring(rx_to_otc_dttm,12,8),'.000000')end) as rx_to_otc_dttm,
(case when (LENGTH(trim( l_last_change_dttm )) ==0) then l_last_change_dttm else concat(substring(l_last_change_dttm,1,10),' ',substring(l_last_change_dttm,12,8),'.000000')end) as l_last_change_dttm,
(case when (LENGTH(trim( l_protect_ind )) ==0) then l_protect_ind else trim(l_protect_ind)end) as l_protect_ind,
(case when (LENGTH(trim( awp_dttm )) ==0) then awp_dttm else concat(substring(awp_dttm,1,10),' ',substring(awp_dttm,12,8),'.000000')end) as awp_dttm,
(case when (LENGTH(trim( drug_counting_cell_id )) ==0) then drug_counting_cell_id else trim(drug_counting_cell_id)end) as drug_counting_cell_id,
(case when (LENGTH(trim( awp_unit_price )) ==0) then awp_unit_price else trim(awp_unit_price)end) as awp_unit_price,
(case when (LENGTH(trim( r_last_change_dttm )) ==0) then r_last_change_dttm else concat(substring(r_last_change_dttm,1,10),' ',substring(r_last_change_dttm,12,8),'.000000')end) as r_last_change_dttm,
(case when (LENGTH(trim( r_protect_ind )) ==0) then r_protect_ind else trim(r_protect_ind)end) as r_protect_ind,
(case when (LENGTH(trim( hcfa_dttm )) ==0) then hcfa_dttm else concat(substring(hcfa_dttm,1,10),' ',substring(hcfa_dttm,12,8),'.000000')end) as hcfa_dttm,
(case when (LENGTH(trim( hcfa_unit_limit )) ==0) then hcfa_unit_limit else trim(hcfa_unit_limit)end) as hcfa_unit_limit,
(case when (LENGTH(trim( t_last_change_dttm )) ==0) then t_last_change_dttm else concat(substring(t_last_change_dttm,1,10),' ',substring(t_last_change_dttm,12,8),'.000000')end) as t_last_change_dttm,
(case when (LENGTH(trim( t_protect_ind )) ==0) then t_protect_ind else trim(t_protect_ind)end) as t_protect_ind,
(case when (LENGTH(trim( product_name_abbr )) ==0) then product_name_abbr else trim(product_name_abbr)end) as product_name_abbr,
(case when (LENGTH(trim( drug_status_cd )) ==0) then drug_status_cd else trim(drug_status_cd)end) as drug_status_cd,
(case when (LENGTH(trim( drug_disc_dttm )) ==0) then drug_disc_dttm else concat(substring(drug_disc_dttm,1,10),' ',substring(drug_disc_dttm,12,8),'.000000')end) as drug_disc_dttm,
(case when (LENGTH(trim( mfp_nbr )) ==0) then mfp_nbr else trim(mfp_nbr)end) as mfp_nbr,
(case when (LENGTH(trim( wic_nbr )) ==0) then wic_nbr else trim(wic_nbr)end) as wic_nbr,
(case when (LENGTH(trim( drug_ppi_ind )) ==0) then drug_ppi_ind else trim(drug_ppi_ind)end) as drug_ppi_ind,
(case when (LENGTH(trim( drug_min_disp_qty )) ==0) then drug_min_disp_qty else trim(drug_min_disp_qty)end) as drug_min_disp_qty,
(case when (LENGTH(trim( default_sig )) ==0) then default_sig else trim(default_sig)end) as default_sig,
(case when (LENGTH(trim( default_days_supply )) ==0) then default_days_supply else trim(default_days_supply)end) as default_days_supply,
(case when (LENGTH(trim( expiration_days )) ==0) then expiration_days else trim(expiration_days)end) as expiration_days,
(case when (LENGTH(trim( drug_class_except_ind )) ==0) then drug_class_except_ind else trim(drug_class_except_ind)end) as drug_class_except_ind,
(case when (LENGTH(trim( ops_study_dept_nbr )) ==0) then ops_study_dept_nbr else trim(ops_study_dept_nbr)end) as ops_study_dept_nbr,
(case when (LENGTH(trim( drug_warehouse_ind )) ==0) then drug_warehouse_ind else trim(drug_warehouse_ind)end) as drug_warehouse_ind,
(case when (LENGTH(trim( pricing_protect_ind )) ==0) then pricing_protect_ind else trim(pricing_protect_ind)end) as pricing_protect_ind,
(case when (LENGTH(trim( pr_daco_ind )) ==0) then pr_daco_ind else trim(pr_daco_ind)end) as pr_daco_ind,
(case when (LENGTH(trim( pricing_override_drug )) ==0) then pricing_override_drug else trim(pricing_override_drug)end) as pricing_override_drug,
(case when (LENGTH(trim( pricing_type )) ==0) then pricing_type else trim(pricing_type)end) as pricing_type,
(case when (LENGTH(trim( aac_unit_price )) ==0) then aac_unit_price else trim(aac_unit_price)end) as aac_unit_price,
(case when (LENGTH(trim( wac_unit_price )) ==0) then wac_unit_price else trim(wac_unit_price)end) as wac_unit_price,
(case when (LENGTH(trim( prorated_quantity )) ==0) then prorated_quantity else trim(prorated_quantity)end) as prorated_quantity,
(case when (LENGTH(trim( pricing_quantity )) ==0) then pricing_quantity else trim(pricing_quantity)end) as pricing_quantity,
(case when (LENGTH(trim( drug_shape_cd )) ==0) then drug_shape_cd else trim(drug_shape_cd)end) as drug_shape_cd,
(case when (LENGTH(trim( drug_color_1_cd )) ==0) then drug_color_1_cd else trim(drug_color_1_cd)end) as drug_color_1_cd,
(case when (LENGTH(trim( drug_color_2_cd )) ==0) then drug_color_2_cd else trim(drug_color_2_cd)end) as drug_color_2_cd,
(case when (LENGTH(trim( drug_side_1 )) ==0) then drug_side_1 else trim(drug_side_1)end) as drug_side_1,
(case when (LENGTH(trim( drug_side_2 )) ==0) then drug_side_2 else trim(drug_side_2)end) as drug_side_2,
(case when (LENGTH(trim( billing_ndc )) ==0) then billing_ndc else trim(billing_ndc)end) as billing_ndc,
(case when (LENGTH(trim( drug_comment_cd )) ==0) then drug_comment_cd else trim(drug_comment_cd)end) as drug_comment_cd,
(case when (LENGTH(trim( default_smart_sig )) ==0) then default_smart_sig else trim(default_smart_sig)end) as default_smart_sig,
(case when (LENGTH(trim( drug_location_cd )) ==0) then drug_location_cd else trim(drug_location_cd)end) as drug_location_cd,
(case when (LENGTH(trim( drug_multihit_disp_ind )) ==0) then drug_multihit_disp_ind else trim(drug_multihit_disp_ind)end) as drug_multihit_disp_ind,
(case when (LENGTH(trim( substitution_drug_id )) ==0) then substitution_drug_id else trim(substitution_drug_id)end) as substitution_drug_id,
(case when (LENGTH(trim( drug_volume )) ==0) then drug_volume else trim(drug_volume)end) as drug_volume,
(case when (LENGTH(trim( precount_ind )) ==0) then precount_ind else trim(precount_ind)end) as precount_ind,
(case when (LENGTH(trim( precount_qty_1 )) ==0) then precount_qty_1 else trim(precount_qty_1)end) as precount_qty_1,
(case when (LENGTH(trim( precount_qty_2 )) ==0) then precount_qty_2 else trim(precount_qty_2)end) as precount_qty_2,
(case when (LENGTH(trim( dur_kdc_nbr )) ==0) then dur_kdc_nbr else trim(dur_kdc_nbr)end) as dur_kdc_nbr,
(case when (LENGTH(trim( ud_uu_pkg_cd )) ==0) then ud_uu_pkg_cd else trim(ud_uu_pkg_cd)end) as ud_uu_pkg_cd,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_dttm )) ==0) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim( update_dttm )) ==0) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( lbl_cmt_cd )) ==0) then lbl_cmt_cd else trim(lbl_cmt_cd)end) as lbl_cmt_cd,
(case when (LENGTH(trim( substitution_prod_type )) ==0) then substitution_prod_type else trim(substitution_prod_type)end) as substitution_prod_type,
(case when (LENGTH(trim( recon_water_qty )) ==0) then recon_water_qty else trim(recon_water_qty)end) as recon_water_qty,
(case when (LENGTH(trim( drug_spec_cmt_cd )) ==0) then drug_spec_cmt_cd else trim(drug_spec_cmt_cd)end) as drug_spec_cmt_cd,
(case when (LENGTH(trim( fax_pbr_cmt_cd )) ==0) then fax_pbr_cmt_cd else trim(fax_pbr_cmt_cd)end) as fax_pbr_cmt_cd,
(case when (LENGTH(trim( promise_sub_drug_id )) ==0) then promise_sub_drug_id else trim(promise_sub_drug_id)end) as promise_sub_drug_id,
(case when (LENGTH(trim( specialty_drug_ind )) ==0) then specialty_drug_ind else trim(specialty_drug_ind)end) as specialty_drug_ind,
(case when (LENGTH(trim( cash_disc_qty )) ==0) then cash_disc_qty else trim(cash_disc_qty)end) as cash_disc_qty,
(case when (LENGTH(trim( piece_weight )) ==0) then piece_weight else trim(piece_weight)end) as piece_weight,
(case when (LENGTH(trim( stock_bottle_barcode )) ==0) then stock_bottle_barcode else trim(stock_bottle_barcode)end) as stock_bottle_barcode,
(case when (LENGTH(trim( doses_per_pkg )) ==0) then doses_per_pkg else trim(doses_per_pkg)end) as doses_per_pkg,
(case when (LENGTH(trim( pct_tot_disc_card )) ==0) then pct_tot_disc_card else trim(pct_tot_disc_card)end) as pct_tot_disc_card,
(case when (LENGTH(trim( pet_med_ind )) ==0) then pet_med_ind else trim(pet_med_ind)end) as pet_med_ind,
(case when (LENGTH(trim( ltd_dist_cd )) ==0) then ltd_dist_cd else trim(ltd_dist_cd)end) as ltd_dist_cd,
(case when (LENGTH(trim( complicated_supplies_ind )) ==0) then complicated_supplies_ind else trim(complicated_supplies_ind)end) as complicated_supplies_ind,
(case when (LENGTH(trim( specialty_review_ind )) ==0) then specialty_review_ind else trim(specialty_review_ind)end) as specialty_review_ind,
(case when (LENGTH(trim( clinical_value_ind )) ==0) then clinical_value_ind else trim(clinical_value_ind)end) as clinical_value_ind,
(case when (LENGTH(trim( required_supplies_ind )) ==0) then required_supplies_ind else trim(required_supplies_ind)end) as required_supplies_ind,
(case when (LENGTH(trim( hcp_drug_mltht_disp_ind )) ==0) then hcp_drug_mltht_disp_ind else trim(hcp_drug_mltht_disp_ind)end) as hcp_drug_mltht_disp_ind,
(case when (LENGTH(trim( mix_ind )) ==0) then mix_ind else trim(mix_ind)end) as mix_ind,
(case when (LENGTH(trim( drug_image_file_name )) ==0) then drug_image_file_name else trim(drug_image_file_name)end) as drug_image_file_name,
(case when (LENGTH(trim( top_drug_ind )) ==0) then top_drug_ind else trim(top_drug_ind)end) as top_drug_ind,
(case when (LENGTH(trim( quality_alert_message )) ==0) then quality_alert_message else trim(quality_alert_message)end) as quality_alert_message,
(case when (LENGTH(trim( quality_alert_keywords )) ==0) then quality_alert_keywords else trim(quality_alert_keywords)end) as quality_alert_keywords,
(case when (LENGTH(trim( quality_alert_rule_ind )) ==0) then quality_alert_rule_ind else trim(quality_alert_rule_ind)end) as quality_alert_rule_ind,
(case when (LENGTH(trim( quality_alert_screen_ind )) ==0) then quality_alert_screen_ind else trim(quality_alert_screen_ind)end) as quality_alert_screen_ind,
(case when (LENGTH(trim( cash_disc_qty2 )) ==0) then cash_disc_qty2 else trim(cash_disc_qty2)end) as cash_disc_qty2,
(case when (LENGTH(trim( cash_disc_qty3 )) ==0) then cash_disc_qty3 else trim(cash_disc_qty3)end) as cash_disc_qty3,
(case when (LENGTH(trim( tip_ind )) ==0) then tip_ind else trim(tip_ind)end) as tip_ind,
(case when (LENGTH(trim( ref_drug_id )) ==0) then ref_drug_id else trim(ref_drug_id)end) as ref_drug_id,
(case when (LENGTH(trim( hcpc )) ==0) then hcpc else trim(hcpc)end) as hcpc,
(case when (LENGTH(trim( pref_mfr_ind )) ==0) then pref_mfr_ind else trim(pref_mfr_ind)end) as pref_mfr_ind,
(case when (LENGTH(trim( med_guide_filename )) ==0) then med_guide_filename else trim(med_guide_filename)end) as med_guide_filename,
(case when (LENGTH(trim( med_guide_ind )) ==0) then med_guide_ind else trim(med_guide_ind)end) as med_guide_ind,
(case when (LENGTH(trim( item_class )) ==0) then item_class else trim(item_class)end) as item_class,
(case when (LENGTH(trim( item_group )) ==0) then item_group else trim(item_group)end) as item_group,
(case when (LENGTH(trim( item_formulary_ind )) ==0) then item_formulary_ind else trim(item_formulary_ind)end) as item_formulary_ind,
(case when (LENGTH(trim( item_category )) ==0) then item_category else trim(item_category)end) as item_category,
(case when (LENGTH(trim( item_lob )) ==0) then item_lob else trim(item_lob)end) as item_lob,
(case when (LENGTH(trim( item_conv_factor )) ==0) then item_conv_factor else trim(item_conv_factor)end) as item_conv_factor,
(case when (LENGTH(trim( item_list_price_sale )) ==0) then item_list_price_sale else trim(item_list_price_sale)end) as item_list_price_sale,
(case when (LENGTH(trim( item_retail_price )) ==0) then item_retail_price else trim(item_retail_price)end) as item_retail_price,
(case when (LENGTH(trim( item_pum )) ==0) then item_pum else trim(item_pum)end) as item_pum,
(case when (LENGTH(trim( item_sub_group )) ==0) then item_sub_group else trim(item_sub_group)end) as item_sub_group,
(case when (LENGTH(trim( item_sub_category )) ==0) then item_sub_category else trim(item_sub_category)end) as item_sub_category,
(case when (LENGTH(trim( item_sum )) ==0) then item_sum else trim(item_sum)end) as item_sum,
(case when (LENGTH(trim( primary_vendor_item_cost )) ==0) then primary_vendor_item_cost else trim(primary_vendor_item_cost)end) as primary_vendor_item_cost,
(case when (LENGTH(trim( primary_vendor_item_nbr )) ==0) then primary_vendor_item_nbr else trim(primary_vendor_item_nbr)end) as primary_vendor_item_nbr,
(case when (LENGTH(trim( secndry_vendor_item_cost )) ==0) then secndry_vendor_item_cost else trim(secndry_vendor_item_cost)end) as secndry_vendor_item_cost,
(case when (LENGTH(trim( secndry_vendor_item_nbr )) ==0) then secndry_vendor_item_nbr else trim(secndry_vendor_item_nbr)end) as secndry_vendor_item_nbr,
(case when (LENGTH(trim( tertry_vendor_item_cost )) ==0) then tertry_vendor_item_cost else trim(tertry_vendor_item_cost)end) as tertry_vendor_item_cost,
(case when (LENGTH(trim( tertry_vendor_item_nbr )) ==0) then tertry_vendor_item_nbr else trim(tertry_vendor_item_nbr)end) as tertry_vendor_item_nbr,
(case when (LENGTH(trim( specific_gravity )) ==0) then specific_gravity else trim(specific_gravity)end) as specific_gravity,
(case when (LENGTH(trim( concentration_nbr )) ==0) then concentration_nbr else trim(concentration_nbr)end) as concentration_nbr,
(case when (LENGTH(trim( concentration_units )) ==0) then concentration_units else trim(concentration_units)end) as concentration_units,
(case when (LENGTH(trim( lipids_ind )) ==0) then lipids_ind else trim(lipids_ind)end) as lipids_ind,
(case when (LENGTH(trim( amino_acid_ind )) ==0) then amino_acid_ind else trim(amino_acid_ind)end) as amino_acid_ind,
(case when (LENGTH(trim( poolable_ind )) ==0) then poolable_ind else trim(poolable_ind)end) as poolable_ind,
(case when (LENGTH(trim( trace_element_ind )) ==0) then trace_element_ind else trim(trace_element_ind)end) as trace_element_ind,
(case when (LENGTH(trim( electrolyte_ind )) ==0) then electrolyte_ind else trim(electrolyte_ind)end) as electrolyte_ind,
(case when (LENGTH(trim( container_material_cd )) ==0) then container_material_cd else trim(container_material_cd)end) as container_material_cd,
(case when (LENGTH(trim( container_max_capacity )) ==0) then container_max_capacity else trim(container_max_capacity)end) as container_max_capacity,
(case when (LENGTH(trim( vehicle_ind )) ==0) then vehicle_ind else trim(vehicle_ind)end) as vehicle_ind,
(case when (LENGTH(trim( vehicle )) ==0) then vehicle else trim(vehicle)end) as vehicle,
(case when (LENGTH(trim( cocktail_ind )) ==0) then cocktail_ind else trim(cocktail_ind)end) as cocktail_ind,
(case when (LENGTH(trim( primary_vendor_nbr )) ==0) then primary_vendor_nbr else trim(primary_vendor_nbr)end) as primary_vendor_nbr,
(case when (LENGTH(trim( secondary_vendor_nbr )) ==0) then secondary_vendor_nbr else trim(secondary_vendor_nbr)end) as secondary_vendor_nbr,
(case when (LENGTH(trim( tertiary_vendor_nbr )) ==0) then tertiary_vendor_nbr else trim(tertiary_vendor_nbr)end) as tertiary_vendor_nbr,
(case when (LENGTH(trim( base_ind )) ==0) then base_ind else trim(base_ind)end) as base_ind,
(case when (LENGTH(trim( item_type )) ==0) then item_type else trim(item_type)end) as item_type,
(case when (LENGTH(trim( conc_dextrose_ind )) ==0) then conc_dextrose_ind else trim(conc_dextrose_ind)end) as conc_dextrose_ind,
(case when (LENGTH(trim( container_ind )) ==0) then container_ind else trim(container_ind)end) as container_ind,
(case when (LENGTH(trim( container_type )) ==0) then container_type else trim(container_type)end) as container_type,
(case when (LENGTH(trim( primary_vendor_name )) ==0) then primary_vendor_name else trim(primary_vendor_name)end) as primary_vendor_name,
(case when (LENGTH(trim( secondary_vendor_name )) ==0) then secondary_vendor_name else trim(secondary_vendor_name)end) as secondary_vendor_name,
(case when (LENGTH(trim( tertiary_vendor_name )) ==0) then tertiary_vendor_name else trim(tertiary_vendor_name)end) as tertiary_vendor_name,
(case when (LENGTH(trim( plx_drug_ind )) ==0) then plx_drug_ind else trim(plx_drug_ind)end) as plx_drug_ind,
(case when (LENGTH(trim( item_size )) ==0) then item_size else trim(item_size)end) as item_size,
(case when (LENGTH(trim( item_size_units )) ==0) then item_size_units else trim(item_size_units)end) as item_size_units,
(case when (LENGTH(trim( item_long_desc )) ==0) then item_long_desc else trim(item_long_desc)end) as item_long_desc,
(case when (LENGTH(trim( item_short_desc )) ==0) then item_short_desc else trim(item_short_desc)end) as item_short_desc,
(case when (LENGTH(trim( item_awp )) ==0) then item_awp else trim(item_awp)end) as item_awp,
(case when (LENGTH(trim( billing_multiplier )) ==0) then billing_multiplier else trim(billing_multiplier)end) as billing_multiplier,
(case when (LENGTH(trim( track_inventory_ind )) ==0) then track_inventory_ind else trim(track_inventory_ind)end) as track_inventory_ind,
(case when (LENGTH(trim( disease_state_ind )) ==0) then disease_state_ind else trim(disease_state_ind)end) as disease_state_ind,
(case when (LENGTH(trim( drug_inference_cd )) ==0) then drug_inference_cd else trim(drug_inference_cd)end) as drug_min_price,
(case when (LENGTH(trim( drug_min_price )) ==0) then drug_min_price else trim(drug_min_price)end) as drug_inference_cd,
(case when (LENGTH(trim( excl_drug_automation_ind )) ==0) then excl_drug_automation_ind else trim(excl_drug_automation_ind)end) as excl_drug_automation_ind,
(case when (LENGTH(trim( excl_tbltp_count_ind )) ==0) then excl_tbltp_count_ind else trim(excl_tbltp_count_ind)end) as excl_tbltp_count_ind,
(case when (LENGTH(trim( require_tbltp_clean )) ==0) then require_tbltp_clean else trim(require_tbltp_clean)end) as require_tbltp_clean,
(case when (LENGTH(trim( thera_class_extd )) ==0) then thera_class_extd else trim(thera_class_extd)end) as thera_class_extd,
(case when (LENGTH(trim( hzrds_lvl_cd )) ==0) then hzrds_lvl_cd else trim(hzrds_lvl_cd)end) as hzrds_lvl_cd,
(case when (LENGTH(trim( auth_generic_cd )) ==0) then auth_generic_cd else trim(auth_generic_cd )end) as auth_generic_cd,
(case when (LENGTH(trim( fda_ind )) ==0) then fda_ind else trim(fda_ind )end) as fda_ind,
(case when (LENGTH(trim( fda_ind_value )) ==0) then fda_ind_value else trim(fda_ind_value )end)  as fda_ind_value,
(case when (LENGTH(trim( auth_ndc_upc_hri )) ==0) then auth_ndc_upc_hri else trim(auth_ndc_upc_hri )end) as auth_ndc_upc_hri,
(case when (LENGTH(trim( auth_gen_override_ind )) ==0) then auth_gen_override_ind else trim(auth_gen_override_ind )end) as auth_gen_override_ind,
(case when (LENGTH(trim( ddid )) ==0) then ddid else trim(ddid )end) as ddid,
(case when (LENGTH(trim( rxcui_type )) ==0) then rxcui_type else trim(rxcui_type )end) as rxcui_type,
(case when (LENGTH(trim( rxcui )) ==0) then rxcui else trim(rxcui )end) as rxcui,
(case when (LENGTH(trim( elsevier_pack_id )) ==0) then elsevier_pack_id else trim(elsevier_pack_id )end) as elsevier_pack_id,
(case when (LENGTH(trim( elsevier_prod_id )) ==0) then elsevier_prod_id else trim(elsevier_prod_id )end) as elsevier_prod_id,
(case when (LENGTH(trim( med_dosage_unit )) ==0) then med_dosage_unit else trim(med_dosage_unit )end) as med_dosage_unit,
(case when (LENGTH(trim( med_conv_factor )) ==0) then med_conv_factor else trim(med_conv_factor )end) as med_conv_factor,
(case when (LENGTH(trim( mme_calc_factor )) ==0) then mme_calc_factor else trim(mme_calc_factor )end)  as mme_calc_factor,
'000000' as tracking_id
from gg_tbf0_drug where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql2 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd_before,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( drug_id_after )) ==0) then drug_id_after else trim(drug_id_after)end) as drug_id,
(case when (LENGTH(trim( ndc_mfg_after )) ==0) then ndc_mfg_after else trim(ndc_mfg_after)end) as ndc_mfg,
(case when (LENGTH(trim( ndc_prod_after )) ==0) then ndc_prod_after else trim(ndc_prod_after)end) as ndc_prod,
(case when (LENGTH(trim( ndc_pkg_after )) ==0) then ndc_pkg_after else trim(ndc_pkg_after)end) as ndc_pkg,
(case when (LENGTH(trim( sims_upc_after )) ==0) then sims_upc_after else trim(sims_upc_after)end) as sims_upc,
(case when (LENGTH(trim( repack_nbr_after )) ==0) then repack_nbr_after else trim(repack_nbr_after)end) as repack_nbr,
(case when (LENGTH(trim( ndc_form_cd_after )) ==0) then ndc_form_cd_after else trim(ndc_form_cd_after)end) as ndc_form_cd,
(case when (LENGTH(trim( ndc_prev_mfg_after )) ==0) then ndc_prev_mfg_after else trim(ndc_prev_mfg_after)end) as ndc_prev_mfg,
(case when (LENGTH(trim( ndc_prev_prod_after )) ==0) then ndc_prev_prod_after else trim(ndc_prev_prod_after)end) as ndc_prev_prod,
(case when (LENGTH(trim( ndc_prev_pkg_after )) ==0) then ndc_prev_pkg_after else trim(ndc_prev_pkg_after)end) as ndc_prev_pkg,
(case when (LENGTH(trim( prev_repack_nbr_after )) ==0) then prev_repack_nbr_after else trim(prev_repack_nbr_after)end) as prev_repack_nbr,
(case when (LENGTH(trim( ndc_prev_form_cd_after )) ==0) then ndc_prev_form_cd_after else trim(ndc_prev_form_cd_after)end) as ndc_prev_form_cd,
(case when (LENGTH(trim( id_form_cd_after )) ==0) then id_form_cd_after else trim(id_form_cd_after)end) as id_form_cd,
(case when (LENGTH(trim( ndc_upc_hri_after )) ==0) then ndc_upc_hri_after else trim(ndc_upc_hri_after)end) as ndc_upc_hri,
(case when (LENGTH(trim( dur_ndc_after )) ==0) then dur_ndc_after else trim(dur_ndc_after)end) as dur_ndc,
(case when (LENGTH(trim( prev_ndc_upc_hri_after )) ==0) then prev_ndc_upc_hri_after else trim(prev_ndc_upc_hri_after)end) as prev_ndc_upc_hri,
(case when (LENGTH(trim( prev_id_form_cd_after )) ==0) then prev_id_form_cd_after else trim(prev_id_form_cd_after)end) as prev_id_form_cd,
(case when (LENGTH(trim( drug_class_after )) ==0) then drug_class_after else trim(drug_class_after)end) as drug_class,
(case when (LENGTH(trim( drug_orange_book_rating_after )) ==0) then drug_orange_book_rating_after else trim(drug_orange_book_rating_after)end) as drug_orange_book_rating,
(case when (LENGTH(trim( drug_name_cd_after )) ==0) then drug_name_cd_after else trim(drug_name_cd_after)end) as drug_name_cd,
(case when (LENGTH(trim( gppc_after )) ==0) then gppc_after else trim(gppc_after)end) as gppc,
(case when (LENGTH(trim( gen_typ_cd_after )) ==0) then gen_typ_cd_after else trim(gen_typ_cd_after)end) as gen_typ_cd,
(case when (LENGTH(trim( gen_id_no_after )) ==0) then gen_id_no_after else trim(gen_id_no_after)end) as gen_id_no,
(case when (LENGTH(trim( thera_class_after )) ==0) then thera_class_after else trim(thera_class_after)end) as thera_class,
(case when (LENGTH(trim( lim_stabil_after )) ==0) then lim_stabil_after else trim(lim_stabil_after)end) as lim_stabil,
(case when (LENGTH(trim( pack_descr_after )) ==0) then pack_descr_after else trim(pack_descr_after)end) as pack_descr,
(case when (LENGTH(trim( rx_otc_cd_after )) ==0) then rx_otc_cd_after else trim(rx_otc_cd_after)end) as rx_otc_cd,
(case when (LENGTH(trim( maint_drug_ind_after )) ==0) then maint_drug_ind_after else trim(maint_drug_ind_after)end) as maint_drug_ind,
(case when (LENGTH(trim( route_of_admin_cd_after )) ==0) then route_of_admin_cd_after else trim(route_of_admin_cd_after)end) as route_of_admin_cd,
(case when (LENGTH(trim( drug_generic_cd_after )) ==0) then drug_generic_cd_after else trim(drug_generic_cd_after)end) as drug_generic_cd,
(case when (LENGTH(trim( drug_type_cd_after )) ==0) then drug_type_cd_after else trim(drug_type_cd_after)end) as drug_type_cd,
(case when (LENGTH(trim( drug_single_comb_cd_after )) ==0) then drug_single_comb_cd_after else trim(drug_single_comb_cd_after)end) as drug_single_comb_cd,
(case when (LENGTH(trim( drug_storage_cond_cd_after )) ==0) then drug_storage_cond_cd_after else trim(drug_storage_cond_cd_after)end) as drug_storage_cond_cd,
(case when (LENGTH(trim( a_last_change_dttm_after )) ==0) then a_last_change_dttm_after else concat(substring(a_last_change_dttm_after,1,10),' ',substring(a_last_change_dttm_after,12,8),'.000000')end) as a_last_change_dttm,
(case when (LENGTH(trim( a_protect_ind_after )) ==0) then a_protect_ind_after else trim(a_protect_ind_after)end) as a_protect_ind,
(case when (LENGTH(trim( product_name_after )) ==0) then product_name_after else trim(product_name_after)end) as product_name,
(case when (LENGTH(trim( product_name_suffix_after )) ==0) then product_name_suffix_after else trim(product_name_suffix_after)end) as product_name_suffix,
(case when (LENGTH(trim( product_name_ext_after )) ==0) then product_name_ext_after else trim(product_name_ext_after)end) as product_name_ext,
(case when (LENGTH(trim( product_mddb_abbr_after )) ==0) then product_mddb_abbr_after else trim(product_mddb_abbr_after)end) as product_mddb_abbr,
(case when (LENGTH(trim( e_last_change_dttm_after )) ==0) then e_last_change_dttm_after else concat(substring(e_last_change_dttm_after,1,10),' ',substring(e_last_change_dttm_after,12,8),'.000000')end) as e_last_change_dttm,
(case when (LENGTH(trim( e_protect_ind_after )) ==0) then e_protect_ind_after else trim(e_protect_ind_after)end) as e_protect_ind,
(case when (LENGTH(trim( gpi_after )) ==0) then gpi_after else trim(gpi_after)end) as gpi,
(case when (LENGTH(trim( gpi_name_after )) ==0) then gpi_name_after else trim(gpi_name_after)end) as gpi_name,
(case when (LENGTH(trim( g_last_change_dttm_after )) ==0) then g_last_change_dttm_after else concat(substring(g_last_change_dttm_after,1,10),' ',substring(g_last_change_dttm_after,12,8),'.000000')end) as g_last_change_dttm,
(case when (LENGTH(trim( g_protect_ind_after )) ==0) then g_protect_ind_after else trim(g_protect_ind_after)end) as g_protect_ind,
(case when (LENGTH(trim( mfg_name_after )) ==0) then mfg_name_after else trim(mfg_name_after)end) as mfg_name,
(case when (LENGTH(trim( mfg_name_abbr_after )) ==0) then mfg_name_abbr_after else trim(mfg_name_abbr_after)end) as mfg_name_abbr,
(case when (LENGTH(trim( mfg_mddb_abbr_after )) ==0) then mfg_mddb_abbr_after else trim(mfg_mddb_abbr_after)end) as mfg_mddb_abbr,
(case when (LENGTH(trim( mfg_name_suffix_after )) ==0) then mfg_name_suffix_after else trim(mfg_name_suffix_after)end) as mfg_name_suffix,
(case when (LENGTH(trim( j_last_change_dttm_after )) ==0) then j_last_change_dttm_after else concat(substring(j_last_change_dttm_after,1,10),' ',substring(j_last_change_dttm_after,12,8),'.000000')end) as j_last_change_dttm,
(case when (LENGTH(trim( j_protect_ind_after )) ==0) then j_protect_ind_after else trim(j_protect_ind_after)end) as j_protect_ind,
(case when (LENGTH(trim( drug_strength_after )) ==0) then drug_strength_after else trim(drug_strength_after)end) as drug_strength,
(case when (LENGTH(trim( drug_strength_uom_after )) ==0) then drug_strength_uom_after else trim(drug_strength_uom_after)end) as drug_strength_uom,
(case when (LENGTH(trim( drug_dosage_form_cd_after )) ==0) then drug_dosage_form_cd_after else trim(drug_dosage_form_cd_after)end) as drug_dosage_form_cd,
(case when (LENGTH(trim( package_size_after )) ==0) then package_size_after else trim(package_size_after)end) as package_size,
(case when (LENGTH(trim( package_size_uom_after )) ==0) then package_size_uom_after else trim(package_size_uom_after)end) as package_size_uom,
(case when (LENGTH(trim( package_qty_after )) ==0) then package_qty_after else trim(package_qty_after)end) as package_qty,
(case when (LENGTH(trim( rx_to_otc_dttm_after )) ==0) then rx_to_otc_dttm_after else concat(substring(rx_to_otc_dttm_after,1,10),' ',substring(rx_to_otc_dttm_after,12,8),'.000000')end) as rx_to_otc_dttm,
(case when (LENGTH(trim( l_last_change_dttm_after )) ==0) then l_last_change_dttm_after else concat(substring(l_last_change_dttm_after,1,10),' ',substring(l_last_change_dttm_after,12,8),'.000000')end) as l_last_change_dttm,
(case when (LENGTH(trim( l_protect_ind_after )) ==0) then l_protect_ind_after else trim(l_protect_ind_after)end) as l_protect_ind,
(case when (LENGTH(trim( awp_dttm_after )) ==0) then awp_dttm_after else concat(substring(awp_dttm_after,1,10),' ',substring(awp_dttm_after,12,8),'.000000')end) as awp_dttm,
(case when (LENGTH(trim( drug_counting_cell_id_after )) ==0) then drug_counting_cell_id_after else trim(drug_counting_cell_id_after)end) as drug_counting_cell_id,
(case when (LENGTH(trim( awp_unit_price_after )) ==0) then awp_unit_price_after else trim(awp_unit_price_after)end) as awp_unit_price,
(case when (LENGTH(trim( r_last_change_dttm_after )) ==0) then r_last_change_dttm_after else concat(substring(r_last_change_dttm_after,1,10),' ',substring(r_last_change_dttm_after,12,8),'.000000')end) as r_last_change_dttm,
(case when (LENGTH(trim( r_protect_ind_after )) ==0) then r_protect_ind_after else trim(r_protect_ind_after)end) as r_protect_ind,
(case when (LENGTH(trim( hcfa_dttm_after )) ==0) then hcfa_dttm_after else concat(substring(hcfa_dttm_after,1,10),' ',substring(hcfa_dttm_after,12,8),'.000000')end) as hcfa_dttm,
(case when (LENGTH(trim( hcfa_unit_limit_after )) ==0) then hcfa_unit_limit_after else trim(hcfa_unit_limit_after)end) as hcfa_unit_limit,
(case when (LENGTH(trim( t_last_change_dttm_after )) ==0) then t_last_change_dttm_after else concat(substring(t_last_change_dttm_after,1,10),' ',substring(t_last_change_dttm_after,12,8),'.000000')end) as t_last_change_dttm,
(case when (LENGTH(trim( t_protect_ind_after )) ==0) then t_protect_ind_after else trim(t_protect_ind_after)end) as t_protect_ind,
(case when (LENGTH(trim( product_name_abbr_after )) ==0) then product_name_abbr_after else trim(product_name_abbr_after)end) as product_name_abbr,
(case when (LENGTH(trim( drug_status_cd_after )) ==0) then drug_status_cd_after else trim(drug_status_cd_after)end) as drug_status_cd,
(case when (LENGTH(trim( drug_disc_dttm_after )) ==0) then drug_disc_dttm_after else concat(substring(drug_disc_dttm_after,1,10),' ',substring(drug_disc_dttm_after,12,8),'.000000')end) as drug_disc_dttm,
(case when (LENGTH(trim( mfp_nbr_after )) ==0) then mfp_nbr_after else trim(mfp_nbr_after)end) as mfp_nbr,
(case when (LENGTH(trim( wic_nbr_after )) ==0) then wic_nbr_after else trim(wic_nbr_after)end) as wic_nbr,
(case when (LENGTH(trim( drug_ppi_ind_after )) ==0) then drug_ppi_ind_after else trim(drug_ppi_ind_after)end) as drug_ppi_ind,
(case when (LENGTH(trim( drug_min_disp_qty_after )) ==0) then drug_min_disp_qty_after else trim(drug_min_disp_qty_after)end) as drug_min_disp_qty,
(case when (LENGTH(trim( default_sig_after )) ==0) then default_sig_after else trim(default_sig_after)end) as default_sig,
(case when (LENGTH(trim( default_days_supply_after )) ==0) then default_days_supply_after else trim(default_days_supply_after)end) as default_days_supply,
(case when (LENGTH(trim( expiration_days_after )) ==0) then expiration_days_after else trim(expiration_days_after)end) as expiration_days,
(case when (LENGTH(trim( drug_class_except_ind_after )) ==0) then drug_class_except_ind_after else trim(drug_class_except_ind_after)end) as drug_class_except_ind,
(case when (LENGTH(trim( ops_study_dept_nbr_after )) ==0) then ops_study_dept_nbr_after else trim(ops_study_dept_nbr_after)end) as ops_study_dept_nbr,
(case when (LENGTH(trim( drug_warehouse_ind_after )) ==0) then drug_warehouse_ind_after else trim(drug_warehouse_ind_after)end) as drug_warehouse_ind,
(case when (LENGTH(trim( pricing_protect_ind_after )) ==0) then pricing_protect_ind_after else trim(pricing_protect_ind_after)end) as pricing_protect_ind,
(case when (LENGTH(trim( pr_daco_ind_after )) ==0) then pr_daco_ind_after else trim(pr_daco_ind_after)end) as pr_daco_ind,
(case when (LENGTH(trim( pricing_override_drug_after )) ==0) then pricing_override_drug_after else trim(pricing_override_drug_after)end) as pricing_override_drug,
(case when (LENGTH(trim( pricing_type_after )) ==0) then pricing_type_after else trim(pricing_type_after)end) as pricing_type,
(case when (LENGTH(trim( aac_unit_price_after )) ==0) then aac_unit_price_after else trim(aac_unit_price_after)end) as aac_unit_price,
(case when (LENGTH(trim( wac_unit_price_after )) ==0) then wac_unit_price_after else trim(wac_unit_price_after)end) as wac_unit_price,
(case when (LENGTH(trim( prorated_quantity_after )) ==0) then prorated_quantity_after else trim(prorated_quantity_after)end) as prorated_quantity,
(case when (LENGTH(trim( pricing_quantity_after )) ==0) then pricing_quantity_after else trim(pricing_quantity_after)end) as pricing_quantity,
(case when (LENGTH(trim( drug_shape_cd_after )) ==0) then drug_shape_cd_after else trim(drug_shape_cd_after)end) as drug_shape_cd,
(case when (LENGTH(trim( drug_color_1_cd_after )) ==0) then drug_color_1_cd_after else trim(drug_color_1_cd_after)end) as drug_color_1_cd,
(case when (LENGTH(trim( drug_color_2_cd_after )) ==0) then drug_color_2_cd_after else trim(drug_color_2_cd_after)end) as drug_color_2_cd,
(case when (LENGTH(trim( drug_side_1_after )) ==0) then drug_side_1_after else trim(drug_side_1_after)end) as drug_side_1,
(case when (LENGTH(trim( drug_side_2_after )) ==0) then drug_side_2_after else trim(drug_side_2_after)end) as drug_side_2,
(case when (LENGTH(trim( billing_ndc_after )) ==0) then billing_ndc_after else trim(billing_ndc_after)end) as billing_ndc,
(case when (LENGTH(trim( drug_comment_cd_after )) ==0) then drug_comment_cd_after else trim(drug_comment_cd_after)end) as drug_comment_cd,
(case when (LENGTH(trim( default_smart_sig_after )) ==0) then default_smart_sig_after else trim(default_smart_sig_after)end) as default_smart_sig,
(case when (LENGTH(trim( drug_location_cd_after )) ==0) then drug_location_cd_after else trim(drug_location_cd_after)end) as drug_location_cd,
(case when (LENGTH(trim( drug_multihit_disp_ind_after )) ==0) then drug_multihit_disp_ind_after else trim(drug_multihit_disp_ind_after)end) as drug_multihit_disp_ind,
(case when (LENGTH(trim( substitution_drug_id_after )) ==0) then substitution_drug_id_after else trim(substitution_drug_id_after)end) as substitution_drug_id,
(case when (LENGTH(trim( drug_volume_after )) ==0) then drug_volume_after else trim(drug_volume_after)end) as drug_volume,
(case when (LENGTH(trim( precount_ind_after )) ==0) then precount_ind_after else trim(precount_ind_after)end) as precount_ind,
(case when (LENGTH(trim( precount_qty_1_after )) ==0) then precount_qty_1_after else trim(precount_qty_1_after)end) as precount_qty_1,
(case when (LENGTH(trim( precount_qty_2_after )) ==0) then precount_qty_2_after else trim(precount_qty_2_after)end) as precount_qty_2,
(case when (LENGTH(trim( dur_kdc_nbr_after )) ==0) then dur_kdc_nbr_after else trim(dur_kdc_nbr_after)end) as dur_kdc_nbr,
(case when (LENGTH(trim( ud_uu_pkg_cd_after )) ==0) then ud_uu_pkg_cd_after else trim(ud_uu_pkg_cd_after)end) as ud_uu_pkg_cd,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( lbl_cmt_cd_after )) ==0) then lbl_cmt_cd_after else trim(lbl_cmt_cd_after)end) as lbl_cmt_cd,
(case when (LENGTH(trim( substitution_prod_type_after )) ==0) then substitution_prod_type_after else trim(substitution_prod_type_after)end) as substitution_prod_type,
(case when (LENGTH(trim( recon_water_qty_after )) ==0) then recon_water_qty_after else trim(recon_water_qty_after)end) as recon_water_qty,
(case when (LENGTH(trim( drug_spec_cmt_cd_after )) ==0) then drug_spec_cmt_cd_after else trim(drug_spec_cmt_cd_after)end) as drug_spec_cmt_cd,
(case when (LENGTH(trim( fax_pbr_cmt_cd_after )) ==0) then fax_pbr_cmt_cd_after else trim(fax_pbr_cmt_cd_after)end) as fax_pbr_cmt_cd,
(case when (LENGTH(trim( promise_sub_drug_id_after )) ==0) then promise_sub_drug_id_after else trim(promise_sub_drug_id_after)end) as promise_sub_drug_id,
(case when (LENGTH(trim( specialty_drug_ind_after )) ==0) then specialty_drug_ind_after else trim(specialty_drug_ind_after)end) as specialty_drug_ind,
(case when (LENGTH(trim( cash_disc_qty_after )) ==0) then cash_disc_qty_after else trim(cash_disc_qty_after)end) as cash_disc_qty,
(case when (LENGTH(trim( piece_weight_after )) ==0) then piece_weight_after else trim(piece_weight_after)end) as piece_weight,
(case when (LENGTH(trim( stock_bottle_barcode_after )) ==0) then stock_bottle_barcode_after else trim(stock_bottle_barcode_after)end) as stock_bottle_barcode,
(case when (LENGTH(trim( doses_per_pkg_after )) ==0) then doses_per_pkg_after else trim(doses_per_pkg_after)end) as doses_per_pkg,
(case when (LENGTH(trim( pct_tot_disc_card_after )) ==0) then pct_tot_disc_card_after else trim(pct_tot_disc_card_after)end) as pct_tot_disc_card,
(case when (LENGTH(trim( pet_med_ind_after )) ==0) then pet_med_ind_after else trim(pet_med_ind_after)end) as pet_med_ind,
(case when (LENGTH(trim( ltd_dist_cd_after )) ==0) then ltd_dist_cd_after else trim(ltd_dist_cd_after)end) as ltd_dist_cd,
(case when (LENGTH(trim( complicated_supplies_ind_after )) ==0) then complicated_supplies_ind_after else trim(complicated_supplies_ind_after)end) as complicated_supplies_ind,
(case when (LENGTH(trim( specialty_review_ind_after )) ==0) then specialty_review_ind_after else trim(specialty_review_ind_after)end) as specialty_review_ind,
(case when (LENGTH(trim( clinical_value_ind_after )) ==0) then clinical_value_ind_after else trim(clinical_value_ind_after)end) as clinical_value_ind,
(case when (LENGTH(trim( required_supplies_ind_after )) ==0) then required_supplies_ind_after else trim(required_supplies_ind_after)end) as required_supplies_ind,
(case when (LENGTH(trim( hcp_drug_mltht_disp_ind_after )) ==0) then hcp_drug_mltht_disp_ind_after else trim(hcp_drug_mltht_disp_ind_after)end) as hcp_drug_mltht_disp_ind,
(case when (LENGTH(trim( mix_ind_after )) ==0) then mix_ind_after else trim(mix_ind_after)end) as mix_ind,
(case when (LENGTH(trim( drug_image_file_name_after )) ==0) then drug_image_file_name_after else trim(drug_image_file_name_after)end) as drug_image_file_name,
(case when (LENGTH(trim( top_drug_ind_after )) ==0) then top_drug_ind_after else trim(top_drug_ind_after)end) as top_drug_ind,
(case when (LENGTH(trim( quality_alert_message_after )) ==0) then quality_alert_message_after else trim(quality_alert_message_after)end) as quality_alert_message,
(case when (LENGTH(trim( quality_alert_keywords_after )) ==0) then quality_alert_keywords_after else trim(quality_alert_keywords_after)end) as quality_alert_keywords,
(case when (LENGTH(trim( quality_alert_rule_ind_after )) ==0) then quality_alert_rule_ind_after else trim(quality_alert_rule_ind_after)end) as quality_alert_rule_ind,
(case when (LENGTH(trim( quality_alert_screen_ind_after )) ==0) then quality_alert_screen_ind_after else trim(quality_alert_screen_ind_after)end) as quality_alert_screen_ind,
(case when (LENGTH(trim( cash_disc_qty2_after )) ==0) then cash_disc_qty2_after else trim(cash_disc_qty2_after)end) as cash_disc_qty2,
(case when (LENGTH(trim( cash_disc_qty3_after )) ==0) then cash_disc_qty3_after else trim(cash_disc_qty3_after)end) as cash_disc_qty3,
(case when (LENGTH(trim( tip_ind_after )) ==0) then tip_ind_after else trim(tip_ind_after)end) as tip_ind,
(case when (LENGTH(trim( ref_drug_id_after )) ==0) then ref_drug_id_after else trim(ref_drug_id_after)end) as ref_drug_id,
(case when (LENGTH(trim( hcpc_after )) ==0) then hcpc_after else trim(hcpc_after)end) as hcpc,
(case when (LENGTH(trim( pref_mfr_ind_after )) ==0) then pref_mfr_ind_after else trim(pref_mfr_ind_after)end) as pref_mfr_ind,
(case when (LENGTH(trim( med_guide_filename_after )) ==0) then med_guide_filename_after else trim(med_guide_filename_after)end) as med_guide_filename,
(case when (LENGTH(trim( med_guide_ind_after )) ==0) then med_guide_ind_after else trim(med_guide_ind_after)end) as med_guide_ind,
(case when (LENGTH(trim( item_class_after )) ==0) then item_class_after else trim(item_class_after)end) as item_class,
(case when (LENGTH(trim( item_group_after )) ==0) then item_group_after else trim(item_group_after)end) as item_group,
(case when (LENGTH(trim( item_formulary_ind_after )) ==0) then item_formulary_ind_after else trim(item_formulary_ind_after)end) as item_formulary_ind,
(case when (LENGTH(trim( item_category_after )) ==0) then item_category_after else trim(item_category_after)end) as item_category,
(case when (LENGTH(trim( item_lob_after )) ==0) then item_lob_after else trim(item_lob_after)end) as item_lob,
(case when (LENGTH(trim( item_conv_factor_after )) ==0) then item_conv_factor_after else trim(item_conv_factor_after)end) as item_conv_factor,
(case when (LENGTH(trim( item_list_price_sale_after )) ==0) then item_list_price_sale_after else trim(item_list_price_sale_after)end) as item_list_price_sale,
(case when (LENGTH(trim( item_retail_price_after )) ==0) then item_retail_price_after else trim(item_retail_price_after)end) as item_retail_price,
(case when (LENGTH(trim( item_pum_after )) ==0) then item_pum_after else trim(item_pum_after)end) as item_pum,
(case when (LENGTH(trim( item_sub_group_after )) ==0) then item_sub_group_after else trim(item_sub_group_after)end) as item_sub_group,
(case when (LENGTH(trim( item_sub_category_after )) ==0) then item_sub_category_after else trim(item_sub_category_after)end) as item_sub_category,
(case when (LENGTH(trim( item_sum_after )) ==0) then item_sum_after else trim(item_sum_after)end) as item_sum,
(case when (LENGTH(trim( primary_vendor_item_cost_after )) ==0) then primary_vendor_item_cost_after else trim(primary_vendor_item_cost_after)end) as primary_vendor_item_cost,
(case when (LENGTH(trim( primary_vendor_item_nbr_after )) ==0) then primary_vendor_item_nbr_after else trim(primary_vendor_item_nbr_after)end) as primary_vendor_item_nbr,
(case when (LENGTH(trim( secndry_vendor_item_cost_after )) ==0) then secndry_vendor_item_cost_after else trim(secndry_vendor_item_cost_after)end) as secndry_vendor_item_cost,
(case when (LENGTH(trim( secndry_vendor_item_nbr_after )) ==0) then secndry_vendor_item_nbr_after else trim(secndry_vendor_item_nbr_after)end) as secndry_vendor_item_nbr,
(case when (LENGTH(trim( tertry_vendor_item_cost_after )) ==0) then tertry_vendor_item_cost_after else trim(tertry_vendor_item_cost_after)end) as tertry_vendor_item_cost,
(case when (LENGTH(trim( tertry_vendor_item_nbr_after )) ==0) then tertry_vendor_item_nbr_after else trim(tertry_vendor_item_nbr_after)end) as tertry_vendor_item_nbr,
(case when (LENGTH(trim( specific_gravity_after )) ==0) then specific_gravity_after else trim(specific_gravity_after)end) as specific_gravity,
(case when (LENGTH(trim( concentration_nbr_after )) ==0) then concentration_nbr_after else trim(concentration_nbr_after)end) as concentration_nbr,
(case when (LENGTH(trim( concentration_units_after )) ==0) then concentration_units_after else trim(concentration_units_after)end) as concentration_units,
(case when (LENGTH(trim( lipids_ind_after )) ==0) then lipids_ind_after else trim(lipids_ind_after)end) as lipids_ind,
(case when (LENGTH(trim( amino_acid_ind_after )) ==0) then amino_acid_ind_after else trim(amino_acid_ind_after)end) as amino_acid_ind,
(case when (LENGTH(trim( poolable_ind_after )) ==0) then poolable_ind_after else trim(poolable_ind_after)end) as poolable_ind,
(case when (LENGTH(trim( trace_element_ind_after )) ==0) then trace_element_ind_after else trim(trace_element_ind_after)end) as trace_element_ind,
(case when (LENGTH(trim( electrolyte_ind_after )) ==0) then electrolyte_ind_after else trim(electrolyte_ind_after)end) as electrolyte_ind,
(case when (LENGTH(trim( container_material_cd_after )) ==0) then container_material_cd_after else trim(container_material_cd_after)end) as container_material_cd,
(case when (LENGTH(trim( container_max_capacity_after )) ==0) then container_max_capacity_after else trim(container_max_capacity_after)end) as container_max_capacity,
(case when (LENGTH(trim( vehicle_ind_after )) ==0) then vehicle_ind_after else trim(vehicle_ind_after)end) as vehicle_ind,
(case when (LENGTH(trim( vehicle_after )) ==0) then vehicle_after else trim(vehicle_after)end) as vehicle,
(case when (LENGTH(trim( cocktail_ind_after )) ==0) then cocktail_ind_after else trim(cocktail_ind_after)end) as cocktail_ind,
(case when (LENGTH(trim( primary_vendor_nbr_after )) ==0) then primary_vendor_nbr_after else trim(primary_vendor_nbr_after)end) as primary_vendor_nbr,
(case when (LENGTH(trim( secondary_vendor_nbr_after )) ==0) then secondary_vendor_nbr_after else trim(secondary_vendor_nbr_after)end) as secondary_vendor_nbr,
(case when (LENGTH(trim( tertiary_vendor_nbr_after )) ==0) then tertiary_vendor_nbr_after else trim(tertiary_vendor_nbr_after)end) as tertiary_vendor_nbr,
(case when (LENGTH(trim( base_ind_after )) ==0) then base_ind_after else trim(base_ind_after)end) as base_ind,
(case when (LENGTH(trim( item_type_after )) ==0) then item_type_after else trim(item_type_after)end) as item_type,
(case when (LENGTH(trim( conc_dextrose_ind_after )) ==0) then conc_dextrose_ind_after else trim(conc_dextrose_ind_after)end) as conc_dextrose_ind,
(case when (LENGTH(trim( container_ind_after )) ==0) then container_ind_after else trim(container_ind_after)end) as container_ind,
(case when (LENGTH(trim( container_type_after )) ==0) then container_type_after else trim(container_type_after)end) as container_type,
(case when (LENGTH(trim( primary_vendor_name_after )) ==0) then primary_vendor_name_after else trim(primary_vendor_name_after)end) as primary_vendor_name,
(case when (LENGTH(trim( secondary_vendor_name_after )) ==0) then secondary_vendor_name_after else trim(secondary_vendor_name_after)end) as secondary_vendor_name,
(case when (LENGTH(trim( tertiary_vendor_name_after )) ==0) then tertiary_vendor_name_after else trim(tertiary_vendor_name_after)end) as tertiary_vendor_name,
(case when (LENGTH(trim( plx_drug_ind_after )) ==0) then plx_drug_ind_after else trim(plx_drug_ind_after)end) as plx_drug_ind,
(case when (LENGTH(trim( item_size_after )) ==0) then item_size_after else trim(item_size_after)end) as item_size,
(case when (LENGTH(trim( item_size_units_after )) ==0) then item_size_units_after else trim(item_size_units_after)end) as item_size_units,
(case when (LENGTH(trim( item_long_desc_after )) ==0) then item_long_desc_after else trim(item_long_desc_after)end) as item_long_desc,
(case when (LENGTH(trim( item_short_desc_after )) ==0) then item_short_desc_after else trim(item_short_desc_after)end) as item_short_desc,
(case when (LENGTH(trim( item_awp_after )) ==0) then item_awp_after else trim(item_awp_after)end) as item_awp,
(case when (LENGTH(trim( billing_multiplier_after )) ==0) then billing_multiplier_after else trim(billing_multiplier_after)end) as billing_multiplier,
(case when (LENGTH(trim( track_inventory_ind_after )) ==0) then track_inventory_ind_after else trim(track_inventory_ind_after)end) as track_inventory_ind,
(case when (LENGTH(trim( disease_state_ind_after )) ==0) then disease_state_ind_after else trim(disease_state_ind_after)end) as disease_state_ind,
(case when (LENGTH(trim( drug_inference_cd_after )) ==0) then drug_inference_cd_after else trim(drug_inference_cd_after)end) as drug_min_price,
(case when (LENGTH(trim( drug_min_price_after )) ==0) then drug_min_price_after else trim(drug_min_price_after)end) as drug_inference_cd,
(case when (LENGTH(trim( excl_drug_automation_ind_after )) ==0) then excl_drug_automation_ind_after else trim(excl_drug_automation_ind_after)end) as excl_drug_automation_ind,
(case when (LENGTH(trim( excl_tbltp_count_ind_after )) ==0) then excl_tbltp_count_ind_after else trim(excl_tbltp_count_ind_after)end) as excl_tbltp_count_ind,
(case when (LENGTH(trim( require_tbltp_clean_after )) ==0) then require_tbltp_clean_after else trim(require_tbltp_clean_after)end) as require_tbltp_clean,
(case when (LENGTH(trim( thera_class_extd )) ==0) then thera_class_extd else trim(thera_class_extd)end) as thera_class_extd,
(case when (LENGTH(trim( hzrds_lvl_cd_after )) ==0) then hzrds_lvl_cd_after else trim(hzrds_lvl_cd_after)end) as hzrds_lvl_cd,
(case when (LENGTH(trim( auth_generic_cd_after )) ==0) then auth_generic_cd_after else trim(auth_generic_cd_after)end) as auth_generic_cd,
(case when (LENGTH(trim( fda_ind_after )) ==0) then fda_ind_after else trim(fda_ind_after)end) as fda_ind,
(case when (LENGTH(trim( fda_ind_value_after )) ==0) then fda_ind_value_after else trim(fda_ind_value_after)end)  as fda_ind_value,
(case when (LENGTH(trim( auth_ndc_upc_hri_after )) ==0) then auth_ndc_upc_hri_after else trim(auth_ndc_upc_hri_after)end) as auth_ndc_upc_hri,
(case when (LENGTH(trim( auth_gen_override_ind_after )) ==0) then auth_gen_override_ind_after else trim(auth_gen_override_ind_after)end) as auth_gen_override_ind,
(case when (LENGTH(trim( ddid_after )) ==0) then ddid_after else trim(ddid_after)end) as ddid,
(case when (LENGTH(trim( rxcui_type_after )) ==0) then rxcui_type_after else trim(rxcui_type_after)end) as rxcui_type,
(case when (LENGTH(trim( rxcui_after )) ==0) then rxcui_after else trim(rxcui_after)end) as rxcui,
(case when (LENGTH(trim( elsevier_pack_id_after )) ==0) then elsevier_pack_id_after else trim(elsevier_pack_id_after)end) as elsevier_pack_id,
(case when (LENGTH(trim( elsevier_prod_id_after )) ==0) then	 elsevier_prod_id_after else trim(elsevier_prod_id_after )end) as elsevier_prod_id,
(case when (LENGTH(trim( med_dosage_unit_after )) ==0) then med_dosage_unit_after else trim(med_dosage_unit_after)end) as med_dosage_unit,
(case when (LENGTH(trim( med_conv_factor_after )) ==0) then med_conv_factor_after else trim(med_conv_factor_after)end) as med_conv_factor,
(case when (LENGTH(trim( mme_calc_factor_after )) ==0) then mme_calc_factor_after else trim(mme_calc_factor_after)end) as mme_calc_factor, 
'000000' as tracking_id
from gg_tbf0_drug where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd_before,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( drug_id_after )) ==0) then drug_id_after else trim(drug_id_after)end) as drug_id,
(case when (LENGTH(trim( ndc_mfg_after )) ==0) then ndc_mfg_after else trim(ndc_mfg_after)end) as ndc_mfg,
(case when (LENGTH(trim( ndc_prod_after )) ==0) then ndc_prod_after else trim(ndc_prod_after)end) as ndc_prod,
(case when (LENGTH(trim( ndc_pkg_after )) ==0) then ndc_pkg_after else trim(ndc_pkg_after)end) as ndc_pkg,
(case when (LENGTH(trim( sims_upc_after )) ==0) then sims_upc_after else trim(sims_upc_after)end) as sims_upc,
(case when (LENGTH(trim( repack_nbr_after )) ==0) then repack_nbr_after else trim(repack_nbr_after)end) as repack_nbr,
(case when (LENGTH(trim( ndc_form_cd_after )) ==0) then ndc_form_cd_after else trim(ndc_form_cd_after)end) as ndc_form_cd,
(case when (LENGTH(trim( ndc_prev_mfg_after )) ==0) then ndc_prev_mfg_after else trim(ndc_prev_mfg_after)end) as ndc_prev_mfg,
(case when (LENGTH(trim( ndc_prev_prod_after )) ==0) then ndc_prev_prod_after else trim(ndc_prev_prod_after)end) as ndc_prev_prod,
(case when (LENGTH(trim( ndc_prev_pkg_after )) ==0) then ndc_prev_pkg_after else trim(ndc_prev_pkg_after)end) as ndc_prev_pkg,
(case when (LENGTH(trim( prev_repack_nbr_after )) ==0) then prev_repack_nbr_after else trim(prev_repack_nbr_after)end) as prev_repack_nbr,
(case when (LENGTH(trim( ndc_prev_form_cd_after )) ==0) then ndc_prev_form_cd_after else trim(ndc_prev_form_cd_after)end) as ndc_prev_form_cd,
(case when (LENGTH(trim( id_form_cd_after )) ==0) then id_form_cd_after else trim(id_form_cd_after)end) as id_form_cd,
(case when (LENGTH(trim( ndc_upc_hri_after )) ==0) then ndc_upc_hri_after else trim(ndc_upc_hri_after)end) as ndc_upc_hri,
(case when (LENGTH(trim( dur_ndc_after )) ==0) then dur_ndc_after else trim(dur_ndc_after)end) as dur_ndc,
(case when (LENGTH(trim( prev_ndc_upc_hri_after )) ==0) then prev_ndc_upc_hri_after else trim(prev_ndc_upc_hri_after)end) as prev_ndc_upc_hri,
(case when (LENGTH(trim( prev_id_form_cd_after )) ==0) then prev_id_form_cd_after else trim(prev_id_form_cd_after)end) as prev_id_form_cd,
(case when (LENGTH(trim( drug_class_after )) ==0) then drug_class_after else trim(drug_class_after)end) as drug_class,
(case when (LENGTH(trim( drug_orange_book_rating_after )) ==0) then drug_orange_book_rating_after else trim(drug_orange_book_rating_after)end) as drug_orange_book_rating,
(case when (LENGTH(trim( drug_name_cd_after )) ==0) then drug_name_cd_after else trim(drug_name_cd_after)end) as drug_name_cd,
(case when (LENGTH(trim( gppc_after )) ==0) then gppc_after else trim(gppc_after)end) as gppc,
(case when (LENGTH(trim( gen_typ_cd_after )) ==0) then gen_typ_cd_after else trim(gen_typ_cd_after)end) as gen_typ_cd,
(case when (LENGTH(trim( gen_id_no_after )) ==0) then gen_id_no_after else trim(gen_id_no_after)end) as gen_id_no,
(case when (LENGTH(trim( thera_class_after )) ==0) then thera_class_after else trim(thera_class_after)end) as thera_class,
(case when (LENGTH(trim( lim_stabil_after )) ==0) then lim_stabil_after else trim(lim_stabil_after)end) as lim_stabil,
(case when (LENGTH(trim( pack_descr_after )) ==0) then pack_descr_after else trim(pack_descr_after)end) as pack_descr,
(case when (LENGTH(trim( rx_otc_cd_after )) ==0) then rx_otc_cd_after else trim(rx_otc_cd_after)end) as rx_otc_cd,
(case when (LENGTH(trim( maint_drug_ind_after )) ==0) then maint_drug_ind_after else trim(maint_drug_ind_after)end) as maint_drug_ind,
(case when (LENGTH(trim( route_of_admin_cd_after )) ==0) then route_of_admin_cd_after else trim(route_of_admin_cd_after)end) as route_of_admin_cd,
(case when (LENGTH(trim( drug_generic_cd_after )) ==0) then drug_generic_cd_after else trim(drug_generic_cd_after)end) as drug_generic_cd,
(case when (LENGTH(trim( drug_type_cd_after )) ==0) then drug_type_cd_after else trim(drug_type_cd_after)end) as drug_type_cd,
(case when (LENGTH(trim( drug_single_comb_cd_after )) ==0) then drug_single_comb_cd_after else trim(drug_single_comb_cd_after)end) as drug_single_comb_cd,
(case when (LENGTH(trim( drug_storage_cond_cd_after )) ==0) then drug_storage_cond_cd_after else trim(drug_storage_cond_cd_after)end) as drug_storage_cond_cd,
(case when (LENGTH(trim( a_last_change_dttm_after )) ==0) then a_last_change_dttm_after else concat(substring(a_last_change_dttm_after,1,10),' ',substring(a_last_change_dttm_after,12,8),'.000000')end) as a_last_change_dttm,
(case when (LENGTH(trim( a_protect_ind_after )) ==0) then a_protect_ind_after else trim(a_protect_ind_after)end) as a_protect_ind,
(case when (LENGTH(trim( product_name_after )) ==0) then product_name_after else trim(product_name_after)end) as product_name,
(case when (LENGTH(trim( product_name_suffix_after )) ==0) then product_name_suffix_after else trim(product_name_suffix_after)end) as product_name_suffix,
(case when (LENGTH(trim( product_name_ext_after )) ==0) then product_name_ext_after else trim(product_name_ext_after)end) as product_name_ext,
(case when (LENGTH(trim( product_mddb_abbr_after )) ==0) then product_mddb_abbr_after else trim(product_mddb_abbr_after)end) as product_mddb_abbr,
(case when (LENGTH(trim( e_last_change_dttm_after )) ==0) then e_last_change_dttm_after else concat(substring(e_last_change_dttm_after,1,10),' ',substring(e_last_change_dttm_after,12,8),'.000000')end) as e_last_change_dttm,
(case when (LENGTH(trim( e_protect_ind_after )) ==0) then e_protect_ind_after else trim(e_protect_ind_after)end) as e_protect_ind,
(case when (LENGTH(trim( gpi_after )) ==0) then gpi_after else trim(gpi_after)end) as gpi,
(case when (LENGTH(trim( gpi_name_after )) ==0) then gpi_name_after else trim(gpi_name_after)end) as gpi_name,
(case when (LENGTH(trim( g_last_change_dttm_after )) ==0) then g_last_change_dttm_after else concat(substring(g_last_change_dttm_after,1,10),' ',substring(g_last_change_dttm_after,12,8),'.000000')end) as g_last_change_dttm,
(case when (LENGTH(trim( g_protect_ind_after )) ==0) then g_protect_ind_after else trim(g_protect_ind_after)end) as g_protect_ind,
(case when (LENGTH(trim( mfg_name_after )) ==0) then mfg_name_after else trim(mfg_name_after)end) as mfg_name,
(case when (LENGTH(trim( mfg_name_abbr_after )) ==0) then mfg_name_abbr_after else trim(mfg_name_abbr_after)end) as mfg_name_abbr,
(case when (LENGTH(trim( mfg_mddb_abbr_after )) ==0) then mfg_mddb_abbr_after else trim(mfg_mddb_abbr_after)end) as mfg_mddb_abbr,
(case when (LENGTH(trim( mfg_name_suffix_after )) ==0) then mfg_name_suffix_after else trim(mfg_name_suffix_after)end) as mfg_name_suffix,
(case when (LENGTH(trim( j_last_change_dttm_after )) ==0) then j_last_change_dttm_after else concat(substring(j_last_change_dttm_after,1,10),' ',substring(j_last_change_dttm_after,12,8),'.000000')end) as j_last_change_dttm,
(case when (LENGTH(trim( j_protect_ind_after )) ==0) then j_protect_ind_after else trim(j_protect_ind_after)end) as j_protect_ind,
(case when (LENGTH(trim( drug_strength_after )) ==0) then drug_strength_after else trim(drug_strength_after)end) as drug_strength,
(case when (LENGTH(trim( drug_strength_uom_after )) ==0) then drug_strength_uom_after else trim(drug_strength_uom_after)end) as drug_strength_uom,
(case when (LENGTH(trim( drug_dosage_form_cd_after )) ==0) then drug_dosage_form_cd_after else trim(drug_dosage_form_cd_after)end) as drug_dosage_form_cd,
(case when (LENGTH(trim( package_size_after )) ==0) then package_size_after else trim(package_size_after)end) as package_size,
(case when (LENGTH(trim( package_size_uom_after )) ==0) then package_size_uom_after else trim(package_size_uom_after)end) as package_size_uom,
(case when (LENGTH(trim( package_qty_after )) ==0) then package_qty_after else trim(package_qty_after)end) as package_qty,
(case when (LENGTH(trim( rx_to_otc_dttm_after )) ==0) then rx_to_otc_dttm_after else concat(substring(rx_to_otc_dttm_after,1,10),' ',substring(rx_to_otc_dttm_after,12,8),'.000000')end) as rx_to_otc_dttm,
(case when (LENGTH(trim( l_last_change_dttm_after )) ==0) then l_last_change_dttm_after else concat(substring(l_last_change_dttm_after,1,10),' ',substring(l_last_change_dttm_after,12,8),'.000000')end) as l_last_change_dttm,
(case when (LENGTH(trim( l_protect_ind_after )) ==0) then l_protect_ind_after else trim(l_protect_ind_after)end) as l_protect_ind,
(case when (LENGTH(trim( awp_dttm_after )) ==0) then awp_dttm_after else concat(substring(awp_dttm_after,1,10),' ',substring(awp_dttm_after,12,8),'.000000')end) as awp_dttm,
(case when (LENGTH(trim( drug_counting_cell_id_after )) ==0) then drug_counting_cell_id_after else trim(drug_counting_cell_id_after)end) as drug_counting_cell_id,
(case when (LENGTH(trim( awp_unit_price_after )) ==0) then awp_unit_price_after else trim(awp_unit_price_after)end) as awp_unit_price,
(case when (LENGTH(trim( r_last_change_dttm_after )) ==0) then r_last_change_dttm_after else concat(substring(r_last_change_dttm_after,1,10),' ',substring(r_last_change_dttm_after,12,8),'.000000')end) as r_last_change_dttm,
(case when (LENGTH(trim( r_protect_ind_after )) ==0) then r_protect_ind_after else trim(r_protect_ind_after)end) as r_protect_ind,
(case when (LENGTH(trim( hcfa_dttm_after )) ==0) then hcfa_dttm_after else concat(substring(hcfa_dttm_after,1,10),' ',substring(hcfa_dttm_after,12,8),'.000000')end) as hcfa_dttm,
(case when (LENGTH(trim( hcfa_unit_limit_after )) ==0) then hcfa_unit_limit_after else trim(hcfa_unit_limit_after)end) as hcfa_unit_limit,
(case when (LENGTH(trim( t_last_change_dttm_after )) ==0) then t_last_change_dttm_after else concat(substring(t_last_change_dttm_after,1,10),' ',substring(t_last_change_dttm_after,12,8),'.000000')end) as t_last_change_dttm,
(case when (LENGTH(trim( t_protect_ind_after )) ==0) then t_protect_ind_after else trim(t_protect_ind_after)end) as t_protect_ind,
(case when (LENGTH(trim( product_name_abbr_after )) ==0) then product_name_abbr_after else trim(product_name_abbr_after)end) as product_name_abbr,
(case when (LENGTH(trim( drug_status_cd_after )) ==0) then drug_status_cd_after else trim(drug_status_cd_after)end) as drug_status_cd,
(case when (LENGTH(trim( drug_disc_dttm_after )) ==0) then drug_disc_dttm_after else concat(substring(drug_disc_dttm_after,1,10),' ',substring(drug_disc_dttm_after,12,8),'.000000')end) as drug_disc_dttm,
(case when (LENGTH(trim( mfp_nbr_after )) ==0) then mfp_nbr_after else trim(mfp_nbr_after)end) as mfp_nbr,
(case when (LENGTH(trim( wic_nbr_after )) ==0) then wic_nbr_after else trim(wic_nbr_after)end) as wic_nbr,
(case when (LENGTH(trim( drug_ppi_ind_after )) ==0) then drug_ppi_ind_after else trim(drug_ppi_ind_after)end) as drug_ppi_ind,
(case when (LENGTH(trim( drug_min_disp_qty_after )) ==0) then drug_min_disp_qty_after else trim(drug_min_disp_qty_after)end) as drug_min_disp_qty,
(case when (LENGTH(trim( default_sig_after )) ==0) then default_sig_after else trim(default_sig_after)end) as default_sig,
(case when (LENGTH(trim( default_days_supply_after )) ==0) then default_days_supply_after else trim(default_days_supply_after)end) as default_days_supply,
(case when (LENGTH(trim( expiration_days_after )) ==0) then expiration_days_after else trim(expiration_days_after)end) as expiration_days,
(case when (LENGTH(trim( drug_class_except_ind_after )) ==0) then drug_class_except_ind_after else trim(drug_class_except_ind_after)end) as drug_class_except_ind,
(case when (LENGTH(trim( ops_study_dept_nbr_after )) ==0) then ops_study_dept_nbr_after else trim(ops_study_dept_nbr_after)end) as ops_study_dept_nbr,
(case when (LENGTH(trim( drug_warehouse_ind_after )) ==0) then drug_warehouse_ind_after else trim(drug_warehouse_ind_after)end) as drug_warehouse_ind,
(case when (LENGTH(trim( pricing_protect_ind_after )) ==0) then pricing_protect_ind_after else trim(pricing_protect_ind_after)end) as pricing_protect_ind,
(case when (LENGTH(trim( pr_daco_ind_after )) ==0) then pr_daco_ind_after else trim(pr_daco_ind_after)end) as pr_daco_ind,
(case when (LENGTH(trim( pricing_override_drug_after )) ==0) then pricing_override_drug_after else trim(pricing_override_drug_after)end) as pricing_override_drug,
(case when (LENGTH(trim( pricing_type_after )) ==0) then pricing_type_after else trim(pricing_type_after)end) as pricing_type,
(case when (LENGTH(trim( aac_unit_price_after )) ==0) then aac_unit_price_after else trim(aac_unit_price_after)end) as aac_unit_price,
(case when (LENGTH(trim( wac_unit_price_after )) ==0) then wac_unit_price_after else trim(wac_unit_price_after)end) as wac_unit_price,
(case when (LENGTH(trim( prorated_quantity_after )) ==0) then prorated_quantity_after else trim(prorated_quantity_after)end) as prorated_quantity,
(case when (LENGTH(trim( pricing_quantity_after )) ==0) then pricing_quantity_after else trim(pricing_quantity_after)end) as pricing_quantity,
(case when (LENGTH(trim( drug_shape_cd_after )) ==0) then drug_shape_cd_after else trim(drug_shape_cd_after)end) as drug_shape_cd,
(case when (LENGTH(trim( drug_color_1_cd_after )) ==0) then drug_color_1_cd_after else trim(drug_color_1_cd_after)end) as drug_color_1_cd,
(case when (LENGTH(trim( drug_color_2_cd_after )) ==0) then drug_color_2_cd_after else trim(drug_color_2_cd_after)end) as drug_color_2_cd,
(case when (LENGTH(trim( drug_side_1_after )) ==0) then drug_side_1_after else trim(drug_side_1_after)end) as drug_side_1,
(case when (LENGTH(trim( drug_side_2_after )) ==0) then drug_side_2_after else trim(drug_side_2_after)end) as drug_side_2,
(case when (LENGTH(trim( billing_ndc_after )) ==0) then billing_ndc_after else trim(billing_ndc_after)end) as billing_ndc,
(case when (LENGTH(trim( drug_comment_cd_after )) ==0) then drug_comment_cd_after else trim(drug_comment_cd_after)end) as drug_comment_cd,
(case when (LENGTH(trim( default_smart_sig_after )) ==0) then default_smart_sig_after else trim(default_smart_sig_after)end) as default_smart_sig,
(case when (LENGTH(trim( drug_location_cd_after )) ==0) then drug_location_cd_after else trim(drug_location_cd_after)end) as drug_location_cd,
(case when (LENGTH(trim( drug_multihit_disp_ind_after )) ==0) then drug_multihit_disp_ind_after else trim(drug_multihit_disp_ind_after)end) as drug_multihit_disp_ind,
(case when (LENGTH(trim( substitution_drug_id_after )) ==0) then substitution_drug_id_after else trim(substitution_drug_id_after)end) as substitution_drug_id,
(case when (LENGTH(trim( drug_volume_after )) ==0) then drug_volume_after else trim(drug_volume_after)end) as drug_volume,
(case when (LENGTH(trim( precount_ind_after )) ==0) then precount_ind_after else trim(precount_ind_after)end) as precount_ind,
(case when (LENGTH(trim( precount_qty_1_after )) ==0) then precount_qty_1_after else trim(precount_qty_1_after)end) as precount_qty_1,
(case when (LENGTH(trim( precount_qty_2_after )) ==0) then precount_qty_2_after else trim(precount_qty_2_after)end) as precount_qty_2,
(case when (LENGTH(trim( dur_kdc_nbr_after )) ==0) then dur_kdc_nbr_after else trim(dur_kdc_nbr_after)end) as dur_kdc_nbr,
(case when (LENGTH(trim( ud_uu_pkg_cd_after )) ==0) then ud_uu_pkg_cd_after else trim(ud_uu_pkg_cd_after)end) as ud_uu_pkg_cd,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( lbl_cmt_cd_after )) ==0) then lbl_cmt_cd_after else trim(lbl_cmt_cd_after)end) as lbl_cmt_cd,
(case when (LENGTH(trim( substitution_prod_type_after )) ==0) then substitution_prod_type_after else trim(substitution_prod_type_after)end) as substitution_prod_type,
(case when (LENGTH(trim( recon_water_qty_after )) ==0) then recon_water_qty_after else trim(recon_water_qty_after)end) as recon_water_qty,
(case when (LENGTH(trim( drug_spec_cmt_cd_after )) ==0) then drug_spec_cmt_cd_after else trim(drug_spec_cmt_cd_after)end) as drug_spec_cmt_cd,
(case when (LENGTH(trim( fax_pbr_cmt_cd_after )) ==0) then fax_pbr_cmt_cd_after else trim(fax_pbr_cmt_cd_after)end) as fax_pbr_cmt_cd,
(case when (LENGTH(trim( promise_sub_drug_id_after )) ==0) then promise_sub_drug_id_after else trim(promise_sub_drug_id_after)end) as promise_sub_drug_id,
(case when (LENGTH(trim( specialty_drug_ind_after )) ==0) then specialty_drug_ind_after else trim(specialty_drug_ind_after)end) as specialty_drug_ind,
(case when (LENGTH(trim( cash_disc_qty_after )) ==0) then cash_disc_qty_after else trim(cash_disc_qty_after)end) as cash_disc_qty,
(case when (LENGTH(trim( piece_weight_after )) ==0) then piece_weight_after else trim(piece_weight_after)end) as piece_weight,
(case when (LENGTH(trim( stock_bottle_barcode_after )) ==0) then stock_bottle_barcode_after else trim(stock_bottle_barcode_after)end) as stock_bottle_barcode,
(case when (LENGTH(trim( doses_per_pkg_after )) ==0) then doses_per_pkg_after else trim(doses_per_pkg_after)end) as doses_per_pkg,
(case when (LENGTH(trim( pct_tot_disc_card_after )) ==0) then pct_tot_disc_card_after else trim(pct_tot_disc_card_after)end) as pct_tot_disc_card,
(case when (LENGTH(trim( pet_med_ind_after )) ==0) then pet_med_ind_after else trim(pet_med_ind_after)end) as pet_med_ind,
(case when (LENGTH(trim( ltd_dist_cd_after )) ==0) then ltd_dist_cd_after else trim(ltd_dist_cd_after)end) as ltd_dist_cd,
(case when (LENGTH(trim( complicated_supplies_ind_after )) ==0) then complicated_supplies_ind_after else trim(complicated_supplies_ind_after)end) as complicated_supplies_ind,
(case when (LENGTH(trim( specialty_review_ind_after )) ==0) then specialty_review_ind_after else trim(specialty_review_ind_after)end) as specialty_review_ind,
(case when (LENGTH(trim( clinical_value_ind_after )) ==0) then clinical_value_ind_after else trim(clinical_value_ind_after)end) as clinical_value_ind,
(case when (LENGTH(trim( required_supplies_ind_after )) ==0) then required_supplies_ind_after else trim(required_supplies_ind_after)end) as required_supplies_ind,
(case when (LENGTH(trim( hcp_drug_mltht_disp_ind_after )) ==0) then hcp_drug_mltht_disp_ind_after else trim(hcp_drug_mltht_disp_ind_after)end) as hcp_drug_mltht_disp_ind,
(case when (LENGTH(trim( mix_ind_after )) ==0) then mix_ind_after else trim(mix_ind_after)end) as mix_ind,
(case when (LENGTH(trim( drug_image_file_name_after )) ==0) then drug_image_file_name_after else trim(drug_image_file_name_after)end) as drug_image_file_name,
(case when (LENGTH(trim( top_drug_ind_after )) ==0) then top_drug_ind_after else trim(top_drug_ind_after)end) as top_drug_ind,
(case when (LENGTH(trim( quality_alert_message_after )) ==0) then quality_alert_message_after else trim(quality_alert_message_after)end) as quality_alert_message,
(case when (LENGTH(trim( quality_alert_keywords_after )) ==0) then quality_alert_keywords_after else trim(quality_alert_keywords_after)end) as quality_alert_keywords,
(case when (LENGTH(trim( quality_alert_rule_ind_after )) ==0) then quality_alert_rule_ind_after else trim(quality_alert_rule_ind_after)end) as quality_alert_rule_ind,
(case when (LENGTH(trim( quality_alert_screen_ind_after )) ==0) then quality_alert_screen_ind_after else trim(quality_alert_screen_ind_after)end) as quality_alert_screen_ind,
(case when (LENGTH(trim( cash_disc_qty2_after )) ==0) then cash_disc_qty2_after else trim(cash_disc_qty2_after)end) as cash_disc_qty2,
(case when (LENGTH(trim( cash_disc_qty3_after )) ==0) then cash_disc_qty3_after else trim(cash_disc_qty3_after)end) as cash_disc_qty3,
(case when (LENGTH(trim( tip_ind_after )) ==0) then tip_ind_after else trim(tip_ind_after)end) as tip_ind,
(case when (LENGTH(trim( ref_drug_id_after )) ==0) then ref_drug_id_after else trim(ref_drug_id_after)end) as ref_drug_id,
(case when (LENGTH(trim( hcpc_after )) ==0) then hcpc_after else trim(hcpc_after)end) as hcpc,
(case when (LENGTH(trim( pref_mfr_ind_after )) ==0) then pref_mfr_ind_after else trim(pref_mfr_ind_after)end) as pref_mfr_ind,
(case when (LENGTH(trim( med_guide_filename_after )) ==0) then med_guide_filename_after else trim(med_guide_filename_after)end) as med_guide_filename,
(case when (LENGTH(trim( med_guide_ind_after )) ==0) then med_guide_ind_after else trim(med_guide_ind_after)end) as med_guide_ind,
(case when (LENGTH(trim( item_class_after )) ==0) then item_class_after else trim(item_class_after)end) as item_class,
(case when (LENGTH(trim( item_group_after )) ==0) then item_group_after else trim(item_group_after)end) as item_group,
(case when (LENGTH(trim( item_formulary_ind_after )) ==0) then item_formulary_ind_after else trim(item_formulary_ind_after)end) as item_formulary_ind,
(case when (LENGTH(trim( item_category_after )) ==0) then item_category_after else trim(item_category_after)end) as item_category,
(case when (LENGTH(trim( item_lob_after )) ==0) then item_lob_after else trim(item_lob_after)end) as item_lob,
(case when (LENGTH(trim( item_conv_factor_after )) ==0) then item_conv_factor_after else trim(item_conv_factor_after)end) as item_conv_factor,
(case when (LENGTH(trim( item_list_price_sale_after )) ==0) then item_list_price_sale_after else trim(item_list_price_sale_after)end) as item_list_price_sale,
(case when (LENGTH(trim( item_retail_price_after )) ==0) then item_retail_price_after else trim(item_retail_price_after)end) as item_retail_price,
(case when (LENGTH(trim( item_pum_after )) ==0) then item_pum_after else trim(item_pum_after)end) as item_pum,
(case when (LENGTH(trim( item_sub_group_after )) ==0) then item_sub_group_after else trim(item_sub_group_after)end) as item_sub_group,
(case when (LENGTH(trim( item_sub_category_after )) ==0) then item_sub_category_after else trim(item_sub_category_after)end) as item_sub_category,
(case when (LENGTH(trim( item_sum_after )) ==0) then item_sum_after else trim(item_sum_after)end) as item_sum,
(case when (LENGTH(trim( primary_vendor_item_cost_after )) ==0) then primary_vendor_item_cost_after else trim(primary_vendor_item_cost_after)end) as primary_vendor_item_cost,
(case when (LENGTH(trim( primary_vendor_item_nbr_after )) ==0) then primary_vendor_item_nbr_after else trim(primary_vendor_item_nbr_after)end) as primary_vendor_item_nbr,
(case when (LENGTH(trim( secndry_vendor_item_cost_after )) ==0) then secndry_vendor_item_cost_after else trim(secndry_vendor_item_cost_after)end) as secndry_vendor_item_cost,
(case when (LENGTH(trim( secndry_vendor_item_nbr_after )) ==0) then secndry_vendor_item_nbr_after else trim(secndry_vendor_item_nbr_after)end) as secndry_vendor_item_nbr,
(case when (LENGTH(trim( tertry_vendor_item_cost_after )) ==0) then tertry_vendor_item_cost_after else trim(tertry_vendor_item_cost_after)end) as tertry_vendor_item_cost,
(case when (LENGTH(trim( tertry_vendor_item_nbr_after )) ==0) then tertry_vendor_item_nbr_after else trim(tertry_vendor_item_nbr_after)end) as tertry_vendor_item_nbr,
(case when (LENGTH(trim( specific_gravity_after )) ==0) then specific_gravity_after else trim(specific_gravity_after)end) as specific_gravity,
(case when (LENGTH(trim( concentration_nbr_after )) ==0) then concentration_nbr_after else trim(concentration_nbr_after)end) as concentration_nbr,
(case when (LENGTH(trim( concentration_units_after )) ==0) then concentration_units_after else trim(concentration_units_after)end) as concentration_units,
(case when (LENGTH(trim( lipids_ind_after )) ==0) then lipids_ind_after else trim(lipids_ind_after)end) as lipids_ind,
(case when (LENGTH(trim( amino_acid_ind_after )) ==0) then amino_acid_ind_after else trim(amino_acid_ind_after)end) as amino_acid_ind,
(case when (LENGTH(trim( poolable_ind_after )) ==0) then poolable_ind_after else trim(poolable_ind_after)end) as poolable_ind,
(case when (LENGTH(trim( trace_element_ind_after )) ==0) then trace_element_ind_after else trim(trace_element_ind_after)end) as trace_element_ind,
(case when (LENGTH(trim( electrolyte_ind_after )) ==0) then electrolyte_ind_after else trim(electrolyte_ind_after)end) as electrolyte_ind,
(case when (LENGTH(trim( container_material_cd_after )) ==0) then container_material_cd_after else trim(container_material_cd_after)end) as container_material_cd,
(case when (LENGTH(trim( container_max_capacity_after )) ==0) then container_max_capacity_after else trim(container_max_capacity_after)end) as container_max_capacity,
(case when (LENGTH(trim( vehicle_ind_after )) ==0) then vehicle_ind_after else trim(vehicle_ind_after)end) as vehicle_ind,
(case when (LENGTH(trim( vehicle_after )) ==0) then vehicle_after else trim(vehicle_after)end) as vehicle,
(case when (LENGTH(trim( cocktail_ind_after )) ==0) then cocktail_ind_after else trim(cocktail_ind_after)end) as cocktail_ind,
(case when (LENGTH(trim( primary_vendor_nbr_after )) ==0) then primary_vendor_nbr_after else trim(primary_vendor_nbr_after)end) as primary_vendor_nbr,
(case when (LENGTH(trim( secondary_vendor_nbr_after )) ==0) then secondary_vendor_nbr_after else trim(secondary_vendor_nbr_after)end) as secondary_vendor_nbr,
(case when (LENGTH(trim( tertiary_vendor_nbr_after )) ==0) then tertiary_vendor_nbr_after else trim(tertiary_vendor_nbr_after)end) as tertiary_vendor_nbr,
(case when (LENGTH(trim( base_ind_after )) ==0) then base_ind_after else trim(base_ind_after)end) as base_ind,
(case when (LENGTH(trim( item_type_after )) ==0) then item_type_after else trim(item_type_after)end) as item_type,
(case when (LENGTH(trim( conc_dextrose_ind_after )) ==0) then conc_dextrose_ind_after else trim(conc_dextrose_ind_after)end) as conc_dextrose_ind,
(case when (LENGTH(trim( container_ind_after )) ==0) then container_ind_after else trim(container_ind_after)end) as container_ind,
(case when (LENGTH(trim( container_type_after )) ==0) then container_type_after else trim(container_type_after)end) as container_type,
(case when (LENGTH(trim( primary_vendor_name_after )) ==0) then primary_vendor_name_after else trim(primary_vendor_name_after)end) as primary_vendor_name,
(case when (LENGTH(trim( secondary_vendor_name_after )) ==0) then secondary_vendor_name_after else trim(secondary_vendor_name_after)end) as secondary_vendor_name,
(case when (LENGTH(trim( tertiary_vendor_name_after )) ==0) then tertiary_vendor_name_after else trim(tertiary_vendor_name_after)end) as tertiary_vendor_name,
(case when (LENGTH(trim( plx_drug_ind_after )) ==0) then plx_drug_ind_after else trim(plx_drug_ind_after)end) as plx_drug_ind,
(case when (LENGTH(trim( item_size_after )) ==0) then item_size_after else trim(item_size_after)end) as item_size,
(case when (LENGTH(trim( item_size_units_after )) ==0) then item_size_units_after else trim(item_size_units_after)end) as item_size_units,
(case when (LENGTH(trim( item_long_desc_after )) ==0) then item_long_desc_after else trim(item_long_desc_after)end) as item_long_desc,
(case when (LENGTH(trim( item_short_desc_after )) ==0) then item_short_desc_after else trim(item_short_desc_after)end) as item_short_desc,
(case when (LENGTH(trim( item_awp_after )) ==0) then item_awp_after else trim(item_awp_after)end) as item_awp,
(case when (LENGTH(trim( billing_multiplier_after )) ==0) then billing_multiplier_after else trim(billing_multiplier_after)end) as billing_multiplier,
(case when (LENGTH(trim( track_inventory_ind_after )) ==0) then track_inventory_ind_after else trim(track_inventory_ind_after)end) as track_inventory_ind,
(case when (LENGTH(trim( disease_state_ind_after )) ==0) then disease_state_ind_after else trim(disease_state_ind_after)end) as disease_state_ind,
(case when (LENGTH(trim( drug_inference_cd_after )) ==0) then drug_inference_cd_after else trim(drug_inference_cd_after)end) as drug_min_price,
(case when (LENGTH(trim( drug_min_price_after )) ==0) then drug_min_price_after else trim(drug_min_price_after)end) as drug_inference_cd,
(case when (LENGTH(trim( excl_drug_automation_ind_after )) ==0) then excl_drug_automation_ind_after else trim(excl_drug_automation_ind_after)end) as excl_drug_automation_ind,
(case when (LENGTH(trim( excl_tbltp_count_ind_after )) ==0) then excl_tbltp_count_ind_after else trim(excl_tbltp_count_ind_after)end) as excl_tbltp_count_ind,
(case when (LENGTH(trim( require_tbltp_clean_after )) ==0) then require_tbltp_clean_after else trim(require_tbltp_clean_after)end) as require_tbltp_clean,
(case when (LENGTH(trim( thera_class_extd )) ==0) then thera_class_extd else trim(thera_class_extd)end) as thera_class_extd,
(case when (LENGTH(trim( hzrds_lvl_cd_after )) ==0) then hzrds_lvl_cd_after else trim(hzrds_lvl_cd_after)end) as hzrds_lvl_cd,
(case when (LENGTH(trim( auth_generic_cd_after )) ==0) then auth_generic_cd_after else trim(auth_generic_cd_after)end) as auth_generic_cd,
(case when (LENGTH(trim( fda_ind_after )) ==0) then fda_ind_after else trim(fda_ind_after)end) as fda_ind,
(case when (LENGTH(trim( fda_ind_value_after )) ==0) then fda_ind_value_after else trim(fda_ind_value_after)end)  as fda_ind_value,
(case when (LENGTH(trim( auth_ndc_upc_hri_after )) ==0) then auth_ndc_upc_hri_after else trim(auth_ndc_upc_hri_after)end) as auth_ndc_upc_hri,
(case when (LENGTH(trim( auth_gen_override_ind_after )) ==0) then auth_gen_override_ind_after else trim(auth_gen_override_ind_after)end) as auth_gen_override_ind,
(case when (LENGTH(trim( ddid_after )) ==0) then ddid_after else trim(ddid_after)end) as ddid,
(case when (LENGTH(trim( rxcui_type_after )) ==0) then rxcui_type_after else trim(rxcui_type_after)end) as rxcui_type,
(case when (LENGTH(trim( rxcui_after )) ==0) then rxcui_after else trim(rxcui_after)end) as rxcui,
(case when (LENGTH(trim( elsevier_pack_id_after )) ==0) then elsevier_pack_id_after else trim(elsevier_pack_id_after)end) as elsevier_pack_id,
(case when (LENGTH(trim( elsevier_prod_id_after )) ==0) then elsevier_prod_id_after else trim(elsevier_prod_id_after )end) as elsevier_prod_id,
(case when (LENGTH(trim( med_dosage_unit_after )) ==0) then med_dosage_unit_after else trim(med_dosage_unit_after)end) as med_dosage_unit,
(case when (LENGTH(trim( med_conv_factor_after )) ==0) then med_conv_factor_after else trim(med_conv_factor_after)end) as med_conv_factor,
(case when (LENGTH(trim( mme_calc_factor_after )) ==0) then mme_calc_factor_after else trim(mme_calc_factor_after)end) as mme_calc_factor,
'000000' as tracking_id
from gg_tbf0_drug where cdc_operation_type_cd_before ='INSERT'"""

# COMMAND ----------

df1 = spark.sql(sql1)

display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)

dfFinal.createOrReplaceTempView("gg_tbf0_drug_final")

# drop columns
df_final = dfFinal.drop("tracking_id")
# convert date and number columns
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
           .withColumn("a_last_change_dttm",to_timestamp(df_final["a_last_change_dttm"]))\
           .withColumn("e_last_change_dttm",to_timestamp(df_final["e_last_change_dttm"]))\
           .withColumn("g_last_change_dttm",to_timestamp(df_final["g_last_change_dttm"]))\
           .withColumn("j_last_change_dttm",to_timestamp(df_final["j_last_change_dttm"]))\
           .withColumn("rx_to_otc_dttm",to_timestamp(df_final["rx_to_otc_dttm"]))\
           .withColumn("l_last_change_dttm",to_timestamp(df_final["l_last_change_dttm"]))\
           .withColumn("awp_dttm",to_timestamp(df_final["awp_dttm"]))\
           .withColumn("r_last_change_dttm",to_timestamp(df_final["r_last_change_dttm"]))\
           .withColumn("hcfa_dttm",to_timestamp(df_final["hcfa_dttm"]))\
           .withColumn("t_last_change_dttm",to_timestamp(df_final["t_last_change_dttm"]))\
           .withColumn("drug_disc_dttm",to_timestamp(df_final["drug_disc_dttm"]))\
           .withColumn("create_dttm",to_timestamp(df_final["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(df_final["update_dttm"]))

#df_final = df_final.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))
df_final = df_final.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in df_final.columns])

#final df to load
display(df_final)
print(f"Final count after union {df_final.count()}")





# COMMAND ----------

#Bad records 
dfBad = spark.sql("select * from gg_tbf0_drug where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")
display(dfBad)
print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

# WRITING DATA IN OUTPUT AND RJECT FOLDER
df_final.write.mode('overwrite').parquet(OUT_FILEPATH)

dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)



# COMMAND ----------

# delete records from snfk table
delete_gg_snowflake = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})



# COMMAND ----------

#Writing to the Snowflakes Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
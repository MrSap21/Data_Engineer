# Databricks notebook source
import pyspark.sql.functions
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType

# COMMAND ----------


dbutils.widgets.text("adls_input_container_name","",label="adls_input_container_name")
dbutils.widgets.text("adls_input_folder_path","",label="adls_input_folder_path")
dbutils.widgets.text("adls_input_file_prefix","",label="adls_input_file_prefix")
dbutils.widgets.text("adls_input_file_suffix","",label="adls_input_file_suffix")
dbutils.widgets.text("adls_output_container_name","",label="adls_output_container_name")
dbutils.widgets.text("adls_output_folder_path","",label="adls_output_folder_path")
dbutils.widgets.text("adls_output_file_list2","",label="adls_output_file_list2")
dbutils.widgets.text("adls_output_file_list3","",label="adls_output_file_list3")



adlsInputContainerName=dbutils.widgets.get("adls_input_container_name")
adlsInputFolderPath=dbutils.widgets.get("adls_input_folder_path")
adlsInputFilePrefix=dbutils.widgets.get("adls_input_file_prefix")
adlsInputFileSuffix=dbutils.widgets.get("adls_input_file_suffix")
adlsOutputContainerName=dbutils.widgets.get("adls_output_container_name")
adlsOutputFolderPath=dbutils.widgets.get("adls_output_folder_path")
adlsOutputFileList2=dbutils.widgets.get("adls_output_file_list2")
adlsOutputFileList3=dbutils.widgets.get("adls_output_file_list3")

# COMMAND ----------

def get_dir_content(ls_path):
  dir_paths = dbutils.fs.ls(ls_path)
  subdir_paths = [get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != ls_path]
  flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
  return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('/')+".dat")
  dbutils.fs.rm(ls_path, recurse = True)
  


# COMMAND ----------

filelist = []
filepart = []
filepartlist = []

paths = get_dir_content('dbfs:/mnt/'+adlsInputContainerName+'/'+adlsInputFolderPath+'/')
for p in paths:
  if p.lower().split("/")[-1].startswith(adlsInputFilePrefix.lower()) and p.split("/")[-1].endswith(adlsInputFileSuffix.lower()):
    filename = p.split("/")[-1]
    filelist.append(filename)
    filepart.append(filename.split("_")[4][0:8])

for i in filepart:
  filepartlist.append((filepart.count(i),i))  

# COMMAND ----------

print(filepartlist)

# COMMAND ----------

if filelist:
  df = spark.createDataFrame(filelist,StringType())
  df1 = spark.createDataFrame(filepartlist)

  ouputLocation1 = "mnt/" + adlsOutputContainerName + "/" + adlsOutputFolderPath + "/" + adlsOutputFileList2
  ouputLocation2 = "mnt/" + adlsOutputContainerName + "/" + adlsOutputFolderPath + "/" + adlsOutputFileList3

  df.coalesce(1).write.options(header='false',delimiter=',').format("csv").mode("overwrite").save(ouputLocation1)
  removePartFiles(ouputLocation1)

  df1.distinct().coalesce(1).write.options(header='false',delimiter=' ').format("csv").mode("overwrite").save(ouputLocation2)
  removePartFiles(ouputLocation2)

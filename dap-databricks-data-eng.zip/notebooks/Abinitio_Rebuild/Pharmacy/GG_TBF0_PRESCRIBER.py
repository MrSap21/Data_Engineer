# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_FEED_NAMES","GG_PRESCRIBER,GG_TBF0_PRESCRIBER_control")

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
Input_File_List= dbutils.widgets.get("PAR_DB_FILE_LIST")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAMES")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'


print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdCntrlArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdCntrlArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

##Convert json asset location/filname to Multi FIle Name List

#inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_File_FEEDNAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{GG_File_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_File_FEEDNAME}.assetid",
                                                   f"{GG_File_FEEDNAME}.assetname")
#display(dfFileList)
#print(gg_file_list)
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdFinalArray = dfAssetIdCntrlArray+dfAssetIdArray
#dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
#dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdFinalArray)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pbr_id',
'pbr_id_after',
'pbr_loc_id',
'pbr_loc_id_after',
'pbr_status_cd',
'pbr_status_cd_after',
'pbr_dea_nbr',
'pbr_dea_nbr_after',
'pbr_dea_suf',
'pbr_dea_suf_after',
'pbr_spin_nbr',
'pbr_spin_nbr_after',
'pbr_last_name',
'pbr_last_name_after',
'pbr_first_name',
'pbr_first_name_after',
'pbr_mid_init',
'pbr_mid_init_after',
'pbr_surname_suffix',
'pbr_surname_suffix_after',
'pbr_name_soundex',
'pbr_name_soundex_after',
'pbr_phone_area_cd',
'pbr_phone_area_cd_after',
'pbr_phone',
'pbr_phone_after',
'pbr_fax_area_cd',
'pbr_fax_area_cd_after',
'pbr_fax',
'pbr_fax_after',
'pbr_addr',
'pbr_addr_after',
'pbr_city',
'pbr_city_after',
'pbr_state',
'pbr_state_after',
'pbr_zip',
'pbr_zip_after',
'pbr_type_cd',
'pbr_type_cd_after',
'pbr_specialty_cd',
'pbr_speciality_cd_after',
'pbr_tax_id',
'pbr_tax_id_after',
'pbr_cmts',
'pbr_cmts_after',
'pbr_last_active_dttm',
'pbr_last_active_dttm_after',
'pbr_hlthcare_reform_nbr',
'pbr_hlthcare_reform_nbr_after',
'quarter1_ind',
'quarter1_ind_after',
'quarter2_ind',
'quarter2_ind_after',
'quarter3_ind',
'quarter3_ind_after',
'quarter4_ind',
'quarter4_ind_after',
'pbr_prescribe_ind',
'pbr_prescriber_ind_after',
'pbr_hub_nbr',
'pbr_hub_nbr_after',
'pbr_clinic_site',
'pbr_clinic_site_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'pbr_clinic_id',
'pbr_clinic_id_after',
'pbr_company_cd',
'pbr_company_cd_after',
'pbr_phone_cmts',
'pbr_phone_cmts_after',
'pbr_change_req_ind',
'pbr_change_req_ind_after',
'pbr_source_ind',
'pbr_source_ind_after',
'ndc_pbr_id',
'ndc_pbr_id_after',
'pbr_provider_status',
'pbr_provider_status_after',
'pbr_prof_status',
'pbr_prof_status_after',
'pbr_sex_cd',
'pbr_sex_cd_after',
'pbr_birth_dttm',
'pbr_birth_dttm_after',
'pbr_middle_name',
'pbr_middle_name_after',
'pbr_addr2',
'pbr_addr2_after',
'pbr_dea_expire_dttm',
'pbr_dea_expire_dttm_after',
'pbr_upin',
'pbr_upin_after',
'pbr_license_state',
'pbr_license_state_after',
'pbr_state_license_nbr',
'pbr_state_license_nbr_after',
'ndc_pbr_loc_id',
'ndc_pbr_loc_id_after',
'pbr_app_cd',
'pbr_app_cd_after',
'pbr_npi',
'pbr_npi_after',
'ow_update_dttm',
'ow_update_dttm_after',
'pbr_group_id',
'pbr_group_id_after',
'pbr_loc_group_id',
'pbr_loc_group_id_after',
'repl_by_pbr_id',
'repl_by_pbr_id_after',
'repl_by_pbr_loc_id',
'repl_by_pbr_loc_id_after',
'pbr_loc_name',
'pbr_loc_name_after',
'pbr_pecos_ind',
'pbr_pecos_ind_after',
'pbr_death_dttm',
'pbr_death_dttm_after',
'pbr_state_ctrl_nbr',
'pbr_state_ctrl_nbr_after',
'pbr_refill_area_cd',
'pbr_refill_area_cd_after',
'pbr_refill_phone',
'pbr_refill_phone_after',
'pbr_foreign_license',
'pbr_foreign_license_after',
'pbr_store_npi_ind',
'pbr_store_npi_ind_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 149 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 150:
      return True
  else:
    if val_len != 150:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 150

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 64
print(f"Bad records count {rd_bad.count()}") # != 64


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df.columns,
#     df
# ))

# COMMAND ----------

#display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_prescriber")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( pbr_id )) ==0) then pbr_id else trim(pbr_id)end) as pbr_id,
(case when (LENGTH(trim( pbr_loc_id )) ==0) then pbr_loc_id else trim(pbr_loc_id)end) as pbr_loc_id,
(case when (LENGTH(trim( pbr_status_cd )) ==0) then pbr_status_cd else trim(pbr_status_cd)end) as pbr_status_cd,
(case when (LENGTH(trim( pbr_dea_nbr )) ==0) then pbr_dea_nbr else trim(pbr_dea_nbr)end) as pbr_dea_nbr,
(case when (LENGTH(trim( pbr_dea_suf )) ==0) then pbr_dea_suf else trim(pbr_dea_suf)end) as pbr_dea_suf,
(case when (LENGTH(trim( pbr_spin_nbr )) ==0) then pbr_spin_nbr else trim(pbr_spin_nbr)end) as pbr_spin_nbr,
(case when (LENGTH(trim( pbr_last_name )) ==0) then pbr_last_name else trim(pbr_last_name)end) as pbr_last_name,
(case when (LENGTH(trim( pbr_first_name )) ==0) then pbr_first_name else trim(pbr_first_name)end) as pbr_first_name,
(case when (LENGTH(trim( pbr_mid_init )) ==0) then pbr_mid_init else trim(pbr_mid_init)end) as pbr_mid_init,
(case when (LENGTH(trim( pbr_surname_suffix )) ==0) then pbr_surname_suffix else trim(pbr_surname_suffix)end) as pbr_surname_suffix,
(case when (LENGTH(trim( pbr_name_soundex )) ==0) then pbr_name_soundex else trim(pbr_name_soundex)end) as pbr_name_soundex,
(case when (LENGTH(trim( pbr_phone_area_cd )) ==0) then pbr_phone_area_cd else trim(pbr_phone_area_cd)end) as pbr_phone_area_cd,
(case when (LENGTH(trim( pbr_phone )) ==0) then pbr_phone else trim(pbr_phone)end) as pbr_phone,
(case when (LENGTH(trim( pbr_fax_area_cd )) ==0) then pbr_fax_area_cd else trim(pbr_fax_area_cd)end) as pbr_fax_area_cd,
(case when (LENGTH(trim( pbr_fax )) ==0) then pbr_fax else trim(pbr_fax)end) as pbr_fax,
(case when (LENGTH(trim( pbr_addr )) ==0) then pbr_addr else trim(pbr_addr)end) as pbr_addr,
(case when (LENGTH(trim( pbr_city )) ==0) then pbr_city else trim(pbr_city)end) as pbr_city,
(case when (LENGTH(trim( pbr_state )) ==0) then pbr_state else trim(pbr_state)end) as pbr_state,
(case when (LENGTH(trim( pbr_zip )) ==0) then pbr_zip else trim(pbr_zip)end) as pbr_zip,
(case when (LENGTH(trim( pbr_type_cd )) ==0) then pbr_type_cd else trim(pbr_type_cd)end) as pbr_type_cd,
(case when (LENGTH(trim( pbr_specialty_cd )) ==0) then pbr_specialty_cd else trim(pbr_specialty_cd)end) as pbr_specialty_cd,
(case when (LENGTH(trim( pbr_tax_id )) ==0) then pbr_tax_id else trim(pbr_tax_id)end) as pbr_tax_id,
(case when (LENGTH(trim( pbr_cmts )) ==0) then pbr_cmts else trim(pbr_cmts)end) as pbr_cmts,
(case when (LENGTH(trim( pbr_last_active_dttm )) ==0) then pbr_last_active_dttm else concat(substring(pbr_last_active_dttm,1,10),' ',substring(pbr_last_active_dttm,12,8),'.000000')end) as pbr_last_active_dttm,
(case when (LENGTH(trim( pbr_hlthcare_reform_nbr )) ==0) then pbr_hlthcare_reform_nbr else trim(pbr_hlthcare_reform_nbr)end) as pbr_hlthcare_reform_nbr,
(case when (LENGTH(trim( quarter1_ind )) ==0) then quarter1_ind else trim(quarter1_ind)end) as quarter1_ind,
(case when (LENGTH(trim( quarter2_ind )) ==0) then quarter2_ind else trim(quarter2_ind)end) as quarter2_ind,
(case when (LENGTH(trim( quarter3_ind )) ==0) then quarter3_ind else trim(quarter3_ind)end) as quarter3_ind,
(case when (LENGTH(trim( quarter4_ind )) ==0) then quarter4_ind else trim(quarter4_ind)end) as quarter4_ind,
(case when (LENGTH(trim( pbr_prescribe_ind )) ==0) then pbr_prescribe_ind else trim(pbr_prescribe_ind)end) as pbr_prescribe_ind,
(case when (LENGTH(trim( pbr_hub_nbr )) ==0) then pbr_hub_nbr else trim(pbr_hub_nbr)end) as pbr_hub_nbr,
(case when (LENGTH(trim( pbr_clinic_site )) ==0) then pbr_clinic_site else trim(pbr_clinic_site)end) as pbr_clinic_site,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_dttm )) ==0) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim( update_dttm )) ==0) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( pbr_clinic_id )) ==0) then pbr_clinic_id else trim(pbr_clinic_id)end) as pbr_clinic_id,
(case when (LENGTH(trim( pbr_company_cd )) ==0) then pbr_company_cd else trim(pbr_company_cd)end) as pbr_company_cd,
(case when (LENGTH(trim( pbr_phone_cmts )) ==0) then pbr_phone_cmts else trim(pbr_phone_cmts)end) as pbr_phone_cmts,
(case when (LENGTH(trim( pbr_change_req_ind )) ==0) then pbr_change_req_ind else trim(pbr_change_req_ind)end) as pbr_change_req_ind,
(case when (LENGTH(trim( pbr_source_ind )) ==0) then pbr_source_ind else trim(pbr_source_ind)end) as pbr_source_ind,
(case when (LENGTH(trim( ndc_pbr_id )) ==0) then ndc_pbr_id else trim(ndc_pbr_id)end) as ndc_pbr_id,
(case when (LENGTH(trim( pbr_provider_status )) ==0) then pbr_provider_status else trim(pbr_provider_status)end) as pbr_provider_status,
(case when (LENGTH(trim( pbr_prof_status )) ==0) then pbr_prof_status else trim(pbr_prof_status)end) as pbr_prof_status,
(case when (LENGTH(trim( pbr_sex_cd )) ==0) then pbr_sex_cd else trim(pbr_sex_cd)end) as pbr_sex_cd,
(case when (LENGTH(trim( pbr_birth_dttm )) ==0) then pbr_birth_dttm else concat(substring(pbr_birth_dttm,1,10),' ',substring(pbr_birth_dttm,12,8),'.000000')end) as pbr_birth_dttm,
(case when (LENGTH(trim( pbr_middle_name )) ==0) then pbr_middle_name else trim(pbr_middle_name)end) as pbr_middle_name,
(case when (LENGTH(trim( pbr_addr2 )) ==0) then pbr_addr2 else trim(pbr_addr2)end) as pbr_addr2,
(case when (LENGTH(trim( pbr_dea_expire_dttm )) ==0) then pbr_dea_expire_dttm else concat(substring(pbr_dea_expire_dttm,1,10),' ',substring(pbr_dea_expire_dttm,12,8),'.000000')end) as pbr_dea_expire_dttm,
(case when (LENGTH(trim( pbr_upin )) ==0) then pbr_upin else trim(pbr_upin)end) as pbr_upin,
(case when (LENGTH(trim( pbr_license_state )) ==0) then pbr_license_state else trim(pbr_license_state)end) as pbr_license_state,
(case when (LENGTH(trim( pbr_state_license_nbr )) ==0) then pbr_state_license_nbr else trim(pbr_state_license_nbr)end) as pbr_state_license_nbr,
(case when (LENGTH(trim( ndc_pbr_loc_id )) ==0) then ndc_pbr_loc_id else trim(ndc_pbr_loc_id)end) as ndc_pbr_loc_id,
(case when (LENGTH(trim( pbr_app_cd )) ==0) then pbr_app_cd else trim(pbr_app_cd)end) as pbr_app_cd,
(case when (LENGTH(trim( pbr_npi )) ==0) then pbr_npi else trim(pbr_npi)end) as pbr_npi,
(case when (LENGTH(trim( ow_update_dttm )) ==0) then ow_update_dttm else concat(substring(ow_update_dttm,1,10),' ',substring(ow_update_dttm,12,8),'.000000')end) as ow_update_dttm,
(case when (LENGTH(trim( pbr_group_id )) ==0) then pbr_group_id else trim(pbr_group_id)end) as pbr_group_id,
(case when (LENGTH(trim( pbr_loc_group_id )) ==0) then pbr_loc_group_id else trim(pbr_loc_group_id)end) as pbr_loc_group_id,
(case when (LENGTH(trim( repl_by_pbr_id )) ==0) then repl_by_pbr_id else trim(repl_by_pbr_id)end) as repl_by_pbr_id,
(case when (LENGTH(trim( repl_by_pbr_loc_id )) ==0) then repl_by_pbr_loc_id else trim(repl_by_pbr_loc_id)end) as repl_by_pbr_loc_id,
(case when (LENGTH(trim( pbr_loc_name )) ==0) then pbr_loc_name else trim(pbr_loc_name)end) as pbr_loc_name,
(case when (LENGTH(trim( pbr_pecos_ind )) ==0) then pbr_pecos_ind else trim(pbr_pecos_ind)end) as pbr_pecos_ind,
(case when (LENGTH(trim( pbr_death_dttm )) ==0) then pbr_death_dttm else concat(substring(pbr_death_dttm,1,10),' ',substring(pbr_death_dttm,12,8),'.000000')end) as pbr_death_dttm,
(case when (LENGTH(trim( pbr_state_ctrl_nbr )) ==0) then pbr_state_ctrl_nbr else trim(pbr_state_ctrl_nbr)end) as pbr_state_ctrl_nbr,
(case when (LENGTH(trim( pbr_refill_area_cd )) ==0) then pbr_refill_area_cd else trim(pbr_refill_area_cd)end) as pbr_refill_area_cd,
(case when (LENGTH(trim( pbr_refill_phone )) ==0) then pbr_refill_phone else trim(pbr_refill_phone)end) as pbr_refill_phone,
(case when (LENGTH(trim( pbr_foreign_license )) ==0) then pbr_foreign_license else trim(pbr_foreign_license)end) as pbr_foreign_license,
(case when (LENGTH(trim( pbr_store_npi_ind )) ==0) then pbr_store_npi_ind else trim(pbr_store_npi_ind)end) as pbr_store_npi_ind,
'000000' as tracking_id     
from gg_tbf0_prescriber where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd ='PK UPDATE')"""

# COMMAND ----------

sql2 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd_after,
edw_batch_id_after,
(case when (LENGTH(trim( pbr_id_after )) ==0) then pbr_id_after else trim(pbr_id_after)end) as pbr_id_after,
(case when (LENGTH(trim( pbr_loc_id_after )) ==0) then pbr_loc_id_after else trim(pbr_loc_id_after)end) as pbr_loc_id_after,
(case when (LENGTH(trim( pbr_status_cd_after )) ==0) then pbr_status_cd_after else trim(pbr_status_cd_after)end) as pbr_status_cd_after,
(case when (LENGTH(trim( pbr_dea_nbr_after )) ==0) then pbr_dea_nbr_after else trim(pbr_dea_nbr_after)end) as pbr_dea_nbr_after,
(case when (LENGTH(trim( pbr_dea_suf_after )) ==0) then pbr_dea_suf_after else trim(pbr_dea_suf_after)end) as pbr_dea_suf_after,
(case when (LENGTH(trim( pbr_spin_nbr_after )) ==0) then pbr_spin_nbr_after else trim(pbr_spin_nbr_after)end) as pbr_spin_nbr_after,
(case when (LENGTH(trim( pbr_last_name_after )) ==0) then pbr_last_name_after else trim(pbr_last_name_after)end) as pbr_last_name_after,
(case when (LENGTH(trim( pbr_first_name_after )) ==0) then pbr_first_name_after else trim(pbr_first_name_after)end) as pbr_first_name_after,
(case when (LENGTH(trim( pbr_mid_init_after )) ==0) then pbr_mid_init_after else trim(pbr_mid_init_after)end) as pbr_mid_init_after,
(case when (LENGTH(trim( pbr_surname_suffix_after )) ==0) then pbr_surname_suffix_after else trim(pbr_surname_suffix_after)end) as pbr_surname_suffix_after,
(case when (LENGTH(trim( pbr_name_soundex_after )) ==0) then pbr_name_soundex_after else trim(pbr_name_soundex_after)end) as pbr_name_soundex_after,
(case when (LENGTH(trim( pbr_phone_area_cd_after )) ==0) then pbr_phone_area_cd_after else trim(pbr_phone_area_cd_after)end) as pbr_phone_area_cd_after,
(case when (LENGTH(trim( pbr_phone_after )) ==0) then pbr_phone_after else trim(pbr_phone_after)end) as pbr_phone_after,
(case when (LENGTH(trim( pbr_fax_area_cd_after )) ==0) then pbr_fax_area_cd_after else trim(pbr_fax_area_cd_after)end) as pbr_fax_area_cd_after,
(case when (LENGTH(trim( pbr_fax_after )) ==0) then pbr_fax_after else trim(pbr_fax_after)end) as pbr_fax_after,
(case when (LENGTH(trim( pbr_addr_after )) ==0) then pbr_addr_after else trim(pbr_addr_after)end) as pbr_addr_after,
(case when (LENGTH(trim( pbr_city_after )) ==0) then pbr_city_after else trim(pbr_city_after)end) as pbr_city_after,
(case when (LENGTH(trim( pbr_state_after )) ==0) then pbr_state_after else trim(pbr_state_after)end) as pbr_state_after,
(case when (LENGTH(trim( pbr_zip_after )) ==0) then pbr_zip_after else trim(pbr_zip_after)end) as pbr_zip_after,
(case when (LENGTH(trim( pbr_type_cd_after )) ==0) then pbr_type_cd_after else trim(pbr_type_cd_after)end) as pbr_type_cd_after,
(case when (LENGTH(trim( pbr_speciality_cd_after )) ==0) then pbr_speciality_cd_after else trim(pbr_speciality_cd_after)end) as pbr_speciality_cd_after,
(case when (LENGTH(trim( pbr_tax_id_after )) ==0) then pbr_tax_id_after else trim(pbr_tax_id_after)end) as pbr_tax_id_after,
(case when (LENGTH(trim( pbr_cmts_after )) ==0) then pbr_cmts_after else trim(pbr_cmts_after)end) as pbr_cmts_after,
(case when (LENGTH(trim( pbr_last_active_dttm_after )) ==0) then pbr_last_active_dttm_after else concat(substring(pbr_last_active_dttm_after,1,10),' ',substring(pbr_last_active_dttm_after,12,8),'.000000')end) as pbr_last_active_dttm_after,
(case when (LENGTH(trim( pbr_hlthcare_reform_nbr_after )) ==0) then pbr_hlthcare_reform_nbr_after else trim(pbr_hlthcare_reform_nbr_after)end) as pbr_hlthcare_reform_nbr_after,
(case when (LENGTH(trim( quarter1_ind_after )) ==0) then quarter1_ind_after else trim(quarter1_ind_after)end) as quarter1_ind_after,
(case when (LENGTH(trim( quarter2_ind_after )) ==0) then quarter2_ind_after else trim(quarter2_ind_after)end) as quarter2_ind_after,
(case when (LENGTH(trim( quarter3_ind_after )) ==0) then quarter3_ind_after else trim(quarter3_ind_after)end) as quarter3_ind_after,
(case when (LENGTH(trim( quarter4_ind_after )) ==0) then quarter4_ind_after else trim(quarter4_ind_after)end) as quarter4_ind_after,
(case when (LENGTH(trim( pbr_prescriber_ind_after )) ==0) then pbr_prescriber_ind_after else trim(pbr_prescriber_ind_after)end) as pbr_prescriber_ind_after,
(case when (LENGTH(trim( pbr_hub_nbr_after )) ==0) then pbr_hub_nbr_after else trim(pbr_hub_nbr_after)end) as pbr_hub_nbr_after,
(case when (LENGTH(trim( pbr_clinic_site_after )) ==0) then pbr_clinic_site_after else trim(pbr_clinic_site_after)end) as pbr_clinic_site_after,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id_after,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id_after,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm_after,
(case when (LENGTH(trim( pbr_clinic_id_after )) ==0) then pbr_clinic_id_after else trim(pbr_clinic_id_after)end) as pbr_clinic_id_after,
(case when (LENGTH(trim( pbr_company_cd_after )) ==0) then pbr_company_cd_after else trim(pbr_company_cd_after)end) as pbr_company_cd_after,
(case when (LENGTH(trim( pbr_phone_cmts_after )) ==0) then pbr_phone_cmts_after else trim(pbr_phone_cmts_after)end) as pbr_phone_cmts_after,
(case when (LENGTH(trim( pbr_change_req_ind_after )) ==0) then pbr_change_req_ind_after else trim(pbr_change_req_ind_after)end) as pbr_change_req_ind_after,
(case when (LENGTH(trim( pbr_source_ind_after )) ==0) then pbr_source_ind_after else trim(pbr_source_ind_after)end) as pbr_source_ind_after,
(case when (LENGTH(trim( ndc_pbr_id_after )) ==0) then ndc_pbr_id_after else trim(ndc_pbr_id_after)end) as ndc_pbr_id_after,
(case when (LENGTH(trim( pbr_provider_status_after )) ==0) then pbr_provider_status_after else trim(pbr_provider_status_after)end) as pbr_provider_status_after,
(case when (LENGTH(trim( pbr_prof_status_after )) ==0) then pbr_prof_status_after else trim(pbr_prof_status_after)end) as pbr_prof_status_after,
(case when (LENGTH(trim( pbr_sex_cd_after )) ==0) then pbr_sex_cd_after else trim(pbr_sex_cd_after)end) as pbr_sex_cd_after,
(case when (LENGTH(trim( pbr_birth_dttm_after )) ==0) then pbr_birth_dttm_after else concat(substring(pbr_birth_dttm_after,1,10),' ',substring(pbr_birth_dttm_after,12,8),'.000000')end) as pbr_birth_dttm_after,
(case when (LENGTH(trim( pbr_middle_name_after )) ==0) then pbr_middle_name_after else trim(pbr_middle_name_after)end) as pbr_middle_name_after,
(case when (LENGTH(trim( pbr_addr2_after )) ==0) then pbr_addr2_after else trim(pbr_addr2_after)end) as pbr_addr2_after,
(case when (LENGTH(trim( pbr_dea_expire_dttm_after )) ==0) then pbr_dea_expire_dttm_after else concat(substring(pbr_dea_expire_dttm_after,1,10),' ',substring(pbr_dea_expire_dttm_after,12,8),'.000000')end) as pbr_dea_expire_dttm_after,
(case when (LENGTH(trim( pbr_upin_after )) ==0) then pbr_upin_after else trim(pbr_upin_after)end) as pbr_upin_after,
(case when (LENGTH(trim( pbr_license_state_after )) ==0) then pbr_license_state_after else trim(pbr_license_state_after)end) as pbr_license_state_after,
(case when (LENGTH(trim( pbr_state_license_nbr_after )) ==0) then pbr_state_license_nbr_after else trim(pbr_state_license_nbr_after)end) as pbr_state_license_nbr_after,
(case when (LENGTH(trim( ndc_pbr_loc_id_after )) ==0) then ndc_pbr_loc_id_after else trim(ndc_pbr_loc_id_after)end) as ndc_pbr_loc_id_after,
(case when (LENGTH(trim( pbr_app_cd_after )) ==0) then pbr_app_cd_after else trim(pbr_app_cd_after)end) as pbr_app_cd_after,
(case when (LENGTH(trim( pbr_npi_after )) ==0) then pbr_npi_after else trim(pbr_npi_after)end) as pbr_npi_after,
(case when (LENGTH(trim( ow_update_dttm_after )) ==0) then ow_update_dttm_after else concat(substring(ow_update_dttm_after,1,10),' ',substring(ow_update_dttm_after,12,8),'.000000')end) as ow_update_dttm_after,
(case when (LENGTH(trim( pbr_group_id_after )) ==0) then pbr_group_id_after else trim(pbr_group_id_after)end) as pbr_group_id_after,
(case when (LENGTH(trim( pbr_loc_group_id_after )) ==0) then pbr_loc_group_id_after else trim(pbr_loc_group_id_after)end) as pbr_loc_group_id_after,
(case when (LENGTH(trim( repl_by_pbr_id_after )) ==0) then repl_by_pbr_id_after else trim(repl_by_pbr_id_after)end) as repl_by_pbr_id_after,
(case when (LENGTH(trim( repl_by_pbr_loc_id_after )) ==0) then repl_by_pbr_loc_id_after else trim(repl_by_pbr_loc_id_after)end) as repl_by_pbr_loc_id_after,
(case when (LENGTH(trim( pbr_loc_name_after )) ==0) then pbr_loc_name_after else trim(pbr_loc_name_after)end) as pbr_loc_name_after,
(case when (LENGTH(trim( pbr_pecos_ind_after )) ==0) then pbr_pecos_ind_after else trim(pbr_pecos_ind_after)end) as pbr_pecos_ind_after,
(case when (LENGTH(trim( pbr_death_dttm_after )) ==0) then pbr_death_dttm_after else concat(substring(pbr_death_dttm_after,1,10),' ',substring(pbr_death_dttm_after,12,8),'.000000')end) as pbr_death_dttm_after,
(case when (LENGTH(trim( pbr_state_ctrl_nbr_after )) ==0) then pbr_state_ctrl_nbr_after else trim(pbr_state_ctrl_nbr_after)end) as pbr_state_ctrl_nbr_after,
(case when (LENGTH(trim( pbr_refill_area_cd_after )) ==0) then pbr_refill_area_cd_after else trim(pbr_refill_area_cd_after)end) as pbr_refill_area_cd_after,
(case when (LENGTH(trim( pbr_refill_phone_after )) ==0) then pbr_refill_phone_after else trim(pbr_refill_phone_after)end) as pbr_refill_phone_after,
(case when (LENGTH(trim( pbr_foreign_license_after )) ==0) then pbr_foreign_license_after else trim(pbr_foreign_license_after)end) as pbr_foreign_license_after,
(case when (LENGTH(trim( pbr_store_npi_ind_after )) ==0) then pbr_store_npi_ind_after else trim(pbr_store_npi_ind_after)end) as pbr_store_npi_ind_after,
'000000' as tracking_id     
from gg_tbf0_prescriber where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd ='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd_after,
edw_batch_id_after,
(case when (LENGTH(trim( pbr_id_after )) ==0) then pbr_id_after else trim(pbr_id_after)end) as pbr_id_after,
(case when (LENGTH(trim( pbr_loc_id_after )) ==0) then pbr_loc_id_after else trim(pbr_loc_id_after)end) as pbr_loc_id_after,
(case when (LENGTH(trim( pbr_status_cd_after )) ==0) then pbr_status_cd_after else trim(pbr_status_cd_after)end) as pbr_status_cd_after,
(case when (LENGTH(trim( pbr_dea_nbr_after )) ==0) then pbr_dea_nbr_after else trim(pbr_dea_nbr_after)end) as pbr_dea_nbr_after,
(case when (LENGTH(trim( pbr_dea_suf_after )) ==0) then pbr_dea_suf_after else trim(pbr_dea_suf_after)end) as pbr_dea_suf_after,
(case when (LENGTH(trim( pbr_spin_nbr_after )) ==0) then pbr_spin_nbr_after else trim(pbr_spin_nbr_after)end) as pbr_spin_nbr_after,
(case when (LENGTH(trim( pbr_last_name_after )) ==0) then pbr_last_name_after else trim(pbr_last_name_after)end) as pbr_last_name_after,
(case when (LENGTH(trim( pbr_first_name_after )) ==0) then pbr_first_name_after else trim(pbr_first_name_after)end) as pbr_first_name_after,
(case when (LENGTH(trim( pbr_mid_init_after )) ==0) then pbr_mid_init_after else trim(pbr_mid_init_after)end) as pbr_mid_init_after,
(case when (LENGTH(trim( pbr_surname_suffix_after )) ==0) then pbr_surname_suffix_after else trim(pbr_surname_suffix_after)end) as pbr_surname_suffix_after,
(case when (LENGTH(trim( pbr_name_soundex_after )) ==0) then pbr_name_soundex_after else trim(pbr_name_soundex_after)end) as pbr_name_soundex_after,
(case when (LENGTH(trim( pbr_phone_area_cd_after )) ==0) then pbr_phone_area_cd_after else trim(pbr_phone_area_cd_after)end) as pbr_phone_area_cd_after,
(case when (LENGTH(trim( pbr_phone_after )) ==0) then pbr_phone_after else trim(pbr_phone_after)end) as pbr_phone_after,
(case when (LENGTH(trim( pbr_fax_area_cd_after )) ==0) then pbr_fax_area_cd_after else trim(pbr_fax_area_cd_after)end) as pbr_fax_area_cd_after,
(case when (LENGTH(trim( pbr_fax_after )) ==0) then pbr_fax_after else trim(pbr_fax_after)end) as pbr_fax_after,
(case when (LENGTH(trim( pbr_addr_after )) ==0) then pbr_addr_after else trim(pbr_addr_after)end) as pbr_addr_after,
(case when (LENGTH(trim( pbr_city_after )) ==0) then pbr_city_after else trim(pbr_city_after)end) as pbr_city_after,
(case when (LENGTH(trim( pbr_state_after )) ==0) then pbr_state_after else trim(pbr_state_after)end) as pbr_state_after,
(case when (LENGTH(trim( pbr_zip_after )) ==0) then pbr_zip_after else trim(pbr_zip_after)end) as pbr_zip_after,
(case when (LENGTH(trim( pbr_type_cd_after )) ==0) then pbr_type_cd_after else trim(pbr_type_cd_after)end) as pbr_type_cd_after,
(case when (LENGTH(trim( pbr_speciality_cd_after )) ==0) then pbr_speciality_cd_after else trim(pbr_speciality_cd_after)end) as pbr_speciality_cd_after,
(case when (LENGTH(trim( pbr_tax_id_after )) ==0) then pbr_tax_id_after else trim(pbr_tax_id_after)end) as pbr_tax_id_after,
(case when (LENGTH(trim( pbr_cmts_after )) ==0) then pbr_cmts_after else trim(pbr_cmts_after)end) as pbr_cmts_after,
(case when (LENGTH(trim( pbr_last_active_dttm_after )) ==0) then pbr_last_active_dttm_after else concat(substring(pbr_last_active_dttm_after,1,10),' ',substring(pbr_last_active_dttm_after,12,8),'.000000')end) as pbr_last_active_dttm_after,
(case when (LENGTH(trim( pbr_hlthcare_reform_nbr_after )) ==0) then pbr_hlthcare_reform_nbr_after else trim(pbr_hlthcare_reform_nbr_after)end) as pbr_hlthcare_reform_nbr_after,
(case when (LENGTH(trim( quarter1_ind_after )) ==0) then quarter1_ind_after else trim(quarter1_ind_after)end) as quarter1_ind_after,
(case when (LENGTH(trim( quarter2_ind_after )) ==0) then quarter2_ind_after else trim(quarter2_ind_after)end) as quarter2_ind_after,
(case when (LENGTH(trim( quarter3_ind_after )) ==0) then quarter3_ind_after else trim(quarter3_ind_after)end) as quarter3_ind_after,
(case when (LENGTH(trim( quarter4_ind_after )) ==0) then quarter4_ind_after else trim(quarter4_ind_after)end) as quarter4_ind_after,
(case when (LENGTH(trim( pbr_prescriber_ind_after )) ==0) then pbr_prescriber_ind_after else trim(pbr_prescriber_ind_after)end) as pbr_prescriber_ind_after,
(case when (LENGTH(trim( pbr_hub_nbr_after )) ==0) then pbr_hub_nbr_after else trim(pbr_hub_nbr_after)end) as pbr_hub_nbr_after,
(case when (LENGTH(trim( pbr_clinic_site_after )) ==0) then pbr_clinic_site_after else trim(pbr_clinic_site_after)end) as pbr_clinic_site_after,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id_after,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id_after,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm_after,
(case when (LENGTH(trim( pbr_clinic_id_after )) ==0) then pbr_clinic_id_after else trim(pbr_clinic_id_after)end) as pbr_clinic_id_after,
(case when (LENGTH(trim( pbr_company_cd_after )) ==0) then pbr_company_cd_after else trim(pbr_company_cd_after)end) as pbr_company_cd_after,
(case when (LENGTH(trim( pbr_phone_cmts_after )) ==0) then pbr_phone_cmts_after else trim(pbr_phone_cmts_after)end) as pbr_phone_cmts_after,
(case when (LENGTH(trim( pbr_change_req_ind_after )) ==0) then pbr_change_req_ind_after else trim(pbr_change_req_ind_after)end) as pbr_change_req_ind_after,
(case when (LENGTH(trim( pbr_source_ind_after )) ==0) then pbr_source_ind_after else trim(pbr_source_ind_after)end) as pbr_source_ind_after,
(case when (LENGTH(trim( ndc_pbr_id_after )) ==0) then ndc_pbr_id_after else trim(ndc_pbr_id_after)end) as ndc_pbr_id_after,
(case when (LENGTH(trim( pbr_provider_status_after )) ==0) then pbr_provider_status_after else trim(pbr_provider_status_after)end) as pbr_provider_status_after,
(case when (LENGTH(trim( pbr_prof_status_after )) ==0) then pbr_prof_status_after else trim(pbr_prof_status_after)end) as pbr_prof_status_after,
(case when (LENGTH(trim( pbr_sex_cd_after )) ==0) then pbr_sex_cd_after else trim(pbr_sex_cd_after)end) as pbr_sex_cd_after,
(case when (LENGTH(trim( pbr_birth_dttm_after )) ==0) then pbr_birth_dttm_after else concat(substring(pbr_birth_dttm_after,1,10),' ',substring(pbr_birth_dttm_after,12,8),'.000000')end) as pbr_birth_dttm_after,
(case when (LENGTH(trim( pbr_middle_name_after )) ==0) then pbr_middle_name_after else trim(pbr_middle_name_after)end) as pbr_middle_name_after,
(case when (LENGTH(trim( pbr_addr2_after )) ==0) then pbr_addr2_after else trim(pbr_addr2_after)end) as pbr_addr2_after,
(case when (LENGTH(trim( pbr_dea_expire_dttm_after )) ==0) then pbr_dea_expire_dttm_after else concat(substring(pbr_dea_expire_dttm_after,1,10),' ',substring(pbr_dea_expire_dttm_after,12,8),'.000000')end) as pbr_dea_expire_dttm_after,
(case when (LENGTH(trim( pbr_upin_after )) ==0) then pbr_upin_after else trim(pbr_upin_after)end) as pbr_upin_after,
(case when (LENGTH(trim( pbr_license_state_after )) ==0) then pbr_license_state_after else trim(pbr_license_state_after)end) as pbr_license_state_after,
(case when (LENGTH(trim( pbr_state_license_nbr_after )) ==0) then pbr_state_license_nbr_after else trim(pbr_state_license_nbr_after)end) as pbr_state_license_nbr_after,
(case when (LENGTH(trim( ndc_pbr_loc_id_after )) ==0) then ndc_pbr_loc_id_after else trim(ndc_pbr_loc_id_after)end) as ndc_pbr_loc_id_after,
(case when (LENGTH(trim( pbr_app_cd_after )) ==0) then pbr_app_cd_after else trim(pbr_app_cd_after)end) as pbr_app_cd_after,
(case when (LENGTH(trim( pbr_npi_after )) ==0) then pbr_npi_after else trim(pbr_npi_after)end) as pbr_npi_after,
(case when (LENGTH(trim( ow_update_dttm_after )) ==0) then ow_update_dttm_after else concat(substring(ow_update_dttm_after,1,10),' ',substring(ow_update_dttm_after,12,8),'.000000')end) as ow_update_dttm_after,
(case when (LENGTH(trim( pbr_group_id_after )) ==0) then pbr_group_id_after else trim(pbr_group_id_after)end) as pbr_group_id_after,
(case when (LENGTH(trim( pbr_loc_group_id_after )) ==0) then pbr_loc_group_id_after else trim(pbr_loc_group_id_after)end) as pbr_loc_group_id_after,
(case when (LENGTH(trim( repl_by_pbr_id_after )) ==0) then repl_by_pbr_id_after else trim(repl_by_pbr_id_after)end) as repl_by_pbr_id_after,
(case when (LENGTH(trim( repl_by_pbr_loc_id_after )) ==0) then repl_by_pbr_loc_id_after else trim(repl_by_pbr_loc_id_after)end) as repl_by_pbr_loc_id_after,
(case when (LENGTH(trim( pbr_loc_name_after )) ==0) then pbr_loc_name_after else trim(pbr_loc_name_after)end) as pbr_loc_name_after,
(case when (LENGTH(trim( pbr_pecos_ind_after )) ==0) then pbr_pecos_ind_after else trim(pbr_pecos_ind_after)end) as pbr_pecos_ind_after,
(case when (LENGTH(trim( pbr_death_dttm_after )) ==0) then pbr_death_dttm_after else concat(substring(pbr_death_dttm_after,1,10),' ',substring(pbr_death_dttm_after,12,8),'.000000')end) as pbr_death_dttm_after,
(case when (LENGTH(trim( pbr_state_ctrl_nbr_after )) ==0) then pbr_state_ctrl_nbr_after else trim(pbr_state_ctrl_nbr_after)end) as pbr_state_ctrl_nbr_after,
(case when (LENGTH(trim( pbr_refill_area_cd_after )) ==0) then pbr_refill_area_cd_after else trim(pbr_refill_area_cd_after)end) as pbr_refill_area_cd_after,
(case when (LENGTH(trim( pbr_refill_phone_after )) ==0) then pbr_refill_phone_after else trim(pbr_refill_phone_after)end) as pbr_refill_phone_after,
(case when (LENGTH(trim( pbr_foreign_license_after )) ==0) then pbr_foreign_license_after else trim(pbr_foreign_license_after)end) as pbr_foreign_license_after,
(case when (LENGTH(trim( pbr_store_npi_ind_after )) ==0) then pbr_store_npi_ind_after else trim(pbr_store_npi_ind_after)end) as pbr_store_npi_ind_after,
'000000' as tracking_id    
from gg_tbf0_prescriber where cdc_operation_type_cd ='INSERT'"""

# COMMAND ----------

df1 = spark.sql(sql1)

#display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

#display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

#display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

# MAGIC %run 
# MAGIC ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)
#display(dfFinal)
dfFinal.createOrReplaceTempView("gg_tbf0_prescriber")

# drop columns
df_final = dfFinal.drop("tracking_id")
# convert date and number columns
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
  .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr")))\
  .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr")))\
  .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id")))\
  .withColumn("pbr_id",when(col("pbr_id") == "",None).otherwise(col("pbr_id")))\
  .withColumn("pbr_loc_id",when(col("pbr_loc_id") == "",None).otherwise(col("pbr_loc_id")))\
  .withColumn("pbr_last_active_dttm", to_timestamp(df_final["pbr_last_active_dttm"]))\
  .withColumn("pbr_hub_nbr",when(col("pbr_hub_nbr") == "",None).otherwise(col("pbr_hub_nbr")))\
  .withColumn("pbr_clinic_site",when(col("pbr_clinic_site") == "",None).otherwise(col("pbr_clinic_site")))\
  .withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id")))\
  .withColumn("create_dttm", to_timestamp(df_final["create_dttm"]))\
  .withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id")))\
  .withColumn("update_dttm", to_timestamp(df_final["update_dttm"]))\
  .withColumn("ndc_pbr_id",when(col("ndc_pbr_id") == "",None).otherwise(col("ndc_pbr_id")))\
  .withColumn("pbr_birth_dttm", to_timestamp(df_final["pbr_birth_dttm"]))\
  .withColumn("pbr_dea_expire_dttm", to_timestamp(df_final["pbr_dea_expire_dttm"]))\
  .withColumn("ndc_pbr_loc_id",when(col("ndc_pbr_loc_id") == "",None).otherwise(col("ndc_pbr_loc_id")))\
  .withColumn("pbr_npi",when(col("pbr_npi") == "",None).otherwise(col("pbr_npi")))\
  .withColumn("ow_update_dttm", to_timestamp(df_final["ow_update_dttm"]))\
  .withColumn("repl_by_pbr_id",when(col("repl_by_pbr_id") == "",None).otherwise(col("repl_by_pbr_id")))\
  .withColumn("repl_by_pbr_loc_id",when(col("repl_by_pbr_loc_id") == "",None).otherwise(col("repl_by_pbr_loc_id")))\
  .withColumn("pbr_death_dttm", to_timestamp(df_final["pbr_death_dttm"]))\

#display(df_final)
#Update Varchar columns to null
from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",sel_snfl_tbl)\
   .load()

#display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
print(str_cols)


for col in str_cols:
  df_final = df_final.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))

#final df to load
#display(df_final)
print(f"Final count after union {df_final.count()}")





# COMMAND ----------


dfBad = spark.sql("select * from gg_tbf0_prescriber where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

#display(dfBad)

print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

# WRITING DATA IN OUTPUT AND RJECT FOLDER
df_final.write.format("parquet").mode("overwrite").save(OUT_FILEPATH)

dfBad.write.format("parquet").mode("overwrite").save(REJ_BAD_FILEPATH)



# COMMAND ----------



# COMMAND ----------

# delete records from snfk table
delete_gg_snowflake = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)
print(delete_gg_snowflake)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})



# COMMAND ----------

#Writing to the Snowflakes Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdFinalArray)

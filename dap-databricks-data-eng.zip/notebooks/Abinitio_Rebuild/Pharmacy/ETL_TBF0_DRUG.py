# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
readList=readList.split(',')
print(readList)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","GG_TBF0_DRUG")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'drug_id',
'drug_id_after',
'ndc_mfg',
'ndc_mfg_after',
'ndc_prod',
'ndc_prod_after',
'ndc_pkg',
'ndc_pkg_after',
'sims_upc',
'sims_upc_after',
'repack_nbr',
'repack_nbr_after',
'ndc_form_cd',
'ndc_form_cd_after',
'ndc_prev_mfg',
'ndc_prev_mfg_after',
'ndc_prev_prod',
'ndc_prev_prod_after',
'ndc_prev_pkg',
'ndc_prev_pkg_after',
'prev_repack_nbr',
'prev_repack_nbr_after',
'ndc_prev_form_cd',
'ndc_prev_form_cd_after',
'id_form_cd',
'id_form_cd_after',
'ndc_upc_hri',
'ndc_upc_hri_after',
'dur_ndc',
'dur_ndc_after',
'prev_ndc_upc_hri',
'prev_ndc_upc_hri_after',
'prev_id_form_cd',
'prev_id_form_cd_after',
'drug_class',
'drug_class_after',
'drug_orange_book_rating',
'drug_orange_book_rating_after',
'drug_name_cd',
'drug_name_cd_after',
'gppc',
'gppc_after',
'gen_typ_cd',
'gen_typ_cd_after',
'gen_id_no',
'gen_id_no_after',
'thera_class',
'thera_class_after',
'lim_stabil',
'lim_stabil_after',
'pack_descr',
'pack_descr_after',
'rx_otc_cd',
'rx_otc_cd_after',
'maint_drug_ind',
'maint_drug_ind_after',
'route_of_admin_cd',
'route_of_admin_cd_after',
'drug_generic_cd',
'drug_generic_cd_after',
'drug_type_cd',
'drug_type_cd_after',
'drug_single_comb_cd',
'drug_single_comb_cd_after',
'drug_storage_cond_cd',
'drug_storage_cond_cd_after',
'a_last_change_dttm',
'a_last_change_dttm_after',
'a_protect_ind',
'a_protect_ind_after',
'product_name',
'product_name_after',
'product_name_suffix',
'product_name_suffix_after',
'product_name_ext',
'product_name_ext_after',
'product_mddb_abbr',
'product_mddb_abbr_after',
'e_last_change_dttm',
'e_last_change_dttm_after',
'e_protect_ind',
'e_protect_ind_after',
'gpi',
'gpi_after',
'gpi_name',
'gpi_name_after',
'g_last_change_dttm',
'g_last_change_dttm_after',
'g_protect_ind',
'g_protect_ind_after',
'mfg_name',
'mfg_name_after',
'mfg_name_abbr',
'mfg_name_abbr_after',
'mfg_mddb_abbr',
'mfg_mddb_abbr_after',
'mfg_name_suffix',
'mfg_name_suffix_after',
'j_last_change_dttm',
'j_last_change_dttm_after',
'j_protect_ind',
'j_protect_ind_after',
'drug_strength',
'drug_strength_after',
'drug_strength_uom',
'drug_strength_uom_after',
'drug_dosage_form_cd',
'drug_dosage_form_cd_after',
'package_size',
'package_size_after',
'package_size_uom',
'package_size_uom_after',
'package_qty',
'package_qty_after',
'rx_to_otc_dttm',
'rx_to_otc_dttm_after',
'l_last_change_dttm',
'l_last_change_dttm_after',
'l_protect_ind',
'l_protect_ind_after',
'awp_dttm',
'awp_dttm_after',
'drug_counting_cell_id',
'drug_counting_cell_id_after',
'awp_unit_price',
'awp_unit_price_after',
'r_last_change_dttm',
'r_last_change_dttm_after',
'r_protect_ind',
'r_protect_ind_after',
'hcfa_dttm',
'hcfa_dttm_after',
'hcfa_unit_limit',
'hcfa_unit_limit_after',
't_last_change_dttm',
't_last_change_dttm_after',
't_protect_ind',
't_protect_ind_after',
'product_name_abbr',
'product_name_abbr_after',
'drug_status_cd',
'drug_status_cd_after',
'drug_disc_dttm',
'drug_disc_dttm_after',
'mfp_nbr',
'mfp_nbr_after',
'wic_nbr',
'wic_nbr_after',
'drug_ppi_ind',
'drug_ppi_ind_after',
'drug_min_disp_qty',
'drug_min_disp_qty_after',
'default_sig',
'default_sig_after',
'default_days_supply',
'default_days_supply_after',
'expiration_days',
'expiration_days_after',
'drug_class_except_ind',
'drug_class_except_ind_after',
'ops_study_dept_nbr',
'ops_study_dept_nbr_after',
'drug_warehouse_ind',
'drug_warehouse_ind_after',
'pricing_protect_ind',
'pricing_protect_ind_after',
'pr_daco_ind',
'pr_daco_ind_after',
'pricing_override_drug',
'pricing_override_drug_after',
'pricing_type',
'pricing_type_after',
'aac_unit_price',
'aac_unit_price_after',
'wac_unit_price',
'wac_unit_price_after',
'prorated_quantity',
'prorated_quantity_after',
'pricing_quantity',
'pricing_quantity_after',
'drug_shape_cd',
'drug_shape_cd_after',
'drug_color_1_cd',
'drug_color_1_cd_after',
'drug_color_2_cd',
'drug_color_2_cd_after',
'drug_side_1',
'drug_side_1_after',
'drug_side_2',
'drug_side_2_after',
'billing_ndc',
'billing_ndc_after',
'drug_comment_cd',
'drug_comment_cd_after',
'default_smart_sig',
'default_smart_sig_after',
'drug_location_cd',
'drug_location_cd_after',
'drug_multihit_disp_ind',
'drug_multihit_disp_ind_after',
'substitution_drug_id',
'substitution_drug_id_after',
'drug_volume',
'drug_volume_after',
'precount_ind',
'precount_ind_after',
'precount_qty_1',
'precount_qty_1_after',
'precount_qty_2',
'precount_qty_2_after',
'dur_kdc_nbr',
'dur_kdc_nbr_after',
'ud_uu_pkg_cd',
'ud_uu_pkg_cd_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'lbl_cmt_cd',
'lbl_cmt_cd_after',
'substitution_prod_type',
'substitution_prod_type_after',
'recon_water_qty',
'recon_water_qty_after',
'drug_spec_cmt_cd',
'drug_spec_cmt_cd_after',
'fax_pbr_cmt_cd',
'fax_pbr_cmt_cd_after',
'promise_sub_drug_id',
'promise_sub_drug_id_after',
'specialty_drug_ind',
'specialty_drug_ind_after',
'cash_disc_qty',
'cash_disc_qty_after',
'piece_weight',
'piece_weight_after',
'stock_bottle_barcode',
'stock_bottle_barcode_after',
'doses_per_pkg',
'doses_per_pkg_after',
'pct_tot_disc_card',
'pct_tot_disc_card_after',
'pet_med_ind',
'pet_med_ind_after',
'ltd_dist_cd',
'ltd_dist_cd_after',
'complicated_supplies_ind',
'complicated_supplies_ind_after',
'specialty_review_ind',
'specialty_review_ind_after',
'clinical_value_ind',
'clinical_value_ind_after',
'required_supplies_ind',
'required_supplies_ind_after',
'hcp_drug_mltht_disp_ind',
'hcp_drug_mltht_disp_ind_after',
'mix_ind',
'mix_ind_after',
'drug_image_file_name',
'drug_image_file_name_after',
'top_drug_ind',
'top_drug_ind_after',
'quality_alert_message',
'quality_alert_message_after',
'quality_alert_keywords',
'quality_alert_keywords_after',
'quality_alert_rule_ind',
'quality_alert_rule_ind_after',
'quality_alert_screen_ind',
'quality_alert_screen_ind_after',
'cash_disc_qty2',
'cash_disc_qty2_after',
'cash_disc_qty3',
'cash_disc_qty3_after',
'tip_ind',
'tip_ind_after',
'ref_drug_id',
'ref_drug_id_after',
'hcpc',
'hcpc_after',
'pref_mfr_ind',
'pref_mfr_ind_after',
'med_guide_filename',
'med_guide_filename_after',
'med_guide_ind',
'med_guide_ind_after',
'item_class',
'item_class_after',
'item_group',
'item_group_after',
'item_formulary_ind',
'item_formulary_ind_after',
'item_category',
'item_category_after',
'item_lob',
'item_lob_after',
'item_conv_factor',
'item_conv_factor_after',
'item_list_price_sale',
'item_list_price_sale_after',
'item_retail_price',
'item_retail_price_after',
'item_pum',
'item_pum_after',
'item_sub_group',
'item_sub_group_after',
'item_sub_category',
'item_sub_category_after',
'item_sum',
'item_sum_after',
'primary_vendor_item_cost',
'primary_vendor_item_cost_after',
'primary_vendor_item_nbr',
'primary_vendor_item_nbr_after',
'secndry_vendor_item_cost',
'secndry_vendor_item_cost_after',
'secndry_vendor_item_nbr',
'secndry_vendor_item_nbr_after',
'tertry_vendor_item_cost',
'tertry_vendor_item_cost_after',
'tertry_vendor_item_nbr',
'tertry_vendor_item_nbr_after',
'specific_gravity',
'specific_gravity_after',
'concentration_nbr',
'concentration_nbr_after',
'concentration_units',
'concentration_units_after',
'lipids_ind',
'lipids_ind_after',
'amino_acid_ind',
'amino_acid_ind_after',
'poolable_ind',
'poolable_ind_after',
'trace_element_ind',
'trace_element_ind_after',
'electrolyte_ind',
'electrolyte_ind_after',
'container_material_cd',
'container_material_cd_after',
'container_max_capacity',
'container_max_capacity_after',
'vehicle_ind',
'vehicle_ind_after',
'vehicle',
'vehicle_after',
'cocktail_ind',
'cocktail_ind_after',
'primary_vendor_nbr',
'primary_vendor_nbr_after',
'secondary_vendor_nbr',
'secondary_vendor_nbr_after',
'tertiary_vendor_nbr',
'tertiary_vendor_nbr_after',
'base_ind',
'base_ind_after',
'item_type',
'item_type_after',
'conc_dextrose_ind',
'conc_dextrose_ind_after',
'container_ind',
'container_ind_after',
'container_type',
'container_type_after',
'primary_vendor_name',
'primary_vendor_name_after',
'secondary_vendor_name',
'secondary_vendor_name_after',
'tertiary_vendor_name',
'tertiary_vendor_name_after',
'plx_drug_ind',
'plx_drug_ind_after',
'item_size',
'item_size_after',
'item_size_units',
'item_size_units_after',
'item_long_desc',
'item_long_desc_after',
'item_short_desc',
'item_short_desc_after',
'item_awp',
'item_awp_after',
'billing_multiplier',
'billing_multiplier_after',
'track_inventory_ind',
'track_inventory_ind_after',
'disease_state_ind',
'disease_state_ind_after',
'drug_min_price',
'drug_min_price_after',
'drug_inference_cd',
'drug_inference_cd_after',
'excl_drug_automation_ind',
'excl_drug_automation_ind_after',
'excl_tbltp_count_ind',
'excl_tbltp_count_ind_after',
'require_tbltp_clean',
'require_tbltp_clean_after',
'thera_class_extd',
'thera_class_extd_after',
'hzrds_lvl_cd',
'hzrds_lvl_cd_after',
'auth_generic_cd',
'auth_generic_cd_after',
'fda_ind',
'fda_ind_after',
'fda_ind_value',
'fda_ind_value_after',
'auth_ndc_upc_hri',
'auth_ndc_upc_hri_after',
'auth_gen_override_ind',
'auth_gen_override_ind_after',
'ddid',
'ddid_after',
'rxcui_type',
'rxcui_type_after',
'rxcui',
'rxcui_after',
'elsevier_pack_id',
'elsevier_pack_id_after',
'elsevier_prod_id',
'elsevier_prod_id_after',
'med_dosage_unit',
'med_dosage_unit_after',
'med_conv_factor',
'med_conv_factor_after',
'mme_calc_factor',
'mme_calc_factor_after'     
]

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 445 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 446:
      return True
  else:
    if val_len != 446:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 446

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 446
print(f"Bad records count {rd_bad.count()}") # != 446


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = df.withColumn('hzrds_lvl_cd', substring('hzrds_lvl_cd', 1,2))\
       .withColumn('hzrds_lvl_cd_after', substring('hzrds_lvl_cd_after', 1,2))
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_drug")

# COMMAND ----------

#Bad records 
dfBad = spark.sql("select * from gg_tbf0_drug where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")
display(dfBad)
print(f"Bad records count {dfBad.count()}")

dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

df_gg = df.withColumn("table_name",lit(SRC_TBL_NAME))
display(df_gg)

df_gg.createOrReplaceTempView("raw_src_gg_table")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')" 

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="(drug_id == drug_id_after  AND drug_id is NOT NULL AND drug_id_after is NOT NULL AND  cdc_seq_nbr  == cdc_seq_nbr_after  AND cdc_seq_nbr is NOT NULL AND cdc_seq_nbr_after is NOT NULL AND  cdc_rba_nbr  == cdc_rba_nbr_after  AND cdc_rba_nbr is NOT NULL AND cdc_rba_nbr_after is NOT NULL AND  cdc_txn_commit_dttm == cdc_txn_commit_dttm_after   AND cdc_txn_commit_dttm is NOT NULL AND cdc_txn_commit_dttm_after is NOT NULL AND  cdc_before_after_cd_after == 'AFTER'  AND cdc_before_after_cd_after is NOT NULL AND   cdc_operation_type_cd_after == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after is NOT NULL AND  cdc_before_after_cd == 'BEFORE'  AND cdc_before_after_cd is NOT NULL AND  cdc_operation_type_cd == 'SQL COMPUPDATE'   AND cdc_operation_type_cd is NOT NULL AND  ( (ndc_mfg == ndc_mfg_after  AND ndc_mfg is NOT NULL AND ndc_mfg_after is NOT NULL) OR ( ndc_mfg IS NULL  AND   ndc_mfg_after IS NULL ) )  AND  (( ndc_prod == ndc_prod_after  AND ndc_prod is NOT NULL AND ndc_prod_after is NOT NULL) OR ( ndc_prod IS NULL  AND   ndc_prod_after IS NULL ) )  AND  ( (ndc_pkg == ndc_pkg_after  AND ndc_pkg is NOT NULL AND ndc_pkg_after is NOT NULL) OR ( ndc_pkg IS NULL  AND   ndc_pkg_after IS NULL ) )  AND  (( sims_upc == sims_upc_after  AND sims_upc is NOT NULL AND sims_upc_after is NOT NULL) OR ( sims_upc IS NULL  AND   sims_upc_after IS NULL ) )  AND  (( repack_nbr == repack_nbr_after  AND repack_nbr is NOT NULL AND repack_nbr_after is NOT NULL) OR ( repack_nbr IS NULL  AND   repack_nbr_after IS NULL ) )  AND  ( (ndc_form_cd == ndc_form_cd_after  AND ndc_form_cd is NOT NULL AND ndc_form_cd_after is NOT NULL ) OR ( ndc_form_cd IS NULL  AND   ndc_form_cd_after IS NULL ) )  AND  ( (ndc_prev_mfg == ndc_prev_mfg_after  AND ndc_prev_mfg is NOT NULL AND ndc_prev_mfg_after is NOT NULL) OR ( ndc_prev_mfg IS NULL  AND   ndc_prev_mfg_after IS NULL ) )  AND  ( (ndc_prev_prod == ndc_prev_prod_after  AND ndc_prev_prod is NOT NULL AND ndc_prev_prod_after is NOT NULL) OR ( ndc_prev_prod IS NULL  AND   ndc_prev_prod_after IS NULL ) )  AND  ( (ndc_prev_pkg == ndc_prev_pkg_after  AND ndc_prev_pkg is NOT NULL AND ndc_prev_pkg_after is NOT NULL) OR ( ndc_prev_pkg IS NULL  AND   ndc_prev_pkg_after IS NULL ) )  AND  ( (prev_repack_nbr == prev_repack_nbr_after  AND prev_repack_nbr is NOT NULL AND prev_repack_nbr_after is NOT NULL) OR ( prev_repack_nbr IS NULL  AND   prev_repack_nbr_after IS NULL ) )  AND  ( (ndc_prev_form_cd == ndc_prev_form_cd_after  AND ndc_prev_form_cd is NOT NULL AND ndc_prev_form_cd_after is NOT NULL) OR ( ndc_prev_form_cd IS NULL  AND   ndc_prev_form_cd_after IS NULL ) )  AND  ( (id_form_cd == id_form_cd_after  AND id_form_cd is NOT NULL AND id_form_cd_after is NOT NULL) OR ( id_form_cd IS NULL  AND   id_form_cd_after IS NULL ) )  AND  ( (ndc_upc_hri == ndc_upc_hri_after  AND ndc_upc_hri is NOT NULL AND ndc_upc_hri_after is NOT NULL) OR ( ndc_upc_hri IS NULL  AND   ndc_upc_hri_after IS NULL ) )  AND  ( (dur_ndc == dur_ndc_after  AND dur_ndc is NOT NULL AND dur_ndc_after is NOT NULL) OR ( dur_ndc IS NULL  AND   dur_ndc_after IS NULL ) )  AND  ( (prev_ndc_upc_hri == prev_ndc_upc_hri_after  AND prev_ndc_upc_hri is NOT NULL AND prev_ndc_upc_hri_after is NOT NULL) OR ( prev_ndc_upc_hri IS NULL  AND   prev_ndc_upc_hri_after IS NULL ) )  AND  (( prev_id_form_cd == prev_id_form_cd_after  AND prev_id_form_cd is NOT NULL AND prev_id_form_cd_after is NOT NULL) OR ( prev_id_form_cd IS NULL  AND   prev_id_form_cd_after IS NULL ) )  AND  (( drug_class == drug_class_after  AND drug_class is NOT NULL AND drug_class_after is NOT NULL) OR ( drug_class IS NULL  AND   drug_class_after IS NULL ) )  AND  ( ( drug_orange_book_rating == drug_orange_book_rating_after  AND drug_orange_book_rating is NOT NULL AND drug_orange_book_rating_after is NOT NULL) OR ( drug_orange_book_rating IS NULL  AND   drug_orange_book_rating_after IS NULL ) )  AND  ( (drug_name_cd == drug_name_cd_after  AND drug_name_cd is NOT NULL AND drug_name_cd_after is NOT NULL) OR ( drug_name_cd IS NULL  AND   drug_name_cd_after IS NULL ) )  AND  ( (gppc == gppc_after  AND gppc is NOT NULL AND gppc_after is NOT NULL) OR ( gppc IS NULL  AND   gppc_after IS NULL ) )  AND  ( (gen_typ_cd == gen_typ_cd_after  AND gen_typ_cd is NOT NULL AND gen_typ_cd_after is NOT NULL) OR ( gen_typ_cd IS NULL  AND   gen_typ_cd_after IS NULL ) )  AND  ( (gen_id_no == gen_id_no_after  AND gen_id_no is NOT NULL AND gen_id_no_after is NOT NULL) OR ( gen_id_no IS NULL  AND   gen_id_no_after IS NULL ) )  AND  ( (thera_class == thera_class_after  AND thera_class is NOT NULL AND thera_class_after is NOT NULL) OR ( thera_class IS NULL  AND   thera_class_after IS NULL ) )  AND  ( (lim_stabil == lim_stabil_after  AND lim_stabil is NOT NULL AND lim_stabil_after is NOT NULL) OR ( lim_stabil IS NULL  AND   lim_stabil_after IS NULL ) )  AND  ( (pack_descr == pack_descr_after  AND pack_descr is NOT NULL AND pack_descr_after is NOT NULL) OR ( pack_descr IS NULL  AND   pack_descr_after IS NULL ) )  AND  ( (rx_otc_cd == rx_otc_cd_after  AND rx_otc_cd is NOT NULL AND rx_otc_cd_after is NOT NULL) OR ( rx_otc_cd IS NULL  AND   rx_otc_cd_after IS NULL ) )  AND  ( (maint_drug_ind == maint_drug_ind_after  AND maint_drug_ind is NOT NULL AND maint_drug_ind_after is NOT NULL) OR ( maint_drug_ind IS NULL  AND   maint_drug_ind_after IS NULL ) )  AND  ( (route_of_admin_cd == route_of_admin_cd_after  AND route_of_admin_cd is NOT NULL AND route_of_admin_cd_after is NOT NULL ) OR ( route_of_admin_cd IS NULL  AND   route_of_admin_cd_after IS NULL ) )  AND  ( (drug_generic_cd == drug_generic_cd_after  AND drug_generic_cd is NOT NULL AND drug_generic_cd_after is NOT NULL) OR ( drug_generic_cd IS NULL  AND   drug_generic_cd_after IS NULL ) )  AND  ( (drug_type_cd == drug_type_cd_after  AND drug_type_cd is NOT NULL AND drug_type_cd_after is NOT NULL) OR ( drug_type_cd IS NULL  AND   drug_type_cd_after IS NULL ) )  AND  ( (drug_single_comb_cd == drug_single_comb_cd_after  AND drug_single_comb_cd is NOT NULL AND drug_single_comb_cd_after is NOT NULL) OR ( drug_single_comb_cd IS NULL  AND   drug_single_comb_cd_after IS NULL ) )  AND  ( (drug_storage_cond_cd == drug_storage_cond_cd_after  AND drug_storage_cond_cd is NOT NULL AND drug_storage_cond_cd_after is NOT NULL) OR ( drug_storage_cond_cd IS NULL  AND   drug_storage_cond_cd_after IS NULL ) )  AND  ( (a_last_change_dttm == a_last_change_dttm_after  AND a_last_change_dttm is NOT NULL AND a_last_change_dttm_after is NOT NULL) OR ( a_last_change_dttm IS NULL  AND   a_last_change_dttm_after IS NULL ) )  AND  ( (a_protect_ind == a_protect_ind_after  AND a_protect_ind is NOT NULL AND a_protect_ind_after is NOT NULL) OR ( a_protect_ind IS NULL  AND   a_protect_ind_after IS NULL ) )  AND  ( (product_name == product_name_after  AND product_name is NOT NULL AND product_name_after is NOT NULL) OR ( product_name IS NULL  AND   product_name_after IS NULL ) )  AND  ( (product_name_suffix == product_name_suffix_after  AND product_name_suffix is NOT NULL AND product_name_suffix_after is NOT NULL ) OR ( product_name_suffix IS NULL  AND   product_name_suffix_after IS NULL ) )  AND  ( (product_name_ext == product_name_ext_after  AND product_name_ext is NOT NULL AND product_name_ext_after is NOT NULL) OR ( product_name_ext IS NULL  AND   product_name_ext_after IS NULL ) )  AND  ( (product_mddb_abbr == product_mddb_abbr_after  AND product_mddb_abbr is NOT NULL AND product_mddb_abbr_after is NOT NULL) OR ( product_mddb_abbr IS NULL  AND   product_mddb_abbr_after IS NULL ) )  AND  ( (e_last_change_dttm == e_last_change_dttm_after  AND e_last_change_dttm is NOT NULL AND e_last_change_dttm_after is NOT NULL) OR ( e_last_change_dttm IS NULL  AND   e_last_change_dttm_after IS NULL ) )  AND  ( (e_protect_ind == e_protect_ind_after  AND e_protect_ind is NOT NULL AND e_protect_ind_after is NOT NULL) OR ( e_protect_ind IS NULL  AND   e_protect_ind_after IS NULL ) )  AND  ( (gpi == gpi_after  AND gpi is NOT NULL AND gpi_after is NOT NULL) OR ( gpi IS NULL  AND   gpi_after IS NULL ) )  AND  ( (gpi_name == gpi_name_after  AND gpi_name is NOT NULL AND gpi_name_after is NOT NULL) OR ( gpi_name IS NULL  AND   gpi_name_after IS NULL ) )  AND  ( (g_last_change_dttm == g_last_change_dttm_after  AND g_last_change_dttm is NOT NULL AND g_last_change_dttm_after is NOT NULL )OR ( g_last_change_dttm IS NULL  AND   g_last_change_dttm_after IS NULL ) )  AND  ( (g_protect_ind == g_protect_ind_after  AND g_protect_ind is NOT NULL AND g_protect_ind_after is NOT NULL )OR ( g_protect_ind IS NULL  AND   g_protect_ind_after IS NULL ) )  AND  ( (mfg_name == mfg_name_after  AND mfg_name is NOT NULL AND mfg_name_after is NOT NULL) OR ( mfg_name IS NULL  AND   mfg_name_after IS NULL ) )  AND  ( (mfg_name_abbr == mfg_name_abbr_after  AND mfg_name_abbr is NOT NULL AND mfg_name_abbr_after is NOT NULL) OR ( mfg_name_abbr IS NULL  AND   mfg_name_abbr_after IS NULL ) )  AND  ( (mfg_mddb_abbr == mfg_mddb_abbr_after  AND mfg_mddb_abbr is NOT NULL AND mfg_mddb_abbr_after is NOT NULL) OR ( mfg_mddb_abbr IS NULL  AND   mfg_mddb_abbr_after IS NULL ) )  AND  ( (mfg_name_suffix == mfg_name_suffix_after  AND mfg_name_suffix is NOT NULL AND mfg_name_suffix_after is NOT NULL )OR ( mfg_name_suffix IS NULL  AND   mfg_name_suffix_after IS NULL ) )  AND  ( (j_last_change_dttm == j_last_change_dttm_after  AND j_last_change_dttm is NOT NULL AND j_last_change_dttm_after is NOT NULL) OR ( j_last_change_dttm IS NULL  AND   j_last_change_dttm_after IS NULL ) )  AND  ( (j_protect_ind == j_protect_ind_after  AND j_protect_ind is NOT NULL AND j_protect_ind_after is NOT NULL ) OR ( j_protect_ind IS NULL  AND   j_protect_ind_after IS NULL ) )  AND  ( (drug_strength == drug_strength_after  AND drug_strength is NOT NULL AND drug_strength_after is NOT NULL ) OR ( drug_strength IS NULL  AND   drug_strength_after IS NULL ) )  AND  ( (drug_strength_uom == drug_strength_uom_after  AND drug_strength_uom is NOT NULL AND drug_strength_uom_after is NOT NULL) OR ( drug_strength_uom IS NULL  AND   drug_strength_uom_after IS NULL ) )  AND  ( (drug_dosage_form_cd == drug_dosage_form_cd_after  AND drug_dosage_form_cd is NOT NULL AND drug_dosage_form_cd_after is NOT NULL) OR ( drug_dosage_form_cd IS NULL  AND   drug_dosage_form_cd_after IS NULL ) )  AND  ( (package_size == package_size_after  AND package_size is NOT NULL AND package_size_after is NOT NULL) OR ( package_size IS NULL  AND   package_size_after IS NULL ) )  AND  ( (package_size_uom == package_size_uom_after  AND package_size_uom is NOT NULL AND package_size_uom_after is NOT NULL) OR ( package_size_uom IS NULL  AND   package_size_uom_after IS NULL ) )  AND  ( (package_qty == package_qty_after  AND package_qty is NOT NULL AND package_qty_after is NOT NULL) OR ( package_qty IS NULL  AND   package_qty_after IS NULL ) )  AND  ( (rx_to_otc_dttm == rx_to_otc_dttm_after  AND rx_to_otc_dttm is NOT NULL AND rx_to_otc_dttm_after is NOT NULL) OR ( rx_to_otc_dttm IS NULL  AND   rx_to_otc_dttm_after IS NULL ) )  AND  ( (l_last_change_dttm == l_last_change_dttm_after  AND l_last_change_dttm is NOT NULL AND l_last_change_dttm_after is NOT NULL) OR ( l_last_change_dttm IS NULL  AND   l_last_change_dttm_after IS NULL ) )  AND  ( (l_protect_ind == l_protect_ind_after  AND l_protect_ind is NOT NULL AND l_protect_ind_after is NOT NULL) OR ( l_protect_ind IS NULL  AND   l_protect_ind_after IS NULL ) )  AND  ( (awp_dttm == awp_dttm_after  AND awp_dttm is NOT NULL AND awp_dttm_after is NOT NULL) OR ( awp_dttm IS NULL  AND   awp_dttm_after IS NULL ) )  AND  ( (drug_counting_cell_id == drug_counting_cell_id_after  AND drug_counting_cell_id is NOT NULL AND drug_counting_cell_id_after is NOT NULL) OR ( drug_counting_cell_id IS NULL  AND   drug_counting_cell_id_after IS NULL ) )  AND  ( (awp_unit_price == awp_unit_price_after  AND awp_unit_price is NOT NULL AND awp_unit_price_after is NOT NULL) OR ( awp_unit_price IS NULL  AND   awp_unit_price_after IS NULL ) )  AND  ( (r_last_change_dttm == r_last_change_dttm_after  AND r_last_change_dttm is NOT NULL AND r_last_change_dttm_after is NOT NULL) OR ( r_last_change_dttm IS NULL  AND   r_last_change_dttm_after IS NULL ) )  AND  ( (r_protect_ind == r_protect_ind_after  AND r_protect_ind is NOT NULL AND r_protect_ind_after is NOT NULL) OR ( r_protect_ind IS NULL  AND   r_protect_ind_after IS NULL ) )  AND  ( (hcfa_dttm == hcfa_dttm_after  AND hcfa_dttm is NOT NULL AND hcfa_dttm_after is NOT NULL) OR ( hcfa_dttm IS NULL  AND   hcfa_dttm_after IS NULL ) )  AND  ( (hcfa_unit_limit == hcfa_unit_limit_after  AND hcfa_unit_limit is NOT NULL AND hcfa_unit_limit_after is NOT NULL) OR ( hcfa_unit_limit IS NULL  AND   hcfa_unit_limit_after IS NULL ) )  AND  ( (t_last_change_dttm == t_last_change_dttm_after  AND t_last_change_dttm is NOT NULL AND t_last_change_dttm_after is NOT NULL) OR ( t_last_change_dttm IS NULL  AND   t_last_change_dttm_after IS NULL ) )  AND  ( (t_protect_ind == t_protect_ind_after  AND t_protect_ind is NOT NULL AND t_protect_ind_after is NOT NULL) OR ( t_protect_ind IS NULL  AND   t_protect_ind_after IS NULL ) )  AND  ( (product_name_abbr == product_name_abbr_after  AND product_name_abbr is NOT NULL AND product_name_abbr_after is NOT NULL ) OR ( product_name_abbr IS NULL  AND   product_name_abbr_after IS NULL ) )  AND  ( (drug_status_cd == drug_status_cd_after  AND drug_status_cd is NOT NULL AND drug_status_cd_after is NOT NULL) OR ( drug_status_cd IS NULL  AND   drug_status_cd_after IS NULL ) )  AND  ( (drug_disc_dttm == drug_disc_dttm_after  AND drug_disc_dttm is NOT NULL AND drug_disc_dttm_after is NOT NULL) OR ( drug_disc_dttm IS NULL  AND   drug_disc_dttm_after IS NULL ) )  AND  ( (mfp_nbr == mfp_nbr_after  AND mfp_nbr is NOT NULL AND mfp_nbr_after is NOT NULL) OR ( mfp_nbr IS NULL  AND   mfp_nbr_after IS NULL ) )  AND  ( (wic_nbr == wic_nbr_after  AND wic_nbr is NOT NULL AND wic_nbr_after is NOT NULL) OR ( wic_nbr IS NULL  AND   wic_nbr_after IS NULL ) )  AND  ( (drug_ppi_ind == drug_ppi_ind_after  AND drug_ppi_ind is NOT NULL AND drug_ppi_ind_after is NOT NULL) OR ( drug_ppi_ind IS NULL  AND   drug_ppi_ind_after IS NULL ) )  AND  ( ( drug_min_disp_qty == drug_min_disp_qty_after  AND drug_min_disp_qty is NOT NULL AND drug_min_disp_qty_after is NOT NULL ) OR ( drug_min_disp_qty IS NULL  AND   drug_min_disp_qty_after IS NULL ) )  AND  ( (  default_sig == default_sig_after  AND default_sig is NOT NULL AND default_sig_after is NOT NULL ) OR ( default_sig IS NULL  AND   default_sig_after IS NULL ) )  AND  ( (  default_days_supply == default_days_supply_after  AND default_days_supply is NOT NULL AND default_days_supply_after is NOT NULL ) OR ( default_days_supply IS NULL  AND   default_days_supply_after IS NULL ) )  AND  ( ( expiration_days == expiration_days_after  AND expiration_days is NOT NULL AND expiration_days_after is NOT NULL ) OR ( expiration_days IS NULL  AND   expiration_days_after IS NULL ) )  AND  ( (  drug_class_except_ind == drug_class_except_ind_after  AND drug_class_except_ind is NOT NULL AND drug_class_except_ind_after is NOT NULL ) OR ( drug_class_except_ind IS NULL  AND   drug_class_except_ind_after IS NULL ) )  AND  ( ( ops_study_dept_nbr == ops_study_dept_nbr_after  AND ops_study_dept_nbr is NOT NULL AND ops_study_dept_nbr_after is NOT NULL ) OR ( ops_study_dept_nbr IS NULL  AND   ops_study_dept_nbr_after IS NULL ) )  AND  ( ( drug_warehouse_ind == drug_warehouse_ind_after  AND drug_warehouse_ind is NOT NULL AND drug_warehouse_ind_after is NOT NULL ) OR ( drug_warehouse_ind IS NULL  AND   drug_warehouse_ind_after IS NULL ) )  AND  ( ( pricing_protect_ind == pricing_protect_ind_after  AND pricing_protect_ind is NOT NULL AND pricing_protect_ind_after is NOT NULL ) OR ( pricing_protect_ind IS NULL  AND   pricing_protect_ind_after IS NULL ) )  AND  ( ( pr_daco_ind == pr_daco_ind_after  AND pr_daco_ind is NOT NULL AND pr_daco_ind_after is NOT NULL ) OR ( pr_daco_ind IS NULL  AND   pr_daco_ind_after IS NULL ) )  AND  ( ( pricing_override_drug == pricing_override_drug_after  AND pricing_override_drug is NOT NULL AND pricing_override_drug_after is NOT NULL ) OR ( pricing_override_drug IS NULL  AND   pricing_override_drug_after IS NULL ) )  AND  ( ( pricing_type == pricing_type_after  AND pricing_type is NOT NULL AND pricing_type_after is NOT NULL ) OR ( pricing_type IS NULL  AND   pricing_type_after IS NULL ) )  AND  ( ( aac_unit_price == aac_unit_price_after  AND aac_unit_price is NOT NULL AND aac_unit_price_after is NOT NULL ) OR ( aac_unit_price IS NULL  AND   aac_unit_price_after IS NULL ) )  AND  ( ( wac_unit_price == wac_unit_price_after  AND wac_unit_price is NOT NULL AND wac_unit_price_after is NOT NULL ) OR ( wac_unit_price IS NULL  AND   wac_unit_price_after IS NULL ) )  AND  ( ( prorated_quantity == prorated_quantity_after  AND prorated_quantity is NOT NULL AND prorated_quantity_after is NOT NULL ) OR ( prorated_quantity IS NULL  AND   prorated_quantity_after IS NULL ) )  AND  ( ( pricing_quantity == pricing_quantity_after  AND pricing_quantity is NOT NULL AND pricing_quantity_after is NOT NULL ) OR ( pricing_quantity IS NULL  AND   pricing_quantity_after IS NULL ) )  AND  ( ( drug_shape_cd == drug_shape_cd_after  AND drug_shape_cd is NOT NULL AND drug_shape_cd_after is NOT NULL ) OR ( drug_shape_cd IS NULL  AND   drug_shape_cd_after IS NULL ) )  AND  ( ( drug_color_1_cd == drug_color_1_cd_after  AND drug_color_1_cd is NOT NULL AND drug_color_1_cd_after is NOT NULL ) OR ( drug_color_1_cd IS NULL  AND   drug_color_1_cd_after IS NULL ) )  AND  ( ( drug_color_2_cd == drug_color_2_cd_after  AND drug_color_2_cd is NOT NULL AND drug_color_2_cd_after is NOT NULL ) OR ( drug_color_2_cd IS NULL  AND   drug_color_2_cd_after IS NULL ) )  AND  ( ( drug_side_1 == drug_side_1_after  AND drug_side_1 is NOT NULL AND drug_side_1_after is NOT NULL ) OR ( drug_side_1 IS NULL  AND   drug_side_1_after IS NULL ) )  AND  ( ( drug_side_2 == drug_side_2_after  AND drug_side_2 is NOT NULL AND drug_side_2_after is NOT NULL ) OR ( drug_side_2 IS NULL  AND   drug_side_2_after IS NULL ) )  AND  ( ( billing_ndc == billing_ndc_after  AND billing_ndc is NOT NULL AND billing_ndc_after is NOT NULL ) OR ( billing_ndc IS NULL  AND   billing_ndc_after IS NULL ) )  AND  ( ( drug_comment_cd == drug_comment_cd_after  AND drug_comment_cd is NOT NULL AND drug_comment_cd_after is NOT NULL ) OR ( drug_comment_cd IS NULL  AND   drug_comment_cd_after IS NULL ) )  AND  ( ( default_smart_sig == default_smart_sig_after  AND default_smart_sig is NOT NULL AND default_smart_sig_after is NOT NULL ) OR ( default_smart_sig IS NULL  AND   default_smart_sig_after IS NULL ) )  AND  ( ( drug_location_cd == drug_location_cd_after  AND drug_location_cd is NOT NULL AND drug_location_cd_after is NOT NULL ) OR ( drug_location_cd IS NULL  AND   drug_location_cd_after IS NULL ) )  AND  ( ( drug_multihit_disp_ind == drug_multihit_disp_ind_after  AND drug_multihit_disp_ind is NOT NULL AND drug_multihit_disp_ind_after is NOT NULL ) OR ( drug_multihit_disp_ind IS NULL  AND   drug_multihit_disp_ind_after IS NULL ) )  AND  ( ( substitution_drug_id == substitution_drug_id_after  AND substitution_drug_id is NOT NULL AND substitution_drug_id_after is NOT NULL ) OR ( substitution_drug_id IS NULL  AND   substitution_drug_id_after IS NULL ) )  AND  ( ( drug_volume == drug_volume_after  AND drug_volume is NOT NULL AND drug_volume_after is NOT NULL ) OR ( drug_volume IS NULL  AND   drug_volume_after IS NULL ) )  AND  ( ( precount_ind == precount_ind_after  AND precount_ind is NOT NULL AND precount_ind_after is NOT NULL ) OR ( precount_ind IS NULL  AND   precount_ind_after IS NULL ) )  AND  ( ( precount_qty_1 == precount_qty_1_after  AND precount_qty_1 is NOT NULL AND precount_qty_1_after is NOT NULL ) OR ( precount_qty_1 IS NULL  AND   precount_qty_1_after IS NULL ) )  AND  ( ( precount_qty_2 == precount_qty_2_after  AND precount_qty_2 is NOT NULL AND precount_qty_2_after is NOT NULL ) OR ( precount_qty_2 IS NULL  AND   precount_qty_2_after IS NULL ) )  AND  ( ( dur_kdc_nbr == dur_kdc_nbr_after  AND dur_kdc_nbr is NOT NULL AND dur_kdc_nbr_after is NOT NULL ) OR ( dur_kdc_nbr IS NULL  AND   dur_kdc_nbr_after IS NULL ) )  AND  ( ( ud_uu_pkg_cd == ud_uu_pkg_cd_after  AND ud_uu_pkg_cd is NOT NULL AND ud_uu_pkg_cd_after is NOT NULL ) OR ( ud_uu_pkg_cd IS NULL  AND   ud_uu_pkg_cd_after IS NULL ) )  AND  ( ( lbl_cmt_cd == lbl_cmt_cd_after  AND lbl_cmt_cd is NOT NULL AND lbl_cmt_cd_after is NOT NULL ) OR ( lbl_cmt_cd IS NULL  AND   lbl_cmt_cd_after IS NULL ) )  AND  ( ( substitution_prod_type == substitution_prod_type_after  AND substitution_prod_type is NOT NULL AND substitution_prod_type_after is NOT NULL ) OR ( substitution_prod_type IS NULL  AND   substitution_prod_type_after IS NULL ) )  AND  ( ( recon_water_qty == recon_water_qty_after  AND recon_water_qty is NOT NULL AND recon_water_qty_after is NOT NULL ) OR ( recon_water_qty IS NULL  AND   recon_water_qty_after IS NULL ) )  AND  ( ( drug_spec_cmt_cd == drug_spec_cmt_cd_after  AND drug_spec_cmt_cd is NOT NULL AND drug_spec_cmt_cd_after is NOT NULL ) OR ( drug_spec_cmt_cd IS NULL  AND   drug_spec_cmt_cd_after IS NULL ) )  AND  ( ( fax_pbr_cmt_cd == fax_pbr_cmt_cd_after  AND fax_pbr_cmt_cd is NOT NULL AND fax_pbr_cmt_cd_after is NOT NULL ) OR ( fax_pbr_cmt_cd IS NULL  AND   fax_pbr_cmt_cd_after IS NULL ) )  AND  ( ( promise_sub_drug_id == promise_sub_drug_id_after  AND promise_sub_drug_id is NOT NULL AND promise_sub_drug_id_after is NOT NULL ) OR ( promise_sub_drug_id IS NULL  AND   promise_sub_drug_id_after IS NULL ) )  AND  ( ( specialty_drug_ind == specialty_drug_ind_after  AND specialty_drug_ind is NOT NULL AND specialty_drug_ind_after is NOT NULL ) OR ( specialty_drug_ind IS NULL  AND   specialty_drug_ind_after IS NULL ) )  AND  ( ( cash_disc_qty == cash_disc_qty_after  AND cash_disc_qty is NOT NULL AND cash_disc_qty_after is NOT NULL ) OR ( cash_disc_qty IS NULL  AND   cash_disc_qty_after IS NULL ) )  AND  ( ( piece_weight == piece_weight_after  AND piece_weight is NOT NULL AND piece_weight_after is NOT NULL ) OR ( piece_weight IS NULL  AND   piece_weight_after IS NULL ) )  AND  ( ( stock_bottle_barcode == stock_bottle_barcode_after  AND stock_bottle_barcode is NOT NULL AND stock_bottle_barcode_after is NOT NULL ) OR ( stock_bottle_barcode IS NULL  AND   stock_bottle_barcode_after IS NULL ) )  AND  ( ( doses_per_pkg == doses_per_pkg_after  AND doses_per_pkg is NOT NULL AND doses_per_pkg_after is NOT NULL ) OR ( doses_per_pkg IS NULL  AND   doses_per_pkg_after IS NULL ) )  AND  ( ( pct_tot_disc_card == pct_tot_disc_card_after  AND pct_tot_disc_card is NOT NULL AND pct_tot_disc_card_after is NOT NULL ) OR ( pct_tot_disc_card IS NULL  AND   pct_tot_disc_card_after IS NULL ) )  AND  ( ( pet_med_ind == pet_med_ind_after  AND pet_med_ind is NOT NULL AND pet_med_ind_after is NOT NULL ) OR ( pet_med_ind IS NULL  AND   pet_med_ind_after IS NULL ) )  AND  ( ( ltd_dist_cd == ltd_dist_cd_after  AND ltd_dist_cd is NOT NULL AND ltd_dist_cd_after is NOT NULL ) OR ( ltd_dist_cd IS NULL  AND   ltd_dist_cd_after IS NULL ) )  AND  ( ( complicated_supplies_ind == complicated_supplies_ind_after  AND complicated_supplies_ind is NOT NULL AND complicated_supplies_ind_after is NOT NULL ) OR ( complicated_supplies_ind IS NULL  AND   complicated_supplies_ind_after IS NULL ) )  AND  ( ( specialty_review_ind == specialty_review_ind_after  AND specialty_review_ind is NOT NULL AND specialty_review_ind_after is NOT NULL ) OR ( specialty_review_ind IS NULL  AND   specialty_review_ind_after IS NULL ) )  AND  ( ( clinical_value_ind == clinical_value_ind_after  AND clinical_value_ind is NOT NULL AND clinical_value_ind_after is NOT NULL ) OR ( clinical_value_ind IS NULL  AND   clinical_value_ind_after IS NULL ) )  AND  ( ( required_supplies_ind == required_supplies_ind_after  AND required_supplies_ind is NOT NULL AND required_supplies_ind_after is NOT NULL ) OR ( required_supplies_ind IS NULL  AND   required_supplies_ind_after IS NULL ) )  AND  ( ( hcp_drug_mltht_disp_ind == hcp_drug_mltht_disp_ind_after  AND hcp_drug_mltht_disp_ind is NOT NULL AND hcp_drug_mltht_disp_ind_after is NOT NULL ) OR ( hcp_drug_mltht_disp_ind IS NULL  AND   hcp_drug_mltht_disp_ind_after IS NULL ) )  AND  ( ( mix_ind == mix_ind_after  AND mix_ind is NOT NULL AND mix_ind_after is NOT NULL ) OR ( mix_ind IS NULL  AND   mix_ind_after IS NULL ) )  AND  ( ( drug_image_file_name == drug_image_file_name_after  AND drug_image_file_name is NOT NULL AND drug_image_file_name_after is NOT NULL ) OR ( drug_image_file_name IS NULL  AND   drug_image_file_name_after IS NULL ) )  AND  ( ( top_drug_ind == top_drug_ind_after AND top_drug_ind is NOT NULL AND top_drug_ind_after is NOT NULL ) OR ( top_drug_ind IS NULL  AND   top_drug_ind_after IS NULL ) )  AND  ( ( quality_alert_message == quality_alert_message_after AND quality_alert_message is NOT NULL AND quality_alert_message_after is NOT NULL ) OR ( quality_alert_message IS NULL  AND   quality_alert_message_after IS NULL ) )  AND  ( ( quality_alert_keywords == quality_alert_keywords_after AND quality_alert_keywords is NOT NULL AND quality_alert_keywords_after is NOT NULL ) OR ( quality_alert_keywords IS NULL  AND   quality_alert_keywords_after IS NULL ) )  AND  ( ( quality_alert_rule_ind == quality_alert_rule_ind_after AND quality_alert_rule_ind is NOT NULL AND quality_alert_rule_ind_after is NOT NULL ) OR ( quality_alert_rule_ind IS NULL  AND   quality_alert_rule_ind_after IS NULL ) )  AND  ( ( quality_alert_screen_ind == quality_alert_screen_ind_after AND quality_alert_screen_ind is NOT NULL AND quality_alert_screen_ind_after is NOT NULL ) OR ( quality_alert_screen_ind IS NULL  AND   quality_alert_screen_ind_after IS NULL ) )  AND  ( ( cash_disc_qty2 == cash_disc_qty2_after AND cash_disc_qty2 is NOT NULL AND cash_disc_qty2_after is NOT NULL ) OR ( cash_disc_qty2 IS NULL  AND   cash_disc_qty2_after IS NULL ) )  AND  ( ( cash_disc_qty3 == cash_disc_qty3_after AND cash_disc_qty3 is NOT NULL AND cash_disc_qty3_after is NOT NULL ) OR ( cash_disc_qty3 IS NULL  AND   cash_disc_qty3_after IS NULL ) )  AND  ( ( tip_ind == tip_ind_after AND tip_ind is NOT NULL AND tip_ind_after is NOT NULL ) OR ( tip_ind IS NULL  AND   tip_ind_after IS NULL ) )  AND  ( ( ref_drug_id == ref_drug_id_after AND ref_drug_id is NOT NULL AND ref_drug_id_after is NOT NULL ) OR ( ref_drug_id IS NULL  AND   ref_drug_id_after IS NULL ) )  AND  ( ( hcpc == hcpc_after AND hcpc is NOT NULL AND hcpc_after is NOT NULL ) OR ( hcpc IS NULL  AND   hcpc_after IS NULL ) )  AND  ( ( pref_mfr_ind == pref_mfr_ind_after AND pref_mfr_ind is NOT NULL AND pref_mfr_ind_after is NOT NULL ) OR ( pref_mfr_ind IS NULL  AND   pref_mfr_ind_after IS NULL ) )  AND  ( ( med_guide_filename == med_guide_filename_after AND med_guide_filename is NOT NULL AND med_guide_filename_after is NOT NULL ) OR ( med_guide_filename IS NULL  AND   med_guide_filename_after IS NULL ) )  AND  ( ( med_guide_ind == med_guide_ind_after AND med_guide_ind is NOT NULL AND med_guide_ind_after is NOT NULL ) OR ( med_guide_ind IS NULL  AND   med_guide_ind_after IS NULL ) )  AND  ( ( item_class == item_class_after AND item_class is NOT NULL AND item_class_after is NOT NULL ) OR ( item_class IS NULL  AND   item_class_after IS NULL ) )  AND  ( ( item_group == item_group_after AND item_group is NOT NULL AND item_group_after is NOT NULL ) OR ( item_group IS NULL  AND   item_group_after IS NULL ) )  AND  ( ( item_formulary_ind == item_formulary_ind_after AND item_formulary_ind is NOT NULL AND item_formulary_ind_after is NOT NULL ) OR ( item_formulary_ind IS NULL  AND   item_formulary_ind_after IS NULL ) )  AND  ( ( item_category == item_category_after AND item_category is NOT NULL AND item_category_after is NOT NULL ) OR ( item_category IS NULL  AND   item_category_after IS NULL ) )  AND  ( ( item_lob == item_lob_after AND item_lob is NOT NULL AND item_lob_after is NOT NULL ) OR ( item_lob IS NULL  AND   item_lob_after IS NULL ) )  AND  ( ( item_conv_factor == item_conv_factor_after AND item_conv_factor is NOT NULL AND item_conv_factor_after is NOT NULL ) OR ( item_conv_factor IS NULL  AND   item_conv_factor_after IS NULL ) )  AND  ( ( item_list_price_sale == item_list_price_sale_after AND item_list_price_sale is NOT NULL AND item_list_price_sale_after is NOT NULL ) OR ( item_list_price_sale IS NULL  AND   item_list_price_sale_after IS NULL ) )  AND  ( ( item_retail_price == item_retail_price_after AND item_retail_price is NOT NULL AND item_retail_price_after is NOT NULL ) OR ( item_retail_price IS NULL  AND   item_retail_price_after IS NULL ) )  AND  ( ( item_pum == item_pum_after AND item_pum is NOT NULL AND item_pum_after is NOT NULL ) OR ( item_pum IS NULL  AND   item_pum_after IS NULL ) )  AND  ( ( item_sub_group == item_sub_group_after AND item_sub_group is NOT NULL AND item_sub_group_after is NOT NULL ) OR ( item_sub_group IS NULL  AND   item_sub_group_after IS NULL ) )  AND  ( ( item_sub_category == item_sub_category_after AND item_sub_category is NOT NULL AND item_sub_category_after is NOT NULL ) OR ( item_sub_category IS NULL  AND   item_sub_category_after IS NULL ) )  AND  ( ( item_sum == item_sum_after AND item_sum is NOT NULL AND item_sum_after is NOT NULL ) OR ( item_sum IS NULL  AND   item_sum_after IS NULL ) )  AND  ( ( primary_vendor_item_cost == primary_vendor_item_cost_after AND primary_vendor_item_cost is NOT NULL AND primary_vendor_item_cost_after is NOT NULL ) OR ( primary_vendor_item_cost IS NULL  AND   primary_vendor_item_cost_after IS NULL ) )  AND  ( ( primary_vendor_item_nbr == primary_vendor_item_nbr_after AND primary_vendor_item_nbr is NOT NULL AND primary_vendor_item_nbr_after is NOT NULL ) OR ( primary_vendor_item_nbr IS NULL  AND   primary_vendor_item_nbr_after IS NULL ) )  AND  ( ( secndry_vendor_item_cost == secndry_vendor_item_cost_after AND secndry_vendor_item_cost is NOT NULL AND secndry_vendor_item_cost_after is NOT NULL ) OR ( secndry_vendor_item_cost IS NULL  AND   secndry_vendor_item_cost_after IS NULL ) )  AND  ( ( secndry_vendor_item_nbr == secndry_vendor_item_nbr_after AND secndry_vendor_item_nbr is NOT NULL AND secndry_vendor_item_nbr_after is NOT NULL ) OR ( secndry_vendor_item_nbr IS NULL  AND   secndry_vendor_item_nbr_after IS NULL ) )  AND  ( ( tertry_vendor_item_cost == tertry_vendor_item_cost_after AND tertry_vendor_item_cost is NOT NULL AND tertry_vendor_item_cost_after is NOT NULL ) OR ( tertry_vendor_item_cost IS NULL  AND   tertry_vendor_item_cost_after IS NULL ) )  AND  ( ( tertry_vendor_item_nbr == tertry_vendor_item_nbr_after AND tertry_vendor_item_nbr is NOT NULL AND tertry_vendor_item_nbr_after is NOT NULL ) OR ( tertry_vendor_item_nbr IS NULL  AND   tertry_vendor_item_nbr_after IS NULL ) )  AND  ( ( specific_gravity == specific_gravity_after AND specific_gravity is NOT NULL AND specific_gravity_after is NOT NULL ) OR ( specific_gravity IS NULL  AND   specific_gravity_after IS NULL ) )  AND  ( ( concentration_nbr == concentration_nbr_after AND concentration_nbr is NOT NULL AND concentration_nbr_after is NOT NULL ) OR ( concentration_nbr IS NULL  AND   concentration_nbr_after IS NULL ) )  AND  ( ( concentration_units == concentration_units_after AND concentration_units is NOT NULL AND concentration_units_after is NOT NULL ) OR ( concentration_units IS NULL  AND   concentration_units_after IS NULL ) )  AND  ( ( lipids_ind == lipids_ind_after AND lipids_ind is NOT NULL AND lipids_ind_after is NOT NULL ) OR ( lipids_ind IS NULL  AND   lipids_ind_after IS NULL ) )  AND  ( ( amino_acid_ind == amino_acid_ind_after AND amino_acid_ind is NOT NULL AND amino_acid_ind_after is NOT NULL ) OR ( amino_acid_ind IS NULL  AND   amino_acid_ind_after IS NULL ) )  AND  ( ( poolable_ind == poolable_ind_after AND poolable_ind is NOT NULL AND poolable_ind_after is NOT NULL ) OR ( poolable_ind IS NULL  AND   poolable_ind_after IS NULL ) )  AND  ( ( trace_element_ind == trace_element_ind_after AND trace_element_ind is NOT NULL AND trace_element_ind_after is NOT NULL ) OR ( trace_element_ind IS NULL  AND   trace_element_ind_after IS NULL ) )  AND  ( ( electrolyte_ind == electrolyte_ind_after AND electrolyte_ind is NOT NULL AND electrolyte_ind_after is NOT NULL ) OR ( electrolyte_ind IS NULL  AND   electrolyte_ind_after IS NULL ) )  AND  ( ( container_material_cd == container_material_cd_after AND container_material_cd is NOT NULL AND container_material_cd_after is NOT NULL ) OR ( container_material_cd IS NULL  AND   container_material_cd_after IS NULL ) )  AND  ( ( container_max_capacity == container_max_capacity_after AND container_max_capacity is NOT NULL AND container_max_capacity_after is NOT NULL ) OR ( container_max_capacity IS NULL  AND   container_max_capacity_after IS NULL ) )  AND  ( ( vehicle_ind == vehicle_ind_after AND vehicle_ind is NOT NULL AND vehicle_ind_after is NOT NULL ) OR ( vehicle_ind IS NULL  AND   vehicle_ind_after IS NULL ) )  AND  ( ( vehicle == vehicle_after AND vehicle is NOT NULL AND vehicle_after is NOT NULL ) OR ( vehicle IS NULL  AND   vehicle_after IS NULL ) )  AND  ( ( cocktail_ind == cocktail_ind_after AND cocktail_ind is NOT NULL AND cocktail_ind_after is NOT NULL ) OR ( cocktail_ind IS NULL  AND   cocktail_ind_after IS NULL ) )  AND  ( ( primary_vendor_nbr == primary_vendor_nbr_after AND primary_vendor_nbr is NOT NULL AND primary_vendor_nbr_after is NOT NULL ) OR ( primary_vendor_nbr IS NULL  AND   primary_vendor_nbr_after IS NULL ) )  AND  ( ( secondary_vendor_nbr == secondary_vendor_nbr_after AND secondary_vendor_nbr is NOT NULL AND secondary_vendor_nbr_after is NOT NULL ) OR ( secondary_vendor_nbr IS NULL  AND   secondary_vendor_nbr_after IS NULL ) )  AND  ( ( tertiary_vendor_nbr == tertiary_vendor_nbr_after AND tertiary_vendor_nbr is NOT NULL AND tertiary_vendor_nbr_after is NOT NULL ) OR ( tertiary_vendor_nbr IS NULL  AND   tertiary_vendor_nbr_after IS NULL ) )  AND  ( ( base_ind == base_ind_after AND base_ind is NOT NULL AND base_ind_after is NOT NULL ) OR ( base_ind IS NULL  AND   base_ind_after IS NULL ) )  AND  ( ( item_type == item_type_after AND item_type is NOT NULL AND item_type_after is NOT NULL ) OR ( item_type IS NULL  AND   item_type_after IS NULL ) )  AND  ( ( conc_dextrose_ind == conc_dextrose_ind_after AND conc_dextrose_ind is NOT NULL AND conc_dextrose_ind_after is NOT NULL ) OR ( conc_dextrose_ind IS NULL  AND   conc_dextrose_ind_after IS NULL ) )  AND  ( ( container_ind == container_ind_after AND container_ind is NOT NULL AND container_ind_after is NOT NULL ) OR ( container_ind IS NULL  AND   container_ind_after IS NULL ) )  AND  ( ( container_type == container_type_after AND container_type is NOT NULL AND container_type_after is NOT NULL ) OR ( container_type IS NULL  AND   container_type_after IS NULL ) )  AND  ( ( primary_vendor_name == primary_vendor_name_after AND primary_vendor_name is NOT NULL AND primary_vendor_name_after is NOT NULL ) OR ( primary_vendor_name IS NULL  AND   primary_vendor_name_after IS NULL ) )  AND  ( ( secondary_vendor_name == secondary_vendor_name_after AND secondary_vendor_name is NOT NULL AND secondary_vendor_name_after is NOT NULL ) OR ( secondary_vendor_name IS NULL  AND   secondary_vendor_name_after IS NULL ) )  AND  ( ( tertiary_vendor_name == tertiary_vendor_name_after AND tertiary_vendor_name is NOT NULL AND tertiary_vendor_name_after is NOT NULL ) OR ( tertiary_vendor_name IS NULL  AND   tertiary_vendor_name_after IS NULL ) )  AND  ( ( plx_drug_ind == plx_drug_ind_after AND plx_drug_ind is NOT NULL AND plx_drug_ind_after is NOT NULL ) OR ( plx_drug_ind IS NULL  AND   plx_drug_ind_after IS NULL ) )  AND  ( ( item_size == item_size_after AND item_size is NOT NULL AND item_size_after is NOT NULL ) OR ( item_size IS NULL  AND   item_size_after IS NULL ) )  AND  ( ( item_size_units == item_size_units_after AND item_size_units is NOT NULL AND item_size_units_after is NOT NULL ) OR ( item_size_units IS NULL  AND   item_size_units_after IS NULL ) )  AND  ( ( item_long_desc == item_long_desc_after AND item_long_desc is NOT NULL AND item_long_desc_after is NOT NULL ) OR ( item_long_desc IS NULL  AND   item_long_desc_after IS NULL ) )  AND  ( ( item_short_desc == item_short_desc_after AND item_short_desc is NOT NULL AND item_short_desc_after is NOT NULL ) OR ( item_short_desc IS NULL  AND   item_short_desc_after IS NULL ) )  AND  ( ( item_awp == item_awp_after AND item_awp is NOT NULL AND item_awp_after is NOT NULL ) OR ( item_awp IS NULL  AND   item_awp_after IS NULL ) )  AND  ( ( billing_multiplier == billing_multiplier_after AND billing_multiplier is NOT NULL AND billing_multiplier_after is NOT NULL ) OR ( billing_multiplier IS NULL  AND   billing_multiplier_after IS NULL ) )  AND  ( ( track_inventory_ind == track_inventory_ind_after AND track_inventory_ind is NOT NULL AND track_inventory_ind_after is NOT NULL ) OR ( track_inventory_ind IS NULL  AND   track_inventory_ind_after IS NULL ) )  AND  ( ( disease_state_ind == disease_state_ind_after AND disease_state_ind is NOT NULL AND disease_state_ind_after is NOT NULL ) OR ( disease_state_ind IS NULL  AND   disease_state_ind_after IS NULL ) )   AND  ( ( drug_inference_cd == drug_inference_cd_after AND drug_inference_cd is NOT NULL AND drug_inference_cd_after is NOT NULL ) OR ( drug_inference_cd IS NULL  AND   drug_inference_cd_after IS NULL ) )   AND  ( ( drug_min_price == drug_min_price_after AND drug_min_price is NOT NULL AND drug_min_price_after is NOT NULL ) OR ( drug_min_price IS NULL  AND   drug_min_price_after IS NULL ) )  AND  ( ( excl_drug_automation_ind == excl_drug_automation_ind_after AND excl_drug_automation_ind is NOT NULL AND excl_drug_automation_ind_after is NOT NULL ) OR ( excl_drug_automation_ind IS NULL  AND   excl_drug_automation_ind_after IS NULL ) ) AND ( ( excl_tbltp_count_ind == excl_tbltp_count_ind_after AND excl_tbltp_count_ind is NOT NULL AND excl_tbltp_count_ind_after is NOT NULL ) OR ( excl_tbltp_count_ind IS NULL  AND   excl_tbltp_count_ind_after IS NULL ) ) AND ( ( require_tbltp_clean == require_tbltp_clean_after AND require_tbltp_clean is NOT NULL AND require_tbltp_clean_after is NOT NULL ) OR ( require_tbltp_clean IS NULL  AND   require_tbltp_clean_after IS NULL ) ) AND ( ( thera_class_extd == thera_class_extd_after AND thera_class_extd is NOT NULL AND thera_class_extd_after is NOT NULL ) OR ( thera_class_extd IS NULL  AND  thera_class_extd_after IS NULL ) )  AND  ( ( hzrds_lvl_cd == hzrds_lvl_cd_after AND hzrds_lvl_cd is NOT NULL AND hzrds_lvl_cd_after is NOT NULL ) OR ( hzrds_lvl_cd IS NULL  AND   hzrds_lvl_cd_after IS NULL ) ) AND ( ( auth_generic_cd  == auth_generic_cd_after AND  auth_generic_cd  is NOT NULL AND  auth_generic_cd_after  is NOT NULL ) OR ( auth_generic_cd  IS NULL AND auth_generic_cd_after  IS NULL ) ) AND ( ( fda_ind  == fda_ind_after AND  fda_ind  is NOT NULL AND  fda_ind_after  is NOT NULL ) OR ( fda_ind  IS NULL AND fda_ind_after  IS NULL ) ) AND ( ( fda_ind_value  == fda_ind_value_after AND  fda_ind_value  is NOT NULL AND  fda_ind_value_after  is NOT NULL ) OR ( fda_ind_value  IS NULL AND fda_ind_value_after  IS NULL ) ) AND ( ( auth_ndc_upc_hri  == auth_ndc_upc_hri_after AND  auth_ndc_upc_hri  is NOT NULL AND  auth_ndc_upc_hri_after  is NOT NULL ) OR ( auth_ndc_upc_hri  IS NULL AND auth_ndc_upc_hri_after  IS NULL ) ) AND ( ( auth_gen_override_ind  == auth_gen_override_ind_after AND  auth_gen_override_ind  is NOT NULL AND  auth_gen_override_ind_after  is NOT NULL ) OR ( auth_gen_override_ind  IS NULL AND auth_gen_override_ind_after  IS NULL ) ) AND ( ( ddid  == ddid_after AND  ddid  is NOT NULL AND  ddid_after  is NOT NULL ) OR ( ddid  IS NULL AND ddid_after  IS NULL ) ) AND ( ( rxcui_type  == rxcui_type_after AND  rxcui_type  is NOT NULL AND  rxcui_type_after  is NOT NULL ) OR ( rxcui_type  IS NULL AND rxcui_type_after  IS NULL ) ) AND ( ( rxcui  == rxcui_after AND  rxcui  is NOT NULL AND  rxcui_after  is NOT NULL ) OR ( rxcui  IS NULL AND rxcui_after  IS NULL ) ) AND ( ( elsevier_pack_id  == elsevier_pack_id_after AND  elsevier_pack_id  is NOT NULL AND  elsevier_pack_id_after  is NOT NULL ) OR ( elsevier_pack_id  IS NULL AND elsevier_pack_id_after  IS NULL ) ) AND ( ( elsevier_prod_id  == elsevier_prod_id_after AND  elsevier_prod_id  is NOT NULL AND  elsevier_prod_id_after  is NOT NULL ) OR ( elsevier_prod_id  IS NULL AND elsevier_prod_id_after  IS NULL ) ) AND ( ( med_dosage_unit  == med_dosage_unit_after AND  med_dosage_unit  is NOT NULL AND  med_dosage_unit_after  is NOT NULL ) OR ( med_dosage_unit  IS NULL AND med_dosage_unit_after  IS NULL ) ) AND ( ( med_conv_factor  == med_conv_factor_after AND  med_conv_factor  is NOT NULL AND  med_conv_factor_after  is NOT NULL ) OR ( med_conv_factor  IS NULL AND med_conv_factor_after  IS NULL ) ) AND ( ( mme_calc_factor == mme_calc_factor_after AND mme_calc_factor  is NOT NULL AND mme_calc_factor_after is NOT NULL ) OR ( mme_calc_factor IS NULL AND mme_calc_factor_after  IS NULL ) ) )"

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr , cdc_rba_nbr , cdc_operation_type_cd , cdc_before_after_cd , cdc_txn_position_cd , edw_batch_id , drug_id , ndc_mfg , ndc_prod , ndc_pkg , sims_upc , repack_nbr , ndc_form_cd , ndc_prev_mfg , ndc_prev_prod , ndc_prev_pkg , prev_repack_nbr , ndc_prev_form_cd , id_form_cd , ndc_upc_hri , dur_ndc , prev_ndc_upc_hri , prev_id_form_cd , drug_class , drug_orange_book_rating , drug_name_cd , gppc , gen_typ_cd , gen_id_no , thera_class , lim_stabil , pack_descr , rx_otc_cd , maint_drug_ind , route_of_admin_cd , drug_generic_cd , drug_type_cd , drug_single_comb_cd , drug_storage_cond_cd , CONCAT(a_last_change_dttm,'.000000') AS a_last_change_dttm, a_protect_ind , product_name , product_name_suffix , product_name_ext , product_mddb_abbr , CONCAT(e_last_change_dttm,'.000000') AS e_last_change_dttm, e_protect_ind , gpi , gpi_name , CONCAT(g_last_change_dttm,'.000000') AS g_last_change_dttm , g_protect_ind , mfg_name , mfg_name_abbr , mfg_mddb_abbr , mfg_name_suffix , CONCAT(j_last_change_dttm,'.000000') AS j_last_change_dttm, j_protect_ind , drug_strength , drug_strength_uom , drug_dosage_form_cd , package_size , package_size_uom , package_qty , CONCAT(rx_to_otc_dttm,'.000000') AS rx_to_otc_dttm , CONCAT(l_last_change_dttm,'.000000') AS l_last_change_dttm , l_protect_ind ,  CONCAT(awp_dttm,'.000000') AS awp_dttm ,drug_counting_cell_id , awp_unit_price , CONCAT(r_last_change_dttm,'.000000') AS r_last_change_dttm , r_protect_ind , CONCAT(hcfa_dttm,'.000000') AS hcfa_dttm,  hcfa_unit_limit ,CONCAT(t_last_change_dttm,'.000000') AS t_last_change_dttm, t_protect_ind , product_name_abbr , drug_status_cd , CONCAT(drug_disc_dttm,'.000000') AS drug_disc_dttm, mfp_nbr , wic_nbr ,drug_ppi_ind , drug_min_disp_qty , default_sig , default_days_supply , expiration_days , drug_class_except_ind , ops_study_dept_nbr , drug_warehouse_ind , pricing_protect_ind , pr_daco_ind , pricing_override_drug , pricing_type , aac_unit_price , wac_unit_price , prorated_quantity , pricing_quantity , drug_shape_cd , drug_color_1_cd , drug_color_2_cd , drug_side_1 , drug_side_2 , billing_ndc , drug_comment_cd , default_smart_sig , drug_location_cd , drug_multihit_disp_ind , substitution_drug_id , drug_volume , precount_ind , precount_qty_1 , precount_qty_2 , dur_kdc_nbr , ud_uu_pkg_cd , create_user_id , CONCAT(create_dttm,'.000000') AS  create_dttm , update_user_id , CONCAT(update_dttm,'.000000') AS update_dttm , lbl_cmt_cd , substitution_prod_type , recon_water_qty , drug_spec_cmt_cd , fax_pbr_cmt_cd , promise_sub_drug_id , specialty_drug_ind , cash_disc_qty , piece_weight , stock_bottle_barcode , doses_per_pkg , pct_tot_disc_card , pet_med_ind , ltd_dist_cd , complicated_supplies_ind , specialty_review_ind , clinical_value_ind , required_supplies_ind , hcp_drug_mltht_disp_ind , mix_ind , drug_image_file_name , top_drug_ind , quality_alert_message , quality_alert_keywords , quality_alert_rule_ind , quality_alert_screen_ind , cash_disc_qty2 , cash_disc_qty3 , tip_ind , ref_drug_id , hcpc , pref_mfr_ind , med_guide_filename , med_guide_ind , item_class , item_group , item_formulary_ind , item_category , item_lob , item_conv_factor , item_list_price_sale , item_retail_price , item_pum , item_sub_group , item_sub_category , item_sum , primary_vendor_item_cost , primary_vendor_item_nbr , secndry_vendor_item_cost , secndry_vendor_item_nbr , tertry_vendor_item_cost , tertry_vendor_item_nbr , specific_gravity , concentration_nbr , concentration_units , lipids_ind , amino_acid_ind , poolable_ind , trace_element_ind , electrolyte_ind , container_material_cd , container_max_capacity , vehicle_ind , vehicle , cocktail_ind , primary_vendor_nbr , secondary_vendor_nbr , tertiary_vendor_nbr , base_ind , item_type , conc_dextrose_ind , container_ind , container_type , primary_vendor_name , secondary_vendor_name , tertiary_vendor_name , plx_drug_ind , item_size , item_size_units , item_long_desc , item_short_desc , item_awp , billing_multiplier , track_inventory_ind , disease_state_ind , drug_inference_cd , drug_min_price , excl_drug_automation_ind , excl_tbltp_count_ind, require_tbltp_clean , thera_class_extd , hzrds_lvl_cd ,auth_generic_cd ,fda_ind ,fda_ind_value ,auth_ndc_upc_hri ,auth_gen_override_ind ,ddid ,rxcui_type ,rxcui ,elsevier_pack_id ,elsevier_prod_id ,med_dosage_unit ,med_conv_factor ,mme_calc_factor" 
#, tracking_id, partition_column"


# COMMAND ----------

# #Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

# etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

# cutoff_records_output = spark.read \
#    .format("snowflake") \
#    .options(**options) \
#    .option("sfWarehouse", SNFL_WH) \
#    .option("sfDatabase", SNFK_ETL_DB) \
#    .option("query",etl_query)\
#    .load()

# #display(cutoff_records_output)

# BATCH_ID_CHK = """'""" + BATCH_ID + """'"""
# PROJ_ID_CHK = """'""" + PROJ_ID + """'"""

# cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_output.PROJ_NAME == PROJ_ID_CHK))
# #display(cutoff_records_filter)


# #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
# cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
#                                      .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
#                                      .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
#                                      .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))
# #display(cutoff_range_rx)
# rx_max = cutoff_range_rx.select("rx_max")
# #rx_max = rx_max.collect()[0][0]
# #print(rx_max.collect()[0][0])


# #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
# cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
#                                      .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
#                                      .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
#                                      .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
# #display(cutoff_range_trans)
# rx_trans_max = cutoff_range_trans.select("rx_trans_max")
# #rx_trans_max = rx_trans_max.collect()[0][0]
# #print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_src_gg_table where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_src_gg_table where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_src_gg_table where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  #display(nr_input_file_filter_rx)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual)
  nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck)
  nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual)
  nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

display(ded)


# COMMAND ----------

dedup_group.printSchema()

# COMMAND ----------


nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim( drug_id )) ==0) then drug_id else trim(drug_id)end) as drug_id,
(case when (LENGTH(trim( drug_id_after )) ==0) then drug_id_after else trim(drug_id_after)end) as drug_id_after,
(case when (LENGTH(trim( ndc_mfg )) ==0) then ndc_mfg else trim(ndc_mfg)end) as ndc_mfg,
(case when (LENGTH(trim( ndc_mfg_after )) ==0) then ndc_mfg_after else trim(ndc_mfg_after)end) as ndc_mfg_after,
(case when (LENGTH(trim( ndc_prod )) ==0) then ndc_prod else trim(ndc_prod)end) as ndc_prod,
(case when (LENGTH(trim( ndc_prod_after )) ==0) then ndc_prod_after else trim(ndc_prod_after)end) as ndc_prod_after,
(case when (LENGTH(trim( ndc_pkg )) ==0) then ndc_pkg else trim(ndc_pkg)end) as ndc_pkg,
(case when (LENGTH(trim( ndc_pkg_after )) ==0) then ndc_pkg_after else trim(ndc_pkg_after)end) as ndc_pkg_after,
(case when (LENGTH(trim( sims_upc )) ==0) then sims_upc else trim(sims_upc)end) as sims_upc,
(case when (LENGTH(trim( sims_upc_after )) ==0) then sims_upc_after else trim(sims_upc_after)end) as sims_upc_after,
(case when (LENGTH(trim( repack_nbr )) ==0) then repack_nbr else trim(repack_nbr)end) as repack_nbr,
(case when (LENGTH(trim( repack_nbr_after )) ==0) then repack_nbr_after else trim(repack_nbr_after)end) as repack_nbr_after,
(case when (LENGTH(trim( ndc_form_cd )) ==0) then ndc_form_cd else trim(ndc_form_cd)end) as ndc_form_cd,
(case when (LENGTH(trim( ndc_form_cd_after )) ==0) then ndc_form_cd_after else trim(ndc_form_cd_after)end) as ndc_form_cd_after,
(case when (LENGTH(trim( ndc_prev_mfg )) ==0) then ndc_prev_mfg else trim(ndc_prev_mfg)end) as ndc_prev_mfg,
(case when (LENGTH(trim( ndc_prev_mfg_after )) ==0) then ndc_prev_mfg_after else trim(ndc_prev_mfg_after)end) as ndc_prev_mfg_after,
(case when (LENGTH(trim( ndc_prev_prod )) ==0) then ndc_prev_prod else trim(ndc_prev_prod)end) as ndc_prev_prod,
(case when (LENGTH(trim( ndc_prev_prod_after )) ==0) then ndc_prev_prod_after else trim(ndc_prev_prod_after)end) as ndc_prev_prod_after,
(case when (LENGTH(trim( ndc_prev_pkg )) ==0) then ndc_prev_pkg else trim(ndc_prev_pkg)end) as ndc_prev_pkg,
(case when (LENGTH(trim( ndc_prev_pkg_after )) ==0) then ndc_prev_pkg_after else trim(ndc_prev_pkg_after)end) as ndc_prev_pkg_after,
(case when (LENGTH(trim( prev_repack_nbr )) ==0) then prev_repack_nbr else trim(prev_repack_nbr)end) as prev_repack_nbr,
(case when (LENGTH(trim( prev_repack_nbr_after )) ==0) then prev_repack_nbr_after else trim(prev_repack_nbr_after)end) as prev_repack_nbr_after,
(case when (LENGTH(trim( ndc_prev_form_cd )) ==0) then ndc_prev_form_cd else trim(ndc_prev_form_cd)end) as ndc_prev_form_cd,
(case when (LENGTH(trim( ndc_prev_form_cd_after )) ==0) then ndc_prev_form_cd_after else trim(ndc_prev_form_cd_after)end) as ndc_prev_form_cd_after,
(case when (LENGTH(trim( id_form_cd )) ==0) then id_form_cd else trim(id_form_cd)end) as id_form_cd,
(case when (LENGTH(trim( id_form_cd_after )) ==0) then id_form_cd_after else trim(id_form_cd_after)end) as id_form_cd_after,
(case when (LENGTH(trim( ndc_upc_hri )) ==0) then ndc_upc_hri else trim(ndc_upc_hri)end) as ndc_upc_hri,
(case when (LENGTH(trim( ndc_upc_hri_after )) ==0) then ndc_upc_hri_after else trim(ndc_upc_hri_after)end) as ndc_upc_hri_after,
(case when (LENGTH(trim( dur_ndc )) ==0) then dur_ndc else trim(dur_ndc)end) as dur_ndc,
(case when (LENGTH(trim( dur_ndc_after )) ==0) then dur_ndc_after else trim(dur_ndc_after)end) as dur_ndc_after,
(case when (LENGTH(trim( prev_ndc_upc_hri )) ==0) then prev_ndc_upc_hri else trim(prev_ndc_upc_hri)end) as prev_ndc_upc_hri,
(case when (LENGTH(trim( prev_ndc_upc_hri_after )) ==0) then prev_ndc_upc_hri_after else trim(prev_ndc_upc_hri_after)end) as prev_ndc_upc_hri_after,
(case when (LENGTH(trim( prev_id_form_cd )) ==0) then prev_id_form_cd else trim(prev_id_form_cd)end) as prev_id_form_cd,
(case when (LENGTH(trim( prev_id_form_cd_after )) ==0) then prev_id_form_cd_after else trim(prev_id_form_cd_after)end) as prev_id_form_cd_after,
(case when (LENGTH(trim( drug_class )) ==0) then drug_class else trim(drug_class)end) as drug_class,
(case when (LENGTH(trim( drug_class_after )) ==0) then drug_class_after else trim(drug_class_after)end) as drug_class_after,
(case when (LENGTH(trim( drug_orange_book_rating )) ==0) then drug_orange_book_rating else trim(drug_orange_book_rating)end) as drug_orange_book_rating,
(case when (LENGTH(trim( drug_orange_book_rating_after )) ==0) then drug_orange_book_rating_after else trim(drug_orange_book_rating_after)end) as drug_orange_book_rating_after,
(case when (LENGTH(trim( drug_name_cd )) ==0) then drug_name_cd else trim(drug_name_cd)end) as drug_name_cd,
(case when (LENGTH(trim( drug_name_cd_after )) ==0) then drug_name_cd_after else trim(drug_name_cd_after)end) as drug_name_cd_after,
(case when (LENGTH(trim( gppc )) ==0) then gppc else trim(gppc)end) as gppc,
(case when (LENGTH(trim( gppc_after )) ==0) then gppc_after else trim(gppc_after)end) as gppc_after,
(case when (LENGTH(trim( gen_typ_cd )) ==0) then gen_typ_cd else trim(gen_typ_cd)end) as gen_typ_cd,
(case when (LENGTH(trim( gen_typ_cd_after )) ==0) then gen_typ_cd_after else trim(gen_typ_cd_after)end) as gen_typ_cd_after,
(case when (LENGTH(trim( gen_id_no )) ==0) then gen_id_no else trim(gen_id_no)end) as gen_id_no,
(case when (LENGTH(trim( gen_id_no_after )) ==0) then gen_id_no_after else trim(gen_id_no_after)end) as gen_id_no_after,
(case when (LENGTH(trim( thera_class )) ==0) then thera_class else trim(thera_class)end) as thera_class,
(case when (LENGTH(trim( thera_class_after )) ==0) then thera_class_after else trim(thera_class_after)end) as thera_class_after,
(case when (LENGTH(trim( lim_stabil )) ==0) then lim_stabil else trim(lim_stabil)end) as lim_stabil,
(case when (LENGTH(trim( lim_stabil_after )) ==0) then lim_stabil_after else trim(lim_stabil_after)end) as lim_stabil_after,
(case when (LENGTH(trim( pack_descr )) ==0) then pack_descr else trim(pack_descr)end) as pack_descr,
(case when (LENGTH(trim( pack_descr_after )) ==0) then pack_descr_after else trim(pack_descr_after)end) as pack_descr_after,
(case when (LENGTH(trim( rx_otc_cd )) ==0) then rx_otc_cd else trim(rx_otc_cd)end) as rx_otc_cd,
(case when (LENGTH(trim( rx_otc_cd_after )) ==0) then rx_otc_cd_after else trim(rx_otc_cd_after)end) as rx_otc_cd_after,
(case when (LENGTH(trim( maint_drug_ind )) ==0) then maint_drug_ind else trim(maint_drug_ind)end) as maint_drug_ind,
(case when (LENGTH(trim( maint_drug_ind_after )) ==0) then maint_drug_ind_after else trim(maint_drug_ind_after)end) as maint_drug_ind_after,
(case when (LENGTH(trim( route_of_admin_cd )) ==0) then route_of_admin_cd else trim(route_of_admin_cd)end) as route_of_admin_cd,
(case when (LENGTH(trim( route_of_admin_cd_after )) ==0) then route_of_admin_cd_after else trim(route_of_admin_cd_after)end) as route_of_admin_cd_after,
(case when (LENGTH(trim( drug_generic_cd )) ==0) then drug_generic_cd else trim(drug_generic_cd)end) as drug_generic_cd,
(case when (LENGTH(trim( drug_generic_cd_after )) ==0) then drug_generic_cd_after else trim(drug_generic_cd_after)end) as drug_generic_cd_after,
(case when (LENGTH(trim( drug_type_cd )) ==0) then drug_type_cd else trim(drug_type_cd)end) as drug_type_cd,
(case when (LENGTH(trim( drug_type_cd_after )) ==0) then drug_type_cd_after else trim(drug_type_cd_after)end) as drug_type_cd_after,
(case when (LENGTH(trim( drug_single_comb_cd )) ==0) then drug_single_comb_cd else trim(drug_single_comb_cd)end) as drug_single_comb_cd,
(case when (LENGTH(trim( drug_single_comb_cd_after )) ==0) then drug_single_comb_cd_after else trim(drug_single_comb_cd_after)end) as drug_single_comb_cd_after,
(case when (LENGTH(trim( drug_storage_cond_cd )) ==0) then drug_storage_cond_cd else trim(drug_storage_cond_cd)end) as drug_storage_cond_cd,
(case when (LENGTH(trim( drug_storage_cond_cd_after )) ==0) then drug_storage_cond_cd_after else trim(drug_storage_cond_cd_after)end) as drug_storage_cond_cd_after,
(case when (LENGTH(trim( a_last_change_dttm )) ==0) then a_last_change_dttm else concat(substring(a_last_change_dttm,1,10),' ',substring(a_last_change_dttm,12,8))end) as a_last_change_dttm,
(case when (LENGTH(trim( a_last_change_dttm_after )) ==0) then a_last_change_dttm_after else concat(substring(a_last_change_dttm_after,1,10),' ',substring(a_last_change_dttm_after,12,8))end) as a_last_change_dttm_after,
(case when (LENGTH(trim( a_protect_ind )) ==0) then a_protect_ind else trim(a_protect_ind)end) as a_protect_ind,
(case when (LENGTH(trim( a_protect_ind_after )) ==0) then a_protect_ind_after else trim(a_protect_ind_after)end) as a_protect_ind_after,
(case when (LENGTH(trim( product_name )) ==0) then product_name else trim(product_name)end) as product_name,
(case when (LENGTH(trim( product_name_after )) ==0) then product_name_after else trim(product_name_after)end) as product_name_after,
(case when (LENGTH(trim( product_name_suffix )) ==0) then product_name_suffix else trim(product_name_suffix)end) as product_name_suffix,
(case when (LENGTH(trim( product_name_suffix_after )) ==0) then product_name_suffix_after else trim(product_name_suffix_after)end) as product_name_suffix_after,
(case when (LENGTH(trim( product_name_ext )) ==0) then product_name_ext else trim(product_name_ext)end) as product_name_ext,
(case when (LENGTH(trim( product_name_ext_after )) ==0) then product_name_ext_after else trim(product_name_ext_after)end) as product_name_ext_after,
(case when (LENGTH(trim( product_mddb_abbr )) ==0) then product_mddb_abbr else trim(product_mddb_abbr)end) as product_mddb_abbr,
(case when (LENGTH(trim( product_mddb_abbr_after )) ==0) then product_mddb_abbr_after else trim(product_mddb_abbr_after)end) as product_mddb_abbr_after,
(case when (LENGTH(trim( e_last_change_dttm )) ==0) then e_last_change_dttm else concat(substring(e_last_change_dttm,1,10),' ',substring(e_last_change_dttm,12,8))end) as e_last_change_dttm,
(case when (LENGTH(trim( e_last_change_dttm_after )) ==0) then e_last_change_dttm_after else concat(substring(e_last_change_dttm_after,1,10),' ',substring(e_last_change_dttm_after,12,8))end) as e_last_change_dttm_after,
(case when (LENGTH(trim( e_protect_ind )) ==0) then e_protect_ind else trim(e_protect_ind)end) as e_protect_ind,
(case when (LENGTH(trim( e_protect_ind_after )) ==0) then e_protect_ind_after else trim(e_protect_ind_after)end) as e_protect_ind_after,
(case when (LENGTH(trim( gpi )) ==0) then gpi else trim(gpi)end) as gpi,
(case when (LENGTH(trim( gpi_after )) ==0) then gpi_after else trim(gpi_after)end) as gpi_after,
(case when (LENGTH(trim( gpi_name )) ==0) then gpi_name else trim(gpi_name)end) as gpi_name,
(case when (LENGTH(trim( gpi_name_after )) ==0) then gpi_name_after else trim(gpi_name_after)end) as gpi_name_after,
(case when (LENGTH(trim( g_last_change_dttm )) ==0) then g_last_change_dttm else concat(substring(g_last_change_dttm,1,10),' ',substring(g_last_change_dttm,12,8))end) as g_last_change_dttm,
(case when (LENGTH(trim( g_last_change_dttm_after )) ==0) then g_last_change_dttm_after else concat(substring(g_last_change_dttm_after,1,10),' ',substring(g_last_change_dttm_after,12,8))end) as g_last_change_dttm_after,
(case when (LENGTH(trim( g_protect_ind )) ==0) then g_protect_ind else trim(g_protect_ind)end) as g_protect_ind,
(case when (LENGTH(trim( g_protect_ind_after )) ==0) then g_protect_ind_after else trim(g_protect_ind_after)end) as g_protect_ind_after,
(case when (LENGTH(trim( mfg_name )) ==0) then mfg_name else trim(mfg_name)end) as mfg_name,
(case when (LENGTH(trim( mfg_name_after )) ==0) then mfg_name_after else trim(mfg_name_after)end) as mfg_name_after,
(case when (LENGTH(trim( mfg_name_abbr )) ==0) then mfg_name_abbr else trim(mfg_name_abbr)end) as mfg_name_abbr,
(case when (LENGTH(trim( mfg_name_abbr_after )) ==0) then mfg_name_abbr_after else trim(mfg_name_abbr_after)end) as mfg_name_abbr_after,
(case when (LENGTH(trim( mfg_mddb_abbr )) ==0) then mfg_mddb_abbr else trim(mfg_mddb_abbr)end) as mfg_mddb_abbr,
(case when (LENGTH(trim( mfg_mddb_abbr_after )) ==0) then mfg_mddb_abbr_after else trim(mfg_mddb_abbr_after)end) as mfg_mddb_abbr_after,
(case when (LENGTH(trim( mfg_name_suffix )) ==0) then mfg_name_suffix else trim(mfg_name_suffix)end) as mfg_name_suffix,
(case when (LENGTH(trim( mfg_name_suffix_after )) ==0) then mfg_name_suffix_after else trim(mfg_name_suffix_after)end) as mfg_name_suffix_after,
(case when (LENGTH(trim( j_last_change_dttm )) ==0) then j_last_change_dttm else concat(substring(j_last_change_dttm,1,10),' ',substring(j_last_change_dttm,12,8))end) as j_last_change_dttm,
(case when (LENGTH(trim( j_last_change_dttm_after )) ==0) then j_last_change_dttm_after else concat(substring(j_last_change_dttm_after,1,10),' ',substring(j_last_change_dttm_after,12,8))end) as j_last_change_dttm_after,
(case when (LENGTH(trim( j_protect_ind )) ==0) then j_protect_ind else trim(j_protect_ind)end) as j_protect_ind,
(case when (LENGTH(trim( j_protect_ind_after )) ==0) then j_protect_ind_after else trim(j_protect_ind_after)end) as j_protect_ind_after,
(case when (LENGTH(trim( drug_strength )) ==0) then drug_strength else trim(drug_strength)end) as drug_strength,
(case when (LENGTH(trim( drug_strength_after )) ==0) then drug_strength_after else trim(drug_strength_after)end) as drug_strength_after,
(case when (LENGTH(trim( drug_strength_uom )) ==0) then drug_strength_uom else trim(drug_strength_uom)end) as drug_strength_uom,
(case when (LENGTH(trim( drug_strength_uom_after )) ==0) then drug_strength_uom_after else trim(drug_strength_uom_after)end) as drug_strength_uom_after,
(case when (LENGTH(trim( drug_dosage_form_cd )) ==0) then drug_dosage_form_cd else trim(drug_dosage_form_cd)end) as drug_dosage_form_cd,
(case when (LENGTH(trim( drug_dosage_form_cd_after )) ==0) then drug_dosage_form_cd_after else trim(drug_dosage_form_cd_after)end) as drug_dosage_form_cd_after,
(case when (LENGTH(trim( package_size )) ==0) then package_size else trim(package_size)end) as package_size,
(case when (LENGTH(trim( package_size_after )) ==0) then package_size_after else trim(package_size_after)end) as package_size_after,
(case when (LENGTH(trim( package_size_uom )) ==0) then package_size_uom else trim(package_size_uom)end) as package_size_uom,
(case when (LENGTH(trim( package_size_uom_after )) ==0) then package_size_uom_after else trim(package_size_uom_after)end) as package_size_uom_after,
(case when (LENGTH(trim( package_qty )) ==0) then package_qty else trim(package_qty)end) as package_qty,
(case when (LENGTH(trim( package_qty_after )) ==0) then package_qty_after else trim(package_qty_after)end) as package_qty_after,
(case when (LENGTH(trim( rx_to_otc_dttm )) ==0) then rx_to_otc_dttm else concat(substring(rx_to_otc_dttm,1,10),' ',substring(rx_to_otc_dttm,12,8))end) as rx_to_otc_dttm,
(case when (LENGTH(trim( rx_to_otc_dttm_after )) ==0) then rx_to_otc_dttm_after else concat(substring(rx_to_otc_dttm_after,1,10),' ',substring(rx_to_otc_dttm_after,12,8))end) as rx_to_otc_dttm_after,
(case when (LENGTH(trim( l_last_change_dttm )) ==0) then l_last_change_dttm else concat(substring(l_last_change_dttm,1,10),' ',substring(l_last_change_dttm,12,8))end) as l_last_change_dttm,
(case when (LENGTH(trim( l_last_change_dttm_after )) ==0) then l_last_change_dttm_after else concat(substring(l_last_change_dttm_after,1,10),' ',substring(l_last_change_dttm_after,12,8))end) as l_last_change_dttm_after,
(case when (LENGTH(trim( l_protect_ind )) ==0) then l_protect_ind else trim(l_protect_ind)end) as l_protect_ind,
(case when (LENGTH(trim( l_protect_ind_after )) ==0) then l_protect_ind_after else trim(l_protect_ind_after)end) as l_protect_ind_after,
(case when (LENGTH(trim( awp_dttm )) ==0) then awp_dttm else concat(substring(awp_dttm,1,10),' ',substring(awp_dttm,12,8))end) as awp_dttm,
(case when (LENGTH(trim( awp_dttm_after )) ==0) then awp_dttm_after else concat(substring(awp_dttm_after,1,10),' ',substring(awp_dttm_after,12,8))end) as awp_dttm_after,
(case when (LENGTH(trim( drug_counting_cell_id )) ==0) then drug_counting_cell_id else trim(drug_counting_cell_id)end) as drug_counting_cell_id,
(case when (LENGTH(trim( drug_counting_cell_id_after )) ==0) then drug_counting_cell_id_after else trim(drug_counting_cell_id_after)end) as drug_counting_cell_id_after,
(case when (LENGTH(trim( awp_unit_price )) ==0) then awp_unit_price else trim(awp_unit_price)end) as awp_unit_price,
(case when (LENGTH(trim( awp_unit_price_after )) ==0) then awp_unit_price_after else trim(awp_unit_price_after)end) as awp_unit_price_after,
(case when (LENGTH(trim( r_last_change_dttm )) ==0) then r_last_change_dttm else concat(substring(r_last_change_dttm,1,10),' ',substring(r_last_change_dttm,12,8))end) as r_last_change_dttm,
(case when (LENGTH(trim( r_last_change_dttm_after )) ==0) then r_last_change_dttm_after else concat(substring(r_last_change_dttm_after,1,10),' ',substring(r_last_change_dttm_after,12,8))end) as r_last_change_dttm_after,
(case when (LENGTH(trim( r_protect_ind )) ==0) then r_protect_ind else trim(r_protect_ind)end) as r_protect_ind,
(case when (LENGTH(trim( r_protect_ind_after )) ==0) then r_protect_ind_after else trim(r_protect_ind_after)end) as r_protect_ind_after,
(case when (LENGTH(trim( hcfa_dttm )) ==0) then hcfa_dttm else concat(substring(hcfa_dttm,1,10),' ',substring(hcfa_dttm,12,8))end) as hcfa_dttm,
(case when (LENGTH(trim( hcfa_dttm_after )) ==0) then hcfa_dttm_after else concat(substring(hcfa_dttm_after,1,10),' ',substring(hcfa_dttm_after,12,8))end) as hcfa_dttm_after,
(case when (LENGTH(trim( hcfa_unit_limit )) ==0) then hcfa_unit_limit else trim(hcfa_unit_limit)end) as hcfa_unit_limit,
(case when (LENGTH(trim( hcfa_unit_limit_after )) ==0) then hcfa_unit_limit_after else trim(hcfa_unit_limit_after)end) as hcfa_unit_limit_after,
(case when (LENGTH(trim( t_last_change_dttm )) ==0) then t_last_change_dttm else concat(substring(t_last_change_dttm,1,10),' ',substring(t_last_change_dttm,12,8))end) as t_last_change_dttm,
(case when (LENGTH(trim( t_last_change_dttm_after )) ==0) then t_last_change_dttm_after else concat(substring(t_last_change_dttm_after,1,10),' ',substring(t_last_change_dttm_after,12,8))end) as t_last_change_dttm_after,
(case when (LENGTH(trim( t_protect_ind )) ==0) then t_protect_ind else trim(t_protect_ind)end) as t_protect_ind,
(case when (LENGTH(trim( t_protect_ind_after )) ==0) then t_protect_ind_after else trim(t_protect_ind_after)end) as t_protect_ind_after,
(case when (LENGTH(trim( product_name_abbr )) ==0) then product_name_abbr else trim(product_name_abbr)end) as product_name_abbr,
(case when (LENGTH(trim( product_name_abbr_after )) ==0) then product_name_abbr_after else trim(product_name_abbr_after)end) as product_name_abbr_after,
(case when (LENGTH(trim( drug_status_cd )) ==0) then drug_status_cd else trim(drug_status_cd)end) as drug_status_cd,
(case when (LENGTH(trim( drug_status_cd_after )) ==0) then drug_status_cd_after else trim(drug_status_cd_after)end) as drug_status_cd_after,
(case when (LENGTH(trim( drug_disc_dttm )) ==0) then drug_disc_dttm else concat(substring(drug_disc_dttm,1,10),' ',substring(drug_disc_dttm,12,8))end) as drug_disc_dttm,
(case when (LENGTH(trim( drug_disc_dttm_after )) ==0) then drug_disc_dttm_after else concat(substring(drug_disc_dttm_after,1,10),' ',substring(drug_disc_dttm_after,12,8))end) as drug_disc_dttm_after,
(case when (LENGTH(trim( mfp_nbr )) ==0) then mfp_nbr else trim(mfp_nbr)end) as mfp_nbr,
(case when (LENGTH(trim( mfp_nbr_after )) ==0) then mfp_nbr_after else trim(mfp_nbr_after)end) as mfp_nbr_after,
(case when (LENGTH(trim( wic_nbr )) ==0) then wic_nbr else trim(wic_nbr)end) as wic_nbr,
(case when (LENGTH(trim( wic_nbr_after )) ==0) then wic_nbr_after else trim(wic_nbr_after)end) as wic_nbr_after,
(case when (LENGTH(trim( drug_ppi_ind )) ==0) then drug_ppi_ind else trim(drug_ppi_ind)end) as drug_ppi_ind,
(case when (LENGTH(trim( drug_ppi_ind_after )) ==0) then drug_ppi_ind_after else trim(drug_ppi_ind_after)end) as drug_ppi_ind_after,
(case when (LENGTH(trim( drug_min_disp_qty )) ==0) then drug_min_disp_qty else trim(drug_min_disp_qty)end) as drug_min_disp_qty,
(case when (LENGTH(trim( drug_min_disp_qty_after )) ==0) then drug_min_disp_qty_after else trim(drug_min_disp_qty_after)end) as drug_min_disp_qty_after,
(case when (LENGTH(trim( default_sig )) ==0) then default_sig else trim(default_sig)end) as default_sig,
(case when (LENGTH(trim( default_sig_after )) ==0) then default_sig_after else trim(default_sig_after)end) as default_sig_after,
(case when (LENGTH(trim( default_days_supply )) ==0) then default_days_supply else trim(default_days_supply)end) as default_days_supply,
(case when (LENGTH(trim( default_days_supply_after )) ==0) then default_days_supply_after else trim(default_days_supply_after)end) as default_days_supply_after,
(case when (LENGTH(trim( expiration_days )) ==0) then expiration_days else trim(expiration_days)end) as expiration_days,
(case when (LENGTH(trim( expiration_days_after )) ==0) then expiration_days_after else trim(expiration_days_after)end) as expiration_days_after,
(case when (LENGTH(trim( drug_class_except_ind )) ==0) then drug_class_except_ind else trim(drug_class_except_ind)end) as drug_class_except_ind,
(case when (LENGTH(trim( drug_class_except_ind_after )) ==0) then drug_class_except_ind_after else trim(drug_class_except_ind_after)end) as drug_class_except_ind_after,
(case when (LENGTH(trim( ops_study_dept_nbr )) ==0) then ops_study_dept_nbr else trim(ops_study_dept_nbr)end) as ops_study_dept_nbr,
(case when (LENGTH(trim( ops_study_dept_nbr_after )) ==0) then ops_study_dept_nbr_after else trim(ops_study_dept_nbr_after)end) as ops_study_dept_nbr_after,
(case when (LENGTH(trim( drug_warehouse_ind )) ==0) then drug_warehouse_ind else trim(drug_warehouse_ind)end) as drug_warehouse_ind,
(case when (LENGTH(trim( drug_warehouse_ind_after )) ==0) then drug_warehouse_ind_after else trim(drug_warehouse_ind_after)end) as drug_warehouse_ind_after,
(case when (LENGTH(trim( pricing_protect_ind )) ==0) then pricing_protect_ind else trim(pricing_protect_ind)end) as pricing_protect_ind,
(case when (LENGTH(trim( pricing_protect_ind_after )) ==0) then pricing_protect_ind_after else trim(pricing_protect_ind_after)end) as pricing_protect_ind_after,
(case when (LENGTH(trim( pr_daco_ind )) ==0) then pr_daco_ind else trim(pr_daco_ind)end) as pr_daco_ind,
(case when (LENGTH(trim( pr_daco_ind_after )) ==0) then pr_daco_ind_after else trim(pr_daco_ind_after)end) as pr_daco_ind_after,
(case when (LENGTH(trim( pricing_override_drug )) ==0) then pricing_override_drug else trim(pricing_override_drug)end) as pricing_override_drug,
(case when (LENGTH(trim( pricing_override_drug_after )) ==0) then pricing_override_drug_after else trim(pricing_override_drug_after)end) as pricing_override_drug_after,
(case when (LENGTH(trim( pricing_type )) ==0) then pricing_type else trim(pricing_type)end) as pricing_type,
(case when (LENGTH(trim( pricing_type_after )) ==0) then pricing_type_after else trim(pricing_type_after)end) as pricing_type_after,
(case when (LENGTH(trim( aac_unit_price )) ==0) then aac_unit_price else trim(aac_unit_price)end) as aac_unit_price,
(case when (LENGTH(trim( aac_unit_price_after )) ==0) then aac_unit_price_after else trim(aac_unit_price_after)end) as aac_unit_price_after,
(case when (LENGTH(trim( wac_unit_price )) ==0) then wac_unit_price else trim(wac_unit_price)end) as wac_unit_price,
(case when (LENGTH(trim( wac_unit_price_after )) ==0) then wac_unit_price_after else trim(wac_unit_price_after)end) as wac_unit_price_after,
(case when (LENGTH(trim( prorated_quantity )) ==0) then prorated_quantity else trim(prorated_quantity)end) as prorated_quantity,
(case when (LENGTH(trim( prorated_quantity_after )) ==0) then prorated_quantity_after else trim(prorated_quantity_after)end) as prorated_quantity_after,
(case when (LENGTH(trim( pricing_quantity )) ==0) then pricing_quantity else trim(pricing_quantity)end) as pricing_quantity,
(case when (LENGTH(trim( pricing_quantity_after )) ==0) then pricing_quantity_after else trim(pricing_quantity_after)end) as pricing_quantity_after,
(case when (LENGTH(trim( drug_shape_cd )) ==0) then drug_shape_cd else trim(drug_shape_cd)end) as drug_shape_cd,
(case when (LENGTH(trim( drug_shape_cd_after )) ==0) then drug_shape_cd_after else trim(drug_shape_cd_after)end) as drug_shape_cd_after,
(case when (LENGTH(trim( drug_color_1_cd )) ==0) then drug_color_1_cd else trim(drug_color_1_cd)end) as drug_color_1_cd,
(case when (LENGTH(trim( drug_color_1_cd_after )) ==0) then drug_color_1_cd_after else trim(drug_color_1_cd_after)end) as drug_color_1_cd_after,
(case when (LENGTH(trim( drug_color_2_cd )) ==0) then drug_color_2_cd else trim(drug_color_2_cd)end) as drug_color_2_cd,
(case when (LENGTH(trim( drug_color_2_cd_after )) ==0) then drug_color_2_cd_after else trim(drug_color_2_cd_after)end) as drug_color_2_cd_after,
(case when (LENGTH(trim( drug_side_1 )) ==0) then drug_side_1 else trim(drug_side_1)end) as drug_side_1,
(case when (LENGTH(trim( drug_side_1_after )) ==0) then drug_side_1_after else trim(drug_side_1_after)end) as drug_side_1_after,
(case when (LENGTH(trim( drug_side_2 )) ==0) then drug_side_2 else trim(drug_side_2)end) as drug_side_2,
(case when (LENGTH(trim( drug_side_2_after )) ==0) then drug_side_2_after else trim(drug_side_2_after)end) as drug_side_2_after,
(case when (LENGTH(trim( billing_ndc )) ==0) then billing_ndc else trim(billing_ndc)end) as billing_ndc,
(case when (LENGTH(trim( billing_ndc_after )) ==0) then billing_ndc_after else trim(billing_ndc_after)end) as billing_ndc_after,
(case when (LENGTH(trim( drug_comment_cd )) ==0) then drug_comment_cd else trim(drug_comment_cd)end) as drug_comment_cd,
(case when (LENGTH(trim( drug_comment_cd_after )) ==0) then drug_comment_cd_after else trim(drug_comment_cd_after)end) as drug_comment_cd_after,
(case when (LENGTH(trim( default_smart_sig )) ==0) then default_smart_sig else trim(default_smart_sig)end) as default_smart_sig,
(case when (LENGTH(trim( default_smart_sig_after )) ==0) then default_smart_sig_after else trim(default_smart_sig_after)end) as default_smart_sig_after,
(case when (LENGTH(trim( drug_location_cd )) ==0) then drug_location_cd else trim(drug_location_cd)end) as drug_location_cd,
(case when (LENGTH(trim( drug_location_cd_after )) ==0) then drug_location_cd_after else trim(drug_location_cd_after)end) as drug_location_cd_after,
(case when (LENGTH(trim( drug_multihit_disp_ind )) ==0) then drug_multihit_disp_ind else trim(drug_multihit_disp_ind)end) as drug_multihit_disp_ind,
(case when (LENGTH(trim( drug_multihit_disp_ind_after )) ==0) then drug_multihit_disp_ind_after else trim(drug_multihit_disp_ind_after)end) as drug_multihit_disp_ind_after,
(case when (LENGTH(trim( substitution_drug_id )) ==0) then substitution_drug_id else trim(substitution_drug_id)end) as substitution_drug_id,
(case when (LENGTH(trim( substitution_drug_id_after )) ==0) then substitution_drug_id_after else trim(substitution_drug_id_after)end) as substitution_drug_id_after,
(case when (LENGTH(trim( drug_volume )) ==0) then drug_volume else trim(drug_volume)end) as drug_volume,
(case when (LENGTH(trim( drug_volume_after )) ==0) then drug_volume_after else trim(drug_volume_after)end) as drug_volume_after,
(case when (LENGTH(trim( precount_ind )) ==0) then precount_ind else trim(precount_ind)end) as precount_ind,
(case when (LENGTH(trim( precount_ind_after )) ==0) then precount_ind_after else trim(precount_ind_after)end) as precount_ind_after,
(case when (LENGTH(trim( precount_qty_1 )) ==0) then precount_qty_1 else trim(precount_qty_1)end) as precount_qty_1,
(case when (LENGTH(trim( precount_qty_1_after )) ==0) then precount_qty_1_after else trim(precount_qty_1_after)end) as precount_qty_1_after,
(case when (LENGTH(trim( precount_qty_2 )) ==0) then precount_qty_2 else trim(precount_qty_2)end) as precount_qty_2,
(case when (LENGTH(trim( precount_qty_2_after )) ==0) then precount_qty_2_after else trim(precount_qty_2_after)end) as precount_qty_2_after,
(case when (LENGTH(trim( dur_kdc_nbr )) ==0) then dur_kdc_nbr else trim(dur_kdc_nbr)end) as dur_kdc_nbr,
(case when (LENGTH(trim( dur_kdc_nbr_after )) ==0) then dur_kdc_nbr_after else trim(dur_kdc_nbr_after)end) as dur_kdc_nbr_after,
(case when (LENGTH(trim( ud_uu_pkg_cd )) ==0) then ud_uu_pkg_cd else trim(ud_uu_pkg_cd)end) as ud_uu_pkg_cd,
(case when (LENGTH(trim( ud_uu_pkg_cd_after )) ==0) then ud_uu_pkg_cd_after else trim(ud_uu_pkg_cd_after)end) as ud_uu_pkg_cd_after,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id_after,
(case when (LENGTH(trim( create_dttm )) ==0) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8))end) as create_dttm,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8))end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id_after,
(case when (LENGTH(trim( update_dttm )) ==0) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8))end) as update_dttm,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8))end) as update_dttm_after,
(case when (LENGTH(trim( lbl_cmt_cd )) ==0) then lbl_cmt_cd else trim(lbl_cmt_cd)end) as lbl_cmt_cd,
(case when (LENGTH(trim( lbl_cmt_cd_after )) ==0) then lbl_cmt_cd_after else trim(lbl_cmt_cd_after)end) as lbl_cmt_cd_after,
(case when (LENGTH(trim( substitution_prod_type )) ==0) then substitution_prod_type else trim(substitution_prod_type)end) as substitution_prod_type,
(case when (LENGTH(trim( substitution_prod_type_after )) ==0) then substitution_prod_type_after else trim(substitution_prod_type_after)end) as substitution_prod_type_after,
(case when (LENGTH(trim( recon_water_qty )) ==0) then recon_water_qty else trim(recon_water_qty)end) as recon_water_qty,
(case when (LENGTH(trim( recon_water_qty_after )) ==0) then recon_water_qty_after else trim(recon_water_qty_after)end) as recon_water_qty_after,
(case when (LENGTH(trim( drug_spec_cmt_cd )) ==0) then drug_spec_cmt_cd else trim(drug_spec_cmt_cd)end) as drug_spec_cmt_cd,
(case when (LENGTH(trim( drug_spec_cmt_cd_after )) ==0) then drug_spec_cmt_cd_after else trim(drug_spec_cmt_cd_after)end) as drug_spec_cmt_cd_after,
(case when (LENGTH(trim( fax_pbr_cmt_cd )) ==0) then fax_pbr_cmt_cd else trim(fax_pbr_cmt_cd)end) as fax_pbr_cmt_cd,
(case when (LENGTH(trim( fax_pbr_cmt_cd_after )) ==0) then fax_pbr_cmt_cd_after else trim(fax_pbr_cmt_cd_after)end) as fax_pbr_cmt_cd_after,
(case when (LENGTH(trim( promise_sub_drug_id )) ==0) then promise_sub_drug_id else trim(promise_sub_drug_id)end) as promise_sub_drug_id,
(case when (LENGTH(trim( promise_sub_drug_id_after )) ==0) then promise_sub_drug_id_after else trim(promise_sub_drug_id_after)end) as promise_sub_drug_id_after,
(case when (LENGTH(trim( specialty_drug_ind )) ==0) then specialty_drug_ind else trim(specialty_drug_ind)end) as specialty_drug_ind,
(case when (LENGTH(trim( specialty_drug_ind_after )) ==0) then specialty_drug_ind_after else trim(specialty_drug_ind_after)end) as specialty_drug_ind_after,
(case when (LENGTH(trim( cash_disc_qty )) ==0) then cash_disc_qty else trim(cash_disc_qty)end) as cash_disc_qty,
(case when (LENGTH(trim( cash_disc_qty_after )) ==0) then cash_disc_qty_after else trim(cash_disc_qty_after)end) as cash_disc_qty_after,
(case when (LENGTH(trim( piece_weight )) ==0) then piece_weight else trim(piece_weight)end) as piece_weight,
(case when (LENGTH(trim( piece_weight_after )) ==0) then piece_weight_after else trim(piece_weight_after)end) as piece_weight_after,
(case when (LENGTH(trim( stock_bottle_barcode )) ==0) then stock_bottle_barcode else trim(stock_bottle_barcode)end) as stock_bottle_barcode,
(case when (LENGTH(trim( stock_bottle_barcode_after )) ==0) then stock_bottle_barcode_after else trim(stock_bottle_barcode_after)end) as stock_bottle_barcode_after,
(case when (LENGTH(trim( doses_per_pkg )) ==0) then doses_per_pkg else trim(doses_per_pkg)end) as doses_per_pkg,
(case when (LENGTH(trim( doses_per_pkg_after )) ==0) then doses_per_pkg_after else trim(doses_per_pkg_after)end) as doses_per_pkg_after,
(case when (LENGTH(trim( pct_tot_disc_card )) ==0) then pct_tot_disc_card else trim(pct_tot_disc_card)end) as pct_tot_disc_card,
(case when (LENGTH(trim( pct_tot_disc_card_after )) ==0) then pct_tot_disc_card_after else trim(pct_tot_disc_card_after)end) as pct_tot_disc_card_after,
(case when (LENGTH(trim( pet_med_ind )) ==0) then pet_med_ind else trim(pet_med_ind)end) as pet_med_ind,
(case when (LENGTH(trim( pet_med_ind_after )) ==0) then pet_med_ind_after else trim(pet_med_ind_after)end) as pet_med_ind_after,
(case when (LENGTH(trim( ltd_dist_cd )) ==0) then ltd_dist_cd else trim(ltd_dist_cd)end) as ltd_dist_cd,
(case when (LENGTH(trim( ltd_dist_cd_after )) ==0) then ltd_dist_cd_after else trim(ltd_dist_cd_after)end) as ltd_dist_cd_after,
(case when (LENGTH(trim( complicated_supplies_ind )) ==0) then complicated_supplies_ind else trim(complicated_supplies_ind)end) as complicated_supplies_ind,
(case when (LENGTH(trim( complicated_supplies_ind_after )) ==0) then complicated_supplies_ind_after else trim(complicated_supplies_ind_after)end) as complicated_supplies_ind_after,
(case when (LENGTH(trim( specialty_review_ind )) ==0) then specialty_review_ind else trim(specialty_review_ind)end) as specialty_review_ind,
(case when (LENGTH(trim( specialty_review_ind_after )) ==0) then specialty_review_ind_after else trim(specialty_review_ind_after)end) as specialty_review_ind_after,
(case when (LENGTH(trim( clinical_value_ind )) ==0) then clinical_value_ind else trim(clinical_value_ind)end) as clinical_value_ind,
(case when (LENGTH(trim( clinical_value_ind_after )) ==0) then clinical_value_ind_after else trim(clinical_value_ind_after)end) as clinical_value_ind_after,
(case when (LENGTH(trim( required_supplies_ind )) ==0) then required_supplies_ind else trim(required_supplies_ind)end) as required_supplies_ind,
(case when (LENGTH(trim( required_supplies_ind_after )) ==0) then required_supplies_ind_after else trim(required_supplies_ind_after)end) as required_supplies_ind_after,
(case when (LENGTH(trim( hcp_drug_mltht_disp_ind )) ==0) then hcp_drug_mltht_disp_ind else trim(hcp_drug_mltht_disp_ind)end) as hcp_drug_mltht_disp_ind,
(case when (LENGTH(trim( hcp_drug_mltht_disp_ind_after )) ==0) then hcp_drug_mltht_disp_ind_after else trim(hcp_drug_mltht_disp_ind_after)end) as hcp_drug_mltht_disp_ind_after,
(case when (LENGTH(trim( mix_ind )) ==0) then mix_ind else trim(mix_ind)end) as mix_ind,
(case when (LENGTH(trim( mix_ind_after )) ==0) then mix_ind_after else trim(mix_ind_after)end) as mix_ind_after,
(case when (LENGTH(trim( drug_image_file_name )) ==0) then drug_image_file_name else trim(drug_image_file_name)end) as drug_image_file_name,
(case when (LENGTH(trim( drug_image_file_name_after )) ==0) then drug_image_file_name_after else trim(drug_image_file_name_after)end) as drug_image_file_name_after,
(case when (LENGTH(trim( top_drug_ind )) ==0) then top_drug_ind else trim(top_drug_ind)end) as top_drug_ind,
(case when (LENGTH(trim( top_drug_ind_after )) ==0) then top_drug_ind_after else trim(top_drug_ind_after)end) as top_drug_ind_after,
(case when (LENGTH(trim( quality_alert_message )) ==0) then quality_alert_message else trim(quality_alert_message)end) as quality_alert_message,
(case when (LENGTH(trim( quality_alert_message_after )) ==0) then quality_alert_message_after else trim(quality_alert_message_after)end) as quality_alert_message_after,
(case when (LENGTH(trim( quality_alert_keywords )) ==0) then quality_alert_keywords else trim(quality_alert_keywords)end) as quality_alert_keywords,
(case when (LENGTH(trim( quality_alert_keywords_after )) ==0) then quality_alert_keywords_after else trim(quality_alert_keywords_after)end) as quality_alert_keywords_after,
(case when (LENGTH(trim( quality_alert_rule_ind )) ==0) then quality_alert_rule_ind else trim(quality_alert_rule_ind)end) as quality_alert_rule_ind,
(case when (LENGTH(trim( quality_alert_rule_ind_after )) ==0) then quality_alert_rule_ind_after else trim(quality_alert_rule_ind_after)end) as quality_alert_rule_ind_after,
(case when (LENGTH(trim( quality_alert_screen_ind )) ==0) then quality_alert_screen_ind else trim(quality_alert_screen_ind)end) as quality_alert_screen_ind,
(case when (LENGTH(trim( quality_alert_screen_ind_after )) ==0) then quality_alert_screen_ind_after else trim(quality_alert_screen_ind_after)end) as quality_alert_screen_ind_after,
(case when (LENGTH(trim( cash_disc_qty2 )) ==0) then cash_disc_qty2 else trim(cash_disc_qty2)end) as cash_disc_qty2,
(case when (LENGTH(trim( cash_disc_qty2_after )) ==0) then cash_disc_qty2_after else trim(cash_disc_qty2_after)end) as cash_disc_qty2_after,
(case when (LENGTH(trim( cash_disc_qty3 )) ==0) then cash_disc_qty3 else trim(cash_disc_qty3)end) as cash_disc_qty3,
(case when (LENGTH(trim( cash_disc_qty3_after )) ==0) then cash_disc_qty3_after else trim(cash_disc_qty3_after)end) as cash_disc_qty3_after,
(case when (LENGTH(trim( tip_ind )) ==0) then tip_ind else trim(tip_ind)end) as tip_ind,
(case when (LENGTH(trim( tip_ind_after )) ==0) then tip_ind_after else trim(tip_ind_after)end) as tip_ind_after,
(case when (LENGTH(trim( ref_drug_id )) ==0) then ref_drug_id else trim(ref_drug_id)end) as ref_drug_id,
(case when (LENGTH(trim( ref_drug_id_after )) ==0) then ref_drug_id_after else trim(ref_drug_id_after)end) as ref_drug_id_after,
(case when (LENGTH(trim( hcpc )) ==0) then hcpc else trim(hcpc)end) as hcpc,
(case when (LENGTH(trim( hcpc_after )) ==0) then hcpc_after else trim(hcpc_after)end) as hcpc_after,
(case when (LENGTH(trim( pref_mfr_ind )) ==0) then pref_mfr_ind else trim(pref_mfr_ind)end) as pref_mfr_ind,
(case when (LENGTH(trim( pref_mfr_ind_after )) ==0) then pref_mfr_ind_after else trim(pref_mfr_ind_after)end) as pref_mfr_ind_after,
(case when (LENGTH(trim( med_guide_filename )) ==0) then med_guide_filename else trim(med_guide_filename)end) as med_guide_filename,
(case when (LENGTH(trim( med_guide_filename_after )) ==0) then med_guide_filename_after else trim(med_guide_filename_after)end) as med_guide_filename_after,
(case when (LENGTH(trim( med_guide_ind )) ==0) then med_guide_ind else trim(med_guide_ind)end) as med_guide_ind,
(case when (LENGTH(trim( med_guide_ind_after )) ==0) then med_guide_ind_after else trim(med_guide_ind_after)end) as med_guide_ind_after,
(case when (LENGTH(trim( item_class )) ==0) then item_class else trim(item_class)end) as item_class,
(case when (LENGTH(trim( item_class_after )) ==0) then item_class_after else trim(item_class_after)end) as item_class_after,
(case when (LENGTH(trim( item_group )) ==0) then item_group else trim(item_group)end) as item_group,
(case when (LENGTH(trim( item_group_after )) ==0) then item_group_after else trim(item_group_after)end) as item_group_after,
(case when (LENGTH(trim( item_formulary_ind )) ==0) then item_formulary_ind else trim(item_formulary_ind)end) as item_formulary_ind,
(case when (LENGTH(trim( item_formulary_ind_after )) ==0) then item_formulary_ind_after else trim(item_formulary_ind_after)end) as item_formulary_ind_after,
(case when (LENGTH(trim( item_category )) ==0) then item_category else trim(item_category)end) as item_category,
(case when (LENGTH(trim( item_category_after )) ==0) then item_category_after else trim(item_category_after)end) as item_category_after,
(case when (LENGTH(trim( item_lob )) ==0) then item_lob else trim(item_lob)end) as item_lob,
(case when (LENGTH(trim( item_lob_after )) ==0) then item_lob_after else trim(item_lob_after)end) as item_lob_after,
(case when (LENGTH(trim( item_conv_factor )) ==0) then item_conv_factor else trim(item_conv_factor)end) as item_conv_factor,
(case when (LENGTH(trim( item_conv_factor_after )) ==0) then item_conv_factor_after else trim(item_conv_factor_after)end) as item_conv_factor_after,
(case when (LENGTH(trim( item_list_price_sale )) ==0) then item_list_price_sale else trim(item_list_price_sale)end) as item_list_price_sale,
(case when (LENGTH(trim( item_list_price_sale_after )) ==0) then item_list_price_sale_after else trim(item_list_price_sale_after)end) as item_list_price_sale_after,
(case when (LENGTH(trim( item_retail_price )) ==0) then item_retail_price else trim(item_retail_price)end) as item_retail_price,
(case when (LENGTH(trim( item_retail_price_after )) ==0) then item_retail_price_after else trim(item_retail_price_after)end) as item_retail_price_after,
(case when (LENGTH(trim( item_pum )) ==0) then item_pum else trim(item_pum)end) as item_pum,
(case when (LENGTH(trim( item_pum_after )) ==0) then item_pum_after else trim(item_pum_after)end) as item_pum_after,
(case when (LENGTH(trim( item_sub_group )) ==0) then item_sub_group else trim(item_sub_group)end) as item_sub_group,
(case when (LENGTH(trim( item_sub_group_after )) ==0) then item_sub_group_after else trim(item_sub_group_after)end) as item_sub_group_after,
(case when (LENGTH(trim( item_sub_category )) ==0) then item_sub_category else trim(item_sub_category)end) as item_sub_category,
(case when (LENGTH(trim( item_sub_category_after )) ==0) then item_sub_category_after else trim(item_sub_category_after)end) as item_sub_category_after,
(case when (LENGTH(trim( item_sum )) ==0) then item_sum else trim(item_sum)end) as item_sum,
(case when (LENGTH(trim( item_sum_after )) ==0) then item_sum_after else trim(item_sum_after)end) as item_sum_after,
(case when (LENGTH(trim( primary_vendor_item_cost )) ==0) then primary_vendor_item_cost else trim(primary_vendor_item_cost)end) as primary_vendor_item_cost,
(case when (LENGTH(trim( primary_vendor_item_cost_after )) ==0) then primary_vendor_item_cost_after else trim(primary_vendor_item_cost_after)end) as primary_vendor_item_cost_after,
(case when (LENGTH(trim( primary_vendor_item_nbr )) ==0) then primary_vendor_item_nbr else trim(primary_vendor_item_nbr)end) as primary_vendor_item_nbr,
(case when (LENGTH(trim( primary_vendor_item_nbr_after )) ==0) then primary_vendor_item_nbr_after else trim(primary_vendor_item_nbr_after)end) as primary_vendor_item_nbr_after,
(case when (LENGTH(trim( secndry_vendor_item_cost )) ==0) then secndry_vendor_item_cost else trim(secndry_vendor_item_cost)end) as secndry_vendor_item_cost,
(case when (LENGTH(trim( secndry_vendor_item_cost_after )) ==0) then secndry_vendor_item_cost_after else trim(secndry_vendor_item_cost_after)end) as secndry_vendor_item_cost_after,
(case when (LENGTH(trim( secndry_vendor_item_nbr )) ==0) then secndry_vendor_item_nbr else trim(secndry_vendor_item_nbr)end) as secndry_vendor_item_nbr,
(case when (LENGTH(trim( secndry_vendor_item_nbr_after )) ==0) then secndry_vendor_item_nbr_after else trim(secndry_vendor_item_nbr_after)end) as secndry_vendor_item_nbr_after,
(case when (LENGTH(trim( tertry_vendor_item_cost )) ==0) then tertry_vendor_item_cost else trim(tertry_vendor_item_cost)end) as tertry_vendor_item_cost,
(case when (LENGTH(trim( tertry_vendor_item_cost_after )) ==0) then tertry_vendor_item_cost_after else trim(tertry_vendor_item_cost_after)end) as tertry_vendor_item_cost_after,
(case when (LENGTH(trim( tertry_vendor_item_nbr )) ==0) then tertry_vendor_item_nbr else trim(tertry_vendor_item_nbr)end) as tertry_vendor_item_nbr,
(case when (LENGTH(trim( tertry_vendor_item_nbr_after )) ==0) then tertry_vendor_item_nbr_after else trim(tertry_vendor_item_nbr_after)end) as tertry_vendor_item_nbr_after,
(case when (LENGTH(trim( specific_gravity )) ==0) then specific_gravity else trim(specific_gravity)end) as specific_gravity,
(case when (LENGTH(trim( specific_gravity_after )) ==0) then specific_gravity_after else trim(specific_gravity_after)end) as specific_gravity_after,
(case when (LENGTH(trim( concentration_nbr )) ==0) then concentration_nbr else trim(concentration_nbr)end) as concentration_nbr,
(case when (LENGTH(trim( concentration_nbr_after )) ==0) then concentration_nbr_after else trim(concentration_nbr_after)end) as concentration_nbr_after,
(case when (LENGTH(trim( concentration_units )) ==0) then concentration_units else trim(concentration_units)end) as concentration_units,
(case when (LENGTH(trim( concentration_units_after )) ==0) then concentration_units_after else trim(concentration_units_after)end) as concentration_units_after,
(case when (LENGTH(trim( lipids_ind )) ==0) then lipids_ind else trim(lipids_ind)end) as lipids_ind,
(case when (LENGTH(trim( lipids_ind_after )) ==0) then lipids_ind_after else trim(lipids_ind_after)end) as lipids_ind_after,
(case when (LENGTH(trim( amino_acid_ind )) ==0) then amino_acid_ind else trim(amino_acid_ind)end) as amino_acid_ind,
(case when (LENGTH(trim( amino_acid_ind_after )) ==0) then amino_acid_ind_after else trim(amino_acid_ind_after)end) as amino_acid_ind_after,
(case when (LENGTH(trim( poolable_ind )) ==0) then poolable_ind else trim(poolable_ind)end) as poolable_ind,
(case when (LENGTH(trim( poolable_ind_after )) ==0) then poolable_ind_after else trim(poolable_ind_after)end) as poolable_ind_after,
(case when (LENGTH(trim( trace_element_ind )) ==0) then trace_element_ind else trim(trace_element_ind)end) as trace_element_ind,
(case when (LENGTH(trim( trace_element_ind_after )) ==0) then trace_element_ind_after else trim(trace_element_ind_after)end) as trace_element_ind_after,
(case when (LENGTH(trim( electrolyte_ind )) ==0) then electrolyte_ind else trim(electrolyte_ind)end) as electrolyte_ind,
(case when (LENGTH(trim( electrolyte_ind_after )) ==0) then electrolyte_ind_after else trim(electrolyte_ind_after)end) as electrolyte_ind_after,
(case when (LENGTH(trim( container_material_cd )) ==0) then container_material_cd else trim(container_material_cd)end) as container_material_cd,
(case when (LENGTH(trim( container_material_cd_after )) ==0) then container_material_cd_after else trim(container_material_cd_after)end) as container_material_cd_after,
(case when (LENGTH(trim( container_max_capacity )) ==0) then container_max_capacity else trim(container_max_capacity)end) as container_max_capacity,
(case when (LENGTH(trim( container_max_capacity_after )) ==0) then container_max_capacity_after else trim(container_max_capacity_after)end) as container_max_capacity_after,
(case when (LENGTH(trim( vehicle_ind )) ==0) then vehicle_ind else trim(vehicle_ind)end) as vehicle_ind,
(case when (LENGTH(trim( vehicle_ind_after )) ==0) then vehicle_ind_after else trim(vehicle_ind_after)end) as vehicle_ind_after,
(case when (LENGTH(trim( vehicle )) ==0) then vehicle else trim(vehicle)end) as vehicle,
(case when (LENGTH(trim( vehicle_after )) ==0) then vehicle_after else trim(vehicle_after)end) as vehicle_after,
(case when (LENGTH(trim( cocktail_ind )) ==0) then cocktail_ind else trim(cocktail_ind)end) as cocktail_ind,
(case when (LENGTH(trim( cocktail_ind_after )) ==0) then cocktail_ind_after else trim(cocktail_ind_after)end) as cocktail_ind_after,
(case when (LENGTH(trim( primary_vendor_nbr )) ==0) then primary_vendor_nbr else trim(primary_vendor_nbr)end) as primary_vendor_nbr,
(case when (LENGTH(trim( primary_vendor_nbr_after )) ==0) then primary_vendor_nbr_after else trim(primary_vendor_nbr_after)end) as primary_vendor_nbr_after,
(case when (LENGTH(trim( secondary_vendor_nbr )) ==0) then secondary_vendor_nbr else trim(secondary_vendor_nbr)end) as secondary_vendor_nbr,
(case when (LENGTH(trim( secondary_vendor_nbr_after )) ==0) then secondary_vendor_nbr_after else trim(secondary_vendor_nbr_after)end) as secondary_vendor_nbr_after,
(case when (LENGTH(trim( tertiary_vendor_nbr )) ==0) then tertiary_vendor_nbr else trim(tertiary_vendor_nbr)end) as tertiary_vendor_nbr,
(case when (LENGTH(trim( tertiary_vendor_nbr_after )) ==0) then tertiary_vendor_nbr_after else trim(tertiary_vendor_nbr_after)end) as tertiary_vendor_nbr_after,
(case when (LENGTH(trim( base_ind )) ==0) then base_ind else trim(base_ind)end) as base_ind,
(case when (LENGTH(trim( base_ind_after )) ==0) then base_ind_after else trim(base_ind_after)end) as base_ind_after,
(case when (LENGTH(trim( item_type )) ==0) then item_type else trim(item_type)end) as item_type,
(case when (LENGTH(trim( item_type_after )) ==0) then item_type_after else trim(item_type_after)end) as item_type_after,
(case when (LENGTH(trim( conc_dextrose_ind )) ==0) then conc_dextrose_ind else trim(conc_dextrose_ind)end) as conc_dextrose_ind,
(case when (LENGTH(trim( conc_dextrose_ind_after )) ==0) then conc_dextrose_ind_after else trim(conc_dextrose_ind_after)end) as conc_dextrose_ind_after,
(case when (LENGTH(trim( container_ind )) ==0) then container_ind else trim(container_ind)end) as container_ind,
(case when (LENGTH(trim( container_ind_after )) ==0) then container_ind_after else trim(container_ind_after)end) as container_ind_after,
(case when (LENGTH(trim( container_type )) ==0) then container_type else trim(container_type)end) as container_type,
(case when (LENGTH(trim( container_type_after )) ==0) then container_type_after else trim(container_type_after)end) as container_type_after,
(case when (LENGTH(trim( primary_vendor_name )) ==0) then primary_vendor_name else trim(primary_vendor_name)end) as primary_vendor_name,
(case when (LENGTH(trim( primary_vendor_name_after )) ==0) then primary_vendor_name_after else trim(primary_vendor_name_after)end) as primary_vendor_name_after,
(case when (LENGTH(trim( secondary_vendor_name )) ==0) then secondary_vendor_name else trim(secondary_vendor_name)end) as secondary_vendor_name,
(case when (LENGTH(trim( secondary_vendor_name_after )) ==0) then secondary_vendor_name_after else trim(secondary_vendor_name_after)end) as secondary_vendor_name_after,
(case when (LENGTH(trim( tertiary_vendor_name )) ==0) then tertiary_vendor_name else trim(tertiary_vendor_name)end) as tertiary_vendor_name,
(case when (LENGTH(trim( tertiary_vendor_name_after )) ==0) then tertiary_vendor_name_after else trim(tertiary_vendor_name_after)end) as tertiary_vendor_name_after,
(case when (LENGTH(trim( plx_drug_ind )) ==0) then plx_drug_ind else trim(plx_drug_ind)end) as plx_drug_ind,
(case when (LENGTH(trim( plx_drug_ind_after )) ==0) then plx_drug_ind_after else trim(plx_drug_ind_after)end) as plx_drug_ind_after,
(case when (LENGTH(trim( item_size )) ==0) then item_size else trim(item_size)end) as item_size,
(case when (LENGTH(trim( item_size_after )) ==0) then item_size_after else trim(item_size_after)end) as item_size_after,
(case when (LENGTH(trim( item_size_units )) ==0) then item_size_units else trim(item_size_units)end) as item_size_units,
(case when (LENGTH(trim( item_size_units_after )) ==0) then item_size_units_after else trim(item_size_units_after)end) as item_size_units_after,
(case when (LENGTH(trim( item_long_desc )) ==0) then item_long_desc else trim(item_long_desc)end) as item_long_desc,
(case when (LENGTH(trim( item_long_desc_after )) ==0) then item_long_desc_after else trim(item_long_desc_after)end) as item_long_desc_after,
(case when (LENGTH(trim( item_short_desc )) ==0) then item_short_desc else trim(item_short_desc)end) as item_short_desc,
(case when (LENGTH(trim( item_short_desc_after )) ==0) then item_short_desc_after else trim(item_short_desc_after)end) as item_short_desc_after,
(case when (LENGTH(trim( item_awp )) ==0) then item_awp else trim(item_awp)end) as item_awp,
(case when (LENGTH(trim( item_awp_after )) ==0) then item_awp_after else trim(item_awp_after)end) as item_awp_after,
(case when (LENGTH(trim( billing_multiplier )) ==0) then billing_multiplier else trim(billing_multiplier)end) as billing_multiplier,
(case when (LENGTH(trim( billing_multiplier_after )) ==0) then billing_multiplier_after else trim(billing_multiplier_after)end) as billing_multiplier_after,
(case when (LENGTH(trim( track_inventory_ind )) ==0) then track_inventory_ind else trim(track_inventory_ind)end) as track_inventory_ind,
(case when (LENGTH(trim( track_inventory_ind_after )) ==0) then track_inventory_ind_after else trim(track_inventory_ind_after)end) as track_inventory_ind_after,
(case when (LENGTH(trim( disease_state_ind )) ==0) then disease_state_ind else trim(disease_state_ind)end) as disease_state_ind,
(case when (LENGTH(trim( disease_state_ind_after )) ==0) then disease_state_ind_after else trim(disease_state_ind_after)end) as disease_state_ind_after,
(case when (LENGTH(trim( drug_inference_cd )) ==0) then drug_inference_cd else trim(drug_inference_cd)end) as drug_inference_cd,
(case when (LENGTH(trim( drug_inference_cd_after )) ==0) then drug_inference_cd_after else trim(drug_inference_cd_after)end) as drug_inference_cd_after,
(case when (LENGTH(trim( drug_min_price )) ==0) then drug_min_price else trim(drug_min_price)end) as drug_min_price,
(case when (LENGTH(trim( drug_min_price_after )) ==0) then drug_min_price_after else trim(drug_min_price_after)end) as drug_min_price_after,
(case when (LENGTH(trim( excl_drug_automation_ind )) ==0) then excl_drug_automation_ind else trim(excl_drug_automation_ind)end) as excl_drug_automation_ind,
(case when (LENGTH(trim( excl_drug_automation_ind_after )) ==0) then excl_drug_automation_ind_after else trim(excl_drug_automation_ind_after)end) as excl_drug_automation_ind_after,
(case when (LENGTH(trim( excl_tbltp_count_ind )) ==0) then excl_tbltp_count_ind else trim(excl_tbltp_count_ind)end) as excl_tbltp_count_ind,
(case when (LENGTH(trim( excl_tbltp_count_ind_after )) ==0) then excl_tbltp_count_ind_after else trim(excl_tbltp_count_ind_after)end) as excl_tbltp_count_ind_after,
(case when (LENGTH(trim( require_tbltp_clean )) ==0) then require_tbltp_clean else trim(require_tbltp_clean)end) as require_tbltp_clean,
(case when (LENGTH(trim( require_tbltp_clean_after )) ==0) then require_tbltp_clean_after else trim(require_tbltp_clean_after)end) as require_tbltp_clean_after,
(case when (LENGTH(trim( thera_class_extd )) ==0) then thera_class_extd else trim(thera_class_extd)end) as thera_class_extd,
(case when (LENGTH(trim( thera_class_extd )) ==0) then thera_class_extd else trim(thera_class_extd)end) as thera_class_extd_after,
(case when (LENGTH(trim( hzrds_lvl_cd )) ==0) then hzrds_lvl_cd else trim(hzrds_lvl_cd)end) as hzrds_lvl_cd,
(case when (LENGTH(trim( hzrds_lvl_cd_after )) ==0) then hzrds_lvl_cd_after else trim(hzrds_lvl_cd_after)end) as hzrds_lvl_cd_after,
(case when (LENGTH(trim( auth_generic_cd )) ==0) then auth_generic_cd else trim(auth_generic_cd )end) as auth_generic_cd,
(case when (LENGTH(trim( auth_generic_cd_after )) ==0) then auth_generic_cd_after else trim(auth_generic_cd_after)end) as auth_generic_cd_after,
(case when (LENGTH(trim( fda_ind )) ==0) then fda_ind else trim(fda_ind )end) as fda_ind,
(case when (LENGTH(trim( fda_ind_after )) ==0) then fda_ind_after else trim(fda_ind_after)end) as fda_ind_after,
(case when (LENGTH(trim( fda_ind_value )) ==0) then fda_ind_value else trim(fda_ind_value )end)  as fda_ind_value,
(case when (LENGTH(trim( fda_ind_value_after )) ==0) then fda_ind_value_after else trim(fda_ind_value_after)end)  as fda_ind_value_after,
(case when (LENGTH(trim( auth_ndc_upc_hri )) ==0) then auth_ndc_upc_hri else trim(auth_ndc_upc_hri )end) as auth_ndc_upc_hri,
(case when (LENGTH(trim( auth_ndc_upc_hri_after )) ==0) then auth_ndc_upc_hri_after else trim(auth_ndc_upc_hri_after)end) as auth_ndc_upc_hri_after,
(case when (LENGTH(trim( auth_gen_override_ind )) ==0) then auth_gen_override_ind else trim(auth_gen_override_ind )end) as auth_gen_override_ind,
(case when (LENGTH(trim( auth_gen_override_ind_after )) ==0) then auth_gen_override_ind_after else trim(auth_gen_override_ind_after)end) as auth_gen_override_ind_after,
(case when (LENGTH(trim( ddid )) ==0) then ddid else trim(ddid )end) as ddid,
(case when (LENGTH(trim( ddid_after )) ==0) then ddid_after else trim(ddid_after)end) as ddid_after,
(case when (LENGTH(trim( rxcui_type )) ==0) then rxcui_type else trim(rxcui_type )end) as rxcui_type,
(case when (LENGTH(trim( rxcui_type_after )) ==0) then rxcui_type_after else trim(rxcui_type_after)end) as rxcui_type_after,
(case when (LENGTH(trim( rxcui )) ==0) then rxcui else trim(rxcui )end) as rxcui,
(case when (LENGTH(trim( rxcui_after )) ==0) then rxcui_after else trim(rxcui_after)end) as rxcui_after,
(case when (LENGTH(trim( elsevier_pack_id )) ==0) then elsevier_pack_id else trim(elsevier_pack_id )end) as elsevier_pack_id,
(case when (LENGTH(trim( elsevier_pack_id_after )) ==0) then elsevier_pack_id_after else trim(elsevier_pack_id_after)end) as elsevier_pack_id_after,
(case when (LENGTH(trim( elsevier_prod_id )) ==0) then elsevier_prod_id else trim(elsevier_prod_id )end) as elsevier_prod_id,
(case when (LENGTH(trim( elsevier_prod_id_after )) ==0) then elsevier_prod_id_after else trim(elsevier_prod_id_after )end) as elsevier_prod_id_after,
(case when (LENGTH(trim( med_dosage_unit )) ==0) then med_dosage_unit else trim(med_dosage_unit )end) as med_dosage_unit,
(case when (LENGTH(trim( med_dosage_unit_after )) ==0) then med_dosage_unit_after else trim(med_dosage_unit_after)end) as med_dosage_unit_after,
(case when (LENGTH(trim( med_conv_factor )) ==0) then med_conv_factor else trim(med_conv_factor )end) as med_conv_factor,
(case when (LENGTH(trim( med_conv_factor_after )) ==0) then med_conv_factor_after else trim(med_conv_factor_after)end) as med_conv_factor_after,
(case when (LENGTH(trim( mme_calc_factor )) ==0) then mme_calc_factor else trim(mme_calc_factor )end)  as mme_calc_factor,
(case when (LENGTH(trim( mme_calc_factor_after )) ==0) then mme_calc_factor_after else trim(mme_calc_factor_after)end) as mme_calc_factor_after
from dedup_group"""

#print(nr_spacetrim_sql)


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

#display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

#Removed tracking id and partition column
pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,drug_id_after AS drug_id , ndc_mfg_after AS ndc_mfg , ndc_prod_after AS ndc_prod , ndc_pkg_after AS ndc_pkg , sims_upc_after AS sims_upc , repack_nbr_after AS repack_nbr , ndc_form_cd_after AS ndc_form_cd , ndc_prev_mfg_after AS ndc_prev_mfg , ndc_prev_prod_after AS ndc_prev_prod , ndc_prev_pkg_after AS ndc_prev_pkg , prev_repack_nbr_after AS prev_repack_nbr , ndc_prev_form_cd_after AS ndc_prev_form_cd , id_form_cd_after AS id_form_cd , ndc_upc_hri_after AS ndc_upc_hri , dur_ndc_after AS dur_ndc , prev_ndc_upc_hri_after AS prev_ndc_upc_hri , prev_id_form_cd_after AS prev_id_form_cd , drug_class_after AS drug_class , drug_orange_book_rating_after AS drug_orange_book_rating , drug_name_cd_after AS drug_name_cd , gppc_after AS gppc , gen_typ_cd_after AS gen_typ_cd , gen_id_no_after AS gen_id_no , thera_class_after AS thera_class , lim_stabil_after AS lim_stabil , pack_descr_after AS pack_descr , rx_otc_cd_after AS rx_otc_cd , maint_drug_ind_after AS maint_drug_ind , route_of_admin_cd_after AS route_of_admin_cd , drug_generic_cd_after AS drug_generic_cd , drug_type_cd_after AS drug_type_cd , drug_single_comb_cd_after AS drug_single_comb_cd , drug_storage_cond_cd_after AS drug_storage_cond_cd , a_last_change_dttm_after AS a_last_change_dttm , a_protect_ind_after AS a_protect_ind , product_name_after AS product_name , product_name_suffix_after AS product_name_suffix , product_name_ext_after AS product_name_ext , product_mddb_abbr_after AS product_mddb_abbr , e_last_change_dttm_after AS e_last_change_dttm , e_protect_ind_after AS e_protect_ind , gpi_after AS gpi , gpi_name_after AS gpi_name , g_last_change_dttm_after AS g_last_change_dttm , g_protect_ind_after AS g_protect_ind , mfg_name_after AS mfg_name , mfg_name_abbr_after AS mfg_name_abbr , mfg_mddb_abbr_after AS mfg_mddb_abbr , mfg_name_suffix_after AS mfg_name_suffix , j_last_change_dttm_after AS j_last_change_dttm , j_protect_ind_after AS j_protect_ind , drug_strength_after AS drug_strength , drug_strength_uom_after AS drug_strength_uom , drug_dosage_form_cd_after AS drug_dosage_form_cd , package_size_after AS package_size , package_size_uom_after AS package_size_uom , package_qty_after AS package_qty , rx_to_otc_dttm_after AS rx_to_otc_dttm , l_last_change_dttm_after AS l_last_change_dttm , l_protect_ind_after AS l_protect_ind , awp_dttm_after AS awp_dttm , drug_counting_cell_id_after AS drug_counting_cell_id , awp_unit_price_after AS awp_unit_price , r_last_change_dttm_after AS r_last_change_dttm , r_protect_ind_after AS r_protect_ind , hcfa_dttm_after AS hcfa_dttm , hcfa_unit_limit_after AS hcfa_unit_limit , t_last_change_dttm_after AS t_last_change_dttm , t_protect_ind_after AS t_protect_ind , product_name_abbr_after AS product_name_abbr , drug_status_cd_after AS drug_status_cd , drug_disc_dttm_after AS drug_disc_dttm , mfp_nbr_after AS mfp_nbr , wic_nbr_after AS wic_nbr , drug_ppi_ind_after AS drug_ppi_ind , drug_min_disp_qty_after AS drug_min_disp_qty , default_sig_after AS default_sig , default_days_supply_after AS default_days_supply , expiration_days_after AS expiration_days , drug_class_except_ind_after AS drug_class_except_ind , ops_study_dept_nbr_after AS ops_study_dept_nbr , drug_warehouse_ind_after AS drug_warehouse_ind , pricing_protect_ind_after AS pricing_protect_ind , pr_daco_ind_after AS pr_daco_ind , pricing_override_drug_after AS pricing_override_drug , pricing_type_after AS pricing_type , aac_unit_price_after AS aac_unit_price , wac_unit_price_after AS wac_unit_price , prorated_quantity_after AS prorated_quantity , pricing_quantity_after AS pricing_quantity , drug_shape_cd_after AS drug_shape_cd , drug_color_1_cd_after AS drug_color_1_cd , drug_color_2_cd_after AS drug_color_2_cd , drug_side_1_after AS drug_side_1 , drug_side_2_after AS drug_side_2 , billing_ndc_after AS billing_ndc , drug_comment_cd_after AS drug_comment_cd , default_smart_sig_after AS default_smart_sig , drug_location_cd_after AS drug_location_cd , drug_multihit_disp_ind_after AS drug_multihit_disp_ind , substitution_drug_id_after AS substitution_drug_id , drug_volume_after AS drug_volume , precount_ind_after AS precount_ind , precount_qty_1_after AS precount_qty_1 , precount_qty_2_after AS precount_qty_2 , dur_kdc_nbr_after AS dur_kdc_nbr , ud_uu_pkg_cd_after AS ud_uu_pkg_cd , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , lbl_cmt_cd_after AS lbl_cmt_cd , substitution_prod_type_after AS substitution_prod_type , recon_water_qty_after AS recon_water_qty , drug_spec_cmt_cd_after AS drug_spec_cmt_cd , fax_pbr_cmt_cd_after AS fax_pbr_cmt_cd , promise_sub_drug_id_after AS promise_sub_drug_id , specialty_drug_ind_after AS specialty_drug_ind , cash_disc_qty_after AS cash_disc_qty , piece_weight_after AS piece_weight , stock_bottle_barcode_after AS stock_bottle_barcode , doses_per_pkg_after AS doses_per_pkg , pct_tot_disc_card_after AS pct_tot_disc_card , pet_med_ind_after AS pet_med_ind , ltd_dist_cd_after AS ltd_dist_cd , complicated_supplies_ind_after AS complicated_supplies_ind , specialty_review_ind_after AS specialty_review_ind , clinical_value_ind_after AS clinical_value_ind , required_supplies_ind_after AS required_supplies_ind , hcp_drug_mltht_disp_ind_after AS hcp_drug_mltht_disp_ind , mix_ind_after AS mix_ind , drug_image_file_name_after AS drug_image_file_name , top_drug_ind_after AS top_drug_ind , quality_alert_message_after AS quality_alert_message , quality_alert_keywords_after AS quality_alert_keywords , quality_alert_rule_ind_after AS quality_alert_rule_ind , quality_alert_screen_ind_after AS quality_alert_screen_ind , cash_disc_qty2_after AS cash_disc_qty2 , cash_disc_qty3_after AS cash_disc_qty3 , tip_ind_after AS tip_ind , ref_drug_id_after AS ref_drug_id , hcpc_after AS hcpc , pref_mfr_ind_after AS pref_mfr_ind , med_guide_filename_after AS med_guide_filename , med_guide_ind_after AS med_guide_ind , item_class_after AS item_class , item_group_after AS item_group , item_formulary_ind_after AS item_formulary_ind , item_category_after AS item_category , item_lob_after AS item_lob , item_conv_factor_after AS item_conv_factor , item_list_price_sale_after AS item_list_price_sale , item_retail_price_after AS item_retail_price , item_pum_after AS item_pum , item_sub_group_after AS item_sub_group , item_sub_category_after AS item_sub_category , item_sum_after AS item_sum , primary_vendor_item_cost_after AS primary_vendor_item_cost , primary_vendor_item_nbr_after AS primary_vendor_item_nbr , secndry_vendor_item_cost_after AS secndry_vendor_item_cost , secndry_vendor_item_nbr_after AS secndry_vendor_item_nbr , tertry_vendor_item_cost_after AS tertry_vendor_item_cost , tertry_vendor_item_nbr_after AS tertry_vendor_item_nbr , specific_gravity_after AS specific_gravity , concentration_nbr_after AS concentration_nbr , concentration_units_after AS concentration_units , lipids_ind_after AS lipids_ind , amino_acid_ind_after AS amino_acid_ind , poolable_ind_after AS poolable_ind , trace_element_ind_after AS trace_element_ind , electrolyte_ind_after AS electrolyte_ind , container_material_cd_after AS container_material_cd , container_max_capacity_after AS container_max_capacity , vehicle_ind_after AS vehicle_ind , vehicle_after AS vehicle , cocktail_ind_after AS cocktail_ind , primary_vendor_nbr_after AS primary_vendor_nbr , secondary_vendor_nbr_after AS secondary_vendor_nbr , tertiary_vendor_nbr_after AS tertiary_vendor_nbr , base_ind_after AS base_ind , item_type_after AS item_type , conc_dextrose_ind_after AS conc_dextrose_ind , container_ind_after AS container_ind , container_type_after AS container_type , primary_vendor_name_after AS primary_vendor_name , secondary_vendor_name_after AS secondary_vendor_name , tertiary_vendor_name_after AS tertiary_vendor_name , plx_drug_ind_after AS plx_drug_ind , item_size_after AS item_size , item_size_units_after AS item_size_units , item_long_desc_after AS item_long_desc , item_short_desc_after AS item_short_desc , item_awp_after AS item_awp , billing_multiplier_after AS billing_multiplier , track_inventory_ind_after AS track_inventory_ind , disease_state_ind_after AS disease_state_ind , drug_min_price_after AS drug_min_price , drug_inference_cd_after AS drug_inference_cd , excl_drug_automation_ind_after AS excl_drug_automation_ind , excl_tbltp_count_ind_after AS excl_tbltp_count_ind , require_tbltp_clean_after AS require_tbltp_clean , thera_class_extd_after AS thera_class_extd , hzrds_lvl_cd_after AS hzrds_lvl_cd ,auth_generic_cd_after As auth_generic_cd , fda_ind_after As fda_ind , fda_ind_value_after As fda_ind_value , auth_ndc_upc_hri_after As auth_ndc_upc_hri , auth_gen_override_ind_after As auth_gen_override_ind , ddid_after As ddid , rxcui_type_after As rxcui_type , rxcui_after As rxcui , elsevier_pack_id_after As elsevier_pack_id , elsevier_prod_id_after As elsevier_prod_id , med_dosage_unit_after As med_dosage_unit , med_conv_factor_after As med_conv_factor , mme_calc_factor_after As mme_calc_factor ,  
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """



# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,drug_id AS drug_id , ndc_mfg AS ndc_mfg , ndc_prod AS ndc_prod , ndc_pkg AS ndc_pkg , sims_upc AS sims_upc , repack_nbr AS repack_nbr , ndc_form_cd AS ndc_form_cd , ndc_prev_mfg AS ndc_prev_mfg , ndc_prev_prod AS ndc_prev_prod , ndc_prev_pkg AS ndc_prev_pkg , prev_repack_nbr AS prev_repack_nbr , ndc_prev_form_cd AS ndc_prev_form_cd , id_form_cd AS id_form_cd , ndc_upc_hri AS ndc_upc_hri , dur_ndc AS dur_ndc , prev_ndc_upc_hri AS prev_ndc_upc_hri , prev_id_form_cd AS prev_id_form_cd , drug_class AS drug_class , drug_orange_book_rating AS drug_orange_book_rating , drug_name_cd AS drug_name_cd , gppc AS gppc , gen_typ_cd AS gen_typ_cd , gen_id_no AS gen_id_no , thera_class AS thera_class , lim_stabil AS lim_stabil , pack_descr AS pack_descr , rx_otc_cd AS rx_otc_cd , maint_drug_ind AS maint_drug_ind , route_of_admin_cd AS route_of_admin_cd , drug_generic_cd AS drug_generic_cd , drug_type_cd AS drug_type_cd , drug_single_comb_cd AS drug_single_comb_cd , drug_storage_cond_cd AS drug_storage_cond_cd , a_last_change_dttm AS a_last_change_dttm , a_protect_ind AS a_protect_ind , product_name AS product_name , product_name_suffix AS product_name_suffix , product_name_ext AS product_name_ext , product_mddb_abbr AS product_mddb_abbr , e_last_change_dttm AS e_last_change_dttm , e_protect_ind AS e_protect_ind , gpi AS gpi , gpi_name AS gpi_name , g_last_change_dttm AS g_last_change_dttm , g_protect_ind AS g_protect_ind , mfg_name AS mfg_name , mfg_name_abbr AS mfg_name_abbr , mfg_mddb_abbr AS mfg_mddb_abbr , mfg_name_suffix AS mfg_name_suffix , j_last_change_dttm AS j_last_change_dttm , j_protect_ind AS j_protect_ind , drug_strength AS drug_strength , drug_strength_uom AS drug_strength_uom , drug_dosage_form_cd AS drug_dosage_form_cd , package_size AS package_size , package_size_uom AS package_size_uom , package_qty AS package_qty , rx_to_otc_dttm AS rx_to_otc_dttm , l_last_change_dttm AS l_last_change_dttm , l_protect_ind AS l_protect_ind , awp_dttm AS awp_dttm , drug_counting_cell_id AS drug_counting_cell_id , awp_unit_price AS awp_unit_price , r_last_change_dttm AS r_last_change_dttm , r_protect_ind AS r_protect_ind , hcfa_dttm AS hcfa_dttm , hcfa_unit_limit AS hcfa_unit_limit , t_last_change_dttm AS t_last_change_dttm , t_protect_ind AS t_protect_ind , product_name_abbr AS product_name_abbr , drug_status_cd AS drug_status_cd , drug_disc_dttm AS drug_disc_dttm , mfp_nbr AS mfp_nbr , wic_nbr AS wic_nbr , drug_ppi_ind AS drug_ppi_ind , drug_min_disp_qty AS drug_min_disp_qty , default_sig AS default_sig , default_days_supply AS default_days_supply , expiration_days AS expiration_days , drug_class_except_ind AS drug_class_except_ind , ops_study_dept_nbr AS ops_study_dept_nbr , drug_warehouse_ind AS drug_warehouse_ind , pricing_protect_ind AS pricing_protect_ind , pr_daco_ind AS pr_daco_ind , pricing_override_drug AS pricing_override_drug , pricing_type AS pricing_type , aac_unit_price AS aac_unit_price , wac_unit_price AS wac_unit_price , prorated_quantity AS prorated_quantity , pricing_quantity AS pricing_quantity , drug_shape_cd AS drug_shape_cd , drug_color_1_cd AS drug_color_1_cd , drug_color_2_cd AS drug_color_2_cd , drug_side_1 AS drug_side_1 , drug_side_2 AS drug_side_2 , billing_ndc AS billing_ndc , drug_comment_cd AS drug_comment_cd , default_smart_sig AS default_smart_sig , drug_location_cd AS drug_location_cd , drug_multihit_disp_ind AS drug_multihit_disp_ind , substitution_drug_id AS substitution_drug_id , drug_volume AS drug_volume , precount_ind AS precount_ind , precount_qty_1 AS precount_qty_1 , precount_qty_2 AS precount_qty_2 , dur_kdc_nbr AS dur_kdc_nbr , ud_uu_pkg_cd AS ud_uu_pkg_cd , create_user_id AS create_user_id , create_dttm AS create_dttm , update_user_id AS update_user_id , update_dttm AS update_dttm , lbl_cmt_cd AS lbl_cmt_cd , substitution_prod_type AS substitution_prod_type , recon_water_qty AS recon_water_qty , drug_spec_cmt_cd AS drug_spec_cmt_cd , fax_pbr_cmt_cd AS fax_pbr_cmt_cd , promise_sub_drug_id AS promise_sub_drug_id , specialty_drug_ind AS specialty_drug_ind , cash_disc_qty AS cash_disc_qty , piece_weight AS piece_weight , stock_bottle_barcode AS stock_bottle_barcode , doses_per_pkg AS doses_per_pkg , pct_tot_disc_card AS pct_tot_disc_card , pet_med_ind AS pet_med_ind , ltd_dist_cd AS ltd_dist_cd , complicated_supplies_ind AS complicated_supplies_ind , specialty_review_ind AS specialty_review_ind , clinical_value_ind AS clinical_value_ind , required_supplies_ind AS required_supplies_ind , hcp_drug_mltht_disp_ind AS hcp_drug_mltht_disp_ind , mix_ind AS mix_ind , drug_image_file_name AS drug_image_file_name , top_drug_ind AS top_drug_ind , quality_alert_message AS quality_alert_message , quality_alert_keywords AS quality_alert_keywords , quality_alert_rule_ind AS quality_alert_rule_ind , quality_alert_screen_ind AS quality_alert_screen_ind , cash_disc_qty2 AS cash_disc_qty2 , cash_disc_qty3 AS cash_disc_qty3 , tip_ind AS tip_ind , ref_drug_id AS ref_drug_id , hcpc AS hcpc , pref_mfr_ind AS pref_mfr_ind , med_guide_filename AS med_guide_filename , med_guide_ind AS med_guide_ind , item_class AS item_class , item_group AS item_group , item_formulary_ind AS item_formulary_ind , item_category AS item_category , item_lob AS item_lob , item_conv_factor AS item_conv_factor , item_list_price_sale AS item_list_price_sale , item_retail_price AS item_retail_price , item_pum AS item_pum , item_sub_group AS item_sub_group , item_sub_category AS item_sub_category , item_sum AS item_sum , primary_vendor_item_cost AS primary_vendor_item_cost , primary_vendor_item_nbr AS primary_vendor_item_nbr , secndry_vendor_item_cost AS secndry_vendor_item_cost , secndry_vendor_item_nbr AS secndry_vendor_item_nbr , tertry_vendor_item_cost AS tertry_vendor_item_cost , tertry_vendor_item_nbr AS tertry_vendor_item_nbr , specific_gravity AS specific_gravity , concentration_nbr AS concentration_nbr , concentration_units AS concentration_units , lipids_ind AS lipids_ind , amino_acid_ind AS amino_acid_ind , poolable_ind AS poolable_ind , trace_element_ind AS trace_element_ind , electrolyte_ind AS electrolyte_ind , container_material_cd AS container_material_cd , container_max_capacity AS container_max_capacity , vehicle_ind AS vehicle_ind , vehicle AS vehicle , cocktail_ind AS cocktail_ind , primary_vendor_nbr AS primary_vendor_nbr , secondary_vendor_nbr AS secondary_vendor_nbr , tertiary_vendor_nbr AS tertiary_vendor_nbr , base_ind AS base_ind , item_type AS item_type , conc_dextrose_ind AS conc_dextrose_ind , container_ind AS container_ind , container_type AS container_type , primary_vendor_name AS primary_vendor_name , secondary_vendor_name AS secondary_vendor_name , tertiary_vendor_name AS tertiary_vendor_name , plx_drug_ind AS plx_drug_ind , item_size AS item_size , item_size_units AS item_size_units , item_long_desc AS item_long_desc , item_short_desc AS item_short_desc , item_awp AS item_awp , billing_multiplier AS billing_multiplier , track_inventory_ind AS track_inventory_ind , disease_state_ind AS disease_state_ind , drug_min_price AS drug_min_price , drug_inference_cd AS drug_inference_cd , excl_drug_automation_ind AS excl_drug_automation_ind , excl_tbltp_count_ind AS excl_tbltp_count_ind , require_tbltp_clean AS require_tbltp_clean , thera_class_extd AS thera_class_extd , hzrds_lvl_cd AS hzrds_lvl_cd ,auth_generic_cd As auth_generic_cd , fda_ind As fda_ind , fda_ind_value As fda_ind_value , auth_ndc_upc_hri As auth_ndc_upc_hri , auth_gen_override_ind As auth_gen_override_ind , ddid As ddid , rxcui_type As rxcui_type , rxcui As rxcui , elsevier_pack_id As elsevier_pack_id , elsevier_prod_id As elsevier_prod_id , med_dosage_unit As med_dosage_unit , med_conv_factor As med_conv_factor , mme_calc_factor As mme_calc_factor , 
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """



# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd, 
""" + BATCH_ID + """ as edw_batch_id,drug_id_after AS drug_id , ndc_mfg_after AS ndc_mfg , ndc_prod_after AS ndc_prod , ndc_pkg_after AS ndc_pkg , sims_upc_after AS sims_upc , repack_nbr_after AS repack_nbr , ndc_form_cd_after AS ndc_form_cd , ndc_prev_mfg_after AS ndc_prev_mfg , ndc_prev_prod_after AS ndc_prev_prod , ndc_prev_pkg_after AS ndc_prev_pkg , prev_repack_nbr_after AS prev_repack_nbr , ndc_prev_form_cd_after AS ndc_prev_form_cd , id_form_cd_after AS id_form_cd , ndc_upc_hri_after AS ndc_upc_hri , dur_ndc_after AS dur_ndc , prev_ndc_upc_hri_after AS prev_ndc_upc_hri , prev_id_form_cd_after AS prev_id_form_cd , drug_class_after AS drug_class , drug_orange_book_rating_after AS drug_orange_book_rating , drug_name_cd_after AS drug_name_cd , gppc_after AS gppc , gen_typ_cd_after AS gen_typ_cd , gen_id_no_after AS gen_id_no , thera_class_after AS thera_class , lim_stabil_after AS lim_stabil , pack_descr_after AS pack_descr , rx_otc_cd_after AS rx_otc_cd , maint_drug_ind_after AS maint_drug_ind , route_of_admin_cd_after AS route_of_admin_cd , drug_generic_cd_after AS drug_generic_cd , drug_type_cd_after AS drug_type_cd , drug_single_comb_cd_after AS drug_single_comb_cd , drug_storage_cond_cd_after AS drug_storage_cond_cd , a_last_change_dttm_after AS a_last_change_dttm , a_protect_ind_after AS a_protect_ind , product_name_after AS product_name , product_name_suffix_after AS product_name_suffix , product_name_ext_after AS product_name_ext , product_mddb_abbr_after AS product_mddb_abbr , e_last_change_dttm_after AS e_last_change_dttm , e_protect_ind_after AS e_protect_ind , gpi_after AS gpi , gpi_name_after AS gpi_name , g_last_change_dttm_after AS g_last_change_dttm , g_protect_ind_after AS g_protect_ind , mfg_name_after AS mfg_name , mfg_name_abbr_after AS mfg_name_abbr , mfg_mddb_abbr_after AS mfg_mddb_abbr , mfg_name_suffix_after AS mfg_name_suffix , j_last_change_dttm_after AS j_last_change_dttm , j_protect_ind_after AS j_protect_ind , drug_strength_after AS drug_strength , drug_strength_uom_after AS drug_strength_uom , drug_dosage_form_cd_after AS drug_dosage_form_cd , package_size_after AS package_size , package_size_uom_after AS package_size_uom , package_qty_after AS package_qty , rx_to_otc_dttm_after AS rx_to_otc_dttm , l_last_change_dttm_after AS l_last_change_dttm , l_protect_ind_after AS l_protect_ind , awp_dttm_after AS awp_dttm , drug_counting_cell_id_after AS drug_counting_cell_id , awp_unit_price_after AS awp_unit_price , r_last_change_dttm_after AS r_last_change_dttm , r_protect_ind_after AS r_protect_ind , hcfa_dttm_after AS hcfa_dttm , hcfa_unit_limit_after AS hcfa_unit_limit , t_last_change_dttm_after AS t_last_change_dttm , t_protect_ind_after AS t_protect_ind , product_name_abbr_after AS product_name_abbr , drug_status_cd_after AS drug_status_cd , drug_disc_dttm_after AS drug_disc_dttm , mfp_nbr_after AS mfp_nbr , wic_nbr_after AS wic_nbr , drug_ppi_ind_after AS drug_ppi_ind , drug_min_disp_qty_after AS drug_min_disp_qty , default_sig_after AS default_sig , default_days_supply_after AS default_days_supply , expiration_days_after AS expiration_days , drug_class_except_ind_after AS drug_class_except_ind , ops_study_dept_nbr_after AS ops_study_dept_nbr , drug_warehouse_ind_after AS drug_warehouse_ind , pricing_protect_ind_after AS pricing_protect_ind , pr_daco_ind_after AS pr_daco_ind , pricing_override_drug_after AS pricing_override_drug , pricing_type_after AS pricing_type , aac_unit_price_after AS aac_unit_price , wac_unit_price_after AS wac_unit_price , prorated_quantity_after AS prorated_quantity , pricing_quantity_after AS pricing_quantity , drug_shape_cd_after AS drug_shape_cd , drug_color_1_cd_after AS drug_color_1_cd , drug_color_2_cd_after AS drug_color_2_cd , drug_side_1_after AS drug_side_1 , drug_side_2_after AS drug_side_2 , billing_ndc_after AS billing_ndc , drug_comment_cd_after AS drug_comment_cd , default_smart_sig_after AS default_smart_sig , drug_location_cd_after AS drug_location_cd , drug_multihit_disp_ind_after AS drug_multihit_disp_ind , substitution_drug_id_after AS substitution_drug_id , drug_volume_after AS drug_volume , precount_ind_after AS precount_ind , precount_qty_1_after AS precount_qty_1 , precount_qty_2_after AS precount_qty_2 , dur_kdc_nbr_after AS dur_kdc_nbr , ud_uu_pkg_cd_after AS ud_uu_pkg_cd , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , lbl_cmt_cd_after AS lbl_cmt_cd , substitution_prod_type_after AS substitution_prod_type , recon_water_qty_after AS recon_water_qty , drug_spec_cmt_cd_after AS drug_spec_cmt_cd , fax_pbr_cmt_cd_after AS fax_pbr_cmt_cd , promise_sub_drug_id_after AS promise_sub_drug_id , specialty_drug_ind_after AS specialty_drug_ind , cash_disc_qty_after AS cash_disc_qty , piece_weight_after AS piece_weight , stock_bottle_barcode_after AS stock_bottle_barcode , doses_per_pkg_after AS doses_per_pkg , pct_tot_disc_card_after AS pct_tot_disc_card , pet_med_ind_after AS pet_med_ind , ltd_dist_cd_after AS ltd_dist_cd , complicated_supplies_ind_after AS complicated_supplies_ind , specialty_review_ind_after AS specialty_review_ind , clinical_value_ind_after AS clinical_value_ind , required_supplies_ind_after AS required_supplies_ind , hcp_drug_mltht_disp_ind_after AS hcp_drug_mltht_disp_ind , mix_ind_after AS mix_ind , drug_image_file_name_after AS drug_image_file_name , top_drug_ind_after AS top_drug_ind , quality_alert_message_after AS quality_alert_message , quality_alert_keywords_after AS quality_alert_keywords , quality_alert_rule_ind_after AS quality_alert_rule_ind , quality_alert_screen_ind_after AS quality_alert_screen_ind , cash_disc_qty2_after AS cash_disc_qty2 , cash_disc_qty3_after AS cash_disc_qty3 , tip_ind_after AS tip_ind , ref_drug_id_after AS ref_drug_id , hcpc_after AS hcpc , pref_mfr_ind_after AS pref_mfr_ind , med_guide_filename_after AS med_guide_filename , med_guide_ind_after AS med_guide_ind , item_class_after AS item_class , item_group_after AS item_group , item_formulary_ind_after AS item_formulary_ind , item_category_after AS item_category , item_lob_after AS item_lob , item_conv_factor_after AS item_conv_factor , item_list_price_sale_after AS item_list_price_sale , item_retail_price_after AS item_retail_price , item_pum_after AS item_pum , item_sub_group_after AS item_sub_group , item_sub_category_after AS item_sub_category , item_sum_after AS item_sum , primary_vendor_item_cost_after AS primary_vendor_item_cost , primary_vendor_item_nbr_after AS primary_vendor_item_nbr , secndry_vendor_item_cost_after AS secndry_vendor_item_cost , secndry_vendor_item_nbr_after AS secndry_vendor_item_nbr , tertry_vendor_item_cost_after AS tertry_vendor_item_cost , tertry_vendor_item_nbr_after AS tertry_vendor_item_nbr , specific_gravity_after AS specific_gravity , concentration_nbr_after AS concentration_nbr , concentration_units_after AS concentration_units , lipids_ind_after AS lipids_ind , amino_acid_ind_after AS amino_acid_ind , poolable_ind_after AS poolable_ind , trace_element_ind_after AS trace_element_ind , electrolyte_ind_after AS electrolyte_ind , container_material_cd_after AS container_material_cd , container_max_capacity_after AS container_max_capacity , vehicle_ind_after AS vehicle_ind , vehicle_after AS vehicle , cocktail_ind_after AS cocktail_ind , primary_vendor_nbr_after AS primary_vendor_nbr , secondary_vendor_nbr_after AS secondary_vendor_nbr , tertiary_vendor_nbr_after AS tertiary_vendor_nbr , base_ind_after AS base_ind , item_type_after AS item_type , conc_dextrose_ind_after AS conc_dextrose_ind , container_ind_after AS container_ind , container_type_after AS container_type , primary_vendor_name_after AS primary_vendor_name , secondary_vendor_name_after AS secondary_vendor_name , tertiary_vendor_name_after AS tertiary_vendor_name , plx_drug_ind_after AS plx_drug_ind , item_size_after AS item_size , item_size_units_after AS item_size_units , item_long_desc_after AS item_long_desc , item_short_desc_after AS item_short_desc , item_awp_after AS item_awp , billing_multiplier_after AS billing_multiplier , track_inventory_ind_after AS track_inventory_ind , disease_state_ind_after AS disease_state_ind , drug_min_price_after AS drug_min_price , drug_inference_cd_after AS drug_inference_cd , excl_drug_automation_ind_after AS excl_drug_automation_ind , excl_tbltp_count_ind_after AS excl_tbltp_count_ind , require_tbltp_clean_after AS require_tbltp_clean , thera_class_extd_after AS thera_class_extd , hzrds_lvl_cd_after AS hzrds_lvl_cd ,auth_generic_cd_after As auth_generic_cd , fda_ind_after As fda_ind , fda_ind_value_after As fda_ind_value , auth_ndc_upc_hri_after As auth_ndc_upc_hri , auth_gen_override_ind_after As auth_gen_override_ind , ddid_after As ddid , rxcui_type_after As rxcui_type , rxcui_after As rxcui , elsevier_pack_id_after As elsevier_pack_id , elsevier_prod_id_after As elsevier_prod_id , med_dosage_unit_after As med_dosage_unit , med_conv_factor_after As med_conv_factor , mme_calc_factor_after As mme_calc_factor , 
'""" + SRC_TBL_NAME +  """' as table_name
from nr_insert_check """

#print(pTgtUpdAftXfr)


# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)





# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
#display(etl_tbf0_file)
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
#print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
#display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
#display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm", to_timestamp(etl_tbf0_reformat_cdc_check_notnull["cdc_txn_commit_dttm"]))\
           .withColumn("a_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["a_last_change_dttm"]))\
           .withColumn("e_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["e_last_change_dttm"]))\
           .withColumn("g_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["g_last_change_dttm"]))\
           .withColumn("j_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["j_last_change_dttm"]))\
           .withColumn("rx_to_otc_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["rx_to_otc_dttm"]))\
           .withColumn("l_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["l_last_change_dttm"]))\
           .withColumn("awp_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["awp_dttm"]))\
           .withColumn("r_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["r_last_change_dttm"]))\
           .withColumn("hcfa_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["hcfa_dttm"]))\
           .withColumn("t_last_change_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["t_last_change_dttm"]))\
           .withColumn("drug_disc_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["drug_disc_dttm"]))\
           .withColumn("create_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["update_dttm"]))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_cdc_check_notnull.columns])

display(etl_tbf0_reformat_cdc_check_notnull)



# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()


# COMMAND ----------

# # ReadAPI Call to fetch asset file names with current location:  
# WRITEAPI_URL = dbutils.widgets.get("PAR_WRITEAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 60, 
#                   {"PAR_WRITEAPI_URL":WRITEAPI_URL,
#                    "PAR_WRITEAPI_KEY1":"statusId",
#                    "PAR_WRITEAPI_VALUE1":"200",
#                    "PAR_WRITEAPI_KEY2":"assetId",
#                    "PAR_WRITEAPI_VALUE2":dfAssetIdStr});

# print("Write API successfully executed...")

# COMMAND ----------

dbutils.notebook.exit("ETL_TBF0_DRUG LOADED SUCCESSFULLY")
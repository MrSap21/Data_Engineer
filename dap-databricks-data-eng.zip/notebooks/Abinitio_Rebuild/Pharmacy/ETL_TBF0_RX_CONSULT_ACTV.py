# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# #Create Widgets for Parameters
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220224070910")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","etl_tbf0_rx_consult_actv")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_CONSULT_ACTV_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_UNPROCESSED_FILES","/mnt/wrangled/pharmacy_healthcare/patient_services/icplus/2022/02/15/PRDRX2STAGE_GG_TBF0_RX_CONSULT_ACTV_4_2022-02-04_00-13-05_01674_data_20220106220003.dsv")
# dbutils.widgets.text("PAR_DB_FEED_NAME","GG_TBF0_RX_CONSULT_ACTV")

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
#FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
#READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
#BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
#PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
#PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
#PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
#PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

#Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 100, 
#                 {"PAR_EDW_BATCH_ID":BATCH_ID,
#                  "PAR_FEED_NAMES":FEED_NAME,
#                  "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
#                  "PAR_READAPI_URL":READAPI_URL,
#                  "PAR_SQL_SERVER":PAR_SQL_SERVER,
#                 "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
#                  "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
#                  "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
#                  "PAR_RETURN_FILE_TYPE":"A"});
#
#print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")
FEED_NAME = dbutils.widgets.get("PAR_DB_FEED_NAME")
Input_File_List=dbutils.widgets.get("PAR_UNPROCESSED_FILES")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'src_partition_nbr',
'src_partition_nbr_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_partial_nbr',
'fill_partial_nbr_after',
'consult_act_type_cd',
'consult_act_type_cd_after',
'camp_id',
'camp_id_after',
'fill_nbr_dispensed',
'fill_nbr_dispensed_after',
'consult_act_status_ind',
'consult_act_status_ind_after',
'consult_req_rph_user_id',
'consult_req_rph_user_id_after',
'consult_req_rph_inits',
'consult_req_rph_inits_after',
'consult_req_dttm',
'consult_req_dttm_after',
'consult_req_comments',
'consult_req_comments_after',
'consult_res_rph_user_id',
'consult_res_rph_user_id_after',
'consult_res_rph_inits',
'consult_res_rph_inits_after',
'consult_res_dttm',
'consult_res_dttm_after',
'consult_res_comments',
'consult_res_comments_after',
'fill_entered_dttm',
'fill_entered_dttm_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'remote_store_nbr',
'remote_store_nbr_after',
'rph_barcd_supervsr_id',
'rph_barcd_supervsr_id_after'
]

#col_len = len(fieldList)
#print(col_len)

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst1[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 61 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 62:
      return True
  else:
    if val_len != 62:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len =62

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

#print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

#print(f"Good records count {rd_good.count()}") # = 492
#print(f"Bad records count {rd_bad.count()}") # != 492


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

#Extarct filename
from pyspark.sql.functions import input_file_name
df = spark.createDataFrame(rd_good, schema)
df_fileName = df.withColumn("fileName",input_file_name())

#Extract partition number from file name
df_split = df_fileName.withColumn("src_partition_nbr",concat(split(col("fileName"),"_")[8]))
df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df_split = df_split.drop("fileName")

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df_split = df_split.drop('row_length')
#df_split = (reduce(
#   lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df_split.columns,
#     df_split
# ))

# COMMAND ----------

df_split.createOrReplaceTempView("gg_tbf0_rx_consult_actv")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_rx_consult_actv where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")



#print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_rx_consult_actv"))
          
df_gg.createOrReplaceTempView("raw_gg_tbf0_rx_consult_actv")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="( (  store_nbr == store_nbr_after AND  store_nbr IS NOT NULL AND  store_nbr_after IS NOT NULL)  AND   (rx_nbr == rx_nbr_after AND  rx_nbr IS NOT NULL AND  rx_nbr_after IS NOT NULL)  AND (  create_dttm == create_dttm_after AND  create_dttm IS NOT NULL AND  create_dttm_after IS NOT NULL) AND (cdc_seq_nbr == cdc_seq_nbr_after AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL)  AND   (cdc_rba_nbr == cdc_rba_nbr_after AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL)  AND   (cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL) AND  (cdc_before_after_cd_after == 'AFTER' AND  cdc_before_after_cd_after IS NOT NULL) AND    (cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND  cdc_operation_type_cd_after IS NOT NULL) AND    (cdc_before_after_cd == 'BEFORE' AND  cdc_before_after_cd IS NOT NULL) AND     (cdc_operation_type_cd == 'SQL COMPUPDATE' AND  cdc_operation_type_cd IS NOT NULL) AND fill_nbr_dispensed  == fill_nbr_dispensed_after AND  fill_nbr_dispensed IS NOT NULL AND  fill_nbr_dispensed_after IS NOT NULL AND consult_act_type_cd == consult_act_type_cd_after AND consult_act_type_cd IS NOT NULL AND  consult_act_type_cd_after IS NOT NULL AND  camp_id == camp_id_after AND camp_id IS NOT NULL AND  camp_id_after IS NOT NULL AND (fill_nbr == fill_nbr_after AND fill_nbr IS NOT NULL AND fill_nbr_after IS NOT NULL OR ( fill_nbr IS NULL AND fill_nbr_after IS NULL )) AND (fill_partial_nbr == fill_partial_nbr_after AND fill_partial_nbr IS NOT NULL AND fill_partial_nbr_after IS NOT NULL OR ( fill_partial_nbr IS NULL AND fill_partial_nbr_after IS NULL )) AND (consult_act_status_ind == consult_act_status_ind_after AND consult_act_status_ind IS NOT NULL AND consult_act_status_ind_after IS NOT NULL OR ( consult_act_status_ind IS NULL AND consult_act_status_ind_after IS NULL )) AND (consult_req_rph_user_id == consult_req_rph_user_id_after AND consult_req_rph_user_id IS NOT NULL AND consult_req_rph_user_id_after IS NOT NULL OR ( consult_req_rph_user_id IS NULL AND consult_req_rph_user_id_after IS NULL )) AND (consult_req_rph_inits == consult_req_rph_inits_after AND consult_req_rph_inits IS NOT NULL AND consult_req_rph_inits_after IS NOT NULL OR ( consult_req_rph_inits IS NULL AND  consult_req_rph_inits_after IS NULL)) AND  ( consult_req_dttm  == consult_req_dttm_after AND consult_req_dttm IS NOT NULL AND consult_req_dttm_after IS NOT NULL OR (consult_req_dttm  IS NULL AND  consult_req_dttm_after  IS NULL)) AND  ( consult_req_comments  == consult_req_comments_after AND consult_req_comments IS NOT NULL AND consult_req_comments_after IS NOT NULL OR ( consult_req_comments IS NULL AND  consult_req_comments_after IS NULL))AND  ( consult_res_rph_user_id == consult_res_rph_user_id_after AND consult_res_rph_user_id IS NOT NULL AND consult_res_rph_user_id_after IS NOT NULL OR ( consult_res_rph_user_id IS NULL AND  consult_res_rph_user_id_after IS NULL)) AND  ( consult_res_rph_inits  == consult_res_rph_inits_after AND consult_res_rph_inits IS NOT NULL AND consult_res_rph_inits_after IS NOT NULL OR ( consult_res_rph_inits  IS NULL AND  consult_res_rph_inits_after  IS NULL)) AND  ( consult_res_dttm  == consult_res_dttm_after AND consult_res_dttm IS NOT NULL AND consult_res_dttm_after IS NOT NULL OR ( consult_res_dttm IS NULL AND  consult_res_dttm_after IS NULL)) AND  ( consult_res_comments == consult_res_comments_after AND consult_res_comments IS NOT NULL AND consult_res_comments_after IS NOT NULL OR ( consult_res_comments IS NULL AND  consult_res_comments_after IS NULL)) AND  ( fill_entered_dttm == fill_entered_dttm_after AND fill_entered_dttm IS NOT NULL AND fill_entered_dttm_after IS NOT NULL OR ( fill_entered_dttm IS NULL AND  fill_entered_dttm_after IS NULL)) AND  ( remote_store_nbr  == remote_store_nbr_after AND remote_store_nbr IS NOT NULL AND remote_store_nbr_after IS NOT NULL OR ( remote_store_nbr IS NULL AND  remote_store_nbr_after IS NULL)) AND  ( rph_barcd_supervsr_id  == rph_barcd_supervsr_id_after AND rph_barcd_supervsr_id IS NOT NULL AND rph_barcd_supervsr_id_after IS NOT NULL OR ( rph_barcd_supervsr_id  IS NULL AND  rph_barcd_supervsr_id_after IS NULL)) )" 

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm , cdc_seq_nbr , cdc_rba_nbr , cdc_operation_type_cd , cdc_before_after_cd , cdc_txn_position_cd , edw_batch_id , src_partition_nbr , store_nbr , rx_nbr , fill_nbr , fill_partial_nbr , consult_act_type_cd , camp_id , fill_nbr_dispensed , consult_act_status_ind , consult_req_rph_user_id , consult_req_rph_inits , CONCAT(consult_req_dttm,'.000000') AS consult_req_dttm , consult_req_comments , consult_res_rph_user_id , consult_res_rph_inits , CONCAT(consult_res_dttm,'.000000') AS consult_res_dttm , consult_res_comments , CONCAT(fill_entered_dttm,'.000000') AS fill_entered_dttm , create_user_id , CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id , CONCAT(update_dttm,'.000000') AS update_dttm, remote_store_nbr ,(CASE WHEN (cdc_operation_type_cd=='INSERT') THEN store_nbr ELSE '' END) AS relocate_fm_str_nbr , rph_barcd_supervsr_id , tracking_id , partition_column"


# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}".format(ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

# BATCH_ID_CHK =  BATCH_ID 
# PROJ_ID_CHK =  PROJ_ID 

# cutoff_records_filter = cutoff_records_output.withColumn("EDW_BATCH_ID",concat(lit("'"),col("EDW_BATCH_ID"),lit("'")))\
#                                              .withColumn("PROJ_NAME",concat(lit("'"),col("PROJ_NAME"),lit("'")))

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == "WALGREENS"))
#display(cutoff_records_filter)

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))

rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_rx_consult_actv where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_rx_consult_actv where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_rx_consult_actv where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  
  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])
  
  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  
  #Remove duplicates
dedup_group = nr_input_file_final.distinct()



dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")


# COMMAND ----------

dedup_group.printSchema()

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim(src_partition_nbr))==0) then src_partition_nbr else TRIM(src_partition_nbr) end) as src_partition_nbr ,  
(case when (LENGTH(trim(src_partition_nbr_after))==0) then src_partition_nbr_after else TRIM(src_partition_nbr_after) end) as src_partition_nbr_after,  
(case when (LENGTH(trim(store_nbr))==0) then store_nbr else TRIM(store_nbr) end) as store_nbr ,  
(case when (LENGTH(trim(store_nbr_after))==0) then store_nbr_after else TRIM(store_nbr_after) end) as store_nbr_after ,  
(case when (LENGTH(trim(rx_nbr))==0) then rx_nbr else TRIM(rx_nbr) end) as rx_nbr ,  
(case when (LENGTH(trim(rx_nbr_after))==0) then rx_nbr_after else TRIM(rx_nbr_after) end) as rx_nbr_after ,  
(case when (LENGTH(trim(fill_nbr))==0) then fill_nbr else TRIM(fill_nbr) end) as fill_nbr ,  
(case when (LENGTH(trim(fill_nbr_after))==0) then fill_nbr_after else TRIM(fill_nbr_after) end) as fill_nbr_after ,  
(case when (LENGTH(trim(fill_partial_nbr))==0) then fill_partial_nbr else TRIM(fill_partial_nbr) end) as fill_partial_nbr ,  
(case when (LENGTH(trim(fill_partial_nbr_after))==0) then fill_partial_nbr_after else TRIM(fill_partial_nbr_after) end) as fill_partial_nbr_after ,  
(case when (LENGTH(trim(consult_act_type_cd))==0) then consult_act_type_cd else TRIM(consult_act_type_cd) end) as consult_act_type_cd ,  
(case when (LENGTH(trim(consult_act_type_cd_after))==0) then consult_act_type_cd_after else TRIM(consult_act_type_cd_after) end) as consult_act_type_cd_after ,  
(case when (LENGTH(trim(camp_id))==0) then camp_id else TRIM(camp_id) end) as camp_id ,  
(case when (LENGTH(trim(camp_id_after))==0) then camp_id_after else TRIM(camp_id_after) end) as camp_id_after ,  
(case when (LENGTH(trim(fill_nbr_dispensed))==0) then fill_nbr_dispensed else TRIM(fill_nbr_dispensed) end) as fill_nbr_dispensed ,  
(case when (LENGTH(trim(fill_nbr_dispensed_after))==0) then fill_nbr_dispensed_after else TRIM(fill_nbr_dispensed_after) end) as fill_nbr_dispensed_after ,  
(case when (LENGTH(trim(consult_act_status_ind))==0) then consult_act_status_ind else TRIM(consult_act_status_ind) end) as consult_act_status_ind ,  
(case when (LENGTH(trim(consult_act_status_ind_after))==0) then consult_act_status_ind_after else TRIM(consult_act_status_ind_after) end) as consult_act_status_ind_after ,  
(case when (LENGTH(trim(consult_req_rph_user_id))==0) then consult_req_rph_user_id else TRIM(consult_req_rph_user_id) end) as consult_req_rph_user_id ,  
(case when (LENGTH(trim(consult_req_rph_user_id_after))==0) then consult_req_rph_user_id_after else TRIM(consult_req_rph_user_id_after) end) as consult_req_rph_user_id_after ,  
(case when (LENGTH(trim(consult_req_rph_inits))==0) then consult_req_rph_inits else TRIM(consult_req_rph_inits) end) as consult_req_rph_inits ,  
(case when (LENGTH(trim(consult_req_rph_inits_after))==0) then consult_req_rph_inits_after else TRIM(consult_req_rph_inits_after) end) as consult_req_rph_inits_after ,  
CONCAT(CONCAT(SUBSTRING(consult_req_dttm,0,10),' '),SUBSTRING(consult_req_dttm,11,19)) as consult_req_dttm ,  
CONCAT(CONCAT(SUBSTRING(consult_req_dttm_after,0,10),' '),SUBSTRING(consult_req_dttm_after,11,19)) as consult_req_dttm_after ,  
(case when (LENGTH(trim(consult_req_comments))==0) then consult_req_comments else TRIM(consult_req_comments) end) as consult_req_comments ,  
(case when (LENGTH(trim(consult_req_comments_after))==0) then consult_req_comments_after else TRIM(consult_req_comments_after) end) as consult_req_comments_after ,  
(case when (LENGTH(trim(consult_res_rph_user_id))==0) then consult_res_rph_user_id else TRIM(consult_res_rph_user_id) end) as consult_res_rph_user_id ,  
(case when (LENGTH(trim(consult_res_rph_user_id_after))==0) then consult_res_rph_user_id_after else TRIM(consult_res_rph_user_id_after) end) as consult_res_rph_user_id_after ,  
(case when (LENGTH(trim(consult_res_rph_inits))==0) then consult_res_rph_inits else TRIM(consult_res_rph_inits) end) as consult_res_rph_inits ,  
(case when (LENGTH(trim(consult_res_rph_inits_after))==0) then consult_res_rph_inits_after else TRIM(consult_res_rph_inits_after) end) as consult_res_rph_inits_after ,  
CONCAT(CONCAT(SUBSTRING(consult_res_dttm,0,10),' '),SUBSTRING(consult_res_dttm,11,19)) as consult_res_dttm ,  
CONCAT(CONCAT(SUBSTRING(consult_res_dttm_after,0,10),' '),SUBSTRING(consult_res_dttm_after,11,19)) as consult_res_dttm_after ,  
(case when (LENGTH(trim(consult_res_comments))==0) then consult_res_comments else TRIM(consult_res_comments) end) as consult_res_comments ,  
(case when (LENGTH(trim(consult_res_comments_after))==0) then consult_res_comments_after else TRIM(consult_res_comments_after) end) as consult_res_comments_after ,  
CONCAT(CONCAT(SUBSTRING(fill_entered_dttm,0,10),' '),SUBSTRING(fill_entered_dttm,11,19)) as fill_entered_dttm ,  
CONCAT(CONCAT(SUBSTRING(fill_entered_dttm_after,0,10),' '),SUBSTRING(fill_entered_dttm_after,11,19)) as fill_entered_dttm_after ,  
(case when (LENGTH(trim(create_user_id))==0) then create_user_id else TRIM(create_user_id) end) as create_user_id ,  
(case when (LENGTH(trim(create_user_id_after))==0) then create_user_id_after else TRIM(create_user_id_after) end) as create_user_id_after ,  CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm,11,19)) as create_dttm ,  
CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after,11,19)) as create_dttm_after ,  
(case when (LENGTH(trim(update_user_id))==0) then update_user_id else TRIM(update_user_id) end) as update_user_id ,  
(case when (LENGTH(trim(update_user_id_after))==0) then update_user_id_after else TRIM(update_user_id_after) end) as update_user_id_after ,  CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm,11,19)) as update_dttm ,  
CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after,11,19)) as update_dttm_after ,  
(case when (LENGTH(trim(remote_store_nbr))==0) then remote_store_nbr else TRIM(remote_store_nbr) end) as remote_store_nbr ,  
(case when (LENGTH(trim(remote_store_nbr_after))==0) then remote_store_nbr_after else TRIM(remote_store_nbr_after) end) as remote_store_nbr_after ,  
(case when (LENGTH(trim(rph_barcd_supervsr_id))==0) then rph_barcd_supervsr_id else TRIM(rph_barcd_supervsr_id) end) as rph_barcd_supervsr_id ,  
(case when (LENGTH(trim(rph_barcd_supervsr_id_after))==0) then rph_barcd_supervsr_id_after else TRIM(rph_barcd_supervsr_id_after) end) as rph_barcd_supervsr_id_after from dedup_group""" 

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
# display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 


gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
src_partition_nbr_after AS src_partition_nbr , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , consult_act_type_cd_after AS consult_act_type_cd , camp_id_after AS camp_id , fill_nbr_dispensed_after AS fill_nbr_dispensed , consult_act_status_ind_after AS consult_act_status_ind , consult_req_rph_user_id_after AS consult_req_rph_user_id , consult_req_rph_inits_after AS consult_req_rph_inits , consult_req_dttm_after AS consult_req_dttm , consult_req_comments_after AS consult_req_comments , consult_res_rph_user_id_after AS consult_res_rph_user_id , consult_res_rph_inits_after AS consult_res_rph_inits , consult_res_dttm_after AS consult_res_dttm , consult_res_comments_after AS consult_res_comments , fill_entered_dttm_after AS fill_entered_dttm , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , remote_store_nbr_after AS remote_store_nbr , rph_barcd_supervsr_id_after AS rph_barcd_supervsr_id , 
'000000' AS tracking_id ,
'' AS partition_column,
'GG_TBF0_RX_CONSULT_ACTV' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,
src_partition_nbr AS src_partition_nbr , store_nbr AS store_nbr , rx_nbr AS rx_nbr , fill_nbr AS fill_nbr , fill_partial_nbr AS fill_partial_nbr , consult_act_type_cd AS consult_act_type_cd , camp_id AS camp_id , fill_nbr_dispensed AS fill_nbr_dispensed , consult_act_status_ind AS consult_act_status_ind , consult_req_rph_user_id AS consult_req_rph_user_id , consult_req_rph_inits AS consult_req_rph_inits , consult_req_dttm AS consult_req_dttm , consult_req_comments AS consult_req_comments , consult_res_rph_user_id AS consult_res_rph_user_id , consult_res_rph_inits AS consult_res_rph_inits , consult_res_dttm AS consult_res_dttm , consult_res_comments AS consult_res_comments , fill_entered_dttm AS fill_entered_dttm , create_user_id AS create_user_id , create_dttm AS create_dttm , update_user_id AS update_user_id , update_dttm AS update_dttm , remote_store_nbr AS remote_store_nbr , rph_barcd_supervsr_id AS rph_barcd_supervsr_id ,
'000000' AS tracking_id ,
'' AS partition_column,
'GG_TBF0_RX_CONSULT_ACTV' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
 src_partition_nbr_after AS src_partition_nbr , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , consult_act_type_cd_after AS consult_act_type_cd , camp_id_after AS camp_id , fill_nbr_dispensed_after AS fill_nbr_dispensed , consult_act_status_ind_after AS consult_act_status_ind , consult_req_rph_user_id_after AS consult_req_rph_user_id , consult_req_rph_inits_after AS consult_req_rph_inits , consult_req_dttm_after AS consult_req_dttm , consult_req_comments_after AS consult_req_comments , consult_res_rph_user_id_after AS consult_res_rph_user_id , consult_res_rph_inits_after AS consult_res_rph_inits , consult_res_dttm_after AS consult_res_dttm , consult_res_comments_after AS consult_res_comments , fill_entered_dttm_after AS fill_entered_dttm , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , remote_store_nbr_after AS remote_store_nbr , rph_barcd_supervsr_id_after AS rph_barcd_supervsr_id ,
'000000' AS tracking_id ,
'' AS partition_column,
'GG_TBF0_RX_CONSULT_ACTV' as table_name 
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)


# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")

  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
# print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))


etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())


#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 
#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

df_correct_time_format = etl_tbf0_reformat_cdc_check_notnull.withColumn("consult_req_dttm",trim("consult_req_dttm"))\
                                                            .withColumn("consult_res_dttm",trim("consult_res_dttm"))\
                                                            .withColumn("fill_entered_dttm",trim("fill_entered_dttm"))\
                                                            .withColumn("create_dttm",trim("create_dttm"))\
                                                            .withColumn("update_dttm",trim("update_dttm"))

df_time_format_corrected = df_correct_time_format.withColumn("consult_req_dttm",concat(split(col("consult_req_dttm"),":")[0],split(col("consult_req_dttm"),":")[1],lit(":"),split(col("consult_req_dttm"),":")[2],lit(":"),split(col("consult_req_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("consult_res_dttm",concat(split(col("consult_res_dttm"),":")[0],split(col("consult_res_dttm"),":")[1],lit(":"),split(col("consult_res_dttm"),":")[2],lit(":"),split(col("consult_res_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("fill_entered_dttm",concat(split(col("fill_entered_dttm"),":")[0],split(col("fill_entered_dttm"),":")[1],lit(":"),split(col("fill_entered_dttm"),":")[2],lit(":"),split(col("fill_entered_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("create_dttm",concat(split(col("create_dttm"),":")[0],split(col("create_dttm"),":")[1],lit(":"),split(col("create_dttm"),":")[2],lit(":"),split(col("create_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("update_dttm",concat(split(col("update_dttm"),":")[0],split(col("update_dttm"),":")[1],lit(":"),split(col("update_dttm"),":")[2],lit(":"),split(col("update_dttm"),":")[3]))

# COMMAND ----------

etl_tbf0_reformat_typeCast = df_time_format_corrected.withColumn("cdc_txn_commit_dttm",to_timestamp(df_time_format_corrected["cdc_txn_commit_dttm"]))\
			.withColumn("consult_req_dttm",to_timestamp(df_time_format_corrected["consult_req_dttm"]))\
			.withColumn("consult_res_dttm",to_timestamp(df_time_format_corrected["consult_res_dttm"]))\
			.withColumn("fill_entered_dttm",to_timestamp(df_time_format_corrected["fill_entered_dttm"]))\
			.withColumn("create_dttm",to_timestamp(df_time_format_corrected["create_dttm"]))\
            .withColumn("update_dttm",to_timestamp(df_time_format_corrected["update_dttm"]))\
			.withColumn("cdc_operation_type_cd",substring(col("cdc_operation_type_cd"),0,20))\
			.withColumn("cdc_before_after_cd",substring(col("cdc_before_after_cd"),0,10))\
			.withColumn("cdc_txn_position_cd",substring(col("cdc_txn_position_cd"),0,10))\
			.withColumn("consult_act_type_cd",substring(col("consult_act_type_cd"),0,3))\
			.withColumn("consult_act_status_ind",substring(col("consult_act_status_ind"),0,1))\
			.withColumn("consult_req_rph_inits",substring(col("consult_req_rph_inits"),0,3))\
			.withColumn("consult_req_comments",substring(col("consult_req_comments"),0,370))\
			.withColumn("consult_res_rph_inits",substring(col("consult_res_rph_inits"),0,3))\
			.withColumn("consult_res_comments",substring(col("consult_res_comments"),0,370))

etl_tbf0_reformat_check_blank = etl_tbf0_reformat_typeCast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_typeCast.columns])
#display(etl_tbf0_reformat_check_blank)


# COMMAND ----------

#drop columns to map table schema
etl_tbf0_reformat_drop_columns = etl_tbf0_reformat_check_blank.drop("tracking_id","partition_column")

# COMMAND ----------

df_drop_nulls = etl_tbf0_reformat_drop_columns.filter("store_nbr is not null and rx_nbr is not null and fill_nbr is not null and fill_partial_nbr is not null and consult_act_type_cd is not null and camp_id is not null")
df_final = df_drop_nulls.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","src_partition_nbr","store_nbr","rx_nbr","fill_nbr","fill_partial_nbr","consult_act_type_cd","camp_id","fill_nbr_dispensed","consult_act_status_ind","consult_req_rph_user_id","consult_req_rph_inits","consult_req_dttm","consult_req_comments","consult_res_rph_user_id","consult_res_rph_inits","consult_res_dttm","consult_res_comments","fill_entered_dttm","create_user_id","create_dttm","update_user_id","update_dttm","remote_store_nbr","relocate_fm_str_nbr","rph_barcd_supervsr_id")

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()


TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]
df_final.write \
.format("snowflake") \
.options(**options) \
.option("sfWarehouse", SNFL_WH) \
.option("sfDatabase", SNFL_DB) \
.option("dbtable", TL_SNFL_TBL_NAME) \
.option("ON_ERROR", "SKIP_FILE") \
.option("truncate_table","ON")\
.option("use staging table","OFF")\
.mode("overwrite") \
.save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

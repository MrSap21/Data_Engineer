# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Import Python libs
import json
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("DELTA_FILE_NAME","",label="DELTA_FILE_NAME")
dbutils.widgets.text("DELTA_FILE_DIR","",label="DELTA_FILE_DIR")
dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")

output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")
delta_file_name = dbutils.widgets.get("DELTA_FILE_NAME")
delta_file_dir = dbutils.widgets.get("DELTA_FILE_DIR")
delta_file_path = mount_point + '/' + delta_file_dir + '/' + delta_file_name + '/' + batch_id
output_file_path = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir + '/' + batch_id

# COMMAND ----------

# Define column values in List((tuple0,tuple1)) -- List((columnnamewithrelativetags,onlycolumnname))
col_list = [("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId"),("providerInfo_entityID","entityID"),("providerInfo_professionalInfo_dea_number","deainfnumber"),("providerInfo_professionalInfo_dea_suffix","profsuffix"),("providerInfo_professionalInfo_dea_expirationDate","deaexpirationDate"),("providerInfo_professionalInfo_dea_data2000WaiverID","profdata2000WaiverID"),("providerInfo_professionalInfo_dea_rank","rank"),("providerInfo_professionalInfo_dea_activeIndicator","profactiveIndicator"),("providerInfo_professionalInfo_dea_businessActivityCode","businessActivityCode"),("providerInfo_professionalInfo_dea_businessActivitySubCode","businessActivitySubCode"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted2","profschedulePermitted2"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted2N","profschedulePermitted2N"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted3","profschedulePermitted3"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted3N","profschedulePermitted3N"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted4","profschedulePermitted4"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted5","profschedulePermitted5")]

selected  = [col(j) for k, j in col_list]

# COMMAND ----------

#Read from delta

delta_df = spark.read.format("delta").load(delta_file_path)
delta_df1=delta_df.select(*selected)
renamed_df = delta_df1.withColumnRenamed("deainfnumber","number")\
             .withColumnRenamed("profsuffix","suffix")\
             .withColumnRenamed("deaexpirationDate","expirationDate")\
             .withColumnRenamed("profactiveIndicator","activeIndicator")\
             .withColumnRenamed("providerInfo_professionalInfo_dea_data2000WaiverID","profdata2000WaiverID")\
             .withColumnRenamed("profschedulePermitted2","schedulePermitted2")\
             .withColumnRenamed("profschedulePermitted2N","schedulePermitted2N")\
             .withColumnRenamed("profschedulePermitted3","schedulePermitted3")\
             .withColumnRenamed("profschedulePermitted3N","schedulePermitted3N")\
             .withColumnRenamed("profschedulePermitted4","schedulePermitted4")\
             .withColumnRenamed("profschedulePermitted5","schedulePermitted5")\

result_df=renamed_df.dropDuplicates()

# COMMAND ----------

# filter to remove unnecesary records
df_final = result_df.filter("number is not null")

# COMMAND ----------

# Write output (parquet)
write_data(df_final,output_file_path)

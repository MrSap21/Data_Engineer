# Databricks notebook source
import os
import json
#dbutils.widgets.text("PAR_NB_CONFIG_FILE","",label="PAR_NB_CONFIG_FILE")
#dbutils.widgets.remove("PAR_PL_CONFIG_FILE")
# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters
#config_file = dbutils.widgets.get("PAR_NB_CONFIG_FILE")
# dbutils.widgets.text("PAR_NB_PARAMETER_LIST","$AI_SERIAL=/customer/dap_gen_run_pgm/script,$EDW_BATCH_ID=20190404")

os.environ['scriptPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_SCRIPT_PATH") 
os.environ['scriptName'] = dbutils.widgets.get("PAR_NB_SCRIPT_NAME")

os.environ['batchId'] = dbutils.widgets.get("PAR_NB_BATCH_ID")

os.environ['configFile'] = dbutils.widgets.get("PAR_NB_CONFIG_FILE")
 

# COMMAND ----------



# COMMAND ----------

# MAGIC %sh
# MAGIC 
# MAGIC pushd $scriptPath
# MAGIC . /dbfs/mnt/WrangledZone/$configFile
# MAGIC $scriptPath/$scriptName $batchId
# MAGIC 
# MAGIC popd
# Databricks notebook source

from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *
'''
dbutils.widgets.text("PAR_NB_BATCH_ID","20220606000000")
dbutils.widgets.text("PAR_NB_STG_DB","DEV_STAGING")
dbutils.widgets.text("PAR_NB_RET_DB","DEV_RETAIL")
dbutils.widgets.text("PAR_NB_CON_DB","DEV_CONSUMPTION")
dbutils.widgets.text("PAR_NB_MSTR_DB","DEV_MASTER_DATA")
dbutils.widgets.text("PAR_NB_PHARM_DB","DEV_PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_NB_SNFK_WH","WBADEVDBENGINEER_WH")
'''



PAR_DF_EMNOS_FEED_TBL="PARTNER.EMNOS_CNTRL_RUN_DT_FEED_STG"
PAR_STG_DB=dbutils.widgets.get("PAR_NB_STG_DB")
PAR_RET_DB=dbutils.widgets.get("PAR_NB_RET_DB")
PAR_CON_DB=dbutils.widgets.get("PAR_NB_CON_DB")
PAR_MSTR_DB=dbutils.widgets.get("PAR_NB_MSTR_DB")
PAR_PHARM_DB=dbutils.widgets.get("PAR_NB_PHARM_DB")
PAR_BATCH_ID=dbutils.widgets.get("PAR_NB_BATCH_ID")
SNFL_WH = dbutils.widgets.get("PAR_NB_SNFK_WH")

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=PAR_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

query1="""select coalesce(max(extract_run_dt),'2022-04-01'),
coalesce(to_varchar(max(extract_dttm),'YYYY-MM-DD HH24:MI:SS'),'2022-04-01 00:00:00')
,lpad(coalesce(max(extract_seq),0),8,0) from {0}.{1} where proj_name='Emnos_extracts' 
and src_stream_name = 'card_file_ext' and extract_name='Emnos_card_file'""".format(PAR_STG_DB,PAR_DF_EMNOS_FEED_TBL)
query2="""select coalesce(to_varchar(max(extract_dttm),'YYYY-MM-DD HH24:MI:SS'),'2022-04-01 00:00:00') from {0}.{1} where proj_name='Emnos_extracts' 
and src_stream_name = 'ecom_card_file_ext' and extract_name='Emnos_ecom_card_file'""".format(PAR_STG_DB,PAR_DF_EMNOS_FEED_TBL)
print(query1)
print(query2)

# COMMAND ----------


df_q1_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query1)\
   .load()
df_q2_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query2)\
   .load()
#df_q1_out.show()
#df_q2_out.show()


pSQL_PARM_1=df_q1_out.collect()[0][0]
pSQL_PARM_3=df_q1_out.collect()[0][1]
pSEQ_NBR=df_q1_out.collect()[0][2]
pSQL_PARM_4=df_q2_out.collect()[0][0]
pRUN_DT=pSQL_PARM_1
pMAX_DTTM=pSQL_PARM_3
pMAX_EC_DTTM=pSQL_PARM_4

PROCESS_DATES_LIST=[str(pRUN_DT),str(pMAX_DTTM),str(pSEQ_NBR),str(pMAX_EC_DTTM)]
process_dates_str=str(PROCESS_DATES_LIST).replace("[","").replace("]","")
print(process_dates_str)



# COMMAND ----------

q1="""   select MID ,consumer_src_id from ( select MID,consumer_src_id,row_number() over (partition by mid order by consumer_src_id desc) as rn from (SELECT  
'E'||trim(mid.cdi_cust_src_id) AS MID ,
 mid.cust_src_id as consumer_src_id
FROM 
(select * from {RET_DB}.RETAIL_SALES.Sales_transaction_detail 
where sales_txn_dt between to_char(DATEADD(DAY, -6, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and to_char(CAST('{pSQL_PARM_1}' as date), 'YYYY-MM-DD') and  src_sys_cd='{pSRC_SYS_CD}'
union all
select * from {RET_DB}.RETAIL_SALES.Sales_transaction_detail 
where 
sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and to_char(DATEADD(DAY, -7, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and src_sys_cd='{pSRC_SYS_CD}'
AND edw_create_dttm > '{pSQL_PARM_3}' ) a
JOIN {RET_DB}.RETAIL_SALES.SALES_TRANSACTION b ON
a.sales_txn_id=b.sales_txn_id
and  a.sales_txn_dt=b.sales_txn_dt
and  a.sales_ord_src_type=b.sales_ord_src_type
and a.sales_txn_type=b.sales_txn_type
and a.src_sys_cd=b.src_sys_cd
and b.src_sys_cd='{pSRC_SYS_CD}'
JOIN (select * from {PHARM_DB}.PATIENT_SERVICES.PRESCRIPTION_FILL WHERE fill_stat_cd = 'SD'
        AND  fill_del_dt IS NULL
        AND  fill_sold_dt IS NOT NULL
        AND  fill_sold_dlrs IS NOT NULL) pfs 
ON 
   b.store_nbr = pfs.str_nbr 
   AND
pfs.rx_nbr = TRY_CAST(a.rx_nbr AS INTEGER)
AND pfs.fill_sold_dt = a.sales_txn_dt
JOIN {CON_DB}.PRDFDLVWB.link_to_customer mid ON mid.cust_src_id =   CAST(translate(to_char(pfs.pat_id ), ' ', '')  AS VARCHAR(20))
AND mid.cust_src_cd = '{pSRC_SYS_CD1}'
AND mid.edw_rec_end_dt =  {pTD_EDW_END_DATE}
WHERE a.rx_nbr IS NOT NULL
and mid.cdi_msg_type_cd = '2'
AND fill_sold_dt between to_char(DATEADD(DAY, -30, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and '{pSQL_PARM_1}'
group by 1,2 union all select 
'E'||trim(b.cdi_cust_src_id) as mid,
b.cust_src_id as consumer_src_id
from (select * from {RET_DB}.RETAIL_SALES.Sales_transaction_detail 
where sales_txn_dt between to_char(DATEADD(DAY, -6, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and to_char(CAST('{pSQL_PARM_1}' as date), 'YYYY-MM-DD') and  src_sys_cd='{pSRC_SYS_CD}'
union all
select * from {RET_DB}.RETAIL_SALES.Sales_transaction_detail 
where sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and to_char(DATEADD(DAY, -7, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD')
 and src_sys_cd='{pSRC_SYS_CD}' and edw_create_dttm > '{pSQL_PARM_3}' ) a
inner join 
(SELECT mid.cdi_cust_src_id , mid.cust_src_id,pop.sales_txn_id,pop.txn_dt,pop.loc_id,pop.line_item_seq_nbr  
from {CON_DB}.PRDFDLVWB.link_to_customer mid,
{RET_DB}.photo.photo_order po,
{RET_DB}.photo.photo_order_sales_transaction  pop
where mid.cust_src_cd = '{pSRC_SYS_CD4}'
and mid.cdi_msg_type_cd = '2'
AND mid.edw_rec_end_dt ={pTD_EDW_END_DATE}
AND mid.cust_src_id = po.cust_id
and po.loc_id = pop.loc_id 
AND po.ord_id = pop.ord_id
AND po.photo_env_nbr = pop.photo_env_nbr
AND po.ord_dt= pop.ord_dt
AND pop.txn_dt between to_char(DATEADD(DAY, -30, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and '{pSQL_PARM_1}'
) b 
on a.sales_txn_id=b.sales_txn_id
and a.sales_txn_dt=b.txn_dt
and a.line_item_seq_nbr=b.line_item_seq_nbr
group by 1,2) t1 ) t2 where rn=1 
and not exists (select 1 
from {MSTR_DB}.PARTNER.emnos_ext_card_file_master m
 where src_sys_cd='M' and m.mid=t2.mid ) """.format(PHARM_DB=PAR_PHARM_DB,MSTR_DB=PAR_MSTR_DB,RET_DB=PAR_RET_DB,pSQL_PARM_1=pSQL_PARM_1,pSRC_SYS_CD='POS',pSQL_PARM_3=pSQL_PARM_3,CON_DB=PAR_CON_DB,pSRC_SYS_CD1='IC',pTD_EDW_END_DATE="CAST('9999-12-31' AS DATE)",pSRC_SYS_CD4='PC') 
print(q1)
df_join1 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",q1)\
   .load()
df_join1_cachedDF=df_join1.cache()
#df_join1.show()

# COMMAND ----------

df_g1_rfmt0=df_join1_cachedDF.select("MID")
df_g1_rfmt1=df_join1_cachedDF.select(lit("-1").alias("CARD_KEY"),col("MID"),lit("-1").alias("LOYALTY_MBR_ID"),lit("M").alias("SRC_SYS_CD"),current_timestamp().alias("EDW_CREATE_DTTM"),lit(None).cast(StringType()).alias("VALID_ADDRESS_FLG"),lit(None).cast(StringType()).alias("DO_NOT_MAIL_FLG"),lit(None).cast(StringType()).alias("DO_NOT_EMAIL_FLG"),lit(None).cast(StringType()).alias("SUSPICIOUS_MEMBER_FLG"),lit(None).cast(StringType()).alias("VALID_EMAIL_FLG"),lit(None).cast(StringType()).alias("HEALTH_CHOICE_FLG"),lit(None).cast(StringType()).alias("WAGDOTCOM_FLG"),lit(None).cast(StringType()).alias("CPN_HUB_FLG"),lit(None).cast(StringType()).alias("MOBILE_APP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_CLUB_FLG"),lit(None).cast(StringType()).alias("SAME_DAY_PICKUP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_2K_FLG"),lit(None).cast(DateType()).alias("LAST_ONLN_DT"),lit(None).cast(StringType()).alias("PREFERRED_STORE_NBR"),lit(None).cast(StringType()).alias("PREFERRED_STORE_INTERSECTION"),lit(None).cast(StringType()).alias("PREFERRED_STORE_ADDR"),lit(None).cast(StringType()).alias("BRTH_MO"),lit('9999-12-31').cast(DateType()).alias("EDW_UPDATE_DT"))
#df_g1_rfmt0.show()
#df_g1_rfmt1.show()

# COMMAND ----------

q2=""" select * from (SELECT  'L'|| TRIM(lmc."mid" ) AS MID ,
lmc."loyalty_mbr_id" AS loyalty_mbr_id
FROM  {CON_DB}.PRDFDLVWB.DIM_LOYALTY_CUSTOMER_CUR_BVW lmc
JOIN {CON_DB}.PRDFDLVWB.link_to_customer mid
ON mid.cust_src_id = lmc."loyalty_mbr_id"
AND mid.cust_src_cd = 'LR'
AND mid.edw_rec_end_dt = {pTD_EDW_END_DATE}
and mid.cdi_msg_type_cd = '2'
group by 1,2) t1 where not exists(
select  1
from {MSTR_DB}.PARTNER.emnos_ext_card_file_master t
where src_sys_cd='L' and t.MID=t1.MID and t.loyalty_mbr_id=t1.loyalty_mbr_id) """.format(MSTR_DB=PAR_MSTR_DB,CON_DB=PAR_CON_DB,pTD_EDW_END_DATE="CAST('9999-12-31' AS DATE)")
print(q2)
df_join2 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",q2)\
   .load()
df_join2_cachedDF=df_join2.cache()
#df_join2.show()

# COMMAND ----------

df_g2_rfmt0=df_join2_cachedDF.select("MID")
df_g2_rfmt1=df_join2_cachedDF.select(lit("-1").alias("CARD_KEY"),col("MID"),col("LOYALTY_MBR_ID"),lit("L").alias("SRC_SYS_CD"),current_timestamp().alias("EDW_CREATE_DTTM"),lit(None).cast(StringType()).alias("VALID_ADDRESS_FLG"),lit(None).cast(StringType()).alias("DO_NOT_MAIL_FLG"),lit(None).cast(StringType()).alias("DO_NOT_EMAIL_FLG"),lit(None).cast(StringType()).alias("SUSPICIOUS_MEMBER_FLG"),lit(None).cast(StringType()).alias("VALID_EMAIL_FLG"),lit(None).cast(StringType()).alias("HEALTH_CHOICE_FLG"),lit(None).cast(StringType()).alias("WAGDOTCOM_FLG"),lit(None).cast(StringType()).alias("CPN_HUB_FLG"),lit(None).cast(StringType()).alias("MOBILE_APP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_CLUB_FLG"),lit(None).cast(StringType()).alias("SAME_DAY_PICKUP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_2K_FLG"),lit(None).cast(DateType()).alias("LAST_ONLN_DT"),lit(None).cast(StringType()).alias("PREFERRED_STORE_NBR"),lit(None).cast(StringType()).alias("PREFERRED_STORE_INTERSECTION"),lit(None).cast(StringType()).alias("PREFERRED_STORE_ADDR"),lit(None).cast(StringType()).alias("BRTH_MO"),lit('9999-12-31').cast(DateType()).alias("EDW_UPDATE_DT"))
#df_g2_rfmt0.show()
#df_g2_rfmt1.show()

# COMMAND ----------

q3=""" select * from (SELECT 
 'C'||TRIM(cast(translate(to_char(b.card_id ), ' ', '') as varchar(21)))  AS card_key  
	FROM (select * from {RET_DB}.RETAIL_SALES.SALES_TRANSACTION_TENDER where src_sys_cd='{pSRC_SYS_CD}'
 and sales_txn_dt between to_char(DATEADD(DAY, -6, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and to_char(CAST('{pSQL_PARM_1}' as date), 'YYYY-MM-DD')
union all
select * from {RET_DB}.RETAIL_SALES.SALES_TRANSACTION_TENDER where src_sys_cd='{pSRC_SYS_CD}'
 and sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD')  and to_char(DATEADD(DAY, -7, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD')
and edw_create_dttm > '{pSQL_PARM_3}' )a
	inner join {RET_DB}.RETAIL_SALES.TENDER_CARD_HASH  b 
	on a.card_hash_val_sk=b.card_hash_val_sk
	AND b.card_id <> '-1'
	 group by 1
) t1 where not exists (	select  1
from {MSTR_DB}.PARTNER.emnos_ext_card_file_master t
where src_sys_cd='C' and t.card_key=t1.card_key
)""".format(MSTR_DB=PAR_MSTR_DB,RET_DB=PAR_RET_DB,pSRC_SYS_CD='POS',pSQL_PARM_1=pSQL_PARM_1,pSQL_PARM_3=pSQL_PARM_3)
print(q3)

df_join3 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",q3)\
   .load()
#df_join3.show()
df_join3_cachedDF=df_join3.cache()

# COMMAND ----------

df_g3_rfmt0=df_join3_cachedDF.select("CARD_KEY",lit("-1").alias("MID"),lit("C").alias("SRC_SYS_CD"))
df_g3_rfmt1=df_join3_cachedDF.select("CARD_KEY",lit("-1").alias("MID"),lit("-1").alias("LOYALTY_MBR_ID"),lit("C").alias("SRC_SYS_CD"),current_timestamp().alias("EDW_CREATE_DTTM"),lit(None).cast(StringType()).alias("VALID_ADDRESS_FLG"),lit(None).cast(StringType()).alias("DO_NOT_MAIL_FLG"),lit(None).cast(StringType()).alias("DO_NOT_EMAIL_FLG"),lit(None).cast(StringType()).alias("SUSPICIOUS_MEMBER_FLG"),lit(None).cast(StringType()).alias("VALID_EMAIL_FLG"),lit(None).cast(StringType()).alias("HEALTH_CHOICE_FLG"),lit(None).cast(StringType()).alias("WAGDOTCOM_FLG"),lit(None).cast(StringType()).alias("CPN_HUB_FLG"),lit(None).cast(StringType()).alias("MOBILE_APP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_CLUB_FLG"),lit(None).cast(StringType()).alias("SAME_DAY_PICKUP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_2K_FLG"),lit(None).cast(DateType()).alias("LAST_ONLN_DT"),lit(None).cast(StringType()).alias("PREFERRED_STORE_NBR"),lit(None).cast(StringType()).alias("PREFERRED_STORE_INTERSECTION"),lit(None).cast(StringType()).alias("PREFERRED_STORE_ADDR"),lit(None).cast(StringType()).alias("BRTH_MO"),lit('9999-12-31').cast(DateType()).alias("EDW_UPDATE_DT"))
#df_g3_rfmt0.show()
#df_g3_rfmt1.show()

# COMMAND ----------

df_union11=df_g1_rfmt0.unionByName(df_g2_rfmt0)
#df_union11.show()

# COMMAND ----------

df_g11_rfmt0=df_union11.select("MID",lit("-1").alias("CARD_KEY"),lit("M").alias("SRC_SYS_CD"))
df_sort1=df_g11_rfmt0.sort("MID")
df_dedup2 = df_sort1.dropDuplicates(['MID'])
#df_dedup2.show()

# COMMAND ----------

df_union2=df_dedup2.unionByName(df_g3_rfmt0)
#df_union2.show()

# COMMAND ----------


delete_EMNOS_EXT_CARD_FILE_DRIVER_STG_tbl = "Truncate table {0}.{1}".format(PAR_STG_DB,"PARTNER.EMNOS_EXT_CARD_FILE_DRIVER_STG")
 
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_EMNOS_EXT_CARD_FILE_DRIVER_STG_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : PAR_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------


df_union2.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("dbtable", "PARTNER.EMNOS_EXT_CARD_FILE_DRIVER_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

df_union1=df_g1_rfmt1.unionByName(df_g2_rfmt1).unionByName(df_g3_rfmt1)

# COMMAND ----------

df_union1.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_MSTR_DB) \
   .option("dbtable", "PARTNER.EMNOS_EXT_CARD_FILE_MASTER") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

q4="""SELECT  'L'|| TRIM(lmc."mid" ) AS MID ,
lmc."loyalty_mbr_id" AS loyalty_mbr_id
FROM  {CON_DB}.PRDFDLVWB.DIM_LOYALTY_CUSTOMER_CUR_BVW lmc
where lmc."loyalty_mbr_id" in 
(select c.cust_src_id as loyalty_mbr_id
from(select cdi_cust_src_id as ecom_cust_id from {CON_DB}.PRDFDLVWB.link_to_customer where cust_src_cd='EC'
and cdi_msg_type_cd='2' and edw_rec_end_dt='9999-12-31' group by 1)d
inner join (select cdi_cust_src_id as mid ,cust_src_id from {CON_DB}.PRDFDLVWB.link_to_customer where cust_src_cd='LR'
and cdi_msg_type_cd='2' and edw_rec_end_dt='9999-12-31' group by 1,2) c
on c.mid=d.ecom_cust_id) and not exists (
select 1
from {MSTR_DB}.PARTNER.emnos_ext_card_file_master t
where src_sys_cd='L' and t.MID='L'|| TRIM(lmc."mid") and t.loyalty_mbr_id=lmc."loyalty_mbr_id")""".format(MSTR_DB=PAR_MSTR_DB,CON_DB=PAR_CON_DB)
print(q4)
df_join4 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",q4)\
   .load()
df_join4_cachedDF=df_join4.cache()
#df_join4.show()

# COMMAND ----------

df_g4_rfmt0=df_join4_cachedDF.select("MID",lit("-1").alias("CARD_KEY"),lit("M").alias("SRC_SYS_CD"))
df_g4_rfmt0=df_g4_rfmt0.sort("MID")
df_g4_rfmt0=df_g4_rfmt0.dropDuplicates(['MID'])
df_g4_rfmt1=df_join4_cachedDF.select(lit("-1").alias("CARD_KEY"),col("MID"),col("LOYALTY_MBR_ID"),lit("L").alias("SRC_SYS_CD"),current_timestamp().alias("EDW_CREATE_DTTM"),lit(None).cast(StringType()).alias("VALID_ADDRESS_FLG"),lit(None).cast(StringType()).alias("DO_NOT_MAIL_FLG"),lit(None).cast(StringType()).alias("DO_NOT_EMAIL_FLG"),lit(None).cast(StringType()).alias("SUSPICIOUS_MEMBER_FLG"),lit(None).cast(StringType()).alias("VALID_EMAIL_FLG"),lit(None).cast(StringType()).alias("HEALTH_CHOICE_FLG"),lit(None).cast(StringType()).alias("WAGDOTCOM_FLG"),lit(None).cast(StringType()).alias("CPN_HUB_FLG"),lit(None).cast(StringType()).alias("MOBILE_APP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_CLUB_FLG"),lit(None).cast(StringType()).alias("SAME_DAY_PICKUP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_2K_FLG"),lit(None).cast(DateType()).alias("LAST_ONLN_DT"),lit(None).cast(StringType()).alias("PREFERRED_STORE_NBR"),lit(None).cast(StringType()).alias("PREFERRED_STORE_INTERSECTION"),lit(None).cast(StringType()).alias("PREFERRED_STORE_ADDR"),lit(None).cast(StringType()).alias("BRTH_MO"),lit('9999-12-31').cast(DateType()).alias("EDW_UPDATE_DT"))
#df_g4_rfmt0.show()
#df_g4_rfmt1.show()

# COMMAND ----------

q5="""select * from (SELECT
 'C'||TRIM(cast(translate(to_char(b.card_id ), ' ', '') as varchar(21)))  AS card_key
        FROM (select * from {RET_DB}.RETAIL_SALES.SALES_TRANSACTION_PAY_GROUP where src_sys_cd='EC' and sales_ord_src_type = 'S' and sales_txn_type = 'S'
 and sales_txn_dt between to_char(DATEADD(DAY, -6, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and to_char(CAST('{pSQL_PARM_1}' as date), 'YYYY-MM-DD')
union all
select * from {RET_DB}.RETAIL_SALES.SALES_TRANSACTION_PAY_GROUP where src_sys_cd='EC' and sales_ord_src_type = 'S' and sales_txn_type = 'S'
 and sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD')  and to_char(DATEADD(DAY, -7, CAST('{pSQL_PARM_1}' as date)), 'YYYY-MM-DD')
and edw_create_dttm > '{pSQL_PARM_3}' )a
        inner join {RET_DB}.RETAIL_SALES.TENDER_CARD_HASH  b
        on a.card_hash_val_sk=b.card_hash_val_sk
        AND b.card_id <> '-1'
         group by 1 ) t1 where not exists (
        select 1
from {MSTR_DB}.PARTNER.emnos_ext_card_file_master t
where src_sys_cd='C' and t.card_key=t1.card_key)""".format(RET_DB=PAR_RET_DB,pSQL_PARM_1=pSQL_PARM_1,pSQL_PARM_3=pSQL_PARM_3,MSTR_DB=PAR_MSTR_DB)
print(q5)
df_join5 = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",q5)\
   .load()
df_join5_cachedDF=df_join5.cache()
#df_join5.show()

# COMMAND ----------

df_g5_rfmt0=df_join5_cachedDF.select("CARD_KEY",lit("-1").alias("MID"),lit("C").alias("SRC_SYS_CD"))
df_g5_rfmt1=df_join5_cachedDF.select(col("CARD_KEY"),lit("-1").alias("MID"),lit("-1").alias("LOYALTY_MBR_ID"),lit("C").alias("SRC_SYS_CD"),current_timestamp().alias("EDW_CREATE_DTTM"),lit(None).cast(StringType()).alias("VALID_ADDRESS_FLG"),lit(None).cast(StringType()).alias("DO_NOT_MAIL_FLG"),lit(None).cast(StringType()).alias("DO_NOT_EMAIL_FLG"),lit(None).cast(StringType()).alias("SUSPICIOUS_MEMBER_FLG"),lit(None).cast(StringType()).alias("VALID_EMAIL_FLG"),lit(None).cast(StringType()).alias("HEALTH_CHOICE_FLG"),lit(None).cast(StringType()).alias("WAGDOTCOM_FLG"),lit(None).cast(StringType()).alias("CPN_HUB_FLG"),lit(None).cast(StringType()).alias("MOBILE_APP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_CLUB_FLG"),lit(None).cast(StringType()).alias("SAME_DAY_PICKUP_FLG"),lit(None).cast(StringType()).alias("BEAUTY_2K_FLG"),lit(None).cast(DateType()).alias("LAST_ONLN_DT"),lit(None).cast(StringType()).alias("PREFERRED_STORE_NBR"),lit(None).cast(StringType()).alias("PREFERRED_STORE_INTERSECTION"),lit(None).cast(StringType()).alias("PREFERRED_STORE_ADDR"),lit(None).cast(StringType()).alias("BRTH_MO"),lit('9999-12-31').cast(DateType()).alias("EDW_UPDATE_DT"))
#df_g5_rfmt0.show()
#df_g5_rfmt1.show()

# COMMAND ----------

df_union4=df_g4_rfmt0.unionByName(df_g5_rfmt0)

# COMMAND ----------

df_union4.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("dbtable", "PARTNER.EMNOS_EXT_CARD_FILE_DRIVER_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

df_union3=df_g4_rfmt1.unionByName(df_g5_rfmt1)

df_union3.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_MSTR_DB) \
   .option("dbtable", "PARTNER.EMNOS_EXT_CARD_FILE_MASTER") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

df_join1_cachedDF.unpersist()
df_join2_cachedDF.unpersist()
df_join3_cachedDF.unpersist()
df_join4_cachedDF.unpersist()
df_join5_cachedDF.unpersist()

# COMMAND ----------

dbutils.notebook.exit(process_dates_str)
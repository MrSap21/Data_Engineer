# Databricks notebook source
# Python code to mount and access Azure Data Lake Storage Gen2 Account to Azure Databricks with Service Principal and OAuth
# Author: Dhyanendra Singh Rathore
# Define the variables used for creating connection strings
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
mountPoint = "/mnt/DAP_IDL_PATIENT_TC_CIF_TC_PATIENT_SELF_RPT_IMMUNIZATION_XFORM"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

# Define Input Schema

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("patientid", StringType(), False),
    StructField("createddt", StringType(), False),
    StructField("problemid", StringType(), False),
    StructField("patientproblemid", StringType(), False),
    StructField("edw_maxupd_dttm", StringType(), False),
    StructField("description", StringType(), False),
    StructField("headeranswerxml", StringType(), False),
    StructField("activeind", StringType(), False),
    StructField("dxcode", StringType(), False),
    StructField("detailanswerxml", StringType(), False),
    StructField("subproblemtypecd", StringType(), False),
    StructField("problemtypecd", StringType(), False)
  ])
)

# COMMAND ----------

# Load Input File

inputFileFullPath = mountPoint + "/" + dbutils.widgets.get('AI_SERIAL') + "/edw_idl_patient_tc_patient_sr_immunization_extr_" + dbutils.widgets.get('pDAP_BATCH_ID') + ".dat"

dfInput = spark.read.format("csv").options(header='false', delimiter = '\x01').schema(inputSchema).load(inputFileFullPath)

#display(dfInput)

# COMMAND ----------

# SRT - NAT KEYS

from pyspark.sql.functions import *

dfInputSorted = dfInput.orderBy("patientid", "createddt", "problemid")

dfInputSorted.createOrReplaceTempView("dfInputSorted")

#display(dfInputSorted)

# COMMAND ----------

# MAGIC %scala
# MAGIC 
# MAGIC /* Flattening nested XMLs */
# MAGIC 
# MAGIC import org.apache.spark.sql.functions.col
# MAGIC import com.databricks.spark.xml.functions.from_xml
# MAGIC import com.databricks.spark.xml.schema_of_xml
# MAGIC import spark.implicits._
# MAGIC 
# MAGIC // Header XML
# MAGIC 
# MAGIC var dfXMLHeaderRaw = spark.sql("SELECT patientid, createddt, problemid, headeranswerxml FROM dfInputSorted")
# MAGIC var dfXMLHeaderStruct = dfXMLHeaderRaw.withColumn("headerstruct", from_xml($"headeranswerxml", schema_of_xml(dfXMLHeaderRaw.select("headeranswerxml").as[String])))
# MAGIC var dfXMLHeaderReject = dfXMLHeaderStruct.filter(col("headerstruct._corrupt_record").isNotNull)
# MAGIC var dfXMLHeader = dfXMLHeaderStruct.filter(col("headerstruct.data").isNotNull)
# MAGIC                                    .withColumn("at", col("headerstruct.data.dca._at"))
# MAGIC                                    .withColumn("qt", col("headerstruct.data.dca._qt"))
# MAGIC                                    .drop("headeranswerxml", "headerstruct")
# MAGIC 
# MAGIC dfXMLHeaderReject.createOrReplaceTempView("dfXMLHeaderReject")
# MAGIC dfXMLHeader.createOrReplaceTempView("dfXMLHeader")
# MAGIC 
# MAGIC // Detail XML
# MAGIC 
# MAGIC var dfXMLDetailRaw = spark.sql("SELECT patientid, createddt, problemid, detailanswerxml FROM dfInputSorted")
# MAGIC var dfXMLDetailStruct = dfXMLDetailRaw.withColumn("detailstruct", from_xml($"detailanswerxml", schema_of_xml(dfXMLDetailRaw.select("detailanswerxml").as[String])))
# MAGIC var dfXMLDetailReject = dfXMLDetailStruct.filter(col("detailstruct._corrupt_record").isNotNull)
# MAGIC var dfXMLDetail = dfXMLDetailStruct.filter(col("detailstruct.data").isNotNull)
# MAGIC                                    .withColumn("at", col("detailstruct.data.dca._at"))
# MAGIC                                    .withColumn("qt", col("detailstruct.data.dca._qt"))
# MAGIC                                    .drop("detailanswerxml", "detailstruct")
# MAGIC 
# MAGIC dfXMLDetailReject.createOrReplaceTempView("dfXMLDetailReject")
# MAGIC dfXMLDetail.createOrReplaceTempView("dfXMLDetail")
# MAGIC 
# MAGIC //display(dfXMLHeader)
# MAGIC //display(dfXMLDetail)

# COMMAND ----------

# Initiating the 3 dataframes this graph will work with

dfMain = dfInputSorted
dfHeader = spark.sql("SELECT * FROM dfXMLHeader")
dfDetail = spark.sql("SELECT * FROM dfXMLDetail")

#display(dfHeader)

# COMMAND ----------

# Reformat Header

dfHeaderAgg = dfHeader.groupBy("patientid", "createddt", "problemid").agg(max(col("at")).alias("at"), max(col("qt")).alias("qt"))

def containsAnyQTHeader(inputStr):
  if len(inputStr) == 0:
    return False
  else:
    return (any(item in inputStr for item in ["Pneumonia:", "Influenza (Flu shot):", "Tdap (Tetanus, diphtheria, pertussis):", "Td (Tetanus):", "Zostavax (Shingles):", "Hepatitis B (3 shot series):"]))

contains_udf_qt_header = udf(containsAnyQTHeader, BooleanType())
  
dfHeaderFinal = dfHeaderAgg.where(col("at") == "Yes")\
                           .withColumn("hqt", when(contains_udf_qt_header(col("qt")), col("qt")).otherwise(lit("")))\
                           .withColumn("hat", when(contains_udf_qt_header(col("qt")), col("at")).otherwise(lit("")))\
                           .drop("qt", "at")

display(dfHeaderAgg)

# COMMAND ----------

# Reformat Detail

dfDetailAgg = dfDetail.groupBy("patientid", "createddt", "problemid").agg(max(col("at")).alias("at"), max(col("qt")).alias("qt"))
  
dfDetailFinal = dfDetailAgg.withColumn("dqt", when(col("qt") == "Date (if known) (MM/YY):", col("qt")).otherwise(lit("")))\
                           .withColumn("dat", when(col("qt") == "Date (if known) (MM/YY):", col("at")).otherwise(lit("")))\
                           .drop("qt", "at")

#display(dfDetailFinal)

# COMMAND ----------

# Join and reformat

dfMainHeader = dfMain.alias("t1").join(dfHeaderFinal.alias("t2"), (col("t1.patientid") == col("t2.patientid")) & (col("t1.createddt") == col("t2.createddt")) & (col("t1.problemid") == col("t2.problemid")), how = "left").select(col("t1.patientid"), col("t1.createddt"), col("t1.problemid"), col("t1.description"), col("t2.hqt"), col("t2.hat"))

dfMainHeaderDetail =  dfMainHeader.alias("t1").join(dfDetailFinal.alias("t2"), (col("t1.patientid") == col("t2.patientid")) & (col("t1.createddt") == col("t2.createddt")) & (col("t1.problemid") == col("t2.problemid")), how = "left").select(col("t1.patientid"), col("t1.createddt"), col("t1.problemid"), col("t1.description"), col("t1.hqt"), col("t1.hat"), col("t2.dqt"), col("t2.dat"))

dfFinal = dfMainHeaderDetail.withColumn("pat_src_id", col("patientid"))\
                            .withColumn("med_info_rec_dt", col("createddt"))\
                            .withColumn("pat_immunization_src_id", col("problemid"))\
                            .withColumn("pat_immunization_desc", col("description"))\
                            .withColumn("pat_immunization_dt", when(col("hqt").isNotNull() & col("dqt").isNotNull(), col("dat")).otherwise(lit("")))\
                            .withColumn("src_sys_cd", lit("TC"))\
                            .withColumn("composite_type_cd", lit("#"))\
                            .withColumn("msg_type_cd", lit("#"))\
                            .withColumn("immunization_type_cd", lit(""))\
                            .select(col("pat_src_id"), col("src_sys_cd"), col("composite_type_cd"), col("msg_type_cd"), col("med_info_rec_dt"), col("pat_immunization_src_id"), col("immunization_type_cd"), col("pat_immunization_desc"), col("pat_immunization_dt"))

#display(dfFinal)

# COMMAND ----------

# Write output files

dfHeaderReject = spark.sql("SELECT patientid, createddt, problemid, headeranswerxml FROM dfXMLHeaderReject")
dfDetailReject = spark.sql("SELECT patientid, createddt, problemid, detailanswerxml FROM dfXMLDetailReject")

data_location_output = "{0}/{1}/edw_idl_patient_tc_cif_tc_patient_sr_immunization_full_ldr_{2}".format(mountPoint, dbutils.widgets.get('AI_SERIAL'), dbutils.widgets.get('pDAP_BATCH_ID'))
data_location_header_rej = "{0}/{1}/aic_{2}_HANSXML_REJ_{3}".format(mountPoint, dbutils.widgets.get('AI_SERIAL_REJECT'), dbutils.widgets.get('AI_GRAPH_NAME'), dbutils.widgets.get('pDAP_BATCH_ID'))
data_location_detail_rej = "{0}/{1}/aic_{2}_DANSXML_REJ_{3}".format(mountPoint, dbutils.widgets.get('AI_SERIAL_REJECT'), dbutils.widgets.get('AI_GRAPH_NAME'), dbutils.widgets.get('pDAP_BATCH_ID'))

dfFinal.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_output)
dfHeaderReject.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_header_rej)
dfDetailReject.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_detail_rej)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

filesheaderrej = dbutils.fs.ls(data_location_header_rej)
csv_file_headerrej = [x.path for x in filesheaderrej if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_headerrej, data_location_header_rej.rstrip('/') + ".rej")
dbutils.fs.rm(data_location_header_rej, recurse = True)

filesdetailrej = dbutils.fs.ls(data_location_detail_rej)
csv_file_detailrej = [x.path for x in filesdetailrej if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_detailrej, data_location_detail_rej.rstrip('/') + ".rej")
dbutils.fs.rm(data_location_detail_rej, recurse = True)
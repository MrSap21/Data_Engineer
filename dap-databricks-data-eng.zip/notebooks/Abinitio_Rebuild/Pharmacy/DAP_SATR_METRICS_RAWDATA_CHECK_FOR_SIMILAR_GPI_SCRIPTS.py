# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove('PAR_DB_SNFK_CONSUMP_DB')
#dbutils.widgets.text('PAR_DB_SNFK_STG_DB', 'DEV_STAGING')

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFK_DB_PHAR = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFK_DB_STG = dbutils.widgets.get("PAR_DB_SNFK_STG_DB")

# COMMAND ----------

SNFK_SC_PS = 'PATIENT_SERVICES'
SNFK_TBL_PRESCRIPTION = 'PRESCRIPTION'
SNFK_SC_PH = 'PHARMACY_HEALTHCARE'
SNFK_TBL_ADHOC_SATR_NOT_FILLED_RXL = 'ADHOC_SATR_NOT_FILLED_RXL_STG'

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFK_DB_STG $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

SEL_QUERY = """select  
pre.pat_id,
pre.rx_nbr,
pre.str_nbr,
pre.fill_nbr_dspn,
pre.fill_entered_dttm,
pre.rx_stat_cd,
pre.drug_id from 
{0}.{1}.{2} pre inner join 
(select pat_id from {3}.{4}.{5}  group by pat_id) tsat 
on pre.pat_id=tsat.pat_id and pre.rx_create_dt>(current_date-730)""".format(SNFK_DB_PHAR, SNFK_SC_PS, SNFK_TBL_PRESCRIPTION,SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_ADHOC_SATR_NOT_FILLED_RXL)

# COMMAND ----------

df_PrescriptionExtract = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("query",SEL_QUERY)\
   .load()
#df_PrescriptionExtract.show()

# COMMAND ----------

#Filtering condition for RX_STAT_CD IN ('AC','CL','ST')
Filter_Values = ['AC','CL','ST']
df_filter_sel = df_PrescriptionExtract.filter(df_PrescriptionExtract.RX_STAT_CD.isin(Filter_Values))

#display(df_filter_sel)

# COMMAND ----------

SNFK_TBL_SATR_PAT_ID_ALL_RXL = 'SATR_PAT_ID_ALL_RXL_STG'

delete_SATR_PAT_ID_ALL_RXL_tbl = "Truncate table {0}.{1}.{2}".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_SATR_PAT_ID_ALL_RXL)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_SATR_PAT_ID_ALL_RXL_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFK_DB_STG,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

df_filter_sel.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("dbtable", "PHARMACY_HEALTHCARE.SATR_PAT_ID_ALL_RXL_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()
#df_filter_sel.show()

# COMMAND ----------

PAR_DF_DRUG_SH = 'DRUG'
PAR_DF_DRUG_TBL = 'DRUG_IC'
PAR_SATR_PAT_ID_ALL_RXL_TBL = 'SATR_PAT_ID_ALL_RXL_STG'

# COMMAND ----------

SEL_QUERY_two = """select 
d.generic_prod_id,
d.generic_prod_id_name,
tsprx.pat_id,
tsprx.rx_nbr,
tsprx.str_nbr,
tsprx.fill_nbr_dspn,
tsprx.fill_entered_dttm,
tsprx.rx_stat_cd,
tsprx.drug_id 
from 
(select drug_id,
generic_prod_id, 
generic_prod_id_name 
from 
{0}.{1}.{2} 
where history_seq_cd='C'  
and generic_prod_id is not null group by 1,2,3 ) d  inner join {3}.{4}.{5} tsprx  on d.drug_id=tsprx.drug_id""".format(SNFK_DB_PHAR,PAR_DF_DRUG_SH,PAR_DF_DRUG_TBL,SNFK_DB_STG,SNFK_SC_PH,PAR_SATR_PAT_ID_ALL_RXL_TBL)

# COMMAND ----------

df_JoinWithDrugForGPI = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("query",SEL_QUERY_two)\
   .load()
#df_JoinWithDrugForGPI.show()

# COMMAND ----------

SEL_ADHOC_SATR_NOT_FILLED_RXL = """select pat_id,store_nbr,pickup_store_nbr,rx_nbr,work_order,expected_fill_enter_dt,max_fill_enter_dt,orig_fill_dspn_qnty from {0}.{1}.{2}""".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_ADHOC_SATR_NOT_FILLED_RXL)

# COMMAND ----------

df_ADHOC_SATR_NOT_FILLED_RXL = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("query",SEL_ADHOC_SATR_NOT_FILLED_RXL)\
   .load()
#df_ADHOC_SATR_NOT_FILLED_RXL.show()

# COMMAND ----------

df_ADHOC_SATR_NOT_FILLED_RXL = df_ADHOC_SATR_NOT_FILLED_RXL.sort("STORE_NBR","RX_NBR")

# COMMAND ----------

df_join1=df_JoinWithDrugForGPI.alias("in0").join(df_ADHOC_SATR_NOT_FILLED_RXL.alias("in1"),((df_JoinWithDrugForGPI.STR_NBR == df_ADHOC_SATR_NOT_FILLED_RXL.STORE_NBR) &  (df_JoinWithDrugForGPI.RX_NBR == df_ADHOC_SATR_NOT_FILLED_RXL.RX_NBR)),"inner").select(col("in0.GENERIC_PROD_ID"),
col("in0.GENERIC_PROD_ID_NAME"),col("in0.PAT_ID"),
col("in0.RX_NBR"),col("in0.STR_NBR")
,col("in0.FILL_NBR_DSPN"),col("in0.FILL_ENTERED_DTTM"),col("in0.RX_STAT_CD"),col("in0.DRUG_ID"),col("in1.ORIG_FILL_DSPN_QNTY"))

#display(df_join1)

# COMMAND ----------

df_join1_anti=df_JoinWithDrugForGPI.join(df_ADHOC_SATR_NOT_FILLED_RXL,((df_JoinWithDrugForGPI.STR_NBR == df_ADHOC_SATR_NOT_FILLED_RXL.STORE_NBR) &  (df_JoinWithDrugForGPI.RX_NBR == df_ADHOC_SATR_NOT_FILLED_RXL.RX_NBR)),"leftanti")

#display(df_join1_anti)

# COMMAND ----------

df_satr_sort=df_join1.sort("STR_NBR","PAT_ID","GENERIC_PROD_ID")
df_non_satr_sort=df_join1_anti.sort("STR_NBR","PAT_ID","GENERIC_PROD_ID")
#display(df_satr_sort)
#display(df_non_satr_sort)

# COMMAND ----------

df_get_similar_non_satr_join=df_satr_sort.alias("in0").join(df_non_satr_sort.alias("in1"),((df_satr_sort.STR_NBR == df_non_satr_sort.STR_NBR) &  (df_satr_sort.PAT_ID == df_non_satr_sort.PAT_ID) & (df_satr_sort.GENERIC_PROD_ID == df_non_satr_sort.GENERIC_PROD_ID)),"inner").select(col("in0.GENERIC_PROD_ID"),
col("in0.GENERIC_PROD_ID_NAME")
,col("in0.PAT_ID"),
col("in0.RX_NBR").alias("OLD_RX_NBR")
,col("in0.STR_NBR").alias("OLD_STR_NBR")
,col("in1.RX_NBR").alias("RX_NBR")
,col("in1.STR_NBR").alias("STR_NBR")
,col("in0.FILL_NBR_DSPN")
,col("in1.FILL_ENTERED_DTTM").alias("FILL_ENTERED_DTTM")
,col("in0.RX_STAT_CD")
,col("in0.DRUG_ID")
,col("in0.ORIG_FILL_DSPN_QNTY").alias("ORIG_FILL_DSPN_QNTY"))

#display(df_get_similar_non_satr_join)

# COMMAND ----------

df_old_rx_str_nbr_sort=df_get_similar_non_satr_join.sort("OLD_RX_NBR","OLD_STR_NBR")

# COMMAND ----------

df_ADHOC_SATR_NOT_FILLED_RXL.printSchema()

# COMMAND ----------


df_get_expected_fill_enter_dttm_join=df_old_rx_str_nbr_sort.alias("in0").join(df_ADHOC_SATR_NOT_FILLED_RXL.alias("in1"),((df_old_rx_str_nbr_sort.OLD_RX_NBR == df_ADHOC_SATR_NOT_FILLED_RXL.RX_NBR) &  (df_old_rx_str_nbr_sort.OLD_STR_NBR == df_ADHOC_SATR_NOT_FILLED_RXL.STORE_NBR)),"inner").select(col("in0.GENERIC_PROD_ID").alias("GENERIC_PROD_ID"),
col("in0.GENERIC_PROD_ID_NAME").alias("GENERIC_PROD_ID_NAME")
,col("in0.PAT_ID").alias("PAT_ID"),
col("in0.OLD_RX_NBR").alias("OLD_RX_NBR")
,col("in0.OLD_STR_NBR").alias("OLD_STR_NBR")
,col("in0.RX_NBR").alias("RX_NBR")
,col("in0.STR_NBR").alias("STR_NBR")
,col("in0.FILL_NBR_DSPN").alias("FILL_NBR_DSPN")
,to_timestamp(col("in1.EXPECTED_FILL_ENTER_DT")).alias("EXPECTED_FILL_ENTERED_DTTM")
,to_timestamp(col("in1.MAX_FILL_ENTER_DT")).alias("MAX_FILL_ENTERED_DTTM")
,col("in0.FILL_ENTERED_DTTM").alias("FILL_ENTERED_DTTM")
,col("in0.RX_STAT_CD").alias("RX_STAT_CD")
,col("in0.DRUG_ID").alias("DRUG_ID")
,col("in1.WORK_ORDER").alias("WORK_ORDER")
,col("in0.ORIG_FILL_DSPN_QNTY").alias("ORIG_FILL_DSPN_QNTY")
)
#display(df_get_expected_fill_enter_dttm_join)

# COMMAND ----------

SNFK_TBL_SATR_SIMILAR_GPI_RX_TMPL = 'SATR_SIMILAR_GPI_RX_TMPL_STG'

delete_SATR_SIMILAR_GPI_RX_TMPL_tbl = "Truncate table {0}.{1}.{2}".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_SATR_SIMILAR_GPI_RX_TMPL)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_SATR_SIMILAR_GPI_RX_TMPL_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFK_DB_STG,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

df_get_expected_fill_enter_dttm_join.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("dbtable", "PHARMACY_HEALTHCARE.SATR_SIMILAR_GPI_RX_TMPL_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()
#df_filter_sel.show()

#print(df_get_expected_fill_enter_dttm_join.count())
# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'

#print (IN_DATAFILE)
print (OUT_FILEPATH)
#print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC 
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'plan_id',
'plan_id_after',
'plan_area_cd',
'plan_area_cd_after',
'plan_phone_nbr',
'plan_phone_nbr_after',
'plan_type_cd',
'plan_type_cd_after',
'plan_name',
'plan_name_after',
'plan_active_ind',
'plan_active_ind_after',
'plan_effective_dttm',
'plan_effective_dttm_after',
'phrm_store_nbr_cd',
'phrm_store_nbr_cd_after',
'pbr_cd',
'pbr_cd_after',
'secondary_pbr_cd',
'secondary_pbr_cd_after',
'plan_cmpd_drug_cd',
'plan_cmpd_drug_cd_after',
'plan_usual_cust_adj_amt',
'plan_usual_cust_adj_amt_after',
'tax_exempt_plan_ind',
'tax_exempt_plan_ind_after',
'plan_usual_cust_ind',
'plan_usual_cust_ind_after',
'plan_usual_cust_cpy_ind',
'plan_usual_cust_cpy_ind_after',
'direct_link_cd',
'direct_link_cd_after',
'bin_nbr',
'bin_nbr_after',
'ncpdp_version',
'ncpdp_version_after',
'processor_ctr_nbr',
'processor_ctr_nbr_after',
'overrid_billing_basis_cd',
'overrid_billing_basis_cd_after',
'overrid_billing_adj_amt',
'overrid_billing_adj_amt_after',
'overrid_billing_adj_typ',
'overrid_billing_adj_typ_after',
'primary_billing_basis_cd',
'primary_billing_basis_cd_after',
'primary_billing_adj_amt',
'primary_billing_adj_amt_after',
'primary_billing_adj_typ',
'primary_billing_adj_typ_after',
'plan_bill_method_cd',
'plan_bill_method_cd_after',
'bill_form_type_cd',
'bill_form_type_cd_after',
'state_plan_cd',
'state_plan_cd_after',
'generic_disp_fee',
'generic_disp_fee_after',
'generic_disp_fee_cd',
'generic_disp_fee_cd_after',
'generic_copay',
'generic_copay_after',
'generic_copay_cd',
'generic_copay_cd_after',
'brand_disp_fee',
'brand_disp_fee_after',
'brand_disp_fee_cd',
'brand_disp_fee_cd_after',
'brand_copay',
'brand_copay_after',
'brand_copay_cd',
'brand_copay_cd_after',
'otc_disp_fee',
'otc_disp_fee_after',
'otc_disp_fee_cd',
'otc_disp_fee_cd_after',
'otc_copay',
'otc_copay_after',
'otc_copay_cd',
'otc_copay_cd_after',
'custom_pay_cd_ind',
'custom_pay_cd_ind_after',
'link_type_cd',
'link_type_cd_after',
'plan_usual_cust_adj_typ',
'plan_usual_cust_adj_typ_after',
'signature_required_ind',
'signature_required_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'child_plan_qty',
'child_plan_qty_after',
'parent_plan_id',
'parent_plan_id_after',
'plan_cfc_exclsns_ind',
'plan_cfc_exclsns_ind_after',
'sign_cd',
'sign_cd_after',
'promise_plan_cfc_cd',
'promise_plan_cfc_cd_after',
'mail_plan_uc_cd',
'mail_plan_uc_cd_after',
'mail_plan_uc_default_amt',
'mail_plan_uc_default_amt_after',
'corp_plan_area_cd',
'corp_plan_area_cd_after',
'corp_plan_phone',
'corp_plan_phone_after',
'plan_prior_auth_area_cd',
'plan_prior_auth_area_cd_after',
'plan_prior_auth_phone',
'plan_prior_auth_phone_after',
'partial_fill_version_cd',
'partial_fill_version_cd_after',
'thrd_pty_cert_id',
'thrd_pty_cert_id_after',
'assignd_nbr_ind',
'assignd_nbr_ind_after',
'dur_level_1',
'dur_level_1_after',
'dur_level_2',
'dur_level_2_after',
'dur_level_3',
'dur_level_3_after',
'dur_level_4',
'dur_level_4_after',
'dur_level_5',
'dur_level_5_after',
'coord_of_benefits_ind',
'coord_of_benefits_ind_after',
'sr_div_elig_ind',
'sr_div_elig_ind_after',
'manual_claim_ind',
'manual_claim_ind_after',
'pbr_assignd_nbr_ind',
'pbr_assignd_nbr_ind_after',
'pharmacist_cd',
'pharmacist_cd_after',
'person_cd_ind',
'person_cd_ind_after',
'actual_processor_ctr_nbr',
'actual_processor_ctr_nbr_after',
'cob_seg_ind',
'cob_seg_ind_after',
'sec_bill_method_cd',
'sec_bill_method_cd_after',
'sec_sent_cob_seg_ind',
'sec_sent_cob_seg_ind_after',
'sec_oac_ind',
'sec_oac_ind_after',
'sec_hybrid_threshold_amt',
'sec_hybrid_threshold_amt_after',
'sec_bill_for_zero_copay',
'sec_bill_for_zero_copay_after',
'sec_zero_opap_occ',
'sec_zero_opap_occ_after',
'sec_fullbill_cob_seg_ind',
'sec_fullbill_cob_seg_ind_after',
'sec_full_bill_occ',
'sec_full_bill_occ_after',
'sec_opap_qualifier',
'sec_opap_qualifier_after',
'sec_op_coverage_type',
'sec_op_coverage_type_after',
'discount_plan_cd',
'discount_plan_cd_after',
'plan_tip_exclusion_ind',
'plan_tip_exclusion_ind_after',
'document_id',
'document_id_after',
'epa_ind',
'epa_ind_after',
'sec_pbr_assignd_nbr_ind',
'sec_pbr_assignd_nbr_ind_after',
'sdl_cob_cd',
'sdl_cob_cd_after',
'allow_non_rx_otc_ind',
'allow_non_rx_otc_ind_after',
'non_rx_otc_pbr_id',
'non_rx_otc_pbr_id_after',
'non_rx_otc_days_supply',
'non_rx_otc_days_supply_after',
'd0_websdl_cob_ind',
'd0_websdl_cob_ind_after',
'elig_plan_description',
'elig_plan_description_after',
'elig_plan_recip_id_lbl',
'elig_plan_recip_id_lbl_after',
'pct_of_util_pln_adj',
'pct_of_util_pln_adj_after',
'sec_bill_lower_cpf_copay',
'sec_bill_lower_cpf_copay_after',
'sec_opap_adm_qlfr',
'sec_opap_adm_qlfr_after',
'sec_opap_cogn_qlfr',
'sec_opap_cogn_qlfr_after',
'd0_sec_zero_opap_occ',
'd0_sec_zero_opap_occ_after',
'sec_opap_dlvry_qlfr',
'sec_opap_dlvry_qlfr_after',
'sec_opap_drug_bnft_qlfr',
'sec_opap_drug_bnft_qlfr_after',
'sec_opap_incntv_qlfr',
'sec_opap_incntv_qlfr_after',
'sec_opap_post_qlfr',
'sec_opap_post_qlfr_after',
'sec_opap_ship_qlfr',
'sec_opap_ship_qlfr_after',
'sec_pat_lump_sum',
'sec_pat_lump_sum_after',
'sec_pat_pay_brkdwn',
'sec_pat_pay_brkdwn_after',
'sec_prim_gt_zero_occ',
'sec_prim_gt_zero_occ_after',
'sec_prim_lt_zero_occ',
'sec_prim_lt_zero_occ_after',
'sec_prim_rej_occ',
'sec_prim_rej_occ_after',
'd0_sec_bill_zero_copay',
'd0_sec_bill_zero_copay_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 239:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 240:
      return True
  else:
    if val_len != 240:
      return True



# COMMAND ----------


in_text = spark.read.text(readList)

in_text = in_text.rdd


# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.parquet(REJ_SHORT_FILEPATH)
  #df_junk.show(truncate=False)


# COMMAND ----------

#split and add schema
col_len = 240

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 240
print(f"Bad records count {rd_bad.count()}") # != 240

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

#display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_third_party_plan")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( plan_id )) ==0) then plan_id else trim(plan_id)end) as plan_id,
(case when (LENGTH(trim( plan_area_cd )) ==0) then plan_area_cd else trim(plan_area_cd)end) as plan_area_cd,
(case when (LENGTH(trim( plan_phone_nbr )) ==0) then plan_phone_nbr else trim(plan_phone_nbr)end) as plan_phone_nbr,
(case when (LENGTH(trim( plan_type_cd )) ==0) then plan_type_cd else trim(plan_type_cd)end) as plan_type_cd,
(case when (LENGTH(trim( plan_name )) ==0) then plan_name else trim(plan_name)end) as plan_name,
(case when (LENGTH(trim( plan_active_ind )) ==0) then plan_active_ind else trim(plan_active_ind)end) as plan_active_ind,
(case when (LENGTH(trim( plan_effective_dttm )) ==0) then plan_effective_dttm else concat(substring(plan_effective_dttm,1,10),' ',substring(plan_effective_dttm,12,8),'.000000')end) as plan_effective_dttm,
(case when (LENGTH(trim( phrm_store_nbr_cd )) ==0) then phrm_store_nbr_cd else trim(phrm_store_nbr_cd)end) as phrm_store_nbr_cd,
(case when (LENGTH(trim( pbr_cd )) ==0) then pbr_cd else trim(pbr_cd)end) as pbr_cd,
(case when (LENGTH(trim( secondary_pbr_cd )) ==0) then secondary_pbr_cd else trim(secondary_pbr_cd)end) as secondary_pbr_cd,
(case when (LENGTH(trim( plan_cmpd_drug_cd )) ==0) then plan_cmpd_drug_cd else trim(plan_cmpd_drug_cd)end) as plan_cmpd_drug_cd,
(case when (LENGTH(trim( plan_usual_cust_adj_amt )) ==0) then plan_usual_cust_adj_amt else trim(plan_usual_cust_adj_amt)end) as plan_usual_cust_adj_amt,
(case when (LENGTH(trim( tax_exempt_plan_ind )) ==0) then tax_exempt_plan_ind else trim(tax_exempt_plan_ind)end) as tax_exempt_plan_ind,
(case when (LENGTH(trim( plan_usual_cust_ind )) ==0) then plan_usual_cust_ind else trim(plan_usual_cust_ind)end) as plan_usual_cust_ind,
(case when (LENGTH(trim( plan_usual_cust_cpy_ind )) ==0) then plan_usual_cust_cpy_ind else trim(plan_usual_cust_cpy_ind)end) as plan_usual_cust_cpy_ind,
(case when (LENGTH(trim( direct_link_cd )) ==0) then direct_link_cd else trim(direct_link_cd)end) as direct_link_cd,
(case when (LENGTH(trim( bin_nbr )) ==0) then bin_nbr else trim(bin_nbr)end) as bin_nbr,
(case when (LENGTH(trim( ncpdp_version )) ==0) then ncpdp_version else trim(ncpdp_version)end) as ncpdp_version,
(case when (LENGTH(trim( processor_ctr_nbr )) ==0) then processor_ctr_nbr else trim(processor_ctr_nbr)end) as processor_ctr_nbr,
(case when (LENGTH(trim( overrid_billing_basis_cd )) ==0) then overrid_billing_basis_cd else trim(overrid_billing_basis_cd)end) as overrid_billing_basis_cd,
(case when (LENGTH(trim( overrid_billing_adj_amt )) ==0) then overrid_billing_adj_amt else trim(overrid_billing_adj_amt)end) as overrid_billing_adj_amt,
(case when (LENGTH(trim( overrid_billing_adj_typ )) ==0) then overrid_billing_adj_typ else trim(overrid_billing_adj_typ)end) as overrid_billing_adj_typ,
(case when (LENGTH(trim( primary_billing_basis_cd )) ==0) then primary_billing_basis_cd else trim(primary_billing_basis_cd)end) as primary_billing_basis_cd,
(case when (LENGTH(trim( primary_billing_adj_amt )) ==0) then primary_billing_adj_amt else trim(primary_billing_adj_amt)end) as primary_billing_adj_amt,
(case when (LENGTH(trim( primary_billing_adj_typ )) ==0) then primary_billing_adj_typ else trim(primary_billing_adj_typ)end) as primary_billing_adj_typ,
(case when (LENGTH(trim( plan_bill_method_cd )) ==0) then plan_bill_method_cd else trim(plan_bill_method_cd)end) as plan_bill_method_cd,
(case when (LENGTH(trim( bill_form_type_cd )) ==0) then bill_form_type_cd else trim(bill_form_type_cd)end) as bill_form_type_cd,
(case when (LENGTH(trim( state_plan_cd )) ==0) then state_plan_cd else trim(state_plan_cd)end) as state_plan_cd,
(case when (LENGTH(trim( generic_disp_fee )) ==0) then generic_disp_fee else trim(generic_disp_fee)end) as generic_disp_fee,
(case when (LENGTH(trim( generic_disp_fee_cd )) ==0) then generic_disp_fee_cd else trim(generic_disp_fee_cd)end) as generic_disp_fee_cd,
(case when (LENGTH(trim( generic_copay )) ==0) then generic_copay else trim(generic_copay)end) as generic_copay,
(case when (LENGTH(trim( generic_copay_cd )) ==0) then generic_copay_cd else trim(generic_copay_cd)end) as generic_copay_cd,
(case when (LENGTH(trim( brand_disp_fee )) ==0) then brand_disp_fee else trim(brand_disp_fee)end) as brand_disp_fee,
(case when (LENGTH(trim( brand_disp_fee_cd )) ==0) then brand_disp_fee_cd else trim(brand_disp_fee_cd)end) as brand_disp_fee_cd,
(case when (LENGTH(trim( brand_copay )) ==0) then brand_copay else trim(brand_copay)end) as brand_copay,
(case when (LENGTH(trim( brand_copay_cd )) ==0) then brand_copay_cd else trim(brand_copay_cd)end) as brand_copay_cd,
(case when (LENGTH(trim( otc_disp_fee )) ==0) then otc_disp_fee else trim(otc_disp_fee)end) as otc_disp_fee,
(case when (LENGTH(trim( otc_disp_fee_cd )) ==0) then otc_disp_fee_cd else trim(otc_disp_fee_cd)end) as otc_disp_fee_cd,
(case when (LENGTH(trim( otc_copay )) ==0) then otc_copay else trim(otc_copay)end) as otc_copay,
(case when (LENGTH(trim( otc_copay_cd )) ==0) then otc_copay_cd else trim(otc_copay_cd)end) as otc_copay_cd,
(case when (LENGTH(trim( custom_pay_cd_ind )) ==0) then custom_pay_cd_ind else trim(custom_pay_cd_ind)end) as custom_pay_cd_ind,
(case when (LENGTH(trim( link_type_cd )) ==0) then link_type_cd else trim(link_type_cd)end) as link_type_cd,
(case when (LENGTH(trim( plan_usual_cust_adj_typ )) ==0) then plan_usual_cust_adj_typ else trim(plan_usual_cust_adj_typ)end) as plan_usual_cust_adj_typ,
(case when (LENGTH(trim( signature_required_ind )) ==0) then signature_required_ind else trim(signature_required_ind)end) as signature_required_ind,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_dttm )) ==0) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim( update_dttm )) ==0) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( child_plan_qty )) ==0) then child_plan_qty else trim(child_plan_qty)end) as child_plan_qty,
(case when (LENGTH(trim( parent_plan_id )) ==0) then parent_plan_id else trim(parent_plan_id)end) as parent_plan_id,
(case when (LENGTH(trim( plan_cfc_exclsns_ind )) ==0) then plan_cfc_exclsns_ind else trim(plan_cfc_exclsns_ind)end) as plan_cfc_exclsns_ind,
(case when (LENGTH(trim( sign_cd )) ==0) then sign_cd else trim(sign_cd)end) as sign_cd,
(case when (LENGTH(trim( promise_plan_cfc_cd )) ==0) then promise_plan_cfc_cd else trim(promise_plan_cfc_cd)end) as promise_plan_cfc_cd,
(case when (LENGTH(trim( mail_plan_uc_cd )) ==0) then mail_plan_uc_cd else trim(mail_plan_uc_cd)end) as mail_plan_uc_cd,
(case when (LENGTH(trim( mail_plan_uc_default_amt )) ==0) then mail_plan_uc_default_amt else trim(mail_plan_uc_default_amt)end) as mail_plan_uc_default_amt,
(case when (LENGTH(trim( corp_plan_area_cd )) ==0) then corp_plan_area_cd else trim(corp_plan_area_cd)end) as corp_plan_area_cd,
(case when (LENGTH(trim( corp_plan_phone )) ==0) then corp_plan_phone else trim(corp_plan_phone)end) as corp_plan_phone,
(case when (LENGTH(trim( plan_prior_auth_area_cd )) ==0) then plan_prior_auth_area_cd else trim(plan_prior_auth_area_cd)end) as plan_prior_auth_area_cd,
(case when (LENGTH(trim( plan_prior_auth_phone )) ==0) then plan_prior_auth_phone else trim(plan_prior_auth_phone)end) as plan_prior_auth_phone,
(case when (LENGTH(trim( partial_fill_version_cd )) ==0) then partial_fill_version_cd else trim(partial_fill_version_cd)end) as partial_fill_version_cd,
(case when (LENGTH(trim( thrd_pty_cert_id )) ==0) then thrd_pty_cert_id else trim(thrd_pty_cert_id)end) as thrd_pty_cert_id,
(case when (LENGTH(trim( assignd_nbr_ind )) ==0) then assignd_nbr_ind else trim(assignd_nbr_ind)end) as assignd_nbr_ind,
(case when (LENGTH(trim( dur_level_1 )) ==0) then dur_level_1 else trim(dur_level_1)end) as dur_level_1,
(case when (LENGTH(trim( dur_level_2 )) ==0) then dur_level_2 else trim(dur_level_2)end) as dur_level_2,
(case when (LENGTH(trim( dur_level_3 )) ==0) then dur_level_3 else trim(dur_level_3)end) as dur_level_3,
(case when (LENGTH(trim( dur_level_4 )) ==0) then dur_level_4 else trim(dur_level_4)end) as dur_level_4,
(case when (LENGTH(trim( dur_level_5 )) ==0) then dur_level_5 else trim(dur_level_5)end) as dur_level_5,
(case when (LENGTH(trim( coord_of_benefits_ind )) ==0) then coord_of_benefits_ind else trim(coord_of_benefits_ind)end) as coord_of_benefits_ind,
(case when (LENGTH(trim( sr_div_elig_ind )) ==0) then sr_div_elig_ind else trim(sr_div_elig_ind)end) as sr_div_elig_ind,
(case when (LENGTH(trim( manual_claim_ind )) ==0) then manual_claim_ind else trim(manual_claim_ind)end) as manual_claim_ind,
(case when (LENGTH(trim( pbr_assignd_nbr_ind )) ==0) then pbr_assignd_nbr_ind else trim(pbr_assignd_nbr_ind)end) as pbr_assignd_nbr_ind,
(case when (LENGTH(trim( pharmacist_cd )) ==0) then pharmacist_cd else trim(pharmacist_cd)end) as pharmacist_cd,
(case when (LENGTH(trim( person_cd_ind )) ==0) then person_cd_ind else trim(person_cd_ind)end) as person_cd_ind,
(case when (LENGTH(trim( actual_processor_ctr_nbr )) ==0) then actual_processor_ctr_nbr else trim(actual_processor_ctr_nbr)end) as actual_processor_ctr_nbr,
(case when (LENGTH(trim( cob_seg_ind )) ==0) then cob_seg_ind else trim(cob_seg_ind)end) as cob_seg_ind,
(case when (LENGTH(trim( sec_bill_method_cd )) ==0) then sec_bill_method_cd else trim(sec_bill_method_cd)end) as sec_bill_method_cd,
(case when (LENGTH(trim( sec_sent_cob_seg_ind )) ==0) then sec_sent_cob_seg_ind else trim(sec_sent_cob_seg_ind)end) as sec_sent_cob_seg_ind,
(case when (LENGTH(trim( sec_oac_ind )) ==0) then sec_oac_ind else trim(sec_oac_ind)end) as sec_oac_ind,
(case when (LENGTH(trim( sec_hybrid_threshold_amt )) ==0) then sec_hybrid_threshold_amt else trim(sec_hybrid_threshold_amt)end) as sec_hybrid_threshold_amt,
(case when (LENGTH(trim( sec_bill_for_zero_copay )) ==0) then sec_bill_for_zero_copay else trim(sec_bill_for_zero_copay)end) as sec_bill_for_zero_copay,
(case when (LENGTH(trim( sec_zero_opap_occ )) ==0) then sec_zero_opap_occ else trim(sec_zero_opap_occ)end) as sec_zero_opap_occ,
(case when (LENGTH(trim( sec_fullbill_cob_seg_ind )) ==0) then sec_fullbill_cob_seg_ind else trim(sec_fullbill_cob_seg_ind)end) as sec_fullbill_cob_seg_ind,
(case when (LENGTH(trim( sec_full_bill_occ )) ==0) then sec_full_bill_occ else trim(sec_full_bill_occ)end) as sec_full_bill_occ,
(case when (LENGTH(trim( sec_opap_qualifier )) ==0) then sec_opap_qualifier else trim(sec_opap_qualifier)end)  as sec_opap_qualifier,
(case when (LENGTH(trim( sec_op_coverage_type )) ==0) then sec_op_coverage_type else trim(sec_op_coverage_type)end)  as sec_op_coverage_type,
(case when (LENGTH(trim( discount_plan_cd )) ==0) then discount_plan_cd else trim(discount_plan_cd)end)  as discount_plan_cd,
(case when (LENGTH(trim( plan_tip_exclusion_ind )) ==0) then plan_tip_exclusion_ind else trim(plan_tip_exclusion_ind)end)  as plan_tip_exclusion_ind,
(case when (LENGTH(trim( document_id )) ==0) then document_id else trim(document_id)end)  as document_id,
(case when (LENGTH(trim( epa_ind )) ==0) then epa_ind else trim(epa_ind)end)  as epa_ind,
(case when (LENGTH(trim( sec_pbr_assignd_nbr_ind )) ==0) then sec_pbr_assignd_nbr_ind else trim(sec_pbr_assignd_nbr_ind)end) as sec_pbr_assignd_nbr_ind,
(case when (LENGTH(trim( sdl_cob_cd )) ==0) then sdl_cob_cd else trim(sdl_cob_cd)end) as sdl_cob_cd,
(case when (LENGTH(trim( allow_non_rx_otc_ind )) ==0) then allow_non_rx_otc_ind else trim(allow_non_rx_otc_ind)end) as allow_non_rx_otc_ind,
(case when (LENGTH(trim( non_rx_otc_pbr_id )) ==0) then non_rx_otc_pbr_id else trim(non_rx_otc_pbr_id)end) as non_rx_otc_pbr_id,
(case when (LENGTH(trim( non_rx_otc_days_supply )) ==0) then non_rx_otc_days_supply else trim(non_rx_otc_days_supply)end) as non_rx_otc_days_supply,
(case when (LENGTH(trim( d0_sec_bill_zero_copay )) ==0) then d0_sec_bill_zero_copay else trim(d0_sec_bill_zero_copay)end) as d0_sec_bill_zero_copay,
(case when (LENGTH(trim( d0_sec_zero_opap_occ )) ==0) then d0_sec_zero_opap_occ else trim(d0_sec_zero_opap_occ)end) as d0_sec_zero_opap_occ,
(case when (LENGTH(trim( d0_websdl_cob_ind )) ==0) then d0_websdl_cob_ind else trim(d0_websdl_cob_ind)end) as d0_websdl_cob_ind,
(case when (LENGTH(trim( elig_plan_description )) ==0) then elig_plan_description else trim(elig_plan_description)end) as elig_plan_description,
(case when (LENGTH(trim( elig_plan_recip_id_lbl )) ==0) then elig_plan_recip_id_lbl else trim(elig_plan_recip_id_lbl)end) as elig_plan_recip_id_lbl,
(case when (LENGTH(trim( pct_of_util_pln_adj )) ==0) then pct_of_util_pln_adj else trim(pct_of_util_pln_adj)end) as pct_of_util_pln_adj,
(case when (LENGTH(trim( sec_bill_lower_cpf_copay )) ==0) then sec_bill_lower_cpf_copay else trim(sec_bill_lower_cpf_copay)end) as sec_bill_lower_cpf_copay,
(case when (LENGTH(trim( sec_opap_adm_qlfr )) ==0) then sec_opap_adm_qlfr else trim(sec_opap_adm_qlfr)end) as sec_opap_adm_qlfr,
(case when (LENGTH(trim( sec_opap_cogn_qlfr )) ==0) then sec_opap_cogn_qlfr else trim(sec_opap_cogn_qlfr)end) as sec_opap_cogn_qlfr,
(case when (LENGTH(trim( sec_opap_dlvry_qlfr )) ==0) then sec_opap_dlvry_qlfr else trim(sec_opap_dlvry_qlfr)end) as sec_opap_dlvry_qlfr,
(case when (LENGTH(trim( sec_opap_drug_bnft_qlfr )) ==0) then sec_opap_drug_bnft_qlfr else trim(sec_opap_drug_bnft_qlfr)end) as sec_opap_drug_bnft_qlfr,
(case when (LENGTH(trim( sec_opap_incntv_qlfr )) ==0) then sec_opap_incntv_qlfr else trim(sec_opap_incntv_qlfr)end) as sec_opap_incntv_qlfr,
(case when (LENGTH(trim( sec_opap_post_qlfr )) ==0) then sec_opap_post_qlfr else trim(sec_opap_post_qlfr)end) as sec_opap_post_qlfr,
(case when (LENGTH(trim( sec_opap_ship_qlfr )) ==0) then sec_opap_ship_qlfr else trim(sec_opap_ship_qlfr)end) as sec_opap_ship_qlfr ,
(case when (LENGTH(trim( sec_pat_lump_sum )) ==0) then sec_pat_lump_sum else trim(sec_pat_lump_sum)end) as sec_pat_lump_sum,
(case when (LENGTH(trim( sec_pat_pay_brkdwn )) ==0) then sec_pat_pay_brkdwn else trim(sec_pat_pay_brkdwn)end) as sec_pat_pay_brkdwn,
(case when (LENGTH(trim( sec_prim_gt_zero_occ )) ==0) then sec_prim_gt_zero_occ else trim(sec_prim_gt_zero_occ)end) as sec_prim_gt_zero_occ,
(case when (LENGTH(trim( sec_prim_lt_zero_occ )) ==0) then sec_prim_lt_zero_occ else trim(sec_prim_lt_zero_occ)end) as sec_prim_lt_zero_occ,
(case when (LENGTH(trim( sec_prim_rej_occ_after )) ==0) then sec_prim_rej_occ_after else trim(sec_prim_rej_occ_after)end) as sec_prim_rej_occ
from gg_tbf0_third_party_plan where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd='PK UPDATE')"""

# COMMAND ----------

sql2 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( plan_id_after )) ==0) then plan_id_after else trim(plan_id_after)end) as plan_id,
(case when (LENGTH(trim( plan_area_cd_after )) ==0) then plan_area_cd_after else trim(plan_area_cd_after)end) as plan_area_cd,
(case when (LENGTH(trim( plan_phone_nbr_after )) ==0) then plan_phone_nbr_after else trim(plan_phone_nbr_after)end) as plan_phone_nbr,
(case when (LENGTH(trim( plan_type_cd_after )) ==0) then plan_type_cd_after else trim(plan_type_cd_after)end) as plan_type_cd,
(case when (LENGTH(trim( plan_name_after )) ==0) then plan_name_after else trim(plan_name_after)end) as plan_name,
(case when (LENGTH(trim( plan_active_ind_after )) ==0) then plan_active_ind_after else trim(plan_active_ind_after)end) as plan_active_ind,
(case when (LENGTH(trim( plan_effective_dttm_after )) ==0) then plan_effective_dttm_after else concat(substring(plan_effective_dttm_after,1,10),' ',substring(plan_effective_dttm_after,12,8),'.000000')end) as plan_effective_dttm,
(case when (LENGTH(trim( phrm_store_nbr_cd_after )) ==0) then phrm_store_nbr_cd_after else trim(phrm_store_nbr_cd_after)end) as ,
(case when (LENGTH(trim( pbr_cd_after )) ==0) then pbr_cd_after else trim(pbr_cd_after)end) as phrm_store_nbr_cd,
(case when (LENGTH(trim( secondary_pbr_cd_after )) ==0) then secondary_pbr_cd_after else trim(secondary_pbr_cd_after)end) as secondary_pbr_cd,
(case when (LENGTH(trim( plan_cmpd_drug_cd_after )) ==0) then plan_cmpd_drug_cd_after else trim(plan_cmpd_drug_cd_after)end) as plan_cmpd_drug_cd,
(case when (LENGTH(trim( plan_usual_cust_adj_amt_after )) ==0) then plan_usual_cust_adj_amt_after else trim(plan_usual_cust_adj_amt_after)end) as plan_usual_cust_adj_amt,
(case when (LENGTH(trim( tax_exempt_plan_ind_after )) ==0) then tax_exempt_plan_ind_after else trim(tax_exempt_plan_ind_after)end) as tax_exempt_plan_ind,
(case when (LENGTH(trim( plan_usual_cust_ind_after )) ==0) then plan_usual_cust_ind_after else trim(plan_usual_cust_ind_after)end) as plan_usual_cust_ind,
(case when (LENGTH(trim( plan_usual_cust_cpy_ind_after )) ==0) then plan_usual_cust_cpy_ind_after else trim(plan_usual_cust_cpy_ind_after)end) as plan_usual_cust_cpy_ind,
(case when (LENGTH(trim( direct_link_cd_after )) ==0) then direct_link_cd_after else trim(direct_link_cd_after)end) as direct_link_cd,
(case when (LENGTH(trim( bin_nbr_after )) ==0) then bin_nbr_after else trim(bin_nbr_after)end) as bin_nbr,
(case when (LENGTH(trim( ncpdp_version_after )) ==0) then ncpdp_version_after else trim(ncpdp_version_after)end) as ncpdp_version,
(case when (LENGTH(trim( processor_ctr_nbr_after )) ==0) then processor_ctr_nbr_after else trim(processor_ctr_nbr_after)end) as processor_ctr_nbr,
(case when (LENGTH(trim( overrid_billing_basis_cd_after )) ==0) then overrid_billing_basis_cd_after else trim(overrid_billing_basis_cd_after)end) as overrid_billing_basis_cd,
(case when (LENGTH(trim( overrid_billing_adj_amt_after )) ==0) then overrid_billing_adj_amt_after else trim(overrid_billing_adj_amt_after)end) as overrid_billing_adj_amt,
(case when (LENGTH(trim( overrid_billing_adj_typ_after )) ==0) then overrid_billing_adj_typ_after else trim(overrid_billing_adj_typ_after)end) as overrid_billing_adj_typ,
(case when (LENGTH(trim( primary_billing_basis_cd_after )) ==0) then primary_billing_basis_cd_after else trim(primary_billing_basis_cd_after)end) as primary_billing_basis_cd,
(case when (LENGTH(trim( primary_billing_adj_amt_after )) ==0) then primary_billing_adj_amt_after else trim(primary_billing_adj_amt_after)end) as primary_billing_adj_amt,
(case when (LENGTH(trim( primary_billing_adj_typ_after )) ==0) then primary_billing_adj_typ_after else trim(primary_billing_adj_typ_after)end) as primary_billing_adj_typ,
(case when (LENGTH(trim( plan_bill_method_cd_after )) ==0) then plan_bill_method_cd_after else trim(plan_bill_method_cd_after)end) as plan_bill_method_cd,
(case when (LENGTH(trim( bill_form_type_cd_after )) ==0) then bill_form_type_cd_after else trim(bill_form_type_cd_after)end) as bill_form_type_cd,
(case when (LENGTH(trim( state_plan_cd_after )) ==0) then state_plan_cd_after else trim(state_plan_cd_after)end) as state_plan_cd,
(case when (LENGTH(trim( generic_disp_fee_after )) ==0) then generic_disp_fee_after else trim(generic_disp_fee_after)end) as generic_disp_fee,
(case when (LENGTH(trim( generic_disp_fee_cd_after )) ==0) then generic_disp_fee_cd_after else trim(generic_disp_fee_cd_after)end) as generic_disp_fee_cd,
(case when (LENGTH(trim( generic_copay_after )) ==0) then generic_copay_after else trim(generic_copay_after)end) as generic_copay,
(case when (LENGTH(trim( generic_copay_cd_after )) ==0) then generic_copay_cd_after else trim(generic_copay_cd_after)end) as generic_copay_cd,
(case when (LENGTH(trim( brand_disp_fee_after )) ==0) then brand_disp_fee_after else trim(brand_disp_fee_after)end) as brand_disp_fee,
(case when (LENGTH(trim( brand_disp_fee_cd_after )) ==0) then brand_disp_fee_cd_after else trim(brand_disp_fee_cd_after)end) as brand_disp_fee_cd,
(case when (LENGTH(trim( brand_copay_after )) ==0) then brand_copay_after else trim(brand_copay_after)end) as brand_copay,
(case when (LENGTH(trim( brand_copay_cd_after )) ==0) then brand_copay_cd_after else trim(brand_copay_cd_after)end) as brand_copay_cd,
(case when (LENGTH(trim( otc_disp_fee_after )) ==0) then otc_disp_fee_after else trim(otc_disp_fee_after)end) as otc_disp_fee,
(case when (LENGTH(trim( otc_disp_fee_cd_after )) ==0) then otc_disp_fee_cd_after else trim(otc_disp_fee_cd_after)end) as otc_disp_fee_cd,
(case when (LENGTH(trim( otc_copay_after )) ==0) then otc_copay_after else trim(otc_copay_after)end) as otc_copay,
(case when (LENGTH(trim( otc_copay_cd_after )) ==0) then otc_copay_cd_after else trim(otc_copay_cd_after)end) as otc_copay_cd,
(case when (LENGTH(trim( custom_pay_cd_ind_after )) ==0) then custom_pay_cd_ind_after else trim(custom_pay_cd_ind_after)end) as custom_pay_cd_ind,
(case when (LENGTH(trim( link_type_cd_after )) ==0) then link_type_cd_after else trim(link_type_cd_after)end) as link_type_cd,
(case when (LENGTH(trim( plan_usual_cust_adj_typ_after )) ==0) then plan_usual_cust_adj_typ_after else trim(plan_usual_cust_adj_typ_after)end) as plan_usual_cust_adj_typ,
(case when (LENGTH(trim( signature_required_ind_after )) ==0) then signature_required_ind_after else trim(signature_required_ind_after)end) as signature_required_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( child_plan_qty_after )) ==0) then child_plan_qty_after else trim(child_plan_qty_after)end) as child_plan_qty,
(case when (LENGTH(trim( parent_plan_id_after )) ==0) then parent_plan_id_after else trim(parent_plan_id_after)end) as parent_plan_id,
(case when (LENGTH(trim( plan_cfc_exclsns_ind_after )) ==0) then plan_cfc_exclsns_ind_after else trim(plan_cfc_exclsns_ind_after)end) as plan_cfc_exclsns_ind,
(case when (LENGTH(trim( sign_cd_after )) ==0) then sign_cd_after else trim(sign_cd_after)end) as sign_cd,
(case when (LENGTH(trim( promise_plan_cfc_cd_after )) ==0) then promise_plan_cfc_cd_after else trim(promise_plan_cfc_cd_after)end) as promise_plan_cfc_cd,
(case when (LENGTH(trim( mail_plan_uc_cd_after )) ==0) then mail_plan_uc_cd_after else trim(mail_plan_uc_cd_after)end) as mail_plan_uc_cd,
(case when (LENGTH(trim( mail_plan_uc_default_amt_after )) ==0) then mail_plan_uc_default_amt_after else trim(mail_plan_uc_default_amt_after)end) as mail_plan_uc_default_amt,
(case when (LENGTH(trim( corp_plan_area_cd_after )) ==0) then corp_plan_area_cd_after else trim(corp_plan_area_cd_after)end) as corp_plan_area_cd,
(case when (LENGTH(trim( corp_plan_phone_after )) ==0) then corp_plan_phone_after else trim(corp_plan_phone_after)end) as corp_plan_phone,
(case when (LENGTH(trim( plan_prior_auth_area_cd_after )) ==0) then plan_prior_auth_area_cd_after else trim(plan_prior_auth_area_cd_after)end) as plan_prior_auth_area_cd,
(case when (LENGTH(trim( plan_prior_auth_phone_after )) ==0) then plan_prior_auth_phone_after else trim(plan_prior_auth_phone_after)end) as plan_prior_auth_phone,
(case when (LENGTH(trim( partial_fill_version_cd_after )) ==0) then partial_fill_version_cd_after else trim(partial_fill_version_cd_after)end) as partial_fill_version_cd,
(case when (LENGTH(trim( thrd_pty_cert_id_after )) ==0) then thrd_pty_cert_id_after else trim(thrd_pty_cert_id_after)end) as thrd_pty_cert_id,
(case when (LENGTH(trim( assignd_nbr_ind_after )) ==0) then assignd_nbr_ind_after else trim(assignd_nbr_ind_after)end) as assignd_nbr_ind,
(case when (LENGTH(trim( dur_level_1_after )) ==0) then dur_level_1_after else trim(dur_level_1_after)end) as dur_level_1,
(case when (LENGTH(trim( dur_level_2_after )) ==0) then dur_level_2_after else trim(dur_level_2_after)end) as dur_level_2,
(case when (LENGTH(trim( dur_level_3_after )) ==0) then dur_level_3_after else trim(dur_level_3_after)end) as dur_level_3,
(case when (LENGTH(trim( dur_level_4_after )) ==0) then dur_level_4_after else trim(dur_level_4_after)end) as dur_level_4,
(case when (LENGTH(trim( dur_level_5_after )) ==0) then dur_level_5_after else trim(dur_level_5_after)end) as dur_level_5,
(case when (LENGTH(trim( coord_of_benefits_ind_after )) ==0) then coord_of_benefits_ind_after else trim(coord_of_benefits_ind_after)end) as coord_of_benefits_ind,
(case when (LENGTH(trim( sr_div_elig_ind_after )) ==0) then sr_div_elig_ind_after else trim(sr_div_elig_ind_after)end) as sr_div_elig_ind,
(case when (LENGTH(trim( manual_claim_ind_after )) ==0) then manual_claim_ind_after else trim(manual_claim_ind_after)end) as manual_claim_ind,
(case when (LENGTH(trim( pbr_assignd_nbr_ind_after )) ==0) then pbr_assignd_nbr_ind_after else trim(pbr_assignd_nbr_ind_after)end) as pbr_assignd_nbr_ind,
(case when (LENGTH(trim( pharmacist_cd_after )) ==0) then pharmacist_cd_after else trim(pharmacist_cd_after)end) as pharmacist_cd,
(case when (LENGTH(trim( person_cd_ind_after )) ==0) then person_cd_ind_after else trim(person_cd_ind_after)end) as person_cd_ind,
(case when (LENGTH(trim( actual_processor_ctr_nbr_after )) ==0) then actual_processor_ctr_nbr_after else trim(actual_processor_ctr_nbr_after)end) as actual_processor_ctr_nbr,
(case when (LENGTH(trim( cob_seg_ind_after )) ==0) then cob_seg_ind_after else trim(cob_seg_ind_after)end) as cob_seg_ind,
(case when (LENGTH(trim( sec_bill_method_cd_after )) ==0) then sec_bill_method_cd_after else trim(sec_bill_method_cd_after)end) as sec_bill_method_cd,
(case when (LENGTH(trim( sec_sent_cob_seg_ind_after )) ==0) then sec_sent_cob_seg_ind_after else trim(sec_sent_cob_seg_ind_after)end) as sec_sent_cob_seg_ind,
(case when (LENGTH(trim( sec_oac_ind_after )) ==0) then sec_oac_ind_after else trim(sec_oac_ind_after)end) as sec_oac_ind,
(case when (LENGTH(trim( sec_hybrid_threshold_amt_after )) ==0) then sec_hybrid_threshold_amt_after else trim(sec_hybrid_threshold_amt_after)end) as sec_hybrid_threshold_amt,
(case when (LENGTH(trim( sec_bill_for_zero_copay_after )) ==0) then sec_bill_for_zero_copay_after else trim(sec_bill_for_zero_copay_after)end) as sec_bill_for_zero_copay,
(case when (LENGTH(trim( sec_zero_opap_occ_after )) ==0) then sec_zero_opap_occ_after else trim(sec_zero_opap_occ_after)end) as sec_zero_opap_occ,
(case when (LENGTH(trim( sec_fullbill_cob_seg_ind_after )) ==0) then sec_fullbill_cob_seg_ind_after else trim(sec_fullbill_cob_seg_ind_after)end) as sec_fullbill_cob_seg_ind,
(case when (LENGTH(trim( sec_full_bill_occ_after )) ==0) then sec_full_bill_occ_after else trim(sec_full_bill_occ_after)end) as sec_full_bill_occ,
(case when (LENGTH(trim( sec_opap_qualifier_after )) ==0) then sec_opap_qualifier_after else trim(sec_opap_qualifier_after)end) as sec_opap_qualifier,
(case when (LENGTH(trim( sec_op_coverage_type_after )) ==0) then sec_op_coverage_type_after else trim(sec_op_coverage_type_after)end) as sec_op_coverage_type,
(case when (LENGTH(trim( discount_plan_cd_after )) ==0) then discount_plan_cd_after else trim(discount_plan_cd_after)end) as discount_plan_cd,
(case when (LENGTH(trim( plan_tip_exclusion_ind_after )) ==0) then plan_tip_exclusion_ind_after else trim(plan_tip_exclusion_ind_after)end) as plan_tip_exclusion_ind,
(case when (LENGTH(trim( document_id_after )) ==0) then document_id_after else trim(document_id_after)end) as document_id,
(case when (LENGTH(trim( epa_ind_after )) ==0) then epa_ind_after else trim(epa_ind_after)end) as epa_ind,
(case when (LENGTH(trim( sec_pbr_assignd_nbr_ind_after )) ==0) then sec_pbr_assignd_nbr_ind_after else trim(sec_pbr_assignd_nbr_ind_after)end) as sec_pbr_assignd_nbr_ind,
(case when (LENGTH(trim( sdl_cob_cd_after )) ==0) then sdl_cob_cd_after else trim(sdl_cob_cd_after)end) as sdl_cob_cd,
(case when (LENGTH(trim( allow_non_rx_otc_ind_after )) ==0) then allow_non_rx_otc_ind_after else trim(allow_non_rx_otc_ind_after)end) as allow_non_rx_otc_ind,
(case when (LENGTH(trim( non_rx_otc_pbr_id_after )) ==0) then non_rx_otc_pbr_id_after else trim(non_rx_otc_pbr_id_after)end) as non_rx_otc_pbr_id,
(case when (LENGTH(trim( non_rx_otc_days_supply_after )) ==0) then non_rx_otc_days_supply_after else trim(non_rx_otc_days_supply_after)end) as non_rx_otc_days_supply,
(case when (LENGTH(trim( d0_sec_bill_zero_copay_after )) ==0) then d0_sec_bill_zero_copay_after else trim(d0_sec_bill_zero_copay_after)end) asd0_sec_bill_zero_copay,
(case when (LENGTH(trim( d0_sec_zero_opap_occ_after )) ==0) then d0_sec_zero_opap_occ_after else trim(d0_sec_zero_opap_occ_after)end) as d0_sec_zero_opap_occ,
(case when (LENGTH(trim( d0_websdl_cob_ind_after )) ==0) then d0_websdl_cob_ind_after else trim(d0_websdl_cob_ind_after)end) as d0_websdl_cob_ind,
(case when (LENGTH(trim( elig_plan_description_after )) ==0) then elig_plan_description_after else trim(elig_plan_description_after)end) as elig_plan_description,
(case when (LENGTH(trim( elig_plan_recip_id_lbl_after )) ==0) then elig_plan_recip_id_lbl_after else trim(elig_plan_recip_id_lbl_after)end) as elig_plan_recip_id_lbl,
(case when (LENGTH(trim( pct_of_util_pln_adj_after )) ==0) then pct_of_util_pln_adj_after else trim(pct_of_util_pln_adj_after)end) as pct_of_util_pln_adj,
(case when (LENGTH(trim( sec_bill_lower_cpf_copay_after )) ==0) then sec_bill_lower_cpf_copay_after else trim(sec_bill_lower_cpf_copay_after)end) as sec_bill_lower_cpf_copay,
(case when (LENGTH(trim( sec_opap_adm_qlfr_after )) ==0) then sec_opap_adm_qlfr_after else trim(sec_opap_adm_qlfr_after)end) as sec_opap_adm_qlfr,
(case when (LENGTH(trim( sec_opap_cogn_qlfr_after )) ==0) then sec_opap_cogn_qlfr_after else trim(sec_opap_cogn_qlfr_after)end) as sec_opap_cogn_qlfr,
(case when (LENGTH(trim( sec_opap_dlvry_qlfr_after )) ==0) then sec_opap_dlvry_qlfr_after else trim(sec_opap_dlvry_qlfr_after)end) as sec_opap_dlvry_qlfr,
(case when (LENGTH(trim( sec_opap_drug_bnft_qlfr_after )) ==0) then sec_opap_drug_bnft_qlfr_after else trim(sec_opap_drug_bnft_qlfr_after)end) as sec_opap_drug_bnft_qlfr,
(case when (LENGTH(trim( sec_opap_incntv_qlfr_after )) ==0) then sec_opap_incntv_qlfr_after else trim(sec_opap_incntv_qlfr_after)end) as sec_opap_incntv_qlfr,
(case when (LENGTH(trim( sec_opap_post_qlfr_after )) ==0) then sec_opap_post_qlfr_after else trim(sec_opap_post_qlfr_after)end) as sec_opap_post_qlfr,
(case when (LENGTH(trim( sec_opap_ship_qlfr_after )) ==0) then sec_opap_ship_qlfr_after else trim(sec_opap_ship_qlfr_after)end) as sec_opap_ship_qlfr,
(case when (LENGTH(trim( sec_pat_lump_sum_after )) ==0) then sec_pat_lump_sum_after else trim(sec_pat_lump_sum_after)end) as sec_pat_lump_sum,
(case when (LENGTH(trim( sec_pat_pay_brkdwn_after )) ==0) then sec_pat_pay_brkdwn_after else trim(sec_pat_pay_brkdwn_after)end) as sec_pat_pay_brkdwn,
(case when (LENGTH(trim( sec_prim_gt_zero_occ_after )) ==0) then sec_prim_gt_zero_occ_after else trim(sec_prim_gt_zero_occ_after)end) as sec_prim_gt_zero_occ,
(case when (LENGTH(trim( sec_prim_lt_zero_occ_after )) ==0) then sec_prim_lt_zero_occ_after else trim(sec_prim_lt_zero_occ_after)end) as sec_prim_lt_zero_occ,
(case when (LENGTH(trim( sec_prim_rej_occ_after )) ==0) then sec_prim_rej_occ_after else trim(sec_prim_rej_occ_after)end) as sec_prim_rej_occ
from  gg_tbf0_third_party_plan where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end),
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end),
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end),
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end),
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( plan_id_after )) ==0) then plan_id_after else trim(plan_id_after)end) as plan_id,
(case when (LENGTH(trim( plan_area_cd_after )) ==0) then plan_area_cd_after else trim(plan_area_cd_after)end) as plan_area_cd,
(case when (LENGTH(trim( plan_phone_nbr_after )) ==0) then plan_phone_nbr_after else trim(plan_phone_nbr_after)end) as plan_phone_nbr,
(case when (LENGTH(trim( plan_type_cd_after )) ==0) then plan_type_cd_after else trim(plan_type_cd_after)end) as plan_type_cd,
(case when (LENGTH(trim( plan_name_after )) ==0) then plan_name_after else trim(plan_name_after)end) as plan_name,
(case when (LENGTH(trim( plan_active_ind_after )) ==0) then plan_active_ind_after else trim(plan_active_ind_after)end) as plan_active_ind,
(case when (LENGTH(trim( plan_effective_dttm_after )) ==0) then plan_effective_dttm_after else concat(substring(plan_effective_dttm_after,1,10),' ',substring(plan_effective_dttm_after,12,8),'.000000')end) as plan_effective_dttm,
(case when (LENGTH(trim( phrm_store_nbr_cd_after )) ==0) then phrm_store_nbr_cd_after else trim(phrm_store_nbr_cd_after)end) as phrm_store_nbr_cd,
(case when (LENGTH(trim( pbr_cd_after )) ==0) then pbr_cd_after else trim(pbr_cd_after)end) as pbr_cd,
(case when (LENGTH(trim( secondary_pbr_cd_after )) ==0) then secondary_pbr_cd_after else trim(secondary_pbr_cd_after)end) as secondary_pbr_cd,
(case when (LENGTH(trim( plan_cmpd_drug_cd_after )) ==0) then plan_cmpd_drug_cd_after else trim(plan_cmpd_drug_cd_after)end) as plan_cmpd_drug_cd,
(case when (LENGTH(trim( plan_usual_cust_adj_amt_after )) ==0) then plan_usual_cust_adj_amt_after else trim(plan_usual_cust_adj_amt_after)end) as plan_usual_cust_adj_amt,
(case when (LENGTH(trim( tax_exempt_plan_ind_after )) ==0) then tax_exempt_plan_ind_after else trim(tax_exempt_plan_ind_after)end) as tax_exempt_plan_ind,
(case when (LENGTH(trim( plan_usual_cust_ind_after )) ==0) then plan_usual_cust_ind_after else trim(plan_usual_cust_ind_after)end) as plan_usual_cust_ind,
(case when (LENGTH(trim( plan_usual_cust_cpy_ind_after )) ==0) then plan_usual_cust_cpy_ind_after else trim(plan_usual_cust_cpy_ind_after)end) as plan_usual_cust_cpy_ind,
(case when (LENGTH(trim( direct_link_cd_after )) ==0) then direct_link_cd_after else trim(direct_link_cd_after)end) as direct_link_cd,
(case when (LENGTH(trim( bin_nbr_after )) ==0) then bin_nbr_after else trim(bin_nbr_after)end) as direct_link_cd,
(case when (LENGTH(trim( ncpdp_version_after )) ==0) then ncpdp_version_after else trim(ncpdp_version_after)end) as ncpdp_version,
(case when (LENGTH(trim( processor_ctr_nbr_after )) ==0) then processor_ctr_nbr_after else trim(processor_ctr_nbr_after)end) as processor_ctr_nbr
,
(case when (LENGTH(trim( overrid_billing_basis_cd_after )) ==0) then overrid_billing_basis_cd_after else trim(overrid_billing_basis_cd_after)end) as overrid_billing_basis_cd,
(case when (LENGTH(trim( overrid_billing_adj_amt_after )) ==0) then overrid_billing_adj_amt_after else trim(overrid_billing_adj_amt_after)end) as overrid_billing_adj_amt,
(case when (LENGTH(trim( overrid_billing_adj_typ_after )) ==0) then overrid_billing_adj_typ_after else trim(overrid_billing_adj_typ_after)end) as overrid_billing_adj_typ,
(case when (LENGTH(trim( primary_billing_basis_cd_after )) ==0) then primary_billing_basis_cd_after else trim(primary_billing_basis_cd_after)end) as primary_billing_basis_cd,
(case when (LENGTH(trim( primary_billing_adj_amt_after )) ==0) then primary_billing_adj_amt_after else trim(primary_billing_adj_amt_after)end) as primary_billing_adj_amt,
(case when (LENGTH(trim( primary_billing_adj_typ_after )) ==0) then primary_billing_adj_typ_after else trim(primary_billing_adj_typ_after)end) as primary_billing_adj_typ,
(case when (LENGTH(trim( plan_bill_method_cd_after )) ==0) then plan_bill_method_cd_after else trim(plan_bill_method_cd_after)end) as plan_bill_method_cd,
(case when (LENGTH(trim( bill_form_type_cd_after )) ==0) then bill_form_type_cd_after else trim(bill_form_type_cd_after)end) as bill_form_type_cd,
(case when (LENGTH(trim( state_plan_cd_after )) ==0) then state_plan_cd_after else trim(state_plan_cd_after)end) as state_plan_cd,
(case when (LENGTH(trim( generic_disp_fee_after )) ==0) then generic_disp_fee_after else trim(generic_disp_fee_after)end) as generic_disp_fee,
(case when (LENGTH(trim( generic_disp_fee_cd_after )) ==0) then generic_disp_fee_cd_after else trim(generic_disp_fee_cd_after)end) as generic_disp_fee_cd,
(case when (LENGTH(trim( generic_copay_after )) ==0) then generic_copay_after else trim(generic_copay_after)end) as generic_disp_fee_cd,
(case when (LENGTH(trim( generic_copay_cd_after )) ==0) then generic_copay_cd_after else trim(generic_copay_cd_after)end) as generic_copay_cd,
(case when (LENGTH(trim( brand_disp_fee_after )) ==0) then brand_disp_fee_after else trim(brand_disp_fee_after)end) as brand_disp_fee,
(case when (LENGTH(trim( brand_disp_fee_cd_after )) ==0) then brand_disp_fee_cd_after else trim(brand_disp_fee_cd_after)end) as brand_disp_fee_cd,
(case when (LENGTH(trim( brand_copay_after )) ==0) then brand_copay_after else trim(brand_copay_after)end) as brand_copay,
(case when (LENGTH(trim( brand_copay_cd_after )) ==0) then brand_copay_cd_after else trim(brand_copay_cd_after)end) as brand_copay,
(case when (LENGTH(trim( otc_disp_fee_after )) ==0) then otc_disp_fee_after else trim(otc_disp_fee_after)end) as otc_disp_fee,
(case when (LENGTH(trim( otc_disp_fee_cd_after )) ==0) then otc_disp_fee_cd_after else trim(otc_disp_fee_cd_after)end) as otc_disp_fee_cd,
(case when (LENGTH(trim( otc_copay_after )) ==0) then otc_copay_after else trim(otc_copay_after)end) as otc_copay,
(case when (LENGTH(trim( otc_copay_cd_after )) ==0) then otc_copay_cd_after else trim(otc_copay_cd_after)end) as otc_copay_cd,
(case when (LENGTH(trim( custom_pay_cd_ind_after )) ==0) then custom_pay_cd_ind_after else trim(custom_pay_cd_ind_after)end) as custom_pay_cd_ind,
(case when (LENGTH(trim( link_type_cd_after )) ==0) then link_type_cd_after else trim(link_type_cd_after)end) as link_type_cd,
(case when (LENGTH(trim( plan_usual_cust_adj_typ_after )) ==0) then plan_usual_cust_adj_typ_after else trim(plan_usual_cust_adj_typ_after)end) as plan_usual_cust_adj_typ,
(case when (LENGTH(trim( signature_required_ind_after )) ==0) then signature_required_ind_after else trim(signature_required_ind_after)end) as signature_required_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as signature_required_ind,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( child_plan_qty_after )) ==0) then child_plan_qty_after else trim(child_plan_qty_after)end) as child_plan_qty,
(case when (LENGTH(trim( parent_plan_id_after )) ==0) then parent_plan_id_after else trim(parent_plan_id_after)end) as parent_plan_id,
(case when (LENGTH(trim( plan_cfc_exclsns_ind_after )) ==0) then plan_cfc_exclsns_ind_after else trim(plan_cfc_exclsns_ind_after)end) as plan_cfc_exclsns_ind,
(case when (LENGTH(trim( sign_cd_after )) ==0) then sign_cd_after else trim(sign_cd_after)end) as sign_cd,
(case when (LENGTH(trim( promise_plan_cfc_cd_after )) ==0) then promise_plan_cfc_cd_after else trim(promise_plan_cfc_cd_after)end) as promise_plan_cfc_cd,
(case when (LENGTH(trim( mail_plan_uc_cd_after )) ==0) then mail_plan_uc_cd_after else trim(mail_plan_uc_cd_after)end) as mail_plan_uc_cd,
(case when (LENGTH(trim( mail_plan_uc_default_amt_after )) ==0) then mail_plan_uc_default_amt_after else trim(mail_plan_uc_default_amt_after)end) as mail_plan_uc_default_amt,
(case when (LENGTH(trim( corp_plan_area_cd_after )) ==0) then corp_plan_area_cd_after else trim(corp_plan_area_cd_after)end) as corp_plan_area_cd,
(case when (LENGTH(trim( corp_plan_phone_after )) ==0) then corp_plan_phone_after else trim(corp_plan_phone_after)end) as corp_plan_phone,
(case when (LENGTH(trim( plan_prior_auth_area_cd_after )) ==0) then plan_prior_auth_area_cd_after else trim(plan_prior_auth_area_cd_after)end) as plan_prior_auth_area_cd,
(case when (LENGTH(trim( plan_prior_auth_phone_after )) ==0) then plan_prior_auth_phone_after else trim(plan_prior_auth_phone_after)end) as plan_prior_auth_phone,
(case when (LENGTH(trim( partial_fill_version_cd_after )) ==0) then partial_fill_version_cd_after else trim(partial_fill_version_cd_after)end) as partial_fill_version_cd,
(case when (LENGTH(trim( thrd_pty_cert_id_after )) ==0) then thrd_pty_cert_id_after else trim(thrd_pty_cert_id_after)end) as thrd_pty_cert_id,
(case when (LENGTH(trim( assignd_nbr_ind_after )) ==0) then assignd_nbr_ind_after else trim(assignd_nbr_ind_after)end) as assignd_nbr_ind,
(case when (LENGTH(trim( dur_level_1_after )) ==0) then dur_level_1_after else trim(dur_level_1_after)end) as dur_level_1,
(case when (LENGTH(trim( dur_level_2_after )) ==0) then dur_level_2_after else trim(dur_level_2_after)end) as dur_level_2,
(case when (LENGTH(trim( dur_level_3_after )) ==0) then dur_level_3_after else trim(dur_level_3_after)end) as dur_level_3,
(case when (LENGTH(trim( dur_level_4_after )) ==0) then dur_level_4_after else trim(dur_level_4_after)end) as dur_level_4,
(case when (LENGTH(trim( dur_level_5_after )) ==0) then dur_level_5_after else trim(dur_level_5_after)end) as dur_level_5,
(case when (LENGTH(trim( coord_of_benefits_ind_after )) ==0) then coord_of_benefits_ind_after else trim(coord_of_benefits_ind_after)end) as coord_of_benefits_ind,
(case when (LENGTH(trim( sr_div_elig_ind_after )) ==0) then sr_div_elig_ind_after else trim(sr_div_elig_ind_after)end) as sr_div_elig_ind,
(case when (LENGTH(trim( manual_claim_ind_after )) ==0) then manual_claim_ind_after else trim(manual_claim_ind_after)end) as manual_claim_ind,
(case when (LENGTH(trim( pbr_assignd_nbr_ind_after )) ==0) then pbr_assignd_nbr_ind_after else trim(pbr_assignd_nbr_ind_after)end) as pbr_assignd_nbr_ind,
(case when (LENGTH(trim( pharmacist_cd_after )) ==0) then pharmacist_cd_after else trim(pharmacist_cd_after)end) as pharmacist_cd,
(case when (LENGTH(trim( person_cd_ind_after )) ==0) then person_cd_ind_after else trim(person_cd_ind_after)end) as person_cd_ind,
(case when (LENGTH(trim( actual_processor_ctr_nbr_after )) ==0) then actual_processor_ctr_nbr_after else trim(actual_processor_ctr_nbr_after)end) as actual_processor_ctr_nbr,
(case when (LENGTH(trim( cob_seg_ind_after )) ==0) then cob_seg_ind_after else trim(cob_seg_ind_after)end) as cob_seg_ind,
(case when (LENGTH(trim( sec_bill_method_cd_after )) ==0) then sec_bill_method_cd_after else trim(sec_bill_method_cd_after)end) as sec_bill_method_cd,
(case when (LENGTH(trim( sec_sent_cob_seg_ind_after )) ==0) then sec_sent_cob_seg_ind_after else trim(sec_sent_cob_seg_ind_after)end) as sec_sent_cob_seg_ind,
(case when (LENGTH(trim( sec_oac_ind_after )) ==0) then sec_oac_ind_after else trim(sec_oac_ind_after)end) as sec_oac_ind,
(case when (LENGTH(trim( sec_hybrid_threshold_amt_after )) ==0) then sec_hybrid_threshold_amt_after else trim(sec_hybrid_threshold_amt_after)end) as sec_hybrid_threshold_amt,
(case when (LENGTH(trim( sec_bill_for_zero_copay_after )) ==0) then sec_bill_for_zero_copay_after else trim(sec_bill_for_zero_copay_after)end) as sec_bill_for_zero_copay,
(case when (LENGTH(trim( sec_zero_opap_occ_after )) ==0) then sec_zero_opap_occ_after else trim(sec_zero_opap_occ_after)end) as sec_zero_opap_occ,
(case when (LENGTH(trim( sec_fullbill_cob_seg_ind_after )) ==0) then sec_fullbill_cob_seg_ind_after else trim(sec_fullbill_cob_seg_ind_after)end) as sec_fullbill_cob_seg_ind,
(case when (LENGTH(trim( sec_full_bill_occ_after )) ==0) then sec_full_bill_occ_after else trim(sec_full_bill_occ_after)end) as sec_full_bill_occ,
(case when (LENGTH(trim( sec_opap_qualifier_after )) ==0) then sec_opap_qualifier_after else trim(sec_opap_qualifier_after)end) as sec_opap_qualifier,
(case when (LENGTH(trim( sec_op_coverage_type_after )) ==0) then sec_op_coverage_type_after else trim(sec_op_coverage_type_after)end) as sec_op_coverage_type,
(case when (LENGTH(trim( discount_plan_cd_after )) ==0) then discount_plan_cd_after else trim(discount_plan_cd_after)end) as discount_plan_cd,
(case when (LENGTH(trim( plan_tip_exclusion_ind_after )) ==0) then plan_tip_exclusion_ind_after else trim(plan_tip_exclusion_ind_after)end) as plan_tip_exclusion_ind,
(case when (LENGTH(trim( document_id_after )) ==0) then document_id_after else trim(document_id_after)end) as document_id,
(case when (LENGTH(trim( epa_ind_after )) ==0) then epa_ind_after else trim(epa_ind_after)end) as epa_ind,
(case when (LENGTH(trim( sec_pbr_assignd_nbr_ind_after )) ==0) then sec_pbr_assignd_nbr_ind_after else trim(sec_pbr_assignd_nbr_ind_after)end) as sec_pbr_assignd_nbr_ind,
(case when (LENGTH(trim( sdl_cob_cd_after )) ==0) then sdl_cob_cd_after else trim(sdl_cob_cd_after)end) as sdl_cob_cd,
(case when (LENGTH(trim( allow_non_rx_otc_ind_after )) ==0) then allow_non_rx_otc_ind_after else trim(allow_non_rx_otc_ind_after)end) as allow_non_rx_otc_ind,
(case when (LENGTH(trim( non_rx_otc_pbr_id_after )) ==0) then non_rx_otc_pbr_id_after else trim(non_rx_otc_pbr_id_after)end) as allow_non_rx_otc_ind,
(case when (LENGTH(trim( non_rx_otc_days_supply_after )) ==0) then non_rx_otc_days_supply_after else trim(non_rx_otc_days_supply_after)end) as non_rx_otc_days_supply,
(case when (LENGTH(trim( d0_sec_bill_zero_copay_after )) ==0) then d0_sec_bill_zero_copay_after else trim(d0_sec_bill_zero_copay_after)end) as d0_sec_bill_zero_copay,
(case when (LENGTH(trim( d0_sec_zero_opap_occ_after )) ==0) then d0_sec_zero_opap_occ_after else trim(d0_sec_zero_opap_occ_after)end) as d0_sec_zero_opap_occ,
(case when (LENGTH(trim( d0_websdl_cob_ind_after )) ==0) then d0_websdl_cob_ind_after else trim(d0_websdl_cob_ind_after)end) as d0_sec_zero_opap_occ,
(case when (LENGTH(trim( elig_plan_description_after )) ==0) then elig_plan_description_after else trim(elig_plan_description_after)end) as elig_plan_description,
(case when (LENGTH(trim( elig_plan_recip_id_lbl_after )) ==0) then elig_plan_recip_id_lbl_after else trim(elig_plan_recip_id_lbl_after)end) as elig_plan_recip_id_lbl,
(case when (LENGTH(trim( pct_of_util_pln_adj_after )) ==0) then pct_of_util_pln_adj_after else trim(pct_of_util_pln_adj_after)end) as pct_of_util_pln_adj,
(case when (LENGTH(trim( sec_bill_lower_cpf_copay_after )) ==0) then sec_bill_lower_cpf_copay_after else trim(sec_bill_lower_cpf_copay_after)end) as sec_bill_lower_cpf_copay,
(case when (LENGTH(trim( sec_opap_adm_qlfr_after )) ==0) then sec_opap_adm_qlfr_after else trim(sec_opap_adm_qlfr_after)end) as sec_opap_adm_qlfr,
(case when (LENGTH(trim( sec_opap_cogn_qlfr_after )) ==0) then sec_opap_cogn_qlfr_after else trim(sec_opap_cogn_qlfr_after)end) as sec_opap_cogn_qlfr,
(case when (LENGTH(trim( sec_opap_dlvry_qlfr_after )) ==0) then sec_opap_dlvry_qlfr_after else trim(sec_opap_dlvry_qlfr_after)end) as sec_opap_dlvry_qlfr,
(case when (LENGTH(trim( sec_opap_drug_bnft_qlfr_after )) ==0) then sec_opap_drug_bnft_qlfr_after else trim(sec_opap_drug_bnft_qlfr_after)end) as sec_opap_drug_bnft_qlfr,
(case when (LENGTH(trim( sec_opap_incntv_qlfr_after )) ==0) then sec_opap_incntv_qlfr_after else trim(sec_opap_incntv_qlfr_after)end) as sec_opap_incntv_qlfr,
(case when (LENGTH(trim( sec_opap_post_qlfr_after )) ==0) then sec_opap_post_qlfr_after else trim(sec_opap_post_qlfr_after)end) as sec_opap_incntv_qlfr,
(case when (LENGTH(trim( sec_opap_ship_qlfr_after )) ==0) then sec_opap_ship_qlfr_after else trim(sec_opap_ship_qlfr_after)end) as sec_opap_ship_qlfr,
(case when (LENGTH(trim( sec_pat_lump_sum_after )) ==0) then sec_pat_lump_sum_after else trim(sec_pat_lump_sum_after)end) as sec_pat_lump_sum,
(case when (LENGTH(trim( sec_pat_pay_brkdwn_after )) ==0) then sec_pat_pay_brkdwn_after else trim(sec_pat_pay_brkdwn_after)end) as sec_pat_pay_brkdwn,
(case when (LENGTH(trim( sec_prim_gt_zero_occ_after )) ==0) then sec_prim_gt_zero_occ_after else trim(sec_prim_gt_zero_occ_after)end) as sec_prim_gt_zero_occ,
(case when (LENGTH(trim( sec_prim_lt_zero_occ_after )) ==0) then sec_prim_lt_zero_occ_after else trim(sec_prim_lt_zero_occ_after)end) as sec_prim_lt_zero_occ,
(case when (LENGTH(trim( sec_prim_rej_occ_after )) ==0) then sec_prim_rej_occ_after else trim(sec_prim_rej_occ_after)end) as sec_prim_rej_occ
from  gg_tbf0_third_party_plan where cdc_operation_type_cd ='INSERT'"""

# COMMAND ----------

df1 = spark.sql(sql1)

#display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

#display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)


# COMMAND ----------


# drop columns
#dfGood = dfGood.drop("tracking_id")

# convert date and number columns
dfGood = dfFinal.withColumn("cdc_txn_commit_dttm", to_timestamp(dfFinal["cdc_txn_commit_dttm"])).withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr"))).withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr"))).withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id"))).withColumn("plan_effective_dttm", to_timestamp(dfFinal["plan_effective_dttm"])).withColumn("plan_usual_cust_adj_amt",when(col("plan_usual_cust_adj_amt") == "",None).otherwise(col("plan_usual_cust_adj_amt"))).withColumn("overrid_billing_adj_amt",when(col("overrid_billing_adj_amt") == "",None).otherwise(col("overrid_billing_adj_amt"))).withColumn("primary_billing_adj_amt",when(col("primary_billing_adj_amt") == "",None).otherwise(col("primary_billing_adj_amt"))).withColumn("generic_disp_fee",when(col("generic_disp_fee") == "",None).otherwise(col("generic_disp_fee"))).withColumn("generic_copay",when(col("generic_copay") == "",None).otherwise(col("generic_copay"))).withColumn("brand_disp_fee",when(col("brand_disp_fee") == "",None).otherwise(col("brand_disp_fee"))).withColumn("brand_copay",when(col("brand_copay") == "",None).otherwise(col("brand_copay"))).withColumn("otc_disp_fee",when(col("otc_disp_fee") == "",None).otherwise(col("otc_disp_fee"))).withColumn("otc_copay",when(col("otc_copay") == "",None).otherwise(col("otc_copay"))).withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id"))).withColumn("create_dttm", to_timestamp(dfFinal["create_dttm"])).withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id"))).withColumn("update_dttm", to_timestamp(dfFinal["update_dttm"])).withColumn("child_plan_qty",when(col("child_plan_qty") == "",None).otherwise(col("child_plan_qty"))).withColumn("mail_plan_uc_default_amt",when(col("mail_plan_uc_default_amt") == "",None).otherwise(col("mail_plan_uc_default_amt"))).withColumn("sec_hybrid_threshold_amt",when(col("sec_hybrid_threshold_amt") == "",None).otherwise(col("sec_hybrid_threshold_amt"))).withColumn("document_id",when(col("document_id") == "",None).otherwise(col("document_id"))).withColumn("non_rx_otc_pbr_id",when(col("non_rx_otc_pbr_id") == "",None).otherwise(col("non_rx_otc_pbr_id"))).withColumn("non_rx_otc_days_supply",when(col("non_rx_otc_days_supply") == "",None).otherwise(col("non_rx_otc_days_supply"))).withColumn("d0_sec_zero_opap_occ",when(col("d0_sec_zero_opap_occ") == "",None).otherwise(col("d0_sec_zero_opap_occ"))).withColumn("pct_of_util_pln_adj",when(col("pct_of_util_pln_adj") == "",None).otherwise(col("pct_of_util_pln_adj"))).withColumn("sec_prim_gt_zero_occ",when(col("sec_prim_gt_zero_occ") == "",None).otherwise(col("sec_prim_gt_zero_occ"))).withColumn("sec_prim_lt_zero_occ",when(col("sec_prim_lt_zero_occ") == "",None).otherwise(col("sec_prim_lt_zero_occ"))).withColumn("sec_prim_rej_occ",when(col("sec_prim_rej_occ") == "",None).otherwise(col("sec_prim_rej_occ")))
			
#Update Varchar columns to null
from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",sel_snfl_tbl)\
   .load()

#display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
#print(str_cols)


for col in str_cols:
  dfGood = dfGood.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))
  
  
  
#display(dfGood)
print(f"Final good after union {dfGood.count()}")


# COMMAND ----------


dfBad = spark.sql("select * from gg_tbf0_third_party_plan where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

#display(dfBad)

print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

#WRITING DATA IN OUTPUT AND RJECT FOLDER

dfG = dfGood.write.mode('overwrite').parquet(OUT_FILEPATH)

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

 
#display(dfGood)

# COMMAND ----------

# Delete records from snfk table

del_snfl_tbl = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


# COMMAND ----------

# Writing to the Snowflakes Table

dfGood.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("dbtable", SNFL_TBL_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

# COMMAND ----------


# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_READAPI_URL","https://dapprodappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220105120923")
# dbutils.widgets.text("PAR_FEED_NAME","gg_code_dtl")
# dbutils.widgets.text("PAR_SQL_SERVER","dapprodsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_PIPELINE_NAME","Code_xform_CodeDetail")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","proddnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapprodsqldb01")
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS")
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","gg_tbf0_code_dtl")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/pharmacy_codes/output")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","etl_tbf0_code_dtl")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/pharmacy_codes/reject")
# dbutils.widgets.text("PAR_DB_SNFK_WH","PROD_HISTORY_MIGRATION_SECONDARY_FR_WH")
# dbutils.widgets.text("PAR_DB_SNFK_DB","PROD_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PHARMACY_CODES.ETL_TBF0_CODE_DTL_STG")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","PROD_ETL")
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapprodappservice-appserver.azurewebsites.net/assetUpdate")

# COMMAND ----------

READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 10000, 
                 {"PAR_EDW_BATCH_ID":BATCH_ID,
                  "PAR_FEED_NAMES":FEED_NAME,
                  "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                  "PAR_READAPI_URL":READAPI_URL,
                  "PAR_SQL_SERVER":PAR_SQL_SERVER,
                  "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                  "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                  "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                  "PAR_RETURN_FILE_TYPE":"O"});

print(Input_File_List)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

rddjson = sc.parallelize([Input_File_List])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,col(FEED_NAME)) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")

dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]
print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'category_cd',
'category_cd_after',
'code',
'code_after',
'primary_decode',
'primary_decode_after',
'secondary_decode',
'secondary_decode_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after'        
 ]

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 29:#Total Number of columns -1
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 30: #Total Number of columns 
      return True
  else:
    if val_len != 30: #Total Number of columns 
      return True

# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len =30

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 30
print(f"Bad records count {rd_bad.count()}") # != 30

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_code_dtl")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_code_dtl where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_code_dtl"))

df_gg.createOrReplaceTempView("raw_src_gg_table")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')" 

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"    

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND category_cd ==  category_cd_after AND category_cd is NOT NULL AND category_cd_after is NOT NULL AND  code ==  code_after AND code is NOT NULL AND  code_after is NOT NULL AND  cdc_seq_nbr ==  cdc_seq_nbr_after AND cdc_seq_nbr is NOT NULL AND cdc_seq_nbr_after is NOT NULL AND  cdc_rba_nbr ==  cdc_rba_nbr_after AND cdc_rba_nbr is NOT NULL AND cdc_rba_nbr_after is NOT NULL AND  cdc_txn_commit_dttm ==  cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm is NOT NULL AND cdc_txn_commit_dttm_after is NOT NULL AND  ((primary_decode  == primary_decode_after AND primary_decode is NOT NULL AND primary_decode_after is NOT NULL) OR ( primary_decode  IS NULL  AND   primary_decode_after  IS NULL ) )   AND  ((secondary_decode  == secondary_decode_after AND secondary_decode is NOT NULL AND secondary_decode_after is NOT NULL) OR ( secondary_decode  IS NULL  AND   secondary_decode_after IS NULL ) ))"

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, category_cd, code, primary_decode, secondary_decode, create_user_id, CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id, CONCAT(update_dttm,'.000000') AS update_dttm "
#, tracking_id, partition_column"

# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

BATCH_ID_CHK = """'""" + BATCH_ID + """'"""
PROJ_ID_CHK = """'""" + PROJ_ID + """'"""

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_output.PROJ_NAME == PROJ_ID_CHK))

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))

rx_trans_max = cutoff_range_trans.select("rx_trans_max")

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_src_gg_table where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_src_gg_table where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_src_gg_table where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)

nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) 
  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual)
  nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) 

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck)
  nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0])

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual)
  nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()
dedup_group.createOrReplaceTempView("dedup_group")
ded = spark.sql("select * from dedup_group")

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim( category_cd )) ==0) then category_cd else trim(category_cd)end) as category_cd,
(case when (LENGTH(trim( category_cd_after )) ==0) then category_cd_after else trim(category_cd_after)end) as category_cd_after,
(case when (LENGTH(trim( code )) ==0) then code else trim(code)end) as code,
(case when (LENGTH(trim( code_after )) ==0) then code_after else trim(code_after)end) as code_after,
(case when (LENGTH(trim( primary_decode )) ==0) then primary_decode else trim(primary_decode)end) as primary_decode,
(case when (LENGTH(trim( primary_decode_after )) ==0) then primary_decode_after else trim(primary_decode_after)end) as primary_decode_after,
(case when (LENGTH(trim( secondary_decode )) ==0) then secondary_decode else trim(secondary_decode)end) as secondary_decode,
(case when (LENGTH(trim( secondary_decode_after )) ==0) then secondary_decode_after else trim(secondary_decode_after)end) as secondary_decode_after,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id_after,
(case when (LENGTH(trim(create_dttm )) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8)) end) as create_dttm,
(case when (LENGTH(trim(create_dttm_after )) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8)) end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id_after,
(case when (LENGTH(trim(update_dttm )) ==0) then  update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8)) end)    as update_dttm,
(case when (LENGTH(trim(update_dttm_after )) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8)) end) as update_dttm_after
from dedup_group"""

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")

# COMMAND ----------

#Removed tracking id and partition column
pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,category_cd_after AS category_cd , code_after AS code , primary_decode_after AS primary_decode , secondary_decode_after AS secondary_decode , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , 
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,category_cd AS category_cd , code AS code , primary_decode AS primary_decode , secondary_decode AS secondary_decode , create_user_id AS create_user_id , create_dttm AS create_dttm , update_user_id AS update_user_id , update_dttm AS update_dttm , 
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd, 
""" + BATCH_ID + """ as edw_batch_id,category_cd_after AS category_cd , code_after AS code , primary_decode_after AS primary_decode , secondary_decode_after AS secondary_decode , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm ,'""" + SRC_TBL_NAME +  """' as table_name
from nr_insert_check """

print(pTgtUpdAftXfr)

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 

# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm", to_timestamp(etl_tbf0_reformat_cdc_check_notnull["cdc_txn_commit_dttm"]))\
           .withColumn("create_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["update_dttm"]))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_cdc_check_notnull.columns])

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_ASSET_STATUS='200'

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/UpdateProcessedFilesStatus", 200, 
                  {"PAR_ASSET_STATUS":PAR_ASSET_STATUS,
                   "PAR_FEED_NAMES":FEED_NAME,
                   "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                   "PAR_SQL_SERVER":PAR_SQL_SERVER,
                   "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                   "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                   "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                   "PAR_WRITEAPI_URL":PAR_WRITEAPI_URL})
                   
print("Write API successfully executed...")

# Databricks notebook source
# Our imported libraries
from functools import reduce
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import input_file_name


# COMMAND ----------
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220728163100")
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","etl_tbf0_rx_transaction")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_TRANSACTION_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","gg_tbf0_rx_transaction")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_RX_TRANSACTION,GG_TBF0_RX_TRANSACTION_control")
# dbutils.widgets.text("PAR_PIPELINE_NAME","PL_MSTR_PHARMACY_AND_HEALTHCARE_PATIENT_SERVICES_ETL_TBF0_RX_TRANSACTION_LOAD")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
# dbutils.widgets.text("PAR_UnprocessedFiles","1")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")

# COMMAND ----------
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME") #rx_De_Dup_PrescriptionFill_RxTrans
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")


# COMMAND ----------
# initializing variables
#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'
# COMMAND ----------
# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH
# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="(( cdc_seq_nbr  ==   cdc_seq_nbr_after  AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL) AND  (cdc_rba_nbr   ==   cdc_rba_nbr_after  AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL) AND  (cdc_txn_commit_dttm   ==   cdc_txn_commit_dttm_after  AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL) AND  (cdc_before_after_cd_after  ==  'AFTER' AND  cdc_before_after_cd_after IS NOT NULL)  AND  ( cdc_operation_type_cd_after   ==  'SQL COMPUPDATE'  AND  cdc_operation_type_cd_after IS NOT NULL) AND  (cdc_before_after_cd  ==  'BEFORE' AND  cdc_before_after_cd IS NOT NULL)  AND  (cdc_operation_type_cd   ==  'SQL COMPUPDATE' AND  cdc_operation_type_cd IS NOT NULL ) AND  (store_nbr  ==  store_nbr_after AND  store_nbr IS NOT NULL AND  store_nbr_after IS NOT NULL) AND   (rx_nbr  ==  rx_nbr_after AND  rx_nbr IS NOT NULL AND  rx_nbr_after IS NOT NULL ) AND  (fill_nbr  ==  fill_nbr_after AND  fill_nbr IS NOT NULL AND  fill_nbr_after IS NOT NULL  ) AND  (( RTRIM(LOWER(fill_partial_nbr)) == RTRIM(LOWER(fill_partial_nbr_after ))  AND fill_partial_nbr IS NOT NULL AND fill_partial_nbr_after IS NOT NULL ) OR ( fill_partial_nbr IS NULL AND fill_partial_nbr_after IS NULL )) AND  (( RTRIM(LOWER(dl_addl_msg_qlfr)) == RTRIM(LOWER(dl_addl_msg_qlfr_after ))  AND dl_addl_msg_qlfr IS NOT NULL AND dl_addl_msg_qlfr_after IS NOT NULL ) OR ( dl_addl_msg_qlfr IS NULL AND dl_addl_msg_qlfr_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_id_qlfr)) == RTRIM(LOWER(pat_pickup_id_qlfr_after ))  AND pat_pickup_id_qlfr IS NOT NULL AND pat_pickup_id_qlfr_after IS NOT NULL ) OR ( pat_pickup_id_qlfr IS NULL AND pat_pickup_id_qlfr_after IS NULL )) AND  (( RTRIM(LOWER(routing_store_rph_inits)) == RTRIM(LOWER(routing_store_rph_inits_after ))  AND routing_store_rph_inits IS NOT NULL AND routing_store_rph_inits_after IS NOT NULL ) OR ( routing_store_rph_inits IS NULL AND routing_store_rph_inits_after IS NULL )) AND  (( RTRIM(LOWER(rx_denial_override_cd)) == RTRIM(LOWER(rx_denial_override_cd_after ))  AND rx_denial_override_cd IS NOT NULL AND rx_denial_override_cd_after IS NOT NULL ) OR ( rx_denial_override_cd IS NULL AND rx_denial_override_cd_after IS NULL )) AND (( RTRIM(LOWER(rx_denial_override_cd_2)) == RTRIM(LOWER(rx_denial_override_cd_2_after ))  AND rx_denial_override_cd_2 IS NOT NULL AND rx_denial_override_cd_2_after IS NOT NULL ) OR ( rx_denial_override_cd_2 IS NULL AND rx_denial_override_cd_2_after IS NULL )) AND (( RTRIM(LOWER(rx_denial_override_cd_3)) == RTRIM(LOWER(rx_denial_override_cd_3_after ))  AND rx_denial_override_cd_3 IS NOT NULL AND rx_denial_override_cd_3_after IS NOT NULL ) OR ( rx_denial_override_cd_3 IS NULL AND rx_denial_override_cd_3_after IS NULL )) AND (( RTRIM(LOWER(sold_local_dttm)) == RTRIM(LOWER(sold_local_dttm_after ))  AND sold_local_dttm IS NOT NULL AND sold_local_dttm_after IS NOT NULL ) OR ( sold_local_dttm IS NULL AND sold_local_dttm_after IS NULL )) AND  (( RTRIM(LOWER(sys_status_when_ent)) == RTRIM(LOWER(sys_status_when_ent_after ))  AND sys_status_when_ent IS NOT NULL AND sys_status_when_ent_after IS NOT NULL ) OR ( sys_status_when_ent IS NULL AND sys_status_when_ent_after IS NULL )) AND  (( RTRIM(LOWER(refills_remaining)) == RTRIM(LOWER(refills_remaining_after ))  AND refills_remaining IS NOT NULL AND refills_remaining_after IS NOT NULL ) OR ( refills_remaining IS NULL AND refills_remaining_after IS NULL )) AND  (( RTRIM(LOWER(fill_wac_cost_amt)) == RTRIM(LOWER(fill_wac_cost_amt_after ))  AND fill_wac_cost_amt IS NOT NULL AND fill_wac_cost_amt_after IS NOT NULL ) OR ( fill_wac_cost_amt IS NULL AND fill_wac_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_cost_amt)) == RTRIM(LOWER(plan_returnd_cost_amt_after ))  AND plan_returnd_cost_amt IS NOT NULL AND plan_returnd_cost_amt_after IS NOT NULL ) OR ( plan_returnd_cost_amt IS NULL AND plan_returnd_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_fee_amt)) == RTRIM(LOWER(plan_returnd_fee_amt_after ))  AND plan_returnd_fee_amt IS NOT NULL AND plan_returnd_fee_amt_after IS NOT NULL ) OR ( plan_returnd_fee_amt IS NULL AND plan_returnd_fee_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_submtd_copay_amt)) == RTRIM(LOWER(plan_submtd_copay_amt_after ))  AND plan_submtd_copay_amt IS NOT NULL AND plan_submtd_copay_amt_after IS NOT NULL ) OR ( plan_submtd_copay_amt IS NULL AND plan_submtd_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(pbr_id)) == RTRIM(LOWER(pbr_id_after ))  AND pbr_id IS NOT NULL AND pbr_id_after IS NOT NULL ) OR ( pbr_id IS NULL AND pbr_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_source_cd)) == RTRIM(LOWER(fill_source_cd_after ))  AND fill_source_cd IS NOT NULL AND fill_source_cd_after IS NOT NULL ) OR ( fill_source_cd IS NULL AND fill_source_cd_after IS NULL )) AND  (( RTRIM(LOWER(refills_remain_when_ent)) == RTRIM(LOWER(refills_remain_when_ent_after ))  AND refills_remain_when_ent IS NOT NULL AND refills_remain_when_ent_after IS NOT NULL ) OR ( refills_remain_when_ent IS NULL AND refills_remain_when_ent_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_rtrnd_fee_amt)) == RTRIM(LOWER(cob_plan_rtrnd_fee_amt_after ))  AND cob_plan_rtrnd_fee_amt IS NOT NULL AND cob_plan_rtrnd_fee_amt_after IS NOT NULL ) OR ( cob_plan_rtrnd_fee_amt IS NULL AND cob_plan_rtrnd_fee_amt_after IS NULL )) AND  (( RTRIM(LOWER(tot_amt_paid_ind)) == RTRIM(LOWER(tot_amt_paid_ind_after ))  AND tot_amt_paid_ind IS NOT NULL AND tot_amt_paid_ind_after IS NOT NULL ) OR ( tot_amt_paid_ind IS NULL AND tot_amt_paid_ind_after IS NULL )) AND  (( RTRIM(LOWER(drug_class)) == RTRIM(LOWER(drug_class_after ))  AND drug_class IS NOT NULL AND drug_class_after IS NOT NULL ) OR ( drug_class IS NULL AND drug_class_after IS NULL )) AND  (( RTRIM(LOWER(drug_name)) == RTRIM(LOWER(drug_name_after ))  AND drug_name IS NOT NULL AND drug_name_after IS NOT NULL ) OR ( drug_name IS NULL AND drug_name_after IS NULL )) AND  (( RTRIM(LOWER(drug_id)) == RTRIM(LOWER(drug_id_after ))  AND drug_id IS NOT NULL AND drug_id_after IS NOT NULL ) OR ( drug_id IS NULL AND drug_id_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_copay_amt)) == RTRIM(LOWER(plan_returnd_copay_amt_after ))  AND plan_returnd_copay_amt IS NOT NULL AND plan_returnd_copay_amt_after IS NOT NULL ) OR ( plan_returnd_copay_amt IS NULL AND plan_returnd_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_total_paid_amt)) == RTRIM(LOWER(plan_total_paid_amt_after ))  AND plan_total_paid_amt IS NOT NULL AND plan_total_paid_amt_after IS NOT NULL ) OR ( plan_total_paid_amt IS NULL AND plan_total_paid_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_tax_amt)) == RTRIM(LOWER(plan_returnd_tax_amt_after ))  AND plan_returnd_tax_amt IS NOT NULL AND plan_returnd_tax_amt_after IS NOT NULL ) OR ( plan_returnd_tax_amt IS NULL AND plan_returnd_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_submtd_cost_amt)) == RTRIM(LOWER(plan_submtd_cost_amt_after ))  AND plan_submtd_cost_amt IS NOT NULL AND plan_submtd_cost_amt_after IS NOT NULL ) OR ( plan_submtd_cost_amt IS NULL AND plan_submtd_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_submtd_fee_amt)) == RTRIM(LOWER(plan_submtd_fee_amt_after ))  AND plan_submtd_fee_amt IS NOT NULL AND plan_submtd_fee_amt_after IS NOT NULL ) OR ( plan_submtd_fee_amt IS NULL AND plan_submtd_fee_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_submtd_tax_amt)) == RTRIM(LOWER(plan_submtd_tax_amt_after ))  AND plan_submtd_tax_amt IS NOT NULL AND plan_submtd_tax_amt_after IS NOT NULL ) OR ( plan_submtd_tax_amt IS NULL AND plan_submtd_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(pat_id)) == RTRIM(LOWER(pat_id_after ))  AND pat_id IS NOT NULL AND pat_id_after IS NOT NULL ) OR ( pat_id IS NULL AND pat_id_after IS NULL )) AND  (( RTRIM(LOWER(sims_upc)) == RTRIM(LOWER(sims_upc_after ))  AND sims_upc IS NOT NULL AND sims_upc_after IS NOT NULL ) OR ( sims_upc IS NULL AND sims_upc_after IS NULL )) AND  (( RTRIM(LOWER(pbr_loc_id)) == RTRIM(LOWER(pbr_loc_id_after ))  AND pbr_loc_id IS NOT NULL AND pbr_loc_id_after IS NOT NULL ) OR ( pbr_loc_id IS NULL AND pbr_loc_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_rtrnd_copay_amt)) == RTRIM(LOWER(cob_plan_rtrnd_copay_amt_after ))  AND cob_plan_rtrnd_copay_amt IS NOT NULL AND cob_plan_rtrnd_copay_amt_after IS NOT NULL ) OR ( cob_plan_rtrnd_copay_amt IS NULL AND cob_plan_rtrnd_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_total_paid_amt)) == RTRIM(LOWER(cob_plan_total_paid_amt_after ))  AND cob_plan_total_paid_amt IS NOT NULL AND cob_plan_total_paid_amt_after IS NOT NULL ) OR ( cob_plan_total_paid_amt IS NULL AND cob_plan_total_paid_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_rtrnd_cost_amt)) == RTRIM(LOWER(cob_plan_rtrnd_cost_amt_after ))  AND cob_plan_rtrnd_cost_amt IS NOT NULL AND cob_plan_rtrnd_cost_amt_after IS NOT NULL ) OR ( cob_plan_rtrnd_cost_amt IS NULL AND cob_plan_rtrnd_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_rtrnd_tax_amt)) == RTRIM(LOWER(cob_plan_rtrnd_tax_amt_after ))  AND cob_plan_rtrnd_tax_amt IS NOT NULL AND cob_plan_rtrnd_tax_amt_after IS NOT NULL ) OR ( cob_plan_rtrnd_tax_amt IS NULL AND cob_plan_rtrnd_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_sbmtd_copay_amt)) == RTRIM(LOWER(cob_plan_sbmtd_copay_amt_after ))  AND cob_plan_sbmtd_copay_amt IS NOT NULL AND cob_plan_sbmtd_copay_amt_after IS NOT NULL ) OR ( cob_plan_sbmtd_copay_amt IS NULL AND cob_plan_sbmtd_copay_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_sbmtd_cost_amt)) == RTRIM(LOWER(cob_plan_sbmtd_cost_amt_after ))  AND cob_plan_sbmtd_cost_amt IS NOT NULL AND cob_plan_sbmtd_cost_amt_after IS NOT NULL ) OR ( cob_plan_sbmtd_cost_amt IS NULL AND cob_plan_sbmtd_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_sbmtd_fee_amt)) == RTRIM(LOWER(cob_plan_sbmtd_fee_amt_after ))  AND cob_plan_sbmtd_fee_amt IS NOT NULL AND cob_plan_sbmtd_fee_amt_after IS NOT NULL ) OR ( cob_plan_sbmtd_fee_amt IS NULL AND cob_plan_sbmtd_fee_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_sbmtd_tax_amt)) == RTRIM(LOWER(cob_plan_sbmtd_tax_amt_after ))  AND cob_plan_sbmtd_tax_amt IS NOT NULL AND cob_plan_sbmtd_tax_amt_after IS NOT NULL ) OR ( cob_plan_sbmtd_tax_amt IS NULL AND cob_plan_sbmtd_tax_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_adjudication_cd)) == RTRIM(LOWER(fill_adjudication_cd_after ))  AND fill_adjudication_cd IS NOT NULL AND fill_adjudication_cd_after IS NOT NULL ) OR ( fill_adjudication_cd IS NULL AND fill_adjudication_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_awp_cost_amt)) == RTRIM(LOWER(fill_awp_cost_amt_after ))  AND fill_awp_cost_amt IS NOT NULL AND fill_awp_cost_amt_after IS NOT NULL ) OR ( fill_awp_cost_amt IS NULL AND fill_awp_cost_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_days_supply)) == RTRIM(LOWER(fill_days_supply_after ))  AND fill_days_supply IS NOT NULL AND fill_days_supply_after IS NOT NULL ) OR ( fill_days_supply IS NULL AND fill_days_supply_after IS NULL )) AND  (( RTRIM(LOWER(fill_entered_dttm)) == RTRIM(LOWER(fill_entered_dttm_after ))  AND fill_entered_dttm IS NOT NULL AND fill_entered_dttm_after IS NOT NULL ) OR ( fill_entered_dttm IS NULL AND fill_entered_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_label_price_amt)) == RTRIM(LOWER(fill_label_price_amt_after ))  AND fill_label_price_amt IS NOT NULL AND fill_label_price_amt_after IS NOT NULL ) OR ( fill_label_price_amt IS NULL AND fill_label_price_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_qty_dispensed)) == RTRIM(LOWER(fill_qty_dispensed_after ))  AND fill_qty_dispensed IS NOT NULL AND fill_qty_dispensed_after IS NOT NULL ) OR ( fill_qty_dispensed IS NULL AND fill_qty_dispensed_after IS NULL )) AND  (( RTRIM(LOWER(fill_retail_price_amt)) == RTRIM(LOWER(fill_retail_price_amt_after ))  AND fill_retail_price_amt IS NOT NULL AND fill_retail_price_amt_after IS NOT NULL ) OR ( fill_retail_price_amt IS NULL AND fill_retail_price_amt_after IS NULL )) AND  (( RTRIM(LOWER(claim_reference_nbr)) == RTRIM(LOWER(claim_reference_nbr_after ))  AND claim_reference_nbr IS NOT NULL AND claim_reference_nbr_after IS NOT NULL ) OR ( claim_reference_nbr IS NULL AND claim_reference_nbr_after IS NULL )) AND  (( RTRIM(LOWER(fill_nbr_dispensed)) == RTRIM(LOWER(fill_nbr_dispensed_after ))  AND fill_nbr_dispensed IS NOT NULL AND fill_nbr_dispensed_after IS NOT NULL ) OR ( fill_nbr_dispensed IS NULL AND fill_nbr_dispensed_after IS NULL )) AND  (( RTRIM(LOWER(plan_id)) == RTRIM(LOWER(plan_id_after ))  AND plan_id IS NOT NULL AND plan_id_after IS NOT NULL ) OR ( plan_id IS NULL AND plan_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_status_cd)) == RTRIM(LOWER(fill_status_cd_after ))  AND fill_status_cd IS NOT NULL AND fill_status_cd_after IS NOT NULL ) OR ( fill_status_cd IS NULL AND fill_status_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_entered_user_id)) == RTRIM(LOWER(fill_entered_user_id_after ))  AND fill_entered_user_id IS NOT NULL AND fill_entered_user_id_after IS NOT NULL ) OR ( fill_entered_user_id IS NULL AND fill_entered_user_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_verified_user_id)) == RTRIM(LOWER(fill_verified_user_id_after ))  AND fill_verified_user_id IS NOT NULL AND fill_verified_user_id_after IS NOT NULL ) OR ( fill_verified_user_id IS NULL AND fill_verified_user_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_verified_dttm)) == RTRIM(LOWER(fill_verified_dttm_after ))  AND fill_verified_dttm IS NOT NULL AND fill_verified_dttm_after IS NOT NULL ) OR ( fill_verified_dttm IS NULL AND fill_verified_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_sold_dttm)) == RTRIM(LOWER(fill_sold_dttm_after ))  AND fill_sold_dttm IS NOT NULL AND fill_sold_dttm_after IS NOT NULL ) OR ( fill_sold_dttm IS NULL AND fill_sold_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_deleted_dttm)) == RTRIM(LOWER(fill_deleted_dttm_after ))  AND fill_deleted_dttm IS NOT NULL AND fill_deleted_dttm_after IS NOT NULL ) OR ( fill_deleted_dttm IS NULL AND fill_deleted_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_discount_cd)) == RTRIM(LOWER(fill_discount_cd_after ))  AND fill_discount_cd IS NOT NULL AND fill_discount_cd_after IS NOT NULL ) OR ( fill_discount_cd IS NULL AND fill_discount_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_pay_method_cd)) == RTRIM(LOWER(fill_pay_method_cd_after ))  AND fill_pay_method_cd IS NOT NULL AND fill_pay_method_cd_after IS NOT NULL ) OR ( fill_pay_method_cd IS NULL AND fill_pay_method_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_discount_amt)) == RTRIM(LOWER(fill_discount_amt_after ))  AND fill_discount_amt IS NOT NULL AND fill_discount_amt_after IS NOT NULL ) OR ( fill_discount_amt IS NULL AND fill_discount_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_sold_amt)) == RTRIM(LOWER(fill_sold_amt_after ))  AND fill_sold_amt IS NOT NULL AND fill_sold_amt_after IS NOT NULL ) OR ( fill_sold_amt IS NULL AND fill_sold_amt_after IS NULL )) AND  (( RTRIM(LOWER(fill_type_cd)) == RTRIM(LOWER(fill_type_cd_after ))  AND fill_type_cd IS NOT NULL AND fill_type_cd_after IS NOT NULL ) OR ( fill_type_cd IS NULL AND fill_type_cd_after IS NULL )) AND  (( RTRIM(LOWER(partial_fill_cd)) == RTRIM(LOWER(partial_fill_cd_after ))  AND partial_fill_cd IS NOT NULL AND partial_fill_cd_after IS NOT NULL ) OR ( partial_fill_cd IS NULL AND partial_fill_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_adjudication_dttm)) == RTRIM(LOWER(fill_adjudication_dttm_after ))  AND fill_adjudication_dttm IS NOT NULL AND fill_adjudication_dttm_after IS NOT NULL ) OR ( fill_adjudication_dttm IS NULL AND fill_adjudication_dttm_after IS NULL )) AND  (( RTRIM(LOWER(cob_fill_adjudication_cd)) == RTRIM(LOWER(cob_fill_adjudication_cd_after ))  AND cob_fill_adjudication_cd IS NOT NULL AND cob_fill_adjudication_cd_after IS NOT NULL ) OR ( cob_fill_adjudication_cd IS NULL AND cob_fill_adjudication_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_claim_ref_nbr)) == RTRIM(LOWER(cob_claim_ref_nbr_after ))  AND cob_claim_ref_nbr IS NOT NULL AND cob_claim_ref_nbr_after IS NOT NULL ) OR ( cob_claim_ref_nbr IS NULL AND cob_claim_ref_nbr_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_id)) == RTRIM(LOWER(cob_plan_id_after ))  AND cob_plan_id IS NOT NULL AND cob_plan_id_after IS NOT NULL ) OR ( cob_plan_id IS NULL AND cob_plan_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_fill_adj_dttm)) == RTRIM(LOWER(cob_fill_adj_dttm_after ))  AND cob_fill_adj_dttm IS NOT NULL AND cob_fill_adj_dttm_after IS NOT NULL ) OR ( cob_fill_adj_dttm IS NULL AND cob_fill_adj_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_data_rev_id)) == RTRIM(LOWER(fill_data_rev_id_after ))  AND fill_data_rev_id IS NOT NULL AND fill_data_rev_id_after IS NOT NULL ) OR ( fill_data_rev_id IS NULL AND fill_data_rev_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_data_rev_dttm)) == RTRIM(LOWER(fill_data_rev_dttm_after ))  AND fill_data_rev_dttm IS NOT NULL AND fill_data_rev_dttm_after IS NOT NULL ) OR ( fill_data_rev_dttm IS NULL AND fill_data_rev_dttm_after IS NULL )) AND  (( RTRIM(LOWER(filling_user_id)) == RTRIM(LOWER(filling_user_id_after ))  AND filling_user_id IS NOT NULL AND filling_user_id_after IS NOT NULL ) OR ( filling_user_id IS NULL AND filling_user_id_after IS NULL )) AND  (( RTRIM(LOWER(filling_dttm)) == RTRIM(LOWER(filling_dttm_after ))  AND filling_dttm IS NOT NULL AND filling_dttm_after IS NOT NULL ) OR ( filling_dttm IS NULL AND filling_dttm_after IS NULL )) AND  (( RTRIM(LOWER(override_user_id)) == RTRIM(LOWER(override_user_id_after ))  AND override_user_id IS NOT NULL AND override_user_id_after IS NOT NULL ) OR ( override_user_id IS NULL AND override_user_id_after IS NULL )) AND  (( RTRIM(LOWER(override_dttm)) == RTRIM(LOWER(override_dttm_after ))  AND override_dttm IS NOT NULL AND override_dttm_after IS NOT NULL ) OR ( override_dttm IS NULL AND override_dttm_after IS NULL )) AND  (( RTRIM(LOWER(entered_store_nbr)) == RTRIM(LOWER(entered_store_nbr_after ))  AND entered_store_nbr IS NOT NULL AND entered_store_nbr_after IS NOT NULL ) OR ( entered_store_nbr IS NULL AND entered_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(reviewed_store_nbr)) == RTRIM(LOWER(reviewed_store_nbr_after ))  AND reviewed_store_nbr IS NOT NULL AND reviewed_store_nbr_after IS NOT NULL ) OR ( reviewed_store_nbr IS NULL AND reviewed_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(plan_gross_due_amt)) == RTRIM(LOWER(plan_gross_due_amt_after ))  AND plan_gross_due_amt IS NOT NULL AND plan_gross_due_amt_after IS NOT NULL ) OR ( plan_gross_due_amt IS NULL AND plan_gross_due_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_gross_due_amt)) == RTRIM(LOWER(cob_plan_gross_due_amt_after ))  AND cob_plan_gross_due_amt IS NOT NULL AND cob_plan_gross_due_amt_after IS NOT NULL ) OR ( cob_plan_gross_due_amt IS NULL AND cob_plan_gross_due_amt_after IS NULL )) AND  (( RTRIM(LOWER(rx_daw_ind)) == RTRIM(LOWER(rx_daw_ind_after ))  AND rx_daw_ind IS NOT NULL AND rx_daw_ind_after IS NOT NULL ) OR ( rx_daw_ind IS NULL AND rx_daw_ind_after IS NULL )) AND  (( RTRIM(LOWER(dl_reject_cd_01)) == RTRIM(LOWER(dl_reject_cd_01_after ))  AND dl_reject_cd_01 IS NOT NULL AND dl_reject_cd_01_after IS NOT NULL ) OR ( dl_reject_cd_01 IS NULL AND dl_reject_cd_01_after IS NULL )) AND  (( RTRIM(LOWER(dl_reject_cd_02)) == RTRIM(LOWER(dl_reject_cd_02_after ))  AND dl_reject_cd_02 IS NOT NULL AND dl_reject_cd_02_after IS NOT NULL ) OR ( dl_reject_cd_02 IS NULL AND dl_reject_cd_02_after IS NULL )) AND  (( RTRIM(LOWER(dl_reject_cd_03)) == RTRIM(LOWER(dl_reject_cd_03_after ))  AND dl_reject_cd_03 IS NOT NULL AND dl_reject_cd_03_after IS NOT NULL ) OR ( dl_reject_cd_03 IS NULL AND dl_reject_cd_03_after IS NULL )) AND  (( RTRIM(LOWER(dl_reject_cd_04)) == RTRIM(LOWER(dl_reject_cd_04_after ))  AND dl_reject_cd_04 IS NOT NULL AND dl_reject_cd_04_after IS NOT NULL ) OR ( dl_reject_cd_04 IS NULL AND dl_reject_cd_04_after IS NULL )) AND  (( RTRIM(LOWER(dl_reject_cd_05)) == RTRIM(LOWER(dl_reject_cd_05_after ))  AND dl_reject_cd_05 IS NOT NULL AND dl_reject_cd_05_after IS NOT NULL ) OR ( dl_reject_cd_05 IS NULL AND dl_reject_cd_05_after IS NULL )) AND  (( RTRIM(LOWER(fill_del_adjudication_cd)) == RTRIM(LOWER(fill_del_adjudication_cd_after ))  AND fill_del_adjudication_cd IS NOT NULL AND fill_del_adjudication_cd_after IS NOT NULL ) OR ( fill_del_adjudication_cd IS NULL AND fill_del_adjudication_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_price_override_amt)) == RTRIM(LOWER(fill_price_override_amt_after ))  AND fill_price_override_amt IS NOT NULL AND fill_price_override_amt_after IS NOT NULL ) OR ( fill_price_override_amt IS NULL AND fill_price_override_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_incentive_paid_amt)) == RTRIM(LOWER(plan_incentive_paid_amt_after ))  AND plan_incentive_paid_amt IS NOT NULL AND plan_incentive_paid_amt_after IS NOT NULL ) OR ( plan_incentive_paid_amt IS NULL AND plan_incentive_paid_amt_after IS NULL )) AND  (( RTRIM(LOWER(general_recipient_nbr)) == RTRIM(LOWER(general_recipient_nbr_after ))  AND general_recipient_nbr IS NOT NULL AND general_recipient_nbr_after IS NOT NULL ) OR ( general_recipient_nbr IS NULL AND general_recipient_nbr_after IS NULL )) AND  (( RTRIM(LOWER(bin_nbr)) == RTRIM(LOWER(bin_nbr_after ))  AND bin_nbr IS NOT NULL AND bin_nbr_after IS NOT NULL ) OR ( bin_nbr IS NULL AND bin_nbr_after IS NULL )) AND  (( RTRIM(LOWER(plan_group_nbr)) == RTRIM(LOWER(plan_group_nbr_after ))  AND plan_group_nbr IS NOT NULL AND plan_group_nbr_after IS NOT NULL ) OR ( plan_group_nbr IS NULL AND plan_group_nbr_after IS NULL )) AND  (( RTRIM(LOWER(drug_warehouse_ind)) == RTRIM(LOWER(drug_warehouse_ind_after ))  AND drug_warehouse_ind IS NOT NULL AND drug_warehouse_ind_after IS NOT NULL ) OR ( drug_warehouse_ind IS NULL AND drug_warehouse_ind_after IS NULL )) AND  (( RTRIM(LOWER(general_phrm_nbr)) == RTRIM(LOWER(general_phrm_nbr_after ))  AND general_phrm_nbr IS NOT NULL AND general_phrm_nbr_after IS NOT NULL ) OR ( general_phrm_nbr IS NULL AND general_phrm_nbr_after IS NULL )) AND  (( RTRIM(LOWER(fill_est_pick_up_dttm)) == RTRIM(LOWER(fill_est_pick_up_dttm_after ))  AND fill_est_pick_up_dttm IS NOT NULL AND fill_est_pick_up_dttm_after IS NOT NULL ) OR ( fill_est_pick_up_dttm IS NULL AND fill_est_pick_up_dttm_after IS NULL )) AND  (( RTRIM(LOWER(reimburs_loss_amt)) == RTRIM(LOWER(reimburs_loss_amt_after ))  AND reimburs_loss_amt IS NOT NULL AND reimburs_loss_amt_after IS NOT NULL ) OR ( reimburs_loss_amt IS NULL AND reimburs_loss_amt_after IS NULL )) AND  (( RTRIM(LOWER(cost_plus_fee_cd)) == RTRIM(LOWER(cost_plus_fee_cd_after ))  AND cost_plus_fee_cd IS NOT NULL AND cost_plus_fee_cd_after IS NOT NULL ) OR ( cost_plus_fee_cd IS NULL AND cost_plus_fee_cd_after IS NULL )) AND  (( RTRIM(LOWER(accept_consult_ind)) == RTRIM(LOWER(accept_consult_ind_after ))  AND accept_consult_ind IS NOT NULL AND accept_consult_ind_after IS NOT NULL ) OR ( accept_consult_ind IS NULL AND accept_consult_ind_after IS NULL )) AND  (( RTRIM(LOWER(basis_of_reimb_determ)) == RTRIM(LOWER(basis_of_reimb_determ_after ))  AND basis_of_reimb_determ IS NOT NULL AND basis_of_reimb_determ_after IS NOT NULL ) OR ( basis_of_reimb_determ IS NULL AND basis_of_reimb_determ_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid)) == RTRIM(LOWER(plan_other_amt_paid_after ))  AND plan_other_amt_paid IS NOT NULL AND plan_other_amt_paid_after IS NOT NULL ) OR ( plan_other_amt_paid IS NULL AND plan_other_amt_paid_after IS NULL )) AND  (( RTRIM(LOWER(amt_attributed_to_tax)) == RTRIM(LOWER(amt_attributed_to_tax_after ))  AND amt_attributed_to_tax IS NOT NULL AND amt_attributed_to_tax_after IS NOT NULL ) OR ( amt_attributed_to_tax IS NULL AND amt_attributed_to_tax_after IS NULL )) AND  (( RTRIM(LOWER(plan_incent_amt_submtd)) == RTRIM(LOWER(plan_incent_amt_submtd_after ))  AND plan_incent_amt_submtd IS NOT NULL AND plan_incent_amt_submtd_after IS NOT NULL ) OR ( plan_incent_amt_submtd IS NULL AND plan_incent_amt_submtd_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_submtd)) == RTRIM(LOWER(plan_other_amt_submtd_after ))  AND plan_other_amt_submtd IS NOT NULL AND plan_other_amt_submtd_after IS NOT NULL ) OR ( plan_other_amt_submtd IS NULL AND plan_other_amt_submtd_after IS NULL )) AND  (( RTRIM(LOWER(lvl_of_svc_cd)) == RTRIM(LOWER(lvl_of_svc_cd_after ))  AND lvl_of_svc_cd IS NOT NULL AND lvl_of_svc_cd_after IS NOT NULL ) OR ( lvl_of_svc_cd IS NULL AND lvl_of_svc_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_01)) == RTRIM(LOWER(cob_dl_reject_cd_01_after ))  AND cob_dl_reject_cd_01 IS NOT NULL AND cob_dl_reject_cd_01_after IS NOT NULL ) OR ( cob_dl_reject_cd_01 IS NULL AND cob_dl_reject_cd_01_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_02)) == RTRIM(LOWER(cob_dl_reject_cd_02_after ))  AND cob_dl_reject_cd_02 IS NOT NULL AND cob_dl_reject_cd_02_after IS NOT NULL ) OR ( cob_dl_reject_cd_02 IS NULL AND cob_dl_reject_cd_02_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_03)) == RTRIM(LOWER(cob_dl_reject_cd_03_after ))  AND cob_dl_reject_cd_03 IS NOT NULL AND cob_dl_reject_cd_03_after IS NOT NULL ) OR ( cob_dl_reject_cd_03 IS NULL AND cob_dl_reject_cd_03_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_04)) == RTRIM(LOWER(cob_dl_reject_cd_04_after ))  AND cob_dl_reject_cd_04 IS NOT NULL AND cob_dl_reject_cd_04_after IS NOT NULL ) OR ( cob_dl_reject_cd_04 IS NULL AND cob_dl_reject_cd_04_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_reject_cd_05)) == RTRIM(LOWER(cob_dl_reject_cd_05_after ))  AND cob_dl_reject_cd_05 IS NOT NULL AND cob_dl_reject_cd_05_after IS NOT NULL ) OR ( cob_dl_reject_cd_05 IS NULL AND cob_dl_reject_cd_05_after IS NULL )) AND  (( RTRIM(LOWER(cob_fill_del_adj_cd)) == RTRIM(LOWER(cob_fill_del_adj_cd_after ))  AND cob_fill_del_adj_cd IS NOT NULL AND cob_fill_del_adj_cd_after IS NOT NULL ) OR ( cob_fill_del_adj_cd IS NULL AND cob_fill_del_adj_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_bin_nbr)) == RTRIM(LOWER(cob_bin_nbr_after ))  AND cob_bin_nbr IS NOT NULL AND cob_bin_nbr_after IS NOT NULL ) OR ( cob_bin_nbr IS NULL AND cob_bin_nbr_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_group_nbr)) == RTRIM(LOWER(cob_plan_group_nbr_after ))  AND cob_plan_group_nbr IS NOT NULL AND cob_plan_group_nbr_after IS NOT NULL ) OR ( cob_plan_group_nbr IS NULL AND cob_plan_group_nbr_after IS NULL )) AND  (( RTRIM(LOWER(cob_general_phrm_nbr)) == RTRIM(LOWER(cob_general_phrm_nbr_after ))  AND cob_general_phrm_nbr IS NOT NULL AND cob_general_phrm_nbr_after IS NOT NULL ) OR ( cob_general_phrm_nbr IS NULL AND cob_general_phrm_nbr_after IS NULL )) AND  (( RTRIM(LOWER(cob_basis_of_reimb_detrm)) == RTRIM(LOWER(cob_basis_of_reimb_detrm_after ))  AND cob_basis_of_reimb_detrm IS NOT NULL AND cob_basis_of_reimb_detrm_after IS NOT NULL ) OR ( cob_basis_of_reimb_detrm IS NULL AND cob_basis_of_reimb_detrm_after IS NULL )) AND  (( RTRIM(LOWER(cob_amt_attrib_to_tax)) == RTRIM(LOWER(cob_amt_attrib_to_tax_after ))  AND cob_amt_attrib_to_tax IS NOT NULL AND cob_amt_attrib_to_tax_after IS NOT NULL ) OR ( cob_amt_attrib_to_tax IS NULL AND cob_amt_attrib_to_tax_after IS NULL )) AND  (( RTRIM(LOWER(cob_pln_othr_amt_pd)) == RTRIM(LOWER(cob_pln_othr_amt_pd_after ))  AND cob_pln_othr_amt_pd IS NOT NULL AND cob_pln_othr_amt_pd_after IS NOT NULL ) OR ( cob_pln_othr_amt_pd IS NULL AND cob_pln_othr_amt_pd_after IS NULL )) AND  (( RTRIM(LOWER(cash_disc_sav_amt)) == RTRIM(LOWER(cash_disc_sav_amt_after ))  AND cash_disc_sav_amt IS NOT NULL AND cash_disc_sav_amt_after IS NOT NULL ) OR ( cash_disc_sav_amt IS NULL AND cash_disc_sav_amt_after IS NULL )) AND  (( RTRIM(LOWER(general_rph_nbr)) == RTRIM(LOWER(general_rph_nbr_after ))  AND general_rph_nbr IS NOT NULL AND general_rph_nbr_after IS NOT NULL ) OR ( general_rph_nbr IS NULL AND general_rph_nbr_after IS NULL )) AND  (( RTRIM(LOWER(routing_store_tech_inits)) == RTRIM(LOWER(routing_store_tech_inits_after ))  AND routing_store_tech_inits IS NOT NULL AND routing_store_tech_inits_after IS NOT NULL ) OR ( routing_store_tech_inits IS NULL AND routing_store_tech_inits_after IS NULL )) AND  (( RTRIM(LOWER(sourcing_ind)) == RTRIM(LOWER(sourcing_ind_after ))  AND sourcing_ind IS NOT NULL AND sourcing_ind_after IS NOT NULL ) OR ( sourcing_ind IS NULL AND sourcing_ind_after IS NULL )) AND  (( RTRIM(LOWER(maj_med_prior_auth_nbr)) == RTRIM(LOWER(maj_med_prior_auth_nbr_after ))  AND maj_med_prior_auth_nbr IS NOT NULL AND maj_med_prior_auth_nbr_after IS NOT NULL ) OR ( maj_med_prior_auth_nbr IS NULL AND maj_med_prior_auth_nbr_after IS NULL )) AND  (( RTRIM(LOWER(tip_rsn_for_svc_cd)) == RTRIM(LOWER(tip_rsn_for_svc_cd_after ))  AND tip_rsn_for_svc_cd IS NOT NULL AND tip_rsn_for_svc_cd_after IS NOT NULL ) OR ( tip_rsn_for_svc_cd IS NULL AND tip_rsn_for_svc_cd_after IS NULL )) AND  (( RTRIM(LOWER(data_rev_spec_id)) == RTRIM(LOWER(data_rev_spec_id_after ))  AND data_rev_spec_id IS NOT NULL AND data_rev_spec_id_after IS NOT NULL ) OR ( data_rev_spec_id IS NULL AND data_rev_spec_id_after IS NULL )) AND  (( RTRIM(LOWER(data_rev_spec_dttm)) == RTRIM(LOWER(data_rev_spec_dttm_after ))  AND data_rev_spec_dttm IS NOT NULL AND data_rev_spec_dttm_after IS NOT NULL ) OR ( data_rev_spec_dttm IS NULL AND data_rev_spec_dttm_after IS NULL )) AND  (( RTRIM(LOWER(data_rev_spec_store_nbr)) == RTRIM(LOWER(data_rev_spec_store_nbr_after ))  AND data_rev_spec_store_nbr IS NOT NULL AND data_rev_spec_store_nbr_after IS NOT NULL ) OR ( data_rev_spec_store_nbr IS NULL AND data_rev_spec_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(fill_rph_of_record_id)) == RTRIM(LOWER(fill_rph_of_record_id_after ))  AND fill_rph_of_record_id IS NOT NULL AND fill_rph_of_record_id_after IS NOT NULL ) OR ( fill_rph_of_record_id IS NULL AND fill_rph_of_record_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_plan_incntv_paid_amt)) == RTRIM(LOWER(cob_plan_incntv_paid_amt_after ))  AND cob_plan_incntv_paid_amt IS NOT NULL AND cob_plan_incntv_paid_amt_after IS NOT NULL ) OR ( cob_plan_incntv_paid_amt IS NULL AND cob_plan_incntv_paid_amt_after IS NULL )) AND  (( RTRIM(LOWER(cob_pln_incnt_amt_sbmtd)) == RTRIM(LOWER(cob_pln_incnt_amt_sbmtd_after ))  AND cob_pln_incnt_amt_sbmtd IS NOT NULL AND cob_pln_incnt_amt_sbmtd_after IS NOT NULL ) OR ( cob_pln_incnt_amt_sbmtd IS NULL AND cob_pln_incnt_amt_sbmtd_after IS NULL )) AND  (( RTRIM(LOWER(cob_gen_recipient_nbr)) == RTRIM(LOWER(cob_gen_recipient_nbr_after ))  AND cob_gen_recipient_nbr IS NOT NULL AND cob_gen_recipient_nbr_after IS NOT NULL ) OR ( cob_gen_recipient_nbr IS NULL AND cob_gen_recipient_nbr_after IS NULL )) AND  (( RTRIM(LOWER(celgene_md_auth_nbr)) == RTRIM(LOWER(celgene_md_auth_nbr_after ))  AND celgene_md_auth_nbr IS NOT NULL AND celgene_md_auth_nbr_after IS NOT NULL ) OR ( celgene_md_auth_nbr IS NULL AND celgene_md_auth_nbr_after IS NULL )) AND  (( RTRIM(LOWER(celgene_conf_nbr)) == RTRIM(LOWER(celgene_conf_nbr_after ))  AND celgene_conf_nbr IS NOT NULL AND celgene_conf_nbr_after IS NOT NULL ) OR ( celgene_conf_nbr IS NULL AND celgene_conf_nbr_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid_type)) == RTRIM(LOWER(plan_other_amt_paid_type_after ))  AND plan_other_amt_paid_type IS NOT NULL AND plan_other_amt_paid_type_after IS NOT NULL ) OR ( plan_other_amt_paid_type IS NULL AND plan_other_amt_paid_type_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_subm_type)) == RTRIM(LOWER(plan_other_amt_subm_type_after ))  AND plan_other_amt_subm_type IS NOT NULL AND plan_other_amt_subm_type_after IS NOT NULL ) OR ( plan_other_amt_subm_type IS NULL AND plan_other_amt_subm_type_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_coins_amt)) == RTRIM(LOWER(plan_returnd_coins_amt_after ))  AND plan_returnd_coins_amt IS NOT NULL AND plan_returnd_coins_amt_after IS NOT NULL ) OR ( plan_returnd_coins_amt IS NULL AND plan_returnd_coins_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_rtrnd_coins_amt)) == RTRIM(LOWER(plan_rtrnd_coins_amt_after ))  AND plan_rtrnd_coins_amt IS NOT NULL AND plan_rtrnd_coins_amt_after IS NOT NULL ) OR ( plan_rtrnd_coins_amt IS NULL AND plan_rtrnd_coins_amt_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid_2)) == RTRIM(LOWER(plan_other_amt_paid_2_after ))  AND plan_other_amt_paid_2 IS NOT NULL AND plan_other_amt_paid_2_after IS NOT NULL ) OR ( plan_other_amt_paid_2 IS NULL AND plan_other_amt_paid_2_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid_typ2)) == RTRIM(LOWER(plan_other_amt_paid_typ2_after ))  AND plan_other_amt_paid_typ2 IS NOT NULL AND plan_other_amt_paid_typ2_after IS NOT NULL ) OR ( plan_other_amt_paid_typ2 IS NULL AND plan_other_amt_paid_typ2_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid_3)) == RTRIM(LOWER(plan_other_amt_paid_3_after ))  AND plan_other_amt_paid_3 IS NOT NULL AND plan_other_amt_paid_3_after IS NOT NULL ) OR ( plan_other_amt_paid_3 IS NULL AND plan_other_amt_paid_3_after IS NULL )) AND  (( RTRIM(LOWER(plan_other_amt_paid_typ3)) == RTRIM(LOWER(plan_other_amt_paid_typ3_after ))  AND plan_other_amt_paid_typ3 IS NOT NULL AND plan_other_amt_paid_typ3_after IS NOT NULL ) OR ( plan_other_amt_paid_typ3 IS NULL AND plan_other_amt_paid_typ3_after IS NULL )) AND  (( RTRIM(LOWER(fill_print_dttm)) == RTRIM(LOWER(fill_print_dttm_after ))  AND fill_print_dttm IS NOT NULL AND fill_print_dttm_after IS NOT NULL ) OR ( fill_print_dttm IS NULL AND fill_print_dttm_after IS NULL )) AND  (( RTRIM(LOWER(pat_lang_pref_cd)) == RTRIM(LOWER(pat_lang_pref_cd_after ))  AND pat_lang_pref_cd IS NOT NULL AND pat_lang_pref_cd_after IS NOT NULL ) OR ( pat_lang_pref_cd IS NULL AND pat_lang_pref_cd_after IS NULL )) AND  (( RTRIM(LOWER(rebilling_dttm)) == RTRIM(LOWER(rebilling_dttm_after ))  AND rebilling_dttm IS NOT NULL AND rebilling_dttm_after IS NOT NULL ) OR ( rebilling_dttm IS NULL AND rebilling_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_90day_pref_ind)) == RTRIM(LOWER(fill_90day_pref_ind_after ))  AND fill_90day_pref_ind IS NOT NULL AND fill_90day_pref_ind_after IS NOT NULL ) OR ( fill_90day_pref_ind IS NULL AND fill_90day_pref_ind_after IS NULL )) AND  (( RTRIM(LOWER(fill_90day_pref_stat_cd)) == RTRIM(LOWER(fill_90day_pref_stat_cd_after ))  AND fill_90day_pref_stat_cd IS NOT NULL AND fill_90day_pref_stat_cd_after IS NOT NULL ) OR ( fill_90day_pref_stat_cd IS NULL AND fill_90day_pref_stat_cd_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_id)) == RTRIM(LOWER(pat_pickup_id_after ))  AND pat_pickup_id IS NOT NULL AND pat_pickup_id_after IS NOT NULL ) OR ( pat_pickup_id IS NULL AND pat_pickup_id_after IS NULL )) AND  (( RTRIM(LOWER(pickup_id)) == RTRIM(LOWER(pickup_id_after ))  AND pickup_id IS NOT NULL AND pickup_id_after IS NOT NULL ) OR ( pickup_id IS NULL AND pickup_id_after IS NULL )) AND  (( RTRIM(LOWER(pickup_first_name)) == RTRIM(LOWER(pickup_first_name_after ))  AND pickup_first_name IS NOT NULL AND pickup_first_name_after IS NOT NULL ) OR ( pickup_first_name IS NULL AND pickup_first_name_after IS NULL )) AND  (( RTRIM(LOWER(pickup_last_name)) == RTRIM(LOWER(pickup_last_name_after ))  AND pickup_last_name IS NOT NULL AND pickup_last_name_after IS NOT NULL ) OR ( pickup_last_name IS NULL AND pickup_last_name_after IS NULL )) AND  (( RTRIM(LOWER(pickup_id_state)) == RTRIM(LOWER(pickup_id_state_after ))  AND pickup_id_state IS NOT NULL AND pickup_id_state_after IS NOT NULL ) OR ( pickup_id_state IS NULL AND pickup_id_state_after IS NULL )) AND  (( RTRIM(LOWER(pickup_id_country)) == RTRIM(LOWER(pickup_id_country_after ))  AND pickup_id_country IS NOT NULL AND pickup_id_country_after IS NOT NULL ) OR ( pickup_id_country IS NULL AND pickup_id_country_after IS NULL )) AND  (( RTRIM(LOWER(pickup_id_qlfr)) == RTRIM(LOWER(pickup_id_qlfr_after ))  AND pickup_id_qlfr IS NOT NULL AND pickup_id_qlfr_after IS NOT NULL ) OR ( pickup_id_qlfr IS NULL AND pickup_id_qlfr_after IS NULL )) AND  (( RTRIM(LOWER(pickup_rel_cd)) == RTRIM(LOWER(pickup_rel_cd_after ))  AND pickup_rel_cd IS NOT NULL AND pickup_rel_cd_after IS NOT NULL ) OR ( pickup_rel_cd IS NULL AND pickup_rel_cd_after IS NULL )) AND  (( RTRIM(LOWER(dl_proc_msg)) == RTRIM(LOWER(dl_proc_msg_after ))  AND dl_proc_msg IS NOT NULL AND dl_proc_msg_after IS NOT NULL ) OR ( dl_proc_msg IS NULL AND dl_proc_msg_after IS NULL )) AND  (( RTRIM(LOWER(cob_dl_proc_msg)) == RTRIM(LOWER(cob_dl_proc_msg_after ))  AND cob_dl_proc_msg IS NOT NULL AND cob_dl_proc_msg_after IS NOT NULL ) OR ( cob_dl_proc_msg IS NULL AND cob_dl_proc_msg_after IS NULL )) AND  (( RTRIM(LOWER(proc_ctrl_nbr)) == RTRIM(LOWER(proc_ctrl_nbr_after ))  AND proc_ctrl_nbr IS NOT NULL AND proc_ctrl_nbr_after IS NOT NULL ) OR ( proc_ctrl_nbr IS NULL AND proc_ctrl_nbr_after IS NULL )) AND  (( RTRIM(LOWER(med_partd_notice_ind)) == RTRIM(LOWER(med_partd_notice_ind_after ))  AND med_partd_notice_ind IS NOT NULL AND med_partd_notice_ind_after IS NOT NULL ) OR ( med_partd_notice_ind IS NULL AND med_partd_notice_ind_after IS NULL )) AND  (( RTRIM(LOWER(dispensed_ndc)) == RTRIM(LOWER(dispensed_ndc_after ))  AND dispensed_ndc IS NOT NULL AND dispensed_ndc_after IS NOT NULL ) OR ( dispensed_ndc IS NULL AND dispensed_ndc_after IS NULL )) AND  (( RTRIM(LOWER(med_partd_print_dttm)) == RTRIM(LOWER(med_partd_print_dttm_after ))  AND med_partd_print_dttm IS NOT NULL AND med_partd_print_dttm_after IS NOT NULL ) OR ( med_partd_print_dttm IS NULL AND med_partd_print_dttm_after IS NULL )) AND  (( RTRIM(LOWER(overstock_ind)) == RTRIM(LOWER(overstock_ind_after ))  AND overstock_ind IS NOT NULL AND overstock_ind_after IS NOT NULL ) OR ( overstock_ind IS NULL AND overstock_ind_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_1)) == RTRIM(LOWER(ben_stg_qualifier_1_after ))  AND ben_stg_qualifier_1 IS NOT NULL AND ben_stg_qualifier_1_after IS NOT NULL ) OR ( ben_stg_qualifier_1 IS NULL AND ben_stg_qualifier_1_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_2)) == RTRIM(LOWER(ben_stg_qualifier_2_after ))  AND ben_stg_qualifier_2 IS NOT NULL AND ben_stg_qualifier_2_after IS NOT NULL ) OR ( ben_stg_qualifier_2 IS NULL AND ben_stg_qualifier_2_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_3)) == RTRIM(LOWER(ben_stg_qualifier_3_after ))  AND ben_stg_qualifier_3 IS NOT NULL AND ben_stg_qualifier_3_after IS NOT NULL ) OR ( ben_stg_qualifier_3 IS NULL AND ben_stg_qualifier_3_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_qualifier_4)) == RTRIM(LOWER(ben_stg_qualifier_4_after ))  AND ben_stg_qualifier_4 IS NOT NULL AND ben_stg_qualifier_4_after IS NOT NULL ) OR ( ben_stg_qualifier_4 IS NULL AND ben_stg_qualifier_4_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_1)) == RTRIM(LOWER(ben_stg_amount_1_after ))  AND ben_stg_amount_1 IS NOT NULL AND ben_stg_amount_1_after IS NOT NULL ) OR ( ben_stg_amount_1 IS NULL AND ben_stg_amount_1_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_2)) == RTRIM(LOWER(ben_stg_amount_2_after ))  AND ben_stg_amount_2 IS NOT NULL AND ben_stg_amount_2_after IS NOT NULL ) OR ( ben_stg_amount_2 IS NULL AND ben_stg_amount_2_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_3)) == RTRIM(LOWER(ben_stg_amount_3_after ))  AND ben_stg_amount_3 IS NOT NULL AND ben_stg_amount_3_after IS NOT NULL ) OR ( ben_stg_amount_3 IS NULL AND ben_stg_amount_3_after IS NULL )) AND  (( RTRIM(LOWER(ben_stg_amount_4)) == RTRIM(LOWER(ben_stg_amount_4_after ))  AND ben_stg_amount_4 IS NOT NULL AND ben_stg_amount_4_after IS NOT NULL ) OR ( ben_stg_amount_4 IS NULL AND ben_stg_amount_4_after IS NULL )) AND  (( RTRIM(LOWER(coupon_drug_id)) == RTRIM(LOWER(coupon_drug_id_after ))  AND coupon_drug_id IS NOT NULL AND coupon_drug_id_after IS NOT NULL ) OR ( coupon_drug_id IS NULL AND coupon_drug_id_after IS NULL )) AND  (( RTRIM(LOWER(cob_coupon_drug_id)) == RTRIM(LOWER(cob_coupon_drug_id_after ))  AND cob_coupon_drug_id IS NOT NULL AND cob_coupon_drug_id_after IS NOT NULL ) OR ( cob_coupon_drug_id IS NULL AND cob_coupon_drug_id_after IS NULL )) AND  (( RTRIM(LOWER(coupon_ind)) == RTRIM(LOWER(coupon_ind_after ))  AND coupon_ind IS NOT NULL AND coupon_ind_after IS NOT NULL ) OR ( coupon_ind IS NULL AND coupon_ind_after IS NULL )) AND  (( RTRIM(LOWER(cob_coupon_ind)) == RTRIM(LOWER(cob_coupon_ind_after ))  AND cob_coupon_ind IS NOT NULL AND cob_coupon_ind_after IS NOT NULL ) OR ( cob_coupon_ind IS NULL AND cob_coupon_ind_after IS NULL )) AND  (( RTRIM(LOWER(other_coverage_cd)) == RTRIM(LOWER(other_coverage_cd_after ))  AND other_coverage_cd IS NOT NULL AND other_coverage_cd_after IS NOT NULL ) OR ( other_coverage_cd IS NULL AND other_coverage_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_other_coverage_cd)) == RTRIM(LOWER(cob_other_coverage_cd_after ))  AND cob_other_coverage_cd IS NOT NULL AND cob_other_coverage_cd_after IS NOT NULL ) OR ( cob_other_coverage_cd IS NULL AND cob_other_coverage_cd_after IS NULL )) AND  (( RTRIM(LOWER(partial_fil_intnded_qty)) == RTRIM(LOWER(partial_fil_intnded_qty_after ))  AND partial_fil_intnded_qty IS NOT NULL AND partial_fil_intnded_qty_after IS NOT NULL ) OR ( partial_fil_intnded_qty IS NULL AND partial_fil_intnded_qty_after IS NULL )) AND  (( RTRIM(LOWER(triplicate_serial_nbr)) == RTRIM(LOWER(triplicate_serial_nbr_after ))  AND triplicate_serial_nbr IS NOT NULL AND triplicate_serial_nbr_after IS NOT NULL ) OR ( triplicate_serial_nbr IS NULL AND triplicate_serial_nbr_after IS NULL )) AND  (( RTRIM(LOWER(source_system_name)) == RTRIM(LOWER(source_system_name_after ))  AND source_system_name IS NOT NULL AND source_system_name_after IS NOT NULL ) OR ( source_system_name IS NULL AND source_system_name_after IS NULL )) AND  (( RTRIM(LOWER(source_sys_trans_id)) == RTRIM(LOWER(source_sys_trans_id_after ))  AND source_sys_trans_id IS NOT NULL AND source_sys_trans_id_after IS NOT NULL ) OR ( source_sys_trans_id IS NULL AND source_sys_trans_id_after IS NULL )) AND  (( RTRIM(LOWER(delivery_ind)) == RTRIM(LOWER(delivery_ind_after ))  AND delivery_ind IS NOT NULL AND delivery_ind_after IS NOT NULL ) OR ( delivery_ind IS NULL AND delivery_ind_after IS NULL )) AND  (( RTRIM(LOWER(delivery_comments)) == RTRIM(LOWER(delivery_comments_after ))  AND delivery_comments IS NOT NULL AND delivery_comments_after IS NOT NULL ) OR ( delivery_comments IS NULL AND delivery_comments_after IS NULL )) AND  (( RTRIM(LOWER(approved_msg_cd)) == RTRIM(LOWER(approved_msg_cd_after ))  AND approved_msg_cd IS NOT NULL AND approved_msg_cd_after IS NOT NULL ) OR ( approved_msg_cd IS NULL AND approved_msg_cd_after IS NULL )) AND  (( RTRIM(LOWER(approved_msg_cd_2)) == RTRIM(LOWER(approved_msg_cd_2_after ))  AND approved_msg_cd_2 IS NOT NULL AND approved_msg_cd_2_after IS NOT NULL ) OR ( approved_msg_cd_2 IS NULL AND approved_msg_cd_2_after IS NULL )) AND  (( RTRIM(LOWER(approved_msg_cd_3)) == RTRIM(LOWER(approved_msg_cd_3_after ))  AND approved_msg_cd_3 IS NOT NULL AND approved_msg_cd_3_after IS NOT NULL ) OR ( approved_msg_cd_3 IS NULL AND approved_msg_cd_3_after IS NULL )) AND  (( RTRIM(LOWER(approved_msg_cd_4)) == RTRIM(LOWER(approved_msg_cd_4_after ))  AND approved_msg_cd_4 IS NOT NULL AND approved_msg_cd_4_after IS NOT NULL ) OR ( approved_msg_cd_4 IS NULL AND approved_msg_cd_4_after IS NULL )) AND  (( RTRIM(LOWER(approved_msg_cd_5)) == RTRIM(LOWER(approved_msg_cd_5_after ))  AND approved_msg_cd_5 IS NOT NULL AND approved_msg_cd_5_after IS NOT NULL ) OR ( approved_msg_cd_5 IS NULL AND approved_msg_cd_5_after IS NULL )) AND  (( RTRIM(LOWER(cob_approved_msg_cd)) == RTRIM(LOWER(cob_approved_msg_cd_after ))  AND cob_approved_msg_cd IS NOT NULL AND cob_approved_msg_cd_after IS NOT NULL ) OR ( cob_approved_msg_cd IS NULL AND cob_approved_msg_cd_after IS NULL )) AND  (( RTRIM(LOWER(cob_approved_msg_cd_2)) == RTRIM(LOWER(cob_approved_msg_cd_2_after ))  AND cob_approved_msg_cd_2 IS NOT NULL AND cob_approved_msg_cd_2_after IS NOT NULL ) OR ( cob_approved_msg_cd_2 IS NULL AND cob_approved_msg_cd_2_after IS NULL )) AND  (( RTRIM(LOWER(cob_approved_msg_cd_3)) == RTRIM(LOWER(cob_approved_msg_cd_3_after ))  AND cob_approved_msg_cd_3 IS NOT NULL AND cob_approved_msg_cd_3_after IS NOT NULL ) OR ( cob_approved_msg_cd_3 IS NULL AND cob_approved_msg_cd_3_after IS NULL )) AND  (( RTRIM(LOWER(cob_approved_msg_cd_4)) == RTRIM(LOWER(cob_approved_msg_cd_4_after ))  AND cob_approved_msg_cd_4 IS NOT NULL AND cob_approved_msg_cd_4_after IS NOT NULL ) OR ( cob_approved_msg_cd_4 IS NULL AND cob_approved_msg_cd_4_after IS NULL )) AND  (( RTRIM(LOWER(cob_approved_msg_cd_5)) == RTRIM(LOWER(cob_approved_msg_cd_5_after ))  AND cob_approved_msg_cd_5 IS NOT NULL AND cob_approved_msg_cd_5_after IS NOT NULL ) OR ( cob_approved_msg_cd_5 IS NULL AND cob_approved_msg_cd_5_after IS NULL )) AND  (( RTRIM(LOWER(cob_general_pbr_nbr)) == RTRIM(LOWER(cob_general_pbr_nbr_after ))  AND cob_general_pbr_nbr IS NOT NULL AND cob_general_pbr_nbr_after IS NOT NULL ) OR ( cob_general_pbr_nbr IS NULL AND cob_general_pbr_nbr_after IS NULL )) AND  (( RTRIM(LOWER(gen_recip_nbr_returnd)) == RTRIM(LOWER(gen_recip_nbr_returnd_after ))  AND gen_recip_nbr_returnd IS NOT NULL AND gen_recip_nbr_returnd_after IS NOT NULL ) OR ( gen_recip_nbr_returnd IS NULL AND gen_recip_nbr_returnd_after IS NULL )) AND  (( RTRIM(LOWER(general_pbr_nbr)) == RTRIM(LOWER(general_pbr_nbr_after ))  AND general_pbr_nbr IS NOT NULL AND general_pbr_nbr_after IS NOT NULL ) OR ( general_pbr_nbr IS NULL AND general_pbr_nbr_after IS NULL )) AND  (( RTRIM(LOWER(general_rph_nbr_qlfr)) == RTRIM(LOWER(general_rph_nbr_qlfr_after ))  AND general_rph_nbr_qlfr IS NOT NULL AND general_rph_nbr_qlfr_after IS NOT NULL ) OR ( general_rph_nbr_qlfr IS NULL AND general_rph_nbr_qlfr_after IS NULL )) AND  (( RTRIM(LOWER(ntwk_reimb_id_returnd)) == RTRIM(LOWER(ntwk_reimb_id_returnd_after ))  AND ntwk_reimb_id_returnd IS NOT NULL AND ntwk_reimb_id_returnd_after IS NOT NULL ) OR ( ntwk_reimb_id_returnd IS NULL AND ntwk_reimb_id_returnd_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_gov_auth_id)) == RTRIM(LOWER(pat_pickup_gov_auth_id_after ))  AND pat_pickup_gov_auth_id IS NOT NULL AND pat_pickup_gov_auth_id_after IS NOT NULL ) OR ( pat_pickup_gov_auth_id IS NULL AND pat_pickup_gov_auth_id_after IS NULL )) AND  (( RTRIM(LOWER(pat_pickup_rel_cd)) == RTRIM(LOWER(pat_pickup_rel_cd_after ))  AND pat_pickup_rel_cd IS NOT NULL AND pat_pickup_rel_cd_after IS NOT NULL ) OR ( pat_pickup_rel_cd IS NULL AND pat_pickup_rel_cd_after IS NULL )) AND  (( RTRIM(LOWER(plan_id_returnd)) == RTRIM(LOWER(plan_id_returnd_after ))  AND plan_id_returnd IS NOT NULL AND plan_id_returnd_after IS NOT NULL ) OR ( plan_id_returnd IS NULL AND plan_id_returnd_after IS NULL )) AND  (( RTRIM(LOWER(plan_returnd_grp_nbr)) == RTRIM(LOWER(plan_returnd_grp_nbr_after ))  AND plan_returnd_grp_nbr IS NOT NULL AND plan_returnd_grp_nbr_after IS NOT NULL ) OR ( plan_returnd_grp_nbr IS NULL AND plan_returnd_grp_nbr_after IS NULL )) AND  (( RTRIM(LOWER(prior_auth_cd)) == RTRIM(LOWER(prior_auth_cd_after ))  AND prior_auth_cd IS NOT NULL AND prior_auth_cd_after IS NOT NULL ) OR ( prior_auth_cd IS NULL AND prior_auth_cd_after IS NULL )) AND  (( RTRIM(LOWER(prior_auth_nbr)) == RTRIM(LOWER(prior_auth_nbr_after ))  AND prior_auth_nbr IS NOT NULL AND prior_auth_nbr_after IS NOT NULL ) OR ( prior_auth_nbr IS NULL AND prior_auth_nbr_after IS NULL )) AND  (( RTRIM(LOWER(dl_additional_msg)) == RTRIM(LOWER(dl_additional_msg_after)) AND dl_additional_msg IS NOT NULL AND dl_additional_msg_after IS NOT NULL) OR (dl_additional_msg IS NULL AND dl_additional_msg_after IS NULL)) AND  (( RTRIM(LOWER(db_cob_proc_ctrl_nbr)) == RTRIM(LOWER(db_cob_proc_ctrl_nbr_after ))  AND db_cob_proc_ctrl_nbr IS NOT NULL AND db_cob_proc_ctrl_nbr_after IS NOT NULL ) OR ( db_cob_proc_ctrl_nbr IS NULL AND db_cob_proc_ctrl_nbr_after IS NULL )) AND  (( RTRIM(LOWER(wo_correlation_id)) == RTRIM(LOWER(wo_correlation_id_after ))  AND wo_correlation_id IS NOT NULL AND wo_correlation_id_after IS NOT NULL ) OR ( wo_correlation_id IS NULL AND wo_correlation_id_after IS NULL )) AND  (( RTRIM(LOWER(wo_rx_count)) == RTRIM(LOWER(wo_rx_count_after ))  AND wo_rx_count IS NOT NULL AND wo_rx_count_after IS NOT NULL ) OR ( wo_rx_count IS NULL AND wo_rx_count_after IS NULL )) AND  (( RTRIM(LOWER(short_fill_ind)) == RTRIM(LOWER(short_fill_ind_after ))  AND short_fill_ind IS NOT NULL AND short_fill_ind_after IS NOT NULL ) OR ( short_fill_ind IS NULL AND short_fill_ind_after IS NULL ))  AND  (( RTRIM(LOWER(pay_cd)) == RTRIM(LOWER(pay_cd_after )) AND pay_cd IS NOT NULL AND pay_cd_after IS NOT NULL ) OR ( pay_cd IS NULL AND pay_cd_after IS NULL )) AND (( RTRIM(LOWER(filling_store_nbr)) == RTRIM(LOWER(filling_store_nbr_after )) AND filling_store_nbr IS NOT NULL AND filling_store_nbr_after IS NOT NULL ) OR ( filling_store_nbr IS NULL AND filling_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(fill_verified_store_nbr)) == RTRIM(LOWER(fill_verified_store_nbr_after ))  AND fill_verified_store_nbr IS NOT NULL AND fill_verified_store_nbr_after IS NOT NULL ) OR ( fill_verified_store_nbr IS NULL AND fill_verified_store_nbr_after IS NULL )) AND (( RTRIM(LOWER(mult_prod_review_ind)) == RTRIM(LOWER(mult_prod_review_ind_after ))  AND mult_prod_review_ind IS NOT NULL AND mult_prod_review_ind_after IS NOT NULL ) OR ( mult_prod_review_ind IS NULL AND mult_prod_review_ind_after IS NULL )) AND (( RTRIM(LOWER(pat_selct_user_id )) == RTRIM(LOWER(pat_selct_user_id_after ))  AND pat_selct_user_id  IS NOT NULL AND pat_selct_user_id_after IS NOT NULL ) OR ( pat_selct_user_id IS NULL AND pat_selct_user_id_after IS NULL )) AND (( RTRIM(LOWER(pbr_selct_user_id )) == RTRIM(LOWER(pbr_selct_user_id_after ))  AND pbr_selct_user_id  IS NOT NULL AND pbr_selct_user_id_after IS NOT NULL ) OR ( pbr_selct_user_id IS NULL AND pbr_selct_user_id_after IS NULL )) AND (( RTRIM(LOWER(pat_selct_dttm )) == RTRIM(LOWER(pat_selct_dttm_after ))  AND pat_selct_dttm  IS NOT NULL AND pat_selct_dttm_after IS NOT NULL ) OR ( pat_selct_dttm IS NULL AND pat_selct_dttm_after IS NULL )) AND (( RTRIM(LOWER(pbr_selct_dttm )) == RTRIM(LOWER(pbr_selct_dttm_after ))  AND pbr_selct_dttm  IS NOT NULL AND pbr_selct_dttm_after IS NOT NULL ) OR ( pbr_selct_dttm IS NULL AND pbr_selct_dttm_after IS NULL )) AND (( RTRIM(LOWER(pat_selct_str_nbr )) == RTRIM(LOWER(pat_selct_str_nbr_after ))  AND pat_selct_str_nbr  IS NOT NULL AND pat_selct_str_nbr_after IS NOT NULL ) OR ( pat_selct_str_nbr IS NULL AND pat_selct_str_nbr_after IS NULL )) AND (( RTRIM(LOWER(pbr_selct_str_nbr )) == RTRIM(LOWER(pbr_selct_str_nbr_after ))  AND pbr_selct_str_nbr  IS NOT NULL AND pbr_selct_str_nbr_after IS NOT NULL ) OR ( pbr_selct_str_nbr IS NULL AND pbr_selct_str_nbr_after IS NULL )) AND (( RTRIM(LOWER(ntt_ind )) == RTRIM(LOWER(ntt_ind_after ))  AND ntt_ind  IS NOT NULL AND ntt_ind_after IS NOT NULL ) OR ( ntt_ind IS NULL AND ntt_ind_after IS NULL )) )" 

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr , cdc_rba_nbr , cdc_operation_type_cd , cdc_before_after_cd , cdc_txn_position_cd , edw_batch_id , store_nbr , rx_nbr , fill_nbr , fill_partial_nbr , refills_remaining , fill_wac_cost_amt , plan_returnd_cost_amt , plan_returnd_fee_amt , plan_submtd_copay_amt , pbr_id , fill_source_cd , refills_remain_when_ent , cob_plan_rtrnd_fee_amt , tot_amt_paid_ind , drug_class , drug_name , drug_id , plan_returnd_copay_amt , plan_total_paid_amt , plan_returnd_tax_amt , plan_submtd_cost_amt , plan_submtd_fee_amt , plan_submtd_tax_amt , pat_id , sims_upc , pbr_loc_id , create_user_id , CONCAT(create_dttm,'.000000') AS create_dttm, cob_plan_rtrnd_copay_amt , cob_plan_total_paid_amt , cob_plan_rtrnd_cost_amt , cob_plan_rtrnd_tax_amt , cob_plan_sbmtd_copay_amt , cob_plan_sbmtd_cost_amt , cob_plan_sbmtd_fee_amt , cob_plan_sbmtd_tax_amt , src_partition_nbr , fill_adjudication_cd , fill_awp_cost_amt , fill_days_supply , CONCAT(fill_entered_dttm,'.000000') AS fill_entered_dttm , fill_label_price_amt , fill_qty_dispensed , fill_retail_price_amt , claim_reference_nbr , fill_nbr_dispensed , plan_id , fill_status_cd , fill_entered_user_id , fill_verified_user_id , CONCAT(fill_verified_dttm,'.000000') AS fill_verified_dttm, CONCAT(fill_sold_dttm,'.000000') AS fill_sold_dttm , CONCAT(fill_deleted_dttm,'.000000') AS fill_deleted_dttm, fill_discount_cd , fill_pay_method_cd , fill_discount_amt , fill_sold_amt , fill_type_cd , update_user_id , CONCAT(update_dttm,'.000000') AS update_dttm , partial_fill_cd , CONCAT(fill_adjudication_dttm,'.000000') AS fill_adjudication_dttm , cob_fill_adjudication_cd , cob_claim_ref_nbr , cob_plan_id , CONCAT(cob_fill_adj_dttm,'.000000') AS cob_fill_adj_dttm , fill_data_rev_id , CONCAT(fill_data_rev_dttm,'.000000')  AS fill_data_rev_dttm, filling_user_id , CONCAT(filling_dttm,'.000000') AS filling_dttm , override_user_id , CONCAT(override_dttm,'.000000') AS override_dttm, entered_store_nbr , reviewed_store_nbr , plan_gross_due_amt , cob_plan_gross_due_amt , dl_reject_cd_01 , dl_reject_cd_02 , dl_reject_cd_03 , dl_reject_cd_04 , dl_reject_cd_05 , fill_del_adjudication_cd , fill_price_override_amt , plan_incentive_paid_amt , general_recipient_nbr , TRIM(bin_nbr) AS bin_nbr , TRIM(plan_group_nbr) AS plan_group_nbr , drug_warehouse_ind , general_phrm_nbr , reimburs_loss_amt , cost_plus_fee_cd , accept_consult_ind , basis_of_reimb_determ , plan_other_amt_paid , amt_attributed_to_tax , plan_incent_amt_submtd , plan_other_amt_submtd , lvl_of_svc_cd , cob_dl_reject_cd_01 , cob_dl_reject_cd_02 , cob_dl_reject_cd_03 , cob_dl_reject_cd_04 , cob_dl_reject_cd_05 , cob_fill_del_adj_cd , TRIM(cob_bin_nbr) AS cob_bin_nbr , TRIM(cob_plan_group_nbr) AS cob_plan_group_nbr , cob_general_phrm_nbr , cob_basis_of_reimb_detrm , cob_amt_attrib_to_tax , cob_pln_othr_amt_pd , cash_disc_sav_amt , general_rph_nbr , routing_store_tech_inits , sourcing_ind , maj_med_prior_auth_nbr , tip_rsn_for_svc_cd , data_rev_spec_id , data_rev_spec_store_nbr , fill_rph_of_record_id , cob_plan_incntv_paid_amt , cob_pln_incnt_amt_sbmtd , CONCAT(fill_est_pick_up_dttm,'.000000') AS fill_est_pick_up_dttm , CONCAT(data_rev_spec_dttm,'.000000') AS data_rev_spec_dttm , rx_daw_ind , (CASE WHEN (cdc_operation_type_cd=='INSERT') THEN store_nbr ELSE '' END) AS relocate_fm_str_nbr ,cob_gen_recipient_nbr , celgene_md_auth_nbr , celgene_conf_nbr , plan_other_amt_paid_type , plan_other_amt_subm_type , plan_returnd_coins_amt , plan_rtrnd_coins_amt , plan_other_amt_paid_2 , plan_other_amt_paid_typ2 , plan_other_amt_paid_3 , plan_other_amt_paid_typ3 , CONCAT(fill_print_dttm,'.000000') AS fill_print_dttm, pat_lang_pref_cd , CONCAT(rebilling_dttm,'.000000') AS rebilling_dttm , fill_90day_pref_ind , fill_90day_pref_stat_cd , pat_pickup_id , pickup_id , pickup_first_name , pickup_last_name , pickup_id_state , pickup_id_country , pickup_id_qlfr , pickup_rel_cd , dl_proc_msg , cob_dl_proc_msg , TRIM(proc_ctrl_nbr) AS proc_ctrl_nbr , dispensed_ndc , overstock_ind , med_partd_notice_ind , CONCAT(med_partd_print_dttm,'.000000') AS med_partd_print_dttm , ben_stg_qualifier_1 , ben_stg_qualifier_2 , ben_stg_qualifier_3 , ben_stg_qualifier_4 , ben_stg_amount_1 , ben_stg_amount_2 , ben_stg_amount_3 , ben_stg_amount_4 , coupon_drug_id , cob_coupon_drug_id , coupon_ind , cob_coupon_ind , other_coverage_cd , cob_other_coverage_cd , partial_fil_intnded_qty , triplicate_serial_nbr , delivery_ind , delivery_comments , CONCAT(sold_local_dttm,'.000000')  AS sold_local_dttm, pat_pickup_gov_auth_id , pat_pickup_id_qlfr , pat_pickup_rel_cd , routing_store_rph_inits , source_system_name , source_sys_trans_id , sys_status_when_ent , dl_addl_msg_qlfr AS additional_msg_qlfr_w1_cd , approved_msg_cd , approved_msg_cd_2 , approved_msg_cd_3 , approved_msg_cd_4 , approved_msg_cd_5 , cob_approved_msg_cd , cob_approved_msg_cd_2 , cob_approved_msg_cd_3 , cob_approved_msg_cd_4 , cob_approved_msg_cd_5 , gen_recip_nbr_returnd , ntwk_reimb_id_returnd , plan_returnd_grp_nbr , plan_id_returnd , general_pbr_nbr , cob_general_pbr_nbr , general_rph_nbr_qlfr , prior_auth_cd , prior_auth_nbr ,dl_additional_msg AS additional_mfgr_coupon_w1_msg, TRIM(db_cob_proc_ctrl_nbr) AS db_cob_proc_ctrl_nbr , wo_correlation_id , wo_rx_count , short_fill_ind , TRIM(rx_denial_override_cd) AS rx_denial_override_cd , TRIM(rx_denial_override_cd_2) AS rx_denial_override_cd_2 , TRIM(rx_denial_override_cd_3) AS rx_denial_override_cd_3 , pay_cd, TRIM(filling_store_nbr) as filling_store_nbr, TRIM(fill_verified_store_nbr) as fill_verified_store_nbr, TRIM(mult_prod_review_ind) as mult_prod_review_ind, TRIM(pat_selct_user_id) as pat_selct_user_id, TRIM(pbr_selct_user_id) as pbr_selct_user_id, CONCAT(pat_selct_dttm,'.000000') as pat_selct_dttm, CONCAT(pbr_selct_dttm,'.000000') AS pbr_selct_dttm, TRIM(pat_selct_str_nbr) as pat_selct_str_nbr, TRIM(pbr_selct_str_nbr) as pbr_selct_str_nbr, TRIM(ntt_ind) as ntt_ind"
#, tracking_id, partition_column"

# COMMAND ----------
#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

# cutoff_records_filter = cutoff_records_output.withColumn("EDW_BATCH_ID",concat(lit("'"),col("EDW_BATCH_ID"),lit("'")))\
#                                              .withColumn("PROJ_NAME",concat(lit("'"),col("PROJ_NAME"),lit("'")))

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == PROJ_ID))
#display(cutoff_records_filter)

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))

rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  
  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])
  
  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  
  #Remove duplicates
dedup_group = nr_input_file_final.distinct()



dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
store_nbr AS store_nbr , 
store_nbr_after AS store_nbr_after , 
rx_nbr AS rx_nbr , 
rx_nbr_after AS rx_nbr_after , 
fill_nbr AS fill_nbr , 
fill_nbr_after AS fill_nbr_after , 
fill_partial_nbr AS fill_partial_nbr , 
fill_partial_nbr_after AS fill_partial_nbr_after , 
refills_remaining AS refills_remaining , 
refills_remaining_after AS refills_remaining_after , 
fill_wac_cost_amt AS fill_wac_cost_amt , 
fill_wac_cost_amt_after AS fill_wac_cost_amt_after , 
plan_returnd_cost_amt AS plan_returnd_cost_amt , 
plan_returnd_cost_amt_after AS plan_returnd_cost_amt_after , 
plan_returnd_fee_amt AS plan_returnd_fee_amt , 
plan_returnd_fee_amt_after AS plan_returnd_fee_amt_after , 
plan_submtd_copay_amt AS plan_submtd_copay_amt , 
plan_submtd_copay_amt_after AS plan_submtd_copay_amt_after , 
pbr_id AS pbr_id , 
pbr_id_after AS pbr_id_after ,
(case when (LENGTH(trim(fill_source_cd))==0) then fill_source_cd else TRIM(fill_source_cd) end) as fill_source_cd , 
(case when (LENGTH(trim(fill_source_cd_after))==0) then fill_source_cd_after else TRIM(fill_source_cd_after) end) as fill_source_cd_after ,
(case when (LENGTH(trim(refills_remain_when_ent))==0) then refills_remain_when_ent else TRIM(refills_remain_when_ent) end) as refills_remain_when_ent , 
(case when (LENGTH(trim(refills_remain_when_ent_after))==0) then refills_remain_when_ent_after else TRIM(refills_remain_when_ent_after) end) as refills_remain_when_ent_after , 
cob_plan_rtrnd_fee_amt AS cob_plan_rtrnd_fee_amt , 
cob_plan_rtrnd_fee_amt_after AS cob_plan_rtrnd_fee_amt_after , 
(case when (LENGTH(trim(tot_amt_paid_ind))==0) then tot_amt_paid_ind else TRIM(tot_amt_paid_ind) end) as tot_amt_paid_ind , 
(case when (LENGTH(trim(tot_amt_paid_ind_after))==0) then tot_amt_paid_ind_after else TRIM(tot_amt_paid_ind_after) end) as tot_amt_paid_ind_after , 
(case when (LENGTH(trim(drug_class))==0) then drug_class else TRIM(drug_class) end) as drug_class , 
(case when (LENGTH(trim(drug_class_after))==0) then drug_class_after else TRIM(drug_class_after) end) as drug_class_after , 
(case when (LENGTH(trim(drug_name))==0) then drug_name else TRIM(drug_name) end) as drug_name , 
(case when (LENGTH(trim(drug_name_after))==0) then drug_name_after else TRIM(drug_name_after) end) as drug_name_after , 
drug_id AS drug_id , 
drug_id_after AS drug_id_after , 
plan_returnd_copay_amt AS plan_returnd_copay_amt , 
plan_returnd_copay_amt_after AS plan_returnd_copay_amt_after , 
plan_total_paid_amt AS plan_total_paid_amt , 
plan_total_paid_amt_after AS plan_total_paid_amt_after , 
plan_returnd_tax_amt AS plan_returnd_tax_amt , 
plan_returnd_tax_amt_after AS plan_returnd_tax_amt_after , 
plan_submtd_cost_amt AS plan_submtd_cost_amt , 
plan_submtd_cost_amt_after AS plan_submtd_cost_amt_after , 
plan_submtd_fee_amt AS plan_submtd_fee_amt , 
plan_submtd_fee_amt_after AS plan_submtd_fee_amt_after , 
plan_submtd_tax_amt AS plan_submtd_tax_amt , 
plan_submtd_tax_amt_after AS plan_submtd_tax_amt_after , 
pat_id AS pat_id , 
pat_id_after AS pat_id_after , 
(case when (LENGTH(trim(sims_upc))==0) then sims_upc else TRIM(sims_upc) end) as sims_upc , 
(case when (LENGTH(trim(sims_upc_after))==0) then sims_upc_after else TRIM(sims_upc_after) end) as sims_upc_after , 
pbr_loc_id AS pbr_loc_id , 
pbr_loc_id_after AS pbr_loc_id_after , 
create_user_id AS create_user_id , 
create_user_id_after AS create_user_id_after , 
CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm,11,19)) as create_dttm ,
CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after,11,19)) as create_dttm_after , 
cob_plan_rtrnd_copay_amt AS cob_plan_rtrnd_copay_amt , 
cob_plan_rtrnd_copay_amt_after AS cob_plan_rtrnd_copay_amt_after , 
cob_plan_total_paid_amt AS cob_plan_total_paid_amt , 
cob_plan_total_paid_amt_after AS cob_plan_total_paid_amt_after , 
cob_plan_rtrnd_cost_amt AS cob_plan_rtrnd_cost_amt , 
cob_plan_rtrnd_cost_amt_after AS cob_plan_rtrnd_cost_amt_after , 
cob_plan_rtrnd_tax_amt AS cob_plan_rtrnd_tax_amt , 
cob_plan_rtrnd_tax_amt_after AS cob_plan_rtrnd_tax_amt_after , 
cob_plan_sbmtd_copay_amt AS cob_plan_sbmtd_copay_amt , 
cob_plan_sbmtd_copay_amt_after AS cob_plan_sbmtd_copay_amt_after , 
cob_plan_sbmtd_cost_amt AS cob_plan_sbmtd_cost_amt , 
cob_plan_sbmtd_cost_amt_after AS cob_plan_sbmtd_cost_amt_after , 
cob_plan_sbmtd_fee_amt AS cob_plan_sbmtd_fee_amt , 
cob_plan_sbmtd_fee_amt_after AS cob_plan_sbmtd_fee_amt_after , 
cob_plan_sbmtd_tax_amt AS cob_plan_sbmtd_tax_amt , 
cob_plan_sbmtd_tax_amt_after AS cob_plan_sbmtd_tax_amt_after , 
src_partition_nbr AS src_partition_nbr , 
src_partition_nbr_after AS src_partition_nbr_after , 
(case when (LENGTH(trim(fill_adjudication_cd))==0) then fill_adjudication_cd else TRIM(fill_adjudication_cd) end) as fill_adjudication_cd ,
(case when (LENGTH(trim(fill_adjudication_cd_after))==0) then fill_adjudication_cd_after else TRIM(fill_adjudication_cd_after) end) as fill_adjudication_cd_after , 
fill_awp_cost_amt AS fill_awp_cost_amt , 
fill_awp_cost_amt_after AS fill_awp_cost_amt_after , 
fill_days_supply AS fill_days_supply , 
fill_days_supply_after AS fill_days_supply_after , 
CONCAT(CONCAT(SUBSTRING(fill_entered_dttm,0,10),' '),SUBSTRING(fill_entered_dttm,11,19)) as fill_entered_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_entered_dttm_after,0,10),' '),SUBSTRING(fill_entered_dttm_after,11,19)) as fill_entered_dttm_after ,
fill_label_price_amt AS fill_label_price_amt , 
fill_label_price_amt_after AS fill_label_price_amt_after , 
fill_qty_dispensed AS fill_qty_dispensed , 
fill_qty_dispensed_after AS fill_qty_dispensed_after , 
fill_retail_price_amt AS fill_retail_price_amt , 
fill_retail_price_amt_after AS fill_retail_price_amt_after , 
(case when (LENGTH(trim(claim_reference_nbr))==0) then claim_reference_nbr else TRIM(claim_reference_nbr) end) as claim_reference_nbr , 
(case when (LENGTH(trim(claim_reference_nbr_after))==0) then claim_reference_nbr_after else TRIM(claim_reference_nbr_after) end) as claim_reference_nbr_after , 
fill_nbr_dispensed AS fill_nbr_dispensed , 
fill_nbr_dispensed_after AS fill_nbr_dispensed_after , 
(case when (LENGTH(trim(plan_id))==0) then plan_id else TRIM(plan_id) end) as plan_id , 
(case when (LENGTH(trim(plan_id_after))==0) then plan_id_after else TRIM(plan_id_after) end) as plan_id_after , 
(case when (LENGTH(trim(fill_status_cd))==0) then fill_status_cd else TRIM(fill_status_cd) end) as fill_status_cd , 
(case when (LENGTH(trim(fill_status_cd_after))==0) then fill_status_cd_after else TRIM(fill_status_cd_after) end) as fill_status_cd_after ,
fill_entered_user_id AS fill_entered_user_id , 
fill_entered_user_id_after AS fill_entered_user_id_after , 
fill_verified_user_id AS fill_verified_user_id , 
fill_verified_user_id_after AS fill_verified_user_id_after , 
CONCAT(CONCAT(SUBSTRING(fill_verified_dttm,0,10),' '),SUBSTRING(fill_verified_dttm,11,19)) as fill_verified_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_verified_dttm_after,0,10),' '),SUBSTRING(fill_verified_dttm_after,11,19)) as fill_verified_dttm_after ,
CONCAT(CONCAT(SUBSTRING(fill_sold_dttm,0,10),' '),SUBSTRING(fill_sold_dttm,11,19)) as fill_sold_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_sold_dttm_after,0,10),' '),SUBSTRING(fill_sold_dttm_after,11,19)) as fill_sold_dttm_after ,
CONCAT(CONCAT(SUBSTRING(fill_deleted_dttm,0,10),' '),SUBSTRING(fill_deleted_dttm,11,19)) as fill_deleted_dttm , 
CONCAT(CONCAT(SUBSTRING(fill_deleted_dttm_after,0,10),' '),SUBSTRING(fill_deleted_dttm_after,11,19)) as fill_deleted_dttm_after , 
(case when (LENGTH(trim(fill_discount_cd))==0) then fill_discount_cd else TRIM(fill_discount_cd) end) as fill_discount_cd , 
(case when (LENGTH(trim(fill_discount_cd_after))==0) then fill_discount_cd_after else TRIM(fill_discount_cd_after) end) as fill_discount_cd_after , 
(case when (LENGTH(trim(fill_pay_method_cd))==0) then fill_pay_method_cd else TRIM(fill_pay_method_cd) end) as fill_pay_method_cd ,
(case when (LENGTH(trim(fill_pay_method_cd_after))==0) then fill_pay_method_cd_after else TRIM(fill_pay_method_cd_after) end) as fill_pay_method_cd_after , 
fill_discount_amt AS fill_discount_amt , 
fill_discount_amt_after AS fill_discount_amt_after , 
fill_sold_amt AS fill_sold_amt , 
fill_sold_amt_after AS fill_sold_amt_after ,
(case when (LENGTH(trim(fill_type_cd))==0) then fill_type_cd else TRIM(fill_type_cd) end) as fill_type_cd ,
(case when (LENGTH(trim(fill_type_cd_after))==0) then fill_type_cd_after else TRIM(fill_type_cd_after) end) as fill_type_cd_after ,
update_user_id AS update_user_id , 
update_user_id_after AS update_user_id_after , 
CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm,11,19)) as update_dttm ,
CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after,11,19)) as update_dttm_after ,
(case when (LENGTH(trim(partial_fill_cd))==0) then partial_fill_cd else TRIM(partial_fill_cd) end) as partial_fill_cd ,
(case when (LENGTH(trim(partial_fill_cd_after))==0) then partial_fill_cd_after else TRIM(partial_fill_cd_after) end) as partial_fill_cd_after ,
CONCAT(CONCAT(SUBSTRING(fill_adjudication_dttm,0,10),' '),SUBSTRING(fill_adjudication_dttm,11,19)) as fill_adjudication_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_adjudication_dttm_after,0,10),' '),SUBSTRING(fill_adjudication_dttm_after,11,19)) as fill_adjudication_dttm_after ,
(case when (LENGTH(trim(cob_fill_adjudication_cd))==0) then cob_fill_adjudication_cd else TRIM(cob_fill_adjudication_cd) end) as cob_fill_adjudication_cd ,
(case when (LENGTH(trim(cob_fill_adjudication_cd_after))==0) then cob_fill_adjudication_cd_after else TRIM(cob_fill_adjudication_cd_after) end) as cob_fill_adjudication_cd_after ,
(case when (LENGTH(trim(cob_claim_ref_nbr))==0) then cob_claim_ref_nbr else TRIM(cob_claim_ref_nbr) end) as cob_claim_ref_nbr ,
(case when (LENGTH(trim(cob_claim_ref_nbr_after))==0) then cob_claim_ref_nbr_after else TRIM(cob_claim_ref_nbr_after) end) as cob_claim_ref_nbr_after ,
(case when (LENGTH(trim(cob_plan_id))==0) then cob_plan_id else TRIM(cob_plan_id) end) as cob_plan_id ,
(case when (LENGTH(trim(cob_plan_id_after))==0) then cob_plan_id_after else TRIM(cob_plan_id_after) end) as cob_plan_id_after ,
CONCAT(CONCAT(SUBSTRING(cob_fill_adj_dttm,0,10),' '),SUBSTRING(cob_fill_adj_dttm,11,19)) as cob_fill_adj_dttm ,
CONCAT(CONCAT(SUBSTRING(cob_fill_adj_dttm_after,0,10),' '),SUBSTRING(cob_fill_adj_dttm_after,11,19)) as cob_fill_adj_dttm_after ,
fill_data_rev_id AS fill_data_rev_id , 
fill_data_rev_id_after AS fill_data_rev_id_after , 
CONCAT(CONCAT(SUBSTRING(fill_data_rev_dttm,0,10),' '),SUBSTRING(fill_data_rev_dttm,11,19)) as fill_data_rev_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_data_rev_dttm_after,0,10),' '),SUBSTRING(fill_data_rev_dttm_after,11,19)) as fill_data_rev_dttm_after , filling_user_id AS filling_user_id , 
filling_user_id_after AS filling_user_id_after , 
CONCAT(CONCAT(SUBSTRING(filling_dttm,0,10),' '),SUBSTRING(filling_dttm,11,19)) as filling_dttm ,
CONCAT(CONCAT(SUBSTRING(filling_dttm_after,0,10),' '),SUBSTRING(filling_dttm_after,11,19)) as filling_dttm_after , 
override_user_id AS override_user_id , 
override_user_id_after AS override_user_id_after , 
CONCAT(CONCAT(SUBSTRING(override_dttm,0,10),' '),SUBSTRING(override_dttm,11,19)) as override_dttm ,
CONCAT(CONCAT(SUBSTRING(override_dttm_after,0,10),' '),SUBSTRING(override_dttm_after,11,19)) as override_dttm_after , 
entered_store_nbr AS entered_store_nbr , 
entered_store_nbr_after AS entered_store_nbr_after , 
reviewed_store_nbr AS reviewed_store_nbr , 
reviewed_store_nbr_after AS reviewed_store_nbr_after , 
plan_gross_due_amt AS plan_gross_due_amt , 
plan_gross_due_amt_after AS plan_gross_due_amt_after , 
cob_plan_gross_due_amt AS cob_plan_gross_due_amt , 
cob_plan_gross_due_amt_after AS cob_plan_gross_due_amt_after ,
(case when (LENGTH(trim(rx_daw_ind))==0) then rx_daw_ind else TRIM(rx_daw_ind) end) as rx_daw_ind ,
(case when (LENGTH(trim(rx_daw_ind_after))==0) then rx_daw_ind_after else TRIM(rx_daw_ind_after) end) as rx_daw_ind_after ,
(case when (LENGTH(trim(dl_reject_cd_01))==0) then dl_reject_cd_01 else TRIM(dl_reject_cd_01) end) as dl_reject_cd_01 ,
(case when (LENGTH(trim(dl_reject_cd_01_after))==0) then dl_reject_cd_01_after else TRIM(dl_reject_cd_01_after) end) as dl_reject_cd_01_after ,
(case when (LENGTH(trim(dl_reject_cd_02))==0) then dl_reject_cd_02 else TRIM(dl_reject_cd_02) end) as dl_reject_cd_02 ,
(case when (LENGTH(trim(dl_reject_cd_02_after))==0) then dl_reject_cd_02_after else TRIM(dl_reject_cd_02_after) end) as dl_reject_cd_02_after ,
(case when (LENGTH(trim(dl_reject_cd_03))==0) then dl_reject_cd_03 else TRIM(dl_reject_cd_03) end) as dl_reject_cd_03 ,
(case when (LENGTH(trim(dl_reject_cd_03_after))==0) then dl_reject_cd_03_after else TRIM(dl_reject_cd_03_after) end) as dl_reject_cd_03_after ,
(case when (LENGTH(trim(dl_reject_cd_04))==0) then dl_reject_cd_04 else TRIM(dl_reject_cd_04) end) as dl_reject_cd_04 ,
(case when (LENGTH(trim(dl_reject_cd_04_after))==0) then dl_reject_cd_04_after else TRIM(dl_reject_cd_04_after) end) as dl_reject_cd_04_after ,
(case when (LENGTH(trim(dl_reject_cd_05))==0) then dl_reject_cd_05 else TRIM(dl_reject_cd_05) end) as dl_reject_cd_05 ,
(case when (LENGTH(trim(dl_reject_cd_05_after))==0) then dl_reject_cd_05_after else TRIM(dl_reject_cd_05_after) end) as dl_reject_cd_05_after ,
(case when (LENGTH(trim(fill_del_adjudication_cd))==0) then fill_del_adjudication_cd else TRIM(fill_del_adjudication_cd) end) as fill_del_adjudication_cd ,
(case when (LENGTH(trim(fill_del_adjudication_cd_after))==0) then fill_del_adjudication_cd_after else TRIM(fill_del_adjudication_cd_after) end) as fill_del_adjudication_cd_after , fill_price_override_amt AS fill_price_override_amt , fill_price_override_amt_after AS fill_price_override_amt_after , plan_incentive_paid_amt AS plan_incentive_paid_amt , plan_incentive_paid_amt_after AS plan_incentive_paid_amt_after ,
(case when (LENGTH(trim(general_recipient_nbr))==0) then general_recipient_nbr else TRIM(general_recipient_nbr) end) as general_recipient_nbr ,
(case when (LENGTH(trim(general_recipient_nbr_after))==0) then general_recipient_nbr_after else TRIM(general_recipient_nbr_after) end) as general_recipient_nbr_after ,
(case when (LENGTH(trim(bin_nbr))==0) then bin_nbr else TRIM(bin_nbr) end) as bin_nbr ,
(case when (LENGTH(trim(bin_nbr_after))==0) then bin_nbr_after else TRIM(bin_nbr_after) end) as bin_nbr_after ,
(case when (LENGTH(trim(plan_group_nbr))==0) then plan_group_nbr else TRIM(plan_group_nbr) end) as plan_group_nbr ,
(case when (LENGTH(trim(plan_group_nbr_after))==0) then plan_group_nbr_after else TRIM(plan_group_nbr_after) end) as plan_group_nbr_after ,
(case when (LENGTH(trim(drug_warehouse_ind))==0) then drug_warehouse_ind else TRIM(drug_warehouse_ind) end) as drug_warehouse_ind ,
(case when (LENGTH(trim(drug_warehouse_ind_after))==0) then drug_warehouse_ind_after else TRIM(drug_warehouse_ind_after) end) as drug_warehouse_ind_after ,
(case when (LENGTH(trim(general_phrm_nbr))==0) then general_phrm_nbr else TRIM(general_phrm_nbr) end) as general_phrm_nbr ,
(case when (LENGTH(trim(general_phrm_nbr_after))==0) then general_phrm_nbr_after else TRIM(general_phrm_nbr_after) end) as general_phrm_nbr_after , 
CONCAT(CONCAT(SUBSTRING(fill_est_pick_up_dttm,0,10),' '),SUBSTRING(fill_est_pick_up_dttm,11,19) ) as fill_est_pick_up_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_est_pick_up_dttm_after,0,10),' '),SUBSTRING(fill_est_pick_up_dttm_after,11,19) ) as fill_est_pick_up_dttm_after , reimburs_loss_amt AS reimburs_loss_amt , reimburs_loss_amt_after AS reimburs_loss_amt_after ,
(case when (LENGTH(trim(cost_plus_fee_cd))==0) then cost_plus_fee_cd else TRIM(cost_plus_fee_cd) end) as cost_plus_fee_cd ,
(case when (LENGTH(trim(cost_plus_fee_cd_after))==0) then cost_plus_fee_cd_after else TRIM(cost_plus_fee_cd_after) end) as cost_plus_fee_cd_after ,
(case when (LENGTH(trim(accept_consult_ind))==0) then accept_consult_ind else TRIM(accept_consult_ind) end) as accept_consult_ind ,
(case when (LENGTH(trim(accept_consult_ind_after))==0) then accept_consult_ind_after else TRIM(accept_consult_ind_after) end) as accept_consult_ind_after ,
(case when (LENGTH(trim(basis_of_reimb_determ))==0) then basis_of_reimb_determ else TRIM(basis_of_reimb_determ) end) as basis_of_reimb_determ ,
(case when (LENGTH(trim(basis_of_reimb_determ_after))==0) then basis_of_reimb_determ_after else TRIM(basis_of_reimb_determ_after) end) as basis_of_reimb_determ_after , 
plan_other_amt_paid AS plan_other_amt_paid , 
plan_other_amt_paid_after AS plan_other_amt_paid_after , 
amt_attributed_to_tax AS amt_attributed_to_tax , 
amt_attributed_to_tax_after AS amt_attributed_to_tax_after , 
plan_incent_amt_submtd AS plan_incent_amt_submtd , 
plan_incent_amt_submtd_after AS plan_incent_amt_submtd_after , 
plan_other_amt_submtd AS plan_other_amt_submtd , 
plan_other_amt_submtd_after AS plan_other_amt_submtd_after ,
(case when (LENGTH(trim(lvl_of_svc_cd))==0) then lvl_of_svc_cd else TRIM(lvl_of_svc_cd) end) as lvl_of_svc_cd ,
(case when (LENGTH(trim(lvl_of_svc_cd_after))==0) then lvl_of_svc_cd_after else TRIM(lvl_of_svc_cd_after) end) as lvl_of_svc_cd_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_01))==0) then cob_dl_reject_cd_01 else TRIM(cob_dl_reject_cd_01) end) as cob_dl_reject_cd_01 ,
(case when (LENGTH(trim(cob_dl_reject_cd_01_after))==0) then cob_dl_reject_cd_01_after else TRIM(cob_dl_reject_cd_01_after) end) as cob_dl_reject_cd_01_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_02))==0) then cob_dl_reject_cd_02 else TRIM(cob_dl_reject_cd_02) end) as cob_dl_reject_cd_02 ,
(case when (LENGTH(trim(cob_dl_reject_cd_02_after))==0) then cob_dl_reject_cd_02_after else TRIM(cob_dl_reject_cd_02_after) end) as cob_dl_reject_cd_02_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_03))==0) then cob_dl_reject_cd_03 else TRIM(cob_dl_reject_cd_03) end) as cob_dl_reject_cd_03 ,
(case when (LENGTH(trim(cob_dl_reject_cd_03_after))==0) then cob_dl_reject_cd_03_after else TRIM(cob_dl_reject_cd_03_after) end) as cob_dl_reject_cd_03_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_04))==0) then cob_dl_reject_cd_04 else TRIM(cob_dl_reject_cd_04) end) as cob_dl_reject_cd_04 ,
(case when (LENGTH(trim(cob_dl_reject_cd_04_after))==0) then cob_dl_reject_cd_04_after else TRIM(cob_dl_reject_cd_04_after) end) as cob_dl_reject_cd_04_after ,
(case when (LENGTH(trim(cob_dl_reject_cd_05))==0) then cob_dl_reject_cd_05 else TRIM(cob_dl_reject_cd_05) end) as cob_dl_reject_cd_05 ,
(case when (LENGTH(trim(cob_dl_reject_cd_05_after))==0) then cob_dl_reject_cd_05_after else TRIM(cob_dl_reject_cd_05_after) end) as cob_dl_reject_cd_05_after , cob_fill_del_adj_cd AS cob_fill_del_adj_cd , cob_fill_del_adj_cd_after AS cob_fill_del_adj_cd_after ,
(case when (LENGTH(trim(cob_bin_nbr))==0) then cob_bin_nbr else TRIM(cob_bin_nbr) end) as cob_bin_nbr ,
(case when (LENGTH(trim(cob_bin_nbr_after))==0) then cob_bin_nbr_after else TRIM(cob_bin_nbr_after) end) as cob_bin_nbr_after ,
(case when (LENGTH(trim(cob_plan_group_nbr))==0) then cob_plan_group_nbr else TRIM(cob_plan_group_nbr) end) as cob_plan_group_nbr ,
(case when (LENGTH(trim(cob_plan_group_nbr_after))==0) then cob_plan_group_nbr_after else TRIM(cob_plan_group_nbr_after) end) as cob_plan_group_nbr_after ,
(case when (LENGTH(trim(cob_general_phrm_nbr))==0) then cob_general_phrm_nbr else TRIM(cob_general_phrm_nbr) end) as cob_general_phrm_nbr ,
(case when (LENGTH(trim(cob_general_phrm_nbr_after))==0) then cob_general_phrm_nbr_after else TRIM(cob_general_phrm_nbr_after) end) as cob_general_phrm_nbr_after ,
(case when (LENGTH(trim(cob_basis_of_reimb_detrm))==0) then cob_basis_of_reimb_detrm else TRIM(cob_basis_of_reimb_detrm) end) as cob_basis_of_reimb_detrm ,
(case when (LENGTH(trim(cob_basis_of_reimb_detrm_after))==0) then cob_basis_of_reimb_detrm_after else TRIM(cob_basis_of_reimb_detrm_after) end) as cob_basis_of_reimb_detrm_after , cob_amt_attrib_to_tax AS cob_amt_attrib_to_tax , cob_amt_attrib_to_tax_after AS cob_amt_attrib_to_tax_after , cob_pln_othr_amt_pd AS cob_pln_othr_amt_pd , cob_pln_othr_amt_pd_after AS cob_pln_othr_amt_pd_after , cash_disc_sav_amt AS cash_disc_sav_amt , cash_disc_sav_amt_after AS cash_disc_sav_amt_after ,
(case when (LENGTH(trim(general_rph_nbr))==0) then general_rph_nbr else TRIM(general_rph_nbr) end) as general_rph_nbr ,
(case when (LENGTH(trim(general_rph_nbr_after))==0) then general_rph_nbr_after else TRIM(general_rph_nbr_after) end) as general_rph_nbr_after ,
(case when (LENGTH(trim(routing_store_tech_inits))==0) then routing_store_tech_inits else TRIM(routing_store_tech_inits) end) as routing_store_tech_inits ,
(case when (LENGTH(trim(routing_store_tech_inits_after))==0) then routing_store_tech_inits_after else TRIM(routing_store_tech_inits_after) end) as routing_store_tech_inits_after ,
(case when (LENGTH(trim(sourcing_ind))==0) then sourcing_ind else TRIM(sourcing_ind) end) as sourcing_ind ,
(case when (LENGTH(trim(sourcing_ind_after))==0) then sourcing_ind_after else TRIM(sourcing_ind_after) end) as sourcing_ind_after ,
(case when (LENGTH(trim(maj_med_prior_auth_nbr))==0) then maj_med_prior_auth_nbr else TRIM(maj_med_prior_auth_nbr) end) as maj_med_prior_auth_nbr ,
(case when (LENGTH(trim(maj_med_prior_auth_nbr_after))==0) then maj_med_prior_auth_nbr_after else TRIM(maj_med_prior_auth_nbr_after) end) as maj_med_prior_auth_nbr_after ,
(case when (LENGTH(trim(tip_rsn_for_svc_cd))==0) then tip_rsn_for_svc_cd else TRIM(tip_rsn_for_svc_cd) end) as tip_rsn_for_svc_cd ,
(case when (LENGTH(trim(tip_rsn_for_svc_cd_after))==0) then tip_rsn_for_svc_cd_after else TRIM(tip_rsn_for_svc_cd_after) end) as tip_rsn_for_svc_cd_after ,
(case when (LENGTH(trim(data_rev_spec_id))==0) then data_rev_spec_id else TRIM(data_rev_spec_id) end) as data_rev_spec_id ,
(case when (LENGTH(trim(data_rev_spec_id_after))==0) then data_rev_spec_id_after else TRIM(data_rev_spec_id_after) end) as data_rev_spec_id_after , 
CONCAT(CONCAT(SUBSTRING(data_rev_spec_dttm,0,10),' '),SUBSTRING(data_rev_spec_dttm,11,19) ) as data_rev_spec_dttm ,
CONCAT(CONCAT(SUBSTRING(data_rev_spec_dttm_after,0,10),' '),SUBSTRING(data_rev_spec_dttm_after,11,19)) as data_rev_spec_dttm_after ,
data_rev_spec_store_nbr AS data_rev_spec_store_nbr , 
data_rev_spec_store_nbr_after AS data_rev_spec_store_nbr_after , 
fill_rph_of_record_id AS fill_rph_of_record_id , 
fill_rph_of_record_id_after AS fill_rph_of_record_id_after , 
cob_plan_incntv_paid_amt AS cob_plan_incntv_paid_amt , 
cob_plan_incntv_paid_amt_after AS cob_plan_incntv_paid_amt_after , 
cob_pln_incnt_amt_sbmtd AS cob_pln_incnt_amt_sbmtd , 
cob_pln_incnt_amt_sbmtd_after AS cob_pln_incnt_amt_sbmtd_after ,
(case when (LENGTH(trim(cob_gen_recipient_nbr))==0) then cob_gen_recipient_nbr else TRIM(cob_gen_recipient_nbr) end) as cob_gen_recipient_nbr ,
(case when (LENGTH(trim(cob_gen_recipient_nbr_after))==0) then cob_gen_recipient_nbr_after else TRIM(cob_gen_recipient_nbr_after) end) as cob_gen_recipient_nbr_after , 
celgene_md_auth_nbr AS celgene_md_auth_nbr , 
celgene_md_auth_nbr_after AS celgene_md_auth_nbr_after , 
celgene_conf_nbr AS celgene_conf_nbr , 
celgene_conf_nbr_after AS celgene_conf_nbr_after , 
plan_other_amt_paid_type AS plan_other_amt_paid_type , 
plan_other_amt_paid_type_after AS plan_other_amt_paid_type_after , 
plan_other_amt_subm_type AS plan_other_amt_subm_type , 
plan_other_amt_subm_type_after AS plan_other_amt_subm_type_after , 
plan_returnd_coins_amt AS plan_returnd_coins_amt , 
plan_returnd_coins_amt_after AS plan_returnd_coins_amt_after , 
plan_rtrnd_coins_amt AS plan_rtrnd_coins_amt , 
plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt_after , 
plan_other_amt_paid_2 AS plan_other_amt_paid_2 , 
plan_other_amt_paid_2_after AS plan_other_amt_paid_2_after , 
plan_other_amt_paid_typ2 AS plan_other_amt_paid_typ2 , 
plan_other_amt_paid_typ2_after AS plan_other_amt_paid_typ2_after , 
plan_other_amt_paid_3 AS plan_other_amt_paid_3 , 
plan_other_amt_paid_3_after AS plan_other_amt_paid_3_after , 
plan_other_amt_paid_typ3 AS plan_other_amt_paid_typ3 , 
plan_other_amt_paid_typ3_after AS plan_other_amt_paid_typ3_after , 
CONCAT(CONCAT(SUBSTRING(fill_print_dttm,0,10),' '),SUBSTRING(fill_print_dttm,11,19)) as fill_print_dttm ,
CONCAT(CONCAT(SUBSTRING(fill_print_dttm_after,0,10),' '),SUBSTRING(fill_print_dttm_after,11,19)) as fill_print_dttm_after ,
pat_lang_pref_cd AS pat_lang_pref_cd , 
pat_lang_pref_cd_after AS pat_lang_pref_cd_after , 
CONCAT(CONCAT(SUBSTRING(rebilling_dttm,0,10),' '),SUBSTRING(rebilling_dttm,11,19)) as rebilling_dttm ,
CONCAT(CONCAT(SUBSTRING((rebilling_dttm_after),0,10),' '),SUBSTRING((rebilling_dttm_after),11,19)) as rebilling_dttm_after ,
fill_90day_pref_ind AS fill_90day_pref_ind , 
fill_90day_pref_ind_after AS fill_90day_pref_ind_after , 
fill_90day_pref_stat_cd AS fill_90day_pref_stat_cd , 
fill_90day_pref_stat_cd_after AS fill_90day_pref_stat_cd_after ,
(case when (LENGTH(trim(pat_pickup_id))==0) then pat_pickup_id else TRIM(pat_pickup_id) end) as pat_pickup_id ,
(case when (LENGTH(trim(pat_pickup_id_after))==0) then pat_pickup_id_after else TRIM(pat_pickup_id_after) end) as pat_pickup_id_after ,
(case when (LENGTH(trim(pickup_id))==0) then pickup_id else TRIM(pickup_id) end) as pickup_id ,
(case when (LENGTH(trim(pickup_id_after))==0) then pickup_id_after else TRIM(pickup_id_after) end) as pickup_id_after ,
(case when (LENGTH(trim(pickup_first_name))==0) then pickup_first_name else TRIM(pickup_first_name) end) as pickup_first_name ,
(case when (LENGTH(trim(pickup_first_name_after))==0) then pickup_first_name_after else TRIM(pickup_first_name_after) end) as pickup_first_name_after ,
(case when (LENGTH(trim(pickup_last_name))==0) then pickup_last_name else TRIM(pickup_last_name) end) as pickup_last_name ,
(case when (LENGTH(trim(pickup_last_name_after))==0) then pickup_last_name_after else TRIM(pickup_last_name_after) end) as pickup_last_name_after ,
(case when (LENGTH(trim(pickup_id_state))==0) then pickup_id_state else TRIM(pickup_id_state) end) as pickup_id_state ,
(case when (LENGTH(trim(pickup_id_state_after))==0) then pickup_id_state_after else TRIM(pickup_id_state_after) end) as pickup_id_state_after ,
(case when (LENGTH(trim(pickup_id_country))==0) then pickup_id_country else TRIM(pickup_id_country) end) as pickup_id_country ,
(case when (LENGTH(trim(pickup_id_country_after))==0) then pickup_id_country_after else TRIM(pickup_id_country_after) end) as pickup_id_country_after ,
(case when (LENGTH(trim(pickup_id_qlfr))==0) then pickup_id_qlfr else TRIM(pickup_id_qlfr) end) as pickup_id_qlfr ,
(case when (LENGTH(trim(pickup_id_qlfr_after))==0) then pickup_id_qlfr_after else TRIM(pickup_id_qlfr_after) end) as pickup_id_qlfr_after ,
(case when (LENGTH(trim(pickup_rel_cd))==0) then pickup_rel_cd else TRIM(pickup_rel_cd) end) as pickup_rel_cd ,
(case when (LENGTH(trim(pickup_rel_cd_after))==0) then pickup_rel_cd_after else TRIM(pickup_rel_cd_after) end) as pickup_rel_cd_after ,
(case when (LENGTH(trim(dl_proc_msg))==0) then dl_proc_msg else TRIM(dl_proc_msg) end) as dl_proc_msg ,
(case when (LENGTH(trim(dl_proc_msg_after))==0) then dl_proc_msg_after else TRIM(dl_proc_msg_after) end) as dl_proc_msg_after ,
(case when (LENGTH(trim(cob_dl_proc_msg))==0) then cob_dl_proc_msg else TRIM(cob_dl_proc_msg) end) as cob_dl_proc_msg ,
(case when (LENGTH(trim(cob_dl_proc_msg_after))==0) then cob_dl_proc_msg_after else TRIM(cob_dl_proc_msg_after) end) as cob_dl_proc_msg_after ,
(case when (LENGTH(trim(proc_ctrl_nbr))==0) then proc_ctrl_nbr else TRIM(proc_ctrl_nbr) end) as proc_ctrl_nbr ,
(case when (LENGTH(trim(proc_ctrl_nbr_after))==0) then proc_ctrl_nbr_after else TRIM(proc_ctrl_nbr_after) end) as proc_ctrl_nbr_after ,
(case when (LENGTH(trim(med_partd_notice_ind))==0) then med_partd_notice_ind else TRIM(med_partd_notice_ind) end) as med_partd_notice_ind ,
(case when (LENGTH(trim(med_partd_notice_ind_after))==0) then med_partd_notice_ind_after else TRIM(med_partd_notice_ind_after) end) as med_partd_notice_ind_after ,
(case when (LENGTH(trim(dispensed_ndc))==0) then dispensed_ndc else TRIM(dispensed_ndc) end) as dispensed_ndc ,
(case when (LENGTH(trim(dispensed_ndc_after))==0) then dispensed_ndc_after else TRIM(dispensed_ndc_after) end) as dispensed_ndc_after ,
CONCAT(CONCAT(SUBSTRING(med_partd_print_dttm,0,10),' '),SUBSTRING(med_partd_print_dttm,11,19)) as med_partd_print_dttm , 
CONCAT(CONCAT(SUBSTRING(med_partd_print_dttm_after,0,10),' '),SUBSTRING(med_partd_print_dttm_after,11,19)) as med_partd_print_dttm_after ,
(case when (LENGTH(trim(overstock_ind))==0) then overstock_ind else TRIM(overstock_ind) end) as overstock_ind ,
(case when (LENGTH(trim(overstock_ind_after))==0) then overstock_ind_after else TRIM(overstock_ind_after) end) as overstock_ind_after ,
(case when (LENGTH(trim(ben_stg_qualifier_1))==0) then ben_stg_qualifier_1 else TRIM(ben_stg_qualifier_1) end) as ben_stg_qualifier_1 ,
(case when (LENGTH(trim(ben_stg_qualifier_1_after))==0) then ben_stg_qualifier_1_after else TRIM(ben_stg_qualifier_1_after) end) as ben_stg_qualifier_1_after ,
(case when (LENGTH(trim(ben_stg_qualifier_2))==0) then ben_stg_qualifier_2 else TRIM(ben_stg_qualifier_2) end) as ben_stg_qualifier_2 ,
(case when (LENGTH(trim(ben_stg_qualifier_2_after))==0) then ben_stg_qualifier_2_after else TRIM(ben_stg_qualifier_2_after) end) as ben_stg_qualifier_2_after ,
(case when (LENGTH(trim(ben_stg_qualifier_3))==0) then ben_stg_qualifier_3 else TRIM(ben_stg_qualifier_3) end) as ben_stg_qualifier_3 ,
(case when (LENGTH(trim(ben_stg_qualifier_3_after))==0) then ben_stg_qualifier_3_after else TRIM(ben_stg_qualifier_3_after) end) as ben_stg_qualifier_3_after ,
(case when (LENGTH(trim(ben_stg_qualifier_4))==0) then ben_stg_qualifier_4 else TRIM(ben_stg_qualifier_4) end) as ben_stg_qualifier_4 ,
(case when (LENGTH(trim(ben_stg_qualifier_4_after))==0) then ben_stg_qualifier_4_after else TRIM(ben_stg_qualifier_4_after) end) as ben_stg_qualifier_4_after ,
(case when (LENGTH(trim(ben_stg_amount_1))==0) then ben_stg_amount_1 else TRIM(ben_stg_amount_1) end) as ben_stg_amount_1 ,
(case when (LENGTH(trim(ben_stg_amount_1_after))==0) then ben_stg_amount_1_after else TRIM(ben_stg_amount_1_after) end) as ben_stg_amount_1_after ,
(case when (LENGTH(trim(ben_stg_amount_2))==0) then ben_stg_amount_2 else TRIM(ben_stg_amount_2) end) as ben_stg_amount_2 ,
(case when (LENGTH(trim(ben_stg_amount_2_after))==0) then ben_stg_amount_2_after else TRIM(ben_stg_amount_2_after) end) as ben_stg_amount_2_after ,
(case when (LENGTH(trim(ben_stg_amount_3))==0) then ben_stg_amount_3 else TRIM(ben_stg_amount_3) end) as ben_stg_amount_3 ,
(case when (LENGTH(trim(ben_stg_amount_3_after))==0) then ben_stg_amount_3_after else TRIM(ben_stg_amount_3_after) end) as ben_stg_amount_3_after ,
(case when (LENGTH(trim(ben_stg_amount_4))==0) then ben_stg_amount_4 else TRIM(ben_stg_amount_4) end) as ben_stg_amount_4 ,
(case when (LENGTH(trim(ben_stg_amount_4_after))==0) then ben_stg_amount_4_after else TRIM(ben_stg_amount_4_after) end) as ben_stg_amount_4_after ,
(case when (LENGTH(trim(coupon_drug_id))==0) then coupon_drug_id else TRIM(coupon_drug_id) end) as coupon_drug_id ,
(case when (LENGTH(trim(coupon_drug_id_after))==0) then coupon_drug_id_after else TRIM(coupon_drug_id_after) end) as coupon_drug_id_after ,
(case when (LENGTH(trim(cob_coupon_drug_id))==0) then cob_coupon_drug_id else TRIM(cob_coupon_drug_id) end) as cob_coupon_drug_id ,
(case when (LENGTH(trim(cob_coupon_drug_id_after))==0) then cob_coupon_drug_id_after else TRIM(cob_coupon_drug_id_after) end) as cob_coupon_drug_id_after ,
(case when (LENGTH(trim(coupon_ind))==0) then coupon_ind else TRIM(coupon_ind) end) as coupon_ind ,
(case when (LENGTH(trim(coupon_ind_after))==0) then coupon_ind_after else TRIM(coupon_ind_after) end) as coupon_ind_after ,
(case when (LENGTH(trim(cob_coupon_ind))==0) then cob_coupon_ind else TRIM(cob_coupon_ind) end) as cob_coupon_ind ,
(case when (LENGTH(trim(cob_coupon_ind_after))==0) then cob_coupon_ind_after else TRIM(cob_coupon_ind_after) end) as cob_coupon_ind_after ,
(case when (LENGTH(trim(other_coverage_cd))==0) then other_coverage_cd else TRIM(other_coverage_cd) end) as other_coverage_cd ,
(case when (LENGTH(trim(other_coverage_cd_after))==0) then other_coverage_cd_after else TRIM(other_coverage_cd_after) end) as other_coverage_cd_after ,
(case when (LENGTH(trim(cob_other_coverage_cd))==0) then cob_other_coverage_cd else TRIM(cob_other_coverage_cd) end) as cob_other_coverage_cd ,
(case when (LENGTH(trim(cob_other_coverage_cd_after))==0) then cob_other_coverage_cd_after else TRIM(cob_other_coverage_cd_after) end) as cob_other_coverage_cd_after ,
(case when (LENGTH(trim(partial_fil_intnded_qty))==0) then partial_fil_intnded_qty else TRIM(partial_fil_intnded_qty) end) as partial_fil_intnded_qty ,
(case when (LENGTH(trim(partial_fil_intnded_qty_after))==0) then partial_fil_intnded_qty_after else TRIM(partial_fil_intnded_qty_after) end) as partial_fil_intnded_qty_after ,
(case when (LENGTH(trim(triplicate_serial_nbr))==0) then triplicate_serial_nbr else TRIM(triplicate_serial_nbr) end) as triplicate_serial_nbr ,
(case when (LENGTH(trim(triplicate_serial_nbr_after))==0) then triplicate_serial_nbr_after else TRIM(triplicate_serial_nbr_after) end) as triplicate_serial_nbr_after ,
(case when (LENGTH(trim(source_system_name))==0) then source_system_name else TRIM(source_system_name) end) as source_system_name ,
(case when (LENGTH(trim(source_system_name_after))==0) then source_system_name_after else TRIM(source_system_name_after) end) as source_system_name_after ,
(case when (LENGTH(trim(source_sys_trans_id))==0) then source_sys_trans_id else TRIM(source_sys_trans_id) end) as source_sys_trans_id ,
(case when (LENGTH(trim(source_sys_trans_id_after))==0) then source_sys_trans_id_after else TRIM(source_sys_trans_id_after) end) as source_sys_trans_id_after ,
(case when (LENGTH(trim(delivery_ind))==0) then delivery_ind else TRIM(delivery_ind) end) as delivery_ind ,
(case when (LENGTH(trim(delivery_ind_after))==0) then delivery_ind_after else TRIM(delivery_ind_after) end) as delivery_ind_after ,
(case when (LENGTH(trim(delivery_comments))==0) then delivery_comments else TRIM(delivery_comments) end) as delivery_comments ,
(case when (LENGTH(trim(delivery_comments_after))==0) then delivery_comments_after else TRIM(delivery_comments_after) end) as delivery_comments_after ,
(case when (LENGTH(trim(approved_msg_cd))==0) then approved_msg_cd else TRIM(approved_msg_cd) end) as approved_msg_cd ,
(case when (LENGTH(trim(approved_msg_cd_after))==0) then approved_msg_cd_after else TRIM(approved_msg_cd_after) end) as approved_msg_cd_after ,
(case when (LENGTH(trim(approved_msg_cd_2))==0) then approved_msg_cd_2 else TRIM(approved_msg_cd_2) end) as approved_msg_cd_2 ,
(case when (LENGTH(trim(approved_msg_cd_2_after))==0) then approved_msg_cd_2_after else TRIM(approved_msg_cd_2_after) end) as approved_msg_cd_2_after ,
(case when (LENGTH(trim(approved_msg_cd_3))==0) then approved_msg_cd_3 else TRIM(approved_msg_cd_3) end) as approved_msg_cd_3 ,
(case when (LENGTH(trim(approved_msg_cd_3_after))==0) then approved_msg_cd_3_after else TRIM(approved_msg_cd_3_after) end) as approved_msg_cd_3_after ,
(case when (LENGTH(trim(approved_msg_cd_4))==0) then approved_msg_cd_4 else TRIM(approved_msg_cd_4) end) as approved_msg_cd_4 ,
(case when (LENGTH(trim(approved_msg_cd_4_after))==0) then approved_msg_cd_4_after else TRIM(approved_msg_cd_4_after) end) as approved_msg_cd_4_after ,
(case when (LENGTH(trim(approved_msg_cd_5))==0) then approved_msg_cd_5 else TRIM(approved_msg_cd_5) end) as approved_msg_cd_5 ,
(case when (LENGTH(trim(approved_msg_cd_5_after))==0) then approved_msg_cd_5_after else TRIM(approved_msg_cd_5_after) end) as approved_msg_cd_5_after ,
(case when (LENGTH(trim(cob_approved_msg_cd))==0) then cob_approved_msg_cd else TRIM(cob_approved_msg_cd) end) as cob_approved_msg_cd ,
(case when (LENGTH(trim(cob_approved_msg_cd_after))==0) then cob_approved_msg_cd_after else TRIM(cob_approved_msg_cd_after) end) as cob_approved_msg_cd_after ,
(case when (LENGTH(trim(cob_approved_msg_cd_2))==0) then cob_approved_msg_cd_2 else TRIM(cob_approved_msg_cd_2) end) as cob_approved_msg_cd_2 ,
(case when (LENGTH(trim(cob_approved_msg_cd_2_after))==0) then cob_approved_msg_cd_2_after else TRIM(cob_approved_msg_cd_2_after) end) as cob_approved_msg_cd_2_after ,
(case when (LENGTH(trim(cob_approved_msg_cd_3))==0) then cob_approved_msg_cd_3 else TRIM(cob_approved_msg_cd_3) end) as cob_approved_msg_cd_3 ,
(case when (LENGTH(trim(cob_approved_msg_cd_3_after))==0) then cob_approved_msg_cd_3_after else TRIM(cob_approved_msg_cd_3_after) end) as cob_approved_msg_cd_3_after ,
(case when (LENGTH(trim(cob_approved_msg_cd_4))==0) then cob_approved_msg_cd_4 else TRIM(cob_approved_msg_cd_4) end) as cob_approved_msg_cd_4 ,
(case when (LENGTH(trim(cob_approved_msg_cd_4_after))==0) then cob_approved_msg_cd_4_after else TRIM(cob_approved_msg_cd_4_after) end) as cob_approved_msg_cd_4_after ,
(case when (LENGTH(trim(cob_approved_msg_cd_5))==0) then cob_approved_msg_cd_5 else TRIM(cob_approved_msg_cd_5) end) as cob_approved_msg_cd_5 ,
(case when (LENGTH(trim(cob_approved_msg_cd_5_after))==0) then cob_approved_msg_cd_5_after else TRIM(cob_approved_msg_cd_5_after) end) as cob_approved_msg_cd_5_after ,
(case when (LENGTH(trim(cob_general_pbr_nbr))==0) then cob_general_pbr_nbr else TRIM(cob_general_pbr_nbr) end) as cob_general_pbr_nbr ,
(case when (LENGTH(trim(cob_general_pbr_nbr_after))==0) then cob_general_pbr_nbr_after else TRIM(cob_general_pbr_nbr_after) end) as cob_general_pbr_nbr_after , cob_place_of_service AS cob_place_of_service , cob_place_of_service_after AS cob_place_of_service_after ,
(case when (LENGTH(trim(cob_plan_tax_exempt_ind))==0) then cob_plan_tax_exempt_ind else TRIM(cob_plan_tax_exempt_ind) end) as cob_plan_tax_exempt_ind ,
(case when (LENGTH(trim(cob_plan_tax_exempt_ind_after))==0) then cob_plan_tax_exempt_ind_after else TRIM(cob_plan_tax_exempt_ind_after) end) as cob_plan_tax_exempt_ind_after ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd))==0) then cob_rx_denial_ovride_cd else TRIM(cob_rx_denial_ovride_cd) end) as cob_rx_denial_ovride_cd ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd_after))==0) then cob_rx_denial_ovride_cd_after else TRIM(cob_rx_denial_ovride_cd_after) end) as cob_rx_denial_ovride_cd_after ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd2))==0) then cob_rx_denial_ovride_cd2 else TRIM(cob_rx_denial_ovride_cd2) end) as cob_rx_denial_ovride_cd2 ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd2_after))==0) then cob_rx_denial_ovride_cd2_after else TRIM(cob_rx_denial_ovride_cd2_after) end) as cob_rx_denial_ovride_cd2_after ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd3))==0) then cob_rx_denial_ovride_cd3 else TRIM(cob_rx_denial_ovride_cd3) end) as cob_rx_denial_ovride_cd3 ,
(case when (LENGTH(trim(cob_rx_denial_ovride_cd3_after))==0) then cob_rx_denial_ovride_cd3_after else TRIM(cob_rx_denial_ovride_cd3_after) end) as cob_rx_denial_ovride_cd3_after ,
(case when (LENGTH(trim(cob_tax_exempt_plan_ind))==0) then cob_tax_exempt_plan_ind else TRIM(cob_tax_exempt_plan_ind) end) as cob_tax_exempt_plan_ind ,
(case when (LENGTH(trim(cob_tax_exempt_plan_ind_after))==0) then cob_tax_exempt_plan_ind_after else TRIM(cob_tax_exempt_plan_ind_after) end) as cob_tax_exempt_plan_ind_after ,
(case when (LENGTH(trim(gen_recip_nbr_returnd))==0) then gen_recip_nbr_returnd else TRIM(gen_recip_nbr_returnd) end) as gen_recip_nbr_returnd ,
(case when (LENGTH(trim(gen_recip_nbr_returnd_after))==0) then gen_recip_nbr_returnd_after else TRIM(gen_recip_nbr_returnd_after) end) as gen_recip_nbr_returnd_after ,
(case when (LENGTH(trim(general_pbr_nbr))==0) then general_pbr_nbr else TRIM(general_pbr_nbr) end) as general_pbr_nbr ,
(case when (LENGTH(trim(general_pbr_nbr_after))==0) then general_pbr_nbr_after else TRIM(general_pbr_nbr_after) end) as general_pbr_nbr_after ,
(case when (LENGTH(trim(general_rph_nbr_qlfr))==0) then general_rph_nbr_qlfr else TRIM(general_rph_nbr_qlfr) end) as general_rph_nbr_qlfr ,
(case when (LENGTH(trim(general_rph_nbr_qlfr_after))==0) then general_rph_nbr_qlfr_after else TRIM(general_rph_nbr_qlfr_after) end) as general_rph_nbr_qlfr_after ,
(case when (LENGTH(trim(medigap_id))==0) then medigap_id else TRIM(medigap_id) end) as medigap_id ,
(case when (LENGTH(trim(medigap_id_after))==0) then medigap_id_after else TRIM(medigap_id_after) end) as medigap_id_after ,
(case when (LENGTH(trim(ntwk_reimb_id_returnd))==0) then ntwk_reimb_id_returnd else TRIM(ntwk_reimb_id_returnd) end) as ntwk_reimb_id_returnd ,
(case when (LENGTH(trim(ntwk_reimb_id_returnd_after))==0) then ntwk_reimb_id_returnd_after else TRIM(ntwk_reimb_id_returnd_after) end) as ntwk_reimb_id_returnd_after ,
(case when (LENGTH(trim(pat_pickup_gov_auth_id))==0) then pat_pickup_gov_auth_id else TRIM(pat_pickup_gov_auth_id) end) as pat_pickup_gov_auth_id ,
(case when (LENGTH(trim(pat_pickup_gov_auth_id_after))==0) then pat_pickup_gov_auth_id_after else TRIM(pat_pickup_gov_auth_id_after) end) as pat_pickup_gov_auth_id_after ,
(case when (LENGTH(trim(pat_pickup_rel_cd))==0) then pat_pickup_rel_cd else TRIM(pat_pickup_rel_cd) end) as pat_pickup_rel_cd ,
(case when (LENGTH(trim(pat_pickup_rel_cd_after))==0) then pat_pickup_rel_cd_after else TRIM(pat_pickup_rel_cd_after) end) as pat_pickup_rel_cd_after , place_of_service AS place_of_service , place_of_service_after AS place_of_service_after ,
(case when (LENGTH(trim(plan_id_returnd))==0) then plan_id_returnd else TRIM(plan_id_returnd) end) as plan_id_returnd ,
(case when (LENGTH(trim(plan_id_returnd_after))==0) then plan_id_returnd_after else TRIM(plan_id_returnd_after) end) as plan_id_returnd_after ,
(case when (LENGTH(trim(plan_returnd_grp_nbr))==0) then plan_returnd_grp_nbr else TRIM(plan_returnd_grp_nbr) end) as plan_returnd_grp_nbr ,
(case when (LENGTH(trim(plan_returnd_grp_nbr_after))==0) then plan_returnd_grp_nbr_after else TRIM(plan_returnd_grp_nbr_after) end) as plan_returnd_grp_nbr_after ,
(case when (LENGTH(trim(plan_tax_exempt_ind))==0) then plan_tax_exempt_ind else TRIM(plan_tax_exempt_ind) end) as plan_tax_exempt_ind ,
(case when (LENGTH(trim(plan_tax_exempt_ind_after))==0) then plan_tax_exempt_ind_after else TRIM(plan_tax_exempt_ind_after) end) as plan_tax_exempt_ind_after ,
(case when (LENGTH(trim(prior_auth_cd))==0) then prior_auth_cd else TRIM(prior_auth_cd) end) as prior_auth_cd ,
(case when (LENGTH(trim(prior_auth_cd_after))==0) then prior_auth_cd_after else TRIM(prior_auth_cd_after) end) as prior_auth_cd_after ,
(case when (LENGTH(trim(prior_auth_nbr))==0) then prior_auth_nbr else TRIM(prior_auth_nbr) end) as prior_auth_nbr ,
(case when (LENGTH(trim(prior_auth_nbr_after))==0) then prior_auth_nbr_after else TRIM(prior_auth_nbr_after) end) as prior_auth_nbr_after ,
(case when (LENGTH(trim(routing_store_rph_inits))==0) then routing_store_rph_inits else TRIM(routing_store_rph_inits) end) as routing_store_rph_inits ,
(case when (LENGTH(trim(routing_store_rph_inits_after))==0) then routing_store_rph_inits_after else TRIM(routing_store_rph_inits_after) end) as routing_store_rph_inits_after ,
(case when (LENGTH(trim(rx_denial_override_cd))==0) then rx_denial_override_cd else TRIM(rx_denial_override_cd) end) as rx_denial_override_cd ,
(case when (LENGTH(trim(rx_denial_override_cd_after))==0) then rx_denial_override_cd_after else TRIM(rx_denial_override_cd_after) end) as rx_denial_override_cd_after ,
(case when (LENGTH(trim(rx_denial_override_cd_2))==0) then rx_denial_override_cd_2 else TRIM(rx_denial_override_cd_2) end) as rx_denial_override_cd_2 ,
(case when (LENGTH(trim(rx_denial_override_cd_2_after))==0) then rx_denial_override_cd_2_after else TRIM(rx_denial_override_cd_2_after) end) as rx_denial_override_cd_2_after ,
(case when (LENGTH(trim(rx_denial_override_cd_3))==0) then rx_denial_override_cd_3 else TRIM(rx_denial_override_cd_3) end) as rx_denial_override_cd_3 ,
(case when (LENGTH(trim(rx_denial_override_cd_3_after))==0) then rx_denial_override_cd_3_after else TRIM(rx_denial_override_cd_3_after) end) as rx_denial_override_cd_3_after , sys_status_when_ent AS sys_status_when_ent , sys_status_when_ent_after AS sys_status_when_ent_after ,
(case when (LENGTH(trim(tax_exempt_plan_ind))==0) then tax_exempt_plan_ind else TRIM(tax_exempt_plan_ind) end) as tax_exempt_plan_ind ,
(case when (LENGTH(trim(tax_exempt_plan_ind_after))==0) then tax_exempt_plan_ind_after else TRIM(tax_exempt_plan_ind_after) end) as tax_exempt_plan_ind_after ,
(case when (LENGTH(trim(pat_pickup_id_qlfr))==0) then pat_pickup_id_qlfr else TRIM(pat_pickup_id_qlfr) end) as pat_pickup_id_qlfr ,
(case when (LENGTH(trim(pat_pickup_id_qlfr_after))==0) then pat_pickup_id_qlfr_after else TRIM(pat_pickup_id_qlfr_after) end) as pat_pickup_id_qlfr_after , 
CONCAT(CONCAT(SUBSTRING(proc_local_dttm,0,10),' '),SUBSTRING(proc_local_dttm,11,19)) as proc_local_dttm ,
CONCAT(CONCAT(SUBSTRING(proc_local_dttm_after,0,10),' '),SUBSTRING(proc_local_dttm_after,11,19)) as proc_local_dttm_after ,
CONCAT(CONCAT(SUBSTRING(proc_del_local_dttm,0,10),' '),SUBSTRING(proc_del_local_dttm,11,19)) as proc_del_local_dttm , 
CONCAT(CONCAT(SUBSTRING(proc_del_local_dttm_after,0,10),' '),SUBSTRING(proc_del_local_dttm_after,11,19)) as proc_del_local_dttm_after ,
CONCAT(CONCAT(SUBSTRING(timeout_local_dttm,0,10),' '),SUBSTRING(timeout_local_dttm,11,19)) as timeout_local_dttm , 
CONCAT(CONCAT(SUBSTRING(timeout_local_dttm_after,0,10),' '),SUBSTRING(timeout_local_dttm_after,11,19)) as timeout_local_dttm_after , 
CONCAT(CONCAT(SUBSTRING(timeout_del_local_dttm,0,10),' '),SUBSTRING(timeout_del_local_dttm,11,19) ) as timeout_del_local_dttm , 
CONCAT(CONCAT(SUBSTRING(timeout_del_local_dttm_after,0,10),' '),SUBSTRING(timeout_del_local_dttm_after,11,19)) as timeout_del_local_dttm_after , 
CONCAT(CONCAT(SUBSTRING(sold_local_dttm,0,10),' '),SUBSTRING(sold_local_dttm,11,19) ) as sold_local_dttm ,
CONCAT(CONCAT(SUBSTRING(sold_local_dttm_after,0,10),' '),SUBSTRING(sold_local_dttm_after,11,19) ) as sold_local_dttm_after , 
CONCAT(CONCAT(SUBSTRING(cob_proc_local_dttm,0,10),' '),SUBSTRING(cob_proc_local_dttm,11,19) ) as cob_proc_local_dttm , 
CONCAT(CONCAT(SUBSTRING(cob_proc_local_dttm_after,0,10),' '),SUBSTRING(cob_proc_local_dttm_after,11,19) ) as cob_proc_local_dttm_after ,
CONCAT(CONCAT(SUBSTRING(cob_proc_del_local_dttm,0,10),' '),SUBSTRING(cob_proc_del_local_dttm,11,19) ) as cob_proc_del_local_dttm ,
CONCAT(CONCAT(SUBSTRING(cob_proc_del_local_dttm_after,0,10),' '),SUBSTRING(cob_proc_del_local_dttm_after,11,19) ) as cob_proc_del_local_dttm_after , 
CONCAT(CONCAT(SUBSTRING(cob_tmout_lcl_dttm,0,10),' '),SUBSTRING(cob_tmout_lcl_dttm,11,19) ) as cob_tmout_lcl_dttm , 
CONCAT(CONCAT(SUBSTRING(cob_tmout_lcl_dttm_after,0,10),' '),SUBSTRING(cob_tmout_lcl_dttm_after,11,19) ) as cob_tmout_lcl_dttm_after , 
CONCAT(CONCAT(SUBSTRING(cob_tmout_del_lcl_dttm,0,10),' '),SUBSTRING(cob_tmout_del_lcl_dttm,11,19) ) as cob_tmout_del_lcl_dttm , 
CONCAT(CONCAT(SUBSTRING(cob_tmout_del_lcl_dttm_after,0,10),' '),SUBSTRING(cob_tmout_del_lcl_dttm_after,11,19) ) as cob_tmout_del_lcl_dttm_after ,
(case when (LENGTH(trim(db_cob_proc_ctrl_nbr))==0) then db_cob_proc_ctrl_nbr else TRIM(db_cob_proc_ctrl_nbr) end) as db_cob_proc_ctrl_nbr ,
(case when (LENGTH(trim(db_cob_proc_ctrl_nbr_after))==0) then db_cob_proc_ctrl_nbr_after else TRIM(db_cob_proc_ctrl_nbr_after) end) as db_cob_proc_ctrl_nbr_after , 
CONCAT(CONCAT(SUBSTRING(org_entered_dttm,0,10),' '),SUBSTRING(org_entered_dttm,11,19) ) as org_entered_dttm ,
CONCAT(CONCAT(SUBSTRING(org_entered_dttm_after,0,10),' '),SUBSTRING(org_entered_dttm_after,11,19)) as org_entered_dttm_after ,
(case when (LENGTH(trim(dl_addl_msg_qlfr))==0) then dl_addl_msg_qlfr else TRIM(dl_addl_msg_qlfr) end) as dl_addl_msg_qlfr ,
(case when (LENGTH(trim(dl_addl_msg_qlfr_after))==0) then dl_addl_msg_qlfr_after else TRIM(dl_addl_msg_qlfr_after) end) as dl_addl_msg_qlfr_after ,
(case when (LENGTH(trim(dl_additional_msg))==0) then dl_additional_msg else TRIM(dl_additional_msg) end) as dl_additional_msg ,
(case when (LENGTH(trim(dl_additional_msg_after))==0) then dl_additional_msg_after else TRIM(dl_additional_msg_after) end) as dl_additional_msg_after ,
(case when (LENGTH(trim(wo_correlation_id))==0) then wo_correlation_id else TRIM(wo_correlation_id) end) as wo_correlation_id ,
(case when (LENGTH(trim(wo_correlation_id_after))==0) then wo_correlation_id_after else TRIM(wo_correlation_id_after) end) as wo_correlation_id_after  ,
(case when (LENGTH(trim(wo_rx_count))==0) then wo_rx_count else TRIM(wo_rx_count) end) as wo_rx_count ,
(case when (LENGTH(trim(wo_rx_count_after))==0) then wo_rx_count_after else TRIM(wo_rx_count_after) end) as wo_rx_count_after  ,
(case when (LENGTH(trim(short_fill_ind))==0) then short_fill_ind else TRIM(short_fill_ind) end) as short_fill_ind ,
(case when (LENGTH(trim(short_fill_ind_after))==0) then short_fill_ind_after else TRIM(short_fill_ind_after) end) as short_fill_ind_after ,
(case when (LENGTH(trim(pay_cd))==0) then pay_cd else TRIM(pay_cd) end) as pay_cd ,
(case when (LENGTH(trim(pay_cd_after))==0) then pay_cd_after else TRIM(pay_cd_after) end) as pay_cd_after ,
(case when (LENGTH(trim(filling_store_nbr))==0) then filling_store_nbr else TRIM(filling_store_nbr) end) as filling_store_nbr ,
(case when (LENGTH(trim(filling_store_nbr_after))==0) then filling_store_nbr_after else TRIM(filling_store_nbr_after) end) as filling_store_nbr_after ,
(case when (LENGTH(trim(fill_verified_store_nbr))==0) then fill_verified_store_nbr else TRIM(fill_verified_store_nbr) end) as fill_verified_store_nbr ,
(case when (LENGTH(trim(fill_verified_store_nbr_after))==0) then fill_verified_store_nbr_after else TRIM(fill_verified_store_nbr_after) end) as fill_verified_store_nbr_after ,
(case when (LENGTH(trim(mult_prod_review_ind))==0) then mult_prod_review_ind else TRIM(mult_prod_review_ind) end) as mult_prod_review_ind,
(case when (LENGTH(trim(mult_prod_review_ind_after))==0) then mult_prod_review_ind_after else TRIM(mult_prod_review_ind_after) end) as mult_prod_review_ind_after,
(case when (LENGTH(trim(pat_selct_user_id))==0) then pat_selct_user_id else TRIM(pat_selct_user_id) end) as pat_selct_user_id,
(case when (LENGTH(trim(pat_selct_user_id_after))==0) then pat_selct_user_id_after else TRIM(pat_selct_user_id_after) end) as pat_selct_user_id_after,
(case when (LENGTH(trim(pbr_selct_user_id))==0) then pbr_selct_user_id else TRIM(pbr_selct_user_id) end) as pbr_selct_user_id,
(case when (LENGTH(trim(pbr_selct_user_id_after))==0) then pbr_selct_user_id_after else TRIM(pbr_selct_user_id_after) end) as pbr_selct_user_id_after,
(case when (LENGTH(trim(pat_selct_dttm))==0) then pat_selct_dttm else TRIM(pat_selct_dttm) end) as pat_selct_dttm,
(case when (LENGTH(trim(pat_selct_dttm_after))==0) then pat_selct_dttm_after else TRIM(pat_selct_dttm_after) end) as pat_selct_dttm_after,
(case when (LENGTH(trim(pbr_selct_dttm))==0) then pbr_selct_dttm else TRIM(pbr_selct_dttm) end) as pbr_selct_dttm,
(case when (LENGTH(trim(pbr_selct_dttm_after))==0) then pbr_selct_dttm_after else TRIM(pbr_selct_dttm_after) end) as pbr_selct_dttm_after,
(case when (LENGTH(trim(pat_selct_str_nbr))==0) then pat_selct_str_nbr else TRIM(pat_selct_str_nbr) end) as pat_selct_str_nbr,
(case when (LENGTH(trim(pat_selct_str_nbr_after))==0) then pat_selct_str_nbr_after else TRIM(pat_selct_str_nbr_after) end) as pat_selct_str_nbr_after,
(case when (LENGTH(trim(pbr_selct_str_nbr))==0) then pbr_selct_str_nbr else TRIM(pbr_selct_str_nbr) end) as pbr_selct_str_nbr,
(case when (LENGTH(trim(pbr_selct_str_nbr_after))==0) then pbr_selct_str_nbr_after else TRIM(pbr_selct_str_nbr_after) end) as pbr_selct_str_nbr_after,
(case when (LENGTH(trim(ntt_ind))==0) then ntt_ind else TRIM(ntt_ind) end) as ntt_ind,
(case when (LENGTH(trim(ntt_ind_after))==0) then ntt_ind_after else TRIM(ntt_ind_after) end) as ntt_ind_after,
(case when (LENGTH(trim(pdmp_sel_ind))==0) then pdmp_sel_ind else trim(pdmp_sel_ind) end) as pdmp_sel_ind,
(case when (LENGTH(trim(pdmp_sel_ind_after))==0) then pdmp_sel_ind_after else trim(pdmp_sel_ind_after) end) as pdmp_sel_ind_after,
(case when (LENGTH(trim(pdmp_click_store_nbr))==0) then pdmp_click_store_nbr else trim(pdmp_click_store_nbr) end) as pdmp_click_store_nbr,
(case when (LENGTH(trim(pdmp_click_store_nbr_after))==0) then pdmp_click_store_nbr_after else trim(pdmp_click_store_nbr_after) end) as pdmp_click_store_nbr_after,
(case when (LENGTH(trim(pdmp_click_user_id))==0) then pdmp_click_user_id else trim(pdmp_click_user_id) end) as pdmp_click_user_id,
(case when (LENGTH(trim(pdmp_click_user_id_after))==0) then pdmp_click_user_id_after else trim(pdmp_click_user_id_after) end) as pdmp_click_user_id_after,
(case when (LENGTH(trim(pdmp_click_dttm))==0) then pdmp_click_dttm else trim(pdmp_click_dttm) end) as pdmp_click_dttm,
(case when (LENGTH(trim(pdmp_click_dttm_after))==0) then pdmp_click_dttm_after else trim(pdmp_click_dttm_after) end) as pdmp_click_dttm_after from dedup_group""" 

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
# display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 


gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , refills_remaining_after AS refills_remaining , fill_wac_cost_amt_after AS fill_wac_cost_amt , plan_returnd_cost_amt_after AS plan_returnd_cost_amt , plan_returnd_fee_amt_after AS plan_returnd_fee_amt , plan_submtd_copay_amt_after AS plan_submtd_copay_amt , pbr_id_after AS pbr_id , fill_source_cd_after AS fill_source_cd , refills_remain_when_ent_after AS refills_remain_when_ent , cob_plan_rtrnd_fee_amt_after AS cob_plan_rtrnd_fee_amt , tot_amt_paid_ind_after AS tot_amt_paid_ind , drug_class_after AS drug_class , drug_name_after AS drug_name , drug_id_after AS drug_id , plan_returnd_copay_amt_after AS plan_returnd_copay_amt , plan_total_paid_amt_after AS plan_total_paid_amt , plan_returnd_tax_amt_after AS plan_returnd_tax_amt , plan_submtd_cost_amt_after AS plan_submtd_cost_amt , plan_submtd_fee_amt_after AS plan_submtd_fee_amt , plan_submtd_tax_amt_after AS plan_submtd_tax_amt , pat_id_after AS pat_id , sims_upc_after AS sims_upc , pbr_loc_id_after AS pbr_loc_id , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , cob_plan_rtrnd_copay_amt_after AS cob_plan_rtrnd_copay_amt , cob_plan_total_paid_amt_after AS cob_plan_total_paid_amt , cob_plan_rtrnd_cost_amt_after AS cob_plan_rtrnd_cost_amt , cob_plan_rtrnd_tax_amt_after AS cob_plan_rtrnd_tax_amt , cob_plan_sbmtd_copay_amt_after AS cob_plan_sbmtd_copay_amt , cob_plan_sbmtd_cost_amt_after AS cob_plan_sbmtd_cost_amt , cob_plan_sbmtd_fee_amt_after AS cob_plan_sbmtd_fee_amt , cob_plan_sbmtd_tax_amt_after AS cob_plan_sbmtd_tax_amt , src_partition_nbr_after AS src_partition_nbr , fill_adjudication_cd_after AS fill_adjudication_cd , fill_awp_cost_amt_after AS fill_awp_cost_amt , fill_days_supply_after AS fill_days_supply , fill_entered_dttm_after AS fill_entered_dttm , fill_label_price_amt_after AS fill_label_price_amt , fill_qty_dispensed_after AS fill_qty_dispensed , fill_retail_price_amt_after AS fill_retail_price_amt , claim_reference_nbr_after AS claim_reference_nbr , fill_nbr_dispensed_after AS fill_nbr_dispensed , plan_id_after AS plan_id , fill_status_cd_after AS fill_status_cd , fill_entered_user_id_after AS fill_entered_user_id , fill_verified_user_id_after AS fill_verified_user_id , fill_verified_dttm_after AS fill_verified_dttm , fill_sold_dttm_after AS fill_sold_dttm , fill_deleted_dttm_after AS fill_deleted_dttm , fill_discount_cd_after AS fill_discount_cd , fill_pay_method_cd_after AS fill_pay_method_cd , fill_discount_amt_after AS fill_discount_amt , fill_sold_amt_after AS fill_sold_amt , fill_type_cd_after AS fill_type_cd , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , partial_fill_cd_after AS partial_fill_cd , fill_adjudication_dttm_after AS fill_adjudication_dttm , cob_fill_adjudication_cd_after AS cob_fill_adjudication_cd , cob_claim_ref_nbr_after AS cob_claim_ref_nbr , cob_plan_id_after AS cob_plan_id , cob_fill_adj_dttm_after AS cob_fill_adj_dttm , fill_data_rev_id_after AS fill_data_rev_id , fill_data_rev_dttm_after AS fill_data_rev_dttm , filling_user_id_after AS filling_user_id , filling_dttm_after AS filling_dttm , override_user_id_after AS override_user_id , override_dttm_after AS override_dttm , entered_store_nbr_after AS entered_store_nbr , reviewed_store_nbr_after AS reviewed_store_nbr , plan_gross_due_amt_after AS plan_gross_due_amt , cob_plan_gross_due_amt_after AS cob_plan_gross_due_amt , rx_daw_ind_after AS rx_daw_ind , dl_reject_cd_01_after AS dl_reject_cd_01 , dl_reject_cd_02_after AS dl_reject_cd_02 , dl_reject_cd_03_after AS dl_reject_cd_03 , dl_reject_cd_04_after AS dl_reject_cd_04 , dl_reject_cd_05_after AS dl_reject_cd_05 , fill_del_adjudication_cd_after AS fill_del_adjudication_cd , fill_price_override_amt_after AS fill_price_override_amt , plan_incentive_paid_amt_after AS plan_incentive_paid_amt , general_recipient_nbr_after AS general_recipient_nbr , bin_nbr_after AS bin_nbr , plan_group_nbr_after AS plan_group_nbr , drug_warehouse_ind_after AS drug_warehouse_ind , general_phrm_nbr_after AS general_phrm_nbr , fill_est_pick_up_dttm_after AS fill_est_pick_up_dttm , reimburs_loss_amt_after AS reimburs_loss_amt , cost_plus_fee_cd_after AS cost_plus_fee_cd , accept_consult_ind_after AS accept_consult_ind , basis_of_reimb_determ_after AS basis_of_reimb_determ , plan_other_amt_paid_after AS plan_other_amt_paid , amt_attributed_to_tax_after AS amt_attributed_to_tax , plan_incent_amt_submtd_after AS plan_incent_amt_submtd , plan_other_amt_submtd_after AS plan_other_amt_submtd , lvl_of_svc_cd_after AS lvl_of_svc_cd , cob_dl_reject_cd_01_after AS cob_dl_reject_cd_01 , cob_dl_reject_cd_02_after AS cob_dl_reject_cd_02 , cob_dl_reject_cd_03_after AS cob_dl_reject_cd_03 , cob_dl_reject_cd_04_after AS cob_dl_reject_cd_04 , cob_dl_reject_cd_05_after AS cob_dl_reject_cd_05 , cob_fill_del_adj_cd_after AS cob_fill_del_adj_cd , cob_bin_nbr_after AS cob_bin_nbr , cob_plan_group_nbr_after AS cob_plan_group_nbr , cob_general_phrm_nbr_after AS cob_general_phrm_nbr , cob_basis_of_reimb_detrm_after AS cob_basis_of_reimb_detrm , cob_amt_attrib_to_tax_after AS cob_amt_attrib_to_tax , cob_pln_othr_amt_pd_after AS cob_pln_othr_amt_pd , cash_disc_sav_amt_after AS cash_disc_sav_amt , general_rph_nbr_after AS general_rph_nbr , routing_store_tech_inits_after AS routing_store_tech_inits , sourcing_ind_after AS sourcing_ind , maj_med_prior_auth_nbr_after AS maj_med_prior_auth_nbr , tip_rsn_for_svc_cd_after AS tip_rsn_for_svc_cd , data_rev_spec_id_after AS data_rev_spec_id , data_rev_spec_dttm_after AS data_rev_spec_dttm , data_rev_spec_store_nbr_after AS data_rev_spec_store_nbr , fill_rph_of_record_id_after AS fill_rph_of_record_id , cob_plan_incntv_paid_amt_after AS cob_plan_incntv_paid_amt , cob_pln_incnt_amt_sbmtd_after AS cob_pln_incnt_amt_sbmtd , cob_gen_recipient_nbr_after AS cob_gen_recipient_nbr , celgene_md_auth_nbr_after AS celgene_md_auth_nbr , celgene_conf_nbr_after AS celgene_conf_nbr , plan_other_amt_paid_type_after AS plan_other_amt_paid_type , plan_other_amt_subm_type_after AS plan_other_amt_subm_type , plan_returnd_coins_amt_after AS plan_returnd_coins_amt , plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt , plan_other_amt_paid_2_after AS plan_other_amt_paid_2 , plan_other_amt_paid_typ2_after AS plan_other_amt_paid_typ2 , plan_other_amt_paid_3_after AS plan_other_amt_paid_3 , plan_other_amt_paid_typ3_after AS plan_other_amt_paid_typ3 , fill_print_dttm_after AS fill_print_dttm , pat_lang_pref_cd_after AS pat_lang_pref_cd , rebilling_dttm_after AS rebilling_dttm , fill_90day_pref_ind_after AS fill_90day_pref_ind , fill_90day_pref_stat_cd_after AS fill_90day_pref_stat_cd , pat_pickup_id_after AS pat_pickup_id , pickup_id_after AS pickup_id , pickup_first_name_after AS pickup_first_name , pickup_last_name_after AS pickup_last_name , pickup_id_state_after AS pickup_id_state , pickup_id_country_after AS pickup_id_country , pickup_id_qlfr_after AS pickup_id_qlfr , pickup_rel_cd_after AS pickup_rel_cd , dl_proc_msg_after AS dl_proc_msg , cob_dl_proc_msg_after AS cob_dl_proc_msg , proc_ctrl_nbr_after AS proc_ctrl_nbr , med_partd_notice_ind_after AS med_partd_notice_ind , dispensed_ndc_after AS dispensed_ndc , med_partd_print_dttm_after AS med_partd_print_dttm , overstock_ind_after AS overstock_ind , ben_stg_qualifier_1_after AS ben_stg_qualifier_1 , ben_stg_qualifier_2_after AS ben_stg_qualifier_2 , ben_stg_qualifier_3_after AS ben_stg_qualifier_3 , ben_stg_qualifier_4_after AS ben_stg_qualifier_4 , ben_stg_amount_1_after AS ben_stg_amount_1 , ben_stg_amount_2_after AS ben_stg_amount_2 , ben_stg_amount_3_after AS ben_stg_amount_3 , ben_stg_amount_4_after AS ben_stg_amount_4 , coupon_drug_id_after AS coupon_drug_id , cob_coupon_drug_id_after AS cob_coupon_drug_id , coupon_ind_after AS coupon_ind , cob_coupon_ind_after AS cob_coupon_ind , other_coverage_cd_after AS other_coverage_cd , cob_other_coverage_cd_after AS cob_other_coverage_cd , partial_fil_intnded_qty_after AS partial_fil_intnded_qty , triplicate_serial_nbr_after AS triplicate_serial_nbr , source_system_name_after AS source_system_name , source_sys_trans_id_after AS source_sys_trans_id , delivery_ind_after AS delivery_ind , delivery_comments_after AS delivery_comments , approved_msg_cd_after AS approved_msg_cd , approved_msg_cd_2_after AS approved_msg_cd_2 , approved_msg_cd_3_after AS approved_msg_cd_3 , approved_msg_cd_4_after AS approved_msg_cd_4 , approved_msg_cd_5_after AS approved_msg_cd_5 , cob_approved_msg_cd_after AS cob_approved_msg_cd , cob_approved_msg_cd_2_after AS cob_approved_msg_cd_2 , cob_approved_msg_cd_3_after AS cob_approved_msg_cd_3 , cob_approved_msg_cd_4_after AS cob_approved_msg_cd_4 , cob_approved_msg_cd_5_after AS cob_approved_msg_cd_5 , cob_general_pbr_nbr_after AS cob_general_pbr_nbr , cob_place_of_service_after AS cob_place_of_service , cob_plan_tax_exempt_ind_after AS cob_plan_tax_exempt_ind , cob_rx_denial_ovride_cd_after AS cob_rx_denial_ovride_cd , cob_rx_denial_ovride_cd2_after AS cob_rx_denial_ovride_cd2 , cob_rx_denial_ovride_cd3_after AS cob_rx_denial_ovride_cd3 , cob_tax_exempt_plan_ind_after AS cob_tax_exempt_plan_ind , gen_recip_nbr_returnd_after AS gen_recip_nbr_returnd , general_pbr_nbr_after AS general_pbr_nbr , general_rph_nbr_qlfr_after AS general_rph_nbr_qlfr , medigap_id_after AS medigap_id , ntwk_reimb_id_returnd_after AS ntwk_reimb_id_returnd , pat_pickup_gov_auth_id_after AS pat_pickup_gov_auth_id , pat_pickup_rel_cd_after AS pat_pickup_rel_cd , place_of_service_after AS place_of_service , plan_id_returnd_after AS plan_id_returnd , plan_returnd_grp_nbr_after AS plan_returnd_grp_nbr , plan_tax_exempt_ind_after AS plan_tax_exempt_ind , prior_auth_cd_after AS prior_auth_cd , prior_auth_nbr_after AS prior_auth_nbr , routing_store_rph_inits_after AS routing_store_rph_inits , rx_denial_override_cd_after AS rx_denial_override_cd , rx_denial_override_cd_2_after AS rx_denial_override_cd_2 , rx_denial_override_cd_3_after AS rx_denial_override_cd_3 , sys_status_when_ent_after AS sys_status_when_ent , tax_exempt_plan_ind_after AS tax_exempt_plan_ind , pat_pickup_id_qlfr_after AS pat_pickup_id_qlfr , proc_local_dttm_after AS proc_local_dttm , proc_del_local_dttm_after AS proc_del_local_dttm , timeout_local_dttm_after AS timeout_local_dttm , timeout_del_local_dttm_after AS timeout_del_local_dttm , sold_local_dttm_after AS sold_local_dttm , cob_proc_local_dttm_after AS cob_proc_local_dttm , cob_proc_del_local_dttm_after AS cob_proc_del_local_dttm , cob_tmout_lcl_dttm_after AS cob_tmout_lcl_dttm , cob_tmout_del_lcl_dttm_after AS cob_tmout_del_lcl_dttm , db_cob_proc_ctrl_nbr_after AS db_cob_proc_ctrl_nbr , org_entered_dttm_after AS org_entered_dttm , dl_addl_msg_qlfr_after AS dl_addl_msg_qlfr , dl_additional_msg_after AS dl_additional_msg , wo_correlation_id_after AS wo_correlation_id , wo_rx_count_after AS wo_rx_count , short_fill_ind_after AS short_fill_ind , pay_cd_after AS pay_cd , filling_store_nbr_after as filling_store_nbr,fill_verified_store_nbr_after as fill_verified_store_nbr, mult_prod_review_ind_after as mult_prod_review_ind, pat_selct_user_id_after as pat_selct_user_id, pbr_selct_user_id_after as pbr_selct_user_id, pat_selct_dttm_after as pat_selct_dttm, pbr_selct_dttm_after as pbr_selct_dttm, pat_selct_str_nbr_after as pat_selct_str_nbr, pbr_selct_str_nbr_after as pbr_selct_str_nbr, ntt_ind_after as ntt_ind, 
'""" + SRC_TBL_NAME +  """' as table_name 
from gg_tbf0_update """


# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,
store_nbr AS store_nbr , rx_nbr AS rx_nbr , fill_nbr AS fill_nbr , fill_partial_nbr AS fill_partial_nbr , refills_remaining AS refills_remaining , fill_wac_cost_amt AS fill_wac_cost_amt , plan_returnd_cost_amt AS plan_returnd_cost_amt , plan_returnd_fee_amt AS plan_returnd_fee_amt , plan_submtd_copay_amt AS plan_submtd_copay_amt , pbr_id AS pbr_id , fill_source_cd AS fill_source_cd , refills_remain_when_ent AS refills_remain_when_ent , cob_plan_rtrnd_fee_amt AS cob_plan_rtrnd_fee_amt , tot_amt_paid_ind AS tot_amt_paid_ind , drug_class AS drug_class , drug_name AS drug_name , drug_id AS drug_id , plan_returnd_copay_amt AS plan_returnd_copay_amt , plan_total_paid_amt AS plan_total_paid_amt , plan_returnd_tax_amt AS plan_returnd_tax_amt , plan_submtd_cost_amt AS plan_submtd_cost_amt , plan_submtd_fee_amt AS plan_submtd_fee_amt , plan_submtd_tax_amt AS plan_submtd_tax_amt , pat_id AS pat_id , sims_upc AS sims_upc , pbr_loc_id AS pbr_loc_id , create_user_id AS create_user_id , create_dttm AS create_dttm , cob_plan_rtrnd_copay_amt AS cob_plan_rtrnd_copay_amt , cob_plan_total_paid_amt AS cob_plan_total_paid_amt , cob_plan_rtrnd_cost_amt AS cob_plan_rtrnd_cost_amt , cob_plan_rtrnd_tax_amt AS cob_plan_rtrnd_tax_amt , cob_plan_sbmtd_copay_amt AS cob_plan_sbmtd_copay_amt , cob_plan_sbmtd_cost_amt AS cob_plan_sbmtd_cost_amt , cob_plan_sbmtd_fee_amt AS cob_plan_sbmtd_fee_amt , cob_plan_sbmtd_tax_amt AS cob_plan_sbmtd_tax_amt , src_partition_nbr AS src_partition_nbr , fill_adjudication_cd AS fill_adjudication_cd , fill_awp_cost_amt AS fill_awp_cost_amt , fill_days_supply AS fill_days_supply , fill_entered_dttm AS fill_entered_dttm , fill_label_price_amt AS fill_label_price_amt , fill_qty_dispensed AS fill_qty_dispensed , fill_retail_price_amt AS fill_retail_price_amt , claim_reference_nbr AS claim_reference_nbr , fill_nbr_dispensed AS fill_nbr_dispensed , plan_id AS plan_id , fill_status_cd AS fill_status_cd , fill_entered_user_id AS fill_entered_user_id , fill_verified_user_id AS fill_verified_user_id , fill_verified_dttm AS fill_verified_dttm , fill_sold_dttm AS fill_sold_dttm , fill_deleted_dttm AS fill_deleted_dttm , fill_discount_cd AS fill_discount_cd , fill_pay_method_cd AS fill_pay_method_cd , fill_discount_amt AS fill_discount_amt , fill_sold_amt AS fill_sold_amt , fill_type_cd AS fill_type_cd , update_user_id AS update_user_id , update_dttm AS update_dttm , partial_fill_cd AS partial_fill_cd , fill_adjudication_dttm AS fill_adjudication_dttm , cob_fill_adjudication_cd AS cob_fill_adjudication_cd , cob_claim_ref_nbr AS cob_claim_ref_nbr , cob_plan_id AS cob_plan_id , cob_fill_adj_dttm AS cob_fill_adj_dttm , fill_data_rev_id AS fill_data_rev_id , fill_data_rev_dttm AS fill_data_rev_dttm , filling_user_id AS filling_user_id , filling_dttm AS filling_dttm , override_user_id AS override_user_id , override_dttm AS override_dttm , entered_store_nbr AS entered_store_nbr , reviewed_store_nbr AS reviewed_store_nbr , plan_gross_due_amt AS plan_gross_due_amt , cob_plan_gross_due_amt AS cob_plan_gross_due_amt , rx_daw_ind AS rx_daw_ind , dl_reject_cd_01 AS dl_reject_cd_01 , dl_reject_cd_02 AS dl_reject_cd_02 , dl_reject_cd_03 AS dl_reject_cd_03 , dl_reject_cd_04 AS dl_reject_cd_04 , dl_reject_cd_05 AS dl_reject_cd_05 , fill_del_adjudication_cd AS fill_del_adjudication_cd , fill_price_override_amt AS fill_price_override_amt , plan_incentive_paid_amt AS plan_incentive_paid_amt , general_recipient_nbr AS general_recipient_nbr , bin_nbr AS bin_nbr , plan_group_nbr AS plan_group_nbr , drug_warehouse_ind AS drug_warehouse_ind , general_phrm_nbr AS general_phrm_nbr , fill_est_pick_up_dttm AS fill_est_pick_up_dttm , reimburs_loss_amt AS reimburs_loss_amt , cost_plus_fee_cd AS cost_plus_fee_cd , accept_consult_ind AS accept_consult_ind , basis_of_reimb_determ AS basis_of_reimb_determ , plan_other_amt_paid AS plan_other_amt_paid , amt_attributed_to_tax AS amt_attributed_to_tax , plan_incent_amt_submtd AS plan_incent_amt_submtd , plan_other_amt_submtd AS plan_other_amt_submtd , lvl_of_svc_cd AS lvl_of_svc_cd , cob_dl_reject_cd_01 AS cob_dl_reject_cd_01 , cob_dl_reject_cd_02 AS cob_dl_reject_cd_02 , cob_dl_reject_cd_03 AS cob_dl_reject_cd_03 , cob_dl_reject_cd_04 AS cob_dl_reject_cd_04 , cob_dl_reject_cd_05 AS cob_dl_reject_cd_05 , cob_fill_del_adj_cd AS cob_fill_del_adj_cd , cob_bin_nbr AS cob_bin_nbr , cob_plan_group_nbr AS cob_plan_group_nbr , cob_general_phrm_nbr AS cob_general_phrm_nbr , cob_basis_of_reimb_detrm AS cob_basis_of_reimb_detrm , cob_amt_attrib_to_tax AS cob_amt_attrib_to_tax , cob_pln_othr_amt_pd AS cob_pln_othr_amt_pd , cash_disc_sav_amt AS cash_disc_sav_amt , general_rph_nbr AS general_rph_nbr , routing_store_tech_inits AS routing_store_tech_inits , sourcing_ind AS sourcing_ind , maj_med_prior_auth_nbr AS maj_med_prior_auth_nbr , tip_rsn_for_svc_cd AS tip_rsn_for_svc_cd , data_rev_spec_id AS data_rev_spec_id , data_rev_spec_dttm AS data_rev_spec_dttm , data_rev_spec_store_nbr AS data_rev_spec_store_nbr , fill_rph_of_record_id AS fill_rph_of_record_id , cob_plan_incntv_paid_amt AS cob_plan_incntv_paid_amt , cob_pln_incnt_amt_sbmtd AS cob_pln_incnt_amt_sbmtd , cob_gen_recipient_nbr AS cob_gen_recipient_nbr , celgene_md_auth_nbr AS celgene_md_auth_nbr , celgene_conf_nbr AS celgene_conf_nbr , plan_other_amt_paid_type AS plan_other_amt_paid_type , plan_other_amt_subm_type AS plan_other_amt_subm_type , plan_returnd_coins_amt AS plan_returnd_coins_amt , plan_rtrnd_coins_amt AS plan_rtrnd_coins_amt , plan_other_amt_paid_2 AS plan_other_amt_paid_2 , plan_other_amt_paid_typ2 AS plan_other_amt_paid_typ2 , plan_other_amt_paid_3 AS plan_other_amt_paid_3 , plan_other_amt_paid_typ3 AS plan_other_amt_paid_typ3 , fill_print_dttm AS fill_print_dttm , pat_lang_pref_cd AS pat_lang_pref_cd , rebilling_dttm AS rebilling_dttm , fill_90day_pref_ind AS fill_90day_pref_ind , fill_90day_pref_stat_cd AS fill_90day_pref_stat_cd , pat_pickup_id AS pat_pickup_id , pickup_id AS pickup_id , pickup_first_name AS pickup_first_name , pickup_last_name AS pickup_last_name , pickup_id_state AS pickup_id_state , pickup_id_country AS pickup_id_country , pickup_id_qlfr AS pickup_id_qlfr , pickup_rel_cd AS pickup_rel_cd , dl_proc_msg AS dl_proc_msg , cob_dl_proc_msg AS cob_dl_proc_msg , proc_ctrl_nbr AS proc_ctrl_nbr , med_partd_notice_ind AS med_partd_notice_ind , dispensed_ndc AS dispensed_ndc , med_partd_print_dttm AS med_partd_print_dttm , overstock_ind AS overstock_ind , ben_stg_qualifier_1 AS ben_stg_qualifier_1 , ben_stg_qualifier_2 AS ben_stg_qualifier_2 , ben_stg_qualifier_3 AS ben_stg_qualifier_3 , ben_stg_qualifier_4 AS ben_stg_qualifier_4 , ben_stg_amount_1 AS ben_stg_amount_1 , ben_stg_amount_2 AS ben_stg_amount_2 , ben_stg_amount_3 AS ben_stg_amount_3 , ben_stg_amount_4 AS ben_stg_amount_4 , coupon_drug_id AS coupon_drug_id , cob_coupon_drug_id AS cob_coupon_drug_id , coupon_ind AS coupon_ind , cob_coupon_ind AS cob_coupon_ind , other_coverage_cd AS other_coverage_cd , cob_other_coverage_cd AS cob_other_coverage_cd , partial_fil_intnded_qty AS partial_fil_intnded_qty , triplicate_serial_nbr AS triplicate_serial_nbr , source_system_name AS source_system_name , source_sys_trans_id AS source_sys_trans_id , delivery_ind AS delivery_ind , delivery_comments AS delivery_comments , approved_msg_cd AS approved_msg_cd , approved_msg_cd_2 AS approved_msg_cd_2 , approved_msg_cd_3 AS approved_msg_cd_3 , approved_msg_cd_4 AS approved_msg_cd_4 , approved_msg_cd_5 AS approved_msg_cd_5 , cob_approved_msg_cd AS cob_approved_msg_cd , cob_approved_msg_cd_2 AS cob_approved_msg_cd_2 , cob_approved_msg_cd_3 AS cob_approved_msg_cd_3 , cob_approved_msg_cd_4 AS cob_approved_msg_cd_4 , cob_approved_msg_cd_5 AS cob_approved_msg_cd_5 , cob_general_pbr_nbr AS cob_general_pbr_nbr , cob_place_of_service AS cob_place_of_service , cob_plan_tax_exempt_ind AS cob_plan_tax_exempt_ind , cob_rx_denial_ovride_cd AS cob_rx_denial_ovride_cd , cob_rx_denial_ovride_cd2 AS cob_rx_denial_ovride_cd2 , cob_rx_denial_ovride_cd3 AS cob_rx_denial_ovride_cd3 , cob_tax_exempt_plan_ind AS cob_tax_exempt_plan_ind , gen_recip_nbr_returnd AS gen_recip_nbr_returnd , general_pbr_nbr AS general_pbr_nbr , general_rph_nbr_qlfr AS general_rph_nbr_qlfr , medigap_id AS medigap_id , ntwk_reimb_id_returnd AS ntwk_reimb_id_returnd , pat_pickup_gov_auth_id AS pat_pickup_gov_auth_id , pat_pickup_rel_cd AS pat_pickup_rel_cd , place_of_service AS place_of_service , plan_id_returnd AS plan_id_returnd , plan_returnd_grp_nbr AS plan_returnd_grp_nbr , plan_tax_exempt_ind AS plan_tax_exempt_ind , prior_auth_cd AS prior_auth_cd , prior_auth_nbr AS prior_auth_nbr , routing_store_rph_inits AS routing_store_rph_inits , rx_denial_override_cd AS rx_denial_override_cd , rx_denial_override_cd_2 AS rx_denial_override_cd_2 , rx_denial_override_cd_3 AS rx_denial_override_cd_3 , sys_status_when_ent AS sys_status_when_ent , tax_exempt_plan_ind AS tax_exempt_plan_ind , pat_pickup_id_qlfr AS pat_pickup_id_qlfr , proc_local_dttm  AS proc_local_dttm  , proc_del_local_dttm  AS proc_del_local_dttm  , timeout_local_dttm  AS timeout_local_dttm  , timeout_del_local_dttm  AS timeout_del_local_dttm  , sold_local_dttm  AS sold_local_dttm  , cob_proc_local_dttm  AS cob_proc_local_dttm  , cob_proc_del_local_dttm  AS cob_proc_del_local_dttm  , cob_tmout_lcl_dttm  AS cob_tmout_lcl_dttm  , cob_tmout_del_lcl_dttm  AS cob_tmout_del_lcl_dttm  , db_cob_proc_ctrl_nbr  AS db_cob_proc_ctrl_nbr  , org_entered_dttm AS org_entered_dttm , dl_addl_msg_qlfr  AS dl_addl_msg_qlfr  , dl_additional_msg  AS dl_additional_msg  , wo_correlation_id AS wo_correlation_id , wo_rx_count AS wo_rx_count , short_fill_ind AS short_fill_ind ,  pay_cd AS pay_cd ,filling_store_nbr as filling_store_nbr,fill_verified_store_nbr as fill_verified_store_nbr, mult_prod_review_ind as mult_prod_review_ind,pat_selct_user_id as pat_selct_user_id, pbr_selct_user_id as pbr_selct_user_id, pat_selct_dttm as pat_selct_dttm, pbr_selct_dttm as pbr_selct_dttm, pat_selct_str_nbr as pat_selct_str_nbr, pbr_selct_str_nbr as pbr_selct_str_nbr, ntt_ind as ntt_ind,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , refills_remaining_after AS refills_remaining , fill_wac_cost_amt_after AS fill_wac_cost_amt , plan_returnd_cost_amt_after AS plan_returnd_cost_amt , plan_returnd_fee_amt_after AS plan_returnd_fee_amt , plan_submtd_copay_amt_after AS plan_submtd_copay_amt , pbr_id_after AS pbr_id , fill_source_cd_after AS fill_source_cd , refills_remain_when_ent_after AS refills_remain_when_ent , cob_plan_rtrnd_fee_amt_after AS cob_plan_rtrnd_fee_amt , tot_amt_paid_ind_after AS tot_amt_paid_ind , drug_class_after AS drug_class , drug_name_after AS drug_name , drug_id_after AS drug_id , plan_returnd_copay_amt_after AS plan_returnd_copay_amt , plan_total_paid_amt_after AS plan_total_paid_amt , plan_returnd_tax_amt_after AS plan_returnd_tax_amt , plan_submtd_cost_amt_after AS plan_submtd_cost_amt , plan_submtd_fee_amt_after AS plan_submtd_fee_amt , plan_submtd_tax_amt_after AS plan_submtd_tax_amt , pat_id_after AS pat_id , sims_upc_after AS sims_upc , pbr_loc_id_after AS pbr_loc_id , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , cob_plan_rtrnd_copay_amt_after AS cob_plan_rtrnd_copay_amt , cob_plan_total_paid_amt_after AS cob_plan_total_paid_amt , cob_plan_rtrnd_cost_amt_after AS cob_plan_rtrnd_cost_amt , cob_plan_rtrnd_tax_amt_after AS cob_plan_rtrnd_tax_amt , cob_plan_sbmtd_copay_amt_after AS cob_plan_sbmtd_copay_amt , cob_plan_sbmtd_cost_amt_after AS cob_plan_sbmtd_cost_amt , cob_plan_sbmtd_fee_amt_after AS cob_plan_sbmtd_fee_amt , cob_plan_sbmtd_tax_amt_after AS cob_plan_sbmtd_tax_amt , src_partition_nbr_after AS src_partition_nbr , fill_adjudication_cd_after AS fill_adjudication_cd , fill_awp_cost_amt_after AS fill_awp_cost_amt , fill_days_supply_after AS fill_days_supply , fill_entered_dttm_after AS fill_entered_dttm , fill_label_price_amt_after AS fill_label_price_amt , fill_qty_dispensed_after AS fill_qty_dispensed , fill_retail_price_amt_after AS fill_retail_price_amt , claim_reference_nbr_after AS claim_reference_nbr , fill_nbr_dispensed_after AS fill_nbr_dispensed , plan_id_after AS plan_id , fill_status_cd_after AS fill_status_cd , fill_entered_user_id_after AS fill_entered_user_id , fill_verified_user_id_after AS fill_verified_user_id , fill_verified_dttm_after AS fill_verified_dttm , fill_sold_dttm_after AS fill_sold_dttm , fill_deleted_dttm_after AS fill_deleted_dttm , fill_discount_cd_after AS fill_discount_cd , fill_pay_method_cd_after AS fill_pay_method_cd , fill_discount_amt_after AS fill_discount_amt , fill_sold_amt_after AS fill_sold_amt , fill_type_cd_after AS fill_type_cd , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , partial_fill_cd_after AS partial_fill_cd , fill_adjudication_dttm_after AS fill_adjudication_dttm , cob_fill_adjudication_cd_after AS cob_fill_adjudication_cd , cob_claim_ref_nbr_after AS cob_claim_ref_nbr , cob_plan_id_after AS cob_plan_id , cob_fill_adj_dttm_after AS cob_fill_adj_dttm , fill_data_rev_id_after AS fill_data_rev_id , fill_data_rev_dttm_after AS fill_data_rev_dttm , filling_user_id_after AS filling_user_id , filling_dttm_after AS filling_dttm , override_user_id_after AS override_user_id , override_dttm_after AS override_dttm , entered_store_nbr_after AS entered_store_nbr , reviewed_store_nbr_after AS reviewed_store_nbr , plan_gross_due_amt_after AS plan_gross_due_amt , cob_plan_gross_due_amt_after AS cob_plan_gross_due_amt , rx_daw_ind_after AS rx_daw_ind , dl_reject_cd_01_after AS dl_reject_cd_01 , dl_reject_cd_02_after AS dl_reject_cd_02 , dl_reject_cd_03_after AS dl_reject_cd_03 , dl_reject_cd_04_after AS dl_reject_cd_04 , dl_reject_cd_05_after AS dl_reject_cd_05 , fill_del_adjudication_cd_after AS fill_del_adjudication_cd , fill_price_override_amt_after AS fill_price_override_amt , plan_incentive_paid_amt_after AS plan_incentive_paid_amt , general_recipient_nbr_after AS general_recipient_nbr , bin_nbr_after AS bin_nbr , plan_group_nbr_after AS plan_group_nbr , drug_warehouse_ind_after AS drug_warehouse_ind , general_phrm_nbr_after AS general_phrm_nbr , fill_est_pick_up_dttm_after AS fill_est_pick_up_dttm , reimburs_loss_amt_after AS reimburs_loss_amt , cost_plus_fee_cd_after AS cost_plus_fee_cd , accept_consult_ind_after AS accept_consult_ind , basis_of_reimb_determ_after AS basis_of_reimb_determ , plan_other_amt_paid_after AS plan_other_amt_paid , amt_attributed_to_tax_after AS amt_attributed_to_tax , plan_incent_amt_submtd_after AS plan_incent_amt_submtd , plan_other_amt_submtd_after AS plan_other_amt_submtd , lvl_of_svc_cd_after AS lvl_of_svc_cd , cob_dl_reject_cd_01_after AS cob_dl_reject_cd_01 , cob_dl_reject_cd_02_after AS cob_dl_reject_cd_02 , cob_dl_reject_cd_03_after AS cob_dl_reject_cd_03 , cob_dl_reject_cd_04_after AS cob_dl_reject_cd_04 , cob_dl_reject_cd_05_after AS cob_dl_reject_cd_05 , cob_fill_del_adj_cd_after AS cob_fill_del_adj_cd , cob_bin_nbr_after AS cob_bin_nbr , cob_plan_group_nbr_after AS cob_plan_group_nbr , cob_general_phrm_nbr_after AS cob_general_phrm_nbr , cob_basis_of_reimb_detrm_after AS cob_basis_of_reimb_detrm , cob_amt_attrib_to_tax_after AS cob_amt_attrib_to_tax , cob_pln_othr_amt_pd_after AS cob_pln_othr_amt_pd , cash_disc_sav_amt_after AS cash_disc_sav_amt , general_rph_nbr_after AS general_rph_nbr , routing_store_tech_inits_after AS routing_store_tech_inits , sourcing_ind_after AS sourcing_ind , maj_med_prior_auth_nbr_after AS maj_med_prior_auth_nbr , tip_rsn_for_svc_cd_after AS tip_rsn_for_svc_cd , data_rev_spec_id_after AS data_rev_spec_id , data_rev_spec_dttm_after AS data_rev_spec_dttm , data_rev_spec_store_nbr_after AS data_rev_spec_store_nbr , fill_rph_of_record_id_after AS fill_rph_of_record_id , cob_plan_incntv_paid_amt_after AS cob_plan_incntv_paid_amt , cob_pln_incnt_amt_sbmtd_after AS cob_pln_incnt_amt_sbmtd , cob_gen_recipient_nbr_after AS cob_gen_recipient_nbr , celgene_md_auth_nbr_after AS celgene_md_auth_nbr , celgene_conf_nbr_after AS celgene_conf_nbr , plan_other_amt_paid_type_after AS plan_other_amt_paid_type , plan_other_amt_subm_type_after AS plan_other_amt_subm_type , plan_returnd_coins_amt_after AS plan_returnd_coins_amt , plan_rtrnd_coins_amt_after AS plan_rtrnd_coins_amt , plan_other_amt_paid_2_after AS plan_other_amt_paid_2 , plan_other_amt_paid_typ2_after AS plan_other_amt_paid_typ2 , plan_other_amt_paid_3_after AS plan_other_amt_paid_3 , plan_other_amt_paid_typ3_after AS plan_other_amt_paid_typ3 , fill_print_dttm_after AS fill_print_dttm , pat_lang_pref_cd_after AS pat_lang_pref_cd , rebilling_dttm_after AS rebilling_dttm , fill_90day_pref_ind_after AS fill_90day_pref_ind , fill_90day_pref_stat_cd_after AS fill_90day_pref_stat_cd , pat_pickup_id_after AS pat_pickup_id , pickup_id_after AS pickup_id , pickup_first_name_after AS pickup_first_name , pickup_last_name_after AS pickup_last_name , pickup_id_state_after AS pickup_id_state , pickup_id_country_after AS pickup_id_country , pickup_id_qlfr_after AS pickup_id_qlfr , pickup_rel_cd_after AS pickup_rel_cd , dl_proc_msg_after AS dl_proc_msg , cob_dl_proc_msg_after AS cob_dl_proc_msg , proc_ctrl_nbr_after AS proc_ctrl_nbr , med_partd_notice_ind_after AS med_partd_notice_ind , dispensed_ndc_after AS dispensed_ndc , med_partd_print_dttm_after AS med_partd_print_dttm , overstock_ind_after AS overstock_ind , ben_stg_qualifier_1_after AS ben_stg_qualifier_1 , ben_stg_qualifier_2_after AS ben_stg_qualifier_2 , ben_stg_qualifier_3_after AS ben_stg_qualifier_3 , ben_stg_qualifier_4_after AS ben_stg_qualifier_4 , ben_stg_amount_1_after AS ben_stg_amount_1 , ben_stg_amount_2_after AS ben_stg_amount_2 , ben_stg_amount_3_after AS ben_stg_amount_3 , ben_stg_amount_4_after AS ben_stg_amount_4 , coupon_drug_id_after AS coupon_drug_id , cob_coupon_drug_id_after AS cob_coupon_drug_id , coupon_ind_after AS coupon_ind , cob_coupon_ind_after AS cob_coupon_ind , other_coverage_cd_after AS other_coverage_cd , cob_other_coverage_cd_after AS cob_other_coverage_cd , partial_fil_intnded_qty_after AS partial_fil_intnded_qty , triplicate_serial_nbr_after AS triplicate_serial_nbr , source_system_name_after AS source_system_name , source_sys_trans_id_after AS source_sys_trans_id , delivery_ind_after AS delivery_ind , delivery_comments_after AS delivery_comments , approved_msg_cd_after AS approved_msg_cd , approved_msg_cd_2_after AS approved_msg_cd_2 , approved_msg_cd_3_after AS approved_msg_cd_3 , approved_msg_cd_4_after AS approved_msg_cd_4 , approved_msg_cd_5_after AS approved_msg_cd_5 , cob_approved_msg_cd_after AS cob_approved_msg_cd , cob_approved_msg_cd_2_after AS cob_approved_msg_cd_2 , cob_approved_msg_cd_3_after AS cob_approved_msg_cd_3 , cob_approved_msg_cd_4_after AS cob_approved_msg_cd_4 , cob_approved_msg_cd_5_after AS cob_approved_msg_cd_5 , cob_general_pbr_nbr_after AS cob_general_pbr_nbr , cob_place_of_service_after AS cob_place_of_service , cob_plan_tax_exempt_ind_after AS cob_plan_tax_exempt_ind , cob_rx_denial_ovride_cd_after AS cob_rx_denial_ovride_cd , cob_rx_denial_ovride_cd2_after AS cob_rx_denial_ovride_cd2 , cob_rx_denial_ovride_cd3_after AS cob_rx_denial_ovride_cd3 , cob_tax_exempt_plan_ind_after AS cob_tax_exempt_plan_ind , gen_recip_nbr_returnd_after AS gen_recip_nbr_returnd , general_pbr_nbr_after AS general_pbr_nbr , general_rph_nbr_qlfr_after AS general_rph_nbr_qlfr , medigap_id_after AS medigap_id , ntwk_reimb_id_returnd_after AS ntwk_reimb_id_returnd , pat_pickup_gov_auth_id_after AS pat_pickup_gov_auth_id , pat_pickup_rel_cd_after AS pat_pickup_rel_cd , place_of_service_after AS place_of_service , plan_id_returnd_after AS plan_id_returnd , plan_returnd_grp_nbr_after AS plan_returnd_grp_nbr , plan_tax_exempt_ind_after AS plan_tax_exempt_ind , prior_auth_cd_after AS prior_auth_cd , prior_auth_nbr_after AS prior_auth_nbr , routing_store_rph_inits_after AS routing_store_rph_inits , rx_denial_override_cd_after AS rx_denial_override_cd , rx_denial_override_cd_2_after AS rx_denial_override_cd_2 , rx_denial_override_cd_3_after AS rx_denial_override_cd_3 , sys_status_when_ent_after AS sys_status_when_ent , tax_exempt_plan_ind_after AS tax_exempt_plan_ind , pat_pickup_id_qlfr_after AS pat_pickup_id_qlfr , proc_local_dttm_after AS proc_local_dttm , proc_del_local_dttm_after AS proc_del_local_dttm , timeout_local_dttm_after AS timeout_local_dttm , timeout_del_local_dttm_after AS timeout_del_local_dttm , sold_local_dttm_after AS sold_local_dttm , cob_proc_local_dttm_after AS cob_proc_local_dttm , cob_proc_del_local_dttm_after AS cob_proc_del_local_dttm , cob_tmout_lcl_dttm_after AS cob_tmout_lcl_dttm , cob_tmout_del_lcl_dttm_after AS cob_tmout_del_lcl_dttm , db_cob_proc_ctrl_nbr_after AS db_cob_proc_ctrl_nbr , org_entered_dttm_after AS org_entered_dttm , dl_addl_msg_qlfr_after AS dl_addl_msg_qlfr , dl_additional_msg_after AS dl_additional_msg , wo_correlation_id_after AS wo_correlation_id , wo_rx_count_after AS wo_rx_count , short_fill_ind_after AS short_fill_ind , pay_cd_after AS pay_cd , filling_store_nbr_after as filling_store_nbr,fill_verified_store_nbr_after as fill_verified_store_nbr, mult_prod_review_ind_after as mult_prod_review_ind, pat_selct_user_id_after as pat_selct_user_id, pbr_selct_user_id_after as pbr_selct_user_id, pat_selct_dttm_after as pat_selct_dttm, pbr_selct_dttm_after as pbr_selct_dttm, pat_selct_str_nbr_after as pat_selct_str_nbr, pbr_selct_str_nbr_after as pbr_selct_str_nbr, ntt_ind_after as ntt_ind,
'""" + SRC_TBL_NAME +  """' as table_name 
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)



# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")

  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
# print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))


etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
#display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CREATE_DTTM",trim("CREATE_DTTM"))\
                                                                         .withColumn("UPDATE_DTTM",trim("UPDATE_DTTM"))\
                                                                         .withColumn("FILL_ENTERED_DTTM",trim("FILL_ENTERED_DTTM"))\
                                                                         .withColumn("FILL_VERIFIED_DTTM",trim("FILL_VERIFIED_DTTM"))\
                                                                         .withColumn("FILL_SOLD_DTTM",trim("FILL_SOLD_DTTM"))\
                                                                         .withColumn("FILL_DELETED_DTTM",trim("FILL_DELETED_DTTM"))\
                                                                         .withColumn("FILL_ADJUDICATION_DTTM",trim("FILL_ADJUDICATION_DTTM"))\
                                                                         .withColumn("COB_FILL_ADJ_DTTM",trim("COB_FILL_ADJ_DTTM"))\
                                                                         .withColumn("FILL_DATA_REV_DTTM",trim("FILL_DATA_REV_DTTM"))\
                                                                         .withColumn("FILLING_DTTM",trim("FILLING_DTTM"))\
                                                                         .withColumn("OVERRIDE_DTTM",trim("OVERRIDE_DTTM"))\
                                                                         .withColumn("FILL_EST_PICK_UP_DTTM",trim("FILL_EST_PICK_UP_DTTM"))\
                                                                         .withColumn("DATA_REV_SPEC_DTTM",trim("DATA_REV_SPEC_DTTM"))\
                                                                         .withColumn("FILL_PRINT_DTTM",trim("FILL_PRINT_DTTM"))\
                                                                         .withColumn("REBILLING_DTTM",trim("REBILLING_DTTM"))\
                                                                         .withColumn("MED_PARTD_PRINT_DTTM",trim("MED_PARTD_PRINT_DTTM"))\
                                                                         .withColumn("SOLD_LOCAL_DTTM",trim("SOLD_LOCAL_DTTM"))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CREATE_DTTM",concat(split(col("CREATE_DTTM"),":")[0],split(col("CREATE_DTTM"),":")[1],lit(":"),split(col("CREATE_DTTM"),":")[2],lit(":"),split(col("CREATE_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("UPDATE_DTTM",concat(split(col("UPDATE_DTTM"),":")[0],split(col("UPDATE_DTTM"),":")[1],lit(":"),split(col("UPDATE_DTTM"),":")[2],lit(":"),split(col("UPDATE_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ENTERED_DTTM",concat(split(col("FILL_ENTERED_DTTM"),":")[0],split(col("FILL_ENTERED_DTTM"),":")[1],lit(":"),split(col("FILL_ENTERED_DTTM"),":")[2],lit(":"),split(col("FILL_ENTERED_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_VERIFIED_DTTM",concat(split(col("FILL_VERIFIED_DTTM"),":")[0],split(col("FILL_VERIFIED_DTTM"),":")[1],lit(":"),split(col("FILL_VERIFIED_DTTM"),":")[2],lit(":"),split(col("FILL_VERIFIED_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_SOLD_DTTM",concat(split(col("FILL_SOLD_DTTM"),":")[0],split(col("FILL_SOLD_DTTM"),":")[1],lit(":"),split(col("FILL_SOLD_DTTM"),":")[2],lit(":"),split(col("FILL_SOLD_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_DELETED_DTTM",concat(split(col("FILL_DELETED_DTTM"),":")[0],split(col("FILL_DELETED_DTTM"),":")[1],lit(":"),split(col("FILL_DELETED_DTTM"),":")[2],lit(":"),split(col("FILL_DELETED_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ADJUDICATION_DTTM",concat(split(col("FILL_ADJUDICATION_DTTM"),":")[0],split(col("FILL_ADJUDICATION_DTTM"),":")[1],lit(":"),split(col("FILL_ADJUDICATION_DTTM"),":")[2],lit(":"),split(col("FILL_ADJUDICATION_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("COB_FILL_ADJ_DTTM",concat(split(col("COB_FILL_ADJ_DTTM"),":")[0],split(col("COB_FILL_ADJ_DTTM"),":")[1],lit(":"),split(col("COB_FILL_ADJ_DTTM"),":")[2],lit(":"),split(col("COB_FILL_ADJ_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_DATA_REV_DTTM",concat(split(col("FILL_DATA_REV_DTTM"),":")[0],split(col("FILL_DATA_REV_DTTM"),":")[1],lit(":"),split(col("FILL_DATA_REV_DTTM"),":")[2],lit(":"),split(col("FILL_DATA_REV_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILLING_DTTM",concat(split(col("FILLING_DTTM"),":")[0],split(col("FILLING_DTTM"),":")[1],lit(":"),split(col("FILLING_DTTM"),":")[2],lit(":"),split(col("FILLING_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("OVERRIDE_DTTM",concat(split(col("OVERRIDE_DTTM"),":")[0],split(col("OVERRIDE_DTTM"),":")[1],lit(":"),split(col("OVERRIDE_DTTM"),":")[2],lit(":"),split(col("OVERRIDE_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_EST_PICK_UP_DTTM",concat(split(col("FILL_EST_PICK_UP_DTTM"),":")[0],split(col("FILL_EST_PICK_UP_DTTM"),":")[1],lit(":"),split(col("FILL_EST_PICK_UP_DTTM"),":")[2],lit(":"),split(col("FILL_EST_PICK_UP_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("DATA_REV_SPEC_DTTM",concat(split(col("DATA_REV_SPEC_DTTM"),":")[0],split(col("DATA_REV_SPEC_DTTM"),":")[1],lit(":"),split(col("DATA_REV_SPEC_DTTM"),":")[2],lit(":"),split(col("DATA_REV_SPEC_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_PRINT_DTTM",concat(split(col("FILL_PRINT_DTTM"),":")[0],split(col("FILL_PRINT_DTTM"),":")[1],lit(":"),split(col("FILL_PRINT_DTTM"),":")[2],lit(":"),split(col("FILL_PRINT_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("REBILLING_DTTM",concat(split(col("REBILLING_DTTM"),":")[0],split(col("REBILLING_DTTM"),":")[1],lit(":"),split(col("REBILLING_DTTM"),":")[2],lit(":"),split(col("REBILLING_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("MED_PARTD_PRINT_DTTM",concat(split(col("MED_PARTD_PRINT_DTTM"),":")[0],split(col("MED_PARTD_PRINT_DTTM"),":")[1],lit(":"),split(col("MED_PARTD_PRINT_DTTM"),":")[2],lit(":"),split(col("MED_PARTD_PRINT_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("SOLD_LOCAL_DTTM",concat(split(col("SOLD_LOCAL_DTTM"),":")[0],split(col("SOLD_LOCAL_DTTM"),":")[1],lit(":"),split(col("SOLD_LOCAL_DTTM"),":")[2],lit(":"),split(col("SOLD_LOCAL_DTTM"),":")[3]))

# COMMAND ----------

etl_tbf0_reformat_typeCast = etl_tbf0_reformat_cdc_check_notnull.withColumn("CDC_TXN_COMMIT_DTTM", to_timestamp(etl_tbf0_reformat_cdc_check_notnull["CDC_TXN_COMMIT_DTTM"]))\
            .withColumn("CREATE_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["CREATE_DTTM"]))\
            .withColumn("FILL_ENTERED_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_ENTERED_DTTM"]))\
            .withColumn("FILL_VERIFIED_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_VERIFIED_DTTM"]))\
            .withColumn("FILL_SOLD_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_SOLD_DTTM"]))\
            .withColumn("FILL_DELETED_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_DELETED_DTTM"]))\
            .withColumn("UPDATE_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["UPDATE_DTTM"]))\
            .withColumn("FILL_ADJUDICATION_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_ADJUDICATION_DTTM"]))\
            .withColumn("COB_FILL_ADJ_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["COB_FILL_ADJ_DTTM"]))\
            .withColumn("FILL_DATA_REV_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_DATA_REV_DTTM"]))\
            .withColumn("FILLING_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILLING_DTTM"]))\
            .withColumn("OVERRIDE_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["OVERRIDE_DTTM"]))\
            .withColumn("FILL_EST_PICK_UP_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_EST_PICK_UP_DTTM"]))\
            .withColumn("DATA_REV_SPEC_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["DATA_REV_SPEC_DTTM"]))\
            .withColumn("FILL_PRINT_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["FILL_PRINT_DTTM"]))\
            .withColumn("REBILLING_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["REBILLING_DTTM"]))\
            .withColumn("MED_PARTD_PRINT_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["MED_PARTD_PRINT_DTTM"]))\
            .withColumn("SOLD_LOCAL_DTTM",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["SOLD_LOCAL_DTTM"]))\
            .withColumn("cdc_operation_type_cd", substring(col("cdc_operation_type_cd"),0,20))\
			.withColumn("cdc_before_after_cd", substring(col("cdc_before_after_cd"),0,10))\
			.withColumn("cdc_txn_position_cd", substring(col("cdc_txn_position_cd"),0,10))\
			.withColumn("fill_source_cd", substring(col("fill_source_cd"),0,1))\
			.withColumn("refills_remain_when_ent", substring(col("refills_remain_when_ent"),0,4))\
			.withColumn("tot_amt_paid_ind", substring(col("tot_amt_paid_ind"),0,1))\
			.withColumn("drug_class", substring(col("drug_class"),0,2))\
			.withColumn("drug_name", substring(col("drug_name"),0,35))\
			.withColumn("sims_upc", substring(col("sims_upc"),0,14))\
			.withColumn("fill_adjudication_cd", substring(col("fill_adjudication_cd"),0,1))\
			.withColumn("claim_reference_nbr", substring(col("claim_reference_nbr"),0,20))\
			.withColumn("plan_id", substring(col("plan_id"),0,8))\
			.withColumn("fill_status_cd", substring(col("fill_status_cd"),0,2))\
			.withColumn("fill_discount_cd", substring(col("fill_discount_cd"),0,1))\
			.withColumn("fill_pay_method_cd", substring(col("fill_pay_method_cd"),0,1))\
			.withColumn("fill_type_cd", substring(col("fill_type_cd"),0,1))\
			.withColumn("partial_fill_cd", substring(col("partial_fill_cd"),0,1))\
			.withColumn("cob_fill_adjudication_cd", substring(col("cob_fill_adjudication_cd"),0,1))\
			.withColumn("cob_claim_ref_nbr", substring(col("cob_claim_ref_nbr"),0,20))\
			.withColumn("cob_plan_id", substring(col("cob_plan_id"),0,8))\
			.withColumn("dl_reject_cd_01", substring(col("dl_reject_cd_01"),0,3))\
			.withColumn("dl_reject_cd_02", substring(col("dl_reject_cd_02"),0,3))\
			.withColumn("dl_reject_cd_03", substring(col("dl_reject_cd_03"),0,3))\
			.withColumn("dl_reject_cd_04", substring(col("dl_reject_cd_04"),0,3))\
			.withColumn("dl_reject_cd_05", substring(col("dl_reject_cd_05"),0,3))\
			.withColumn("fill_del_adjudication_cd", substring(col("fill_del_adjudication_cd"),0,1))\
			.withColumn("general_recipient_nbr", substring(col("general_recipient_nbr"),0,21))\
			.withColumn("bin_nbr", substring(col("bin_nbr"),0,6))\
			.withColumn("plan_group_nbr", substring(col("plan_group_nbr"),0,15))\
			.withColumn("drug_warehouse_ind", substring(col("drug_warehouse_ind"),0,1))\
			.withColumn("general_phrm_nbr", substring(col("general_phrm_nbr"),0,15))\
			.withColumn("cost_plus_fee_cd", substring(col("cost_plus_fee_cd"),0,1))\
			.withColumn("accept_consult_ind", substring(col("accept_consult_ind"),0,1))\
			.withColumn("basis_of_reimb_determ", substring(col("basis_of_reimb_determ"),0,2))\
			.withColumn("lvl_of_svc_cd", substring(col("lvl_of_svc_cd"),0,2))\
			.withColumn("cob_dl_reject_cd_01", substring(col("cob_dl_reject_cd_01"),0,3))\
			.withColumn("cob_dl_reject_cd_02", substring(col("cob_dl_reject_cd_02"),0,3))\
			.withColumn("cob_dl_reject_cd_03", substring(col("cob_dl_reject_cd_03"),0,3))\
			.withColumn("cob_dl_reject_cd_04", substring(col("cob_dl_reject_cd_04"),0,3))\
			.withColumn("cob_dl_reject_cd_05", substring(col("cob_dl_reject_cd_05"),0,3))\
			.withColumn("cob_fill_del_adj_cd", substring(col("cob_fill_del_adj_cd"),0,1))\
			.withColumn("cob_bin_nbr", substring(col("cob_bin_nbr"),0,6))\
			.withColumn("cob_plan_group_nbr", substring(col("cob_plan_group_nbr"),0,15))\
			.withColumn("cob_general_phrm_nbr", substring(col("cob_general_phrm_nbr"),0,15))\
			.withColumn("cob_basis_of_reimb_detrm", substring(col("cob_basis_of_reimb_detrm"),0,2))\
			.withColumn("general_rph_nbr", substring(col("general_rph_nbr"),0,15))\
			.withColumn("routing_store_tech_inits", substring(col("routing_store_tech_inits"),0,3))\
			.withColumn("sourcing_ind", substring(col("sourcing_ind"),0,1))\
			.withColumn("maj_med_prior_auth_nbr", substring(col("maj_med_prior_auth_nbr"),0,20))\
			.withColumn("tip_rsn_for_svc_cd", substring(col("tip_rsn_for_svc_cd"),0,2))\
			.withColumn("rx_daw_ind", substring(col("rx_daw_ind"),0,1))\
			.withColumn("cob_gen_recipient_nbr", substring(col("cob_gen_recipient_nbr"),0,21))\
			.withColumn("celgene_md_auth_nbr", substring(col("celgene_md_auth_nbr"),0,7))\
			.withColumn("celgene_conf_nbr", substring(col("celgene_conf_nbr"),0,7))\
			.withColumn("plan_other_amt_paid_type", substring(col("plan_other_amt_paid_type"),0,2))\
			.withColumn("plan_other_amt_subm_type", substring(col("plan_other_amt_subm_type"),0,2))\
			.withColumn("plan_other_amt_paid_typ2", substring(col("plan_other_amt_paid_typ2"),0,2))\
			.withColumn("plan_other_amt_paid_typ3", substring(col("plan_other_amt_paid_typ3"),0,2))\
			.withColumn("pat_lang_pref_cd", substring(col("pat_lang_pref_cd"),0,1))\
			.withColumn("fill_90day_pref_ind", substring(col("fill_90day_pref_ind"),0,1))\
			.withColumn("fill_90day_pref_stat_cd", substring(col("fill_90day_pref_stat_cd"),0,1))\
			.withColumn("pat_pickup_id", substring(col("pat_pickup_id"),0,20))\
			.withColumn("pickup_id", substring(col("pickup_id"),0,20))\
			.withColumn("pickup_first_name", substring(col("pickup_first_name"),0,50))\
			.withColumn("pickup_last_name", substring(col("pickup_last_name"),0,50))\
			.withColumn("pickup_id_state", substring(col("pickup_id_state"),0,2))\
			.withColumn("pickup_id_country", substring(col("pickup_id_country"),0,2))\
			.withColumn("pickup_id_qlfr", substring(col("pickup_id_qlfr"),0,2))\
			.withColumn("pickup_rel_cd", substring(col("pickup_rel_cd"),0,2))\
			.withColumn("dl_proc_msg", substring(col("dl_proc_msg"),0,200))\
			.withColumn("cob_dl_proc_msg", substring(col("cob_dl_proc_msg"),0,81))\
			.withColumn("proc_ctrl_nbr", substring(col("proc_ctrl_nbr"),0,10))\
			.withColumn("dispensed_ndc", substring(col("dispensed_ndc"),0,11))\
			.withColumn("overstock_ind", substring(col("overstock_ind"),0,1))\
			.withColumn("med_partd_notice_ind", substring(col("med_partd_notice_ind"),0,1))\
			.withColumn("ben_stg_qualifier_1", substring(col("ben_stg_qualifier_1"),0,2))\
			.withColumn("ben_stg_qualifier_2", substring(col("ben_stg_qualifier_2"),0,2))\
			.withColumn("ben_stg_qualifier_3", substring(col("ben_stg_qualifier_3"),0,2))\
			.withColumn("ben_stg_qualifier_4", substring(col("ben_stg_qualifier_4"),0,2))\
			.withColumn("coupon_ind", substring(col("coupon_ind"),0,1))\
			.withColumn("cob_coupon_ind", substring(col("cob_coupon_ind"),0,1))\
			.withColumn("triplicate_serial_nbr", substring(col("triplicate_serial_nbr"),0,25))\
			.withColumn("delivery_ind", substring(col("delivery_ind"),0,1))\
			.withColumn("delivery_comments", substring(col("delivery_comments"),0,120))\
			.withColumn("pat_pickup_gov_auth_id", substring(col("pat_pickup_gov_auth_id"),0,3))\
			.withColumn("pat_pickup_id_qlfr", substring(col("pat_pickup_id_qlfr"),0,2))\
			.withColumn("pat_pickup_rel_cd", substring(col("pat_pickup_rel_cd"),0,2))\
			.withColumn("routing_store_rph_inits", substring(col("routing_store_rph_inits"),0,3))\
			.withColumn("source_system_name", substring(col("source_system_name"),0,10))\
			.withColumn("source_sys_trans_id", substring(col("source_sys_trans_id"),0,35))\
			.withColumn("additional_msg_qlfr_w1_cd", substring(col("additional_msg_qlfr_w1_cd"),0,20))\
			.withColumn("approved_msg_cd", substring(col("approved_msg_cd"),0,3))\
			.withColumn("approved_msg_cd_2", substring(col("approved_msg_cd_2"),0,3))\
			.withColumn("approved_msg_cd_3", substring(col("approved_msg_cd_3"),0,3))\
			.withColumn("approved_msg_cd_4", substring(col("approved_msg_cd_4"),0,3))\
			.withColumn("approved_msg_cd_5", substring(col("approved_msg_cd_5"),0,3))\
			.withColumn("cob_approved_msg_cd", substring(col("cob_approved_msg_cd"),0,3))\
			.withColumn("cob_approved_msg_cd_2", substring(col("cob_approved_msg_cd_2"),0,3))\
			.withColumn("cob_approved_msg_cd_3", substring(col("cob_approved_msg_cd_3"),0,3))\
			.withColumn("cob_approved_msg_cd_4", substring(col("cob_approved_msg_cd_4"),0,3))\
			.withColumn("cob_approved_msg_cd_5", substring(col("cob_approved_msg_cd_5"),0,3))\
			.withColumn("gen_recip_nbr_returnd", substring(col("gen_recip_nbr_returnd"),0,21))\
			.withColumn("ntwk_reimb_id_returnd", substring(col("ntwk_reimb_id_returnd"),0,10))\
			.withColumn("plan_returnd_grp_nbr", substring(col("plan_returnd_grp_nbr"),0,15))\
			.withColumn("plan_id_returnd", substring(col("plan_id_returnd"),0,8))\
			.withColumn("general_pbr_nbr", substring(col("general_pbr_nbr"),0,15))\
			.withColumn("cob_general_pbr_nbr", substring(col("cob_general_pbr_nbr"),0,15))\
			.withColumn("general_rph_nbr_qlfr", substring(col("general_rph_nbr_qlfr"),0,2))\
			.withColumn("prior_auth_cd", substring(col("prior_auth_cd"),0,1))\
			.withColumn("prior_auth_nbr", substring(col("prior_auth_nbr"),0,11))\
			.withColumn("additional_mfgr_coupon_w1_msg", substring(col("additional_mfgr_coupon_w1_msg"),0,1000))\
			.withColumn("db_cob_proc_ctrl_nbr", substring(col("db_cob_proc_ctrl_nbr"),0,10))\
			.withColumn("wo_correlation_id", substring(col("wo_correlation_id"),0,35))\
			.withColumn("short_fill_ind", substring(col("short_fill_ind"),0,1))\
            .withColumn("pay_cd",trim(col("pay_cd")))\
            .withColumn("fill_sold_yr", lit("")) \
            .withColumn("fill_enter_mnth", lit(""))


etl_tbf0_reformat_check_blank = etl_tbf0_reformat_typeCast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_typeCast.columns])

#Select Req Columns For TL Table
df_drop_nulls = etl_tbf0_reformat_check_blank.filter("store_nbr is not null and rx_nbr is not null")
df_final = df_drop_nulls.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","store_nbr","rx_nbr","fill_nbr","fill_partial_nbr","refills_remaining","fill_wac_cost_amt","plan_returnd_cost_amt","plan_returnd_fee_amt","plan_submtd_copay_amt","pbr_id","fill_source_cd","refills_remain_when_ent","cob_plan_rtrnd_fee_amt","tot_amt_paid_ind","drug_class","drug_name","drug_id","plan_returnd_copay_amt","plan_total_paid_amt","plan_returnd_tax_amt","plan_submtd_cost_amt","plan_submtd_fee_amt","plan_submtd_tax_amt","pat_id","sims_upc","pbr_loc_id","create_user_id","create_dttm","cob_plan_rtrnd_copay_amt","cob_plan_total_paid_amt","cob_plan_rtrnd_cost_amt","cob_plan_rtrnd_tax_amt","cob_plan_sbmtd_copay_amt","cob_plan_sbmtd_cost_amt","cob_plan_sbmtd_fee_amt","cob_plan_sbmtd_tax_amt","src_partition_nbr","fill_adjudication_cd","fill_awp_cost_amt","fill_days_supply","fill_entered_dttm","fill_label_price_amt","fill_qty_dispensed","fill_retail_price_amt","claim_reference_nbr","fill_nbr_dispensed","plan_id","fill_status_cd","fill_entered_user_id","fill_verified_user_id","fill_verified_dttm","fill_sold_dttm","fill_deleted_dttm","fill_discount_cd","fill_pay_method_cd","fill_discount_amt","fill_sold_amt","fill_type_cd","update_user_id","update_dttm","partial_fill_cd","fill_adjudication_dttm","cob_fill_adjudication_cd","cob_claim_ref_nbr","cob_plan_id","cob_fill_adj_dttm","fill_data_rev_id","fill_data_rev_dttm","filling_user_id","filling_dttm","override_user_id","override_dttm","entered_store_nbr","reviewed_store_nbr","plan_gross_due_amt","cob_plan_gross_due_amt","dl_reject_cd_01","dl_reject_cd_02","dl_reject_cd_03","dl_reject_cd_04","dl_reject_cd_05","fill_del_adjudication_cd","fill_price_override_amt","plan_incentive_paid_amt","general_recipient_nbr","bin_nbr","plan_group_nbr","drug_warehouse_ind","general_phrm_nbr","reimburs_loss_amt","cost_plus_fee_cd","accept_consult_ind","basis_of_reimb_determ","plan_other_amt_paid","amt_attributed_to_tax","plan_incent_amt_submtd","plan_other_amt_submtd","lvl_of_svc_cd","cob_dl_reject_cd_01","cob_dl_reject_cd_02","cob_dl_reject_cd_03","cob_dl_reject_cd_04","cob_dl_reject_cd_05","cob_fill_del_adj_cd","cob_bin_nbr","cob_plan_group_nbr","cob_general_phrm_nbr","cob_basis_of_reimb_detrm","cob_amt_attrib_to_tax","cob_pln_othr_amt_pd","cash_disc_sav_amt","general_rph_nbr","routing_store_tech_inits","sourcing_ind","maj_med_prior_auth_nbr","tip_rsn_for_svc_cd","data_rev_spec_id","data_rev_spec_store_nbr","fill_rph_of_record_id","cob_plan_incntv_paid_amt","cob_pln_incnt_amt_sbmtd","fill_est_pick_up_dttm","data_rev_spec_dttm","rx_daw_ind","relocate_fm_str_nbr","cob_gen_recipient_nbr","celgene_md_auth_nbr","celgene_conf_nbr","plan_other_amt_paid_type","plan_other_amt_subm_type","plan_returnd_coins_amt","plan_rtrnd_coins_amt","plan_other_amt_paid_2","plan_other_amt_paid_typ2","plan_other_amt_paid_3","plan_other_amt_paid_typ3","fill_print_dttm","pat_lang_pref_cd","rebilling_dttm","fill_90day_pref_ind","fill_90day_pref_stat_cd","pat_pickup_id","pickup_id","pickup_first_name","pickup_last_name","pickup_id_state","pickup_id_country","pickup_id_qlfr","pickup_rel_cd","dl_proc_msg","cob_dl_proc_msg","proc_ctrl_nbr","dispensed_ndc","overstock_ind","med_partd_notice_ind","med_partd_print_dttm","ben_stg_qualifier_1","ben_stg_qualifier_2","ben_stg_qualifier_3","ben_stg_qualifier_4","ben_stg_amount_1","ben_stg_amount_2","ben_stg_amount_3","ben_stg_amount_4","coupon_drug_id","cob_coupon_drug_id","coupon_ind","cob_coupon_ind","other_coverage_cd","cob_other_coverage_cd","partial_fil_intnded_qty","triplicate_serial_nbr","delivery_ind","delivery_comments","sold_local_dttm","pat_pickup_gov_auth_id","pat_pickup_id_qlfr","pat_pickup_rel_cd","routing_store_rph_inits","source_system_name","source_sys_trans_id","sys_status_when_ent","additional_msg_qlfr_w1_cd","approved_msg_cd","approved_msg_cd_2","approved_msg_cd_3","approved_msg_cd_4","approved_msg_cd_5","cob_approved_msg_cd","cob_approved_msg_cd_2","cob_approved_msg_cd_3","cob_approved_msg_cd_4","cob_approved_msg_cd_5","gen_recip_nbr_returnd","ntwk_reimb_id_returnd","plan_returnd_grp_nbr","plan_id_returnd","general_pbr_nbr","cob_general_pbr_nbr","general_rph_nbr_qlfr","prior_auth_cd","prior_auth_nbr","additional_mfgr_coupon_w1_msg","db_cob_proc_ctrl_nbr","wo_correlation_id","wo_rx_count","short_fill_ind","pay_cd", "filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind","pat_selct_user_id", "pbr_selct_user_id", "pat_selct_dttm", "pbr_selct_dttm", "pat_selct_str_nbr", "pbr_selct_str_nbr", "ntt_ind", "fill_sold_yr", "fill_enter_mnth", "rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3")


#Load TL_ETL_TBF0_* formatted records to the Snowflake Table
TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, TL_SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

df_final.write \
    .format("net.snowflake.spark.snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", TL_SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()

etl_tbf0_reformat_check_blank = etl_tbf0_reformat_typeCast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_typeCast.columns])



# COMMAND ----------

#drop columns to map table schema
#etl_tbf0_reformat_drop_columns = etl_tbf0_reformat_check_blank.drop("rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3","pay_cd","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind")
etl_tbf0_reformat_drop_columns = etl_tbf0_reformat_check_blank.drop("rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3","pay_cd")
# etl_tbf0_reformat_drop_columns = etl_tbf0_reformat_drop_columns.withColumn("fill_sold_yr", lit("")) \
#                                                                .withColumn("fill_enter_mnth", lit(""))

# COMMAND ----------

df_drop_nulls = etl_tbf0_reformat_drop_columns.filter("store_nbr is not null and rx_nbr is not null")
df_final = df_drop_nulls.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","store_nbr","rx_nbr","fill_nbr","fill_partial_nbr","refills_remaining","fill_wac_cost_amt","plan_returnd_cost_amt","plan_returnd_fee_amt","plan_submtd_copay_amt","pbr_id","fill_source_cd","refills_remain_when_ent","cob_plan_rtrnd_fee_amt","tot_amt_paid_ind","drug_class","drug_name","drug_id","plan_returnd_copay_amt","plan_total_paid_amt","plan_returnd_tax_amt","plan_submtd_cost_amt","plan_submtd_fee_amt","plan_submtd_tax_amt","pat_id","sims_upc","pbr_loc_id","create_user_id","create_dttm","cob_plan_rtrnd_copay_amt","cob_plan_total_paid_amt","cob_plan_rtrnd_cost_amt","cob_plan_rtrnd_tax_amt","cob_plan_sbmtd_copay_amt","cob_plan_sbmtd_cost_amt","cob_plan_sbmtd_fee_amt","cob_plan_sbmtd_tax_amt","src_partition_nbr","fill_adjudication_cd","fill_awp_cost_amt","fill_days_supply","fill_entered_dttm","fill_label_price_amt","fill_qty_dispensed","fill_retail_price_amt","claim_reference_nbr","fill_nbr_dispensed","plan_id","fill_status_cd","fill_entered_user_id","fill_verified_user_id","fill_verified_dttm","fill_sold_dttm","fill_deleted_dttm","fill_discount_cd","fill_pay_method_cd","fill_discount_amt","fill_sold_amt","fill_type_cd","update_user_id","update_dttm","partial_fill_cd","fill_adjudication_dttm","cob_fill_adjudication_cd","cob_claim_ref_nbr","cob_plan_id","cob_fill_adj_dttm","fill_data_rev_id","fill_data_rev_dttm","filling_user_id","filling_dttm","override_user_id","override_dttm","entered_store_nbr","reviewed_store_nbr","plan_gross_due_amt","cob_plan_gross_due_amt","dl_reject_cd_01","dl_reject_cd_02","dl_reject_cd_03","dl_reject_cd_04","dl_reject_cd_05","fill_del_adjudication_cd","fill_price_override_amt","plan_incentive_paid_amt","general_recipient_nbr","bin_nbr","plan_group_nbr","drug_warehouse_ind","general_phrm_nbr","reimburs_loss_amt","cost_plus_fee_cd","accept_consult_ind","basis_of_reimb_determ","plan_other_amt_paid","amt_attributed_to_tax","plan_incent_amt_submtd","plan_other_amt_submtd","lvl_of_svc_cd","cob_dl_reject_cd_01","cob_dl_reject_cd_02","cob_dl_reject_cd_03","cob_dl_reject_cd_04","cob_dl_reject_cd_05","cob_fill_del_adj_cd","cob_bin_nbr","cob_plan_group_nbr","cob_general_phrm_nbr","cob_basis_of_reimb_detrm","cob_amt_attrib_to_tax","cob_pln_othr_amt_pd","cash_disc_sav_amt","general_rph_nbr","routing_store_tech_inits","sourcing_ind","maj_med_prior_auth_nbr","tip_rsn_for_svc_cd","data_rev_spec_id","data_rev_spec_store_nbr","fill_rph_of_record_id","cob_plan_incntv_paid_amt","cob_pln_incnt_amt_sbmtd","fill_est_pick_up_dttm","data_rev_spec_dttm","rx_daw_ind","relocate_fm_str_nbr","cob_gen_recipient_nbr","celgene_md_auth_nbr","celgene_conf_nbr","plan_other_amt_paid_type","plan_other_amt_subm_type","plan_returnd_coins_amt","plan_rtrnd_coins_amt","plan_other_amt_paid_2","plan_other_amt_paid_typ2","plan_other_amt_paid_3","plan_other_amt_paid_typ3","fill_print_dttm","pat_lang_pref_cd","rebilling_dttm","fill_90day_pref_ind","fill_90day_pref_stat_cd","pat_pickup_id","pickup_id","pickup_first_name","pickup_last_name","pickup_id_state","pickup_id_country","pickup_id_qlfr","pickup_rel_cd","dl_proc_msg","cob_dl_proc_msg","proc_ctrl_nbr","dispensed_ndc","overstock_ind","med_partd_notice_ind","med_partd_print_dttm","ben_stg_qualifier_1","ben_stg_qualifier_2","ben_stg_qualifier_3","ben_stg_qualifier_4","ben_stg_amount_1","ben_stg_amount_2","ben_stg_amount_3","ben_stg_amount_4","coupon_drug_id","cob_coupon_drug_id","coupon_ind","cob_coupon_ind","other_coverage_cd","cob_other_coverage_cd","partial_fil_intnded_qty","triplicate_serial_nbr","delivery_ind","delivery_comments","sold_local_dttm","pat_pickup_gov_auth_id","pat_pickup_id_qlfr","pat_pickup_rel_cd","routing_store_rph_inits","source_system_name","source_sys_trans_id","sys_status_when_ent","additional_msg_qlfr_w1_cd","approved_msg_cd","approved_msg_cd_2","approved_msg_cd_3","approved_msg_cd_4","approved_msg_cd_5","cob_approved_msg_cd","cob_approved_msg_cd_2","cob_approved_msg_cd_3","cob_approved_msg_cd_4","cob_approved_msg_cd_5","gen_recip_nbr_returnd","ntwk_reimb_id_returnd","plan_returnd_grp_nbr","plan_id_returnd","general_pbr_nbr","cob_general_pbr_nbr","general_rph_nbr_qlfr","prior_auth_cd","prior_auth_nbr","additional_mfgr_coupon_w1_msg","db_cob_proc_ctrl_nbr","wo_correlation_id","wo_rx_count","short_fill_ind","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind","pat_selct_user_id", "pbr_selct_user_id", "pat_selct_dttm", "pbr_selct_dttm", "pat_selct_str_nbr", "pbr_selct_str_nbr", "ntt_ind", "fill_sold_yr", "fill_enter_mnth")

# COMMAND ----------

#display(df_final)

# COMMAND ----------

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

df_final.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", SNFL_TBL_NAME) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()

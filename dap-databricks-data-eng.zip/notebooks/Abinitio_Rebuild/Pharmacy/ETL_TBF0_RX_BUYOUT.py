# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
# FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
# READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPI", 200, 
#                   {"PAR_READAPI_KEY":"feedNames",
#                    "PAR_READAPI_URL":READAPI_URL,
#                    "PAR_READAPI_VALUE":FEED_NAME,
#                    "PAR_RETURN_FILE_TYPE":"A"});


# print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")
FEED_NAME = dbutils.widgets.get("PAR_DB_FEED_NAME")
Input_File_List=dbutils.widgets.get("PAR_UNPROCESSED_FILES")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

 

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'send_phrm_name',
'send_phrm_name_after',
'send_phrm_addr',
'send_phrm_addr_after',
'send_phrm_city',
'send_phrm_city_after',
'send_phrm_state',
'send_phrm_state_after',
'send_phrm_nabp',
'send_phrm_nabp_after',
'send_rph_init',
'send_rph_init_after',
'buyout_rx_nbr',
'buyout_rx_nbr_after',
'pat_code',
'pat_code_after',
'buyout_drug_name',
'buyout_drug_name_after',
'buyout_drug_strength',
'buyout_drug_strength_after',
'ndc_mfg',
'ndc_mfg_after',
'ndc_prod',
'ndc_prod_after',
'ndc_pkg',
'ndc_pkg_after',
'rx_daw_ind',
'rx_daw_ind_after',
'rx_original_fill_dttm',
'rx_original_fill_dttm_after',
'rx_status',
'rx_status_after',
'rx_sig',
'rx_sig_after',
'rx_written_dttm',
'rx_written_dttm_after',
'rx_original_qty',
'rx_original_qty_after',
'rx_original_qty_disp',
'rx_original_qty_disp_after',
'rx_cmts',
'rx_cmts_after',
'rx_qty_remaining',
'rx_qty_remaining_after',
'fill_days_supply',
'fill_days_supply_after',
'fill_nbr_prescribed',
'fill_nbr_prescribed_after',
'fill_nbr_remaining',
'fill_nbr_remaining_after',
'drug_mfg_name',
'drug_mfg_name_after',
'pbr_last_name',
'pbr_last_name_after',
'pbr_first_name',
'pbr_first_name_after',
'pbr_dea_nbr',
'pbr_dea_nbr_after',
'pbr_addr',
'pbr_addr_after',
'pbr_city',
'pbr_city_after',
'pbr_state',
'pbr_state_after',
'pbr_zip',
'pbr_zip_after',
'create_dttm',
'create_dttm_after',
'fill_entered_dttm',
'fill_entered_dttm_after',
'rx_xfr_to_store_nbr',
'rx_xfr_to_store_nbr_after',
'rx_xfr_to_rx_nbr',
'rx_xfr_to_rx_nbr_after',
'rx_close_reason_cd',
'rx_close_reason_cd_after',
'rx_close_reason_cmt',
'rx_close_reason_cmt_after',
'rx_xfr_to_rph_init',
'rx_xfr_to_rph_init_after',
'rx_xfr_compt_name',
'rx_xfr_compt_name_after',
'rx_xfr_compt_area_cd',
'rx_xfr_compt_area_cd_after',
'rx_xfr_compt_phone_nbr',
'rx_xfr_compt_phone_nbr_after',
'rx_xfr_to_tech_init',
'rx_xfr_to_tech_init_after',
'pat_id',
'pat_id_after',
'rx_xfr_from_store_nbr',
'rx_xfr_from_store_nbr_after',
'rx_xfr_from_rph_init',
'rx_xfr_from_rph_init_after',
'rx_trnsf_close_reason_cd',
'rx_trnsf_close_reason_cd_after',
'rx_xfr_from_tech_init',
'rx_xfr_from_tech_init_after'
]

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if '"INSERT"' in key_list[6]:
    if val_len != 111 : # your total column count -1
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 112:  # your total cloumn count 
      return True
  else:
    if val_len != 112:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

#in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)
  #display(df_junk)

# COMMAND ----------

#split and add schema
col_len = 112

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)
print(f"Good records count {rd_good.count()}") # = 62
print(f"Bad records count {rd_bad.count()}") # != 62
schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

#Extarct filename
from pyspark.sql.functions import input_file_name
df = spark.createDataFrame(rd_good, schema)
df_fileName = df.withColumn("fileName",input_file_name())

#Extract partition number from file name
df_split = df_fileName.withColumn("src_partition_nbr",concat(split(col("fileName"),"_")[7]))
df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df_split = df_split.drop("fileName")

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

#df_split = df_split.drop('row_length')
# df_split = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df_split.columns,
#     df_split
# ))

# COMMAND ----------

df_split = df_split.drop('row_length')
df_split = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    df_split.columns,
    df_split
))

# COMMAND ----------

display(df_split)

# COMMAND ----------

df_split.createOrReplaceTempView("gg_tbf0_rx_buyout")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_rx_buyout where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_rx_buyout"))
df_gg.createOrReplaceTempView("raw_gg_tbf0_rx_buyout")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  


pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcGgTbf0Schema

pUpdateReform="((buyout_rx_nbr == buyout_rx_nbr_after AND buyout_rx_nbr IS NOT NULL AND buyout_rx_nbr_after IS NOT NULL) AND   (pat_code == pat_code_after AND pat_code IS NOT NULL AND pat_code_after IS NOT NULL) AND   (cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL) AND   (cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL) AND   (cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL) AND  (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL) AND   (cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND cdc_operation_type_cd_after IS NOT NULL ) AND  (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL ) AND   (cdc_operation_type_cd == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL) AND  (( send_phrm_name == send_phrm_name_after AND send_phrm_name IS NOT NULL AND send_phrm_name_after IS NOT NULL) OR ( send_phrm_name IS NULL AND  send_phrm_name_after IS NULL ) ) AND  (( send_phrm_city == send_phrm_city_after AND send_phrm_city IS NOT NULL AND send_phrm_city_after IS NOT NULL )OR ( send_phrm_city IS NULL AND  send_phrm_city_after IS NULL ) ) AND  (( send_phrm_state == send_phrm_state_after AND send_phrm_state IS NOT NULL AND send_phrm_state_after IS NOT NULL) OR ( send_phrm_state IS NULL AND  send_phrm_state_after IS NULL ) ) AND  (( ndc_mfg == ndc_mfg_after AND ndc_mfg IS NOT NULL AND ndc_mfg_after IS NOT NULL) OR ( ndc_mfg IS NULL AND  ndc_mfg_after IS NULL ) ) AND  (( ndc_prod == ndc_prod_after AND ndc_prod IS NOT NULL AND ndc_prod_after IS NOT NULL )OR ( ndc_prod IS NULL AND  ndc_prod_after IS NULL ) ) AND  (( ndc_pkg == ndc_pkg_after AND ndc_pkg IS NOT NULL AND ndc_pkg_after IS NOT NULL) OR ( ndc_pkg IS NULL AND  ndc_pkg_after IS NULL ) ) AND  (( rx_daw_ind == rx_daw_ind_after AND rx_daw_ind IS NOT NULL AND rx_daw_ind_after IS NOT NULL) OR ( rx_daw_ind IS NULL AND  rx_daw_ind_after IS NULL ) ) AND  (( rx_original_fill_dttm == rx_original_fill_dttm_after AND rx_original_fill_dttm IS NOT NULL AND rx_original_fill_dttm_after IS NOT NULL) OR ( rx_original_fill_dttm IS NULL AND  rx_original_fill_dttm_after IS NULL ) ) AND  (( rx_sig == rx_sig_after AND rx_sig IS NOT NULL AND rx_sig_after IS NOT NULL) OR ( rx_sig IS NULL AND  rx_sig_after IS NULL ) ) AND  (( rx_written_dttm == rx_written_dttm_after AND rx_written_dttm IS NOT NULL AND rx_written_dttm_after IS NOT NULL) OR ( rx_written_dttm IS NULL AND  rx_written_dttm_after IS NULL ) ) AND  (( fill_days_supply == fill_days_supply_after AND fill_days_supply IS NOT NULL AND fill_days_supply_after IS NOT NULL) OR ( fill_days_supply IS NULL AND  fill_days_supply_after IS NULL ) ) AND  (( fill_nbr_prescribed == fill_nbr_prescribed_after AND fill_nbr_prescribed IS NOT NULL AND fill_nbr_prescribed_after IS NOT NULL) OR ( fill_nbr_prescribed IS NULL AND  fill_nbr_prescribed_after IS NULL ) ) AND  (( fill_nbr_remaining == fill_nbr_remaining_after AND fill_nbr_remaining IS NOT NULL AND fill_nbr_remaining_after IS NOT NULL) OR ( fill_nbr_remaining IS NULL AND  fill_nbr_remaining_after IS NULL ) ) AND  (( drug_mfg_name == drug_mfg_name_after AND drug_mfg_name IS NOT NULL AND drug_mfg_name_after IS NOT NULL) OR ( drug_mfg_name IS NULL AND  drug_mfg_name_after IS NULL ) ) AND  (( pbr_last_name == pbr_last_name_after AND pbr_last_name IS NOT NULL AND pbr_last_name_after IS NOT NULL) OR ( pbr_last_name IS NULL AND  pbr_last_name_after IS NULL ) ) AND  (( pbr_first_name == pbr_first_name_after AND pbr_first_name IS NOT NULL AND pbr_first_name_after IS NOT NULL) OR ( pbr_first_name IS NULL AND  pbr_first_name_after IS NULL ) ) AND  (( pbr_dea_nbr == pbr_dea_nbr_after AND pbr_dea_nbr IS NOT NULL AND pbr_dea_nbr_after IS NOT NULL) OR ( pbr_dea_nbr IS NULL AND  pbr_dea_nbr_after IS NULL ) ) AND  (( pbr_addr == pbr_addr_after AND pbr_addr IS NOT NULL AND pbr_addr_after IS NOT NULL ) OR ( pbr_addr IS NULL AND  pbr_addr_after IS NULL ) ) AND  (( pbr_city == pbr_city_after AND pbr_city IS NOT NULL AND pbr_city_after IS NOT NULL) OR ( pbr_city IS NULL AND  pbr_city_after IS NULL ) ) AND  (( pbr_state == pbr_state_after AND pbr_state IS NOT NULL AND pbr_state_after IS NOT NULL) OR ( pbr_state IS NULL AND  pbr_state_after IS NULL ) ) AND  (( pbr_zip == pbr_zip_after AND pbr_zip IS NOT NULL AND pbr_zip_after IS NOT NULL ) OR ( pbr_zip IS NULL AND  pbr_zip_after IS NULL ) ) AND  (( fill_entered_dttm == fill_entered_dttm_after AND fill_entered_dttm IS NOT NULL AND fill_entered_dttm_after IS NOT NULL ) OR ( fill_entered_dttm IS NULL AND  fill_entered_dttm_after IS NULL ) ) AND  (( rx_xfr_to_store_nbr == rx_xfr_to_store_nbr_after AND rx_xfr_to_store_nbr IS NOT NULL AND rx_xfr_to_store_nbr_after IS NOT NULL) OR ( rx_xfr_to_store_nbr IS NULL AND  rx_xfr_to_store_nbr_after IS NULL ) ) AND  (( rx_xfr_to_rx_nbr == rx_xfr_to_rx_nbr_after AND rx_xfr_to_rx_nbr IS NOT NULL AND rx_xfr_to_rx_nbr_after IS NOT NULL) OR ( rx_xfr_to_rx_nbr IS NULL AND  rx_xfr_to_rx_nbr_after IS NULL ) ) AND  (( rx_xfr_compt_name == rx_xfr_compt_name_after AND rx_xfr_compt_name IS NOT NULL AND rx_xfr_compt_name_after IS NOT NULL) OR ( rx_xfr_compt_name IS NULL AND  rx_xfr_compt_name_after IS NULL ) ) AND  (( pat_id == pat_id_after AND pat_id IS NOT NULL AND pat_id_after IS NOT NULL) OR ( pat_id IS NULL AND  pat_id_after IS NULL ) ) AND  (( rx_xfr_from_store_nbr == rx_xfr_from_store_nbr_after AND rx_xfr_from_store_nbr IS NOT NULL AND rx_xfr_from_store_nbr_after IS NOT NULL) OR ( rx_xfr_from_store_nbr IS NULL AND  rx_xfr_from_store_nbr_after IS NULL ) ) AND  (( send_phrm_nabp == send_phrm_nabp_after AND send_phrm_nabp IS NOT NULL AND send_phrm_nabp_after IS NOT NULL) OR ( send_phrm_nabp IS NULL AND  send_phrm_nabp_after IS NULL ) ) AND  (( rx_close_reason_cd == rx_close_reason_cd_after AND rx_close_reason_cd IS NOT NULL AND rx_close_reason_cd_after IS NOT NULL) OR ( rx_close_reason_cd IS NULL AND  rx_close_reason_cd_after IS NULL ) ) AND  (( rx_close_reason_cmt == rx_close_reason_cmt_after AND rx_close_reason_cmt IS NOT NULL AND rx_close_reason_cmt_after IS NOT NULL) OR ( rx_close_reason_cmt IS NULL AND  rx_close_reason_cmt_after IS NULL ) ) AND  (( rx_xfr_to_rph_init == rx_xfr_to_rph_init_after AND rx_xfr_to_rph_init IS NOT NULL AND rx_xfr_to_rph_init_after IS NOT NULL ) OR ( rx_xfr_to_rph_init IS NULL AND  rx_xfr_to_rph_init_after IS NULL ) ) AND  (( rx_xfr_compt_area_cd == rx_xfr_compt_area_cd_after AND rx_xfr_compt_area_cd IS NOT NULL AND rx_xfr_compt_area_cd_after IS NOT NULL) OR ( rx_xfr_compt_area_cd IS NULL AND  rx_xfr_compt_area_cd_after IS NULL ) ) AND  (( rx_xfr_compt_phone_nbr == rx_xfr_compt_phone_nbr_after  AND rx_xfr_compt_phone_nbr IS NOT NULL AND rx_xfr_compt_phone_nbr_after IS NOT NULL ) OR ( rx_xfr_compt_phone_nbr IS NULL AND  rx_xfr_compt_phone_nbr_after IS NULL ) ) AND  (( rx_xfr_to_tech_init == rx_xfr_to_tech_init_after AND rx_xfr_to_tech_init IS NOT NULL AND rx_xfr_to_tech_init_after IS NOT NULL) OR ( rx_xfr_to_tech_init IS NULL AND  rx_xfr_to_tech_init_after IS NULL ) ) AND  (( rx_xfr_from_rph_init == rx_xfr_from_rph_init_after AND rx_xfr_from_rph_init IS NOT NULL AND rx_xfr_from_rph_init_after IS NOT NULL) OR ( rx_xfr_from_rph_init IS NULL AND  rx_xfr_from_rph_init_after IS NULL ) ) AND  (( rx_trnsf_close_reason_cd == rx_trnsf_close_reason_cd_after AND rx_trnsf_close_reason_cd IS NOT NULL AND rx_trnsf_close_reason_cd_after IS NOT NULL) OR ( rx_trnsf_close_reason_cd IS NULL AND  rx_trnsf_close_reason_cd_after IS NULL ) ) AND  (( rx_xfr_from_tech_init == rx_xfr_from_tech_init_after AND rx_xfr_from_tech_init IS NOT NULL AND rx_xfr_from_tech_init_after IS NOT NULL) OR ( rx_xfr_from_tech_init IS NULL AND  rx_xfr_from_tech_init_after IS NULL ) ) AND  (( send_rph_init == send_rph_init_after AND send_rph_init IS NOT NULL AND send_rph_init_after IS NOT NULL) OR ( send_rph_init IS NULL AND  send_rph_init_after IS NULL ) ) AND  (( buyout_drug_name == buyout_drug_name_after AND buyout_drug_name IS NOT NULL AND buyout_drug_name_after IS NOT NULL) OR ( buyout_drug_name IS NULL AND  buyout_drug_name_after IS NULL ) ) AND  (( buyout_drug_strength == buyout_drug_strength_after AND buyout_drug_strength IS NOT NULL AND buyout_drug_strength_after IS NOT NULL) OR ( buyout_drug_strength IS NULL AND  buyout_drug_strength_after IS NULL ) ) AND  (( rx_status == rx_status_after AND rx_status IS NOT NULL AND rx_status_after IS NOT NULL) OR ( rx_status IS NULL AND  rx_status_after IS NULL ) ) AND  (( rx_original_qty == rx_original_qty_after  AND rx_original_qty IS NOT NULL AND rx_original_qty_after IS NOT NULL) OR ( rx_original_qty IS NULL AND  rx_original_qty_after IS NULL ) ) AND  (( rx_original_qty_disp == rx_original_qty_disp_after AND rx_original_qty_disp IS NOT NULL AND rx_original_qty_disp_after IS NOT NULL) OR ( rx_original_qty_disp IS NULL AND  rx_original_qty_disp_after IS NULL ) ) AND  (( rx_cmts == rx_cmts_after AND rx_cmts IS NOT NULL AND rx_cmts_after IS NOT NULL) OR ( rx_cmts IS NULL AND  rx_cmts_after IS NULL ) ) AND  (( rx_qty_remaining == rx_qty_remaining_after AND rx_qty_remaining IS NOT NULL AND rx_qty_remaining_after IS NOT NULL) OR ( rx_qty_remaining IS NULL AND  rx_qty_remaining_after IS NULL ) ) )"


#pSrcCleanseXfr

#pTgtUpdBfrXfr

#pTgtUpdAftXfr
 
pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, send_phrm_name, send_phrm_addr, send_phrm_city, send_phrm_state, buyout_rx_nbr, pat_code, ndc_mfg, ndc_prod, ndc_pkg, rx_daw_ind, CONCAT(rx_original_fill_dttm,'.000000') AS rx_original_fill_dttm, rx_sig, CONCAT(rx_written_dttm,'.000000') AS rx_written_dttm, fill_days_supply, fill_nbr_prescribed, fill_nbr_remaining, drug_mfg_name, pbr_last_name, pbr_first_name, pbr_dea_nbr, pbr_addr, pbr_city, pbr_state, pbr_zip, CONCAT(fill_entered_dttm,'.000000') AS fill_entered_dttm, rx_xfr_to_store_nbr, rx_xfr_to_rx_nbr, rx_xfr_compt_name, pat_id, rx_xfr_from_store_nbr, send_phrm_nabp, rx_close_reason_cd, rx_close_reason_cmt, rx_xfr_to_rph_init, rx_xfr_compt_area_cd, rx_xfr_compt_phone_nbr, rx_xfr_to_tech_init, rx_xfr_from_rph_init, rx_trnsf_close_reason_cd, rx_xfr_from_tech_init, send_rph_init, buyout_drug_name, buyout_drug_strength, rx_status, rx_original_qty, rx_original_qty_disp, rx_cmts, rx_qty_remaining, CONCAT(create_dttm,'.000000') AS create_dttm, tracking_id, partition_column" 




# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == "WALGREENS"))
#display(cutoff_records_filter)
#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
rx_trans_max = cutoff_range_trans.select("rx_trans_max")



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_rx_buyout where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_rx_buyout where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_rx_buyout where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) 
  #rx_max = to_timestamxp(cutoff_range_rx.rx_max)
  #display(nr_input_file_filter_rx)
  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)
#display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()


dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(TRIM(send_phrm_name))==0) then send_phrm_name else TRIM(send_phrm_name)  end) as send_phrm_name , (case when (LENGTH(TRIM(send_phrm_name_after))==0) then send_phrm_name_after else TRIM(send_phrm_name_after)  end) as send_phrm_name_after , (case when (LENGTH(TRIM(send_phrm_addr))==0) then send_phrm_addr else TRIM(send_phrm_addr)  end) as send_phrm_addr , (case when (LENGTH(TRIM(send_phrm_addr_after))==0) then send_phrm_addr_after else TRIM(send_phrm_addr_after)  end) as send_phrm_addr_after , (case when (LENGTH(TRIM(send_phrm_city))==0) then send_phrm_city else TRIM(send_phrm_city)  end) as send_phrm_city , (case when (LENGTH(TRIM(send_phrm_city_after))==0) then send_phrm_city_after else TRIM(send_phrm_city_after)  end) as send_phrm_city_after , (case when (LENGTH(TRIM(send_phrm_state))==0) then send_phrm_state else TRIM(send_phrm_state)  end) as send_phrm_state , (case when (LENGTH(TRIM(send_phrm_state_after))==0) then send_phrm_state_after else TRIM(send_phrm_state_after)  end) as send_phrm_state_after , (case when (LENGTH(TRIM(send_phrm_nabp))==0) then send_phrm_nabp else TRIM(send_phrm_nabp)  end) as send_phrm_nabp , (case when (LENGTH(TRIM(send_phrm_nabp_after))==0) then send_phrm_nabp_after else TRIM(send_phrm_nabp_after)  end) as send_phrm_nabp_after , (case when (LENGTH(TRIM(send_rph_init))==0) then send_rph_init else TRIM(send_rph_init)  end) as send_rph_init , (case when (LENGTH(TRIM(send_rph_init_after))==0) then send_rph_init_after else TRIM(send_rph_init_after)  end) as send_rph_init_after , (case when (LENGTH(TRIM(buyout_rx_nbr))==0) then buyout_rx_nbr else TRIM(buyout_rx_nbr)  end) as buyout_rx_nbr , (case when (LENGTH(TRIM(buyout_rx_nbr_after))==0) then buyout_rx_nbr_after else TRIM(buyout_rx_nbr_after)  end) as buyout_rx_nbr_after , (case when (LENGTH(TRIM(pat_code))==0) then pat_code else TRIM(pat_code)  end) as pat_code , (case when (LENGTH(TRIM(pat_code_after))==0) then pat_code_after else TRIM(pat_code_after)  end) as pat_code_after , (case when (LENGTH(TRIM(buyout_drug_name))==0) then buyout_drug_name else TRIM(buyout_drug_name)  end) as buyout_drug_name , (case when (LENGTH(TRIM(buyout_drug_name_after))==0) then buyout_drug_name_after else TRIM(buyout_drug_name_after)  end) as buyout_drug_name_after , (case when (LENGTH(TRIM(buyout_drug_strength))==0) then buyout_drug_strength else TRIM(buyout_drug_strength)  end) as buyout_drug_strength , (case when (LENGTH(TRIM(buyout_drug_strength_after))==0) then buyout_drug_strength_after else TRIM(buyout_drug_strength_after)  end) as buyout_drug_strength_after , (case when (LENGTH(TRIM(ndc_mfg))==0) then ndc_mfg else TRIM(ndc_mfg)  end) as ndc_mfg , (case when (LENGTH(TRIM(ndc_mfg_after))==0) then ndc_mfg_after else TRIM(ndc_mfg_after)  end) as ndc_mfg_after , (case when (LENGTH(TRIM(ndc_prod))==0) then ndc_prod else TRIM(ndc_prod)  end) as ndc_prod , (case when (LENGTH(TRIM(ndc_prod_after))==0) then ndc_prod_after else TRIM(ndc_prod_after)  end) as ndc_prod_after , (case when (LENGTH(TRIM(ndc_pkg))==0) then ndc_pkg else TRIM(ndc_pkg)  end) as ndc_pkg , (case when (LENGTH(TRIM(ndc_pkg_after))==0) then ndc_pkg_after else TRIM(ndc_pkg_after)  end) as ndc_pkg_after , (case when (LENGTH(TRIM(rx_daw_ind))==0) then rx_daw_ind else TRIM(rx_daw_ind)  end) as rx_daw_ind , (case when (LENGTH(TRIM(rx_daw_ind_after))==0) then rx_daw_ind_after else TRIM(rx_daw_ind_after)  end) as rx_daw_ind_after , CONCAT(CONCAT(SUBSTRING(rx_original_fill_dttm,0,10),' '),SUBSTRING(rx_original_fill_dttm,11,19)) as rx_original_fill_dttm , CONCAT(CONCAT(SUBSTRING(rx_original_fill_dttm_after,0,10),' '),SUBSTRING(rx_original_fill_dttm_after,11,19)) as rx_original_fill_dttm_after , (case when (LENGTH(TRIM(rx_status))==0) then rx_status else TRIM(rx_status)  end) as rx_status , (case when (LENGTH(TRIM(rx_status_after))==0) then rx_status_after else TRIM(rx_status_after)  end) as rx_status_after , (case when (LENGTH(TRIM(rx_sig))==0) then rx_sig else TRIM(rx_sig)  end) as rx_sig , (case when (LENGTH(TRIM(rx_sig_after))==0) then rx_sig_after else TRIM(rx_sig_after)  end) as rx_sig_after , CONCAT(CONCAT(SUBSTRING(rx_written_dttm,0,10),' '),SUBSTRING(rx_written_dttm,11,19)) as rx_written_dttm , CONCAT(CONCAT(SUBSTRING(rx_written_dttm_after,0,10),' '),SUBSTRING(rx_written_dttm_after,11,19)) as rx_written_dttm_after , (case when (LENGTH(TRIM(rx_original_qty))==0) then rx_original_qty else TRIM(rx_original_qty)  end) as rx_original_qty , (case when (LENGTH(TRIM(rx_original_qty_after))==0) then rx_original_qty_after else TRIM(rx_original_qty_after)  end) as rx_original_qty_after , (case when (LENGTH(TRIM(rx_original_qty_disp))==0) then rx_original_qty_disp else TRIM(rx_original_qty_disp)  end) as rx_original_qty_disp , (case when (LENGTH(TRIM(rx_original_qty_disp_after))==0) then rx_original_qty_disp_after else TRIM(rx_original_qty_disp_after)  end) as rx_original_qty_disp_after , (case when (LENGTH(TRIM(rx_cmts))==0) then rx_cmts else TRIM(rx_cmts)  end) as rx_cmts , (case when (LENGTH(TRIM(rx_cmts_after))==0) then rx_cmts_after else TRIM(rx_cmts_after)  end) as rx_cmts_after , (case when (LENGTH(TRIM(rx_qty_remaining))==0) then rx_qty_remaining else TRIM(rx_qty_remaining)  end) as rx_qty_remaining , (case when (LENGTH(TRIM(rx_qty_remaining_after))==0) then rx_qty_remaining_after else TRIM(rx_qty_remaining_after)  end) as rx_qty_remaining_after , (case when (LENGTH(TRIM(fill_days_supply))==0) then fill_days_supply else TRIM(fill_days_supply)  end) as fill_days_supply , (case when (LENGTH(TRIM(fill_days_supply_after))==0) then fill_days_supply_after else TRIM(fill_days_supply_after)  end) as fill_days_supply_after , (case when (LENGTH(TRIM(fill_nbr_prescribed))==0) then fill_nbr_prescribed else TRIM(fill_nbr_prescribed)  end) as fill_nbr_prescribed , (case when (LENGTH(TRIM(fill_nbr_prescribed_after))==0) then fill_nbr_prescribed_after else TRIM(fill_nbr_prescribed_after)  end) as fill_nbr_prescribed_after , (case when (LENGTH(TRIM(fill_nbr_remaining))==0) then fill_nbr_remaining else TRIM(fill_nbr_remaining)  end) as fill_nbr_remaining , (case when (LENGTH(TRIM(fill_nbr_remaining_after))==0) then fill_nbr_remaining_after else TRIM(fill_nbr_remaining_after)  end) as fill_nbr_remaining_after , (case when (LENGTH(TRIM(drug_mfg_name))==0) then drug_mfg_name else TRIM(drug_mfg_name)  end) as drug_mfg_name , (case when (LENGTH(TRIM(drug_mfg_name_after))==0) then drug_mfg_name_after else TRIM(drug_mfg_name_after)  end) as drug_mfg_name_after , (case when (LENGTH(TRIM(pbr_last_name))==0) then pbr_last_name else TRIM(pbr_last_name)  end) as pbr_last_name , (case when (LENGTH(TRIM(pbr_last_name_after))==0) then pbr_last_name_after else TRIM(pbr_last_name_after)  end) as pbr_last_name_after , (case when (LENGTH(TRIM(pbr_first_name))==0) then pbr_first_name else TRIM(pbr_first_name)  end) as pbr_first_name , (case when (LENGTH(TRIM(pbr_first_name_after))==0) then pbr_first_name_after else TRIM(pbr_first_name_after)  end) as pbr_first_name_after , (case when (LENGTH(TRIM(pbr_dea_nbr))==0) then pbr_dea_nbr else TRIM(pbr_dea_nbr)  end) as pbr_dea_nbr , (case when (LENGTH(TRIM(pbr_dea_nbr_after))==0) then pbr_dea_nbr_after else TRIM(pbr_dea_nbr_after)  end) as pbr_dea_nbr_after , (case when (LENGTH(TRIM(pbr_addr))==0) then pbr_addr else TRIM(pbr_addr)  end) as pbr_addr , (case when (LENGTH(TRIM(pbr_addr_after))==0) then pbr_addr_after else TRIM(pbr_addr_after)  end) as pbr_addr_after , (case when (LENGTH(TRIM(pbr_city))==0) then pbr_city else TRIM(pbr_city)  end) as pbr_city , (case when (LENGTH(TRIM(pbr_city_after))==0) then pbr_city_after else TRIM(pbr_city_after)  end) as pbr_city_after , (case when (LENGTH(TRIM(pbr_state))==0) then pbr_state else TRIM(pbr_state)  end) as pbr_state , (case when (LENGTH(TRIM(pbr_state_after))==0) then pbr_state_after else TRIM(pbr_state_after)  end) as pbr_state_after , (case when (LENGTH(TRIM(pbr_zip))==0) then pbr_zip else TRIM(pbr_zip)  end) as pbr_zip , (case when (LENGTH(TRIM(pbr_zip_after))==0) then pbr_zip_after else TRIM(pbr_zip_after)  end) as pbr_zip_after , CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm,11,19)) as create_dttm , CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after,11,19)) as create_dttm_after , CONCAT(CONCAT(SUBSTRING(fill_entered_dttm,0,10),' '),SUBSTRING(fill_entered_dttm,11,19)) as fill_entered_dttm , CONCAT(CONCAT(SUBSTRING(fill_entered_dttm_after,0,10),' '),SUBSTRING(fill_entered_dttm_after,11,19)) as fill_entered_dttm_after , (case when (LENGTH(TRIM(rx_xfr_to_store_nbr))==0) then rx_xfr_to_store_nbr else TRIM(rx_xfr_to_store_nbr)  end) as rx_xfr_to_store_nbr , (case when (LENGTH(TRIM(rx_xfr_to_store_nbr_after))==0) then rx_xfr_to_store_nbr_after else TRIM(rx_xfr_to_store_nbr_after)  end) as rx_xfr_to_store_nbr_after , (case when (LENGTH(TRIM(rx_xfr_to_rx_nbr))==0) then rx_xfr_to_rx_nbr else TRIM(rx_xfr_to_rx_nbr)  end) as rx_xfr_to_rx_nbr , (case when (LENGTH(TRIM(rx_xfr_to_rx_nbr_after))==0) then rx_xfr_to_rx_nbr_after else TRIM(rx_xfr_to_rx_nbr_after)  end) as rx_xfr_to_rx_nbr_after , (case when (LENGTH(TRIM(rx_close_reason_cd))==0) then rx_close_reason_cd else TRIM(rx_close_reason_cd)  end) as rx_close_reason_cd , (case when (LENGTH(TRIM(rx_close_reason_cd_after))==0) then rx_close_reason_cd_after else TRIM(rx_close_reason_cd_after)  end) as rx_close_reason_cd_after , (case when (LENGTH(TRIM(rx_close_reason_cmt))==0) then rx_close_reason_cmt else TRIM(rx_close_reason_cmt)  end) as rx_close_reason_cmt , (case when (LENGTH(TRIM(rx_close_reason_cmt_after))==0) then rx_close_reason_cmt_after else TRIM(rx_close_reason_cmt_after)  end) as rx_close_reason_cmt_after , (case when (LENGTH(TRIM(rx_xfr_to_rph_init))==0) then rx_xfr_to_rph_init else TRIM(rx_xfr_to_rph_init)  end) as rx_xfr_to_rph_init , (case when (LENGTH(TRIM(rx_xfr_to_rph_init_after))==0) then rx_xfr_to_rph_init_after else TRIM(rx_xfr_to_rph_init_after)  end) as rx_xfr_to_rph_init_after , (case when (LENGTH(TRIM(rx_xfr_compt_name))==0) then rx_xfr_compt_name else TRIM(rx_xfr_compt_name)  end) as rx_xfr_compt_name , (case when (LENGTH(TRIM(rx_xfr_compt_name_after))==0) then rx_xfr_compt_name_after else TRIM(rx_xfr_compt_name_after)  end) as rx_xfr_compt_name_after , (case when (LENGTH(TRIM(rx_xfr_compt_area_cd))==0) then rx_xfr_compt_area_cd else TRIM(rx_xfr_compt_area_cd)  end) as rx_xfr_compt_area_cd , (case when (LENGTH(TRIM(rx_xfr_compt_area_cd_after))==0) then rx_xfr_compt_area_cd_after else TRIM(rx_xfr_compt_area_cd_after)  end) as rx_xfr_compt_area_cd_after , (case when (LENGTH(TRIM(rx_xfr_compt_phone_nbr))==0) then rx_xfr_compt_phone_nbr else TRIM(rx_xfr_compt_phone_nbr)  end) as rx_xfr_compt_phone_nbr , (case when (LENGTH(TRIM(rx_xfr_compt_phone_nbr_after))==0) then rx_xfr_compt_phone_nbr_after else TRIM(rx_xfr_compt_phone_nbr_after)  end) as rx_xfr_compt_phone_nbr_after , (case when (LENGTH(TRIM(rx_xfr_to_tech_init))==0) then rx_xfr_to_tech_init else TRIM(rx_xfr_to_tech_init)  end) as rx_xfr_to_tech_init , (case when (LENGTH(TRIM(rx_xfr_to_tech_init_after))==0) then rx_xfr_to_tech_init_after else TRIM(rx_xfr_to_tech_init_after)  end) as rx_xfr_to_tech_init_after , (case when (LENGTH(TRIM(pat_id))==0) then pat_id else TRIM(pat_id)  end) as pat_id , (case when (LENGTH(TRIM(pat_id_after))==0) then pat_id_after else TRIM(pat_id_after)  end) as pat_id_after , (case when (LENGTH(TRIM(rx_xfr_from_store_nbr))==0) then rx_xfr_from_store_nbr else TRIM(rx_xfr_from_store_nbr)  end) as rx_xfr_from_store_nbr , (case when (LENGTH(TRIM(rx_xfr_from_store_nbr_after))==0) then rx_xfr_from_store_nbr_after else TRIM(rx_xfr_from_store_nbr_after)  end) as rx_xfr_from_store_nbr_after , (case when (LENGTH(TRIM(rx_xfr_from_rph_init))==0) then rx_xfr_from_rph_init else TRIM(rx_xfr_from_rph_init)  end) as rx_xfr_from_rph_init , (case when (LENGTH(TRIM(rx_xfr_from_rph_init_after))==0) then rx_xfr_from_rph_init_after else TRIM(rx_xfr_from_rph_init_after)  end) as rx_xfr_from_rph_init_after , (case when (LENGTH(TRIM(rx_trnsf_close_reason_cd))==0) then rx_trnsf_close_reason_cd else TRIM(rx_trnsf_close_reason_cd)  end) as rx_trnsf_close_reason_cd , (case when (LENGTH(TRIM(rx_trnsf_close_reason_cd_after))==0) then rx_trnsf_close_reason_cd_after else TRIM(rx_trnsf_close_reason_cd_after)  end) as rx_trnsf_close_reason_cd_after , (case when (LENGTH(TRIM(rx_xfr_from_tech_init))==0) then rx_xfr_from_tech_init else TRIM(rx_xfr_from_tech_init)  end) as rx_xfr_from_tech_init , (case when (LENGTH(TRIM(rx_xfr_from_tech_init_after))==0) then rx_xfr_from_tech_init_after else TRIM(rx_xfr_from_tech_init_after)  end) as rx_xfr_from_tech_init_after from dedup_group"""


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdBfrXfr="""Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,  """ + BATCH_ID + """ as edw_batch_id, send_phrm_name AS send_phrm_name , send_phrm_addr AS send_phrm_addr , send_phrm_city AS send_phrm_city , send_phrm_state  AS send_phrm_state  , send_phrm_nabp AS send_phrm_nabp , send_rph_init AS send_rph_init , buyout_rx_nbr  AS buyout_rx_nbr  , pat_code AS pat_code , buyout_drug_name AS buyout_drug_name , buyout_drug_strength  AS buyout_drug_strength  , ndc_mfg AS ndc_mfg , ndc_prod AS ndc_prod , ndc_pkg  AS ndc_pkg  , rx_daw_ind  AS rx_daw_ind  , rx_original_fill_dttm AS rx_original_fill_dttm , rx_status  AS rx_status  , rx_sig  AS rx_sig  , rx_written_dttm AS rx_written_dttm , rx_original_qty AS rx_original_qty , rx_original_qty_disp AS rx_original_qty_disp , rx_cmts AS rx_cmts , rx_qty_remaining AS rx_qty_remaining , fill_days_supply AS fill_days_supply , fill_nbr_prescribed AS fill_nbr_prescribed , fill_nbr_remaining AS fill_nbr_remaining , drug_mfg_name AS drug_mfg_name , pbr_last_name AS pbr_last_name , pbr_first_name AS pbr_first_name , pbr_dea_nbr  AS pbr_dea_nbr  , pbr_addr AS pbr_addr , pbr_city AS pbr_city , pbr_state AS pbr_state , pbr_zip  AS pbr_zip  , create_dttm  AS create_dttm  , fill_entered_dttm AS fill_entered_dttm , rx_xfr_to_store_nbr AS rx_xfr_to_store_nbr , rx_xfr_to_rx_nbr  AS rx_xfr_to_rx_nbr  , rx_close_reason_cd  AS rx_close_reason_cd  , rx_close_reason_cmt AS rx_close_reason_cmt , rx_xfr_to_rph_init  AS rx_xfr_to_rph_init  , rx_xfr_compt_name  AS rx_xfr_compt_name  , rx_xfr_compt_area_cd AS rx_xfr_compt_area_cd , rx_xfr_compt_phone_nbr AS rx_xfr_compt_phone_nbr , rx_xfr_to_tech_init AS rx_xfr_to_tech_init , pat_id AS pat_id , rx_xfr_from_store_nbr  AS rx_xfr_from_store_nbr  , rx_xfr_from_rph_init AS rx_xfr_from_rph_init , rx_trnsf_close_reason_cd AS rx_trnsf_close_reason_cd , rx_xfr_from_tech_init AS rx_xfr_from_tech_init, '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from gg_tbf0_update """



pTgtUpdAftXfr="""Select 
cdc_txn_commit_dttm_after  as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id , send_phrm_name_after AS send_phrm_name , send_phrm_addr_after AS send_phrm_addr , send_phrm_city_after AS send_phrm_city , send_phrm_state_after AS send_phrm_state , send_phrm_nabp_after AS send_phrm_nabp , send_rph_init_after AS send_rph_init , buyout_rx_nbr_after AS buyout_rx_nbr , pat_code_after AS pat_code , buyout_drug_name_after AS buyout_drug_name , buyout_drug_strength_after AS buyout_drug_strength , ndc_mfg_after AS ndc_mfg , ndc_prod_after AS ndc_prod , ndc_pkg_after AS ndc_pkg , rx_daw_ind_after AS rx_daw_ind , rx_original_fill_dttm_after AS rx_original_fill_dttm , rx_status_after AS rx_status , rx_sig_after AS rx_sig , rx_written_dttm_after AS rx_written_dttm , rx_original_qty_after AS rx_original_qty , rx_original_qty_disp_after AS rx_original_qty_disp , rx_cmts_after AS rx_cmts , rx_qty_remaining_after AS rx_qty_remaining , fill_days_supply_after AS fill_days_supply , fill_nbr_prescribed_after AS fill_nbr_prescribed , fill_nbr_remaining_after AS fill_nbr_remaining , drug_mfg_name_after AS drug_mfg_name , pbr_last_name_after AS pbr_last_name , pbr_first_name_after AS pbr_first_name , pbr_dea_nbr_after AS pbr_dea_nbr , pbr_addr_after AS pbr_addr , pbr_city_after AS pbr_city , pbr_state_after AS pbr_state , pbr_zip_after AS pbr_zip , create_dttm_after AS create_dttm , fill_entered_dttm_after AS fill_entered_dttm , rx_xfr_to_store_nbr_after AS rx_xfr_to_store_nbr , rx_xfr_to_rx_nbr_after AS rx_xfr_to_rx_nbr , rx_close_reason_cd_after AS rx_close_reason_cd , rx_close_reason_cmt_after AS rx_close_reason_cmt , rx_xfr_to_rph_init_after AS rx_xfr_to_rph_init , rx_xfr_compt_name_after AS rx_xfr_compt_name , rx_xfr_compt_area_cd_after AS rx_xfr_compt_area_cd , rx_xfr_compt_phone_nbr_after AS rx_xfr_compt_phone_nbr , rx_xfr_to_tech_init_after AS rx_xfr_to_tech_init , pat_id_after AS pat_id , rx_xfr_from_store_nbr_after AS rx_xfr_from_store_nbr , rx_xfr_from_rph_init_after AS rx_xfr_from_rph_init , rx_trnsf_close_reason_cd_after AS rx_trnsf_close_reason_cd , rx_xfr_from_tech_init_after AS rx_xfr_from_tech_init , '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from gg_tbf0_update"""




pTgtInsBfrAftXfr = """Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id, send_phrm_name_after AS send_phrm_name , send_phrm_addr_after AS send_phrm_addr , send_phrm_city_after AS send_phrm_city , send_phrm_state_after AS send_phrm_state , send_phrm_nabp_after AS send_phrm_nabp , send_rph_init_after AS send_rph_init , buyout_rx_nbr_after AS buyout_rx_nbr , pat_code_after AS pat_code , buyout_drug_name_after AS buyout_drug_name , buyout_drug_strength_after AS buyout_drug_strength , ndc_mfg_after AS ndc_mfg , ndc_prod_after AS ndc_prod , ndc_pkg_after AS ndc_pkg , rx_daw_ind_after AS rx_daw_ind , rx_original_fill_dttm_after AS rx_original_fill_dttm , rx_status_after AS rx_status , rx_sig_after AS rx_sig , rx_written_dttm_after AS rx_written_dttm , rx_original_qty_after AS rx_original_qty , rx_original_qty_disp_after AS rx_original_qty_disp , rx_cmts_after AS rx_cmts , rx_qty_remaining_after AS rx_qty_remaining , fill_days_supply_after AS fill_days_supply , fill_nbr_prescribed_after AS fill_nbr_prescribed , fill_nbr_remaining_after AS fill_nbr_remaining , drug_mfg_name_after AS drug_mfg_name , pbr_last_name_after AS pbr_last_name , pbr_first_name_after AS pbr_first_name , pbr_dea_nbr_after AS pbr_dea_nbr , pbr_addr_after AS pbr_addr , pbr_city_after AS pbr_city , pbr_state_after AS pbr_state , pbr_zip_after AS pbr_zip , create_dttm_after AS create_dttm , fill_entered_dttm_after AS fill_entered_dttm , rx_xfr_to_store_nbr_after AS rx_xfr_to_store_nbr , rx_xfr_to_rx_nbr_after AS rx_xfr_to_rx_nbr , rx_close_reason_cd_after AS rx_close_reason_cd , rx_close_reason_cmt_after AS rx_close_reason_cmt , rx_xfr_to_rph_init_after AS rx_xfr_to_rph_init , rx_xfr_compt_name_after AS rx_xfr_compt_name , rx_xfr_compt_area_cd_after AS rx_xfr_compt_area_cd , rx_xfr_compt_phone_nbr_after AS rx_xfr_compt_phone_nbr , rx_xfr_to_tech_init_after AS rx_xfr_to_tech_init , pat_id_after AS pat_id , rx_xfr_from_store_nbr_after AS rx_xfr_from_store_nbr , rx_xfr_from_rph_init_after AS rx_xfr_from_rph_init , rx_trnsf_close_reason_cd_after AS rx_trnsf_close_reason_cd , rx_xfr_from_tech_init_after AS rx_xfr_from_tech_init , '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 


gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)


#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CREATE_DTTM",trim("CREATE_DTTM"))\
                                                                         .withColumn("RX_ORIGINAL_FILL_DTTM",trim("RX_ORIGINAL_FILL_DTTM"))\
                                                                        .withColumn("RX_WRITTEN_DTTM",trim("RX_WRITTEN_DTTM"))\
                                                                        .withColumn("FILL_ENTERED_DTTM",trim("FILL_ENTERED_DTTM"))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CREATE_DTTM",concat(split(col("CREATE_DTTM"),":")[0],split(col("CREATE_DTTM"),":")[1],lit(":"),split(col("CREATE_DTTM"),":")[2],lit(":"),split(col("CREATE_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("RX_ORIGINAL_FILL_DTTM",concat(split(col("RX_ORIGINAL_FILL_DTTM"),":")[0],split(col("RX_ORIGINAL_FILL_DTTM"),":")[1],lit(":"),split(col("RX_ORIGINAL_FILL_DTTM"),":")[2],lit(":"),split(col("RX_ORIGINAL_FILL_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("RX_WRITTEN_DTTM",concat(split(col("RX_WRITTEN_DTTM"),":")[0],split(col("RX_WRITTEN_DTTM"),":")[1],lit(":"),split(col("RX_WRITTEN_DTTM"),":")[2],lit(":"),split(col("RX_WRITTEN_DTTM"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ENTERED_DTTM",concat(split(col("FILL_ENTERED_DTTM"),":")[0],split(col("FILL_ENTERED_DTTM"),":")[1],lit(":"),split(col("FILL_ENTERED_DTTM"),":")[2],lit(":"),split(col("FILL_ENTERED_DTTM"),":")[3]))

# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull= etl_tbf0_reformat_cdc_check_notnull.withColumn("PAT_ID", \
       when(col("PAT_ID")=="" ,None) \
          .otherwise(col("PAT_ID")))

# COMMAND ----------

 df_final = etl_tbf0_reformat_cdc_check_notnull.drop("tracking_id","partition_column")
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
  .withColumn("CREATE_DTTM", to_timestamp(df_final["CREATE_DTTM"]))\
  .withColumn("RX_ORIGINAL_FILL_DTTM", to_timestamp(df_final["RX_ORIGINAL_FILL_DTTM"]))\
  .withColumn("RX_WRITTEN_DTTM", to_timestamp(df_final["RX_WRITTEN_DTTM"]))\
  .withColumn("FILL_ENTERED_DTTM", to_timestamp(df_final["FILL_ENTERED_DTTM"]))\
  .withColumn("CDC_SEQ_NBR",df_final["CDC_SEQ_NBR"].cast(IntegerType()))\
  .withColumn("CDC_RBA_NBR",df_final["CDC_RBA_NBR"].cast(IntegerType()))\
  .withColumn("FILL_DAYS_SUPPLY",df_final["FILL_DAYS_SUPPLY"].cast(IntegerType()))\
  .withColumn("FILL_NBR_PRESCRIBED",df_final["FILL_NBR_PRESCRIBED"].cast(IntegerType()))\
  .withColumn("RX_XFR_TO_STORE_NBR",df_final["RX_XFR_TO_STORE_NBR"].cast(IntegerType()))\
  .withColumn("RX_XFR_TO_RX_NBR",df_final["RX_XFR_TO_RX_NBR"].cast(IntegerType()))\
  .withColumn("FILL_NBR_REMAINING",df_final["FILL_NBR_REMAINING"].cast(IntegerType()))\
  .withColumn("RX_XFR_FROM_STORE_NBR",df_final["RX_XFR_FROM_STORE_NBR"].cast(IntegerType()))\
  .withColumn("RX_ORIGINAL_QTY",df_final["RX_ORIGINAL_QTY"].cast(IntegerType()))\
  .withColumn("RX_ORIGINAL_QTY_DISP",df_final["RX_ORIGINAL_QTY_DISP"].cast(IntegerType()))\
  .withColumn("RX_QTY_REMAINING",df_final["RX_QTY_REMAINING"].cast(IntegerType()))\
  .withColumn("SEND_PHRM_NAME", substring(col("SEND_PHRM_NAME"),0,25))\
  .withColumn("SEND_PHRM_ADDR", substring(col("SEND_PHRM_ADDR"),0,40))\
  .withColumn("SEND_PHRM_CITY", substring(col("SEND_PHRM_CITY"),0,20))\
  .withColumn("SEND_PHRM_STATE", substring(col("SEND_PHRM_STATE"),0,2))\
  .withColumn("BUYOUT_RX_NBR", substring(col("BUYOUT_RX_NBR"),0,20))\
  .withColumn("PAT_CODE", substring(col("PAT_CODE"),0,20))\
  .withColumn("NDC_MFG", substring(col("NDC_MFG"),0,5))\
  .withColumn("NDC_PROD", substring(col("NDC_PROD"),0,4))\
  .withColumn("NDC_PKG", substring(col("NDC_PKG"),0,2))\
  .withColumn("CDC_OPERATION_TYPE_CD", substring(col("CDC_OPERATION_TYPE_CD"),0,20))\
  .withColumn("RX_DAW_IND", substring(col("RX_DAW_IND"),0,1))\
  .withColumn("RX_SIG", substring(col("RX_SIG"),0,150))\
  .withColumn("PBR_LAST_NAME", substring(col("PBR_LAST_NAME"),0,20))\
  .withColumn("PBR_FIRST_NAME", substring(col("PBR_FIRST_NAME"),0,14))\
  .withColumn("PBR_DEA_NBR", substring(col("PBR_DEA_NBR"),0,9))\
  .withColumn("CDC_BEFORE_AFTER_CD", substring(col("CDC_BEFORE_AFTER_CD"),0,10))\
  .withColumn("CDC_TXN_POSITION_CD", substring(col("CDC_TXN_POSITION_CD"),0,10))\
  .withColumn("RX_CLOSE_REASON_CD", substring(col("RX_CLOSE_REASON_CD"),0,1))\
  .withColumn("DRUG_MFG_NAME", substring(col("DRUG_MFG_NAME"),0,30))\
  .withColumn("PBR_ADDR", substring(col("PBR_ADDR"),0,40))\
  .withColumn("PBR_CITY", substring(col("PBR_CITY"),0,20))\
  .withColumn("PBR_STATE", substring(col("PBR_STATE"),0,2))\
  .withColumn("PBR_ZIP", substring(col("PBR_ZIP"),0,9))\
  .withColumn("RX_XFR_COMPT_NAME", substring(col("RX_XFR_COMPT_NAME"),0,25))\
  .withColumn("RX_CLOSE_REASON_CD", substring(col("RX_CLOSE_REASON_CD"),0,1))\
  .withColumn("RX_CLOSE_REASON_CMT", substring(col("RX_CLOSE_REASON_CMT"),0,70))\
  .withColumn("RX_XFR_TO_RPH_INIT", substring(col("RX_XFR_TO_RPH_INIT"),0,3))\
  .withColumn("RX_XFR_COMPT_AREA_CD", substring(col("RX_XFR_COMPT_AREA_CD"),0,3))\
  .withColumn("RX_XFR_COMPT_PHONE_NBR", substring(col("RX_XFR_COMPT_PHONE_NBR"),0,7))\
  .withColumn("RX_XFR_TO_TECH_INIT", substring(col("RX_XFR_TO_TECH_INIT"),0,3))\
  .withColumn("RX_XFR_FROM_RPH_INIT", substring(col("RX_XFR_FROM_RPH_INIT"),0,3))\
  .withColumn("RX_TRNSF_CLOSE_REASON_CD", substring(col("RX_TRNSF_CLOSE_REASON_CD"),0,2))\
  .withColumn("RX_XFR_FROM_TECH_INIT", substring(col("RX_XFR_FROM_TECH_INIT"),0,3))\
  .withColumn("SEND_RPH_INIT", substring(col("SEND_RPH_INIT"),0,3))\
  .withColumn("BUYOUT_DRUG_NAME", substring(col("BUYOUT_DRUG_NAME"),0,60))\
  .withColumn("BUYOUT_DRUG_STRENGTH", substring(col("BUYOUT_DRUG_STRENGTH"),0,11))\
  .withColumn("RX_STATUS", substring(col("RX_STATUS"),0,10))\
  .withColumn("RX_CMTS", substring(col("RX_CMTS"),0,50))
  

df_final = df_final.filter("BUYOUT_RX_NBR IS NOT NULL AND SEND_PHRM_NABP IS NOT NULL AND PAT_CODE IS NOT NULL")
# display(df_final)

# COMMAND ----------

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

#dbutils.notebook.exit(PAR_WRITEAPI_VALUE2);
dbutils.notebook.exit("ETL_TBF0_RX_BUYOUT_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")
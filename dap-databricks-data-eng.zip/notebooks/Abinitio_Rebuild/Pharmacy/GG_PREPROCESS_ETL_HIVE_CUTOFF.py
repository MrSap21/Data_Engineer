# Databricks notebook source
# Our imported libraries
import json
import os

from datetime import datetime
from functools import reduce
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import input_file_name

# COMMAND ----------
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")
# COMMAND ----------
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------
# Multithreading to assure we are loading the files simultaneously
from multiprocessing.pool import ThreadPool
try:
    pool = ThreadPool(3)
    notebooks = [
        {
            'notebook': 'GG_PREPROCESS_ETL_RX_INGESTION',
            'params': {
                "PAR_DB_BATCH_ID": dbutils.widgets.get("PAR_DB_BATCH_ID"),
                "PAR_FEED_NAME": dbutils.widgets.get("PAR_FEED_NAME_RX"),
                "PAR_READAPI_URL": dbutils.widgets.get("PAR_READAPI_URL"),
                "PAR_DB_OUTPUT_PATH": dbutils.widgets.get("PAR_DB_OUTPUT_PATH_RX"),
                "PAR_DB_OUTPUT_FILENAME": dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME_RX"),
                "PAR_DB_REJECT_PATH": dbutils.widgets.get("PAR_DB_REJECT_PATH_RX"),
                "PAR_DB_SNFK_WH": dbutils.widgets.get("PAR_DB_SNFK_WH"),
                "PAR_DB_SNFK_DB": dbutils.widgets.get("PAR_DB_SNFK_DB"),
                "PAR_DB_SNFK_ETL": dbutils.widgets.get("PAR_DB_SNFK_ETL"),
                "PAR_ETL_HIVE_CUTOFF_TBL": dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL"),
                "PAR_WRITEAPI_URL": dbutils.widgets.get("PAR_WRITEAPI_URL")
            }
        }, 
        {
            'notebook': 'GG_PREPROCESS_ETL_RX_TRANSACTION_INGESTION',
            'params': {
                "PAR_DB_BATCH_ID": dbutils.widgets.get("PAR_DB_BATCH_ID"),
                "PAR_FEED_NAME": dbutils.widgets.get("PAR_FEED_NAME_RX_TRANS"),
                "PAR_READAPI_URL": dbutils.widgets.get("PAR_READAPI_URL"),
                "PAR_DB_OUTPUT_PATH": dbutils.widgets.get("PAR_DB_OUTPUT_PATH_RX_TRANS"),
                "PAR_DB_OUTPUT_FILENAME": dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME_RX_TRANS"),
                "PAR_DB_REJECT_PATH": dbutils.widgets.get("PAR_DB_REJECT_PATH_RX_TRANS"),
                "PAR_DB_SNFK_WH": dbutils.widgets.get("PAR_DB_SNFK_WH"),
                "PAR_DB_SNFK_DB": dbutils.widgets.get("PAR_DB_SNFK_DB"),
                "PAR_DB_SNFK_ETL": dbutils.widgets.get("PAR_DB_SNFK_ETL"),
                "PAR_DB_ETL_TBL_NAME": dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL"),
                "PAR_WRITEAPI_URL": dbutils.widgets.get("PAR_WRITEAPI_URL"),
                "PAR_DB_JOB_ID": dbutils.widgets.get("PAR_DB_JOB_ID")
            }
        }
    ]
    parrallel_notebooks = pool.map(lambda notebook: dbutils.notebook.run(f"/Abinitio_Rebuild/Pharmacy/{notebook.get('notebook')}", timeout_seconds=0, arguments=notebook.get('params')), notebooks)
    pool.close()
    pool.join()
except Exception as e:
    print("Error ingesting file, attempting to close thread pool and shutting down.")
    try:
        pool.close()
        pool.join()
        raise Exception("Error Processing GG_TBF0_RX and GG_TBF0_RX_TRANSACTION feeds. Shutting Down. Please set files to 24014 and re-run.")
    except Exception as e:
        raise Exception("Error shutting down thread pool. Shutting Down")
# finally:
#     print("Attempting to continue loading ETL Hive Cutoff table.")
# COMMAND ----------
# print notebooks run in process. will fail if subprocesses failed.
print(list(parrallel_notebooks))
# COMMAND ----------
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH
# COMMAND ----------
# Query the ETL_HIVE_CUTOFF table in Snowflake to retrieve the last batch's dttm values
query_min_dttm = f"""
SELECT 
  COALESCE((
    SELECT 
        RX_CUT_OFF_MAX_DTTM
    FROM {SNFK_ETL_DB}.{ETL_HIVE_CUTOFF_TBL}
    WHERE edw_batch_id in (
        SELECT max(edw_batch_id) 
        FROM {SNFK_ETL_DB}.{ETL_HIVE_CUTOFF_TBL}
    )), '0001-01-01 00:00:00'
  ) as RX_CUT_OFF_MAX_DTTM,
  COALESCE((
    SELECT 
        RX_TRAN_CUT_OFF_MAX_DTTM
    FROM {SNFK_ETL_DB}.{ETL_HIVE_CUTOFF_TBL}
    WHERE edw_batch_id in (
        SELECT max(edw_batch_id) 
        FROM {SNFK_ETL_DB}.{ETL_HIVE_CUTOFF_TBL}
    )), '0001-01-01 00:00:00'
  ) as RX_TRAN_CUT_OFF_MIN_DTTM
"""

df_min_dttm = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFK_ETL_DB) \
   .option("query",query_min_dttm) \
   .load()

# display(df_min_dttm)
RX_MIN_DTTM = f"'{str(df_min_dttm.collect()[0][0])}'"
RX_TRAN_MIN_DTTM=f"'{str(df_min_dttm.collect()[0][1])}'"
# COMMAND ----------
spark.conf.set("spark.sql.crossJoin.enabled", "true")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
# select from gg_tbf0_rx table:
df_rx_max_dttm = spark.sql(f"""
SELECT 
    max(RX_MAX) as RX_MAX 
FROM (
    SELECT max(cdc_txn_commit_dttm) as RX_MAX 
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg
    WHERE src_partition_nbr=1 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM}
    UNION 
    SELECT max(cdc_txn_commit_dttm) as RX_MAX 
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg
    WHERE src_partition_nbr=2 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM}
    UNION 
    SELECT max(cdc_txn_commit_dttm) as RX_MAX 
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg
    WHERE src_partition_nbr=3 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM}
    UNION 
    SELECT max(cdc_txn_commit_dttm) as RX_MAX 
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg
    WHERE src_partition_nbr=4 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM}
)""")
RX_MAX_DTTM = "'" + df_rx_max_dttm.collect()[0][0] + "'"
# display(getMaxDttm)
# COMMAND ----------
# select from gg_tbf0_rx_transaction table:
df_rx_trans_max_dttm = spark.sql(f"""
SELECT max(RX_MAX) as RX_TRAN_CUT_OFF_MAX_DTTM
FROM (                
    SELECT max(cdc_txn_commit_dttm) as RX_MAX
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg
    WHERE src_partition_nbr=1 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM} AND cdc_txn_commit_dttm < {RX_MAX_DTTM}
    UNION
    SELECT max(cdc_txn_commit_dttm) as RX_MAX
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg
    WHERE src_partition_nbr=2 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM} AND cdc_txn_commit_dttm < {RX_MAX_DTTM}
    UNION
    SELECT max(cdc_txn_commit_dttm) as RX_MAX
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg
    WHERE src_partition_nbr=3 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM} AND cdc_txn_commit_dttm < {RX_MAX_DTTM}
    UNION
    SELECT max(cdc_txn_commit_dttm) as RX_MAX
    FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg
    WHERE src_partition_nbr=4 AND cdc_txn_commit_dttm >= {RX_MIN_DTTM} AND cdc_txn_commit_dttm < {RX_MAX_DTTM}
)""")
try:
    RX_TRAN_MAX_DTTM="'"+str(df_rx_trans_max_dttm.collect()[0][0])+"'"
    if RX_TRAN_MAX_DTTM == 'None':
        RX_TRAN_MAX_DTTM=RX_MAX_DTTM
except Exception as e:
    RX_TRAN_MAX_DTTM=RX_MAX_DTTM

# COMMAND ----------
print("rx min      :",RX_MIN_DTTM)
print("rx max      :",RX_MAX_DTTM)
print("rx trans min:",RX_TRAN_MIN_DTTM)
print("rx trans max:",RX_TRAN_MAX_DTTM)
# COMMAND ----------
merge_query = f"""
MERGE INTO {SNFK_ETL_DB}.{ETL_HIVE_CUTOFF_TBL} A 
USING (SELECT max(EDW_BATCH_ID) as edw_batch_id FROM {SNFK_ETL_DB}.{ETL_HIVE_CUTOFF_TBL}) B
    ON B.edw_batch_id = {BATCH_ID} AND  A.EDW_BATCH_ID = B.EDW_BATCH_ID
WHEN MATCHED THEN UPDATE 
    SET 
        PROJ_NAME = 'WALGREENS',
        EDW_BATCH_ID = {BATCH_ID},
        RX_CUT_OFF_MIN_DTTM = A.RX_CUT_OFF_MIN_DTTM,
        RX_CUT_OFF_MAX_DTTM = {RX_MAX_DTTM}, 
        RX_TRAN_CUT_OFF_MIN_DTTM = A.RX_CUT_OFF_MIN_DTTM,
        RX_TRAN_CUT_OFF_MAX_DTTM = {RX_TRAN_MAX_DTTM},
        PROCESS_IND = 'SO'
WHEN NOT MATCHED THEN INSERT 
    VALUES('WALGREENS',{BATCH_ID},{RX_MIN_DTTM},{RX_MAX_DTTM},{RX_TRAN_MIN_DTTM},{RX_TRAN_MAX_DTTM},'SO')
"""
dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000,{ "query": merge_query, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFK_ETL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# Databricks notebook source
import os
import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters

# dbutils.widgets.text("PAR_NB_PARAMETER_LIST","$AI_SERIAL=/customer/dap_gen_run_pgm/script,$EDW_BATCH_ID=20190404")

os.environ['scriptPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_SCRIPT_PATH") 
os.environ['scriptName'] = dbutils.widgets.get("PAR_NB_SCRIPT_NAME")
os.environ['JOB_INVOCATION'] = dbutils.widgets.get("PAR_NB_JOB_INVOCATION")
os.environ['pEDWBATCHID'] = dbutils.widgets.get("PAR_NB_BATCH_ID")
 

# COMMAND ----------

# MAGIC %sh
# MAGIC 
# MAGIC pushd $scriptPath
# MAGIC 
# MAGIC $scriptPath/$scriptName $JOB_INVOCATION $pEDWBATCHID
# MAGIC 
# MAGIC popd

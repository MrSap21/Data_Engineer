# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove('PAR_DB_SNFK_MASTR_DB')
#dbutils.widgets.text('PAR_DB_INPUT_FILENAME', 'edw_adl_hiv_reporting_extract')

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_INPUT_FILE1")



INPUT_PATH = dbutils.widgets.get("PAR_DB_INPUT_PATH")
INPUT_FILENAME = dbutils.widgets.get("PAR_DB_INPUT_FILENAME")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFK_DB_PHAR = dbutils.widgets.get("PAR_DB_SNFK_DB")
#SNFK_DB_MAST = dbutils.widgets.get("PAR_DB_SNFK_MASTR_DB")
#SNFK_DB_CONS = dbutils.widgets.get("PAR_DB_SNFK_CONSUMP_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")



#IN_DATAFILE2 = mountPoint + '/'+ IN_PATH #+ '/' + IN_FILE
#IN_DATAFILE1 = mountPoint + '/'+ IN_FILE1 + '/'+ BATCH_ID

IN_FILEPATH = mountPoint + '/'+ INPUT_PATH + '/' + INPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID



#print (IN_DATAFILE2)

print (IN_FILEPATH)



# COMMAND ----------

df1 = spark.read.parquet(IN_FILEPATH)

df1 = df1.sort("str_nbr", "rx_fill_nbr", "fill_enter_dt", "fill_enter_tm", "rx_create_dt", "fill_sold_dt")
df1 = df1.dropDuplicates(['rx_nbr', 'str_nbr', 'rx_fill_nbr', 'fill_enter_dt', 'fill_enter_tm', 'rx_create_dt', 'fill_sold_dt']) 
display(df1)

# COMMAND ----------

from pyspark.sql.functions import lit,col, current_timestamp
#df2 = df1.withColumn('store_nbr', col('str_nbr'))
df_final = df1.withColumnRenamed('str_nbr', 'store_nbr') \
         .withColumnRenamed('third_party_plan_id', 'primary_third_party_plan_id') \
         .withColumnRenamed('plan_tot_paid_dlrs', 'primary_plan_tot_paid_dlrs') \
         .withColumnRenamed('plan_copay_dlrs', 'primary_plan_copay_dlrs') \
         .withColumn("primary_third_party_plan_id", trim("primary_third_party_plan_id")) \
         .withColumn("edw_batch_id",lit(BATCH_ID)) \
         .withColumn("edw_create_dttm",current_timestamp())
display(df_final)

# COMMAND ----------

df_final = df_final.select(
            "rx_nbr",
            "store_nbr",
            "rx_fill_nbr",
            "rx_partial_fill_nbr",
            "fill_enter_dt",
            "fill_enter_tm",
            "fill_sold_dt",
            "fill_days_supply",
            "fill_qty_dspn",
            "fill_revenue_dlrs",
            "fill_gross_profit_dlrs",
            "primary_third_party_plan_id",
            "primary_plan_tot_paid_dlrs",
            "primary_plan_copay_dlrs",
            "edw_batch_id",
            "edw_create_dttm"
          )
display(df_final)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

df_final.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_PHAR) \
   .option("dbtable", SNFL_TBL_NAME) \
   .mode("append") \
   .save()
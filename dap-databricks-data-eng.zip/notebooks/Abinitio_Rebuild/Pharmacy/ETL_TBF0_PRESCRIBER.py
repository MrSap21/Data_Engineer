# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

del_snfl_tbl = "TRUNCATE TABLE {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 200, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")
SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 10800, 
                  {"PAR_EDW_BATCH_ID":BATCH_ID,
                   "PAR_FEED_NAMES":FEED_NAME,
                   "PAR_PIPELINE_NAME":PIPELINE_NAME,
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_RETURN_FILE_TYPE":"A",
                   "PAR_SQL_SERVER":SQL_SERVER,
                   "PAR_SQL_SERVER_AD_CLIENT_ID":SQL_SERVER_AD_CLIENT_ID,
                   "PAR_SQL_SERVER_AD_CLIENT_SECRET":SQL_SERVER_AD_CLIENT_SECRET,
                   "PAR_SQL_SERVER_DB":SQL_SERVER_DB});


print(Input_File_List)

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdControlArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdControlArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

##Convert json asset location/filname to Multi FIle Name List

#inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_File_FEEDNAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{GG_File_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_File_FEEDNAME}.assetid",
                                                   f"{GG_File_FEEDNAME}.assetname")
#display(dfFileList)
#print(gg_file_list)
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
#dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
#dfAssetIdStr=dfAssetIdStr.replace(" ","")
dfAssetIdFinalArray = dfAssetIdControlArray+dfAssetIdArray
print(dfAssetIdFinalArray)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pbr_id',
'pbr_id_after',
'pbr_loc_id',
'pbr_loc_id_after',
'pbr_status_cd',
'pbr_status_cd_after',
'pbr_dea_nbr',
'pbr_dea_nbr_after',
'pbr_dea_suf',
'pbr_dea_suf_after',
'pbr_spin_nbr',
'pbr_spin_nbr_after',
'pbr_last_name',
'pbr_last_name_after',
'pbr_first_name',
'pbr_first_name_after',
'pbr_mid_init',
'pbr_mid_init_after',
'pbr_surname_suffix',
'pbr_surname_suffix_after',
'pbr_name_soundex',
'pbr_name_soundex_after',
'pbr_phone_area_cd',
'pbr_phone_area_cd_after',
'pbr_phone',
'pbr_phone_after',
'pbr_fax_area_cd',
'pbr_fax_area_cd_after',
'pbr_fax',
'pbr_fax_after',
'pbr_addr',
'pbr_addr_after',
'pbr_city',
'pbr_city_after',
'pbr_state',
'pbr_state_after',
'pbr_zip',
'pbr_zip_after',
'pbr_type_cd',
'pbr_type_cd_after',
'pbr_specialty_cd',
'pbr_specialty_cd_after',
'pbr_tax_id',
'pbr_tax_id_after',
'pbr_cmts',
'pbr_cmts_after',
'pbr_last_active_dttm',
'pbr_last_active_dttm_after',
'pbr_hlthcare_reform_nbr',
'pbr_hlthcare_reform_nbr_after',
'quarter1_ind',
'quarter1_ind_after',
'quarter2_ind',
'quarter2_ind_after',
'quarter3_ind',
'quarter3_ind_after',
'quarter4_ind',
'quarter4_ind_after',
'pbr_prescribe_ind',
'pbr_prescribe_ind_after',
'pbr_hub_nbr',
'pbr_hub_nbr_after',
'pbr_clinic_site',
'pbr_clinic_site_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'pbr_clinic_id',
'pbr_clinic_id_after',
'pbr_company_cd',
'pbr_company_cd_after',
'pbr_phone_cmts',
'pbr_phone_cmts_after',
'pbr_change_req_ind',
'pbr_change_req_ind_after',
'pbr_source_ind',
'pbr_source_ind_after',
'ndc_pbr_id',
'ndc_pbr_id_after',
'pbr_provider_status',
'pbr_provider_status_after',
'pbr_prof_status',
'pbr_prof_status_after',
'pbr_sex_cd',
'pbr_sex_cd_after',
'pbr_birth_dttm',
'pbr_birth_dttm_after',
'pbr_middle_name',
'pbr_middle_name_after',
'pbr_addr2',
'pbr_addr2_after',
'pbr_dea_expire_dttm',
'pbr_dea_expire_dttm_after',
'pbr_upin',
'pbr_upin_after',
'pbr_license_state',
'pbr_license_state_after',
'pbr_state_license_nbr',
'pbr_state_license_nbr_after',
'ndc_pbr_loc_id',
'ndc_pbr_loc_id_after',
'pbr_app_cd',
'pbr_app_cd_after',
'pbr_npi',
'pbr_npi_after',
'ow_update_dttm',
'ow_update_dttm_after',
'pbr_group_id',
'pbr_group_id_after',
'pbr_loc_group_id',
'pbr_loc_group_id_after',
'repl_by_pbr_id',
'repl_by_pbr_id_after',
'repl_by_pbr_loc_id',
'repl_by_pbr_loc_id_after',
'pbr_loc_name',
'pbr_loc_name_after',
'pbr_pecos_ind',
'pbr_pecos_ind_after',
'pbr_death_dttm',
'pbr_death_dttm_after',
'pbr_state_ctrl_nbr',
'pbr_state_ctrl_nbr_after',
'pbr_refill_area_cd',
'pbr_refill_area_cd_after',
'pbr_refill_phone',
'pbr_refill_phone_after',
'pbr_foreign_license',
'pbr_foreign_license_after',
'pbr_store_npi_ind',
'pbr_store_npi_ind_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 149 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 150:
      return True
  else:
    if val_len != 150:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 150

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 64
print(f"Bad records count {rd_bad.count()}") # != 64


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df.columns,
#     df
# ))

# COMMAND ----------

#display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_prescriber")
df.display()

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_prescriber where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

#display(dfBad)

print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_prescriber"))\
.withColumnRenamed("pbr_dea_suf","pbr_dea_suf")\
.withColumnRenamed("pbr_spin_nbr","pbr_spin_nbr")\
.withColumnRenamed("pbr_last_name","pbr_last_name")\
.withColumnRenamed("pbr_first_name","pbr_first_name")\
.withColumnRenamed("pbr_mid_init","pbr_mid_init")\
.withColumnRenamed("pbr_surname_suffix","pbr_surname_suffix")\
.withColumnRenamed("pbr_name_soundex","pbr_name_soundex")\
.withColumnRenamed("pbr_phone_area_cd","pbr_phone_area_cd")\
.withColumnRenamed("pbr_phone","pbr_phone")\
.withColumnRenamed("pbr_fax_area_cd","pbr_fax_area_cd")\
.withColumnRenamed("pbr_fax","pbr_fax")\
.withColumnRenamed("pbr_addr","pbr_addr")\
.withColumnRenamed("pbr_city","pbr_city")\
.withColumnRenamed("pbr_state","pbr_state")\
.withColumnRenamed("pbr_zip","pbr_zip")\
.withColumnRenamed("pbr_type_cd","pbr_type_cd")\
.withColumnRenamed("pbr_specialty_cd","pbr_specialty_cd")\
.withColumnRenamed("pbr_specialty_cd_after","pbr_specialty_cd_after")\
.withColumnRenamed("pbr_tax_id","pbr_tax_id")\
.withColumnRenamed("pbr_cmts","pbr_cmts")\
.withColumnRenamed("pbr_last_active_dttm","pbr_last_active_dttm")\
.withColumnRenamed("pbr_hlthcare_reform_nbr","pbr_hlthcare_reform_nbr")\
.withColumnRenamed("quarter1_ind","quarter1_ind")\
.withColumnRenamed("quarter2_ind","quarter2_ind")\
.withColumnRenamed("quarter3_ind","quarter3_ind")\
.withColumnRenamed("quarter4_ind","quarter4_ind")\
.withColumnRenamed("pbr_prescribe_ind","pbr_prescribe_ind")\
.withColumnRenamed("pbr_prescribe_ind_after","pbr_prescribe_ind_after")\
.withColumnRenamed("pbr_hub_nbr","pbr_hub_nbr")\
.withColumnRenamed("pbr_clinic_site","pbr_clinic_site")\
.withColumnRenamed("create_user_id","create_user_id")\
.withColumnRenamed("create_dttm","create_dttm")\
.withColumnRenamed("update_user_id","update_user_id")\
.withColumnRenamed("update_dttm","update_dttm")\
.withColumnRenamed("pbr_clinic_id","pbr_clinic_id")\
.withColumnRenamed("pbr_company_cd","pbr_company_cd")\
.withColumnRenamed("pbr_phone_cmts","pbr_phone_cmts")\
.withColumnRenamed("pbr_change_req_ind","pbr_change_req_ind")\
.withColumnRenamed("pbr_source_ind","pbr_source_ind")\
.withColumnRenamed("ndc_pbr_id","ndc_pbr_id")\
.withColumnRenamed("pbr_provider_status","pbr_provider_status")\
.withColumnRenamed("pbr_prof_status","pbr_prof_status")\
.withColumnRenamed("pbr_sex_cd","pbr_sex_cd")\
.withColumnRenamed("pbr_birth_dttm","pbr_birth_dttm")\
.withColumnRenamed("pbr_middle_name","pbr_middle_name")\
.withColumnRenamed("pbr_addr2","pbr_addr2")\
.withColumnRenamed("pbr_dea_expire_dttm","pbr_dea_expire_dttm")\
.withColumnRenamed("pbr_upin","pbr_upin")\
.withColumnRenamed("pbr_license_state","pbr_license_state")\
.withColumnRenamed("pbr_state_license_nbr","pbr_state_license_nbr")\
.withColumnRenamed("ndc_pbr_loc_id","ndc_pbr_loc_id")\
.withColumnRenamed("pbr_app_cd","pbr_app_cd")\
.withColumnRenamed("pbr_npi","pbr_npi")\
.withColumnRenamed("pbr_group_id","pbr_group_id")\
.withColumnRenamed("pbr_loc_group_id","pbr_loc_group_id")\
.withColumnRenamed("repl_by_pbr_id","repl_by_pbr_id")\
.withColumnRenamed("repl_by_pbr_loc_id","repl_by_pbr_loc_id")\
.withColumnRenamed("pbr_state_ctrl_nbr","pbr_state_ctrl_nbr")\
.withColumnRenamed("pbr_foreign_license","pbr_foreign_license")


#display(df_gg)

df_gg.createOrReplaceTempView("raw_gg_tbf0_prescriber")


# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

#pSrcGgTbf0Schema

pUpdateReform="((cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND pbr_id == pbr_id_after AND pbr_id IS NOT NULL AND pbr_id_after IS NOT NULL AND  pbr_loc_id  == pbr_loc_id_after AND pbr_loc_id IS NOT NULL AND pbr_loc_id_after IS NOT NULL AND  cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL AND  cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL AND  cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL AND ( (pbr_status_cd == pbr_status_cd_after AND  pbr_status_cd IS NOT NULL AND  pbr_status_cd_after IS NOT NULL ) OR ( pbr_status_cd IS NULL AND   pbr_status_cd_after IS NULL ) ) AND   ( (pbr_dea_nbr == pbr_dea_nbr_after AND  pbr_dea_nbr IS NOT NULL AND   pbr_dea_nbr_after IS NOT NULL ) OR ( pbr_dea_nbr IS NULL AND   pbr_dea_nbr_after IS NULL ) ) AND   ( (pbr_dea_suf == pbr_dea_suf_after AND  pbr_dea_suf IS NOT NULL AND  pbr_dea_suf_after IS NOT NULL ) OR ( pbr_dea_suf IS NULL AND   pbr_dea_suf_after IS NULL ) ) AND   ( (pbr_spin_nbr == pbr_spin_nbr_after AND  pbr_spin_nbr IS NOT NULL AND  pbr_spin_nbr_after IS NOT NULL ) OR ( pbr_spin_nbr IS NULL AND   pbr_spin_nbr_after IS NULL ) ) AND   ( (pbr_last_name == pbr_last_name_after AND  pbr_last_name IS NOT NULL AND  pbr_last_name_after IS NOT NULL ) OR ( pbr_last_name IS NULL AND   pbr_last_name_after IS NULL ) ) AND   ( (pbr_first_name == pbr_first_name_after AND  pbr_first_name IS NOT NULL AND  pbr_first_name_after IS NOT NULL ) OR ( pbr_first_name IS NULL AND   pbr_first_name_after IS NULL ) ) AND   ( (pbr_mid_init == pbr_mid_init_after AND  pbr_mid_init IS NOT NULL AND  pbr_mid_init_after IS NOT NULL ) OR ( pbr_mid_init IS NULL AND   pbr_mid_init_after IS NULL ) ) AND   ( (pbr_surname_suffix == pbr_surname_suffix_after AND  pbr_surname_suffix IS NOT NULL AND  pbr_surname_suffix_after IS NOT NULL ) OR ( pbr_surname_suffix IS NULL AND   pbr_surname_suffix_after IS NULL ) ) AND   ( (pbr_name_soundex == pbr_name_soundex_after AND  pbr_name_soundex IS NOT NULL AND  pbr_name_soundex_after IS NOT NULL ) OR ( pbr_name_soundex IS NULL AND   pbr_name_soundex_after IS NULL ) ) AND   ( (pbr_phone_area_cd == pbr_phone_area_cd_after AND  pbr_phone_area_cd IS NOT NULL AND  pbr_phone_area_cd_after IS NOT NULL ) OR ( pbr_phone_area_cd IS NULL AND   pbr_phone_area_cd_after IS NULL ) ) AND   ( (pbr_phone == pbr_phone_after  AND  pbr_phone IS NOT NULL AND  pbr_phone_after IS NOT NULL ) OR  ( pbr_phone IS NULL AND   pbr_phone_after IS NULL ) ) AND   ( (pbr_fax_area_cd == pbr_fax_area_cd_after AND  pbr_fax_area_cd IS NOT NULL AND  pbr_fax_area_cd_after IS NOT NULL ) OR ( pbr_fax_area_cd IS NULL AND   pbr_fax_area_cd_after IS NULL ) ) AND   ( (pbr_fax == pbr_fax_after AND  pbr_fax IS NOT NULL AND  pbr_fax_after IS NOT NULL ) OR ( pbr_fax IS NULL AND   pbr_fax_after IS NULL ) ) AND   ( (pbr_addr == pbr_addr_after AND  pbr_addr IS NOT NULL AND  pbr_addr_after IS NOT NULL ) OR ( pbr_addr IS NULL AND   pbr_addr_after IS NULL ) ) AND   ( (pbr_city == pbr_city_after AND  pbr_city IS NOT NULL AND   pbr_city_after  IS NOT NULL ) OR ( pbr_city IS NULL AND   pbr_city_after IS NULL ) ) AND   ( (pbr_state == pbr_state_after AND  pbr_state IS NOT NULL AND  pbr_state_after IS NOT NULL ) OR ( pbr_state IS NULL AND   pbr_state_after IS NULL ) ) AND   ( (pbr_zip == pbr_zip_after AND  pbr_zip IS NOT NULL AND  pbr_zip_after IS NOT NULL ) OR ( pbr_zip IS NULL AND   pbr_zip_after IS NULL ) ) AND   ( (pbr_type_cd == pbr_type_cd_after AND  pbr_type_cd IS NOT NULL AND  pbr_type_cd_after IS NOT NULL ) OR ( pbr_type_cd IS NULL AND   pbr_type_cd_after IS NULL ) ) AND   ( (pbr_specialty_cd == pbr_specialty_cd_after AND  pbr_specialty_cd IS NOT NULL AND  pbr_specialty_cd_after IS NOT NULL ) OR ( pbr_specialty_cd IS NULL AND   pbr_specialty_cd_after IS NULL ) ) AND   ( (pbr_tax_id == pbr_tax_id_after AND  pbr_tax_id IS NOT NULL AND  pbr_tax_id_after IS NOT NULL ) OR ( pbr_tax_id IS NULL AND   pbr_tax_id_after IS NULL ) ) AND   ( (pbr_cmts == pbr_cmts_after AND  pbr_cmts IS NOT NULL AND  pbr_cmts_after IS NOT NULL ) OR ( pbr_cmts IS NULL AND   pbr_cmts_after IS NULL ) ) AND   ( (pbr_last_active_dttm == pbr_last_active_dttm_after AND  pbr_last_active_dttm IS NOT NULL AND  pbr_last_active_dttm_after IS NOT NULL ) OR ( pbr_last_active_dttm IS NULL AND   pbr_last_active_dttm_after IS NULL ) ) AND   ( (pbr_hlthcare_reform_nbr == pbr_hlthcare_reform_nbr_after AND  pbr_hlthcare_reform_nbr IS NOT NULL AND  pbr_hlthcare_reform_nbr_after IS NOT NULL ) OR ( pbr_hlthcare_reform_nbr IS NULL AND   pbr_hlthcare_reform_nbr_after IS NULL ) ) AND   ( (quarter1_ind == quarter1_ind_after AND  quarter1_ind IS NOT NULL AND  quarter1_ind_after IS NOT NULL ) OR ( quarter1_ind IS NULL AND   quarter1_ind_after IS NULL ) ) AND   ( (quarter2_ind == quarter2_ind_after AND  quarter2_ind IS NOT NULL AND  quarter2_ind_after IS NOT NULL ) OR ( quarter2_ind IS NULL AND   quarter2_ind_after IS NULL ) ) AND   ( (quarter3_ind == quarter3_ind_after AND  quarter3_ind IS NOT NULL AND  quarter3_ind_after IS NOT NULL ) OR ( quarter3_ind IS NULL AND   quarter3_ind_after IS NULL ) ) AND   ( (quarter4_ind == quarter4_ind_after AND  quarter4_ind IS NOT NULL AND  quarter4_ind_after IS NOT NULL ) OR ( quarter4_ind IS NULL AND   quarter4_ind_after IS NULL ) ) AND   ( (pbr_prescribe_ind == pbr_prescribe_ind_after AND  pbr_prescribe_ind IS NOT NULL AND  pbr_prescribe_ind_after IS NOT NULL ) OR ( pbr_prescribe_ind IS NULL AND   pbr_prescribe_ind_after IS NULL ) ) AND   ( (pbr_hub_nbr == pbr_hub_nbr_after AND  pbr_hub_nbr IS NOT NULL AND  pbr_hub_nbr_after IS NOT NULL ) OR ( pbr_hub_nbr IS NULL AND   pbr_hub_nbr_after IS NULL ) ) AND   ( (pbr_clinic_site == pbr_clinic_site_after AND  pbr_clinic_site IS NOT NULL AND  pbr_clinic_site_after IS NOT NULL ) OR ( pbr_clinic_site IS NULL AND   pbr_clinic_site_after IS NULL ) ) AND   ( (pbr_clinic_id == pbr_clinic_id_after AND  pbr_clinic_id IS NOT NULL AND  pbr_clinic_id_after IS NOT NULL ) OR ( pbr_clinic_id IS NULL AND   pbr_clinic_id_after IS NULL ) ) AND   ( (pbr_company_cd == pbr_company_cd_after AND  pbr_company_cd IS NOT NULL AND  pbr_company_cd_after IS NOT NULL ) OR ( pbr_company_cd IS NULL AND   pbr_company_cd_after IS NULL ) ) AND   ( (pbr_phone_cmts == pbr_phone_cmts_after AND  pbr_phone_cmts IS NOT NULL AND  pbr_phone_cmts_after IS NOT NULL ) OR ( pbr_phone_cmts IS NULL AND   pbr_phone_cmts_after IS NULL ) ) AND   ( (pbr_change_req_ind == pbr_change_req_ind_after AND  pbr_change_req_ind IS NOT NULL AND  pbr_change_req_ind_after IS NOT NULL ) OR ( pbr_change_req_ind IS NULL AND   pbr_change_req_ind_after IS NULL ) ) AND   ( (pbr_source_ind == pbr_source_ind_after AND  pbr_source_ind IS NOT NULL AND  pbr_source_ind_after IS NOT NULL   ) OR ( pbr_source_ind IS NULL AND   pbr_source_ind_after IS NULL ) ) AND   ( (ndc_pbr_id == ndc_pbr_id_after AND  ndc_pbr_id IS NOT NULL AND  ndc_pbr_id_after IS NOT NULL ) OR ( ndc_pbr_id IS NULL AND   ndc_pbr_id_after IS NULL ) ) AND   ( (pbr_provider_status == pbr_provider_status_after AND  pbr_provider_status IS NOT NULL AND  pbr_provider_status_after IS NOT NULL ) OR ( pbr_provider_status IS NULL AND   pbr_provider_status_after IS NULL ) ) AND   ( (pbr_prof_status == pbr_prof_status_after AND  pbr_prof_status IS NOT NULL AND  pbr_prof_status_after IS NOT NULL ) OR ( pbr_prof_status IS NULL AND   pbr_prof_status_after IS NULL ) ) AND   ( (pbr_sex_cd == pbr_sex_cd_after AND  pbr_sex_cd IS NOT NULL AND  pbr_sex_cd_after IS NOT NULL  ) OR ( pbr_sex_cd IS NULL AND   pbr_sex_cd_after IS NULL ) ) AND   ( (pbr_birth_dttm == pbr_birth_dttm_after AND  pbr_birth_dttm IS NOT NULL AND  pbr_birth_dttm_after IS NOT NULL ) OR ( pbr_birth_dttm IS NULL AND   pbr_birth_dttm_after IS NULL ) ) AND   ( (pbr_middle_name == pbr_middle_name_after AND  pbr_middle_name IS NOT NULL AND  pbr_middle_name_after IS NOT NULL  ) OR ( pbr_middle_name IS NULL AND   pbr_middle_name_after IS NULL ) ) AND   ( (pbr_addr2 == pbr_addr2_after AND  pbr_addr2 IS NOT NULL AND  pbr_addr2_after IS NOT NULL ) OR ( pbr_addr2 IS NULL AND   pbr_addr2_after IS NULL ) ) AND   ( (pbr_dea_expire_dttm == pbr_dea_expire_dttm_after AND  pbr_dea_expire_dttm IS NOT NULL AND  pbr_dea_expire_dttm_after IS NOT NULL  ) OR ( pbr_dea_expire_dttm IS NULL AND   pbr_dea_expire_dttm_after IS NULL ) ) AND   ( (pbr_upin == pbr_upin_after AND  pbr_upin IS NOT NULL AND  pbr_upin_after IS NOT NULL  ) OR ( pbr_upin IS NULL AND   pbr_upin_after IS NULL ) ) AND   ( (pbr_license_state == pbr_license_state_after AND  pbr_license_state IS NOT NULL AND   pbr_license_state_after IS NOT NULL ) OR ( pbr_license_state IS NULL AND   pbr_license_state_after IS NULL ) ) AND   ( (pbr_state_license_nbr == pbr_state_license_nbr_after AND  pbr_state_license_nbr IS NOT NULL AND  pbr_state_license_nbr_after IS NOT NULL ) OR ( pbr_state_license_nbr IS NULL AND   pbr_state_license_nbr_after IS NULL ) ) AND   ( (ndc_pbr_loc_id == ndc_pbr_loc_id_after AND  ndc_pbr_loc_id IS NOT NULL AND  ndc_pbr_loc_id_after IS NOT NULL ) OR ( ndc_pbr_loc_id IS NULL AND   ndc_pbr_loc_id_after IS NULL ) ) AND   ( (pbr_app_cd == pbr_app_cd_after AND  pbr_app_cd IS NOT NULL AND  pbr_app_cd_after IS NOT NULL ) OR ( pbr_app_cd IS NULL AND   pbr_app_cd_after IS NULL ) ) AND   ( (pbr_npi == pbr_npi_after AND  pbr_npi IS NOT NULL AND  pbr_npi_after IS NOT NULL ) OR ( pbr_npi IS NULL AND   pbr_npi_after IS NULL ) ) AND   ( (pbr_group_id == pbr_group_id_after AND  pbr_group_id IS NOT NULL AND  pbr_group_id_after IS NOT NULL  ) OR ( pbr_group_id IS NULL AND   pbr_group_id_after IS NULL ) ) AND   ( (pbr_loc_group_id == pbr_loc_group_id_after AND  pbr_loc_group_id IS NOT NULL AND  pbr_loc_group_id_after IS NOT NULL ) OR ( pbr_loc_group_id IS NULL AND   pbr_loc_group_id_after IS NULL ) ) AND   ( (repl_by_pbr_id == repl_by_pbr_id_after AND  repl_by_pbr_id IS NOT NULL AND  repl_by_pbr_id_after IS NOT NULL ) OR ( repl_by_pbr_id IS NULL AND   repl_by_pbr_id_after IS NULL ) ) AND   ( (repl_by_pbr_loc_id == repl_by_pbr_loc_id_after AND  repl_by_pbr_loc_id IS NOT NULL AND  repl_by_pbr_loc_id_after IS NOT NULL  ) OR ( repl_by_pbr_loc_id IS NULL AND   repl_by_pbr_loc_id_after IS NULL ) ) AND   ( (pbr_state_ctrl_nbr == pbr_state_ctrl_nbr_after AND  pbr_state_ctrl_nbr IS NOT NULL AND  pbr_state_ctrl_nbr_after IS NOT NULL ) OR ( pbr_state_ctrl_nbr IS NULL AND   pbr_state_ctrl_nbr_after IS NULL ) ) AND   ( (pbr_foreign_license == pbr_foreign_license_after AND  pbr_foreign_license IS NOT NULL AND  pbr_foreign_license_after IS NOT NULL ) OR ( pbr_foreign_license IS NULL AND   pbr_foreign_license_after IS NULL ) ) )" 

#pSrcCleanseXfr

#pTgtUpdBfrXfr

#pTgtUpdAftXfr

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name =='gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, pbr_id, pbr_loc_id, pbr_status_cd, pbr_dea_nbr, pbr_dea_suf, pbr_spin_nbr, pbr_last_name, pbr_first_name, pbr_mid_init, pbr_surname_suffix, pbr_name_soundex, pbr_phone_area_cd, pbr_phone, pbr_fax_area_cd, pbr_fax, pbr_addr, pbr_city, pbr_state, pbr_zip, pbr_type_cd, pbr_specialty_cd, pbr_tax_id, pbr_cmts, CONCAT(pbr_last_active_dttm,'.000000') AS pbr_last_active_dttm, pbr_hlthcare_reform_nbr, quarter1_ind, quarter2_ind, quarter3_ind, quarter4_ind, pbr_prescribe_ind, pbr_hub_nbr, pbr_clinic_site, create_user_id, CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id, CONCAT(update_dttm,'.000000') AS update_dttm, pbr_clinic_id, pbr_company_cd, pbr_phone_cmts, pbr_change_req_ind, pbr_source_ind, ndc_pbr_id, pbr_provider_status, pbr_prof_status, pbr_sex_cd, CONCAT(pbr_birth_dttm,'.000000') AS pbr_birth_dttm, pbr_middle_name, pbr_addr2, CONCAT(pbr_dea_expire_dttm,'.000000') AS pbr_dea_expire_dttm, pbr_upin, pbr_license_state, pbr_state_license_nbr, ndc_pbr_loc_id, pbr_app_cd, pbr_npi, pbr_group_id, pbr_loc_group_id, repl_by_pbr_id, repl_by_pbr_loc_id, pbr_state_ctrl_nbr, pbr_foreign_license, tracking_id, partition_column"


# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

BATCH_ID_CHK = """'""" + BATCH_ID + """'"""
PROJ_ID_CHK = """'""" + PROJ_ID + """'"""
#print(BATCH_ID_CHK)
#print(PROJ_ID_CHK)
cutoff_records_filter = cutoff_records_output.withColumn("EDW_BATCH_ID",concat(lit("'"),col("EDW_BATCH_ID"),lit("'")))
cutoff_records_filter = cutoff_records_filter.withColumn("PROJ_NAME",concat(lit("'"),col("PROJ_NAME"),lit("'")))
#display(cutoff_records_filter)
cutoff_records_filter = cutoff_records_filter.filter((cutoff_records_filter.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_filter.PROJ_NAME == PROJ_ID_CHK))
#display(cutoff_records_filter)
#cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_output.PROJ_NAME == PROJ_ID_CHK))


#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_rx)
rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_trans)
rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_prescriber where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_prescriber where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_prescriber where " + pNopartitionTableCheck


print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)

nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  
  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

#display(ded)


# COMMAND ----------

dedup_group.printSchema()

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim( pbr_id )) ==0) then pbr_id else TRIM(pbr_id) end) as pbr_id ,
(case when (LENGTH(trim( pbr_id_after )) ==0) then pbr_id_after else TRIM(pbr_id_after) end) as pbr_id_after ,
(case when (LENGTH(trim( pbr_loc_id )) ==0) then pbr_loc_id else TRIM(pbr_loc_id) end) as pbr_loc_id ,
(case when (LENGTH(trim( pbr_loc_id_after )) ==0) then pbr_loc_id_after else TRIM(pbr_loc_id_after) end) as pbr_loc_id_after ,
(case when (LENGTH(trim( pbr_status_cd )) ==0) then pbr_status_cd else TRIM(pbr_status_cd) end) as pbr_status_cd ,
(case when (LENGTH(trim( pbr_status_cd_after )) ==0) then pbr_status_cd_after else TRIM(pbr_status_cd_after) end) as pbr_status_cd_after ,
(case when (LENGTH(trim( pbr_dea_nbr )) ==0) then pbr_dea_nbr else TRIM(pbr_dea_nbr) end) as pbr_dea_nbr ,
(case when (LENGTH(trim( pbr_dea_nbr_after )) ==0) then pbr_dea_nbr_after else TRIM(pbr_dea_nbr_after) end) as pbr_dea_nbr_after ,
(case when (LENGTH(trim( pbr_dea_suf )) ==0) then pbr_dea_suf else TRIM(pbr_dea_suf) end) as pbr_dea_suf ,
(case when (LENGTH(trim( pbr_dea_suf_after )) ==0) then pbr_dea_suf_after else TRIM(pbr_dea_suf_after) end) as pbr_dea_suf_after ,
(case when (LENGTH(trim( pbr_spin_nbr )) ==0) then pbr_spin_nbr else TRIM(pbr_spin_nbr) end) as pbr_spin_nbr ,
(case when (LENGTH(trim( pbr_spin_nbr_after )) ==0) then pbr_spin_nbr_after else TRIM(pbr_spin_nbr_after) end) as pbr_spin_nbr_after ,
(case when (LENGTH(trim( pbr_last_name )) ==0) then pbr_last_name else TRIM(pbr_last_name) end) as pbr_last_name ,
(case when (LENGTH(trim( pbr_last_name_after )) ==0) then pbr_last_name_after else TRIM(pbr_last_name_after) end) as pbr_last_name_after ,
(case when (LENGTH(trim( pbr_first_name )) ==0) then pbr_first_name else TRIM(pbr_first_name) end) as pbr_first_name ,
(case when (LENGTH(trim( pbr_first_name_after )) ==0) then pbr_first_name_after else TRIM(pbr_first_name_after) end) as pbr_first_name_after ,
(case when (LENGTH(trim( pbr_mid_init )) ==0) then pbr_mid_init else TRIM(pbr_mid_init) end) as pbr_mid_init ,
(case when (LENGTH(trim( pbr_mid_init_after )) ==0) then pbr_mid_init_after else TRIM(pbr_mid_init_after) end) as pbr_mid_init_after ,
(case when (LENGTH(trim( pbr_surname_suffix )) ==0) then pbr_surname_suffix else TRIM(pbr_surname_suffix) end) as pbr_surname_suffix ,
(case when (LENGTH(trim( pbr_surname_suffix_after )) ==0) then pbr_surname_suffix_after else TRIM(pbr_surname_suffix_after) end) as pbr_surname_suffix_after ,
(case when (LENGTH(trim( pbr_name_soundex )) ==0) then pbr_name_soundex else TRIM(pbr_name_soundex) end) as pbr_name_soundex ,
(case when (LENGTH(trim( pbr_name_soundex_after )) ==0) then pbr_name_soundex_after else TRIM(pbr_name_soundex_after) end) as pbr_name_soundex_after,
(case when (LENGTH(trim( pbr_phone_area_cd )) ==0) then pbr_phone_area_cd else TRIM(pbr_phone_area_cd) end) as pbr_phone_area_cd,
(case when (LENGTH(trim( pbr_phone_area_cd_after )) ==0) then pbr_phone_area_cd_after else TRIM(pbr_phone_area_cd_after) end) as pbr_phone_area_cd_after,
(case when (LENGTH(trim( pbr_phone )) ==0) then pbr_phone else TRIM(pbr_phone) end) as pbr_phone,
(case when (LENGTH(trim( pbr_phone_after )) ==0) then pbr_phone_after else TRIM(pbr_phone_after) end) as pbr_phone_after,
(case when (LENGTH(trim( pbr_fax_area_cd )) ==0) then pbr_fax_area_cd else TRIM(pbr_fax_area_cd) end) as pbr_fax_area_cd,
(case when (LENGTH(trim( pbr_fax_area_cd_after )) ==0) then pbr_fax_area_cd_after else TRIM(pbr_fax_area_cd_after) end) as pbr_fax_area_cd_after,
(case when (LENGTH(trim( pbr_fax )) ==0) then pbr_fax else TRIM(pbr_fax) end) as pbr_fax,
(case when (LENGTH(trim( pbr_fax_after )) ==0) then pbr_fax_after else TRIM(pbr_fax_after) end) as pbr_fax_after,
(case when (LENGTH(trim( pbr_addr )) ==0) then pbr_addr else TRIM(pbr_addr) end) as pbr_addr,
(case when (LENGTH(trim( pbr_addr_after )) ==0) then pbr_addr_after else TRIM(pbr_addr_after) end) as pbr_addr_after,
(case when (LENGTH(trim( pbr_city )) ==0) then pbr_city else TRIM(pbr_city) end) as pbr_city,
(case when (LENGTH(trim( pbr_city_after )) ==0) then pbr_city_after else TRIM(pbr_city_after) end) as pbr_city_after,
(case when (LENGTH(trim( pbr_state )) ==0) then pbr_state else TRIM(pbr_state) end) as pbr_state,
(case when (LENGTH(trim( pbr_state_after )) ==0) then pbr_state_after else TRIM(pbr_state_after) end) as pbr_state_after,
(case when (LENGTH(trim( pbr_zip )) ==0) then pbr_zip else TRIM(pbr_zip) end) as pbr_zip,
(case when (LENGTH(trim( pbr_zip_after )) ==0) then pbr_zip_after else TRIM(pbr_zip_after) end) as pbr_zip_after,
(case when (LENGTH(trim( pbr_type_cd )) ==0) then pbr_type_cd else TRIM(pbr_type_cd) end) as pbr_type_cd,
(case when (LENGTH(trim( pbr_type_cd_after )) ==0) then pbr_type_cd_after else TRIM(pbr_type_cd_after) end) as pbr_type_cd_after,
(case when (LENGTH(trim( pbr_specialty_cd )) ==0) then pbr_specialty_cd else TRIM(pbr_specialty_cd) end) as pbr_specialty_cd,
(case when (LENGTH(trim( pbr_specialty_cd_after )) ==0) then pbr_specialty_cd_after else TRIM(pbr_specialty_cd_after) end) as  pbr_specialty_cd_after,
(case when (LENGTH(trim( pbr_tax_id )) ==0) then pbr_tax_id else TRIM(pbr_tax_id) end) as pbr_tax_id,
(case when (LENGTH(trim( pbr_tax_id_after )) ==0) then pbr_tax_id_after else TRIM(pbr_tax_id_after) end) as pbr_tax_id_after,
(case when (LENGTH(trim( pbr_cmts )) ==0) then pbr_cmts else TRIM(pbr_cmts) end) as pbr_cmts,
(case when (LENGTH(trim( pbr_cmts_after )) ==0) then pbr_cmts_after else TRIM(pbr_cmts_after) end) as pbr_cmts_after,
(case when (LENGTH(trim(pbr_last_active_dttm )) ==0) then  pbr_last_active_dttm else CONCAT(CONCAT(SUBSTRING(pbr_last_active_dttm,0,10),' '),SUBSTRING(pbr_last_active_dttm,11,19)) end) as pbr_last_active_dttm,
(case when (LENGTH(trim(pbr_last_active_dttm_after )) ==0) then  pbr_last_active_dttm_after else CONCAT(CONCAT(SUBSTRING(pbr_last_active_dttm_after,0,10),' '),SUBSTRING(pbr_last_active_dttm_after,11,19)) end) as pbr_last_active_dttm_after,
(case when (LENGTH(trim( pbr_hlthcare_reform_nbr )) ==0) then pbr_hlthcare_reform_nbr else TRIM(pbr_hlthcare_reform_nbr) end) as pbr_hlthcare_reform_nbr,
(case when (LENGTH(trim( pbr_hlthcare_reform_nbr_after )) ==0) then pbr_hlthcare_reform_nbr_after else TRIM(pbr_hlthcare_reform_nbr_after) end) as pbr_hlthcare_reform_nbr_after,
(case when (LENGTH(trim( quarter1_ind )) ==0) then quarter1_ind else TRIM(quarter1_ind) end) as quarter1_ind,
(case when (LENGTH(trim( quarter1_ind_after )) ==0) then quarter1_ind_after else TRIM(quarter1_ind_after) end) as quarter1_ind_after,
(case when (LENGTH(trim( quarter2_ind )) ==0) then quarter2_ind else TRIM(quarter2_ind) end) as quarter2_ind,
(case when (LENGTH(trim( quarter2_ind_after )) ==0) then quarter2_ind_after else TRIM(quarter2_ind_after) end) as quarter2_ind_after,
(case when (LENGTH(trim( quarter3_ind )) ==0) then quarter3_ind else TRIM(quarter3_ind) end) as quarter3_ind,
(case when (LENGTH(trim( quarter3_ind_after )) ==0) then quarter3_ind_after else TRIM(quarter3_ind_after) end) as quarter3_ind_after,
(case when (LENGTH(trim( quarter4_ind )) ==0) then quarter4_ind else TRIM(quarter4_ind) end) as quarter4_ind,
(case when (LENGTH(trim( quarter4_ind_after )) ==0) then quarter4_ind_after else TRIM(quarter4_ind_after) end) as quarter4_ind_after,
(case when (LENGTH(trim( pbr_prescribe_ind )) ==0) then pbr_prescribe_ind else TRIM(pbr_prescribe_ind) end) as pbr_prescribe_ind,
(case when (LENGTH(trim( pbr_prescribe_ind_after )) ==0) then pbr_prescribe_ind_after else TRIM(pbr_prescribe_ind_after) end) as pbr_prescribe_ind_after,
(case when (LENGTH(trim( pbr_hub_nbr )) ==0) then pbr_hub_nbr else TRIM(pbr_hub_nbr) end) as pbr_hub_nbr,
(case when (LENGTH(trim( pbr_hub_nbr_after )) ==0) then pbr_hub_nbr_after else TRIM(pbr_hub_nbr_after) end) as pbr_hub_nbr_after,
(case when (LENGTH(trim( pbr_clinic_site )) ==0) then pbr_clinic_site else TRIM(pbr_clinic_site) end) as pbr_clinic_site,
(case when (LENGTH(trim( pbr_clinic_site_after )) ==0) then pbr_clinic_site_after else TRIM(pbr_clinic_site_after) end) as pbr_clinic_site_after,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else TRIM(create_user_id) end) as create_user_id,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else TRIM(create_user_id_after) end) as create_user_id_after,
(case when (LENGTH(trim(create_dttm )) ==0) then  create_dttm else CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm,11,19)) end) as create_dttm,
(case when (LENGTH(trim(create_dttm_after )) ==0) then  create_dttm_after else CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after,11,19)) end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else TRIM(update_user_id) end) as update_user_id,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else TRIM(update_user_id_after) end) as update_user_id_after,
(case when (LENGTH(trim(update_dttm )) ==0) then  update_dttm else CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm,11,19)) end) as update_dttm,
(case when (LENGTH(trim(update_dttm_after )) ==0) then  update_dttm_after else CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after,11,19)) end) as update_dttm_after,
(case when (LENGTH(trim( pbr_clinic_id )) ==0) then pbr_clinic_id else TRIM(pbr_clinic_id) end) as pbr_clinic_id,
(case when (LENGTH(trim( pbr_clinic_id_after )) ==0) then pbr_clinic_id_after else TRIM(pbr_clinic_id_after) end) as pbr_clinic_id_after,
(case when (LENGTH(trim( pbr_company_cd )) ==0) then pbr_company_cd else TRIM(pbr_company_cd) end) as pbr_company_cd,
(case when (LENGTH(trim( pbr_company_cd_after )) ==0) then pbr_company_cd_after else TRIM(pbr_company_cd_after) end) as pbr_company_cd_after,
(case when (LENGTH(trim( pbr_phone_cmts )) ==0) then pbr_phone_cmts else TRIM(pbr_phone_cmts) end) as pbr_phone_cmts,
(case when (LENGTH(trim( pbr_phone_cmts_after )) ==0) then pbr_phone_cmts_after else TRIM(pbr_phone_cmts_after) end) as pbr_phone_cmts_after,
(case when (LENGTH(trim( pbr_change_req_ind )) ==0) then pbr_change_req_ind else TRIM(pbr_change_req_ind) end) as pbr_change_req_ind,
(case when (LENGTH(trim( pbr_change_req_ind_after )) ==0) then pbr_change_req_ind_after else TRIM(pbr_change_req_ind_after) end) as pbr_change_req_ind_after,
(case when (LENGTH(trim( pbr_source_ind )) ==0) then pbr_source_ind else TRIM(pbr_source_ind) end) as pbr_source_ind,
(case when (LENGTH(trim( pbr_source_ind_after )) ==0) then pbr_source_ind_after else TRIM(pbr_source_ind_after) end) as pbr_source_ind_after,
(case when (LENGTH(trim( ndc_pbr_id )) ==0) then ndc_pbr_id else TRIM(ndc_pbr_id) end) as ndc_pbr_id,
(case when (LENGTH(trim( ndc_pbr_id_after )) ==0) then ndc_pbr_id_after else TRIM(ndc_pbr_id_after) end) as ndc_pbr_id_after,
(case when (LENGTH(trim( pbr_provider_status )) ==0) then pbr_provider_status else TRIM(pbr_provider_status) end) as pbr_provider_status,
(case when (LENGTH(trim( pbr_provider_status_after )) ==0) then pbr_provider_status_after else TRIM(pbr_provider_status_after) end) as pbr_provider_status_after,
(case when (LENGTH(trim( pbr_prof_status )) ==0) then pbr_prof_status else TRIM(pbr_prof_status) end) as pbr_prof_status,
(case when (LENGTH(trim( pbr_prof_status_after )) ==0) then pbr_prof_status_after else TRIM(pbr_prof_status_after) end) as pbr_prof_status_after,
(case when (LENGTH(trim( pbr_sex_cd )) ==0) then pbr_sex_cd else TRIM(pbr_sex_cd) end) as pbr_sex_cd,
(case when (LENGTH(trim( pbr_sex_cd_after )) ==0) then pbr_sex_cd_after else TRIM(pbr_sex_cd_after) end) as pbr_sex_cd_after,
(case when (LENGTH(trim(pbr_birth_dttm )) ==0) then  pbr_birth_dttm else CONCAT(CONCAT(SUBSTRING(pbr_birth_dttm,0,10),' '),SUBSTRING(pbr_birth_dttm,11,19)) end) as pbr_birth_dttm,
(case when (LENGTH(trim(pbr_birth_dttm_after )) ==0) then  pbr_birth_dttm_after else CONCAT(CONCAT(SUBSTRING(pbr_birth_dttm_after,0,10),' '),SUBSTRING(pbr_birth_dttm_after,11,19)) end) as pbr_birth_dttm_after,
(case when (LENGTH(trim( pbr_middle_name )) ==0) then pbr_middle_name else TRIM(pbr_middle_name) end) as pbr_middle_name,
(case when (LENGTH(trim( pbr_middle_name_after )) ==0) then pbr_middle_name_after else TRIM(pbr_middle_name_after) end) as pbr_middle_name_after,
(case when (LENGTH(trim( pbr_addr2 )) ==0) then pbr_addr2 else TRIM(pbr_addr2) end) as pbr_addr2,
(case when (LENGTH(trim( pbr_addr2_after )) ==0) then pbr_addr2_after else TRIM(pbr_addr2_after) end) as pbr_addr2_after,
(case when (LENGTH(trim(pbr_dea_expire_dttm )) ==0) then  pbr_dea_expire_dttm else CONCAT(CONCAT(SUBSTRING(pbr_dea_expire_dttm,0,10),' '),SUBSTRING(pbr_dea_expire_dttm,11,19)) end) as pbr_dea_expire_dttm,
(case when (LENGTH(trim(pbr_dea_expire_dttm_after )) ==0) then  pbr_dea_expire_dttm_after else CONCAT(CONCAT(SUBSTRING(pbr_dea_expire_dttm_after,0,10),' '),SUBSTRING(pbr_dea_expire_dttm_after,11,19)) end) as pbr_dea_expire_dttm_after,
(case when (LENGTH(trim( pbr_upin )) ==0) then pbr_upin else TRIM(pbr_upin) end) as pbr_upin,
(case when (LENGTH(trim( pbr_upin_after )) ==0) then pbr_upin_after else TRIM(pbr_upin_after) end) as pbr_upin_after,
(case when (LENGTH(trim( pbr_license_state )) ==0) then pbr_license_state else TRIM(pbr_license_state) end) as pbr_license_state,
(case when (LENGTH(trim( pbr_license_state_after )) ==0) then pbr_license_state_after else TRIM(pbr_license_state_after) end) as pbr_license_state_after,
(case when (LENGTH(trim( pbr_state_license_nbr )) ==0) then pbr_state_license_nbr else TRIM(pbr_state_license_nbr) end) as pbr_state_license_nbr,
(case when (LENGTH(trim( pbr_state_license_nbr_after )) ==0) then pbr_state_license_nbr_after else TRIM(pbr_state_license_nbr_after) end) as pbr_state_license_nbr_after,
(case when (LENGTH(trim( ndc_pbr_loc_id )) ==0) then ndc_pbr_loc_id else TRIM(ndc_pbr_loc_id) end) as ndc_pbr_loc_id,
(case when (LENGTH(trim( ndc_pbr_loc_id_after )) ==0) then ndc_pbr_loc_id_after else TRIM(ndc_pbr_loc_id_after) end) as ndc_pbr_loc_id_after,
(case when (LENGTH(trim( pbr_app_cd )) ==0) then pbr_app_cd else TRIM(pbr_app_cd) end) as pbr_app_cd,
(case when (LENGTH(trim( pbr_app_cd_after )) ==0) then pbr_app_cd_after else TRIM(pbr_app_cd_after) end) as pbr_app_cd_after,
(case when (LENGTH(trim( pbr_npi )) ==0) then pbr_npi else TRIM(pbr_npi) end) as pbr_npi,
(case when (LENGTH(trim( pbr_npi_after )) ==0) then pbr_npi_after else TRIM(pbr_npi_after) end) as pbr_npi_after,
(case when (LENGTH(trim(ow_update_dttm )) ==0) then  ow_update_dttm else CONCAT(CONCAT(SUBSTRING(ow_update_dttm,0,10),' '),SUBSTRING(ow_update_dttm,11,19)) end) as ow_update_dttm,
(case when (LENGTH(trim(ow_update_dttm_after )) ==0) then  ow_update_dttm_after else CONCAT(CONCAT(SUBSTRING(ow_update_dttm_after,0,10),' '),SUBSTRING(ow_update_dttm_after,11,19)) end) as ow_update_dttm_after,
(case when (LENGTH(trim( pbr_group_id )) ==0) then pbr_group_id else TRIM(pbr_group_id) end) as pbr_group_id,
(case when (LENGTH(trim( pbr_group_id_after )) ==0) then pbr_group_id_after else TRIM(pbr_group_id_after) end) as pbr_group_id_after,
(case when (LENGTH(trim( pbr_loc_group_id )) ==0) then pbr_loc_group_id else TRIM(pbr_loc_group_id) end) as pbr_loc_group_id,
(case when (LENGTH(trim( pbr_loc_group_id_after )) ==0) then pbr_loc_group_id_after else TRIM(pbr_loc_group_id_after) end) as pbr_loc_group_id_after,
(case when (LENGTH(trim( repl_by_pbr_id )) ==0) then repl_by_pbr_id else TRIM(repl_by_pbr_id) end) as repl_by_pbr_id,
(case when (LENGTH(trim( repl_by_pbr_id_after )) ==0) then repl_by_pbr_id_after else TRIM(repl_by_pbr_id_after) end) as repl_by_pbr_id_after,
(case when (LENGTH(trim( repl_by_pbr_loc_id )) ==0) then repl_by_pbr_loc_id else TRIM(repl_by_pbr_loc_id) end) as repl_by_pbr_loc_id,
(case when (LENGTH(trim( repl_by_pbr_loc_id_after )) ==0) then repl_by_pbr_loc_id_after else TRIM(repl_by_pbr_loc_id_after) end) as repl_by_pbr_loc_id_after,
(case when (LENGTH(trim( pbr_loc_name )) ==0) then pbr_loc_name else TRIM(pbr_loc_name) end) as pbr_loc_name,
(case when (LENGTH(trim( pbr_loc_name_after )) ==0) then pbr_loc_name_after else TRIM(pbr_loc_name_after) end) as pbr_loc_name_after,
(case when (LENGTH(trim( pbr_pecos_ind )) ==0) then pbr_pecos_ind else TRIM(pbr_pecos_ind) end) as pbr_pecos_ind,
(case when (LENGTH(trim( pbr_pecos_ind_after )) ==0) then pbr_pecos_ind_after else TRIM(pbr_pecos_ind_after) end) as pbr_pecos_ind_after,
(case when (LENGTH(trim(pbr_death_dttm )) ==0) then  pbr_death_dttm else CONCAT(CONCAT(SUBSTRING(pbr_death_dttm,0,10),' '),SUBSTRING(pbr_death_dttm,11,19)) end) as pbr_death_dttm,
(case when (LENGTH(trim(pbr_death_dttm_after )) ==0) then  pbr_death_dttm_after else CONCAT(CONCAT(SUBSTRING(pbr_death_dttm_after,0,10),' '),SUBSTRING(pbr_death_dttm_after,11,19)) end) as pbr_death_dttm_after,
(case when (LENGTH(trim( pbr_state_ctrl_nbr )) ==0) then pbr_state_ctrl_nbr else TRIM(pbr_state_ctrl_nbr) end) as pbr_state_ctrl_nbr,
(case when (LENGTH(trim( pbr_state_ctrl_nbr_after )) ==0) then pbr_state_ctrl_nbr_after else TRIM(pbr_state_ctrl_nbr_after) end) as pbr_state_ctrl_nbr_after,
(case when (LENGTH(trim( pbr_refill_area_cd )) ==0) then pbr_refill_area_cd else TRIM(pbr_refill_area_cd) end) as pbr_refill_area_cd,
(case when (LENGTH(trim( pbr_refill_area_cd_after )) ==0) then pbr_refill_area_cd_after else TRIM(pbr_refill_area_cd_after) end) as pbr_refill_area_cd_after,
(case when (LENGTH(trim( pbr_refill_phone )) ==0) then pbr_refill_phone else TRIM(pbr_refill_phone) end) as pbr_refill_phone,
(case when (LENGTH(trim( pbr_refill_phone_after )) ==0) then pbr_refill_phone_after else TRIM(pbr_refill_phone_after) end) as pbr_refill_phone_after,
(case when (LENGTH(trim( pbr_foreign_license )) ==0) then pbr_foreign_license else TRIM(pbr_foreign_license) end) as pbr_foreign_license,
(case when (LENGTH(trim( pbr_foreign_license_after )) ==0) then pbr_foreign_license_after else TRIM(pbr_foreign_license_after) end) as pbr_foreign_license_after,
(case when (LENGTH(trim( pbr_store_npi_ind )) ==0) then pbr_store_npi_ind else TRIM(pbr_store_npi_ind) end) as pbr_store_npi_ind,
(case when (LENGTH(trim( pbr_store_npi_ind_after )) ==0) then pbr_store_npi_ind_after else TRIM(pbr_store_npi_ind_after) end) as pbr_store_npi_ind_after
--,tracking_id AS tracking_id,
--partition_column AS partition_column  
from dedup_group"""

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
from pyspark.sql.functions import *
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#nr_spacetrim = nr_spacetrim.withColumn([(i,regexp_replace(nr_spacetrim[i],"\"","")) for i in nr_spacetrim.columns])
# cols = [regexp_replace(i, '"', '').alias(i) for i in nr_spacetrim.columns]
# nr_spacetrim=nr_spacetrim.select(*cols)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

#display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdBfrXfr=""" select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
pbr_id AS pbr_id ,
pbr_loc_id AS pbr_loc_id ,
pbr_status_cd AS pbr_status_cd ,
pbr_dea_nbr AS pbr_dea_nbr ,
pbr_dea_suf AS pbr_dea_suf ,
pbr_spin_nbr AS pbr_spin_nbr ,
pbr_last_name AS pbr_last_name ,
pbr_first_name AS pbr_first_name ,
pbr_mid_init AS pbr_mid_init ,
pbr_surname_suffix AS pbr_surname_suffix ,
pbr_name_soundex AS pbr_name_soundex ,
pbr_phone_area_cd AS pbr_phone_area_cd ,
pbr_phone AS pbr_phone ,
pbr_fax_area_cd AS pbr_fax_area_cd ,
pbr_fax AS pbr_fax ,
pbr_addr AS pbr_addr ,
pbr_city AS pbr_city ,
pbr_state AS pbr_state ,
pbr_zip AS pbr_zip ,
pbr_type_cd AS pbr_type_cd ,
pbr_specialty_cd AS pbr_specialty_cd ,
pbr_tax_id AS pbr_tax_id ,
pbr_cmts AS pbr_cmts ,
pbr_last_active_dttm AS pbr_last_active_dttm ,
pbr_hlthcare_reform_nbr AS pbr_hlthcare_reform_nbr ,
quarter1_ind AS quarter1_ind ,
quarter2_ind AS quarter2_ind ,
quarter3_ind AS quarter3_ind ,
quarter4_ind AS quarter4_ind ,
pbr_prescribe_ind AS pbr_prescribe_ind ,
pbr_hub_nbr AS pbr_hub_nbr ,
pbr_clinic_site AS pbr_clinic_site ,
create_user_id AS create_user_id ,
create_dttm AS create_dttm ,
update_user_id AS update_user_id ,
update_dttm AS update_dttm ,
pbr_clinic_id AS pbr_clinic_id ,
pbr_company_cd AS pbr_company_cd ,
pbr_phone_cmts AS pbr_phone_cmts ,
pbr_change_req_ind AS pbr_change_req_ind ,
pbr_source_ind AS pbr_source_ind ,
ndc_pbr_id AS ndc_pbr_id ,
pbr_provider_status AS pbr_provider_status ,
pbr_prof_status AS pbr_prof_status ,
pbr_sex_cd AS pbr_sex_cd ,
pbr_birth_dttm AS pbr_birth_dttm ,
pbr_middle_name AS pbr_middle_name ,
pbr_addr2 AS pbr_addr2 ,
pbr_dea_expire_dttm AS pbr_dea_expire_dttm ,
pbr_upin AS pbr_upin ,
pbr_license_state AS pbr_license_state ,
pbr_state_license_nbr AS pbr_state_license_nbr ,
ndc_pbr_loc_id AS ndc_pbr_loc_id ,
pbr_app_cd AS pbr_app_cd ,
pbr_npi AS pbr_npi ,
ow_update_dttm AS ow_update_dttm ,
pbr_group_id AS pbr_group_id ,
pbr_loc_group_id AS pbr_loc_group_id ,
repl_by_pbr_id AS repl_by_pbr_id ,
repl_by_pbr_loc_id AS repl_by_pbr_loc_id ,
pbr_loc_name AS pbr_loc_name ,
pbr_pecos_ind AS pbr_pecos_ind ,
pbr_death_dttm AS pbr_death_dttm ,
pbr_state_ctrl_nbr AS pbr_state_ctrl_nbr ,
pbr_refill_area_cd AS pbr_refill_area_cd ,
pbr_refill_phone AS pbr_refill_phone ,
pbr_foreign_license AS pbr_foreign_license ,
pbr_store_npi_ind AS pbr_store_npi_ind, 
'000000' AS tracking_id ,
'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """


pTgtUpdAftXfr=""" select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
pbr_id_after AS pbr_id ,
pbr_loc_id_after AS pbr_loc_id ,
pbr_status_cd_after AS pbr_status_cd ,
pbr_dea_nbr_after AS pbr_dea_nbr ,
pbr_dea_suf_after AS pbr_dea_suf ,
pbr_spin_nbr_after AS pbr_spin_nbr ,
pbr_last_name_after AS pbr_last_name ,
pbr_first_name_after AS pbr_first_name ,
pbr_mid_init_after AS pbr_mid_init ,
pbr_surname_suffix_after AS pbr_surname_suffix ,
pbr_name_soundex_after AS pbr_name_soundex ,
pbr_phone_area_cd_after  AS pbr_phone_area_cd ,
pbr_phone_after AS pbr_phone ,
pbr_fax_area_cd_after AS pbr_fax_area_cd ,
pbr_fax_after AS pbr_fax ,
pbr_addr_after AS pbr_addr ,
pbr_city_after AS pbr_city ,
pbr_state_after AS pbr_state ,
pbr_zip_after AS pbr_zip ,
pbr_type_cd_after AS pbr_type_cd ,
pbr_specialty_cd_after AS pbr_specialty_cd ,
pbr_tax_id_after AS pbr_tax_id ,
pbr_cmts_after AS pbr_cmts ,
pbr_last_active_dttm_after AS pbr_last_active_dttm ,
pbr_hlthcare_reform_nbr_after AS pbr_hlthcare_reform_nbr ,
quarter1_ind_after AS quarter1_ind ,
quarter2_ind_after AS quarter2_ind ,
quarter3_ind_after AS quarter3_ind ,
quarter4_ind_after AS quarter4_ind ,
pbr_prescribe_ind_after AS pbr_prescribe_ind ,
pbr_hub_nbr_after AS pbr_hub_nbr ,
pbr_clinic_site_after AS pbr_clinic_site ,
create_user_id_after AS create_user_id ,
create_dttm_after AS create_dttm ,
update_user_id_after AS update_user_id ,
update_dttm_after AS update_dttm ,
pbr_clinic_id_after AS pbr_clinic_id ,
pbr_company_cd_after AS pbr_company_cd ,
pbr_phone_cmts_after AS pbr_phone_cmts ,
pbr_change_req_ind_after AS pbr_change_req_ind ,
pbr_source_ind_after AS pbr_source_ind ,
ndc_pbr_id_after AS ndc_pbr_id ,
pbr_provider_status_after AS pbr_provider_status ,
pbr_prof_status_after AS pbr_prof_status ,
pbr_sex_cd_after AS pbr_sex_cd ,
pbr_birth_dttm_after AS pbr_birth_dttm ,
pbr_middle_name_after AS pbr_middle_name ,
pbr_addr2_after AS pbr_addr2 ,
pbr_dea_expire_dttm_after AS pbr_dea_expire_dttm ,
pbr_upin_after AS pbr_upin ,
pbr_license_state_after AS pbr_license_state ,
pbr_state_license_nbr_after AS pbr_state_license_nbr ,
ndc_pbr_loc_id_after AS ndc_pbr_loc_id ,
pbr_app_cd_after AS pbr_app_cd ,
pbr_npi_after AS pbr_npi ,
ow_update_dttm_after AS ow_update_dttm ,
pbr_group_id_after AS pbr_group_id ,
pbr_loc_group_id_after AS pbr_loc_group_id ,
repl_by_pbr_id_after AS repl_by_pbr_id ,
repl_by_pbr_loc_id_after AS repl_by_pbr_loc_id ,
pbr_loc_name_after AS pbr_loc_name ,
pbr_pecos_ind_after AS pbr_pecos_ind ,
pbr_death_dttm_after AS pbr_death_dttm ,
pbr_state_ctrl_nbr_after AS pbr_state_ctrl_nbr ,
pbr_refill_area_cd_after AS pbr_refill_area_cd ,
pbr_refill_phone_after AS pbr_refill_phone ,
pbr_foreign_license_after AS pbr_foreign_license ,
pbr_store_npi_ind_after AS pbr_store_npi_ind, 
'000000' AS tracking_id ,
'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """



pTgtInsBfrAftXfr = """select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
pbr_id_after AS pbr_id ,
pbr_loc_id_after AS pbr_loc_id ,
pbr_status_cd_after AS pbr_status_cd ,
pbr_dea_nbr_after AS pbr_dea_nbr ,
pbr_dea_suf_after AS pbr_dea_suf ,
pbr_spin_nbr_after AS pbr_spin_nbr ,
pbr_last_name_after AS pbr_last_name ,
pbr_first_name_after AS pbr_first_name ,
pbr_mid_init_after AS pbr_mid_init ,
pbr_surname_suffix_after AS pbr_surname_suffix ,
pbr_name_soundex_after AS pbr_name_soundex ,
pbr_phone_area_cd_after  AS pbr_phone_area_cd ,
pbr_phone_after AS pbr_phone ,
pbr_fax_area_cd_after AS pbr_fax_area_cd ,
pbr_fax_after AS pbr_fax ,
pbr_addr_after AS pbr_addr ,
pbr_city_after AS pbr_city ,
pbr_state_after AS pbr_state ,
pbr_zip_after AS pbr_zip ,
pbr_type_cd_after AS pbr_type_cd ,
pbr_specialty_cd_after AS pbr_specialty_cd ,
pbr_tax_id_after AS pbr_tax_id ,
pbr_cmts_after AS pbr_cmts ,
pbr_last_active_dttm_after AS pbr_last_active_dttm ,
pbr_hlthcare_reform_nbr_after AS pbr_hlthcare_reform_nbr ,
quarter1_ind_after AS quarter1_ind ,
quarter2_ind_after AS quarter2_ind ,
quarter3_ind_after AS quarter3_ind ,
quarter4_ind_after AS quarter4_ind ,
pbr_prescribe_ind_after AS pbr_prescribe_ind ,
pbr_hub_nbr_after AS pbr_hub_nbr ,
pbr_clinic_site_after AS pbr_clinic_site ,
create_user_id_after AS create_user_id ,
create_dttm_after AS create_dttm ,
update_user_id_after AS update_user_id ,
update_dttm_after AS update_dttm ,
pbr_clinic_id_after AS pbr_clinic_id ,
pbr_company_cd_after AS pbr_company_cd ,
pbr_phone_cmts_after AS pbr_phone_cmts ,
pbr_change_req_ind_after AS pbr_change_req_ind ,
pbr_source_ind_after AS pbr_source_ind ,
ndc_pbr_id_after AS ndc_pbr_id ,
pbr_provider_status_after AS pbr_provider_status ,
pbr_prof_status_after AS pbr_prof_status ,
pbr_sex_cd_after AS pbr_sex_cd ,
pbr_birth_dttm_after AS pbr_birth_dttm ,
pbr_middle_name_after AS pbr_middle_name ,
pbr_addr2_after AS pbr_addr2 ,
pbr_dea_expire_dttm_after AS pbr_dea_expire_dttm ,
pbr_upin_after AS pbr_upin ,
pbr_license_state_after AS pbr_license_state ,
pbr_state_license_nbr_after AS pbr_state_license_nbr ,
ndc_pbr_loc_id_after AS ndc_pbr_loc_id ,
pbr_app_cd_after AS pbr_app_cd ,
pbr_npi_after AS pbr_npi ,
ow_update_dttm_after AS ow_update_dttm ,
pbr_group_id_after AS pbr_group_id ,
pbr_loc_group_id_after AS pbr_loc_group_id ,
repl_by_pbr_id_after AS repl_by_pbr_id ,
repl_by_pbr_loc_id_after AS repl_by_pbr_loc_id ,
pbr_loc_name_after AS pbr_loc_name ,
pbr_pecos_ind_after AS pbr_pecos_ind ,
pbr_death_dttm_after AS pbr_death_dttm ,
pbr_state_ctrl_nbr_after AS pbr_state_ctrl_nbr ,
pbr_refill_area_cd_after AS pbr_refill_area_cd ,
pbr_refill_phone_after AS pbr_refill_phone ,
pbr_foreign_license_after AS pbr_foreign_license ,
pbr_store_npi_ind_after AS pbr_store_npi_ind, 
'000000' AS tracking_id ,
'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name
from nr_insert_check"""

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)
#display(gg_tbf0_update_afr)
gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)
#display(gg_tbf0_update_bfr)
gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)





# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
#display(etl_tbf0_file)
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
#display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
#display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

df_correct_time_format = etl_tbf0_reformat_cdc_check_notnull.withColumn("pbr_last_active_dttm",trim("pbr_last_active_dttm"))\
                                                            .withColumn("create_dttm",trim("create_dttm"))\
                                                            .withColumn("update_dttm",trim("update_dttm"))\
                                                            .withColumn("pbr_birth_dttm",trim("pbr_birth_dttm"))\
                                                            .withColumn("pbr_dea_expire_dttm",trim("pbr_dea_expire_dttm"))

df_time_format_corrected = df_correct_time_format.withColumn("pbr_last_active_dttm",concat(split(col("pbr_last_active_dttm"),":")[0],split(col("pbr_last_active_dttm"),":")[1],lit(":"),split(col("pbr_last_active_dttm"),":")[2],lit(":"),split(col("pbr_last_active_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("create_dttm",concat(split(col("create_dttm"),":")[0],split(col("create_dttm"),":")[1],lit(":"),split(col("create_dttm"),":")[2],lit(":"),split(col("create_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("update_dttm",concat(split(col("update_dttm"),":")[0],split(col("update_dttm"),":")[1],lit(":"),split(col("update_dttm"),":")[2],lit(":"),split(col("update_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("pbr_birth_dttm",concat(split(col("pbr_birth_dttm"),":")[0],split(col("pbr_birth_dttm"),":")[1],lit(":"),split(col("pbr_birth_dttm"),":")[2],lit(":"),split(col("pbr_birth_dttm"),":")[3]))
df_time_format_corrected = df_time_format_corrected.withColumn("pbr_dea_expire_dttm",concat(split(col("pbr_dea_expire_dttm"),":")[0],split(col("pbr_dea_expire_dttm"),":")[1],lit(":"),split(col("pbr_dea_expire_dttm"),":")[2],lit(":"),split(col("pbr_dea_expire_dttm"),":")[3]))

# COMMAND ----------

df_final = df_time_format_corrected.drop("tracking_id","partition_column")
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
  .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr")))\
  .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr")))\
  .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id")))\
  .withColumn("pbr_id",when(col("pbr_id") == "",None).otherwise(col("pbr_id")))\
  .withColumn("pbr_loc_id",when(col("pbr_loc_id") == "",None).otherwise(col("pbr_loc_id")))\
  .withColumn("pbr_last_active_dttm", to_timestamp(df_final["pbr_last_active_dttm"]))\
  .withColumn("pbr_hub_nbr",when(col("pbr_hub_nbr") == "",None).otherwise(col("pbr_hub_nbr")))\
  .withColumn("pbr_clinic_site",when(col("pbr_clinic_site") == "",None).otherwise(col("pbr_clinic_site")))\
  .withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id")))\
  .withColumn("create_dttm", to_timestamp(df_final["create_dttm"]))\
  .withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id")))\
  .withColumn("update_dttm", to_timestamp(df_final["update_dttm"]))\
  .withColumn("ndc_pbr_id",when(col("ndc_pbr_id") == "",None).otherwise(col("ndc_pbr_id")))\
  .withColumn("pbr_birth_dttm", to_timestamp(df_final["pbr_birth_dttm"]))\
  .withColumn("pbr_dea_expire_dttm", to_timestamp(df_final["pbr_dea_expire_dttm"]))\
  .withColumn("ndc_pbr_loc_id",when(col("ndc_pbr_loc_id") == "",None).otherwise(col("ndc_pbr_loc_id")))\
  .withColumn("pbr_npi",when(col("pbr_npi") == "",None).otherwise(col("pbr_npi")))\
  .withColumn("repl_by_pbr_id",when(col("repl_by_pbr_id") == "",None).otherwise(col("repl_by_pbr_id")))\
  .withColumn("repl_by_pbr_loc_id",when(col("repl_by_pbr_loc_id") == "",None).otherwise(col("repl_by_pbr_loc_id")))\
  .withColumn("pbr_specialty_cd",when(col("pbr_specialty_cd") == "",None).otherwise(col("pbr_specialty_cd")))

etl_tbf0_reformat_check_blank = df_final.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in df_final.columns])

# COMMAND ----------

etl_tbf0_reformat_check_blank.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", SNFL_TBL_NAME) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()

# COMMAND ----------


#Write API Call to Close Open Assets
#WRITEAPI_URL = dbutils.widgets.get("PAR_WRITEAPI_URL")

#Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 60, 
#                    {"PAR_WRITEAPI_URL":WRITEAPI_URL,
#                     "PAR_WRITEAPI_KEY1":"statusId",
#                     "PAR_WRITEAPI_VALUE1":"200",
#                     "PAR_WRITEAPI_KEY2":"assetId",
#                     "PAR_WRITEAPI_VALUE2":dfAssetIdStr});

#print("Write API successfully executed...")
#dbutils.notebook.exit("ETL_TBF0_PRESCRIBER_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")

# COMMAND ----------

#return only assets of control files and ssets in control files

print(len(dfAssetIdFinalArray))
rdd = spark.sparkContext.parallelize(dfAssetIdFinalArray)
print(rdd.collect())
assets_path =  mountPoint + '/pharmacy_healthcare/patient_services/etl_prescriber_assets/' + BATCH_ID 
print(assets_path)
rdd.coalesce(1).saveAsTextFile(assets_path)

#dbutils.notebook.exit(dfAssetIdStr)

# Databricks notebook source
# DBTITLE 1,Include Common Utility Functions
# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# Load Data - (INF - INFILE)

from pyspark.sql.types import *
from pyspark.sql.functions import *

inputSchema = (
  StructType([
    StructField("hc_provider_src_id",StringType(),True),
    StructField("hc_provider_addr_src_id",StringType(),True),
    StructField("src_sys_cd",StringType(),True),
    StructField("surescripts_provider_id",StringType(),True),
    StructField("spi_service_lvl_cd",StringType(),True),
    StructField("spi_eff_dt",StringType(),True),
    StructField("spi_expire_dt",StringType(),True),
    StructField("src_create_user_id",StringType(),True),
    StructField("src_create_dttm",StringType(),True),
    StructField("src_update_user_id",StringType(),True),
    StructField("src_update_dttm",StringType(),True),
    StructField("etl_change_cd",StringType(),True),
    StructField("newline_last_col", StringType(), True)
  ])
)

#filePath = mountPoint + "/" + dbutils.widgets.get("pSRC_DIR") + "/" + dbutils.widgets.get("pFILE_PATTERN") + "*" + ".dat"

# dbutils.notebook.run("/Abinitio_Rebuild//Utilities/TRANSFORM_SINGLE_ROW_FILE_INTERNAL", 60, {"PAR_DB_DELIMITER": "\x01", "PAR_DB_INPUT_PATH": filePath, "PAR_DB_NUMBER_OF_COLUMNS": 12, "PAR_RESULT_VIEW": "dfRaw"})

# global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")

# dfRaw = table(global_temp_db + ".dfRaw")

# dfRaw = sqlContext.createDataFrame(dfRaw.collect(), inputSchema)

#dfRaw = spark.read.format("csv").option("header", False).schema(inputSchema).option("delimiter","\x01").load(filePath)

#display(dfRaw)
#Replacing *.dat with IN_FILE param to process specific input file and to match row count
filePath = mountPoint + "/" + dbutils.widgets.get("pIN_FILE")

# Read the data into DF with schema & other required options
df = spark.read.format("csv")\
       .option("header", False)\
       .option("delimiter", "\x01")\
       .option("quote", "\"")\
       .schema(inputSchema)\
       .load(filePath)

# Drop the last columns as it is just a record end indicator used in Abinitio
dfRaw = df.drop("newline_last_col")

# COMMAND ----------

#df = spark.read.parquet("/mnt/wrangled/master_data/customer/staging/edw_idl_customer_opv_owg_to_edw_cust_noti_pref_extr/20210929063511/*.parquet")
#df.limit(5).write.format("parquet").mode("overwrite").save("/mnt/wrangled/master_data/customer/staging/edw_idl_customer_opv_owg_to_edw_cust_noti_pref_extr/20210929063510")

# COMMAND ----------

if dfRaw.count() != int(dbutils.widgets.get("pCNTL_FILE_CNT")) :
  raise Exception("Record Count Mismatch in Source file and Cntl File. Aborting Graph")
else:
  dfRecordCount = spark.createDataFrame([dfRaw.count()], IntegerType()).withColumn("count", col("value")).drop("value")
  
  # Save Record Count - (OUTF-Record Count SRC file)
  file_path = "{0}/{1}/{2}_temp_cnt".format(mountPoint, dbutils.widgets.get("AI_SERIAL_TEMP"), dbutils.widgets.get("pFILE_PATTERN"))
  write_data(dfRecordCount,file_path)


# COMMAND ----------

# Validation  - (RFMT-VALIDATE)

pSRC_SYS_CD = dbutils.widgets.get("pSRC_SYS_CD").upper()

dfValidated = dfRaw\
             .withColumn("ValidRecord", when((trim(col("hc_provider_src_id")) == "") | (col("hc_provider_src_id").isNull()) | (trim(col("surescripts_provider_id")) == "") | (col("surescripts_provider_id").isNull()) | (trim(col("hc_provider_addr_src_id")) == "") | (col("hc_provider_addr_src_id").isNull()), "N"))

#if pSRC_SYS_CD == "SM":
  #dfValidated = dfValidated.withColumn("ValidRecord", lit("N"))
# Apply default values to src_create_user_id and src_update_user_id according to DML
dfValidated = dfValidated \
              .withColumn("src_create_user_id", when((col("src_create_user_id").isNull()) | (trim(col("src_create_user_id")) == ""), lit("#")).otherwise(col("src_create_user_id"))) \
              .withColumn("src_update_user_id", when((col("src_update_user_id").isNull()) | (trim(col("src_update_user_id")) == ""), lit("#")).otherwise(col("src_update_user_id")))
# RFMT

if pSRC_SYS_CD == "SM1":
  dfValidated = dfValidated.withColumn("hc_provider_addr_src_id", lit("#"))

dfValidated = dfValidated.withColumn("src_sys_cd", lit(pSRC_SYS_CD))
  
dfValid = dfValidated.filter(col("ValidRecord").isNull()).drop("ValidRecord")

#Apply Substring and Concat functions on spi_eff_dt and spi_expire_dt columns to obtain date from string
#spi_eff_dt
dfSplit_spi_eff_dt = dfValid.withColumn('year', substring('spi_eff_dt', 1,4))\
    .withColumn('month', substring('spi_eff_dt', 5,2))\
    .withColumn('date', substring('spi_eff_dt', 7,2))
dfSpplitted = dfSplit_spi_eff_dt.withColumn('spi_eff_dt',concat(col("year"),lit('-'),col("month"),lit('-'),col("date"))).drop("year").drop("month").drop("date")

#spi_expire_dt
dfSplit_spi_expire_dt = dfSpplitted.withColumn('year', substring('spi_expire_dt', 1,4))\
    .withColumn('month', substring('spi_expire_dt', 5,2))\
    .withColumn('date', substring('spi_expire_dt', 7,2))
dfFinal = dfSplit_spi_expire_dt.withColumn('spi_expire_dt',concat(col("year"),lit('-'),col("month"),lit('-'),col("date"))).drop("year").drop("month").drop("date")

display(dfFinal)

# COMMAND ----------

# RFMT-ERR MSG

dfInvalid = dfValidated.filter(col("ValidRecord").isNotNull()).drop("ValidRecord")

dfInvalid = dfInvalid.na.fill("")

# Create error message
dfInvalid = dfInvalid\
            .withColumn("error_desc", when((trim(col("hc_provider_src_id")) == ""), lit("hc_provider_src_id is NULL or Blank: ")).otherwise(lit("")))\
            .withColumn("error_desc", when((trim(col("hc_provider_addr_src_id")) == ""), concat(col("error_desc"), lit("hc_provider_addr_src_id is NULL or Blank: "))).otherwise(col("error_desc")))\
            .withColumn("error_desc", when((trim(col("surescripts_provider_id")) == ""), concat(col("error_desc"), lit("surescripts_provider_id is NULL or Blank: "))).otherwise(col("error_desc")))

pIN_FILE = dbutils.widgets.get("pIN_FILE")
pSRC_DIR = dbutils.widgets.get("pSRC_DIR")
src_file = pIN_FILE.split(pSRC_DIR + "/")[1]
tgt_table = "cif_" + dbutils.widgets.get("pSRC_SYS_CD") + "_provider_address_spi_stg"

# Populate remaining fields
dfInvalid = dfInvalid\
            .withColumn("src_file", lit(src_file))\
            .withColumn("src_type", lit("File"))\
            .withColumn("src_key", concat(col("hc_provider_src_id"), lit("~"), col("src_sys_cd"), lit("~"), col("surescripts_provider_id")))\
            .withColumn("tgt_table", lit(tgt_table))\
            .withColumn("priority_cd", when(col("error_desc").isNotNull(), lit(1)).otherwise(2))\
            .withColumn("src_data", concat(col("hc_provider_src_id"), lit("~"),col("hc_provider_addr_src_id"), lit("~"),col("src_sys_cd"), lit("~"),col("surescripts_provider_id"), lit("~"),col("spi_service_lvl_cd"), lit("~"),col("spi_eff_dt"), lit("~"),col("spi_expire_dt"), lit("~"),col("src_create_user_id"), lit("~"),col("src_create_dttm"), lit("~"),col("src_update_user_id"), lit("~"),col("src_update_dttm"), lit("~"),col("etl_change_cd"), lit("~")))\
            .withColumn("edw_batch_id", lit(dbutils.widgets.get("pEDW_BATCH_ID")))\
            .withColumn("edw_batch_dt", lit(dbutils.widgets.get("pEDW_BATCH_DATE")))

# Format output
dfInvalid = dfInvalid.select("src_file", "src_type", "src_key", "tgt_table", "error_desc", "priority_cd", "src_data", "edw_batch_id", "edw_batch_dt")
display(dfInvalid)

# COMMAND ----------

# Write outputs

# Main output
dfFinal = trim_column(dfFinal)
dfFinal = escape_slash(dfFinal)
file_path_output = "{0}/{1}/edw_idl_provider_cif_sm_provider_address_spi_ldr/{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL"), dbutils.widgets.get("pEDW_BATCH_ID"))
write_data(dfFinal,file_path_output)
# Rejected Recrods
dfInvalid = trim_column(dfInvalid)
dfInvalid = escape_slash(dfInvalid)
file_path_reject = "{0}/{1}/edw_idl_provider_cif_sm_provider_address_spi/{2}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("pEDW_BATCH_ID"))
write_data(dfInvalid,file_path_reject)
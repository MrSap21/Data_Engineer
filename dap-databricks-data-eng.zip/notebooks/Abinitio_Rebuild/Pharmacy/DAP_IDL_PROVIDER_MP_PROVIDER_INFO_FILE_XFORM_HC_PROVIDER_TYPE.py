# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Import Python libs
import json
import random
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("DELTA_FILE_NAME","",label="DELTA_FILE_NAME")
dbutils.widgets.text("DELTA_FILE_DIR","",label="DELTA_FILE_DIR")
#dbutils.widgets.text("INPUT_DATA_FILES_LIST","",label="INPUT_DATA_FILES_LIST")
dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")


#input_data_files_list = dbutils.widgets.get("INPUT_DATA_FILES_LIST")
output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")
delta_file_name = dbutils.widgets.get("DELTA_FILE_NAME")
delta_file_dir = dbutils.widgets.get("DELTA_FILE_DIR")


delta_file_path = mount_point + '/' + delta_file_dir + '/' + delta_file_name + '/' + batch_id
output_file_path = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir + '/' + batch_id

# COMMAND ----------

# Define column values in List((tuple0,tuple1)) -- List((columnnamewithrelativetags,onlycolumnname))
#Credential code specific columns
col_list_credential = [("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId"),("providerInfo_entityID","entityID"),("providerInfo_professionalInfo_credential_code","credcode")] 

#Practioner code specific columns
col_list_practitioner = [("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId"),("providerInfo_entityID","entityID"),("providerInfo_professionalInfo_practitioner_code","practcode")] 

#Specialty code specific columns
col_list_specialty = [("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId"),("providerInfo_entityID","entityID"),("providerInfo_professionalInfo_specialty_code","speccode")] 

selected_credential  = [col(j) for k, j in col_list_credential]
selected_practitioner  = [col(j) for k, j in col_list_practitioner]
selected_specialty  = [col(j) for k, j in col_list_specialty]

# COMMAND ----------

#Read from delta

delta_df = spark.read.format("delta").load(delta_file_path)


# COMMAND ----------

# select only required coloumns for credential,practioner,specialty code
df2_credential=delta_df.select(*selected_credential)
df2_practitioner=delta_df.select(*selected_practitioner)
df2_specialty=delta_df.select(*selected_specialty)

#adding hard coded values to provider_catg_type column based on credential or practioner or specialty code columns
df2_credential=df2_credential.withColumn("provider_catg_type",lit("CREDENTIAL")).withColumnRenamed("credcode","provider_catg_type_cd")
df2_practitioner=df2_practitioner.withColumn("provider_catg_type",lit("PRACTITIONER")).withColumnRenamed("practcode","provider_catg_type_cd")
df2_specialty=df2_specialty.withColumn("provider_catg_type",lit("SPECIALITY")).withColumnRenamed("speccode","provider_catg_type_cd")

#drop duplicates 
df3_credential=df2_credential.dropDuplicates()
df3_practitioner=df2_practitioner.dropDuplicates()
df3_specialty=df2_specialty.dropDuplicates() 

#df4 = df3_credential.union(df3_practitioner).union(df3_specialty)

#combine credential,practioner,specialty code columns
df4 = custom_union(df3_credential,df3_practitioner)
result_df = custom_union(df4,df3_specialty)


# COMMAND ----------

#Filter mandatory columns with null records
df_final=result_df.filter("provider_catg_type_cd is not null")

# COMMAND ----------

# Write output (parquet)
write_data(df_final,output_file_path)

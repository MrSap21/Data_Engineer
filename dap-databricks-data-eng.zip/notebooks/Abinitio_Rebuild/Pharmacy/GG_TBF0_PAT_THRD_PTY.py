# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'

#print (IN_DATAFILE)
print (OUT_FILEPATH)
#print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC 
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pat_id',
'pat_id_after',
'plan_id',
'plan_id_after',
'general_recipient_nbr',
'general_recipient_nbr_after',
'plan_group_nbr',
'plan_group_nbr_after',
'plan_pat_exp_dttm',
'plan_pat_exp_dttm_after',
'primary_plan_ind',
'primary_plan_ind_after',
'person_cd',
'person_cd_after',
'pat_plan_plcy_hldr_id',
'pat_plan_plcy_hldr_id_after',
'pat_plan_plcy_hldr_rel',
'pat_plan_plcy_hldr_rel_after',
'pat_usual_cust_ind',
'pat_usual_cust_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'upi',
'upi_after',
'pat_brand_copay',
'pat_brand_copay_after',
'pat_generic_copay',
'pat_generic_copay_after',
'pat_cob_ind',
'pat_cob_ind_after',
'pat_mfg_card_ind',
'pat_mfg_card_ind_after',
'pat_employer_id',
'pat_employer_id_after',
'pat_rem_ded_amt',
'pat_rem_ded_amt_after',
'pat_rem_ben_amt',
'pat_rem_ben_amt_after',
'maj_med_plan_id',
'maj_med_plan_id_after',
'image_id',
'image_id_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 61:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 62:
      return True
  else:
    if val_len != 62:
      return True



# COMMAND ----------


in_text = spark.read.text(readList)

in_text = in_text.rdd


# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  #df_junk.write.parquet(REJ_SHORT_FILEPATH)
  df_junk.show(truncate=False)


# COMMAND ----------

#split and add schema
col_len = 62

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 62
print(f"Bad records count {rd_bad.count()}") # != 62

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

#display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_pat_thrd_pty")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( pat_id )) ==0) then pat_id else trim(pat_id)end) as pat_id,
(case when (LENGTH(trim( plan_id )) ==0) then plan_id else trim(plan_id)end) as plan_id,
(case when (LENGTH(trim( general_recipient_nbr )) ==0) then general_recipient_nbr else trim(general_recipient_nbr)end) as general_recipient_nbr,
(case when (LENGTH(trim( plan_group_nbr )) ==0) then plan_group_nbr else trim(plan_group_nbr)end) as plan_group_nbr,
(case when (LENGTH(trim( plan_pat_exp_dttm )) ==0) then plan_pat_exp_dttm else concat(substring(plan_pat_exp_dttm,1,10),' ',substring(plan_pat_exp_dttm,12,8),'.000000')end) as plan_pat_exp_dttm,
(case when (LENGTH(trim( primary_plan_ind )) ==0) then primary_plan_ind else trim(primary_plan_ind)end) as primary_plan_ind,
(case when (LENGTH(trim( person_cd )) ==0) then person_cd else trim(person_cd)end) as person_cd,
(case when (LENGTH(trim( pat_plan_plcy_hldr_id )) ==0) then pat_plan_plcy_hldr_id else trim(pat_plan_plcy_hldr_id)end) as pat_plan_plcy_hldr_id,
(case when (LENGTH(trim( pat_plan_plcy_hldr_rel )) ==0) then pat_plan_plcy_hldr_rel else trim(pat_plan_plcy_hldr_rel)end) as pat_plan_plcy_hldr_rel,
(case when (LENGTH(trim( pat_usual_cust_ind )) ==0) then pat_usual_cust_ind else trim(pat_usual_cust_ind)end) as pat_usual_cust_ind,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_dttm )) ==0) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) update_user_id,
(case when (LENGTH(trim( update_dttm )) ==0) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( upi )) ==0) then upi else trim(upi)end) as upi,
(case when (LENGTH(trim( pat_brand_copay )) ==0) then pat_brand_copay else trim(pat_brand_copay)end) as pat_brand_copay,
(case when (LENGTH(trim( pat_generic_copay )) ==0) then pat_generic_copay else trim(pat_generic_copay)end) as pat_generic_copay,
(case when (LENGTH(trim( pat_cob_ind )) ==0) then pat_cob_ind else trim(pat_cob_ind)end) as pat_cob_ind,
(case when (LENGTH(trim( pat_mfg_card_ind )) ==0) then pat_mfg_card_ind else trim(pat_mfg_card_ind)end) as pat_mfg_card_ind,
(case when (LENGTH(trim( pat_employer_id )) ==0) then pat_employer_id else trim(pat_employer_id)end) as pat_employer_id,
(case when (LENGTH(trim( pat_rem_ded_amt )) ==0) then pat_rem_ded_amt else trim(pat_rem_ded_amt)end) as pat_rem_ded_amt,
(case when (LENGTH(trim( pat_rem_ben_amt )) ==0) then pat_rem_ben_amt else trim(pat_rem_ben_amt)end) as pat_rem_ben_amt,
(case when (LENGTH(trim( maj_med_plan_id )) ==0) then maj_med_plan_id else trim(maj_med_plan_id)end) as maj_med_plan_id,
(case when (LENGTH(trim( image_id )) ==0) then image_id else trim(image_id)end) as image_id
from gg_tbf0_pat_thrd_pty where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd ='PK UPDATE')"""

# COMMAND ----------

sql2 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after)end) as pat_id,
(case when (LENGTH(trim( plan_id_after )) ==0) then plan_id_after else trim(plan_id_after)end) as plan_id,
(case when (LENGTH(trim( general_recipient_nbr_after )) ==0) then general_recipient_nbr_after else trim(general_recipient_nbr_after)end) as general_recipient_nbr,
(case when (LENGTH(trim( plan_group_nbr_after )) ==0) then plan_group_nbr_after else trim(plan_group_nbr_after)end) as plan_group_nbr,
(case when (LENGTH(trim( plan_pat_exp_dttm_after )) ==0) then plan_pat_exp_dttm_after else concat(substring(plan_pat_exp_dttm_after,1,10),' ',substring(plan_pat_exp_dttm_after,12,8),'.000000')end) as plan_pat_exp_dttm,
(case when (LENGTH(trim( primary_plan_ind_after )) ==0) then primary_plan_ind_after else trim(primary_plan_ind_after)end) as primary_plan_ind,
(case when (LENGTH(trim( person_cd_after )) ==0) then person_cd_after else trim(person_cd_after)end) as person_cd,
(case when (LENGTH(trim( pat_plan_plcy_hldr_id_after )) ==0) then pat_plan_plcy_hldr_id_after else trim(pat_plan_plcy_hldr_id_after)end) as pat_plan_plcy_hldr_id,
(case when (LENGTH(trim( pat_plan_plcy_hldr_rel_after )) ==0) then pat_plan_plcy_hldr_rel_after else trim(pat_plan_plcy_hldr_rel_after)end) as pat_plan_plcy_hldr_rel,
(case when (LENGTH(trim( pat_usual_cust_ind_after )) ==0) then pat_usual_cust_ind_after else trim(pat_usual_cust_ind_after)end) as pat_usual_cust_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( upi_after )) ==0) then upi_after else trim(upi_after)end) as upi,
(case when (LENGTH(trim( pat_brand_copay_after )) ==0) then pat_brand_copay_after else trim(pat_brand_copay_after)end) as pat_brand_copay,
(case when (LENGTH(trim( pat_generic_copay_after )) ==0) then pat_generic_copay_after else trim(pat_generic_copay_after)end) as pat_generic_copay,
(case when (LENGTH(trim( pat_cob_ind_after )) ==0) then pat_cob_ind_after else trim(pat_cob_ind_after)end) as pat_cob_ind,
(case when (LENGTH(trim( pat_mfg_card_ind_after )) ==0) then pat_mfg_card_ind_after else trim(pat_mfg_card_ind_after)end) as pat_mfg_card_ind,
(case when (LENGTH(trim( pat_employer_id_after )) ==0) then pat_employer_id_after else trim(pat_employer_id_after)end) as pat_employer_id,
(case when (LENGTH(trim( pat_rem_ded_amt_after )) ==0) then pat_rem_ded_amt_after else trim(pat_rem_ded_amt_after)end) as pat_rem_ded_amt,
(case when (LENGTH(trim( pat_rem_ben_amt_after )) ==0) then pat_rem_ben_amt_after else trim(pat_rem_ben_amt_after)end) as pat_rem_ben_amt,
(case when (LENGTH(trim( maj_med_plan_id_after )) ==0) then maj_med_plan_id_after else trim(maj_med_plan_id_after)end) as maj_med_plan_id,
(case when (LENGTH(trim( image_id_after )) ==0) then image_id_after else trim(image_id_after)end) as image_id
from gg_tbf0_pat_thrd_pty where (cdc_operation_type_cd ='SQL COMPUPDATE' or cdc_operation_type_cd ='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after)end) as pat_id,
(case when (LENGTH(trim( plan_id_after )) ==0) then plan_id_after else trim(plan_id_after)end) as plan_id,
(case when (LENGTH(trim( general_recipient_nbr_after )) ==0) then general_recipient_nbr_after else trim(general_recipient_nbr_after)end) as general_recipient_nbr,
(case when (LENGTH(trim( plan_group_nbr_after )) ==0) then plan_group_nbr_after else trim(plan_group_nbr_after)end) as plan_group_nbr,
(case when (LENGTH(trim( plan_pat_exp_dttm_after )) ==0) then plan_pat_exp_dttm_after else concat(substring(plan_pat_exp_dttm_after,1,10),' ',substring(plan_pat_exp_dttm_after,12,8),'.000000')end) as plan_pat_exp_dttm,
(case when (LENGTH(trim( primary_plan_ind_after )) ==0) then primary_plan_ind_after else trim(primary_plan_ind_after)end) as primary_plan_ind,
(case when (LENGTH(trim( person_cd_after )) ==0) then person_cd_after else trim(person_cd_after)end) as person_cd,
(case when (LENGTH(trim( pat_plan_plcy_hldr_id_after )) ==0) then pat_plan_plcy_hldr_id_after else trim(pat_plan_plcy_hldr_id_after)end) as pat_plan_plcy_hldr_id,
(case when (LENGTH(trim( pat_plan_plcy_hldr_rel_after )) ==0) then pat_plan_plcy_hldr_rel_after else trim(pat_plan_plcy_hldr_rel_after)end) as pat_plan_plcy_hldr_rel,
(case when (LENGTH(trim( pat_usual_cust_ind_after )) ==0) then pat_usual_cust_ind_after else trim(pat_usual_cust_ind_after)end) as pat_usual_cust_ind,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000')end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000')end) as update_dttm,
(case when (LENGTH(trim( upi_after )) ==0) then upi_after else trim(upi_after)end) as upi,
(case when (LENGTH(trim( pat_brand_copay_after )) ==0) then pat_brand_copay_after else trim(pat_brand_copay_after)end) as pat_brand_copay,
(case when (LENGTH(trim( pat_generic_copay_after )) ==0) then pat_generic_copay_after else trim(pat_generic_copay_after)end) as pat_generic_copay,
(case when (LENGTH(trim( pat_cob_ind_after )) ==0) then pat_cob_ind_after else trim(pat_cob_ind_after)end) as pat_cob_ind,
(case when (LENGTH(trim( pat_mfg_card_ind_after )) ==0) then pat_mfg_card_ind_after else trim(pat_mfg_card_ind_after)end) as pat_mfg_card_ind,
(case when (LENGTH(trim( pat_employer_id_after )) ==0) then pat_employer_id_after else trim(pat_employer_id_after)end) as pat_employer_id,
(case when (LENGTH(trim( pat_rem_ded_amt_after )) ==0) then pat_rem_ded_amt_after else trim(pat_rem_ded_amt_after)end) as pat_rem_ded_amt,
(case when (LENGTH(trim( pat_rem_ben_amt_after )) ==0) then pat_rem_ben_amt_after else trim(pat_rem_ben_amt_after)end) as pat_rem_ben_amt,
(case when (LENGTH(trim( maj_med_plan_id_after )) ==0) then maj_med_plan_id_after else trim(maj_med_plan_id_after)end) as maj_med_plan_id,
(case when (LENGTH(trim( image_id_after )) ==0) then image_id_after else trim(image_id_after)end) as image_id
from gg_tbf0_pat_thrd_pty where cdc_operation_type_cd ='INSERT'"""

# COMMAND ----------

df1 = spark.sql(sql1)

#display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

#display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

#display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)


# COMMAND ----------


# drop columns
#dfGood = dfGood.drop("tracking_id")
#.cast('string')
# convert date and number columns - not required as all columns are varchar
dfGood = dfFinal.withColumn("cdc_txn_commit_dttm", to_timestamp(dfFinal["cdc_txn_commit_dttm"])).withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr"))).withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr"))).withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id"))).withColumn("pat_id",when(col("pat_id") == "",None).otherwise(col("pat_id"))).withColumn("plan_pat_exp_dttm", to_timestamp(dfFinal["plan_pat_exp_dttm"])).withColumn("pat_plan_plcy_hldr_id",when(col("pat_plan_plcy_hldr_id") == "",None).otherwise(col("pat_plan_plcy_hldr_id"))).withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id"))).withColumn("create_dttm", to_timestamp(dfFinal["create_dttm"])).withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id"))).withColumn("update_dttm", to_timestamp(dfFinal["update_dttm"])).withColumn("pat_brand_copay",when(col("pat_brand_copay") == "",None).otherwise(col("pat_brand_copay"))).withColumn("pat_generic_copay",when(col("pat_generic_copay") == "",None).otherwise(col("pat_generic_copay"))).withColumn("pat_rem_ded_amt",when(col("pat_rem_ded_amt") == "",None).otherwise(col("pat_rem_ded_amt"))).withColumn("pat_rem_ben_amt",when(col("pat_rem_ben_amt") == "",None).otherwise(col("pat_rem_ben_amt")))


#Update varchars as null

from pyspark.sql.types import StringType
from pyspark.sql import functions as F

sel_snfl_tbl = "Select * FROM {0} limit 1".format(SNFL_TBL_NAME)
print(sel_snfl_tbl)
dfsf=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("query",sel_snfl_tbl)\
   .load()

#display(dfsf)
# get string
str_cols = [f.name for f in dfsf.schema.fields if (isinstance(f.dataType, StringType) and  dfsf.schema[f.name].nullable)]
#print(str_cols)


for col in str_cols:
  dfGood = dfGood.withColumn(col,when(F.col(col) == "",None).otherwise(F.col(col)))

#display(dfGood)
print(f"Final good after union {dfGood.count()}")


# COMMAND ----------


dfBad = spark.sql("select * from gg_tbf0_pat_thrd_pty where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

#display(dfBad)

print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

#WRITING DATA IN OUTPUT AND RJECT FOLDER

if((dbutils.widgets.get("PAR_DB_OUTPUT_PATH").strip())!=""):
    dfG = dfGood.write.mode('overwrite').parquet(OUT_FILEPATH)
    dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)
else:  
    raise Exception("Output path parameter passed as empty, Pass a valid value")
  


# COMMAND ----------

# Delete records from snfk table

del_snfl_tbl = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : del_snfl_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


# COMMAND ----------

# Writing to the Snowflakes Table

dfGood.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_DB) \
   .option("dbtable", SNFL_TBL_NAME) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

# COMMAND ----------



# Databricks notebook source
# Our imported libraries
import json
import os

from datetime import datetime
from functools import reduce
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import input_file_name
from pyspark.sql import functions as F

# COMMAND ----------

# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220728163100")
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","etl_tbf0_rx_transaction")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_TRANSACTION_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","gg_tbf0_rx_transaction")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_RX_TRANSACTION,GG_TBF0_RX_TRANSACTION_control")
# dbutils.widgets.text("PAR_PIPELINE_NAME","PL_MSTR_PHARMACY_AND_HEALTHCARE_PATIENT_SERVICES_ETL_TBF0_RX_TRANSACTION_LOAD")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
# dbutils.widgets.text("PAR_UnprocessedFiles","1")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")

# COMMAND ----------

#ReadAPI Call to fetch asset file names with current location:
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
# PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
# PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME") #rx_De_Dup_PrescriptionFill_RxTrans
# PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
# PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
# PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPI", 200, 
                  {"PAR_READAPI_KEY":"feedNames",
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_READAPI_VALUE":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A"});
print(Input_File_List)

# COMMAND ----------

# initializing variables
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
print(type(gg_file_list))

# COMMAND ----------

# Convert json asset location/filname to Multi FIle Name List
GG_File_FEEDNAME = FEED_NAME.split(",")[0]

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_File_FEEDNAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{GG_File_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_File_FEEDNAME}.assetid",
                                                   f"{GG_File_FEEDNAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path
import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]
print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_partial_nbr',
'fill_partial_nbr_after',
'refills_remaining',
'refills_remaining_after',
'fill_wac_cost_amt',
'fill_wac_cost_amt_after',
'plan_returnd_cost_amt',
'plan_returnd_cost_amt_after',
'plan_returnd_fee_amt',
'plan_returnd_fee_amt_after',
'plan_submtd_copay_amt',
'plan_submtd_copay_amt_after',
'pbr_id',
'pbr_id_after',
'fill_source_cd',
'fill_source_cd_after',
'refills_remain_when_ent',
'refills_remain_when_ent_after',
'cob_plan_rtrnd_fee_amt',
'cob_plan_rtrnd_fee_amt_after',
'tot_amt_paid_ind',
'tot_amt_paid_ind_after',
'drug_class',
'drug_class_after',
'drug_name',
'drug_name_after',
'drug_id',
'drug_id_after',
'plan_returnd_copay_amt',
'plan_returnd_copay_amt_after',
'plan_total_paid_amt',
'plan_total_paid_amt_after',
'plan_returnd_tax_amt',
'plan_returnd_tax_amt_after',
'plan_submtd_cost_amt',
'plan_submtd_cost_amt_after',
'plan_submtd_fee_amt',
'plan_submtd_fee_amt_after',
'plan_submtd_tax_amt',
'plan_submtd_tax_amt_after',
'pat_id',
'pat_id_after',
'sims_upc',
'sims_upc_after',
'pbr_loc_id',
'pbr_loc_id_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'cob_plan_rtrnd_copay_amt',
'cob_plan_rtrnd_copay_amt_after',
'cob_plan_total_paid_amt',
'cob_plan_total_paid_amt_after',
'cob_plan_rtrnd_cost_amt',
'cob_plan_rtrnd_cost_amt_after',
'cob_plan_rtrnd_tax_amt',
'cob_plan_rtrnd_tax_amt_after',
'cob_plan_sbmtd_copay_amt',
'cob_plan_sbmtd_copay_amt_after',
'cob_plan_sbmtd_cost_amt',
'cob_plan_sbmtd_cost_amt_after',
'cob_plan_sbmtd_fee_amt',
'cob_plan_sbmtd_fee_amt_after',
'cob_plan_sbmtd_tax_amt',
'cob_plan_sbmtd_tax_amt_after',
'src_partition_nbr',
'src_partition_nbr_after',
'fill_adjudication_cd',
'fill_adjudication_cd_after',
'fill_awp_cost_amt',
'fill_awp_cost_amt_after',
'fill_days_supply',
'fill_days_supply_after',
'fill_entered_dttm',
'fill_entered_dttm_after',
'fill_label_price_amt',
'fill_label_price_amt_after',
'fill_qty_dispensed',
'fill_qty_dispensed_after',
'fill_retail_price_amt',
'fill_retail_price_amt_after',
'claim_reference_nbr',
'claim_reference_nbr_after',
'fill_nbr_dispensed',
'fill_nbr_dispensed_after',
'plan_id',
'plan_id_after',
'fill_status_cd',
'fill_status_cd_after',
'fill_entered_user_id',
'fill_entered_user_id_after',
'fill_verified_user_id',
'fill_verified_user_id_after',
'fill_verified_dttm',
'fill_verified_dttm_after',
'fill_sold_dttm',
'fill_sold_dttm_after',
'fill_deleted_dttm',
'fill_deleted_dttm_after',
'fill_discount_cd',
'fill_discount_cd_after',
'fill_pay_method_cd',
'fill_pay_method_cd_after',
'fill_discount_amt',
'fill_discount_amt_after',
'fill_sold_amt',
'fill_sold_amt_after',
'fill_type_cd',
'fill_type_cd_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'partial_fill_cd',
'partial_fill_cd_after',
'fill_adjudication_dttm',
'fill_adjudication_dttm_after',
'cob_fill_adjudication_cd',
'cob_fill_adjudication_cd_after',
'cob_claim_ref_nbr',
'cob_claim_ref_nbr_after',
'cob_plan_id',
'cob_plan_id_after',
'cob_fill_adj_dttm',
'cob_fill_adj_dttm_after',
'fill_data_rev_id',
'fill_data_rev_id_after',
'fill_data_rev_dttm',
'fill_data_rev_dttm_after',
'filling_user_id',
'filling_user_id_after',
'filling_dttm',
'filling_dttm_after',
'override_user_id',
'override_user_id_after',
'override_dttm',
'override_dttm_after',
'entered_store_nbr',
'entered_store_nbr_after',
'reviewed_store_nbr',
'reviewed_store_nbr_after',
'plan_gross_due_amt',
'plan_gross_due_amt_after',
'cob_plan_gross_due_amt',
'cob_plan_gross_due_amt_after',
'rx_daw_ind',
'rx_daw_ind_after',
'dl_reject_cd_01',
'dl_reject_cd_01_after',
'dl_reject_cd_02',
'dl_reject_cd_02_after',
'dl_reject_cd_03',
'dl_reject_cd_03_after',
'dl_reject_cd_04',
'dl_reject_cd_04_after',
'dl_reject_cd_05',
'dl_reject_cd_05_after',
'fill_del_adjudication_cd',
'fill_del_adjudication_cd_after',
'fill_price_override_amt',
'fill_price_override_amt_after',
'plan_incentive_paid_amt',
'plan_incentive_paid_amt_after',
'general_recipient_nbr',
'general_recipient_nbr_after',
'bin_nbr',
'bin_nbr_after',
'plan_group_nbr',
'plan_group_nbr_after',
'drug_warehouse_ind',
'drug_warehouse_ind_after',
'general_phrm_nbr',
'general_phrm_nbr_after',
'fill_est_pick_up_dttm',
'fill_est_pick_up_dttm_after',
'reimburs_loss_amt',
'reimburs_loss_amt_after',
'cost_plus_fee_cd',
'cost_plus_fee_cd_after',
'accept_consult_ind',
'accept_consult_ind_after',
'basis_of_reimb_determ',
'basis_of_reimb_determ_after',
'plan_other_amt_paid',
'plan_other_amt_paid_after',
'amt_attributed_to_tax',
'amt_attributed_to_tax_after',
'plan_incent_amt_submtd',
'plan_incent_amt_submtd_after',
'plan_other_amt_submtd',
'plan_other_amt_submtd_after',
'lvl_of_svc_cd',
'lvl_of_svc_cd_after',
'cob_dl_reject_cd_01',
'cob_dl_reject_cd_01_after',
'cob_dl_reject_cd_02',
'cob_dl_reject_cd_02_after',
'cob_dl_reject_cd_03',
'cob_dl_reject_cd_03_after',
'cob_dl_reject_cd_04',
'cob_dl_reject_cd_04_after',
'cob_dl_reject_cd_05',
'cob_dl_reject_cd_05_after',
'cob_fill_del_adj_cd',
'cob_fill_del_adj_cd_after',
'cob_bin_nbr',
'cob_bin_nbr_after',
'cob_plan_group_nbr',
'cob_plan_group_nbr_after',
'cob_general_phrm_nbr',
'cob_general_phrm_nbr_after',
'cob_basis_of_reimb_detrm',
'cob_basis_of_reimb_detrm_after',
'cob_amt_attrib_to_tax',
'cob_amt_attrib_to_tax_after',
'cob_pln_othr_amt_pd',
'cob_pln_othr_amt_pd_after',
'cash_disc_sav_amt',
'cash_disc_sav_amt_after',
'general_rph_nbr',
'general_rph_nbr_after',
'routing_store_tech_inits',
'routing_store_tech_inits_after',
'sourcing_ind',
'sourcing_ind_after',
'maj_med_prior_auth_nbr',
'maj_med_prior_auth_nbr_after',
'tip_rsn_for_svc_cd',
'tip_rsn_for_svc_cd_after',
'data_rev_spec_id',
'data_rev_spec_id_after',
'data_rev_spec_dttm',
'data_rev_spec_dttm_after',
'data_rev_spec_store_nbr',
'data_rev_spec_store_nbr_after',
'fill_rph_of_record_id',
'fill_rph_of_record_id_after',
'cob_plan_incntv_paid_amt',
'cob_plan_incntv_paid_amt_after',
'cob_pln_incnt_amt_sbmtd',
'cob_pln_incnt_amt_sbmtd_after',
'cob_gen_recipient_nbr',
'cob_gen_recipient_nbr_after',
'celgene_md_auth_nbr',
'celgene_md_auth_nbr_after',
'celgene_conf_nbr',
'celgene_conf_nbr_after',
'plan_other_amt_paid_type',
'plan_other_amt_paid_type_after',
'plan_other_amt_subm_type',
'plan_other_amt_subm_type_after',
'plan_returnd_coins_amt',
'plan_returnd_coins_amt_after',
'plan_rtrnd_coins_amt',
'plan_rtrnd_coins_amt_after',
'plan_other_amt_paid_2',
'plan_other_amt_paid_2_after',
'plan_other_amt_paid_typ2',
'plan_other_amt_paid_typ2_after',
'plan_other_amt_paid_3',
'plan_other_amt_paid_3_after',
'plan_other_amt_paid_typ3',
'plan_other_amt_paid_typ3_after',
'fill_print_dttm',
'fill_print_dttm_after',
'pat_lang_pref_cd',
'pat_lang_pref_cd_after',
'rebilling_dttm',
'rebilling_dttm_after',
'fill_90day_pref_ind',
'fill_90day_pref_ind_after',
'fill_90day_pref_stat_cd',
'fill_90day_pref_stat_cd_after',
'pat_pickup_id',
'pat_pickup_id_after',
'pickup_id',
'pickup_id_after',
'pickup_first_name',
'pickup_first_name_after',
'pickup_last_name',
'pickup_last_name_after',
'pickup_id_state',
'pickup_id_state_after',
'pickup_id_country',
'pickup_id_country_after',
'pickup_id_qlfr',
'pickup_id_qlfr_after',
'pickup_rel_cd',
'pickup_rel_cd_after',
'dl_proc_msg',
'dl_proc_msg_after',
'cob_dl_proc_msg',
'cob_dl_proc_msg_after',
'proc_ctrl_nbr',
'proc_ctrl_nbr_after',
'med_partd_notice_ind',
'med_partd_notice_ind_after',
'dispensed_ndc',
'dispensed_ndc_after',
'med_partd_print_dttm',
'med_partd_print_dttm_after',
'overstock_ind',
'overstock_ind_after',
'ben_stg_qualifier_1',
'ben_stg_qualifier_1_after',
'ben_stg_qualifier_2',
'ben_stg_qualifier_2_after',
'ben_stg_qualifier_3',
'ben_stg_qualifier_3_after',
'ben_stg_qualifier_4',
'ben_stg_qualifier_4_after',
'ben_stg_amount_1',
'ben_stg_amount_1_after',
'ben_stg_amount_2',
'ben_stg_amount_2_after',
'ben_stg_amount_3',
'ben_stg_amount_3_after',
'ben_stg_amount_4',
'ben_stg_amount_4_after',
'coupon_drug_id',
'coupon_drug_id_after',
'cob_coupon_drug_id',
'cob_coupon_drug_id_after',
'coupon_ind',
'coupon_ind_after',
'cob_coupon_ind',
'cob_coupon_ind_after',
'other_coverage_cd',
'other_coverage_cd_after',
'cob_other_coverage_cd',
'cob_other_coverage_cd_after',
'partial_fil_intnded_qty',
'partial_fil_intnded_qty_after',
'triplicate_serial_nbr',
'triplicate_serial_nbr_after',
'source_system_name',
'source_system_name_after',
'source_sys_trans_id',
'source_sys_trans_id_after',
'delivery_ind',
'delivery_ind_after',
'delivery_comments',
'delivery_comments_after',
'approved_msg_cd',
'approved_msg_cd_after',
'approved_msg_cd_2',
'approved_msg_cd_2_after',
'approved_msg_cd_3',
'approved_msg_cd_3_after',
'approved_msg_cd_4',
'approved_msg_cd_4_after',
'approved_msg_cd_5',
'approved_msg_cd_5_after',
'cob_approved_msg_cd',
'cob_approved_msg_cd_after',
'cob_approved_msg_cd_2',
'cob_approved_msg_cd_2_after',
'cob_approved_msg_cd_3',
'cob_approved_msg_cd_3_after',
'cob_approved_msg_cd_4',
'cob_approved_msg_cd_4_after',
'cob_approved_msg_cd_5',
'cob_approved_msg_cd_5_after',
'cob_general_pbr_nbr',
'cob_general_pbr_nbr_after',
'cob_place_of_service',
'cob_place_of_service_after',
'cob_plan_tax_exempt_ind',
'cob_plan_tax_exempt_ind_after',
'cob_rx_denial_ovride_cd',
'cob_rx_denial_ovride_cd_after',
'cob_rx_denial_ovride_cd2',
'cob_rx_denial_ovride_cd2_after',
'cob_rx_denial_ovride_cd3',
'cob_rx_denial_ovride_cd3_after',
'cob_tax_exempt_plan_ind',
'cob_tax_exempt_plan_ind_after',
'gen_recip_nbr_returnd',
'gen_recip_nbr_returnd_after',
'general_pbr_nbr',
'general_pbr_nbr_after',
'general_rph_nbr_qlfr',
'general_rph_nbr_qlfr_after',
'medigap_id',
'medigap_id_after',
'ntwk_reimb_id_returnd',
'ntwk_reimb_id_returnd_after',
'pat_pickup_gov_auth_id',
'pat_pickup_gov_auth_id_after',
'pat_pickup_rel_cd',
'pat_pickup_rel_cd_after',
'place_of_service',
'place_of_service_after',
'plan_id_returnd',
'plan_id_returnd_after',
'plan_returnd_grp_nbr',
'plan_returnd_grp_nbr_after',
'plan_tax_exempt_ind',
'plan_tax_exempt_ind_after',
'prior_auth_cd',
'prior_auth_cd_after',
'prior_auth_nbr',
'prior_auth_nbr_after',
'routing_store_rph_inits',
'routing_store_rph_inits_after',
'rx_denial_override_cd',
'rx_denial_override_cd_after',
'rx_denial_override_cd_2',
'rx_denial_override_cd_2_after',
'rx_denial_override_cd_3',
'rx_denial_override_cd_3_after',
'sys_status_when_ent',
'sys_status_when_ent_after',
'tax_exempt_plan_ind',
'tax_exempt_plan_ind_after',
'pat_pickup_id_qlfr',
'pat_pickup_id_qlfr_after',
'proc_local_dttm',
'proc_local_dttm_after',
'proc_del_local_dttm',
'proc_del_local_dttm_after',
'timeout_local_dttm',
'timeout_local_dttm_after',
'timeout_del_local_dttm',
'timeout_del_local_dttm_after',
'sold_local_dttm',
'sold_local_dttm_after',
'cob_proc_local_dttm',
'cob_proc_local_dttm_after',
'cob_proc_del_local_dttm',
'cob_proc_del_local_dttm_after',
'cob_tmout_lcl_dttm',
'cob_tmout_lcl_dttm_after',
'cob_tmout_del_lcl_dttm',
'cob_tmout_del_lcl_dttm_after',
'db_cob_proc_ctrl_nbr',
'db_cob_proc_ctrl_nbr_after',
'org_entered_dttm',
'org_entered_dttm_after',
'dl_addl_msg_qlfr',
'dl_addl_msg_qlfr_after',
'dl_additional_msg',
'dl_additional_msg_after',
'wo_correlation_id',
'wo_correlation_id_after',
'wo_rx_count',
'wo_rx_count_after',
'short_fill_ind',
'short_fill_ind_after',
'pay_cd',
'pay_cd_after',
'filling_store_nbr',
'filling_store_nbr_after',
'fill_verified_store_nbr',
'fill_verified_store_nbr_after',
'mult_prod_review_ind',
'mult_prod_review_ind_after',
'pat_selct_user_id',
'pat_selct_user_id_after',
'pbr_selct_user_id',
'pbr_selct_user_id_after',
'pat_selct_dttm',
'pat_selct_dttm_after',
'pbr_selct_dttm',
'pbr_selct_dttm_after',
'pat_selct_str_nbr',
'pat_selct_str_nbr_after',
'pbr_selct_str_nbr',
'pbr_selct_str_nbr_after',
'ntt_ind',
'ntt_ind_after',
'multiple_tech_fill_ind',
'multiple_tech_fill_ind_after',
'cf_fill_type',
'cf_fill_type_after',
'pdmp_sel_ind',
'pdmp_sel_ind_after',
'pdmp_click_store_nbr',
'pdmp_click_store_nbr_after',
'pdmp_click_user_id',
'pdmp_click_user_id_after',
'pdmp_click_dttm',
'pdmp_click_dttm_after'
]

col_len = len(fieldList)

# COMMAND ----------

# Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

# Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  if val_len <= 6:
    return True
  if 'INSERT' in key_list[6]:
    if val_len != 503 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 504:
      return True
  else:
    if val_len != 504:
      return True

# COMMAND ----------

#spliting the assets to 4 partitions based on src_partition_nbr on asset name
readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[7]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[7]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[7]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[7]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

# Read files based on partitions
in1_text = spark.read.text(readList_src_1)
in2_text = spark.read.text(readList_src_2)
in3_text = spark.read.text(readList_src_3)
in4_text = spark.read.text(readList_src_4)

in1_text = in1_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in2_text = in2_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in3_text = in3_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in4_text = in4_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data
rdb1 = in1_text.filter(lambda x: checkbad(x[0]))
rdb2 = in2_text.filter(lambda x: checkbad(x[0]))
rdb3 = in3_text.filter(lambda x: checkbad(x[0]))
rdb4 = in4_text.filter(lambda x: checkbad(x[0]))

rdb_count = rdb1.count()+ rdb2.count()+ rdb3.count()+ rdb4.count()
rdb = rdb1+rdb2+rdb3+rdb4
if rdb_count>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)


# COMMAND ----------

# split and add schema
col_len =504

rd1 = in1_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd2 = in2_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd3 = in3_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd4 = in4_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd1_good = rd1.filter(lambda x: x[0] == col_len)
rd2_good = rd2.filter(lambda x: x[0] == col_len)
rd3_good = rd3.filter(lambda x: x[0] == col_len)
rd4_good = rd4.filter(lambda x: x[0] == col_len)

rd_bad_all = rd1+rd2+rd3+rd4
rd_bad = rd_bad_all.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

# COMMAND ----------

#add schema to df for each partition
df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

#splitted df to one df
df_split = df_g1.union(df_g2).union(df_g3).union(df_g4)

# COMMAND ----------

# #Extarct filename
# df = spark.createDataFrame(rd_good, schema)
# df_fileName = df.withColumn("fileName",input_file_name())

# #Extract partition number from file name
# df_split = df_fileName.withColumn("src_partition_nbr",split(col("fileName"),"_")[7])
# df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
# df_split = df_split.drop("fileName")

# COMMAND ----------

# function to remove "" & \\
def handlEscpeQuotes(val):
  if not val:
    return ""
  # remove rightmost "
  outval = val[0:-1]
  # remove leftmost "
  outval = outval.lstrip("\"")
  # replace double \\ with \
  outval = outval.replace("\\\\","\\")
  # replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df_split = df_split.drop('row_length')

# COMMAND ----------

df_split.createOrReplaceTempView("gg_tbf0_rx_transaction")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_rx_transaction where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")
dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_rx_transaction"))\
          .withColumnRenamed("legend_change_dttm_aftr","legend_change_dttm_after")\
          .withColumnRenamed("next_smlr_suffix_aftr","next_smlr_suffix_after")\
          .withColumnRenamed("next_lrgr_suffix_aftr","next_lrgr_suffix_after")\
          .withColumnRenamed("l_last_change_dttm_aftr","l_last_change_dttm_after")\
          .withColumnRenamed("awp_cd_1_3_aftr","awp_cd_1_3_after")\
          .withColumnRenamed("awp_pack_price_aftr","awp_pack_price_after")\
          .withColumnRenamed("awp_unit_price_aftr","awp_unit_price_after")\
          .withColumnRenamed("awp_dttm_aftr","awp_dttm_after")\
          .withColumnRenamed("wholesale_unit_price_aftr","wholesale_unit_price_after")\
          .withColumnRenamed("r1_last_change_dttm_aftr","r1_last_change_dttm_after")\
          .withColumnRenamed("awp_cd_4_6_aftr","awp_cd_4_6_after")\
          .withColumnRenamed("awp_reported_ind_aftr","awp_reported_ind_after")\
          .withColumnRenamed("r11_last_change_dttm_aftr","r11_last_change_dttm_after")\
          .withColumnRenamed("dp_pack_price_aftr","dp_pack_price_after")\
          .withColumnRenamed("dp_unit_price_aftr","dp_unit_price_after")\
          .withColumnRenamed("dp_dttm_aftr","dp_dttm_after")\
          .withColumnRenamed("s1_last_change_dttm_aftr","s1_last_change_dttm_after")\
          .withColumnRenamed("hcfa_ffp_limit_aftr","hcfa_ffp_limit_after")\
          .withColumnRenamed("whac_dttm_aftr","whac_dttm_after")\
          .withColumnRenamed("whac_pack_price_aftr","whac_pack_price_after")\
          .withColumnRenamed("cdc_operation_type_cd_before","cdc_operation_type_cd")\
          .withColumnRenamed("gen_type_cd","gen_typ_cd")\
          .withColumnRenamed("gen_type_cd_after","gen_typ_cd_after")\
          .withColumnRenamed("prod_desc_abbr_after","prod_descr_abbr_after")


df_gg = df_gg.withColumn("fileName",input_file_name())
df_gg = df_gg.withColumn("tracking_id",lit(BATCH_ID))
df_gg = df_gg.withColumn("partition_column",col("src_partition_nbr"))
df_gg = df_gg.drop("fileName")


# COMMAND ----------

spark.sql(f"TRUNCATE TABLE staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg")

# COMMAND ----------

# Check whether table exists first, and get schema if it does, else throw error and exit:
target_table = spark.sql(f"SELECT * FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg LIMIT 0")
columns = []
addititional_cols_types = []
for i in target_table.schema:
  columns.append(i)

schema = StructType(columns)

# COMMAND ----------

df_tgt_schema = df_gg.select(target_table.columns)
df_tgt_schema.createOrReplaceTempView(f'temp_gg_tbf0_rx_transaction')
spark.sql(f"INSERT INTO staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg PARTITION(partition_column) SELECT * FROM temp_gg_tbf0_rx_transaction")

# COMMAND ----------

# df_gg.write.format("delta").mode("overwrite").saveAsTable("staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_transaction_stg")

# COMMAND ----------

# Write API after successful load:
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit(PAR_WRITEAPI_VALUE2);
# dbutils.notebook.exit(True)

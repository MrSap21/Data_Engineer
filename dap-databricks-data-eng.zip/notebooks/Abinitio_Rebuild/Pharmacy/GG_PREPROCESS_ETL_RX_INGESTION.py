# Databricks notebook source
# Our imported libraries
import json
import os

from datetime import datetime
from functools import reduce
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import input_file_name

# COMMAND ----------

# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220111183013")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_rx")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_STG")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","master_data/location/output")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","master_data/location/reject")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_RX,GG_TBF0_RX_control")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL",'https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate')

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPI", 200, 
                  {"PAR_READAPI_KEY":"feedNames",
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_READAPI_VALUE":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A"});


print(Input_File_List)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
print (REJ_FILE_NOISE_RMV)
print(REJ_FILE_PAT_MOD)
print(REJ_FILE_UPD_NULL)
print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])
dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("Number of control files are not as expected")
  10/0  
      

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)

# COMMAND ----------

# Convert json asset location/filname to Multi FIle Name List
GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])
dfFileList = sqlContext.read.json(rddjson).withColumn(GG_File_FEEDNAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{GG_File_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_File_FEEDNAME}.assetid",
                                                   f"{GG_File_FEEDNAME}.assetname")

flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path
getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]
print(readList)

# COMMAND ----------

fieldList = ['cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'src_partition_nbr',
'src_partition_nbr_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'pat_id',
'pat_id_after',
'drug_id',
'drug_id_after',
'drug_class',
'drug_class_after',
'drug_non_system_cd',
'drug_non_system_cd_after',
'drug_sub_cd',
'drug_sub_cd_after',
'pbr_id',
'pbr_id_after',
'pbr_loc_id',
'pbr_loc_id_after',
'pay_cd',
'pay_cd_after',
'rx_comment',
'rx_comment_after',
'rx_daw_ind',
'rx_daw_ind_after',
'rx_written_dttm',
'rx_written_dttm_after',
'rx_original_fill_dttm',
'rx_original_fill_dttm_after',
'rx_status_cd',
'rx_status_cd_after',
'rx_sig',
'rx_sig_after',
'rx_original_qty',
'rx_original_qty_after',
'rx_total_dispensed_qty',
'rx_total_dispensed_qty_after',
'rx_refills_by_dttm',
'rx_refills_by_dttm_after',
'fill_nbr_prescribed',
'fill_nbr_prescribed_after',
'fill_nbr_dispensed',
'fill_nbr_dispensed_after',
'fill_nbr_added',
'fill_nbr_added_after',
'fill_unlimited_ind',
'fill_unlimited_ind_after',
'fill_auto_ind',
'fill_auto_ind_after',
'ordered_drug_id',
'ordered_drug_id_after',
'rx_original_qty_disp',
'rx_original_qty_disp_after',
'rx_original_days_supply',
'rx_original_days_supply_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'generic_subs_pref',
'generic_subs_pref_after',
'diagnosis_cd',
'diagnosis_cd_after',
'image_id',
'image_id_after',
'routing_store_nbr',
'routing_store_nbr_after',
'scanned_user_id',
'scanned_user_id_after',
'scanned_dttm',
'scanned_dttm_after',
'scanned_store_nbr',
'scanned_store_nbr_after',
'diagnosis_cd_qualifier',
'diagnosis_cd_qualifier_after',
'tip_rx_ind',
'tip_rx_ind_after',
'pbr_order_nbr',
'pbr_order_nbr_after',
'origin_cd',
'origin_cd_after',
'diagnosis_cd_2',
'diagnosis_cd_2_after',
'diagnosis_cd_3',
'diagnosis_cd_3_after',
'diagnosis_cd_4',
'diagnosis_cd_4_after',
'rx_pad_program_ind',
'rx_pad_program_ind_after',
'rx_pad_barcode',
'rx_pad_barcode_after',
'fill_qty_dispensed',
'fill_qty_dispensed_after',
'fill_days_supply',
'fill_days_supply_after',
'rx_added_qty',
'rx_added_qty_after',
'fill_nbr_last_disp',
'fill_nbr_last_disp_after',
'fill_entered_dttm',
'fill_entered_dttm_after',
'fill_part_nbr_last_disp',
'fill_part_nbr_last_disp_after',
'rx_vacc_manuf_lot_nbr',
'rx_vacc_manuf_lot_nbr_after',
'rx_vacc_exp_dttm',
'rx_vacc_exp_dttm_after',
'rx_vacc_area_of_admin',
'rx_vacc_area_of_admin_after',
'rx_vacc_consent_ind',
'rx_vacc_consent_ind_after',
'rx_vacc_pnl_ent_dttm',
'rx_vacc_pnl_ent_dttm_after',
'rx_vacc_pnl_status_cd',
'rx_vacc_pnl_status_cd_after',
'rx_90day_pref_ind',
'rx_90day_pref_ind_after',
'rx_90day_pref_dttm',
'rx_90day_pref_dttm_after',
'rx_90day_pref_stat_cd',
'rx_90day_pref_stat_cd_after',
'rx_90day_pref_stat_dttm',
'rx_90day_pref_stat_dttm_after',
'rx_immu_ind',
'rx_immu_ind_after',
'diagnosis_cd_5',
'diagnosis_cd_5_after',
'diagnosis_cd_qualifier_2',
'diagnosis_cd_qualifier_2_after',
'diagnosis_cd_qualifier_3',
'diagnosis_cd_qualifier_3_after',
'diagnosis_cd_qualifier_4',
'diagnosis_cd_qualifier_4_after',
'diagnosis_cd_qualifier_5',
'diagnosis_cd_qualifier_5_after',
'pbr_dea_nbr',
'pbr_dea_nbr_after',
'pbr_dea_suf',
'pbr_dea_suf_after',
'buyout_rx_ind',
'buyout_rx_ind_after',
'trmt_type_cd',
'trmt_type_cd_after',
'fill_sold_dttm',
'fill_sold_dttm_after',
'erx_pat_automatch_ind',
'erx_pat_automatch_ind_after',
'rx_90day_switch_ind',
'rx_90day_switch_ind_after',
'fill_adv_rfl_opt_ind',
'fill_adv_rfl_opt_ind_after',
'fill_adv_rfl_opt_dttm',
'fill_adv_rfl_opt_dttm_after',
'rx_vacc_info_race',
'rx_vacc_info_race_after',
'rx_vacc_info_ethnicity',
'rx_vacc_info_ethnicity_after',
'rx_vacc_info_comorbidity',
'rx_vacc_info_comorbidity_after']

# COMMAND ----------

#spliting the assets to 4 partitions based on src_partition_nbr on asset name
readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[5]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[5]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[5]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[5]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

df_source1 = spark.read.format("text").load(readList_src_1)
df_src1 = df_source1.withColumn('value',regexp_replace(col('value'),"\"",""))\
                      .withColumn('splitted',split(col('value'),'\^\|\~'))\
                      .withColumn('length',size(col('splitted')))\
                      .withColumn('6th_element',col('splitted')[6])\
                      .withColumn('checkbad',when((col('length')<=6),True)\
                                            .when(((col('6th_element').contains('INSERT')) & (col('length') < 177)),True)\
                                            .when(((col('6th_element').contains('SQL COMPUPDATE') | col('6th_element').contains('PK UPDATE'))
                                                  & (col('length') < 178)),True).otherwise(False))\
                      .withColumn('finalValue',\
                                  when((col('6th_element').contains('INSERT')),\
                                       concat(slice(col('splitted'),1,6),array(lit('INSERT')),slice(col('splitted'),7,171)))\
                                  .otherwise(slice(col('splitted'),1,178)))

df_source2 = spark.read.format("text").load(readList_src_2)
df_src2 = df_source2.withColumn('value',regexp_replace(col('value'),"\"",""))\
                      .withColumn('splitted',split(col('value'),'\^\|\~'))\
                      .withColumn('length',size(col('splitted')))\
                      .withColumn('6th_element',col('splitted')[6])\
                      .withColumn('checkbad',when((col('length')<=6),True)\
                                            .when(((col('6th_element').contains('INSERT')) & (col('length') < 177)),True)\
                                            .when(((col('6th_element').contains('SQL COMPUPDATE') | col('6th_element').contains('PK UPDATE'))
                                                  & (col('length') < 178)),True).otherwise(False))\
                      .withColumn('finalValue',\
                                  when((col('6th_element').contains('INSERT')),\
                                       concat(slice(col('splitted'),1,6),array(lit('INSERT')),slice(col('splitted'),7,171)))\
                                  .otherwise(slice(col('splitted'),1,178)))

df_source3 = spark.read.format("text").load(readList_src_3)
df_src3 = df_source3.withColumn('value',regexp_replace(col('value'),"\"",""))\
                      .withColumn('splitted',split(col('value'),'\^\|\~'))\
                      .withColumn('length',size(col('splitted')))\
                      .withColumn('6th_element',col('splitted')[6])\
                      .withColumn('checkbad',when((col('length')<=6),True)\
                                            .when(((col('6th_element').contains('INSERT')) & (col('length') < 177)),True)\
                                            .when(((col('6th_element').contains('SQL COMPUPDATE') | col('6th_element').contains('PK UPDATE'))
                                                  & (col('length') < 178)),True).otherwise(False))\
                      .withColumn('finalValue',\
                                  when((col('6th_element').contains('INSERT')),\
                                       concat(slice(col('splitted'),1,6),array(lit('INSERT')),slice(col('splitted'),7,171)))\
                                  .otherwise(slice(col('splitted'),1,178)))

df_source4 = spark.read.format("text").load(readList_src_4)
df_src4 = df_source4.withColumn('value',regexp_replace(col('value'),"\"",""))\
                      .withColumn('splitted',split(col('value'),'\^\|\~'))\
                      .withColumn('length',size(col('splitted')))\
                      .withColumn('6th_element',col('splitted')[6])\
                      .withColumn('checkbad',when((col('length')<=6),True)\
                                            .when(((col('6th_element').contains('INSERT')) & (col('length') < 177)),True)\
                                            .when(((col('6th_element').contains('SQL COMPUPDATE') | col('6th_element').contains('PK UPDATE'))
                                                  & (col('length') < 178)),True).otherwise(False))\
                      .withColumn('finalValue',\
                                  when((col('6th_element').contains('INSERT')),\
                                       concat(slice(col('splitted'),1,6),array(lit('INSERT')),slice(col('splitted'),7,171)))\
                                  .otherwise(slice(col('splitted'),1,178)))

# COMMAND ----------

df_source = df_src1.union(df_src2).union(df_src3).union(df_src4)
df_junk = df_source.where(col('checkbad') == True).select('value')
if df_junk.count() > 0:
  df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

df_cleansed1 = df_src1.select('finalValue').withColumn('len',size(col('finalValue'))).withColumn('conc',concat_ws('^|~',col('finalValue')))
print(f"Total count {df_cleansed1.count()}")

df_cleansed2 = df_src2.select('finalValue').withColumn('len',size(col('finalValue'))).withColumn('conc',concat_ws('^|~',col('finalValue')))
print(f"Total count {df_cleansed2.count()}")

df_cleansed3 = df_src3.select('finalValue').withColumn('len',size(col('finalValue'))).withColumn('conc',concat_ws('^|~',col('finalValue')))
print(f"Total count {df_cleansed3.count()}")

df_cleansed4 = df_src4.select('finalValue').withColumn('len',size(col('finalValue'))).withColumn('conc',concat_ws('^|~',col('finalValue')))
print(f"Total count {df_cleansed4.count()}")

rd1_good = df_cleansed1.where(col('len')==178).select('conc').rdd.map(lambda x: x[0].split('^|~'))
rd2_good = df_cleansed2.where(col('len')==178).select('conc').rdd.map(lambda x: x[0].split('^|~'))
rd3_good = df_cleansed3.where(col('len')==178).select('conc').rdd.map(lambda x: x[0].split('^|~'))
rd4_good = df_cleansed4.where(col('len')==178).select('conc').rdd.map(lambda x: x[0].split('^|~'))

df_cleansed = df_cleansed1.union(df_cleansed2).union(df_cleansed3).union(df_cleansed4)
rd_bad = df_cleansed.where(col('len')!=178).select('finalValue').rdd

#print(f"Good records count {rd_good.count()}") # = 32
#print(f"Bad records count {rd_bad.count()}") # != 32
schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
#display(df_cleansed)

# COMMAND ----------

#add schema to df for each partition
df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

df = df_g1.union(df_g2).union(df_g3).union(df_g4)

# COMMAND ----------

# # Extract filename
# df = spark.createDataFrame(rd_good, schema)
# df = df.withColumn("fileName",input_file_name())
# #Extract partition number from file name
# df = df.withColumn("src_partition_nbr",concat(split(col("fileName"),"_")[5]))
# df = df.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df = df.withColumn("tracking_id",lit(BATCH_ID))
df = df.withColumn("partition_column",col("src_partition_nbr"))

# df = df.drop("fileName")
# # df.createOrReplaceTempView("gg_tbf0_rx")

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_rx")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 

# COMMAND ----------

spark.sql(f"TRUNCATE TABLE staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg")

# COMMAND ----------

# Check whether table exists first, and get schema if it does, else throw error and exit:
target_table = spark.sql(f"SELECT * FROM staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg LIMIT 0")
columns = []
addititional_cols_types = []
for i in target_table.schema:
  columns.append(i)

schema = StructType(columns)

# COMMAND ----------

df_tgt_schema = df_gg.select(target_table.columns)
df_tgt_schema.createOrReplaceTempView(f'temp_gg_tbf0_rx')
spark.sql(f"INSERT INTO staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg PARTITION(partition_column) SELECT * FROM temp_gg_tbf0_rx")

# COMMAND ----------

# df.write.format("delta").mode("overwrite").saveAsTable("staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg")

# COMMAND ----------

# Write API after successful load:
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit(PAR_WRITEAPI_VALUE2)
# dbutils.notebook.exit(True)

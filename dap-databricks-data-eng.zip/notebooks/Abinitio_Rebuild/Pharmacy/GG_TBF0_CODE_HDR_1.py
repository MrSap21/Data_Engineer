# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")


#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID


print (OUT_FILEPATH)
print (REJ_FILEPATH)


# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

display(dfFileList)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
#print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime

#dbutils.widgets.text("PAR_DB_FILE_LIST","DAPDEVDWH01.PRDRX2STAGE")
#dbutils.widgets.remove("PAR_DB_FILE_NAME")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'category_cd',
'category_cd_after',
'category_desc',
'category_desc_after',
'local_ind',
'local_ind_after',
'secondary_decode_mask',
'secondary_decode_mask_after',
'maintain_ind',
'maintain_ind_after',
'code_decode_mask',
'code_decode_mask_after',
'primary_decode_mask',
'primary_decode_mask_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after']

# COMMAND ----------

def addlistlength(lst) :
  lst1 = list(lst)
  if lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

in_text = spark.read.text(readList)
col_len = 36

rd1 = in_text.rdd.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
print(rd1.count())
rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(rd_good.count()) # = 64
print(rd_bad.count()) # != 64


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

df.createOrReplaceTempView("gg_tbf0_code_hdr")

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

sql1 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd_before,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
edw_batch_id,
(case when (LENGTH(trim( category_cd )) ==0) then category_cd else trim(category_cd)end) as category_cd,
(case when (LENGTH(trim( category_desc )) ==0) then category_desc else trim(category_desc)end) as category_desc,
(case when (LENGTH(trim( local_ind )) ==0) then local_ind else trim(local_ind)end) as local_ind,
(case when (LENGTH(trim( secondary_decode_mask )) ==0) then secondary_decode_mask else trim(secondary_decode_mask)end) as secondary_decode_mask,
(case when (LENGTH(trim( maintain_ind )) ==0) then maintain_ind else trim(maintain_ind)end) as maintain_ind,
(case when (LENGTH(trim( code_decode_mask )) ==0) then code_decode_mask else trim(code_decode_mask)end) as code_decode_mask,
(case when (LENGTH(trim( primary_decode_mask )) ==0) then primary_decode_mask else trim(primary_decode_mask)end) as primary_decode_mask,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_dttm )) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim(update_dttm )) ==0) then  update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8),'.000000') end) as update_dttm
from gg_tbf0_code_hdr where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql2 = """select
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd_before,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( category_cd_after )) ==0) then category_cd_after else trim(category_cd_after)end) as category_cd,
(case when (LENGTH(trim( category_desc_after )) ==0) then category_desc_after else trim(category_desc_after)end) as category_desc,
(case when (LENGTH(trim( local_ind_after )) ==0) then local_ind_after else trim(local_ind_after)end) as local_ind,
(case when (LENGTH(trim( secondary_decode_mask_after )) ==0) then secondary_decode_mask_after else trim(secondary_decode_mask_after)end) as secondary_decode_mask,
(case when (LENGTH(trim( maintain_ind_after )) ==0) then maintain_ind_after else trim(maintain_ind_after)end) as maintain_ind,
(case when (LENGTH(trim( code_decode_mask_after )) ==0) then code_decode_mask_after else trim(code_decode_mask_after)end) as code_decode_mask,
(case when (LENGTH(trim( primary_decode_mask_after )) ==0) then primary_decode_mask_after else trim(primary_decode_mask_after)end) as primary_decode_mask,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim(update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000') end) as update_dttm
from gg_tbf0_code_hdr where (cdc_operation_type_cd_before ='SQL COMPUPDATE' or cdc_operation_type_cd_before ='PK UPDATE')"""

# COMMAND ----------

sql3 = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8),'.000000') end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd_before,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim( category_cd_after )) ==0) then category_cd_after else trim(category_cd_after)end) as category_cd,
(case when (LENGTH(trim( category_desc_after )) ==0) then category_desc_after else trim(category_desc_after)end) as category_desc,
(case when (LENGTH(trim( local_ind_after )) ==0) then local_ind_after else trim(local_ind_after)end) as local_ind,
(case when (LENGTH(trim( secondary_decode_mask_after )) ==0) then secondary_decode_mask_after else trim(secondary_decode_mask_after)end) as secondary_decode_mask,
(case when (LENGTH(trim( maintain_ind_after )) ==0) then maintain_ind_after else trim(maintain_ind_after)end) as maintain_ind,
(case when (LENGTH(trim( code_decode_mask_after )) ==0) then code_decode_mask_after else trim(code_decode_mask_after)end) as code_decode_mask,
(case when (LENGTH(trim( primary_decode_mask_after )) ==0) then primary_decode_mask_after else trim(primary_decode_mask_after)end) as primary_decode_mask,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after )) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8),'.000000') end) as create_dttm,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id,
(case when (LENGTH(trim(update_dttm_after )) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8),'.000000') end) as update_dttm
from gg_tbf0_code_hdr where cdc_operation_type_cd_before ='INSERT'"""

# COMMAND ----------

df1 = spark.sql(sql1)

display(df1)
print(f"sql 1 filter count : {df1.count()}")

# COMMAND ----------

df2 = spark.sql(sql2)

display(df2)
print(f"sql 2 filter count : {df2.count()}")

# COMMAND ----------

df3 = spark.sql(sql3)

display(df3)
print(f"sql 3 filter count : {df3.count()}")

# COMMAND ----------

dfFinal = df1.union(df2)

dfFinal = dfFinal.union(df3)

dfFinal.createOrReplaceTempView("gg_tbf0_code_hdr_final")

# drop columns
df_final = dfFinal.drop("tracking_id")
# convert date and number columns
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
           .withColumn("create_dttm",to_timestamp(df_final["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(df_final["update_dttm"]))\
           .withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr")))\
           .withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr")))\
           .withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id")))\
           .withColumn("category_cd",when(col("category_cd") == "",None).otherwise(col("category_cd")))\
           .withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id")))\
           .withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id")))
           


#final df to load
display(df_final)
print(f"Final count after union {df_final.count()}")





# COMMAND ----------

#Bad records 
dfBad = spark.sql("select * from gg_tbf0_code_hdr where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")
display(dfBad)
print(f"Bad records count {dfBad.count()}")

# COMMAND ----------

# #WRITING DATA IN OUTPUT AND RJECT FOLDER
df_final.write.parquet(OUT_FILEPATH)

dfBad.write.parquet(REJ_FILEPATH)

# write bad records for junk columns
if rd_bad.count() > 0:
  bad_df_1 = spark.createDataFrame(rd_bad)
  bad_df_1.write.mode('append').parquet(REJ_FILEPATH)


# COMMAND ----------

# MAGIC %run 
# MAGIC ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# delete records from snfk table
delete_gg_snowflake = "DELETE FROM {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL", 120, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})



# COMMAND ----------

#Writing to the Snowflakes Table
df_final = df_final.withColumn("edw_batch_id",lit(BATCH_ID))

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .mode("append") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

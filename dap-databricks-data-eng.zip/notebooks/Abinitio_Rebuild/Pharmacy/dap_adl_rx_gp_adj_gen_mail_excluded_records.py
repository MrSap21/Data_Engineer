# Databricks notebook source
import os
import json

# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# Defining Pipeline Parameters

# dbutils.widgets.text("PAR_NB_PARAMETER_LIST","$AI_SERIAL=/customer/dap_gen_run_pgm/script,$EDW_BATCH_ID=20190404")

os.environ['scriptPath'] = "/dbfs" + mountPoint + dbutils.widgets.get("PAR_NB_SCRIPT_PATH") 
os.environ['scriptName'] = dbutils.widgets.get("PAR_NB_SCRIPT_NAME")

os.environ['pEDW_BATCH_ID'] = dbutils.widgets.get("PAR_NB_BATCH_ID")
os.environ['out_file_name'] = dbutils.widgets.get("PAR_NB_OUT_FILE_NAME") 
os.environ['excl_type'] = dbutils.widgets.get("PAR_NB_EXCL_TYPE")
os.environ['mail_list'] = dbutils.widgets.get("PAR_NB_MAIL_LIST")
os.environ['AI_SERIAL_LOG'] = dbutils.widgets.get("PAR_NB_AI_SERIAL_LOG")
os.environ['AI_SERIAL'] = dbutils.widgets.get("PAR_NB_AI_SERIAL")
os.environ['LOG_FILE'] = dbutils.widgets.get("PAR_NB_LOG_FILE")
os.environ['AI_GRAPH_NAME'] = dbutils.widgets.get("PAR_NB_AI_GRAPH_NAME")

# COMMAND ----------

# MAGIC %sh
# MAGIC 
# MAGIC pushd $scriptPath
# MAGIC 
# MAGIC $scriptPath/$scriptName $out_file_name $excl_type $mail_list $pEDW_BATCH_ID $AI_GRAPH_NAME $LOG_FILE $AI_SERIAL_LOG $AI_SERIAL
# MAGIC 
# MAGIC popd

# COMMAND ----------


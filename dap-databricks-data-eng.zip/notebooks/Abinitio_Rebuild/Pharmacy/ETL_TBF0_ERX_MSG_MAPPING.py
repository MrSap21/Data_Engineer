# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# #Create Widgets for Parameters
# dbutils.widgets.text("PAR_DB_BATCH_ID","20220224070910")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_erx_msg_mapping")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_ERX_MSG_MAPPING_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_UNPROCESSED_FILES","{'gg_tbf0_erx_msg_mapping': [{'assetid': 4552, 'assetname': 'PRDRX2STAGE_GG_TBF0_ERX_MSG_MAPPING_2022-02-08_data.dsv', 'assetcurrentlocation': 'pharmacy_healthcare/plan/icplus/2022/02/18/'}]}")
# dbutils.widgets.text("PAR_DB_FEED_NAME","GG_TBF0_ERX_MSG_MAPPING")

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
#FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
#READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
#BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
#PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
#PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
#PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
#PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

#Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 100, 
#                 {"PAR_EDW_BATCH_ID":BATCH_ID,
#                  "PAR_FEED_NAMES":FEED_NAME,
#                  "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
#                  "PAR_READAPI_URL":READAPI_URL,
#                  "PAR_SQL_SERVER":PAR_SQL_SERVER,
#                 "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
#                  "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
#                  "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
#                  "PAR_RETURN_FILE_TYPE":"A"});
#
#print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")
FEED_NAME = dbutils.widgets.get("PAR_DB_FEED_NAME")
Input_File_List=dbutils.widgets.get("PAR_UNPROCESSED_FILES")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = [
'row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'icp_erx_msg_id',
'icp_erx_msg_id_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'epbr_erx_msg_id',
'epbr_erx_msg_id_after',
'erx_msg_type_sent',
'erx_msg_type_sent_after',
'erx_msg_sent_dttm',
'erx_msg_sent_dttm_after',
'erx_msg_type_rcvd',
'erx_msg_type_rcvd_after',
'erx_msg_rcvd_dttm',
'erx_msg_rcvd_dttm_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'pbr_clinic_id',
'pbr_clinic_id_after',
'erx_xml_image_id',
'erx_xml_image_id_after',
'drug_schedule',
'drug_schedule_after',
'erx_pat_full_name',
'erx_pat_full_name_after',
'erx_pat_address',
'erx_pat_address_after',
'erx_pbr_full_name',
'erx_pbr_full_name_after',
'erx_pbr_address',
'erx_pbr_address_after',
'digital_sig_ind',
'digital_sig_ind_after',
'erx_del_cntrl_drug_nme',
'erx_del_cntrl_drug_nme_after',
'erx_del_cntrl_drug_ndc',
'erx_del_cntrl_drug_ndc_after',
'erx_del_cntrl_drug_gpi',
'erx_del_cntrl_drug_gpi_after',
'erx_del_cntrl_pbr_id',
'erx_del_cntrl_pbr_id_after',
'erx_exc_resolved_ind',
'erx_exc_resolved_ind_after',
'msg_ncpdp_vendor_name',
'msg_ncpdp_vendor_name_after',
'msg_ncpdp_app_name',
'msg_ncpdp_app_name_after',
'msg_ncpdp_app_version',
'msg_ncpdp_app_version_after',
'msg_drug_cov_cds',
'msg_drug_cov_cds_after',
'pbr_dig_sig_value',
'pbr_dig_sig_value_after',
'pbr_dig_digest_value',
'pbr_dig_digest_value_after',
'pbr_dig_x509data',
'pbr_dig_x509data_after',
'wag_dig_sig',
'wag_dig_sig_after',
'wag_dig_x509data',
'wag_dig_x509data_after',
'facility_id_1',
'facility_id_1_after',
'facility_id_qual_1',
'facility_id_qual_1_after',
'facility_id_2',
'facility_id_2_after',
'facility_id_qual_2',
'facility_id_qual_2_after',
'facility_id_3',
'facility_id_3_after',
'facility_id_qual_3',
'facility_id_qual_3_after',
'erx_phrm_ncpdp_id',
'erx_phrm_ncpdp_id_after',
'erx_pbr_phone_nbr',
'erx_pbr_phone_nbr_after',
'erx_pat_brth_dt',
'erx_pat_brth_dt_after',
'erx_drug_desc',
'erx_drug_desc_after',
'erx_ndc',
'erx_ndc_after',
'erx_rx_sig',
'erx_rx_sig_after',
'erx_rx_written_dttm',
'erx_rx_written_dttm_after',
'erx_rx_note',
'erx_rx_note_after',
'cancel_reqst_deny_reason_cd',
'cancel_reqst_deny_reason_cd_after',
'cancel_reqst_deny_reason_txt',
'cancel_reqst_deny_reason_txt_after',
'erx_overwrite_cmnt_ind',
'erx_overwrite_cmnt_ind_after',
'erx_relate_to_msg_id',
'erx_relate_to_msg_id_after',
'erx_relate_to_msg_sent_dttm',
'erx_relate_to_msg_sent_dttm_after',
'erx_pbr_ord_nbr',
'erx_pbr_ord_nbr_after',
'erx_pbr_npi',
'erx_pbr_npi_after',
'erx_prev_dspn_ind',
'erx_prev_dspn_ind_after',
'cancel_reqst_response_type_cd',
'cancel_reqst_response_type_cd_after',
'msg_erx_opa_id_1',
'msg_erx_opa_id_1_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if '"INSERT"' in key_list[6]:
    if val_len != 129 :
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 130:
      return True
  else:
    if val_len != 130:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 130

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)
#display(df)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
#display(df)
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col_name)),
    df.columns,
    df
))
#display(df)

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_erx_msg_mapping")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_erx_msg_mapping where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)
#display(dfBad)

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_erx_msg_mapping")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 
#display(df_gg)
df_gg.createOrReplaceTempView("raw_gg_tbf0_erx_msg_mapping")
#display(df_gg)

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcGgTbf0Schema

pUpdateReform="((cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm is NOT NULL AND cdc_txn_commit_dttm_after is NOT NULL AND  cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr is NOT NULL AND cdc_seq_nbr_after is NOT NULL AND  cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr is NOT NULL AND cdc_rba_nbr_after is NOT NULL AND  icp_erx_msg_id == icp_erx_msg_id_after AND icp_erx_msg_id is NOT NULL AND icp_erx_msg_id_after is NOT NULL AND  store_nbr == store_nbr_after AND store_nbr is NOT NULL AND store_nbr_after is NOT NULL AND  rx_nbr == rx_nbr_after AND rx_nbr is NOT NULL AND rx_nbr_after is NOT NULL AND  ( (epbr_erx_msg_id == epbr_erx_msg_id_after AND epbr_erx_msg_id is NOT NULL AND epbr_erx_msg_id_after is NOT NULL ) OR (epbr_erx_msg_id IS NULL  AND  epbr_erx_msg_id_after IS NULL)) AND  ( (erx_msg_type_sent == erx_msg_type_sent_after AND erx_msg_type_sent is NOT NULL AND erx_msg_type_sent_after is NOT NULL ) OR (erx_msg_type_sent IS NULL  AND  erx_msg_type_sent_after IS NULL)) AND  ( (erx_msg_sent_dttm == erx_msg_sent_dttm_after AND erx_msg_sent_dttm is NOT NULL AND erx_msg_sent_dttm_after is NOT NULL ) OR (erx_msg_sent_dttm IS NULL  AND  erx_msg_sent_dttm_after IS NULL)) AND  ( (erx_msg_type_rcvd == erx_msg_type_rcvd_after AND erx_msg_type_rcvd is NOT NULL AND erx_msg_type_rcvd_after is NOT NULL ) OR (erx_msg_type_rcvd IS NULL  AND  erx_msg_type_rcvd_after IS NULL)) AND  ( (erx_msg_rcvd_dttm == erx_msg_rcvd_dttm_after AND erx_msg_rcvd_dttm is NOT NULL AND erx_msg_rcvd_dttm_after is NOT NULL ) OR (erx_msg_rcvd_dttm IS NULL  AND  erx_msg_rcvd_dttm_after IS NULL)) AND  ( (create_user_id == create_user_id_after AND create_user_id is NOT NULL AND create_user_id_after is NOT NULL ) OR (create_user_id IS NULL  AND  create_user_id_after IS NULL)) AND  ( (create_dttm == create_dttm_after AND create_dttm is NOT NULL AND create_dttm_after is NOT NULL ) OR (create_dttm IS NULL  AND  create_dttm_after IS NULL)) AND  ( (pbr_clinic_id == pbr_clinic_id_after AND pbr_clinic_id is NOT NULL AND pbr_clinic_id_after is NOT NULL ) OR (pbr_clinic_id IS NULL  AND  pbr_clinic_id_after IS NULL)) AND  ( (erx_xml_image_id == erx_xml_image_id_after AND erx_xml_image_id is NOT NULL AND erx_xml_image_id_after is NOT NULL ) OR (erx_xml_image_id IS NULL  AND  erx_xml_image_id_after IS NULL)) AND  ( (drug_schedule == drug_schedule_after AND drug_schedule is NOT NULL AND drug_schedule_after is NOT NULL ) OR (drug_schedule IS NULL  AND  drug_schedule_after IS NULL)) AND  ( (erx_pat_full_name == erx_pat_full_name_after AND erx_pat_full_name is NOT NULL AND erx_pat_full_name_after is NOT NULL ) OR (erx_pat_full_name IS NULL  AND  erx_pat_full_name_after IS NULL)) AND  ( (erx_pat_address == erx_pat_address_after AND erx_pat_address is NOT NULL AND erx_pat_address_after is NOT NULL ) OR (erx_pat_address IS NULL  AND  erx_pat_address_after IS NULL)) AND  ( (erx_pbr_full_name == erx_pbr_full_name_after AND erx_pbr_full_name is NOT NULL AND erx_pbr_full_name_after is NOT NULL ) OR (erx_pbr_full_name IS NULL  AND  erx_pbr_full_name_after IS NULL)) AND  ( (erx_pbr_address == erx_pbr_address_after AND erx_pbr_address is NOT NULL AND erx_pbr_address_after is NOT NULL ) OR (erx_pbr_address IS NULL  AND  erx_pbr_address_after IS NULL)) AND  ( (digital_sig_ind == digital_sig_ind_after AND digital_sig_ind is NOT NULL AND digital_sig_ind_after is NOT NULL ) OR (digital_sig_ind IS NULL  AND  digital_sig_ind_after IS NULL)) AND  ( (erx_del_cntrl_drug_nme == erx_del_cntrl_drug_nme_after AND erx_del_cntrl_drug_nme is NOT NULL AND erx_del_cntrl_drug_nme_after is NOT NULL ) OR (erx_del_cntrl_drug_nme IS NULL  AND  erx_del_cntrl_drug_nme_after IS NULL)) AND  ( (erx_del_cntrl_drug_ndc == erx_del_cntrl_drug_ndc_after AND erx_del_cntrl_drug_ndc is NOT NULL AND erx_del_cntrl_drug_ndc_after is NOT NULL ) OR (erx_del_cntrl_drug_ndc IS NULL  AND  erx_del_cntrl_drug_ndc_after IS NULL)) AND  ( (erx_del_cntrl_drug_gpi == erx_del_cntrl_drug_gpi_after AND erx_del_cntrl_drug_gpi is NOT NULL AND erx_del_cntrl_drug_gpi_after is NOT NULL ) OR (erx_del_cntrl_drug_gpi IS NULL  AND  erx_del_cntrl_drug_gpi_after IS NULL)) AND  ( (erx_del_cntrl_pbr_id == erx_del_cntrl_pbr_id_after AND erx_del_cntrl_pbr_id is NOT NULL AND erx_del_cntrl_pbr_id_after is NOT NULL ) OR (erx_del_cntrl_pbr_id IS NULL  AND  erx_del_cntrl_pbr_id_after IS NULL)) AND  ( (msg_ncpdp_vendor_name == msg_ncpdp_vendor_name_after AND msg_ncpdp_vendor_name is NOT NULL AND msg_ncpdp_vendor_name_after is NOT NULL ) OR (msg_ncpdp_vendor_name IS NULL  AND  msg_ncpdp_vendor_name_after IS NULL)) AND  ( (msg_ncpdp_app_name == msg_ncpdp_app_name_after AND msg_ncpdp_app_name is NOT NULL AND msg_ncpdp_app_name_after is NOT NULL ) OR (msg_ncpdp_app_name IS NULL  AND  msg_ncpdp_app_name_after IS NULL)) AND  ( (msg_ncpdp_app_version == msg_ncpdp_app_version_after AND msg_ncpdp_app_version is NOT NULL AND msg_ncpdp_app_version_after is NOT NULL ) OR (msg_ncpdp_app_version IS NULL  AND  msg_ncpdp_app_version_after IS NULL)) AND  ( (msg_drug_cov_cds == msg_drug_cov_cds_after AND msg_drug_cov_cds is NOT NULL AND msg_drug_cov_cds_after is NOT NULL ) OR (msg_drug_cov_cds IS NULL  AND  msg_drug_cov_cds_after IS NULL)) AND  ( (pbr_dig_sig_value == pbr_dig_sig_value_after AND pbr_dig_sig_value is NOT NULL AND pbr_dig_sig_value_after is NOT NULL ) OR (pbr_dig_sig_value IS NULL  AND  pbr_dig_sig_value_after IS NULL)) AND  ( (pbr_dig_digest_value == pbr_dig_digest_value_after AND pbr_dig_digest_value is NOT NULL AND pbr_dig_digest_value_after is NOT NULL ) OR (pbr_dig_digest_value IS NULL  AND  pbr_dig_digest_value_after IS NULL)) AND  ( (pbr_dig_x509data == pbr_dig_x509data_after AND pbr_dig_x509data is NOT NULL AND pbr_dig_x509data_after is NOT NULL ) OR (pbr_dig_x509data IS NULL  AND  pbr_dig_x509data_after IS NULL)) AND  ( (wag_dig_sig == wag_dig_sig_after AND wag_dig_sig is NOT NULL AND wag_dig_sig_after is NOT NULL ) OR (wag_dig_sig IS NULL  AND  wag_dig_sig_after IS NULL)) AND  ( (wag_dig_x509data == wag_dig_x509data_after AND wag_dig_x509data is NOT NULL AND wag_dig_x509data_after is NOT NULL ) OR (wag_dig_x509data IS NULL  AND  wag_dig_x509data_after IS NULL)) AND  ( (erx_exc_resolved_ind == erx_exc_resolved_ind_after AND erx_exc_resolved_ind is NOT NULL AND erx_exc_resolved_ind_after is NOT NULL ) OR (erx_exc_resolved_ind IS NULL  AND  erx_exc_resolved_ind_after IS NULL)) AND  ( (facility_id_1 == facility_id_1_after AND facility_id_1 is NOT NULL AND facility_id_1_after is NOT NULL ) OR (facility_id_1 IS NULL  AND  facility_id_1_after IS NULL)) AND  ( (facility_id_qual_1 == facility_id_qual_1_after AND facility_id_qual_1 is NOT NULL AND facility_id_qual_1_after is NOT NULL ) OR (facility_id_qual_1 IS NULL  AND  facility_id_qual_1_after IS NULL)) AND  ( (facility_id_2 == facility_id_2_after AND facility_id_2 is NOT NULL AND facility_id_2_after is NOT NULL ) OR (facility_id_2 IS NULL  AND  facility_id_2_after IS NULL)) AND  ( (facility_id_qual_2 == facility_id_qual_2_after AND facility_id_qual_2 is NOT NULL AND facility_id_qual_2_after is NOT NULL ) OR (facility_id_qual_2 IS NULL  AND  facility_id_qual_2_after IS NULL)) AND  ( (facility_id_3 == facility_id_3_after AND facility_id_3 is NOT NULL AND facility_id_3_after is NOT NULL ) OR (facility_id_3 IS NULL  AND  facility_id_3_after IS NULL)) AND  ( (facility_id_qual_3 == facility_id_qual_3_after AND facility_id_qual_3 is NOT NULL AND facility_id_qual_3_after is NOT NULL ) OR (facility_id_qual_3 IS NULL  AND  facility_id_qual_3_after IS NULL)) AND  ( (erx_phrm_ncpdp_id ==erx_phrm_ncpdp_id_after  AND erx_phrm_ncpdp_id is NOT NULL AND erx_phrm_ncpdp_id_after is NOT NULL ) OR (erx_phrm_ncpdp_id IS NULL  AND erx_phrm_ncpdp_id_after IS NULL)) AND  ( (erx_pbr_npi ==erx_pbr_npi_after  AND erx_pbr_npi is NOT NULL AND erx_pbr_npi_after is NOT NULL ) OR (erx_pbr_npi IS NULL  AND erx_pbr_npi_after IS NULL)) AND  ( (erx_pbr_ord_nbr ==erx_pbr_ord_nbr_after  AND erx_pbr_ord_nbr is NOT NULL AND erx_pbr_ord_nbr_after is NOT NULL ) OR (erx_pbr_ord_nbr IS NULL  AND erx_pbr_ord_nbr_after IS NULL)) AND  ( (erx_pbr_phone_nbr ==erx_pbr_phone_nbr_after  AND erx_pbr_phone_nbr is NOT NULL AND erx_pbr_phone_nbr_after is NOT NULL ) OR (erx_pbr_phone_nbr IS NULL  AND erx_pbr_phone_nbr_after IS NULL)) AND  ( (erx_pat_brth_dt ==erx_pat_brth_dt_after  AND erx_pat_brth_dt is NOT NULL AND erx_pat_brth_dt_after is NOT NULL ) OR (erx_pat_brth_dt IS NULL  AND erx_pat_brth_dt_after IS NULL)) AND  ( (erx_drug_desc ==erx_drug_desc_after  AND erx_drug_desc is NOT NULL AND erx_drug_desc_after is NOT NULL ) OR (erx_drug_desc IS NULL  AND erx_drug_desc_after IS NULL)) AND  ( (erx_ndc ==erx_ndc_after  AND erx_ndc is NOT NULL AND erx_ndc_after is NOT NULL ) OR (erx_ndc IS NULL  AND erx_ndc_after IS NULL)) AND  ( (erx_rx_sig ==erx_rx_sig_after  AND erx_rx_sig is NOT NULL AND erx_rx_sig_after is NOT NULL ) OR (erx_rx_sig IS NULL  AND erx_rx_sig_after IS NULL)) AND  ( (erx_rx_written_dttm ==erx_rx_written_dttm_after  AND erx_rx_written_dttm is NOT NULL AND erx_rx_written_dttm_after is NOT NULL ) OR (erx_rx_written_dttm IS NULL  AND erx_rx_written_dttm_after IS NULL)) AND  ( (erx_rx_note ==erx_rx_note_after  AND erx_rx_note is NOT NULL AND erx_rx_note_after is NOT NULL ) OR (erx_rx_note IS NULL  AND erx_rx_note_after IS NULL)) AND  ( (cancel_reqst_deny_reason_cd ==cancel_reqst_deny_reason_cd_after  AND cancel_reqst_deny_reason_cd is NOT NULL AND cancel_reqst_deny_reason_cd_after is NOT NULL ) OR (cancel_reqst_deny_reason_cd IS NULL  AND cancel_reqst_deny_reason_cd_after IS NULL)) AND  ( (cancel_reqst_deny_reason_txt ==cancel_reqst_deny_reason_txt_after  AND cancel_reqst_deny_reason_txt is NOT NULL AND cancel_reqst_deny_reason_txt_after is NOT NULL ) OR (cancel_reqst_deny_reason_txt IS NULL  AND cancel_reqst_deny_reason_txt_after IS NULL)) AND  ( (erx_overwrite_cmnt_ind ==erx_overwrite_cmnt_ind_after  AND erx_overwrite_cmnt_ind is NOT NULL AND erx_overwrite_cmnt_ind_after is NOT NULL ) OR (erx_overwrite_cmnt_ind IS NULL  AND erx_overwrite_cmnt_ind_after IS NULL)) AND  ( (erx_relate_to_msg_id ==erx_relate_to_msg_id_after  AND erx_relate_to_msg_id is NOT NULL AND erx_relate_to_msg_id_after is NOT NULL ) OR (erx_relate_to_msg_id IS NULL  AND erx_relate_to_msg_id_after IS NULL)) AND  ( (erx_relate_to_msg_sent_dttm ==erx_relate_to_msg_sent_dttm_after  AND erx_relate_to_msg_sent_dttm is NOT NULL AND erx_relate_to_msg_sent_dttm_after is NOT NULL ) OR (erx_relate_to_msg_sent_dttm IS NULL  AND erx_relate_to_msg_sent_dttm_after IS NULL)) AND  ( (erx_prev_dspn_ind ==erx_prev_dspn_ind_after  AND erx_prev_dspn_ind is NOT NULL AND erx_prev_dspn_ind_after is NOT NULL ) OR (erx_prev_dspn_ind IS NULL  AND erx_prev_dspn_ind_after IS NULL)) AND  ( (cancel_reqst_response_type_cd ==cancel_reqst_response_type_cd_after  AND cancel_reqst_response_type_cd is NOT NULL AND cancel_reqst_response_type_cd_after is NOT NULL ) OR (cancel_reqst_response_type_cd IS NULL  AND cancel_reqst_response_type_cd_after IS NULL)) AND  ( (msg_erx_opa_id_1 ==msg_erx_opa_id_1_after  AND msg_erx_opa_id_1 is NOT NULL AND msg_erx_opa_id_1_after is NOT NULL ) OR (msg_erx_opa_id_1 IS NULL  AND msg_erx_opa_id_1_after IS NULL)) )"


#pSrcCleanseXfr

#pTgtUpdBfrXfr

#pTgtUpdAftXfr

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, icp_erx_msg_id, rx_nbr, store_nbr, epbr_erx_msg_id, erx_msg_type_sent, CONCAT(erx_msg_sent_dttm,'.000000') AS erx_msg_sent_dttm, erx_msg_type_rcvd, CONCAT(erx_msg_rcvd_dttm,'.000000') AS erx_msg_rcvd_dttm, create_user_id, CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id,  CONCAT(update_dttm,'.000000') AS update_dttm, pbr_clinic_id, erx_xml_image_id, drug_schedule, erx_pat_full_name, erx_pat_address, erx_pbr_full_name, erx_pbr_address, digital_sig_ind, erx_del_cntrl_drug_nme, erx_del_cntrl_drug_ndc, erx_del_cntrl_drug_gpi, erx_del_cntrl_pbr_id, msg_ncpdp_vendor_name, msg_ncpdp_app_name, msg_ncpdp_app_version, msg_drug_cov_cds, pbr_dig_sig_value, pbr_dig_digest_value, pbr_dig_x509data, wag_dig_sig, wag_dig_x509data, erx_exc_resolved_ind, store_nbr AS relocate_fm_str_nbr, facility_id_1, facility_id_qual_1, facility_id_2, facility_id_qual_2, facility_id_3, facility_id_qual_3, erx_phrm_ncpdp_id, erx_pbr_npi, erx_pbr_ord_nbr, erx_pbr_phone_nbr, erx_pat_brth_dt, erx_drug_desc, erx_ndc, erx_rx_sig, CONCAT(erx_rx_written_dttm,'.000000') AS erx_rx_written_dttm, erx_rx_note, cancel_reqst_deny_reason_cd, cancel_reqst_deny_reason_txt, erx_overwrite_cmnt_ind, erx_relate_to_msg_id, CONCAT(erx_relate_to_msg_sent_dttm,'.000000') AS erx_relate_to_msg_sent_dttm, erx_prev_dspn_ind, cancel_reqst_response_type_cd,msg_erx_opa_id_1, tracking_id,partition_column" 




# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}".format(ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

# BATCH_ID_CHK =  BATCH_ID 
# PROJ_ID_CHK =  PROJ_ID 

# cutoff_records_filter = cutoff_records_output.withColumn("EDW_BATCH_ID",concat(lit("'"),col("EDW_BATCH_ID"),lit("'")))\
#                                              .withColumn("PROJ_NAME",concat(lit("'"),col("PROJ_NAME"),lit("'")))

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == "WALGREENS"))
#display(cutoff_records_filter)

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))

rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_erx_msg_mapping where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_erx_msg_mapping where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual
nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_erx_msg_mapping where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  
  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])
  
  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  
  #Remove duplicates
dedup_group = nr_input_file_final.distinct()
dedup_group.createOrReplaceTempView("dedup_group")
ded = spark.sql("select * from dedup_group")
#display(ded)

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim(icp_erx_msg_id))==0) then  icp_erx_msg_id else trim(icp_erx_msg_id) end) as icp_erx_msg_id , 
(case when (LENGTH(trim(icp_erx_msg_id_after))==0) then  icp_erx_msg_id_after else trim(icp_erx_msg_id_after) end) as icp_erx_msg_id_after , 
(case when (LENGTH(trim(store_nbr))==0) then  store_nbr else trim(store_nbr) end) as store_nbr , 
(case when (LENGTH(trim(store_nbr_after))==0) then  store_nbr_after else trim(store_nbr_after) end) as store_nbr_after , 
(case when (LENGTH(trim(rx_nbr))==0) then  rx_nbr else trim(rx_nbr) end) as rx_nbr , 
(case when (LENGTH(trim(rx_nbr_after))==0) then  rx_nbr_after else trim(rx_nbr_after) end) as rx_nbr_after , 
(case when (LENGTH(trim(epbr_erx_msg_id))==0) then  epbr_erx_msg_id else trim(epbr_erx_msg_id) end) as epbr_erx_msg_id , 
(case when (LENGTH(trim(epbr_erx_msg_id_after))==0) then  epbr_erx_msg_id_after else trim(epbr_erx_msg_id_after) end) as epbr_erx_msg_id_after , 
(case when (LENGTH(trim(erx_msg_type_sent))==0) then  erx_msg_type_sent else trim(erx_msg_type_sent) end) as erx_msg_type_sent , 
(case when (LENGTH(trim(erx_msg_type_sent_after))==0) then  erx_msg_type_sent_after else trim(erx_msg_type_sent_after) end) as erx_msg_type_sent_after , 
CONCAT(CONCAT(SUBSTRING(erx_msg_sent_dttm,0,10),' '),SUBSTRING(erx_msg_sent_dttm,11,19) ) as erx_msg_sent_dttm , 
CONCAT(CONCAT(SUBSTRING(erx_msg_sent_dttm_after,0,10),' '),SUBSTRING(erx_msg_sent_dttm_after,11,19) ) as erx_msg_sent_dttm_after , 
(case when (LENGTH(trim(erx_msg_type_rcvd))==0) then  erx_msg_type_rcvd else trim(erx_msg_type_rcvd) end) as erx_msg_type_rcvd , 
(case when (LENGTH(trim(erx_msg_type_rcvd_after))==0) then  erx_msg_type_rcvd_after else trim(erx_msg_type_rcvd_after) end) as erx_msg_type_rcvd_after , 
CONCAT(CONCAT(SUBSTRING(erx_msg_rcvd_dttm,0,10),' '),SUBSTRING(erx_msg_rcvd_dttm,11,19)) as erx_msg_rcvd_dttm , 
CONCAT(CONCAT(SUBSTRING(erx_msg_rcvd_dttm_after,0,10),' '),SUBSTRING(erx_msg_rcvd_dttm_after,11,19)) as erx_msg_rcvd_dttm_after , 
(case when (LENGTH(trim(create_user_id))==0) then  create_user_id else trim(create_user_id) end) as create_user_id , 
(case when (LENGTH(trim(create_user_id_after))==0) then  create_user_id_after else trim(create_user_id_after) end) as create_user_id_after ,
CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm,11,19)) as create_dttm , 
CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after,11,19)) as create_dttm_after , 
(case when (LENGTH(trim(update_user_id))==0) then  update_user_id else trim(update_user_id) end) as update_user_id , 
(case when (LENGTH(trim(update_user_id_after))==0) then  update_user_id_after else trim(update_user_id_after) end) as update_user_id_after , 
CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm,11,19)) as update_dttm , 
CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after,11,19)) as update_dttm_after , 
(case when (LENGTH(trim(pbr_clinic_id))==0) then  pbr_clinic_id else trim(pbr_clinic_id) end) as pbr_clinic_id , 
(case when (LENGTH(trim(pbr_clinic_id_after))==0) then  pbr_clinic_id_after else trim(pbr_clinic_id_after) end) as pbr_clinic_id_after , 
(case when (LENGTH(trim(erx_xml_image_id))==0) then  erx_xml_image_id else trim(erx_xml_image_id) end) as erx_xml_image_id , 
(case when (LENGTH(trim(erx_xml_image_id_after))==0) then  erx_xml_image_id_after else trim(erx_xml_image_id_after) end) as erx_xml_image_id_after , 
(case when (LENGTH(trim(drug_schedule))==0) then  drug_schedule else trim(drug_schedule) end) as drug_schedule , 
(case when (LENGTH(trim(drug_schedule_after))==0) then  drug_schedule_after else trim(drug_schedule_after) end) as drug_schedule_after , 
(case when (LENGTH(trim(erx_pat_full_name))==0) then  erx_pat_full_name else trim(erx_pat_full_name) end) as erx_pat_full_name , 
(case when (LENGTH(trim(erx_pat_full_name_after))==0) then  erx_pat_full_name_after else trim(erx_pat_full_name_after) end) as erx_pat_full_name_after , 
(case when (LENGTH(trim(erx_pat_address))==0) then  erx_pat_address else trim(erx_pat_address) end) as erx_pat_address , 
(case when (LENGTH(trim(erx_pat_address_after))==0) then  erx_pat_address_after else trim(erx_pat_address_after) end) as erx_pat_address_after , 
(case when (LENGTH(trim(erx_pbr_full_name))==0) then  erx_pbr_full_name else trim(erx_pbr_full_name) end) as erx_pbr_full_name , 
(case when (LENGTH(trim(erx_pbr_full_name_after))==0) then  erx_pbr_full_name_after else trim(erx_pbr_full_name_after) end) as erx_pbr_full_name_after , 
(case when (LENGTH(trim(erx_pbr_address))==0) then  erx_pbr_address else trim(erx_pbr_address) end) as erx_pbr_address , 
(case when (LENGTH(trim(erx_pbr_address_after))==0) then  erx_pbr_address_after else trim(erx_pbr_address_after) end) as erx_pbr_address_after , 
(case when (LENGTH(trim(digital_sig_ind))==0) then  digital_sig_ind else trim(digital_sig_ind) end) as digital_sig_ind , 
(case when (LENGTH(trim(digital_sig_ind_after))==0) then  digital_sig_ind_after else trim(digital_sig_ind_after) end) as digital_sig_ind_after , 
(case when (LENGTH(trim(erx_del_cntrl_drug_nme))==0) then  erx_del_cntrl_drug_nme else trim(erx_del_cntrl_drug_nme) end) as erx_del_cntrl_drug_nme , 
(case when (LENGTH(trim(erx_del_cntrl_drug_nme_after))==0) then  erx_del_cntrl_drug_nme_after else trim(erx_del_cntrl_drug_nme_after) end) as erx_del_cntrl_drug_nme_after , 
(case when (LENGTH(trim(erx_del_cntrl_drug_ndc))==0) then  erx_del_cntrl_drug_ndc else trim(erx_del_cntrl_drug_ndc) end) as erx_del_cntrl_drug_ndc , 
(case when (LENGTH(trim(erx_del_cntrl_drug_ndc_after))==0) then  erx_del_cntrl_drug_ndc_after else trim(erx_del_cntrl_drug_ndc_after) end) as erx_del_cntrl_drug_ndc_after , 
(case when (LENGTH(trim(erx_del_cntrl_drug_gpi))==0) then  erx_del_cntrl_drug_gpi else trim(erx_del_cntrl_drug_gpi) end) as erx_del_cntrl_drug_gpi , 
(case when (LENGTH(trim(erx_del_cntrl_drug_gpi_after))==0) then  erx_del_cntrl_drug_gpi_after else trim(erx_del_cntrl_drug_gpi_after) end) as erx_del_cntrl_drug_gpi_after , 
(case when (LENGTH(trim(erx_del_cntrl_pbr_id))==0) then  erx_del_cntrl_pbr_id else trim(erx_del_cntrl_pbr_id) end) as erx_del_cntrl_pbr_id , 
(case when (LENGTH(trim(erx_del_cntrl_pbr_id_after))==0) then  erx_del_cntrl_pbr_id_after else trim(erx_del_cntrl_pbr_id_after) end) as erx_del_cntrl_pbr_id_after , 
(case when (LENGTH(trim(erx_exc_resolved_ind))==0) then  erx_exc_resolved_ind else trim(erx_exc_resolved_ind) end) as erx_exc_resolved_ind , 
(case when (LENGTH(trim(erx_exc_resolved_ind_after))==0) then  erx_exc_resolved_ind_after else trim(erx_exc_resolved_ind_after) end) as erx_exc_resolved_ind_after , 
(case when (LENGTH(trim(msg_ncpdp_vendor_name))==0) then  msg_ncpdp_vendor_name else trim(msg_ncpdp_vendor_name) end) as msg_ncpdp_vendor_name , 
(case when (LENGTH(trim(msg_ncpdp_vendor_name_after))==0) then  msg_ncpdp_vendor_name_after else trim(msg_ncpdp_vendor_name_after) end) as msg_ncpdp_vendor_name_after , 
(case when (LENGTH(trim(msg_ncpdp_app_name))==0) then  msg_ncpdp_app_name else trim(msg_ncpdp_app_name) end) as msg_ncpdp_app_name , 
(case when (LENGTH(trim(msg_ncpdp_app_name_after))==0) then  msg_ncpdp_app_name_after else trim(msg_ncpdp_app_name_after) end) as msg_ncpdp_app_name_after , 
(case when (LENGTH(trim(msg_ncpdp_app_version))==0) then  msg_ncpdp_app_version else trim(msg_ncpdp_app_version) end) as msg_ncpdp_app_version , 
(case when (LENGTH(trim(msg_ncpdp_app_version_after))==0) then  msg_ncpdp_app_version_after else trim(msg_ncpdp_app_version_after) end) as msg_ncpdp_app_version_after , 
(case when (LENGTH(trim(msg_drug_cov_cds))==0) then  msg_drug_cov_cds else trim(msg_drug_cov_cds) end) as msg_drug_cov_cds , 
(case when (LENGTH(trim(msg_drug_cov_cds_after))==0) then  msg_drug_cov_cds_after else trim(msg_drug_cov_cds_after) end) as msg_drug_cov_cds_after , 
(case when (LENGTH(trim(pbr_dig_sig_value))==0) then  pbr_dig_sig_value else trim(pbr_dig_sig_value) end) as pbr_dig_sig_value , 
(case when (LENGTH(trim(pbr_dig_sig_value_after))==0) then  pbr_dig_sig_value_after else trim(pbr_dig_sig_value_after) end) as pbr_dig_sig_value_after , 
(case when (LENGTH(trim(pbr_dig_digest_value))==0) then  pbr_dig_digest_value else trim(pbr_dig_digest_value) end) as pbr_dig_digest_value , 
(case when (LENGTH(trim(pbr_dig_digest_value_after))==0) then  pbr_dig_digest_value_after else trim(pbr_dig_digest_value_after) end) as pbr_dig_digest_value_after , 
(case when (LENGTH(trim(pbr_dig_x509data))==0) then  pbr_dig_x509data else trim(pbr_dig_x509data) end) as pbr_dig_x509data , 
(case when (LENGTH(trim(pbr_dig_x509data_after))==0) then  pbr_dig_x509data_after else trim(pbr_dig_x509data_after) end) as pbr_dig_x509data_after , 
(case when (LENGTH(trim(wag_dig_sig))==0) then  wag_dig_sig else trim(wag_dig_sig) end) as wag_dig_sig , 
(case when (LENGTH(trim(wag_dig_sig_after))==0) then  wag_dig_sig_after else trim(wag_dig_sig_after) end) as wag_dig_sig_after , 
(case when (LENGTH(trim(wag_dig_x509data))==0) then  wag_dig_x509data else trim(wag_dig_x509data) end) as wag_dig_x509data , 
(case when (LENGTH(trim(wag_dig_x509data_after))==0) then  wag_dig_x509data_after else trim(wag_dig_x509data_after) end) as wag_dig_x509data_after , 
(case when (LENGTH(trim(facility_id_1))==0) then  facility_id_1 else trim(facility_id_1) end) as facility_id_1 , 
(case when (LENGTH(trim(facility_id_1_after))==0) then  facility_id_1_after else trim(facility_id_1_after) end) as facility_id_1_after , 
(case when (LENGTH(trim(facility_id_qual_1))==0) then  facility_id_qual_1 else trim(facility_id_qual_1) end) as facility_id_qual_1 , 
(case when (LENGTH(trim(facility_id_qual_1_after))==0) then  facility_id_qual_1_after else trim(facility_id_qual_1_after) end) as facility_id_qual_1_after , 
(case when (LENGTH(trim(facility_id_2))==0) then  facility_id_2 else trim(facility_id_2) end) as facility_id_2 , 
(case when (LENGTH(trim(facility_id_2_after))==0) then  facility_id_2_after else trim(facility_id_2_after) end) as facility_id_2_after , 
(case when (LENGTH(trim(facility_id_qual_2))==0) then  facility_id_qual_2 else trim(facility_id_qual_2) end) as facility_id_qual_2 , 
(case when (LENGTH(trim(facility_id_qual_2_after))==0) then  facility_id_qual_2_after else trim(facility_id_qual_2_after) end) as facility_id_qual_2_after , 
(case when (LENGTH(trim(facility_id_3))==0) then  facility_id_3 else trim(facility_id_3) end) as facility_id_3 , 
(case when (LENGTH(trim(facility_id_3_after))==0) then  facility_id_3_after else trim(facility_id_3_after) end) as facility_id_3_after , 
(case when (LENGTH(trim(facility_id_qual_3))==0) then  facility_id_qual_3 else trim(facility_id_qual_3) end) as facility_id_qual_3 , 
(case when (LENGTH(trim(facility_id_qual_3_after))==0) then  facility_id_qual_3_after else trim(facility_id_qual_3_after) end) as facility_id_qual_3_after  , 
(case when (LENGTH(trim(erx_phrm_ncpdp_id))==0) then  erx_phrm_ncpdp_id else trim(erx_phrm_ncpdp_id) end) as erx_phrm_ncpdp_id, 
(case when (LENGTH(trim(erx_phrm_ncpdp_id_after))==0) then  erx_phrm_ncpdp_id_after else trim(erx_phrm_ncpdp_id_after) end) as erx_phrm_ncpdp_id_after, 
(case when (LENGTH(trim(erx_pbr_npi))==0) then  erx_pbr_npi else trim(erx_pbr_npi) end) as erx_pbr_npi, 
(case when (LENGTH(trim(erx_pbr_npi_after))==0) then  erx_pbr_npi_after else trim(erx_pbr_npi_after) end) as erx_pbr_npi_after, 
(case when (LENGTH(trim(erx_pbr_ord_nbr))==0) then  erx_pbr_ord_nbr else trim(erx_pbr_ord_nbr) end) as erx_pbr_ord_nbr, 
(case when (LENGTH(trim(erx_pbr_ord_nbr_after))==0) then  erx_pbr_ord_nbr_after else trim(erx_pbr_ord_nbr_after) end) as erx_pbr_ord_nbr_after, 
(case when (LENGTH(trim(erx_pbr_phone_nbr))==0) then  erx_pbr_phone_nbr else trim(erx_pbr_phone_nbr) end) as erx_pbr_phone_nbr, 
(case when (LENGTH(trim(erx_pbr_phone_nbr_after))==0) then  erx_pbr_phone_nbr_after else trim(erx_pbr_phone_nbr_after) end) as erx_pbr_phone_nbr_after, 
SUBSTRING(TRIM(erx_pat_brth_dt),0,10) as erx_pat_brth_dt, SUBSTRING(TRIM(erx_pat_brth_dt_after),0,10) as erx_pat_brth_dt_after, 
(case when (LENGTH(trim(erx_drug_desc))==0) then  erx_drug_desc else trim(erx_drug_desc) end) as erx_drug_desc, 
(case when (LENGTH(trim(erx_drug_desc_after))==0) then  erx_drug_desc_after else trim(erx_drug_desc_after) end) as erx_drug_desc_after, 
(case when (LENGTH(trim(erx_ndc))==0) then  erx_ndc else trim(erx_ndc) end) as erx_ndc, 
(case when (LENGTH(trim(erx_ndc_after))==0) then  erx_ndc_after else trim(erx_ndc_after) end) as erx_ndc_after, 
(case when (LENGTH(trim(erx_rx_sig))==0) then  erx_rx_sig else trim(erx_rx_sig) end) as erx_rx_sig, 
(case when (LENGTH(trim(erx_rx_sig_after))==0) then  erx_rx_sig_after else trim(erx_rx_sig_after) end) as erx_rx_sig_after, CONCAT(CONCAT(SUBSTRING(TRIM(erx_rx_written_dttm),0,10),' '),SUBSTRING(TRIM(erx_rx_written_dttm),11,19)) as erx_rx_written_dttm, 
CONCAT(CONCAT(SUBSTRING(TRIM(erx_rx_written_dttm_after),0,10),' '),SUBSTRING(TRIM(erx_rx_written_dttm_after),11,19)) as erx_rx_written_dttm_after, 
(case when (LENGTH(trim(erx_rx_note))==0) then  erx_rx_note else trim(erx_rx_note) end) as erx_rx_note, 
(case when (LENGTH(trim(erx_rx_note_after))==0) then  erx_rx_note_after else trim(erx_rx_note_after) end) as erx_rx_note_after, 
(case when (LENGTH(trim(cancel_reqst_deny_reason_cd))==0) then  cancel_reqst_deny_reason_cd else trim(cancel_reqst_deny_reason_cd) end) as cancel_reqst_deny_reason_cd, 
(case when (LENGTH(trim(cancel_reqst_deny_reason_cd_after))==0) then  cancel_reqst_deny_reason_cd_after else trim(cancel_reqst_deny_reason_cd_after) end) as cancel_reqst_deny_reason_cd_after, 
(case when (LENGTH(trim(cancel_reqst_deny_reason_txt))==0) then  cancel_reqst_deny_reason_txt else trim(cancel_reqst_deny_reason_txt) end) as cancel_reqst_deny_reason_txt, 
(case when (LENGTH(trim(cancel_reqst_deny_reason_txt_after))==0) then  cancel_reqst_deny_reason_txt_after else trim(cancel_reqst_deny_reason_txt_after) end) as cancel_reqst_deny_reason_txt_after, 
(case when (LENGTH(trim(erx_overwrite_cmnt_ind))==0) then  erx_overwrite_cmnt_ind else trim(erx_overwrite_cmnt_ind) end) as erx_overwrite_cmnt_ind, 
(case when (LENGTH(trim(erx_overwrite_cmnt_ind_after))==0) then  erx_overwrite_cmnt_ind_after else trim(erx_overwrite_cmnt_ind_after) end) as erx_overwrite_cmnt_ind_after, 
(case when (LENGTH(trim(erx_relate_to_msg_id))==0) then  erx_relate_to_msg_id else trim(erx_relate_to_msg_id) end) as erx_relate_to_msg_id, 
(case when (LENGTH(trim(erx_relate_to_msg_id_after))==0) then  erx_relate_to_msg_id_after else trim(erx_relate_to_msg_id_after) end) as erx_relate_to_msg_id_after, 
CONCAT(CONCAT(SUBSTRING(TRIM(erx_relate_to_msg_sent_dttm),0,10),' '),SUBSTRING(TRIM(erx_relate_to_msg_sent_dttm),11,19)) as erx_relate_to_msg_sent_dttm, 
CONCAT(CONCAT(SUBSTRING(TRIM(erx_relate_to_msg_sent_dttm_after),0,10),' '),SUBSTRING(TRIM(erx_relate_to_msg_sent_dttm_after),11,19)) as erx_relate_to_msg_sent_dttm_after, 
(case when (LENGTH(trim(erx_prev_dspn_ind))==0) then  erx_prev_dspn_ind else trim(erx_prev_dspn_ind) end) as erx_prev_dspn_ind, 
(case when (LENGTH(trim(erx_prev_dspn_ind_after))==0) then  erx_prev_dspn_ind_after else trim(erx_prev_dspn_ind_after) end) as erx_prev_dspn_ind_after, 
(case when (LENGTH(trim(cancel_reqst_response_type_cd))==0) then  cancel_reqst_response_type_cd else trim(cancel_reqst_response_type_cd) end) as cancel_reqst_response_type_cd, 
(case when (LENGTH(trim(cancel_reqst_response_type_cd_after))==0) then  cancel_reqst_response_type_cd_after else trim(cancel_reqst_response_type_cd_after) end) as cancel_reqst_response_type_cd_after,
(case when (LENGTH(trim(msg_erx_opa_id_1))==0) then  msg_erx_opa_id_1 else trim(msg_erx_opa_id_1) end) as msg_erx_opa_id_1, 
(case when (LENGTH(trim(msg_erx_opa_id_1_after))==0) then  msg_erx_opa_id_1_after else trim(msg_erx_opa_id_1_after) end) as msg_erx_opa_id_1_after  from dedup_group"""


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)
nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

#display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdBfrXfr="""Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id, icp_erx_msg_id AS icp_erx_msg_id , store_nbr AS store_nbr , rx_nbr AS rx_nbr , epbr_erx_msg_id AS epbr_erx_msg_id , erx_msg_type_sent AS erx_msg_type_sent , erx_msg_sent_dttm AS erx_msg_sent_dttm , erx_msg_type_rcvd AS erx_msg_type_rcvd , erx_msg_rcvd_dttm AS erx_msg_rcvd_dttm , create_user_id AS create_user_id , create_dttm AS create_dttm , update_user_id AS update_user_id , update_dttm AS update_dttm , pbr_clinic_id AS pbr_clinic_id , erx_xml_image_id AS erx_xml_image_id , drug_schedule AS drug_schedule , erx_pat_full_name AS erx_pat_full_name , erx_pat_address AS erx_pat_address , erx_pbr_full_name AS erx_pbr_full_name , erx_pbr_address AS erx_pbr_address , digital_sig_ind AS digital_sig_ind , erx_del_cntrl_drug_nme AS erx_del_cntrl_drug_nme , erx_del_cntrl_drug_ndc AS erx_del_cntrl_drug_ndc , erx_del_cntrl_drug_gpi AS erx_del_cntrl_drug_gpi , erx_del_cntrl_pbr_id AS erx_del_cntrl_pbr_id , erx_exc_resolved_ind AS erx_exc_resolved_ind , msg_ncpdp_vendor_name AS msg_ncpdp_vendor_name , msg_ncpdp_app_name AS msg_ncpdp_app_name , msg_ncpdp_app_version AS msg_ncpdp_app_version , msg_drug_cov_cds AS msg_drug_cov_cds , pbr_dig_sig_value AS pbr_dig_sig_value , pbr_dig_digest_value AS pbr_dig_digest_value , pbr_dig_x509data AS pbr_dig_x509data , wag_dig_sig AS wag_dig_sig , wag_dig_x509data AS wag_dig_x509data , facility_id_1 AS facility_id_1 , facility_id_qual_1 AS facility_id_qual_1 , facility_id_2 AS facility_id_2 , facility_id_qual_2 AS facility_id_qual_2 , facility_id_3 AS facility_id_3 , facility_id_qual_3 AS facility_id_qual_3  , erx_phrm_ncpdp_id AS erx_phrm_ncpdp_id, erx_pbr_npi AS erx_pbr_npi, erx_pbr_ord_nbr AS erx_pbr_ord_nbr, erx_pbr_phone_nbr AS erx_pbr_phone_nbr, erx_pat_brth_dt AS erx_pat_brth_dt, erx_drug_desc AS erx_drug_desc, erx_ndc AS erx_ndc, erx_rx_sig AS erx_rx_sig, erx_rx_written_dttm AS erx_rx_written_dttm, erx_rx_note AS erx_rx_note, cancel_reqst_deny_reason_cd AS cancel_reqst_deny_reason_cd, cancel_reqst_deny_reason_txt AS cancel_reqst_deny_reason_txt, erx_overwrite_cmnt_ind AS erx_overwrite_cmnt_ind, erx_relate_to_msg_id AS erx_relate_to_msg_id, erx_relate_to_msg_sent_dttm AS erx_relate_to_msg_sent_dttm, erx_prev_dspn_ind AS erx_prev_dspn_ind, cancel_reqst_response_type_cd AS cancel_reqst_response_type_cd,msg_erx_opa_id_1 AS msg_erx_opa_id_1, '000000' AS tracking_id ,'' AS partition_column,'gg_tbf0_erx_msg_mapping' as table_name from gg_tbf0_update """ 



pTgtUpdAftXfr="""Select 
cdc_txn_commit_dttm_after  as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id , icp_erx_msg_id_after AS icp_erx_msg_id , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , epbr_erx_msg_id_after AS epbr_erx_msg_id , erx_msg_type_sent_after AS erx_msg_type_sent , erx_msg_sent_dttm_after AS erx_msg_sent_dttm , erx_msg_type_rcvd_after AS erx_msg_type_rcvd , erx_msg_rcvd_dttm_after AS erx_msg_rcvd_dttm , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , pbr_clinic_id_after AS pbr_clinic_id , erx_xml_image_id_after AS erx_xml_image_id , drug_schedule_after AS drug_schedule , erx_pat_full_name_after AS erx_pat_full_name , erx_pat_address_after AS erx_pat_address , erx_pbr_full_name_after AS erx_pbr_full_name , erx_pbr_address_after AS erx_pbr_address , digital_sig_ind_after AS digital_sig_ind , erx_del_cntrl_drug_nme_after AS erx_del_cntrl_drug_nme , erx_del_cntrl_drug_ndc_after AS erx_del_cntrl_drug_ndc , erx_del_cntrl_drug_gpi_after AS erx_del_cntrl_drug_gpi , erx_del_cntrl_pbr_id_after AS erx_del_cntrl_pbr_id , erx_exc_resolved_ind_after AS erx_exc_resolved_ind , msg_ncpdp_vendor_name_after AS msg_ncpdp_vendor_name , msg_ncpdp_app_name_after AS msg_ncpdp_app_name , msg_ncpdp_app_version_after AS msg_ncpdp_app_version , msg_drug_cov_cds_after AS msg_drug_cov_cds , pbr_dig_sig_value_after AS pbr_dig_sig_value , pbr_dig_digest_value_after AS pbr_dig_digest_value , pbr_dig_x509data_after AS pbr_dig_x509data , wag_dig_sig_after AS wag_dig_sig , wag_dig_x509data_after AS wag_dig_x509data , facility_id_1_after AS facility_id_1 , facility_id_qual_1_after AS facility_id_qual_1 , facility_id_2_after AS facility_id_2 , facility_id_qual_2_after AS facility_id_qual_2 , facility_id_3_after AS facility_id_3 , facility_id_qual_3_after AS facility_id_qual_3 , erx_phrm_ncpdp_id_after AS erx_phrm_ncpdp_id, erx_pbr_npi_after AS erx_pbr_npi, erx_pbr_ord_nbr_after AS erx_pbr_ord_nbr, erx_pbr_phone_nbr_after AS erx_pbr_phone_nbr, erx_pat_brth_dt_after AS erx_pat_brth_dt, erx_drug_desc_after AS erx_drug_desc, erx_ndc_after AS erx_ndc, erx_rx_sig_after AS erx_rx_sig, erx_rx_written_dttm_after AS erx_rx_written_dttm, erx_rx_note_after AS erx_rx_note, cancel_reqst_deny_reason_cd_after AS cancel_reqst_deny_reason_cd, cancel_reqst_deny_reason_txt_after AS cancel_reqst_deny_reason_txt, erx_overwrite_cmnt_ind_after AS erx_overwrite_cmnt_ind, erx_relate_to_msg_id_after AS erx_relate_to_msg_id, erx_relate_to_msg_sent_dttm_after AS erx_relate_to_msg_sent_dttm, erx_prev_dspn_ind_after AS erx_prev_dspn_ind, cancel_reqst_response_type_cd_after AS cancel_reqst_response_type_cd , msg_erx_opa_id_1_after AS msg_erx_opa_id_1, '000000' AS tracking_id ,'' AS partition_column,'gg_tbf0_erx_msg_mapping' as table_name from gg_tbf0_update"""




pTgtInsBfrAftXfr = """Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id, icp_erx_msg_id_after AS icp_erx_msg_id , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , epbr_erx_msg_id_after AS epbr_erx_msg_id , erx_msg_type_sent_after AS erx_msg_type_sent , erx_msg_sent_dttm_after AS erx_msg_sent_dttm , erx_msg_type_rcvd_after AS erx_msg_type_rcvd , erx_msg_rcvd_dttm_after AS erx_msg_rcvd_dttm , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , pbr_clinic_id_after AS pbr_clinic_id , erx_xml_image_id_after AS erx_xml_image_id , drug_schedule_after AS drug_schedule , erx_pat_full_name_after AS erx_pat_full_name , erx_pat_address_after AS erx_pat_address , erx_pbr_full_name_after AS erx_pbr_full_name , erx_pbr_address_after AS erx_pbr_address , digital_sig_ind_after AS digital_sig_ind , erx_del_cntrl_drug_nme_after AS erx_del_cntrl_drug_nme , erx_del_cntrl_drug_ndc_after AS erx_del_cntrl_drug_ndc , erx_del_cntrl_drug_gpi_after AS erx_del_cntrl_drug_gpi , erx_del_cntrl_pbr_id_after AS erx_del_cntrl_pbr_id , erx_exc_resolved_ind_after AS erx_exc_resolved_ind , msg_ncpdp_vendor_name_after AS msg_ncpdp_vendor_name , msg_ncpdp_app_name_after AS msg_ncpdp_app_name , msg_ncpdp_app_version_after AS msg_ncpdp_app_version , msg_drug_cov_cds_after AS msg_drug_cov_cds , pbr_dig_sig_value_after AS pbr_dig_sig_value , pbr_dig_digest_value_after AS pbr_dig_digest_value , pbr_dig_x509data_after AS pbr_dig_x509data , wag_dig_sig_after AS wag_dig_sig , wag_dig_x509data_after AS wag_dig_x509data , facility_id_1_after AS facility_id_1 , facility_id_qual_1_after AS facility_id_qual_1 , facility_id_2_after AS facility_id_2 , facility_id_qual_2_after AS facility_id_qual_2 , facility_id_3_after AS facility_id_3 , facility_id_qual_3_after AS facility_id_qual_3 , erx_phrm_ncpdp_id_after AS erx_phrm_ncpdp_id, erx_pbr_npi_after AS erx_pbr_npi, erx_pbr_ord_nbr_after AS erx_pbr_ord_nbr, erx_pbr_phone_nbr_after AS erx_pbr_phone_nbr, erx_pat_brth_dt_after AS erx_pat_brth_dt, erx_drug_desc_after AS erx_drug_desc, erx_ndc_after AS erx_ndc, erx_rx_sig_after AS erx_rx_sig, erx_rx_written_dttm_after AS erx_rx_written_dttm, erx_rx_note_after AS erx_rx_note, cancel_reqst_deny_reason_cd_after AS cancel_reqst_deny_reason_cd, cancel_reqst_deny_reason_txt_after AS cancel_reqst_deny_reason_txt, erx_overwrite_cmnt_ind_after AS erx_overwrite_cmnt_ind, erx_relate_to_msg_id_after AS erx_relate_to_msg_id, erx_relate_to_msg_sent_dttm_after AS erx_relate_to_msg_sent_dttm, erx_prev_dspn_ind_after AS erx_prev_dspn_ind, cancel_reqst_response_type_cd_after AS cancel_reqst_response_type_cd , msg_erx_opa_id_1_after AS msg_erx_opa_id_1, '000000' AS tracking_id ,'' AS partition_column,'gg_tbf0_erx_msg_mapping' as table_name from nr_insert_check """


# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

#display(gg_tbf0_update_afr)
#display(gg_tbf0_update_bfr)
#display(gg_tbf0_insert_afr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 


gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)
#display(etl_tbf0_file)
etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)
#display(etl_tbf0_reformat)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
#display(etl_tbf0_reformat_cdc_check_notnull)
#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm",trim("cdc_txn_commit_dttm"))\
.withColumn("erx_msg_sent_dttm",trim("erx_msg_sent_dttm"))\
.withColumn("erx_msg_rcvd_dttm",trim("erx_msg_rcvd_dttm"))\
.withColumn("create_dttm",trim("create_dttm"))\
.withColumn("update_dttm",trim("update_dttm"))\
.withColumn("erx_rx_written_dttm",trim("erx_rx_written_dttm"))\
.withColumn("erx_pat_brth_dt",trim("erx_pat_brth_dt"))\
.withColumn("erx_relate_to_msg_sent_dttm",trim("erx_relate_to_msg_sent_dttm"))
#etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm",concat(split(col("cdc_txn_commit_dttm"),":")[0],split(col("cdc_txn_commit_dttm"),":")[1],lit(":"),split(col("cdc_txn_commit_dttm"),":")[2],lit(":"),split(col("cdc_txn_commit_dttm"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("erx_msg_sent_dttm",concat(split(col("erx_msg_sent_dttm"),":")[0],split(col("erx_msg_sent_dttm"),":")[1],lit(":"),split(col("erx_msg_sent_dttm"),":")[2],lit(":"),split(col("erx_msg_sent_dttm"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("erx_msg_rcvd_dttm",concat(split(col("erx_msg_rcvd_dttm"),":")[0],split(col("erx_msg_rcvd_dttm"),":")[1],lit(":"),split(col("erx_msg_rcvd_dttm"),":")[2],lit(":"),split(col("erx_msg_rcvd_dttm"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("create_dttm",concat(split(col("create_dttm"),":")[0],split(col("create_dttm"),":")[1],lit(":"),split(col("create_dttm"),":")[2],lit(":"),split(col("create_dttm"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("update_dttm",concat(split(col("update_dttm"),":")[0],split(col("update_dttm"),":")[1],lit(":"),split(col("update_dttm"),":")[2],lit(":"),split(col("update_dttm"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("erx_rx_written_dttm",concat(split(col("erx_rx_written_dttm"),":")[0],split(col("erx_rx_written_dttm"),":")[1],lit(":"),split(col("erx_rx_written_dttm"),":")[2],lit(":"),split(col("erx_rx_written_dttm"),":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("erx_relate_to_msg_sent_dttm",concat(split(col("erx_relate_to_msg_sent_dttm"),":")[0],split(col("erx_relate_to_msg_sent_dttm"),":")[1],lit(":"),split(col("erx_relate_to_msg_sent_dttm"),":")[2],lit(":"),split(col("erx_relate_to_msg_sent_dttm"),":")[3]))
#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

df_final = etl_tbf0_reformat_cdc_check_notnull.drop("tracking_id","partition_column")
df_final_typecast = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
  .withColumn("erx_msg_sent_dttm", to_timestamp(df_final["erx_msg_sent_dttm"]))\
  .withColumn("erx_msg_rcvd_dttm", to_timestamp(df_final["erx_msg_rcvd_dttm"]))\
  .withColumn("create_dttm", to_timestamp(df_final["create_dttm"]))\
  .withColumn("update_dttm", to_timestamp(df_final["update_dttm"]))\
  .withColumn("erx_rx_written_dttm", to_timestamp(df_final["erx_rx_written_dttm"]))\
  .withColumn("erx_relate_to_msg_sent_dttm", to_timestamp(df_final["erx_relate_to_msg_sent_dttm"]))\
  .withColumn("erx_pat_brth_dt", to_date(df_final["erx_pat_brth_dt"]))\
  .withColumn("create_user_id",df_final["create_user_id"].cast(IntegerType()))\
  .withColumn("update_user_id",df_final["update_user_id"].cast(IntegerType()))\
  .withColumn("store_nbr",df_final["store_nbr"].cast(IntegerType()))\
  .withColumn("cdc_seq_nbr",df_final["cdc_seq_nbr"].cast(IntegerType()))\
  .withColumn("relocate_fm_str_nbr",df_final["relocate_fm_str_nbr"].cast(IntegerType()))\
  .withColumn("cdc_rba_nbr",df_final["cdc_rba_nbr"].cast(IntegerType()))\
  .withColumn("edw_batch_id",df_final["edw_batch_id"])\
  .withColumn("erx_del_cntrl_pbr_id",df_final["erx_del_cntrl_pbr_id"].cast(IntegerType()))\
  .withColumn("erx_pbr_npi",df_final["erx_pbr_npi"].cast(IntegerType()))\
  .withColumn("facility_id_qual_1", substring(col("facility_id_qual_1"),0,8))\
  .withColumn("facility_id_qual_2", substring(col("facility_id_qual_2"),0,8))\
  .withColumn("facility_id_qual_3", substring(col("facility_id_qual_3"),0,8))\
  .withColumn("cancel_reqst_deny_reason_txt", substring(col("cancel_reqst_deny_reason_txt"),0,70))\
  .withColumn("erx_msg_type_rcvd", substring(col("erx_msg_type_rcvd"),0,6))\
  .withColumn("drug_schedule", substring(col("drug_schedule"),0,5))\
  .withColumn("epbr_erx_msg_id", substring(col("epbr_erx_msg_id"),0,35))\
  .withColumn("pbr_clinic_id", substring(col("pbr_clinic_id"),0,35))\
  .withColumn("erx_del_cntrl_drug_nme", substring(col("erx_del_cntrl_drug_nme"),0,35))\
  .withColumn("msg_ncpdp_vendor_name", substring(col("msg_ncpdp_vendor_name"),0,35))\
  .withColumn("msg_ncpdp_app_name", substring(col("msg_ncpdp_app_name"),0,35))\
  .withColumn("msg_ncpdp_app_version", substring(col("msg_ncpdp_app_version"),0,35))\
  .withColumn("facility_id_1", substring(col("facility_id_1"),0,35))\
  .withColumn("facility_id_2", substring(col("facility_id_2"),0,35))\
  .withColumn("facility_id_3", substring(col("facility_id_3"),0,35))\
  .withColumn("erx_phrm_ncpdp_id", substring(col("erx_phrm_ncpdp_id"),0,35))\
  .withColumn("erx_pbr_ord_nbr", substring(col("erx_pbr_ord_nbr"),0,35))\
  .withColumn("erx_ndc", substring(col("erx_ndc"),0,35))\
  .withColumn("erx_relate_to_msg_id", substring(col("erx_relate_to_msg_id"),0,35))\
  .withColumn("icp_erx_msg_id", substring(col("icp_erx_msg_id"),0,28))\
  .withColumn("pbr_dig_sig_value", substring(col("pbr_dig_sig_value"),0,256))\
  .withColumn("pbr_dig_digest_value", substring(col("pbr_dig_digest_value"),0,256))\
  .withColumn("wag_dig_sig", substring(col("wag_dig_sig"),0,256))\
  .withColumn("erx_rx_note", substring(col("erx_rx_note"),0,210))\
  .withColumn("pbr_dig_x509data", substring(col("pbr_dig_x509data"),0,2000))\
  .withColumn("wag_dig_x509data", substring(col("wag_dig_x509data"),0,2000))\
  .withColumn("cdc_operation_type_cd", substring(col("cdc_operation_type_cd"),0,20))\
  .withColumn("cancel_reqst_deny_reason_cd", substring(col("cancel_reqst_deny_reason_cd"),0,2))\
  .withColumn("erx_xml_image_id", substring(col("erx_xml_image_id"),0,19))\
  .withColumn("erx_rx_sig", substring(col("erx_rx_sig"),0,150))\
  .withColumn("erx_del_cntrl_drug_gpi", substring(col("erx_del_cntrl_drug_gpi"),0,14))\
  .withColumn("msg_drug_cov_cds", substring(col("msg_drug_cov_cds"),0,14))\
  .withColumn("erx_del_cntrl_drug_ndc", substring(col("erx_del_cntrl_drug_ndc"),0,13))\
  .withColumn("erx_pat_full_name", substring(col("erx_pat_full_name"),0,107))\
  .withColumn("erx_pbr_full_name", substring(col("erx_pbr_full_name"),0,107))\
  .withColumn("erx_drug_desc", substring(col("erx_drug_desc"),0,105))\
  .withColumn("erx_pat_address", substring(col("erx_pat_address"),0,100))\
  .withColumn("erx_pbr_address", substring(col("erx_pbr_address"),0,100))\
  .withColumn("cdc_before_after_cd", substring(col("cdc_before_after_cd"),0,10))\
  .withColumn("cdc_txn_position_cd", substring(col("cdc_txn_position_cd"),0,10))\
  .withColumn("erx_pbr_phone_nbr", substring(col("erx_pbr_phone_nbr"),0,10))\
  .withColumn("digital_sig_ind", substring(col("digital_sig_ind"),0,1))\
  .withColumn("erx_exc_resolved_ind", substring(col("erx_exc_resolved_ind"),0,1))\
  .withColumn("erx_overwrite_cmnt_ind", substring(col("erx_overwrite_cmnt_ind"),0,1))\
  .withColumn("erx_prev_dspn_ind", substring(col("erx_prev_dspn_ind"),0,1))\
  .withColumn("cancel_reqst_response_type_cd", substring(col("cancel_reqst_response_type_cd"),0,1))

df_final_check_blank = df_final_typecast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in df_final_typecast.columns])
df_final_notNull = df_final_check_blank.filter("store_nbr is not null and rx_nbr is not null and icp_erx_msg_id is not null")
#display(df_final_notNull)

# COMMAND ----------

#drop columns to map table schema
df_final_drop_columns = df_final_notNull.drop("rx_denial_override_cd","rx_denial_override_cd_2","rx_denial_override_cd_3","pay_cd","filling_store_nbr","fill_verified_store_nbr","mult_prod_review_ind")
df_final_columns = df_final_drop_columns.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","icp_erx_msg_id","rx_nbr","store_nbr","epbr_erx_msg_id","erx_msg_type_sent","erx_msg_sent_dttm","erx_msg_type_rcvd","erx_msg_rcvd_dttm","create_user_id","create_dttm","update_user_id","update_dttm","pbr_clinic_id","erx_xml_image_id","drug_schedule","erx_pat_full_name","erx_pat_address","erx_pbr_full_name","erx_pbr_address","digital_sig_ind","erx_del_cntrl_drug_nme","erx_del_cntrl_drug_ndc","erx_del_cntrl_drug_gpi","erx_del_cntrl_pbr_id","msg_ncpdp_vendor_name","msg_ncpdp_app_name","msg_ncpdp_app_version","msg_drug_cov_cds","pbr_dig_sig_value","pbr_dig_digest_value","pbr_dig_x509data","wag_dig_sig","wag_dig_x509data","erx_exc_resolved_ind","relocate_fm_str_nbr","facility_id_1","facility_id_qual_1","facility_id_2","facility_id_qual_2","facility_id_3","facility_id_qual_3","erx_phrm_ncpdp_id","erx_pbr_npi","erx_pbr_ord_nbr","erx_pbr_phone_nbr","erx_pat_brth_dt","erx_drug_desc","erx_ndc","erx_rx_sig","erx_rx_written_dttm","erx_rx_note","cancel_reqst_deny_reason_cd","cancel_reqst_deny_reason_txt","erx_overwrite_cmnt_ind","erx_relate_to_msg_id","erx_relate_to_msg_sent_dttm","erx_prev_dspn_ind","cancel_reqst_response_type_cd")

df_final_TL_columns = df_final_drop_columns.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd","cdc_txn_position_cd","edw_batch_id","icp_erx_msg_id","rx_nbr","store_nbr","epbr_erx_msg_id","erx_msg_type_sent","erx_msg_sent_dttm","erx_msg_type_rcvd","erx_msg_rcvd_dttm","create_user_id","create_dttm","update_user_id","update_dttm","pbr_clinic_id","erx_xml_image_id","drug_schedule","erx_pat_full_name","erx_pat_address","erx_pbr_full_name","erx_pbr_address","digital_sig_ind","erx_del_cntrl_drug_nme","erx_del_cntrl_drug_ndc","erx_del_cntrl_drug_gpi","erx_del_cntrl_pbr_id","msg_ncpdp_vendor_name","msg_ncpdp_app_name","msg_ncpdp_app_version","msg_drug_cov_cds","pbr_dig_sig_value","pbr_dig_digest_value","pbr_dig_x509data","wag_dig_sig","wag_dig_x509data","erx_exc_resolved_ind","relocate_fm_str_nbr","facility_id_1","facility_id_qual_1","facility_id_2","facility_id_qual_2","facility_id_3","facility_id_qual_3","erx_phrm_ncpdp_id","erx_pbr_npi","erx_pbr_ord_nbr","erx_pbr_phone_nbr","erx_pat_brth_dt","erx_drug_desc","erx_ndc","erx_rx_sig","erx_rx_written_dttm","erx_rx_note","cancel_reqst_deny_reason_cd","cancel_reqst_deny_reason_txt","erx_overwrite_cmnt_ind","erx_relate_to_msg_id","erx_relate_to_msg_sent_dttm","erx_prev_dspn_ind","cancel_reqst_response_type_cd","msg_erx_opa_id_1")

#display(df_final_columns)

# COMMAND ----------

df_final_columns.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

df_final_TL_columns.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", "PATIENT_SERVICES.CONS_TL_ETL_TBF0_ERX_MSG_MAPPING_STG") \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

df_final_TL_columns.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", "PATIENT_SERVICES.TL_ETL_TBF0_ERX_MSG_MAPPING_STG") \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

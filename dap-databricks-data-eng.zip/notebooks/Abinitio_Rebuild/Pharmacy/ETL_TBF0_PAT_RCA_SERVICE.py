# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")
#dbutils.widgets.text("PAR_READAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

# COMMAND ----------

readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
readList=readList.split(',')
print(readList)

# COMMAND ----------

  # ReadAPI Call to fetch asset file names with current location:  

  #READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
  BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
  FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
  PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
  PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
  PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
  PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
  PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")
  '''
  Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 100, 
                   {"PAR_EDW_BATCH_ID":BATCH_ID,
                    "PAR_FEED_NAMES":FEED_NAME,
                    "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                    "PAR_READAPI_URL":READAPI_URL,
                    "PAR_SQL_SERVER":PAR_SQL_SERVER,
                    "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                    "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                    "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                    "PAR_RETURN_FILE_TYPE":"A"});
  '''

  #print(Input_File_List)
# GetUnprocessedFiles = dbutils.widgets.get("UnprocessedFiles")
# Input_File_List = GetUnprocessedFiles
# print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC 
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#dbutils.widgets.text("PAR_DB_FILE_LIST","DAPDEVDWH01.PRDRX2STAGE")
#dbutils.widgets.remove("PAR_DB_FILE_NAME")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd_before',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'pat_id',
'pat_id_after',
'rca_serv_id',
'rca_serv_id_after',
'rca_active_ind',
'rca_active_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 27:#Total Number of columns -1
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 28: #Total Number of columns 
      return True
  else:
    if val_len != 28: #Total Number of columns 
      return True




# COMMAND ----------

readList_src_1 = []
[readList_src_1.append(i) for i in readList if str(i).split("_")[8]=="1" ]
readList_src_2 = []
[readList_src_2.append(i) for i in readList if str(i).split("_")[8]=="2" ]
readList_src_3 = []
[readList_src_3.append(i) for i in readList if str(i).split("_")[8]=="3" ]
readList_src_4 = []
[readList_src_4.append(i) for i in readList if str(i).split("_")[8]=="4" ]
print(readList_src_1)
print(readList_src_2)
print(readList_src_3)
print(readList_src_4)

# COMMAND ----------

# Read input files
# in_text = spark.read.text(readList)
# in_text = in_text.rdd

# Read files based on partitions
in1_text = spark.read.text(readList_src_1)
in2_text = spark.read.text(readList_src_2)
in3_text = spark.read.text(readList_src_3)
in4_text = spark.read.text(readList_src_4)
in1_text = in1_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in2_text = in2_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in3_text = in3_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd
in4_text = in4_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

# rdb = in_text.filter(lambda x: checkbad(x[0]))

# if rdb.count()>0:
#   df_junk = spark.createDataFrame(rdb)
#   df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)
  
rdb1 = in1_text.filter(lambda x: checkbad(x[0]))
rdb2 = in2_text.filter(lambda x: checkbad(x[0]))
rdb3 = in3_text.filter(lambda x: checkbad(x[0]))
rdb4 = in4_text.filter(lambda x: checkbad(x[0]))

rdb_count = rdb1.count()+ rdb2.count()+ rdb3.count()+ rdb4.count()
rdb= rdb1+rdb2+rdb3+rdb4
if rdb_count>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)  

# COMMAND ----------

#split and add schema
col_len = 28

# rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

# print(f"Total count {rd1.count()}")

# rd_good = rd1.filter(lambda x: x[0] == col_len)
# rd_bad = rd1.filter(lambda x: x[0] != col_len)

# print(f"Good records count {rd_good.count()}") # = 28
# print(f"Bad records count {rd_bad.count()}") # != 28 Should read output as 0

rd1 = in1_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd2 = in2_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd3 = in3_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))
rd4 = in4_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd1_good = rd1.filter(lambda x: x[0] == col_len)
rd2_good = rd2.filter(lambda x: x[0] == col_len)
rd3_good = rd3.filter(lambda x: x[0] == col_len)
rd4_good = rd4.filter(lambda x: x[0] == col_len)

rd_bad_all = rd1+rd2+rd3+rd4
rd_bad = rd_bad_all.filter(lambda x: x[0] != col_len)

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

# df = spark.createDataFrame(rd_good, schema)
df1 = spark.createDataFrame(rd1_good, schema)
df2 = spark.createDataFrame(rd2_good, schema)
df3 = spark.createDataFrame(rd3_good, schema)
df4 = spark.createDataFrame(rd4_good, schema)

df_g1 = df1.withColumn("src_partition_nbr",lit("1")).withColumn("src_partition_nbr_after",lit("1"))
df_g2 = df2.withColumn("src_partition_nbr",lit("2")).withColumn("src_partition_nbr_after",lit("2"))
df_g3 = df3.withColumn("src_partition_nbr",lit("3")).withColumn("src_partition_nbr_after",lit("3"))
df_g4 = df4.withColumn("src_partition_nbr",lit("4")).withColumn("src_partition_nbr_after",lit("4"))

df = df_g1.union(df_g2).union(df_g3).union(df_g4)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
# df = (reduce(
#       lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
#     df.columns,
#     df
# ))

# COMMAND ----------

display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_pat_rca_service")

# COMMAND ----------


dfBad = spark.sql("select * from gg_tbf0_pat_rca_service where (cdc_operation_type_cd_before is null) or (cdc_operation_type_cd_before != 'SQL COMPUPDATE' and cdc_operation_type_cd_before != 'PK UPDATE' and cdc_operation_type_cd_before != 'INSERT')")

display(dfBad)

print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_pat_rca_service"))
#display(df_gg)

df_gg.createOrReplaceTempView("raw_src_gg_table")

display(df_gg)

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="((pat_id == pat_id_after AND pat_id IS NOT NULL AND pat_id_after IS NOT NULL ) AND  (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL) AND  ( cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND cdc_operation_type_cd_after IS NOT NULL) AND  (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL )AND  ( cdc_operation_type_cd == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL) AND (rca_serv_id  == rca_serv_id_after AND rca_serv_id IS NOT NULL  AND rca_serv_id_after IS NOT NULL) AND ( cdc_seq_nbr  ==  cdc_seq_nbr_after  AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL ) AND  (cdc_rba_nbr  ==  cdc_rba_nbr_after  AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL ) AND ( cdc_txn_commit_dttm  ==  cdc_txn_commit_dttm_after   AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL ) AND  ((rca_active_ind  == rca_active_ind_after AND rca_active_ind IS NOT NULL AND rca_active_ind_after IS NOT NULL ) OR ( rca_active_ind  IS NULL  AND  rca_active_ind_after  IS NULL ) ))"

#(to_int(pat_id) % 4) == (to_int(src_partition_nbr) -1) AND  -- Removed this logic from pPatIdModCheck as we are not getting values for src_partition_nbr
pPatIdModCheck="(CAST(pat_id AS LONG)%4 == CAST(src_partition_nbr AS INTEGER) -1) AND  (table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck=" (table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd,  cdc_txn_position_cd, edw_batch_id, pat_id, rca_serv_id, rca_active_ind, create_user_id, CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id, CONCAT(update_dttm,'.000000') AS update_dttm, src_partition_nbr" #src_partition_nbr, tracking_id, partition_column


# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

BATCH_ID_CHK = """'""" + BATCH_ID + """'"""
PROJ_ID_CHK = """'""" + PROJ_ID + """'"""

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_output.PROJ_NAME == PROJ_ID_CHK))
#display(cutoff_records_filter)


#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_rx)
rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_trans)
rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_src_gg_table where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_src_gg_table where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_src_gg_table where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  #display(nr_input_file_filter_rx)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual)
  nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck)
  nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual)
  nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

display(ded)


# COMMAND ----------

dedup_group.printSchema()

# COMMAND ----------

nr_spacetrim_sql = """SELECT (case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8) ) end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8) ) end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr)end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after)end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr)end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after)end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd_before )) ==0) then cdc_operation_type_cd_before else trim(cdc_operation_type_cd_before)end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after)) ==0) then cdc_operation_type_cd_after else trim(cdc_operation_type_cd_after)end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd)end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after)end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd)end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after)end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as  edw_batch_id,
""" + BATCH_ID + """ as  edw_batch_id_after,
(case when (LENGTH(trim( src_partition_nbr )) ==0) then src_partition_nbr else trim(src_partition_nbr)end) as src_partition_nbr,
(case when (LENGTH(trim( src_partition_nbr_after )) ==0) then src_partition_nbr_after else trim(src_partition_nbr_after)end) as src_partition_nbr_after,
(case when (LENGTH(trim( pat_id )) ==0) then pat_id else trim(pat_id)end) as pat_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after)end) as pat_id_after,
(case when (LENGTH(trim( rca_serv_id )) ==0) then rca_serv_id else trim(rca_serv_id)end) as rca_serv_id,
(case when (LENGTH(trim( rca_serv_id_after )) ==0) then rca_serv_id_after else trim(rca_serv_id_after)end) as rca_serv_id_after,
(case when (LENGTH(trim( rca_active_ind )) ==0) then rca_active_ind else trim(rca_active_ind)end) as rca_active_ind,
(case when (LENGTH(trim( rca_active_ind_after )) ==0) then rca_active_ind_after else trim(rca_active_ind_after)end) as rca_active_ind_after,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id)end) as create_user_id,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after)end) as create_user_id_after,
(case when (LENGTH(trim( create_dttm )) ==0) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8) )end) as create_dttm,
(case when (LENGTH(trim( create_dttm_after )) ==0) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8) )end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id)end) as update_user_id,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after)end) as update_user_id_after,
(case when (LENGTH(trim( update_dttm )) ==0) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8) )end) as update_dttm,
(case when (LENGTH(trim( update_dttm_after )) ==0) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8) )end) as update_dttm_after
from dedup_group"""



# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """ select cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,
cdc_operation_type_cd_after as cdc_operation_type_cd,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,""" + BATCH_ID + """ as edw_batch_id,src_partition_nbr_after as src_partition_nbr, pat_id_after AS pat_id , rca_serv_id_after AS rca_serv_id ,  rca_active_ind_after AS rca_active_ind ,  create_user_id_after AS create_user_id ,  create_dttm_after AS create_dttm ,  update_user_id_after AS update_user_id ,  update_dttm_after AS update_dttm , '""" + SRC_TBL_NAME + """' as table_name 
from gg_tbf0_update """

#print(pTgtUpdAftXfr) 
#Hardcoded src_partition_nbr as 1 since we not getting value for this column from intermediate tables as in teradata

# COMMAND ----------

pTgtUpdBfrXfr = """ select  cdc_txn_commit_dttm,cdc_seq_nbr,cdc_rba_nbr,cdc_operation_type_cd,cdc_before_after_cd,cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,src_partition_nbr as src_partition_nbr,pat_id AS pat_id, rca_serv_id AS rca_serv_id, rca_active_ind AS rca_active_ind,create_user_id AS create_user_id,create_dttm AS create_dttm,update_user_id AS update_user_id,update_dttm AS update_dttm,'""" + SRC_TBL_NAME + """' as table_name 
from gg_tbf0_update """

#print(pTgtUpdBfrXfr)
#Hardcoded src_partition_nbr as 1 since we not getting value for this column from intermediate tables as in teradata

# COMMAND ----------

pTgtInsBfrAftXfr = """ select  cdc_txn_commit_dttm,cdc_seq_nbr,cdc_rba_nbr,cdc_operation_type_cd,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd
,""" + BATCH_ID + """ as edw_batch_id,src_partition_nbr_after as src_partition_nbr, pat_id_after AS pat_id , rca_serv_id_after AS rca_serv_id ,  rca_active_ind_after AS rca_active_ind ,  create_user_id_after AS create_user_id ,  create_dttm_after AS create_dttm ,  update_user_id_after AS update_user_id ,  update_dttm_after AS update_dttm , '""" + SRC_TBL_NAME + """' as table_name
from nr_insert_check """

#print(pTgtInsBfrAftXfr)
#Hardcoded src_partition_nbr as 1 since we not getting value for this column from intermediate tables as in teradata

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)
#display(gg_tbf0_update_afr)
gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)
#display(gg_tbf0_update_bfr)
gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)
#display(gg_tbf0_insert_afr)




# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
display(etl_tbf0_file)
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["cdc_txn_commit_dttm"]))\
           .withColumn("create_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["update_dttm"]))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_cdc_check_notnull.columns])

#display(etl_tbf0_reformat_cdc_check_notnull)

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()


# COMMAND ----------

# #ReadAPI Call to fetch asset file names with current location:  
# WRITEAPI_URL = dbutils.widgets.get("PAR_WRITEAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 60, 
#                  {"PAR_WRITEAPI_URL":WRITEAPI_URL,
#                   "PAR_WRITEAPI_KEY1":"statusId",
#                   "PAR_WRITEAPI_VALUE1":"200",
#                    "PAR_WRITEAPI_KEY2":"assetId",
#                   "PAR_WRITEAPI_VALUE2":dfAssetIdStr});

# print("Write API successfully executed...")

# COMMAND ----------

#Write API Call to Close Open Assets
'''
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_ASSET_STATUS='200'
#dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/UpdateProcessedFilesStatus", 200, 
                  {"PAR_ASSET_STATUS":PAR_ASSET_STATUS,
                   "PAR_FEED_NAMES":FEED_NAME,
                   "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                   "PAR_SQL_SERVER":PAR_SQL_SERVER,
                   "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                   "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                   "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                   "PAR_WRITEAPI_URL":PAR_WRITEAPI_URL})
'''                  

dbutils.notebook.exit("ETL_TBF0_PAT_RCA_SERVICE_STG_1 LOADED SUCCESSFULLY AND ASSET IS CLOSED")
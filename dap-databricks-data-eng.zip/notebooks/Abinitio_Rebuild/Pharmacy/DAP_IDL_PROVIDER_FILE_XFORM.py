# Databricks notebook source
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

#dbutils.widgets.text("EDWBATCHID", "")
#dbutils.widgets.remove("AI_OUTPUT_Path")

EDWBATCHID=dbutils.widgets.get("EDWBATCHID")
AI_OUTPUT_PATH=dbutils.widgets.get("AI_OUTPUT_PATH")


# COMMAND ----------

FilesList= []

FilesList.append('edw_idl_provider_mp_cif_mp_hc_provider_address_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_healthcare_provider_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_provider_address_dea_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_provider_address_spi_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_hc_provider_type_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_hc_provider_dea_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_provider_state_license_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_prvdr_sanction_offense_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_ic_cif_ic_provider_link_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_gw_cif_gw_provider_link_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_tc_cif_tc_provider_link_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_rr_cif_rr_provider_link_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_provider_link_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_provider_identification_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_hc_prov_cont_chnl_land/'+EDWBATCHID)
FilesList.append('edw_idl_provider_mp_cif_mp_hc_prov_addr_cont_chnl_land/'+EDWBATCHID)
MessageInfo='edw_idl_provider_mp_cif_temp_message_info/'+EDWBATCHID

# COMMAND ----------

for i in FilesList:
  df=spark.read.parquet(mountPoint+'/'+AI_OUTPUT_PATH+'/'+i)
  df1=spark.read.parquet(mountPoint+'/'+AI_OUTPUT_PATH+'/'+MessageInfo)
  df2=df.crossJoin(df1)
  df2.write.format("parquet").mode("overwrite").save(mountPoint+'/'+AI_OUTPUT_PATH+'/'+i)
  
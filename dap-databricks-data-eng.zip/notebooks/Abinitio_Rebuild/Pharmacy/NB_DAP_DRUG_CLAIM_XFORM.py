# Databricks notebook source
PAR_NB_BATCH_ID=dbutils.widgets.get("PAR_BATCH_ID")

# COMMAND ----------

import os
import sys
from npspark import *
from npjet import *
sys.argv[0] = [0]

p = ["{}", "/dbfs/FileStore/apps/projects/edw_pharmacy_prd/config/project.json"]
sys.argv = sys.argv[0] + p
print(sys.argv)

# COMMAND ----------

ctx = JobContext("drug_ic_xform_extract",
    exprParamStr("APT_CONFIG_FILE", "/usr/local/edw/pharmacy/prod/common/apt/edw_phrm_config_4x4.apt"),
    projParamStr("DP_DB_STAGING"),
    projParamStr("pDirDataSetPharmacyHealthcareDrug"),
    projParamStr("pDirLoadReadyPharmacyHealthcareDrug"),
    projParamStr("pDirRejectPharmacyHealthcareDrug"),
    projParamStr("pDirSchema"),
    projParamStr("pTDServer"),
    projParamStr("pTDUserid"),
    exprParamStr("pTDPassword", "LD;@1KVH=9;>0F6M4:J41KI7B<MMM0U5BUCMkF9dG2U71TG:"),
    #projParamStr("pTDStageDB"),
    exprParamStr("pTDETLStageTable", "ETL_TBF0_DRUG_STG"),
    exprParamStr("pSchemaFile_ETLTBL01", "etl_tbf0_drug_hndl_null.osh"),
    exprParamStr("pDSJobName", "drug_ic_xform_extract"),
    exprParamStr("pDSJobInvocation", "NOINVID"),
    exprParamStr("pEdwBatchId", PAR_NB_BATCH_ID),
    exprParamStr("pTDETLReadSessions", "4"),
    exprParamStr("pPAR_DB_ETL_TBL_NAME", "PRDSTGMET.ETL_HIVE_CUTOFF_STG"),
    exprParamStr("pPAR_DB_JOB_ID", "WALGREENS"),
    exprParamStr("pPAR_DB_OUTPUT_FILENAME", "etl_tbf0_drug"),
    exprParamStr("pPAR_DB_OUTPUT_PATH", "pharmacy_healthcare/drug/output"),
    exprParamStr("pPAR_DB_REJECT_PATH", "pharmacy_healthcare/drug/reject"),
    exprParamStr("pPAR_DB_SNFK_TBL_NAME", "DRUG.ETL_TBF0_DRUG_STG"),
    exprParamStr("pPAR_DB_SRC_TBL_NAME", "gg_tbf0_drug"),
    exprParamStr("pPAR_FEED_NAME", "GG_TBF0_DRUG"),
    projParamStr("READ_API_URL"),
    projParamStr("DP_DB_ETL"),
    projParamStr("sfWarehouse"),
    #projParamStr("WRITE_API_URL"),
    exprParamStr("pDSJobName1", "drug_xform_extract_ALL"),
    exprParamStr("NOTEBOOK_PATH_GG_TABLE_LOAD", "/Abinitio_Rebuild/Pharmacy/ETL_TBF0_DRUG"))

# COMMAND ----------

UnprocessedFiles = GetUnprocessedFiles(f"{ctx.pEdwBatchId}", f"{ctx.pDSJobName1}", f"{ctx.pPAR_FEED_NAME}",
                                         f"{ctx.READ_API_URL}", f"/mnt/wrangled/", f"A", ctx)
pFeedNames = [ctx.pPAR_FEED_NAME]
filePathAndFile = ','.join(UnprocessedFiles)
print(filePathAndFile)
dbutils.notebook.run(ctx.NOTEBOOK_PATH_GG_TABLE_LOAD, 1500,
                         {"PAR_DB_BATCH_ID": ctx.pEdwBatchId, "PAR_FEED_NAME": ctx.pPAR_FEED_NAME,
                          "PAR_DB_OUTPUT_FILENAME": ctx.pPAR_DB_OUTPUT_FILENAME,
                          "PAR_DB_OUTPUT_PATH": ctx.pPAR_DB_OUTPUT_PATH,
                          "PAR_DB_REJECT_PATH": ctx.pDirRejectPharmacyHealthcareDrug,
                          "PAR_DB_SNFK_DB": ctx.DP_DB_STAGING, "PAR_DB_SNFK_TBL_NAME": ctx.pPAR_DB_SNFK_TBL_NAME,
                          "PAR_DB_SNFK_WH": ctx.sfWarehouse, "PAR_DB_SNFK_ETL": ctx.DP_DB_ETL,
                          "PAR_DB_ETL_TBL_NAME": ctx.pPAR_DB_ETL_TBL_NAME, "PAR_DB_JOB_ID": ctx.pPAR_DB_JOB_ID,
                          "PAR_DB_SRC_TBL_NAME": ctx.pPAR_DB_SRC_TBL_NAME,
                          "PAR_UNPROCESSED_FILES":filePathAndFile})


# COMMAND ----------

def SKGEN_gen_sk_sequence(df):
    sdf = ctx.addSurrogateKey(df,
      sequenceName=f"{ctx.pDirLoadReadyPharmacyHealthcareDrug}/DRUG_seq_nbr_generator_file.txt",
      surrogateKeyColName="etl_proc_seq_nbr",
      initialValue=1)
    return sdf.alias("srto_key_cdc").selectExpr(
      "srto_key_cdc.cdc_txn_commit_dttm as cdc_txn_commit_dttm",
      "srto_key_cdc.cdc_seq_nbr as cdc_seq_nbr",
      "srto_key_cdc.cdc_rba_nbr as cdc_rba_nbr",
      "srto_key_cdc.cdc_operation_type_cd as cdc_operation_type_cd",
      "srto_key_cdc.cdc_before_after_cd as cdc_before_after_cd",
      "srto_key_cdc.cdc_txn_position_cd as cdc_txn_position_cd",
      "srto_key_cdc.edw_batch_id as edw_batch_id",
      "srto_key_cdc.drug_id as drug_id",
      "srto_key_cdc.ndc_mfg as ndc_mfg",
      "srto_key_cdc.ndc_prod as ndc_prod",
      "srto_key_cdc.ndc_pkg as ndc_pkg",
      "srto_key_cdc.sims_upc as sims_upc",
      "srto_key_cdc.repack_nbr as repack_nbr",
      "srto_key_cdc.ndc_form_cd as ndc_form_cd",
      "srto_key_cdc.ndc_prev_mfg as ndc_prev_mfg",
      "srto_key_cdc.ndc_prev_prod as ndc_prev_prod",
      "srto_key_cdc.ndc_prev_pkg as ndc_prev_pkg",
      "srto_key_cdc.prev_repack_nbr as prev_repack_nbr",
      "srto_key_cdc.ndc_prev_form_cd as ndc_prev_form_cd",
      "srto_key_cdc.id_form_cd as id_form_cd",
      "srto_key_cdc.ndc_upc_hri as ndc_upc_hri",
      "srto_key_cdc.dur_ndc as dur_ndc",
      "srto_key_cdc.prev_ndc_upc_hri as prev_ndc_upc_hri",
      "srto_key_cdc.prev_id_form_cd as prev_id_form_cd",
      "srto_key_cdc.drug_class as drug_class",
      "srto_key_cdc.drug_orange_book_rating as drug_orange_book_rating",
      "srto_key_cdc.drug_name_cd as drug_name_cd",
      "srto_key_cdc.gppc as gppc",
      "srto_key_cdc.gen_typ_cd as gen_typ_cd",
      "srto_key_cdc.gen_id_no as gen_id_no",
      "srto_key_cdc.thera_class as thera_class",
      "srto_key_cdc.lim_stabil as lim_stabil",
      "srto_key_cdc.pack_descr as pack_descr",
      "srto_key_cdc.rx_otc_cd as rx_otc_cd",
      "srto_key_cdc.maint_drug_ind as maint_drug_ind",
      "srto_key_cdc.route_of_admin_cd as route_of_admin_cd",
      "srto_key_cdc.drug_generic_cd as drug_generic_cd",
      "srto_key_cdc.drug_type_cd as drug_type_cd",
      "srto_key_cdc.drug_single_comb_cd as drug_single_comb_cd",
      "srto_key_cdc.drug_storage_cond_cd as drug_storage_cond_cd",
      "srto_key_cdc.a_last_change_dttm as a_last_change_dttm",
      "srto_key_cdc.a_protect_ind as a_protect_ind",
      "srto_key_cdc.product_name as product_name",
      "srto_key_cdc.product_name_suffix as product_name_suffix",
      "srto_key_cdc.product_name_ext as product_name_ext",
      "srto_key_cdc.product_mddb_abbr as product_mddb_abbr",
      "srto_key_cdc.e_last_change_dttm as e_last_change_dttm",
      "srto_key_cdc.e_protect_ind as e_protect_ind",
      "srto_key_cdc.gpi as gpi",
      "srto_key_cdc.gpi_name as gpi_name",
      "srto_key_cdc.g_last_change_dttm as g_last_change_dttm",
      "srto_key_cdc.g_protect_ind as g_protect_ind",
      "srto_key_cdc.mfg_name as mfg_name",
      "srto_key_cdc.mfg_name_abbr as mfg_name_abbr",
      "srto_key_cdc.mfg_mddb_abbr as mfg_mddb_abbr",
      "srto_key_cdc.mfg_name_suffix as mfg_name_suffix",
      "srto_key_cdc.j_last_change_dttm as j_last_change_dttm",
      "srto_key_cdc.j_protect_ind as j_protect_ind",
      "srto_key_cdc.drug_strength as drug_strength",
      "srto_key_cdc.drug_strength_uom as drug_strength_uom",
      "srto_key_cdc.drug_dosage_form_cd as drug_dosage_form_cd",
      "srto_key_cdc.package_size as package_size",
      "srto_key_cdc.package_size_uom as package_size_uom",
      "srto_key_cdc.package_qty as package_qty",
      "srto_key_cdc.rx_to_otc_dttm as rx_to_otc_dttm",
      "srto_key_cdc.l_last_change_dttm as l_last_change_dttm",
      "srto_key_cdc.l_protect_ind as l_protect_ind",
      "srto_key_cdc.awp_dttm as awp_dttm",
      "srto_key_cdc.drug_counting_cell_id as drug_counting_cell_id",
      "srto_key_cdc.awp_unit_price as awp_unit_price",
      "srto_key_cdc.r_last_change_dttm as r_last_change_dttm",
      "srto_key_cdc.r_protect_ind as r_protect_ind",
      "srto_key_cdc.hcfa_dttm as hcfa_dttm",
      "srto_key_cdc.hcfa_unit_limit as hcfa_unit_limit",
      "srto_key_cdc.t_last_change_dttm as t_last_change_dttm",
      "srto_key_cdc.t_protect_ind as t_protect_ind",
      "srto_key_cdc.product_name_abbr as product_name_abbr",
      "srto_key_cdc.drug_status_cd as drug_status_cd",
      "srto_key_cdc.drug_disc_dttm as drug_disc_dttm",
      "srto_key_cdc.mfp_nbr as mfp_nbr",
      "srto_key_cdc.wic_nbr as wic_nbr",
      "srto_key_cdc.drug_ppi_ind as drug_ppi_ind",
      "srto_key_cdc.drug_min_disp_qty as drug_min_disp_qty",
      "srto_key_cdc.default_sig as default_sig",
      "srto_key_cdc.default_days_supply as default_days_supply",
      "srto_key_cdc.expiration_days as expiration_days",
      "srto_key_cdc.drug_class_except_ind as drug_class_except_ind",
      "srto_key_cdc.ops_study_dept_nbr as ops_study_dept_nbr",
      "srto_key_cdc.drug_warehouse_ind as drug_warehouse_ind",
      "srto_key_cdc.pricing_protect_ind as pricing_protect_ind",
      "srto_key_cdc.pr_daco_ind as pr_daco_ind",
      "srto_key_cdc.pricing_override_drug as pricing_override_drug",
      "srto_key_cdc.pricing_type as pricing_type",
      "srto_key_cdc.aac_unit_price as aac_unit_price",
      "srto_key_cdc.wac_unit_price as wac_unit_price",
      "srto_key_cdc.prorated_quantity as prorated_quantity",
      "srto_key_cdc.pricing_quantity as pricing_quantity",
      "srto_key_cdc.drug_shape_cd as drug_shape_cd",
      "srto_key_cdc.drug_color_1_cd as drug_color_1_cd",
      "srto_key_cdc.drug_color_2_cd as drug_color_2_cd",
      "srto_key_cdc.drug_side_1 as drug_side_1",
      "srto_key_cdc.drug_side_2 as drug_side_2",
      "srto_key_cdc.billing_ndc as billing_ndc",
      "srto_key_cdc.drug_comment_cd as drug_comment_cd",
      "srto_key_cdc.default_smart_sig as default_smart_sig",
      "srto_key_cdc.drug_location_cd as drug_location_cd",
      "srto_key_cdc.drug_multihit_disp_ind as drug_multihit_disp_ind",
      "srto_key_cdc.substitution_drug_id as substitution_drug_id",
      "srto_key_cdc.drug_volume as drug_volume",
      "srto_key_cdc.precount_ind as precount_ind",
      "srto_key_cdc.precount_qty_1 as precount_qty_1",
      "srto_key_cdc.precount_qty_2 as precount_qty_2",
      "srto_key_cdc.dur_kdc_nbr as dur_kdc_nbr",
      "srto_key_cdc.ud_uu_pkg_cd as ud_uu_pkg_cd",
      "srto_key_cdc.create_user_id as create_user_id",
      "srto_key_cdc.create_dttm as create_dttm",
      "srto_key_cdc.update_user_id as update_user_id",
      "srto_key_cdc.update_dttm as update_dttm",
      "srto_key_cdc.lbl_cmt_cd as lbl_cmt_cd",
      "srto_key_cdc.substitution_prod_type as substitution_prod_type",
      "srto_key_cdc.recon_water_qty as recon_water_qty",
      "srto_key_cdc.drug_spec_cmt_cd as drug_spec_cmt_cd",
      "srto_key_cdc.fax_pbr_cmt_cd as fax_pbr_cmt_cd",
      "srto_key_cdc.promise_sub_drug_id as promise_sub_drug_id",
      "srto_key_cdc.specialty_drug_ind as specialty_drug_ind",
      "srto_key_cdc.cash_disc_qty as cash_disc_qty",
      "srto_key_cdc.piece_weight as piece_weight",
      "srto_key_cdc.stock_bottle_barcode as stock_bottle_barcode",
      "srto_key_cdc.doses_per_pkg as doses_per_pkg",
      "srto_key_cdc.pct_tot_disc_card as pct_tot_disc_card",
      "srto_key_cdc.pet_med_ind as pet_med_ind",
      "srto_key_cdc.ltd_dist_cd as ltd_dist_cd",
      "srto_key_cdc.complicated_supplies_ind as complicated_supplies_ind",
      "srto_key_cdc.specialty_review_ind as specialty_review_ind",
      "srto_key_cdc.clinical_value_ind as clinical_value_ind",
      "srto_key_cdc.required_supplies_ind as required_supplies_ind",
      "srto_key_cdc.hcp_drug_mltht_disp_ind as hcp_drug_mltht_disp_ind",
      "srto_key_cdc.mix_ind as mix_ind",
      "srto_key_cdc.drug_image_file_name as drug_image_file_name",
      "srto_key_cdc.top_drug_ind as top_drug_ind",
      "srto_key_cdc.quality_alert_message as quality_alert_message",
      "srto_key_cdc.quality_alert_keywords as quality_alert_keywords",
      "srto_key_cdc.quality_alert_rule_ind as quality_alert_rule_ind",
      "srto_key_cdc.quality_alert_screen_ind as quality_alert_screen_ind",
      "srto_key_cdc.cash_disc_qty2 as cash_disc_qty2",
      "srto_key_cdc.cash_disc_qty3 as cash_disc_qty3",
      "srto_key_cdc.tip_ind as tip_ind",
      "srto_key_cdc.ref_drug_id as ref_drug_id",
      "srto_key_cdc.hcpc as hcpc",
      "srto_key_cdc.pref_mfr_ind as pref_mfr_ind",
      "srto_key_cdc.med_guide_filename as med_guide_filename",
      "srto_key_cdc.med_guide_ind as med_guide_ind",
      "srto_key_cdc.item_class as item_class",
      "srto_key_cdc.item_group as item_group",
      "srto_key_cdc.item_formulary_ind as item_formulary_ind",
      "srto_key_cdc.item_category as item_category",
      "srto_key_cdc.item_lob as item_lob",
      "srto_key_cdc.item_conv_factor as item_conv_factor",
      "srto_key_cdc.item_list_price_sale as item_list_price_sale",
      "srto_key_cdc.item_retail_price as item_retail_price",
      "srto_key_cdc.item_pum as item_pum",
      "srto_key_cdc.item_sub_group as item_sub_group",
      "srto_key_cdc.item_sub_category as item_sub_category",
      "srto_key_cdc.item_sum as item_sum",
      "srto_key_cdc.primary_vendor_item_cost as primary_vendor_item_cost",
      "srto_key_cdc.primary_vendor_item_nbr as primary_vendor_item_nbr",
      "srto_key_cdc.secndry_vendor_item_cost as secndry_vendor_item_cost",
      "srto_key_cdc.secndry_vendor_item_nbr as secndry_vendor_item_nbr",
      "srto_key_cdc.tertry_vendor_item_cost as tertry_vendor_item_cost",
      "srto_key_cdc.tertry_vendor_item_nbr as tertry_vendor_item_nbr",
      "srto_key_cdc.specific_gravity as specific_gravity",
      "srto_key_cdc.concentration_nbr as concentration_nbr",
      "srto_key_cdc.concentration_units as concentration_units",
      "srto_key_cdc.lipids_ind as lipids_ind",
      "srto_key_cdc.amino_acid_ind as amino_acid_ind",
      "srto_key_cdc.poolable_ind as poolable_ind",
      "srto_key_cdc.trace_element_ind as trace_element_ind",
      "srto_key_cdc.electrolyte_ind as electrolyte_ind",
      "srto_key_cdc.container_material_cd as container_material_cd",
      "srto_key_cdc.container_max_capacity as container_max_capacity",
      "srto_key_cdc.vehicle_ind as vehicle_ind",
      "srto_key_cdc.vehicle as vehicle",
      "srto_key_cdc.cocktail_ind as cocktail_ind",
      "srto_key_cdc.primary_vendor_nbr as primary_vendor_nbr",
      "srto_key_cdc.secondary_vendor_nbr as secondary_vendor_nbr",
      "srto_key_cdc.tertiary_vendor_nbr as tertiary_vendor_nbr",
      "srto_key_cdc.base_ind as base_ind",
      "srto_key_cdc.item_type as item_type",
      "srto_key_cdc.conc_dextrose_ind as conc_dextrose_ind",
      "srto_key_cdc.container_ind as container_ind",
      "srto_key_cdc.container_type as container_type",
      "srto_key_cdc.primary_vendor_name as primary_vendor_name",
      "srto_key_cdc.secondary_vendor_name as secondary_vendor_name",
      "srto_key_cdc.tertiary_vendor_name as tertiary_vendor_name",
      "srto_key_cdc.plx_drug_ind as plx_drug_ind",
      "srto_key_cdc.item_size as item_size",
      "srto_key_cdc.item_size_units as item_size_units",
      "srto_key_cdc.item_long_desc as item_long_desc",
      "srto_key_cdc.item_short_desc as item_short_desc",
      "srto_key_cdc.item_awp as item_awp",
      "srto_key_cdc.billing_multiplier as billing_multiplier",
      "srto_key_cdc.track_inventory_ind as track_inventory_ind",
      "srto_key_cdc.disease_state_ind as disease_state_ind",
      "srto_key_cdc.drug_inference_cd as drug_inference_cd",
      "srto_key_cdc.drug_min_price as drug_min_price",
      "srto_key_cdc.excl_drug_automation_ind as excl_drug_automation_ind",
      "srto_key_cdc.excl_tbltp_count_ind as excl_tbltp_count_ind",
      "srto_key_cdc.require_tbltp_clean as require_tbltp_clean",
      "srto_key_cdc.thera_class_extd as thera_class_extd",
      "srto_key_cdc.hzrds_lvl_cd as hzrds_lvl_cd",
      "srto_key_cdc.auth_generic_cd as auth_generic_cd",
      "srto_key_cdc.fda_ind as fda_ind",
      "srto_key_cdc.fda_ind_value as fda_ind_value",
      "srto_key_cdc.auth_ndc_upc_hri as auth_ndc_upc_hri",
      "srto_key_cdc.auth_gen_override_ind as auth_gen_override_ind",
      "srto_key_cdc.ddid as ddid",
      "srto_key_cdc.rxcui_type as rxcui_type",
      "srto_key_cdc.rxcui as rxcui",
      "srto_key_cdc.elsevier_pack_id as elsevier_pack_id",
      "srto_key_cdc.elsevier_prod_id as elsevier_prod_id",
      "srto_key_cdc.med_dosage_unit as med_dosage_unit",
      "srto_key_cdc.med_conv_factor as med_conv_factor",
      "srto_key_cdc.mme_calc_factor as mme_calc_factor",
      "etl_proc_seq_nbr as etl_proc_seq_nbr")

# COMMAND ----------

def X_trim_df(df):
    return df.alias("skgeno_gen_sk").selectExpr(
      "skgeno_gen_sk.cdc_txn_commit_dttm as cdc_txn_commit_dttm",
      "skgeno_gen_sk.cdc_seq_nbr as cdc_seq_nbr",
      "skgeno_gen_sk.cdc_rba_nbr as cdc_rba_nbr", 
      "skgeno_gen_sk.cdc_operation_type_cd as cdc_operation_type_cd",
      "skgeno_gen_sk.cdc_before_after_cd as cdc_before_after_cd",
      "skgeno_gen_sk.cdc_txn_position_cd as cdc_txn_position_cd",
      "'I' as edw_dml_ind",
      "skgeno_gen_sk.edw_batch_id as edw_batch_id",
      "skgeno_gen_sk.drug_id as drug_id",
      " if(IsNull(skgeno_gen_sk.ndc_mfg), skgeno_gen_sk.ndc_mfg, trim(skgeno_gen_sk.ndc_mfg)) as ndc_mfg",
      " if(IsNull(skgeno_gen_sk.ndc_prod), skgeno_gen_sk.ndc_prod, trim(skgeno_gen_sk.ndc_prod)) as ndc_prod",
      " if(IsNull(skgeno_gen_sk.ndc_pkg), skgeno_gen_sk.ndc_pkg, trim(skgeno_gen_sk.ndc_pkg)) as ndc_pkg",
      " if(IsNull(skgeno_gen_sk.sims_upc), skgeno_gen_sk.sims_upc, trim(skgeno_gen_sk.sims_upc)) as sims_upc",
      " if(IsNull(skgeno_gen_sk.repack_nbr), skgeno_gen_sk.repack_nbr, trim(skgeno_gen_sk.repack_nbr)) as repack_nbr",
      "skgeno_gen_sk.ndc_form_cd as ndc_form_cd",
      " if(IsNull(skgeno_gen_sk.ndc_prev_mfg), skgeno_gen_sk.ndc_prev_mfg, trim(skgeno_gen_sk.ndc_prev_mfg)) as ndc_prev_mfg",
      " if(IsNull(skgeno_gen_sk.ndc_prev_prod), skgeno_gen_sk.ndc_prev_prod, trim(skgeno_gen_sk.ndc_prev_prod)) as ndc_prev_prod",
      " if(IsNull(skgeno_gen_sk.ndc_prev_pkg), skgeno_gen_sk.ndc_prev_pkg, trim(skgeno_gen_sk.ndc_prev_pkg)) as ndc_prev_pkg",
      " if(IsNull(skgeno_gen_sk.prev_repack_nbr), skgeno_gen_sk.prev_repack_nbr, trim(skgeno_gen_sk.prev_repack_nbr)) as prev_repack_nbr",
      "skgeno_gen_sk.ndc_prev_form_cd as ndc_prev_form_cd",
      "skgeno_gen_sk.id_form_cd as id_form_cd",
      " if(IsNull(skgeno_gen_sk.ndc_upc_hri), skgeno_gen_sk.ndc_upc_hri, trim(skgeno_gen_sk.ndc_upc_hri)) as ndc_upc_hri",
      " if(IsNull(skgeno_gen_sk.dur_ndc), skgeno_gen_sk.dur_ndc, trim(skgeno_gen_sk.dur_ndc)) as dur_ndc",
      " if(IsNull(skgeno_gen_sk.prev_ndc_upc_hri), skgeno_gen_sk.prev_ndc_upc_hri, trim(skgeno_gen_sk.prev_ndc_upc_hri)) as prev_ndc_upc_hri",
      "skgeno_gen_sk.prev_id_form_cd as prev_id_form_cd",
      " if(IsNull(skgeno_gen_sk.drug_class), skgeno_gen_sk.drug_class, trim(skgeno_gen_sk.drug_class)) as drug_class",
      " if(IsNull(skgeno_gen_sk.drug_orange_book_rating), skgeno_gen_sk.drug_orange_book_rating, trim(skgeno_gen_sk.drug_orange_book_rating)) as drug_orange_book_rating",
      " if(IsNull(skgeno_gen_sk.drug_name_cd), skgeno_gen_sk.drug_name_cd, trim(skgeno_gen_sk.drug_name_cd)) as drug_name_cd",
      " if(IsNull(skgeno_gen_sk.gppc), skgeno_gen_sk.gppc, trim(skgeno_gen_sk.gppc)) as gppc",
      " if(IsNull(skgeno_gen_sk.gen_typ_cd), skgeno_gen_sk.gen_typ_cd, trim(skgeno_gen_sk.gen_typ_cd)) as gen_typ_cd",
      "skgeno_gen_sk.gen_id_no as gen_id_no",
      "skgeno_gen_sk.thera_class as thera_class",
      " if(IsNull(skgeno_gen_sk.lim_stabil), skgeno_gen_sk.lim_stabil, trim(skgeno_gen_sk.lim_stabil)) as lim_stabil",
      " if(IsNull(skgeno_gen_sk.pack_descr), skgeno_gen_sk.pack_descr, trim(skgeno_gen_sk.pack_descr)) as pack_descr",
      " if(IsNull(skgeno_gen_sk.rx_otc_cd), skgeno_gen_sk.rx_otc_cd, trim(skgeno_gen_sk.rx_otc_cd)) as rx_otc_cd",
      " if(IsNull(skgeno_gen_sk.maint_drug_ind), skgeno_gen_sk.maint_drug_ind, trim(skgeno_gen_sk.maint_drug_ind)) as maint_drug_ind",
      " if(IsNull(skgeno_gen_sk.route_of_admin_cd), skgeno_gen_sk.route_of_admin_cd, trim(skgeno_gen_sk.route_of_admin_cd)) as route_of_admin_cd",
      " if(IsNull(skgeno_gen_sk.drug_generic_cd), skgeno_gen_sk.drug_generic_cd, trim(skgeno_gen_sk.drug_generic_cd)) as drug_generic_cd",
      " if(IsNull(skgeno_gen_sk.drug_type_cd), skgeno_gen_sk.drug_type_cd, trim(skgeno_gen_sk.drug_type_cd)) as drug_type_cd",
      " if(IsNull(skgeno_gen_sk.drug_single_comb_cd), skgeno_gen_sk.drug_single_comb_cd, trim(skgeno_gen_sk.drug_single_comb_cd)) as drug_single_comb_cd",
      " if(IsNull(skgeno_gen_sk.drug_storage_cond_cd), skgeno_gen_sk.drug_storage_cond_cd, trim(skgeno_gen_sk.drug_storage_cond_cd)) as drug_storage_cond_cd",
      "skgeno_gen_sk.a_last_change_dttm as a_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.a_protect_ind), skgeno_gen_sk.a_protect_ind, trim(skgeno_gen_sk.a_protect_ind)) as a_protect_ind",
      " if(IsNull(skgeno_gen_sk.product_name), skgeno_gen_sk.product_name, trim(skgeno_gen_sk.product_name)) as product_name",
      " if(IsNull(skgeno_gen_sk.product_name_suffix), skgeno_gen_sk.product_name_suffix, trim(skgeno_gen_sk.product_name_suffix)) as product_name_suffix",
      " if(IsNull(skgeno_gen_sk.product_name_ext), skgeno_gen_sk.product_name_ext, trim(skgeno_gen_sk.product_name_ext)) as product_name_ext",
      " if(IsNull(skgeno_gen_sk.product_mddb_abbr), skgeno_gen_sk.product_mddb_abbr, trim(skgeno_gen_sk.product_mddb_abbr)) as product_mddb_abbr",
      "skgeno_gen_sk.e_last_change_dttm as e_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.e_protect_ind), skgeno_gen_sk.e_protect_ind, trim(skgeno_gen_sk.e_protect_ind)) as e_protect_ind",
      " if(IsNull(skgeno_gen_sk.gpi), skgeno_gen_sk.gpi, trim(skgeno_gen_sk.gpi)) as gpi",
      " if(IsNull(skgeno_gen_sk.gpi_name), skgeno_gen_sk.gpi_name, trim(skgeno_gen_sk.gpi_name)) as gpi_name",
      "skgeno_gen_sk.g_last_change_dttm as g_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.g_protect_ind), skgeno_gen_sk.g_protect_ind, trim(skgeno_gen_sk.g_protect_ind)) as g_protect_ind",
      " if(IsNull(skgeno_gen_sk.mfg_name), skgeno_gen_sk.mfg_name, trim(skgeno_gen_sk.mfg_name)) as mfg_name",
      " if(IsNull(skgeno_gen_sk.mfg_name_abbr), skgeno_gen_sk.mfg_name_abbr, trim(skgeno_gen_sk.mfg_name_abbr)) as mfg_name_abbr",
      " if(IsNull(skgeno_gen_sk.mfg_mddb_abbr), skgeno_gen_sk.mfg_mddb_abbr, trim(skgeno_gen_sk.mfg_mddb_abbr)) as mfg_mddb_abbr",
      " if(IsNull(skgeno_gen_sk.mfg_name_suffix), skgeno_gen_sk.mfg_name_suffix, trim(skgeno_gen_sk.mfg_name_suffix)) as mfg_name_suffix",
      "skgeno_gen_sk.j_last_change_dttm as j_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.j_protect_ind), skgeno_gen_sk.j_protect_ind, trim(skgeno_gen_sk.j_protect_ind)) as j_protect_ind",
      "skgeno_gen_sk.drug_strength as drug_strength",
      " if(IsNull(skgeno_gen_sk.drug_strength_uom), skgeno_gen_sk.drug_strength_uom, trim(skgeno_gen_sk.drug_strength_uom)) as drug_strength_uom",
      " if(IsNull(skgeno_gen_sk.drug_dosage_form_cd), skgeno_gen_sk.drug_dosage_form_cd, trim(skgeno_gen_sk.drug_dosage_form_cd)) as drug_dosage_form_cd",
      "skgeno_gen_sk.package_size as package_size",
      " if(IsNull(skgeno_gen_sk.package_size_uom), skgeno_gen_sk.package_size_uom, trim(skgeno_gen_sk.package_size_uom)) as package_size_uom",
      "skgeno_gen_sk.package_qty as package_qty",
      "skgeno_gen_sk.rx_to_otc_dttm as rx_to_otc_dttm",
      "skgeno_gen_sk.l_last_change_dttm as l_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.l_protect_ind), skgeno_gen_sk.l_protect_ind, trim(skgeno_gen_sk.l_protect_ind)) as l_protect_ind",
      "skgeno_gen_sk.awp_dttm as awp_dttm",
      "skgeno_gen_sk.drug_counting_cell_id as drug_counting_cell_id",
      "skgeno_gen_sk.awp_unit_price as awp_unit_price",
      "skgeno_gen_sk.r_last_change_dttm as r_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.r_protect_ind), skgeno_gen_sk.r_protect_ind, trim(skgeno_gen_sk.r_protect_ind)) as r_protect_ind",
      "skgeno_gen_sk.hcfa_dttm as hcfa_dttm",
      "skgeno_gen_sk.hcfa_unit_limit as hcfa_unit_limit",
      "skgeno_gen_sk.t_last_change_dttm as t_last_change_dttm",
      " if(IsNull(skgeno_gen_sk.t_protect_ind), skgeno_gen_sk.t_protect_ind, trim(skgeno_gen_sk.t_protect_ind)) as t_protect_ind",
      " if(IsNull(skgeno_gen_sk.product_name_abbr), skgeno_gen_sk.product_name_abbr, trim(skgeno_gen_sk.product_name_abbr)) as product_name_abbr",
      " if(IsNull(skgeno_gen_sk.drug_status_cd), skgeno_gen_sk.drug_status_cd, trim(skgeno_gen_sk.drug_status_cd)) as drug_status_cd",
      "skgeno_gen_sk.drug_disc_dttm as drug_disc_dttm",
      " if(IsNull(skgeno_gen_sk.mfp_nbr), skgeno_gen_sk.mfp_nbr, trim(skgeno_gen_sk.mfp_nbr)) as mfp_nbr",
      "skgeno_gen_sk.wic_nbr as wic_nbr",
      " if(IsNull(skgeno_gen_sk.drug_ppi_ind), skgeno_gen_sk.drug_ppi_ind, trim(skgeno_gen_sk.drug_ppi_ind)) as drug_ppi_ind",
      "skgeno_gen_sk.drug_min_disp_qty as drug_min_disp_qty",
      " if(IsNull(skgeno_gen_sk.default_sig), skgeno_gen_sk.default_sig, trim(skgeno_gen_sk.default_sig)) as default_sig",
      "skgeno_gen_sk.default_days_supply as default_days_supply",
      "skgeno_gen_sk.expiration_days as expiration_days",
      " if(IsNull(skgeno_gen_sk.drug_class_except_ind), skgeno_gen_sk.drug_class_except_ind, trim(skgeno_gen_sk.drug_class_except_ind)) as drug_class_except_ind",
      "skgeno_gen_sk.ops_study_dept_nbr as ops_study_dept_nbr",
      " if(IsNull(skgeno_gen_sk.drug_warehouse_ind), skgeno_gen_sk.drug_warehouse_ind, trim(skgeno_gen_sk.drug_warehouse_ind)) as drug_warehouse_ind",
      " if(IsNull(skgeno_gen_sk.pricing_protect_ind), skgeno_gen_sk.pricing_protect_ind, trim(skgeno_gen_sk.pricing_protect_ind)) as pricing_protect_ind",
      " if(IsNull(skgeno_gen_sk.pr_daco_ind), skgeno_gen_sk.pr_daco_ind, trim(skgeno_gen_sk.pr_daco_ind)) as pr_daco_ind",
      "skgeno_gen_sk.pricing_override_drug as pricing_override_drug",
      "skgeno_gen_sk.pricing_type as pricing_type",
      "skgeno_gen_sk.aac_unit_price as aac_unit_price",
      "skgeno_gen_sk.wac_unit_price as wac_unit_price",
      "skgeno_gen_sk.prorated_quantity as prorated_quantity",
      "skgeno_gen_sk.pricing_quantity as pricing_quantity",
      " if(IsNull(skgeno_gen_sk.drug_shape_cd), skgeno_gen_sk.drug_shape_cd, trim(skgeno_gen_sk.drug_shape_cd)) as drug_shape_cd",
      " if(IsNull(skgeno_gen_sk.drug_color_1_cd), skgeno_gen_sk.drug_color_1_cd, trim(skgeno_gen_sk.drug_color_1_cd)) as drug_color_1_cd",
      " if(IsNull(skgeno_gen_sk.drug_color_2_cd), skgeno_gen_sk.drug_color_2_cd, trim(skgeno_gen_sk.drug_color_2_cd)) as drug_color_2_cd",
      " if(IsNull(skgeno_gen_sk.drug_side_1), skgeno_gen_sk.drug_side_1, trim(skgeno_gen_sk.drug_side_1)) as drug_side_1",
      " if(IsNull(skgeno_gen_sk.drug_side_2), skgeno_gen_sk.drug_side_2, trim(skgeno_gen_sk.drug_side_2)) as drug_side_2",
      " if(IsNull(skgeno_gen_sk.billing_ndc), skgeno_gen_sk.billing_ndc, trim(skgeno_gen_sk.billing_ndc)) as billing_ndc",
      " if(IsNull(skgeno_gen_sk.drug_comment_cd), skgeno_gen_sk.drug_comment_cd, trim(skgeno_gen_sk.drug_comment_cd)) as drug_comment_cd",
      " if(IsNull(skgeno_gen_sk.default_smart_sig), skgeno_gen_sk.default_smart_sig, trim(skgeno_gen_sk.default_smart_sig)) as default_smart_sig",
      " if(IsNull(skgeno_gen_sk.drug_location_cd), skgeno_gen_sk.drug_location_cd, trim(skgeno_gen_sk.drug_location_cd)) as drug_location_cd",
      " if(IsNull(skgeno_gen_sk.drug_multihit_disp_ind), skgeno_gen_sk.drug_multihit_disp_ind, trim(skgeno_gen_sk.drug_multihit_disp_ind)) as drug_multihit_disp_ind",
      "skgeno_gen_sk.substitution_drug_id as substitution_drug_id",
      "skgeno_gen_sk.drug_volume as drug_volume",
      " if(IsNull(skgeno_gen_sk.precount_ind), skgeno_gen_sk.precount_ind, trim(skgeno_gen_sk.precount_ind)) as precount_ind",
      "skgeno_gen_sk.precount_qty_1 as precount_qty_1",
      "skgeno_gen_sk.precount_qty_2 as precount_qty_2",
      " if(IsNull(skgeno_gen_sk.dur_kdc_nbr), skgeno_gen_sk.dur_kdc_nbr, trim(skgeno_gen_sk.dur_kdc_nbr)) as dur_kdc_nbr",
      " if(IsNull(skgeno_gen_sk.ud_uu_pkg_cd), skgeno_gen_sk.ud_uu_pkg_cd, trim(skgeno_gen_sk.ud_uu_pkg_cd)) as ud_uu_pkg_cd",
      "skgeno_gen_sk.create_user_id as create_user_id",
      "skgeno_gen_sk.create_dttm as create_dttm",
      "skgeno_gen_sk.update_user_id as update_user_id",
      "skgeno_gen_sk.update_dttm as update_dttm",
      " if(IsNull(skgeno_gen_sk.lbl_cmt_cd), skgeno_gen_sk.lbl_cmt_cd, trim(skgeno_gen_sk.lbl_cmt_cd)) as lbl_cmt_cd",
      " if(IsNull(skgeno_gen_sk.substitution_prod_type), skgeno_gen_sk.substitution_prod_type, trim(skgeno_gen_sk.substitution_prod_type)) as substitution_prod_type",
      "skgeno_gen_sk.recon_water_qty as recon_water_qty",
      " if(IsNull(skgeno_gen_sk.drug_spec_cmt_cd), skgeno_gen_sk.drug_spec_cmt_cd, trim(skgeno_gen_sk.drug_spec_cmt_cd)) as drug_spec_cmt_cd",
      " if(IsNull(skgeno_gen_sk.fax_pbr_cmt_cd), skgeno_gen_sk.fax_pbr_cmt_cd, trim(skgeno_gen_sk.fax_pbr_cmt_cd)) as fax_pbr_cmt_cd",
      "skgeno_gen_sk.promise_sub_drug_id as promise_sub_drug_id",
      " if(IsNull(skgeno_gen_sk.specialty_drug_ind), skgeno_gen_sk.specialty_drug_ind, trim(skgeno_gen_sk.specialty_drug_ind)) as specialty_drug_ind",
      "skgeno_gen_sk.cash_disc_qty as cash_disc_qty",
      "skgeno_gen_sk.piece_weight as piece_weight",
      " if(IsNull(skgeno_gen_sk.stock_bottle_barcode), skgeno_gen_sk.stock_bottle_barcode, trim(skgeno_gen_sk.stock_bottle_barcode)) as stock_bottle_barcode",
      "skgeno_gen_sk.doses_per_pkg as doses_per_pkg",
      "skgeno_gen_sk.pct_tot_disc_card as pct_tot_disc_card",
      " if(IsNull(skgeno_gen_sk.pet_med_ind), skgeno_gen_sk.pet_med_ind, trim(skgeno_gen_sk.pet_med_ind)) as pet_med_ind",
      " if(IsNull(skgeno_gen_sk.ltd_dist_cd), skgeno_gen_sk.ltd_dist_cd, trim(skgeno_gen_sk.ltd_dist_cd)) as ltd_dist_cd",
      " if(IsNull(skgeno_gen_sk.complicated_supplies_ind), skgeno_gen_sk.complicated_supplies_ind, trim(skgeno_gen_sk.complicated_supplies_ind)) as complicated_supplies_ind",
      " if(IsNull(skgeno_gen_sk.specialty_review_ind), skgeno_gen_sk.specialty_review_ind, trim(skgeno_gen_sk.specialty_review_ind)) as specialty_review_ind",
      " if(IsNull(skgeno_gen_sk.clinical_value_ind), skgeno_gen_sk.clinical_value_ind, trim(skgeno_gen_sk.clinical_value_ind)) as clinical_value_ind",
      " if(IsNull(skgeno_gen_sk.required_supplies_ind), skgeno_gen_sk.required_supplies_ind, trim(skgeno_gen_sk.required_supplies_ind)) as required_supplies_ind",
      " if(IsNull(skgeno_gen_sk.hcp_drug_mltht_disp_ind), skgeno_gen_sk.hcp_drug_mltht_disp_ind, trim(skgeno_gen_sk.hcp_drug_mltht_disp_ind)) as hcp_drug_mltht_disp_ind",
      " if(IsNull(skgeno_gen_sk.mix_ind), skgeno_gen_sk.mix_ind, trim(skgeno_gen_sk.mix_ind)) as mix_ind",
      " if(IsNull(skgeno_gen_sk.drug_image_file_name), skgeno_gen_sk.drug_image_file_name, trim(skgeno_gen_sk.drug_image_file_name)) as drug_image_file_name",
      " if(IsNull(skgeno_gen_sk.top_drug_ind), skgeno_gen_sk.top_drug_ind, trim(skgeno_gen_sk.top_drug_ind)) as top_drug_ind",
      " if(IsNull(skgeno_gen_sk.quality_alert_message), skgeno_gen_sk.quality_alert_message, trim(skgeno_gen_sk.quality_alert_message)) as quality_alert_message",
      " if(IsNull(skgeno_gen_sk.quality_alert_keywords), skgeno_gen_sk.quality_alert_keywords, trim(skgeno_gen_sk.quality_alert_keywords)) as quality_alert_keywords",
      " if(IsNull(skgeno_gen_sk.quality_alert_rule_ind), skgeno_gen_sk.quality_alert_rule_ind, trim(skgeno_gen_sk.quality_alert_rule_ind)) as quality_alert_rule_ind",
      " if(IsNull(skgeno_gen_sk.quality_alert_screen_ind), skgeno_gen_sk.quality_alert_screen_ind, trim(skgeno_gen_sk.quality_alert_screen_ind)) as quality_alert_screen_ind",
      "skgeno_gen_sk.cash_disc_qty2 as cash_disc_qty2",
      "skgeno_gen_sk.cash_disc_qty3 as cash_disc_qty3",
      " if(IsNull(skgeno_gen_sk.tip_ind), skgeno_gen_sk.tip_ind, trim(skgeno_gen_sk.tip_ind)) as tip_ind",
      "skgeno_gen_sk.ref_drug_id as ref_drug_id",
      " if(IsNull(skgeno_gen_sk.hcpc), skgeno_gen_sk.hcpc, trim(skgeno_gen_sk.hcpc)) as hcpc",
      " if(IsNull(skgeno_gen_sk.pref_mfr_ind), skgeno_gen_sk.pref_mfr_ind, trim(skgeno_gen_sk.pref_mfr_ind)) as pref_mfr_ind",
      " if(IsNull(skgeno_gen_sk.med_guide_filename), skgeno_gen_sk.med_guide_filename, trim(skgeno_gen_sk.med_guide_filename)) as med_guide_filename",
      " if(IsNull(skgeno_gen_sk.med_guide_ind), skgeno_gen_sk.med_guide_ind, trim(skgeno_gen_sk.med_guide_ind)) as med_guide_ind",
      "skgeno_gen_sk.item_class as item_class",
      "skgeno_gen_sk.item_group as item_group",
      " if(IsNull(skgeno_gen_sk.item_formulary_ind), skgeno_gen_sk.item_formulary_ind, trim(skgeno_gen_sk.item_formulary_ind)) as item_formulary_ind",
      "skgeno_gen_sk.item_category as item_category",
      "skgeno_gen_sk.item_lob as item_lob",
      "skgeno_gen_sk.item_conv_factor as item_conv_factor",
      "skgeno_gen_sk.item_list_price_sale as item_list_price_sale",
      "skgeno_gen_sk.item_retail_price as item_retail_price",
      "skgeno_gen_sk.item_pum as item_pum",
      "skgeno_gen_sk.item_sub_group as item_sub_group",
      "skgeno_gen_sk.item_sub_category as item_sub_category",
      "skgeno_gen_sk.item_sum as item_sum",
      "skgeno_gen_sk.primary_vendor_item_cost as primary_vendor_item_cost",
      " if(IsNull(skgeno_gen_sk.primary_vendor_item_nbr), skgeno_gen_sk.primary_vendor_item_nbr, trim(skgeno_gen_sk.primary_vendor_item_nbr)) as primary_vendor_item_nbr",
      "skgeno_gen_sk.secndry_vendor_item_cost as secndry_vendor_item_cost",
      " if(IsNull(skgeno_gen_sk.secndry_vendor_item_nbr), skgeno_gen_sk.secndry_vendor_item_nbr, trim(skgeno_gen_sk.secndry_vendor_item_nbr)) as secndry_vendor_item_nbr",
      "skgeno_gen_sk.tertry_vendor_item_cost as tertry_vendor_item_cost",
      " if(IsNull(skgeno_gen_sk.tertry_vendor_item_nbr), skgeno_gen_sk.tertry_vendor_item_nbr, trim(skgeno_gen_sk.tertry_vendor_item_nbr)) as tertry_vendor_item_nbr",
      "skgeno_gen_sk.specific_gravity as specific_gravity",
      "skgeno_gen_sk.concentration_nbr as concentration_nbr",
      "skgeno_gen_sk.concentration_units as concentration_units",
      " if(IsNull(skgeno_gen_sk.lipids_ind), skgeno_gen_sk.lipids_ind, trim(skgeno_gen_sk.lipids_ind)) as lipids_ind",
      " if(IsNull(skgeno_gen_sk.amino_acid_ind), skgeno_gen_sk.amino_acid_ind, trim(skgeno_gen_sk.amino_acid_ind)) as amino_acid_ind",
      " if(IsNull(skgeno_gen_sk.poolable_ind), skgeno_gen_sk.poolable_ind, trim(skgeno_gen_sk.poolable_ind)) as poolable_ind",
      " if(IsNull(skgeno_gen_sk.trace_element_ind), skgeno_gen_sk.trace_element_ind, trim(skgeno_gen_sk.trace_element_ind)) as trace_element_ind",
      " if(IsNull(skgeno_gen_sk.electrolyte_ind), skgeno_gen_sk.electrolyte_ind, trim(skgeno_gen_sk.electrolyte_ind)) as electrolyte_ind",
      "skgeno_gen_sk.container_material_cd as container_material_cd",
      "skgeno_gen_sk.container_max_capacity as container_max_capacity",
      " if(IsNull(skgeno_gen_sk.vehicle_ind), skgeno_gen_sk.vehicle_ind, trim(skgeno_gen_sk.vehicle_ind)) as vehicle_ind",
      "skgeno_gen_sk.vehicle as vehicle",
      " if(IsNull(skgeno_gen_sk.cocktail_ind), skgeno_gen_sk.cocktail_ind, trim(skgeno_gen_sk.cocktail_ind)) as cocktail_ind",
      " if(IsNull(skgeno_gen_sk.primary_vendor_nbr), skgeno_gen_sk.primary_vendor_nbr, trim(skgeno_gen_sk.primary_vendor_nbr)) as primary_vendor_nbr",
      " if(IsNull(skgeno_gen_sk.secondary_vendor_nbr), skgeno_gen_sk.secondary_vendor_nbr, trim(skgeno_gen_sk.secondary_vendor_nbr)) as secondary_vendor_nbr",
      " if(IsNull(skgeno_gen_sk.tertiary_vendor_nbr), skgeno_gen_sk.tertiary_vendor_nbr, trim(skgeno_gen_sk.tertiary_vendor_nbr)) as tertiary_vendor_nbr",
      " if(IsNull(skgeno_gen_sk.base_ind), skgeno_gen_sk.base_ind, trim(skgeno_gen_sk.base_ind)) as base_ind",
      "skgeno_gen_sk.item_type as item_type",
      " if(IsNull(skgeno_gen_sk.conc_dextrose_ind), skgeno_gen_sk.conc_dextrose_ind, trim(skgeno_gen_sk.conc_dextrose_ind)) as conc_dextrose_ind",
      " if(IsNull(skgeno_gen_sk.container_ind), skgeno_gen_sk.container_ind, trim(skgeno_gen_sk.container_ind)) as container_ind",
      "skgeno_gen_sk.container_type as container_type",
      " if(IsNull(skgeno_gen_sk.primary_vendor_name), skgeno_gen_sk.primary_vendor_name, trim(skgeno_gen_sk.primary_vendor_name)) as primary_vendor_name",
      " if(IsNull(skgeno_gen_sk.secondary_vendor_name), skgeno_gen_sk.secondary_vendor_name, trim(skgeno_gen_sk.secondary_vendor_name)) as secondary_vendor_name",
      " if(IsNull(skgeno_gen_sk.tertiary_vendor_name), skgeno_gen_sk.tertiary_vendor_name, trim(skgeno_gen_sk.tertiary_vendor_name)) as tertiary_vendor_name",
      " if(IsNull(skgeno_gen_sk.plx_drug_ind), skgeno_gen_sk.plx_drug_ind, trim(skgeno_gen_sk.plx_drug_ind)) as plx_drug_ind",
      "skgeno_gen_sk.item_size as item_size",
      "skgeno_gen_sk.item_size_units as item_size_units",
      " if(IsNull(skgeno_gen_sk.item_long_desc), skgeno_gen_sk.item_long_desc, trim(skgeno_gen_sk.item_long_desc)) as item_long_desc",
      " if(IsNull(skgeno_gen_sk.item_short_desc), skgeno_gen_sk.item_short_desc, trim(skgeno_gen_sk.item_short_desc)) as item_short_desc",
      "skgeno_gen_sk.item_awp as item_awp",
      "skgeno_gen_sk.billing_multiplier as billing_multiplier",
      " if(IsNull(skgeno_gen_sk.track_inventory_ind), skgeno_gen_sk.track_inventory_ind, trim(skgeno_gen_sk.track_inventory_ind)) as track_inventory_ind",
      " if(IsNull(skgeno_gen_sk.disease_state_ind), skgeno_gen_sk.disease_state_ind, trim(skgeno_gen_sk.disease_state_ind)) as disease_state_ind",
      " if(IsNull(skgeno_gen_sk.drug_inference_cd), skgeno_gen_sk.drug_inference_cd, trim(skgeno_gen_sk.drug_inference_cd)) as drug_inference_cd",
      "skgeno_gen_sk.drug_min_price as drug_min_price",
      " if(IsNull(skgeno_gen_sk.excl_drug_automation_ind), skgeno_gen_sk.excl_drug_automation_ind, trim(skgeno_gen_sk.excl_drug_automation_ind)) as excl_drug_automation_ind",
      "skgeno_gen_sk.excl_tbltp_count_ind as excl_tbltp_count_ind",
      "skgeno_gen_sk.require_tbltp_clean as require_tbltp_clean",
      "skgeno_gen_sk.thera_class_extd as thera_class_extd",
      "skgeno_gen_sk.etl_proc_seq_nbr as etl_proc_seq_nbr",
      "skgeno_gen_sk.hzrds_lvl_cd as hzrds_lvl_cd",
      "skgeno_gen_sk.auth_generic_cd as auth_generic_cd",
      "skgeno_gen_sk.fda_ind as fda_ind",
      "skgeno_gen_sk.fda_ind_value as fda_ind_value",
      "skgeno_gen_sk.auth_ndc_upc_hri as auth_ndc_upc_hri",
      "skgeno_gen_sk.auth_gen_override_ind as auth_gen_override_ind",
      "skgeno_gen_sk.ddid as ddid",
      "skgeno_gen_sk.rxcui_type as rxcui_type",
      "skgeno_gen_sk.rxcui as rxcui",
      "skgeno_gen_sk.elsevier_pack_id as elsevier_pack_id",
      "skgeno_gen_sk.elsevier_prod_id as elsevier_prod_id",
      "skgeno_gen_sk.med_dosage_unit as med_dosage_unit",
      "skgeno_gen_sk.med_conv_factor as med_conv_factor",
      "skgeno_gen_sk.mme_calc_factor as mme_calc_factor")

# COMMAND ----------

def cpo_distribute_V0S44P1_df(df):
    return df.alias("xo_trim").selectExpr(
      "xo_trim.cdc_txn_commit_dttm as cdc_txn_commit_dttm",
      "xo_trim.cdc_seq_nbr as cdc_seq_nbr",
      "xo_trim.cdc_rba_nbr as cdc_rba_nbr",
      "xo_trim.cdc_operation_type_cd as cdc_operation_type_cd",
      "xo_trim.cdc_before_after_cd as cdc_before_after_cd",
      "xo_trim.edw_dml_ind as edw_dml_ind",
      "xo_trim.edw_batch_id as edw_batch_id",
      "xo_trim.drug_id as drug_id",
      "xo_trim.ndc_mfg as ndc_mfg",
      "xo_trim.ndc_prod as ndc_prod",
      "xo_trim.ndc_pkg as ndc_pkg",
      "xo_trim.sims_upc as sims_upc",
      "xo_trim.repack_nbr as repack_nbr",
      "xo_trim.ndc_form_cd as ndc_form_cd",
      "xo_trim.ndc_prev_mfg as ndc_prev_mfg",
      "xo_trim.ndc_prev_prod as ndc_prev_prod",
      "xo_trim.ndc_prev_pkg as ndc_prev_pkg",
      "xo_trim.prev_repack_nbr as prev_repack_nbr",
      "xo_trim.ndc_prev_form_cd as ndc_prev_form_cd",
      "xo_trim.id_form_cd as id_form_cd",
      "xo_trim.ndc_upc_hri as ndc_upc_hri",
      "xo_trim.dur_ndc as dur_ndc",
      "xo_trim.prev_ndc_upc_hri as prev_ndc_upc_hri",
      "xo_trim.prev_id_form_cd as prev_id_form_cd",
      "xo_trim.drug_class as drug_class",
      "xo_trim.drug_orange_book_rating as drug_orange_book_rating",
      "xo_trim.drug_name_cd as drug_name_cd",
      "xo_trim.gppc as gppc",
      "xo_trim.gen_typ_cd as gen_typ_cd",
      "xo_trim.gen_id_no as gen_id_no",
      "xo_trim.thera_class as thera_class",
      "xo_trim.lim_stabil as lim_stabil",
      "xo_trim.pack_descr as pack_descr",
      "xo_trim.rx_otc_cd as rx_otc_cd",
      "xo_trim.maint_drug_ind as maint_drug_ind",
      "xo_trim.route_of_admin_cd as route_of_admin_cd",
      "xo_trim.drug_generic_cd as drug_generic_cd",
      "xo_trim.drug_type_cd as drug_type_cd",
      "xo_trim.drug_single_comb_cd as drug_single_comb_cd",
      "xo_trim.drug_storage_cond_cd as drug_storage_cond_cd",
      "xo_trim.product_name as product_name",
      "xo_trim.product_name_suffix as product_name_suffix",
      "xo_trim.product_name_ext as product_name_ext",
      "xo_trim.product_mddb_abbr as product_mddb_abbr",
      "xo_trim.gpi as gpi",
      "xo_trim.gpi_name as gpi_name",
      "xo_trim.mfg_name as mfg_name",
      "xo_trim.mfg_name_abbr as mfg_name_abbr",
      "xo_trim.mfg_mddb_abbr as mfg_mddb_abbr",
      "xo_trim.mfg_name_suffix as mfg_name_suffix",
      "xo_trim.drug_strength as drug_strength",
      "xo_trim.drug_strength_uom as drug_strength_uom",
      "xo_trim.drug_dosage_form_cd as drug_dosage_form_cd",
      "xo_trim.package_size as package_size",
      "xo_trim.package_size_uom as package_size_uom",
      "xo_trim.package_qty as package_qty",
      "xo_trim.rx_to_otc_dttm as rx_to_otc_dttm",
      "xo_trim.awp_dttm as awp_dttm",
      "xo_trim.drug_counting_cell_id as drug_counting_cell_id",
      "xo_trim.awp_unit_price as awp_unit_price",
      "xo_trim.hcfa_dttm as hcfa_dttm",
      "xo_trim.hcfa_unit_limit as hcfa_unit_limit",
      "xo_trim.product_name_abbr as product_name_abbr",
      "xo_trim.drug_status_cd as drug_status_cd",
      "xo_trim.drug_disc_dttm as drug_disc_dttm",
      "xo_trim.mfp_nbr as mfp_nbr",
      "xo_trim.wic_nbr as wic_nbr",
      "xo_trim.drug_ppi_ind as drug_ppi_ind",
      "xo_trim.drug_min_disp_qty as drug_min_disp_qty",
      "xo_trim.default_sig as default_sig",
      "xo_trim.default_days_supply as default_days_supply",
      "xo_trim.expiration_days as expiration_days",
      "xo_trim.drug_class_except_ind as drug_class_except_ind",
      "xo_trim.ops_study_dept_nbr as ops_study_dept_nbr",
      "xo_trim.drug_warehouse_ind as drug_warehouse_ind",
      "xo_trim.pricing_protect_ind as pricing_protect_ind",
      "xo_trim.pr_daco_ind as pr_daco_ind",
      "xo_trim.pricing_override_drug as pricing_override_drug",
      "xo_trim.pricing_type as pricing_type",
      "xo_trim.aac_unit_price as aac_unit_price",
      "xo_trim.wac_unit_price as wac_unit_price",
      "xo_trim.prorated_quantity as prorated_quantity",
      "xo_trim.pricing_quantity as pricing_quantity",
      "xo_trim.drug_shape_cd as drug_shape_cd",
      "xo_trim.drug_color_1_cd as drug_color_1_cd",
      "xo_trim.drug_color_2_cd as drug_color_2_cd",
      "xo_trim.drug_side_1 as drug_side_1",
      "xo_trim.drug_side_2 as drug_side_2",
      "xo_trim.billing_ndc as billing_ndc",
      "xo_trim.drug_comment_cd as drug_comment_cd",
      "xo_trim.default_smart_sig as default_smart_sig",
      "xo_trim.drug_location_cd as drug_location_cd",
      "xo_trim.drug_multihit_disp_ind as drug_multihit_disp_ind",
      "xo_trim.substitution_drug_id as substitution_drug_id",
      "xo_trim.drug_volume as drug_volume",
      "xo_trim.precount_ind as precount_ind",
      "xo_trim.precount_qty_1 as precount_qty_1",
      "xo_trim.precount_qty_2 as precount_qty_2",
      "xo_trim.dur_kdc_nbr as dur_kdc_nbr",
      "xo_trim.ud_uu_pkg_cd as ud_uu_pkg_cd",
      "xo_trim.create_user_id as create_user_id",
      "xo_trim.create_dttm as create_dttm",
      "xo_trim.update_user_id as update_user_id",
      "xo_trim.lbl_cmt_cd as lbl_cmt_cd",
      "xo_trim.substitution_prod_type as substitution_prod_type",
      "xo_trim.recon_water_qty as recon_water_qty",
      "xo_trim.drug_spec_cmt_cd as drug_spec_cmt_cd",
      "xo_trim.fax_pbr_cmt_cd as fax_pbr_cmt_cd",
      "xo_trim.promise_sub_drug_id as promise_sub_drug_id",
      "xo_trim.specialty_drug_ind as specialty_drug_ind",
      "xo_trim.piece_weight as piece_weight",
      "xo_trim.stock_bottle_barcode as stock_bottle_barcode",
      "xo_trim.doses_per_pkg as doses_per_pkg",
      "xo_trim.pct_tot_disc_card as pct_tot_disc_card",
      "xo_trim.pet_med_ind as pet_med_ind",
      "xo_trim.ltd_dist_cd as ltd_dist_cd",
      "xo_trim.complicated_supplies_ind as complicated_supplies_ind",
      "xo_trim.specialty_review_ind as specialty_review_ind",
      "xo_trim.clinical_value_ind as clinical_value_ind",
      "xo_trim.required_supplies_ind as required_supplies_ind",
      "xo_trim.hcp_drug_mltht_disp_ind as hcp_drug_mltht_disp_ind",
      "xo_trim.mix_ind as mix_ind",
      "xo_trim.drug_image_file_name as drug_image_file_name",
      "xo_trim.top_drug_ind as top_drug_ind",
      "xo_trim.quality_alert_message as quality_alert_message",
      "xo_trim.quality_alert_keywords as quality_alert_keywords",
      "xo_trim.quality_alert_rule_ind as quality_alert_rule_ind",
      "xo_trim.quality_alert_screen_ind as quality_alert_screen_ind",
      "xo_trim.tip_ind as tip_ind",
      "xo_trim.ref_drug_id as ref_drug_id",
      "xo_trim.hcpc as hcpc",
      "xo_trim.pref_mfr_ind as pref_mfr_ind",
      "xo_trim.med_guide_filename as med_guide_filename",
      "xo_trim.med_guide_ind as med_guide_ind",
      "xo_trim.item_class as item_class",
      "xo_trim.item_group as item_group",
      "xo_trim.item_formulary_ind as item_formulary_ind",
      "xo_trim.item_category as item_category",
      "xo_trim.item_lob as item_lob",
      "xo_trim.item_conv_factor as item_conv_factor",
      "xo_trim.item_list_price_sale as item_list_price_sale",
      "xo_trim.item_retail_price as item_retail_price",
      "xo_trim.item_pum as item_pum",
      "xo_trim.item_sub_group as item_sub_group",
      "xo_trim.item_sub_category as item_sub_category",
      "xo_trim.item_sum as item_sum",
      "xo_trim.specific_gravity as specific_gravity",
      "xo_trim.concentration_nbr as concentration_nbr",
      "xo_trim.concentration_units as concentration_units",
      "xo_trim.lipids_ind as lipids_ind",
      "xo_trim.amino_acid_ind as amino_acid_ind",
      "xo_trim.poolable_ind as poolable_ind",
      "xo_trim.trace_element_ind as trace_element_ind",
      "xo_trim.electrolyte_ind as electrolyte_ind",
      "xo_trim.container_material_cd as container_material_cd",
      "xo_trim.container_max_capacity as container_max_capacity",
      "xo_trim.vehicle_ind as vehicle_ind",
      "xo_trim.vehicle as vehicle",
      "xo_trim.cocktail_ind as cocktail_ind",
      "xo_trim.base_ind as base_ind",
      "xo_trim.item_type as item_type",
      "xo_trim.conc_dextrose_ind as conc_dextrose_ind",
      "xo_trim.container_ind as container_ind",
      "xo_trim.container_type as container_type",
      "xo_trim.plx_drug_ind as plx_drug_ind",
      "xo_trim.item_size as item_size",
      "xo_trim.item_size_units as item_size_units",
      "xo_trim.item_long_desc as item_long_desc",
      "xo_trim.item_short_desc as item_short_desc",
      "xo_trim.item_awp as item_awp",
      "xo_trim.billing_multiplier as billing_multiplier",
      "xo_trim.track_inventory_ind as track_inventory_ind",
      "xo_trim.disease_state_ind as disease_state_ind",
      "xo_trim.drug_inference_cd as drug_inference_cd",
      "xo_trim.drug_min_price as drug_min_price",
      "xo_trim.excl_drug_automation_ind as excl_drug_automation_ind",
      "xo_trim.excl_tbltp_count_ind as excl_tbltp_count_ind",
      "xo_trim.require_tbltp_clean as require_tbltp_clean",
      "xo_trim.thera_class_extd as thera_class_extd",
      "xo_trim.etl_proc_seq_nbr as etl_proc_seq_nbr",
      "xo_trim.hzrds_lvl_cd as hzrds_lvl_cd",
      "xo_trim.auth_generic_cd as auth_generic_cd",
      "xo_trim.fda_ind as fda_ind",
      "xo_trim.fda_ind_value as fda_ind_value",
      "xo_trim.auth_ndc_upc_hri as auth_ndc_upc_hri",
      "xo_trim.auth_gen_override_ind as auth_gen_override_ind",
      "xo_trim.ddid as ddid",
      "xo_trim.rxcui_type as rxcui_type",
      "xo_trim.rxcui as rxcui",
      "xo_trim.elsevier_pack_id as elsevier_pack_id",
      "xo_trim.elsevier_prod_id as elsevier_prod_id",
      "xo_trim.med_dosage_unit as med_dosage_unit",
      "xo_trim.med_conv_factor as med_conv_factor",
      "xo_trim.mme_calc_factor as mme_calc_factor")
def DS_drug_save(df):
    return ctx.saveAsCsv(df,
      path=f"{ctx.pDirDataSetPharmacyHealthcareDrug}/etl_drug_extract.ds",
      header=False,
      delimiter=",",
      updateMode="overwrite",
      rejectMode="continue")

# COMMAND ----------

TDENTR_etl_stg_src_tbl = ctx.dbFrameReader() \
  .option("query", f"""SELECT
 cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,drug_id
,ndc_mfg
,ndc_prod
,ndc_pkg
,sims_upc
,repack_nbr
,ndc_form_cd
,ndc_prev_mfg
,ndc_prev_prod
,ndc_prev_pkg
,prev_repack_nbr
,ndc_prev_form_cd
,id_form_cd
,ndc_upc_hri
,dur_ndc
,prev_ndc_upc_hri
,prev_id_form_cd
,drug_class
,drug_orange_book_rating
,drug_name_cd
,gppc
,gen_typ_cd
,gen_id_no
,thera_class
,lim_stabil
,pack_descr
,rx_otc_cd
,maint_drug_ind
,route_of_admin_cd
,drug_generic_cd
,drug_type_cd
,drug_single_comb_cd
,drug_storage_cond_cd
,TO_TIMESTAMP_NTZ(a_last_change_dttm) as a_last_change_dttm
,a_protect_ind
,product_name
,product_name_suffix
,product_name_ext
,product_mddb_abbr
,TO_TIMESTAMP_NTZ(e_last_change_dttm) as e_last_change_dttm
,e_protect_ind
,gpi
,gpi_name
,TO_TIMESTAMP_NTZ(g_last_change_dttm) as g_last_change_dttm
,g_protect_ind
,mfg_name
,mfg_name_abbr
,mfg_mddb_abbr
,mfg_name_suffix
,TO_TIMESTAMP_NTZ(j_last_change_dttm) as j_last_change_dttm
,j_protect_ind
,drug_strength
,drug_strength_uom
,drug_dosage_form_cd
,package_size
,package_size_uom
,package_qty
,TO_TIMESTAMP_NTZ(rx_to_otc_dttm) as rx_to_otc_dttm
,TO_TIMESTAMP_NTZ(l_last_change_dttm) as l_last_change_dttm
,l_protect_ind
,TO_TIMESTAMP_NTZ(awp_dttm) as awp_dttm 
,drug_counting_cell_id
,awp_unit_price
,TO_TIMESTAMP_NTZ(r_last_change_dttm) as r_last_change_dttm
,r_protect_ind
,TO_TIMESTAMP_NTZ(hcfa_dttm) as hcfa_dttm
,hcfa_unit_limit
,TO_TIMESTAMP_NTZ(t_last_change_dttm) as t_last_change_dttm 
,t_protect_ind
,product_name_abbr
,drug_status_cd
,TO_TIMESTAMP_NTZ(drug_disc_dttm) as drug_disc_dttm 
,mfp_nbr
,wic_nbr
,drug_ppi_ind
,drug_min_disp_qty
,default_sig
,default_days_supply
,expiration_days
,drug_class_except_ind
,ops_study_dept_nbr
,drug_warehouse_ind
,pricing_protect_ind
,pr_daco_ind
,pricing_override_drug
,pricing_type
,aac_unit_price
,wac_unit_price
,prorated_quantity
,pricing_quantity
,drug_shape_cd
,drug_color_1_cd
,drug_color_2_cd
,drug_side_1
,drug_side_2
,billing_ndc
,drug_comment_cd
,default_smart_sig
,drug_location_cd
,drug_multihit_disp_ind
,substitution_drug_id
,drug_volume
,precount_ind
,precount_qty_1
,precount_qty_2
,dur_kdc_nbr
,ud_uu_pkg_cd
,create_user_id
,TO_TIMESTAMP_NTZ(create_dttm) as create_dttm
,update_user_id 
,TO_TIMESTAMP_NTZ(update_dttm) as  update_dttm
,lbl_cmt_cd
,substitution_prod_type
,recon_water_qty
,drug_spec_cmt_cd
,fax_pbr_cmt_cd
,promise_sub_drug_id
,specialty_drug_ind
,cash_disc_qty
,piece_weight
,stock_bottle_barcode
,doses_per_pkg
,pct_tot_disc_card
,pet_med_ind
,ltd_dist_cd
,complicated_supplies_ind
,specialty_review_ind
,clinical_value_ind
,required_supplies_ind
,hcp_drug_mltht_disp_ind
,mix_ind
,drug_image_file_name
,top_drug_ind
,quality_alert_message
,quality_alert_keywords
,quality_alert_rule_ind
,quality_alert_screen_ind
,cash_disc_qty2
,cash_disc_qty3
,tip_ind
,ref_drug_id
,hcpc
,pref_mfr_ind
,med_guide_filename
,med_guide_ind
,item_class
,item_group
,item_formulary_ind
,item_category
,item_lob
,item_conv_factor
,item_list_price_sale
,item_retail_price
,item_pum
,item_sub_group
,item_sub_category
,item_sum
,primary_vendor_item_cost
,primary_vendor_item_nbr
,secndry_vendor_item_cost
,secndry_vendor_item_nbr
,tertry_vendor_item_cost
,tertry_vendor_item_nbr
,specific_gravity
,concentration_nbr
,concentration_units
,lipids_ind
,amino_acid_ind
,poolable_ind
,trace_element_ind
,electrolyte_ind
,container_material_cd
,container_max_capacity
,vehicle_ind
,vehicle
,cocktail_ind
,primary_vendor_nbr
,secondary_vendor_nbr
,tertiary_vendor_nbr
,base_ind
,item_type
,conc_dextrose_ind
,container_ind
,container_type
,primary_vendor_name
,secondary_vendor_name
,tertiary_vendor_name
,plx_drug_ind
,item_size
,item_size_units
,item_long_desc
,item_short_desc
,item_awp
,billing_multiplier
,track_inventory_ind
,disease_state_ind
,drug_inference_cd
,drug_min_price
,excl_drug_automation_ind
,excl_tbltp_count_ind
,require_tbltp_clean
,thera_class_extd
,hzrds_lvl_cd
,auth_generic_cd
,fda_ind
,fda_ind_value
,auth_ndc_upc_hri
,auth_gen_override_ind
,ddid
,rxcui_type
,rxcui
,elsevier_pack_id
,elsevier_prod_id
,med_dosage_unit
,med_conv_factor
,mme_calc_factor
FROM {ctx.DP_DB_STAGING}.DRUG.{ctx.pTDETLStageTable}
""") \
  .load() \
  .select("*")
SCNTNRClnseData_1 = SCNTNRClnseData(TDENTR_etl_stg_src_tbl,
  ctx = ctx,
  pDirReject = f"{ctx.pDirRejectPharmacyHealthcareDrug}",
  pDirSchema = f"{ctx.pDirSchema}",
  pSchemaFile_ETLTBL01 = f"{ctx.pSchemaFile_ETLTBL01}",
  pEdwBatchId = f"{ctx.pEdwBatchId}",
  pDSJobName = f"{ctx.pDSJobName}",
  pDSJobInvocation = f"{ctx.pDSJobInvocation}",
  pTDETLStageTable = f"{ctx.pTDETLStageTable}",
  pTDETLReadSessions = f"{ctx.pTDETLReadSessions}")
scntnro_ext_clnse_etl_src = SCNTNRClnseData_1
SRT_key_cdc = scntnro_ext_clnse_etl_src.alias("scntnro_ext_clnse_etl_src") \
     .sort(asc("drug_id"), asc("cdc_txn_commit_dttm"), asc("cdc_seq_nbr"), asc("cdc_rba_nbr"), asc("cdc_before_after_cd")) \
     .select(col("scntnro_ext_clnse_etl_src.cdc_txn_commit_dttm").alias("cdc_txn_commit_dttm"), col("scntnro_ext_clnse_etl_src.cdc_seq_nbr").alias("cdc_seq_nbr"), col("scntnro_ext_clnse_etl_src.cdc_rba_nbr").alias("cdc_rba_nbr"), col("scntnro_ext_clnse_etl_src.cdc_operation_type_cd").alias("cdc_operation_type_cd"), col("scntnro_ext_clnse_etl_src.cdc_before_after_cd").alias("cdc_before_after_cd"), col("scntnro_ext_clnse_etl_src.cdc_txn_position_cd").alias("cdc_txn_position_cd"), col("scntnro_ext_clnse_etl_src.edw_batch_id").alias("edw_batch_id"), col("scntnro_ext_clnse_etl_src.drug_id").alias("drug_id"), col("scntnro_ext_clnse_etl_src.ndc_mfg").alias("ndc_mfg"), col("scntnro_ext_clnse_etl_src.ndc_prod").alias("ndc_prod"), col("scntnro_ext_clnse_etl_src.ndc_pkg").alias("ndc_pkg"), col("scntnro_ext_clnse_etl_src.sims_upc").alias("sims_upc"), col("scntnro_ext_clnse_etl_src.repack_nbr").alias("repack_nbr"), col("scntnro_ext_clnse_etl_src.ndc_form_cd").alias("ndc_form_cd"), col("scntnro_ext_clnse_etl_src.ndc_prev_mfg").alias("ndc_prev_mfg"), col("scntnro_ext_clnse_etl_src.ndc_prev_prod").alias("ndc_prev_prod"), col("scntnro_ext_clnse_etl_src.ndc_prev_pkg").alias("ndc_prev_pkg"), col("scntnro_ext_clnse_etl_src.prev_repack_nbr").alias("prev_repack_nbr"), col("scntnro_ext_clnse_etl_src.ndc_prev_form_cd").alias("ndc_prev_form_cd"), col("scntnro_ext_clnse_etl_src.id_form_cd").alias("id_form_cd"), col("scntnro_ext_clnse_etl_src.ndc_upc_hri").alias("ndc_upc_hri"), col("scntnro_ext_clnse_etl_src.dur_ndc").alias("dur_ndc"), col("scntnro_ext_clnse_etl_src.prev_ndc_upc_hri").alias("prev_ndc_upc_hri"), col("scntnro_ext_clnse_etl_src.prev_id_form_cd").alias("prev_id_form_cd"), col("scntnro_ext_clnse_etl_src.drug_class").alias("drug_class"), col("scntnro_ext_clnse_etl_src.drug_orange_book_rating").alias("drug_orange_book_rating"), col("scntnro_ext_clnse_etl_src.drug_name_cd").alias("drug_name_cd"), col("scntnro_ext_clnse_etl_src.gppc").alias("gppc"), col("scntnro_ext_clnse_etl_src.gen_typ_cd").alias("gen_typ_cd"), col("scntnro_ext_clnse_etl_src.gen_id_no").alias("gen_id_no"), col("scntnro_ext_clnse_etl_src.thera_class").alias("thera_class"), col("scntnro_ext_clnse_etl_src.lim_stabil").alias("lim_stabil"), col("scntnro_ext_clnse_etl_src.pack_descr").alias("pack_descr"), col("scntnro_ext_clnse_etl_src.rx_otc_cd").alias("rx_otc_cd"), col("scntnro_ext_clnse_etl_src.maint_drug_ind").alias("maint_drug_ind"), col("scntnro_ext_clnse_etl_src.route_of_admin_cd").alias("route_of_admin_cd"), col("scntnro_ext_clnse_etl_src.drug_generic_cd").alias("drug_generic_cd"), col("scntnro_ext_clnse_etl_src.drug_type_cd").alias("drug_type_cd"), col("scntnro_ext_clnse_etl_src.drug_single_comb_cd").alias("drug_single_comb_cd"), col("scntnro_ext_clnse_etl_src.drug_storage_cond_cd").alias("drug_storage_cond_cd"), col("scntnro_ext_clnse_etl_src.a_last_change_dttm").alias("a_last_change_dttm"), col("scntnro_ext_clnse_etl_src.a_protect_ind").alias("a_protect_ind"), col("scntnro_ext_clnse_etl_src.product_name").alias("product_name"), col("scntnro_ext_clnse_etl_src.product_name_suffix").alias("product_name_suffix"), col("scntnro_ext_clnse_etl_src.product_name_ext").alias("product_name_ext"), col("scntnro_ext_clnse_etl_src.product_mddb_abbr").alias("product_mddb_abbr"), col("scntnro_ext_clnse_etl_src.e_last_change_dttm").alias("e_last_change_dttm"), col("scntnro_ext_clnse_etl_src.e_protect_ind").alias("e_protect_ind"), col("scntnro_ext_clnse_etl_src.gpi").alias("gpi"), col("scntnro_ext_clnse_etl_src.gpi_name").alias("gpi_name"), col("scntnro_ext_clnse_etl_src.g_last_change_dttm").alias("g_last_change_dttm"), col("scntnro_ext_clnse_etl_src.g_protect_ind").alias("g_protect_ind"), col("scntnro_ext_clnse_etl_src.mfg_name").alias("mfg_name"), col("scntnro_ext_clnse_etl_src.mfg_name_abbr").alias("mfg_name_abbr"), col("scntnro_ext_clnse_etl_src.mfg_mddb_abbr").alias("mfg_mddb_abbr"), col("scntnro_ext_clnse_etl_src.mfg_name_suffix").alias("mfg_name_suffix"), col("scntnro_ext_clnse_etl_src.j_last_change_dttm").alias("j_last_change_dttm"), col("scntnro_ext_clnse_etl_src.j_protect_ind").alias("j_protect_ind"), col("scntnro_ext_clnse_etl_src.drug_strength").alias("drug_strength"), col("scntnro_ext_clnse_etl_src.drug_strength_uom").alias("drug_strength_uom"), col("scntnro_ext_clnse_etl_src.drug_dosage_form_cd").alias("drug_dosage_form_cd"), col("scntnro_ext_clnse_etl_src.package_size").alias("package_size"), col("scntnro_ext_clnse_etl_src.package_size_uom").alias("package_size_uom"), col("scntnro_ext_clnse_etl_src.package_qty").alias("package_qty"), col("scntnro_ext_clnse_etl_src.rx_to_otc_dttm").alias("rx_to_otc_dttm"), col("scntnro_ext_clnse_etl_src.l_last_change_dttm").alias("l_last_change_dttm"), col("scntnro_ext_clnse_etl_src.l_protect_ind").alias("l_protect_ind"), col("scntnro_ext_clnse_etl_src.awp_dttm").alias("awp_dttm"), col("scntnro_ext_clnse_etl_src.drug_counting_cell_id").alias("drug_counting_cell_id"), col("scntnro_ext_clnse_etl_src.awp_unit_price").alias("awp_unit_price"), col("scntnro_ext_clnse_etl_src.r_last_change_dttm").alias("r_last_change_dttm"), col("scntnro_ext_clnse_etl_src.r_protect_ind").alias("r_protect_ind"), col("scntnro_ext_clnse_etl_src.hcfa_dttm").alias("hcfa_dttm"), col("scntnro_ext_clnse_etl_src.hcfa_unit_limit").alias("hcfa_unit_limit"), col("scntnro_ext_clnse_etl_src.t_last_change_dttm").alias("t_last_change_dttm"), col("scntnro_ext_clnse_etl_src.t_protect_ind").alias("t_protect_ind"), col("scntnro_ext_clnse_etl_src.product_name_abbr").alias("product_name_abbr"), col("scntnro_ext_clnse_etl_src.drug_status_cd").alias("drug_status_cd"), col("scntnro_ext_clnse_etl_src.drug_disc_dttm").alias("drug_disc_dttm"), col("scntnro_ext_clnse_etl_src.mfp_nbr").alias("mfp_nbr"), col("scntnro_ext_clnse_etl_src.wic_nbr").alias("wic_nbr"), col("scntnro_ext_clnse_etl_src.drug_ppi_ind").alias("drug_ppi_ind"), col("scntnro_ext_clnse_etl_src.drug_min_disp_qty").alias("drug_min_disp_qty"), col("scntnro_ext_clnse_etl_src.default_sig").alias("default_sig"), col("scntnro_ext_clnse_etl_src.default_days_supply").alias("default_days_supply"), col("scntnro_ext_clnse_etl_src.expiration_days").alias("expiration_days"), col("scntnro_ext_clnse_etl_src.drug_class_except_ind").alias("drug_class_except_ind"), col("scntnro_ext_clnse_etl_src.ops_study_dept_nbr").alias("ops_study_dept_nbr"), col("scntnro_ext_clnse_etl_src.drug_warehouse_ind").alias("drug_warehouse_ind"), col("scntnro_ext_clnse_etl_src.pricing_protect_ind").alias("pricing_protect_ind"), col("scntnro_ext_clnse_etl_src.pr_daco_ind").alias("pr_daco_ind"), col("scntnro_ext_clnse_etl_src.pricing_override_drug").alias("pricing_override_drug"), col("scntnro_ext_clnse_etl_src.pricing_type").alias("pricing_type"), col("scntnro_ext_clnse_etl_src.aac_unit_price").alias("aac_unit_price"), col("scntnro_ext_clnse_etl_src.wac_unit_price").alias("wac_unit_price"), col("scntnro_ext_clnse_etl_src.prorated_quantity").alias("prorated_quantity"), col("scntnro_ext_clnse_etl_src.pricing_quantity").alias("pricing_quantity"), col("scntnro_ext_clnse_etl_src.drug_shape_cd").alias("drug_shape_cd"), col("scntnro_ext_clnse_etl_src.drug_color_1_cd").alias("drug_color_1_cd"), col("scntnro_ext_clnse_etl_src.drug_color_2_cd").alias("drug_color_2_cd"), col("scntnro_ext_clnse_etl_src.drug_side_1").alias("drug_side_1"), col("scntnro_ext_clnse_etl_src.drug_side_2").alias("drug_side_2"), col("scntnro_ext_clnse_etl_src.billing_ndc").alias("billing_ndc"), col("scntnro_ext_clnse_etl_src.drug_comment_cd").alias("drug_comment_cd"), col("scntnro_ext_clnse_etl_src.default_smart_sig").alias("default_smart_sig"), col("scntnro_ext_clnse_etl_src.drug_location_cd").alias("drug_location_cd"), col("scntnro_ext_clnse_etl_src.drug_multihit_disp_ind").alias("drug_multihit_disp_ind"), col("scntnro_ext_clnse_etl_src.substitution_drug_id").alias("substitution_drug_id"), col("scntnro_ext_clnse_etl_src.drug_volume").alias("drug_volume"), col("scntnro_ext_clnse_etl_src.precount_ind").alias("precount_ind"), col("scntnro_ext_clnse_etl_src.precount_qty_1").alias("precount_qty_1"), col("scntnro_ext_clnse_etl_src.precount_qty_2").alias("precount_qty_2"), col("scntnro_ext_clnse_etl_src.dur_kdc_nbr").alias("dur_kdc_nbr"), col("scntnro_ext_clnse_etl_src.ud_uu_pkg_cd").alias("ud_uu_pkg_cd"), col("scntnro_ext_clnse_etl_src.create_user_id").alias("create_user_id"), col("scntnro_ext_clnse_etl_src.create_dttm").alias("create_dttm"), col("scntnro_ext_clnse_etl_src.update_user_id").alias("update_user_id"), col("scntnro_ext_clnse_etl_src.update_dttm").alias("update_dttm"), col("scntnro_ext_clnse_etl_src.lbl_cmt_cd").alias("lbl_cmt_cd"), col("scntnro_ext_clnse_etl_src.substitution_prod_type").alias("substitution_prod_type"), col("scntnro_ext_clnse_etl_src.recon_water_qty").alias("recon_water_qty"), col("scntnro_ext_clnse_etl_src.drug_spec_cmt_cd").alias("drug_spec_cmt_cd"), col("scntnro_ext_clnse_etl_src.fax_pbr_cmt_cd").alias("fax_pbr_cmt_cd"), col("scntnro_ext_clnse_etl_src.promise_sub_drug_id").alias("promise_sub_drug_id"), col("scntnro_ext_clnse_etl_src.specialty_drug_ind").alias("specialty_drug_ind"), col("scntnro_ext_clnse_etl_src.cash_disc_qty").alias("cash_disc_qty"), col("scntnro_ext_clnse_etl_src.piece_weight").alias("piece_weight"), col("scntnro_ext_clnse_etl_src.stock_bottle_barcode").alias("stock_bottle_barcode"), col("scntnro_ext_clnse_etl_src.doses_per_pkg").alias("doses_per_pkg"), col("scntnro_ext_clnse_etl_src.pct_tot_disc_card").alias("pct_tot_disc_card"), col("scntnro_ext_clnse_etl_src.pet_med_ind").alias("pet_med_ind"), col("scntnro_ext_clnse_etl_src.ltd_dist_cd").alias("ltd_dist_cd"), col("scntnro_ext_clnse_etl_src.complicated_supplies_ind").alias("complicated_supplies_ind"), col("scntnro_ext_clnse_etl_src.specialty_review_ind").alias("specialty_review_ind"), col("scntnro_ext_clnse_etl_src.clinical_value_ind").alias("clinical_value_ind"), col("scntnro_ext_clnse_etl_src.required_supplies_ind").alias("required_supplies_ind"), col("scntnro_ext_clnse_etl_src.hcp_drug_mltht_disp_ind").alias("hcp_drug_mltht_disp_ind"), col("scntnro_ext_clnse_etl_src.mix_ind").alias("mix_ind"), col("scntnro_ext_clnse_etl_src.drug_image_file_name").alias("drug_image_file_name"), col("scntnro_ext_clnse_etl_src.top_drug_ind").alias("top_drug_ind"),
col("scntnro_ext_clnse_etl_src.quality_alert_message").alias("quality_alert_message"), col("scntnro_ext_clnse_etl_src.quality_alert_keywords").alias("quality_alert_keywords"), col("scntnro_ext_clnse_etl_src.quality_alert_rule_ind").alias("quality_alert_rule_ind"), col("scntnro_ext_clnse_etl_src.quality_alert_screen_ind").alias("quality_alert_screen_ind"), col("scntnro_ext_clnse_etl_src.cash_disc_qty2").alias("cash_disc_qty2"), col("scntnro_ext_clnse_etl_src.cash_disc_qty3").alias("cash_disc_qty3"), col("scntnro_ext_clnse_etl_src.tip_ind").alias("tip_ind"), col("scntnro_ext_clnse_etl_src.ref_drug_id").alias("ref_drug_id"), col("scntnro_ext_clnse_etl_src.hcpc").alias("hcpc"), col("scntnro_ext_clnse_etl_src.pref_mfr_ind").alias("pref_mfr_ind"), col("scntnro_ext_clnse_etl_src.med_guide_filename").alias("med_guide_filename"), col("scntnro_ext_clnse_etl_src.med_guide_ind").alias("med_guide_ind"), col("scntnro_ext_clnse_etl_src.item_class").alias("item_class"), col("scntnro_ext_clnse_etl_src.item_group").alias("item_group"), col("scntnro_ext_clnse_etl_src.item_formulary_ind").alias("item_formulary_ind"), col("scntnro_ext_clnse_etl_src.item_category").alias("item_category"), col("scntnro_ext_clnse_etl_src.item_lob").alias("item_lob"), col("scntnro_ext_clnse_etl_src.item_conv_factor").alias("item_conv_factor"), col("scntnro_ext_clnse_etl_src.item_list_price_sale").alias("item_list_price_sale"), col("scntnro_ext_clnse_etl_src.item_retail_price").alias("item_retail_price"), col("scntnro_ext_clnse_etl_src.item_pum").alias("item_pum"), col("scntnro_ext_clnse_etl_src.item_sub_group").alias("item_sub_group"), col("scntnro_ext_clnse_etl_src.item_sub_category").alias("item_sub_category"), col("scntnro_ext_clnse_etl_src.item_sum").alias("item_sum"), col("scntnro_ext_clnse_etl_src.primary_vendor_item_cost").alias("primary_vendor_item_cost"), col("scntnro_ext_clnse_etl_src.primary_vendor_item_nbr").alias("primary_vendor_item_nbr"), col("scntnro_ext_clnse_etl_src.secndry_vendor_item_cost").alias("secndry_vendor_item_cost"), col("scntnro_ext_clnse_etl_src.secndry_vendor_item_nbr").alias("secndry_vendor_item_nbr"), col("scntnro_ext_clnse_etl_src.tertry_vendor_item_cost").alias("tertry_vendor_item_cost"), col("scntnro_ext_clnse_etl_src.tertry_vendor_item_nbr").alias("tertry_vendor_item_nbr"), col("scntnro_ext_clnse_etl_src.specific_gravity").alias("specific_gravity"), col("scntnro_ext_clnse_etl_src.concentration_nbr").alias("concentration_nbr"), col("scntnro_ext_clnse_etl_src.concentration_units").alias("concentration_units"), col("scntnro_ext_clnse_etl_src.lipids_ind").alias("lipids_ind"), col("scntnro_ext_clnse_etl_src.amino_acid_ind").alias("amino_acid_ind"), col("scntnro_ext_clnse_etl_src.poolable_ind").alias("poolable_ind"), col("scntnro_ext_clnse_etl_src.trace_element_ind").alias("trace_element_ind"), col("scntnro_ext_clnse_etl_src.electrolyte_ind").alias("electrolyte_ind"), col("scntnro_ext_clnse_etl_src.container_material_cd").alias("container_material_cd"), col("scntnro_ext_clnse_etl_src.container_max_capacity").alias("container_max_capacity"), col("scntnro_ext_clnse_etl_src.vehicle_ind").alias("vehicle_ind"), col("scntnro_ext_clnse_etl_src.vehicle").alias("vehicle"), col("scntnro_ext_clnse_etl_src.cocktail_ind").alias("cocktail_ind"), col("scntnro_ext_clnse_etl_src.primary_vendor_nbr").alias("primary_vendor_nbr"), col("scntnro_ext_clnse_etl_src.secondary_vendor_nbr").alias("secondary_vendor_nbr"), col("scntnro_ext_clnse_etl_src.tertiary_vendor_nbr").alias("tertiary_vendor_nbr"), col("scntnro_ext_clnse_etl_src.base_ind").alias("base_ind"), col("scntnro_ext_clnse_etl_src.item_type").alias("item_type"), col("scntnro_ext_clnse_etl_src.conc_dextrose_ind").alias("conc_dextrose_ind"), col("scntnro_ext_clnse_etl_src.container_ind").alias("container_ind"), col("scntnro_ext_clnse_etl_src.container_type").alias("container_type"), col("scntnro_ext_clnse_etl_src.primary_vendor_name").alias("primary_vendor_name"), col("scntnro_ext_clnse_etl_src.secondary_vendor_name").alias("secondary_vendor_name"), col("scntnro_ext_clnse_etl_src.tertiary_vendor_name").alias("tertiary_vendor_name"), col("scntnro_ext_clnse_etl_src.plx_drug_ind").alias("plx_drug_ind"), col("scntnro_ext_clnse_etl_src.item_size").alias("item_size"), col("scntnro_ext_clnse_etl_src.item_size_units").alias("item_size_units"), col("scntnro_ext_clnse_etl_src.item_long_desc").alias("item_long_desc"), col("scntnro_ext_clnse_etl_src.item_short_desc").alias("item_short_desc"), col("scntnro_ext_clnse_etl_src.item_awp").alias("item_awp"), col("scntnro_ext_clnse_etl_src.billing_multiplier").alias("billing_multiplier"), col("scntnro_ext_clnse_etl_src.track_inventory_ind").alias("track_inventory_ind"), col("scntnro_ext_clnse_etl_src.disease_state_ind").alias("disease_state_ind"), col("scntnro_ext_clnse_etl_src.drug_inference_cd").alias("drug_inference_cd"), col("scntnro_ext_clnse_etl_src.drug_min_price").alias("drug_min_price"), col("scntnro_ext_clnse_etl_src.excl_drug_automation_ind").alias("excl_drug_automation_ind"), col("scntnro_ext_clnse_etl_src.excl_tbltp_count_ind").alias("excl_tbltp_count_ind"), col("scntnro_ext_clnse_etl_src.require_tbltp_clean").alias("require_tbltp_clean"), col("scntnro_ext_clnse_etl_src.thera_class_extd").alias("thera_class_extd"), col("scntnro_ext_clnse_etl_src.hzrds_lvl_cd").alias("hzrds_lvl_cd"),col("scntnro_ext_clnse_etl_src.auth_generic_cd").alias("auth_generic_cd"),col("scntnro_ext_clnse_etl_src.fda_ind").alias("fda_ind"),col("scntnro_ext_clnse_etl_src.fda_ind_value").alias("fda_ind_value"),col("scntnro_ext_clnse_etl_src.auth_ndc_upc_hri").alias("auth_ndc_upc_hri"),col("scntnro_ext_clnse_etl_src.auth_gen_override_ind").alias("auth_gen_override_ind"),col("scntnro_ext_clnse_etl_src.ddid").alias("ddid"),col("scntnro_ext_clnse_etl_src.rxcui_type").alias("rxcui_type"),col("scntnro_ext_clnse_etl_src.rxcui").alias("rxcui"),col("scntnro_ext_clnse_etl_src.elsevier_pack_id").alias("elsevier_pack_id"),col("scntnro_ext_clnse_etl_src.elsevier_prod_id").alias("elsevier_prod_id"),col("scntnro_ext_clnse_etl_src.med_dosage_unit").alias("med_dosage_unit"),col("scntnro_ext_clnse_etl_src.med_conv_factor").alias("med_conv_factor"),col("scntnro_ext_clnse_etl_src.mme_calc_factor").alias("mme_calc_factor"))


# COMMAND ----------

SKGEN_gen_sk = SKGEN_gen_sk_sequence(SRT_key_cdc)
X_trim = X_trim_df(SKGEN_gen_sk)
cpo_distribute_V0S44P1 = cpo_distribute_V0S44P1_df(X_trim)
DS_drug_save(cpo_distribute_V0S44P1)

# COMMAND ----------

from npspark import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window


ctx = JobContext("drug_ic_xform_drug",
  exprParamStr("APT_CONFIG_FILE", "/usr/local/edw/pharmacy/prod/common/apt/edw_phrm_config_4x4.apt"),
  projParamStr("APT_TERA_SYNC_DATABASE"),
  projParamStr("pDirDataSet"),
  projParamStr("pDirLoadready"),
  projParamStr("pDirReject"),
  projParamStr("pTDServer"),
  projParamStr("pTDUserid"),
  exprParamStr("pTDPassword", "LD;@1KVH=9;>0F6M4:J41KI7B<MMM0U5BUCMkF9dG2U71TG:"),
  projParamStr("pTDStageDB"),
  exprParamStr("pTDStageDrugDB","DEV_STAGING.DRUG"),
  projParamStr("pTDViewDBName"),
  exprParamStr("pTDTargetDrugTable","DRUG"),
  projParamStr("DP_DB_STAGING"),
  projParamStr("DP_DB_PHARMACY_HEALTHCARE"),
  exprParamStr("pTDTargetDrugStagingTable","DRUG"),
  exprParamStr("pTDEDWTargetTable", "drug"),
  exprParamStr("pTDETLReadSessions", "4"),
  exprParamStr("pEdwBatchId", PAR_NB_BATCH_ID),
  exprParamStr("pDSJobName", "drug_ic_xform_drug"),
  exprParamStr("pDSJobInvocation", "NOINVID"))

# COMMAND ----------


def DS_drug_df():
  return ctx.csvFrameReader(
    ignoreBadRecords=True,
    schema=
      StructType()
      .add("cdc_txn_commit_dttm", TimestampType(), True)
      .add("cdc_seq_nbr", IntegerType(), True)
      .add("cdc_rba_nbr", DecimalType(18), True)
      .add("cdc_operation_type_cd", StringType(), True)
      .add("cdc_before_after_cd", StringType(), True)
      .add("edw_dml_ind", StringType(), True)
      .add("edw_batch_id", DecimalType(18), True)
      .add("drug_id", DecimalType(6), False)
      .add("ndc_mfg", StringType(), True)
      .add("ndc_prod", StringType(), True)
      .add("ndc_pkg", StringType(), True)
      .add("sims_upc", StringType(), True)
      .add("repack_nbr", StringType(), True)
      .add("ndc_form_cd", DecimalType(1), True)
      .add("ndc_prev_mfg", StringType(), True)
      .add("ndc_prev_prod", StringType(), True)
      .add("ndc_prev_pkg", StringType(), True)
      .add("prev_repack_nbr", StringType(), True)
      .add("ndc_prev_form_cd", DecimalType(1), True)
      .add("id_form_cd", DecimalType(1), True)
      .add("ndc_upc_hri", StringType(), True)
      .add("dur_ndc", StringType(), True)
      .add("prev_ndc_upc_hri", StringType(), True)
      .add("prev_id_form_cd", DecimalType(1), True)
      .add("drug_class", StringType(), True)
      .add("drug_orange_book_rating", StringType(), True)
      .add("drug_name_cd", StringType(), True)
      .add("gppc", StringType(), True)
      .add("gen_typ_cd", StringType(), True)
      .add("gen_id_no", DecimalType(9), True)
      .add("thera_class", DecimalType(6), True)
      .add("lim_stabil", StringType(), True)
      .add("pack_descr", StringType(), True)
      .add("rx_otc_cd", StringType(), True)
      .add("maint_drug_ind", StringType(), True)
      .add("route_of_admin_cd", StringType(), True)
      .add("drug_generic_cd", StringType(), True)
      .add("drug_type_cd", StringType(), True)
      .add("drug_single_comb_cd", StringType(), True)
      .add("drug_storage_cond_cd", StringType(), True)
      .add("product_name", StringType(), True)
      .add("product_name_suffix", StringType(), True)
      .add("product_name_ext", StringType(), True)
      .add("product_mddb_abbr", StringType(), True)
      .add("gpi", StringType(), True)
      .add("gpi_name", StringType(), True)
      .add("mfg_name", StringType(), True)
      .add("mfg_name_abbr", StringType(), True)
      .add("mfg_mddb_abbr", StringType(), True)
      .add("mfg_name_suffix", StringType(), True)
      .add("drug_strength", DecimalType(13, 5), True)
      .add("drug_strength_uom", StringType(), True)
      .add("drug_dosage_form_cd", StringType(), True)
      .add("package_size", DecimalType(8, 3), True)
      .add("package_size_uom", StringType(), True)
      .add("package_qty", DecimalType(5), True)
      .add("rx_to_otc_dttm", StringType(), True)
      .add("awp_dttm", StringType(), True)
      .add("drug_counting_cell_id", DecimalType(3), True)
      .add("awp_unit_price", DecimalType(10, 5), True)
      .add("hcfa_dttm", StringType(), True)
      .add("hcfa_unit_limit", DecimalType(10, 5), True)
      .add("product_name_abbr", StringType(), True)
      .add("drug_status_cd", StringType(), True)
      .add("drug_disc_dttm", StringType(), True)
      .add("mfp_nbr", StringType(), True)
      .add("wic_nbr", DecimalType(6), True)
      .add("drug_ppi_ind", StringType(), True)
      .add("drug_min_disp_qty", DecimalType(10, 3), True)
      .add("default_sig", StringType(), True)
      .add("default_days_supply", DecimalType(3), True)
      .add("expiration_days", DecimalType(3), True)
      .add("drug_class_except_ind", StringType(), True)
      .add("ops_study_dept_nbr", DecimalType(3), True)
      .add("drug_warehouse_ind", StringType(), True)
      .add("pricing_protect_ind", StringType(), True)
      .add("pr_daco_ind", StringType(), True)
      .add("pricing_override_drug", DecimalType(6), True)
      .add("pricing_type", DecimalType(2), True)
      .add("aac_unit_price", DecimalType(10, 5), True)
      .add("wac_unit_price", DecimalType(10, 5), True)
      .add("prorated_quantity", DecimalType(10, 3), True)
      .add("pricing_quantity", DecimalType(10, 3), True)
      .add("drug_shape_cd", StringType(), True)
      .add("drug_color_1_cd", StringType(), True)
      .add("drug_color_2_cd", StringType(), True)
      .add("drug_side_1", StringType(), True)
      .add("drug_side_2", StringType(), True)
      .add("billing_ndc", StringType(), True)
      .add("drug_comment_cd", StringType(), True)
      .add("default_smart_sig", StringType(), True)
      .add("drug_location_cd", StringType(), True)
      .add("drug_multihit_disp_ind", StringType(), True)
      .add("substitution_drug_id", DecimalType(6), True)
      .add("drug_volume", DecimalType(10, 3), True)
      .add("precount_ind", StringType(), True)
      .add("precount_qty_1", DecimalType(3), True)
      .add("precount_qty_2", DecimalType(3), True)
      .add("dur_kdc_nbr", StringType(), True)
      .add("ud_uu_pkg_cd", StringType(), True)
      .add("create_user_id", DecimalType(9), True)
      .add("create_dttm", StringType(), True)
      .add("update_user_id", DecimalType(9), True)
      .add("lbl_cmt_cd", StringType(), True)
      .add("substitution_prod_type", StringType(), True)
      .add("recon_water_qty", DecimalType(5, 1), True)
      .add("drug_spec_cmt_cd", StringType(), True)
      .add("fax_pbr_cmt_cd", StringType(), True)
      .add("promise_sub_drug_id", DecimalType(6), True)
      .add("specialty_drug_ind", StringType(), True)
      .add("piece_weight", DecimalType(6, 4), True)
      .add("stock_bottle_barcode", StringType(), True)
      .add("doses_per_pkg", DecimalType(5), True)
      .add("pct_tot_disc_card", DecimalType(5, 2), True)
      .add("pet_med_ind", StringType(), True)
      .add("ltd_dist_cd", StringType(), True)
      .add("complicated_supplies_ind", StringType(), True)
      .add("specialty_review_ind", StringType(), True)
      .add("clinical_value_ind", StringType(), True)
      .add("required_supplies_ind", StringType(), True)
      .add("hcp_drug_mltht_disp_ind", StringType(), True)
      .add("mix_ind", StringType(), True)
      .add("drug_image_file_name", StringType(), True)
      .add("top_drug_ind", StringType(), True)
      .add("quality_alert_message", StringType(), True)
      .add("quality_alert_keywords", StringType(), True)
      .add("quality_alert_rule_ind", StringType(), True)
      .add("quality_alert_screen_ind", StringType(), True)
      .add("tip_ind", StringType(), True)
      .add("ref_drug_id", DecimalType(6), True)
      .add("hcpc", StringType(), True)
      .add("pref_mfr_ind", StringType(), True)
      .add("med_guide_filename", StringType(), True)
      .add("med_guide_ind", StringType(), True)
      .add("item_class", DecimalType(12), True)
      .add("item_group", DecimalType(12), True)
      .add("item_formulary_ind", StringType(), True)
      .add("item_category", DecimalType(12), True)
      .add("item_lob", DecimalType(12), True)
      .add("item_conv_factor", DecimalType(18, 4), True)
      .add("item_list_price_sale", DecimalType(12, 2), True)
      .add("item_retail_price", DecimalType(12, 2), True)
      .add("item_pum", DecimalType(12), True)
      .add("item_sub_group", DecimalType(12), True)
      .add("item_sub_category", DecimalType(12), True)
      .add("item_sum", DecimalType(12), True)
      .add("specific_gravity", DecimalType(18, 4), True)
      .add("concentration_nbr", DecimalType(18, 4), True)
      .add("concentration_units", DecimalType(12), True)
      .add("lipids_ind", StringType(), True)
      .add("amino_acid_ind", StringType(), True)
      .add("poolable_ind", StringType(), True)
      .add("trace_element_ind", StringType(), True)
      .add("electrolyte_ind", StringType(), True)
      .add("container_material_cd", DecimalType(12), True)
      .add("container_max_capacity", DecimalType(18, 4), True)
      .add("vehicle_ind", StringType(), True)
      .add("vehicle", DecimalType(12), True)
      .add("cocktail_ind", StringType(), True)
      .add("base_ind", StringType(), True)
      .add("item_type", DecimalType(12), True)
      .add("conc_dextrose_ind", StringType(), True)
      .add("container_ind", StringType(), True)
      .add("container_type", DecimalType(12), True)
      .add("plx_drug_ind", StringType(), True)
      .add("item_size", DecimalType(18, 4), True)
      .add("item_size_units", DecimalType(12), True)
      .add("item_long_desc", StringType(), True)
      .add("item_short_desc", StringType(), True)
      .add("item_awp", DecimalType(16, 6), True)
      .add("billing_multiplier", DecimalType(18, 4), True)
      .add("track_inventory_ind", StringType(), True)
      .add("disease_state_ind", StringType(), True)
      .add("drug_inference_cd", StringType(), True)
      .add("drug_min_price", DecimalType(4, 2), True)
      .add("excl_drug_automation_ind", StringType(), True)
      .add("excl_tbltp_count_ind", StringType(), True)
      .add("require_tbltp_clean", StringType(), True)
      .add("thera_class_extd", StringType(), True)
      .add("etl_proc_seq_nbr", IntegerType(), False)
      .add("hzrds_lvl_cd", StringType(), True)
      .add("auth_generic_cd",StringType(),True)
      .add("fda_ind",StringType(),True)
      .add("fda_ind_value",StringType(),True)
      .add("auth_ndc_upc_hri",StringType(),True)
      .add("auth_gen_override_ind",StringType(),True)
      .add("ddid",StringType(),True)
      .add("rxcui_type",StringType(),True)
      .add("rxcui",StringType(),True)
      .add("elsevier_pack_id",StringType(),True)
      .add("elsevier_prod_id",StringType(),True)
      .add("med_dosage_unit",StringType(),True)
      .add("med_conv_factor",StringType(),True)
      .add("mme_calc_factor",StringType(),True),
    path=[
      f"{ctx.pDirDataSetPharmacyHealthcareDrug}/etl_drug_extract.ds"],
    header=False,
    delimiter=",")
def X_map_to_tgt_df(df):
  return df.alias("fltro_combine_upd_ins").selectExpr(
    "fltro_combine_upd_ins.drug_id as drug_id",
    "fltro_combine_upd_ins.ndc_mfg as ndc_mfgr_nbr",
    "fltro_combine_upd_ins.ndc_prod as ndc_prod_nbr",
    "fltro_combine_upd_ins.ndc_pkg as ndc_pkg_cd",
    "fltro_combine_upd_ins.sims_upc as sims_upc",
    "fltro_combine_upd_ins.repack_nbr as repack_nbr",
    "fltro_combine_upd_ins.ndc_form_cd as ndc_form_cd",
    "fltro_combine_upd_ins.ndc_prev_mfg as prev_ndc_mfgr_nbr",
    "fltro_combine_upd_ins.ndc_prev_prod as prev_ndc_prod_nbr",
    "fltro_combine_upd_ins.ndc_prev_pkg as prev_ndc_pkg_cd",
    "fltro_combine_upd_ins.prev_repack_nbr as prev_repack_nbr",
    "fltro_combine_upd_ins.ndc_prev_form_cd as prev_ndc_form_cd",
    "fltro_combine_upd_ins.id_form_cd as upc_hri_format_cd",
    "fltro_combine_upd_ins.ndc_upc_hri as ndc_upc_hri_nbr",
    "fltro_combine_upd_ins.dur_ndc as dur_ndc",
    "fltro_combine_upd_ins.prev_ndc_upc_hri as prev_ndc_upc_hri_nbr",
    "fltro_combine_upd_ins.prev_id_form_cd as prev_upc_hri_format_cd",
    "fltro_combine_upd_ins.drug_class as dea_class_cd",
    "fltro_combine_upd_ins.drug_orange_book_rating as orange_book_rating",
    "fltro_combine_upd_ins.drug_name_cd as drug_name_cd",
    "fltro_combine_upd_ins.gppc as generic_prod_pkg_cd",
    "fltro_combine_upd_ins.gen_typ_cd as generic_id_type_cd",
    "fltro_combine_upd_ins.gen_id_no as generic_ingrd_id",
    "fltro_combine_upd_ins.thera_class as ahfscc_therapeutic_class_cd",
    "fltro_combine_upd_ins.lim_stabil as limit_stability_cd",
    "fltro_combine_upd_ins.pack_descr as pkg_desc",
    "fltro_combine_upd_ins.rx_otc_cd as rx_otc_cd",
    "fltro_combine_upd_ins.maint_drug_ind as maint_drug_ind",
    "fltro_combine_upd_ins.route_of_admin_cd as route_admin",
    "fltro_combine_upd_ins.drug_generic_cd as generic_drug_cd",
    "fltro_combine_upd_ins.drug_type_cd as drug_type_cd",
    "fltro_combine_upd_ins.drug_single_comb_cd as drug_single_combine_cd",
    "fltro_combine_upd_ins.drug_storage_cond_cd as drug_storage_cd",
    "fltro_combine_upd_ins.product_name as prod_name",
    "fltro_combine_upd_ins.product_name_suffix as prod_name_suffix",
    "fltro_combine_upd_ins.product_name_ext as prod_name_extn",
    "fltro_combine_upd_ins.product_mddb_abbr as prod_name_medispan_abbr",
    "fltro_combine_upd_ins.gpi as generic_prod_id",
    "fltro_combine_upd_ins.gpi_name as generic_prod_id_name",
    "fltro_combine_upd_ins.mfg_name as mfgr_name",
    "fltro_combine_upd_ins.mfg_name_abbr as mfgr_name_abbr",
    "fltro_combine_upd_ins.mfg_mddb_abbr as medispan_mfgr_name_abbr",
    "fltro_combine_upd_ins.mfg_name_suffix as mfgr_name_suffix",
    "fltro_combine_upd_ins.drug_strength as drug_strength",
    "fltro_combine_upd_ins.drug_strength_uom as drug_strength_uom",
    "fltro_combine_upd_ins.drug_dosage_form_cd as dosage_form_cd",
    "fltro_combine_upd_ins.package_size as pkg_sz",
    "fltro_combine_upd_ins.package_size_uom as pkg_sz_uom",
    "fltro_combine_upd_ins.package_qty as pkg_qty",
    " if(IsNull(fltro_combine_upd_ins.rx_to_otc_dttm), fltro_combine_upd_ins.rx_to_otc_dttm, to_date(substring(fltro_combine_upd_ins.rx_to_otc_dttm, 1, 10))) as rx_to_otc_dt",
    "fltro_combine_upd_ins.awp_unit_price as awp_per_unit_dlrs",
    "fltro_combine_upd_ins.drug_counting_cell_id as drug_cnt_cell_id",
    " if(IsNull(fltro_combine_upd_ins.awp_dttm), fltro_combine_upd_ins.awp_dttm, to_date(substring(fltro_combine_upd_ins.awp_dttm, 1, 10))) as awp_dt",
    " if(IsNull(fltro_combine_upd_ins.hcfa_dttm), fltro_combine_upd_ins.hcfa_dttm, to_date(substring(fltro_combine_upd_ins.hcfa_dttm, 1, 10))) as hcfa_ffp_limit_eff_dt",
    "fltro_combine_upd_ins.hcfa_unit_limit as hcfa_ffp_limit_dlrs",
    "fltro_combine_upd_ins.product_name_abbr as prod_name_abbr",
    "fltro_combine_upd_ins.drug_status_cd as drug_stat_cd",
    " if(IsNull(fltro_combine_upd_ins.drug_disc_dttm), fltro_combine_upd_ins.drug_disc_dttm, to_date(substring(fltro_combine_upd_ins.drug_disc_dttm, 1, 10))) as drug_discontinue_dt",
    "fltro_combine_upd_ins.mfp_nbr as most_freq_prescribed_nbr",
    "fltro_combine_upd_ins.wic_nbr as wic_nbr",
    "fltro_combine_upd_ins.drug_ppi_ind as pat_pkg_insert_ind",
    "fltro_combine_upd_ins.drug_min_disp_qty as min_dspnsbl_metric_qty",
    "fltro_combine_upd_ins.default_sig as default_sig",
    "fltro_combine_upd_ins.default_days_supply as default_day_supply",
    "fltro_combine_upd_ins.expiration_days as drug_expire_day",
    "fltro_combine_upd_ins.drug_class_except_ind as drug_class_excpn_ind",
    "fltro_combine_upd_ins.ops_study_dept_nbr as ops_study_dept_nbr",
    "fltro_combine_upd_ins.drug_warehouse_ind as drug_whse_ind",
    "fltro_combine_upd_ins.pricing_protect_ind as price_protect_ind",
    "fltro_combine_upd_ins.pr_daco_ind as puerto_rico_drug_ind",
    "fltro_combine_upd_ins.pricing_override_drug as price_override_drug_id",
    "fltro_combine_upd_ins.pricing_type as price_type",
    "fltro_combine_upd_ins.aac_unit_price as aac_per_unit_dlrs",
    "fltro_combine_upd_ins.wac_unit_price as wac_per_unit_dlrs",
    "fltro_combine_upd_ins.prorated_quantity as prorated_qty",
    "fltro_combine_upd_ins.pricing_quantity as price_qty",
    "fltro_combine_upd_ins.drug_shape_cd as drug_shape_cd",
    "fltro_combine_upd_ins.drug_color_1_cd as primary_color_cd",
    "fltro_combine_upd_ins.drug_color_2_cd as secondary_color_cd",
    "fltro_combine_upd_ins.drug_side_1 as drug_side_1_id",
    "fltro_combine_upd_ins.drug_side_2 as drug_side_2_id",
    "fltro_combine_upd_ins.billing_ndc as bill_ndc",
    "fltro_combine_upd_ins.drug_comment_cd as drug_cmnt_cd",
    "fltro_combine_upd_ins.default_smart_sig as default_smart_sig_cd",
    "fltro_combine_upd_ins.drug_location_cd as drug_loc_cd",
    "fltro_combine_upd_ins.drug_multihit_disp_ind as drug_multihit_display_ind",
    "fltro_combine_upd_ins.substitution_drug_id as substn_drug_id",
    "fltro_combine_upd_ins.substitution_prod_type as substn_prod_type",
    "fltro_combine_upd_ins.drug_volume as drug_volume",
    "fltro_combine_upd_ins.precount_ind as precount_qty_ind",
    "fltro_combine_upd_ins.precount_qty_1 as precount_qty_1",
    "fltro_combine_upd_ins.precount_qty_2 as precount_qty_2",
    "fltro_combine_upd_ins.dur_kdc_nbr as dur_knowledge_base_drug_cd",
    "fltro_combine_upd_ins.ud_uu_pkg_cd as unit_dose_unit_of_use_cd",
    "fltro_combine_upd_ins.lbl_cmt_cd as label_cmnt_cd",
    "fltro_combine_upd_ins.recon_water_qty as reconstitute_water_qty",
    "fltro_combine_upd_ins.drug_spec_cmt_cd as drug_spcl_cmnt_cd",
    "fltro_combine_upd_ins.fax_pbr_cmt_cd as fax_pbr_cmnt_cd",
    "fltro_combine_upd_ins.promise_sub_drug_id as promise_substn_drug_id",
    "fltro_combine_upd_ins.specialty_drug_ind as spclty_drug_ind",
    "fltro_combine_upd_ins.piece_weight as piece_weight",
    "fltro_combine_upd_ins.stock_bottle_barcode as stock_bottle_barcode",
    "fltro_combine_upd_ins.doses_per_pkg as dose_per_pkg",
    "fltro_combine_upd_ins.pct_tot_disc_card as tot_discnt_card_pct",
    "fltro_combine_upd_ins.pet_med_ind as pet_drug_ind",
    "fltro_combine_upd_ins.ltd_dist_cd as limit_dstrb_cd",
    "fltro_combine_upd_ins.complicated_supplies_ind as complicate_supplies_ind",
    "fltro_combine_upd_ins.specialty_review_ind as spclty_review_ind",
    "fltro_combine_upd_ins.clinical_value_ind as clinical_val_ind",
    "fltro_combine_upd_ins.required_supplies_ind as req_supplies_ind",
    "fltro_combine_upd_ins.hcp_drug_mltht_disp_ind as mail_drug_multihit_display_ind",
    "fltro_combine_upd_ins.mix_ind as mixed_ind",
    "fltro_combine_upd_ins.drug_image_file_name as drug_image_filename",
    "fltro_combine_upd_ins.top_drug_ind as top_drug_image_ind",
    "fltro_combine_upd_ins.quality_alert_message as quality_alert_msg",
    "fltro_combine_upd_ins.quality_alert_keywords as quality_alert_keyword",
    "fltro_combine_upd_ins.quality_alert_rule_ind as quality_alert_rule_ind",
    "fltro_combine_upd_ins.quality_alert_screen_ind as quality_alert_screen_ind",
    "fltro_combine_upd_ins.tip_ind as tip_ind",
    "fltro_combine_upd_ins.ref_drug_id as ref_drug_id",
    "fltro_combine_upd_ins.hcpc as hc_proc_cd",
    "fltro_combine_upd_ins.pref_mfr_ind as preferred_mfgr_drug_ind",
    "fltro_combine_upd_ins.med_guide_filename as med_guide_filename",
    "fltro_combine_upd_ins.med_guide_ind as med_guide_print_ind",
    "fltro_combine_upd_ins.item_class as item_class",
    "fltro_combine_upd_ins.item_formulary_ind as item_formulary_ind",
    "fltro_combine_upd_ins.item_lob as item_lob",
    "fltro_combine_upd_ins.item_conv_factor as item_conv_factor",
    "fltro_combine_upd_ins.item_list_price_sale as item_list_price_dlrs",
    "fltro_combine_upd_ins.item_retail_price as item_rtl_price_dlrs",
    "fltro_combine_upd_ins.item_pum as item_prch_uom",
    "fltro_combine_upd_ins.item_sum as item_selling_uom",
    "fltro_combine_upd_ins.specific_gravity as specific_gravity",
    "fltro_combine_upd_ins.concentration_nbr as conc_nbr",
    "fltro_combine_upd_ins.concentration_units as drug_item_conc_unit_cd",
    "fltro_combine_upd_ins.lipids_ind as lipids_ind",
    "fltro_combine_upd_ins.amino_acid_ind as amino_acid_ind",
    "fltro_combine_upd_ins.poolable_ind as poolable_ind",
    "fltro_combine_upd_ins.trace_element_ind as trace_element_ind",
    "fltro_combine_upd_ins.electrolyte_ind as electrolyte_ind",
    "fltro_combine_upd_ins.container_material_cd as contnr_material_cd",
    "fltro_combine_upd_ins.container_max_capacity as contnr_max_capacity",
    "fltro_combine_upd_ins.vehicle_ind as drug_vehicle_method_ind",
    "fltro_combine_upd_ins.vehicle as drug_vehicle_method",
    "fltro_combine_upd_ins.cocktail_ind as cocktail_ind",
    "fltro_combine_upd_ins.base_ind as base_ind",
    "fltro_combine_upd_ins.item_type as item_type_cd",
    "fltro_combine_upd_ins.conc_dextrose_ind as conc_dextrose_ind",
    "fltro_combine_upd_ins.container_ind as contnr_ind",
    "fltro_combine_upd_ins.container_type as contnr_type",
    "fltro_combine_upd_ins.plx_drug_ind as plx_drug_use_ind",
    "fltro_combine_upd_ins.item_size as item_pkg_sz",
    "fltro_combine_upd_ins.item_size_units as item_pkg_sz_uom",
    "fltro_combine_upd_ins.item_long_desc as item_full_name",
    "fltro_combine_upd_ins.item_short_desc as item_short_name",
    "fltro_combine_upd_ins.item_awp as item_awp_dlrs",
    "fltro_combine_upd_ins.billing_multiplier as item_bill_factor",
    "fltro_combine_upd_ins.disease_state_ind as drug_disease_type_cd",
    "fltro_combine_upd_ins.item_sub_category as item_drug_sub_catg",
    "fltro_combine_upd_ins.item_category as item_drug_catg",
    "fltro_combine_upd_ins.item_sub_group as item_drug_sub_grp",
    "fltro_combine_upd_ins.item_group as item_drug_grp",
    "date(fltro_combine_upd_ins.cdc_txn_commit_dttm) as src_eff_dt",
    "date_format(fltro_combine_upd_ins.cdc_txn_commit_dttm, 'HH:mm:ss') as src_eff_tm",
    "fltro_combine_upd_ins.create_user_id as src_create_user_id",
    "fltro_combine_upd_ins.update_user_id as src_update_user_id",
    "null as src_end_dt",
    "null as src_end_tm",
    "fltro_combine_upd_ins.edw_batch_id as edw_batch_id",
    "fltro_combine_upd_ins.track_inventory_ind as track_inv_ind",
    "to_timestamp(fltro_combine_upd_ins.create_dttm) as src_create_dttm",
    "-1 as history_seq_nbr",
    "null as history_seq_cd",
    "fltro_combine_upd_ins.drug_inference_cd as inferred_drug_ind",
    "fltro_combine_upd_ins.drug_min_price as min_drug_price_dlrs",
    "fltro_combine_upd_ins.excl_drug_automation_ind as excl_drug_auto_rcmd_ind",
    "fltro_combine_upd_ins.excl_tbltp_count_ind as excl_tbltop_cnt_ind",
    "fltro_combine_upd_ins.require_tbltp_clean as require_tbltop_clean_ind",
    "fltro_combine_upd_ins.thera_class_extd as ahfs_extend_therapeutic_class_cd",
    "fltro_combine_upd_ins.hzrds_lvl_cd as hzrds_lvl_cd",
    "fltro_combine_upd_ins.auth_generic_cd as auth_generic_cd",
    "fltro_combine_upd_ins.fda_ind as fda_ind",
    "fltro_combine_upd_ins.fda_ind_value as fda_ind_value",
    "fltro_combine_upd_ins.auth_ndc_upc_hri as auth_ndc_upc_hri",
    "fltro_combine_upd_ins.auth_gen_override_ind as auth_gen_override_ind",
    "fltro_combine_upd_ins.ddid as ddid",
    "fltro_combine_upd_ins.rxcui_type as rxcui_type",
    "fltro_combine_upd_ins.rxcui as rxcui",
    "fltro_combine_upd_ins.elsevier_pack_id as elsevier_pack_id",
    "fltro_combine_upd_ins.elsevier_prod_id as elsevier_prod_id",
    "fltro_combine_upd_ins.med_dosage_unit as med_dosage_unit",
    "fltro_combine_upd_ins.med_conv_factor as med_conv_factor",
    "fltro_combine_upd_ins.mme_calc_factor as mme_calc_factor",
    "fltro_combine_upd_ins.edw_dml_ind as edw_dml_ind",
    "fltro_combine_upd_ins.etl_proc_seq_nbr as etl_proc_seq_nbr")
def X_enddt_histseqcd_df(df):
  return df.alias("srto_add_cluster_key_chng").selectExpr(
    "srto_add_cluster_key_chng.drug_id as drug_id",
    "srto_add_cluster_key_chng.ndc_mfgr_nbr as ndc_mfgr_nbr",
    "srto_add_cluster_key_chng.ndc_prod_nbr as ndc_prod_nbr",
    "srto_add_cluster_key_chng.ndc_pkg_cd as ndc_pkg_cd",
    "srto_add_cluster_key_chng.sims_upc as sims_upc",
    "srto_add_cluster_key_chng.repack_nbr as repack_nbr",
    "srto_add_cluster_key_chng.ndc_form_cd as ndc_form_cd",
    "srto_add_cluster_key_chng.prev_ndc_mfgr_nbr as prev_ndc_mfgr_nbr",
    "srto_add_cluster_key_chng.prev_ndc_prod_nbr as prev_ndc_prod_nbr",
    "srto_add_cluster_key_chng.prev_ndc_pkg_cd as prev_ndc_pkg_cd",
    "srto_add_cluster_key_chng.prev_repack_nbr as prev_repack_nbr",
    "srto_add_cluster_key_chng.prev_ndc_form_cd as prev_ndc_form_cd",
    "srto_add_cluster_key_chng.upc_hri_format_cd as upc_hri_format_cd",
    "srto_add_cluster_key_chng.ndc_upc_hri_nbr as ndc_upc_hri_nbr",
    "srto_add_cluster_key_chng.dur_ndc as dur_ndc",
    "srto_add_cluster_key_chng.prev_ndc_upc_hri_nbr as prev_ndc_upc_hri_nbr",
    "srto_add_cluster_key_chng.prev_upc_hri_format_cd as prev_upc_hri_format_cd",
    "srto_add_cluster_key_chng.dea_class_cd as dea_class_cd",
    "srto_add_cluster_key_chng.orange_book_rating as orange_book_rating",
    "srto_add_cluster_key_chng.drug_name_cd as drug_name_cd",
    "srto_add_cluster_key_chng.generic_prod_pkg_cd as generic_prod_pkg_cd",
    "srto_add_cluster_key_chng.generic_id_type_cd as generic_id_type_cd",
    "srto_add_cluster_key_chng.generic_ingrd_id as generic_ingrd_id",
    "srto_add_cluster_key_chng.ahfscc_therapeutic_class_cd as ahfscc_therapeutic_class_cd",
    "srto_add_cluster_key_chng.limit_stability_cd as limit_stability_cd",
    "srto_add_cluster_key_chng.pkg_desc as pkg_desc",
    "srto_add_cluster_key_chng.rx_otc_cd as rx_otc_cd",
    "srto_add_cluster_key_chng.maint_drug_ind as maint_drug_ind",
    "srto_add_cluster_key_chng.route_admin as route_admin",
    "srto_add_cluster_key_chng.generic_drug_cd as generic_drug_cd",
    "srto_add_cluster_key_chng.drug_type_cd as drug_type_cd",
    "srto_add_cluster_key_chng.drug_single_combine_cd as drug_single_combine_cd",
    "srto_add_cluster_key_chng.drug_storage_cd as drug_storage_cd",
    "srto_add_cluster_key_chng.prod_name as prod_name",
    "srto_add_cluster_key_chng.prod_name_suffix as prod_name_suffix",
    "srto_add_cluster_key_chng.prod_name_extn as prod_name_extn",
    "srto_add_cluster_key_chng.prod_name_medispan_abbr as prod_name_medispan_abbr",
    "srto_add_cluster_key_chng.generic_prod_id as generic_prod_id",
    "srto_add_cluster_key_chng.generic_prod_id_name as generic_prod_id_name",
    "srto_add_cluster_key_chng.mfgr_name as mfgr_name",
    "srto_add_cluster_key_chng.mfgr_name_abbr as mfgr_name_abbr",
    "srto_add_cluster_key_chng.medispan_mfgr_name_abbr as medispan_mfgr_name_abbr",
    "srto_add_cluster_key_chng.mfgr_name_suffix as mfgr_name_suffix",
    "srto_add_cluster_key_chng.drug_strength as drug_strength",
    "srto_add_cluster_key_chng.drug_strength_uom as drug_strength_uom",
    "srto_add_cluster_key_chng.dosage_form_cd as dosage_form_cd",
    "srto_add_cluster_key_chng.pkg_sz as pkg_sz",
    "srto_add_cluster_key_chng.pkg_sz_uom as pkg_sz_uom",
    "srto_add_cluster_key_chng.pkg_qty as pkg_qty",
    "srto_add_cluster_key_chng.rx_to_otc_dt as rx_to_otc_dt",
    "srto_add_cluster_key_chng.awp_per_unit_dlrs as awp_per_unit_dlrs",
    "srto_add_cluster_key_chng.drug_cnt_cell_id as drug_cnt_cell_id",
    "srto_add_cluster_key_chng.awp_dt as awp_dt",
    "srto_add_cluster_key_chng.hcfa_ffp_limit_eff_dt as hcfa_ffp_limit_eff_dt",
    "srto_add_cluster_key_chng.hcfa_ffp_limit_dlrs as hcfa_ffp_limit_dlrs",
    "srto_add_cluster_key_chng.prod_name_abbr as prod_name_abbr",
    "srto_add_cluster_key_chng.drug_stat_cd as drug_stat_cd",
    "srto_add_cluster_key_chng.drug_discontinue_dt as drug_discontinue_dt",
    "srto_add_cluster_key_chng.most_freq_prescribed_nbr as most_freq_prescribed_nbr",
    "srto_add_cluster_key_chng.wic_nbr as wic_nbr",
    "srto_add_cluster_key_chng.pat_pkg_insert_ind as pat_pkg_insert_ind",
    "srto_add_cluster_key_chng.min_dspnsbl_metric_qty as min_dspnsbl_metric_qty",
    "srto_add_cluster_key_chng.default_sig as default_sig",
    "srto_add_cluster_key_chng.default_day_supply as default_day_supply",
    "srto_add_cluster_key_chng.drug_expire_day as drug_expire_day",
    "srto_add_cluster_key_chng.drug_class_excpn_ind as drug_class_excpn_ind",
    "srto_add_cluster_key_chng.ops_study_dept_nbr as ops_study_dept_nbr",
    "srto_add_cluster_key_chng.drug_whse_ind as drug_whse_ind",
    "srto_add_cluster_key_chng.price_protect_ind as price_protect_ind",
    "srto_add_cluster_key_chng.puerto_rico_drug_ind as puerto_rico_drug_ind",
    "srto_add_cluster_key_chng.price_override_drug_id as price_override_drug_id",
    "srto_add_cluster_key_chng.price_type as price_type",
    "srto_add_cluster_key_chng.aac_per_unit_dlrs as aac_per_unit_dlrs",
    "srto_add_cluster_key_chng.wac_per_unit_dlrs as wac_per_unit_dlrs",
    "srto_add_cluster_key_chng.prorated_qty as prorated_qty",
    "srto_add_cluster_key_chng.price_qty as price_qty",
    "srto_add_cluster_key_chng.drug_shape_cd as drug_shape_cd",
    "srto_add_cluster_key_chng.primary_color_cd as primary_color_cd",
    "srto_add_cluster_key_chng.secondary_color_cd as secondary_color_cd",
    "srto_add_cluster_key_chng.drug_side_1_id as drug_side_1_id",
    "srto_add_cluster_key_chng.drug_side_2_id as drug_side_2_id",
    "srto_add_cluster_key_chng.bill_ndc as bill_ndc",
    "srto_add_cluster_key_chng.drug_cmnt_cd as drug_cmnt_cd",
    "srto_add_cluster_key_chng.default_smart_sig_cd as default_smart_sig_cd",
    "srto_add_cluster_key_chng.drug_loc_cd as drug_loc_cd",
    "srto_add_cluster_key_chng.drug_multihit_display_ind as drug_multihit_display_ind",
    "srto_add_cluster_key_chng.substn_drug_id as substn_drug_id",
    "srto_add_cluster_key_chng.substn_prod_type as substn_prod_type",
    "srto_add_cluster_key_chng.drug_volume as drug_volume",
    "srto_add_cluster_key_chng.precount_qty_ind as precount_qty_ind",
    "srto_add_cluster_key_chng.precount_qty_1 as precount_qty_1",
    "srto_add_cluster_key_chng.precount_qty_2 as precount_qty_2",
    "srto_add_cluster_key_chng.dur_knowledge_base_drug_cd as dur_knowledge_base_drug_cd",
    "srto_add_cluster_key_chng.unit_dose_unit_of_use_cd as unit_dose_unit_of_use_cd",
    "srto_add_cluster_key_chng.label_cmnt_cd as label_cmnt_cd",
    "srto_add_cluster_key_chng.reconstitute_water_qty as reconstitute_water_qty",
    "srto_add_cluster_key_chng.drug_spcl_cmnt_cd as drug_spcl_cmnt_cd",
    "srto_add_cluster_key_chng.fax_pbr_cmnt_cd as fax_pbr_cmnt_cd",
    "srto_add_cluster_key_chng.promise_substn_drug_id as promise_substn_drug_id",
    "srto_add_cluster_key_chng.spclty_drug_ind as spclty_drug_ind",
    "srto_add_cluster_key_chng.piece_weight as piece_weight",
    "srto_add_cluster_key_chng.stock_bottle_barcode as stock_bottle_barcode",
    "srto_add_cluster_key_chng.dose_per_pkg as dose_per_pkg",
    "srto_add_cluster_key_chng.tot_discnt_card_pct as tot_discnt_card_pct",
    "srto_add_cluster_key_chng.pet_drug_ind as pet_drug_ind",
    "srto_add_cluster_key_chng.limit_dstrb_cd as limit_dstrb_cd",
    "srto_add_cluster_key_chng.complicate_supplies_ind as complicate_supplies_ind",
    "srto_add_cluster_key_chng.spclty_review_ind as spclty_review_ind",
    "srto_add_cluster_key_chng.clinical_val_ind as clinical_val_ind",
    "srto_add_cluster_key_chng.req_supplies_ind as req_supplies_ind",
    "srto_add_cluster_key_chng.mail_drug_multihit_display_ind as mail_drug_multihit_display_ind",
    "srto_add_cluster_key_chng.mixed_ind as mixed_ind",
    "srto_add_cluster_key_chng.drug_image_filename as drug_image_filename",
    "srto_add_cluster_key_chng.top_drug_image_ind as top_drug_image_ind",
    "srto_add_cluster_key_chng.quality_alert_msg as quality_alert_msg",
    "srto_add_cluster_key_chng.quality_alert_keyword as quality_alert_keyword",
    "srto_add_cluster_key_chng.quality_alert_rule_ind as quality_alert_rule_ind",
    "srto_add_cluster_key_chng.quality_alert_screen_ind as quality_alert_screen_ind",
    "srto_add_cluster_key_chng.tip_ind as tip_ind",
    "srto_add_cluster_key_chng.ref_drug_id as ref_drug_id",
    "srto_add_cluster_key_chng.hc_proc_cd as hc_proc_cd",
    "srto_add_cluster_key_chng.preferred_mfgr_drug_ind as preferred_mfgr_drug_ind",
    "srto_add_cluster_key_chng.med_guide_filename as med_guide_filename",
    "srto_add_cluster_key_chng.med_guide_print_ind as med_guide_print_ind",
    "srto_add_cluster_key_chng.item_class as item_class",
    "srto_add_cluster_key_chng.item_formulary_ind as item_formulary_ind",
    "srto_add_cluster_key_chng.item_lob as item_lob",
    "srto_add_cluster_key_chng.item_conv_factor as item_conv_factor",
    "srto_add_cluster_key_chng.item_list_price_dlrs as item_list_price_dlrs",
    "srto_add_cluster_key_chng.item_rtl_price_dlrs as item_rtl_price_dlrs",
    "srto_add_cluster_key_chng.item_prch_uom as item_prch_uom",
    "srto_add_cluster_key_chng.item_selling_uom as item_selling_uom",
    "srto_add_cluster_key_chng.specific_gravity as specific_gravity",
    "srto_add_cluster_key_chng.conc_nbr as conc_nbr",
    "srto_add_cluster_key_chng.drug_item_conc_unit_cd as drug_item_conc_unit_cd",
    "srto_add_cluster_key_chng.lipids_ind as lipids_ind",
    "srto_add_cluster_key_chng.amino_acid_ind as amino_acid_ind",
    "srto_add_cluster_key_chng.poolable_ind as poolable_ind",
    "srto_add_cluster_key_chng.trace_element_ind as trace_element_ind",
    "srto_add_cluster_key_chng.electrolyte_ind as electrolyte_ind",
    "srto_add_cluster_key_chng.contnr_material_cd as contnr_material_cd",
    "srto_add_cluster_key_chng.contnr_max_capacity as contnr_max_capacity",
    "srto_add_cluster_key_chng.drug_vehicle_method_ind as drug_vehicle_method_ind",
    "srto_add_cluster_key_chng.drug_vehicle_method as drug_vehicle_method",
    "srto_add_cluster_key_chng.cocktail_ind as cocktail_ind",
    "srto_add_cluster_key_chng.base_ind as base_ind",
    "srto_add_cluster_key_chng.item_type_cd as item_type_cd",
    "srto_add_cluster_key_chng.conc_dextrose_ind as conc_dextrose_ind",
    "srto_add_cluster_key_chng.contnr_ind as contnr_ind",
    "srto_add_cluster_key_chng.contnr_type as contnr_type",
    "srto_add_cluster_key_chng.plx_drug_use_ind as plx_drug_use_ind",
    "srto_add_cluster_key_chng.item_pkg_sz as item_pkg_sz",
    "srto_add_cluster_key_chng.item_pkg_sz_uom as item_pkg_sz_uom",
    "srto_add_cluster_key_chng.item_full_name as item_full_name",
    "srto_add_cluster_key_chng.item_short_name as item_short_name",
    "srto_add_cluster_key_chng.item_awp_dlrs as item_awp_dlrs",
    "srto_add_cluster_key_chng.item_bill_factor as item_bill_factor",
    "srto_add_cluster_key_chng.drug_disease_type_cd as drug_disease_type_cd",
    "srto_add_cluster_key_chng.item_drug_sub_catg as item_drug_sub_catg",
    "srto_add_cluster_key_chng.item_drug_catg as item_drug_catg",
    "srto_add_cluster_key_chng.item_drug_sub_grp as item_drug_sub_grp",
    "srto_add_cluster_key_chng.item_drug_grp as item_drug_grp",
    "srto_add_cluster_key_chng.src_eff_dt as src_eff_dt",
    "srto_add_cluster_key_chng.src_eff_tm as src_eff_tm",
    "srto_add_cluster_key_chng.src_create_user_id as src_create_user_id",
    "srto_add_cluster_key_chng.src_update_user_id as src_update_user_id",
    "case when srto_add_cluster_key_chng.clusterKeyChange = 0 THEN SrcEndDt else null end as src_end_dt",
    "case when srto_add_cluster_key_chng.clusterKeyChange = 0 THEN SrcEndTm else null end as src_end_tm",
    "srto_add_cluster_key_chng.edw_batch_id as edw_batch_id",
    "srto_add_cluster_key_chng.track_inv_ind as track_inv_ind",
    "srto_add_cluster_key_chng.src_create_dttm as src_create_dttm",
    "srto_add_cluster_key_chng.history_seq_nbr as history_seq_nbr",
    "srto_add_cluster_key_chng.HistSeqCd as history_seq_cd",
    "srto_add_cluster_key_chng.inferred_drug_ind as inferred_drug_ind",
    "srto_add_cluster_key_chng.min_drug_price_dlrs as min_drug_price_dlrs",
    "srto_add_cluster_key_chng.excl_drug_auto_rcmd_ind as excl_drug_auto_rcmd_ind",
    "srto_add_cluster_key_chng.excl_tbltop_cnt_ind as excl_tbltop_cnt_ind",
    "srto_add_cluster_key_chng.require_tbltop_clean_ind as require_tbltop_clean_ind",
    "srto_add_cluster_key_chng.ahfs_extend_therapeutic_class_cd as ahfs_extend_therapeutic_class_cd",
    "srto_add_cluster_key_chng.hzrds_lvl_cd as hzrds_lvl_cd",
    "srto_add_cluster_key_chng.auth_generic_cd as auth_generic_cd",
    "srto_add_cluster_key_chng.fda_ind as fda_ind",
    "srto_add_cluster_key_chng.fda_ind_value as fda_ind_value",
    "srto_add_cluster_key_chng.auth_ndc_upc_hri as auth_ndc_upc_hri",
    "srto_add_cluster_key_chng.auth_gen_override_ind as auth_gen_override_ind",
    "srto_add_cluster_key_chng.ddid as ddid",
    "srto_add_cluster_key_chng.rxcui_type as rxcui_type",
    "srto_add_cluster_key_chng.rxcui as rxcui",
    "srto_add_cluster_key_chng.elsevier_pack_id as elsevier_pack_id",
    "srto_add_cluster_key_chng.elsevier_prod_id as elsevier_prod_id",
    "srto_add_cluster_key_chng.med_dosage_unit as med_dosage_unit",
    "srto_add_cluster_key_chng.med_conv_factor as med_conv_factor",
    "srto_add_cluster_key_chng.mme_calc_factor as mme_calc_factor",
    "srto_add_cluster_key_chng.edw_dml_ind as edw_dml_ind",
    "srto_add_cluster_key_chng.etl_proc_seq_nbr as etl_proc_seq_nbr")
def X_history_seq_nbr_V0S94P3_df(df):
  return df.alias("srto_pkey_cdc_asc_add_clstr").selectExpr(
    "srto_pkey_cdc_asc_add_clstr.drug_id as drug_id",
    "srto_pkey_cdc_asc_add_clstr.ndc_mfgr_nbr as ndc_mfgr_nbr",
    "srto_pkey_cdc_asc_add_clstr.ndc_prod_nbr as ndc_prod_nbr",
    "srto_pkey_cdc_asc_add_clstr.ndc_pkg_cd as ndc_pkg_cd",
    "srto_pkey_cdc_asc_add_clstr.sims_upc as sims_upc",
    "srto_pkey_cdc_asc_add_clstr.repack_nbr as repack_nbr",
    "srto_pkey_cdc_asc_add_clstr.ndc_form_cd as ndc_form_cd",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_mfgr_nbr as prev_ndc_mfgr_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_prod_nbr as prev_ndc_prod_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_pkg_cd as prev_ndc_pkg_cd",
    "srto_pkey_cdc_asc_add_clstr.prev_repack_nbr as prev_repack_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_form_cd as prev_ndc_form_cd",
    "srto_pkey_cdc_asc_add_clstr.upc_hri_format_cd as upc_hri_format_cd",
    "srto_pkey_cdc_asc_add_clstr.ndc_upc_hri_nbr as ndc_upc_hri_nbr",
    "srto_pkey_cdc_asc_add_clstr.dur_ndc as dur_ndc",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_upc_hri_nbr as prev_ndc_upc_hri_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_upc_hri_format_cd as prev_upc_hri_format_cd",
    "srto_pkey_cdc_asc_add_clstr.dea_class_cd as dea_class_cd",
    "srto_pkey_cdc_asc_add_clstr.orange_book_rating as orange_book_rating",
    "srto_pkey_cdc_asc_add_clstr.drug_name_cd as drug_name_cd",
    "srto_pkey_cdc_asc_add_clstr.generic_prod_pkg_cd as generic_prod_pkg_cd",
    "srto_pkey_cdc_asc_add_clstr.generic_id_type_cd as generic_id_type_cd",
    "srto_pkey_cdc_asc_add_clstr.generic_ingrd_id as generic_ingrd_id",
    "srto_pkey_cdc_asc_add_clstr.ahfscc_therapeutic_class_cd as ahfscc_therapeutic_class_cd",
    "srto_pkey_cdc_asc_add_clstr.limit_stability_cd as limit_stability_cd",
    "srto_pkey_cdc_asc_add_clstr.pkg_desc as pkg_desc",
    "srto_pkey_cdc_asc_add_clstr.rx_otc_cd as rx_otc_cd",
    "srto_pkey_cdc_asc_add_clstr.maint_drug_ind as maint_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.route_admin as route_admin",
    "srto_pkey_cdc_asc_add_clstr.generic_drug_cd as generic_drug_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_type_cd as drug_type_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_single_combine_cd as drug_single_combine_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_storage_cd as drug_storage_cd",
    "srto_pkey_cdc_asc_add_clstr.prod_name as prod_name",
    "srto_pkey_cdc_asc_add_clstr.prod_name_suffix as prod_name_suffix",
    "srto_pkey_cdc_asc_add_clstr.prod_name_extn as prod_name_extn",
    "srto_pkey_cdc_asc_add_clstr.prod_name_medispan_abbr as prod_name_medispan_abbr",
    "srto_pkey_cdc_asc_add_clstr.generic_prod_id as generic_prod_id",
    "srto_pkey_cdc_asc_add_clstr.generic_prod_id_name as generic_prod_id_name",
    "srto_pkey_cdc_asc_add_clstr.mfgr_name as mfgr_name",
    "srto_pkey_cdc_asc_add_clstr.mfgr_name_abbr as mfgr_name_abbr",
    "srto_pkey_cdc_asc_add_clstr.medispan_mfgr_name_abbr as medispan_mfgr_name_abbr",
    "srto_pkey_cdc_asc_add_clstr.mfgr_name_suffix as mfgr_name_suffix",
    "srto_pkey_cdc_asc_add_clstr.drug_strength as drug_strength",
    "srto_pkey_cdc_asc_add_clstr.drug_strength_uom as drug_strength_uom",
    "srto_pkey_cdc_asc_add_clstr.dosage_form_cd as dosage_form_cd",
    "srto_pkey_cdc_asc_add_clstr.pkg_sz as pkg_sz",
    "srto_pkey_cdc_asc_add_clstr.pkg_sz_uom as pkg_sz_uom",
    "srto_pkey_cdc_asc_add_clstr.pkg_qty as pkg_qty",
    "srto_pkey_cdc_asc_add_clstr.rx_to_otc_dt as rx_to_otc_dt",
    "srto_pkey_cdc_asc_add_clstr.awp_per_unit_dlrs as awp_per_unit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.drug_cnt_cell_id as drug_cnt_cell_id",
    "srto_pkey_cdc_asc_add_clstr.awp_dt as awp_dt",
    "srto_pkey_cdc_asc_add_clstr.hcfa_ffp_limit_eff_dt as hcfa_ffp_limit_eff_dt",
    "srto_pkey_cdc_asc_add_clstr.hcfa_ffp_limit_dlrs as hcfa_ffp_limit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.prod_name_abbr as prod_name_abbr",
    "srto_pkey_cdc_asc_add_clstr.drug_stat_cd as drug_stat_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_discontinue_dt as drug_discontinue_dt",
    "srto_pkey_cdc_asc_add_clstr.most_freq_prescribed_nbr as most_freq_prescribed_nbr",
    "srto_pkey_cdc_asc_add_clstr.wic_nbr as wic_nbr",
    "srto_pkey_cdc_asc_add_clstr.pat_pkg_insert_ind as pat_pkg_insert_ind",
    "srto_pkey_cdc_asc_add_clstr.min_dspnsbl_metric_qty as min_dspnsbl_metric_qty",
    "srto_pkey_cdc_asc_add_clstr.default_sig as default_sig",
    "srto_pkey_cdc_asc_add_clstr.default_day_supply as default_day_supply",
    "srto_pkey_cdc_asc_add_clstr.drug_expire_day as drug_expire_day",
    "srto_pkey_cdc_asc_add_clstr.drug_class_excpn_ind as drug_class_excpn_ind",
    "srto_pkey_cdc_asc_add_clstr.ops_study_dept_nbr as ops_study_dept_nbr",
    "srto_pkey_cdc_asc_add_clstr.drug_whse_ind as drug_whse_ind",
    "srto_pkey_cdc_asc_add_clstr.price_protect_ind as price_protect_ind",
    "srto_pkey_cdc_asc_add_clstr.puerto_rico_drug_ind as puerto_rico_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.price_override_drug_id as price_override_drug_id",
    "srto_pkey_cdc_asc_add_clstr.price_type as price_type",
    "srto_pkey_cdc_asc_add_clstr.aac_per_unit_dlrs as aac_per_unit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.wac_per_unit_dlrs as wac_per_unit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.prorated_qty as prorated_qty",
    "srto_pkey_cdc_asc_add_clstr.price_qty as price_qty",
    "srto_pkey_cdc_asc_add_clstr.drug_shape_cd as drug_shape_cd",
    "srto_pkey_cdc_asc_add_clstr.primary_color_cd as primary_color_cd",
    "srto_pkey_cdc_asc_add_clstr.secondary_color_cd as secondary_color_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_side_1_id as drug_side_1_id",
    "srto_pkey_cdc_asc_add_clstr.drug_side_2_id as drug_side_2_id",
    "srto_pkey_cdc_asc_add_clstr.bill_ndc as bill_ndc",
    "srto_pkey_cdc_asc_add_clstr.drug_cmnt_cd as drug_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.default_smart_sig_cd as default_smart_sig_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_loc_cd as drug_loc_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_multihit_display_ind as drug_multihit_display_ind",
    "srto_pkey_cdc_asc_add_clstr.substn_drug_id as substn_drug_id",
    "srto_pkey_cdc_asc_add_clstr.substn_prod_type as substn_prod_type",
    "srto_pkey_cdc_asc_add_clstr.drug_volume as drug_volume",
    "srto_pkey_cdc_asc_add_clstr.precount_qty_ind as precount_qty_ind",
    "srto_pkey_cdc_asc_add_clstr.precount_qty_1 as precount_qty_1",
    "srto_pkey_cdc_asc_add_clstr.precount_qty_2 as precount_qty_2",
    "srto_pkey_cdc_asc_add_clstr.dur_knowledge_base_drug_cd as dur_knowledge_base_drug_cd",
    "srto_pkey_cdc_asc_add_clstr.unit_dose_unit_of_use_cd as unit_dose_unit_of_use_cd",
    "srto_pkey_cdc_asc_add_clstr.label_cmnt_cd as label_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.reconstitute_water_qty as reconstitute_water_qty",
    "srto_pkey_cdc_asc_add_clstr.drug_spcl_cmnt_cd as drug_spcl_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.fax_pbr_cmnt_cd as fax_pbr_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.promise_substn_drug_id as promise_substn_drug_id",
    "srto_pkey_cdc_asc_add_clstr.spclty_drug_ind as spclty_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.piece_weight as piece_weight",
    "srto_pkey_cdc_asc_add_clstr.stock_bottle_barcode as stock_bottle_barcode",
    "srto_pkey_cdc_asc_add_clstr.dose_per_pkg as dose_per_pkg",
    "srto_pkey_cdc_asc_add_clstr.tot_discnt_card_pct as tot_discnt_card_pct",
    "srto_pkey_cdc_asc_add_clstr.pet_drug_ind as pet_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.limit_dstrb_cd as limit_dstrb_cd",
    "srto_pkey_cdc_asc_add_clstr.complicate_supplies_ind as complicate_supplies_ind",
    "srto_pkey_cdc_asc_add_clstr.spclty_review_ind as spclty_review_ind",
    "srto_pkey_cdc_asc_add_clstr.clinical_val_ind as clinical_val_ind",
    "srto_pkey_cdc_asc_add_clstr.req_supplies_ind as req_supplies_ind",
    "srto_pkey_cdc_asc_add_clstr.mail_drug_multihit_display_ind as mail_drug_multihit_display_ind",
    "srto_pkey_cdc_asc_add_clstr.mixed_ind as mixed_ind",
    "srto_pkey_cdc_asc_add_clstr.drug_image_filename as drug_image_filename",
    "srto_pkey_cdc_asc_add_clstr.top_drug_image_ind as top_drug_image_ind",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_msg as quality_alert_msg",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_keyword as quality_alert_keyword",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_rule_ind as quality_alert_rule_ind",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_screen_ind as quality_alert_screen_ind",
    "srto_pkey_cdc_asc_add_clstr.tip_ind as tip_ind",
    "srto_pkey_cdc_asc_add_clstr.ref_drug_id as ref_drug_id",
    "srto_pkey_cdc_asc_add_clstr.hc_proc_cd as hc_proc_cd",
    "srto_pkey_cdc_asc_add_clstr.preferred_mfgr_drug_ind as preferred_mfgr_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.med_guide_filename as med_guide_filename",
    "srto_pkey_cdc_asc_add_clstr.med_guide_print_ind as med_guide_print_ind",
    "srto_pkey_cdc_asc_add_clstr.item_class as item_class",
    "srto_pkey_cdc_asc_add_clstr.item_formulary_ind as item_formulary_ind",
    "srto_pkey_cdc_asc_add_clstr.item_lob as item_lob",
    "srto_pkey_cdc_asc_add_clstr.item_conv_factor as item_conv_factor",
    "srto_pkey_cdc_asc_add_clstr.item_list_price_dlrs as item_list_price_dlrs",
    "srto_pkey_cdc_asc_add_clstr.item_rtl_price_dlrs as item_rtl_price_dlrs",
    "srto_pkey_cdc_asc_add_clstr.item_prch_uom as item_prch_uom",
    "srto_pkey_cdc_asc_add_clstr.item_selling_uom as item_selling_uom",
    "srto_pkey_cdc_asc_add_clstr.specific_gravity as specific_gravity",
    "srto_pkey_cdc_asc_add_clstr.conc_nbr as conc_nbr",
    "srto_pkey_cdc_asc_add_clstr.drug_item_conc_unit_cd as drug_item_conc_unit_cd",
    "srto_pkey_cdc_asc_add_clstr.lipids_ind as lipids_ind",
    "srto_pkey_cdc_asc_add_clstr.amino_acid_ind as amino_acid_ind",
    "srto_pkey_cdc_asc_add_clstr.poolable_ind as poolable_ind",
    "srto_pkey_cdc_asc_add_clstr.trace_element_ind as trace_element_ind",
    "srto_pkey_cdc_asc_add_clstr.electrolyte_ind as electrolyte_ind",
    "srto_pkey_cdc_asc_add_clstr.contnr_material_cd as contnr_material_cd",
    "srto_pkey_cdc_asc_add_clstr.contnr_max_capacity as contnr_max_capacity",
    "srto_pkey_cdc_asc_add_clstr.drug_vehicle_method_ind as drug_vehicle_method_ind",
    "srto_pkey_cdc_asc_add_clstr.drug_vehicle_method as drug_vehicle_method",
    "srto_pkey_cdc_asc_add_clstr.cocktail_ind as cocktail_ind",
    "srto_pkey_cdc_asc_add_clstr.base_ind as base_ind",
    "srto_pkey_cdc_asc_add_clstr.item_type_cd as item_type_cd",
    "srto_pkey_cdc_asc_add_clstr.conc_dextrose_ind as conc_dextrose_ind",
    "srto_pkey_cdc_asc_add_clstr.contnr_ind as contnr_ind",
    "srto_pkey_cdc_asc_add_clstr.contnr_type as contnr_type",
    "srto_pkey_cdc_asc_add_clstr.plx_drug_use_ind as plx_drug_use_ind",
    "srto_pkey_cdc_asc_add_clstr.item_pkg_sz as item_pkg_sz",
    "srto_pkey_cdc_asc_add_clstr.item_pkg_sz_uom as item_pkg_sz_uom",
    "srto_pkey_cdc_asc_add_clstr.item_full_name as item_full_name",
    "srto_pkey_cdc_asc_add_clstr.item_short_name as item_short_name",
    "srto_pkey_cdc_asc_add_clstr.item_awp_dlrs as item_awp_dlrs",
    "srto_pkey_cdc_asc_add_clstr.item_bill_factor as item_bill_factor",
    "srto_pkey_cdc_asc_add_clstr.drug_disease_type_cd as drug_disease_type_cd",
    "srto_pkey_cdc_asc_add_clstr.item_drug_sub_catg as item_drug_sub_catg",
    "srto_pkey_cdc_asc_add_clstr.item_drug_catg as item_drug_catg",
    "srto_pkey_cdc_asc_add_clstr.item_drug_sub_grp as item_drug_sub_grp",
    "srto_pkey_cdc_asc_add_clstr.item_drug_grp as item_drug_grp",
    "srto_pkey_cdc_asc_add_clstr.src_eff_dt as src_eff_dt",
    "srto_pkey_cdc_asc_add_clstr.src_eff_tm as src_eff_tm",
    "srto_pkey_cdc_asc_add_clstr.src_create_user_id as src_create_user_id",
    "srto_pkey_cdc_asc_add_clstr.src_update_user_id as src_update_user_id",
    "srto_pkey_cdc_asc_add_clstr.src_end_dt as src_end_dt",
    "srto_pkey_cdc_asc_add_clstr.src_end_tm as src_end_tm",
    "srto_pkey_cdc_asc_add_clstr.edw_batch_id as edw_batch_id",
    "srto_pkey_cdc_asc_add_clstr.track_inv_ind as track_inv_ind",
    "srto_pkey_cdc_asc_add_clstr.src_create_dttm as src_create_dttm",
    "srto_pkey_cdc_asc_add_clstr.history_seq_nbr as history_seq_nbr",
    #HistSeqNbr + 1
    "srto_pkey_cdc_asc_add_clstr.history_seq_cd as history_seq_cd",
    "srto_pkey_cdc_asc_add_clstr.inferred_drug_ind as inferred_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.min_drug_price_dlrs as min_drug_price_dlrs",
    "srto_pkey_cdc_asc_add_clstr.excl_drug_auto_rcmd_ind as excl_drug_auto_rcmd_ind",
    "'N' as medicare_b_dts_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.excl_tbltop_cnt_ind), srto_pkey_cdc_asc_add_clstr.excl_tbltop_cnt_ind, trim(srto_pkey_cdc_asc_add_clstr.excl_tbltop_cnt_ind)) as excl_tbltop_cnt_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.require_tbltop_clean_ind), srto_pkey_cdc_asc_add_clstr.require_tbltop_clean_ind, trim(srto_pkey_cdc_asc_add_clstr.require_tbltop_clean_ind)) as require_tbltop_clean_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.ahfs_extend_therapeutic_class_cd), srto_pkey_cdc_asc_add_clstr.ahfs_extend_therapeutic_class_cd, trim(srto_pkey_cdc_asc_add_clstr.ahfs_extend_therapeutic_class_cd)) as ahfs_extend_therapeutic_class_cd",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.hzrds_lvl_cd), srto_pkey_cdc_asc_add_clstr.hzrds_lvl_cd, trim(srto_pkey_cdc_asc_add_clstr.hzrds_lvl_cd)) as hzrds_lvl_cd",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.auth_generic_cd), srto_pkey_cdc_asc_add_clstr.auth_generic_cd, trim(srto_pkey_cdc_asc_add_clstr.auth_generic_cd)) as auth_generic_cd",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.fda_ind), srto_pkey_cdc_asc_add_clstr.fda_ind, trim(srto_pkey_cdc_asc_add_clstr.fda_ind)) as fda_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.fda_ind_value), srto_pkey_cdc_asc_add_clstr.fda_ind_value, trim(srto_pkey_cdc_asc_add_clstr.fda_ind_value)) as fda_ind_value",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.auth_ndc_upc_hri), srto_pkey_cdc_asc_add_clstr.auth_ndc_upc_hri, trim(srto_pkey_cdc_asc_add_clstr.auth_ndc_upc_hri)) as auth_ndc_upc_hri",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.auth_gen_override_ind), srto_pkey_cdc_asc_add_clstr.auth_gen_override_ind, trim(srto_pkey_cdc_asc_add_clstr.auth_gen_override_ind)) as auth_gen_override_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.ddid), srto_pkey_cdc_asc_add_clstr.ddid, trim(srto_pkey_cdc_asc_add_clstr.ddid)) as ddid",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.rxcui_type), srto_pkey_cdc_asc_add_clstr.rxcui_type, trim(srto_pkey_cdc_asc_add_clstr.rxcui_type)) as rxcui_type",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.rxcui), srto_pkey_cdc_asc_add_clstr.rxcui, trim(srto_pkey_cdc_asc_add_clstr.rxcui)) as rxcui",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.elsevier_pack_id), srto_pkey_cdc_asc_add_clstr.elsevier_pack_id, trim(srto_pkey_cdc_asc_add_clstr.elsevier_pack_id)) as elsevier_pack_id",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.elsevier_prod_id), srto_pkey_cdc_asc_add_clstr.elsevier_prod_id, trim(srto_pkey_cdc_asc_add_clstr.elsevier_prod_id)) as elsevier_prod_id",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.med_dosage_unit), srto_pkey_cdc_asc_add_clstr.med_dosage_unit, trim(srto_pkey_cdc_asc_add_clstr.med_dosage_unit)) as med_dosage_unit",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.med_conv_factor), srto_pkey_cdc_asc_add_clstr.med_conv_factor, trim(srto_pkey_cdc_asc_add_clstr.med_conv_factor)) as med_conv_factor",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.mme_calc_factor), srto_pkey_cdc_asc_add_clstr.mme_calc_factor, trim(srto_pkey_cdc_asc_add_clstr.mme_calc_factor)) as mme_calc_factor"
    
    )
def FFW_upd_loadready_save(df):
  return ctx.saveAsCsv(df,
    path=f"{ctx.pDirLoadReadyPharmacyHealthcareDrug}/{ctx.pEdwBatchId}_{ctx.pTDEDWTargetTable}.update.dat",
    header=False,
    delimiter="\u00C7",
    updateMode="overwrite",
    rejectMode="continue")
def X_history_seq_nbr_V0S94P2_df(df):
  return df.alias("srto_pkey_cdc_asc_add_clstr").selectExpr(
    "srto_pkey_cdc_asc_add_clstr.drug_id as drug_id",
    "srto_pkey_cdc_asc_add_clstr.ndc_mfgr_nbr as ndc_mfgr_nbr",
    "srto_pkey_cdc_asc_add_clstr.ndc_prod_nbr as ndc_prod_nbr",
    "srto_pkey_cdc_asc_add_clstr.ndc_pkg_cd as ndc_pkg_cd",
    "srto_pkey_cdc_asc_add_clstr.sims_upc as sims_upc",
    "srto_pkey_cdc_asc_add_clstr.repack_nbr as repack_nbr",
    "srto_pkey_cdc_asc_add_clstr.ndc_form_cd as ndc_form_cd",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_mfgr_nbr as prev_ndc_mfgr_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_prod_nbr as prev_ndc_prod_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_pkg_cd as prev_ndc_pkg_cd",
    "srto_pkey_cdc_asc_add_clstr.prev_repack_nbr as prev_repack_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_form_cd as prev_ndc_form_cd",
    "srto_pkey_cdc_asc_add_clstr.upc_hri_format_cd as upc_hri_format_cd",
    "srto_pkey_cdc_asc_add_clstr.ndc_upc_hri_nbr as ndc_upc_hri_nbr",
    "srto_pkey_cdc_asc_add_clstr.dur_ndc as dur_ndc",
    "srto_pkey_cdc_asc_add_clstr.prev_ndc_upc_hri_nbr as prev_ndc_upc_hri_nbr",
    "srto_pkey_cdc_asc_add_clstr.prev_upc_hri_format_cd as prev_upc_hri_format_cd",
    "srto_pkey_cdc_asc_add_clstr.dea_class_cd as dea_class_cd",
    "srto_pkey_cdc_asc_add_clstr.orange_book_rating as orange_book_rating",
    "srto_pkey_cdc_asc_add_clstr.drug_name_cd as drug_name_cd",
    "srto_pkey_cdc_asc_add_clstr.generic_prod_pkg_cd as generic_prod_pkg_cd",
    "srto_pkey_cdc_asc_add_clstr.generic_id_type_cd as generic_id_type_cd",
    "srto_pkey_cdc_asc_add_clstr.generic_ingrd_id as generic_ingrd_id",
    "srto_pkey_cdc_asc_add_clstr.ahfscc_therapeutic_class_cd as ahfscc_therapeutic_class_cd",
    "srto_pkey_cdc_asc_add_clstr.limit_stability_cd as limit_stability_cd",
    "srto_pkey_cdc_asc_add_clstr.pkg_desc as pkg_desc",
    "srto_pkey_cdc_asc_add_clstr.rx_otc_cd as rx_otc_cd",
    "srto_pkey_cdc_asc_add_clstr.maint_drug_ind as maint_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.route_admin as route_admin",
    "srto_pkey_cdc_asc_add_clstr.generic_drug_cd as generic_drug_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_type_cd as drug_type_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_single_combine_cd as drug_single_combine_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_storage_cd as drug_storage_cd",
    "srto_pkey_cdc_asc_add_clstr.prod_name as prod_name",
    "srto_pkey_cdc_asc_add_clstr.prod_name_suffix as prod_name_suffix",
    "srto_pkey_cdc_asc_add_clstr.prod_name_extn as prod_name_extn",
    "srto_pkey_cdc_asc_add_clstr.prod_name_medispan_abbr as prod_name_medispan_abbr",
    "srto_pkey_cdc_asc_add_clstr.generic_prod_id as generic_prod_id",
    "srto_pkey_cdc_asc_add_clstr.generic_prod_id_name as generic_prod_id_name",
    "srto_pkey_cdc_asc_add_clstr.mfgr_name as mfgr_name",
    "srto_pkey_cdc_asc_add_clstr.mfgr_name_abbr as mfgr_name_abbr",
    "srto_pkey_cdc_asc_add_clstr.medispan_mfgr_name_abbr as medispan_mfgr_name_abbr",
    "srto_pkey_cdc_asc_add_clstr.mfgr_name_suffix as mfgr_name_suffix",
    "srto_pkey_cdc_asc_add_clstr.drug_strength as drug_strength",
    "srto_pkey_cdc_asc_add_clstr.drug_strength_uom as drug_strength_uom",
    "srto_pkey_cdc_asc_add_clstr.dosage_form_cd as dosage_form_cd",
    "srto_pkey_cdc_asc_add_clstr.pkg_sz as pkg_sz",
    "srto_pkey_cdc_asc_add_clstr.pkg_sz_uom as pkg_sz_uom",
    "srto_pkey_cdc_asc_add_clstr.pkg_qty as pkg_qty",
    "srto_pkey_cdc_asc_add_clstr.rx_to_otc_dt as rx_to_otc_dt",
    "srto_pkey_cdc_asc_add_clstr.awp_per_unit_dlrs as awp_per_unit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.drug_cnt_cell_id as drug_cnt_cell_id",
    "srto_pkey_cdc_asc_add_clstr.awp_dt as awp_dt",
    "srto_pkey_cdc_asc_add_clstr.hcfa_ffp_limit_eff_dt as hcfa_ffp_limit_eff_dt",
    "srto_pkey_cdc_asc_add_clstr.hcfa_ffp_limit_dlrs as hcfa_ffp_limit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.prod_name_abbr as prod_name_abbr",
    "srto_pkey_cdc_asc_add_clstr.drug_stat_cd as drug_stat_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_discontinue_dt as drug_discontinue_dt",
    "srto_pkey_cdc_asc_add_clstr.most_freq_prescribed_nbr as most_freq_prescribed_nbr",
    "srto_pkey_cdc_asc_add_clstr.wic_nbr as wic_nbr",
    "srto_pkey_cdc_asc_add_clstr.pat_pkg_insert_ind as pat_pkg_insert_ind",
    "srto_pkey_cdc_asc_add_clstr.min_dspnsbl_metric_qty as min_dspnsbl_metric_qty",
    "srto_pkey_cdc_asc_add_clstr.default_sig as default_sig",
    "srto_pkey_cdc_asc_add_clstr.default_day_supply as default_day_supply",
    "srto_pkey_cdc_asc_add_clstr.drug_expire_day as drug_expire_day",
    "srto_pkey_cdc_asc_add_clstr.drug_class_excpn_ind as drug_class_excpn_ind",
    "srto_pkey_cdc_asc_add_clstr.ops_study_dept_nbr as ops_study_dept_nbr",
    "srto_pkey_cdc_asc_add_clstr.drug_whse_ind as drug_whse_ind",
    "srto_pkey_cdc_asc_add_clstr.price_protect_ind as price_protect_ind",
    "srto_pkey_cdc_asc_add_clstr.puerto_rico_drug_ind as puerto_rico_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.price_override_drug_id as price_override_drug_id",
    "srto_pkey_cdc_asc_add_clstr.price_type as price_type",
    "srto_pkey_cdc_asc_add_clstr.aac_per_unit_dlrs as aac_per_unit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.wac_per_unit_dlrs as wac_per_unit_dlrs",
    "srto_pkey_cdc_asc_add_clstr.prorated_qty as prorated_qty",
    "srto_pkey_cdc_asc_add_clstr.price_qty as price_qty",
    "srto_pkey_cdc_asc_add_clstr.drug_shape_cd as drug_shape_cd",
    "srto_pkey_cdc_asc_add_clstr.primary_color_cd as primary_color_cd",
    "srto_pkey_cdc_asc_add_clstr.secondary_color_cd as secondary_color_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_side_1_id as drug_side_1_id",
    "srto_pkey_cdc_asc_add_clstr.drug_side_2_id as drug_side_2_id",
    "srto_pkey_cdc_asc_add_clstr.bill_ndc as bill_ndc",
    "srto_pkey_cdc_asc_add_clstr.drug_cmnt_cd as drug_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.default_smart_sig_cd as default_smart_sig_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_loc_cd as drug_loc_cd",
    "srto_pkey_cdc_asc_add_clstr.drug_multihit_display_ind as drug_multihit_display_ind",
    "srto_pkey_cdc_asc_add_clstr.substn_drug_id as substn_drug_id",
    "srto_pkey_cdc_asc_add_clstr.substn_prod_type as substn_prod_type",
    "srto_pkey_cdc_asc_add_clstr.drug_volume as drug_volume",
    "srto_pkey_cdc_asc_add_clstr.precount_qty_ind as precount_qty_ind",
    "srto_pkey_cdc_asc_add_clstr.precount_qty_1 as precount_qty_1",
    "srto_pkey_cdc_asc_add_clstr.precount_qty_2 as precount_qty_2",
    "srto_pkey_cdc_asc_add_clstr.dur_knowledge_base_drug_cd as dur_knowledge_base_drug_cd",
    "srto_pkey_cdc_asc_add_clstr.unit_dose_unit_of_use_cd as unit_dose_unit_of_use_cd",
    "srto_pkey_cdc_asc_add_clstr.label_cmnt_cd as label_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.reconstitute_water_qty as reconstitute_water_qty",
    "srto_pkey_cdc_asc_add_clstr.drug_spcl_cmnt_cd as drug_spcl_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.fax_pbr_cmnt_cd as fax_pbr_cmnt_cd",
    "srto_pkey_cdc_asc_add_clstr.promise_substn_drug_id as promise_substn_drug_id",
    "srto_pkey_cdc_asc_add_clstr.spclty_drug_ind as spclty_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.piece_weight as piece_weight",
    "srto_pkey_cdc_asc_add_clstr.stock_bottle_barcode as stock_bottle_barcode",
    "srto_pkey_cdc_asc_add_clstr.dose_per_pkg as dose_per_pkg",
    "srto_pkey_cdc_asc_add_clstr.tot_discnt_card_pct as tot_discnt_card_pct",
    "srto_pkey_cdc_asc_add_clstr.pet_drug_ind as pet_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.limit_dstrb_cd as limit_dstrb_cd",
    "srto_pkey_cdc_asc_add_clstr.complicate_supplies_ind as complicate_supplies_ind",
    "srto_pkey_cdc_asc_add_clstr.spclty_review_ind as spclty_review_ind",
    "srto_pkey_cdc_asc_add_clstr.clinical_val_ind as clinical_val_ind",
    "srto_pkey_cdc_asc_add_clstr.req_supplies_ind as req_supplies_ind",
    "srto_pkey_cdc_asc_add_clstr.mail_drug_multihit_display_ind as mail_drug_multihit_display_ind",
    "srto_pkey_cdc_asc_add_clstr.mixed_ind as mixed_ind",
    "srto_pkey_cdc_asc_add_clstr.drug_image_filename as drug_image_filename",
    "srto_pkey_cdc_asc_add_clstr.top_drug_image_ind as top_drug_image_ind",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_msg as quality_alert_msg",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_keyword as quality_alert_keyword",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_rule_ind as quality_alert_rule_ind",
    "srto_pkey_cdc_asc_add_clstr.quality_alert_screen_ind as quality_alert_screen_ind",
    "srto_pkey_cdc_asc_add_clstr.tip_ind as tip_ind",
    "srto_pkey_cdc_asc_add_clstr.ref_drug_id as ref_drug_id",
    "srto_pkey_cdc_asc_add_clstr.hc_proc_cd as hc_proc_cd",
    "srto_pkey_cdc_asc_add_clstr.preferred_mfgr_drug_ind as preferred_mfgr_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.med_guide_filename as med_guide_filename",
    "srto_pkey_cdc_asc_add_clstr.med_guide_print_ind as med_guide_print_ind",
    "srto_pkey_cdc_asc_add_clstr.item_class as item_class",
    "srto_pkey_cdc_asc_add_clstr.item_formulary_ind as item_formulary_ind",
    "srto_pkey_cdc_asc_add_clstr.item_lob as item_lob",
    "srto_pkey_cdc_asc_add_clstr.item_conv_factor as item_conv_factor",
    "srto_pkey_cdc_asc_add_clstr.item_list_price_dlrs as item_list_price_dlrs",
    "srto_pkey_cdc_asc_add_clstr.item_rtl_price_dlrs as item_rtl_price_dlrs",
    "srto_pkey_cdc_asc_add_clstr.item_prch_uom as item_prch_uom",
    "srto_pkey_cdc_asc_add_clstr.item_selling_uom as item_selling_uom",
    "srto_pkey_cdc_asc_add_clstr.specific_gravity as specific_gravity",
    "srto_pkey_cdc_asc_add_clstr.conc_nbr as conc_nbr",
    "srto_pkey_cdc_asc_add_clstr.drug_item_conc_unit_cd as drug_item_conc_unit_cd",
    "srto_pkey_cdc_asc_add_clstr.lipids_ind as lipids_ind",
    "srto_pkey_cdc_asc_add_clstr.amino_acid_ind as amino_acid_ind",
    "srto_pkey_cdc_asc_add_clstr.poolable_ind as poolable_ind",
    "srto_pkey_cdc_asc_add_clstr.trace_element_ind as trace_element_ind",
    "srto_pkey_cdc_asc_add_clstr.electrolyte_ind as electrolyte_ind",
    "srto_pkey_cdc_asc_add_clstr.contnr_material_cd as contnr_material_cd",
    "srto_pkey_cdc_asc_add_clstr.contnr_max_capacity as contnr_max_capacity",
    "srto_pkey_cdc_asc_add_clstr.drug_vehicle_method_ind as drug_vehicle_method_ind",
    "srto_pkey_cdc_asc_add_clstr.drug_vehicle_method as drug_vehicle_method",
    "srto_pkey_cdc_asc_add_clstr.cocktail_ind as cocktail_ind",
    "srto_pkey_cdc_asc_add_clstr.base_ind as base_ind",
    "srto_pkey_cdc_asc_add_clstr.item_type_cd as item_type_cd",
    "srto_pkey_cdc_asc_add_clstr.conc_dextrose_ind as conc_dextrose_ind",
    "srto_pkey_cdc_asc_add_clstr.contnr_ind as contnr_ind",
    "srto_pkey_cdc_asc_add_clstr.contnr_type as contnr_type",
    "srto_pkey_cdc_asc_add_clstr.plx_drug_use_ind as plx_drug_use_ind",
    "srto_pkey_cdc_asc_add_clstr.item_pkg_sz as item_pkg_sz",
    "srto_pkey_cdc_asc_add_clstr.item_pkg_sz_uom as item_pkg_sz_uom",
    "srto_pkey_cdc_asc_add_clstr.item_full_name as item_full_name",
    "srto_pkey_cdc_asc_add_clstr.item_short_name as item_short_name",
    "srto_pkey_cdc_asc_add_clstr.item_awp_dlrs as item_awp_dlrs",
    "srto_pkey_cdc_asc_add_clstr.item_bill_factor as item_bill_factor",
    "srto_pkey_cdc_asc_add_clstr.drug_disease_type_cd as drug_disease_type_cd",
    "srto_pkey_cdc_asc_add_clstr.item_drug_sub_catg as item_drug_sub_catg",
    "srto_pkey_cdc_asc_add_clstr.item_drug_catg as item_drug_catg",
    "srto_pkey_cdc_asc_add_clstr.item_drug_sub_grp as item_drug_sub_grp",
    "srto_pkey_cdc_asc_add_clstr.item_drug_grp as item_drug_grp",
    "srto_pkey_cdc_asc_add_clstr.src_eff_dt as src_eff_dt",
    "srto_pkey_cdc_asc_add_clstr.src_eff_tm as src_eff_tm",
    "srto_pkey_cdc_asc_add_clstr.src_create_user_id as src_create_user_id",
    "srto_pkey_cdc_asc_add_clstr.src_update_user_id as src_update_user_id",
    "srto_pkey_cdc_asc_add_clstr.src_end_dt as src_end_dt",
    "srto_pkey_cdc_asc_add_clstr.src_end_tm as src_end_tm",
    "srto_pkey_cdc_asc_add_clstr.edw_batch_id as edw_batch_id",
    "srto_pkey_cdc_asc_add_clstr.track_inv_ind as track_inv_ind",
    "srto_pkey_cdc_asc_add_clstr.src_create_dttm as src_create_dttm",
    "srto_pkey_cdc_asc_add_clstr.HistSeqNbr_1 as history_seq_nbr",
    #ELSE HistSeqNbr + 1 
    "srto_pkey_cdc_asc_add_clstr.history_seq_cd as history_seq_cd",
    "srto_pkey_cdc_asc_add_clstr.inferred_drug_ind as inferred_drug_ind",
    "srto_pkey_cdc_asc_add_clstr.min_drug_price_dlrs as min_drug_price_dlrs",
    "srto_pkey_cdc_asc_add_clstr.excl_drug_auto_rcmd_ind as excl_drug_auto_rcmd_ind",
    "'N' as medicare_b_dts_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.excl_tbltop_cnt_ind), srto_pkey_cdc_asc_add_clstr.excl_tbltop_cnt_ind, trim(srto_pkey_cdc_asc_add_clstr.excl_tbltop_cnt_ind)) as excl_tbltop_cnt_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.require_tbltop_clean_ind), srto_pkey_cdc_asc_add_clstr.require_tbltop_clean_ind, trim(srto_pkey_cdc_asc_add_clstr.require_tbltop_clean_ind)) as require_tbltop_clean_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.ahfs_extend_therapeutic_class_cd), srto_pkey_cdc_asc_add_clstr.ahfs_extend_therapeutic_class_cd, trim(srto_pkey_cdc_asc_add_clstr.ahfs_extend_therapeutic_class_cd)) as ahfs_extend_therapeutic_class_cd",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.hzrds_lvl_cd), srto_pkey_cdc_asc_add_clstr.hzrds_lvl_cd, trim(srto_pkey_cdc_asc_add_clstr.hzrds_lvl_cd)) as hzrds_lvl_cd",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.auth_generic_cd), srto_pkey_cdc_asc_add_clstr.auth_generic_cd, trim(srto_pkey_cdc_asc_add_clstr.auth_generic_cd)) as auth_generic_cd",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.fda_ind), srto_pkey_cdc_asc_add_clstr.fda_ind, trim(srto_pkey_cdc_asc_add_clstr.fda_ind)) as fda_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.fda_ind_value), srto_pkey_cdc_asc_add_clstr.fda_ind_value, trim(srto_pkey_cdc_asc_add_clstr.fda_ind_value)) as fda_ind_value",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.auth_ndc_upc_hri), srto_pkey_cdc_asc_add_clstr.auth_ndc_upc_hri, trim(srto_pkey_cdc_asc_add_clstr.auth_ndc_upc_hri)) as auth_ndc_upc_hri",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.auth_gen_override_ind), srto_pkey_cdc_asc_add_clstr.auth_gen_override_ind, trim(srto_pkey_cdc_asc_add_clstr.auth_gen_override_ind)) as auth_gen_override_ind",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.ddid), srto_pkey_cdc_asc_add_clstr.ddid, trim(srto_pkey_cdc_asc_add_clstr.ddid)) as ddid",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.rxcui_type), srto_pkey_cdc_asc_add_clstr.rxcui_type, trim(srto_pkey_cdc_asc_add_clstr.rxcui_type)) as rxcui_type",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.rxcui), srto_pkey_cdc_asc_add_clstr.rxcui, trim(srto_pkey_cdc_asc_add_clstr.rxcui)) as rxcui",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.elsevier_pack_id), srto_pkey_cdc_asc_add_clstr.elsevier_pack_id, trim(srto_pkey_cdc_asc_add_clstr.elsevier_pack_id)) as elsevier_pack_id",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.elsevier_prod_id), srto_pkey_cdc_asc_add_clstr.elsevier_prod_id, trim(srto_pkey_cdc_asc_add_clstr.elsevier_prod_id)) as elsevier_prod_id",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.med_dosage_unit), srto_pkey_cdc_asc_add_clstr.med_dosage_unit, trim(srto_pkey_cdc_asc_add_clstr.med_dosage_unit)) as med_dosage_unit",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.med_conv_factor), srto_pkey_cdc_asc_add_clstr.med_conv_factor, trim(srto_pkey_cdc_asc_add_clstr.med_conv_factor)) as med_conv_factor",
    " if(IsNull(srto_pkey_cdc_asc_add_clstr.mme_calc_factor), srto_pkey_cdc_asc_add_clstr.mme_calc_factor, trim(srto_pkey_cdc_asc_add_clstr.mme_calc_factor)) as mme_calc_factor"
     )
def FFW_ins_loadready_save(df):
  return ctx.saveAsCsv(df,
    path=f"{ctx.pDirLoadReadyPharmacyHealthcareDrug}/{ctx.pEdwBatchId}_{ctx.pTDEDWTargetTable}.insert.dat",
    header=False,
    delimiter="\u00C7",
    updateMode="overwrite",
    rejectMode="continue")

# COMMAND ----------

DS_drug = DS_drug_df()
FLTR_cdc_op_type_V0S49P4 = DS_drug.filter("(cdc_operation_type_cd==\"INSERT\")")
FLTR_cdc_op_type_V0S49P2 = DS_drug.filter("(cdc_operation_type_cd==\"SQL COMPUPDATE\" and cdc_before_after_cd==\"BEFORE\")")
FLTR_cdc_op_type_V0S49P3 = DS_drug.filter("(cdc_operation_type_cd==\"SQL COMPUPDATE\" and cdc_before_after_cd==\"AFTER\")")
fltro_before = FLTR_cdc_op_type_V0S49P2
fltro_after = FLTR_cdc_op_type_V0S49P3
CDC_change_capture = fltro_before.alias("tgt").join(fltro_after.alias("src"), (fltro_before.drug_id == fltro_after.drug_id) & (fltro_before.cdc_txn_commit_dttm == fltro_after.cdc_txn_commit_dttm) & (fltro_before.cdc_seq_nbr == fltro_after.cdc_seq_nbr) & (fltro_before.cdc_rba_nbr == fltro_after.cdc_rba_nbr), how="fullouter").\
  withColumn("change_code", 
             when(col("tgt.drug_id").isNull() & col("tgt.cdc_txn_commit_dttm").isNull() & col("tgt.cdc_seq_nbr").isNull() & col("tgt.cdc_rba_nbr").isNull(), '1')
            .when((col("src.drug_id").isNull() & col("src.cdc_txn_commit_dttm").isNull() & col("src.cdc_seq_nbr").isNull() & col("src.cdc_rba_nbr").isNull()), '2')
            .when( (col("tgt.cdc_operation_type_cd") != col("src.cdc_operation_type_cd")) |  (col("tgt.edw_dml_ind") != col("src.edw_dml_ind")) |  (col("tgt.edw_batch_id") != col("src.edw_batch_id")) |  (col("tgt.drug_id") != col("src.drug_id")) |  (col("tgt.ndc_mfg") != col("src.ndc_mfg")) |  (col("tgt.ndc_prod") != col("src.ndc_prod")) |  (col("tgt.ndc_pkg") != col("src.ndc_pkg")) |  (col("tgt.sims_upc") != col("src.sims_upc")) |  (col("tgt.repack_nbr") != col("src.repack_nbr")) |  (col("tgt.ndc_form_cd") != col("src.ndc_form_cd")) |  (col("tgt.ndc_prev_mfg") != col("src.ndc_prev_mfg")) |  (col("tgt.ndc_prev_prod") != col("src.ndc_prev_prod")) |  (col("tgt.ndc_prev_pkg") != col("src.ndc_prev_pkg")) |  (col("tgt.prev_repack_nbr") != col("src.prev_repack_nbr")) |  (col("tgt.ndc_prev_form_cd") != col("src.ndc_prev_form_cd")) |  (col("tgt.id_form_cd") != col("src.id_form_cd")) |  (col("tgt.ndc_upc_hri") != col("src.ndc_upc_hri")) |  (col("tgt.dur_ndc") != col("src.dur_ndc")) |  (col("tgt.prev_ndc_upc_hri") != col("src.prev_ndc_upc_hri")) |  (col("tgt.prev_id_form_cd") != col("src.prev_id_form_cd")) |  (col("tgt.drug_class") != col("src.drug_class")) |  (col("tgt.drug_orange_book_rating") != col("src.drug_orange_book_rating")) |  (col("tgt.drug_name_cd") != col("src.drug_name_cd")) |  (col("tgt.gppc") != col("src.gppc")) |  (col("tgt.gen_typ_cd") != col("src.gen_typ_cd")) |  (col("tgt.gen_id_no") != col("src.gen_id_no")) |  (col("tgt.thera_class") != col("src.thera_class")) |  (col("tgt.lim_stabil") != col("src.lim_stabil")) |  (col("tgt.pack_descr") != col("src.pack_descr")) |  (col("tgt.rx_otc_cd") != col("src.rx_otc_cd")) |  (col("tgt.maint_drug_ind") != col("src.maint_drug_ind")) |  (col("tgt.route_of_admin_cd") != col("src.route_of_admin_cd")) |  (col("tgt.drug_generic_cd") != col("src.drug_generic_cd")) |  (col("tgt.drug_type_cd") != col("src.drug_type_cd")) |  (col("tgt.drug_single_comb_cd") != col("src.drug_single_comb_cd")) |  (col("tgt.drug_storage_cond_cd") != col("src.drug_storage_cond_cd")) |  (col("tgt.product_name") != col("src.product_name")) |  (col("tgt.product_name_suffix") != col("src.product_name_suffix")) |  (col("tgt.product_name_ext") != col("src.product_name_ext")) |  (col("tgt.product_mddb_abbr") != col("src.product_mddb_abbr")) |  (col("tgt.gpi") != col("src.gpi")) |  (col("tgt.gpi_name") != col("src.gpi_name")) |  (col("tgt.mfg_name") != col("src.mfg_name")) |  (col("tgt.mfg_name_abbr") != col("src.mfg_name_abbr")) |  (col("tgt.mfg_mddb_abbr") != col("src.mfg_mddb_abbr")) |  (col("tgt.mfg_name_suffix") != col("src.mfg_name_suffix")) |  (col("tgt.drug_strength") != col("src.drug_strength")) |  (col("tgt.drug_strength_uom") != col("src.drug_strength_uom")) |  (col("tgt.drug_dosage_form_cd") != col("src.drug_dosage_form_cd")) |  (col("tgt.package_size") != col("src.package_size")) |  (col("tgt.package_size_uom") != col("src.package_size_uom")) |  (col("tgt.package_qty") != col("src.package_qty")) |  (col("tgt.rx_to_otc_dttm") != col("src.rx_to_otc_dttm")) |  (col("tgt.awp_dttm") != col("src.awp_dttm")) |  (col("tgt.drug_counting_cell_id") != col("src.drug_counting_cell_id")) |  (col("tgt.awp_unit_price") != col("src.awp_unit_price")) |  (col("tgt.hcfa_dttm") != col("src.hcfa_dttm")) |  (col("tgt.hcfa_unit_limit") != col("src.hcfa_unit_limit")) |  (col("tgt.product_name_abbr") != col("src.product_name_abbr")) |  (col("tgt.drug_status_cd") != col("src.drug_status_cd")) |  (col("tgt.drug_disc_dttm") != col("src.drug_disc_dttm")) |  (col("tgt.mfp_nbr") != col("src.mfp_nbr")) |  (col("tgt.wic_nbr") != col("src.wic_nbr")) |  (col("tgt.drug_ppi_ind") != col("src.drug_ppi_ind")) |  (col("tgt.drug_min_disp_qty") != col("src.drug_min_disp_qty")) |  (col("tgt.default_sig") != col("src.default_sig")) |  (col("tgt.default_days_supply") != col("src.default_days_supply")) |  (col("tgt.expiration_days") != col("src.expiration_days")) |  (col("tgt.drug_class_except_ind") != col("src.drug_class_except_ind")) |  (col("tgt.ops_study_dept_nbr") != col("src.ops_study_dept_nbr")) |  (col("tgt.drug_warehouse_ind") != col("src.drug_warehouse_ind")) |  (col("tgt.pricing_protect_ind") != col("src.pricing_protect_ind")) |  (col("tgt.pr_daco_ind") != col("src.pr_daco_ind")) |  (col("tgt.pricing_override_drug") != col("src.pricing_override_drug")) |  (col("tgt.pricing_type") != col("src.pricing_type")) |  (col("tgt.aac_unit_price") != col("src.aac_unit_price")) |  (col("tgt.wac_unit_price") != col("src.wac_unit_price")) |  (col("tgt.prorated_quantity") != col("src.prorated_quantity")) |  (col("tgt.pricing_quantity") != col("src.pricing_quantity")) |  (col("tgt.drug_shape_cd") != col("src.drug_shape_cd")) |  (col("tgt.drug_color_1_cd") != col("src.drug_color_1_cd")) |  (col("tgt.drug_color_2_cd") != col("src.drug_color_2_cd")) |  (col("tgt.drug_side_1") != col("src.drug_side_1")) |  (col("tgt.drug_side_2") != col("src.drug_side_2")) |  (col("tgt.billing_ndc") != col("src.billing_ndc")) |  (col("tgt.drug_comment_cd") != col("src.drug_comment_cd")) |  (col("tgt.default_smart_sig") != col("src.default_smart_sig")) |  (col("tgt.drug_location_cd") != col("src.drug_location_cd")) |  (col("tgt.drug_multihit_disp_ind") != col("src.drug_multihit_disp_ind")) |  (col("tgt.substitution_drug_id") != col("src.substitution_drug_id")) |  (col("tgt.drug_volume") != col("src.drug_volume")) |  (col("tgt.precount_ind") != col("src.precount_ind")) |  (col("tgt.precount_qty_1") != col("src.precount_qty_1")) |  (col("tgt.precount_qty_2") != col("src.precount_qty_2")) |  (col("tgt.dur_kdc_nbr") != col("src.dur_kdc_nbr")) |  (col("tgt.ud_uu_pkg_cd") != col("src.ud_uu_pkg_cd")) |  (col("tgt.lbl_cmt_cd") != col("src.lbl_cmt_cd")) |  (col("tgt.substitution_prod_type") != col("src.substitution_prod_type")) |  (col("tgt.recon_water_qty") != col("src.recon_water_qty")) |  (col("tgt.drug_spec_cmt_cd") != col("src.drug_spec_cmt_cd")) |  (col("tgt.fax_pbr_cmt_cd") != col("src.fax_pbr_cmt_cd")) |  (col("tgt.promise_sub_drug_id") != col("src.promise_sub_drug_id")) |  (col("tgt.specialty_drug_ind") != col("src.specialty_drug_ind")) |  (col("tgt.piece_weight") != col("src.piece_weight")) |  (col("tgt.stock_bottle_barcode") != col("src.stock_bottle_barcode")) |  (col("tgt.doses_per_pkg") != col("src.doses_per_pkg")) |  (col("tgt.pct_tot_disc_card") != col("src.pct_tot_disc_card")) |  (col("tgt.pet_med_ind") != col("src.pet_med_ind")) |  (col("tgt.ltd_dist_cd") != col("src.ltd_dist_cd")) |  (col("tgt.complicated_supplies_ind") != col("src.complicated_supplies_ind")) |  (col("tgt.specialty_review_ind") != col("src.specialty_review_ind")) |  (col("tgt.clinical_value_ind") != col("src.clinical_value_ind")) |  (col("tgt.required_supplies_ind") != col("src.required_supplies_ind")) |  (col("tgt.hcp_drug_mltht_disp_ind") != col("src.hcp_drug_mltht_disp_ind")) |  (col("tgt.mix_ind") != col("src.mix_ind")) |  (col("tgt.drug_image_file_name") != col("src.drug_image_file_name")) |  (col("tgt.top_drug_ind") != col("src.top_drug_ind")) |  (col("tgt.quality_alert_message") != col("src.quality_alert_message")) |  (col("tgt.quality_alert_keywords") != col("src.quality_alert_keywords")) |  (col("tgt.quality_alert_rule_ind") != col("src.quality_alert_rule_ind")) |  (col("tgt.quality_alert_screen_ind") != col("src.quality_alert_screen_ind")) |  (col("tgt.tip_ind") != col("src.tip_ind")) |  (col("tgt.ref_drug_id") != col("src.ref_drug_id")) |  (col("tgt.hcpc") != col("src.hcpc")) |  (col("tgt.pref_mfr_ind") != col("src.pref_mfr_ind")) |  (col("tgt.med_guide_filename") != col("src.med_guide_filename")) |  (col("tgt.med_guide_ind") != col("src.med_guide_ind")) |  (col("tgt.item_class") != col("src.item_class")) |  (col("tgt.item_group") != col("src.item_group")) |  (col("tgt.item_formulary_ind") != col("src.item_formulary_ind")) |  (col("tgt.item_category") != col("src.item_category")) |  (col("tgt.item_lob") != col("src.item_lob")) |  (col("tgt.item_conv_factor") != col("src.item_conv_factor")) |  (col("tgt.item_list_price_sale") != col("src.item_list_price_sale")) |  (col("tgt.item_retail_price") != col("src.item_retail_price")) |  (col("tgt.item_pum") != col("src.item_pum")) |  (col("tgt.item_sub_group") != col("src.item_sub_group")) |  (col("tgt.item_sub_category") != col("src.item_sub_category")) |  (col("tgt.item_sum") != col("src.item_sum")) |  (col("tgt.specific_gravity") != col("src.specific_gravity")) |  (col("tgt.concentration_nbr") != col("src.concentration_nbr")) |  (col("tgt.concentration_units") != col("src.concentration_units")) |  (col("tgt.lipids_ind") != col("src.lipids_ind")) |  (col("tgt.amino_acid_ind") != col("src.amino_acid_ind")) |  (col("tgt.poolable_ind") != col("src.poolable_ind")) |  (col("tgt.trace_element_ind") != col("src.trace_element_ind")) |  (col("tgt.electrolyte_ind") != col("src.electrolyte_ind")) |  (col("tgt.container_material_cd") != col("src.container_material_cd")) |  (col("tgt.container_max_capacity") != col("src.container_max_capacity")) |  (col("tgt.vehicle_ind") != col("src.vehicle_ind")) |  (col("tgt.vehicle") != col("src.vehicle")) |  (col("tgt.cocktail_ind") != col("src.cocktail_ind")) |  (col("tgt.base_ind") != col("src.base_ind")) |  (col("tgt.item_type") != col("src.item_type")) |  (col("tgt.conc_dextrose_ind") != col("src.conc_dextrose_ind")) |  (col("tgt.container_ind") != col("src.container_ind")) |  (col("tgt.container_type") != col("src.container_type")) |  (col("tgt.plx_drug_ind") != col("src.plx_drug_ind")) |  (col("tgt.item_size") != col("src.item_size")) |  (col("tgt.item_size_units") != col("src.item_size_units")) |  (col("tgt.item_long_desc") != col("src.item_long_desc")) |  (col("tgt.item_short_desc") != col("src.item_short_desc")) |  (col("tgt.item_awp") != col("src.item_awp")) |  (col("tgt.billing_multiplier") != col("src.billing_multiplier")) |  (col("tgt.track_inventory_ind") != col("src.track_inventory_ind")) |  (col("tgt.disease_state_ind") != col("src.disease_state_ind")) |  (col("tgt.drug_inference_cd") != col("src.drug_inference_cd")) |  (col("tgt.drug_min_price") != col("src.drug_min_price")) |  (col("tgt.excl_drug_automation_ind") != col("src.excl_drug_automation_ind")) |  (col("tgt.excl_tbltp_count_ind") != col("src.excl_tbltp_count_ind")) |  (col("tgt.require_tbltp_clean") != col("src.require_tbltp_clean")) |  (col("tgt.thera_class_extd") != col("src.thera_class_extd")) |  (col("tgt.hzrds_lvl_cd") != col("src.hzrds_lvl_cd")) | (col("tgt.auth_generic_cd") != col("src.auth_generic_cd"))  | (col("tgt.fda_ind") != col("src.fda_ind"))  |(col("tgt.fda_ind_value") != col("src.fda_ind_value"))  |(col("tgt.auth_ndc_upc_hri") != col("src.auth_ndc_upc_hri"))  | (col("tgt.auth_gen_override_ind") != col("src.auth_gen_override_ind"))  | (col("tgt.ddid") != col("src.ddid"))  |(col("tgt.rxcui_type") != col("src.rxcui_type"))  |(col("tgt.rxcui") != col("src.rxcui"))  |(col("tgt.elsevier_pack_id") != col("src.elsevier_pack_id"))  | (col("tgt.elsevier_prod_id") != col("src.elsevier_prod_id"))  | (col("tgt.med_dosage_unit") != col("src.med_dosage_unit"))  | (col("tgt.med_conv_factor") != col("src.med_conv_factor"))  |  (col("tgt.mme_calc_factor") != col("src.mme_calc_factor")) | (None) , '3')
            .otherwise('0'))\
  .selectExpr ("case when change_code in ('0','1','3')  then src.cdc_txn_commit_dttm else tgt.cdc_txn_commit_dttm end as cdc_txn_commit_dttm" ,"case when change_code in ('0','1','3')  then src.cdc_seq_nbr else tgt.cdc_seq_nbr end as cdc_seq_nbr" ,"case when change_code in ('0','1','3')  then src.cdc_rba_nbr else tgt.cdc_rba_nbr end as cdc_rba_nbr" ,"case when change_code in ('0','1','3')  then src.cdc_operation_type_cd else tgt.cdc_operation_type_cd end as cdc_operation_type_cd" ,"case when change_code in ('0','1','3')  then src.cdc_before_after_cd else tgt.cdc_before_after_cd end as cdc_before_after_cd" ,"case when change_code in ('0','1','3')  then src.edw_dml_ind else tgt.edw_dml_ind end as edw_dml_ind" ,"case when change_code in ('0','1','3')  then src.edw_batch_id else tgt.edw_batch_id end as edw_batch_id" ,"case when change_code in ('0','1','3')  then src.drug_id else tgt.drug_id end as drug_id" ,"case when change_code in ('0','1','3')  then src.ndc_mfg else tgt.ndc_mfg end as ndc_mfg" ,"case when change_code in ('0','1','3')  then src.ndc_prod else tgt.ndc_prod end as ndc_prod" ,"case when change_code in ('0','1','3')  then src.ndc_pkg else tgt.ndc_pkg end as ndc_pkg" ,"case when change_code in ('0','1','3')  then src.sims_upc else tgt.sims_upc end as sims_upc" ,"case when change_code in ('0','1','3')  then src.repack_nbr else tgt.repack_nbr end as repack_nbr" ,"case when change_code in ('0','1','3')  then src.ndc_form_cd else tgt.ndc_form_cd end as ndc_form_cd" ,"case when change_code in ('0','1','3')  then src.ndc_prev_mfg else tgt.ndc_prev_mfg end as ndc_prev_mfg" ,"case when change_code in ('0','1','3')  then src.ndc_prev_prod else tgt.ndc_prev_prod end as ndc_prev_prod" ,"case when change_code in ('0','1','3')  then src.ndc_prev_pkg else tgt.ndc_prev_pkg end as ndc_prev_pkg" ,"case when change_code in ('0','1','3')  then src.prev_repack_nbr else tgt.prev_repack_nbr end as prev_repack_nbr" ,"case when change_code in ('0','1','3')  then src.ndc_prev_form_cd else tgt.ndc_prev_form_cd end as ndc_prev_form_cd" ,"case when change_code in ('0','1','3')  then src.id_form_cd else tgt.id_form_cd end as id_form_cd" ,"case when change_code in ('0','1','3')  then src.ndc_upc_hri else tgt.ndc_upc_hri end as ndc_upc_hri" ,"case when change_code in ('0','1','3')  then src.dur_ndc else tgt.dur_ndc end as dur_ndc" ,"case when change_code in ('0','1','3')  then src.prev_ndc_upc_hri else tgt.prev_ndc_upc_hri end as prev_ndc_upc_hri" ,"case when change_code in ('0','1','3')  then src.prev_id_form_cd else tgt.prev_id_form_cd end as prev_id_form_cd" ,"case when change_code in ('0','1','3')  then src.drug_class else tgt.drug_class end as drug_class" ,"case when change_code in ('0','1','3')  then src.drug_orange_book_rating else tgt.drug_orange_book_rating end as drug_orange_book_rating" ,"case when change_code in ('0','1','3')  then src.drug_name_cd else tgt.drug_name_cd end as drug_name_cd" ,"case when change_code in ('0','1','3')  then src.gppc else tgt.gppc end as gppc" ,"case when change_code in ('0','1','3')  then src.gen_typ_cd else tgt.gen_typ_cd end as gen_typ_cd" ,"case when change_code in ('0','1','3')  then src.gen_id_no else tgt.gen_id_no end as gen_id_no" ,"case when change_code in ('0','1','3')  then src.thera_class else tgt.thera_class end as thera_class" ,"case when change_code in ('0','1','3')  then src.lim_stabil else tgt.lim_stabil end as lim_stabil" ,"case when change_code in ('0','1','3')  then src.pack_descr else tgt.pack_descr end as pack_descr" ,"case when change_code in ('0','1','3')  then src.rx_otc_cd else tgt.rx_otc_cd end as rx_otc_cd" ,"case when change_code in ('0','1','3')  then src.maint_drug_ind else tgt.maint_drug_ind end as maint_drug_ind" ,"case when change_code in ('0','1','3')  then src.route_of_admin_cd else tgt.route_of_admin_cd end as route_of_admin_cd" ,"case when change_code in ('0','1','3')  then src.drug_generic_cd else tgt.drug_generic_cd end as drug_generic_cd" ,"case when change_code in ('0','1','3')  then src.drug_type_cd else tgt.drug_type_cd end as drug_type_cd" ,"case when change_code in ('0','1','3')  then src.drug_single_comb_cd else tgt.drug_single_comb_cd end as drug_single_comb_cd" ,"case when change_code in ('0','1','3')  then src.drug_storage_cond_cd else tgt.drug_storage_cond_cd end as drug_storage_cond_cd" ,"case when change_code in ('0','1','3')  then src.product_name else tgt.product_name end as product_name" ,"case when change_code in ('0','1','3')  then src.product_name_suffix else tgt.product_name_suffix end as product_name_suffix" ,"case when change_code in ('0','1','3')  then src.product_name_ext else tgt.product_name_ext end as product_name_ext" ,"case when change_code in ('0','1','3')  then src.product_mddb_abbr else tgt.product_mddb_abbr end as product_mddb_abbr" ,"case when change_code in ('0','1','3')  then src.gpi else tgt.gpi end as gpi" ,"case when change_code in ('0','1','3')  then src.gpi_name else tgt.gpi_name end as gpi_name" ,"case when change_code in ('0','1','3')  then src.mfg_name else tgt.mfg_name end as mfg_name" ,"case when change_code in ('0','1','3')  then src.mfg_name_abbr else tgt.mfg_name_abbr end as mfg_name_abbr" ,"case when change_code in ('0','1','3')  then src.mfg_mddb_abbr else tgt.mfg_mddb_abbr end as mfg_mddb_abbr" ,"case when change_code in ('0','1','3')  then src.mfg_name_suffix else tgt.mfg_name_suffix end as mfg_name_suffix" ,"case when change_code in ('0','1','3')  then src.drug_strength else tgt.drug_strength end as drug_strength" ,"case when change_code in ('0','1','3')  then src.drug_strength_uom else tgt.drug_strength_uom end as drug_strength_uom" ,"case when change_code in ('0','1','3')  then src.drug_dosage_form_cd else tgt.drug_dosage_form_cd end as drug_dosage_form_cd" ,"case when change_code in ('0','1','3')  then src.package_size else tgt.package_size end as package_size" ,"case when change_code in ('0','1','3')  then src.package_size_uom else tgt.package_size_uom end as package_size_uom" ,"case when change_code in ('0','1','3')  then src.package_qty else tgt.package_qty end as package_qty" ,"case when change_code in ('0','1','3')  then src.rx_to_otc_dttm else tgt.rx_to_otc_dttm end as rx_to_otc_dttm" ,"case when change_code in ('0','1','3')  then src.awp_dttm else tgt.awp_dttm end as awp_dttm" ,"case when change_code in ('0','1','3')  then src.drug_counting_cell_id else tgt.drug_counting_cell_id end as drug_counting_cell_id" ,"case when change_code in ('0','1','3')  then src.awp_unit_price else tgt.awp_unit_price end as awp_unit_price" ,"case when change_code in ('0','1','3')  then src.hcfa_dttm else tgt.hcfa_dttm end as hcfa_dttm" ,"case when change_code in ('0','1','3')  then src.hcfa_unit_limit else tgt.hcfa_unit_limit end as hcfa_unit_limit" ,"case when change_code in ('0','1','3')  then src.product_name_abbr else tgt.product_name_abbr end as product_name_abbr" ,"case when change_code in ('0','1','3')  then src.drug_status_cd else tgt.drug_status_cd end as drug_status_cd" ,"case when change_code in ('0','1','3')  then src.drug_disc_dttm else tgt.drug_disc_dttm end as drug_disc_dttm" ,"case when change_code in ('0','1','3')  then src.mfp_nbr else tgt.mfp_nbr end as mfp_nbr" ,"case when change_code in ('0','1','3')  then src.wic_nbr else tgt.wic_nbr end as wic_nbr" ,"case when change_code in ('0','1','3')  then src.drug_ppi_ind else tgt.drug_ppi_ind end as drug_ppi_ind" ,"case when change_code in ('0','1','3')  then src.drug_min_disp_qty else tgt.drug_min_disp_qty end as drug_min_disp_qty" ,"case when change_code in ('0','1','3')  then src.default_sig else tgt.default_sig end as default_sig" ,"case when change_code in ('0','1','3')  then src.default_days_supply else tgt.default_days_supply end as default_days_supply" ,"case when change_code in ('0','1','3')  then src.expiration_days else tgt.expiration_days end as expiration_days" ,"case when change_code in ('0','1','3')  then src.drug_class_except_ind else tgt.drug_class_except_ind end as drug_class_except_ind" ,"case when change_code in ('0','1','3')  then src.ops_study_dept_nbr else tgt.ops_study_dept_nbr end as ops_study_dept_nbr" ,"case when change_code in ('0','1','3')  then src.drug_warehouse_ind else tgt.drug_warehouse_ind end as drug_warehouse_ind" ,"case when change_code in ('0','1','3')  then src.pricing_protect_ind else tgt.pricing_protect_ind end as pricing_protect_ind" ,"case when change_code in ('0','1','3')  then src.pr_daco_ind else tgt.pr_daco_ind end as pr_daco_ind" ,"case when change_code in ('0','1','3')  then src.pricing_override_drug else tgt.pricing_override_drug end as pricing_override_drug" ,"case when change_code in ('0','1','3')  then src.pricing_type else tgt.pricing_type end as pricing_type" ,"case when change_code in ('0','1','3')  then src.aac_unit_price else tgt.aac_unit_price end as aac_unit_price" ,"case when change_code in ('0','1','3')  then src.wac_unit_price else tgt.wac_unit_price end as wac_unit_price" ,"case when change_code in ('0','1','3')  then src.prorated_quantity else tgt.prorated_quantity end as prorated_quantity" ,"case when change_code in ('0','1','3')  then src.pricing_quantity else tgt.pricing_quantity end as pricing_quantity" ,"case when change_code in ('0','1','3')  then src.drug_shape_cd else tgt.drug_shape_cd end as drug_shape_cd" ,"case when change_code in ('0','1','3')  then src.drug_color_1_cd else tgt.drug_color_1_cd end as drug_color_1_cd" ,"case when change_code in ('0','1','3')  then src.drug_color_2_cd else tgt.drug_color_2_cd end as drug_color_2_cd" ,"case when change_code in ('0','1','3')  then src.drug_side_1 else tgt.drug_side_1 end as drug_side_1" ,"case when change_code in ('0','1','3')  then src.drug_side_2 else tgt.drug_side_2 end as drug_side_2" ,"case when change_code in ('0','1','3')  then src.billing_ndc else tgt.billing_ndc end as billing_ndc" ,"case when change_code in ('0','1','3')  then src.drug_comment_cd else tgt.drug_comment_cd end as drug_comment_cd" ,"case when change_code in ('0','1','3')  then src.default_smart_sig else tgt.default_smart_sig end as default_smart_sig" ,"case when change_code in ('0','1','3')  then src.drug_location_cd else tgt.drug_location_cd end as drug_location_cd" ,"case when change_code in ('0','1','3')  then src.drug_multihit_disp_ind else tgt.drug_multihit_disp_ind end as drug_multihit_disp_ind" ,"case when change_code in ('0','1','3')  then src.substitution_drug_id else tgt.substitution_drug_id end as substitution_drug_id" ,"case when change_code in ('0','1','3')  then src.drug_volume else tgt.drug_volume end as drug_volume" ,"case when change_code in ('0','1','3')  then src.precount_ind else tgt.precount_ind end as precount_ind" ,"case when change_code in ('0','1','3')  then src.precount_qty_1 else tgt.precount_qty_1 end as precount_qty_1" ,"case when change_code in ('0','1','3')  then src.precount_qty_2 else tgt.precount_qty_2 end as precount_qty_2" ,"case when change_code in ('0','1','3')  then src.dur_kdc_nbr else tgt.dur_kdc_nbr end as dur_kdc_nbr" ,"case when change_code in ('0','1','3')  then src.ud_uu_pkg_cd else tgt.ud_uu_pkg_cd end as ud_uu_pkg_cd" ,"case when change_code in ('0','1','3')  then src.create_user_id else tgt.create_user_id end as create_user_id" ,"case when change_code in ('0','1','3')  then src.create_dttm else tgt.create_dttm end as create_dttm" ,"case when change_code in ('0','1','3')  then src.update_user_id else tgt.update_user_id end as update_user_id" ,"case when change_code in ('0','1','3')  then src.lbl_cmt_cd else tgt.lbl_cmt_cd end as lbl_cmt_cd" ,"case when change_code in ('0','1','3')  then src.substitution_prod_type else tgt.substitution_prod_type end as substitution_prod_type" ,"case when change_code in ('0','1','3')  then src.recon_water_qty else tgt.recon_water_qty end as recon_water_qty" ,"case when change_code in ('0','1','3')  then src.drug_spec_cmt_cd else tgt.drug_spec_cmt_cd end as drug_spec_cmt_cd" ,"case when change_code in ('0','1','3')  then src.fax_pbr_cmt_cd else tgt.fax_pbr_cmt_cd end as fax_pbr_cmt_cd" ,"case when change_code in ('0','1','3')  then src.promise_sub_drug_id else tgt.promise_sub_drug_id end as promise_sub_drug_id" ,"case when change_code in ('0','1','3')  then src.specialty_drug_ind else tgt.specialty_drug_ind end as specialty_drug_ind" ,"case when change_code in ('0','1','3')  then src.piece_weight else tgt.piece_weight end as piece_weight" ,"case when change_code in ('0','1','3')  then src.stock_bottle_barcode else tgt.stock_bottle_barcode end as stock_bottle_barcode" ,"case when change_code in ('0','1','3')  then src.doses_per_pkg else tgt.doses_per_pkg end as doses_per_pkg" ,"case when change_code in ('0','1','3')  then src.pct_tot_disc_card else tgt.pct_tot_disc_card end as pct_tot_disc_card" ,"case when change_code in ('0','1','3')  then src.pet_med_ind else tgt.pet_med_ind end as pet_med_ind" ,"case when change_code in ('0','1','3')  then src.ltd_dist_cd else tgt.ltd_dist_cd end as ltd_dist_cd" ,"case when change_code in ('0','1','3')  then src.complicated_supplies_ind else tgt.complicated_supplies_ind end as complicated_supplies_ind" ,"case when change_code in ('0','1','3')  then src.specialty_review_ind else tgt.specialty_review_ind end as specialty_review_ind" ,"case when change_code in ('0','1','3')  then src.clinical_value_ind else tgt.clinical_value_ind end as clinical_value_ind" ,"case when change_code in ('0','1','3')  then src.required_supplies_ind else tgt.required_supplies_ind end as required_supplies_ind" ,"case when change_code in ('0','1','3')  then src.hcp_drug_mltht_disp_ind else tgt.hcp_drug_mltht_disp_ind end as hcp_drug_mltht_disp_ind" ,"case when change_code in ('0','1','3')  then src.mix_ind else tgt.mix_ind end as mix_ind" ,"case when change_code in ('0','1','3')  then src.drug_image_file_name else tgt.drug_image_file_name end as drug_image_file_name" ,"case when change_code in ('0','1','3')  then src.top_drug_ind else tgt.top_drug_ind end as top_drug_ind" ,"case when change_code in ('0','1','3')  then src.quality_alert_message else tgt.quality_alert_message end as quality_alert_message" ,"case when change_code in ('0','1','3')  then src.quality_alert_keywords else tgt.quality_alert_keywords end as quality_alert_keywords" ,"case when change_code in ('0','1','3')  then src.quality_alert_rule_ind else tgt.quality_alert_rule_ind end as quality_alert_rule_ind" ,"case when change_code in ('0','1','3')  then src.quality_alert_screen_ind else tgt.quality_alert_screen_ind end as quality_alert_screen_ind" ,"case when change_code in ('0','1','3')  then src.tip_ind else tgt.tip_ind end as tip_ind" ,"case when change_code in ('0','1','3')  then src.ref_drug_id else tgt.ref_drug_id end as ref_drug_id" ,"case when change_code in ('0','1','3')  then src.hcpc else tgt.hcpc end as hcpc" ,"case when change_code in ('0','1','3')  then src.pref_mfr_ind else tgt.pref_mfr_ind end as pref_mfr_ind" ,"case when change_code in ('0','1','3')  then src.med_guide_filename else tgt.med_guide_filename end as med_guide_filename" ,"case when change_code in ('0','1','3')  then src.med_guide_ind else tgt.med_guide_ind end as med_guide_ind" ,"case when change_code in ('0','1','3')  then src.item_class else tgt.item_class end as item_class" ,"case when change_code in ('0','1','3')  then src.item_group else tgt.item_group end as item_group" ,"case when change_code in ('0','1','3')  then src.item_formulary_ind else tgt.item_formulary_ind end as item_formulary_ind" ,"case when change_code in ('0','1','3')  then src.item_category else tgt.item_category end as item_category" ,"case when change_code in ('0','1','3')  then src.item_lob else tgt.item_lob end as item_lob" ,"case when change_code in ('0','1','3')  then src.item_conv_factor else tgt.item_conv_factor end as item_conv_factor" ,"case when change_code in ('0','1','3')  then src.item_list_price_sale else tgt.item_list_price_sale end as item_list_price_sale" ,"case when change_code in ('0','1','3')  then src.item_retail_price else tgt.item_retail_price end as item_retail_price" ,"case when change_code in ('0','1','3')  then src.item_pum else tgt.item_pum end as item_pum" ,"case when change_code in ('0','1','3')  then src.item_sub_group else tgt.item_sub_group end as item_sub_group" ,"case when change_code in ('0','1','3')  then src.item_sub_category else tgt.item_sub_category end as item_sub_category" ,"case when change_code in ('0','1','3')  then src.item_sum else tgt.item_sum end as item_sum" ,"case when change_code in ('0','1','3')  then src.specific_gravity else tgt.specific_gravity end as specific_gravity" ,"case when change_code in ('0','1','3')  then src.concentration_nbr else tgt.concentration_nbr end as concentration_nbr" ,"case when change_code in ('0','1','3')  then src.concentration_units else tgt.concentration_units end as concentration_units" ,"case when change_code in ('0','1','3')  then src.lipids_ind else tgt.lipids_ind end as lipids_ind" ,"case when change_code in ('0','1','3')  then src.amino_acid_ind else tgt.amino_acid_ind end as amino_acid_ind" ,"case when change_code in ('0','1','3')  then src.poolable_ind else tgt.poolable_ind end as poolable_ind" ,"case when change_code in ('0','1','3')  then src.trace_element_ind else tgt.trace_element_ind end as trace_element_ind" ,"case when change_code in ('0','1','3')  then src.electrolyte_ind else tgt.electrolyte_ind end as electrolyte_ind" ,"case when change_code in ('0','1','3')  then src.container_material_cd else tgt.container_material_cd end as container_material_cd" ,"case when change_code in ('0','1','3')  then src.container_max_capacity else tgt.container_max_capacity end as container_max_capacity" ,"case when change_code in ('0','1','3')  then src.vehicle_ind else tgt.vehicle_ind end as vehicle_ind" ,"case when change_code in ('0','1','3')  then src.vehicle else tgt.vehicle end as vehicle" ,"case when change_code in ('0','1','3')  then src.cocktail_ind else tgt.cocktail_ind end as cocktail_ind" ,"case when change_code in ('0','1','3')  then src.base_ind else tgt.base_ind end as base_ind" ,"case when change_code in ('0','1','3')  then src.item_type else tgt.item_type end as item_type" ,"case when change_code in ('0','1','3')  then src.conc_dextrose_ind else tgt.conc_dextrose_ind end as conc_dextrose_ind" ,"case when change_code in ('0','1','3')  then src.container_ind else tgt.container_ind end as container_ind" ,"case when change_code in ('0','1','3')  then src.container_type else tgt.container_type end as container_type" ,"case when change_code in ('0','1','3')  then src.plx_drug_ind else tgt.plx_drug_ind end as plx_drug_ind" ,"case when change_code in ('0','1','3')  then src.item_size else tgt.item_size end as item_size" ,"case when change_code in ('0','1','3')  then src.item_size_units else tgt.item_size_units end as item_size_units" ,"case when change_code in ('0','1','3')  then src.item_long_desc else tgt.item_long_desc end as item_long_desc" ,"case when change_code in ('0','1','3')  then src.item_short_desc else tgt.item_short_desc end as item_short_desc" ,"case when change_code in ('0','1','3')  then src.item_awp else tgt.item_awp end as item_awp" ,"case when change_code in ('0','1','3')  then src.billing_multiplier else tgt.billing_multiplier end as billing_multiplier" ,"case when change_code in ('0','1','3')  then src.track_inventory_ind else tgt.track_inventory_ind end as track_inventory_ind" ,"case when change_code in ('0','1','3')  then src.disease_state_ind else tgt.disease_state_ind end as disease_state_ind" ,"case when change_code in ('0','1','3')  then src.drug_inference_cd else tgt.drug_inference_cd end as drug_inference_cd" ,"case when change_code in ('0','1','3')  then src.drug_min_price else tgt.drug_min_price end as drug_min_price" ,"case when change_code in ('0','1','3')  then src.excl_drug_automation_ind else tgt.excl_drug_automation_ind end as excl_drug_automation_ind" ,"case when change_code in ('0','1','3')  then src.excl_tbltp_count_ind else tgt.excl_tbltp_count_ind end as excl_tbltp_count_ind" ,"case when change_code in ('0','1','3')  then src.require_tbltp_clean else tgt.require_tbltp_clean end as require_tbltp_clean" ,"case when change_code in ('0','1','3')  then src.thera_class_extd else tgt.thera_class_extd end as thera_class_extd" ,"case when change_code in ('0','1','3')  then src.hzrds_lvl_cd else tgt.hzrds_lvl_cd end as hzrds_lvl_cd" ,"case when change_code in ('0','1','3')  then src.auth_generic_cd else tgt.auth_generic_cd end as auth_generic_cd","case when change_code in ('0','1','3')  then src.fda_ind else tgt.fda_ind end as fda_ind","case when change_code in ('0','1','3')  then src.fda_ind_value else tgt.fda_ind_value end as fda_ind_value", "case when change_code in ('0','1','3')  then src.auth_ndc_upc_hri else tgt.auth_ndc_upc_hri end as auth_ndc_upc_hri","case when change_code in ('0','1','3')  then src.auth_gen_override_ind else tgt.auth_gen_override_ind end as auth_gen_override_ind","case when change_code in ('0','1','3')  then src.ddid else tgt.ddid end as ddid","case when change_code in ('0','1','3')  then src.rxcui_type else tgt.rxcui_type end as rxcui_type","case when change_code in ('0','1','3')  then src.rxcui else tgt.rxcui end as rxcui","case when change_code in ('0','1','3')  then src.elsevier_pack_id else tgt.elsevier_pack_id end as elsevier_pack_id" ,"case when change_code in ('0','1','3')  then src.elsevier_prod_id else tgt.elsevier_prod_id end as elsevier_prod_id","case when change_code in ('0','1','3')  then src.med_dosage_unit else tgt.med_dosage_unit end as med_dosage_unit","case when change_code in ('0','1','3')  then src.med_conv_factor else tgt.med_conv_factor end as med_conv_factor" ,"case when change_code in ('0','1','3')  then src.mme_calc_factor else tgt.mme_calc_factor end as mme_calc_factor","case when change_code in ('0','1','3')  then src.etl_proc_seq_nbr else tgt.etl_proc_seq_nbr end as etl_proc_seq_nbr" ,"change_code" )
FLTR_remove_noise_upd_V0S59P2 = CDC_change_capture.filter("(cdc_before_after_cd==\"AFTER\" and change_code!=0)").drop("change_code")
FUNL_combine_upd_ins = FLTR_cdc_op_type_V0S49P4.unionByName(FLTR_remove_noise_upd_V0S59P2).select(col("cdc_txn_commit_dttm").alias("cdc_txn_commit_dttm"),col("cdc_seq_nbr").alias("cdc_seq_nbr"),col("cdc_rba_nbr").alias("cdc_rba_nbr"),col("cdc_operation_type_cd").alias("cdc_operation_type_cd"),col("cdc_before_after_cd").alias("cdc_before_after_cd"),col("edw_dml_ind").alias("edw_dml_ind"),col("edw_batch_id").alias("edw_batch_id"),col("drug_id").alias("drug_id"),col("ndc_mfg").alias("ndc_mfg"),col("ndc_prod").alias("ndc_prod"),col("ndc_pkg").alias("ndc_pkg"),col("sims_upc").alias("sims_upc"),col("repack_nbr").alias("repack_nbr"),col("ndc_form_cd").alias("ndc_form_cd"),col("ndc_prev_mfg").alias("ndc_prev_mfg"),col("ndc_prev_prod").alias("ndc_prev_prod"),col("ndc_prev_pkg").alias("ndc_prev_pkg"),col("prev_repack_nbr").alias("prev_repack_nbr"),col("ndc_prev_form_cd").alias("ndc_prev_form_cd"),col("id_form_cd").alias("id_form_cd"),col("ndc_upc_hri").alias("ndc_upc_hri"),col("dur_ndc").alias("dur_ndc"),col("prev_ndc_upc_hri").alias("prev_ndc_upc_hri"),col("prev_id_form_cd").alias("prev_id_form_cd"),col("drug_class").alias("drug_class"),col("drug_orange_book_rating").alias("drug_orange_book_rating"),col("drug_name_cd").alias("drug_name_cd"),col("gppc").alias("gppc"),col("gen_typ_cd").alias("gen_typ_cd"),col("gen_id_no").alias("gen_id_no"),col("thera_class").alias("thera_class"),col("lim_stabil").alias("lim_stabil"),col("pack_descr").alias("pack_descr"),col("rx_otc_cd").alias("rx_otc_cd"),col("maint_drug_ind").alias("maint_drug_ind"),col("route_of_admin_cd").alias("route_of_admin_cd"),col("drug_generic_cd").alias("drug_generic_cd"),col("drug_type_cd").alias("drug_type_cd"),col("drug_single_comb_cd").alias("drug_single_comb_cd"),col("drug_storage_cond_cd").alias("drug_storage_cond_cd"),col("product_name").alias("product_name"),col("product_name_suffix").alias("product_name_suffix"),col("product_name_ext").alias("product_name_ext"),col("product_mddb_abbr").alias("product_mddb_abbr"),col("gpi").alias("gpi"),col("gpi_name").alias("gpi_name"),col("mfg_name").alias("mfg_name"),col("mfg_name_abbr").alias("mfg_name_abbr"),col("mfg_mddb_abbr").alias("mfg_mddb_abbr"),col("mfg_name_suffix").alias("mfg_name_suffix"),col("drug_strength").alias("drug_strength"),col("drug_strength_uom").alias("drug_strength_uom"),col("drug_dosage_form_cd").alias("drug_dosage_form_cd"),col("package_size").alias("package_size"),col("package_size_uom").alias("package_size_uom"),col("package_qty").alias("package_qty"),col("rx_to_otc_dttm").alias("rx_to_otc_dttm"),col("awp_dttm").alias("awp_dttm"),col("drug_counting_cell_id").alias("drug_counting_cell_id"),col("awp_unit_price").alias("awp_unit_price"),col("hcfa_dttm").alias("hcfa_dttm"),col("hcfa_unit_limit").alias("hcfa_unit_limit"),col("product_name_abbr").alias("product_name_abbr"),col("drug_status_cd").alias("drug_status_cd"),col("drug_disc_dttm").alias("drug_disc_dttm"),col("mfp_nbr").alias("mfp_nbr"),col("wic_nbr").alias("wic_nbr"),col("drug_ppi_ind").alias("drug_ppi_ind"),col("drug_min_disp_qty").alias("drug_min_disp_qty"),col("default_sig").alias("default_sig"),col("default_days_supply").alias("default_days_supply"),col("expiration_days").alias("expiration_days"),col("drug_class_except_ind").alias("drug_class_except_ind"),col("ops_study_dept_nbr").alias("ops_study_dept_nbr"),col("drug_warehouse_ind").alias("drug_warehouse_ind"),col("pricing_protect_ind").alias("pricing_protect_ind"),col("pr_daco_ind").alias("pr_daco_ind"),col("pricing_override_drug").alias("pricing_override_drug"),col("pricing_type").alias("pricing_type"),col("aac_unit_price").alias("aac_unit_price"),col("wac_unit_price").alias("wac_unit_price"),col("prorated_quantity").alias("prorated_quantity"),col("pricing_quantity").alias("pricing_quantity"),col("drug_shape_cd").alias("drug_shape_cd"),col("drug_color_1_cd").alias("drug_color_1_cd"),col("drug_color_2_cd").alias("drug_color_2_cd"),col("drug_side_1").alias("drug_side_1"),col("drug_side_2").alias("drug_side_2"),col("billing_ndc").alias("billing_ndc"),col("drug_comment_cd").alias("drug_comment_cd"),col("default_smart_sig").alias("default_smart_sig"),col("drug_location_cd").alias("drug_location_cd"),col("drug_multihit_disp_ind").alias("drug_multihit_disp_ind"),col("substitution_drug_id").alias("substitution_drug_id"),col("drug_volume").alias("drug_volume"),col("precount_ind").alias("precount_ind"),col("precount_qty_1").alias("precount_qty_1"),col("precount_qty_2").alias("precount_qty_2"),col("dur_kdc_nbr").alias("dur_kdc_nbr"),col("ud_uu_pkg_cd").alias("ud_uu_pkg_cd"),col("create_user_id").alias("create_user_id"),col("create_dttm").alias("create_dttm"),col("update_user_id").alias("update_user_id"),col("lbl_cmt_cd").alias("lbl_cmt_cd"),col("substitution_prod_type").alias("substitution_prod_type"),col("recon_water_qty").alias("recon_water_qty"),col("drug_spec_cmt_cd").alias("drug_spec_cmt_cd"),col("fax_pbr_cmt_cd").alias("fax_pbr_cmt_cd"),col("promise_sub_drug_id").alias("promise_sub_drug_id"),col("specialty_drug_ind").alias("specialty_drug_ind"),col("piece_weight").alias("piece_weight"),col("stock_bottle_barcode").alias("stock_bottle_barcode"),col("doses_per_pkg").alias("doses_per_pkg"),col("pct_tot_disc_card").alias("pct_tot_disc_card"),col("pet_med_ind").alias("pet_med_ind"),col("ltd_dist_cd").alias("ltd_dist_cd"),col("complicated_supplies_ind").alias("complicated_supplies_ind"),col("specialty_review_ind").alias("specialty_review_ind"),col("clinical_value_ind").alias("clinical_value_ind"),col("required_supplies_ind").alias("required_supplies_ind"),col("hcp_drug_mltht_disp_ind").alias("hcp_drug_mltht_disp_ind"),col("mix_ind").alias("mix_ind"),col("drug_image_file_name").alias("drug_image_file_name"),col("top_drug_ind").alias("top_drug_ind"),col("quality_alert_message").alias("quality_alert_message"),col("quality_alert_keywords").alias("quality_alert_keywords"),col("quality_alert_rule_ind").alias("quality_alert_rule_ind"),col("quality_alert_screen_ind").alias("quality_alert_screen_ind"),col("tip_ind").alias("tip_ind"),col("ref_drug_id").alias("ref_drug_id"),col("hcpc").alias("hcpc"),col("pref_mfr_ind").alias("pref_mfr_ind"),col("med_guide_filename").alias("med_guide_filename"),col("med_guide_ind").alias("med_guide_ind"),col("item_class").alias("item_class"),col("item_group").alias("item_group"),col("item_formulary_ind").alias("item_formulary_ind"),col("item_category").alias("item_category"),col("item_lob").alias("item_lob"),col("item_conv_factor").alias("item_conv_factor"),col("item_list_price_sale").alias("item_list_price_sale"),col("item_retail_price").alias("item_retail_price"),col("item_pum").alias("item_pum"),col("item_sub_group").alias("item_sub_group"),col("item_sub_category").alias("item_sub_category"),col("item_sum").alias("item_sum"),col("specific_gravity").alias("specific_gravity"),col("concentration_nbr").alias("concentration_nbr"),col("concentration_units").alias("concentration_units"),col("lipids_ind").alias("lipids_ind"),col("amino_acid_ind").alias("amino_acid_ind"),col("poolable_ind").alias("poolable_ind"),col("trace_element_ind").alias("trace_element_ind"),col("electrolyte_ind").alias("electrolyte_ind"),col("container_material_cd").alias("container_material_cd"),col("container_max_capacity").alias("container_max_capacity"),col("vehicle_ind").alias("vehicle_ind"),col("vehicle").alias("vehicle"),col("cocktail_ind").alias("cocktail_ind"),col("base_ind").alias("base_ind"),col("item_type").alias("item_type"),col("conc_dextrose_ind").alias("conc_dextrose_ind"),col("container_ind").alias("container_ind"),col("container_type").alias("container_type"),col("plx_drug_ind").alias("plx_drug_ind"),col("item_size").alias("item_size"),col("item_size_units").alias("item_size_units"),col("item_long_desc").alias("item_long_desc"),col("item_short_desc").alias("item_short_desc"),col("item_awp").alias("item_awp"),col("billing_multiplier").alias("billing_multiplier"),col("track_inventory_ind").alias("track_inventory_ind"),col("disease_state_ind").alias("disease_state_ind"),col("drug_inference_cd").alias("drug_inference_cd"),col("drug_min_price").alias("drug_min_price"),col("excl_drug_automation_ind").alias("excl_drug_automation_ind"),col("excl_tbltp_count_ind").alias("excl_tbltp_count_ind"),col("require_tbltp_clean").alias("require_tbltp_clean"),col("thera_class_extd").alias("thera_class_extd"),col("etl_proc_seq_nbr").alias("etl_proc_seq_nbr"),col("hzrds_lvl_cd").alias("hzrds_lvl_cd"),col("auth_generic_cd").alias("auth_generic_cd"),col("fda_ind").alias("fda_ind"),col("fda_ind_value").alias("fda_ind_value"),col("auth_ndc_upc_hri").alias("auth_ndc_upc_hri"),col("auth_gen_override_ind").alias("auth_gen_override_ind"),col("ddid").alias("ddid"),col("rxcui_type").alias("rxcui_type"),col("rxcui").alias("rxcui"),col("elsevier_pack_id").alias("elsevier_pack_id"),col("elsevier_prod_id").alias("elsevier_prod_id"),col("med_dosage_unit").alias("med_dosage_unit"),col("med_conv_factor").alias("med_conv_factor"),col("mme_calc_factor").alias("mme_calc_factor"))
X_map_to_tgt = X_map_to_tgt_df(FUNL_combine_upd_ins)
TDENTR_edw_drug = ctx.dbFrameReader() \
  .option("query", f"""SELECT 
 tgt.drug_id
,tgt.ndc_mfgr_nbr
,tgt.ndc_prod_nbr
,tgt.ndc_pkg_cd
,tgt.sims_upc
,tgt.repack_nbr
,tgt.ndc_form_cd
,tgt.prev_ndc_mfgr_nbr
,tgt.prev_ndc_prod_nbr
,tgt.prev_ndc_pkg_cd
,tgt.prev_repack_nbr
,tgt.prev_ndc_form_cd
,tgt.upc_hri_format_cd
,tgt.ndc_upc_hri_nbr
,tgt.dur_ndc
,tgt.prev_ndc_upc_hri_nbr
,tgt.prev_upc_hri_format_cd
,tgt.dea_class_cd
,tgt.orange_book_rating
,tgt.drug_name_cd
,tgt.generic_prod_pkg_cd
,tgt.generic_id_type_cd
,tgt.generic_ingrd_id
,tgt.ahfscc_therapeutic_class_cd
,tgt.limit_stability_cd
,tgt.pkg_desc
,tgt.rx_otc_cd
,tgt.maint_drug_ind
,tgt.route_admin
,tgt.generic_drug_cd
,tgt.drug_type_cd
,tgt.drug_single_combine_cd
,tgt.drug_storage_cd
,tgt.prod_name
,tgt.prod_name_suffix
,tgt.prod_name_extn
,tgt.prod_name_medispan_abbr
,tgt.generic_prod_id
,tgt.generic_prod_id_name
,tgt.mfgr_name
,tgt.mfgr_name_abbr
,tgt.medispan_mfgr_name_abbr
,tgt.mfgr_name_suffix
,tgt.drug_strength
,tgt.drug_strength_uom
,tgt.dosage_form_cd
,tgt.pkg_sz
,tgt.pkg_sz_uom
,tgt.pkg_qty
,tgt.rx_to_otc_dt
,tgt.awp_per_unit_dlrs
,tgt.drug_cnt_cell_id
,tgt.awp_dt
,tgt.hcfa_ffp_limit_eff_dt
,tgt.hcfa_ffp_limit_dlrs
,tgt.prod_name_abbr
,tgt.drug_stat_cd
,tgt.drug_discontinue_dt
,tgt.most_freq_prescribed_nbr
,tgt.wic_nbr
,tgt.pat_pkg_insert_ind
,tgt.min_dspnsbl_metric_qty
,tgt.default_sig
,tgt.default_day_supply
,tgt.drug_expire_day
,tgt.drug_class_excpn_ind
,tgt.ops_study_dept_nbr
,tgt.drug_whse_ind
,tgt.price_protect_ind
,tgt.puerto_rico_drug_ind
,tgt.price_override_drug_id
,tgt.price_type
,tgt.aac_per_unit_dlrs
,tgt.wac_per_unit_dlrs
,tgt.prorated_qty
,tgt.price_qty
,tgt.drug_shape_cd
,tgt.primary_color_cd
,tgt.secondary_color_cd
,tgt.drug_side_1_id
,tgt.drug_side_2_id
,tgt.bill_ndc
,tgt.drug_cmnt_cd
,tgt.default_smart_sig_cd
,tgt.drug_loc_cd
,tgt.drug_multihit_display_ind
,tgt.substn_drug_id
,tgt.substn_prod_type
,tgt.drug_volume
,tgt.precount_qty_ind
,tgt.precount_qty_1
,tgt.precount_qty_2
,tgt.dur_knowledge_base_drug_cd
,tgt.unit_dose_unit_of_use_cd
,tgt.label_cmnt_cd
,tgt.reconstitute_water_qty
,tgt.drug_spcl_cmnt_cd
,tgt.fax_pbr_cmnt_cd
,tgt.promise_substn_drug_id
,tgt.spclty_drug_ind
,tgt.piece_weight
,tgt.stock_bottle_barcode
,tgt.dose_per_pkg
,tgt.tot_discnt_card_pct
,tgt.pet_drug_ind
,tgt.limit_dstrb_cd
,tgt.complicate_supplies_ind
,tgt.spclty_review_ind
,tgt.clinical_val_ind
,tgt.req_supplies_ind
,tgt.mail_drug_multihit_display_ind
,tgt.mixed_ind
,tgt.drug_image_filename
,tgt.top_drug_image_ind
,tgt.quality_alert_msg
,tgt.quality_alert_keyword
,tgt.quality_alert_rule_ind
,tgt.quality_alert_screen_ind
,tgt.tip_ind
,tgt.ref_drug_id
,tgt.hc_proc_cd
,tgt.preferred_mfgr_drug_ind
,tgt.med_guide_filename
,tgt.med_guide_print_ind
,tgt.item_class
,tgt.item_formulary_ind
,tgt.item_lob
,tgt.item_conv_factor
,tgt.item_list_price_dlrs
,tgt.item_rtl_price_dlrs
,tgt.item_prch_uom
,tgt.item_selling_uom
,tgt.specific_gravity
,tgt.conc_nbr
,tgt.drug_item_conc_unit_cd
,tgt.lipids_ind
,tgt.amino_acid_ind
,tgt.poolable_ind
,tgt.trace_element_ind
,tgt.electrolyte_ind
,tgt.contnr_material_cd
,tgt.contnr_max_capacity
,tgt.drug_vehicle_method_ind
,tgt.drug_vehicle_method
,tgt.cocktail_ind
,tgt.base_ind
,tgt.item_type_cd
,tgt.conc_dextrose_ind
,tgt.contnr_ind
,tgt.contnr_type
,tgt.plx_drug_use_ind
,tgt.item_pkg_sz
,tgt.item_pkg_sz_uom
,tgt.item_full_name
,tgt.item_short_name
,tgt.item_awp_dlrs
,tgt.item_bill_factor
,tgt.drug_disease_type_cd
,tgt.item_drug_sub_catg
,tgt.item_drug_catg
,tgt.item_drug_sub_grp
,tgt.item_drug_grp
,tgt.src_eff_dt
,tgt.src_eff_tm
,tgt.src_create_user_id
,tgt.src_update_user_id
,tgt.src_end_dt
,COALESCE(tgt.src_end_tm, time '00:00:00') AS src_end_tm
,tgt.edw_batch_id
,tgt.track_inv_ind
,tgt.src_create_dttm
,tgt.history_seq_nbr
,tgt.history_seq_cd
,tgt.inferred_drug_ind
,tgt.min_drug_price_dlrs
,tgt.excl_drug_auto_rcmd_ind
,tgt.excl_tbltop_cnt_ind
,tgt.require_tbltop_clean_ind
,tgt.ahfs_extend_therapeutic_class_cd
,tgt.hzrds_lvl_cd
,tgt.auth_generic_cd
,tgt.fda_ind
,tgt.fda_ind_value
,tgt.auth_ndc_upc_hri
,tgt.auth_gen_override_ind
,tgt.ddid
,tgt.rxcui_type
,tgt.rxcui
,tgt.elsevier_pack_id
,tgt.elsevier_prod_id
,tgt.med_dosage_unit
,tgt.med_conv_factor
,tgt.mme_calc_factor
,'U' AS edw_dml_ind
,'0' AS etl_proc_seq_nbr
FROM 
	{ctx.DP_DB_PHARMACY_HEALTHCARE}.{ctx.pTDTargetDrugTable}.drug_ic tgt,
	(SELECT drug_id FROM {ctx.DP_DB_STAGING}.{ctx.pTDTargetDrugStagingTable}.etl_tbf0_drug_stg GROUP BY 1) etl
WHERE
	tgt.drug_id = etl.drug_id
and	tgt.history_seq_cd='C';
""") \
  .load() \
  .select("drug_id", "ndc_mfgr_nbr", "ndc_prod_nbr", "ndc_pkg_cd", "sims_upc", "repack_nbr", "ndc_form_cd", "prev_ndc_mfgr_nbr", "prev_ndc_prod_nbr", "prev_ndc_pkg_cd", "prev_repack_nbr", "prev_ndc_form_cd", "upc_hri_format_cd", "ndc_upc_hri_nbr", "dur_ndc", "prev_ndc_upc_hri_nbr", "prev_upc_hri_format_cd", "dea_class_cd", "orange_book_rating", "drug_name_cd", "generic_prod_pkg_cd", "generic_id_type_cd", "generic_ingrd_id", "ahfscc_therapeutic_class_cd", "limit_stability_cd", "pkg_desc", "rx_otc_cd", "maint_drug_ind", "route_admin", "generic_drug_cd", "drug_type_cd", "drug_single_combine_cd", "drug_storage_cd", "prod_name", "prod_name_suffix", "prod_name_extn", "prod_name_medispan_abbr", "generic_prod_id", "generic_prod_id_name", "mfgr_name", "mfgr_name_abbr", "medispan_mfgr_name_abbr", "mfgr_name_suffix", "drug_strength", "drug_strength_uom", "dosage_form_cd", "pkg_sz", "pkg_sz_uom", "pkg_qty", "rx_to_otc_dt", "awp_per_unit_dlrs", "drug_cnt_cell_id", "awp_dt", "hcfa_ffp_limit_eff_dt", "hcfa_ffp_limit_dlrs", "prod_name_abbr", "drug_stat_cd", "drug_discontinue_dt", "most_freq_prescribed_nbr", "wic_nbr", "pat_pkg_insert_ind", "min_dspnsbl_metric_qty", "default_sig", "default_day_supply", "drug_expire_day", "drug_class_excpn_ind", "ops_study_dept_nbr", "drug_whse_ind", "price_protect_ind", "puerto_rico_drug_ind", "price_override_drug_id", "price_type", "aac_per_unit_dlrs", "wac_per_unit_dlrs", "prorated_qty", "price_qty", "drug_shape_cd", "primary_color_cd", "secondary_color_cd", "drug_side_1_id", "drug_side_2_id", "bill_ndc", "drug_cmnt_cd", "default_smart_sig_cd", "drug_loc_cd", "drug_multihit_display_ind", "substn_drug_id", "substn_prod_type", "drug_volume", "precount_qty_ind", "precount_qty_1", "precount_qty_2", "dur_knowledge_base_drug_cd", "unit_dose_unit_of_use_cd", "label_cmnt_cd", "reconstitute_water_qty", "drug_spcl_cmnt_cd", "fax_pbr_cmnt_cd", "promise_substn_drug_id", "spclty_drug_ind", "piece_weight", "stock_bottle_barcode", "dose_per_pkg", "tot_discnt_card_pct", "pet_drug_ind", "limit_dstrb_cd", "complicate_supplies_ind", "spclty_review_ind", "clinical_val_ind", "req_supplies_ind", "mail_drug_multihit_display_ind", "mixed_ind", "drug_image_filename", "top_drug_image_ind", "quality_alert_msg", "quality_alert_keyword", "quality_alert_rule_ind", "quality_alert_screen_ind", "tip_ind", "ref_drug_id", "hc_proc_cd", "preferred_mfgr_drug_ind", "med_guide_filename", "med_guide_print_ind", "item_class", "item_formulary_ind", "item_lob", "item_conv_factor", "item_list_price_dlrs", "item_rtl_price_dlrs", "item_prch_uom", "item_selling_uom", "specific_gravity", "conc_nbr", "drug_item_conc_unit_cd", "lipids_ind", "amino_acid_ind", "poolable_ind", "trace_element_ind", "electrolyte_ind", "contnr_material_cd", "contnr_max_capacity", "drug_vehicle_method_ind", "drug_vehicle_method", "cocktail_ind", "base_ind", "item_type_cd", "conc_dextrose_ind", "contnr_ind", "contnr_type", "plx_drug_use_ind", "item_pkg_sz", "item_pkg_sz_uom", "item_full_name", "item_short_name", "item_awp_dlrs", "item_bill_factor", "drug_disease_type_cd", "item_drug_sub_catg", "item_drug_catg", "item_drug_sub_grp", "item_drug_grp", "src_eff_dt", "src_eff_tm", "src_create_user_id", "src_update_user_id", "src_end_dt", "src_end_tm", "edw_batch_id", "track_inv_ind", "src_create_dttm", "history_seq_nbr", "history_seq_cd", "inferred_drug_ind", "min_drug_price_dlrs", "excl_drug_auto_rcmd_ind", "excl_tbltop_cnt_ind", "require_tbltop_clean_ind", "ahfs_extend_therapeutic_class_cd", "edw_dml_ind", "etl_proc_seq_nbr", "hzrds_lvl_cd","auth_generic_cd","fda_ind","fda_ind_value","auth_ndc_upc_hri","auth_gen_override_ind","ddid","rxcui_type","rxcui","elsevier_pack_id","elsevier_prod_id","med_dosage_unit","med_conv_factor","mme_calc_factor")
FUNL_combine_etl_tgt = X_map_to_tgt.unionByName(TDENTR_edw_drug).select(col("drug_id").alias("drug_id"),col("ndc_mfgr_nbr").alias("ndc_mfgr_nbr"),col("ndc_prod_nbr").alias("ndc_prod_nbr"),col("ndc_pkg_cd").alias("ndc_pkg_cd"),col("sims_upc").alias("sims_upc"),col("repack_nbr").alias("repack_nbr"),col("ndc_form_cd").alias("ndc_form_cd"),col("prev_ndc_mfgr_nbr").alias("prev_ndc_mfgr_nbr"),col("prev_ndc_prod_nbr").alias("prev_ndc_prod_nbr"),col("prev_ndc_pkg_cd").alias("prev_ndc_pkg_cd"),col("prev_repack_nbr").alias("prev_repack_nbr"),col("prev_ndc_form_cd").alias("prev_ndc_form_cd"),col("upc_hri_format_cd").alias("upc_hri_format_cd"),col("ndc_upc_hri_nbr").alias("ndc_upc_hri_nbr"),col("dur_ndc").alias("dur_ndc"),col("prev_ndc_upc_hri_nbr").alias("prev_ndc_upc_hri_nbr"),col("prev_upc_hri_format_cd").alias("prev_upc_hri_format_cd"),col("dea_class_cd").alias("dea_class_cd"),col("orange_book_rating").alias("orange_book_rating"),col("drug_name_cd").alias("drug_name_cd"),col("generic_prod_pkg_cd").alias("generic_prod_pkg_cd"),col("generic_id_type_cd").alias("generic_id_type_cd"),col("generic_ingrd_id").alias("generic_ingrd_id"),col("ahfscc_therapeutic_class_cd").alias("ahfscc_therapeutic_class_cd"),col("limit_stability_cd").alias("limit_stability_cd"),col("pkg_desc").alias("pkg_desc"),col("rx_otc_cd").alias("rx_otc_cd"),col("maint_drug_ind").alias("maint_drug_ind"),col("route_admin").alias("route_admin"),col("generic_drug_cd").alias("generic_drug_cd"),col("drug_type_cd").alias("drug_type_cd"),col("drug_single_combine_cd").alias("drug_single_combine_cd"),col("drug_storage_cd").alias("drug_storage_cd"),col("prod_name").alias("prod_name"),col("prod_name_suffix").alias("prod_name_suffix"),col("prod_name_extn").alias("prod_name_extn"),col("prod_name_medispan_abbr").alias("prod_name_medispan_abbr"),col("generic_prod_id").alias("generic_prod_id"),col("generic_prod_id_name").alias("generic_prod_id_name"),col("mfgr_name").alias("mfgr_name"),col("mfgr_name_abbr").alias("mfgr_name_abbr"),col("medispan_mfgr_name_abbr").alias("medispan_mfgr_name_abbr"),col("mfgr_name_suffix").alias("mfgr_name_suffix"),col("drug_strength").alias("drug_strength"),col("drug_strength_uom").alias("drug_strength_uom"),col("dosage_form_cd").alias("dosage_form_cd"),col("pkg_sz").alias("pkg_sz"),col("pkg_sz_uom").alias("pkg_sz_uom"),col("pkg_qty").alias("pkg_qty"),col("rx_to_otc_dt").alias("rx_to_otc_dt"),col("awp_per_unit_dlrs").alias("awp_per_unit_dlrs"),col("drug_cnt_cell_id").alias("drug_cnt_cell_id"),col("awp_dt").alias("awp_dt"),col("hcfa_ffp_limit_eff_dt").alias("hcfa_ffp_limit_eff_dt"),col("hcfa_ffp_limit_dlrs").alias("hcfa_ffp_limit_dlrs"),col("prod_name_abbr").alias("prod_name_abbr"),col("drug_stat_cd").alias("drug_stat_cd"),col("drug_discontinue_dt").alias("drug_discontinue_dt"),col("most_freq_prescribed_nbr").alias("most_freq_prescribed_nbr"),col("wic_nbr").alias("wic_nbr"),col("pat_pkg_insert_ind").alias("pat_pkg_insert_ind"),col("min_dspnsbl_metric_qty").alias("min_dspnsbl_metric_qty"),col("default_sig").alias("default_sig"),col("default_day_supply").alias("default_day_supply"),col("drug_expire_day").alias("drug_expire_day"),col("drug_class_excpn_ind").alias("drug_class_excpn_ind"),col("ops_study_dept_nbr").alias("ops_study_dept_nbr"),col("drug_whse_ind").alias("drug_whse_ind"),col("price_protect_ind").alias("price_protect_ind"),col("puerto_rico_drug_ind").alias("puerto_rico_drug_ind"),col("price_override_drug_id").alias("price_override_drug_id"),col("price_type").alias("price_type"),col("aac_per_unit_dlrs").alias("aac_per_unit_dlrs"),col("wac_per_unit_dlrs").alias("wac_per_unit_dlrs"),col("prorated_qty").alias("prorated_qty"),col("price_qty").alias("price_qty"),col("drug_shape_cd").alias("drug_shape_cd"),col("primary_color_cd").alias("primary_color_cd"),col("secondary_color_cd").alias("secondary_color_cd"),col("drug_side_1_id").alias("drug_side_1_id"),col("drug_side_2_id").alias("drug_side_2_id"),col("bill_ndc").alias("bill_ndc"),col("drug_cmnt_cd").alias("drug_cmnt_cd"),col("default_smart_sig_cd").alias("default_smart_sig_cd"),col("drug_loc_cd").alias("drug_loc_cd"),col("drug_multihit_display_ind").alias("drug_multihit_display_ind"),col("substn_drug_id").alias("substn_drug_id"),col("substn_prod_type").alias("substn_prod_type"),col("drug_volume").alias("drug_volume"),col("precount_qty_ind").alias("precount_qty_ind"),col("precount_qty_1").alias("precount_qty_1"),col("precount_qty_2").alias("precount_qty_2"),col("dur_knowledge_base_drug_cd").alias("dur_knowledge_base_drug_cd"),col("unit_dose_unit_of_use_cd").alias("unit_dose_unit_of_use_cd"),col("label_cmnt_cd").alias("label_cmnt_cd"),col("reconstitute_water_qty").alias("reconstitute_water_qty"),col("drug_spcl_cmnt_cd").alias("drug_spcl_cmnt_cd"),col("fax_pbr_cmnt_cd").alias("fax_pbr_cmnt_cd"),col("promise_substn_drug_id").alias("promise_substn_drug_id"),col("spclty_drug_ind").alias("spclty_drug_ind"),col("piece_weight").alias("piece_weight"),col("stock_bottle_barcode").alias("stock_bottle_barcode"),col("dose_per_pkg").alias("dose_per_pkg"),col("tot_discnt_card_pct").alias("tot_discnt_card_pct"),col("pet_drug_ind").alias("pet_drug_ind"),col("limit_dstrb_cd").alias("limit_dstrb_cd"),col("complicate_supplies_ind").alias("complicate_supplies_ind"),col("spclty_review_ind").alias("spclty_review_ind"),col("clinical_val_ind").alias("clinical_val_ind"),col("req_supplies_ind").alias("req_supplies_ind"),col("mail_drug_multihit_display_ind").alias("mail_drug_multihit_display_ind"),col("mixed_ind").alias("mixed_ind"),col("drug_image_filename").alias("drug_image_filename"),col("top_drug_image_ind").alias("top_drug_image_ind"),col("quality_alert_msg").alias("quality_alert_msg"),col("quality_alert_keyword").alias("quality_alert_keyword"),col("quality_alert_rule_ind").alias("quality_alert_rule_ind"),col("quality_alert_screen_ind").alias("quality_alert_screen_ind"),col("tip_ind").alias("tip_ind"),col("ref_drug_id").alias("ref_drug_id"),col("hc_proc_cd").alias("hc_proc_cd"),col("preferred_mfgr_drug_ind").alias("preferred_mfgr_drug_ind"),col("med_guide_filename").alias("med_guide_filename"),col("med_guide_print_ind").alias("med_guide_print_ind"),col("item_class").alias("item_class"),col("item_formulary_ind").alias("item_formulary_ind"),col("item_lob").alias("item_lob"),col("item_conv_factor").alias("item_conv_factor"),col("item_list_price_dlrs").alias("item_list_price_dlrs"),col("item_rtl_price_dlrs").alias("item_rtl_price_dlrs"),col("item_prch_uom").alias("item_prch_uom"),col("item_selling_uom").alias("item_selling_uom"),col("specific_gravity").alias("specific_gravity"),col("conc_nbr").alias("conc_nbr"),col("drug_item_conc_unit_cd").alias("drug_item_conc_unit_cd"),col("lipids_ind").alias("lipids_ind"),col("amino_acid_ind").alias("amino_acid_ind"),col("poolable_ind").alias("poolable_ind"),col("trace_element_ind").alias("trace_element_ind"),col("electrolyte_ind").alias("electrolyte_ind"),col("contnr_material_cd").alias("contnr_material_cd"),col("contnr_max_capacity").alias("contnr_max_capacity"),col("drug_vehicle_method_ind").alias("drug_vehicle_method_ind"),col("drug_vehicle_method").alias("drug_vehicle_method"),col("cocktail_ind").alias("cocktail_ind"),col("base_ind").alias("base_ind"),col("item_type_cd").alias("item_type_cd"),col("conc_dextrose_ind").alias("conc_dextrose_ind"),col("contnr_ind").alias("contnr_ind"),col("contnr_type").alias("contnr_type"),col("plx_drug_use_ind").alias("plx_drug_use_ind"),col("item_pkg_sz").alias("item_pkg_sz"),col("item_pkg_sz_uom").alias("item_pkg_sz_uom"),col("item_full_name").alias("item_full_name"),col("item_short_name").alias("item_short_name"),col("item_awp_dlrs").alias("item_awp_dlrs"),col("item_bill_factor").alias("item_bill_factor"),col("drug_disease_type_cd").alias("drug_disease_type_cd"),col("item_drug_sub_catg").alias("item_drug_sub_catg"),col("item_drug_catg").alias("item_drug_catg"),col("item_drug_sub_grp").alias("item_drug_sub_grp"),col("item_drug_grp").alias("item_drug_grp"),col("src_eff_dt").alias("src_eff_dt"),col("src_eff_tm").alias("src_eff_tm"),col("src_create_user_id").alias("src_create_user_id"),col("src_update_user_id").alias("src_update_user_id"),col("src_end_dt").alias("src_end_dt"),col("src_end_tm").alias("src_end_tm"),col("edw_batch_id").alias("edw_batch_id"),col("track_inv_ind").alias("track_inv_ind"),col("src_create_dttm").alias("src_create_dttm"),col("history_seq_nbr").alias("history_seq_nbr"),col("history_seq_cd").alias("history_seq_cd"),col("inferred_drug_ind").alias("inferred_drug_ind"),col("min_drug_price_dlrs").alias("min_drug_price_dlrs"),col("excl_drug_auto_rcmd_ind").alias("excl_drug_auto_rcmd_ind"),col("excl_tbltop_cnt_ind").alias("excl_tbltop_cnt_ind"),col("require_tbltop_clean_ind").alias("require_tbltop_clean_ind"),col("ahfs_extend_therapeutic_class_cd").alias("ahfs_extend_therapeutic_class_cd"),col("hzrds_lvl_cd").alias("hzrds_lvl_cd"),col("auth_generic_cd").alias("auth_generic_cd"),col("fda_ind").alias("fda_ind"),col("fda_ind_value").alias("fda_ind_value"),col("auth_ndc_upc_hri").alias("auth_ndc_upc_hri"),col("auth_gen_override_ind").alias("auth_gen_override_ind"),col("ddid").alias("ddid"),col("rxcui_type").alias("rxcui_type"),col("rxcui").alias("rxcui"),col("elsevier_pack_id").alias("elsevier_pack_id"),col("elsevier_prod_id").alias("elsevier_prod_id"),col("med_dosage_unit").alias("med_dosage_unit"),col("med_conv_factor").alias("med_conv_factor"),col("mme_calc_factor").alias("mme_calc_factor"),col("edw_dml_ind").alias("edw_dml_ind"),col("etl_proc_seq_nbr").alias("etl_proc_seq_nbr"))
funlo_combine_etl_tgt = FUNL_combine_etl_tgt
#.sort(asc("drug_id"), desc("etl_proc_seq_nbr")) \
SRT_pkey_cdc = funlo_combine_etl_tgt.alias("funlo_combine_etl_tgt").select(col("funlo_combine_etl_tgt.drug_id").alias("drug_id"), col("funlo_combine_etl_tgt.ndc_mfgr_nbr").alias("ndc_mfgr_nbr"), col("funlo_combine_etl_tgt.ndc_prod_nbr").alias("ndc_prod_nbr"), col("funlo_combine_etl_tgt.ndc_pkg_cd").alias("ndc_pkg_cd"), col("funlo_combine_etl_tgt.sims_upc").alias("sims_upc"), col("funlo_combine_etl_tgt.repack_nbr").alias("repack_nbr"), col("funlo_combine_etl_tgt.ndc_form_cd").alias("ndc_form_cd"), col("funlo_combine_etl_tgt.prev_ndc_mfgr_nbr").alias("prev_ndc_mfgr_nbr"), col("funlo_combine_etl_tgt.prev_ndc_prod_nbr").alias("prev_ndc_prod_nbr"), col("funlo_combine_etl_tgt.prev_ndc_pkg_cd").alias("prev_ndc_pkg_cd"), col("funlo_combine_etl_tgt.prev_repack_nbr").alias("prev_repack_nbr"), col("funlo_combine_etl_tgt.prev_ndc_form_cd").alias("prev_ndc_form_cd"), col("funlo_combine_etl_tgt.upc_hri_format_cd").alias("upc_hri_format_cd"), col("funlo_combine_etl_tgt.ndc_upc_hri_nbr").alias("ndc_upc_hri_nbr"), col("funlo_combine_etl_tgt.dur_ndc").alias("dur_ndc"), col("funlo_combine_etl_tgt.prev_ndc_upc_hri_nbr").alias("prev_ndc_upc_hri_nbr"), col("funlo_combine_etl_tgt.prev_upc_hri_format_cd").alias("prev_upc_hri_format_cd"), col("funlo_combine_etl_tgt.dea_class_cd").alias("dea_class_cd"), col("funlo_combine_etl_tgt.orange_book_rating").alias("orange_book_rating"), col("funlo_combine_etl_tgt.drug_name_cd").alias("drug_name_cd"), col("funlo_combine_etl_tgt.generic_prod_pkg_cd").alias("generic_prod_pkg_cd"), col("funlo_combine_etl_tgt.generic_id_type_cd").alias("generic_id_type_cd"), col("funlo_combine_etl_tgt.generic_ingrd_id").alias("generic_ingrd_id"), col("funlo_combine_etl_tgt.ahfscc_therapeutic_class_cd").alias("ahfscc_therapeutic_class_cd"), col("funlo_combine_etl_tgt.limit_stability_cd").alias("limit_stability_cd"), col("funlo_combine_etl_tgt.pkg_desc").alias("pkg_desc"), col("funlo_combine_etl_tgt.rx_otc_cd").alias("rx_otc_cd"), col("funlo_combine_etl_tgt.maint_drug_ind").alias("maint_drug_ind"), col("funlo_combine_etl_tgt.route_admin").alias("route_admin"), col("funlo_combine_etl_tgt.generic_drug_cd").alias("generic_drug_cd"), col("funlo_combine_etl_tgt.drug_type_cd").alias("drug_type_cd"), col("funlo_combine_etl_tgt.drug_single_combine_cd").alias("drug_single_combine_cd"), col("funlo_combine_etl_tgt.drug_storage_cd").alias("drug_storage_cd"), col("funlo_combine_etl_tgt.prod_name").alias("prod_name"), col("funlo_combine_etl_tgt.prod_name_suffix").alias("prod_name_suffix"), col("funlo_combine_etl_tgt.prod_name_extn").alias("prod_name_extn"), col("funlo_combine_etl_tgt.prod_name_medispan_abbr").alias("prod_name_medispan_abbr"), col("funlo_combine_etl_tgt.generic_prod_id").alias("generic_prod_id"), col("funlo_combine_etl_tgt.generic_prod_id_name").alias("generic_prod_id_name"), col("funlo_combine_etl_tgt.mfgr_name").alias("mfgr_name"), col("funlo_combine_etl_tgt.mfgr_name_abbr").alias("mfgr_name_abbr"), col("funlo_combine_etl_tgt.medispan_mfgr_name_abbr").alias("medispan_mfgr_name_abbr"), col("funlo_combine_etl_tgt.mfgr_name_suffix").alias("mfgr_name_suffix"), col("funlo_combine_etl_tgt.drug_strength").alias("drug_strength"), col("funlo_combine_etl_tgt.drug_strength_uom").alias("drug_strength_uom"), col("funlo_combine_etl_tgt.dosage_form_cd").alias("dosage_form_cd"), col("funlo_combine_etl_tgt.pkg_sz").alias("pkg_sz"), col("funlo_combine_etl_tgt.pkg_sz_uom").alias("pkg_sz_uom"), col("funlo_combine_etl_tgt.pkg_qty").alias("pkg_qty"), col("funlo_combine_etl_tgt.rx_to_otc_dt").alias("rx_to_otc_dt"), col("funlo_combine_etl_tgt.awp_per_unit_dlrs").alias("awp_per_unit_dlrs"), col("funlo_combine_etl_tgt.drug_cnt_cell_id").alias("drug_cnt_cell_id"), col("funlo_combine_etl_tgt.awp_dt").alias("awp_dt"), col("funlo_combine_etl_tgt.hcfa_ffp_limit_eff_dt").alias("hcfa_ffp_limit_eff_dt"), col("funlo_combine_etl_tgt.hcfa_ffp_limit_dlrs").alias("hcfa_ffp_limit_dlrs"), col("funlo_combine_etl_tgt.prod_name_abbr").alias("prod_name_abbr"), col("funlo_combine_etl_tgt.drug_stat_cd").alias("drug_stat_cd"), col("funlo_combine_etl_tgt.drug_discontinue_dt").alias("drug_discontinue_dt"), col("funlo_combine_etl_tgt.most_freq_prescribed_nbr").alias("most_freq_prescribed_nbr"), col("funlo_combine_etl_tgt.wic_nbr").alias("wic_nbr"), col("funlo_combine_etl_tgt.pat_pkg_insert_ind").alias("pat_pkg_insert_ind"), col("funlo_combine_etl_tgt.min_dspnsbl_metric_qty").alias("min_dspnsbl_metric_qty"), col("funlo_combine_etl_tgt.default_sig").alias("default_sig"), col("funlo_combine_etl_tgt.default_day_supply").alias("default_day_supply"), col("funlo_combine_etl_tgt.drug_expire_day").alias("drug_expire_day"), col("funlo_combine_etl_tgt.drug_class_excpn_ind").alias("drug_class_excpn_ind"), col("funlo_combine_etl_tgt.ops_study_dept_nbr").alias("ops_study_dept_nbr"), col("funlo_combine_etl_tgt.drug_whse_ind").alias("drug_whse_ind"), col("funlo_combine_etl_tgt.price_protect_ind").alias("price_protect_ind"), col("funlo_combine_etl_tgt.puerto_rico_drug_ind").alias("puerto_rico_drug_ind"), col("funlo_combine_etl_tgt.price_override_drug_id").alias("price_override_drug_id"), col("funlo_combine_etl_tgt.price_type").alias("price_type"), col("funlo_combine_etl_tgt.aac_per_unit_dlrs").alias("aac_per_unit_dlrs"), col("funlo_combine_etl_tgt.wac_per_unit_dlrs").alias("wac_per_unit_dlrs"), col("funlo_combine_etl_tgt.prorated_qty").alias("prorated_qty"), col("funlo_combine_etl_tgt.price_qty").alias("price_qty"), col("funlo_combine_etl_tgt.drug_shape_cd").alias("drug_shape_cd"), col("funlo_combine_etl_tgt.primary_color_cd").alias("primary_color_cd"), col("funlo_combine_etl_tgt.secondary_color_cd").alias("secondary_color_cd"), col("funlo_combine_etl_tgt.drug_side_1_id").alias("drug_side_1_id"), col("funlo_combine_etl_tgt.drug_side_2_id").alias("drug_side_2_id"), col("funlo_combine_etl_tgt.bill_ndc").alias("bill_ndc"), col("funlo_combine_etl_tgt.drug_cmnt_cd").alias("drug_cmnt_cd"), col("funlo_combine_etl_tgt.default_smart_sig_cd").alias("default_smart_sig_cd"), col("funlo_combine_etl_tgt.drug_loc_cd").alias("drug_loc_cd"), col("funlo_combine_etl_tgt.drug_multihit_display_ind").alias("drug_multihit_display_ind"), col("funlo_combine_etl_tgt.substn_drug_id").alias("substn_drug_id"), col("funlo_combine_etl_tgt.substn_prod_type").alias("substn_prod_type"), col("funlo_combine_etl_tgt.drug_volume").alias("drug_volume"), col("funlo_combine_etl_tgt.precount_qty_ind").alias("precount_qty_ind"), col("funlo_combine_etl_tgt.precount_qty_1").alias("precount_qty_1"), col("funlo_combine_etl_tgt.precount_qty_2").alias("precount_qty_2"), col("funlo_combine_etl_tgt.dur_knowledge_base_drug_cd").alias("dur_knowledge_base_drug_cd"), col("funlo_combine_etl_tgt.unit_dose_unit_of_use_cd").alias("unit_dose_unit_of_use_cd"), col("funlo_combine_etl_tgt.label_cmnt_cd").alias("label_cmnt_cd"), col("funlo_combine_etl_tgt.reconstitute_water_qty").alias("reconstitute_water_qty"), col("funlo_combine_etl_tgt.drug_spcl_cmnt_cd").alias("drug_spcl_cmnt_cd"), col("funlo_combine_etl_tgt.fax_pbr_cmnt_cd").alias("fax_pbr_cmnt_cd"), col("funlo_combine_etl_tgt.promise_substn_drug_id").alias("promise_substn_drug_id"), col("funlo_combine_etl_tgt.spclty_drug_ind").alias("spclty_drug_ind"), col("funlo_combine_etl_tgt.piece_weight").alias("piece_weight"), col("funlo_combine_etl_tgt.stock_bottle_barcode").alias("stock_bottle_barcode"), col("funlo_combine_etl_tgt.dose_per_pkg").alias("dose_per_pkg"), col("funlo_combine_etl_tgt.tot_discnt_card_pct").alias("tot_discnt_card_pct"), col("funlo_combine_etl_tgt.pet_drug_ind").alias("pet_drug_ind"), col("funlo_combine_etl_tgt.limit_dstrb_cd").alias("limit_dstrb_cd"), col("funlo_combine_etl_tgt.complicate_supplies_ind").alias("complicate_supplies_ind"), col("funlo_combine_etl_tgt.spclty_review_ind").alias("spclty_review_ind"), col("funlo_combine_etl_tgt.clinical_val_ind").alias("clinical_val_ind"), col("funlo_combine_etl_tgt.req_supplies_ind").alias("req_supplies_ind"), col("funlo_combine_etl_tgt.mail_drug_multihit_display_ind").alias("mail_drug_multihit_display_ind"), col("funlo_combine_etl_tgt.mixed_ind").alias("mixed_ind"), col("funlo_combine_etl_tgt.drug_image_filename").alias("drug_image_filename"), col("funlo_combine_etl_tgt.top_drug_image_ind").alias("top_drug_image_ind"), col("funlo_combine_etl_tgt.quality_alert_msg").alias("quality_alert_msg"), col("funlo_combine_etl_tgt.quality_alert_keyword").alias("quality_alert_keyword"), col("funlo_combine_etl_tgt.quality_alert_rule_ind").alias("quality_alert_rule_ind"), col("funlo_combine_etl_tgt.quality_alert_screen_ind").alias("quality_alert_screen_ind"), col("funlo_combine_etl_tgt.tip_ind").alias("tip_ind"), col("funlo_combine_etl_tgt.ref_drug_id").alias("ref_drug_id"), col("funlo_combine_etl_tgt.hc_proc_cd").alias("hc_proc_cd"), col("funlo_combine_etl_tgt.preferred_mfgr_drug_ind").alias("preferred_mfgr_drug_ind"), col("funlo_combine_etl_tgt.med_guide_filename").alias("med_guide_filename"), col("funlo_combine_etl_tgt.med_guide_print_ind").alias("med_guide_print_ind"), col("funlo_combine_etl_tgt.item_class").alias("item_class"), col("funlo_combine_etl_tgt.item_formulary_ind").alias("item_formulary_ind"), col("funlo_combine_etl_tgt.item_lob").alias("item_lob"), col("funlo_combine_etl_tgt.item_conv_factor").alias("item_conv_factor"), col("funlo_combine_etl_tgt.item_list_price_dlrs").alias("item_list_price_dlrs"), col("funlo_combine_etl_tgt.item_rtl_price_dlrs").alias("item_rtl_price_dlrs"), col("funlo_combine_etl_tgt.item_prch_uom").alias("item_prch_uom"), col("funlo_combine_etl_tgt.item_selling_uom").alias("item_selling_uom"), col("funlo_combine_etl_tgt.specific_gravity").alias("specific_gravity"), col("funlo_combine_etl_tgt.conc_nbr").alias("conc_nbr"), col("funlo_combine_etl_tgt.drug_item_conc_unit_cd").alias("drug_item_conc_unit_cd"), col("funlo_combine_etl_tgt.lipids_ind").alias("lipids_ind"), col("funlo_combine_etl_tgt.amino_acid_ind").alias("amino_acid_ind"), col("funlo_combine_etl_tgt.poolable_ind").alias("poolable_ind"), col("funlo_combine_etl_tgt.trace_element_ind").alias("trace_element_ind"), col("funlo_combine_etl_tgt.electrolyte_ind").alias("electrolyte_ind"), col("funlo_combine_etl_tgt.contnr_material_cd").alias("contnr_material_cd"), col("funlo_combine_etl_tgt.contnr_max_capacity").alias("contnr_max_capacity"), col("funlo_combine_etl_tgt.drug_vehicle_method_ind").alias("drug_vehicle_method_ind"), col("funlo_combine_etl_tgt.drug_vehicle_method").alias("drug_vehicle_method"), col("funlo_combine_etl_tgt.cocktail_ind").alias("cocktail_ind"), col("funlo_combine_etl_tgt.base_ind").alias("base_ind"), col("funlo_combine_etl_tgt.item_type_cd").alias("item_type_cd"), col("funlo_combine_etl_tgt.conc_dextrose_ind").alias("conc_dextrose_ind"), col("funlo_combine_etl_tgt.contnr_ind").alias("contnr_ind"), col("funlo_combine_etl_tgt.contnr_type").alias("contnr_type"), col("funlo_combine_etl_tgt.plx_drug_use_ind").alias("plx_drug_use_ind"), col("funlo_combine_etl_tgt.item_pkg_sz").alias("item_pkg_sz"), col("funlo_combine_etl_tgt.item_pkg_sz_uom").alias("item_pkg_sz_uom"), col("funlo_combine_etl_tgt.item_full_name").alias("item_full_name"), col("funlo_combine_etl_tgt.item_short_name").alias("item_short_name"), col("funlo_combine_etl_tgt.item_awp_dlrs").alias("item_awp_dlrs"), col("funlo_combine_etl_tgt.item_bill_factor").alias("item_bill_factor"), col("funlo_combine_etl_tgt.drug_disease_type_cd").alias("drug_disease_type_cd"), col("funlo_combine_etl_tgt.item_drug_sub_catg").alias("item_drug_sub_catg"), col("funlo_combine_etl_tgt.item_drug_catg").alias("item_drug_catg"), col("funlo_combine_etl_tgt.item_drug_sub_grp").alias("item_drug_sub_grp"), col("funlo_combine_etl_tgt.item_drug_grp").alias("item_drug_grp"), col("funlo_combine_etl_tgt.src_eff_dt").alias("src_eff_dt"), col("funlo_combine_etl_tgt.src_eff_tm").alias("src_eff_tm"), col("funlo_combine_etl_tgt.src_create_user_id").alias("src_create_user_id"), col("funlo_combine_etl_tgt.src_update_user_id").alias("src_update_user_id"), col("funlo_combine_etl_tgt.src_end_dt").alias("src_end_dt"), col("funlo_combine_etl_tgt.src_end_tm").alias("src_end_tm"), col("funlo_combine_etl_tgt.edw_batch_id").alias("edw_batch_id"), col("funlo_combine_etl_tgt.track_inv_ind").alias("track_inv_ind"), col("funlo_combine_etl_tgt.src_create_dttm").alias("src_create_dttm"), col("funlo_combine_etl_tgt.history_seq_nbr").alias("history_seq_nbr"), col("funlo_combine_etl_tgt.history_seq_cd").alias("history_seq_cd"), col("funlo_combine_etl_tgt.inferred_drug_ind").alias("inferred_drug_ind"), col("funlo_combine_etl_tgt.min_drug_price_dlrs").alias("min_drug_price_dlrs"), col("funlo_combine_etl_tgt.excl_drug_auto_rcmd_ind").alias("excl_drug_auto_rcmd_ind"), col("funlo_combine_etl_tgt.excl_tbltop_cnt_ind").alias("excl_tbltop_cnt_ind"), col("funlo_combine_etl_tgt.require_tbltop_clean_ind").alias("require_tbltop_clean_ind"), col("funlo_combine_etl_tgt.ahfs_extend_therapeutic_class_cd").alias("ahfs_extend_therapeutic_class_cd"), col("funlo_combine_etl_tgt.hzrds_lvl_cd").alias("hzrds_lvl_cd"),col("auth_generic_cd").alias("auth_generic_cd"),col("funlo_combine_etl_tgt.fda_ind").alias("fda_ind"),col("funlo_combine_etl_tgt.fda_ind_value").alias("fda_ind_value"),col("funlo_combine_etl_tgt.auth_ndc_upc_hri").alias("auth_ndc_upc_hri"),col("funlo_combine_etl_tgt.auth_gen_override_ind").alias("auth_gen_override_ind"),col("funlo_combine_etl_tgt.ddid").alias("ddid"),col("funlo_combine_etl_tgt.rxcui_type").alias("rxcui_type"),col("funlo_combine_etl_tgt.rxcui").alias("rxcui"),col("funlo_combine_etl_tgt.elsevier_pack_id").alias("elsevier_pack_id"),col("funlo_combine_etl_tgt.elsevier_prod_id").alias("elsevier_prod_id"),col("funlo_combine_etl_tgt.med_dosage_unit").alias("med_dosage_unit"),col("funlo_combine_etl_tgt.med_conv_factor").alias("med_conv_factor"),col("funlo_combine_etl_tgt.mme_calc_factor").alias("mme_calc_factor"),col("funlo_combine_etl_tgt.edw_dml_ind").alias("edw_dml_ind"), col("funlo_combine_etl_tgt.etl_proc_seq_nbr").alias("etl_proc_seq_nbr"))
srto_pkey_cdc = SRT_pkey_cdc
SRT_add_cluster_key_chng = srto_pkey_cdc.alias("srto_pkey_cdc") \
    .selectExpr("srto_pkey_cdc.drug_id as drug_id" ,"srto_pkey_cdc.ndc_mfgr_nbr as ndc_mfgr_nbr" ,"srto_pkey_cdc.ndc_prod_nbr as ndc_prod_nbr" ,"srto_pkey_cdc.ndc_pkg_cd as ndc_pkg_cd" ,"srto_pkey_cdc.sims_upc as sims_upc" ,"srto_pkey_cdc.repack_nbr as repack_nbr" ,"srto_pkey_cdc.ndc_form_cd as ndc_form_cd" ,"srto_pkey_cdc.prev_ndc_mfgr_nbr as prev_ndc_mfgr_nbr" ,"srto_pkey_cdc.prev_ndc_prod_nbr as prev_ndc_prod_nbr" ,"srto_pkey_cdc.prev_ndc_pkg_cd as prev_ndc_pkg_cd" ,"srto_pkey_cdc.prev_repack_nbr as prev_repack_nbr" ,"srto_pkey_cdc.prev_ndc_form_cd as prev_ndc_form_cd" ,"srto_pkey_cdc.upc_hri_format_cd as upc_hri_format_cd" ,"srto_pkey_cdc.ndc_upc_hri_nbr as ndc_upc_hri_nbr" ,"srto_pkey_cdc.dur_ndc as dur_ndc" ,"srto_pkey_cdc.prev_ndc_upc_hri_nbr as prev_ndc_upc_hri_nbr" ,"srto_pkey_cdc.prev_upc_hri_format_cd as prev_upc_hri_format_cd" ,"srto_pkey_cdc.dea_class_cd as dea_class_cd" ,"srto_pkey_cdc.orange_book_rating as orange_book_rating" ,"srto_pkey_cdc.drug_name_cd as drug_name_cd" ,"srto_pkey_cdc.generic_prod_pkg_cd as generic_prod_pkg_cd" ,"srto_pkey_cdc.generic_id_type_cd as generic_id_type_cd" ,"srto_pkey_cdc.generic_ingrd_id as generic_ingrd_id" ,"srto_pkey_cdc.ahfscc_therapeutic_class_cd as ahfscc_therapeutic_class_cd" ,"srto_pkey_cdc.limit_stability_cd as limit_stability_cd" ,"srto_pkey_cdc.pkg_desc as pkg_desc" ,"srto_pkey_cdc.rx_otc_cd as rx_otc_cd" ,"srto_pkey_cdc.maint_drug_ind as maint_drug_ind" ,"srto_pkey_cdc.route_admin as route_admin" ,"srto_pkey_cdc.generic_drug_cd as generic_drug_cd" ,"srto_pkey_cdc.drug_type_cd as drug_type_cd" ,"srto_pkey_cdc.drug_single_combine_cd as drug_single_combine_cd" ,"srto_pkey_cdc.drug_storage_cd as drug_storage_cd" ,"srto_pkey_cdc.prod_name as prod_name" ,"srto_pkey_cdc.prod_name_suffix as prod_name_suffix" ,"srto_pkey_cdc.prod_name_extn as prod_name_extn" ,"srto_pkey_cdc.prod_name_medispan_abbr as prod_name_medispan_abbr" ,"srto_pkey_cdc.generic_prod_id as generic_prod_id" ,"srto_pkey_cdc.generic_prod_id_name as generic_prod_id_name" ,"srto_pkey_cdc.mfgr_name as mfgr_name" ,"srto_pkey_cdc.mfgr_name_abbr as mfgr_name_abbr" ,"srto_pkey_cdc.medispan_mfgr_name_abbr as medispan_mfgr_name_abbr" ,"srto_pkey_cdc.mfgr_name_suffix as mfgr_name_suffix" ,"srto_pkey_cdc.drug_strength as drug_strength" ,"srto_pkey_cdc.drug_strength_uom as drug_strength_uom" ,"srto_pkey_cdc.dosage_form_cd as dosage_form_cd" ,"srto_pkey_cdc.pkg_sz as pkg_sz" ,"srto_pkey_cdc.pkg_sz_uom as pkg_sz_uom" ,"srto_pkey_cdc.pkg_qty as pkg_qty" ,"srto_pkey_cdc.rx_to_otc_dt as rx_to_otc_dt" ,"srto_pkey_cdc.awp_per_unit_dlrs as awp_per_unit_dlrs" ,"srto_pkey_cdc.drug_cnt_cell_id as drug_cnt_cell_id" ,"srto_pkey_cdc.awp_dt as awp_dt" ,"srto_pkey_cdc.hcfa_ffp_limit_eff_dt as hcfa_ffp_limit_eff_dt" ,"srto_pkey_cdc.hcfa_ffp_limit_dlrs as hcfa_ffp_limit_dlrs" ,"srto_pkey_cdc.prod_name_abbr as prod_name_abbr" ,"srto_pkey_cdc.drug_stat_cd as drug_stat_cd" ,"srto_pkey_cdc.drug_discontinue_dt as drug_discontinue_dt" ,"srto_pkey_cdc.most_freq_prescribed_nbr as most_freq_prescribed_nbr" ,"srto_pkey_cdc.wic_nbr as wic_nbr" ,"srto_pkey_cdc.pat_pkg_insert_ind as pat_pkg_insert_ind" ,"srto_pkey_cdc.min_dspnsbl_metric_qty as min_dspnsbl_metric_qty" ,"srto_pkey_cdc.default_sig as default_sig" ,"srto_pkey_cdc.default_day_supply as default_day_supply" ,"srto_pkey_cdc.drug_expire_day as drug_expire_day" ,"srto_pkey_cdc.drug_class_excpn_ind as drug_class_excpn_ind" ,"srto_pkey_cdc.ops_study_dept_nbr as ops_study_dept_nbr" ,"srto_pkey_cdc.drug_whse_ind as drug_whse_ind" ,"srto_pkey_cdc.price_protect_ind as price_protect_ind" ,"srto_pkey_cdc.puerto_rico_drug_ind as puerto_rico_drug_ind" ,"srto_pkey_cdc.price_override_drug_id as price_override_drug_id" ,"srto_pkey_cdc.price_type as price_type" ,"srto_pkey_cdc.aac_per_unit_dlrs as aac_per_unit_dlrs" ,"srto_pkey_cdc.wac_per_unit_dlrs as wac_per_unit_dlrs" ,"srto_pkey_cdc.prorated_qty as prorated_qty" ,"srto_pkey_cdc.price_qty as price_qty" ,"srto_pkey_cdc.drug_shape_cd as drug_shape_cd" ,"srto_pkey_cdc.primary_color_cd as primary_color_cd" ,"srto_pkey_cdc.secondary_color_cd as secondary_color_cd" ,"srto_pkey_cdc.drug_side_1_id as drug_side_1_id" ,"srto_pkey_cdc.drug_side_2_id as drug_side_2_id" ,"srto_pkey_cdc.bill_ndc as bill_ndc" ,"srto_pkey_cdc.drug_cmnt_cd as drug_cmnt_cd" ,"srto_pkey_cdc.default_smart_sig_cd as default_smart_sig_cd" ,"srto_pkey_cdc.drug_loc_cd as drug_loc_cd" ,"srto_pkey_cdc.drug_multihit_display_ind as drug_multihit_display_ind" ,"srto_pkey_cdc.substn_drug_id as substn_drug_id" ,"srto_pkey_cdc.substn_prod_type as substn_prod_type" ,"srto_pkey_cdc.drug_volume as drug_volume" ,"srto_pkey_cdc.precount_qty_ind as precount_qty_ind" ,"srto_pkey_cdc.precount_qty_1 as precount_qty_1" ,"srto_pkey_cdc.precount_qty_2 as precount_qty_2" ,"srto_pkey_cdc.dur_knowledge_base_drug_cd as dur_knowledge_base_drug_cd" ,"srto_pkey_cdc.unit_dose_unit_of_use_cd as unit_dose_unit_of_use_cd" ,"srto_pkey_cdc.label_cmnt_cd as label_cmnt_cd" ,"srto_pkey_cdc.reconstitute_water_qty as reconstitute_water_qty" ,"srto_pkey_cdc.drug_spcl_cmnt_cd as drug_spcl_cmnt_cd" ,"srto_pkey_cdc.fax_pbr_cmnt_cd as fax_pbr_cmnt_cd" ,"srto_pkey_cdc.promise_substn_drug_id as promise_substn_drug_id" ,"srto_pkey_cdc.spclty_drug_ind as spclty_drug_ind" ,"srto_pkey_cdc.piece_weight as piece_weight" ,"srto_pkey_cdc.stock_bottle_barcode as stock_bottle_barcode" ,"srto_pkey_cdc.dose_per_pkg as dose_per_pkg" ,"srto_pkey_cdc.tot_discnt_card_pct as tot_discnt_card_pct" ,"srto_pkey_cdc.pet_drug_ind as pet_drug_ind" ,"srto_pkey_cdc.limit_dstrb_cd as limit_dstrb_cd" ,"srto_pkey_cdc.complicate_supplies_ind as complicate_supplies_ind" ,"srto_pkey_cdc.spclty_review_ind as spclty_review_ind" ,"srto_pkey_cdc.clinical_val_ind as clinical_val_ind" ,"srto_pkey_cdc.req_supplies_ind as req_supplies_ind" ,"srto_pkey_cdc.mail_drug_multihit_display_ind as mail_drug_multihit_display_ind" ,"srto_pkey_cdc.mixed_ind as mixed_ind" ,"srto_pkey_cdc.drug_image_filename as drug_image_filename" ,"srto_pkey_cdc.top_drug_image_ind as top_drug_image_ind" ,"srto_pkey_cdc.quality_alert_msg as quality_alert_msg" ,"srto_pkey_cdc.quality_alert_keyword as quality_alert_keyword" ,"srto_pkey_cdc.quality_alert_rule_ind as quality_alert_rule_ind" ,"srto_pkey_cdc.quality_alert_screen_ind as quality_alert_screen_ind" ,"srto_pkey_cdc.tip_ind as tip_ind" ,"srto_pkey_cdc.ref_drug_id as ref_drug_id" ,"srto_pkey_cdc.hc_proc_cd as hc_proc_cd" ,"srto_pkey_cdc.preferred_mfgr_drug_ind as preferred_mfgr_drug_ind" ,"srto_pkey_cdc.med_guide_filename as med_guide_filename" ,"srto_pkey_cdc.med_guide_print_ind as med_guide_print_ind" ,"srto_pkey_cdc.item_class as item_class" ,"srto_pkey_cdc.item_formulary_ind as item_formulary_ind" ,"srto_pkey_cdc.item_lob as item_lob" ,"srto_pkey_cdc.item_conv_factor as item_conv_factor" ,"srto_pkey_cdc.item_list_price_dlrs as item_list_price_dlrs" ,"srto_pkey_cdc.item_rtl_price_dlrs as item_rtl_price_dlrs" ,"srto_pkey_cdc.item_prch_uom as item_prch_uom" ,"srto_pkey_cdc.item_selling_uom as item_selling_uom" ,"srto_pkey_cdc.specific_gravity as specific_gravity" ,"srto_pkey_cdc.conc_nbr as conc_nbr" ,"srto_pkey_cdc.drug_item_conc_unit_cd as drug_item_conc_unit_cd" ,"srto_pkey_cdc.lipids_ind as lipids_ind" ,"srto_pkey_cdc.amino_acid_ind as amino_acid_ind" ,"srto_pkey_cdc.poolable_ind as poolable_ind" ,"srto_pkey_cdc.trace_element_ind as trace_element_ind" ,"srto_pkey_cdc.electrolyte_ind as electrolyte_ind" ,"srto_pkey_cdc.contnr_material_cd as contnr_material_cd" ,"srto_pkey_cdc.contnr_max_capacity as contnr_max_capacity" ,"srto_pkey_cdc.drug_vehicle_method_ind as drug_vehicle_method_ind" ,"srto_pkey_cdc.drug_vehicle_method as drug_vehicle_method" ,"srto_pkey_cdc.cocktail_ind as cocktail_ind" ,"srto_pkey_cdc.base_ind as base_ind" ,"srto_pkey_cdc.item_type_cd as item_type_cd" ,"srto_pkey_cdc.conc_dextrose_ind as conc_dextrose_ind" ,"srto_pkey_cdc.contnr_ind as contnr_ind" ,"srto_pkey_cdc.contnr_type as contnr_type" ,"srto_pkey_cdc.plx_drug_use_ind as plx_drug_use_ind" ,"srto_pkey_cdc.item_pkg_sz as item_pkg_sz" ,"srto_pkey_cdc.item_pkg_sz_uom as item_pkg_sz_uom" ,"srto_pkey_cdc.item_full_name as item_full_name" ,"srto_pkey_cdc.item_short_name as item_short_name" ,"srto_pkey_cdc.item_awp_dlrs as item_awp_dlrs" ,"srto_pkey_cdc.item_bill_factor as item_bill_factor" ,"srto_pkey_cdc.drug_disease_type_cd as drug_disease_type_cd" ,"srto_pkey_cdc.item_drug_sub_catg as item_drug_sub_catg" ,"srto_pkey_cdc.item_drug_catg as item_drug_catg" ,"srto_pkey_cdc.item_drug_sub_grp as item_drug_sub_grp" ,"srto_pkey_cdc.item_drug_grp as item_drug_grp" ,"srto_pkey_cdc.src_eff_dt as src_eff_dt" ,"srto_pkey_cdc.src_eff_tm as src_eff_tm" ,"srto_pkey_cdc.src_create_user_id as src_create_user_id" ,"srto_pkey_cdc.src_update_user_id as src_update_user_id" ,"srto_pkey_cdc.src_end_dt as src_end_dt" ,"srto_pkey_cdc.src_end_tm as src_end_tm" ,"srto_pkey_cdc.edw_batch_id as edw_batch_id" ,"srto_pkey_cdc.track_inv_ind as track_inv_ind" ,"srto_pkey_cdc.src_create_dttm as src_create_dttm" ,"srto_pkey_cdc.history_seq_nbr as history_seq_nbr" ,"srto_pkey_cdc.history_seq_cd as history_seq_cd" ,"srto_pkey_cdc.inferred_drug_ind as inferred_drug_ind" ,"srto_pkey_cdc.min_drug_price_dlrs as min_drug_price_dlrs" ,"srto_pkey_cdc.excl_drug_auto_rcmd_ind as excl_drug_auto_rcmd_ind" ,"srto_pkey_cdc.excl_tbltop_cnt_ind as excl_tbltop_cnt_ind" ,"srto_pkey_cdc.require_tbltop_clean_ind as require_tbltop_clean_ind" ,"srto_pkey_cdc.ahfs_extend_therapeutic_class_cd as ahfs_extend_therapeutic_class_cd" ,"srto_pkey_cdc.hzrds_lvl_cd as hzrds_lvl_cd","srto_pkey_cdc.auth_generic_cd as auth_generic_cd","srto_pkey_cdc.fda_ind as fda_ind","srto_pkey_cdc.fda_ind_value as fda_ind_value","srto_pkey_cdc.auth_ndc_upc_hri as auth_ndc_upc_hri","srto_pkey_cdc.auth_gen_override_ind as auth_gen_override_ind","srto_pkey_cdc.ddid as ddid","srto_pkey_cdc.rxcui_type as rxcui_type","srto_pkey_cdc.rxcui as rxcui","srto_pkey_cdc.elsevier_pack_id as elsevier_pack_id","srto_pkey_cdc.elsevier_prod_id as elsevier_prod_id","srto_pkey_cdc.med_dosage_unit as med_dosage_unit","srto_pkey_cdc.med_conv_factor as med_conv_factor","srto_pkey_cdc.mme_calc_factor as mme_calc_factor","srto_pkey_cdc.edw_dml_ind as edw_dml_ind" ,"srto_pkey_cdc.etl_proc_seq_nbr as etl_proc_seq_nbr" ,"case when (row_number() over(partition By drug_id order By etl_proc_seq_nbr desc) = 1) then 1 else 0 end as clusterKeyChange" )
drugDatewindow = Window().orderBy("drug_id")
window_spec_lag = Window.partitionBy("drug_id").orderBy(desc("etl_proc_seq_nbr"))
X_enddt_histseqcd_filter = SRT_add_cluster_key_chng.withColumn("identifyTGTnoise",expr("case when clusterKeyChange = 1 AND edw_dml_ind = 'U' THEN 1 else 0 END")).filter("identifyTGTnoise == \"0\"").withColumn("CurrEffDttm",concat(SRT_add_cluster_key_chng.src_eff_dt, lit(" ") ,SRT_add_cluster_key_chng.src_eff_tm)).withColumn("PrevEffDttm",concat(F.lag(SRT_add_cluster_key_chng.src_eff_dt,1).over(drugDatewindow) , lit(" ") ,F.lag(SRT_add_cluster_key_chng.src_eff_tm,1).over(drugDatewindow) )).withColumn("SrcEndDt",when(col("clusterKeyChange") == lit("0") , F.lag(SRT_add_cluster_key_chng.src_eff_dt,1).over(drugDatewindow)).otherwise("NULL")).withColumn("SrcEndTm",when(col("clusterKeyChange") == lit("0") , F.lag(SRT_add_cluster_key_chng.src_eff_tm,1).over(drugDatewindow)).otherwise("NULL")).selectExpr( "*","case when clusterKeyChange = 1 then 'C' when clusterKeyChange = 0 AND CurrEffDttm <> PrevEffDttm THEN 'H' when clusterKeyChange = 0 AND CurrEffDttm = PrevEffDttm THEN 'L' else '?' end as HistSeqCd" )
X_enddt_histseqcd = X_enddt_histseqcd_df(X_enddt_histseqcd_filter)
xo_enddt_histseq_cd = X_enddt_histseqcd
SRT_pkey_cdc_asc_add_clstr = xo_enddt_histseq_cd.alias("xo_enddt_histseq_cd") \
    .selectExpr("xo_enddt_histseq_cd.drug_id as drug_id" ,"xo_enddt_histseq_cd.ndc_mfgr_nbr as ndc_mfgr_nbr" ,"xo_enddt_histseq_cd.ndc_prod_nbr as ndc_prod_nbr" ,"xo_enddt_histseq_cd.ndc_pkg_cd as ndc_pkg_cd" ,"xo_enddt_histseq_cd.sims_upc as sims_upc" ,"xo_enddt_histseq_cd.repack_nbr as repack_nbr" ,"xo_enddt_histseq_cd.ndc_form_cd as ndc_form_cd" ,"xo_enddt_histseq_cd.prev_ndc_mfgr_nbr as prev_ndc_mfgr_nbr" ,"xo_enddt_histseq_cd.prev_ndc_prod_nbr as prev_ndc_prod_nbr" ,"xo_enddt_histseq_cd.prev_ndc_pkg_cd as prev_ndc_pkg_cd" ,"xo_enddt_histseq_cd.prev_repack_nbr as prev_repack_nbr" ,"xo_enddt_histseq_cd.prev_ndc_form_cd as prev_ndc_form_cd" ,"xo_enddt_histseq_cd.upc_hri_format_cd as upc_hri_format_cd" ,"xo_enddt_histseq_cd.ndc_upc_hri_nbr as ndc_upc_hri_nbr" ,"xo_enddt_histseq_cd.dur_ndc as dur_ndc" ,"xo_enddt_histseq_cd.prev_ndc_upc_hri_nbr as prev_ndc_upc_hri_nbr" ,"xo_enddt_histseq_cd.prev_upc_hri_format_cd as prev_upc_hri_format_cd" ,"xo_enddt_histseq_cd.dea_class_cd as dea_class_cd" ,"xo_enddt_histseq_cd.orange_book_rating as orange_book_rating" ,"xo_enddt_histseq_cd.drug_name_cd as drug_name_cd" ,"xo_enddt_histseq_cd.generic_prod_pkg_cd as generic_prod_pkg_cd" ,"xo_enddt_histseq_cd.generic_id_type_cd as generic_id_type_cd" ,"xo_enddt_histseq_cd.generic_ingrd_id as generic_ingrd_id" ,"xo_enddt_histseq_cd.ahfscc_therapeutic_class_cd as ahfscc_therapeutic_class_cd" ,"xo_enddt_histseq_cd.limit_stability_cd as limit_stability_cd" ,"xo_enddt_histseq_cd.pkg_desc as pkg_desc" ,"xo_enddt_histseq_cd.rx_otc_cd as rx_otc_cd" ,"xo_enddt_histseq_cd.maint_drug_ind as maint_drug_ind" ,"xo_enddt_histseq_cd.route_admin as route_admin" ,"xo_enddt_histseq_cd.generic_drug_cd as generic_drug_cd" ,"xo_enddt_histseq_cd.drug_type_cd as drug_type_cd" ,"xo_enddt_histseq_cd.drug_single_combine_cd as drug_single_combine_cd" ,"xo_enddt_histseq_cd.drug_storage_cd as drug_storage_cd" ,"xo_enddt_histseq_cd.prod_name as prod_name" ,"xo_enddt_histseq_cd.prod_name_suffix as prod_name_suffix" ,"xo_enddt_histseq_cd.prod_name_extn as prod_name_extn" ,"xo_enddt_histseq_cd.prod_name_medispan_abbr as prod_name_medispan_abbr" ,"xo_enddt_histseq_cd.generic_prod_id as generic_prod_id" ,"xo_enddt_histseq_cd.generic_prod_id_name as generic_prod_id_name" ,"xo_enddt_histseq_cd.mfgr_name as mfgr_name" ,"xo_enddt_histseq_cd.mfgr_name_abbr as mfgr_name_abbr" ,"xo_enddt_histseq_cd.medispan_mfgr_name_abbr as medispan_mfgr_name_abbr" ,"xo_enddt_histseq_cd.mfgr_name_suffix as mfgr_name_suffix" ,"xo_enddt_histseq_cd.drug_strength as drug_strength" ,"xo_enddt_histseq_cd.drug_strength_uom as drug_strength_uom" ,"xo_enddt_histseq_cd.dosage_form_cd as dosage_form_cd" ,"xo_enddt_histseq_cd.pkg_sz as pkg_sz" ,"xo_enddt_histseq_cd.pkg_sz_uom as pkg_sz_uom" ,"xo_enddt_histseq_cd.pkg_qty as pkg_qty" ,"xo_enddt_histseq_cd.rx_to_otc_dt as rx_to_otc_dt" ,"xo_enddt_histseq_cd.awp_per_unit_dlrs as awp_per_unit_dlrs" ,"xo_enddt_histseq_cd.drug_cnt_cell_id as drug_cnt_cell_id" ,"xo_enddt_histseq_cd.awp_dt as awp_dt" ,"xo_enddt_histseq_cd.hcfa_ffp_limit_eff_dt as hcfa_ffp_limit_eff_dt" ,"xo_enddt_histseq_cd.hcfa_ffp_limit_dlrs as hcfa_ffp_limit_dlrs" ,"xo_enddt_histseq_cd.prod_name_abbr as prod_name_abbr" ,"xo_enddt_histseq_cd.drug_stat_cd as drug_stat_cd" ,"xo_enddt_histseq_cd.drug_discontinue_dt as drug_discontinue_dt" ,"xo_enddt_histseq_cd.most_freq_prescribed_nbr as most_freq_prescribed_nbr" ,"xo_enddt_histseq_cd.wic_nbr as wic_nbr" ,"xo_enddt_histseq_cd.pat_pkg_insert_ind as pat_pkg_insert_ind" ,"xo_enddt_histseq_cd.min_dspnsbl_metric_qty as min_dspnsbl_metric_qty" ,"xo_enddt_histseq_cd.default_sig as default_sig" ,"xo_enddt_histseq_cd.default_day_supply as default_day_supply" ,"xo_enddt_histseq_cd.drug_expire_day as drug_expire_day" ,"xo_enddt_histseq_cd.drug_class_excpn_ind as drug_class_excpn_ind" ,"xo_enddt_histseq_cd.ops_study_dept_nbr as ops_study_dept_nbr" ,"xo_enddt_histseq_cd.drug_whse_ind as drug_whse_ind" ,"xo_enddt_histseq_cd.price_protect_ind as price_protect_ind" ,"xo_enddt_histseq_cd.puerto_rico_drug_ind as puerto_rico_drug_ind" ,"xo_enddt_histseq_cd.price_override_drug_id as price_override_drug_id" ,"xo_enddt_histseq_cd.price_type as price_type" ,"xo_enddt_histseq_cd.aac_per_unit_dlrs as aac_per_unit_dlrs" ,"xo_enddt_histseq_cd.wac_per_unit_dlrs as wac_per_unit_dlrs" ,"xo_enddt_histseq_cd.prorated_qty as prorated_qty" ,"xo_enddt_histseq_cd.price_qty as price_qty" ,"xo_enddt_histseq_cd.drug_shape_cd as drug_shape_cd" ,"xo_enddt_histseq_cd.primary_color_cd as primary_color_cd" ,"xo_enddt_histseq_cd.secondary_color_cd as secondary_color_cd" ,"xo_enddt_histseq_cd.drug_side_1_id as drug_side_1_id" ,"xo_enddt_histseq_cd.drug_side_2_id as drug_side_2_id" ,"xo_enddt_histseq_cd.bill_ndc as bill_ndc" ,"xo_enddt_histseq_cd.drug_cmnt_cd as drug_cmnt_cd" ,"xo_enddt_histseq_cd.default_smart_sig_cd as default_smart_sig_cd" ,"xo_enddt_histseq_cd.drug_loc_cd as drug_loc_cd" ,"xo_enddt_histseq_cd.drug_multihit_display_ind as drug_multihit_display_ind" ,"xo_enddt_histseq_cd.substn_drug_id as substn_drug_id" ,"xo_enddt_histseq_cd.substn_prod_type as substn_prod_type" ,"xo_enddt_histseq_cd.drug_volume as drug_volume" ,"xo_enddt_histseq_cd.precount_qty_ind as precount_qty_ind" ,"xo_enddt_histseq_cd.precount_qty_1 as precount_qty_1" ,"xo_enddt_histseq_cd.precount_qty_2 as precount_qty_2" ,"xo_enddt_histseq_cd.dur_knowledge_base_drug_cd as dur_knowledge_base_drug_cd" ,"xo_enddt_histseq_cd.unit_dose_unit_of_use_cd as unit_dose_unit_of_use_cd" ,"xo_enddt_histseq_cd.label_cmnt_cd as label_cmnt_cd" ,"xo_enddt_histseq_cd.reconstitute_water_qty as reconstitute_water_qty" ,"xo_enddt_histseq_cd.drug_spcl_cmnt_cd as drug_spcl_cmnt_cd" ,"xo_enddt_histseq_cd.fax_pbr_cmnt_cd as fax_pbr_cmnt_cd" ,"xo_enddt_histseq_cd.promise_substn_drug_id as promise_substn_drug_id" ,"xo_enddt_histseq_cd.spclty_drug_ind as spclty_drug_ind" ,"xo_enddt_histseq_cd.piece_weight as piece_weight" ,"xo_enddt_histseq_cd.stock_bottle_barcode as stock_bottle_barcode" ,"xo_enddt_histseq_cd.dose_per_pkg as dose_per_pkg" ,"xo_enddt_histseq_cd.tot_discnt_card_pct as tot_discnt_card_pct" ,"xo_enddt_histseq_cd.pet_drug_ind as pet_drug_ind" ,"xo_enddt_histseq_cd.limit_dstrb_cd as limit_dstrb_cd" ,"xo_enddt_histseq_cd.complicate_supplies_ind as complicate_supplies_ind" ,"xo_enddt_histseq_cd.spclty_review_ind as spclty_review_ind" ,"xo_enddt_histseq_cd.clinical_val_ind as clinical_val_ind" ,"xo_enddt_histseq_cd.req_supplies_ind as req_supplies_ind" ,"xo_enddt_histseq_cd.mail_drug_multihit_display_ind as mail_drug_multihit_display_ind" ,"xo_enddt_histseq_cd.mixed_ind as mixed_ind" ,"xo_enddt_histseq_cd.drug_image_filename as drug_image_filename" ,"xo_enddt_histseq_cd.top_drug_image_ind as top_drug_image_ind" ,"xo_enddt_histseq_cd.quality_alert_msg as quality_alert_msg" ,"xo_enddt_histseq_cd.quality_alert_keyword as quality_alert_keyword" ,"xo_enddt_histseq_cd.quality_alert_rule_ind as quality_alert_rule_ind" ,"xo_enddt_histseq_cd.quality_alert_screen_ind as quality_alert_screen_ind" ,"xo_enddt_histseq_cd.tip_ind as tip_ind" ,"xo_enddt_histseq_cd.ref_drug_id as ref_drug_id" ,"xo_enddt_histseq_cd.hc_proc_cd as hc_proc_cd" ,"xo_enddt_histseq_cd.preferred_mfgr_drug_ind as preferred_mfgr_drug_ind" ,"xo_enddt_histseq_cd.med_guide_filename as med_guide_filename" ,"xo_enddt_histseq_cd.med_guide_print_ind as med_guide_print_ind" ,"xo_enddt_histseq_cd.item_class as item_class" ,"xo_enddt_histseq_cd.item_formulary_ind as item_formulary_ind" ,"xo_enddt_histseq_cd.item_lob as item_lob" ,"xo_enddt_histseq_cd.item_conv_factor as item_conv_factor" ,"xo_enddt_histseq_cd.item_list_price_dlrs as item_list_price_dlrs" ,"xo_enddt_histseq_cd.item_rtl_price_dlrs as item_rtl_price_dlrs" ,"xo_enddt_histseq_cd.item_prch_uom as item_prch_uom" ,"xo_enddt_histseq_cd.item_selling_uom as item_selling_uom" ,"xo_enddt_histseq_cd.specific_gravity as specific_gravity" ,"xo_enddt_histseq_cd.conc_nbr as conc_nbr" ,"xo_enddt_histseq_cd.drug_item_conc_unit_cd as drug_item_conc_unit_cd" ,"xo_enddt_histseq_cd.lipids_ind as lipids_ind" ,"xo_enddt_histseq_cd.amino_acid_ind as amino_acid_ind" ,"xo_enddt_histseq_cd.poolable_ind as poolable_ind" ,"xo_enddt_histseq_cd.trace_element_ind as trace_element_ind" ,"xo_enddt_histseq_cd.electrolyte_ind as electrolyte_ind" ,"xo_enddt_histseq_cd.contnr_material_cd as contnr_material_cd" ,"xo_enddt_histseq_cd.contnr_max_capacity as contnr_max_capacity" ,"xo_enddt_histseq_cd.drug_vehicle_method_ind as drug_vehicle_method_ind" ,"xo_enddt_histseq_cd.drug_vehicle_method as drug_vehicle_method" ,"xo_enddt_histseq_cd.cocktail_ind as cocktail_ind" ,"xo_enddt_histseq_cd.base_ind as base_ind" ,"xo_enddt_histseq_cd.item_type_cd as item_type_cd" ,"xo_enddt_histseq_cd.conc_dextrose_ind as conc_dextrose_ind" ,"xo_enddt_histseq_cd.contnr_ind as contnr_ind" ,"xo_enddt_histseq_cd.contnr_type as contnr_type" ,"xo_enddt_histseq_cd.plx_drug_use_ind as plx_drug_use_ind" ,"xo_enddt_histseq_cd.item_pkg_sz as item_pkg_sz" ,"xo_enddt_histseq_cd.item_pkg_sz_uom as item_pkg_sz_uom" ,"xo_enddt_histseq_cd.item_full_name as item_full_name" ,"xo_enddt_histseq_cd.item_short_name as item_short_name" ,"xo_enddt_histseq_cd.item_awp_dlrs as item_awp_dlrs" ,"xo_enddt_histseq_cd.item_bill_factor as item_bill_factor" ,"xo_enddt_histseq_cd.drug_disease_type_cd as drug_disease_type_cd" ,"xo_enddt_histseq_cd.item_drug_sub_catg as item_drug_sub_catg" ,"xo_enddt_histseq_cd.item_drug_catg as item_drug_catg" ,"xo_enddt_histseq_cd.item_drug_sub_grp as item_drug_sub_grp" ,"xo_enddt_histseq_cd.item_drug_grp as item_drug_grp" ,"xo_enddt_histseq_cd.src_eff_dt as src_eff_dt" ,"xo_enddt_histseq_cd.src_eff_tm as src_eff_tm" ,"xo_enddt_histseq_cd.src_create_user_id as src_create_user_id" ,"xo_enddt_histseq_cd.src_update_user_id as src_update_user_id" ,"xo_enddt_histseq_cd.src_end_dt as src_end_dt" ,"xo_enddt_histseq_cd.src_end_tm as src_end_tm" ,"xo_enddt_histseq_cd.edw_batch_id as edw_batch_id" ,"xo_enddt_histseq_cd.track_inv_ind as track_inv_ind" ,"xo_enddt_histseq_cd.src_create_dttm as src_create_dttm" ,"xo_enddt_histseq_cd.history_seq_nbr as history_seq_nbr" ,"xo_enddt_histseq_cd.history_seq_cd as history_seq_cd" ,"xo_enddt_histseq_cd.inferred_drug_ind as inferred_drug_ind" ,"xo_enddt_histseq_cd.min_drug_price_dlrs as min_drug_price_dlrs" ,"xo_enddt_histseq_cd.excl_drug_auto_rcmd_ind as excl_drug_auto_rcmd_ind" ,"xo_enddt_histseq_cd.excl_tbltop_cnt_ind as excl_tbltop_cnt_ind" ,"xo_enddt_histseq_cd.require_tbltop_clean_ind as require_tbltop_clean_ind" ,"xo_enddt_histseq_cd.ahfs_extend_therapeutic_class_cd as ahfs_extend_therapeutic_class_cd" ,"xo_enddt_histseq_cd.hzrds_lvl_cd as hzrds_lvl_cd","xo_enddt_histseq_cd.auth_generic_cd as auth_generic_cd" ,"xo_enddt_histseq_cd.fda_ind as fda_ind","xo_enddt_histseq_cd.fda_ind_value as fda_ind_value","xo_enddt_histseq_cd.auth_ndc_upc_hri as auth_ndc_upc_hri","xo_enddt_histseq_cd.auth_gen_override_ind as auth_gen_override_ind","xo_enddt_histseq_cd.ddid as ddid","xo_enddt_histseq_cd.rxcui_type as rxcui_type","xo_enddt_histseq_cd.rxcui as rxcui","xo_enddt_histseq_cd.elsevier_pack_id as elsevier_pack_id","xo_enddt_histseq_cd.elsevier_prod_id as elsevier_prod_id","xo_enddt_histseq_cd.med_dosage_unit as med_dosage_unit","xo_enddt_histseq_cd.med_conv_factor as med_conv_factor","xo_enddt_histseq_cd.mme_calc_factor as mme_calc_factor","xo_enddt_histseq_cd.edw_dml_ind as edw_dml_ind" ,"xo_enddt_histseq_cd.etl_proc_seq_nbr as etl_proc_seq_nbr" ,"case when (row_number() over(partition By drug_id  order By etl_proc_seq_nbr desc ) = 1) then 1 else 0 end as clusterKeyChange" ).withColumn("HistSeqNbr", F.lead(col("history_seq_nbr"), 1, 1).over(window_spec_lag) )

SRT_pkey_cdc_asc_add_clstr_1 = SRT_pkey_cdc_asc_add_clstr.withColumn("lkp_hist", max("HistSeqNbr").over(Window.partitionBy("drug_id")))
SRT_pkey_cdc_asc_add_clstr_2 = SRT_pkey_cdc_asc_add_clstr_1.withColumn("row_num_hist_seq", row_number().over(Window.partitionBy("drug_id").orderBy("etl_proc_seq_nbr")) -1)
SRT_pkey_cdc_asc_add_clstr_3 = SRT_pkey_cdc_asc_add_clstr_2.withColumn("HistSeqNbr_1", col("lkp_hist")+col("row_num_hist_seq"))
X_history_seq_nbr_V0S94P3_filter = SRT_pkey_cdc_asc_add_clstr_3.filter("edw_dml_ind == \"U\"")
X_history_seq_nbr_V0S94P3 = X_history_seq_nbr_V0S94P3_df(X_history_seq_nbr_V0S94P3_filter)

FFW_upd_loadready_save(X_history_seq_nbr_V0S94P3)
X_history_seq_nbr_V0S94P2_filter = SRT_pkey_cdc_asc_add_clstr_3.filter("edw_dml_ind == \"I\"")
X_history_seq_nbr_V0S94P2 = X_history_seq_nbr_V0S94P2_df(X_history_seq_nbr_V0S94P2_filter)
FFW_ins_loadready_save(X_history_seq_nbr_V0S94P2)

# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Import Python libs
import json
import random
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("DELTA_FILE_NAME","",label="DELTA_FILE_NAME")
dbutils.widgets.text("DELTA_FILE_DIR","",label="DELTA_FILE_DIR")
dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")

output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")
delta_file_name = dbutils.widgets.get("DELTA_FILE_NAME")
delta_file_dir = dbutils.widgets.get("DELTA_FILE_DIR")

delta_file_path = mount_point + '/' + delta_file_dir + '/' + delta_file_name + '/' + batch_id
output_file_path = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir + '/' + batch_id

# COMMAND ----------

# Define column values in List((tuple0,tuple1)) -- List((columnnamewithrelativetags,onlycolumnname))
# Email type specific columns
col_list_email = [("providerInfo_entityID","entityID"),("providerInfo_email_type","mailtype0"),("providerInfo_email_address","address"),("providerInfo_email_rank","mailrank"),("providerInfo_email_activeIndicator","mailactiveIndicator"),("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId")]

# Phone type specific columns
col_list_phone = [("providerInfo_entityID","entityID"),("providerInfo_phone_type","type0"),("providerInfo_phone_areaCode","areaCode"),("providerInfo_phone_number","infnumber"),("providerInfo_phone_extension","extension"),("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId")]

selected_email  = [col(j) for k, j in col_list_email]
selected_phone  = [col(j) for k, j in col_list_phone]

# COMMAND ----------

#Read from delta

delta_df = spark.read.format("delta").load(delta_file_path)


# COMMAND ----------

#select only required coloumns for both email and phone type
df2_email=delta_df.select(*selected_email)
df2_phone=delta_df.select(*selected_phone)

#adding hard coded values for column cntc_channel_type_val based on email or phone type columns
df2_email = df2_email.withColumn("cntc_channel_type_val",lit("EMAIL"))
df2_phone = df2_phone.withColumn("cntc_channel_type_val",lit("PHONE"))

df2_phone = df2_phone.withColumnRenamed("infnumber","number")
df2_email = df2_email.withColumnRenamed("mailtype0","type0").withColumnRenamed("mailrank","rank").withColumnRenamed("mailactiveIndicator","activeIndicator")

#drop duplicates
df3_email=df2_email.dropDuplicates()
df3_phone=df2_phone.dropDuplicates()

#combine both email and phone type column
df4 = custom_union(df3_email,df3_phone)

# COMMAND ----------

df_final = df4.filter("type0 is not null")

# COMMAND ----------

# Write output (parquet)
write_data(df_final,output_file_path)

# Databricks notebook source
#dbutils.widgets.remove('pTGT_FILE')
#dbutils.widgets.help()
'''
dbutils.widgets.text("pEDW_BATCH_ID","20220526153800")
dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
dbutils.widgets.text("PAR_PROJ_NAME","edw_out_pharmacy_extracts")
dbutils.widgets.text("PAR_SRC_STREAM_NAME","satr_extract")
dbutils.widgets.text("PAR_PROC_META_TABLE","PROC_CNTRL_EXTRACT_META_DETAIL_STG")
dbutils.widgets.text("PAR_PROC_META_TABLE_SCHEMA","PRDSTGMET")
dbutils.widgets.text("PAR_PSET_NAME","plan_edw_out_phrm_ext_satr_extract_weekly.pset")
dbutils.widgets.text("PAR_PHARMACY_SCHEMA","PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_STG_TABLE_1","TEMP_SATR_EXTRACTL_STG")
dbutils.widgets.text("PAR_OUTPUT_STG_FILE_PATH","partner_extracts/pharmacy_healthcare/staging")
dbutils.widgets.text("PAR_OUTPUT_STG_FILE_1","edw_out_phrm_satr_input")

'''

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------


SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
PROJ_NAME=dbutils.widgets.get("PAR_PROJ_NAME")
SRC_STREAM_NAME=dbutils.widgets.get("PAR_SRC_STREAM_NAME")
PROC_META_TABLE=dbutils.widgets.get("PAR_PROC_META_TABLE")
PROC_META_TABLE_SCHEMA=dbutils.widgets.get("PAR_PROC_META_TABLE_SCHEMA")
PSET_NAME=dbutils.widgets.get("PAR_PSET_NAME")
PHARMACY_SCHEMA=dbutils.widgets.get("PAR_PHARMACY_SCHEMA")
STG_TABLE_1=dbutils.widgets.get("PAR_STG_TABLE_1")
OUTPUT_STG_FILE_PATH=dbutils.widgets.get("PAR_OUTPUT_STG_FILE_PATH")
OUTPUT_STG_FILE_1=dbutils.widgets.get("PAR_OUTPUT_STG_FILE_1")
EDW_BATCH_ID=dbutils.widgets.get("pEDW_BATCH_ID")


# COMMAND ----------

# MAGIC 
# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------


etl_query ='''select coalesce(cast(max(extract_create_dt) as date), cast('2022-05-14' as date)) + 1 as EXEC_WK_START_DT,coalesce(cast(max(extract_create_dt) as date),cast('2022-05-14' as date)) + 7 as EXEC_WK_END_DT from {0}.{1} where proj_name='{2}' 
and src_stream_name='{3}'and pset_name='{4}' '''.format(SNFK_ETL_DB,PROC_META_TABLE_SCHEMA+'.'+PROC_META_TABLE,PROJ_NAME,SRC_STREAM_NAME,PSET_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)
EXEC_WK_START_DT=cutoff_records_output.collect()[0][0]
EXEC_WK_END_DT=cutoff_records_output.collect()[0][1]
PROCESS_DATES_LIST=[str(EXEC_WK_START_DT),str(EXEC_WK_END_DT)]
process_dates_str=str(PROCESS_DATES_LIST).replace("[","").replace("]","")
print(process_dates_str)


# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit,col
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("pIN_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

# COMMAND ----------

# Reading files content
from pyspark.sql.functions import *


schema = StructType() \
      .add("PAT_ID",StringType(),True) \
      .add("PICKUP_AT_STORE_NUMBER",StringType(),True) \
      .add("PICKUP_DATE",StringType(),True) \
      .add("PICKUP_TIME",StringType(),True) \
      .add("RX_NUMBER",StringType(),True) \
      .add("STORE_NUMBER",StringType(),True) \
      .add("Dummy_Col1",StringType(),True) \
      .add("Dummy_Col2",StringType(),True) \
      .add("Dummy_Col3",StringType(),True) \
      .add("WORK_ORDER_CORRELATION_ID",StringType(),True)
      

readList=[mountPoint + row[0] + '/' + row[1] for row in dfNamePath.select('filepath','filename').collect()]

dfMulti = spark.read.format("csv").schema(schema).option("sep","\u0001").load(readList).withColumn("FileName", input_file_name())
#display(dfMulti)
#print(dfMulti.count())
#display(dfMulti)

# COMMAND ----------

from pyspark.sql.window import Window

df_select=dfMulti.select(col("RX_NUMBER").alias("rx_nbr"),col("PAT_ID").alias("pat_id"),col("WORK_ORDER_CORRELATION_ID").alias("work_order"),col("STORE_NUMBER").alias("store_nbr"),col("PICKUP_AT_STORE_NUMBER").alias("pickup_store_nbr"),col("Dummy_Col1").alias("orig_fill_dspn_qnty"),col("Dummy_Col3").alias("fill_type"),col("FileName").alias("fill_name"),col("FileName").alias("FileName")).withColumn("EXPECTED_FILL_ENTER_DTTM", coalesce(unix_timestamp(regexp_replace(reverse(split(reverse(col("FileName")), "_")[1]), ".dat", ""), "yyyyMMddHHmmss").cast("timestamp").cast("date"),unix_timestamp(regexp_replace(reverse(split(reverse(col("FileName")), "_")[1]), ".dat", ""), "yyyyMMdd").cast("timestamp").cast("date"))).drop(col("FileName"))


#display(df_select)


# COMMAND ----------

df_filter=df_select.filter( ~ ((F.length(col("store_nbr"))==5) & (F.substring(col("store_nbr"),1,1) =='5') ) )
#display(df_filter)

# COMMAND ----------

df_sort = df_filter.sort(col("store_nbr").asc(),col("rx_nbr").asc(),col("EXPECTED_FILL_ENTER_DTTM").desc())
dfDedup = df_sort.dropDuplicates(["store_nbr","rx_nbr","EXPECTED_FILL_ENTER_DTTM"])
df_lag=dfDedup.withColumn("lag_fill_enter_dt",F.lag(col("EXPECTED_FILL_ENTER_DTTM"),1).over(Window.partitionBy("store_nbr","rx_nbr").orderBy(col("store_nbr").asc(),col("rx_nbr").asc(),col("EXPECTED_FILL_ENTER_DTTM").desc()))).withColumn("expected_fill_enter_dt",col("EXPECTED_FILL_ENTER_DTTM")).drop(col("EXPECTED_FILL_ENTER_DTTM"))
df_max=df_lag.withColumn("max_fill_enter_dt",when(col("expected_fill_enter_dt") == col("lag_fill_enter_dt"),current_date())
                         .when(col("lag_fill_enter_dt").isNull() ,current_date())
                         .otherwise(col("lag_fill_enter_dt"))).drop(col("lag_fill_enter_dt"))
#display(df_max)
                                                               

# COMMAND ----------

df_filter_1=df_max.filter( (col("expected_fill_enter_dt") >= to_date(lit(EXEC_WK_START_DT))) & (col("expected_fill_enter_dt") <= to_date(lit(EXEC_WK_END_DT))) )
#display(df_filter_1)

# COMMAND ----------

file_path = "{0}/{1}/{2}/{3}".format(mountPoint, OUTPUT_STG_FILE_PATH,OUTPUT_STG_FILE_1,EDW_BATCH_ID)

df_filter_1.write.format("parquet").mode("overwrite").save(file_path)


# COMMAND ----------



delete_gg_snowflake_tl = "Truncate table {0}.{1}".format(SNFL_DB, PHARMACY_SCHEMA+"."+STG_TABLE_1)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake_tl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

##Populating the TL_ETL_TBF0_RX_CMPND_INGRDNT_STG table
df_final=df_filter_1.select(col("pat_id"),col("store_nbr"),col("pickup_store_nbr"),col("rx_nbr"),col("work_order"),col("orig_fill_dspn_qnty"),col("fill_type"),col("expected_fill_enter_dt"),col("MAX_FILL_ENTER_DT"),).drop("fill_name")
df_final.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable",  PHARMACY_SCHEMA+"."+STG_TABLE_1) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()


# COMMAND ----------

dbutils.notebook.exit(process_dates_str)
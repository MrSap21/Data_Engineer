# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220111183013")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_rx")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_STG")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","master_data/location/output")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","master_data/location/reject")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_RX,GG_TBF0_RX_control")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL",'https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate')
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_PIPELINE_NAME","employee_xform_pharmacy_staff")
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
# dbutils.widgets.text("PAR_UnprocessedFiles","1")  
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS") 
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","GG_TBF0_RX_CMPND_INGRDNT") 
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG") 


# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPINative", 600, 
                  {"PAR_READAPI_KEY":"feedNames",
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_READAPI_VALUE":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A"});


print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME) 

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{FEED_NAME}.assetcurrentlocation",
                                                   f"{FEED_NAME}.assetid",
                                                   f"{FEED_NAME}.assetname")
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]


# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length','cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_partial_nbr',
'fill_partial_nbr_after',
'fill_entered_dttm',
'fill_entered_dttm_after',
'cl_status_cd',
'cl_status_cd_after',
'cl_eligible_dttm',
'cl_eligible_dttm_after',
'cl_comment_status',
'cl_comment_status_after',
'cl_cmt_status_dttm',
'cl_cmt_status_dttm_after',
'cl_comment',
'cl_comment_after',
'cl_comment_dttm',
'cl_comment_dttm_after',
'create_dttm',
'create_dttm_after',
'create_user_id',
'create_user_id_after',
'update_dttm',
'update_dttm_after',
'update_user_id',
'update_user_id_after',
'autofill_ind',
'autofill_ind_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if 'INSERT' in key_list[6]:
    if val_len != 45 :
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 46:
      return True
  else:
    if val_len != 46:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.format("parquet").mode("overwrite").save(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len = 46

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)
schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))

print(f"Good records count {rd_good.count()}")
print(f"Bad records count {rd_bad.count()}")


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)


# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
# df = (reduce(
#     lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
#     df.columns,
#     df
# ))

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_ret_to_stk_call_list")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_ret_to_stk_call_list where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df.withColumn("table_name",lit("gg_tbf0_ret_to_stk_call_list"))
df_gg.createOrReplaceTempView("raw_gg_tbf0_ret_to_stk_call_list")


# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

#pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_ret_to_stk_call_list' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  


pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_ret_to_stk_call_list' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcGgTbf0Schema

pUpdateReform="(cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL AND  cdc_seq_nbr == cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL AND  cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL AND  store_nbr == store_nbr_after AND store_nbr IS NOT NULL AND store_nbr_after IS NOT NULL AND  rx_nbr == rx_nbr_after AND rx_nbr IS NOT NULL AND rx_nbr_after IS NOT NULL AND  fill_nbr == fill_nbr_after AND fill_nbr IS NOT NULL AND fill_nbr_after IS NOT NULL AND  fill_partial_nbr == fill_partial_nbr_after AND fill_partial_nbr IS NOT NULL AND fill_partial_nbr_after IS NOT NULL AND  cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL AND   cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND cdc_operation_type_cd_after IS NOT NULL AND  cdc_before_after_cd== 'BEFORE' AND cdc_before_after_cd IS NOT NULL AND   cdc_operation_type_cd == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL AND    ((fill_entered_dttm == fill_entered_dttm_after AND fill_entered_dttm IS NOT NULL AND fill_entered_dttm_after IS NOT NULL)OR (fill_entered_dttm IS NULL AND  fill_entered_dttm_after IS NULL)) AND  ((cl_status_cd == cl_status_cd_after AND cl_status_cd IS NOT NULL AND cl_status_cd_after IS NOT NULL)OR (cl_status_cd IS NULL AND  cl_status_cd_after IS NULL)) AND  ((cl_eligible_dttm == cl_eligible_dttm_after AND cl_eligible_dttm IS NOT NULL AND cl_eligible_dttm_after IS NOT NULL)OR (cl_eligible_dttm IS NULL AND  cl_eligible_dttm_after IS NULL)) AND  ((cl_comment_status == cl_comment_status_after AND cl_comment_status IS NOT NULL AND cl_comment_status_after IS NOT NULL) OR (cl_comment_status IS NULL AND  cl_comment_status_after IS NULL)) AND  ((cl_cmt_status_dttm == cl_cmt_status_dttm_after AND cl_cmt_status_dttm IS NOT NULL AND cl_cmt_status_dttm_after IS NOT NULL)OR (cl_cmt_status_dttm IS NULL AND  cl_cmt_status_dttm_after IS NULL)) AND  ((cl_comment == cl_comment_after AND cl_comment IS NOT NULL AND cl_comment_after IS NOT NULL)OR (cl_comment IS NULL AND  cl_comment_after IS NULL)) AND  ( (cl_comment_dttm == cl_comment_dttm_after AND cl_comment_dttm IS NOT NULL AND cl_comment_dttm_after IS NOT NULL) OR (cl_comment_dttm IS NULL AND  cl_comment_dttm_after IS NULL)) AND  ((create_dttm == create_dttm_after AND create_dttm IS NOT NULL AND create_dttm_after IS NOT NULL) OR (create_dttm IS NULL AND  create_dttm_after IS NULL)) AND  ( (create_user_id == create_user_id_after AND create_user_id IS NOT NULL AND create_user_id_after IS NOT NULL) OR (create_user_id IS NULL AND  create_user_id_after IS NULL)) AND  ((autofill_ind == autofill_ind_after AND autofill_ind IS NOT NULL AND autofill_ind_after IS NOT NULL)OR (autofill_ind IS NULL AND  autofill_ind_after IS NULL)))"


#pSrcCleanseXfr

#pTgtUpdBfrXfr

#pTgtUpdAftXfr

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, store_nbr, rx_nbr, fill_nbr, fill_partial_nbr, CONCAT(fill_entered_dttm,'.000000') AS fill_entered_dttm, cl_status_cd, CONCAT(cl_eligible_dttm,'.000000') AS cl_eligible_dttm, cl_comment_status, CONCAT(cl_cmt_status_dttm,'.000000') AS cl_cmt_status_dttm, cl_comment, CONCAT(cl_comment_dttm,'.000000') AS cl_comment_dttm, CONCAT(create_dttm,'.000000') AS create_dttm, create_user_id, CONCAT(update_dttm,'.000000') AS update_dttm, update_user_id, autofill_ind, store_nbr AS relocate_fm_str_nbr, tracking_id, partition_column" 




# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == PROJ_ID))

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
rx_trans_max = cutoff_range_trans.select("rx_trans_max")



# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_ret_to_stk_call_list where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_ret_to_stk_call_list where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_ret_to_stk_call_list where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) 
  #rx_max = to_timestamxp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)


  #Remove duplicates
dedup_group = nr_input_file_final.distinct()
#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")


# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
store_nbr AS store_nbr ,
 store_nbr_after AS store_nbr_after ,
 rx_nbr AS rx_nbr ,
 rx_nbr_after AS rx_nbr_after ,
 fill_nbr AS fill_nbr ,
 fill_nbr_after AS fill_nbr_after ,
 fill_partial_nbr AS fill_partial_nbr ,
 fill_partial_nbr_after AS fill_partial_nbr_after ,
 concat(concat(SUBSTRING(fill_entered_dttm,1,10),' '),SUBSTRING(fill_entered_dttm,12,18)) AS fill_entered_dttm, 
 concat(concat(SUBSTRING(fill_entered_dttm_after,1,10),' '),SUBSTRING(fill_entered_dttm_after,12,18)) AS fill_entered_dttm_after, 
 (case when (LENGTH(trim(cl_status_cd))==0) then cl_status_cd else TRIM(cl_status_cd) end) as cl_status_cd , 
 (case when (LENGTH(trim(cl_status_cd_after))==0) then cl_status_cd_after else TRIM(cl_status_cd_after) end) as cl_status_cd_after , 
 concat(concat(SUBSTRING(cl_eligible_dttm,1,10),' '),SUBSTRING(cl_eligible_dttm,12,18)) as cl_eligible_dttm,
 concat(concat(SUBSTRING(cl_eligible_dttm_after,1,10),' '),SUBSTRING(cl_eligible_dttm_after,12,18)) as cl_eligible_dttm_after, 
 (case when (LENGTH(trim(cl_comment_status))==0) then cl_comment_status else TRIM(cl_comment_status) end) as cl_comment_status , 
 (case when (LENGTH(trim(cl_comment_status_after))==0) then cl_comment_status_after else TRIM(cl_comment_status_after) end) as cl_comment_status_after ,
 concat(concat(SUBSTRING(cl_cmt_status_dttm,1,10),' '),SUBSTRING(cl_cmt_status_dttm,12,18)) as cl_cmt_status_dttm, 
 concat(concat(SUBSTRING(cl_cmt_status_dttm_after,1,10),' '),SUBSTRING(cl_cmt_status_dttm_after,12,18)) as cl_cmt_status_dttm_after, 
 (case when (LENGTH(trim(cl_comment))==0) then cl_comment else TRIM(cl_comment) end) as cl_comment ,
 (case when (LENGTH(trim(cl_comment_after))==0) then cl_comment_after else TRIM(cl_comment_after) end) as cl_comment_after , 
 concat(concat(SUBSTRING(cl_comment_dttm,1,10),' '),SUBSTRING(cl_comment_dttm,12,18)) as cl_comment_dttm, 
 concat(concat(SUBSTRING(cl_comment_dttm_after,1,10),' '),SUBSTRING(cl_comment_dttm_after,12,18)) as cl_comment_dttm_after,
 concat(concat(SUBSTRING(create_dttm,1,10),' '),SUBSTRING(create_dttm,12,18)) as create_dttm,
 concat(concat(SUBSTRING(create_dttm_after,1,10),' '),SUBSTRING(create_dttm_after,12,18)) as create_dttm_after, 
 create_user_id AS create_user_id ,
 create_user_id_after AS create_user_id_after , 
 concat(concat(SUBSTRING(update_dttm,1,10),' '),SUBSTRING(update_dttm,12,18)) as update_dttm,
 concat(concat(SUBSTRING(update_dttm_after,1,10),' '),SUBSTRING(update_dttm_after,12,18)) as update_dttm_after, 
 update_user_id AS update_user_id ,
 update_user_id_after AS update_user_id_after , 
 (case when (LENGTH(trim(autofill_ind))==0) then autofill_ind else TRIM(autofill_ind) end) as autofill_ind , 
 (case when (LENGTH(trim(autofill_ind_after))==0) then autofill_ind_after else TRIM(autofill_ind_after) end) as autofill_ind_after from dedup_group
"""


# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform 
gg_tbf0_rejected = spark.sql(query1)


gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL)

display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")


# COMMAND ----------

pTgtUpdBfrXfr="""Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id, store_nbr AS store_nbr , rx_nbr AS rx_nbr , fill_nbr AS fill_nbr , fill_partial_nbr AS fill_partial_nbr , fill_entered_dttm AS fill_entered_dttm , cl_status_cd AS cl_status_cd , cl_eligible_dttm AS cl_eligible_dttm , cl_comment_status AS cl_comment_status , cl_cmt_status_dttm AS cl_cmt_status_dttm , cl_comment AS cl_comment , cl_comment_dttm AS cl_comment_dttm , create_dttm AS create_dttm , create_user_id AS create_user_id , update_dttm AS update_dttm , update_user_id AS update_user_id , autofill_ind AS autofill_ind , '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from gg_tbf0_update """ 



pTgtUpdAftXfr="""Select 
cdc_txn_commit_dttm_after  as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , fill_entered_dttm_after AS fill_entered_dttm , cl_status_cd_after AS cl_status_cd , cl_eligible_dttm_after AS cl_eligible_dttm , cl_comment_status_after AS cl_comment_status , cl_cmt_status_dttm_after AS cl_cmt_status_dttm , cl_comment_after AS cl_comment , cl_comment_dttm_after AS cl_comment_dttm , create_dttm_after AS create_dttm , create_user_id_after AS create_user_id , update_dttm_after AS update_dttm , update_user_id_after AS update_user_id , autofill_ind_after AS autofill_ind , '000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name from gg_tbf0_update"""




pTgtInsBfrAftXfr = """Select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd, """ + BATCH_ID + """ as edw_batch_id,store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , fill_entered_dttm_after AS fill_entered_dttm , cl_status_cd_after AS cl_status_cd , cl_eligible_dttm_after AS cl_eligible_dttm , cl_comment_status_after AS cl_comment_status , cl_cmt_status_dttm_after AS cl_cmt_status_dttm , cl_comment_after AS cl_comment , cl_comment_dttm_after AS cl_comment_dttm , create_dttm_after AS create_dttm , create_user_id_after AS create_user_id , update_dttm_after AS update_dttm , update_user_id_after AS update_user_id , autofill_ind_after AS autofill_ind,'000000' AS tracking_id ,'' AS partition_column,'""" + SRC_TBL_NAME +  """' as table_name 
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)





# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 


gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)


#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

#Formating the timestamp values
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CREATE_DTTM",concat(substring(col("CREATE_DTTM"),1,10),lit(' '),substring(col("CREATE_DTTM"),12,8)))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("UPDATE_DTTM",concat(substring(col("UPDATE_DTTM"),1,10),lit(' '),substring(col("UPDATE_DTTM"),12,8)))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("FILL_ENTERED_DTTM",concat(substring(col("FILL_ENTERED_DTTM"),1,10),lit(' '),substring(col("FILL_ENTERED_DTTM"),12,8)))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CL_ELIGIBLE_DTTM",concat(substring(col("CL_ELIGIBLE_DTTM"),1,10),lit(' '),substring(col("CL_ELIGIBLE_DTTM"),12,8)))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CL_CMT_STATUS_DTTM",concat(substring(col("CL_CMT_STATUS_DTTM"),1,10),lit(' '),substring(col("CL_CMT_STATUS_DTTM"),12,8)))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CL_COMMENT_DTTM",concat(substring(col("CL_COMMENT_DTTM"),1,10),lit(' '),substring(col("CL_COMMENT_DTTM"),12,8)))


# COMMAND ----------

 df_final = etl_tbf0_reformat_cdc_check_notnull.drop("tracking_id","partition_column")
df_final_typeCast = df_final.withColumn("CDC_TXN_COMMIT_DTTM",to_timestamp(df_final["CDC_TXN_COMMIT_DTTM"]))\
  .withColumn("CDC_SEQ_NBR", df_final["CDC_SEQ_NBR"].cast(IntegerType()))\
  .withColumn("CDC_RBA_NBR", df_final["CDC_RBA_NBR"].cast(IntegerType()))\
  .withColumn("CDC_OPERATION_TYPE_CD", df_final["CDC_OPERATION_TYPE_CD"])\
  .withColumn("CDC_BEFORE_AFTER_CD", df_final["CDC_BEFORE_AFTER_CD"])\
  .withColumn("CDC_TXN_POSITION_CD", df_final["CDC_TXN_POSITION_CD"])\
  .withColumn("STORE_NBR", df_final["STORE_NBR"].cast(IntegerType()))\
  .withColumn("RX_NBR", df_final["RX_NBR"].cast(IntegerType()))\
  .withColumn("FILL_NBR", df_final["FILL_NBR"].cast(IntegerType()))\
  .withColumn("FILL_PARTIAL_NBR", df_final["FILL_PARTIAL_NBR"].cast(IntegerType()))\
  .withColumn("FILL_ENTERED_DTTM", to_timestamp(df_final["FILL_ENTERED_DTTM"]))\
  .withColumn("CL_STATUS_CD", df_final["CL_STATUS_CD"])\
  .withColumn("CL_ELIGIBLE_DTTM", to_timestamp(df_final["CL_ELIGIBLE_DTTM"]))\
  .withColumn("CL_COMMENT_STATUS", df_final["CL_COMMENT_STATUS"])\
  .withColumn("CL_CMT_STATUS_DTTM", to_timestamp(df_final["CL_CMT_STATUS_DTTM"]))\
  .withColumn("CL_COMMENT", df_final["CL_COMMENT"])\
  .withColumn("CL_COMMENT_DTTM", to_timestamp(df_final["CL_COMMENT_DTTM"]))\
  .withColumn("CREATE_DTTM", to_timestamp(df_final["CREATE_DTTM"]))\
  .withColumn("CREATE_USER_ID", df_final["CREATE_USER_ID"].cast(IntegerType()))\
  .withColumn("UPDATE_DTTM", to_timestamp(df_final["UPDATE_DTTM"]))\
  .withColumn("UPDATE_USER_ID", df_final["UPDATE_USER_ID"].cast(IntegerType()))\
  .withColumn("AUTOFILL_IND", df_final["AUTOFILL_IND"])\
  .withColumn("RELOCATE_FM_STR_NBR", df_final["RELOCATE_FM_STR_NBR"].cast(IntegerType()))


df_final_check_blank = df_final_typeCast.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in df_final_typeCast.columns])

df_final_notNull = df_final_check_blank.filter("store_nbr is not null and rx_nbr is not null")
df_final_notNull=df_final_notNull.select("CDC_TXN_COMMIT_DTTM","CDC_SEQ_NBR","CDC_RBA_NBR","CDC_OPERATION_TYPE_CD","CDC_BEFORE_AFTER_CD","CDC_TXN_POSITION_CD","EDW_BATCH_ID","STORE_NBR","RX_NBR","FILL_NBR","FILL_PARTIAL_NBR","FILL_ENTERED_DTTM","CL_STATUS_CD","CL_ELIGIBLE_DTTM","CL_COMMENT_STATUS","CL_CMT_STATUS_DTTM","CL_COMMENT","CL_COMMENT_DTTM","CREATE_DTTM","CREATE_USER_ID","UPDATE_DTTM","UPDATE_USER_ID","AUTOFILL_IND","RELOCATE_FM_STR_NBR")


# COMMAND ----------

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB,SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

df_final_notNull.write \
    .format("net.snowflake.spark.snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("continue_on_error", "on") \
    .option("truncate_columns","on") \
    .mode("append") \
    .save()

Tl_df_final_notNull=df_final_notNull.select("CDC_TXN_COMMIT_DTTM","CDC_SEQ_NBR","CDC_RBA_NBR","CDC_OPERATION_TYPE_CD","CDC_BEFORE_AFTER_CD","CDC_TXN_POSITION_CD","EDW_BATCH_ID","STORE_NBR","RX_NBR","FILL_NBR","FILL_PARTIAL_NBR","FILL_ENTERED_DTTM","CL_STATUS_CD","CL_ELIGIBLE_DTTM","CL_COMMENT_STATUS","CL_CMT_STATUS_DTTM","CL_COMMENT","CL_COMMENT_DTTM","CREATE_DTTM","CREATE_USER_ID","UPDATE_DTTM","UPDATE_USER_ID","AUTOFILL_IND","RELOCATE_FM_STR_NBR")

TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]

delete_gg_snowflake_tl = "Truncate table {0}.{1}".format(SNFL_DB,TL_SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake_tl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

Tl_df_final_notNull.write \
.format("snowflake") \
.options(**options) \
.option("sfWarehouse", SNFL_WH) \
.option("sfDatabase", SNFL_DB) \
.option("dbtable", TL_SNFL_TBL_NAME) \
.option("continue_on_error", "on") \
.option("truncate_columns","on")\
.mode("append") \
.save()

# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit(PAR_WRITEAPI_VALUE2);
                   
print("Write API successfully executed...")
dbutils.notebook.exit("ETL_TBF0_RET_TO_STK_CALL_LIST_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")

# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# #Create Widgets for Parameters
#dbutils.widgets.text("PAR_UNPROCESSED_FILES","/mnt/wrangled//pharmacy_healthcare/patient_services/icplus/2022/01/31//PRDRX2STAGE_GG_TBF0_PATIENT_MERGE_2022-01-29_01-27-01_01697_data.dsv")
#dbutils.widgets.remove("PAR_PIPELINE_NAME")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_patient_merge")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","/pharmacy_healthcare/patient/output")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","/pharmacy_healthcare/patient/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT.ETL_TBF0_PATIENT_MERGE_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")

# COMMAND ----------

FEED_NAME=dbutils.widgets.get("PAR_FEED_NAME") 

import json
from pyspark.sql.functions import *
from pyspark.sql.types import *

readList=dbutils.widgets.get("PAR_UNPROCESSED_FILES")
readList=readList.split(',')
print(readList)

# COMMAND ----------

#Implement Control Files Logic

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILE_NOISE_RMV)
# print(REJ_FILE_PAT_MOD)
# print(REJ_FILE_UPD_NULL)
# print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Define Input File Schema
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'store_nbr',
'store_nbr_after',
'phrm_staff_user_id',
'phrm_staff_user_id_after',
'staff_initials',
'staff_initials_after',
'phrm_staff_first_name',
'phrm_staff_first_name_after',
'phrm_staff_mid_init',
'phrm_staff_mid_init_after',
'phrm_staff_last_name',
'phrm_staff_last_name_after',
'phrm_staff_position_cd',
'phrm_staff_position_cd_after',
'phrm_rph_label_id',
'phrm_rph_label_id_after',
'phrm_staff_lic_nbr',
'phrm_staff_lic_nbr_after',
'phrm_staff_home_area_cd',
'phrm_staff_home_area_cd_after',
'phrm_staff_home_phone',
'phrm_staff_home_phone_after',
'phrm_phrmcst_access_ind',
'phrm_phrmcst_access_ind_after',
'p2000_access_level',
'p2000_access_level_after',
'employment_status_ind',
'employment_status_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'phrm_staff_spec_lic_nbr',
'phrm_staff_spec_lic_nbr_after',
'phrm_staff_employed_ind',
'phrm_staff_employed_ind_after',
'icplus_editable_ind',
'icplus_editable_ind_after',
'rph_consult_barcd_nbr',
'rph_consult_barcd_nbr_after',
'rph_barcd_exp_dttm',
'rph_barcd_exp_dttm_after',
'phrm_staff_npi',
'phrm_staff_npi_after',
'phrm_staff_rfp_ind',
'phrm_staff_rfp_ind_after']

print(len(fieldList))


# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif '"INSERT"' in key_list[6]:
    if val_len != 63:
      print(val_len)
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 64:
      return True
  else:
    if val_len != 64:
      return True

# COMMAND ----------

# Read input files
in_text = spark.read.text(readList)
in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len =64

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 24
print(f"Bad records count {rd_bad.count()}") # != 24

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
df = spark.createDataFrame(rd_good, schema)
#display(df)

# COMMAND ----------

#function to remove "" & \\ <Only when the file is encrypted?
def handlEscpeQuotes(val):
 if not val:
   return ""
  
  #remove rightmost "
 outval = val[0:-1]
  #remove leftmost "
 outval = outval.lstrip("\"")
  #replace double \\ with \
 outval = outval.replace("\\\\","\\")
  #replace double \" with "
 outval = outval.replace("\\\"","\"")
 return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

from functools import reduce
df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    df.columns,
    df
))

df_gg = df.withColumn("table_name",lit("gg_tbf0_store_phrm_staff")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 

df_gg.createOrReplaceTempView("raw_gg_pharmacy_staff")
#display(df_gg)

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')" 

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"    

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from raw_gg_pharmacy_staff where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_gg_pharmacy_staff where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_pharmacy_staff where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)


if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition

else:  
  sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETL_HIVE_CUTOFF_TBL)
  df_cutoff_records_output=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFK_ETL_DB) \
     .option("query",sel_ETL_Hive_Cutoff_tbl) \
     .load()


  cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
  cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

  #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
  cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
  RX_CUT_OFF_MAX_DTTM as rx_max,
  CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
  CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
  from cutoff_records_filter""" 
  cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
  

  #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
  cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
  RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
  from cutoff_records_filter"""
  cutoff_range_trans = spark.sql(cutoff_range_trans_sql)

  #Fetching rx_max and rx_trans_max as values
  rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
  rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max

  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_trans_max)

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_trans_max)
  
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)
  
#Remove duplicates
dedup_group = nr_input_file_final.distinct()

#nr spacetrim
for col in dedup_group.columns:
    nr_spacetrim = dedup_group.withColumn(col, when(ltrim(rtrim(dedup_group[col])) == "",None).otherwise(ltrim(rtrim(dedup_group[col]))))

nr_spacetrim.createOrReplaceTempView("nr_spacetrim")



# COMMAND ----------

pUpdateReform="((cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND (store_nbr ==  store_nbr_after AND store_nbr IS NOT NULL AND store_nbr_after IS NOT NULL) AND  (phrm_staff_user_id ==  phrm_staff_user_id_after AND phrm_staff_user_id IS NOT NULL AND phrm_staff_user_id_after IS NOT NULL) AND  (cdc_seq_nbr ==  cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL) AND  (cdc_rba_nbr ==  cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL) AND  (cdc_txn_commit_dttm  ==  cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL) AND   (( staff_initials  == staff_initials_after AND staff_initials IS NOT NULL AND staff_initials_after IS NOT NULL) OR ( staff_initials  IS NULL AND  staff_initials_after  IS NULL ) )  AND  (( phrm_staff_first_name  == phrm_staff_first_name_after AND phrm_staff_first_name IS NOT NULL AND phrm_staff_first_name_after IS NOT NULL)  OR ( phrm_staff_first_name  IS NULL AND  phrm_staff_first_name_after  IS NULL ) )  AND  (( phrm_staff_mid_init  == phrm_staff_mid_init_after AND phrm_staff_mid_init IS NOT NULL AND phrm_staff_mid_init_after IS NOT NULL ) OR ( phrm_staff_mid_init  IS NULL AND  phrm_staff_mid_init_after  IS NULL ) )  AND  (( phrm_staff_last_name  == phrm_staff_last_name_after AND phrm_staff_last_name IS NOT NULL AND phrm_staff_last_name_after IS NOT  NULL) OR ( phrm_staff_last_name  IS NULL AND  phrm_staff_last_name_after  IS NULL ) )  AND  (( phrm_staff_position_cd  == phrm_staff_position_cd_after AND phrm_staff_position_cd IS NOT NULL AND phrm_staff_position_cd_after IS NOT NULL) OR ( phrm_staff_position_cd  IS NULL AND  phrm_staff_position_cd_after  IS NULL ) )  AND  (( phrm_rph_label_id  == phrm_rph_label_id_after AND phrm_rph_label_id IS NOT NULL AND phrm_rph_label_id_after IS NOT NULL) OR ( phrm_rph_label_id  IS NULL AND  phrm_rph_label_id_after  IS NULL ) )  AND  (( phrm_staff_lic_nbr  == phrm_staff_lic_nbr_after AND phrm_staff_lic_nbr IS NOT NULL AND phrm_staff_lic_nbr_after IS NOT NULL ) OR ( phrm_staff_lic_nbr  IS NULL AND  phrm_staff_lic_nbr_after  IS NULL ) )  AND  (( phrm_staff_home_area_cd  == phrm_staff_home_area_cd_after AND phrm_staff_home_area_cd IS NOT NULL AND phrm_staff_home_area_cd_after IS NOT NULL) OR ( phrm_staff_home_area_cd  IS NULL AND  phrm_staff_home_area_cd_after  IS NULL ) )  AND  (( phrm_staff_home_phone  == phrm_staff_home_phone_after AND phrm_staff_home_phone IS NOT NULL AND phrm_staff_home_phone_after IS NOT NULL) OR ( phrm_staff_home_phone  IS NULL AND  phrm_staff_home_phone_after  IS NULL ) )  AND  (( phrm_phrmcst_access_ind  == phrm_phrmcst_access_ind_after AND phrm_phrmcst_access_ind IS NOT NULL AND phrm_phrmcst_access_ind_after IS NOT NULL) OR ( phrm_phrmcst_access_ind  IS NULL AND  phrm_phrmcst_access_ind_after  IS NULL ) )  AND  (( p2000_access_level  == p2000_access_level_after AND p2000_access_level IS NOT NULL AND p2000_access_level_after IS NOT NULL) OR ( p2000_access_level  IS NULL AND  p2000_access_level_after  IS NULL ) )  AND  (( employment_status_ind  == employment_status_ind_after AND employment_status_ind IS NOT NULL AND employment_status_ind_after IS NOT NULL) OR ( employment_status_ind  IS NULL AND  employment_status_ind_after  IS NULL ) )  AND  (( phrm_staff_spec_lic_nbr  == phrm_staff_spec_lic_nbr_after AND phrm_staff_spec_lic_nbr IS NOT NULL AND phrm_staff_spec_lic_nbr_after IS NOT NULL) OR ( phrm_staff_spec_lic_nbr  IS NULL AND  phrm_staff_spec_lic_nbr_after  IS NULL ) )  AND  (( phrm_staff_employed_ind  == phrm_staff_employed_ind_after AND phrm_staff_employed_ind IS NOT NULL AND phrm_staff_employed_ind_after IS NOT NULL) OR ( phrm_staff_employed_ind  IS NULL AND  phrm_staff_employed_ind_after  IS NULL ) )  AND  (( icplus_editable_ind  == icplus_editable_ind_after AND icplus_editable_ind IS NOT NULL AND icplus_editable_ind_after IS NOT NULL) OR ( icplus_editable_ind  IS NULL AND  icplus_editable_ind_after  IS NULL ) )  AND  (( rph_consult_barcd_nbr  == rph_consult_barcd_nbr_after AND rph_consult_barcd_nbr IS NOT NULL AND rph_consult_barcd_nbr_after IS NOT NULL) OR ( rph_consult_barcd_nbr  IS NULL AND  rph_consult_barcd_nbr_after  IS NULL ) )  AND  (( rph_barcd_exp_dttm  == rph_barcd_exp_dttm_after AND rph_barcd_exp_dttm IS NOT NULL AND rph_barcd_exp_dttm_after IS NOT NULL) OR ( rph_barcd_exp_dttm  IS NULL AND  rph_barcd_exp_dttm_after  IS NULL ) )  AND  (( phrm_staff_npi  == phrm_staff_npi_after AND phrm_staff_npi IS NOT NULL AND phrm_staff_npi_after IS NOT NULL) OR ( phrm_staff_npi  IS NULL AND  phrm_staff_npi_after  IS NULL ) )  AND  (( phrm_staff_rfp_ind  == phrm_staff_rfp_ind_after AND phrm_staff_rfp_ind IS NOT NULL AND phrm_staff_rfp_ind_after IS NOT NULL) OR ( phrm_staff_rfp_ind  IS NULL AND  phrm_staff_rfp_ind_after  IS NULL ) ))"

# COMMAND ----------

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

gg_tbf0_rejected_query = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(gg_tbf0_rejected_query)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 
  
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")


# COMMAND ----------

gg_tbf0_update_afr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm_after.alias("cdc_txn_commit_dttm"),\
gg_tbf0_update.cdc_seq_nbr_after.alias("cdc_seq_nbr"),\
gg_tbf0_update.cdc_rba_nbr_after.alias("cdc_rba_nbr"),\
gg_tbf0_update.cdc_operation_type_cd_after.alias("cdc_operation_type_cd"),\
gg_tbf0_update.cdc_before_after_cd_after.alias("cdc_before_after_cd"),\
gg_tbf0_update.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"),\
gg_tbf0_update.edw_batch_id_after.alias("edw_batch_id"),\
gg_tbf0_update.store_nbr_after.alias("store_nbr"),\
gg_tbf0_update.phrm_staff_user_id_after.alias("phrm_staff_user_id"),\
gg_tbf0_update.staff_initials_after.alias("staff_initials"),\
gg_tbf0_update.phrm_staff_first_name_after.alias("phrm_staff_first_name"),\
gg_tbf0_update.phrm_staff_mid_init_after.alias("phrm_staff_mid_init"),\
gg_tbf0_update.phrm_staff_last_name_after.alias("phrm_staff_last_name"),\
gg_tbf0_update.phrm_staff_position_cd_after.alias("phrm_staff_position_cd"),\
gg_tbf0_update.phrm_rph_label_id_after.alias("phrm_rph_label_id"),\
gg_tbf0_update.phrm_staff_lic_nbr_after.alias("phrm_staff_lic_nbr"),\
gg_tbf0_update.phrm_staff_home_area_cd_after.alias("phrm_staff_home_area_cd"),\
gg_tbf0_update.phrm_staff_home_phone_after.alias("phrm_staff_home_phone"),\
gg_tbf0_update.phrm_phrmcst_access_ind_after.alias("phrm_phrmcst_access_ind"),\
gg_tbf0_update.p2000_access_level_after.alias("p2000_access_level"),\
gg_tbf0_update.employment_status_ind_after.alias("employment_status_ind"),\
gg_tbf0_update.create_user_id_after.alias("create_user_id"),\
gg_tbf0_update.create_dttm_after.alias("create_dttm"),\
gg_tbf0_update.update_user_id_after.alias("update_user_id"),\
gg_tbf0_update.update_dttm_after.alias("update_dttm"),\
gg_tbf0_update.phrm_staff_spec_lic_nbr_after.alias("phrm_staff_spec_lic_nbr"),\
gg_tbf0_update.phrm_staff_employed_ind_after.alias("phrm_staff_employed_ind"),\
gg_tbf0_update.icplus_editable_ind_after.alias("icplus_editable_ind"),\
gg_tbf0_update.rph_consult_barcd_nbr_after.alias("rph_consult_barcd_nbr"),\
gg_tbf0_update.rph_barcd_exp_dttm_after.alias("rph_barcd_exp_dttm"),\
gg_tbf0_update.phrm_staff_npi_after.alias("phrm_staff_npi"),\
gg_tbf0_update.phrm_staff_rfp_ind_after.alias("phrm_staff_rfp_ind"), \
gg_tbf0_update.table_name)

gg_tbf0_update_bfr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"),\
gg_tbf0_update.cdc_seq_nbr.alias("cdc_seq_nbr"),\
gg_tbf0_update.cdc_rba_nbr.alias("cdc_rba_nbr"),\
gg_tbf0_update.cdc_operation_type_cd.alias("cdc_operation_type_cd"),\
gg_tbf0_update.cdc_before_after_cd.alias("cdc_before_after_cd"),\
gg_tbf0_update.cdc_txn_position_cd.alias("cdc_txn_position_cd"),\
gg_tbf0_update.edw_batch_id.alias("edw_batch_id"),\
gg_tbf0_update.store_nbr.alias("store_nbr"),\
gg_tbf0_update.phrm_staff_user_id.alias("phrm_staff_user_id"),\
gg_tbf0_update.staff_initials.alias("staff_initials"),\
gg_tbf0_update.phrm_staff_first_name.alias("phrm_staff_first_name"),\
gg_tbf0_update.phrm_staff_mid_init.alias("phrm_staff_mid_init"),\
gg_tbf0_update.phrm_staff_last_name.alias("phrm_staff_last_name"),\
gg_tbf0_update.phrm_staff_position_cd.alias("phrm_staff_position_cd"),\
gg_tbf0_update.phrm_rph_label_id.alias("phrm_rph_label_id"),\
gg_tbf0_update.phrm_staff_lic_nbr.alias("phrm_staff_lic_nbr"),\
gg_tbf0_update.phrm_staff_home_area_cd.alias("phrm_staff_home_area_cd"),\
gg_tbf0_update.phrm_staff_home_phone.alias("phrm_staff_home_phone"),\
gg_tbf0_update.phrm_phrmcst_access_ind.alias("phrm_phrmcst_access_ind"),\
gg_tbf0_update.p2000_access_level.alias("p2000_access_level"),\
gg_tbf0_update.employment_status_ind.alias("employment_status_ind"),\
gg_tbf0_update.create_user_id.alias("create_user_id"),\
gg_tbf0_update.create_dttm.alias("create_dttm"),\
gg_tbf0_update.update_user_id.alias("update_user_id"),\
gg_tbf0_update.update_dttm.alias("update_dttm"),\
gg_tbf0_update.phrm_staff_spec_lic_nbr.alias("phrm_staff_spec_lic_nbr"),\
gg_tbf0_update.phrm_staff_employed_ind.alias("phrm_staff_employed_ind"),\
gg_tbf0_update.icplus_editable_ind.alias("icplus_editable_ind"),\
gg_tbf0_update.rph_consult_barcd_nbr.alias("rph_consult_barcd_nbr"),\
gg_tbf0_update.rph_barcd_exp_dttm.alias("rph_barcd_exp_dttm"),\
gg_tbf0_update.phrm_staff_npi.alias("phrm_staff_npi"),\
gg_tbf0_update.phrm_staff_rfp_ind.alias("phrm_staff_rfp_ind"),\
gg_tbf0_update.table_name)

gg_tbf0_insert_afr = nr_insert_check.select(nr_insert_check.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"),\
nr_insert_check.cdc_seq_nbr.alias("cdc_seq_nbr"),\
nr_insert_check.cdc_rba_nbr.alias("cdc_rba_nbr"),\
nr_insert_check.cdc_operation_type_cd.alias("cdc_operation_type_cd"),\
nr_insert_check.cdc_before_after_cd_after.alias("cdc_before_after_cd"),\
nr_insert_check.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"),\
nr_insert_check.edw_batch_id_after.alias("edw_batch_id"),\
nr_insert_check.store_nbr_after.alias("store_nbr"),\
nr_insert_check.phrm_staff_user_id_after.alias("phrm_staff_user_id"),\
nr_insert_check.staff_initials_after.alias("staff_initials"),\
nr_insert_check.phrm_staff_first_name_after.alias("phrm_staff_first_name"),\
nr_insert_check.phrm_staff_mid_init_after.alias("phrm_staff_mid_init"),\
nr_insert_check.phrm_staff_last_name_after.alias("phrm_staff_last_name"),\
nr_insert_check.phrm_staff_position_cd_after.alias("phrm_staff_position_cd"),\
nr_insert_check.phrm_rph_label_id_after.alias("phrm_rph_label_id"),\
nr_insert_check.phrm_staff_lic_nbr_after.alias("phrm_staff_lic_nbr"),\
nr_insert_check.phrm_staff_home_area_cd_after.alias("phrm_staff_home_area_cd"),\
nr_insert_check.phrm_staff_home_phone_after.alias("phrm_staff_home_phone"),\
nr_insert_check.phrm_phrmcst_access_ind_after.alias("phrm_phrmcst_access_ind"),\
nr_insert_check.p2000_access_level_after.alias("p2000_access_level"),\
nr_insert_check.employment_status_ind_after.alias("employment_status_ind"),\
nr_insert_check.create_user_id_after.alias("create_user_id"),\
nr_insert_check.create_dttm_after.alias("create_dttm"),\
nr_insert_check.update_user_id_after.alias("update_user_id"),\
nr_insert_check.update_dttm_after.alias("update_dttm"),\
nr_insert_check.phrm_staff_spec_lic_nbr_after.alias("phrm_staff_spec_lic_nbr"),\
nr_insert_check.phrm_staff_employed_ind_after.alias("phrm_staff_employed_ind"),\
nr_insert_check.icplus_editable_ind_after.alias("icplus_editable_ind"),\
nr_insert_check.rph_consult_barcd_nbr_after.alias("rph_consult_barcd_nbr"),\
nr_insert_check.rph_barcd_exp_dttm_after.alias("rph_barcd_exp_dttm"),\
nr_insert_check.phrm_staff_npi_after.alias("phrm_staff_npi"),\
nr_insert_check.phrm_staff_rfp_ind_after.alias("phrm_staff_rfp_ind"), \
nr_insert_check.table_name)

# COMMAND ----------

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")


# COMMAND ----------

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, store_nbr, phrm_staff_user_id, staff_initials, phrm_staff_first_name, phrm_staff_mid_init, phrm_staff_last_name, phrm_staff_position_cd, phrm_rph_label_id, phrm_staff_lic_nbr, phrm_staff_home_area_cd, phrm_staff_home_phone, phrm_phrmcst_access_ind, p2000_access_level, employment_status_ind, create_user_id, CONCAT(substring(create_dttm,0,10),' ',substring(create_dttm,12,19),'.000000') AS create_dttm, update_user_id, CONCAT(substring(update_dttm,0,10),' ',substring(update_dttm,12,19),'.000000') AS update_dttm, phrm_staff_spec_lic_nbr, phrm_staff_employed_ind, icplus_editable_ind, rph_consult_barcd_nbr, CONCAT(substring(rph_barcd_exp_dttm,0,10),' ',substring(rph_barcd_exp_dttm,12,19),'.000000') AS rph_barcd_exp_dttm, phrm_staff_npi, phrm_staff_rfp_ind"

# COMMAND ----------

etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Remove Blank Values
for col in etl_tbf0_reformat.columns:
    etl_tbf0_reformat = etl_tbf0_reformat.withColumn(col, when(ltrim(rtrim(etl_tbf0_reformat[col])) == "",None).otherwise(ltrim(rtrim(etl_tbf0_reformat[col]))))
    
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())\
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
.withColumn("create_dttm",to_timestamp(etl_tbf0_reformat["create_dttm"])) \
.withColumn("update_dttm",to_timestamp(etl_tbf0_reformat["update_dttm"])) \
.withColumn("rph_barcd_exp_dttm",to_timestamp(etl_tbf0_reformat["rph_barcd_exp_dttm"]))

etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)


# COMMAND ----------

#Load ETL_TBF0_PATIENT_MERGE formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

dbutils.notebook.exit("ETL_TBF0_STORE_PHRM_STAFF_STG LOADED SUCCESSFULLY")
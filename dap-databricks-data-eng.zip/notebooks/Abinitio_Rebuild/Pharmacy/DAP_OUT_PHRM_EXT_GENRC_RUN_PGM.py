# Databricks notebook source
dbutils.widgets.text("PAR_INPUT_FILENAME", "", label = "PAR_INPUT_FILENAME")
dbutils.widgets.text("PAR_OUTPUT_FILENAME", "", label = "PAR_OUTPUT_FILENAME")
dbutils.widgets.text("PAR_ARCH_FILENAME", "", label = "PAR_ARCH_FILENAME")
dbutils.widgets.text("PAR_DIRECTORY_PATH", "", label = "PAR_DIRECTORY_PATH")
dbutils.widgets.text("PAR_BATCH_ID", "", label = "PAR_BATCH_ID")
dbutils.widgets.text("PAR_JOB_NM", "", label = "PAR_JOB_NM")
dbutils.widgets.text("PAR_EXTENSION", "", label = "PAR_EXTENSION")

# COMMAND ----------

#Defining paramters

inputFileName = dbutils.widgets.get("PAR_INPUT_FILENAME")
outputFileName = dbutils.widgets.get("PAR_OUTPUT_FILENAME")
archiveFileName = dbutils.widgets.get("PAR_ARCH_FILENAME")
directoryPath = dbutils.widgets.get("PAR_DIRECTORY_PATH")
batchId = dbutils.widgets.get("PAR_BATCH_ID")
jobName = dbutils.widgets.get("PAR_JOB_NM")
fileExt = dbutils.widgets.get("PAR_EXTENSION")
adlsAccountName = 'dapdevadlswrng01'
adlsContainerName = 'wrangled'

# COMMAND ----------


# Define the variables used for creating connection strings
mountPoint = "/mnt/" + adlsContainerName + "/"+ directoryPath + '/input'

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint} 

# COMMAND ----------

from py4j.java_gateway import java_import

def moveAndRenameFiles(folder,fileName, extension, mvFlag):
  java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
  fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(spark._jsc.hadoopConfiguration())
  
  if mvFlag:
    if(fs.exists(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/archive/'))):
      if(fs.exists(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/archive/'+fileName))):
        fs.delete(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/archive/'+fileName))
      fs.rename(sc._jvm.Path(mountPoint+'/' +fileName), sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/archive/'+fileName))
    else:
      fs.mkdirs(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/archive/'))
      fs.rename(sc._jvm.Path(mountPoint+'/' +fileName), sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/archive/'+fileName)) 
  else:
    file = fs.globStatus(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + folder +fileName + "/part*"))[0].getPath().getName()
    if(fs.exists(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + folder+fileName+extension))):
      fs.delete(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + folder+fileName+extension))
    fs.rename(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + folder + fileName + '/' +file), sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + folder+fileName+extension))
  fs.delete(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + folder + fileName), True)
  

# COMMAND ----------

from pyspark.sql import Row
from datetime import datetime
from py4j.java_gateway import java_import

java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(spark._jsc.hadoopConfiguration())
curr_date = datetime.today().strftime('%m/%d/%y %H:%M:%S %p')
dateStr = datetime.today().strftime('%Y%m%d%H%M')
logFileName = 'edw_out_gen_post_batch_'+ dateStr
inputFile = ''
outputFile = ''
if outputFileName=='None':
  inputFile = inputFileName
  outputFile = dateStr
else:
  if inputFileName == 'cust_geo' or inputFileName == 'cust_dcal' or inputFileName == 'Wag_to_SureScripts':
    inputFile = inputFileName + '_' +batchId[0:8] + fileExt
    outputFile = outputFileName + '_' + batchId[0:8]
  elif inputFileName == 'EDW_NYC_Extract':
    inputFile = batchId + '_' + inputFileName  + fileExt
    outputFile = batchId + '_' + outputFileName 
  else:
    inputFile = inputFileName + '_' + batchId + fileExt
    outputFile = outputFileName + '_' + batchId
#Creating Log entry
logRows = [Row(jobName),
       Row("Current Batch Id :" + batchId),
       Row(curr_date + " Copying the files to ftp directory"),
       Row('Input File :' + adlsContainerName +'/'+ directoryPath + '/input/' + inputFile),
       Row('Output File :' + adlsContainerName +'/'+ directoryPath + '/ftp/' + outputFile + fileExt)]
logDf = spark.createDataFrame(logRows,["LogEntry"])

#Copying file to ftp folder
try:
  if fileExt == '.dat.gz':
    if(not fs.exists(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/ftp/'))):      
      fs.mkdirs(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/ftp/'))
    fs.rename(sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/input/' +inputFile), sc._jvm.Path("/mnt/" + adlsContainerName + "/"+ directoryPath + '/ftp/'))
  else:
    fileDf = spark.read.text(mountPoint+'/'+inputFile) 
    fileDf.coalesce(1).write.format('text').option('header',False).mode('overwrite').save("/mnt/" + adlsContainerName + '/'+ directoryPath + '/ftp/' +outputFile)
    moveAndRenameFiles('/ftp/',outputFile,fileExt,False)
  
  isCopySuccess = True
except Exception as e:
  isCopySuccess = False
  print(e)
  pass

#Moving to archived folder
if isCopySuccess:
  newLogRows = [Row("Done copying the Generic Extract to ftp directory at " + curr_date),
               Row("Done Copying the files to gen directory at " + curr_date)]
  moveAndRenameFiles('/input/',inputFile,fileExt,True)
  
else:
  newLogRows = [Row("edw_out_gen_post_batch.ksh failed at "+curr_date+": Please resend the Generic for edw_batch_id of  " + batchId),
                Row("Done Copying the files to gen directory at " + curr_date)]

#Writing Log files
newLogDf = spark.createDataFrame(newLogRows,["LogEntry"])
finalLog = logDf.union(newLogDf)
finalLog.coalesce(1).write.format('text').option('header',False).mode('overwrite').save("/mnt/" + adlsContainerName + '/'+ directoryPath + '/log/' +logFileName)
moveAndRenameFiles('/log/',logFileName,'.log',False)

# COMMAND ----------



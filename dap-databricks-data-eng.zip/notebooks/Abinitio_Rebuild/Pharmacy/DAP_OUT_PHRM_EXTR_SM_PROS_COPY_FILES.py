# Databricks notebook source
dbutils.widgets.text("PAR_INPUT_DIR", "", label = "PAR_INPUT_DIR")
dbutils.widgets.text("PAR_FTP_DIR", "", label = "PAR_FTP_DIR")
dbutils.widgets.text("PAR_TEMP_DIR", "", label = "PAR_TEMP_DIR")
dbutils.widgets.text("PAR_FREQUENCY", "", label = "PAR_FREQUENCY")
dbutils.widgets.text("PAR_BATCH_ID", "", label = "PAR_BATCH_ID")
dbutils.widgets.text("PAR_JOB_NAME", "", label = "PAR_JOB_NAME")

# COMMAND ----------

inputDirectory = dbutils.widgets.get("PAR_INPUT_DIR")
ftpDirectory = dbutils.widgets.get("PAR_FTP_DIR")
tempDirectory = dbutils.widgets.get("PAR_TEMP_DIR")
frequency = dbutils.widgets.get("PAR_FREQUENCY")
batchid = dbutils.widgets.get("PAR_BATCH_ID")
jobname = dbutils.widgets.get('PAR_JOB_NAME')

DRUG_DATA_FILE = 'edw_pros_contcomp_sm_drug_' + frequency + '_' + batchid + '.dat.gz'
CLAIM_DATA_FILE = 'edw_pros_contcomp_sm_claim_' + frequency + '_'  + batchid + '.dat.gz'
DRUG_CNTL_FILE = 'edw_pros_contcomp_sm_drug_' + frequency + '_'  + batchid + '.cntl.gz'
CLAIM_CNTL_FILE = 'edw_pros_contcomp_sm_claim_' + frequency +  '_' +  batchid + '.cntl.gz'

adlsAccountName = 'dapdevadlswrng01'
adlsContainerName = 'wrangled'

# COMMAND ----------

# Define the variables used for creating connection strings
mountPoint = "/mnt/" + adlsContainerName + "/"+ inputDirectory + '/input'

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint} 

# COMMAND ----------

from py4j.java_gateway import java_import


def moveFiles(fileType,datafileName, cntlFilename):
  loggerMessage = ''
  java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
  fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(spark._jsc.hadoopConfiguration())
  try:
    
    fs.rename(sc._jvm.Path(mountPoint + '/' + datafileName), sc._jvm.Path("/mnt/" + adlsContainerName + "/", tempDirectory + '/' + datafileName))    
    
    try:      
      fs.rename(sc._jvm.Path(mountPoint + '/' + cntlFilename), sc._jvm.Path("/mnt/" + adlsContainerName + "/", tempDirectory + '/' + cntlFilename))
      loggerMessage = 'Done moving the '+ fileType + 'Files to Target directory at ' + datetime.today().strftime('%m/%d/%y %H:%M:%S %p')
    except Exception as e:
      print(e)
      loggerMessage = jobname + '.ksh failed at ' + datetime.today().strftime('%m/%d/%y %H:%M:%S %p') +': Drug data and control files not copied successfully for edw_batch_id of ' + batchid
  except Exception as e:
    print(e)
    
    pass
  return loggerMessage

# COMMAND ----------

from datetime import datetime
from pyspark.sql import Row
from pyspark.sql.types import *

currentDate = datetime.today()
logFileName = 'edw_out_sm_pros_post_batch_' + currentDate.strftime('%Y%m%d%H%M')
trgFileName = 'edw_pros_contcomp_sm_start_' + frequency + '_' + batchid

logRows = [Row(jobname),
       Row("Current Batch Id :" + batchid),
       Row(currentDate.strftime('%m/%d/%y %H:%M:%S %p') + " Copying the files to the target directory"),           
       Row('Drug Input File:' + DRUG_DATA_FILE),           
           Row('Claim Input File:' + CLAIM_DATA_FILE),
           Row('Drug Control File:' + DRUG_CNTL_FILE),
           Row('Claim Control File:' + CLAIM_CNTL_FILE),           
       Row('Output Dir:' + tempDirectory),
          Row('Start trigger file created at '+ currentDate.strftime('%m/%d/%y %H:%M:%S %p') )]
logDf = spark.createDataFrame(logRows,["LogEntry"])
trgRow = Row('Pros- EDW extract file transfer started at ' + currentDate.strftime('%m/%d/%y %H:%M:%S %p'))

# COMMAND ----------

#----------------moving DRUG File-----------------#

loggerMessage = moveFiles("Drug", DRUG_DATA_FILE,DRUG_CNTL_FILE)
logRowDrug = Row(loggerMessage)

#----------------moving CLAIM File-----------------#

dbutils.fs.cp(mountPoint + '/' + CLAIM_DATA_FILE, "/mnt/" + adlsContainerName + '/' + ftpDirectory)
dbutils.fs.cp(mountPoint + '/' + CLAIM_CNTL_FILE, "/mnt/" + adlsContainerName + '/' + ftpDirectory)

loggerMessage = moveFiles("Claim", CLAIM_DATA_FILE,CLAIM_CNTL_FILE)
logRowClaim = Row(loggerMessage)

# COMMAND ----------

#----------------Write Log Files--------------------------#

newLogRows = [logRowDrug,logRowClaim, 
              Row('Done moving the files to One Walgreens directory at ' + currentDate.strftime('%m/%d/%y %H:%M:%S %p'))]
newTrgRow = Row('Pros- EDW extract file transfer completed')

appendlogs = spark.createDataFrame(newLogRows,["logEntry"])
finalLog = logDf.union(appendlogs)
trgDf = spark.createDataFrame([trgRow,newTrgRow],['trgEntry'])

finalLog.coalesce(1).write.format('text').option('header',False).mode('overwrite').save("/mnt/" + adlsContainerName + '/'+ inputDirectory +'/' + logFileName)
trgDf.coalesce(1).write.format('text').option('header',False).mode('overwrite').save("/mnt/" + adlsContainerName + '/'+ inputDirectory +'/' + trgFileName)

java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(spark._jsc.hadoopConfiguration())

file = fs.globStatus(sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory +'/' + logFileName + "/part*"))[0].getPath().getName()
fs.rename(sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory + '/' + logFileName + '/' + file), sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory + '/log/' + logFileName + '.log'))
fs.delete(sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory + '/' + logFileName ), True)


trgfile = fs.globStatus(sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory +'/' +trgFileName + "/part*"))[0].getPath().getName()
fs.rename(sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory + '/' + trgFileName + '/' + trgfile), sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ tempDirectory + '/' + trgFileName + '.trg'))
fs.delete(sc._jvm.Path("/mnt/" + adlsContainerName + '/'+ inputDirectory + '/' + trgFileName ), True)


# COMMAND ----------



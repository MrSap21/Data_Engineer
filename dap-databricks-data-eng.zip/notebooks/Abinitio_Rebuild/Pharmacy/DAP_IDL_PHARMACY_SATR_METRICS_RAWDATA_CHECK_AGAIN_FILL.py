# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove('EXEC_WK_START_DT')
#dbutils.widgets.text('PAR_EXEC_WK_START_DT', '')

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFK_DB_PHAR = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFK_DB_STG = dbutils.widgets.get("PAR_DB_SNFK_STG_DB")
EXEC_WK_START_DT = dbutils.widgets.get("PAR_EXEC_WK_START_DT")

# COMMAND ----------

SNFK_SC_P = 'PATIENT'
SNFK_SC_PS = 'PATIENT_SERVICES'
SNFK_SC_PH = 'PHARMACY_HEALTHCARE'
SNFK_SC_CF = 'PRDETL'
SNFK_TBL_PRES_FILL = 'PRESCRIPTION_FILL'
SNFK_TBL_SATR = 'TEMP_SATR_COPY_CREATE_FINALL_STG'
SNFK_TBL_PRES_FILL_P = 'PRESCRIPTION_FILL_PLAN'
SNFK_TBL_P = 'PATIENT'
SNFK_DB_PRDETL=''
#EXEC_WK_START_DT = ''

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFK_DB_STG $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

SEL_QUERY = """select tsat.xfer_to_rx_nbr
      ,tsat.xfer_to_str_nbr
      ,tsat.rx_nbr
      ,tsat.store_nbr
      ,pfill.rx_fill_nbr
      ,pfill.dspn_fill_nbr
      ,pfill.fill_qty_dspn
      ,pfill.update_dttm
      ,pfill.fill_sold_dt
      ,pfill.fill_est_pick_up_dttm
      ,pfill.fill_enter_dt
      ,pfill.fill_enter_user_id
      ,pfill.fill_vrfy_dt
      ,pfill.fill_stat_cd
      ,pfill.fill_vrfy_user_id
      ,pfill.fill_print_dt
      ,pfill.fill_days_supply 
      ,pfill.drug_id
      ,pfill.drug_name
      ,pfill.fill_type_cd
      ,pfp.third_party_plan_id
      ,pfp.plan_group_nbr
      ,pfp.bin_nbr
      ,pfp.prcs_ctrl_nbr
      ,pat.first_name
      ,pat.last_name
      ,pat.gndr_cd
      ,pat.brth_dt
      ,tsat.pat_id
      ,tsat.work_order
      ,tsat.expected_fill_enter_dt
      ,tsat.max_fill_enter_dt
      ,tsat.orig_fill_dspn_qnty
from {0}.{2}.{5} pfill 
inner join {11}.{10}.{6} tsat 
      on tsat.xfer_to_rx_nbr=pfill.rx_nbr 
      and tsat.xfer_to_str_nbr=pfill.str_nbr
      and pfill.fill_sold_dt>=TO_DATE('{9}'  , 'YYYY-MM-DD') 
      and	pfill.fill_enter_dt>=TO_DATE('{9}'  , 'YYYY-MM-DD')
left outer join {0}.{2}.{7} pfp
      on pfill.rx_nbr = pfp.rx_nbr
      and     pfill.str_nbr = pfp.str_nbr
      and     pfill.rx_fill_nbr = pfp.rx_fill_nbr
      and pfp.cob_ind = 'N'
left outer join {0}.{4}.{8}  pat
        on tsat.pat_id = pat.pat_id
UNION 
        select 
         tsat.xfer_to_rx_nbr
        ,tsat.xfer_to_str_nbr
        ,tsat.rx_nbr
        ,tsat.store_nbr
        ,pfill.rx_fill_nbr
        ,pfill.dspn_fill_nbr
        ,pfill.fill_qty_dspn
        ,pfill.update_dttm
        ,pfill.fill_sold_dt
        ,pfill.fill_est_pick_up_dttm
        ,pfill.fill_enter_dt
        ,pfill.fill_enter_user_id
        ,pfill.fill_vrfy_dt
        ,pfill.fill_stat_cd
        ,pfill.fill_vrfy_user_id
        ,pfill.fill_print_dt
        ,pfill.fill_days_supply 
        ,pfill.drug_id
        ,pfill.drug_name
        ,pfill.fill_type_cd
        ,pfp.third_party_plan_id
        ,pfp.plan_group_nbr
        ,pfp.bin_nbr
        ,pfp.prcs_ctrl_nbr
        ,pat.first_name
        ,pat.last_name
        ,pat.gndr_cd
        ,pat.brth_dt
        ,tsat.pat_id
        ,tsat.work_order
        ,tsat.expected_fill_enter_dt
        ,tsat.max_fill_enter_dt
        ,tsat.orig_fill_dspn_qnty
from {0}.{2}.{5} pfill
inner join {11}.{10}.{6}  tsat 
        on  tsat.xfer_to_rx_nbr=pfill.rx_nbr 
        and tsat.xfer_to_str_nbr=pfill.str_nbr
        and pfill.fill_sold_dt is NULL
        and pfill.fill_enter_dt>=TO_DATE('{9}'  , 'YYYY-MM-DD')
left outer join {0}.{2}.{7}  pfp 
        on      pfill.rx_nbr = pfp.rx_nbr
        and     pfill.str_nbr = pfp.str_nbr
        and     pfill.rx_fill_nbr = pfp.rx_fill_nbr
        and pfp.cob_ind = 'N'
left outer join {0}.{4}.{8}  pat
        on tsat.pat_id = pat.pat_id""".format(SNFK_DB_PHAR, SNFK_DB_PRDETL, SNFK_SC_PS, SNFK_SC_CF, SNFK_SC_P, SNFK_TBL_PRES_FILL, SNFK_TBL_SATR, SNFK_TBL_PRES_FILL_P, SNFK_TBL_P, EXEC_WK_START_DT,SNFK_SC_PH,SNFK_DB_STG)

# COMMAND ----------

df_sel = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", SEL_QUERY) \
  .load()

#df_sel.show()

# COMMAND ----------

#Filtering condition for Fills enter with in 5 days

df_sel = df_sel.filter((df_sel.FILL_ENTER_DT.isNotNull()) & (df_sel.FILL_ENTER_DT >= df_sel.EXPECTED_FILL_ENTER_DT) & (df_sel.FILL_ENTER_DT < df_sel.MAX_FILL_ENTER_DT) & (datediff(df_sel.FILL_ENTER_DT,df_sel.EXPECTED_FILL_ENTER_DT ) <5))

#Sorting result

#df_sel = df_sel.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR", "RX_FILL_NBR" )

#df_sel.show()

#df_sort1=df_sel
#print(df_sort1.count())

# COMMAND ----------

'''df_fi_vdt=df_sort1.groupBy("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR").agg(last("FILL_VRFY_DT",ignorenulls=True).alias("derv_fi_vdt"))
#display(df_fi_vdt)
df_r1=df_sort1.alias("in0").join(df_fi_vdt.alias("in1"), (  (df_sort1.STORE_NBR==df_fi_vdt.STORE_NBR)  &       (df_sort1.RX_NBR==df_fi_vdt.RX_NBR)  &  (df_sort1.EXPECTED_FILL_ENTER_DT==df_fi_vdt.EXPECTED_FILL_ENTER_DT)  &  (df_sort1.XFER_TO_STR_NBR==df_fi_vdt.XFER_TO_STR_NBR) &  (df_sort1.XFER_TO_RX_NBR==df_fi_vdt.XFER_TO_RX_NBR) &  (df_sort1.DSPN_FILL_NBR==df_fi_vdt.DSPN_FILL_NBR)) , "inner").select(col("in0.*"),col("in1.derv_fi_vdt")).drop(col("FILL_VRFY_DT")).withColumn("FILL_VRFY_DT",col("derv_fi_vdt")).drop(col("derv_fi_vdt"))
#display(df_r1)
'''
from pyspark.sql.window import Window
windowSpec  = Window.partitionBy("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR").orderBy("RX_FILL_NBR")

df_r1=df_sel.withColumn("FILL_VRFY_DT",last("FILL_VRFY_DT",ignorenulls=True).over(windowSpec))



# COMMAND ----------

df_r1=df_r1.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR", "RX_FILL_NBR")
df_r1.cache()
df_g1_51=df_r1.filter(df_r1.FILL_ENTER_USER_ID==51).groupBy("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR").agg(last("FILL_ENTER_USER_ID",ignorenulls=True).alias("derv_fill_enter_user_id"),last("FILL_ENTER_DT",ignorenulls=True).alias("derv_fill_enter_dt"))
#display(df_g1_51)
df_tg=df_r1.select("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR").distinct()
#print(df_tg.count())
df_g1=df_g1_51.select("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR").distinct()
#print(df_g1.count())
df_g2=df_tg.exceptAll(df_g1)
#print(df_g2.count())

# COMMAND ----------

df_g2_join=df_r1.alias("in0").join(df_g2.alias("in1"),  (  (df_r1.STORE_NBR==df_g2.STORE_NBR)  &       (df_r1.RX_NBR==df_g2.RX_NBR)  &  (df_r1.EXPECTED_FILL_ENTER_DT==df_g2.EXPECTED_FILL_ENTER_DT)  &  (df_r1.XFER_TO_STR_NBR==df_g2.XFER_TO_STR_NBR) &  (df_r1.XFER_TO_RX_NBR==df_g2.XFER_TO_RX_NBR) &  (df_r1.DSPN_FILL_NBR==df_g2.DSPN_FILL_NBR) ) , "inner").select(col("in0.*"))
#df_g2_join=df_g2_join.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR", "RX_FILL_NBR")

# COMMAND ----------

'''df_g2_join1=df_g2_join.groupBy("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR").agg(first("FILL_ENTER_USER_ID",ignorenulls=True).alias("derv_fill_enter_user_id"),first("FILL_ENTER_DT",ignorenulls=True).alias("derv_fill_enter_dt"))
'''
#display(df_g2_join1)

# COMMAND ----------

df_u1=df_r1.alias("in0").join(df_g1_51.alias("in1"), (  (df_r1.STORE_NBR==df_g1_51.STORE_NBR)  &       (df_r1.RX_NBR==df_g1_51.RX_NBR)  &  (df_r1.EXPECTED_FILL_ENTER_DT==df_g1_51.EXPECTED_FILL_ENTER_DT)  &  (df_r1.XFER_TO_STR_NBR==df_g1_51.XFER_TO_STR_NBR)  &       (df_r1.XFER_TO_RX_NBR==df_g1_51.XFER_TO_RX_NBR)  &       (df_r1.DSPN_FILL_NBR==df_g1_51.DSPN_FILL_NBR)) , "inner").select(col("in0.*"),col("in1.derv_fill_enter_user_id"),col("in1.derv_fill_enter_dt")).drop(col("FILL_ENTER_USER_ID")).drop(col("FILL_ENTER_DT")).withColumn("FILL_ENTER_USER_ID",col("derv_fill_enter_user_id")) \
.withColumn("FILL_ENTER_DT",col("derv_fill_enter_dt")).drop(col("derv_fill_enter_user_id")).drop(col("derv_fill_enter_dt"))
#display(df_u1)
df_u2=df_g2_join.withColumn("FILL_ENTER_USER_ID",first("FILL_ENTER_USER_ID").over(windowSpec)).withColumn("FILL_ENTER_DT",first("FILL_ENTER_DT").over(windowSpec))
'''
df_u2=df_r1.alias("in0").join(df_g2_join1.alias("in1"), (  (df_r1.STORE_NBR==df_g2_join1.STORE_NBR)  &       (df_r1.RX_NBR==df_g2_join1.RX_NBR)  &  (df_r1.EXPECTED_FILL_ENTER_DT==df_g2_join1.EXPECTED_FILL_ENTER_DT)  &  (df_r1.XFER_TO_STR_NBR==df_g2_join1.XFER_TO_STR_NBR) &  (df_r1.XFER_TO_RX_NBR==df_g2_join1.XFER_TO_RX_NBR) &  (df_r1.DSPN_FILL_NBR==df_g2_join1.DSPN_FILL_NBR)) , "inner").select(col("in0.*"),col("in1.derv_fill_enter_user_id"),col("in1.derv_fill_enter_dt")).drop(col("FILL_ENTER_USER_ID")).drop(col("FILL_ENTER_DT")).withColumn("FILL_ENTER_USER_ID",col("derv_fill_enter_user_id")) \
.withColumn("FILL_ENTER_DT",col("derv_fill_enter_dt")).drop(col("derv_fill_enter_user_id")).drop(col("derv_fill_enter_dt"))
'''
#display(df_u2)
df_sel=df_u1.unionByName(df_u2)
#display(df_sel)

# COMMAND ----------

#print(df_sel.count())

# COMMAND ----------

#Sorting based on keys
df_sel = df_sel.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "XFER_TO_STR_NBR", "XFER_TO_RX_NBR", "DSPN_FILL_NBR")

#Remove Duplicates
df_sel = df_sel.dropDuplicates(['STORE_NBR', 'RX_NBR', 'EXPECTED_FILL_ENTER_DT', 'XFER_TO_STR_NBR', 'XFER_TO_RX_NBR'])

# COMMAND ----------

#Set priority base on Fill Status

df_sel = df_sel.withColumn("PRIORITY_FLAG", when(df_sel.FILL_STAT_CD == 'SD', 1)
                                        .when(df_sel.FILL_STAT_CD == 'RD', 2)
                                        .when(df_sel.FILL_STAT_CD == 'VR', 3)
                                        .when(df_sel.FILL_STAT_CD == 'EN', 4)
                                        .otherwise(lit(5)))

#sorting
df_sel = df_sel.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT", "PRIORITY_FLAG")

#Removing duplicates based on keys
df_sel_dropDuplicates = df_sel.dropDuplicates(['STORE_NBR', 'RX_NBR', 'EXPECTED_FILL_ENTER_DT'])
df_sel_non_dropDuplicates = df_sel.exceptAll(df_sel_dropDuplicates)
#Filtering data based on condition
df_fil1 = df_sel_non_dropDuplicates.filter(df_sel_non_dropDuplicates.FILL_ENTER_USER_ID==51)

#df_fil1.show()

# COMMAND ----------

df_join1 = df_sel_dropDuplicates.alias("in0").join(df_fil1.alias("in1"), ((df_sel_dropDuplicates.STORE_NBR == df_fil1.STORE_NBR) & (df_sel_dropDuplicates.RX_NBR == df_fil1.RX_NBR) & (df_sel_dropDuplicates.EXPECTED_FILL_ENTER_DT == df_fil1.EXPECTED_FILL_ENTER_DT)), "left").select(col("in0.*"),coalesce(col("in1.FILL_ENTER_USER_ID"),col("in0.FILL_ENTER_USER_ID")).alias("fill_enter_user_id_acutal")).drop(col("in0.FILL_ENTER_USER_ID")) \
.withColumn("FILL_ENTER_USER_ID",col("fill_enter_user_id_acutal")).drop(col("fill_enter_user_id_acutal"))
#display(df_join1)


# COMMAND ----------

df_join1.printSchema()

# COMMAND ----------

#"select * from "+$PAR_DF_DATABASE_STG+"."+$PAR_DF_ADHOC_SATR_FILLED_RXL+""
SNFK_DB_STG = dbutils.widgets.get("PAR_DB_SNFK_STG_DB")
SNFK_TBL_ADHOC_SATR_FILLED_RXL = 'ADHOC_SATR_FILLED_RXL_STG'
SNFK_SC_PH ='PHARMACY_HEALTHCARE'
SEL_ADHOC_SATR_FILLED_RXL = """select * from {0}.{1}.{2}""".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_ADHOC_SATR_FILLED_RXL)
#SEL_ADHOC_SATR_FILLED_RXL.show()

# COMMAND ----------

df_ADHOC_SATR_FILLED_RXL = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("query",SEL_ADHOC_SATR_FILLED_RXL)\
   .load()
#df_ADHOC_SATR_FILLED_RXL.show()

df_df_ADHOC_SATR_FILLED_RXL_sort= df_ADHOC_SATR_FILLED_RXL.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT")

#df_df_ADHOC_SATR_FILLED_RXL_sort.show()

# COMMAND ----------

df_df_ADHOC_SATR_FILLED_RXL_sort.printSchema()

# COMMAND ----------

df_join1.printSchema()

# COMMAND ----------

df_join2 = df_df_ADHOC_SATR_FILLED_RXL_sort.alias("in0").join(df_join1.alias("in1"), ((df_df_ADHOC_SATR_FILLED_RXL_sort.STORE_NBR == df_join1.STORE_NBR) & (df_df_ADHOC_SATR_FILLED_RXL_sort.RX_NBR == df_join1.RX_NBR) & (df_df_ADHOC_SATR_FILLED_RXL_sort.EXPECTED_FILL_ENTER_DT == df_join1.EXPECTED_FILL_ENTER_DT)), "right").select(col("in1.*"),when( ( (col("in1.FILL_ENTER_USER_ID").isNotNull()) & (col("in1.FILL_ENTER_USER_ID")==51)),col("in1.FILL_ENTER_DT")).otherwise(coalesce(col("in0.FILL_ENTER_DT"),col("in1.FILL_ENTER_DT"))).alias("FILL_ENTER_DT_Actual"),when( ( (col("in1.FILL_ENTER_USER_ID").isNotNull()) & (col("in1.FILL_ENTER_USER_ID")==51)),col("in1.FILL_ENTER_USER_ID")).otherwise(coalesce(col("in0.FILL_ENTER_USER_ID"),col("in1.FILL_ENTER_USER_ID"))).alias("FILL_ENTER_USER_ID_Actual"),
lit('Y').alias("COPY_CREATED")).drop(col("in1.FILL_ENTER_USER_ID")).drop(col("in1.FILL_ENTER_DT")).withColumn("FILL_ENTER_USER_ID",col("FILL_ENTER_USER_ID_Actual")).withColumn("FILL_ENTER_DT",col("FILL_ENTER_DT_Actual")).drop(col("FILL_ENTER_DT_Actual")).drop(col("FILL_ENTER_USER_ID_Actual"))
#display(df_join2) 

#Suresh Help


# COMMAND ----------

df_df_ADHOC_SATR_FILLED_RXL_sort.printSchema()

# COMMAND ----------

df_join2_antijoin = df_df_ADHOC_SATR_FILLED_RXL_sort.alias("in0").join(df_join1.alias("in1"), ((df_join1.STORE_NBR == df_df_ADHOC_SATR_FILLED_RXL_sort.STORE_NBR) & (df_join1.RX_NBR == df_df_ADHOC_SATR_FILLED_RXL_sort.RX_NBR) & (df_join1.EXPECTED_FILL_ENTER_DT == df_df_ADHOC_SATR_FILLED_RXL_sort.EXPECTED_FILL_ENTER_DT)), "leftanti").select(col("in0.*")).withColumn("XFER_TO_STR_NBR",col("in0.PICKUP_STORE_NBR")).drop(col("in0.PICKUP_STORE_NBR"))

#help

# COMMAND ----------

df_union1=df_join2.unionByName(df_join2_antijoin,allowMissingColumns = True)
#display(df_union1)

# COMMAND ----------

df_union2 = df_union1.select(df_union1.RX_NBR                 
,df_union1.STORE_NBR             
,df_union1.XFER_TO_RX_NBR        
,df_union1.XFER_TO_STR_NBR       
,df_union1.RX_FILL_NBR           
,df_union1.DSPN_FILL_NBR         
,df_union1.FILL_SOLD_DT          
,df_union1.FILL_EST_PICK_UP_DTTM 
,df_union1.FILL_ENTER_DT         
,df_union1.FILL_ENTER_USER_ID    
,df_union1.FILL_VRFY_DT          
,df_union1.FILL_QTY_DSPN         
,df_union1.UPDATE_DTTM           
,df_union1.FILL_STAT_CD          
,df_union1.DRUG_ID               
,df_union1.DRUG_NAME             
,df_union1.PAT_ID                
,df_union1.WORK_ORDER            
,df_union1.COPY_CREATED          
,df_union1.EXPECTED_FILL_ENTER_DT
,df_union1.MAX_FILL_ENTER_DT     
,df_union1.ORIG_FILL_DSPN_QNTY   
)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.sql.functions import *



df_q1_out=df_union1.select([F.col(x).alias(x.lower()) for x in df_union1.columns])
#df_q1_out.show()

PAR_OUTPUT_STG_FILE_PATH='partner_extracts/pharmacy_healthcare/staging'
PAR_OUTPUT_STG_FILE_3='temp123'
path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,PAR_OUTPUT_STG_FILE_3,BATCH_ID)
df_q1_out.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

SNFK_TBL_ADHOC_SATR_FILLED_RX_LVL2L = 'ADHOC_SATR_FILLED_RX_LVL2L_STG'

delete_ADHOC_SATR_FILLED_RX_LVL2L_tbl = "Truncate table {0}.{1}.{2}".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_ADHOC_SATR_FILLED_RX_LVL2L)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_ADHOC_SATR_FILLED_RX_LVL2L_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFK_DB_STG,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

df_union2.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("dbtable", "PHARMACY_HEALTHCARE.ADHOC_SATR_FILLED_RX_LVL2L_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

df_union_sort = df_union1.sort("STORE_NBR", "RX_NBR", "EXPECTED_FILL_ENTER_DT")
df_filter_1 = df_union_sort.filter(df_join2.FILL_STAT_CD != 'DL')
df_filter_2 = df_union_sort.filter(df_join2.FILL_STAT_CD == 'DL')

# COMMAND ----------

#SNFK_DB_STG = dbutils.widgets.get("PAR_DB_SNFK_STG_DB")
SNFK_TBL_TEMP_SATR_EXTRACTL = 'TEMP_SATR_EXTRACTL_STG'
#SNFK_SC_PH ='PHARMACY_HEALTHCARE'
SEL_TEMP_SATR_EXTRACTL = """select * from {0}.{1}.{2}""".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_TEMP_SATR_EXTRACTL)
#SEL_ADHOC_SATR_FILLED_RXL.show()

# COMMAND ----------

df_TEMP_SATR_EXTRACTL = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("query",SEL_TEMP_SATR_EXTRACTL)\
   .load()
#df_TEMP_SATR_EXTRACTL.show()

df_TEMP_SATR_EXTRACTL_sort = df_TEMP_SATR_EXTRACTL.sort("STORE_NBR","RX_NBR","EXPECTED_FILL_ENTER_DT")

# COMMAND ----------

df_join_3 = df_filter_1.alias("in0").join(df_TEMP_SATR_EXTRACTL_sort.alias("in1"),((df_filter_1.STORE_NBR == df_TEMP_SATR_EXTRACTL_sort.STORE_NBR) &  (df_filter_1.RX_NBR == df_TEMP_SATR_EXTRACTL_sort.RX_NBR) &  (df_filter_1.EXPECTED_FILL_ENTER_DT == df_TEMP_SATR_EXTRACTL_sort.EXPECTED_FILL_ENTER_DT)),"right").select("in1.*")

# COMMAND ----------

df_filter_2.printSchema()

# COMMAND ----------

df_Final_join = df_join_3.alias("in0").join(df_filter_2.alias("in1"),((df_join_3.STORE_NBR == df_filter_2.STORE_NBR) &  (df_join_3.RX_NBR == df_filter_2.RX_NBR) &  (df_join_3.EXPECTED_FILL_ENTER_DT == df_filter_2.EXPECTED_FILL_ENTER_DT)),"left").select(col("in0.*"),coalesce(col("in0.RX_NBR"),col("in1.XFER_TO_RX_NBR")).alias("RX_NBR_Actual"),
coalesce(col("in0.STORE_NBR"),col("in1.XFER_TO_STR_NBR")).alias("STORE_NBR_Actuall")).drop(col("in0.RX_NBR")).drop(col("in0.STORE_NBR")).withColumn("RX_NBR",col("RX_NBR_Actual")).withColumn("STORE_NBR",col("STORE_NBR_Actuall")).drop(col("RX_NBR_Actual")).drop(col("STORE_NBR_Actuall"))

#column addition


# COMMAND ----------

#Rearrange Columns
Df_Final_Columns = df_Final_join.select(df_Final_join.PAT_ID
,df_Final_join.STORE_NBR
,df_Final_join.PICKUP_STORE_NBR
,df_Final_join.RX_NBR
,df_Final_join.WORK_ORDER
,df_Final_join.EXPECTED_FILL_ENTER_DT
,df_Final_join.MAX_FILL_ENTER_DT
,df_Final_join.ORIG_FILL_DSPN_QNTY)

# COMMAND ----------

SNFK_TBL_ADHOC_SATR_NOT_FILLED_RXL = 'ADHOC_SATR_NOT_FILLED_RXL_STG'

delete_ADHOC_SATR_NOT_FILLED_RXL_tbl = "Truncate table {0}.{1}.{2}".format(SNFK_DB_STG,SNFK_SC_PH,SNFK_TBL_ADHOC_SATR_NOT_FILLED_RXL)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_ADHOC_SATR_NOT_FILLED_RXL_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFK_DB_STG,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

Df_Final_Columns.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_STG) \
   .option("dbtable", "PHARMACY_HEALTHCARE.ADHOC_SATR_NOT_FILLED_RXL_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()
#df_filter_sel.show()

#print(Df_Final_Columns.count())
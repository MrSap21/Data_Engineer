# Databricks notebook source
# Return connection details

options = eval(dbutils.notebook.run("../Utilities/SnowflakeConnOptions", 60))

# COMMAND ----------

# Load data to dataframe

df = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", dbutils.widgets.get("pSQL_QUERY")) \
  .load()

# COMMAND ----------

# Apply RFMT

from pyspark.sql.types import *
from pyspark.sql.functions import *

dfRMFT = df \
         .withColumn("rx_nbr", trim(col("rx_nbr"))) \
		 .withColumn("rx_partial_fill_nbr", trim(col("rx_partial_fill_nbr"))) \
         .withColumn("fill_partial_cd", trim(col("fill_partial_cd"))) \
		 .withColumn("fill_pat_src_id", trim(col("fill_pat_src_id"))) \
		 .withColumn("pbr_provider_src_id", trim(col("pbr_provider_src_id"))) \
		 .withColumn("pbr_provider_addr_src_id", trim(col("pbr_provider_addr_src_id"))) \
		 .withColumn("fill_stat_cd", trim(col("fill_stat_cd"))) \
		 .withColumn("fill_pay_method_cd", trim(col("fill_pay_method_cd"))) \
		 .withColumn("fill_discnt_cd", trim(col("fill_discnt_cd"))) \
		 .withColumn("fill_vrfy_user_id", when(col("fill_vrfy_user_id") == "#", None).otherwise(trim(col("fill_vrfy_user_id")))) \
		 .withColumn("fill_type_cd", trim(col("fill_type_cd"))) \
		 .withColumn("fill_data_review_user_id", when(col("fill_data_review_user_id") == "#", None).otherwise(trim(col("fill_data_review_user_id")))) \
		 .withColumn("fill_enter_user_id", when(col("fill_enter_user_id") == "#", None).otherwise(trim(col("fill_enter_user_id")))) \
		 .withColumn("fill_src_cd", trim(col("fill_src_cd"))) \
		 .withColumn("filling_user_id", when(col("filling_user_id") == "#", None).otherwise(trim(col("filling_user_id")))) \
		 .withColumn("drug_id", trim(col("drug_id"))) \
		 .withColumn("drug_name", trim(col("drug_name"))) \
		 .withColumn("dea_class_cd", trim(col("dea_class_cd"))) \
		 .withColumn("refill_remain_when_enter_cnt", trim(col("refill_remain_when_enter_cnt")) \
		 .withColumn("tot_amt_paid_cd", trim(col("tot_amt_paid_cd"))) \
		 .withColumn("override_user_id", when(col("override_user_id") == "#", None).otherwise(trim(col("override_user_id")))) \
		 .withColumn("src_create_user_id", when(col("src_create_user_id") == "#", None).otherwise(trim(col("src_create_user_id")))) \
		 .withColumn("src_update_user_id", when(col("src_update_user_id") == "#", None).otherwise(trim(col("src_update_user_id")))) \
		 .withColumn("data_review_spct_id", when(col("data_review_spct_id") == "#", None).otherwise(trim(col("data_review_spct_id")))) \
		 .withColumn("fill_rph_of_rec_id", when(col("fill_rph_of_rec_id") == "#", None).otherwise(trim(col("fill_rph_of_rec_id")))) \
		 .withColumn("drug_whse_cd", trim(col("drug_whse_cd"))) \
		 .withColumn("service_lvl_cd", trim(col("service_lvl_cd"))) \
		 .withColumn("rx_daw_ind_cd", trim(col("rx_daw_ind_cd"))) \
		 .withColumn("store_sourcing_cd", trim(col("store_sourcing_cd"))) \
		 .withColumn("tip_rsn_for_svc_cd", trim(col("tip_rsn_for_svc_cd"))) \
		 .withColumn("fill_cost_plus_fee_cd", trim(col("fill_cost_plus_fee_cd"))) \
		 .withColumn("ecom_cd", trim(col("ecom_cd"))) \
		 .withColumn("cust_pref_val", trim(col("cust_pref_val"))) \
		 .withColumn("drug_dspn_id", when(col("drug_dspn_id") == "#", None).otherwise(trim(col("drug_dspn_id")))) \
		 .withColumn("insure_plan_src_id", when(col("insure_plan_src_id") == "#", None).otherwise(trim(col("insure_plan_src_id")))) \
		 .withColumn("plan_rank_cd", when(col("plan_rank_cd") == "#", None).otherwise(trim(col("plan_rank_cd")))) \            
         .withColumn("adjud_cd", trim(col("adjud_cd"))) \
         .withColumn("basis_of_remb_cd", trim(col("basis_of_remb_cd"))) \
         .withColumn("plan_bank_id_nbr", trim(col("plan_bank_id_nbr"))) \
         .withColumn("plan_type_cd", trim(col("plan_type_cd"))) \
         .withColumn("del_adjud_cd", trim(col("del_adjud_cd"))) \
         .withColumn("plan_other_paid_amt_qlfr_cd", trim(col("plan_other_paid_amt_qlfr_cd"))) \
         .withColumn("plan_other_submit_amt_qlfr_cd", trim(col("plan_other_submit_amt_qlfr_cd"))) \
         .withColumn("plan_other_paid_2_amt_qlfr_cd", trim(col("plan_other_paid_2_amt_qlfr_cd"))) \
         .withColumn("plan_other_paid_3_amt_qlfr_cd", trim(col("plan_other_paid_3_amt_qlfr_cd"))) \
         .withColumn("src_sys_name", trim(col("src_sys_name"))) \ 
         .withColumn("fill_enter_store_nbr", when(col("fill_enter_store_nbr") == -1, None).otherwise(trim(col("fill_enter_store_nbr")))) \
         .withColumn("fill_review_store_nbr", when(col("fill_review_store_nbr") == -1, None).otherwise(trim(col("fill_review_store_nbr")))) \
         .withColumn("relocate_fm_store_nbr", when(col("relocate_fm_store_nbr") == -1, None).otherwise(trim(col("relocate_fm_store_nbr")))) \
         .withColumn("data_review_spct_store_nbr", when(col("data_review_spct_store_nbr") == -1, None).otherwise(trim(col("data_review_spct_store_nbr")))) \
         .withColumn("prcs_ctrl_nbr", trim(col("prcs_ctrl_nbr")))


# COMMAND ----------

# Build Output

dfOutput = dfRFMT.select("rx_nbr","store_nbr","rx_create_dt","rx_fill_nbr","rx_partial_fill_nbr","fill_dspn_nbr","fill_partial_cd","fill_pat_src_id","pbr_provider_src_id","pbr_provider_addr_src_id","fill_sold_dt","fill_sold_tm","fill_sold_amt","fill_stat_cd","fill_dspn_qty","fill_pay_method_cd","fill_days_supply_nbr","fill_awp_amt","fill_discnt_cd","fill_discnt_amt","fill_rtl_price_amt","fill_label_price_amt","fill_vrfy_user_id","fill_vrfy_dt","fill_vrfy_tm","fill_type_cd","fill_del_dt","fill_del_tm","fill_data_review_user_id","fill_data_review_dt","fill_data_review_tm","fill_enter_user_id","fill_enter_dt","fill_enter_tm","fill_src_cd","fill_wac_amt","filling_user_id","filling_dt","filling_tm","fill_enter_store_nbr","fill_review_store_nbr","drug_id","drug_name","dea_class_cd","refill_remain_cnt","refill_remain_when_enter_cnt","tot_amt_paid_cd","sims_upc","override_user_id","override_dt","override_tm","relocate_fm_store_nbr","src_create_user_id","src_create_dttm","src_update_user_id","src_update_dttm","src_partition_nbr","fill_consult_outcome_cd","cash_discnt_savings_amt","data_review_spct_dttm","data_review_spct_id","data_review_spct_store_nbr","fax_image_id","fill_price_override_amt","fill_rph_of_rec_id","route_store_tech_initials","drug_whse_cd","service_lvl_cd","rx_daw_ind_cd","store_sourcing_cd","tip_rsn_for_svc_cd","fill_est_pickup_dttm","fill_cost_plus_fee_cd","rec_src_cd","med_auth_nbr","mfgr_confirmation_nbr","ecom_cd","fill_print_dt","fill_print_tm","cust_pref_val","fill_rebill_dt","fill_rebill_tm","drug_dspn_id","insure_plan_src_id","plan_rank_cd","adjud_dt","adjud_tm","adjud_cd","claim_ref_nbr","plan_tot_paid_amt","plan_return_cost_amt","plan_return_fee_amt","plan_return_copay_amt","plan_return_tax_amt","plan_submit_copay_amt","plan_submit_cost_amt","plan_submit_fee_amt","plan_submit_tax_amt","plan_acct_receivable_amt","plan_gross_due_amt","basis_of_remb_cd","plan_bank_id_nbr","plan_type_cd","del_adjud_cd","general_phrm_nbr","general_recipient_nbr","general_rph_nbr","major_medical_prior_auth_nbr","plan_submit_incentive_amt","plan_return_incentive_amt","plan_other_paid_amt","plan_other_submit_amt","plan_tax_amt","remb_loss_amt","pat_copay_amt","plan_other_amt","plan_tax_amt_1","plan_return_coinsure2_amt","plan_return_coinsure1_amt","plan_other_paid_amt_qlfr_cd","plan_other_submit_amt_qlfr_cd","plan_other_paid_2_amt","plan_other_paid_2_amt_qlfr_cd","plan_other_paid_3_amt","plan_other_paid_3_amt_qlfr_cd","partial_fill_tot_intended_qty","src_sys_name","apprv_msg_cd2","additional_msg_qlfr_w1_cd","additional_mfgr_coupon_w1_msg","insure_plan_group_src_nbr","prcs_ctrl_nbr")

# COMMAND ----------

# Write outputs

# Main output
dfOutput.createOrReplaceGlobalTempView("DAP_GEN_SERIAL_EXTR_340B_025_FILL_FILLPLAN_EXTRACT_OPT2")
file_path_output = "{0}/{1}/edw_out_340B_025_Fill_FillPlan_Extract_opt2".format(mountPoint, dbutils.widgets.get("AI_SERIAL"))
dbutils.notebook.run("../Utilities/WRITE_TO_STORAGE", 60, {"file_path": file_path_output, "file_extention": "dat", "view_name": "DAP_GEN_SERIAL_EXTR_340B_025_FILL_FILLPLAN_EXTRACT_OPT2", "delimiter": "\x01", "has_header": "false"})
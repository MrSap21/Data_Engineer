# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# # ReadAPI Call to fetch asset file names with current location:  
# FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
# READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPI", 60, 
#                   {"PAR_READAPI_KEY":"feedNames",
#                    "PAR_READAPI_URL":READAPI_URL,
#                    "PAR_READAPI_VALUE":FEED_NAME,
#                    "PAR_RETURN_FILE_TYPE":"A"});

# print(Input_File_List)

# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_DB_FILE_LIST","DEV_ETL")
#dbutils.widgets.remove("PAR_WRITEAPI_URL")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from functools import reduce

#dbutils.widgets.remove("PAR_DB_FILE_PATH")

#adding extra column row_length to filter bad records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'plan_id',
'plan_id_after',
'plan_area_cd',
'plan_area_cd_after',
'plan_phone_nbr',
'plan_phone_nbr_after',
'plan_type_cd',
'plan_type_cd_after',
'plan_name',
'plan_name_after',
'plan_active_ind',
'plan_active_ind_after',
'plan_effective_dttm',
'plan_effective_dttm_after',
'phrm_store_nbr_cd',
'phrm_store_nbr_cd_after',
'pbr_cd',
'pbr_cd_after',
'secondary_pbr_cd',
'secondary_pbr_cd_after',
'plan_cmpd_drug_cd',
'plan_cmpd_drug_cd_after',
'plan_usual_cust_adj_amt',
'plan_usual_cust_adj_amt_after',
'tax_exempt_plan_ind',
'tax_exempt_plan_ind_after',
'plan_usual_cust_ind',
'plan_usual_cust_ind_after',
'plan_usual_cust_cpy_ind',
'plan_usual_cust_cpy_ind_after',
'direct_link_cd',
'direct_link_cd_after',
'bin_nbr',
'bin_nbr_after',
'ncpdp_version',
'ncpdp_version_after',
'processor_ctr_nbr',
'processor_ctr_nbr_after',
'overrid_billing_basis_cd',
'overrid_billing_basis_cd_after',
'overrid_billing_adj_amt',
'overrid_billing_adj_amt_after',
'overrid_billing_adj_typ',
'overrid_billing_adj_typ_after',
'primary_billing_basis_cd',
'primary_billing_basis_cd_after',
'primary_billing_adj_amt',
'primary_billing_adj_amt_after',
'primary_billing_adj_typ',
'primary_billing_adj_typ_after',
'plan_bill_method_cd',
'plan_bill_method_cd_after',
'bill_form_type_cd',
'bill_form_type_cd_after',
'state_plan_cd',
'state_plan_cd_after',
'generic_disp_fee',
'generic_disp_fee_after',
'generic_disp_fee_cd',
'generic_disp_fee_cd_after',
'generic_copay',
'generic_copay_after',
'generic_copay_cd',
'generic_copay_cd_after',
'brand_disp_fee',
'brand_disp_fee_after',
'brand_disp_fee_cd',
'brand_disp_fee_cd_after',
'brand_copay',
'brand_copay_after',
'brand_copay_cd',
'brand_copay_cd_after',
'otc_disp_fee',
'otc_disp_fee_after',
'otc_disp_fee_cd',
'otc_disp_fee_cd_after',
'otc_copay',
'otc_copay_after',
'otc_copay_cd',
'otc_copay_cd_after',
'custom_pay_cd_ind',
'custom_pay_cd_ind_after',
'link_type_cd',
'link_type_cd_after',
'plan_usual_cust_adj_typ',
'plan_usual_cust_adj_typ_after',
'signature_required_ind',
'signature_required_ind_after',
'create_user_id',
'create_user_id_after',
'create_dttm',
'create_dttm_after',
'update_user_id',
'update_user_id_after',
'update_dttm',
'update_dttm_after',
'child_plan_qty',
'child_plan_qty_after',
'parent_plan_id',
'parent_plan_id_after',
'plan_cfc_exclsns_ind',
'plan_cfc_exclsns_ind_after',
'sign_cd',
'sign_cd_after',
'promise_plan_cfc_cd',
'promise_plan_cfc_cd_after',
'mail_plan_uc_cd',
'mail_plan_uc_cd_after',
'mail_plan_uc_default_amt',
'mail_plan_uc_default_amt_after',
'corp_plan_area_cd',
'corp_plan_area_cd_after',
'corp_plan_phone',
'corp_plan_phone_after',
'plan_prior_auth_area_cd',
'plan_prior_auth_area_cd_after',
'plan_prior_auth_phone',
'plan_prior_auth_phone_after',
'partial_fill_version_cd',
'partial_fill_version_cd_after',
'thrd_pty_cert_id',
'thrd_pty_cert_id_after',
'assignd_nbr_ind',
'assignd_nbr_ind_after',
'dur_level_1',
'dur_level_1_after',
'dur_level_2',
'dur_level_2_after',
'dur_level_3',
'dur_level_3_after',
'dur_level_4',
'dur_level_4_after',
'dur_level_5',
'dur_level_5_after',
'coord_of_benefits_ind',
'coord_of_benefits_ind_after',
'sr_div_elig_ind',
'sr_div_elig_ind_after',
'manual_claim_ind',
'manual_claim_ind_after',
'pbr_assignd_nbr_ind',
'pbr_assignd_nbr_ind_after',
'pharmacist_cd',
'pharmacist_cd_after',
'person_cd_ind',
'person_cd_ind_after',
'actual_processor_ctr_nbr',
'actual_processor_ctr_nbr_after',
'cob_seg_ind',
'cob_seg_ind_after',
'sec_bill_method_cd',
'sec_bill_method_cd_after',
'sec_sent_cob_seg_ind',
'sec_sent_cob_seg_ind_after',
'sec_oac_ind',
'sec_oac_ind_after',
'sec_hybrid_threshold_amt',
'sec_hybrid_threshold_amt_after',
'sec_bill_for_zero_copay',
'sec_bill_for_zero_copay_after',
'sec_zero_opap_occ',
'sec_zero_opap_occ_after',
'sec_fullbill_cob_seg_ind',
'sec_fullbill_cob_seg_ind_after',
'sec_full_bill_occ',
'sec_full_bill_occ_after',
'sec_opap_qualifier',
'sec_opap_qualifier_after',
'sec_op_coverage_type',
'sec_op_coverage_type_after',
'discount_plan_cd',
'discount_plan_cd_after',
'plan_tip_exclusion_ind',
'plan_tip_exclusion_ind_after',
'document_id',
'document_id_after',
'epa_ind',
'epa_ind_after',
'sec_pbr_assignd_nbr_ind',
'sec_pbr_assignd_nbr_ind_after',
'sdl_cob_cd',
'sdl_cob_cd_after',
'allow_non_rx_otc_ind',
'allow_non_rx_otc_ind_after',
'non_rx_otc_pbr_id',
'non_rx_otc_pbr_id_after',
'non_rx_otc_days_supply',
'non_rx_otc_days_supply_after',
'd0_websdl_cob_ind',
'd0_websdl_cob_ind_after',
'elig_plan_description',
'elig_plan_description_after',
'elig_plan_recip_id_lbl',
'elig_plan_recip_id_lbl_after',
'pct_of_util_pln_adj',
'pct_of_util_pln_adj_after',
'sec_bill_lower_cpf_copay',
'sec_bill_lower_cpf_copay_after',
'sec_opap_adm_qlfr',
'sec_opap_adm_qlfr_after',
'sec_opap_cogn_qlfr',
'sec_opap_cogn_qlfr_after',
'd0_sec_zero_opap_occ',
'd0_sec_zero_opap_occ_after',
'sec_opap_dlvry_qlfr',
'sec_opap_dlvry_qlfr_after',
'sec_opap_drug_bnft_qlfr',
'sec_opap_drug_bnft_qlfr_after',
'sec_opap_incntv_qlfr',
'sec_opap_incntv_qlfr_after',
'sec_opap_post_qlfr',
'sec_opap_post_qlfr_after',
'sec_opap_ship_qlfr',
'sec_opap_ship_qlfr_after',
'sec_pat_lump_sum',
'sec_pat_lump_sum_after',
'sec_pat_pay_brkdwn',
'sec_pat_pay_brkdwn_after',
'sec_prim_gt_zero_occ',
'sec_prim_gt_zero_occ_after',
'sec_prim_lt_zero_occ',
'sec_prim_lt_zero_occ_after',
'sec_prim_rej_occ',
'sec_prim_rej_occ_after',
'd0_sec_bill_zero_copay',
'd0_sec_bill_zero_copay_after']

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == 'INSERT':
    lst1.insert(6, 'INSERT')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif 'INSERT' in key_list[6]:
    if val_len != 239:
      print(val_len)
      return True
  elif 'SQL COMPUPDATE' in key_list[6] or 'PK UPDATE' in key_list[6]:
    if val_len != 240:
      return True
  else:
    if val_len != 240:
      return True



# COMMAND ----------


in_text = spark.read.text(readList)

in_text = in_text.rdd


# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)
  #df_junk.show(truncate=False)


# COMMAND ----------

#split and add schema
col_len = 240

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 240
print(f"Bad records count {rd_bad.count()}") # != 240

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

df = spark.createDataFrame(rd_good, schema)

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, col(col_name)),
    df.columns,
    df
))

# COMMAND ----------

#display(df)
print(f"Total source count {df.count()}")

# COMMAND ----------

df.createOrReplaceTempView("gg_tbf0_third_party_plan")

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")
      

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_third_party_plan where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")

display(dfBad)

print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

# print(f"Total source count {df.count()}")
# sql_comp_count = df.filter(df.cdc_operation_type_cd_before == 'SQL COMPUPDATE').count()
# print(f"Total sql computdate count {sql_comp_count}")
# pk_update_count = df.filter(df.cdc_operation_type_cd_before == 'PK UPDATE').count()
# print(f"Total pk update count {pk_update_count}")
# insert_count = df.filter(df.cdc_operation_type_cd_before == 'INSERT').count()
# print(f"Total insert count {insert_count}")
# null_count = df.filter(df.cdc_operation_type_cd_before == "").count()
# print(f"Total null count {null_count}")
# other_count = df.filter((col('cdc_operation_type_cd_before') != 'SQL COMPUPDATE') & (col('cdc_operation_type_cd_before') != 'PK UPDATE') \
#                            & (col('cdc_operation_type_cd_before') != 'INSERT')).count()
# print(f"Total other value count {other_count}")

# total = sql_comp_count + pk_update_count + insert_count + null_count + (other_count-null_count)

# print(f"Total key values count {total}")

# COMMAND ----------

df_gg = df.withColumn("table_name",lit(SRC_TBL_NAME))

display(df_gg)

df_gg.createOrReplaceTempView("raw_src_gg_table")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"

#pRxCutoffTableCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR table_name == 'gg_tbf0_rx_consult_hist' OR  table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_lis')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"

#pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR table_name  == 'gg_tbf0_rx_consult_actv' OR  table_name  == 'gg_tbf0_dur_history' OR table_name  == 'gg_tbf0_rx_consult_adhoc'   OR  table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_lis')"

#pSrcCleanseXfr

pUpdateReform=" ( (plan_id == plan_id_after AND plan_id is NOT NULL AND plan_id_after IS NOT NULL) AND (cdc_seq_nbr== cdc_seq_nbr_after AND cdc_seq_nbr IS NOT NULL AND cdc_seq_nbr_after IS NOT NULL) AND    (cdc_rba_nbr == cdc_rba_nbr_after AND cdc_rba_nbr IS NOT NULL AND cdc_rba_nbr_after IS NOT NULL)  AND    (cdc_txn_commit_dttm== cdc_txn_commit_dttm_after AND cdc_txn_commit_dttm IS NOT NULL AND cdc_txn_commit_dttm_after IS NOT NULL) AND  (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL) AND   (cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND cdc_operation_type_cd_after IS NOT NULL) AND  (cdc_before_after_cd== 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND   (cdc_operation_type_cd == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL) AND   (( plan_area_cd== plan_area_cd_after AND plan_area_cd IS NOT NULL AND plan_area_cd_after IS NOT NULL) OR ( plan_area_cd IS NULL AND    plan_area_cd_after IS NULL)) AND  (( plan_phone_nbr == plan_phone_nbr_after AND plan_phone_nbr IS NOT NULL AND plan_phone_nbr_after IS NOT NULL) OR ( plan_phone_nbr IS NULL AND plan_phone_nbr_after IS NULL)) AND  (( plan_type_cd == plan_type_cd_after AND plan_type_cd IS NOT NULL AND plan_type_cd_after IS NOT NULL) OR ( plan_type_cd IS NULL AND plan_type_cd_after IS NULL)) AND  ( (plan_name== plan_name_after AND plan_name IS NOT NULL AND plan_name_after IS NOT NULL) OR ( plan_name IS NULL AND    plan_name_after IS NULL)) AND  (( plan_active_ind== plan_active_ind_after AND plan_active_ind IS NOT NULL AND plan_active_ind_after IS NOT NULL) OR ( plan_active_ind IS NULL AND    plan_active_ind_after IS NULL)) AND  ( (plan_effective_dttm== plan_effective_dttm_after AND plan_effective_dttm IS NOT NULL AND plan_effective_dttm_after IS NOT NULL) OR ( plan_effective_dttm IS NULL AND    plan_effective_dttm_after IS NULL)) AND ( ( phrm_store_nbr_cd== phrm_store_nbr_cd_after AND phrm_store_nbr_cd IS NOT NULL AND phrm_store_nbr_cd_after IS NOT NULL) OR ( phrm_store_nbr_cd IS NULL AND    phrm_store_nbr_cd_after IS NULL)) AND  (( pbr_cd== pbr_cd_after AND pbr_cd IS NOT NULL AND pbr_cd_after IS NOT NULL) OR ( pbr_cd IS NULL AND    pbr_cd_after IS NULL)) AND  (( secondary_pbr_cd== secondary_pbr_cd_after AND secondary_pbr_cd IS NOT NULL AND secondary_pbr_cd_after IS NOT NULL) OR ( secondary_pbr_cd IS NULL AND    secondary_pbr_cd_after IS NULL)) AND  (( plan_cmpd_drug_cd== plan_cmpd_drug_cd_after AND plan_cmpd_drug_cd IS NOT NULL AND plan_cmpd_drug_cd_after IS NOT NULL ) OR ( plan_cmpd_drug_cd IS NULL AND    plan_cmpd_drug_cd_after IS NULL)) AND  (( plan_usual_cust_adj_amt== plan_usual_cust_adj_amt_after AND plan_usual_cust_adj_amt IS NOT NULL AND plan_usual_cust_adj_amt_after IS NOT NULL) OR ( plan_usual_cust_adj_amt IS NULL AND    plan_usual_cust_adj_amt_after IS NULL)) AND  (( tax_exempt_plan_ind== tax_exempt_plan_ind_after  AND tax_exempt_plan_ind IS NOT NULL AND tax_exempt_plan_ind_after IS NOT NULL ) OR ( tax_exempt_plan_ind IS NULL AND    tax_exempt_plan_ind_after IS NULL)) AND  (( plan_usual_cust_ind== plan_usual_cust_ind_after AND plan_usual_cust_ind IS NOT NULL AND plan_usual_cust_ind_after IS NOT NULL ) OR ( plan_usual_cust_ind IS NULL AND    plan_usual_cust_ind_after IS NULL)) AND  (( plan_usual_cust_cpy_ind== plan_usual_cust_cpy_ind_after AND plan_usual_cust_cpy_ind IS NOT NULL AND plan_usual_cust_cpy_ind_after IS NOT NULL) OR ( plan_usual_cust_cpy_ind IS NULL AND    plan_usual_cust_cpy_ind_after IS NULL)) AND  (( direct_link_cd== direct_link_cd_after AND direct_link_cd is not null and direct_link_cd_after IS NOT NULL) OR ( direct_link_cd IS NULL AND    direct_link_cd_after IS NULL)) AND  (( bin_nbr== bin_nbr_after AND bin_nbr IS NOT NULL AND bin_nbr_after IS NOT NULL) OR ( bin_nbr IS NULL AND    bin_nbr_after IS NULL)) AND  ( (ncpdp_version== ncpdp_version_after AND ncpdp_version IS NOT NULL AND ncpdp_version_after IS NOT NULL) OR ( ncpdp_version IS NULL AND    ncpdp_version_after IS NULL)) AND  (( processor_ctr_nbr== processor_ctr_nbr_after AND processor_ctr_nbr IS NOT NULL AND processor_ctr_nbr_after IS NOT NULL ) OR ( processor_ctr_nbr IS NULL AND    processor_ctr_nbr_after IS NULL)) AND  (( overrid_billing_basis_cd== overrid_billing_basis_cd_after AND overrid_billing_basis_cd IS NOT NULL AND overrid_billing_basis_cd_after IS NOT NULL) OR ( overrid_billing_basis_cd IS NULL AND    overrid_billing_basis_cd_after IS NULL)) AND  ( (overrid_billing_adj_amt== overrid_billing_adj_amt_after AND overrid_billing_adj_amt IS NOT NULL AND overrid_billing_adj_amt_after IS NOT NULL) OR ( overrid_billing_adj_amt IS NULL AND    overrid_billing_adj_amt_after IS NULL)) AND  ( (overrid_billing_adj_typ== overrid_billing_adj_typ_after AND overrid_billing_adj_typ IS NOT NULL AND overrid_billing_adj_typ_after IS NOT NULL ) OR ( overrid_billing_adj_typ IS NULL AND    overrid_billing_adj_typ_after IS NULL)) AND  ( (primary_billing_basis_cd== primary_billing_basis_cd_after AND primary_billing_basis_cd IS NOT NULL AND primary_billing_basis_cd_after IS NOT NULL) OR ( primary_billing_basis_cd IS NULL AND    primary_billing_basis_cd_after IS NULL)) AND  (( primary_billing_adj_amt== primary_billing_adj_amt_after AND primary_billing_adj_amt IS NOT NULL AND primary_billing_adj_amt IS NOT NULL )OR ( primary_billing_adj_amt IS NULL AND    primary_billing_adj_amt_after IS NULL)) AND  (( primary_billing_adj_typ== primary_billing_adj_typ_after AND primary_billing_adj_typ IS NOT NULL AND primary_billing_adj_typ_after IS NOT NULL )OR ( primary_billing_adj_typ IS NULL AND    primary_billing_adj_typ_after IS NULL)) AND  (( plan_bill_method_cd== plan_bill_method_cd_after AND plan_bill_method_cd IS NOT NULL AND plan_bill_method_cd_after IS NOT NULL) OR ( plan_bill_method_cd IS NULL AND    plan_bill_method_cd_after IS NULL)) AND  (( bill_form_type_cd== bill_form_type_cd_after AND bill_form_type_cd IS NOT NULL AND bill_form_type_cd_after IS NOT NULL ) OR ( bill_form_type_cd IS NULL AND    bill_form_type_cd_after IS NULL)) AND  (( state_plan_cd== state_plan_cd_after AND state_plan_cd IS NOT NULL AND state_plan_cd_after IS NOT NULL )OR ( state_plan_cd IS NULL AND    state_plan_cd_after IS NULL)) AND  ( (generic_disp_fee== generic_disp_fee_after AND generic_disp_fee IS NOT NULL AND generic_disp_fee_after IS NOT NULL) OR ( generic_disp_fee IS NULL AND    generic_disp_fee_after IS NULL)) AND  ( (generic_disp_fee_cd== generic_disp_fee_cd_after AND generic_disp_fee_cd IS NOT NULL AND generic_disp_fee_cd_after IS NOT NULL )OR ( generic_disp_fee_cd IS NULL AND    generic_disp_fee_cd_after IS NULL)) AND  (( generic_copay== generic_copay_after AND generic_copay IS NOT NULL AND generic_copay_after IS NOT NULL) OR ( generic_copay IS NULL AND    generic_copay_after IS NULL)) AND  ( (generic_copay_cd== generic_copay_cd_after AND generic_copay_cd IS NOT NULL AND generic_copay_cd_after IS NOT NULL) OR ( generic_copay_cd IS NULL AND    generic_copay_cd_after IS NULL)) AND  (( brand_disp_fee== brand_disp_fee_after AND brand_disp_fee IS NOT NULL AND brand_disp_fee_after IS NOT NULL) OR ( brand_disp_fee IS NULL AND    brand_disp_fee_after IS NULL)) AND  (( brand_disp_fee_cd== brand_disp_fee_cd_after AND brand_disp_fee_cd IS NOT NULL AND brand_disp_fee_cd_after IS NOT NULL) OR ( brand_disp_fee_cd IS NULL AND    brand_disp_fee_cd_after IS NULL)) AND  (( brand_copay== brand_copay_after AND brand_copay IS NOT NULL AND brand_copay_after IS NOT NULL) OR ( brand_copay IS NULL AND    brand_copay_after IS NULL)) AND  ( (brand_copay_cd== brand_copay_cd_after AND brand_copay_cd IS NOT NULL AND brand_copay_cd_after IS NOT NULL ) OR ( brand_copay_cd IS NULL AND    brand_copay_cd_after IS NULL)) AND  (( otc_disp_fee== otc_disp_fee_after AND otc_disp_fee IS NOT NULL AND otc_disp_fee_after IS NOT NULL ) OR ( otc_disp_fee IS NULL AND    otc_disp_fee_after IS NULL)) AND  (( otc_disp_fee_cd== otc_disp_fee_cd_after AND otc_disp_fee_cd IS NOT NULL AND otc_disp_fee_cd_after IS NOT NULL) OR ( otc_disp_fee_cd IS NULL AND    otc_disp_fee_cd_after IS NULL)) AND  (( otc_copay== otc_copay_after AND otc_copay IS NOT NULL AND otc_copay_after IS NOT NULL )OR ( otc_copay IS NULL AND    otc_copay_after IS NULL)) AND  (( otc_copay_cd== otc_copay_cd_after AND otc_copay_cd IS NOT NULL AND otc_copay_cd_after IS NOT NULL) OR ( otc_copay_cd IS NULL AND    otc_copay_cd_after IS NULL)) AND  (( custom_pay_cd_ind== custom_pay_cd_ind_after AND custom_pay_cd_ind IS NOT NULL AND custom_pay_cd_ind_after IS NOT NULL) OR ( custom_pay_cd_ind IS NULL AND    custom_pay_cd_ind_after IS NULL)) AND  (( link_type_cd== link_type_cd_after AND link_type_cd IS NOT NULL AND link_type_cd_after IS NOT NULL) OR ( link_type_cd IS NULL AND    link_type_cd_after IS NULL)) AND  (( plan_usual_cust_adj_typ== plan_usual_cust_adj_typ_after AND plan_usual_cust_adj_typ IS NOT NULL AND plan_usual_cust_adj_typ_after IS NOT NULL) OR ( plan_usual_cust_adj_typ IS NULL AND    plan_usual_cust_adj_typ_after IS NULL)) AND  (( signature_required_ind== signature_required_ind_after AND signature_required_ind IS NOT NULL AND signature_required_ind_after IS NOT NULL) OR ( signature_required_ind IS NULL AND    signature_required_ind_after IS NULL)) AND  (( child_plan_qty== child_plan_qty_after AND child_plan_qty IS NOT NULL AND child_plan_qty_after IS NOT NULL ) OR ( child_plan_qty IS NULL AND    child_plan_qty_after IS NULL)) AND  (( parent_plan_id== parent_plan_id_after AND parent_plan_id IS NOT NULL AND parent_plan_id_after IS NOT NULL) OR ( parent_plan_id IS NULL AND    parent_plan_id_after IS NULL)) AND  (( plan_cfc_exclsns_ind== plan_cfc_exclsns_ind_after AND plan_cfc_exclsns_ind IS NOT NULL AND plan_cfc_exclsns_ind_after IS NOT NULL ) OR ( plan_cfc_exclsns_ind IS NULL AND    plan_cfc_exclsns_ind_after IS NULL)) AND  ( (sign_cd== sign_cd_after AND  sign_cd IS NOT NULL AND sign_cd_after IS NOT NULL ) OR ( sign_cd IS NULL AND    sign_cd_after IS NULL)) AND  ( (promise_plan_cfc_cd== promise_plan_cfc_cd_after AND promise_plan_cfc_cd IS NOT NULL AND promise_plan_cfc_cd_after IS NOT NULL) OR ( promise_plan_cfc_cd IS NULL AND    promise_plan_cfc_cd_after IS NULL)) AND  ( (mail_plan_uc_cd== mail_plan_uc_cd_after AND mail_plan_uc_cd IS NOT NULL AND mail_plan_uc_cd_after IS NOT NULL ) OR ( mail_plan_uc_cd IS NULL AND    mail_plan_uc_cd_after IS NULL)) AND  ( (mail_plan_uc_default_amt== mail_plan_uc_default_amt_after AND mail_plan_uc_default_amt IS NOT NULL AND mail_plan_uc_default_amt_after IS NOT NULL) OR ( mail_plan_uc_default_amt IS NULL AND    mail_plan_uc_default_amt_after IS NULL)) AND  (( corp_plan_area_cd== corp_plan_area_cd_after AND corp_plan_area_cd IS NOT NULL AND corp_plan_area_cd_after IS NOT NULL) OR ( corp_plan_area_cd IS NULL AND  corp_plan_area_cd_after IS NULL)) AND  ( (corp_plan_phone == corp_plan_phone_after AND corp_plan_phone IS NOT NULL AND corp_plan_phone_after IS NOT NULL) OR ( corp_plan_phone IS NULL AND    corp_plan_phone_after IS NULL)) AND  ( (plan_prior_auth_area_cd== plan_prior_auth_area_cd_after AND plan_prior_auth_area_cd IS NOT NULL AND plan_prior_auth_area_cd_after IS NOT NULL) OR ( plan_prior_auth_area_cd IS NULL AND    plan_prior_auth_area_cd_after IS NULL)) AND  (( plan_prior_auth_phone== plan_prior_auth_phone_after AND plan_prior_auth_phone IS NOT NULL AND plan_prior_auth_phone_after IS NOT NULL) OR ( plan_prior_auth_phone IS NULL AND    plan_prior_auth_phone_after IS NULL)) AND  ( ( partial_fill_version_cd== partial_fill_version_cd_after AND partial_fill_version_cd IS NOT NULL AND partial_fill_version_cd_after IS NOT NULL) OR ( partial_fill_version_cd IS NULL AND    partial_fill_version_cd_after IS NULL)) AND  ( (thrd_pty_cert_id== thrd_pty_cert_id_after AND thrd_pty_cert_id IS NOT NULL AND thrd_pty_cert_id_after IS NOT NULL) OR ( thrd_pty_cert_id IS NULL AND    thrd_pty_cert_id_after IS NULL)) AND  ( (assignd_nbr_ind== assignd_nbr_ind_after AND assignd_nbr_ind IS NOT NULL AND assignd_nbr_ind_after IS NOT NULL) OR ( assignd_nbr_ind IS NULL AND    assignd_nbr_ind_after IS NULL)) AND  ( (dur_level_1== dur_level_1_after AND dur_level_1 IS NOT NULL AND dur_level_1_after IS NOT NULL) OR ( dur_level_1 IS NULL AND    dur_level_1_after IS NULL)) AND  ( (dur_level_2== dur_level_2_after AND dur_level_2 IS NOT NULL AND dur_level_2_after IS NOT NULL) OR ( dur_level_2 IS NULL AND    dur_level_2_after IS NULL)) AND  ( (dur_level_3== dur_level_3_after AND dur_level_3 IS NOT NULL AND dur_level_3_after IS NOT NULL) OR ( dur_level_3 IS NULL AND    dur_level_3_after IS NULL)) AND  (( dur_level_4== dur_level_4_after AND dur_level_4 IS NOT NULL AND dur_level_4_after IS NOT NULL) OR ( dur_level_4 IS NULL AND    dur_level_4_after IS NULL)) AND  (( dur_level_5== dur_level_5_after AND dur_level_5 IS NOT NULL AND dur_level_5_after IS NOT NULL) OR ( dur_level_5 IS NULL AND    dur_level_5_after IS NULL)) AND  (( coord_of_benefits_ind== coord_of_benefits_ind_after AND coord_of_benefits_ind IS NOT NULL AND coord_of_benefits_ind_after IS NOT NULL) OR ( coord_of_benefits_ind IS NULL AND    coord_of_benefits_ind_after IS NULL)) AND  (( sr_div_elig_ind== sr_div_elig_ind_after AND sr_div_elig_ind IS NOT NULL AND sr_div_elig_ind_after IS NOT NULL) OR ( sr_div_elig_ind IS NULL AND    sr_div_elig_ind_after IS NULL)) AND  (( manual_claim_ind== manual_claim_ind_after AND manual_claim_ind IS NOT NULL AND manual_claim_ind_after IS NOT NULL) OR ( manual_claim_ind IS NULL AND    manual_claim_ind_after IS NULL)) AND  (( pbr_assignd_nbr_ind== pbr_assignd_nbr_ind_after  AND pbr_assignd_nbr_ind IS NOT NULL AND pbr_assignd_nbr_ind_after IS NOT NULL) OR ( pbr_assignd_nbr_ind IS NULL AND    pbr_assignd_nbr_ind_after IS NULL)) AND  (( pharmacist_cd== pharmacist_cd_after AND pharmacist_cd IS NOT NULL AND pharmacist_cd_after IS NOT NULL) OR ( pharmacist_cd IS NULL AND    pharmacist_cd_after IS NULL)) AND  (( person_cd_ind== person_cd_ind_after AND person_cd_ind IS NOT NULL AND person_cd_ind_after IS NOT NULL) OR ( person_cd_ind IS NULL AND    person_cd_ind_after IS NULL)) AND  (( actual_processor_ctr_nbr== actual_processor_ctr_nbr_after AND actual_processor_ctr_nbr IS NOT NULL AND actual_processor_ctr_nbr_after IS NOT NULL) OR ( actual_processor_ctr_nbr IS NULL AND    actual_processor_ctr_nbr_after IS NULL)) AND  (( cob_seg_ind== cob_seg_ind_after AND cob_seg_ind IS NOT NULL AND cob_seg_ind_after IS NOT NULL) OR ( cob_seg_ind IS NULL AND    cob_seg_ind_after IS NULL)) AND  (( sec_bill_method_cd== sec_bill_method_cd_after AND sec_bill_method_cd IS NOT NULL AND sec_bill_method_cd_after IS NOT NULL) OR ( sec_bill_method_cd IS NULL AND    sec_bill_method_cd_after IS NULL)) AND  (( sec_sent_cob_seg_ind== sec_sent_cob_seg_ind_after AND sec_sent_cob_seg_ind IS NOT NULL AND sec_sent_cob_seg_ind_after IS NOT NULL) OR ( sec_sent_cob_seg_ind IS NULL AND    sec_sent_cob_seg_ind_after IS NULL)) AND  (( sec_oac_ind== sec_oac_ind_after AND sec_oac_ind IS NOT NULL AND sec_oac_ind_after IS NOT NULL) OR ( sec_oac_ind IS NULL AND    sec_oac_ind_after IS NULL)) AND  (( sec_hybrid_threshold_amt== sec_hybrid_threshold_amt_after AND sec_hybrid_threshold_amt IS NOT NULL AND sec_hybrid_threshold_amt_after IS NOT NULL) OR ( sec_hybrid_threshold_amt IS NULL AND    sec_hybrid_threshold_amt_after IS NULL)) AND  (( sec_bill_for_zero_copay== sec_bill_for_zero_copay_after AND sec_bill_for_zero_copay IS NOT NULL AND sec_bill_for_zero_copay_after IS NOT NULL) OR ( sec_bill_for_zero_copay IS NULL AND    sec_bill_for_zero_copay_after IS NULL)) AND  ( (sec_zero_opap_occ== sec_zero_opap_occ_after AND sec_zero_opap_occ IS NOT NULL AND sec_zero_opap_occ_after IS NOT NULL) OR ( sec_zero_opap_occ IS NULL AND    sec_zero_opap_occ_after IS NULL)) AND  ( (sec_fullbill_cob_seg_ind== sec_fullbill_cob_seg_ind_after AND sec_fullbill_cob_seg_ind IS NOT NULL AND sec_fullbill_cob_seg_ind_after IS NOT NULL ) OR ( sec_fullbill_cob_seg_ind IS NULL AND    sec_fullbill_cob_seg_ind_after IS NULL)) AND  ( (sec_full_bill_occ== sec_full_bill_occ_after AND sec_full_bill_occ IS NOT NULL AND sec_full_bill_occ_after IS NOT NULL )OR ( sec_full_bill_occ IS NULL AND    sec_full_bill_occ_after IS NULL)) AND  (( sec_opap_qualifier== sec_opap_qualifier_after AND sec_opap_qualifier IS NOT NULL AND sec_opap_qualifier_after IS NOT NULL) OR ( sec_opap_qualifier IS NULL AND    sec_opap_qualifier_after IS NULL)) AND  (( sec_op_coverage_type== sec_op_coverage_type_after AND sec_op_coverage_type IS NOT NULL AND sec_op_coverage_type_after IS NOT NULL) OR ( sec_op_coverage_type IS NULL AND    sec_op_coverage_type_after IS NULL)) AND  (( discount_plan_cd== discount_plan_cd_after AND discount_plan_cd IS NOT NULL AND discount_plan_cd_after IS NOT NULL) OR ( discount_plan_cd IS NULL AND    discount_plan_cd_after IS NULL)) AND  ( (plan_tip_exclusion_ind== plan_tip_exclusion_ind_after AND plan_tip_exclusion_ind IS NOT NULL AND plan_tip_exclusion_ind_after IS NOT NULL) OR ( plan_tip_exclusion_ind IS NULL AND    plan_tip_exclusion_ind_after IS NULL)) AND  (( document_id== document_id_after AND document_id IS NOT NULL AND document_id_after IS NOT NULL) OR ( document_id IS NULL AND    document_id_after IS NULL)) AND  (( epa_ind== epa_ind_after AND epa_ind IS NOT NULL AND epa_ind_after IS NOT NULL ) OR ( epa_ind IS NULL AND    epa_ind_after IS NULL)) AND  (( sec_pbr_assignd_nbr_ind== sec_pbr_assignd_nbr_ind_after AND sec_pbr_assignd_nbr_ind IS NOT NULL AND sec_pbr_assignd_nbr_ind_after IS NOT NULL) OR ( sec_pbr_assignd_nbr_ind IS NULL AND    sec_pbr_assignd_nbr_ind_after IS NULL)) AND  ( (sdl_cob_cd== sdl_cob_cd_after AND sdl_cob_cd IS NOT NULL AND sdl_cob_cd_after IS NOT NULL )OR ( sdl_cob_cd IS NULL AND sdl_cob_cd_after IS NULL)) AND  (( allow_non_rx_otc_ind== allow_non_rx_otc_ind_after AND allow_non_rx_otc_ind IS NOT NULL AND allow_non_rx_otc_ind_after IS NOT NULL ) OR ( allow_non_rx_otc_ind IS NULL AND    allow_non_rx_otc_ind_after IS NULL)) AND  (( non_rx_otc_pbr_id== non_rx_otc_pbr_id_after AND non_rx_otc_pbr_id IS NOT NULL AND non_rx_otc_pbr_id_after IS NOT NULL) OR ( non_rx_otc_pbr_id IS NULL AND    non_rx_otc_pbr_id_after IS NULL)) AND  (( non_rx_otc_days_supply== non_rx_otc_days_supply_after AND non_rx_otc_days_supply IS NOT NULL AND non_rx_otc_days_supply_after IS NOT NULL) OR ( non_rx_otc_days_supply IS NULL AND    non_rx_otc_days_supply_after IS NULL)) AND  (( d0_sec_bill_zero_copay== d0_sec_bill_zero_copay_after AND d0_sec_bill_zero_copay IS NOT NULL AND d0_sec_bill_zero_copay_after IS NOT NULL) OR ( d0_sec_bill_zero_copay IS NULL AND    d0_sec_bill_zero_copay_after IS NULL)) AND  (( d0_sec_zero_opap_occ== d0_sec_zero_opap_occ_after AND d0_sec_zero_opap_occ IS NOT NULL AND d0_sec_zero_opap_occ_after IS NOT NULL) OR ( d0_sec_zero_opap_occ IS NULL AND    d0_sec_zero_opap_occ_after IS NULL)) AND  (( d0_websdl_cob_ind== d0_websdl_cob_ind_after AND d0_websdl_cob_ind IS NOT NULL AND d0_websdl_cob_ind_after IS NOT NULL) OR ( d0_websdl_cob_ind IS NULL AND    d0_websdl_cob_ind_after IS NULL)) AND  (( elig_plan_description== elig_plan_description_after AND elig_plan_description IS NOT NULL AND elig_plan_description_after IS NOT NULL) OR ( elig_plan_description IS NULL AND    elig_plan_description_after IS NULL)) AND  (( elig_plan_recip_id_lbl== elig_plan_recip_id_lbl_after AND elig_plan_recip_id_lbl IS NOT NULL AND elig_plan_recip_id_lbl_after IS NOT NULL) OR ( elig_plan_recip_id_lbl IS NULL AND    elig_plan_recip_id_lbl_after IS NULL)) AND  (( pct_of_util_pln_adj== pct_of_util_pln_adj_after AND pct_of_util_pln_adj IS NOT NULL AND pct_of_util_pln_adj IS NOT NULL) OR ( pct_of_util_pln_adj IS NULL AND    pct_of_util_pln_adj_after IS NULL)) AND  (( sec_bill_lower_cpf_copay== sec_bill_lower_cpf_copay_after AND sec_bill_lower_cpf_copay IS NOT NULL AND sec_bill_lower_cpf_copay_after IS NOT NULL) OR ( sec_bill_lower_cpf_copay IS NULL AND    sec_bill_lower_cpf_copay_after IS NULL)) AND  (( sec_opap_adm_qlfr== sec_opap_adm_qlfr_after AND sec_opap_adm_qlfr IS NOT NULL AND sec_opap_adm_qlfr_after IS NOT NULL) OR ( sec_opap_adm_qlfr IS NULL AND    sec_opap_adm_qlfr_after IS NULL)) AND  (( sec_opap_cogn_qlfr== sec_opap_cogn_qlfr_after AND sec_opap_cogn_qlfr IS NOT NULL AND sec_opap_cogn_qlfr_after IS NOT NULL) OR ( sec_opap_cogn_qlfr IS NULL AND    sec_opap_cogn_qlfr_after IS NULL)) AND  (( sec_opap_dlvry_qlfr== sec_opap_dlvry_qlfr_after AND sec_opap_dlvry_qlfr IS NOT NULL AND sec_opap_dlvry_qlfr_after IS NOT NULL) OR ( sec_opap_dlvry_qlfr IS NULL AND    sec_opap_dlvry_qlfr_after IS NULL)) AND  (( sec_opap_drug_bnft_qlfr== sec_opap_drug_bnft_qlfr_after AND sec_opap_drug_bnft_qlfr IS NOT NULL AND sec_opap_drug_bnft_qlfr_after IS NOT NULL) OR ( sec_opap_drug_bnft_qlfr IS NULL AND    sec_opap_drug_bnft_qlfr_after IS NULL)) AND  (( sec_opap_incntv_qlfr== sec_opap_incntv_qlfr_after AND sec_opap_incntv_qlfr IS NOT NULL AND sec_opap_incntv_qlfr_after IS NOT NULL) OR ( sec_opap_incntv_qlfr IS NULL AND    sec_opap_incntv_qlfr_after IS NULL)) AND  (( sec_opap_post_qlfr== sec_opap_post_qlfr_after AND sec_opap_post_qlfr IS NOT NULL AND sec_opap_post_qlfr_after IS NOT NULL ) OR ( sec_opap_post_qlfr IS NULL AND    sec_opap_post_qlfr_after IS NULL)) AND  (( sec_opap_ship_qlfr== sec_opap_ship_qlfr_after AND sec_opap_ship_qlfr IS NOT NULL AND sec_opap_ship_qlfr_after IS NOT NULL) OR ( sec_opap_ship_qlfr IS NULL AND    sec_opap_ship_qlfr_after IS NULL)) AND  (( sec_pat_lump_sum== sec_pat_lump_sum_after AND  sec_pat_lump_sum IS NOT NULL AND sec_pat_lump_sum_after IS NOT NULL) OR ( sec_pat_lump_sum IS NULL AND    sec_pat_lump_sum_after IS NULL)) AND  (( sec_pat_pay_brkdwn== sec_pat_pay_brkdwn_after AND sec_pat_pay_brkdwn IS NOT NULL AND sec_pat_pay_brkdwn_after IS NOT NULL) OR ( sec_pat_pay_brkdwn IS NULL AND    sec_pat_pay_brkdwn_after IS NULL)) AND  (( sec_prim_gt_zero_occ== sec_prim_gt_zero_occ_after AND sec_prim_gt_zero_occ IS NOT NULL AND sec_prim_gt_zero_occ_after IS NOT NULL) OR ( sec_prim_gt_zero_occ IS NULL AND    sec_prim_gt_zero_occ_after IS NULL)) AND  ( (sec_prim_lt_zero_occ== sec_prim_lt_zero_occ_after  AND sec_prim_lt_zero_occ IS NOT NULL AND sec_prim_lt_zero_occ_after IS NOT NULL) OR ( sec_prim_lt_zero_occ IS NULL AND    sec_prim_lt_zero_occ_after IS NULL)) AND  (( sec_prim_rej_occ== sec_prim_rej_occ_after AND sec_prim_rej_occ IS NOT NULL AND sec_prim_rej_occ_after IS NOT NULL) OR ( sec_prim_rej_occ IS NULL AND    sec_prim_rej_occ_after IS NULL)) )"

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

#pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr , cdc_rba_nbr , cdc_operation_type_cd , cdc_before_after_cd , cdc_txn_position_cd , edw_batch_id , plan_id , plan_area_cd , plan_phone_nbr , plan_type_cd , plan_name , plan_active_ind , CONCAT(plan_effective_dttm,'.000000') AS plan_effective_dttm, phrm_store_nbr_cd , pbr_cd , secondary_pbr_cd , plan_cmpd_drug_cd , plan_usual_cust_adj_amt , tax_exempt_plan_ind , plan_usual_cust_ind , plan_usual_cust_cpy_ind , direct_link_cd , bin_nbr , ncpdp_version , processor_ctr_nbr , overrid_billing_basis_cd , overrid_billing_adj_amt , overrid_billing_adj_typ , primary_billing_basis_cd , primary_billing_adj_amt , primary_billing_adj_typ , plan_bill_method_cd , bill_form_type_cd , state_plan_cd , generic_disp_fee , generic_disp_fee_cd , generic_copay , generic_copay_cd , brand_disp_fee , brand_disp_fee_cd , brand_copay , brand_copay_cd , otc_disp_fee , otc_disp_fee_cd , otc_copay , otc_copay_cd , custom_pay_cd_ind , link_type_cd , plan_usual_cust_adj_typ , signature_required_ind , create_user_id , CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id , CONCAT(update_dttm,'.000000') AS update_dttm, child_plan_qty , parent_plan_id , plan_cfc_exclsns_ind , sign_cd , promise_plan_cfc_cd , mail_plan_uc_cd , mail_plan_uc_default_amt , corp_plan_area_cd , corp_plan_phone , plan_prior_auth_area_cd , plan_prior_auth_phone , partial_fill_version_cd , thrd_pty_cert_id , assignd_nbr_ind , dur_level_1 , dur_level_2 , dur_level_3 , dur_level_4 , dur_level_5 , coord_of_benefits_ind , sr_div_elig_ind , manual_claim_ind , pbr_assignd_nbr_ind , pharmacist_cd , person_cd_ind , actual_processor_ctr_nbr , cob_seg_ind , sec_bill_method_cd , sec_sent_cob_seg_ind , sec_oac_ind , sec_hybrid_threshold_amt , sec_bill_for_zero_copay , sec_zero_opap_occ , sec_fullbill_cob_seg_ind , sec_full_bill_occ , sec_opap_qualifier , sec_op_coverage_type , discount_plan_cd , plan_tip_exclusion_ind , document_id , epa_ind , sec_pbr_assignd_nbr_ind , sdl_cob_cd , allow_non_rx_otc_ind , non_rx_otc_pbr_id , non_rx_otc_days_supply , d0_sec_bill_zero_copay , d0_sec_zero_opap_occ , d0_websdl_cob_ind , elig_plan_description , elig_plan_recip_id_lbl , pct_of_util_pln_adj , sec_bill_lower_cpf_copay , sec_opap_adm_qlfr , sec_opap_cogn_qlfr , sec_opap_dlvry_qlfr , sec_opap_drug_bnft_qlfr , sec_opap_incntv_qlfr , sec_opap_post_qlfr , sec_opap_ship_qlfr , sec_pat_lump_sum , sec_pat_pay_brkdwn , sec_prim_gt_zero_occ , sec_prim_lt_zero_occ , sec_prim_rej_occ "
#, tracking_id, partition_column"

# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()

#display(cutoff_records_output)

BATCH_ID_CHK = """'""" + BATCH_ID + """'"""
PROJ_ID_CHK = """'""" + PROJ_ID + """'"""

cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID_CHK) & (cutoff_records_output.PROJ_NAME == PROJ_ID_CHK))
#display(cutoff_records_filter)


#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_rx)
rx_max = cutoff_range_rx.select("rx_max")
#rx_max = rx_max.collect()[0][0]
#print(rx_max.collect()[0][0])


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))
#display(cutoff_range_trans)
rx_trans_max = cutoff_range_trans.select("rx_trans_max")
#rx_trans_max = rx_trans_max.collect()[0][0]
#print(rx_trans_max.collect()[0][0])

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_src_gg_table where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_src_gg_table where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_src_gg_table where " + pNopartitionTableCheck


#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
#display(nr_input_filter_rxpartition)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
#display(nr_input_filter_transpartition)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)

#nr_input_filter_rxpartition.printSchema()
#display(nr_input_filter_nopartition)

if nr_input_filter_rxpartition.count()==0 & nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  #display(nr_input_file_filter_rx)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual)
  nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck)
  nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual)
  nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])

  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  #display(nr_input_file_final)

  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

#display(dedup_group)

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

display(ded)

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
(case when (LENGTH(trim( plan_id )) ==0) then plan_id else trim(plan_id) end) as plan_id,
(case when (LENGTH(trim( plan_id_after )) ==0) then plan_id_after else trim(plan_id_after) end) as plan_id_after,
(case when (LENGTH(trim( plan_area_cd )) ==0) then plan_area_cd else trim(plan_area_cd) end) as plan_area_cd,
(case when (LENGTH(trim( plan_area_cd_after )) ==0) then plan_area_cd_after else trim(plan_area_cd_after) end) as plan_area_cd_after,
(case when (LENGTH(trim( plan_phone_nbr )) ==0) then plan_phone_nbr else trim(plan_phone_nbr) end) as plan_phone_nbr,
(case when (LENGTH(trim( plan_phone_nbr_after )) ==0) then plan_phone_nbr_after else trim(plan_phone_nbr_after) end) as plan_phone_nbr_after,
(case when (LENGTH(trim( plan_type_cd )) ==0) then plan_type_cd else trim(plan_type_cd) end) as plan_type_cd,
(case when (LENGTH(trim( plan_type_cd_after )) ==0) then plan_type_cd_after else trim(plan_type_cd_after) end) as plan_type_cd_after,
(case when (LENGTH(trim( plan_name )) ==0) then plan_name else trim(plan_name) end) as plan_name,
(case when (LENGTH(trim( plan_name_after )) ==0) then plan_name_after else trim(plan_name_after) end) as plan_name_after,
(case when (LENGTH(trim( plan_active_ind )) ==0) then plan_active_ind else trim(plan_active_ind) end) as plan_active_ind,
(case when (LENGTH(trim( plan_active_ind_after )) ==0) then plan_active_ind_after else trim(plan_active_ind_after) end) as plan_active_ind_after,
(case when (LENGTH(trim( plan_effective_dttm )) ==0) then  plan_effective_dttm else concat(substring(plan_effective_dttm,1,10),' ',substring(plan_effective_dttm,12,8))  end) as plan_effective_dttm,
(case when (LENGTH(trim( plan_effective_dttm_after )) ==0) then  plan_effective_dttm_after else concat(substring(plan_effective_dttm_after,1,10),' ',substring(plan_effective_dttm_after,12,8))  end) as plan_effective_dttm_after,
(case when (LENGTH(trim( phrm_store_nbr_cd )) ==0) then phrm_store_nbr_cd else trim(phrm_store_nbr_cd) end) as phrm_store_nbr_cd,
(case when (LENGTH(trim( phrm_store_nbr_cd_after )) ==0) then phrm_store_nbr_cd_after else trim(phrm_store_nbr_cd_after) end) as phrm_store_nbr_cd_after,
(case when (LENGTH(trim( pbr_cd )) ==0) then pbr_cd else trim(pbr_cd) end) as pbr_cd,
(case when (LENGTH(trim( pbr_cd_after )) ==0) then pbr_cd_after else trim(pbr_cd_after) end) as pbr_cd_after,
(case when (LENGTH(trim( secondary_pbr_cd )) ==0) then secondary_pbr_cd else trim(secondary_pbr_cd) end) as secondary_pbr_cd,
(case when (LENGTH(trim( secondary_pbr_cd_after )) ==0) then secondary_pbr_cd_after else trim(secondary_pbr_cd_after) end) as secondary_pbr_cd_after,
(case when (LENGTH(trim( plan_cmpd_drug_cd )) ==0) then plan_cmpd_drug_cd else trim(plan_cmpd_drug_cd) end) as plan_cmpd_drug_cd,
(case when (LENGTH(trim( plan_cmpd_drug_cd_after )) ==0) then plan_cmpd_drug_cd_after else trim(plan_cmpd_drug_cd_after) end) as plan_cmpd_drug_cd_after,
(case when (LENGTH(trim( plan_usual_cust_adj_amt )) ==0) then plan_usual_cust_adj_amt else trim(plan_usual_cust_adj_amt) end) as plan_usual_cust_adj_amt,
(case when (LENGTH(trim( plan_usual_cust_adj_amt_after )) ==0) then plan_usual_cust_adj_amt_after else trim(plan_usual_cust_adj_amt_after) end) as plan_usual_cust_adj_amt_after,
(case when (LENGTH(trim( tax_exempt_plan_ind )) ==0) then tax_exempt_plan_ind else trim(tax_exempt_plan_ind) end) as tax_exempt_plan_ind,
(case when (LENGTH(trim( tax_exempt_plan_ind_after )) ==0) then tax_exempt_plan_ind_after else trim(tax_exempt_plan_ind_after) end) as tax_exempt_plan_ind_after,
(case when (LENGTH(trim( plan_usual_cust_ind )) ==0) then plan_usual_cust_ind else trim(plan_usual_cust_ind) end) as plan_usual_cust_ind,
(case when (LENGTH(trim( plan_usual_cust_ind_after )) ==0) then plan_usual_cust_ind_after else trim(plan_usual_cust_ind_after) end) as plan_usual_cust_ind_after,
(case when (LENGTH(trim( plan_usual_cust_cpy_ind )) ==0) then plan_usual_cust_cpy_ind else trim(plan_usual_cust_cpy_ind) end) as plan_usual_cust_cpy_ind,
(case when (LENGTH(trim( plan_usual_cust_cpy_ind_after )) ==0) then plan_usual_cust_cpy_ind_after else trim(plan_usual_cust_cpy_ind_after) end) as plan_usual_cust_cpy_ind_after,
(case when (LENGTH(trim( direct_link_cd )) ==0) then direct_link_cd else trim(direct_link_cd) end) as direct_link_cd,
(case when (LENGTH(trim( direct_link_cd_after )) ==0) then direct_link_cd_after else trim(direct_link_cd_after) end) as direct_link_cd_after,
(case when (LENGTH(trim( bin_nbr )) ==0) then bin_nbr else trim(bin_nbr) end) as bin_nbr,
(case when (LENGTH(trim( bin_nbr_after )) ==0) then bin_nbr_after else trim(bin_nbr_after) end) as bin_nbr_after,
(case when (LENGTH(trim( ncpdp_version )) ==0) then ncpdp_version else trim(ncpdp_version) end) as ncpdp_version,
(case when (LENGTH(trim( ncpdp_version_after )) ==0) then ncpdp_version_after else trim(ncpdp_version_after) end) as ncpdp_version_after,
(case when (LENGTH(trim( processor_ctr_nbr )) ==0) then processor_ctr_nbr else trim(processor_ctr_nbr) end) as processor_ctr_nbr,
(case when (LENGTH(trim( processor_ctr_nbr_after )) ==0) then processor_ctr_nbr_after else trim(processor_ctr_nbr_after) end) as processor_ctr_nbr_after,
(case when (LENGTH(trim( overrid_billing_basis_cd )) ==0) then overrid_billing_basis_cd else trim(overrid_billing_basis_cd) end) as overrid_billing_basis_cd,
(case when (LENGTH(trim( overrid_billing_basis_cd_after )) ==0) then overrid_billing_basis_cd_after else trim(overrid_billing_basis_cd_after) end) as overrid_billing_basis_cd_after,
(case when (LENGTH(trim( overrid_billing_adj_amt )) ==0) then overrid_billing_adj_amt else trim(overrid_billing_adj_amt) end) as overrid_billing_adj_amt,
(case when (LENGTH(trim( overrid_billing_adj_amt_after )) ==0) then overrid_billing_adj_amt_after else trim(overrid_billing_adj_amt_after) end) as overrid_billing_adj_amt_after,
(case when (LENGTH(trim( overrid_billing_adj_typ )) ==0) then overrid_billing_adj_typ else trim(overrid_billing_adj_typ) end) as overrid_billing_adj_typ,
(case when (LENGTH(trim( overrid_billing_adj_typ_after )) ==0) then overrid_billing_adj_typ_after else trim(overrid_billing_adj_typ_after) end) as overrid_billing_adj_typ_after,
(case when (LENGTH(trim( primary_billing_basis_cd )) ==0) then primary_billing_basis_cd else trim(primary_billing_basis_cd) end) as primary_billing_basis_cd,
(case when (LENGTH(trim( primary_billing_basis_cd_after )) ==0) then primary_billing_basis_cd_after else trim(primary_billing_basis_cd_after) end) as primary_billing_basis_cd_after,
(case when (LENGTH(trim( primary_billing_adj_amt )) ==0) then primary_billing_adj_amt else trim(primary_billing_adj_amt) end) as primary_billing_adj_amt,
(case when (LENGTH(trim( primary_billing_adj_amt_after )) ==0) then primary_billing_adj_amt_after else trim(primary_billing_adj_amt_after) end) as primary_billing_adj_amt_after,
(case when (LENGTH(trim( primary_billing_adj_typ )) ==0) then primary_billing_adj_typ else trim(primary_billing_adj_typ) end) as primary_billing_adj_typ,
(case when (LENGTH(trim( primary_billing_adj_typ_after )) ==0) then primary_billing_adj_typ_after else trim(primary_billing_adj_typ_after) end) as primary_billing_adj_typ_after,
(case when (LENGTH(trim( plan_bill_method_cd )) ==0) then plan_bill_method_cd else trim(plan_bill_method_cd) end) as plan_bill_method_cd,
(case when (LENGTH(trim( plan_bill_method_cd_after )) ==0) then plan_bill_method_cd_after else trim(plan_bill_method_cd_after) end) as plan_bill_method_cd_after,
(case when (LENGTH(trim( bill_form_type_cd )) ==0) then bill_form_type_cd else trim(bill_form_type_cd) end) as bill_form_type_cd,
(case when (LENGTH(trim( bill_form_type_cd_after )) ==0) then bill_form_type_cd_after else trim(bill_form_type_cd_after) end) as bill_form_type_cd_after,
(case when (LENGTH(trim( state_plan_cd )) ==0) then state_plan_cd else trim(state_plan_cd) end) as state_plan_cd,
(case when (LENGTH(trim( state_plan_cd_after )) ==0) then state_plan_cd_after else trim(state_plan_cd_after) end) as state_plan_cd_after,
(case when (LENGTH(trim( generic_disp_fee )) ==0) then generic_disp_fee else trim(generic_disp_fee) end) as generic_disp_fee,
(case when (LENGTH(trim( generic_disp_fee_after )) ==0) then generic_disp_fee_after else trim(generic_disp_fee_after) end) as generic_disp_fee_after,
(case when (LENGTH(trim( generic_disp_fee_cd )) ==0) then generic_disp_fee_cd else trim(generic_disp_fee_cd) end) as generic_disp_fee_cd,
(case when (LENGTH(trim( generic_disp_fee_cd_after )) ==0) then generic_disp_fee_cd_after else trim(generic_disp_fee_cd_after) end) as generic_disp_fee_cd_after,
(case when (LENGTH(trim( generic_copay )) ==0) then generic_copay else trim(generic_copay) end) as generic_copay,
(case when (LENGTH(trim( generic_copay_after )) ==0) then generic_copay_after else trim(generic_copay_after) end) as generic_copay_after,
(case when (LENGTH(trim( generic_copay_cd )) ==0) then generic_copay_cd else trim(generic_copay_cd) end) as generic_copay_cd,
(case when (LENGTH(trim( generic_copay_cd_after )) ==0) then generic_copay_cd_after else trim(generic_copay_cd_after) end) as generic_copay_cd_after,
(case when (LENGTH(trim( brand_disp_fee )) ==0) then brand_disp_fee else trim(brand_disp_fee) end) as brand_disp_fee,
(case when (LENGTH(trim( brand_disp_fee_after )) ==0) then brand_disp_fee_after else trim(brand_disp_fee_after) end) as brand_disp_fee_after,
(case when (LENGTH(trim( brand_disp_fee_cd )) ==0) then brand_disp_fee_cd else trim(brand_disp_fee_cd) end) as brand_disp_fee_cd,
(case when (LENGTH(trim( brand_disp_fee_cd_after )) ==0) then brand_disp_fee_cd_after else trim(brand_disp_fee_cd_after) end) as brand_disp_fee_cd_after,
(case when (LENGTH(trim( brand_copay )) ==0) then brand_copay else trim(brand_copay) end) as brand_copay,
(case when (LENGTH(trim( brand_copay_after )) ==0) then brand_copay_after else trim(brand_copay_after) end) as brand_copay_after,
(case when (LENGTH(trim( brand_copay_cd )) ==0) then brand_copay_cd else trim(brand_copay_cd) end) as brand_copay_cd,
(case when (LENGTH(trim( brand_copay_cd_after )) ==0) then brand_copay_cd_after else trim(brand_copay_cd_after) end) as brand_copay_cd_after,
(case when (LENGTH(trim( otc_disp_fee )) ==0) then otc_disp_fee else trim(otc_disp_fee) end) as otc_disp_fee,
(case when (LENGTH(trim( otc_disp_fee_after )) ==0) then otc_disp_fee_after else trim(otc_disp_fee_after) end) as otc_disp_fee_after,
(case when (LENGTH(trim( otc_disp_fee_cd )) ==0) then otc_disp_fee_cd else trim(otc_disp_fee_cd) end) as otc_disp_fee_cd,
(case when (LENGTH(trim( otc_disp_fee_cd_after )) ==0) then otc_disp_fee_cd_after else trim(otc_disp_fee_cd_after) end) as otc_disp_fee_cd_after,
(case when (LENGTH(trim( otc_copay )) ==0) then otc_copay else trim(otc_copay) end) as otc_copay,
(case when (LENGTH(trim( otc_copay_after )) ==0) then otc_copay_after else trim(otc_copay_after) end) as otc_copay_after,
(case when (LENGTH(trim( otc_copay_cd )) ==0) then otc_copay_cd else trim(otc_copay_cd) end) as otc_copay_cd,
(case when (LENGTH(trim( otc_copay_cd_after )) ==0) then otc_copay_cd_after else trim(otc_copay_cd_after) end) as otc_copay_cd_after,
(case when (LENGTH(trim( custom_pay_cd_ind )) ==0) then custom_pay_cd_ind else trim(custom_pay_cd_ind) end) as custom_pay_cd_ind,
(case when (LENGTH(trim( custom_pay_cd_ind_after )) ==0) then custom_pay_cd_ind_after else trim(custom_pay_cd_ind_after) end) as custom_pay_cd_ind_after,
(case when (LENGTH(trim( link_type_cd )) ==0) then link_type_cd else trim(link_type_cd) end) as link_type_cd,
(case when (LENGTH(trim( link_type_cd_after )) ==0) then link_type_cd_after else trim(link_type_cd_after) end) as link_type_cd_after,
(case when (LENGTH(trim( plan_usual_cust_adj_typ )) ==0) then plan_usual_cust_adj_typ else trim(plan_usual_cust_adj_typ) end) as plan_usual_cust_adj_typ,
(case when (LENGTH(trim( plan_usual_cust_adj_typ_after )) ==0) then plan_usual_cust_adj_typ_after else trim(plan_usual_cust_adj_typ_after) end) as plan_usual_cust_adj_typ_after,
(case when (LENGTH(trim( signature_required_ind )) ==0) then signature_required_ind else trim(signature_required_ind) end) as signature_required_ind,
(case when (LENGTH(trim( signature_required_ind_after )) ==0) then signature_required_ind_after else trim(signature_required_ind_after) end) as signature_required_ind_after,
(case when (LENGTH(trim( create_user_id )) ==0) then create_user_id else trim(create_user_id) end) as create_user_id,
(case when (LENGTH(trim( create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after) end) as create_user_id_after,
(case when (LENGTH(trim( create_dttm )) ==0) then  create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8))  end) as create_dttm,
(case when (LENGTH(trim( create_dttm_after )) ==0) then  create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8))  end) as create_dttm_after,
(case when (LENGTH(trim( update_user_id )) ==0) then update_user_id else trim(update_user_id) end) as update_user_id,
(case when (LENGTH(trim( update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after) end) as update_user_id_after,
(case when (LENGTH(trim( update_dttm )) ==0) then  update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8))  end) as update_dttm,
(case when (LENGTH(trim( update_dttm_after )) ==0) then  update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8))  end) as update_dttm_after,
(case when (LENGTH(trim( child_plan_qty )) ==0) then child_plan_qty else trim(child_plan_qty) end) as child_plan_qty,
(case when (LENGTH(trim( child_plan_qty_after )) ==0) then child_plan_qty_after else trim(child_plan_qty_after) end) as child_plan_qty_after,
(case when (LENGTH(trim( parent_plan_id )) ==0) then parent_plan_id else trim(parent_plan_id) end) as parent_plan_id,
(case when (LENGTH(trim( parent_plan_id_after )) ==0) then parent_plan_id_after else trim(parent_plan_id_after) end) as parent_plan_id_after,
(case when (LENGTH(trim( plan_cfc_exclsns_ind )) ==0) then plan_cfc_exclsns_ind else trim(plan_cfc_exclsns_ind) end) as plan_cfc_exclsns_ind,
(case when (LENGTH(trim( plan_cfc_exclsns_ind_after )) ==0) then plan_cfc_exclsns_ind_after else trim(plan_cfc_exclsns_ind_after) end) as plan_cfc_exclsns_ind_after,
(case when (LENGTH(trim( sign_cd )) ==0) then sign_cd else trim(sign_cd) end) as sign_cd,
(case when (LENGTH(trim( sign_cd_after )) ==0) then sign_cd_after else trim(sign_cd_after) end) as sign_cd_after,
(case when (LENGTH(trim( promise_plan_cfc_cd )) ==0) then promise_plan_cfc_cd else trim(promise_plan_cfc_cd) end) as promise_plan_cfc_cd,
(case when (LENGTH(trim( promise_plan_cfc_cd_after )) ==0) then promise_plan_cfc_cd_after else trim(promise_plan_cfc_cd_after) end) as promise_plan_cfc_cd_after,
(case when (LENGTH(trim( mail_plan_uc_cd )) ==0) then mail_plan_uc_cd else trim(mail_plan_uc_cd) end) as mail_plan_uc_cd,
(case when (LENGTH(trim( mail_plan_uc_cd_after )) ==0) then mail_plan_uc_cd_after else trim(mail_plan_uc_cd_after) end) as mail_plan_uc_cd_after,
(case when (LENGTH(trim( mail_plan_uc_default_amt )) ==0) then mail_plan_uc_default_amt else trim(mail_plan_uc_default_amt) end) as mail_plan_uc_default_amt,
(case when (LENGTH(trim( mail_plan_uc_default_amt_after )) ==0) then mail_plan_uc_default_amt_after else trim(mail_plan_uc_default_amt_after) end) as mail_plan_uc_default_amt_after,
(case when (LENGTH(trim( corp_plan_area_cd )) ==0) then corp_plan_area_cd else trim(corp_plan_area_cd) end) as corp_plan_area_cd,
(case when (LENGTH(trim( corp_plan_area_cd_after )) ==0) then corp_plan_area_cd_after else trim(corp_plan_area_cd_after) end) as corp_plan_area_cd_after,
(case when (LENGTH(trim( corp_plan_phone )) ==0) then corp_plan_phone else trim(corp_plan_phone) end) as corp_plan_phone,
(case when (LENGTH(trim( corp_plan_phone_after )) ==0) then corp_plan_phone_after else trim(corp_plan_phone_after) end) as corp_plan_phone_after,
(case when (LENGTH(trim( plan_prior_auth_area_cd )) ==0) then plan_prior_auth_area_cd else trim(plan_prior_auth_area_cd) end) as plan_prior_auth_area_cd,
(case when (LENGTH(trim( plan_prior_auth_area_cd_after )) ==0) then plan_prior_auth_area_cd_after else trim(plan_prior_auth_area_cd_after) end) as plan_prior_auth_area_cd_after,
(case when (LENGTH(trim( plan_prior_auth_phone )) ==0) then plan_prior_auth_phone else trim(plan_prior_auth_phone) end) as plan_prior_auth_phone,
(case when (LENGTH(trim( plan_prior_auth_phone_after )) ==0) then plan_prior_auth_phone_after else trim(plan_prior_auth_phone_after) end) as plan_prior_auth_phone_after,
(case when (LENGTH(trim( partial_fill_version_cd )) ==0) then partial_fill_version_cd else trim(partial_fill_version_cd) end) as partial_fill_version_cd,
(case when (LENGTH(trim( partial_fill_version_cd_after )) ==0) then partial_fill_version_cd_after else trim(partial_fill_version_cd_after) end) as partial_fill_version_cd_after,
(case when (LENGTH(trim( thrd_pty_cert_id )) ==0) then thrd_pty_cert_id else trim(thrd_pty_cert_id) end) as thrd_pty_cert_id,
(case when (LENGTH(trim( thrd_pty_cert_id_after )) ==0) then thrd_pty_cert_id_after else trim(thrd_pty_cert_id_after) end) as thrd_pty_cert_id_after,
(case when (LENGTH(trim( assignd_nbr_ind )) ==0) then assignd_nbr_ind else trim(assignd_nbr_ind) end) as assignd_nbr_ind,
(case when (LENGTH(trim( assignd_nbr_ind_after )) ==0) then assignd_nbr_ind_after else trim(assignd_nbr_ind_after) end) as assignd_nbr_ind_after,
(case when (LENGTH(trim( dur_level_1 )) ==0) then dur_level_1 else trim(dur_level_1) end) as dur_level_1,
(case when (LENGTH(trim( dur_level_1_after )) ==0) then dur_level_1_after else trim(dur_level_1_after) end) as dur_level_1_after,
(case when (LENGTH(trim( dur_level_2 )) ==0) then dur_level_2 else trim(dur_level_2) end) as dur_level_2,
(case when (LENGTH(trim( dur_level_2_after )) ==0) then dur_level_2_after else trim(dur_level_2_after) end) as dur_level_2_after,
(case when (LENGTH(trim( dur_level_3 )) ==0) then dur_level_3 else trim(dur_level_3) end) as dur_level_3,
(case when (LENGTH(trim( dur_level_3_after )) ==0) then dur_level_3_after else trim(dur_level_3_after) end) as dur_level_3_after,
(case when (LENGTH(trim( dur_level_4 )) ==0) then dur_level_4 else trim(dur_level_4) end) as dur_level_4,
(case when (LENGTH(trim( dur_level_4_after )) ==0) then dur_level_4_after else trim(dur_level_4_after) end) as dur_level_4_after,
(case when (LENGTH(trim( dur_level_5 )) ==0) then dur_level_5 else trim(dur_level_5) end) as dur_level_5,
(case when (LENGTH(trim( dur_level_5_after )) ==0) then dur_level_5_after else trim(dur_level_5_after) end) as dur_level_5_after,
(case when (LENGTH(trim( coord_of_benefits_ind )) ==0) then coord_of_benefits_ind else trim(coord_of_benefits_ind) end) as coord_of_benefits_ind,
(case when (LENGTH(trim( coord_of_benefits_ind_after )) ==0) then coord_of_benefits_ind_after else trim(coord_of_benefits_ind_after) end) as coord_of_benefits_ind_after,
(case when (LENGTH(trim( sr_div_elig_ind )) ==0) then sr_div_elig_ind else trim(sr_div_elig_ind) end) as sr_div_elig_ind,
(case when (LENGTH(trim( sr_div_elig_ind_after )) ==0) then sr_div_elig_ind_after else trim(sr_div_elig_ind_after) end) as sr_div_elig_ind_after,
(case when (LENGTH(trim( manual_claim_ind )) ==0) then manual_claim_ind else trim(manual_claim_ind) end) as manual_claim_ind,
(case when (LENGTH(trim( manual_claim_ind_after )) ==0) then manual_claim_ind_after else trim(manual_claim_ind_after) end) as manual_claim_ind_after,
(case when (LENGTH(trim( pbr_assignd_nbr_ind )) ==0) then pbr_assignd_nbr_ind else trim(pbr_assignd_nbr_ind) end) as pbr_assignd_nbr_ind,
(case when (LENGTH(trim( pbr_assignd_nbr_ind_after )) ==0) then pbr_assignd_nbr_ind_after else trim(pbr_assignd_nbr_ind_after) end) as pbr_assignd_nbr_ind_after,
(case when (LENGTH(trim( pharmacist_cd )) ==0) then pharmacist_cd else trim(pharmacist_cd) end) as pharmacist_cd,
(case when (LENGTH(trim( pharmacist_cd_after )) ==0) then pharmacist_cd_after else trim(pharmacist_cd_after) end) as pharmacist_cd_after,
(case when (LENGTH(trim( person_cd_ind )) ==0) then person_cd_ind else trim(person_cd_ind) end) as person_cd_ind,
(case when (LENGTH(trim( person_cd_ind_after )) ==0) then person_cd_ind_after else trim(person_cd_ind_after) end) as person_cd_ind_after,
(case when (LENGTH(trim( actual_processor_ctr_nbr )) ==0) then actual_processor_ctr_nbr else trim(actual_processor_ctr_nbr) end) as actual_processor_ctr_nbr,
(case when (LENGTH(trim( actual_processor_ctr_nbr_after )) ==0) then actual_processor_ctr_nbr_after else trim(actual_processor_ctr_nbr_after) end) as actual_processor_ctr_nbr_after,
(case when (LENGTH(trim( cob_seg_ind )) ==0) then cob_seg_ind else trim(cob_seg_ind) end) as cob_seg_ind,
(case when (LENGTH(trim( cob_seg_ind_after )) ==0) then cob_seg_ind_after else trim(cob_seg_ind_after) end) as cob_seg_ind_after,
(case when (LENGTH(trim( sec_bill_method_cd )) ==0) then sec_bill_method_cd else trim(sec_bill_method_cd) end) as sec_bill_method_cd,
(case when (LENGTH(trim( sec_bill_method_cd_after )) ==0) then sec_bill_method_cd_after else trim(sec_bill_method_cd_after) end) as sec_bill_method_cd_after,
(case when (LENGTH(trim( sec_sent_cob_seg_ind )) ==0) then sec_sent_cob_seg_ind else trim(sec_sent_cob_seg_ind) end) as sec_sent_cob_seg_ind,
(case when (LENGTH(trim( sec_sent_cob_seg_ind_after )) ==0) then sec_sent_cob_seg_ind_after else trim(sec_sent_cob_seg_ind_after) end) as sec_sent_cob_seg_ind_after,
(case when (LENGTH(trim( sec_oac_ind )) ==0) then sec_oac_ind else trim(sec_oac_ind) end) as sec_oac_ind,
(case when (LENGTH(trim( sec_oac_ind_after )) ==0) then sec_oac_ind_after else trim(sec_oac_ind_after) end) as sec_oac_ind_after,
(case when (LENGTH(trim( sec_hybrid_threshold_amt )) ==0) then sec_hybrid_threshold_amt else trim(sec_hybrid_threshold_amt) end) as sec_hybrid_threshold_amt,
(case when (LENGTH(trim( sec_hybrid_threshold_amt_after )) ==0) then sec_hybrid_threshold_amt_after else trim(sec_hybrid_threshold_amt_after) end) as sec_hybrid_threshold_amt_after,
(case when (LENGTH(trim( sec_bill_for_zero_copay )) ==0) then sec_bill_for_zero_copay else trim(sec_bill_for_zero_copay) end) as sec_bill_for_zero_copay,
(case when (LENGTH(trim( sec_bill_for_zero_copay_after )) ==0) then sec_bill_for_zero_copay_after else trim(sec_bill_for_zero_copay_after) end) as sec_bill_for_zero_copay_after,
(case when (LENGTH(trim( sec_zero_opap_occ )) ==0) then sec_zero_opap_occ else trim(sec_zero_opap_occ) end) as sec_zero_opap_occ,
(case when (LENGTH(trim( sec_zero_opap_occ_after )) ==0) then sec_zero_opap_occ_after else trim(sec_zero_opap_occ_after) end) as sec_zero_opap_occ_after,
(case when (LENGTH(trim( sec_fullbill_cob_seg_ind )) ==0) then sec_fullbill_cob_seg_ind else trim(sec_fullbill_cob_seg_ind) end) as sec_fullbill_cob_seg_ind,
(case when (LENGTH(trim( sec_fullbill_cob_seg_ind_after )) ==0) then sec_fullbill_cob_seg_ind_after else trim(sec_fullbill_cob_seg_ind_after) end) as sec_fullbill_cob_seg_ind_after,
(case when (LENGTH(trim( sec_full_bill_occ )) ==0) then sec_full_bill_occ else trim(sec_full_bill_occ) end) as sec_full_bill_occ,
(case when (LENGTH(trim( sec_full_bill_occ_after )) ==0) then sec_full_bill_occ_after else trim(sec_full_bill_occ_after) end) as sec_full_bill_occ_after,
(case when (LENGTH(trim( sec_opap_qualifier )) ==0) then sec_opap_qualifier else trim(sec_opap_qualifier) end) as sec_opap_qualifier,
(case when (LENGTH(trim( sec_opap_qualifier_after )) ==0) then sec_opap_qualifier_after else trim(sec_opap_qualifier_after) end) as sec_opap_qualifier_after,
(case when (LENGTH(trim( sec_op_coverage_type )) ==0) then sec_op_coverage_type else trim(sec_op_coverage_type) end) as sec_op_coverage_type,
(case when (LENGTH(trim( sec_op_coverage_type_after )) ==0) then sec_op_coverage_type_after else trim(sec_op_coverage_type_after) end) as sec_op_coverage_type_after,
(case when (LENGTH(trim( discount_plan_cd )) ==0) then discount_plan_cd else trim(discount_plan_cd) end) as discount_plan_cd,
(case when (LENGTH(trim( discount_plan_cd_after )) ==0) then discount_plan_cd_after else trim(discount_plan_cd_after) end) as discount_plan_cd_after,
(case when (LENGTH(trim( plan_tip_exclusion_ind )) ==0) then plan_tip_exclusion_ind else trim(plan_tip_exclusion_ind) end) as plan_tip_exclusion_ind,
(case when (LENGTH(trim( plan_tip_exclusion_ind_after )) ==0) then plan_tip_exclusion_ind_after else trim(plan_tip_exclusion_ind_after) end) as plan_tip_exclusion_ind_after,
(case when (LENGTH(trim( document_id )) ==0) then document_id else trim(document_id) end) as document_id,
(case when (LENGTH(trim( document_id_after )) ==0) then document_id_after else trim(document_id_after) end) as document_id_after,
(case when (LENGTH(trim( epa_ind )) ==0) then epa_ind else trim(epa_ind) end) as epa_ind,
(case when (LENGTH(trim( epa_ind_after )) ==0) then epa_ind_after else trim(epa_ind_after) end) as epa_ind_after,
(case when (LENGTH(trim( sec_pbr_assignd_nbr_ind )) ==0) then sec_pbr_assignd_nbr_ind else trim(sec_pbr_assignd_nbr_ind) end) as sec_pbr_assignd_nbr_ind,
(case when (LENGTH(trim( sec_pbr_assignd_nbr_ind_after )) ==0) then sec_pbr_assignd_nbr_ind_after else trim(sec_pbr_assignd_nbr_ind_after) end) as sec_pbr_assignd_nbr_ind_after,
(case when (LENGTH(trim( sdl_cob_cd )) ==0) then sdl_cob_cd else trim(sdl_cob_cd) end) as sdl_cob_cd,
(case when (LENGTH(trim( sdl_cob_cd_after )) ==0) then sdl_cob_cd_after else trim(sdl_cob_cd_after) end) as sdl_cob_cd_after,
(case when (LENGTH(trim( allow_non_rx_otc_ind )) ==0) then allow_non_rx_otc_ind else trim(allow_non_rx_otc_ind) end) as allow_non_rx_otc_ind,
(case when (LENGTH(trim( allow_non_rx_otc_ind_after )) ==0) then allow_non_rx_otc_ind_after else trim(allow_non_rx_otc_ind_after) end) as allow_non_rx_otc_ind_after,
(case when (LENGTH(trim( non_rx_otc_pbr_id )) ==0) then non_rx_otc_pbr_id else trim(non_rx_otc_pbr_id) end) as non_rx_otc_pbr_id,
(case when (LENGTH(trim( non_rx_otc_pbr_id_after )) ==0) then non_rx_otc_pbr_id_after else trim(non_rx_otc_pbr_id_after) end) as non_rx_otc_pbr_id_after,
(case when (LENGTH(trim( non_rx_otc_days_supply )) ==0) then non_rx_otc_days_supply else trim(non_rx_otc_days_supply) end) as non_rx_otc_days_supply,
(case when (LENGTH(trim( non_rx_otc_days_supply_after )) ==0) then non_rx_otc_days_supply_after else trim(non_rx_otc_days_supply_after) end) as non_rx_otc_days_supply_after,
(case when (LENGTH(trim( d0_websdl_cob_ind )) ==0) then d0_websdl_cob_ind else trim(d0_websdl_cob_ind) end) as d0_websdl_cob_ind,
(case when (LENGTH(trim( d0_websdl_cob_ind_after )) ==0) then d0_websdl_cob_ind_after else trim(d0_websdl_cob_ind_after) end) as d0_websdl_cob_ind_after,
(case when (LENGTH(trim( elig_plan_description )) ==0) then elig_plan_description else trim(elig_plan_description) end) as elig_plan_description,
(case when (LENGTH(trim( elig_plan_description_after )) ==0) then elig_plan_description_after else trim(elig_plan_description_after) end) as elig_plan_description_after,
(case when (LENGTH(trim( elig_plan_recip_id_lbl )) ==0) then elig_plan_recip_id_lbl else trim(elig_plan_recip_id_lbl) end) as elig_plan_recip_id_lbl,
(case when (LENGTH(trim( elig_plan_recip_id_lbl_after )) ==0) then elig_plan_recip_id_lbl_after else trim(elig_plan_recip_id_lbl_after) end) as elig_plan_recip_id_lbl_after,
(case when (LENGTH(trim( pct_of_util_pln_adj )) ==0) then pct_of_util_pln_adj else trim(pct_of_util_pln_adj) end) as pct_of_util_pln_adj,
(case when (LENGTH(trim( pct_of_util_pln_adj_after )) ==0) then pct_of_util_pln_adj_after else trim(pct_of_util_pln_adj_after) end) as pct_of_util_pln_adj_after,
(case when (LENGTH(trim( sec_bill_lower_cpf_copay )) ==0) then sec_bill_lower_cpf_copay else trim(sec_bill_lower_cpf_copay) end) as sec_bill_lower_cpf_copay,
(case when (LENGTH(trim( sec_bill_lower_cpf_copay_after )) ==0) then sec_bill_lower_cpf_copay_after else trim(sec_bill_lower_cpf_copay_after) end) as sec_bill_lower_cpf_copay_after,
(case when (LENGTH(trim( sec_opap_adm_qlfr )) ==0) then sec_opap_adm_qlfr else trim(sec_opap_adm_qlfr) end) as sec_opap_adm_qlfr,
(case when (LENGTH(trim( sec_opap_adm_qlfr_after )) ==0) then sec_opap_adm_qlfr_after else trim(sec_opap_adm_qlfr_after) end) as sec_opap_adm_qlfr_after,
(case when (LENGTH(trim( sec_opap_cogn_qlfr )) ==0) then sec_opap_cogn_qlfr else trim(sec_opap_cogn_qlfr) end) as sec_opap_cogn_qlfr,
(case when (LENGTH(trim( sec_opap_cogn_qlfr_after )) ==0) then sec_opap_cogn_qlfr_after else trim(sec_opap_cogn_qlfr_after) end) as sec_opap_cogn_qlfr_after,
(case when (LENGTH(trim( d0_sec_zero_opap_occ )) ==0) then d0_sec_zero_opap_occ else trim(d0_sec_zero_opap_occ) end) as d0_sec_zero_opap_occ,
(case when (LENGTH(trim( d0_sec_zero_opap_occ_after )) ==0) then d0_sec_zero_opap_occ_after else trim(d0_sec_zero_opap_occ_after) end) as d0_sec_zero_opap_occ_after,
(case when (LENGTH(trim( sec_opap_dlvry_qlfr )) ==0) then sec_opap_dlvry_qlfr else trim(sec_opap_dlvry_qlfr) end) as sec_opap_dlvry_qlfr,
(case when (LENGTH(trim( sec_opap_dlvry_qlfr_after )) ==0) then sec_opap_dlvry_qlfr_after else trim(sec_opap_dlvry_qlfr_after) end) as sec_opap_dlvry_qlfr_after,
(case when (LENGTH(trim( sec_opap_drug_bnft_qlfr )) ==0) then sec_opap_drug_bnft_qlfr else trim(sec_opap_drug_bnft_qlfr) end) as sec_opap_drug_bnft_qlfr,
(case when (LENGTH(trim( sec_opap_drug_bnft_qlfr_after )) ==0) then sec_opap_drug_bnft_qlfr_after else trim(sec_opap_drug_bnft_qlfr_after) end) as sec_opap_drug_bnft_qlfr_after,
(case when (LENGTH(trim( sec_opap_incntv_qlfr )) ==0) then sec_opap_incntv_qlfr else trim(sec_opap_incntv_qlfr) end) as sec_opap_incntv_qlfr,
(case when (LENGTH(trim( sec_opap_incntv_qlfr_after )) ==0) then sec_opap_incntv_qlfr_after else trim(sec_opap_incntv_qlfr_after) end) as sec_opap_incntv_qlfr_after,
(case when (LENGTH(trim( sec_opap_post_qlfr )) ==0) then sec_opap_post_qlfr else trim(sec_opap_post_qlfr) end) as sec_opap_post_qlfr,
(case when (LENGTH(trim( sec_opap_post_qlfr_after )) ==0) then sec_opap_post_qlfr_after else trim(sec_opap_post_qlfr_after) end) as sec_opap_post_qlfr_after,
(case when (LENGTH(trim( sec_opap_ship_qlfr )) ==0) then sec_opap_ship_qlfr else trim(sec_opap_ship_qlfr) end) as sec_opap_ship_qlfr,
(case when (LENGTH(trim( sec_opap_ship_qlfr_after )) ==0) then sec_opap_ship_qlfr_after else trim(sec_opap_ship_qlfr_after) end) as sec_opap_ship_qlfr_after,
(case when (LENGTH(trim( sec_pat_lump_sum )) ==0) then sec_pat_lump_sum else trim(sec_pat_lump_sum) end) as sec_pat_lump_sum,
(case when (LENGTH(trim( sec_pat_lump_sum_after )) ==0) then sec_pat_lump_sum_after else trim(sec_pat_lump_sum_after) end) as sec_pat_lump_sum_after,
(case when (LENGTH(trim( sec_pat_pay_brkdwn )) ==0) then sec_pat_pay_brkdwn else trim(sec_pat_pay_brkdwn) end) as sec_pat_pay_brkdwn,
(case when (LENGTH(trim( sec_pat_pay_brkdwn_after )) ==0) then sec_pat_pay_brkdwn_after else trim(sec_pat_pay_brkdwn_after) end) as sec_pat_pay_brkdwn_after,
(case when (LENGTH(trim( sec_prim_gt_zero_occ )) ==0) then sec_prim_gt_zero_occ else trim(sec_prim_gt_zero_occ) end) as sec_prim_gt_zero_occ,
(case when (LENGTH(trim( sec_prim_gt_zero_occ_after )) ==0) then sec_prim_gt_zero_occ_after else trim(sec_prim_gt_zero_occ_after) end) as sec_prim_gt_zero_occ_after,
(case when (LENGTH(trim( sec_prim_lt_zero_occ )) ==0) then sec_prim_lt_zero_occ else trim(sec_prim_lt_zero_occ) end) as sec_prim_lt_zero_occ,
(case when (LENGTH(trim( sec_prim_lt_zero_occ_after )) ==0) then sec_prim_lt_zero_occ_after else trim(sec_prim_lt_zero_occ_after) end) as sec_prim_lt_zero_occ_after,
(case when (LENGTH(trim( sec_prim_rej_occ )) ==0) then sec_prim_rej_occ else trim(sec_prim_rej_occ) end) as sec_prim_rej_occ,
(case when (LENGTH(trim( sec_prim_rej_occ_after )) ==0) then sec_prim_rej_occ_after else trim(sec_prim_rej_occ_after) end) as sec_prim_rej_occ_after,
(case when (LENGTH(trim( d0_sec_bill_zero_copay )) ==0) then d0_sec_bill_zero_copay else trim(d0_sec_bill_zero_copay) end) as d0_sec_bill_zero_copay,
(case when (LENGTH(trim( d0_sec_bill_zero_copay_after )) ==0) then d0_sec_bill_zero_copay_after else trim(d0_sec_bill_zero_copay_after) end) as d0_sec_bill_zero_copay_after from dedup_group"""

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 

display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
plan_id_after AS plan_id , plan_area_cd_after AS plan_area_cd , plan_phone_nbr_after AS plan_phone_nbr , plan_type_cd_after AS plan_type_cd , plan_name_after AS plan_name , plan_active_ind_after AS plan_active_ind , plan_effective_dttm_after AS plan_effective_dttm , phrm_store_nbr_cd_after AS phrm_store_nbr_cd , pbr_cd_after AS pbr_cd , secondary_pbr_cd_after AS secondary_pbr_cd , plan_cmpd_drug_cd_after AS plan_cmpd_drug_cd , plan_usual_cust_adj_amt_after AS plan_usual_cust_adj_amt , tax_exempt_plan_ind_after AS tax_exempt_plan_ind , plan_usual_cust_ind_after AS plan_usual_cust_ind , plan_usual_cust_cpy_ind_after AS plan_usual_cust_cpy_ind , direct_link_cd_after AS direct_link_cd , bin_nbr_after AS bin_nbr , ncpdp_version_after AS ncpdp_version , processor_ctr_nbr_after AS processor_ctr_nbr , overrid_billing_basis_cd_after AS overrid_billing_basis_cd , overrid_billing_adj_amt_after AS overrid_billing_adj_amt , overrid_billing_adj_typ_after AS overrid_billing_adj_typ , primary_billing_basis_cd_after AS primary_billing_basis_cd , primary_billing_adj_amt_after AS primary_billing_adj_amt , primary_billing_adj_typ_after AS primary_billing_adj_typ , plan_bill_method_cd_after AS plan_bill_method_cd , bill_form_type_cd_after AS bill_form_type_cd , state_plan_cd_after AS state_plan_cd , generic_disp_fee_after AS generic_disp_fee , generic_disp_fee_cd_after AS generic_disp_fee_cd , generic_copay_after AS generic_copay , generic_copay_cd_after AS generic_copay_cd , brand_disp_fee_after AS brand_disp_fee , brand_disp_fee_cd_after AS brand_disp_fee_cd , brand_copay_after AS brand_copay , brand_copay_cd_after AS brand_copay_cd , otc_disp_fee_after AS otc_disp_fee , otc_disp_fee_cd_after AS otc_disp_fee_cd , otc_copay_after AS otc_copay , otc_copay_cd_after AS otc_copay_cd , custom_pay_cd_ind_after AS custom_pay_cd_ind , link_type_cd_after AS link_type_cd , plan_usual_cust_adj_typ_after AS plan_usual_cust_adj_typ , signature_required_ind_after AS signature_required_ind , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , child_plan_qty_after AS child_plan_qty , parent_plan_id_after AS parent_plan_id , plan_cfc_exclsns_ind_after AS plan_cfc_exclsns_ind , sign_cd_after AS sign_cd , promise_plan_cfc_cd_after AS promise_plan_cfc_cd , mail_plan_uc_cd_after AS mail_plan_uc_cd , mail_plan_uc_default_amt_after AS mail_plan_uc_default_amt , corp_plan_area_cd_after AS corp_plan_area_cd , corp_plan_phone_after AS corp_plan_phone , plan_prior_auth_area_cd_after AS plan_prior_auth_area_cd , plan_prior_auth_phone_after AS plan_prior_auth_phone , partial_fill_version_cd_after AS partial_fill_version_cd , thrd_pty_cert_id_after AS thrd_pty_cert_id , assignd_nbr_ind_after AS assignd_nbr_ind , dur_level_1_after AS dur_level_1 , dur_level_2_after AS dur_level_2 , dur_level_3_after AS dur_level_3 , dur_level_4_after AS dur_level_4 , dur_level_5_after AS dur_level_5 , coord_of_benefits_ind_after AS coord_of_benefits_ind , sr_div_elig_ind_after AS sr_div_elig_ind , manual_claim_ind_after AS manual_claim_ind , pbr_assignd_nbr_ind_after AS pbr_assignd_nbr_ind , pharmacist_cd_after AS pharmacist_cd , person_cd_ind_after AS person_cd_ind , actual_processor_ctr_nbr_after AS actual_processor_ctr_nbr , cob_seg_ind_after AS cob_seg_ind , sec_bill_method_cd_after AS sec_bill_method_cd , sec_sent_cob_seg_ind_after AS sec_sent_cob_seg_ind , sec_oac_ind_after AS sec_oac_ind , sec_hybrid_threshold_amt_after AS sec_hybrid_threshold_amt , sec_bill_for_zero_copay_after AS sec_bill_for_zero_copay , sec_zero_opap_occ_after AS sec_zero_opap_occ , sec_fullbill_cob_seg_ind_after AS sec_fullbill_cob_seg_ind , sec_full_bill_occ_after AS sec_full_bill_occ , sec_opap_qualifier_after AS sec_opap_qualifier , sec_op_coverage_type_after AS sec_op_coverage_type , discount_plan_cd_after AS discount_plan_cd , plan_tip_exclusion_ind_after AS plan_tip_exclusion_ind , document_id_after AS document_id , epa_ind_after AS epa_ind , sec_pbr_assignd_nbr_ind_after AS sec_pbr_assignd_nbr_ind , sdl_cob_cd_after AS sdl_cob_cd , allow_non_rx_otc_ind_after AS allow_non_rx_otc_ind , non_rx_otc_pbr_id_after AS non_rx_otc_pbr_id , non_rx_otc_days_supply_after AS non_rx_otc_days_supply , d0_websdl_cob_ind_after AS d0_websdl_cob_ind , elig_plan_description_after AS elig_plan_description , elig_plan_recip_id_lbl_after AS elig_plan_recip_id_lbl , pct_of_util_pln_adj_after AS pct_of_util_pln_adj , sec_bill_lower_cpf_copay_after AS sec_bill_lower_cpf_copay , sec_opap_adm_qlfr_after AS sec_opap_adm_qlfr , sec_opap_cogn_qlfr_after AS sec_opap_cogn_qlfr , d0_sec_zero_opap_occ_after AS d0_sec_zero_opap_occ , sec_opap_dlvry_qlfr_after AS sec_opap_dlvry_qlfr , sec_opap_drug_bnft_qlfr_after AS sec_opap_drug_bnft_qlfr , sec_opap_incntv_qlfr_after AS sec_opap_incntv_qlfr , sec_opap_post_qlfr_after AS sec_opap_post_qlfr , sec_opap_ship_qlfr_after AS sec_opap_ship_qlfr , sec_pat_lump_sum_after AS sec_pat_lump_sum , sec_pat_pay_brkdwn_after AS sec_pat_pay_brkdwn , sec_prim_gt_zero_occ_after AS sec_prim_gt_zero_occ , sec_prim_lt_zero_occ_after AS sec_prim_lt_zero_occ , sec_prim_rej_occ_after AS sec_prim_rej_occ , d0_sec_bill_zero_copay_after AS d0_sec_bill_zero_copay , 
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """

# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,
plan_id AS plan_id , plan_area_cd AS plan_area_cd , plan_phone_nbr AS plan_phone_nbr , plan_type_cd AS plan_type_cd , plan_name AS plan_name , plan_active_ind AS plan_active_ind , plan_effective_dttm AS plan_effective_dttm , phrm_store_nbr_cd AS phrm_store_nbr_cd , pbr_cd AS pbr_cd , secondary_pbr_cd AS secondary_pbr_cd , plan_cmpd_drug_cd AS plan_cmpd_drug_cd , plan_usual_cust_adj_amt AS plan_usual_cust_adj_amt , tax_exempt_plan_ind AS tax_exempt_plan_ind , plan_usual_cust_ind AS plan_usual_cust_ind , plan_usual_cust_cpy_ind AS plan_usual_cust_cpy_ind , direct_link_cd AS direct_link_cd , bin_nbr AS bin_nbr , ncpdp_version AS ncpdp_version , processor_ctr_nbr AS processor_ctr_nbr , overrid_billing_basis_cd AS overrid_billing_basis_cd , overrid_billing_adj_amt AS overrid_billing_adj_amt , overrid_billing_adj_typ AS overrid_billing_adj_typ , primary_billing_basis_cd AS primary_billing_basis_cd , primary_billing_adj_amt AS primary_billing_adj_amt , primary_billing_adj_typ AS primary_billing_adj_typ , plan_bill_method_cd AS plan_bill_method_cd , bill_form_type_cd AS bill_form_type_cd , state_plan_cd AS state_plan_cd , generic_disp_fee AS generic_disp_fee , generic_disp_fee_cd AS generic_disp_fee_cd , generic_copay AS generic_copay , generic_copay_cd AS generic_copay_cd , brand_disp_fee AS brand_disp_fee , brand_disp_fee_cd AS brand_disp_fee_cd , brand_copay AS brand_copay , brand_copay_cd AS brand_copay_cd , otc_disp_fee AS otc_disp_fee , otc_disp_fee_cd AS otc_disp_fee_cd , otc_copay AS otc_copay , otc_copay_cd AS otc_copay_cd , custom_pay_cd_ind AS custom_pay_cd_ind , link_type_cd AS link_type_cd , plan_usual_cust_adj_typ AS plan_usual_cust_adj_typ , signature_required_ind AS signature_required_ind , create_user_id AS create_user_id , create_dttm AS create_dttm , update_user_id AS update_user_id , update_dttm AS update_dttm , child_plan_qty AS child_plan_qty , parent_plan_id AS parent_plan_id , plan_cfc_exclsns_ind AS plan_cfc_exclsns_ind , sign_cd AS sign_cd , promise_plan_cfc_cd AS promise_plan_cfc_cd , mail_plan_uc_cd AS mail_plan_uc_cd , mail_plan_uc_default_amt AS mail_plan_uc_default_amt , corp_plan_area_cd AS corp_plan_area_cd , corp_plan_phone AS corp_plan_phone , plan_prior_auth_area_cd AS plan_prior_auth_area_cd , plan_prior_auth_phone AS plan_prior_auth_phone , partial_fill_version_cd AS partial_fill_version_cd , thrd_pty_cert_id AS thrd_pty_cert_id , assignd_nbr_ind AS assignd_nbr_ind , dur_level_1 AS dur_level_1 , dur_level_2 AS dur_level_2 , dur_level_3 AS dur_level_3 , dur_level_4 AS dur_level_4 , dur_level_5 AS dur_level_5 , coord_of_benefits_ind AS coord_of_benefits_ind , sr_div_elig_ind AS sr_div_elig_ind , manual_claim_ind AS manual_claim_ind , pbr_assignd_nbr_ind AS pbr_assignd_nbr_ind , pharmacist_cd AS pharmacist_cd , person_cd_ind AS person_cd_ind , actual_processor_ctr_nbr AS actual_processor_ctr_nbr , cob_seg_ind AS cob_seg_ind , sec_bill_method_cd AS sec_bill_method_cd , sec_sent_cob_seg_ind AS sec_sent_cob_seg_ind , sec_oac_ind AS sec_oac_ind , sec_hybrid_threshold_amt AS sec_hybrid_threshold_amt , sec_bill_for_zero_copay AS sec_bill_for_zero_copay , sec_zero_opap_occ AS sec_zero_opap_occ , sec_fullbill_cob_seg_ind AS sec_fullbill_cob_seg_ind , sec_full_bill_occ AS sec_full_bill_occ , sec_opap_qualifier AS sec_opap_qualifier , sec_op_coverage_type AS sec_op_coverage_type , discount_plan_cd AS discount_plan_cd , plan_tip_exclusion_ind AS plan_tip_exclusion_ind , document_id AS document_id , epa_ind AS epa_ind , sec_pbr_assignd_nbr_ind AS sec_pbr_assignd_nbr_ind , sdl_cob_cd AS sdl_cob_cd , allow_non_rx_otc_ind AS allow_non_rx_otc_ind , non_rx_otc_pbr_id AS non_rx_otc_pbr_id , non_rx_otc_days_supply AS non_rx_otc_days_supply , d0_websdl_cob_ind AS d0_websdl_cob_ind , elig_plan_description AS elig_plan_description , elig_plan_recip_id_lbl AS elig_plan_recip_id_lbl , pct_of_util_pln_adj AS pct_of_util_pln_adj , sec_bill_lower_cpf_copay AS sec_bill_lower_cpf_copay , sec_opap_adm_qlfr AS sec_opap_adm_qlfr , sec_opap_cogn_qlfr AS sec_opap_cogn_qlfr , d0_sec_zero_opap_occ AS d0_sec_zero_opap_occ , sec_opap_dlvry_qlfr AS sec_opap_dlvry_qlfr , sec_opap_drug_bnft_qlfr AS sec_opap_drug_bnft_qlfr , sec_opap_incntv_qlfr AS sec_opap_incntv_qlfr , sec_opap_post_qlfr AS sec_opap_post_qlfr , sec_opap_ship_qlfr AS sec_opap_ship_qlfr , sec_pat_lump_sum AS sec_pat_lump_sum , sec_pat_pay_brkdwn AS sec_pat_pay_brkdwn , sec_prim_gt_zero_occ AS sec_prim_gt_zero_occ , sec_prim_lt_zero_occ AS sec_prim_lt_zero_occ , sec_prim_rej_occ_after AS sec_prim_rej_occ , d0_sec_bill_zero_copay AS d0_sec_bill_zero_copay , 
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """

# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd, 
""" + BATCH_ID + """ as edw_batch_id,
plan_id_after AS plan_id , plan_area_cd_after AS plan_area_cd , plan_phone_nbr_after AS plan_phone_nbr , plan_type_cd_after AS plan_type_cd , plan_name_after AS plan_name , plan_active_ind_after AS plan_active_ind , plan_effective_dttm_after AS plan_effective_dttm , phrm_store_nbr_cd_after AS phrm_store_nbr_cd , pbr_cd_after AS pbr_cd , secondary_pbr_cd_after AS secondary_pbr_cd , plan_cmpd_drug_cd_after AS plan_cmpd_drug_cd , plan_usual_cust_adj_amt_after AS plan_usual_cust_adj_amt , tax_exempt_plan_ind_after AS tax_exempt_plan_ind , plan_usual_cust_ind_after AS plan_usual_cust_ind , plan_usual_cust_cpy_ind_after AS plan_usual_cust_cpy_ind , direct_link_cd_after AS direct_link_cd , bin_nbr_after AS bin_nbr , ncpdp_version_after AS ncpdp_version , processor_ctr_nbr_after AS processor_ctr_nbr , overrid_billing_basis_cd_after AS overrid_billing_basis_cd , overrid_billing_adj_amt_after AS overrid_billing_adj_amt , overrid_billing_adj_typ_after AS overrid_billing_adj_typ , primary_billing_basis_cd_after AS primary_billing_basis_cd , primary_billing_adj_amt_after AS primary_billing_adj_amt , primary_billing_adj_typ_after AS primary_billing_adj_typ , plan_bill_method_cd_after AS plan_bill_method_cd , bill_form_type_cd_after AS bill_form_type_cd , state_plan_cd_after AS state_plan_cd , generic_disp_fee_after AS generic_disp_fee , generic_disp_fee_cd_after AS generic_disp_fee_cd , generic_copay_after AS generic_copay , generic_copay_cd_after AS generic_copay_cd , brand_disp_fee_after AS brand_disp_fee , brand_disp_fee_cd_after AS brand_disp_fee_cd , brand_copay_after AS brand_copay , brand_copay_cd_after AS brand_copay_cd , otc_disp_fee_after AS otc_disp_fee , otc_disp_fee_cd_after AS otc_disp_fee_cd , otc_copay_after AS otc_copay , otc_copay_cd_after AS otc_copay_cd , custom_pay_cd_ind_after AS custom_pay_cd_ind , link_type_cd_after AS link_type_cd , plan_usual_cust_adj_typ_after AS plan_usual_cust_adj_typ , signature_required_ind_after AS signature_required_ind , create_user_id_after AS create_user_id , create_dttm_after AS create_dttm , update_user_id_after AS update_user_id , update_dttm_after AS update_dttm , child_plan_qty_after AS child_plan_qty , parent_plan_id_after AS parent_plan_id , plan_cfc_exclsns_ind_after AS plan_cfc_exclsns_ind , sign_cd_after AS sign_cd , promise_plan_cfc_cd_after AS promise_plan_cfc_cd , mail_plan_uc_cd_after AS mail_plan_uc_cd , mail_plan_uc_default_amt_after AS mail_plan_uc_default_amt , corp_plan_area_cd_after AS corp_plan_area_cd , corp_plan_phone_after AS corp_plan_phone , plan_prior_auth_area_cd_after AS plan_prior_auth_area_cd , plan_prior_auth_phone_after AS plan_prior_auth_phone , partial_fill_version_cd_after AS partial_fill_version_cd , thrd_pty_cert_id_after AS thrd_pty_cert_id , assignd_nbr_ind_after AS assignd_nbr_ind , dur_level_1_after AS dur_level_1 , dur_level_2_after AS dur_level_2 , dur_level_3_after AS dur_level_3 , dur_level_4_after AS dur_level_4 , dur_level_5_after AS dur_level_5 , coord_of_benefits_ind_after AS coord_of_benefits_ind , sr_div_elig_ind_after AS sr_div_elig_ind , manual_claim_ind_after AS manual_claim_ind , pbr_assignd_nbr_ind_after AS pbr_assignd_nbr_ind , pharmacist_cd_after AS pharmacist_cd , person_cd_ind_after AS person_cd_ind , actual_processor_ctr_nbr_after AS actual_processor_ctr_nbr , cob_seg_ind_after AS cob_seg_ind , sec_bill_method_cd_after AS sec_bill_method_cd , sec_sent_cob_seg_ind_after AS sec_sent_cob_seg_ind , sec_oac_ind_after AS sec_oac_ind , sec_hybrid_threshold_amt_after AS sec_hybrid_threshold_amt , sec_bill_for_zero_copay_after AS sec_bill_for_zero_copay , sec_zero_opap_occ_after AS sec_zero_opap_occ , sec_fullbill_cob_seg_ind_after AS sec_fullbill_cob_seg_ind , sec_full_bill_occ_after AS sec_full_bill_occ , sec_opap_qualifier_after AS sec_opap_qualifier , sec_op_coverage_type_after AS sec_op_coverage_type , discount_plan_cd_after AS discount_plan_cd , plan_tip_exclusion_ind_after AS plan_tip_exclusion_ind , document_id_after AS document_id , epa_ind_after AS epa_ind , sec_pbr_assignd_nbr_ind_after AS sec_pbr_assignd_nbr_ind , sdl_cob_cd_after AS sdl_cob_cd , allow_non_rx_otc_ind_after AS allow_non_rx_otc_ind , non_rx_otc_pbr_id_after AS non_rx_otc_pbr_id , non_rx_otc_days_supply_after AS non_rx_otc_days_supply , d0_websdl_cob_ind_after AS d0_websdl_cob_ind , elig_plan_description_after AS elig_plan_description , elig_plan_recip_id_lbl_after AS elig_plan_recip_id_lbl , pct_of_util_pln_adj_after AS pct_of_util_pln_adj , sec_bill_lower_cpf_copay_after AS sec_bill_lower_cpf_copay , sec_opap_adm_qlfr_after AS sec_opap_adm_qlfr , sec_opap_cogn_qlfr_after AS sec_opap_cogn_qlfr , d0_sec_zero_opap_occ_after AS d0_sec_zero_opap_occ , sec_opap_dlvry_qlfr_after AS sec_opap_dlvry_qlfr , sec_opap_drug_bnft_qlfr_after AS sec_opap_drug_bnft_qlfr , sec_opap_incntv_qlfr_after AS sec_opap_incntv_qlfr , sec_opap_post_qlfr_after AS sec_opap_post_qlfr , sec_opap_ship_qlfr_after AS sec_opap_ship_qlfr , sec_pat_lump_sum_after AS sec_pat_lump_sum , sec_pat_pay_brkdwn_after AS sec_pat_pay_brkdwn , sec_prim_gt_zero_occ_after AS sec_prim_gt_zero_occ , sec_prim_lt_zero_occ_after AS sec_prim_lt_zero_occ , sec_prim_rej_occ_after AS sec_prim_rej_occ , d0_sec_bill_zero_copay_after AS d0_sec_bill_zero_copay ,
'""" + SRC_TBL_NAME +  """' as table_name
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 

#Union to get the gg_tbf0_insert_final
#if gg_tbf0_insert_patid_check.count()==0:
#  gg_tbf0_insert_final = gg_tbf0_insert_nopatid
  
#elif gg_tbf0_insert_nopatid.count()==0:
#   gg_tbf0_insert_final = gg_tbf0_insert_patid_check
  
#else:
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")
display(etl_tbf0_file)

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

# if (etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ):
#   etl_tbf0_reformat_cdc_check = etl_tbf0_reformat
  
# else:
#   etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())
display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK)

# COMMAND ----------



# COMMAND ----------

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("cdc_txn_commit_dttm", to_timestamp(etl_tbf0_reformat_cdc_check_notnull["cdc_txn_commit_dttm"]))\
           .withColumn("plan_effective_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["plan_effective_dttm"]))\
           .withColumn("create_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["create_dttm"]))\
           .withColumn("update_dttm",to_timestamp(etl_tbf0_reformat_cdc_check_notnull["update_dttm"]))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in etl_tbf0_reformat_cdc_check_notnull.columns])

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

# # ReadAPI Call to fetch asset file names with current location:  
# WRITEAPI_URL = dbutils.widgets.get("PAR_WRITEAPI_URL")

# Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 60, 
#                   {"PAR_WRITEAPI_URL":WRITEAPI_URL,
#                    "PAR_WRITEAPI_KEY1":"statusId",
#                    "PAR_WRITEAPI_VALUE1":"200",
#                    "PAR_WRITEAPI_KEY2":"assetId",
#                    "PAR_WRITEAPI_VALUE2":dfAssetIdStr});

# print("Write API successfully executed...")

# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)
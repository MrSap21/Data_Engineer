# Databricks notebook source
dbutils.widgets.text("PAR_DB_FOLDER","",label="PAR_DB_FOLDER")
dbutils.widgets.text("PAR_DB_FILE_NAME","",label="PAR_DB_FILE_NAME")


folderName=dbutils.widgets.get("PAR_DB_FOLDER")
fileName=dbutils.widgets.get("PAR_DB_FILE_NAME")


# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.functions import concat, col, lit

input_path="/mnt/wrangled/"+ folderName + "/" + fileName + ".dat"
df = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header", "false")\
      .option("sep", ",")\
      .load(input_path)
#display(df)
#df.filter(df.columns.contains("invalid")).show
#df.filter(df._c0.contains("invalid")).show
col_list=df.columns
#print(col_list)
dfNullFill=df.na.fill("")
#display(dfNullFill)
dfConcatenated=dfNullFill.withColumn("concatenated",concat(*col_list))
dfInvalid = dfConcatenated.filter(dfConcatenated.concatenated.contains("Invalid"))
if(dfInvalid.count()>0):
  display(dfInvalid)



# COMMAND ----------

if(dfInvalid.count()>0):
  dbutils.fs.rm(input_path, recurse = True)
  raise Exception("Invalid records found, Please find Above invalid records")
else:
  #dfValid = dfConcatenated.filter(~dfConcatenated.concatenated.contains("invalid")).drop("concatenated")
  dfValid = dfConcatenated.filter(~dfConcatenated.concatenated.contains("invalid")).select("concatenated")


# COMMAND ----------

#Write output file
data_location_output="/mnt/wrangled/"+ folderName + "/" + fileName
print(data_location_output)
dfValid.coalesce(1).write.mode("overwrite").option("quote"," ").option("escape", " ").option("sep","|")\
.option("emptyValue",None).format("csv").save(data_location_output)
filesoutput = dbutils.fs.ls(data_location_output)
print(filesoutput) 
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
print(csv_file_output) 
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)
#dbutils.fs.rm(input_path, recurse = True)

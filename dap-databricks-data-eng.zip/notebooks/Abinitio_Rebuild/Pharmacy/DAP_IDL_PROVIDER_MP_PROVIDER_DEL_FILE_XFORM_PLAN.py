# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("INPUT_DATA_FILES_LIST","",label="INPUT_DATA_FILES_LIST")
dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")

input_data_files_list = dbutils.widgets.get("INPUT_DATA_FILES_LIST")
output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")
output_file_path = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir + '/' + batch_id

# COMMAND ----------

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

col_list = [("providerInfoPublish_messageInfoPublish_peid","peid"),("providerInfoPublish_messageInfoPublish_leid","leid"),("providerInfoPublish_messageInfoPublish_actionCode","actionCode"),("providerInfoPublish_messageInfoPublish_actionDate","actionDate"),("providerInfoPublish_messageInfoPublish_createDate","createDate"),("providerInfoPublish_messageInfoPublish_lastUpdateSystemCode","lastUpdateSystemCode"),("providerInfoPublish_messageInfoPublish_lastUpdateDate","lastUpdateDate")]

selected = [col(j) for k, j in col_list]

# COMMAND ----------

def read_del_xml(df_files_meta, asset_item_id):
  # Retrieve the specific input file path
  input_file = df_files_meta.filter('asset_id = {0}'.format(asset_item_id))\
                              .select('input_file_path')\
                              .rdd.flatMap(lambda x: x).collect()[0]
  #read del files row tags
  df_del1 = spark.read.format("com.databricks.spark.xml").option("rowTag","ns1:publishProviderCV").load(input_file)
  
  #Flatten all columns
  df_del = flatten_dataframe(df_del1)
  
  #trim spaces for all columns both left and right ends
  df_del = trim_column(df_del)
  
  #drop null records and select records with non blank values
  df_del_val =  df_del.select([when(col(_col).alias(_col) != "",col(_col)).alias(_col) for _col in df_del.columns])
  #df_del_val = df_del_val.na.drop()
  #add missing tags
  df_del_add_tags = add_missing_tag(df_del_val,col_list)
  
  df_del_final=df_del_add_tags.select(*selected)
  
  #Transformations as per GDE
  df_del_final_gde = df_del_final.withColumn("actionDate",df_del_final["actionDate"].cast(TimestampType())).withColumn("createDate",df_del_final["createDate"].cast(TimestampType())).withColumn("lastUpdateDate",df_del_final["lastUpdateDate"].cast(TimestampType()))
  df_del_dat=df_del_final_gde.dropDuplicates()
  return df_del_dat

# COMMAND ----------

# Get the files metadata
df_files_meta = get_files_meta_data(input_data_files_list)
# Read multiple xml files in parallel based on the files metedata and merge all in a single dataframe
print("df_files_meta::",df_files_meta)
df_final = process_multi_xml_del_parallel(df_files_meta)
df_final = df_final.withColumn("etl_change_cd",lit("D")).withColumnRenamed("peid","hc_provider_src_id")
df_final_del = df_final.select("hc_provider_src_id","etl_change_cd")

# COMMAND ----------

# Write output (parquet)
write_data(df_final_del,output_file_path)


# COMMAND ----------

# df_final_del.show()
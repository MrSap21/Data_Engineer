# Databricks notebook source
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","19981117163100")
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","UAT_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","UAT_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_MADR_QUEUE")
# dbutils.widgets.text("PAR_DB_SNFK_WH","UAT_HISTORY_MIGRATION_FR_WH")
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","GG_TBF0_MADR_QUEUE")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_MADR_QUEUE_dsv")
# dbutils.widgets.text("PAR_PIPELINE_NAME","PL_MSTR_PHARMACY_AND_HEALTHCARE_PATIENT_SERVICES_ETL_TBF0_MADR_QUEUE_LOAD")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapuatappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_SQL_SERVER","dapuatsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","uatdnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapuatsqldb01")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapuatappservice-appserver.azurewebsites.net/assetUpdate")

# COMMAND ----------

READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
PAR_SQL_SERVER = dbutils.widgets.get("PAR_SQL_SERVER")
PAR_PIPELINE_NAME = dbutils.widgets.get("PAR_PIPELINE_NAME")
PAR_SQL_SERVER_AD_CLIENT_ID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
PAR_SQL_SERVER_AD_CLIENT_SECRET = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")
PAR_SQL_SERVER_DB = dbutils.widgets.get("PAR_SQL_SERVER_DB")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/GetUnprocessedFiles", 10000, 
                 {"PAR_EDW_BATCH_ID":BATCH_ID,
                  "PAR_FEED_NAMES":FEED_NAME,
                  "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                  "PAR_READAPI_URL":READAPI_URL,
                  "PAR_SQL_SERVER":PAR_SQL_SERVER,
                  "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                  "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                  "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                  "PAR_RETURN_FILE_TYPE":"A"});

print(Input_File_List)

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *


rddjson = sc.parallelize([Input_File_List])

dfFeedName = sqlContext.read.json(rddjson).withColumn(FEED_NAME,col(FEED_NAME))
display(dfFeedName)
complex_fields = dict([(field.name, field.dataType)
                             for field in dfFeedName.schema.fields
                             if type(field.dataType) == ArrayType or  type(field.dataType) == StructType])

if(type(complex_fields[FEED_NAME])) == ArrayType:
  #dfFileList1 = sqlContext.read.json(rddjson)
  dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,explode(col(FEED_NAME)))\
                               .select(f"{FEED_NAME}.assetcurrentlocation",
                               f"{FEED_NAME}.assetid",
                               f"{FEED_NAME}.assetname")
                                            
else:
  dfFileList = sqlContext.read.json(rddjson).withColumn(FEED_NAME,col(FEED_NAME))\
                               .select(f"{FEED_NAME}.assetcurrentlocation",
                               f"{FEED_NAME}.assetid",
                               f"{FEED_NAME}.assetname")
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")


# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList=[mountPoint + row[0] +  row[1] for row in dfNamePath.select('filepath','filename').collect()]


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)
in_text = in_text.select(regexp_replace(col("value"),"\"","").alias("value")).rdd

# COMMAND ----------

#Implement Control Files Logic

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

# print (OUT_FILEPATH)
# print (REJ_FILE_NOISE_RMV)
# print(REJ_FILE_PAT_MOD)
# print(REJ_FILE_UPD_NULL)
# print(REJ_FILE_CDC_CHECK)


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Define Input File Schema
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'str_nbr',
'str_nbr_after',
'rx_nbr',
'rx_nbr_after',
'rx_fill_nbr',
'rx_fill_nbr_after',
'rx_partial_fill_nbr',
'rx_partial_fill_nbr_after',
'dspn_fill_nbr',
'dspn_fill_nbr_after',
'madr_status_cd',
'madr_status_cd_after',
'madr_rules_passed',
'madr_rules_passed_after',
'madr_rules_failed',
'madr_rules_failed_after',
'madr_pullback_dttm',
'madr_pullback_dttm_after',
'madr_failure_reason_cd',
'madr_failure_reason_cd_after',
'send_to_remote_ind',
'send_to_remote_ind_after',
'rx_type_cd',
'rx_type_cd_after',
'ml_relevant_categories',
'ml_relevant_categories_after',
'ml_confidence_scores',
'ml_confidence_scores_after',
'daily_dosage',
'daily_dosage_after',
'single_dose',
'single_dose_after',
'sig_admin_time',
'sig_admin_time_after',
'sig_indication',
'sig_indication_after',
'sig_roa_value',
'sig_roa_value_after',
'quality_alert_ind',
'quality_alert_ind_after',
'pbr_status_cd',
'pbr_status_cd_after',
'pbr_id',
'pbr_id_after',
'new_to_therapy_ind',
'new_to_therapy_ind_after',
'src_create_user_id',
'src_create_user_id_after',
'src_create_dttm',
'src_create_dttm_after',
'src_update_user_id',
'src_update_user_id_after',
'src_update_dttm',
'src_update_dttm_after']
print(len(fieldList))

# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  elif '"INSERT"' in key_list[6]:
    if val_len != 67:
      print(val_len)
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 68:
      return True
  else:
    if val_len != 68:
      return True

# COMMAND ----------

# Read input files
in_text = spark.read.text(readList)
in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode("overwrite").parquet(REJ_SHORT_FILEPATH)

# COMMAND ----------

#split and add schema
col_len = 68

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(f"Total count {rd1.count()}")

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 24
print(f"Bad records count {rd_bad.count()}") # != 24

schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))
df = spark.createDataFrame(rd_good, schema)
#display(df)

# COMMAND ----------

#function to remove "" & \\ <Only when the file is encrypted?
def handlEscpeQuotes(val):
 if not val:
   return ""
  
  #remove rightmost "
 outval = val[0:-1]
  #remove leftmost "
 outval = outval.lstrip("\"")
  #replace double \\ with \
 outval = outval.replace("\\\\","\\")
  #replace double \" with "
 outval = outval.replace("\\\"","\"")
 return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

from functools import reduce
df = df.drop('row_length')
df = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col_name)),
    df.columns,
    df
))

df_gg = df.withColumn("table_name",lit("gg_tbf0_prescription_madr_queue")) \
          .withColumn("edw_batch_id",lit(BATCH_ID)) \
          .withColumn("edw_batch_id_after",lit(BATCH_ID)) 
display(df_gg)
df_gg.createOrReplaceTempView("raw_gg_prescription_madr_queue")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR table_name  == 'gg_tbf0_prescription_madr_queue' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"
pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"


# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from raw_gg_prescription_madr_queue where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual
nr_input_filter_transpartition_sql = "select * from raw_gg_prescription_madr_queue where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_prescription_madr_queue where " + pNopartitionTableCheck

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)
nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)
nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)
# print(nr_input_filter_rxpartition.count())
# print(nr_input_filter_transpartition.count())
# print(nr_input_filter_nopartition.count())

if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition

else:  
  sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETL_HIVE_CUTOFF_TBL)
  df_cutoff_records_output=spark.read \
     .format("snowflake") \
     .options(**options) \
     .option("sfWarehouse", SNFL_WH) \
     .option("sfDatabase",SNFK_ETL_DB) \
     .option("query",sel_ETL_Hive_Cutoff_tbl) \
     .load()


  cutoff_records_filter = df_cutoff_records_output.filter((df_cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (df_cutoff_records_output.PROJ_NAME == 'WALGREENS'))
  cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

  #Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
  cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
  RX_CUT_OFF_MAX_DTTM as rx_max,
  CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
  CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
  from cutoff_records_filter""" 
  cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
  

  #Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
  cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
  RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
  CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
  from cutoff_records_filter"""
  cutoff_range_trans = spark.sql(cutoff_range_trans_sql)

  #Fetching rx_max and rx_trans_max as values
  rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
  rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max

  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck).filter(nr_input_filter_rxpartition.cdc_txn_commit_dttm < rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_transpartition.filter(pRxCutoffTableCheckEqual).filter(nr_input_filter_transpartition.cdc_txn_commit_dttm <= rx_max)

  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheck).filter(nr_input_filter_nopartition.cdc_txn_commit_dttm < rx_trans_max)

  nr_input_file_filter_trans_equal = nr_input_filter_nopartition.filter(pRxTransCutoffTableCheckEqual).filter(nr_input_filter_nopartition.cdc_txn_commit_dttm <= rx_trans_max)
  
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)
  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)
  
#Remove duplicates
dedup_group = nr_input_file_final.distinct()

#nr spacetrim
for col in dedup_group.columns:
    nr_spacetrim = dedup_group.withColumn(col, when(ltrim(rtrim(dedup_group[col])) == "",None).otherwise(ltrim(rtrim(dedup_group[col]))))
# display(nr_spacetrim)
nr_spacetrim.createOrReplaceTempView("nr_spacetrim")



# COMMAND ----------

pUpdateReform="(str_nbr == str_nbr_after  AND  str_nbr IS NOT NULL AND  str_nbr_after IS NOT NULL AND rx_nbr == rx_nbr_after  AND  rx_nbr IS NOT NULL AND  rx_nbr_after IS NOT NULL AND rx_fill_nbr == rx_fill_nbr_after  AND  rx_fill_nbr IS NOT NULL AND  rx_fill_nbr_after IS NOT NULL AND rx_partial_fill_nbr == rx_partial_fill_nbr_after  AND  rx_partial_fill_nbr IS NOT NULL AND  rx_partial_fill_nbr_after IS NOT NULL AND cdc_seq_nbr == cdc_seq_nbr_after  AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL AND cdc_rba_nbr == cdc_rba_nbr_after  AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL AND cdc_txn_commit_dttm == cdc_txn_commit_dttm_after   AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL AND cdc_before_after_cd_after =='AFTER' AND  cdc_before_after_cd_after IS NOT NULL AND cdc_operation_type_cd_after =='SQL COMPUPDATE' AND  cdc_operation_type_cd_after IS NOT NULL AND cdc_before_after_cd == 'BEFORE'  AND  cdc_before_after_cd IS NOT NULL AND cdc_operation_type_cd == 'SQL COMPUPDATE'   AND  cdc_operation_type_cd IS NOT NULL AND (( RTRIM(LOWER(dspn_fill_nbr)) == RTRIM(LOWER(dspn_fill_nbr_after ))  AND dspn_fill_nbr IS NOT NULL AND dspn_fill_nbr_after IS NOT NULL ) OR ( dspn_fill_nbr IS NULL AND dspn_fill_nbr_after IS NULL )) AND (( RTRIM(LOWER(madr_status_cd)) == RTRIM(LOWER(madr_status_cd_after ))  AND madr_status_cd IS NOT NULL AND madr_status_cd_after IS NOT NULL ) OR ( madr_status_cd IS NULL AND madr_status_cd_after IS NULL )) AND (( RTRIM(LOWER(madr_rules_passed)) == RTRIM(LOWER(madr_rules_passed_after ))  AND madr_rules_passed IS NOT NULL AND madr_rules_passed_after IS NOT NULL ) OR ( madr_rules_passed IS NULL AND madr_rules_passed_after IS NULL )) AND (( RTRIM(LOWER(madr_rules_failed)) == RTRIM(LOWER(madr_rules_failed_after ))  AND madr_rules_failed IS NOT NULL AND madr_rules_failed_after IS NOT NULL ) OR ( madr_rules_failed IS NULL AND madr_rules_failed_after IS NULL )) AND (( RTRIM(LOWER(madr_pullback_dttm)) == RTRIM(LOWER(madr_pullback_dttm_after ))  AND madr_pullback_dttm IS NOT NULL AND madr_pullback_dttm_after IS NOT NULL ) OR ( madr_pullback_dttm IS NULL AND madr_pullback_dttm_after IS NULL )) AND (( RTRIM(LOWER(madr_failure_reason_cd)) == RTRIM(LOWER(madr_failure_reason_cd_after ))  AND madr_failure_reason_cd IS NOT NULL AND madr_failure_reason_cd_after IS NOT NULL ) OR ( madr_failure_reason_cd IS NULL AND madr_failure_reason_cd_after IS NULL )) AND (( RTRIM(LOWER(send_to_remote_ind)) == RTRIM(LOWER(send_to_remote_ind_after ))  AND send_to_remote_ind IS NOT NULL AND send_to_remote_ind_after IS NOT NULL ) OR ( send_to_remote_ind IS NULL AND send_to_remote_ind_after IS NULL )) AND (( RTRIM(LOWER(rx_type_cd)) == RTRIM(LOWER(rx_type_cd_after ))  AND rx_type_cd IS NOT NULL AND rx_type_cd_after IS NOT NULL ) OR ( rx_type_cd IS NULL AND rx_type_cd_after IS NULL )) AND (( RTRIM(LOWER(ml_relevant_categories)) == RTRIM(LOWER(ml_relevant_categories_after ))  AND ml_relevant_categories IS NOT NULL AND ml_relevant_categories_after IS NOT NULL ) OR ( ml_relevant_categories IS NULL AND ml_relevant_categories_after IS NULL )) AND (( RTRIM(LOWER(ml_confidence_scores)) == RTRIM(LOWER(ml_confidence_scores_after ))  AND ml_confidence_scores IS NOT NULL AND ml_confidence_scores_after IS NOT NULL ) OR ( ml_confidence_scores IS NULL AND ml_confidence_scores_after IS NULL )) AND (( RTRIM(LOWER(daily_dosage)) == RTRIM(LOWER(daily_dosage_after ))  AND daily_dosage IS NOT NULL AND daily_dosage_after IS NOT NULL ) OR ( daily_dosage IS NULL AND daily_dosage_after IS NULL )) AND (( RTRIM(LOWER(single_dose)) == RTRIM(LOWER(single_dose_after ))  AND single_dose IS NOT NULL AND single_dose_after IS NOT NULL ) OR ( single_dose IS NULL AND single_dose_after IS NULL )) AND (( RTRIM(LOWER(sig_admin_time)) == RTRIM(LOWER(sig_admin_time_after ))  AND sig_admin_time IS NOT NULL AND sig_admin_time_after IS NOT NULL ) OR ( sig_admin_time IS NULL AND sig_admin_time_after IS NULL )) AND (( RTRIM(LOWER(sig_indication)) == RTRIM(LOWER(sig_indication_after ))  AND sig_indication IS NOT NULL AND sig_indication_after IS NOT NULL ) OR ( sig_indication IS NULL AND sig_indication_after IS NULL )) AND (( RTRIM(LOWER(sig_roa_value)) == RTRIM(LOWER(sig_roa_value_after ))  AND sig_roa_value IS NOT NULL AND sig_roa_value_after IS NOT NULL ) OR ( sig_roa_value IS NULL AND sig_roa_value_after IS NULL )) AND (( RTRIM(LOWER(quality_alert_ind)) == RTRIM(LOWER(quality_alert_ind_after ))  AND quality_alert_ind IS NOT NULL AND quality_alert_ind_after IS NOT NULL ) OR ( quality_alert_ind IS NULL AND quality_alert_ind_after IS NULL )) AND (( RTRIM(LOWER(pbr_status_cd)) == RTRIM(LOWER(pbr_status_cd_after ))  AND pbr_status_cd IS NOT NULL AND pbr_status_cd_after IS NOT NULL ) OR ( pbr_status_cd IS NULL AND pbr_status_cd_after IS NULL )) AND (( RTRIM(LOWER(pbr_id)) == RTRIM(LOWER(pbr_id_after ))  AND pbr_id IS NOT NULL AND pbr_id_after IS NOT NULL ) OR ( pbr_id IS NULL AND pbr_id_after IS NULL )) AND (( RTRIM(LOWER(new_to_therapy_ind)) == RTRIM(LOWER(new_to_therapy_ind_after ))  AND new_to_therapy_ind IS NOT NULL AND new_to_therapy_ind_after IS NOT NULL ) OR ( new_to_therapy_ind IS NULL AND new_to_therapy_ind_after IS NULL )) AND (( RTRIM(LOWER(src_create_user_id)) == RTRIM(LOWER(src_create_user_id_after ))  AND src_create_user_id IS NOT NULL AND src_create_user_id_after IS NOT NULL ) OR ( src_create_user_id IS NULL AND src_create_user_id_after IS NULL )) AND (( RTRIM(LOWER(src_create_dttm)) == RTRIM(LOWER(src_create_dttm_after ))  AND src_create_dttm IS NOT NULL AND src_create_dttm_after IS NOT NULL ) OR ( src_create_dttm IS NULL AND src_create_dttm_after IS NULL )) AND (( RTRIM(LOWER(src_update_user_id)) == RTRIM(LOWER(src_update_user_id_after ))  AND src_update_user_id IS NOT NULL AND src_update_user_id_after IS NOT NULL ) OR ( src_update_user_id IS NULL AND src_update_user_id_after IS NULL )) AND (( RTRIM(LOWER(src_update_dttm)) == RTRIM(LOWER(src_update_dttm_after ))  AND src_update_dttm IS NOT NULL AND src_update_dttm_after IS NOT NULL ) OR ( src_update_dttm IS NULL AND src_update_dttm_after IS NULL )) )"


# COMMAND ----------

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

gg_tbf0_rejected_query = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(gg_tbf0_rejected_query)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 
  
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")


# COMMAND ----------

gg_tbf0_update_afr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm_after.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr_after.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr_after.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd_after.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id_after.alias("edw_batch_id"), \
                                           gg_tbf0_update.str_nbr_after.alias("str_nbr"), \
                                           gg_tbf0_update.rx_nbr_after.alias("rx_nbr"), \
                                           gg_tbf0_update.rx_fill_nbr_after.alias("rx_fill_nbr"), \
                                           gg_tbf0_update.rx_partial_fill_nbr_after.alias("rx_partial_fill_nbr"), \
                                           gg_tbf0_update.dspn_fill_nbr_after.alias("dspn_fill_nbr"), \
                                           gg_tbf0_update.madr_status_cd_after.alias("madr_status_cd"), \
                                           gg_tbf0_update.madr_rules_passed_after.alias("madr_rules_passed"), \
                                           gg_tbf0_update.madr_rules_failed_after.alias("madr_rules_failed"), \
                                           gg_tbf0_update.madr_pullback_dttm_after.alias("madr_pullback_dttm"), \
                                           gg_tbf0_update.madr_failure_reason_cd_after.alias("madr_failure_reason_cd"), \
                                           gg_tbf0_update.send_to_remote_ind_after.alias("send_to_remote_ind"), \
                                           gg_tbf0_update.rx_type_cd_after.alias("rx_type_cd"), \
                                           gg_tbf0_update.ml_relevant_categories_after.alias("ml_relevant_categories"), \
                                           gg_tbf0_update.ml_confidence_scores_after.alias("ml_confidence_scores"), \
                                           gg_tbf0_update.daily_dosage_after.alias("daily_dosage"), \
                                           gg_tbf0_update.single_dose_after.alias("single_dose"), \
                                           gg_tbf0_update.sig_admin_time_after.alias("sig_admin_time"), \
                                           gg_tbf0_update.sig_indication_after.alias("sig_indication"), \
                                           gg_tbf0_update.sig_roa_value_after.alias("sig_roa_value"), \
                                           gg_tbf0_update.quality_alert_ind_after.alias("quality_alert_ind"), \
                                           gg_tbf0_update.pbr_status_cd_after.alias("pbr_status_cd"), \
                                           gg_tbf0_update.pbr_id_after.alias("pbr_id"), \
                                           gg_tbf0_update.new_to_therapy_ind_after.alias("new_to_therapy_ind"), \
                                           gg_tbf0_update.src_create_user_id_after.alias("src_create_user_id"), \
                                           gg_tbf0_update.src_create_dttm_after.alias("src_create_dttm"), \
                                           gg_tbf0_update.src_update_user_id_after.alias("src_update_user_id"), \
                                           gg_tbf0_update.src_update_dttm_after.alias("src_update_dttm"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_update_bfr = gg_tbf0_update.select(gg_tbf0_update.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                           gg_tbf0_update.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                           gg_tbf0_update.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                           gg_tbf0_update.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                           gg_tbf0_update.cdc_before_after_cd.alias("cdc_before_after_cd"), \
                                           gg_tbf0_update.cdc_txn_position_cd.alias("cdc_txn_position_cd"), \
                                           gg_tbf0_update.edw_batch_id.alias("edw_batch_id"), \
                                           gg_tbf0_update.str_nbr.alias("str_nbr"), \
                                           gg_tbf0_update.rx_nbr.alias("rx_nbr"), \
                                           gg_tbf0_update.rx_fill_nbr.alias("rx_fill_nbr"), \
                                           gg_tbf0_update.rx_partial_fill_nbr.alias("rx_partial_fill_nbr"), \
                                           gg_tbf0_update.dspn_fill_nbr.alias("dspn_fill_nbr"), \
                                           gg_tbf0_update.madr_status_cd.alias("madr_status_cd"), \
                                           gg_tbf0_update.madr_rules_passed.alias("madr_rules_passed"), \
                                           gg_tbf0_update.madr_rules_failed.alias("madr_rules_failed"), \
                                           gg_tbf0_update.madr_pullback_dttm.alias("madr_pullback_dttm"), \
                                           gg_tbf0_update.madr_failure_reason_cd.alias("madr_failure_reason_cd"), \
                                           gg_tbf0_update.send_to_remote_ind.alias("send_to_remote_ind"), \
                                           gg_tbf0_update.rx_type_cd.alias("rx_type_cd"), \
                                           gg_tbf0_update.ml_relevant_categories.alias("ml_relevant_categories"), \
                                           gg_tbf0_update.ml_confidence_scores.alias("ml_confidence_scores"), \
                                           gg_tbf0_update.daily_dosage.alias("daily_dosage"), \
                                           gg_tbf0_update.single_dose.alias("single_dose"), \
                                           gg_tbf0_update.sig_admin_time.alias("sig_admin_time"), \
                                           gg_tbf0_update.sig_indication.alias("sig_indication"), \
                                           gg_tbf0_update.sig_roa_value.alias("sig_roa_value"), \
                                           gg_tbf0_update.quality_alert_ind.alias("quality_alert_ind"), \
                                           gg_tbf0_update.pbr_status_cd.alias("pbr_status_cd"), \
                                           gg_tbf0_update.pbr_id.alias("pbr_id"), \
                                           gg_tbf0_update.new_to_therapy_ind.alias("new_to_therapy_ind"), \
                                           gg_tbf0_update.src_create_user_id.alias("src_create_user_id"), \
                                           gg_tbf0_update.src_create_dttm.alias("src_create_dttm"), \
                                           gg_tbf0_update.src_update_user_id.alias("src_update_user_id"), \
                                           gg_tbf0_update.src_update_dttm.alias("src_update_dttm"), \
                                           gg_tbf0_update.table_name)

gg_tbf0_insert_afr = nr_insert_check.select(nr_insert_check.cdc_txn_commit_dttm.alias("cdc_txn_commit_dttm"), \
                                           nr_insert_check.cdc_seq_nbr.alias("cdc_seq_nbr"), \
                                           nr_insert_check.cdc_rba_nbr.alias("cdc_rba_nbr"), \
                                           nr_insert_check.cdc_operation_type_cd.alias("cdc_operation_type_cd"), \
                                           nr_insert_check.cdc_before_after_cd_after.alias("cdc_before_after_cd"), \
                                           nr_insert_check.cdc_txn_position_cd_after.alias("cdc_txn_position_cd"), \
                                           nr_insert_check.edw_batch_id_after.alias("edw_batch_id"), \
                                           nr_insert_check.str_nbr_after.alias("str_nbr"), \
                                           nr_insert_check.rx_nbr_after.alias("rx_nbr"), \
                                           nr_insert_check.rx_fill_nbr_after.alias("rx_fill_nbr"), \
                                           nr_insert_check.rx_partial_fill_nbr_after.alias("rx_partial_fill_nbr"), \
                                           nr_insert_check.dspn_fill_nbr_after.alias("dspn_fill_nbr"), \
                                           nr_insert_check.madr_status_cd_after.alias("madr_status_cd"), \
                                           nr_insert_check.madr_rules_passed_after.alias("madr_rules_passed"), \
                                           nr_insert_check.madr_rules_failed_after.alias("madr_rules_failed"), \
                                           nr_insert_check.madr_pullback_dttm_after.alias("madr_pullback_dttm"), \
                                           nr_insert_check.madr_failure_reason_cd_after.alias("madr_failure_reason_cd"), \
                                           nr_insert_check.send_to_remote_ind_after.alias("send_to_remote_ind"), \
                                           nr_insert_check.rx_type_cd_after.alias("rx_type_cd"), \
                                           nr_insert_check.ml_relevant_categories_after.alias("ml_relevant_categories"), \
                                           nr_insert_check.ml_confidence_scores_after.alias("ml_confidence_scores"), \
                                           nr_insert_check.daily_dosage_after.alias("daily_dosage"), \
                                           nr_insert_check.single_dose_after.alias("single_dose"), \
                                           nr_insert_check.sig_admin_time_after.alias("sig_admin_time"), \
                                           nr_insert_check.sig_indication_after.alias("sig_indication"), \
                                           nr_insert_check.sig_roa_value_after.alias("sig_roa_value"), \
                                           nr_insert_check.quality_alert_ind_after.alias("quality_alert_ind"), \
                                           nr_insert_check.pbr_status_cd_after.alias("pbr_status_cd"), \
                                           nr_insert_check.pbr_id_after.alias("pbr_id"), \
                                           nr_insert_check.new_to_therapy_ind_after.alias("new_to_therapy_ind"), \
                                           nr_insert_check.src_create_user_id_after.alias("src_create_user_id"), \
                                           nr_insert_check.src_create_dttm_after.alias("src_create_dttm"), \
                                           nr_insert_check.src_update_user_id_after.alias("src_update_user_id"), \
                                           nr_insert_check.src_update_dttm_after.alias("src_update_dttm"), \
                                           nr_insert_check.table_name)
                                         
                                          

# COMMAND ----------

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"


# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")


# COMMAND ----------

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm , cdc_seq_nbr , cdc_rba_nbr , cdc_operation_type_cd , cdc_before_after_cd , cdc_txn_position_cd , edw_batch_id , str_nbr , rx_nbr , rx_fill_nbr , rx_partial_fill_nbr , dspn_fill_nbr , madr_status_cd , madr_rules_passed , madr_rules_failed , CONCAT(substring(madr_pullback_dttm,0,10),' ',substring(madr_pullback_dttm,12,19),'.000000') AS madr_pullback_dttm , madr_failure_reason_cd , send_to_remote_ind , rx_type_cd , ml_relevant_categories , ml_confidence_scores , daily_dosage , single_dose , sig_admin_time , sig_indication , sig_roa_value , quality_alert_ind , pbr_status_cd , pbr_id , new_to_therapy_ind , src_create_user_id , CONCAT(substring(src_create_dttm,0,10),' ',substring(src_create_dttm,12,19),'.000000') AS src_create_dttm , src_update_user_id , CONCAT(substring(src_update_dttm,0,10),' ',substring(src_update_dttm,12,19),'.000000') AS src_update_dttm"


# COMMAND ----------

etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

#Remove Blank Values
for col in etl_tbf0_reformat.columns:
    etl_tbf0_reformat = etl_tbf0_reformat.withColumn(col, when(ltrim(rtrim(etl_tbf0_reformat[col])) == "",None).otherwise(ltrim(rtrim(etl_tbf0_reformat[col]))))
    
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())\
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"]))\
.withColumn("madr_pullback_dttm",to_timestamp(etl_tbf0_reformat["madr_pullback_dttm"]))\
.withColumn("src_create_dttm",to_timestamp(etl_tbf0_reformat["src_create_dttm"]))\
.withColumn("src_update_dttm",to_timestamp(etl_tbf0_reformat["src_update_dttm"]))

etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)


# COMMAND ----------

#Load ETL_TBF0_PATIENT_MERGE formatted records to the Snowflake Table
#etl_tbf0_reformat_cdc_check_notnull.selectExpr()
#TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+'.TL_'+SNFL_TBL_NAME.split(".")[1]
print(SNFL_TBL_NAME)
etl_tbf0_reformat_cdc_check_notnull=etl_tbf0_reformat_cdc_check_notnull.withColumn("TRACKING_ID",lit("1"))
etl_tbf0_reformat_cdc_check_notnull.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("usestagingtable","OFF")\
    .mode("overwrite") \
    .save()

# COMMAND ----------

 
PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_ASSET_STATUS='200'
#dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/Ingestion_Framework/UpdateProcessedFilesStatus", 200, 
                  {"PAR_ASSET_STATUS":PAR_ASSET_STATUS,
                   "PAR_FEED_NAMES":FEED_NAME,
                   "PAR_PIPELINE_NAME":PAR_PIPELINE_NAME,
                   "PAR_SQL_SERVER":PAR_SQL_SERVER,
                   "PAR_SQL_SERVER_AD_CLIENT_ID":PAR_SQL_SERVER_AD_CLIENT_ID,
                   "PAR_SQL_SERVER_AD_CLIENT_SECRET":PAR_SQL_SERVER_AD_CLIENT_SECRET,
                   "PAR_SQL_SERVER_DB":PAR_SQL_SERVER_DB,
                   "PAR_WRITEAPI_URL":PAR_WRITEAPI_URL})
                   
print("Write API successfully executed...")

# COMMAND ----------



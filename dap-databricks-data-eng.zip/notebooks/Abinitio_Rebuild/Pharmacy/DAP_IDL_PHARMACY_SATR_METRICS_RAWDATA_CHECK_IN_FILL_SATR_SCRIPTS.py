# Databricks notebook source
'''
dbutils.widgets.text("PAR_DF_PRESCRIPTION_FILL_TBL","PATIENT_SERVICES.PRESCRIPTION_FILL")
dbutils.widgets.text("PAR_DF_PHC_DB","DEV_PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_DF_PHARMACY_SCHEMA","PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_DF_STG_TABLE_1","TEMP_SATR_EXTRACTL_STG")
dbutils.widgets.text("PAR_DF_STG_TABLE_2","ADHOC_SATR_FILLED_RXL_STG")
dbutils.widgets.text("PAR_DF_STG_TABLE_3","ADHOC_SATR_NOT_FILLED_RXL_STG")
dbutils.widgets.text("PAR_DF_STG_DB","DEV_STAGING")
dbutils.widgets.text("PAR_DF_EXEC_WK_START_DT","2022-05-15")
dbutils.widgets.text("PAR_DF_EXEC_WK_END_DT","2022-05-21")
dbutils.widgets.text("PAR_DF_PRESCRIPTION_FILL_PLAN_TBL","PATIENT_SERVICES.PRESCRIPTION_FILL_PLAN")
dbutils.widgets.text("PAR_DF_PATIENT_TBL","PATIENT.PATIENT")
dbutils.widgets.text("PAR_DF_BATCH_ID","20220606000000")
dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
'''





PAR_PRESCRIPTION_FILL_TBL=dbutils.widgets.get("PAR_DF_PRESCRIPTION_FILL_TBL")
PAR_PHC_DB=dbutils.widgets.get("PAR_DF_PHC_DB")
PAR_PHARMACY_SCHEMA=dbutils.widgets.get("PAR_DF_PHARMACY_SCHEMA")
PAR_STG_TABLE_1=dbutils.widgets.get("PAR_DF_STG_TABLE_1")
PAR_STG_TABLE_2=dbutils.widgets.get("PAR_DF_STG_TABLE_2")
PAR_STG_TABLE_3=dbutils.widgets.get("PAR_DF_STG_TABLE_3")
PAR_STG_DB=dbutils.widgets.get("PAR_DF_STG_DB")
PAR_EXEC_WK_START_DT=dbutils.widgets.get("PAR_DF_EXEC_WK_START_DT")
PAR_EXEC_WK_END_DT=dbutils.widgets.get("PAR_DF_EXEC_WK_END_DT")
PAR_PRESCRIPTION_FILL_PLAN_TBL=dbutils.widgets.get("PAR_DF_PRESCRIPTION_FILL_PLAN_TBL")
PAR_PATIENT_TBL=dbutils.widgets.get("PAR_DF_PATIENT_TBL")
PAR_BATCH_ID=dbutils.widgets.get("PAR_DF_BATCH_ID")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")



# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=PAR_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

query1="""  
select	
 tsat.rx_nbr
,tsat.store_nbr
,tsat.pickup_store_nbr
,pfill.rx_fill_nbr
,pfill.dspn_fill_nbr
,pfill.fill_qty_dspn
,pfill.update_dttm
,pfill.fill_sold_dt
,pfill.fill_est_pick_up_dttm
,pfill.fill_enter_dt
,pfill.fill_enter_user_id
,pfill.fill_vrfy_dt
,pfill.fill_stat_cd
,pfill.fill_vrfy_user_id
,pfill.fill_print_dt
,pfill.fill_days_supply
,pfill.drug_id
,pfill.drug_name
,pfill.fill_type_cd
,coalesce(pfp.third_party_plan_id, '') as third_party_plan_id
,pfp.plan_group_nbr
,pfp.bin_nbr
,pfp.prcs_ctrl_nbr
,pat.first_name
,pat.last_name
,pat.gndr_cd
,pat.brth_dt
,tsat.pat_id
,tsat.work_order
,tsat.expected_fill_enter_dt
,tsat.max_fill_enter_dt
,tsat.orig_fill_dspn_qnty
  from	{0}.{1} pfill 
  inner join {2}.{7}.{3} tsat 
	on	tsat.rx_nbr=pfill.rx_nbr 
	and	tsat.store_nbr=pfill.str_nbr
	and pfill.fill_sold_dt>=CAST('{4}'  as date) 
	and	pfill.fill_enter_dt>=CAST('{4}'  as date)
 left outer join {0}.{5} pfp
        on      pfill.rx_nbr = pfp.rx_nbr
        and     pfill.str_nbr = pfp.str_nbr
        and     pfill.rx_fill_nbr = pfp.rx_fill_nbr
        and pfp.cob_ind = 'N'
left outer join {0}.{6} pat
        on tsat.pat_id = pat.pat_id
UNION	
select	
 tsat.rx_nbr
,tsat.store_nbr
,tsat.pickup_store_nbr
,pfill.rx_fill_nbr
,pfill.dspn_fill_nbr
,pfill.fill_qty_dspn
,pfill.update_dttm
,pfill.fill_sold_dt
,pfill.fill_est_pick_up_dttm
,pfill.fill_enter_dt
,pfill.fill_enter_user_id
,pfill.fill_vrfy_dt
,pfill.fill_stat_cd
,pfill.fill_vrfy_user_id
,pfill.fill_print_dt
,pfill.fill_days_supply
,pfill.drug_id
,pfill.drug_name
,pfill.fill_type_cd
,coalesce(pfp.third_party_plan_id, '') as third_party_plan_id
,pfp.plan_group_nbr
,pfp.bin_nbr
,pfp.prcs_ctrl_nbr
,pat.first_name
,pat.last_name
,pat.gndr_cd
,pat.brth_dt
,tsat.pat_id
,tsat.work_order
,tsat.expected_fill_enter_dt
,tsat.max_fill_enter_dt
,tsat.orig_fill_dspn_qnty
  from	{0}.{1} pfill 
  inner join {2}.{7}.{3} tsat 
	on	tsat.rx_nbr=pfill.rx_nbr 
	and	tsat.store_nbr=pfill.str_nbr
	and pfill.fill_sold_dt is null 
	and	pfill.fill_enter_dt>= CAST('{4}'  as date)
  left outer join {0}.{5} pfp
        on      pfill.rx_nbr = pfp.rx_nbr
        and     pfill.str_nbr = pfp.str_nbr
        and     pfill.rx_fill_nbr = pfp.rx_fill_nbr
        and pfp.cob_ind = 'N'
left outer join {0}.{6} pat
        on tsat.pat_id = pat.pat_id
""".format(PAR_PHC_DB,PAR_PRESCRIPTION_FILL_TBL,PAR_STG_DB,PAR_STG_TABLE_1,PAR_EXEC_WK_START_DT,PAR_PRESCRIPTION_FILL_PLAN_TBL,PAR_PATIENT_TBL,PAR_PHARMACY_SCHEMA)
print(query1)


# COMMAND ----------

df_q1_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query1)\
   .load()
#df_q1_out.show()

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.sql.functions import *

df_q1_out=df_q1_out.select([F.col(x).alias(x.lower()) for x in df_q1_out.columns])
#df_q1_out.show()

# COMMAND ----------

df_filter1=df_q1_out.filter(  (col("fill_enter_dt").isNotNull()) & (col("fill_enter_dt") >= col("expected_fill_enter_dt"))  & (col("fill_enter_dt") < col("max_fill_enter_dt")) & (F.datediff(col("fill_enter_dt"),col("expected_fill_enter_dt")) < 5)    )
#print(df_filter1.count())
#df_sort1=df_filter1.sort("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr","rx_fill_nbr")

# COMMAND ----------

'''
df_fi_vdt=df_sort1.groupBy("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr").agg(last("fill_vrfy_dt",ignorenulls=True).alias("derv_fi_vdt"))
#display(df_fi_vdt)
df_r1=df_sort1.alias("in0").join(df_fi_vdt.alias("in1"), (  (df_sort1.store_nbr==df_fi_vdt.store_nbr)  &       (df_sort1.rx_nbr==df_fi_vdt.rx_nbr)  &  (df_sort1.expected_fill_enter_dt==df_fi_vdt.expected_fill_enter_dt)  &  (df_sort1.dspn_fill_nbr==df_fi_vdt.dspn_fill_nbr)) , "inner").select(col("in0.*"),col("in1.derv_fi_vdt")).drop(col("fill_vrfy_dt")).withColumn("fill_vrfy_dt",col("derv_fi_vdt")).drop(col("derv_fi_vdt"))
#display(df_r1)
'''
from pyspark.sql.window import Window
windowSpec  = Window.partitionBy("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr").orderBy("rx_fill_nbr")

df_r1=df_filter1.withColumn("fill_vrfy_dt",last("fill_vrfy_dt",ignorenulls=True).over(windowSpec))


# COMMAND ----------

df_r1=df_r1.sort("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr","rx_fill_nbr")
df_r1.cache()
df_g1_51=df_r1.filter(df_r1.fill_enter_user_id==51).groupBy("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr").agg(last("fill_enter_user_id",ignorenulls=True).alias("derv_fill_enter_user_id"),last("fill_enter_dt",ignorenulls=True).alias("derv_fill_enter_dt"))
#display(df_g1_51)
df_tg=df_r1.select("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr").distinct()
#print(df_tg.count())
df_g1=df_g1_51.select("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr").distinct()
#print(df_g1.count())
df_g2=df_tg.exceptAll(df_g1)
#print(df_g2.count())

# COMMAND ----------

df_g2_join=df_r1.alias("in0").join(df_g2.alias("in1"),  (  (df_r1.store_nbr==df_g2.store_nbr)  &       (df_r1.rx_nbr==df_g2.rx_nbr)  &  (df_r1.expected_fill_enter_dt==df_g2.expected_fill_enter_dt)  &  (df_r1.dspn_fill_nbr==df_g2.dspn_fill_nbr)) , "inner").select(col("in0.*"))
#df_g2_join=df_g2_join.sort("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr","rx_fill_nbr")

# COMMAND ----------

'''
df_g2_join1=df_g2_join.groupBy("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr").agg(first("fill_enter_user_id",ignorenulls=True).alias("derv_fill_enter_user_id"),first("fill_enter_dt",ignorenulls=True).alias("derv_fill_enter_dt"))
'''
#display(df_g2_join1)

# COMMAND ----------

df_u1=df_r1.alias("in0").join(df_g1_51.alias("in1"), (  (df_r1.store_nbr==df_g1_51.store_nbr)  &       (df_r1.rx_nbr==df_g1_51.rx_nbr)  &  (df_r1.expected_fill_enter_dt==df_g1_51.expected_fill_enter_dt)  &  (df_r1.dspn_fill_nbr==df_g1_51.dspn_fill_nbr)) , "inner").select(col("in0.*"),col("in1.derv_fill_enter_user_id"),col("in1.derv_fill_enter_dt")).drop(col("fill_enter_user_id")).drop(col("fill_enter_dt")).withColumn("fill_enter_user_id",col("derv_fill_enter_user_id")) \
.withColumn("fill_enter_dt",col("derv_fill_enter_dt")).drop(col("derv_fill_enter_user_id")).drop(col("derv_fill_enter_dt"))
df_u2=df_g2_join.withColumn("fill_enter_user_id",first("fill_enter_user_id").over(windowSpec)).withColumn("fill_enter_dt",first("fill_enter_dt").over(windowSpec))
#display(df_u1)
'''
df_u2=df_r1.alias("in0").join(df_g2_join1.alias("in1"), (  (df_r1.store_nbr==df_g2_join1.store_nbr)  &       (df_r1.rx_nbr==df_g2_join1.rx_nbr)  &  (df_r1.expected_fill_enter_dt==df_g2_join1.expected_fill_enter_dt)  &  (df_r1.dspn_fill_nbr==df_g2_join1.dspn_fill_nbr)) , "inner").select(col("in0.*"),col("in1.derv_fill_enter_user_id"),col("in1.derv_fill_enter_dt")).drop(col("fill_enter_user_id")).drop(col("fill_enter_dt")).withColumn("fill_enter_user_id",col("derv_fill_enter_user_id")) \
.withColumn("fill_enter_dt",col("derv_fill_enter_dt")).drop(col("derv_fill_enter_user_id")).drop(col("derv_fill_enter_dt"))
'''
#display(df_u2)
df_sel=df_u1.unionByName(df_u2)
#display(df_sel)

# COMMAND ----------

#print(df_sel.count())

# COMMAND ----------

#dedup

df_sort2=df_sel.sort("store_nbr","rx_nbr","expected_fill_enter_dt","dspn_fill_nbr")
df_dedup1 = df_sort2.dropDuplicates(['store_nbr', 'rx_nbr', 'expected_fill_enter_dt'])

# COMMAND ----------

df_filter_deselect=df_dedup1.filter(col("fill_stat_cd")!='DL')
df_filter_select=df_dedup1.filter(col("fill_stat_cd")=='DL')

# COMMAND ----------

query2="""  select * from {0}.{1}.{2}
""".format(PAR_STG_DB,PAR_PHARMACY_SCHEMA,PAR_STG_TABLE_1)
print(query2)


# COMMAND ----------

df_q2_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query2)\
   .load()
#df_q2_out.show()

# COMMAND ----------



df_q2_out=df_q2_out.select([F.col(x).alias(x.lower()) for x in df_q2_out.columns])
#df_q2_out.show()

# COMMAND ----------

df_sort3=df_q2_out.sort("store_nbr","rx_nbr","expected_fill_enter_dt")

# COMMAND ----------

df_join1=df_filter_deselect.alias("in0").join(df_sort3.alias("in1"),( (df_filter_deselect.store_nbr ==  df_sort3.store_nbr) &  (df_filter_deselect.rx_nbr ==  df_sort3.rx_nbr) & (df_filter_deselect.expected_fill_enter_dt ==  df_sort3.expected_fill_enter_dt) ),"inner").select(col("in0.*"))

# COMMAND ----------

df_union1=df_join1.unionByName(df_filter_select,allowMissingColumns = True)
#display(df_union1)

# COMMAND ----------

df_join2=df_sort3.alias("in0").join(df_filter_deselect.alias("in1"),( (df_filter_deselect.store_nbr ==  df_sort3.store_nbr) &  (df_filter_deselect.rx_nbr ==  df_sort3.rx_nbr) & (df_filter_deselect.expected_fill_enter_dt ==  df_sort3.expected_fill_enter_dt) ),"leftanti").select(col("in0.*"))

#display(df_join2)

# COMMAND ----------

delete_gg_snowflake_tl = "Truncate table {0}.{1}".format(PAR_STG_DB, PAR_PHARMACY_SCHEMA+"."+PAR_STG_TABLE_2)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake_tl, "transaction" : True, "SNOWFLAKE_DATABASE" : PAR_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

##Populating the ADHOC_SATR_FILLED_RXL_STG table

df_final_satr_fil=df_union1.select("rx_nbr", "store_nbr", "pickup_store_nbr", "rx_fill_nbr", "dspn_fill_nbr", "fill_qty_dspn", "update_dttm", "fill_sold_dt", "fill_est_pick_up_dttm", "fill_enter_dt", "fill_enter_user_id", "fill_vrfy_dt", "fill_stat_cd", "fill_vrfy_user_id", "fill_print_dt", "fill_days_supply", "drug_id", "drug_name", "fill_type_cd", "third_party_plan_id", "plan_group_nbr", "bin_nbr", "prcs_ctrl_nbr", "first_name", "last_name", "gndr_cd", "brth_dt", "pat_id", "work_order", "expected_fill_enter_dt", "max_fill_enter_dt", "orig_fill_dspn_qnty")
df_final_satr_fil=df_final_satr_fil.select([F.col(x).alias(x.upper()) for x in df_final_satr_fil.columns])
#display(df_final_satr_fil)

df_final_satr_fil.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", PAR_STG_DB) \
        .option("dbtable",  PAR_PHARMACY_SCHEMA+"."+PAR_STG_TABLE_2) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()


# COMMAND ----------

delete_gg_snowflake_tl = "Truncate table {0}.{1}".format(PAR_STG_DB, PAR_PHARMACY_SCHEMA+"."+PAR_STG_TABLE_3)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake_tl, "transaction" : True, "SNOWFLAKE_DATABASE" : PAR_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

##Populating the ADHOC_SATR_NOT_FILLED_RXL_STG table
df_final_satr_not_fil=df_join2.select("pat_id", "store_nbr", "pickup_store_nbr", "rx_nbr", "work_order", "expected_fill_enter_dt", "max_fill_enter_dt","orig_fill_dspn_qnty"  )
df_final_satr_not_fil=df_final_satr_not_fil.select([F.col(x).alias(x.upper()) for x in df_final_satr_not_fil.columns])

#display(df_final_satr_not_fil)

df_final_satr_not_fil.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", PAR_STG_DB) \
        .option("dbtable",  PAR_PHARMACY_SCHEMA+"."+PAR_STG_TABLE_3) \
        .option("ON_ERROR","SKIP_FILE")\
        .save()

# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220329144200")
# dbutils.widgets.text("PAR_DB_ETL_TBL_NAME","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_DB_JOB_ID","WALGREENS")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","etl_tbf0_exception")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","pharmacy_healthcare/patient_services/output")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","pharmacy_healthcare/patient_services/reject")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_EXCEPTION_STG")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SRC_TBL_NAME","gg_tbf0_exception")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_EXCEPTION")
# dbutils.widgets.text("PAR_PIPELINE_NAME","PL_MSTR_PHARMACY_AND_HEALTHCARE_PATIENT_SERVICES_ETL_TBF0_EXCEPTION_LOAD")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_SQL_SERVER","dapdevsqlsrv01.database.windows.net")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_ID","sqldbapplicationid")
# dbutils.widgets.text("PAR_SQL_SERVER_AD_CLIENT_SECRET","devdnasqldb")
# dbutils.widgets.text("PAR_SQL_SERVER_DB","dapdevsqldb01")
# dbutils.widgets.text("PAR_UnprocessedFiles","1")
# dbutils.widgets.text("PAR_WRITEAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate")


# COMMAND ----------

# ReadAPI Call to fetch asset file names with current location:  
FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")

Input_File_List = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/ReadAPINative", 600, 
                  {"PAR_READAPI_KEY":"feedNames",
                   "PAR_READAPI_URL":READAPI_URL,
                   "PAR_READAPI_VALUE":FEED_NAME,
                   "PAR_RETURN_FILE_TYPE":"A"});


print(Input_File_List)


# COMMAND ----------

# initializing variables


#dbutils.widgets.text("PAR_WRITEAPI_URL","DEV_ETL")
#dbutils.widgets.remove("PAR_DB_FILE_LIST")

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_FILE_PATH")
#IN_FILE = dbutils.widgets.get("PAR_DB_FILE_NAME")
PROJ_ID = dbutils.widgets.get("PAR_DB_JOB_ID")
SRC_TBL_NAME = dbutils.widgets.get("PAR_DB_SRC_TBL_NAME")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_TBL_NAME = dbutils.widgets.get("PAR_DB_ETL_TBL_NAME")

#IN_DATAFILE = mountPoint + '/'+ IN_PATH + '/' + IN_FILE
OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
# REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

print (OUT_FILEPATH)
# print (REJ_FILEPATH)
print(REJ_BAD_FILEPATH)
print(REJ_SHORT_FILEPATH)


# COMMAND ----------

# Reading File Names from Control File:
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os

GG_Control_FEEDNAME = FEED_NAME.split(",")[1]
print(GG_Control_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_Control_FEEDNAME,explode(col(GG_Control_FEEDNAME))) \
                                            .select(f"{GG_Control_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_Control_FEEDNAME}.assetid",
                                                   f"{GG_Control_FEEDNAME}.assetname")
#display(dfFileList)
dfRaw_control = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw_control)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= str(dfAssetIdArray).replace("[","").replace("]","")+","
dfAssetIdStrCntrl=dfAssetIdStr
print(dfAssetIdStrCntrl)

if(len(dfAssetIdArray)!=4):
  print("number of control files are not as expected")
  10/0

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw_control\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

readList_Control=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

Control_file = spark.read.text(readList_Control).rdd.map(lambda x: x[0]).map(lambda x : x.split("\"")).collect()
Control_file_list = []

for i in range(0,len(Control_file)):
  for j in Control_file[i]:
    if j!='':
      Control_file_list.append(j.split(","))
      
#print(Control_file_list)

gg_file_list = []

for i in range(0,len(Control_file_list)):
  for j in Control_file_list[i]:
    if j!='':
      gg_file_list.append(j.split("/")[2].split(".")[0])
      
print(gg_file_list)
#print(type(gg_file_list))

# COMMAND ----------

##Convert json asset location/filname to Multi FIle Name List

#inputFileList= dbutils.widgets.get("PAR_DB_FILE_LIST")
GG_File_FEEDNAME = FEED_NAME.split(",")[0]
print(GG_File_FEEDNAME)

rddjson = sc.parallelize([Input_File_List])

dfFileList = sqlContext.read.json(rddjson).withColumn(GG_File_FEEDNAME,explode(col(GG_File_FEEDNAME))) \
                                            .select(f"{GG_File_FEEDNAME}.assetcurrentlocation",
                                                   f"{GG_File_FEEDNAME}.assetid",
                                                   f"{GG_File_FEEDNAME}.assetname")
#display(dfFileList)
#print(gg_file_list)
flag=0
for FileName in gg_file_list:
    
    df_gg_file_final = dfFileList.where("assetname like '%{0}%' ".format(FileName))
    if flag==0:
      df_gg_file_final_1=df_gg_file_final
      flag=flag+1
    if df_gg_file_final.count!=0:
      df_gg_file_final_1=df_gg_file_final_1.union(df_gg_file_final)

df_gg_file_final_1 = df_gg_file_final_1.distinct()      
#display(df_gg_file_final_1)
dfRaw = df_gg_file_final_1.select(concat(lit('/'),df_gg_file_final_1.assetcurrentlocation,lit('/'),df_gg_file_final_1.assetname).alias('full_filename'))
#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = df_gg_file_final_1.select(df_gg_file_final_1.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr= dfAssetIdStrCntrl+str(dfAssetIdArray).replace("[","").replace("]","")
dfAssetIdStr=dfAssetIdStr.replace(" ","")
print(dfAssetIdStr)

# COMMAND ----------

if dfRaw.count()!=len(gg_file_list):
  print("Number of files doesnt match with Control Files")
  10/0

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

readList=[mountPoint + row[0] + row[1] for row in dfNamePath.select('filepath','filename').collect()]

print(readList)

# COMMAND ----------

from  pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce

#adding extra column row_length to filter short/invalid schema records
fieldList = ['row_length',
'cdc_txn_commit_dttm',
'cdc_txn_commit_dttm_after',
'cdc_seq_nbr',
'cdc_seq_nbr_after',
'cdc_rba_nbr',
'cdc_rba_nbr_after',
'cdc_operation_type_cd',
'cdc_operation_type_cd_after',
'cdc_before_after_cd',
'cdc_before_after_cd_after',
'cdc_txn_position_cd',
'cdc_txn_position_cd_after',
'edw_batch_id',
'edw_batch_id_after',
'src_partition_nbr',
'src_partition_nbr_after',
'store_nbr',
'store_nbr_after',
'rx_nbr',
'rx_nbr_after',
'fill_nbr',
'fill_nbr_after',
'fill_partial_nbr',
'fill_partial_nbr_after',
'exc_nbr',
'exc_nbr_after',
'exc_reason_cd',
'exc_reason_cd_after',
'contacted_by_cd',
'contacted_by_cd_after',
'emergency_quantity',
'emergency_quantity_after',
'pbr_auth_full_name',
'pbr_auth_full_name_after',
'msg_pbr_full_name',
'msg_pbr_full_name_after',
'exc_critical_dttm',
'exc_critical_dttm_after',
'exc_reason_update_dttm',
'exc_reason_update_dttm_after',
'exc_sub_type_ind',
'exc_sub_type_ind_after',
'fill_deleted_ind',
'fill_deleted_ind_after',
'max_ldr_type_sevr_cd',
'max_ldr_type_sevr_cd_after',
'max_ldr_type_cd',
'max_ldr_type_cd_after',
'prescribe_auth_id',
'prescribe_auth_id_after',
'msg_cmts',
'msg_cmts_after',
'pbr_phone_cmts',
'pbr_phone_cmts_after',
'prescribe_reply_cd',
'prescribe_reply_cd_after',
'prescribe_refills_added',
'prescribe_refills_added_after',
'refills_added',
'refills_added_after',
'resubmit_dttm',
'resubmit_dttm_after',
'sold_thrd_pty_rej_ind',
'sold_thrd_pty_rej_ind_after',
'exc_cmt',
'exc_cmt_after',
'exc_status_update_dttm',
'exc_status_update_dttm_after',
'exc_resolution_cd',
'exc_resolution_cd_after',
'exc_resolution_dttm',
'exc_resolution_dttm_after',
'exc_resolution_user_id',
'exc_resolution_user_id_after',
'exc_status_cd',
'exc_status_cd_after',
'create_dttm',
'create_dttm_after',
'create_user_id',
'create_user_id_after',
'update_dttm',
'update_dttm_after',
'update_user_id',
'update_user_id_after',
'em_selected_ind',
'em_selected_ind_after',
'epa_reply_msg',
'epa_reply_msg_after',
'epa_status',
'epa_status_after',
'equivalent_generic_copay',
'equivalent_generic_copay_after',
'exc_ccp_response',
'exc_ccp_response_after',
'last_action_dttm',
'last_action_dttm_after',
'workstation_locked_ip',
'workstation_locked_ip_after',
'fax_image_id',
'fax_image_id_after',
'tpr_status_cd',
'tpr_status_cd_after',
'tpr_assignment_cd',
'tpr_assignment_cd_after',
'tpr_status_update_dttm',
'tpr_status_update_dttm_after',
'reh_resubmit_dttm',
'reh_resubmit_dttm_after'
]


# COMMAND ----------

#Add Insert for length of columns to DF
def addlistlength(lst) :
  lst1 = list(lst)
  if  len(lst1) > 6 and lst[6] == '"INSERT"':
    lst1.insert(6, '"INSERT"')
  list_len = len(lst1)
  lst1.insert(0, list_len)
  return tuple(lst1)

# COMMAND ----------

#Check invalid schema records records
def checkbad(val):
  key_list = val.split("^|~")
  val_len = len(key_list)
  
  if val_len <= 6:
    return True
  
  if '"INSERT"' in key_list[6]:
    if val_len != 107 :
      return True
  elif '"SQL COMPUPDATE"' in key_list[6] or '"PK UPDATE"' in key_list[6]:
    if val_len != 108:
      return True
  else:
    if val_len != 108:
      return True


# COMMAND ----------

# Read files
in_text = spark.read.text(readList)

in_text = in_text.rdd

# COMMAND ----------

# write bad data

rdb = in_text.filter(lambda x: checkbad(x[0]))

print(rdb.count())

if rdb.count()>0:
  df_junk = spark.createDataFrame(rdb)
  df_junk.write.mode('overwrite').parquet(REJ_SHORT_FILEPATH)



# COMMAND ----------

#split and add schema
col_len =108

rd1 = in_text.map(lambda rw: rw[0].split("^|~")).map(lambda lst : addlistlength(lst))

print(rd1.count())

rd_good = rd1.filter(lambda x: x[0] == col_len)
rd_bad = rd1.filter(lambda x: x[0] != col_len)

print(f"Good records count {rd_good.count()}") # = 108
print(f"Bad records count {rd_bad.count()}") # != 108


schema = StructType(list(map(lambda fl : StructField(fl,StringType(),False) ,fieldList )))


# COMMAND ----------

#Extarct filename
from pyspark.sql.functions import input_file_name
df = spark.createDataFrame(rd_good, schema)
df_fileName = df.withColumn("fileName",input_file_name())

#Extract partition number from file name
df_split = df_fileName.withColumn("src_partition_nbr",concat(lit("\""),split(col("fileName"),"_")[5],lit("\"")))
df_split = df_split.withColumn("src_partition_nbr_after",col("src_partition_nbr"))
df_split = df_split.drop("fileName")

# COMMAND ----------

#function to remove "" & \\
def handlEscpeQuotes(val):
  
  if not val:
    return ""
  
  #remove rightmost "
  outval = val[0:-1]
  #remove leftmost "
  outval = outval.lstrip("\"")
  #replace double \\ with \
  outval = outval.replace("\\\\","\\")
  #replace double \" with "
  outval = outval.replace("\\\"","\"")
  return outval

udf_handlEscpeQuotes = udf(handlEscpeQuotes)

# COMMAND ----------

df_split = df_split.drop('row_length')
df_split = (reduce(
    lambda memo_df, col_name: memo_df.withColumn(col_name, udf_handlEscpeQuotes(col(col_name))),
    df_split.columns,
    df_split
))

# COMMAND ----------

display(df_split)

# COMMAND ----------

df_split.createOrReplaceTempView("gg_tbf0_exception")

# COMMAND ----------

#Picking up bad records
dfBad = spark.sql("select * from gg_tbf0_exception where (cdc_operation_type_cd is null) or (cdc_operation_type_cd != 'SQL COMPUPDATE' and cdc_operation_type_cd != 'PK UPDATE' and cdc_operation_type_cd != 'INSERT')")



print(f"Bad records count {dfBad.count()}")

dfB = dfBad.write.mode('overwrite').parquet(REJ_BAD_FILEPATH)

# COMMAND ----------

df_gg = df_split.withColumn("table_name",lit("gg_tbf0_exception"))\
          
df_gg.createOrReplaceTempView("raw_gg_tbf0_exception")

# COMMAND ----------

pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')"  

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')"

#pSrcCleanseXfr

pUpdateReform="( (cdc_before_after_cd_after == 'AFTER' AND cdc_before_after_cd_after IS NOT NULL)  AND ( cdc_operation_type_cd_after  == 'SQL COMPUPDATE'  AND cdc_operation_type_cd_after IS NOT NULL) AND (cdc_before_after_cd == 'BEFORE' AND cdc_before_after_cd IS NOT NULL) AND (cdc_operation_type_cd  == 'SQL COMPUPDATE' AND cdc_operation_type_cd IS NOT NULL ) AND store_nbr == store_nbr_after AND  store_nbr IS NOT NULL AND  store_nbr_after IS NOT NULL AND   rx_nbr == rx_nbr_after AND  rx_nbr IS NOT NULL AND  rx_nbr_after IS NOT NULL AND   fill_nbr == fill_nbr_after AND  fill_nbr IS NOT NULL AND  fill_nbr_after IS NOT NULL AND   fill_partial_nbr == fill_partial_nbr_after AND  fill_partial_nbr IS NOT NULL AND  fill_partial_nbr_after IS NOT NULL AND  exc_nbr == exc_nbr_after AND  exc_nbr IS NOT NULL AND  exc_nbr_after IS NOT NULL AND   cdc_seq_nbr == cdc_seq_nbr_after AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL AND   cdc_rba_nbr == cdc_rba_nbr_after AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL AND   cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL AND   ( (exc_reason_cd == exc_reason_cd_after AND  exc_reason_cd IS NOT NULL AND  exc_reason_cd_after IS NOT NULL ) OR ( exc_reason_cd IS NULL AND   exc_reason_cd_after IS NULL ) ) AND   ( (create_dttm == create_dttm_after AND  create_dttm IS NOT NULL AND  create_dttm_after IS NOT NULL ) OR ( create_dttm IS NULL AND   create_dttm_after IS NULL ) ) AND   ( (exc_ccp_response == exc_ccp_response_after AND  exc_ccp_response IS NOT NULL AND  exc_ccp_response_after IS NOT NULL ) OR ( exc_ccp_response IS NULL AND   exc_ccp_response_after IS NULL ) ) AND   ( (RTRIM(LOWER(exc_cmt)) == RTRIM(LOWER(exc_cmt_after)) AND  exc_cmt IS NOT NULL AND  exc_cmt_after IS NOT NULL ) OR ( exc_cmt IS NULL AND   exc_cmt_after IS NULL ) ) AND   ( (exc_resolution_cd == exc_resolution_cd_after AND  exc_resolution_cd IS NOT NULL AND  exc_resolution_cd_after IS NOT NULL ) OR ( exc_resolution_cd IS NULL AND   exc_resolution_cd_after IS NULL ) ) AND   ( (exc_resolution_user_id == exc_resolution_user_id_after AND  exc_resolution_user_id IS NOT NULL AND  exc_resolution_user_id_after IS NOT NULL ) OR ( exc_resolution_user_id IS NULL AND   exc_resolution_user_id_after IS NULL ) ) AND   ( (exc_resolution_dttm == exc_resolution_dttm_after AND  exc_resolution_dttm IS NOT NULL AND  exc_resolution_dttm_after IS NOT NULL ) OR ( exc_resolution_dttm IS NULL AND   exc_resolution_dttm_after IS NULL ) ) AND   ( (exc_critical_dttm == exc_critical_dttm_after AND  exc_critical_dttm IS NOT NULL AND  exc_critical_dttm_after IS NOT NULL ) OR ( exc_critical_dttm IS NULL AND   exc_critical_dttm_after IS NULL ) ) AND   ( (fill_deleted_ind == fill_deleted_ind_after AND  fill_deleted_ind IS NOT NULL AND  fill_deleted_ind_after IS NOT NULL ) OR ( fill_deleted_ind IS NULL AND   fill_deleted_ind_after IS NULL ) ) AND   ( (max_ldr_type_cd == max_ldr_type_cd_after AND  max_ldr_type_cd IS NOT NULL AND  max_ldr_type_cd_after IS NOT NULL ) OR ( max_ldr_type_cd IS NULL AND   max_ldr_type_cd_after IS NULL ) ) AND   ( (max_ldr_type_sevr_cd == max_ldr_type_sevr_cd_after AND  max_ldr_type_sevr_cd IS NOT NULL AND  max_ldr_type_sevr_cd_after IS NOT NULL ) OR ( max_ldr_type_sevr_cd IS NULL AND   max_ldr_type_sevr_cd_after IS NULL ) ) AND   ( (refills_added == refills_added_after AND  refills_added IS NOT NULL AND  refills_added_after IS NOT NULL ) OR ( refills_added IS NULL AND   refills_added_after IS NULL ) ) AND   ( (prescribe_refills_added == prescribe_refills_added_after AND  prescribe_refills_added IS NOT NULL AND  prescribe_refills_added_after IS NOT NULL ) OR ( prescribe_refills_added IS NULL AND   prescribe_refills_added_after IS NULL ) ) AND   ( (prescribe_reply_cd == prescribe_reply_cd_after AND  prescribe_reply_cd IS NOT NULL AND  prescribe_reply_cd_after IS NOT NULL ) OR ( prescribe_reply_cd IS NULL AND   prescribe_reply_cd_after IS NULL ) ) AND   ( (msg_cmts == msg_cmts_after AND  msg_cmts IS NOT NULL AND  msg_cmts_after IS NOT NULL ) OR ( msg_cmts IS NULL AND   msg_cmts_after IS NULL ) ) AND   ( (prescribe_auth_id == prescribe_auth_id_after AND  prescribe_auth_id IS NOT NULL AND  prescribe_auth_id_after IS NOT NULL ) OR ( prescribe_auth_id IS NULL AND   prescribe_auth_id_after IS NULL ) ) AND   ( (exc_reason_update_dttm == exc_reason_update_dttm_after AND  exc_reason_update_dttm IS NOT NULL AND  exc_reason_update_dttm_after IS NOT NULL ) OR ( exc_reason_update_dttm IS NULL AND   exc_reason_update_dttm_after IS NULL ) ) AND   ( (contacted_by_cd == contacted_by_cd_after AND  contacted_by_cd IS NOT NULL AND  contacted_by_cd_after IS NOT NULL ) OR ( contacted_by_cd IS NULL AND   contacted_by_cd_after IS NULL ) ) AND   ( (resubmit_dttm == resubmit_dttm_after AND  resubmit_dttm IS NOT NULL AND  resubmit_dttm_after IS NOT NULL ) OR ( resubmit_dttm IS NULL AND   resubmit_dttm_after IS NULL ) ) AND   ( (sold_thrd_pty_rej_ind == sold_thrd_pty_rej_ind_after AND  sold_thrd_pty_rej_ind IS NOT NULL AND  sold_thrd_pty_rej_ind_after IS NOT NULL ) OR ( sold_thrd_pty_rej_ind IS NULL AND   sold_thrd_pty_rej_ind_after IS NULL ) ) AND   ( (exc_status_cd == exc_status_cd_after AND  exc_status_cd IS NOT NULL AND  exc_status_cd_after IS NOT NULL ) OR ( exc_status_cd IS NULL AND   exc_status_cd_after IS NULL ) ) AND   ( (exc_status_update_dttm == exc_status_update_dttm_after AND  exc_status_update_dttm IS NOT NULL AND  exc_status_update_dttm_after IS NOT NULL ) OR ( exc_status_update_dttm IS NULL AND   exc_status_update_dttm_after IS NULL ) ) AND   ( (pbr_phone_cmts == pbr_phone_cmts_after AND  pbr_phone_cmts IS NOT NULL AND  pbr_phone_cmts_after IS NOT NULL ) OR ( pbr_phone_cmts IS NULL AND   pbr_phone_cmts_after IS NULL ) ) AND   ( (em_selected_ind == em_selected_ind_after AND  em_selected_ind IS NOT NULL AND  em_selected_ind_after IS NOT NULL ) OR ( em_selected_ind IS NULL AND   em_selected_ind_after IS NULL ) ) AND   ( (exc_sub_type_ind == exc_sub_type_ind_after AND  exc_sub_type_ind IS NOT NULL AND  exc_sub_type_ind_after IS NOT NULL ) OR ( exc_sub_type_ind IS NULL AND   exc_sub_type_ind_after IS NULL ) ) AND   ( (emergency_quantity == emergency_quantity_after AND  emergency_quantity IS NOT NULL AND  emergency_quantity_after IS NOT NULL ) OR ( emergency_quantity IS NULL AND   emergency_quantity_after IS NULL ) ) AND   ( (equivalent_generic_copay == equivalent_generic_copay_after AND  equivalent_generic_copay IS NOT NULL AND  equivalent_generic_copay_after IS NOT NULL )OR  ( equivalent_generic_copay IS NULL AND   equivalent_generic_copay_after IS NULL ) ) AND   ( (pbr_auth_full_name == pbr_auth_full_name_after AND  pbr_auth_full_name IS NOT NULL AND  pbr_auth_full_name_after IS NOT NULL ) OR ( pbr_auth_full_name IS NULL AND   pbr_auth_full_name_after IS NULL ) ) AND   ( (msg_pbr_full_name == msg_pbr_full_name_after AND  msg_pbr_full_name IS NOT NULL AND  msg_pbr_full_name_after IS NOT NULL ) OR ( msg_pbr_full_name IS NULL AND   msg_pbr_full_name_after IS NULL ) ) AND   ( (epa_status == epa_status_after AND  epa_status IS NOT NULL AND  epa_status_after IS NOT NULL ) OR ( epa_status IS NULL AND   epa_status_after IS NULL ) ) AND   ( (epa_reply_msg == epa_reply_msg_after AND  epa_reply_msg IS NOT NULL AND  epa_reply_msg_after IS NOT NULL ) OR ( epa_reply_msg IS NULL AND   epa_reply_msg_after IS NULL ) ) AND   ( (workstation_locked_ip == workstation_locked_ip_after AND  workstation_locked_ip IS NOT NULL AND  workstation_locked_ip_after IS NOT NULL ) OR ( workstation_locked_ip IS NULL AND   workstation_locked_ip_after IS NULL ) ) AND   ( (last_action_dttm == last_action_dttm_after AND  last_action_dttm IS NOT NULL AND  last_action_dttm_after IS NOT NULL ) OR ( last_action_dttm IS NULL AND   last_action_dttm_after IS NULL ) ) AND   ( (fax_image_id == fax_image_id_after AND  fax_image_id IS NOT NULL AND  fax_image_id_after IS NOT NULL ) OR ( fax_image_id IS NULL AND   fax_image_id_after IS NULL ) ) AND   ( (tpr_status_cd == tpr_status_cd_after AND  tpr_status_cd IS NOT NULL AND  tpr_status_cd_after IS NOT NULL ) OR ( tpr_status_cd IS NULL AND   tpr_status_cd_after IS NULL ) ) AND   ( (tpr_assignment_cd == tpr_assignment_cd_after AND  tpr_assignment_cd IS NOT NULL AND  tpr_assignment_cd_after IS NOT NULL ) OR ( tpr_assignment_cd IS NULL AND   tpr_assignment_cd_after IS NULL ) ) AND   ( (tpr_status_update_dttm == tpr_status_update_dttm_after AND  tpr_status_update_dttm IS NOT NULL AND  tpr_status_update_dttm_after IS NOT NULL ) OR ( tpr_status_update_dttm IS NULL AND   tpr_status_update_dttm_after IS NULL ) ) )" 

pPatIdModCheck="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')"

pTgtUDFcleanXfr="CONCAT(cdc_txn_commit_dttm,'.000000') AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, src_partition_nbr, store_nbr, rx_nbr, fill_nbr, fill_partial_nbr, exc_nbr, exc_reason_cd, exc_ccp_response, exc_cmt, exc_resolution_cd, exc_resolution_user_id, CONCAT(exc_resolution_dttm,'.000000') AS exc_resolution_dttm, CONCAT(exc_critical_dttm,'.000000') AS exc_critical_dttm, fill_deleted_ind, max_ldr_type_cd, max_ldr_type_sevr_cd, create_user_id, refills_added, CONCAT(create_dttm,'.000000') AS create_dttm, update_user_id, CONCAT(update_dttm,'.000000') AS update_dttm, prescribe_refills_added, prescribe_reply_cd, msg_cmts, prescribe_auth_id, CONCAT(exc_reason_update_dttm,'.000000') AS exc_reason_update_dttm, contacted_by_cd, CONCAT(resubmit_dttm,'.000000') AS resubmit_dttm, sold_thrd_pty_rej_ind, exc_status_cd, CONCAT(exc_status_update_dttm,'.000000') AS exc_status_update_dttm, pbr_phone_cmts, em_selected_ind, exc_sub_type_ind, emergency_quantity, equivalent_generic_copay, pbr_auth_full_name, msg_pbr_full_name, epa_status, epa_reply_msg, workstation_locked_ip, CONCAT(last_action_dttm,'.000000') AS last_action_dttm, fax_image_id, (CASE WHEN (LENGTH(trim(tpr_status_cd)) == 4) THEN SUBSTRING(tpr_status_cd,2,4) ELSE trim(tpr_status_cd) END) AS tpr_status_cd, tpr_assignment_cd, CONCAT(tpr_status_update_dttm,'.000000') AS tpr_status_update_dttm, '' AS reh_resubmit_dttm, tracking_id, partition_column"



# COMMAND ----------

#Read the current batch's cutoff records from the ETL_HIVE_CUTOFF table

etl_query = "SELECT * FROM {0}.{1}".format(SNFK_ETL_DB,ETL_TBL_NAME)

cutoff_records_output = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_ETL_DB) \
   .option("query",etl_query)\
   .load()


cutoff_records_filter = cutoff_records_output.filter((cutoff_records_output.EDW_BATCH_ID == BATCH_ID) & (cutoff_records_output.PROJ_NAME == PROJ_ID))


#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx = cutoff_records_filter.withColumn("rx_min",col("RX_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_max",to_timestamp(col("RX_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_max_substring",substring(col("RX_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_min_substring",substring(col("RX_CUT_OFF_MIN_DTTM"),1,10))

rx_max = cutoff_range_rx.select("rx_max")


#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans = cutoff_records_filter.withColumn("rx_trans_min",col("RX_TRAN_CUT_OFF_MIN_DTTM"))\
                                     .withColumn("rx_trans_max",to_timestamp(col("RX_TRAN_CUT_OFF_MAX_DTTM")))\
                                     .withColumn("rx_trans_max_substring",substring(col("RX_TRAN_CUT_OFF_MAX_DTTM"),1,10))\
                                     .withColumn("rx_trans_min_substring",substring(col("RX_TRAN_CUT_OFF_MIN_DTTM"),1,10))

rx_trans_max = cutoff_range_trans.select("rx_trans_max")


# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value
nr_input_filter_rxpartition_sql = "select * from raw_gg_tbf0_exception where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from raw_gg_tbf0_exception where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from raw_gg_tbf0_exception where " + pNopartitionTableCheck


nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)

nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)


if nr_input_filter_rxpartition.count()==0 and nr_input_filter_transpartition.count()==0:
  print("Table not falling under cut off table check list...")
  nr_input_file_final = nr_input_filter_nopartition
  
else:
  var_max = rx_max.count()
  var_trans_max = rx_trans_max.count()
  #Applying rx_cutoff range on rx related tables
  nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck)
  if var_max > 0:
    nr_input_file_filter_rx = nr_input_file_filter_rx.filter(nr_input_file_filter_rx.cdc_txn_commit_dttm <  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)

  nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual)
  if var_max > 0:
    nr_input_file_filter_rx_equal = nr_input_file_filter_rx_equal.filter(nr_input_file_filter_rx_equal.cdc_txn_commit_dttm <=  rx_max.collect()[0][0]) #rx_max = to_timestamp(cutoff_range_rx.rx_max)
  
  #Applying trans_cutoff range on trans related tables
  nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck)
  if var_trans_max > 0:
    nr_input_file_filter_trans = nr_input_file_filter_trans.filter(nr_input_file_filter_trans.cdc_txn_commit_dttm < rx_trans_max.collect()[0][0]) 

  nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual)
  if var_trans_max > 0:
    nr_input_file_filter_trans_equal = nr_input_file_filter_trans_equal.filter(nr_input_file_filter_trans_equal.cdc_txn_commit_dttm <= rx_trans_max.collect()[0][0])
  
  #Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
  nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

  nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)
  
  nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

  
  #Remove duplicates
dedup_group = nr_input_file_final.distinct()

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")
#display(ded)

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
""" + BATCH_ID + """ as edw_batch_id,
""" + BATCH_ID + """ as edw_batch_id_after,
 (case when (LENGTH(trim(src_partition_nbr))==0) then src_partition_nbr else TRIM(src_partition_nbr) end) as src_partition_nbr , 
(case when (LENGTH(trim(src_partition_nbr_after))==0) then src_partition_nbr_after else TRIM(src_partition_nbr_after) end) as src_partition_nbr_after ,
(case when (LENGTH(trim(store_nbr))==0) then store_nbr else TRIM(store_nbr) end) as store_nbr , 
(case when (LENGTH(trim(store_nbr_after))==0) then store_nbr_after else TRIM(store_nbr_after) end) as store_nbr_after ,
(case when (LENGTH(trim(rx_nbr))==0) then rx_nbr else TRIM(rx_nbr) end) as rx_nbr ,
(case when (LENGTH(trim(rx_nbr_after))==0) then rx_nbr_after else TRIM(rx_nbr_after) end) as rx_nbr_after , 
(case when (LENGTH(trim(fill_nbr))==0) then fill_nbr else TRIM(fill_nbr) end) as fill_nbr ,
(case when (LENGTH(trim(fill_nbr_after))==0) then fill_nbr_after else TRIM(fill_nbr_after) end) as fill_nbr_after ,
(case when (LENGTH(trim(fill_partial_nbr))==0) then fill_partial_nbr else TRIM(fill_partial_nbr) end) as fill_partial_nbr , 
(case when (LENGTH(trim(fill_partial_nbr_after))==0) then fill_partial_nbr_after else TRIM(fill_partial_nbr_after) end) as fill_partial_nbr_after ,
(case when (LENGTH(trim(exc_nbr))==0) then exc_nbr else TRIM(exc_nbr) end) as exc_nbr ,
(case when (LENGTH(trim(exc_nbr_after))==0) then exc_nbr_after else TRIM(exc_nbr_after) end) as exc_nbr_after ,
(case when (LENGTH(trim(exc_reason_cd))==0) then exc_reason_cd else TRIM(exc_reason_cd) end) as exc_reason_cd ,
(case when (LENGTH(trim(exc_reason_cd_after))==0) then exc_reason_cd_after else TRIM(exc_reason_cd_after) end) as exc_reason_cd_after ,
(case when (LENGTH(trim(contacted_by_cd))==0) then contacted_by_cd else TRIM(contacted_by_cd) end) as contacted_by_cd ,
(case when (LENGTH(trim(contacted_by_cd_after))==0) then contacted_by_cd_after else TRIM(contacted_by_cd_after) end) as contacted_by_cd_after , 
(case when (LENGTH(trim(emergency_quantity))==0) then emergency_quantity else TRIM(emergency_quantity) end) as emergency_quantity , 
(case when (LENGTH(trim(emergency_quantity_after))==0) then emergency_quantity_after else TRIM(emergency_quantity_after) end) as emergency_quantity_after , 
(case when (LENGTH(trim(pbr_auth_full_name))==0) then pbr_auth_full_name else TRIM(pbr_auth_full_name) end) as pbr_auth_full_name , 
(case when (LENGTH(trim(pbr_auth_full_name_after))==0) then pbr_auth_full_name_after else TRIM(pbr_auth_full_name_after) end) as pbr_auth_full_name_after , 
(case when (LENGTH(trim(msg_pbr_full_name))==0) then msg_pbr_full_name else TRIM(msg_pbr_full_name) end) as msg_pbr_full_name , 
(case when (LENGTH(trim(msg_pbr_full_name_after))==0) then msg_pbr_full_name_after else TRIM(msg_pbr_full_name_after) end) as msg_pbr_full_name_after ,
CONCAT(CONCAT(SUBSTRING(exc_critical_dttm,0,10),' '),SUBSTRING(exc_critical_dttm,11,19)) as exc_critical_dttm ,
CONCAT(CONCAT(SUBSTRING(exc_critical_dttm_after,0,10),' '),SUBSTRING(exc_critical_dttm_after,11,19)) as exc_critical_dttm_after ,
CONCAT(CONCAT(SUBSTRING(exc_reason_update_dttm,0,10),' '),SUBSTRING(exc_reason_update_dttm,11,19)) as exc_reason_update_dttm ,
CONCAT(CONCAT(SUBSTRING(exc_reason_update_dttm_after,0,10),' '),SUBSTRING(exc_reason_update_dttm_after,11,19)) as exc_reason_update_dttm_after , 
(case when (LENGTH(trim(exc_sub_type_ind))==0) then exc_sub_type_ind else TRIM(exc_sub_type_ind) end) as exc_sub_type_ind , 
(case when (LENGTH(trim(exc_sub_type_ind_after))==0) then exc_sub_type_ind_after else TRIM(exc_sub_type_ind_after) end) as exc_sub_type_ind_after , 
(case when (LENGTH(trim(fill_deleted_ind))==0) then fill_deleted_ind else TRIM(fill_deleted_ind) end) as fill_deleted_ind , 
(case when (LENGTH(trim(fill_deleted_ind_after))==0) then fill_deleted_ind_after else TRIM(fill_deleted_ind_after) end) as fill_deleted_ind_after , 
(case when (LENGTH(trim(max_ldr_type_sevr_cd))==0) then max_ldr_type_sevr_cd else TRIM(max_ldr_type_sevr_cd) end) as max_ldr_type_sevr_cd , 
(case when (LENGTH(trim(max_ldr_type_sevr_cd_after))==0) then max_ldr_type_sevr_cd_after else TRIM(max_ldr_type_sevr_cd_after) end) as max_ldr_type_sevr_cd_after , 
(case when (LENGTH(trim(max_ldr_type_cd))==0) then max_ldr_type_cd else TRIM(max_ldr_type_cd) end) as max_ldr_type_cd ,
(case when (LENGTH(trim(max_ldr_type_cd_after))==0) then max_ldr_type_cd_after else TRIM(max_ldr_type_cd_after) end) as max_ldr_type_cd_after , 
(case when (LENGTH(trim(prescribe_auth_id))==0) then prescribe_auth_id else TRIM(prescribe_auth_id) end) as prescribe_auth_id , 
(case when (LENGTH(trim(prescribe_auth_id_after))==0) then prescribe_auth_id_after else TRIM(prescribe_auth_id_after) end) as prescribe_auth_id_after ,
(case when (LENGTH(trim(msg_cmts))==0) then msg_cmts else TRIM(msg_cmts) end) as msg_cmts ,
(case when (LENGTH(trim(msg_cmts_after))==0) then msg_cmts_after else TRIM(msg_cmts_after) end) as msg_cmts_after ,
(case when (LENGTH(trim(pbr_phone_cmts))==0) then pbr_phone_cmts else TRIM(pbr_phone_cmts) end) as pbr_phone_cmts ,
(case when (LENGTH(trim(pbr_phone_cmts_after))==0) then pbr_phone_cmts_after else TRIM(pbr_phone_cmts_after) end) as pbr_phone_cmts_after , 
(case when (LENGTH(trim(prescribe_reply_cd))==0) then prescribe_reply_cd else TRIM(prescribe_reply_cd) end) as prescribe_reply_cd , 
(case when (LENGTH(trim(prescribe_reply_cd_after))==0) then prescribe_reply_cd_after else TRIM(prescribe_reply_cd_after) end) as prescribe_reply_cd_after , 
(case when (LENGTH(trim(prescribe_refills_added))==0) then prescribe_refills_added else TRIM(prescribe_refills_added) end) as prescribe_refills_added , 
(case when (LENGTH(trim(prescribe_refills_added_after))==0) then prescribe_refills_added_after else TRIM(prescribe_refills_added_after) end) as prescribe_refills_added_after , 
(case when (LENGTH(trim(refills_added))==0) then refills_added else TRIM(refills_added) end) as refills_added ,
(case when (LENGTH(trim(refills_added_after))==0) then refills_added_after else TRIM(refills_added_after) end) as refills_added_after ,
CONCAT(CONCAT(SUBSTRING(resubmit_dttm,0,10),' '),SUBSTRING(resubmit_dttm,11,19)) as resubmit_dttm ,
CONCAT(CONCAT(SUBSTRING(resubmit_dttm_after,0,10),' '),SUBSTRING(resubmit_dttm_after,11,19)) as resubmit_dttm_after , 
(case when (LENGTH(trim(sold_thrd_pty_rej_ind))==0) then sold_thrd_pty_rej_ind else TRIM(sold_thrd_pty_rej_ind) end) as sold_thrd_pty_rej_ind , 
(case when (LENGTH(trim(sold_thrd_pty_rej_ind_after))==0) then sold_thrd_pty_rej_ind_after else TRIM(sold_thrd_pty_rej_ind_after) end) as sold_thrd_pty_rej_ind_after , 
(case when (LENGTH(trim(exc_cmt))==0) then exc_cmt else TRIM(exc_cmt) end) as exc_cmt ,
(case when (LENGTH(trim(exc_cmt_after))==0) then exc_cmt_after else TRIM(exc_cmt_after) end) as exc_cmt_after ,
CONCAT(CONCAT(SUBSTRING(exc_status_update_dttm,0,10),' '),SUBSTRING(exc_status_update_dttm,11,19)) as exc_status_update_dttm ,
CONCAT(CONCAT(SUBSTRING(exc_status_update_dttm_after,0,10),' '),SUBSTRING(exc_status_update_dttm_after,11,19)) as exc_status_update_dttm_after , 
(case when (LENGTH(trim(exc_resolution_cd))==0) then exc_resolution_cd else TRIM(exc_resolution_cd) end) as exc_resolution_cd , 
(case when (LENGTH(trim(exc_resolution_cd_after))==0) then exc_resolution_cd_after else TRIM(exc_resolution_cd_after) end) as exc_resolution_cd_after ,
CONCAT(CONCAT(SUBSTRING(exc_resolution_dttm,0,10),' '),SUBSTRING(exc_resolution_dttm,11,19)) as exc_resolution_dttm ,
CONCAT(CONCAT(SUBSTRING(exc_resolution_dttm_after,0,10),' '),SUBSTRING(exc_resolution_dttm_after,11,19)) as exc_resolution_dttm_after , 
(case when (LENGTH(trim(exc_resolution_user_id))==0) then exc_resolution_user_id else TRIM(exc_resolution_user_id) end) as exc_resolution_user_id , 
(case when (LENGTH(trim(exc_resolution_user_id_after))==0) then exc_resolution_user_id_after else TRIM(exc_resolution_user_id_after) end) as exc_resolution_user_id_after , 
(case when (LENGTH(trim(exc_status_cd))==0) then exc_status_cd else TRIM(exc_status_cd) end) as exc_status_cd ,
(case when (LENGTH(trim(exc_status_cd_after))==0) then exc_status_cd_after else TRIM(exc_status_cd_after) end) as exc_status_cd_after ,
CONCAT(CONCAT(SUBSTRING(create_dttm,0,10),' '),SUBSTRING(create_dttm,11,19)) as create_dttm ,
CONCAT(CONCAT(SUBSTRING(create_dttm_after,0,10),' '),SUBSTRING(create_dttm_after,11,19)) as create_dttm_after ,
(case when (LENGTH(trim(create_user_id))==0) then create_user_id else TRIM(create_user_id) end) as create_user_id ,
(case when (LENGTH(trim(create_user_id_after))==0) then create_user_id_after else TRIM(create_user_id_after) end) as create_user_id_after ,
CONCAT(CONCAT(SUBSTRING(update_dttm,0,10),' '),SUBSTRING(update_dttm,11,19)) as update_dttm ,
CONCAT(CONCAT(SUBSTRING(update_dttm_after,0,10),' '),SUBSTRING(update_dttm_after,11,19)) as update_dttm_after ,
(case when (LENGTH(trim(update_user_id))==0) then update_user_id else TRIM(update_user_id) end) as update_user_id ,
(case when (LENGTH(trim(update_user_id_after))==0) then update_user_id_after else TRIM(update_user_id_after) end) as update_user_id_after , 
(case when (LENGTH(trim(em_selected_ind))==0) then em_selected_ind else TRIM(em_selected_ind) end) as em_selected_ind ,
(case when (LENGTH(trim(em_selected_ind_after))==0) then em_selected_ind_after else TRIM(em_selected_ind_after) end) as em_selected_ind_after ,
epa_reply_msg AS epa_reply_msg ,
epa_reply_msg_after AS epa_reply_msg_after ,
(case when (LENGTH(trim(epa_status))==0) then epa_status else TRIM(epa_status) end) as epa_status ,
(case when (LENGTH(trim(epa_status_after))==0) then epa_status_after else TRIM(epa_status_after) end) as epa_status_after , 
(case when (LENGTH(trim(equivalent_generic_copay))==0) then equivalent_generic_copay else TRIM(equivalent_generic_copay) end) as equivalent_generic_copay , 
(case when (LENGTH(trim(equivalent_generic_copay_after))==0) then equivalent_generic_copay_after else TRIM(equivalent_generic_copay_after) end) as equivalent_generic_copay_after , (case when (LENGTH(trim(exc_ccp_response))==0) then exc_ccp_response else TRIM(exc_ccp_response) end) as exc_ccp_response , 
(case when (LENGTH(trim(exc_ccp_response_after))==0) then exc_ccp_response_after else TRIM(exc_ccp_response_after) end) as exc_ccp_response_after ,
CONCAT(CONCAT(SUBSTRING(last_action_dttm,0,10),' '),SUBSTRING(last_action_dttm,11,19)) as last_action_dttm ,
CONCAT(CONCAT(SUBSTRING(last_action_dttm_after,0,10),' '),SUBSTRING(last_action_dttm_after,11,19)) as last_action_dttm_after , 
(case when (LENGTH(trim(workstation_locked_ip))==0) then workstation_locked_ip else TRIM(workstation_locked_ip) end) as workstation_locked_ip , 
(case when (LENGTH(trim(workstation_locked_ip_after))==0) then workstation_locked_ip_after else TRIM(workstation_locked_ip_after) end) as workstation_locked_ip_after , 
(case when (LENGTH(trim(fax_image_id))==0) then fax_image_id else TRIM(fax_image_id) end) as fax_image_id ,
(case when (LENGTH(trim(fax_image_id_after))==0) then fax_image_id_after else TRIM(fax_image_id_after) end) as fax_image_id_after ,
(case when (LENGTH(trim(tpr_status_cd))==0) then tpr_status_cd else TRIM(tpr_status_cd) end) as tpr_status_cd ,
(case when (LENGTH(trim(tpr_status_cd_after))==0) then tpr_status_cd_after else TRIM(tpr_status_cd_after) end) as tpr_status_cd_after , 
(case when (LENGTH(trim(tpr_assignment_cd))==0) then tpr_assignment_cd else TRIM(tpr_assignment_cd) end) as tpr_assignment_cd , 
(case when (LENGTH(trim(tpr_assignment_cd_after))==0) then tpr_assignment_cd_after else TRIM(tpr_assignment_cd_after) end) as tpr_assignment_cd_after ,
CONCAT(CONCAT(SUBSTRING(tpr_status_update_dttm,0,10),' '),SUBSTRING(tpr_status_update_dttm,11,19)) as tpr_status_update_dttm ,
CONCAT(CONCAT(SUBSTRING(tpr_status_update_dttm_after,0,10),' '),SUBSTRING(tpr_status_update_dttm_after,11,19)) as tpr_status_update_dttm_after ,
CONCAT(CONCAT(SUBSTRING(reh_resubmit_dttm,0,10),' '),SUBSTRING(reh_resubmit_dttm,11,19)) as reh_resubmit_dttm ,
CONCAT(CONCAT(SUBSTRING(reh_resubmit_dttm_after,0,10),' '),SUBSTRING(reh_resubmit_dttm_after,11,19)) as reh_resubmit_dttm_after from dedup_group""" 

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)


nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')

nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )

             
if nr_rejected.count()>0:
  nr_rejected.write.mode('overwrite').parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")
query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  gg_tbf0_rejected.write.mode('overwrite').parquet(REJ_FILE_UPD_NULL) 


gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")
  

# COMMAND ----------

pTgtUpdAftXfr = """select 
cdc_txn_commit_dttm_after as cdc_txn_commit_dttm,cdc_seq_nbr_after as cdc_seq_nbr,cdc_rba_nbr_after as cdc_rba_nbr,cdc_operation_type_cd_after as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id,
src_partition_nbr_after AS src_partition_nbr , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , exc_nbr_after AS exc_nbr , exc_reason_cd_after AS exc_reason_cd , contacted_by_cd_after AS contacted_by_cd , emergency_quantity_after AS emergency_quantity , pbr_auth_full_name_after AS pbr_auth_full_name , msg_pbr_full_name_after AS msg_pbr_full_name , exc_critical_dttm_after AS exc_critical_dttm , exc_reason_update_dttm_after AS exc_reason_update_dttm , exc_sub_type_ind_after AS exc_sub_type_ind , fill_deleted_ind_after AS fill_deleted_ind , max_ldr_type_sevr_cd_after AS max_ldr_type_sevr_cd , max_ldr_type_cd_after AS max_ldr_type_cd , prescribe_auth_id_after AS prescribe_auth_id , msg_cmts_after AS msg_cmts , pbr_phone_cmts_after AS pbr_phone_cmts , prescribe_reply_cd_after AS prescribe_reply_cd , prescribe_refills_added_after AS prescribe_refills_added , refills_added_after AS refills_added , resubmit_dttm_after AS resubmit_dttm , sold_thrd_pty_rej_ind_after AS sold_thrd_pty_rej_ind , exc_cmt_after AS exc_cmt , exc_status_update_dttm_after AS exc_status_update_dttm , exc_resolution_cd_after AS exc_resolution_cd , exc_resolution_dttm_after AS exc_resolution_dttm , exc_resolution_user_id_after AS exc_resolution_user_id , exc_status_cd_after AS exc_status_cd , create_dttm_after AS create_dttm , create_user_id_after AS create_user_id , update_dttm_after AS update_dttm , update_user_id_after AS update_user_id , em_selected_ind_after AS em_selected_ind , epa_reply_msg_after AS epa_reply_msg , epa_status_after AS epa_status , equivalent_generic_copay_after AS equivalent_generic_copay , exc_ccp_response_after AS exc_ccp_response , last_action_dttm_after AS last_action_dttm , workstation_locked_ip_after AS workstation_locked_ip , fax_image_id_after AS fax_image_id , tpr_status_cd_after AS tpr_status_cd , tpr_assignment_cd_after AS tpr_assignment_cd , tpr_status_update_dttm_after AS tpr_status_update_dttm , reh_resubmit_dttm_after AS reh_resubmit_dttm , '000000' AS tracking_id ,'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name 
from gg_tbf0_update """


# COMMAND ----------

pTgtUpdBfrXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd as cdc_before_after_cd,cdc_txn_position_cd as cdc_txn_position_cd, 
"""  + BATCH_ID + """ as edw_batch_id,
src_partition_nbr AS src_partition_nbr , store_nbr AS store_nbr , rx_nbr AS rx_nbr , fill_nbr AS fill_nbr , fill_partial_nbr AS fill_partial_nbr , exc_nbr AS exc_nbr , exc_reason_cd AS exc_reason_cd , contacted_by_cd AS contacted_by_cd , emergency_quantity AS emergency_quantity , pbr_auth_full_name AS pbr_auth_full_name , msg_pbr_full_name AS msg_pbr_full_name , exc_critical_dttm AS exc_critical_dttm , exc_reason_update_dttm AS exc_reason_update_dttm , exc_sub_type_ind AS exc_sub_type_ind , fill_deleted_ind AS fill_deleted_ind , max_ldr_type_sevr_cd AS max_ldr_type_sevr_cd , max_ldr_type_cd AS max_ldr_type_cd , prescribe_auth_id AS prescribe_auth_id , msg_cmts AS msg_cmts , pbr_phone_cmts AS pbr_phone_cmts , prescribe_reply_cd AS prescribe_reply_cd , prescribe_refills_added AS prescribe_refills_added , refills_added AS refills_added , resubmit_dttm AS resubmit_dttm , sold_thrd_pty_rej_ind AS sold_thrd_pty_rej_ind , exc_cmt AS exc_cmt , exc_status_update_dttm AS exc_status_update_dttm , exc_resolution_cd AS exc_resolution_cd , exc_resolution_dttm AS exc_resolution_dttm , exc_resolution_user_id AS exc_resolution_user_id , exc_status_cd AS exc_status_cd , create_dttm AS create_dttm , create_user_id AS create_user_id , update_dttm AS update_dttm , update_user_id AS update_user_id , em_selected_ind AS em_selected_ind , epa_reply_msg AS epa_reply_msg , epa_status AS epa_status , equivalent_generic_copay AS equivalent_generic_copay , exc_ccp_response AS exc_ccp_response , last_action_dttm AS last_action_dttm , workstation_locked_ip AS workstation_locked_ip , fax_image_id AS fax_image_id , tpr_status_cd AS tpr_status_cd , tpr_assignment_cd AS tpr_assignment_cd , tpr_status_update_dttm AS tpr_status_update_dttm , reh_resubmit_dttm AS reh_resubmit_dttm , '000000' AS tracking_id ,'' AS partition_column,
'""" + SRC_TBL_NAME +  """' as table_name
from gg_tbf0_update """


# COMMAND ----------

pTgtInsBfrAftXfr = """ select 
cdc_txn_commit_dttm as cdc_txn_commit_dttm,cdc_seq_nbr as cdc_seq_nbr,cdc_rba_nbr as cdc_rba_nbr,cdc_operation_type_cd as cdc_operation_type_cd ,cdc_before_after_cd_after as cdc_before_after_cd,cdc_txn_position_cd_after as cdc_txn_position_cd,
""" + BATCH_ID + """ as edw_batch_id, src_partition_nbr_after AS src_partition_nbr , store_nbr_after AS store_nbr , rx_nbr_after AS rx_nbr , fill_nbr_after AS fill_nbr , fill_partial_nbr_after AS fill_partial_nbr , exc_nbr_after AS exc_nbr , exc_reason_cd_after AS exc_reason_cd , contacted_by_cd_after AS contacted_by_cd , emergency_quantity_after AS emergency_quantity , pbr_auth_full_name_after AS pbr_auth_full_name , msg_pbr_full_name_after AS msg_pbr_full_name , exc_critical_dttm_after AS exc_critical_dttm , exc_reason_update_dttm_after AS exc_reason_update_dttm , exc_sub_type_ind_after AS exc_sub_type_ind , fill_deleted_ind_after AS fill_deleted_ind , max_ldr_type_sevr_cd_after AS max_ldr_type_sevr_cd , max_ldr_type_cd_after AS max_ldr_type_cd , prescribe_auth_id_after AS prescribe_auth_id , msg_cmts_after AS msg_cmts , pbr_phone_cmts_after AS pbr_phone_cmts , prescribe_reply_cd_after AS prescribe_reply_cd , prescribe_refills_added_after AS prescribe_refills_added , refills_added_after AS refills_added , resubmit_dttm_after AS resubmit_dttm , sold_thrd_pty_rej_ind_after AS sold_thrd_pty_rej_ind , exc_cmt_after AS exc_cmt , exc_status_update_dttm_after AS exc_status_update_dttm , exc_resolution_cd_after AS exc_resolution_cd , exc_resolution_dttm_after AS exc_resolution_dttm , exc_resolution_user_id_after AS exc_resolution_user_id , exc_status_cd_after AS exc_status_cd , create_dttm_after AS create_dttm , create_user_id_after AS create_user_id , update_dttm_after AS update_dttm , update_user_id_after AS update_user_id , em_selected_ind_after AS em_selected_ind , epa_reply_msg_after AS epa_reply_msg , epa_status_after AS epa_status , equivalent_generic_copay_after AS equivalent_generic_copay , exc_ccp_response_after AS exc_ccp_response , last_action_dttm_after AS last_action_dttm , workstation_locked_ip_after AS workstation_locked_ip , fax_image_id_after AS fax_image_id , tpr_status_cd_after AS tpr_status_cd , tpr_assignment_cd_after AS tpr_assignment_cd , tpr_status_update_dttm_after AS tpr_status_update_dttm , reh_resubmit_dttm_after AS reh_resubmit_dttm , '000000' AS tracking_id ,'' AS partition_column, 
'""" + SRC_TBL_NAME +  """' as table_name 
from nr_insert_check """

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr)

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)


if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode('overwrite').parquet(REJ_FILE_PAT_MOD) 


gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")

  

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"


etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)


etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))


etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull())


#Storing rejected records from above step in a separate Reject File
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode('overwrite').parquet(REJ_FILE_CDC_CHECK) 


# COMMAND ----------

#Remove Blank Values
for col in etl_tbf0_reformat_cdc_check_notnull.columns:
    etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn(col, when(ltrim(rtrim(etl_tbf0_reformat_cdc_check_notnull[col])) == "",None).otherwise(ltrim(rtrim(etl_tbf0_reformat_cdc_check_notnull[col]))))

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("CREATE_DTTM",concat(split("CREATE_DTTM",":")[0],split("CREATE_DTTM",":")[1],lit(":"),split("CREATE_DTTM",":")[2],lit(":"),split("CREATE_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("UPDATE_DTTM",concat(split("UPDATE_DTTM",":")[0],split("UPDATE_DTTM",":")[1],lit(":"),split("UPDATE_DTTM",":")[2],lit(":"),split("UPDATE_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("EXC_RESOLUTION_DTTM",concat(split("EXC_RESOLUTION_DTTM",":")[0],split("EXC_RESOLUTION_DTTM",":")[1],lit(":"),split("EXC_RESOLUTION_DTTM",":")[2],lit(":"),split("EXC_RESOLUTION_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("EXC_CRITICAL_DTTM",concat(split("EXC_CRITICAL_DTTM",":")[0],split("EXC_CRITICAL_DTTM",":")[1],lit(":"),split("EXC_CRITICAL_DTTM",":")[2],lit(":"),split("EXC_CRITICAL_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("EXC_REASON_UPDATE_DTTM",concat(split("EXC_REASON_UPDATE_DTTM",":")[0],split("EXC_REASON_UPDATE_DTTM",":")[1],lit(":"),split("EXC_REASON_UPDATE_DTTM",":")[2],lit(":"),split("EXC_REASON_UPDATE_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("RESUBMIT_DTTM",concat(split("RESUBMIT_DTTM",":")[0],split("RESUBMIT_DTTM",":")[1],lit(":"),split("RESUBMIT_DTTM",":")[2],lit(":"),split("RESUBMIT_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("EXC_STATUS_UPDATE_DTTM",concat(split("EXC_STATUS_UPDATE_DTTM",":")[0],split("EXC_STATUS_UPDATE_DTTM",":")[1],lit(":"),split("EXC_STATUS_UPDATE_DTTM",":")[2],lit(":"),split("EXC_STATUS_UPDATE_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("LAST_ACTION_DTTM",concat(split("LAST_ACTION_DTTM",":")[0],split("LAST_ACTION_DTTM",":")[1],lit(":"),split("LAST_ACTION_DTTM",":")[2],lit(":"),split("LAST_ACTION_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("TPR_STATUS_UPDATE_DTTM",concat(split("TPR_STATUS_UPDATE_DTTM",":")[0],split("TPR_STATUS_UPDATE_DTTM",":")[1],lit(":"),split("TPR_STATUS_UPDATE_DTTM",":")[2],lit(":"),split("TPR_STATUS_UPDATE_DTTM",":")[3]))
etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn("REH_RESUBMIT_DTTM",concat(split("REH_RESUBMIT_DTTM",":")[0],split("REH_RESUBMIT_DTTM",":")[1],lit(":"),split("REH_RESUBMIT_DTTM",":")[2],lit(":"),split("REH_RESUBMIT_DTTM",":")[3]))

# COMMAND ----------

df_final = etl_tbf0_reformat_cdc_check_notnull.drop("tracking_id","partition_column")
df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
           	.withColumn("CDC_SEQ_NBR",df_final["CDC_SEQ_NBR"].cast(IntegerType()))\
			.withColumn("CDC_RBA_NBR",df_final["CDC_RBA_NBR"].cast(IntegerType()))\
            .withColumn("CREATE_USER_ID",df_final["CREATE_USER_ID"].cast(IntegerType()))\
            .withColumn("UPDATE_USER_ID",df_final["UPDATE_USER_ID"].cast(IntegerType()))\
			.withColumn("EXC_RESOLUTION_USER_ID",df_final["EXC_RESOLUTION_USER_ID"].cast(IntegerType()))\
			.withColumn("EMERGENCY_QUANTITY",df_final["EMERGENCY_QUANTITY"].cast(IntegerType()))\
			.withColumn("EQUIVALENT_GENERIC_COPAY",df_final["EQUIVALENT_GENERIC_COPAY"].cast(IntegerType()))\
			.withColumn("RX_NBR",df_final["RX_NBR"].cast(IntegerType()))\
			.withColumn("STORE_NBR",df_final["STORE_NBR"].cast(IntegerType()))\
			.withColumn("SRC_PARTITION_NBR",df_final["SRC_PARTITION_NBR"].cast(IntegerType()))\
			.withColumn("FILL_NBR",df_final["FILL_NBR"].cast(IntegerType()))\
			.withColumn("EXC_NBR",df_final["EXC_NBR"].cast(IntegerType()))\
			.withColumn("FILL_PARTIAL_NBR",df_final["FILL_PARTIAL_NBR"].cast(IntegerType()))\
            .withColumn("TPR_STATUS_CD",df_final["TPR_STATUS_CD"].cast(IntegerType()))\
			.withColumn("CREATE_DTTM",to_timestamp(df_final["CREATE_DTTM"]))\
			.withColumn("UPDATE_DTTM",to_timestamp(df_final["UPDATE_DTTM"]))\
            .withColumn("REH_RESUBMIT_DTTM",to_timestamp(df_final["REH_RESUBMIT_DTTM"]))\
            .withColumn("EXC_RESOLUTION_DTTM",to_timestamp(df_final["EXC_RESOLUTION_DTTM"]))\
            .withColumn("EXC_CRITICAL_DTTM",to_timestamp(df_final["EXC_CRITICAL_DTTM"]))\
            .withColumn("EXC_REASON_UPDATE_DTTM",to_timestamp(df_final["EXC_REASON_UPDATE_DTTM"]))\
            .withColumn("RESUBMIT_DTTM",to_timestamp(df_final["RESUBMIT_DTTM"]))\
            .withColumn("EXC_STATUS_UPDATE_DTTM",to_timestamp(df_final["EXC_STATUS_UPDATE_DTTM"]))\
            .withColumn("LAST_ACTION_DTTM",to_timestamp(df_final["LAST_ACTION_DTTM"]))\
            .withColumn("TPR_STATUS_UPDATE_DTTM",to_timestamp(df_final["TPR_STATUS_UPDATE_DTTM"]))
			
df_final = df_final.filter("STORE_NBR IS NOT NULL AND RX_NBR IS NOT NULL AND FILL_NBR IS NOT NULL AND FILL_PARTIAL_NBR IS NOT NULL AND EXC_NBR IS NOT NULL AND EXC_REASON_CD IS NOT NULL AND CREATE_USER_ID IS NOT NULL AND CREATE_DTTM IS NOT NULL AND UPDATE_USER_ID IS NOT NULL AND UPDATE_DTTM IS NOT NULL")


df_final = df_final.withColumn("cdc_txn_commit_dttm", to_timestamp(df_final["cdc_txn_commit_dttm"]))\
			.withColumn("CREATE_DTTM",to_timestamp(df_final["CREATE_DTTM"]))\
			.withColumn("UPDATE_DTTM",to_timestamp(df_final["UPDATE_DTTM"]))\
            .withColumn("REH_RESUBMIT_DTTM",to_timestamp(df_final["REH_RESUBMIT_DTTM"]))\
            .withColumn("EXC_RESOLUTION_DTTM",to_timestamp(df_final["EXC_RESOLUTION_DTTM"]))\
            .withColumn("EXC_CRITICAL_DTTM",to_timestamp(df_final["EXC_CRITICAL_DTTM"]))\
            .withColumn("EXC_REASON_UPDATE_DTTM",to_timestamp(df_final["EXC_REASON_UPDATE_DTTM"]))\
            .withColumn("RESUBMIT_DTTM",to_timestamp(df_final["RESUBMIT_DTTM"]))\
            .withColumn("EXC_STATUS_UPDATE_DTTM",to_timestamp(df_final["EXC_STATUS_UPDATE_DTTM"]))\
            .withColumn("LAST_ACTION_DTTM",to_timestamp(df_final["LAST_ACTION_DTTM"]))\
            .withColumn("TPR_STATUS_UPDATE_DTTM",to_timestamp(df_final["TPR_STATUS_UPDATE_DTTM"]))



# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table

df_final.write \
    .format("snowflake") \
    .options(**options) \
    .option("sfWarehouse", SNFL_WH) \
    .option("sfDatabase", SNFL_DB) \
    .option("dbtable", SNFL_TBL_NAME) \
    .option("ON_ERROR", "SKIP_FILE") \
    .option("truncate_table","ON")\
    .option("use staging table","OFF")\
    .mode("overwrite") \
    .save()

TL_SNFL_TBL_NAME=SNFL_TBL_NAME.split(".")[0]+".TL_"+SNFL_TBL_NAME.split(".")[1]
df_final.write \
.format("snowflake") \
.options(**options) \
.option("sfWarehouse", SNFL_WH) \
.option("sfDatabase", SNFL_DB) \
.option("dbtable", TL_SNFL_TBL_NAME) \
.option("ON_ERROR", "SKIP_FILE") \
.option("truncate_table","ON")\
.option("use staging table","OFF")\
.mode("overwrite") \
.save()


# COMMAND ----------

PAR_WRITEAPI_URL=dbutils.widgets.get("PAR_WRITEAPI_URL")
PAR_WRITEAPI_KEY1='statusId'
PAR_WRITEAPI_VALUE1='200'
PAR_WRITEAPI_KEY2='assetId'
PAR_WRITEAPI_VALUE2=dfAssetIdStr

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WriteAPI", 200, 
                  {"PAR_WRITEAPI_URL":PAR_WRITEAPI_URL,
                   "PAR_WRITEAPI_KEY1":PAR_WRITEAPI_KEY1,
                   "PAR_WRITEAPI_VALUE1":PAR_WRITEAPI_VALUE1,
                   "PAR_WRITEAPI_KEY2":PAR_WRITEAPI_KEY2,
                   "PAR_WRITEAPI_VALUE2":PAR_WRITEAPI_VALUE2});

dbutils.notebook.exit(PAR_WRITEAPI_VALUE2);
dbutils.notebook.exit("ETL_TBF0_EXCEPTION_STG LOADED SUCCESSFULLY AND ASSET IS CLOSED")

# COMMAND ----------



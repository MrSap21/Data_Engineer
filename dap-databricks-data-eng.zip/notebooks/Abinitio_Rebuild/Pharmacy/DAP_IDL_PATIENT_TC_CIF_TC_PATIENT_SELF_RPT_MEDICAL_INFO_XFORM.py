# Databricks notebook source
# Python code to mount and access Azure Data Lake Storage Gen2 Account to Azure Databricks with Service Principal and OAuth
# Author: Dhyanendra Singh Rathore
# Define the variables used for creating connection strings
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
mountPoint = "/mnt/DAP_IDL_PATIENT_TC_CIF_TC_PATIENT_SELF_RPT_MEDICAL_INFO_XFORM"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

# Define Input Schema

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("patientid", StringType(), False),
    StructField("med_info_rec_dt", StringType(), False),
    StructField("pat_med_info_dt", StringType(), False),
    StructField("problemtypecd", StringType(), False),
    StructField("hipaacceptind", StringType(), False),
    StructField("problemid", StringType(), False),
    StructField("headeranswerxml", StringType(), False),
    StructField("answerxml", StringType(), False),
    StructField("edw_maxupd_dttm", StringType(), False)
  ])
)

# COMMAND ----------

# Load Input File

inputFileFullPath = mountPoint + "/" + dbutils.widgets.get('AI_SERIAL') + "/edw_idl_patient_tc_patient_sr_medical_info_extr_" + dbutils.widgets.get('pDAP_BATCH_ID') + ".dat"

dfInput = spark.read.format("csv").options(header='false', delimiter = '\x01').schema(inputSchema).load(inputFileFullPath)

#display(dfInput)

# COMMAND ----------

# SRT - NAT KEYS

from pyspark.sql.functions import *

dfInputSorted = dfInput.orderBy("patientid", "med_info_rec_dt", "answerxml")

dfInputSorted.createOrReplaceTempView("dfInputSorted")

display(dfInputSorted)

# COMMAND ----------

# MAGIC %scala
# MAGIC 
# MAGIC /* Flattening nested XMLs */
# MAGIC 
# MAGIC import org.apache.spark.sql.functions.col
# MAGIC import com.databricks.spark.xml.functions.from_xml
# MAGIC import com.databricks.spark.xml.schema_of_xml
# MAGIC import spark.implicits._
# MAGIC 
# MAGIC // Header XML
# MAGIC 
# MAGIC var dfXMLHeaderRaw = spark.sql("SELECT patientid, med_info_rec_dt, headeranswerxml FROM dfInputSorted")
# MAGIC var dfXMLHeaderStruct = dfXMLHeaderRaw.withColumn("headerstruct", from_xml($"headeranswerxml", schema_of_xml(dfXMLHeaderRaw.select("headeranswerxml").as[String])))
# MAGIC var dfXMLHeaderReject = dfXMLHeaderStruct.filter(col("headerstruct._corrupt_record").isNotNull)
# MAGIC var dfXMLHeader = dfXMLHeaderStruct.filter(col("headerstruct.data").isNotNull)
# MAGIC                                    .withColumn("at", col("headerstruct.data.dca._at"))
# MAGIC                                    .withColumn("qt", col("headerstruct.data.dca._qt"))
# MAGIC                                    .drop("headeranswerxml", "headerstruct")
# MAGIC 
# MAGIC dfXMLHeaderReject.createOrReplaceTempView("dfXMLHeaderReject")
# MAGIC dfXMLHeader.createOrReplaceTempView("dfXMLHeader")
# MAGIC 
# MAGIC // Answer XML
# MAGIC 
# MAGIC var dfXMLAnswerRaw = spark.sql("SELECT patientid, med_info_rec_dt, answerxml FROM dfInputSorted")
# MAGIC var dfXMLAnswerStruct = dfXMLAnswerRaw.withColumn("answerstruct", from_xml($"answerxml", schema_of_xml(dfXMLAnswerRaw.select("answerxml").as[String])))
# MAGIC var dfXMLAnswerReject = dfXMLAnswerStruct.filter(col("answerstruct._corrupt_record").isNotNull)
# MAGIC var dfXMLAnswer = dfXMLAnswerStruct.filter(col("answerstruct.dca").isNotNull)
# MAGIC                                    .withColumn("at_attr", col("answerstruct.dca._at"))
# MAGIC                                    .withColumn("qt", col("answerstruct.dca._qt"))
# MAGIC                                    .drop("answerxml", "answerstruct")
# MAGIC 
# MAGIC dfXMLAnswerReject.createOrReplaceTempView("dfXMLAnswerReject")
# MAGIC dfXMLAnswer.createOrReplaceTempView("dfXMLAnswer")
# MAGIC 
# MAGIC //display(dfXMLHeader)
# MAGIC //display(dfXMLAnswer)
# MAGIC //display(dfXMLHeaderReject)
# MAGIC //display(dfXMLAnswerReject)

# COMMAND ----------

# Initiating the 3 dataframes this graph will work with

dfMain = dfInputSorted
dfHeader = spark.sql("SELECT * FROM dfXMLHeader")
dfAnswer = spark.sql("SELECT * FROM dfXMLAnswer")

#display(dfHeader)

# COMMAND ----------

# Reformat Header

dfHeaderAgg = dfHeader.groupBy("patientid", "med_info_rec_dt").agg(max(col("at")).alias("at"), max(col("qt")).alias("qt"))
  
dfHeaderFinal = dfHeaderAgg.withColumn("hqt_sm", when(col("qt").like("%smok%"), col("qt")).otherwise(''))\
                           .withColumn("hat_sm", when(col("qt").like("%smok%"), col("at")).otherwise(''))\
                           .withColumn("hqt_rd", when(col("qt").like("%Recreational Drug Use%"), col("qt")).otherwise(''))\
                           .withColumn("hat_rd", when(col("qt").like("%Recreational Drug Use%"), col("at")).otherwise(''))\
                           .drop("qt", "at")

#display(dfHeaderAgg)

# COMMAND ----------

# Reformat Answer

dfAnswerAgg = dfAnswer.groupBy("patientid", "med_info_rec_dt").agg(max(col("at_attr")).alias("at_attr"), max(col("qt")).alias("qt"))
  
dfAnswerFinal = dfAnswerAgg.withColumn("aat_lmp", when(col("qt").like("Last Menstrual Period%"), col("at_attr")).otherwise(''))\
                           .withColumn("aqt_lmp", when(col("qt").like("Last Menstrual Period%"), col("qt")).otherwise(''))\
                           .withColumn("aat_m", when(col("qt").like("%Menopaus%"), col("at_attr")).otherwise(''))\
                           .withColumn("aqt_m", when(col("qt").like("%Menopaus%"), col("qt")).otherwise(''))\
                           .drop("qt", "at_attr")

#display(dfAnswerAgg)

# COMMAND ----------

# Join and reformat

dfMainHeader = dfMain.alias("t1").join(dfHeaderFinal.alias("t2"), (col("t1.patientid") == col("t2.patientid")) & (col("t1.med_info_rec_dt") == col("t2.med_info_rec_dt")), how = "left").select(col("t1.patientid"), col("t1.med_info_rec_dt"), col("t1.pat_med_info_dt"), col("t1.hipaacceptind"), col("t1.problemtypecd"), col("t1.problemid"), col("t2.hqt_sm"), col("t2.hat_sm"), col("t2.hqt_rd"), col("t2.hat_rd"))

dfMainHeaderAnswer =  dfMainHeader.alias("t1").join(dfAnswerFinal.alias("t2"), (col("t1.patientid") == col("t2.patientid")) & (col("t1.med_info_rec_dt") == col("t2.med_info_rec_dt")), how = "left").select(col("t1.patientid"), col("t1.med_info_rec_dt"), col("t1.pat_med_info_dt"), col("t1.hipaacceptind"), col("t1.problemtypecd"), col("t1.problemid"), col("t1.hqt_sm"), col("t1.hat_sm"), col("t1.hqt_rd"), col("t1.hat_rd"), col("t2.aat_lmp"), col("t2.aqt_lmp"), col("t2.aat_m"), col("t2.aqt_m"))

def returnSmokeCD(problemtypecd, problemid, hqt_sm, hat_sm):
  if ((problemtypecd == "2" and problemid == "93") or (problemtypecd == "2" and problemid == "94")):
    if (hqt_sm != None) and ("smok" in hqt_sm):
      if ("Current smoker" in hat_sm) or ("Yes" in hat_sm):
        return "Y"
      else:
        return "N"

def returnDrugUseCD(problemtypecd, problemid, hqt_rd, hat_rd):
  if (problemtypecd == "2" and problemid == "97"):
    if (hqt_rd != None) and ("Recreational Drug Use" in hqt_rd):
      return hat_rd

returnSmokeCD_udf = udf(returnSmokeCD, StringType())
returnDrugUseCD_udf = udf(returnDrugUseCD, StringType())

dfFinal = dfMainHeaderAnswer.withColumn("src_sys_cd", lit("TC"))\
                            .withColumn("composite_type_cd", lit("#"))\
                            .withColumn("msg_type_cd", lit("#"))\
                            .withColumn("pat_src_id", col("patientid"))\
                            .withColumn("med_info_rec_dt", when(col("med_info_rec_dt").isNotNull(), col("med_info_rec_dt")).otherwise(lit("1900-01-01")))\
                            .withColumn("smoker_cd", returnSmokeCD_udf(col("problemtypecd"), col("problemid"), col("hqt_sm"), col("hat_sm")))\
                            .withColumn("last_mnstl_period_end_dt", when(col("aqt_lmp").like("Last Menstrual Period%"), col("aat_lmp")))\
                            .withColumn("drug_user_cd", returnDrugUseCD_udf(col("problemtypecd"), col("problemid"), col("hqt_rd"), col("hat_rd")))\
                            .withColumn("menopause_stat_desc", when(col("aat_m").like("%Menopaus%"), col("aqt_m")))\
                            .withColumn("pat_self_reportd_med_src_id", lit("#"))\
                            .withColumn("pat_med_info_dt", col("pat_med_info_dt"))\
                            .withColumn("hipaa_agremnt_cd", col("hipaacceptind"))\
                            .withColumn("pat_med_info_desc", lit(''))\
                            .withColumn("pat_med_info_opt_txt", lit(''))\
                            .withColumn("pregnancy_est_due_dt", lit(''))\
                            .withColumn("pregnancy_cd", lit(''))\
                            .select(col("pat_src_id"), col("src_sys_cd"), col("composite_type_cd"), col("msg_type_cd"), col("med_info_rec_dt"), col("pat_self_reportd_med_src_id"), col("pat_med_info_dt"), col("pat_med_info_desc"), col("pat_med_info_opt_txt"), col("last_mnstl_period_end_dt"), col("pregnancy_est_due_dt"), col("pregnancy_cd"), col("hipaa_agremnt_cd"), col("smoker_cd"), col("drug_user_cd"), col("menopause_stat_desc"))

display(dfFinal)

# COMMAND ----------

# Write output files

dfHeaderReject = spark.sql("SELECT patientid, med_info_rec_dt, headeranswerxml FROM dfXMLHeaderReject")
dfAnswerReject = spark.sql("SELECT patientid, med_info_rec_dt, answerxml FROM dfXMLAnswerReject")

data_location_output = "{0}/{1}/edw_idl_patient_tc_cif_tc_patient_sr_medical_info_full_ldr_{2}".format(mountPoint, dbutils.widgets.get('AI_SERIAL'), dbutils.widgets.get('pDAP_BATCH_ID'))
data_location_header_rej = "{0}/{1}/aic_{2}_HANSXML_REJ_{3}".format(mountPoint, dbutils.widgets.get('AI_SERIAL_REJECT'), dbutils.widgets.get('AI_GRAPH_NAME'), dbutils.widgets.get('pDAP_BATCH_ID'))
data_location_answer_rej = "{0}/{1}/aic_{2}_DANSXML_REJ_{3}".format(mountPoint, dbutils.widgets.get('AI_SERIAL_REJECT'), dbutils.widgets.get('AI_GRAPH_NAME'), dbutils.widgets.get('pDAP_BATCH_ID'))

dfFinal.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_output)
dfHeaderReject.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_header_rej)
dfAnswerReject.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_answer_rej)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

filesheaderrej = dbutils.fs.ls(data_location_header_rej)
csv_file_headerrej = [x.path for x in filesheaderrej if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_headerrej, data_location_header_rej.rstrip('/') + ".rej")
dbutils.fs.rm(data_location_header_rej, recurse = True)

filesanswerrej = dbutils.fs.ls(data_location_answer_rej)
csv_file_answerrej = [x.path for x in filesanswerrej if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_answerrej, data_location_answer_rej.rstrip('/') + ".rej")
dbutils.fs.rm(data_location_answer_rej, recurse = True)

# COMMAND ----------


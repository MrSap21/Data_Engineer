# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# Import Python libs
import json
import random
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import StringType


# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("INPUT_DATA_FILES_LIST","",label="INPUT_DATA_FILES_LIST")
dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")

input_data_files_list = dbutils.widgets.get("INPUT_DATA_FILES_LIST")

output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")

output_file_path = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir + '/' + batch_id

# COMMAND ----------

#to generate final columns
def genrate_final_col(df1,lst_data_type):
  selstr= ""
  select_col_str = []
  for fdt in df1.schema.fields:
    if str(fdt.dataType) not in lst_data_type:
      select_col_str.append(fdt.name)
    else:
      alsname = fdt.name + "_new"
      select_col_str.append(explode(fdt.name).alias(alsname))
  return select_col_str


# COMMAND ----------

#handle array type data for mp
def hc_provider_link_mp_arytpe(df,lst_data_type):
  df1=df.withColumn("entityID",col("providerInfo.entityID"))
  df1=df1.withColumn("locationEntityID",col("providerInfo.providerLocationInfo.locationEntityID"))
  
  df1=df1.select("entityID",col("locationEntityID"),"providerInfo.providerLocationInfo","messageInfo.*")
  select_col_str=genrate_final_col(df1,lst_data_type)

  df2=df1.select(*select_col_str)


  df4=df2.select("entityID","locationEntityID_new","providerLocationInfo","SourceSystem.*",col("UpdateDTTM").alias("updateDatetime"))

  df5=df4.select("entityID","locationEntityID_new",explode("providerLocationInfo"),col("name").alias("createUserId"),
                   col("updateDTTM").alias("createDTTM"),col("name").alias("updateUserId"),col("updateDatetime").alias("updateDTTM"))
  df5=df5.select("entityID","locationEntityID_new","col.*","createUserId","createDTTM","updateUserId","updateDTTM")
  select_col_str_new=genrate_final_col(df5,lst_data_type)

  df6=df5.select(*select_col_str_new)

  df6=df6.select("entityID","locationEntityID_new","sourceSystem","createUserId","createDTTM","updateUserId","updateDTTM",
                col("phone.areacode").alias("areacode"),"phone")
  select_col_str_new_a=genrate_final_col(df6,lst_data_type)
  df6=df6.select(*select_col_str_new_a)

  df6=df6.select("entityID","locationEntityID_new",explode("sourceSystem"),"createUserId","createDTTM","updateUserId",
                 "updateDTTM","areacode_new",col("phone.type").alias("type0"),"phone")
  select_col_str_new_a=genrate_final_col(df6,lst_data_type)
  df9=df6.select(*select_col_str_new_a)


  df9=df9.select("entityID","locationEntityID_new",col("col.name"),col("col.id"),col("col.id2"),"createUserId","createDTTM","updateUserId",
                 "updateDTTM","type0_new",col("phone.number").alias("number"),"areacode_new")
  select_col_str_new_a_f=genrate_final_col(df9,lst_data_type)
  df10=df9.select(*select_col_str_new_a_f)
  df10=df10.withColumn("extension",lit(None).cast('string'))


  df_final=df10.select("updateDTTM","updateUserId","createDTTM","id","id2","name","createUserId",
                      "entityID",col("locationEntityID_new").alias("locationEntityID"),
                      col("type0_new").alias("type0"),
                      col("areaCode_new").alias("areaCode"),col("number_new").alias("number"),"extension")
  return df_final

# COMMAND ----------

#handle struct type data for mp
def hc_provider_link_mp_struct_type(df,lst_data_type):
  df1=df.withColumn("entityID",col("providerInfo.entityID"))
  df1=df1.withColumn("locationEntityID",col("providerInfo.providerLocationInfo.locationEntityID"))

  df1=df1.select("entityID",col("locationEntityID").alias("locationEntityID_new"),"providerInfo.providerLocationInfo","messageInfo.*")
  select_col_str=genrate_final_col(df1,lst_data_type)

  df2=df1.select(*select_col_str)


  df3=df2.select("entityID","locationEntityID_new","providerLocationInfo.*","SourceSystem.*",col("UpdateDTTM").alias("updateDatetime"))

  select_col_str=genrate_final_col(df3,lst_data_type)
  df4=df3.select(*select_col_str)

  df5=df4.select("entityID","locationEntityID_new",
                 col("phone.type").alias("type0"),
                 col("phone"),col("name").alias("createUserId"),"sourceSystem.*",col("updateDTTM").alias("createDTTM"),
                 col("name").alias("updateUserId"),col("updateDatetime").alias("updateDTTM"))
  df5=df5.select("entityID","locationEntityID_new","createUserId","name","id","id2","createDTTM","updateUserId","updateDTTM","type0","phone")

  select_col_str_new=genrate_final_col(df5,lst_data_type)


  df6=df5.select(*select_col_str_new)
  df6=df6.select("entityID","locationEntityID_new","createUserId","name","id","id2","createDTTM","updateUserId","updateDTTM","type0_new",
                col("phone.areacode").alias("areacode"),"phone")
  select_col_str_new_a=genrate_final_col(df6,lst_data_type)
  df6=df6.select(*select_col_str_new_a)

  df6=df6.select("entityID","locationEntityID_new","createUserId","name","id","id2","createDTTM","updateUserId","updateDTTM","type0_new",
               col("phone.number").alias("number"),"areacode_new")
  select_col_str_new_a_f=genrate_final_col(df6,lst_data_type)
  df6=df6.select(*select_col_str_new_a_f)
  df6=df6.withColumn("extension",lit(None).cast('string'))


  df_final=df6.select("updateDTTM","updateUserId","createDTTM","createUserId","name","id","id2","entityID",
                    col("locationEntityID_new").alias("locationEntityID"),col("type0_new").alias("type0"),
                    col("areaCode_new").alias("areaCode"),col("number_new").alias("number"),"extension")
  
  return df_final

# COMMAND ----------

# Function to read a single XML file
def read_single_xml(df_files_meta, asset_item_id):  
  # Retrieve the specific input file path
  input_file = df_files_meta.filter('asset_id = {0}'.format(asset_item_id))\
                            .select('input_file_path')\
                            .rdd.flatMap(lambda x: x).collect()[0]
  #read xml file
  df = spark.read.format("com.databricks.spark.xml").option("rowTag","ns2:getProviderDetailResp").load(input_file)
  df_final = ""
  lst_data_type = ["ArrayType(LongType,true)","ArrayType(StringType,true)"]
  df_check=df.withColumn("providerLocationInfo_check",col("providerInfo.providerLocationInfo"))
  df_check=df_check.select("providerLocationInfo_check")
  lst=df_check.schema.simpleString()
  ls= lst.split(":")
  ls2=ls[1].split("<")
  print (ls2[0])
  if ls2[0] == "array":
    df_final = hc_provider_link_mp_arytpe(df,lst_data_type)
  else:
    df_final = hc_provider_link_mp_struct_type(df,lst_data_type)
  
  #select required columns
  df3=df_final.select("updateDTTM","entityID","locationEntityID","name","id","id2")
  df_final = df3.filter("name not like '%IC%'").filter("name not like '%RR%'").filter("name not like '%GW%'").filter("name not like '%TC%'")
  return df_final


# COMMAND ----------

# Get the files metadata
df_files_meta = get_files_meta_data(input_data_files_list)
# Read multiple xml files in parallel based on the files metedata and merge all in a single dataframe
df_final = process_multi_xml_parallel(df_files_meta)

# COMMAND ----------

# Write output (parquet)
global_temp_view_name = 'mp_hc_provider_link_' + str(random.randint(1,100))
df_final.createOrReplaceGlobalTempView(global_temp_view_name)
dbutils.notebook.run("../Utilities/WRITE_TO_STORAGE_PARQUET", 600, {"file_path": output_file_path, "file_extention": "", \
                                                                                  "view_name": global_temp_view_name, "delimiter": "", "has_header": "false"})
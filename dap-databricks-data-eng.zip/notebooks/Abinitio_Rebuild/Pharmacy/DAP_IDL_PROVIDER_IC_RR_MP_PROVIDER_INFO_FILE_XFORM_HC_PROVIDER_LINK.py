# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Import Python libs
import json
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("DELTA_FILE_NAME","",label="DELTA_FILE_NAME")
dbutils.widgets.text("DELTA_FILE_DIR","",label="DELTA_FILE_DIR")
dbutils.widgets.text("OUTPUT_DATA_FILE_PATH_ROOT","",label="OUTPUT_DATA_FILE_PATH_ROOT")
dbutils.widgets.text("OUTPUT_DATA_FILE_PARQUET_DIR","",label="OUTPUT_DATA_FILE_PARQUET_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")


output_data_file_path_root = dbutils.widgets.get("OUTPUT_DATA_FILE_PATH_ROOT")
output_data_file_parquet_dir = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR")
batch_id = dbutils.widgets.get("BATCH_ID")
delta_file_name = dbutils.widgets.get("DELTA_FILE_NAME")
delta_file_dir = dbutils.widgets.get("DELTA_FILE_DIR")
delta_file_path = mount_point + '/' + delta_file_dir + '/' + delta_file_name + '/' + batch_id

output_data_file_parquet_dir_ic = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR").split(",")[0]
output_data_file_parquet_dir_rr = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR").split(",")[1]
output_data_file_parquet_dir_mp = dbutils.widgets.get("OUTPUT_DATA_FILE_PARQUET_DIR").split(",")[2]

output_file_path_ic = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir_ic + '/' + batch_id
output_file_path_rr = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir_rr + '/' + batch_id
output_file_path_mp = mount_point + '/' + output_data_file_path_root + '/' + output_data_file_parquet_dir_mp + '/' + batch_id

# COMMAND ----------

# Define column values in List((tuple0,tuple1)) -- List((columnnamewithrelativetags,onlycolumnname))
col_list = [("messageInfo_SourceSystem_updateDTTM","sourceupdateDTTM"),("providerInfo_entityID","entityID"),("providerInfo_providerLocationInfo_locationEntityID","locationEntityID"),("providerInfo_providerLocationInfo_sourceSystem_name","name"),("providerInfo_providerLocationInfo_sourceSystem_id","id"),("providerInfo_providerLocationInfo_sourceSystem_id2","id2")]

selected  = [col(j) for k, j in col_list]

# COMMAND ----------

#Read from delta

delta_df = spark.read.format("delta").load(delta_file_path)


# COMMAND ----------

df_result=delta_df.select(*selected)
df_result= df_result.withColumnRenamed('sourceupdateDTTM','updateDTTM')
result_df=df_result.dropDuplicates()


# COMMAND ----------

# Cache for better performance
####df_final--o/p of read_flattened_xml(new function)
result_df.cache()

# Prepare IC, RR & MP dataframes & write (parquet) separately 
# IC
result_df_ic = result_df.filter("name like '%IC%'")
write_data(result_df_ic,output_file_path_ic)

# RR
result_df_rr = result_df.filter("name like '%RR%'") 
write_data(result_df_rr,output_file_path_rr)

# MP
result_df_mp = result_df.filter("name not like '%IC%' and name not like '%RR%' and name not like '%GW%' and name not like '%TC%'")
write_data(result_df_mp,output_file_path_mp)

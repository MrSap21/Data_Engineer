# Databricks notebook source
#dbutils.widgets.removeAll()

# COMMAND ----------

'''
dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
dbutils.widgets.text("PAR_DF_STG_DB","DEV_STAGING")
dbutils.widgets.text("PAR_DF_STG_DB1","DEV_CONSUMPTION")
dbutils.widgets.text("PAR_DF_STG_DB2","DEV_MASTER_DATA")
dbutils.widgets.text("PAR_DF_TABLE1","PARTNER.EMNOS_EXT_CARD_FILE_DRIVER_STG")
dbutils.widgets.text("PAR_DF_TABLE2","PRDFDLVWB.DIM_LOYALTY_CUSTOMER_CUR_BVW")
dbutils.widgets.text("PAR_DF_TABLE3","PRDFDLVWB.LOYALTY_CUSTOMER_PROGRAM_BVW")
dbutils.widgets.text("PAR_DF_TABLE4","PARTNER.LOYALTY_TEST_MEMBERS_STG")
dbutils.widgets.text("PAR_DF_TABLE5","PRDFDLVWR.dim_mid_customer_cur_bvw")
dbutils.widgets.text("PAR_DF_TABLE6","CUSTOMER.CUSTOMER_ADDRESS")
dbutils.widgets.text("PAR_DF_BATCH_ID","20220606000000")
dbutils.widgets.text("PAR_DF_OUTPUT_STG_FILE_PATH","master_data/partner/staging")
'''

# COMMAND ----------

PAR_STG_DB=dbutils.widgets.get("PAR_DF_STG_DB")
PAR_STG_DB1=dbutils.widgets.get("PAR_DF_STG_DB1")
PAR_STG_DB2=dbutils.widgets.get("PAR_DF_STG_DB2")
PAR_TABLE1=dbutils.widgets.get("PAR_DF_TABLE1")
PAR_TABLE2=dbutils.widgets.get("PAR_DF_TABLE2")
PAR_TABLE3=dbutils.widgets.get("PAR_DF_TABLE3")
PAR_TABLE4=dbutils.widgets.get("PAR_DF_TABLE4")
PAR_TABLE5=dbutils.widgets.get("PAR_DF_TABLE5")
PAR_TABLE6=dbutils.widgets.get("PAR_DF_TABLE6")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
PAR_BATCH_ID=dbutils.widgets.get("PAR_DF_BATCH_ID")
PAR_OUTPUT_STG_FILE_PATH=dbutils.widgets.get("PAR_DF_OUTPUT_STG_FILE_PATH")

# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=PAR_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

query1="""SELECT
mid AS CARD_KEY ,
'A' AS CARD_STATUS_KEY,
NULL AS CARD_TYPE_KEY,
NULL AS CARD_START_DATE,
NULL AS CARD_END_DATE,
NULL AS CARD_GROUP_01_KEY,
NULL AS CUSTOMER_BIRTH_DATE,
NULL AS CUSTOMER_GENDER,
NULL AS STATE,
NULL AS EMPLOYEE_KEY,
NULL AS NEAREST_WG_DISTANCE,
NULL AS NEAREST_COMPT_DISTANCE,
NULL AS SPECIAL_MEMBER,
NULL AS NBR_OF_CHILD,
NULL AS CHILD_DOB_1,
NULL AS CHILD_DOB_2,
NULL AS CHILD_DOB_3,
NULL AS CHILD_DOB_4,
NULL AS HOUSEHOLD_SZ,
NULL AS JOIN_KEY
FROM {0}.{1}
WHERE src_sys_cd='M' and mid NOT LIKE 'L%'
group by 1,2;""".format(PAR_STG_DB,PAR_TABLE1)
print(query1)

# COMMAND ----------

df_q1_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query1)\
   .load()
#df_q1_out.show()

# COMMAND ----------

query2="""SELECT
e."loyalty_mbr_id" AS member_id ,
SUBSTR(m.mid,2) AS card_key,
a.prog_stat_cd AS card_status_key,
(CASE WHEN a.prog_cd = 'VCD' THEN 'LY' WHEN a.prog_cd LIKE '%DR%' THEN 'DR' ELSE NULL END) AS card_type_key,
a.prog_start_dt AS card_start_date, a.prog_end_dt AS card_end_date,
NULL AS customer_birth_date ,

e.gndr_cd AS customer_gender, e.perm_state_cd AS state,
(CASE WHEN emp.member_id IS NOT NULL THEN 'Y' ELSE 'N' END) AS employee_key,
(CASE WHEN mgr.loyalty_mbr_id IS NOT NULL THEN 'T' ELSE NULL END) AS store_manager_ind
FROM {1}.prdfdlvwr.dim_loyalty_customer_cur_bvw AS e
LEFT OUTER JOIN
(SELECT loyalty_mbr_id, prog_stat_cd,prog_start_dt,prog_end_dt,prog_cd,cust_sk
FROM {1}.prdfdlvwr.loyalty_customer_program_bvw
WHERE prog_cd like ('VCD') OR PROG_CD LIKE ('%DR%')
QUALIFY ROW_NUMBER() OVER(PARTITION BY loyalty_mbr_id ORDER BY prog_cd ) = 1 ) AS a
ON a.cust_sk= e.loyalty_cust_sk
JOIN (SELECT DISTINCT SUBSTR(mid,2) AS join_key , mid FROM {0}.{2} where src_sys_cd<>'C' ) AS m
ON e."mid" = m.join_key
LEFT OUTER JOIN
(SELECT loyalty_mbr_id AS member_id
FROM {1}.prdfdlvwr.loyalty_customer_program_bvw  AS a WHERE a.prog_cd IN ('EEDR','EEWAG') ) AS emp
ON emp.member_id = a.loyalty_mbr_id
LEFT OUTER JOIN {0}.{5} AS mgr
ON mgr.loyalty_mbr_id = a.loyalty_mbr_id
group by 1,2,3,4,5,6,7,8,9,10,11
ORDER BY Card_key;""".format(PAR_STG_DB,PAR_STG_DB1,PAR_TABLE1,PAR_TABLE2,PAR_TABLE3,PAR_TABLE4)
print(query2)

# COMMAND ----------

df_q2_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query2)\
   .load()
#df_q2_out.show()

# COMMAND ----------

query3="""select card_key,customer_birth_date,customer_gender,state,nearest_wg_distance,nearest_compt_distance,join_key,CARD_STATUS_KEY,CARD_TYPE_KEY,CARD_START_DATE,CARD_END_DATE,CARD_GROUP_01_KEY,SPECIAL_MEMBER,
NBR_OF_CHILD,CHILD_DOB_1,CHILD_DOB_2,CHILD_DOB_3,CHILD_DOB_4,HOUSEHOLD_SZ
from (select *,row_number() over (partition by join_key order by join_key) as rn from  (SELECT b.mid AS card_key ,
NULL AS customer_birth_date,
a.gndr_cd AS customer_gender ,
a.perm_state_cd AS state ,
f.closest_wag_store_distance_mil AS nearest_wg_distance,
f.closest_competitor_distance_mi AS nearest_compt_distance ,
b.join_key,
null as CARD_STATUS_KEY,
null as CARD_TYPE_KEY,
null as CARD_START_DATE,
null as CARD_END_DATE,
null as CARD_GROUP_01_KEY,
null as SPECIAL_MEMBER,
null as NBR_OF_CHILD,
null as CHILD_DOB_1,
null as CHILD_DOB_2,
null as CHILD_DOB_3,
null as CHILD_DOB_4,
null as HOUSEHOLD_SZ
FROM (SELECT SUBSTR(mid,2) AS join_key , mid FROM {0}.{3} where src_sys_cd<>'C' group by 1,2 ) AS b
JOIN (SELECT "mid", brth_dt, gndr_cd, perm_state_cd FROM {1}.{4} ) AS a
ON a."mid" = b.join_key
LEFT OUTER JOIN ( SELECT cust_src_id , closest_wag_store_distance_mil,closest_competitor_distance_mi
FROM {2}.CUSTOMER.CUSTOMER_ADDRESS WHERE COMPOSITE_TYPE_CD = 'A'and src_sys_cd='CDI' and edw_rec_end_dt='9999-12-31' and msg_type_cd='1' ) AS f
ON f.cust_src_id = a."mid"
ORDER BY join_key) a) b where rn =1 """.format(PAR_STG_DB,PAR_STG_DB1,PAR_STG_DB2,PAR_TABLE1,PAR_TABLE5,PAR_TABLE6)
print(query3)

# COMMAND ----------

df_q3_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query3)\
   .load()
#df_q3_out.show()
df_q3_out_cachedDF=df_q3_out.cache()

# COMMAND ----------

#full outer join for loyalty members
full_q2_q3=df_q2_out.alias("in0").join(df_q3_out_cachedDF.alias("in1"),df_q2_out.CARD_KEY==df_q3_out_cachedDF.CARD_KEY,'fullouter').select(coalesce(col("in0.MEMBER_ID"),col("in1.CARD_KEY")).alias("CARD_KEY"), \
                                                                                                                         coalesce(col("in0.CARD_STATUS_KEY"), lit("A")).alias("CARD_STATUS_KEY"), \
                                                                                                                        coalesce(col("in0.CARD_TYPE_KEY"),col("in1.CARD_TYPE_KEY")).alias("CARD_TYPE_KEY"), \
                                                                                                                        coalesce(col("in0.CARD_START_DATE"),col("in1.CARD_START_DATE")).alias("CARD_START_DATE"), \
                                                                                                                        coalesce(col("in0.CUSTOMER_BIRTH_DATE"),col("in1.CUSTOMER_BIRTH_DATE")).alias("CUSTOMER_BIRTH_DATE"), \
                                                                                                                         coalesce(col("in0.CUSTOMER_GENDER"),col("in1.CUSTOMER_GENDER")).alias("CUSTOMER_GENDER"), \
                                                                                                                         coalesce(col("in0.STATE"),col("in1.STATE")).alias("STATE"), \
                                                                                                                         col("in1.NBR_OF_CHILD"), \
                                                                                                                         col("in1.CHILD_DOB_1"), \
                                                                                                                         col("in1.CHILD_DOB_2"), \
                                                                                                                         col("in1.CHILD_DOB_3"), \
                                                                                                                         col("in1.CHILD_DOB_4"), \
                                                                                                                         col("in1.HOUSEHOLD_SZ"), \
                                                                                                                         col("in0.STORE_MANAGER_IND").alias("SPECIAL_MEMBER"), \
                                                                                                                         col("in1.NEAREST_WG_DISTANCE"), \
                                                                                                                         col("in1.NEAREST_COMPT_DISTANCE"), \
                                                                                                                         coalesce(col("in0.CARD_KEY"),col("in1.JOIN_KEY")).alias("JOIN_KEY"), \
                                                                                                                         col("in0.EMPLOYEE_KEY"), \
                                                                                                                         col("in0.CARD_END_DATE"),lit(None).alias("JOIN_KEY"))

# COMMAND ----------

left_anti=df_q1_out.join(full_q2_q3,df_q1_out.CARD_KEY==full_q2_q3.CARD_KEY,'leftanti')
gather3=left_anti.union(full_q2_q3)

# COMMAND ----------

rfmt_lylty_mid=gather3.withColumn("CARD_ATTRIBUTE01",lit("")).drop("JOIN_KEY")

# COMMAND ----------

query4="""select CARD_KEY,
NULL AS CARD_STATUS_KEY,
NULL AS CARD_TYPE_KEY,
NULL AS CARD_START_DATE,
NULL AS CARD_END_DATE,
NULL AS CARD_GROUP_01_KEY,
NULL AS CUSTOMER_BIRTH_DATE,
NULL AS CUSTOMER_GENDER,
NULL AS STATE,
NULL AS EMPLOYEE_KEY,
NULL AS NEAREST_WG_DISTANCE,
NULL AS NEAREST_COMPT_DISTANCE,
NULL AS SPECIAL_MEMBER,
NULL AS NBR_OF_CHILD,
NULL AS CHILD_DOB_1,
NULL AS CHILD_DOB_2,
NULL AS CHILD_DOB_3,
NULL AS CHILD_DOB_4,
NULL AS HOUSEHOLD_SZ,
NULL AS CARD_ATTRIBUTE01
from {0}.{1} where src_sys_cd='C';""".format(PAR_STG_DB,PAR_TABLE1)
df_cc = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query4)\
   .load()
#df_cc.show()


# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,TimestampType



schema = StructType([ \
    StructField("CARD_KEY",StringType(),True), \
    StructField("CARD_STATUS_KEY",StringType(),True), \
    StructField("CARD_TYPE_KEY",StringType(),True),\
    StructField("CARD_START_DATE",StringType(),True), \
    StructField("CARD_END_DATE",StringType(),True), \
    StructField("CARD_GROUP_01_KEY",StringType(),True), \
     StructField("CUSTOMER_BIRTH_DATE",StringType(),True), \
    StructField("CUSTOMER_GENDER",StringType(),True), \
    StructField("STATE",StringType(),True),\
    StructField("EMPLOYEE_KEY",StringType(),True), \
    StructField("NEAREST_WG_DISTANCE",StringType(),True), \
    StructField("NEAREST_COMPT_DISTANCE",StringType(),True), \
    StructField("SPECIAL_MEMBER",StringType(),True), \
    StructField("NBR_OF_CHILD",StringType(),True), \
    StructField("CHILD_DOB_1",StringType(),True), \
    StructField("CHILD_DOB_2",StringType(),True), \
    StructField("CHILD_DOB_3",StringType(),True), \
    StructField("CHILD_DOB_4",StringType(),True), \
    StructField("HOUSEHOLD_SZ",StringType(),True),StructField("CARD_ATTRIBUTE01",StringType(),True)                 
           ])
 
#df_proc = spark.createDataFrame(data=data2,schema=schema)


# COMMAND ----------

newDF1 = spark.createDataFrame(rfmt_lylty_mid.rdd, schema=schema)

# COMMAND ----------

#df_cc.schema['CARD_KEY'].nullable=True

newDF2 = spark.createDataFrame(df_cc.rdd, schema=schema)
#df_cc.withColumn("CARD_KEY", when(df_cc.CARD_KEY.isNotNull(), df_cc.CARD_KEY).otherwise(lit(None)))
#df_cc.printSchema()


# COMMAND ----------

gather=newDF1.unionByName(newDF2)

# COMMAND ----------

rfmt_card_file=gather.withColumn("CARD_KEY",when(gather.CARD_KEY.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("CARD_KEY")),lit("\"")))) \
.withColumn("CARD_STATUS_KEY",when(gather.CARD_STATUS_KEY.isNull(),concat(lit("\""),lit("A"),lit("\""))).otherwise(concat(lit("\""),ltrim(col("CARD_STATUS_KEY")),lit("\"")))) \
.withColumn("CARD_TYPE_KEY",when(gather.CARD_TYPE_KEY.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("CARD_TYPE_KEY")),lit("\""))))\
.withColumn("CARD_START_DATE",gather.CARD_START_DATE) \
.withColumn("CARD_GROUP_01_KEY",when(gather.CARD_GROUP_01_KEY.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("CARD_GROUP_01_KEY")),lit("\"")))) \
.withColumn("CARD_GROUP_02_KEY",concat(lit("\""),lit("\"")))\
.withColumn("CUSTOMER_BIRTH_DATE",concat(gather.CUSTOMER_BIRTH_DATE,lit("-01-01")))\
.withColumn("CUSTOMER_GENDER",when(gather.CUSTOMER_GENDER.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("CUSTOMER_GENDER")),lit("\"")))) \
.withColumn("COUNTRY",concat(lit("\""),lit("\""))) \
.withColumn("STATE",when(gather.STATE.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("STATE")),lit("\"")))) \
.withColumn("CITY",concat(lit("\""),lit("\""))) \
.withColumn("ZIP_CODE",concat(lit("\""),lit("\""))) \
.withColumn("EMPLOYEE_KEY",concat(lit("\""),ltrim(col("EMPLOYEE_KEY")),lit("\""))) \
.withColumn("NBR_OF_CHILD",gather.NBR_OF_CHILD) \
.withColumn("CHILD_DOB_1",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_2",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_3",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_4",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_5",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_6",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_7",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_8",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_9",lit(None).cast(StringType()))\
.withColumn("CHILD_DOB_10",lit(None).cast(StringType()))\
.withColumn("HOUSEHOLD_SZ",gather.HOUSEHOLD_SZ)\
.withColumn("MARTIAL_STATUS",concat(lit("\""),lit("\""))) \
.withColumn("NEAREST_WG_DISTANCE",gather.NEAREST_WG_DISTANCE) \
.withColumn("NEAREST_COMPT_DISTANCE",gather.NEAREST_COMPT_DISTANCE) \
.withColumn("SPECIAL_MEMBER",when(gather.SPECIAL_MEMBER.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("SPECIAL_MEMBER")),lit("\"")))) \
.withColumn("CHRONIC_SEGMENT",when(gather.CARD_ATTRIBUTE01.isNull(),lit("\"\"")).otherwise(concat(lit("\""),ltrim(col("CARD_ATTRIBUTE01")),lit("\"")))) \
.withColumn("CARD_ATTRIBUTE05",concat(lit("\""),lit("\""))) \
.withColumn("CARD_END_DATE",gather.CARD_END_DATE) \
.select("CARD_KEY",
"CARD_STATUS_KEY",
"CARD_TYPE_KEY",
"CARD_START_DATE",
"CARD_END_DATE",
"CARD_GROUP_01_KEY",
"CARD_GROUP_02_KEY",
"CUSTOMER_BIRTH_DATE",
"CUSTOMER_GENDER",
"COUNTRY",
"STATE",
"CITY",
"ZIP_CODE",
"EMPLOYEE_KEY",
"NBR_OF_CHILD",
"CHILD_DOB_1",
"CHILD_DOB_2",
"CHILD_DOB_3",
"CHILD_DOB_4",
"CHILD_DOB_5",
"CHILD_DOB_6",
"CHILD_DOB_7",
"CHILD_DOB_8",
"CHILD_DOB_9",
"CHILD_DOB_10",
"HOUSEHOLD_SZ",
"MARTIAL_STATUS",
"NEAREST_WG_DISTANCE",
"NEAREST_COMPT_DISTANCE",
"SPECIAL_MEMBER",
"CHRONIC_SEGMENT",
"CARD_ATTRIBUTE05")


# COMMAND ----------

path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,'dap_out_emons_ext_outf_card_file',PAR_BATCH_ID)
rfmt_card_file.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

rec_count=rfmt_card_file.count()
from pyspark.sql.types import StructType,StructField,IntegerType,TimestampType
data2 = [[rec_count]]
print(data2)
 

schema = StructType([ \
    StructField("rec_count",IntegerType(),True)
    ])
 
df_proc = spark.createDataFrame(data=data2,schema=schema)


path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,'dap_out_emons_ext_card_file_record_cnt_20120403163612',PAR_BATCH_ID)
df_proc.write.format("parquet").mode("overwrite").save(path)


# COMMAND ----------

df_q3_out_cachedDF.unpersist()
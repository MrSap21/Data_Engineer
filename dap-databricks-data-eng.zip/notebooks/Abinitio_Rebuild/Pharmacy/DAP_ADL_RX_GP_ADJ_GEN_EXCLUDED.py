# Databricks notebook source
dbutils.widgets.text("PAR_NB_AI_SERIAL","",label="PAR_NB_AI_SERIAL")
dbutils.widgets.text("PAR_NB_INPUT_OUTPUT_FILE","",label="PAR_NB_INPUT_OUTPUT_FILE")
dbutils.widgets.text("PAR_NB_ADJ_PERIOD","",label="PAR_NB_ADJ_PERIOD")
dbutils.widgets.text("PAR_NB_DML_COLUMNS","",label="PAR_NB_DML_COLUMNS")
dbutils.widgets.text("PAR_NB_PARAM_3","",label="PAR_NB_PARAM_3")

par_file_path = dbutils.widgets.get("PAR_NB_AI_SERIAL")
par_input_file = dbutils.widgets.get("PAR_NB_INPUT_OUTPUT_FILE")
par_adj_period= dbutils.widgets.get("PAR_NB_ADJ_PERIOD")
par_dml_columns=dbutils.widgets.get("PAR_NB_DML_COLUMNS")
par_param_3=dbutils.widgets.get("PAR_NB_PARAM_3")

mountPoint="/mnt/wrangled"

InputFile  = mountPoint +"/"+ par_file_path + "/" + par_input_file + ".dat"
outputFile = mountPoint +"/"+ par_file_path + "/" + par_input_file + "_" +par_adj_period +".xlsx"


#Replacing sheet text with required value
replaced_header = par_dml_columns.replace("sheet",par_param_3)


# COMMAND ----------

from pyspark.sql.types import (StringType,IntegerType,StructType,StructField)
from pyspark.sql.functions import lit,row_number,col
from pyspark.sql.window import Window

#This function will use the Data and sheet# as input and append the new sheet into existing Output Excel File
def write_to_sheet(df,sheet_num):
      Sheet_Name ={"SheetName":sheet_num}
      df.write.format("com.crealytics.spark.excel")\
              .option("header", True)\
              .options(**Sheet_Name)\
              .mode("append")\
              .save(outputFile) 

#Read Input File 
df = spark.read.format("csv").options(delimiter=' ').option("header", False).load(InputFile)
display(df)




# COMMAND ----------

replaced_header_list=replaced_header.split(" ")
final_output_df=df

if(df.count() > 0):
  final_output_df=df.toDF(*replaced_header_list)

  

#write to excel
write_to_sheet(final_output_df,1)



# COMMAND ----------

#Delete the Input file used
dbutils.fs.rm(InputFile)

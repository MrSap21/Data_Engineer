# Databricks notebook source
# Return connection details

options = eval(dbutils.notebook.run("../Utilities/SnowflakeConnOptions", 60))

# COMMAND ----------

# Load data to dataframe

df = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", dbutils.widgets.get("pSQL_QUERY")) \
  .load()

# COMMAND ----------

# Validation

from pyspark.sql.types import *
from pyspark.sql.functions import *

dfValidation = df.withColumn("ERROR_MSG", when(len(translate(trim(col("wag_store_id")), ".", "")) > 5, lit("Size of destination is 5 character and input has 6 character")).otherwise(""))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("prescription_ref_no_402d2")) == "") | (col("prescription_ref_no_402d2").isNull()), concat(col("ERROR_MSG"), " Invalid String in prescription_ref_no_402d2")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_fill_partial_nbr")) == "") | (col("pcc_fill_partial_nbr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_fill_partial_nbr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((col("date_authorized").isNotNull()) & (to_date(col("date_authorized"), "yyyyMMdd").isNull()), concat(col("ERROR_MSG"), " Invalid Date in date_authorized")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((col("time_authorized").isNotNull()) & (to_date(col("time_authorized"), "HH:MM:SS").isNull()), concat(col("ERROR_MSG"), " Invalid Time in time_authorized")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((col("service_date_401d1").isNotNull()) & (to_date(col("service_date_401d1"), "yyyyMMdd").isNull()), concat(col("ERROR_MSG"), " Invalid Date in service_date_401d1")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((col("wag_fill_sold_tm").isNotNull()) & (to_date(col("wag_fill_sold_tm"), "HH:MM:SS").isNull()), concat(col("ERROR_MSG"), " Invalid Time in wag_fill_sold_tm")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("anonymous_patient_id")) == "") | (col("anonymous_patient_id").isNull()), concat(col("ERROR_MSG"), " Invalid String in anonymous_patient_id")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_id")) == "") | (col("pcc_pbr_id").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_id")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_loc_id")) == "") | (col("pcc_pbr_loc_id").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_loc_id")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_drug_id")) == "") | (col("pcc_drug_id").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_drug_id")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_stat_cd")) == "") | (col("wag_fill_stat_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_stat_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("fill_num_403d3")) == "") | (col("fill_num_403d3").isNull()), concat(col("ERROR_MSG"), " Invalid String in fill_num_403d3")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("quantity_dispensed_442e7")) == "") | (col("quantity_dispensed_442e7").isNull()), concat(col("ERROR_MSG"), " Invalid String in quantity_dispensed_442e7")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("days_supply_405d5")) == "") | (col("days_supply_405d5").isNull()), concat(col("ERROR_MSG"), " Invalid String in days_supply_405d5")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("prescription_type_60149")) == "") | (col("prescription_type_60149").isNull()), concat(col("ERROR_MSG"), " Invalid String in prescription_type_60149")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_partial_fill_cd")) == "") | (col("pcc_partial_fill_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_partial_fill_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_refills_remaining")) == "") | (col("pcc_refills_remaining").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_refills_remaining")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("payer1_type")) == "") | (col("payer1_type").isNull()), concat(col("ERROR_MSG"), " Invalid String in payer1_type")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_vrfy_dt")) == "") | (col("wag_fill_vrfy_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_vrfy_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_vrfy_tm")) == "") | (col("wag_fill_vrfy_tm").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_vrfy_tm")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_data_review_dt")) == "") | (col("wag_fill_data_review_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_data_review_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_data_review_tm")) == "") | (col("wag_fill_data_review_tm").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_data_review_tm")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_filling_dt")) == "") | (col("wag_filling_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_filling_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_filling_tm")) == "") | (col("wag_filling_tm").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_filling_tm")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_del_dt")) == "") | (col("wag_fill_del_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_del_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_del_tm")) == "") | (col("wag_fill_del_tm").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_del_tm")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("plan_id_524fo")) == "") | (col("plan_id_524fo").isNull()), concat(col("ERROR_MSG"), " Invalid String in plan_id_524fo")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_cob_ind")) == "") | (col("wag_cob_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_cob_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("trans_response_status_112an")) == "") | (col("trans_response_status_112an").isNull()), concat(col("ERROR_MSG"), " Invalid String in trans_response_status_112an")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_adjud_dt")) == "") | (col("wag_fill_adjud_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_adjud_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_adjud_tm")) == "") | (col("wag_fill_adjud_tm").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_adjud_tm")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("cardholder_id_302c2_encrypted")) == "") | (col("cardholder_id_302c2_encrypted").isNull()), concat(col("ERROR_MSG"), " Invalid String in cardholder_id_302c2_encrypted")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("group_id_301c1")) == "") | (col("group_id_301c1").isNull()), concat(col("ERROR_MSG"), " Invalid String in group_id_301c1")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("ingredient_cost_submit_409d9")) == "") | (col("ingredient_cost_submit_409d9").isNull()), concat(col("ERROR_MSG"), " Invalid String in ingredient_cost_submit_409d9")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("dispensing_fee_submitted_412dc")) == "") | (col("dispensing_fee_submitted_412dc").isNull()), concat(col("ERROR_MSG"), " Invalid String in dispensing_fee_submitted_412dc")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_del_dt")) == "") | (col("wag_fill_del_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_del_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_del_dt")) == "") | (col("wag_fill_del_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_del_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_del_dt")) == "") | (col("wag_fill_del_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_del_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_fill_del_dt")) == "") | (col("wag_fill_del_dt").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_fill_del_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when(len(translate(trim(col("PATIENT_PAID_AMT_SUBMIT_433DX")), ".", "")) > 9, lit("Size of destination is 9 character and input has 10 character")).otherwise(""))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_fill_awp_cost_amt")) == "") | (col("pcc_fill_awp_cost_amt").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_fill_awp_cost_amt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("flatsalestax_amt_submit_481ha")) == "") | (col("flatsalestax_amt_submit_481ha").isNull()), concat(col("ERROR_MSG"), " Invalid String in flatsalestax_amt_submit_481ha")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("claim_reference_id_435dz")) == "") | (col("claim_reference_id_435dz").isNull()), concat(col("ERROR_MSG"), " Invalid String in claim_reference_id_435dz")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("bin_num_101a1")) == "") | (col("bin_num_101a1").isNull()), concat(col("ERROR_MSG"), " Invalid String in bin_num_101a1")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("reject_cd_1_511fb")) == "") | (col("reject_cd_1_511fb").isNull()), concat(col("ERROR_MSG"), " Invalid String in reject_cd_1_511fb")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("reject_cd_2_511fb")) == "") | (col("reject_cd_2_511fb").isNull()), concat(col("ERROR_MSG"), " Invalid String in reject_cd_2_511fb")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("reject_cd_3_511fb")) == "") | (col("reject_cd_3_511fb").isNull()), concat(col("ERROR_MSG"), " Invalid String in reject_cd_3_511fb")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("reject_count_510fa")) == "") | (col("reject_count_510fa").isNull()), concat(col("ERROR_MSG"), " Invalid String in reject_count_510fa")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((col("date_prescript_written_414de").isNotNull()) & (to_date(col("date_prescript_written_414de"), "yyyyMMdd").isNull()), concat(col("ERROR_MSG"), " Invalid Date in date_prescript_written_414de")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("num_refills_auth_415df")) == "") | (col("num_refills_auth_415df").isNull()), concat(col("ERROR_MSG"), " Invalid String in num_refills_auth_415df")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("orig_presc_quantity_446eb")) == "") | (col("orig_presc_quantity_446eb").isNull()), concat(col("ERROR_MSG"), " Invalid String in orig_presc_quantity_446eb")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("compound_cd_406d6")) == "") | (col("compound_cd_406d6").isNull()), concat(col("ERROR_MSG"), " Invalid String in compound_cd_406d6")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("daw_prod_selection_cd_408d8")) == "") | (col("daw_prod_selection_cd_408d8").isNull()), concat(col("ERROR_MSG"), " Invalid String in daw_prod_selection_cd_408d8")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_fill_auto_ind")) == "") | (col("pcc_fill_auto_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_fill_auto_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_daw_cd")) == "") | (col("pcc_daw_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_daw_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_rx_sig")) == "") | (col("pcc_rx_sig").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_rx_sig")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_sub_pref_cd")) == "") | (col("pcc_pat_sub_pref_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_sub_pref_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("first_name")) == "") | (col("first_name").isNull()), concat(col("ERROR_MSG"), " Invalid String in first_name")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("last_name")) == "") | (col("last_name").isNull()), concat(col("ERROR_MSG"), " Invalid String in last_name")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((col("brth_dt").isNotNull()) & (to_date(col("brth_dt"), "yyyyMMdd").isNull()), concat(col("ERROR_MSG"), " Invalid Date in brth_dt")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("patient_gender_305c5")) == "") | (col("patient_gender_305c5").isNull()), concat(col("ERROR_MSG"), " Invalid String in patient_gender_305c5")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_lock_store_nbr")) == "") | (col("pcc_pat_lock_store_nbr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_lock_store_nbr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_lock_ind")) == "") | (col("pcc_lock_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_lock_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_generic_subs_pref")) == "") | (col("pcc_pat_generic_subs_pref").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_generic_subs_pref")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_mail_list_pref")) == "") | (col("pcc_pat_mail_list_pref").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_mail_list_pref")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_lang_cd")) == "") | (col("pcc_pat_lang_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_lang_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_phone_contact_pref_ind")) == "") | (col("pcc_pat_phone_contact_pref_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_phone_contact_pref_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_pet_ind")) == "") | (col("pcc_pat_pet_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_pet_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_hipaa_ind")) == "") | (col("pcc_pat_hipaa_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_hipaa_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_internet_ind")) == "") | (col("pcc_pat_internet_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_internet_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_algy_hlth_type_cd")) == "") | (col("pcc_pat_algy_hlth_type_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_algy_hlth_type_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pat_algy_cd_inq_ind")) == "") | (col("pcc_pat_algy_cd_inq_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pat_algy_cd_inq_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pat_addr_line")) == "") | (col("pat_addr_line").isNull()), concat(col("ERROR_MSG"), " Invalid String in pat_addr_line")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pat_city")) == "") | (col("pat_city").isNull()), concat(col("ERROR_MSG"), " Invalid String in pat_city")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("patient_state_province_324_co")) == "") | (col("patient_state_province_324_co").isNull()), concat(col("ERROR_MSG"), " Invalid String in patient_state_province_324_co")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("patient_zip_325cp")) == "") | (col("patient_zip_325cp").isNull()), concat(col("ERROR_MSG"), " Invalid String in patient_zip_325cp")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pat_comm_channel_val")) == "") | (col("pat_comm_channel_val").isNull()), concat(col("ERROR_MSG"), " Invalid String in pat_comm_channel_val")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("patient_rel_to_ins_306c6")) == "") | (col("patient_rel_to_ins_306c6").isNull()), concat(col("ERROR_MSG"), " Invalid String in patient_rel_to_ins_306c6")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_person_cd")) == "") | (col("pcc_person_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_person_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("prescriber_id_411db")) == "") | (col("prescriber_id_411db").isNull()), concat(col("ERROR_MSG"), " Invalid String in prescriber_id_411db")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("prescriber_id_qualifer_466ez")) == "") | (col("prescriber_id_qualifer_466ez").isNull()), concat(col("ERROR_MSG"), " Invalid String in prescriber_id_qualifer_466ez")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_first_name")) == "") | (col("pcc_pbr_first_name").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_first_name")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_mid_init")) == "") | (col("pcc_pbr_mid_init").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_mid_init")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("prescriber_last_name_427dr")) == "") | (col("prescriber_last_name_427dr").isNull()), concat(col("ERROR_MSG"), " Invalid String in prescriber_last_name_427dr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_addr")) == "") | (col("pcc_pbr_addr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_addr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_city")) == "") | (col("pcc_pbr_city").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_city")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_state_cd")) == "") | (col("pcc_pbr_state_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_state_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_zip")) == "") | (col("pcc_pbr_zip").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_zip")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_phone_area_cd")) == "") | (col("pcc_pbr_phone_area_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_phone_area_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_phone_nbr")) == "") | (col("pcc_pbr_phone_nbr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_phone_nbr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_fax_area_cd")) == "") | (col("pcc_pbr_fax_area_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_fax_area_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_fax_nbr")) == "") | (col("pcc_pbr_fax_nbr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_fax_nbr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_e_prescribe_ind")) == "") | (col("pcc_pbr_e_prescribe_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_e_prescribe_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_e_prescribe_hub_nbr")) == "") | (col("pcc_pbr_e_prescribe_hub_nbr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_e_prescribe_hub_nbr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_pbr_clinic_site_nbr")) == "") | (col("pcc_pbr_clinic_site_nbr").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_pbr_clinic_site_nbr")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("product_service_id_407d7")) == "") | (col("product_service_id_407d7").isNull()), concat(col("ERROR_MSG"), " Invalid String in product_service_id_407d7")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_dea_drug_class")) == "") | (col("pcc_dea_drug_class").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_dea_drug_class")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("product_service_id_qual_436e1")) == "") | (col("product_service_id_qual_436e1").isNull()), concat(col("ERROR_MSG"), " Invalid String in product_service_id_qual_436e1")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("unit_of_measure_60028")) == "") | (col("unit_of_measure_60028").isNull()), concat(col("ERROR_MSG"), " Invalid String in unit_of_measure_60028")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when(len(translate(trim(col("pcc_district_nbr")), ".", "")) > 5, lit("Size of destination is 5 character and input has 6 character")).otherwise(""))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_store_mailing_state_cd")) == "") | (col("pcc_store_mailing_state_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_store_mailing_state_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("service_provider_id_201b1")) == "") | (col("service_provider_id_201b1").isNull()), concat(col("ERROR_MSG"), " Invalid String in service_provider_id_201b1")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_mail_retail_ind")) == "") | (col("wag_mail_retail_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_mail_retail_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("wag_e_id")) == "") | (col("wag_e_id").isNull()), concat(col("ERROR_MSG"), " Invalid String in wag_e_id")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("processor_ctrl_num_104a4")) == "") | (col("processor_ctrl_num_104a4").isNull()), concat(col("ERROR_MSG"), " Invalid String in processor_ctrl_num_104a4")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("pcc_direct_link_cd")) == "") | (col("pcc_direct_link_cd").isNull()), concat(col("ERROR_MSG"), " Invalid String in pcc_direct_link_cd")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when((trim(col("fill_sold_dlrs_ind")) == "") | (col("fill_sold_dlrs_ind").isNull()), concat(col("ERROR_MSG"), " Invalid String in fill_sold_dlrs_ind")).otherwise(col("ERROR_MSG")))

dfValidation = dfValidation.withColumn("ERROR_MSG", when(len(translate(trim(col("pcc_area_nbr")), ".", "")) > 5, lit("Size of destination is 5 character and input has 6 character")).otherwise(""))


# COMMAND ----------

# Throw Exception if error is found

dfValidationResults = dfValidation.filter(col("ERROR_MSG") != "")

if dfValidationResults.count() > 0:
  raise Exception(dfValidationResults.collect()[0]["ERROR_MSG"])

# COMMAND ----------

# Apply RFMT

dfRFMT = df\
         .withColumn("WAG_STORE_ID", when((col("wag_store_id").isNull()) & (trim(col("wag_store_id")) == ""), col("wag_store_id")).otherwise(lpad(translate(trim(col("wag_store_id")), ".", ""), 5, '0')))\
         .withColumn("PRESCRIPTION_REF_NO_402D2", col("prescription_ref_no_402d2"))\
         .withColumn("WAG_RX_FILL_NBR", col("wag_rx_fill_nbr"))\
         .withColumn("PCC_FILL_PARTIAL_NBR", col("pcc_fill_partial_nbr"))\
         .withColumn("DATE_AUTHORIZED", when((col("date_authorized").isNull()) & (trim(col("date_authorized")) == ""), "        ").otherwise(col("date_authorized")))\
         .withColumn("TIME_AUTHORIZED", when((col("time_authorized").isNull()) & (trim(col("time_authorized")) == ""), "        ").otherwise(col("time_authorized")))\
		 .withColumn("SERVICE_DATE_401D1", when((col("service_date_401d1").isNull()) & (trim(col("service_date_401d1")) == ""), "        ").otherwise(col("service_date_401d1")))\
		 .withColumn("WAG_FILL_SOLD_TM", when((col("wag_fill_sold_tm").isNull()) & (trim(col("wag_fill_sold_tm")) == ""), "        ").otherwise(col("wag_fill_sold_tm")))\
         .withColumn("ANONYMOUS_PATIENT_ID", col("anonymous_patient_id"))\
         .withColumn("PCC_PBR_ID", col("pcc_pbr_id"))\
         .withColumn("PCC_PBR_LOC_ID", col("pcc_pbr_loc_id"))\
         .withColumn("PCC_DRUG_ID", col("pcc_drug_id"))\
         .withColumn("WAG_FILL_STAT_CD", col("fill_num_403d3"))\
         .withColumn("QUANTITY_DISPENSED_442E7", col("quantity_dispensed_442e7"))\
         .withColumn("DAYS_SUPPLY_405D5", col("days_supply_405d5"))\
         .withColumn("PRESCRIPTION_TYPE_60149", col("prescription_type_60149"))\
         .withColumn("PCC_PARTIAL_FILL_CD", col("pcc_partial_fill_cd"))\
         .withColumn("PCC_REFILLS_REMAINING", col("pcc_refills_remaining"))\
         .withColumn("PAYER1_TYPE", col("payer1_type"))\
         .withColumn("WAG_FILL_VRFY_DT", col("wag_fill_vrfy_dt"))\
         .withColumn("WAG_FILL_VRFY_TM", col("wag_fill_vrfy_tm"))\
         .withColumn("WAG_FILL_DATA_REVIEW_DT", col("wag_fill_data_review_dt"))\
         .withColumn("WAG_FILL_DATA_REVIEW_TM", col("wag_fill_data_review_tm"))\
         .withColumn("WAG_FILLING_DT", col("wag_filling_dt"))\
         .withColumn("WAG_FILLING_TM", col("wag_filling_tm"))\
         .withColumn("WAG_FILL_DEL_DT", col("wag_fill_del_dt"))\
         .withColumn("WAG_FILL_DEL_TM", col("wag_fill_del_tm"))\
         .withColumn("PLAN_ID_524FO", col("plan_id_524fo"))\
         .withColumn("WAG_COB_IND", col("wag_cob_ind"))\
         .withColumn("TRANS_RESPONSE_STATUS_112AN", col("trans_response_status_112an"))\
         .withColumn("WAG_FILL_ADJUD_DT", col("wag_fill_adjud_dt"))\
         .withColumn("WAG_FILL_ADJUD_TM", col("wag_fill_adjud_tm"))\
         .withColumn("CARDHOLDER_ID_302C2_ENCRYPTED", col("cardholder_id_302c2_encrypted"))\
         .withColumn("GROUP_ID_301C1", col("group_id_301c1"))\
         .withColumn("INGREDIENT_COST_SUBMIT_409D9", col("ingredient_cost_submit_409d9"))\
         .withColumn("DISPENSING_FEE_SUBMITTED_412DC", col("dispensing_fee_submitted_412dc"))\
         .withColumn("PATIENT_PAID_AMT_SUBMIT_433DX", when((col("patient_paid_amt_submit_433dx").isNull()) & (trim(col("patient_paid_amt_submit_433dx")) == ""), col("patient_paid_amt_submit_433dx")).otherwise(lpad(translate(trim(col("patient_paid_amt_submit_433dx")), ".", ""), 9, '0')))\
         .withColumn("PCC_FILL_AWP_COST_AMT", col("pcc_fill_awp_cost_amt"))\
         .withColumn("FLATSALESTAX_AMT_SUBMIT_481HA", col("flatsalestax_amt_submit_481ha"))\
		 .withColumn("TOTAL_AMT_PAID_509F9", when((col("total_amt_paid_509f9").isNull()) & (trim(col("total_amt_paid_509f9")) == ""), col("total_amt_paid_509f9")).otherwise(lpad(translate(trim(col("total_amt_paid_509f9")), ".", ""), 9, '0')))\
         .withColumn("CLAIM_REFERENCE_ID_435DZ", col("claim_reference_id_435dz"))\
         .withColumn("BIN_NUM_101A1", col("bin_num_101a1"))\              
         .withColumn("REJECT_CD_1_511FB", col("reject_cd_1_511fb"))\
         .withColumn("REJECT_CD_2_511FB", col("reject_cd_2_511fb"))\
         .withColumn("REJECT_CD_3_511FB", col("reject_cd_3_511fb"))\
         .withColumn("REJECT_COUNT_510FA", col("reject_count_510fa"))\              
         .withColumn("DATE_PRESCRIPT_WRITTEN_414DE", when((col("date_prescript_written_414de").isNull()) & (trim(col("date_prescript_written_414de")) == ""), "        ").otherwise(col("date_prescript_written_414de")))\
         .withColumn("NUM_REFILLS_AUTH_415DF", col("num_refills_auth_415df"))\
         .withColumn("ORIG_PRESC_QUANTITY_446EB", col("orig_presc_quantity_446eb"))\
         .withColumn("COMPOUND_CD_406D6", col("compound_cd_406d6"))\
         .withColumn("DAW_PROD_SELECTION_CD_408D8", col("daw_prod_selection_cd_408d8"))\
         .withColumn("PCC_FILL_AUTO_IND", col("pcc_fill_auto_ind"))\
         .withColumn("PCC_DAW_CD", col("pcc_daw_cd"))\
         .withColumn("PCC_RX_SIG", col("pcc_rx_sig"))\
         .withColumn("PCC_PAT_SUB_PREF_CD", col("pcc_pat_sub_pref_cd"))\
         .withColumn("FIRST_NAME", col("first_name"))\
         .withColumn("LAST_NAME", col("last_name"))\
         .withColumn("BRTH_DT", col("brth_dt"))\
         .withColumn("PATIENT_GENDER_305C5", col("patient_gender_305c5"))\
         .withColumn("PCC_PAT_LOCK_STORE_NBR", col("pcc_pat_lock_store_nbr"))\
         .withColumn("PCC_LOCK_IND", col("pcc_lock_ind"))\
         .withColumn("PCC_PAT_GENERIC_SUBS_PREF", col("pcc_pat_generic_subs_pref"))\
         .withColumn("PCC_PAT_MAIL_LIST_PREF", col("pcc_pat_mail_list_pref"))\
         .withColumn("PCC_PAT_LANG_CD", col("pcc_pat_lang_cd"))\
         .withColumn("PCC_PAT_PHONE_CONTACT_PREF_IND", col("pcc_pat_pet_ind"))\
         .withColumn("PCC_PAT_HIPAA_IND", col("pcc_pat_hipaa_ind"))\
         .withColumn("PCC_PAT_INTERNET_IND", col("pcc_pat_internet_ind"))\
         .withColumn("PCC_PAT_ALGY_HLTH_TYPE_CD", col("pcc_pat_algy_hlth_type_cd"))\
         .withColumn("PCC_PAT_ALGY_CD_INQ_IND", col("pcc_pat_algy_cd_inq_ind"))\
         .withColumn("PAT_ADDR_LINE", col("pat_addr_line"))\
         .withColumn("PAT_CITY", col("pat_city"))\
         .withColumn("PATIENT_STATE_PROVINCE_324_CO", col("patient_state_province_324_co"))\
         .withColumn("PATIENT_ZIP_325CP", col("patient_zip_325cp"))\
         .withColumn("PAT_COMM_CHANNEL_VAL", col("pat_comm_channel_val"))\
         .withColumn("PATIENT_REL_TO_INS_306C6", col("patient_rel_to_ins_306c6"))\
         .withColumn("PCC_PERSON_CD", col("pcc_person_cd"))\              
         .withColumn("PRESCRIBER_ID_411DB", col("prescriber_id_411db"))\
         .withColumn("PRESCRIBER_ID_QUALIFER_466EZ", col("prescriber_id_qualifer_466ez"))\
         .withColumn("PCC_PBR_FIRST_NAME", col("pcc_pbr_first_name"))\
         .withColumn("PCC_PBR_MID_INIT", col("pcc_pbr_mid_init"))\
         .withColumn("PRESCRIBER_LAST_NAME_427DR", col("prescriber_last_name_427dr"))\
         .withColumn("PCC_PBR_ADDR", col("pcc_pbr_addr"))\
         .withColumn("PCC_PBR_CITY", col("pcc_pbr_city"))\
         .withColumn("PCC_PBR_STATE_CD", col("pcc_pbr_state_cd"))\
         .withColumn("PCC_PBR_ZIP", col("pcc_pbr_zip"))\
         .withColumn("PCC_PBR_PHONE_AREA_CD", col("pcc_pbr_phone_area_cd"))\
         .withColumn("PCC_PBR_PHONE_NBR", col("pcc_pbr_phone_nbr"))\
         .withColumn("PCC_PBR_FAX_AREA_CD", col("pcc_pbr_fax_area_cd"))\
         .withColumn("PCC_PBR_FAX_NBR", col("pcc_pbr_fax_nbr"))\
         .withColumn("PCC_PBR_E_PRESCRIBE_IND", col("pcc_pbr_e_prescribe_ind"))\
         .withColumn("PCC_PBR_E_PRESCRIBE_HUB_NBR", col("pcc_pbr_e_prescribe_hub_nbr"))\
         .withColumn("PCC_PBR_CLINIC_SITE_NBR", col("pcc_pbr_clinic_site_nbr"))\
         .withColumn("PRODUCT_SERVICE_ID_407D7", col("product_service_id_407d7"))\
         .withColumn("PCC_DEA_DRUG_CLASS", col("pcc_dea_drug_class"))\
         .withColumn("PRODUCT_SERVICE_ID_QUAL_436E1", col("product_service_id_qual_436e1"))\
         .withColumn("UNIT_OF_MEASURE_60028", col("unit_of_measure_60028"))\              
         .withColumn("PCC_DISTRICT_NBR", when((col("pcc_district_nbr").isNull()) & (trim(col("pcc_district_nbr")) == ""), col("pcc_district_nbr")).otherwise(lpad(translate(trim(col("pcc_district_nbr")), ".", ""), 5, '0')))\                
         .withColumn("PCC_STORE_MAILING_STATE_CD", col("pcc_store_mailing_state_cd"))\
         .withColumn("SERVICE_PROVIDER_ID_201B1", col("service_provider_id_201b1"))\
         .withColumn("WAG_MAIL_RETAIL_IND", col("wag_mail_retail_ind"))\
         .withColumn("WAG_E_ID", col("wag_e_id"))\
         .withColumn("PROCESSOR_CTRL_NUM_104A4", col("processor_ctrl_num_104a4"))\
         .withColumn("PCC_DIRECT_LINK_CD", col("pcc_direct_link_cd"))\
         .withColumn("FILL_SOLD_DLRS_IND", col("fill_sold_dlrs_ind"))\
         .withColumn("PCC_AREA_NBR", when((col("pcc_area_nbr").isNull()) & (trim(col("pcc_area_nbr")) == ""), col("pcc_area_nbr")).otherwise(lpad(translate(trim(col("pcc_area_nbr")), ".", ""), 5, '0')))          

# COMMAND ----------

# Build Output

dfOutput = dfRFMT.select("WAG_STORE_ID","PRESCRIPTION_REF_NO_402D2","WAG_RX_FILL_NBR","PCC_FILL_PARTIAL_NBR","DATE_AUTHORIZED","TIME_AUTHORIZED","SERVICE_DATE_401D1","WAG_FILL_SOLD_TM","ANONYMOUS_PATIENT_ID","PCC_PBR_ID","PCC_PBR_LOC_ID","PCC_DRUG_ID","WAG_FILL_STAT_CD","FILL_NUM_403D3","QUANTITY_DISPENSED_442E7","DAYS_SUPPLY_405D5","PRESCRIPTION_TYPE_60149","PCC_PARTIAL_FILL_CD","PCC_REFILLS_REMAINING","PAYER1_TYPE","WAG_FILL_VRFY_DT","WAG_FILL_VRFY_TM","WAG_FILL_DATA_REVIEW_DT","WAG_FILL_DATA_REVIEW_TM","WAG_FILLING_DT","WAG_FILLING_TM","WAG_FILL_DEL_DT","WAG_FILL_DEL_TM","PLAN_ID_524FO","WAG_COB_IND","TRANS_RESPONSE_STATUS_112AN","WAG_FILL_ADJUD_DT","WAG_FILL_ADJUD_TM","CARDHOLDER_ID_302C2_ENCRYPTED","GROUP_ID_301C1","INGREDIENT_COST_SUBMIT_409D9","DISPENSING_FEE_SUBMITTED_412DC","PATIENT_PAID_AMT_SUBMIT_433DX","PCC_FILL_AWP_COST_AMT","FLATSALESTAX_AMT_SUBMIT_481HA","TOTAL_AMT_PAID_509F9","CLAIM_REFERENCE_ID_435DZ","BIN_NUM_101A1","REJECT_CD_1_511FB","REJECT_CD_2_511FB","REJECT_CD_3_511FB","REJECT_COUNT_510FA","DATE_PRESCRIPT_WRITTEN_414DE","NUM_REFILLS_AUTH_415DF","ORIG_PRESC_QUANTITY_446EB","COMPOUND_CD_406D6","DAW_PROD_SELECTION_CD_408D8","PCC_FILL_AUTO_IND","PCC_DAW_CD","PCC_RX_SIG","PCC_PAT_SUB_PREF_CD","FIRST_NAME","LAST_NAME","BRTH_DT","PATIENT_GENDER_305C5","PCC_PAT_LOCK_STORE_NBR","PCC_LOCK_IND","PCC_PAT_GENERIC_SUBS_PREF","PCC_PAT_MAIL_LIST_PREF","PCC_PAT_LANG_CD","PCC_PAT_PHONE_CONTACT_PREF_IND","PCC_PAT_PET_IND","PCC_PAT_HIPAA_IND","PCC_PAT_INTERNET_IND","PCC_PAT_ALGY_HLTH_TYPE_CD","PCC_PAT_ALGY_CD_INQ_IND","PAT_ADDR_LINE","PAT_CITY","PATIENT_STATE_PROVINCE_324_CO","PATIENT_ZIP_325CP","PAT_COMM_CHANNEL_VAL","PATIENT_REL_TO_INS_306C6","PCC_PERSON_CD","PRESCRIBER_ID_411DB","PRESCRIBER_ID_QUALIFER_466EZ","PCC_PBR_FIRST_NAME","PCC_PBR_MID_INIT","PRESCRIBER_LAST_NAME_427DR","PCC_PBR_ADDR","PCC_PBR_CITY","PCC_PBR_STATE_CD","PCC_PBR_ZIP","PCC_PBR_PHONE_AREA_CD","PCC_PBR_PHONE_NBR","PCC_PBR_FAX_AREA_CD","PCC_PBR_FAX_NBR","PCC_PBR_E_PRESCRIBE_IND","PCC_PBR_E_PRESCRIBE_HUB_NBR","PCC_PBR_CLINIC_SITE_NBR","PRODUCT_SERVICE_ID_407D7","PCC_DEA_DRUG_CLASS","PRODUCT_SERVICE_ID_QUAL_436E1","UNIT_OF_MEASURE_60028","PCC_DISTRICT_NBR","PCC_AREA_NBR","PCC_STORE_MAILING_STATE_CD","SERVICE_PROVIDER_ID_201B1","WAG_MAIL_RETAIL_IND","WAG_E_ID","PROCESSOR_CTRL_NUM_104A4","PCC_DIRECT_LINK_CD","FILL_SOLD_DLRS_IND")

# COMMAND ----------

# Write outputs

# Main output
dfOutput.createOrReplaceGlobalTempView("DAP_OUT_GW_SDI_EXTR_DAILY_EXTRACT")
file_path_output = "{0}/{1}/WAG_125_{2}_0T".format(mountPoint, dbutils.widgets.get("AI_DIR_FTP_OUTBOUND"), dbutils.widgets.get("pSQL_PARM_2"))
dbutils.notebook.run("../Utilities/WRITE_TO_STORAGE", 60, {"file_path": file_path_output, "file_extention": "dat", "view_name": "DAP_OUT_GW_SDI_EXTR_DAILY_EXTRACT", "delimiter": "\x01", "has_header": "false"})
# Databricks notebook source
'''
dbutils.widgets.text("PAR_DF_PRESCRIPTION_FILL_TBL","PATIENT_SERVICES.PRESCRIPTION_FILL")
dbutils.widgets.text("PAR_DF_PHC_DB","DEV_PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_DF_PE_DB","DEV_PARTNER_EXTRACTS")
dbutils.widgets.text("PAR_DF_PHARMACY_SCHEMA","PHARMACY_HEALTHCARE")
dbutils.widgets.text("PAR_DF_STG_TABLE_1","SATR_SIMILAR_GPI_RX_TMPL_STG")
dbutils.widgets.text("PAR_DF_STG_TABLE_2","TEMP_SATR_EXTRACTL_STG")
dbutils.widgets.text("PAR_DF_CALDR_TABLE","SATR_CALENDAR_REPORT")
dbutils.widgets.text("PAR_DF_STG_DB","DEV_STAGING")
dbutils.widgets.text("PAR_DF_EXEC_WK_START_DT","2022-05-15")
dbutils.widgets.text("PAR_DF_EXEC_WK_END_DT","2022-05-21")
dbutils.widgets.text("PAR_DF_PRESCRIPTION_FILL_PLAN_TBL","PATIENT_SERVICES.PRESCRIPTION_FILL_PLAN")
dbutils.widgets.text("PAR_DF_PATIENT_TBL","PATIENT.PATIENT")
dbutils.widgets.text("PAR_DF_OUTPUT_STG_FILE_PATH","partner_extracts/pharmacy_healthcare/staging")
dbutils.widgets.text("PAR_DF_OUTPUT_STG_FILE_2","temp123")
dbutils.widgets.text("PAR_DF_OUTPUT_STG_FILE_3","dap_out_phrm_satr_on_time_report_intermediate")
dbutils.widgets.text("PAR_DF_PROJ_NAME","edw_out_pharmacy_extracts")
dbutils.widgets.text("PAR_DF_SRC_STREAM_NAME","satr_extract")
dbutils.widgets.text("PAR_DF_PSET_NAME","plan_edw_out_phrm_ext_satr_extract_weekly.pset")
dbutils.widgets.text("PAR_DF_BATCH_ID","20220606000000")
dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
dbutils.widgets.text("PAR_DB_TGT_TBL","SATR_METRICS_RAWDATA")
'''
PAR_PRESCRIPTION_FILL_TBL=dbutils.widgets.get("PAR_DF_PRESCRIPTION_FILL_TBL")
PAR_PHC_DB=dbutils.widgets.get("PAR_DF_PHC_DB")
PAR_PE_DB=dbutils.widgets.get("PAR_DF_PE_DB")
PAR_PHARMACY_SCHEMA=dbutils.widgets.get("PAR_DF_PHARMACY_SCHEMA")
PAR_STG_TABLE_1=dbutils.widgets.get("PAR_DF_STG_TABLE_1")
PAR_STG_TABLE_2=dbutils.widgets.get("PAR_DF_STG_TABLE_2")
PAR_CALDR_TABLE=dbutils.widgets.get("PAR_DF_CALDR_TABLE")
PAR_STG_DB=dbutils.widgets.get("PAR_DF_STG_DB")
PAR_EXEC_WK_START_DT=dbutils.widgets.get("PAR_DF_EXEC_WK_START_DT")
PAR_EXEC_WK_END_DT=dbutils.widgets.get("PAR_DF_EXEC_WK_END_DT")
PAR_PRESCRIPTION_FILL_PLAN_TBL=dbutils.widgets.get("PAR_DF_PRESCRIPTION_FILL_PLAN_TBL")
PAR_PATIENT_TBL=dbutils.widgets.get("PAR_DF_PATIENT_TBL")
PAR_OUTPUT_STG_FILE_PATH=dbutils.widgets.get("PAR_DF_OUTPUT_STG_FILE_PATH")
PAR_OUTPUT_STG_FILE_2=dbutils.widgets.get("PAR_DF_OUTPUT_STG_FILE_2")
PAR_OUTPUT_STG_FILE_3=dbutils.widgets.get("PAR_DF_OUTPUT_STG_FILE_3")
PAR_PROJ_NAME=dbutils.widgets.get("PAR_DF_PROJ_NAME")
PAR_SRC_STREAM_NAME=dbutils.widgets.get("PAR_DF_SRC_STREAM_NAME")
PAR_PSET_NAME=dbutils.widgets.get("PAR_DF_PSET_NAME")
PAR_BATCH_ID=dbutils.widgets.get("PAR_DF_BATCH_ID")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
PAR_TGT_TBL = dbutils.widgets.get("PAR_DB_TGT_TBL")



# COMMAND ----------

# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# MAGIC 
# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=PAR_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

query1="""select 
 tsat.generic_prod_id
,tsat.generic_prod_id_name
,pfill.drug_id
,pfill.drug_name
,pfill.fill_qty_dspn
,pfill.update_dttm
,tsat.rx_nbr as same_gpi_rx
,tsat.str_nbr as same_gpi_str
,pfill.rx_fill_nbr
,pfill.dspn_fill_nbr
,pfill.fill_sold_dt
,pfill.fill_est_pick_up_dttm
,pfill.fill_enter_dt
,pfill.fill_enter_user_id
,pfill.fill_vrfy_dt
,pfill.fill_stat_cd
,pfill.fill_vrfy_user_id
,pfill.fill_print_dt
,pfill.fill_days_supply
,pfill.fill_type_cd
,pfp.third_party_plan_id
,pfp.plan_group_nbr
,pfp.bin_nbr
,pfp.prcs_ctrl_nbr
,pat.first_name
,pat.last_name
,pat.gndr_cd
,pat.brth_dt
,tsat.pat_id
,tsat.work_order
,tsat.expected_fill_entered_dttm
,tsat.max_fill_entered_dttm
,tsat.old_rx_nbr
,tsat.old_str_nbr
,tsat.orig_fill_dspn_qnty
from {0}.{1} pfill 
inner join {2}.{7}.{3} tsat
on tsat.rx_nbr=pfill.rx_nbr and tsat.str_nbr=pfill.str_nbr
and pfill.fill_sold_dt>= CAST('{4}' as date)
and pfill.fill_enter_dt>=CAST('{4}' as date)
inner join {0}.{5} pfp
        on      pfill.rx_nbr = pfp.rx_nbr
        and     pfill.str_nbr = pfp.str_nbr
        and     pfill.rx_fill_nbr = pfp.rx_fill_nbr
        and pfp.cob_ind = 'N'
inner join {0}.{6} pat
        on tsat.pat_id = pat.pat_id
 UNION 
select 
 tsat.generic_prod_id
,tsat.generic_prod_id_name
,pfill.drug_id
,pfill.drug_name
,pfill.fill_qty_dspn
,pfill.update_dttm
,tsat.rx_nbr as same_gpi_rx
,tsat.str_nbr as same_gpi_str
,pfill.rx_fill_nbr
,pfill.dspn_fill_nbr
,pfill.fill_sold_dt
,pfill.fill_est_pick_up_dttm
,pfill.fill_enter_dt
,pfill.fill_enter_user_id
,pfill.fill_vrfy_dt
,pfill.fill_stat_cd
,pfill.fill_vrfy_user_id
,pfill.fill_print_dt
,pfill.fill_days_supply
,pfill.fill_type_cd
,pfp.third_party_plan_id
,pfp.plan_group_nbr
,pfp.bin_nbr
,pfp.prcs_ctrl_nbr
,pat.first_name
,pat.last_name
,pat.gndr_cd
,pat.brth_dt
,tsat.pat_id
,tsat.work_order
,tsat.expected_fill_entered_dttm
,tsat.max_fill_entered_dttm
,tsat.old_rx_nbr
,tsat.old_str_nbr
,tsat.orig_fill_dspn_qnty
from {0}.{1} pfill 
inner join {2}.{7}.{3} tsat
on tsat.rx_nbr=pfill.rx_nbr and tsat.str_nbr=pfill.str_nbr
and pfill.fill_sold_dt is NULL
and pfill.fill_enter_dt>=CAST('{4}' as date)
inner join {0}.{5} pfp
        on      pfill.rx_nbr = pfp.rx_nbr
        and     pfill.str_nbr = pfp.str_nbr
        and     pfill.rx_fill_nbr = pfp.rx_fill_nbr
        and pfp.cob_ind = 'N'
inner join {0}.{6} pat
        on tsat.pat_id = pat.pat_id""".format(PAR_PHC_DB,PAR_PRESCRIPTION_FILL_TBL,PAR_STG_DB,PAR_STG_TABLE_1,PAR_EXEC_WK_START_DT,PAR_PRESCRIPTION_FILL_PLAN_TBL,PAR_PATIENT_TBL,PAR_PHARMACY_SCHEMA)


# COMMAND ----------

print(query1)

# COMMAND ----------

df_q1_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query1)\
   .load()
#df_q1_out.show()

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.sql.functions import *

df_q1_out=df_q1_out.select([F.col(x).alias(x.lower()) for x in df_q1_out.columns])
#df_q1_out.show()

# COMMAND ----------

df_filter1=df_q1_out.filter( ( (col("fill_enter_dt").isNotNull()) & (col("fill_sold_dt").isNotNull()) & (F.datediff(col("fill_sold_dt"),to_date(col("expected_fill_entered_dttm"))) >= 0) & (F.datediff(col("fill_sold_dt"),to_date(col("expected_fill_entered_dttm"))) <= 16)   )  | ( (col("fill_enter_dt").isNotNull()) & (F.datediff(col("fill_enter_dt"),to_date(col("expected_fill_entered_dttm"))) >= 0) & (F.datediff(col("fill_enter_dt"),to_date(col("expected_fill_entered_dttm"))) <5) )  )
#print(df_filter1.count())
#df_sort1=df_filter1.sort("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr","rx_fill_nbr")

# COMMAND ----------

'''
df_fi_vdt=df_sort1.groupBy("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr").agg(last("fill_vrfy_dt",ignorenulls=True).alias("derv_fi_vdt"))
#display(df_fi_vdt)
df_r1=df_sort1.alias("in0").join(df_fi_vdt.alias("in1"), (  (df_sort1.old_str_nbr==df_fi_vdt.old_str_nbr)  &       (df_sort1.old_rx_nbr==df_fi_vdt.old_rx_nbr)  &  (df_sort1.expected_fill_entered_dttm==df_fi_vdt.expected_fill_entered_dttm)  &  (df_sort1.same_gpi_str==df_fi_vdt.same_gpi_str) &  (df_sort1.same_gpi_rx==df_fi_vdt.same_gpi_rx) &  (df_sort1.dspn_fill_nbr==df_fi_vdt.dspn_fill_nbr)) , "inner").select(col("in0.*"),col("in1.derv_fi_vdt")).drop(col("fill_vrfy_dt")).withColumn("fill_vrfy_dt",col("derv_fi_vdt")).drop(col("derv_fi_vdt"))
#display(df_r1)
'''
from pyspark.sql.window import Window
windowSpec  = Window.partitionBy("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr").orderBy("rx_fill_nbr")

df_r1=df_filter1.withColumn("fill_vrfy_dt",last("fill_vrfy_dt",ignorenulls=True).over(windowSpec))


# COMMAND ----------

df_r1=df_r1.sort("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr","rx_fill_nbr")
df_r1.cache()
df_g1_51=df_r1.filter(df_r1.fill_enter_user_id==51).groupBy("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr").agg(last("fill_enter_user_id",ignorenulls=True).alias("derv_fill_enter_user_id"),last("fill_enter_dt",ignorenulls=True).alias("derv_fill_enter_dt"))
#display(df_g1_51)
df_tg=df_r1.select("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr").distinct()
#print(df_tg.count())
df_g1=df_g1_51.select("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr").distinct()
#print(df_g1.count())
df_g2=df_tg.exceptAll(df_g1)
#print(df_g2.count())

# COMMAND ----------

df_g2_join=df_r1.alias("in0").join(df_g2.alias("in1"),  (  (df_r1.old_str_nbr==df_g2.old_str_nbr)  &       (df_r1.old_rx_nbr==df_g2.old_rx_nbr)  &  (df_r1.expected_fill_entered_dttm==df_g2.expected_fill_entered_dttm)  &  (df_r1.same_gpi_str==df_g2.same_gpi_str) &  (df_r1.same_gpi_rx==df_g2.same_gpi_rx) &  (df_r1.dspn_fill_nbr==df_g2.dspn_fill_nbr) ) , "inner").select(col("in0.*"))
#df_g2_join=df_g2_join.sort("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr","rx_fill_nbr")

# COMMAND ----------

'''df_g2_join1=df_g2_join.groupBy("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr").agg(first("fill_enter_user_id",ignorenulls=True).alias("derv_fill_enter_user_id"),first("fill_enter_dt",ignorenulls=True).alias("derv_fill_enter_dt"))
#display(df_g2_join1)
'''

# COMMAND ----------

df_u1=df_r1.alias("in0").join(df_g1_51.alias("in1"), (  (df_r1.old_str_nbr==df_g1_51.old_str_nbr)  &       (df_r1.old_rx_nbr==df_g1_51.old_rx_nbr)  &  (df_r1.expected_fill_entered_dttm==df_g1_51.expected_fill_entered_dttm)  &  (df_r1.same_gpi_str==df_g1_51.same_gpi_str)  &       (df_r1.same_gpi_rx==df_g1_51.same_gpi_rx)  &       (df_r1.dspn_fill_nbr==df_g1_51.dspn_fill_nbr)) , "inner").select(col("in0.*"),col("in1.derv_fill_enter_user_id"),col("in1.derv_fill_enter_dt")).drop(col("fill_enter_user_id")).drop(col("fill_enter_dt")).withColumn("fill_enter_user_id",col("derv_fill_enter_user_id")) \
.withColumn("fill_enter_dt",col("derv_fill_enter_dt")).drop(col("derv_fill_enter_user_id")).drop(col("derv_fill_enter_dt"))
#display(df_u1)
df_u2=df_g2_join.withColumn("fill_enter_user_id",first("fill_enter_user_id").over(windowSpec)).withColumn("fill_enter_dt",first("fill_enter_dt").over(windowSpec))
'''
df_u2=df_r1.alias("in0").join(df_g2_join1.alias("in1"), (  (df_r1.old_str_nbr==df_g2_join1.old_str_nbr)  &       (df_r1.old_rx_nbr==df_g2_join1.old_rx_nbr)  &  (df_r1.expected_fill_entered_dttm==df_g2_join1.expected_fill_entered_dttm)  &  (df_r1.same_gpi_str==df_g2_join1.same_gpi_str) &  (df_r1.same_gpi_rx==df_g2_join1.same_gpi_rx) &  (df_r1.dspn_fill_nbr==df_g2_join1.dspn_fill_nbr)) , "inner").select(col("in0.*"),col("in1.derv_fill_enter_user_id"),col("in1.derv_fill_enter_dt")).drop(col("fill_enter_user_id")).drop(col("fill_enter_dt")).withColumn("fill_enter_user_id",col("derv_fill_enter_user_id")) \
.withColumn("fill_enter_dt",col("derv_fill_enter_dt")).drop(col("derv_fill_enter_user_id")).drop(col("derv_fill_enter_dt"))
'''
#display(df_u2)
df_sel=df_u1.unionByName(df_u2)
#display(df_sel)

# COMMAND ----------

#print(df_sel.count())

# COMMAND ----------

#dedup

df_sort2=df_sel.sort("old_str_nbr","old_rx_nbr","expected_fill_entered_dttm","same_gpi_str","same_gpi_rx","dspn_fill_nbr")
df_dedup1 = df_sort2.dropDuplicates(['old_str_nbr', 'old_rx_nbr', 'expected_fill_entered_dttm', 'same_gpi_str', 'same_gpi_rx'])

# COMMAND ----------

df_reft1=df_dedup1.withColumn("priority_flag",when(df_dedup1.fill_stat_cd=='SD', 1).when(df_dedup1.fill_stat_cd=='RD', 2).when(df_dedup1.fill_stat_cd=='VR', 3).when(df_dedup1.fill_stat_cd=='EN', 4).otherwise(5)) \
                  .withColumn("rx_nbr",col("old_rx_nbr")) \
                  .withColumn("str_nbr",col("old_str_nbr")) \
                  .withColumn("str_nbr",col("old_str_nbr"))

# COMMAND ----------

#dedup

df_sort3=df_reft1.sort("str_nbr","rx_nbr","expected_fill_entered_dttm","priority_flag")
df_dedup2 = df_sort3.dropDuplicates(['str_nbr', 'rx_nbr', 'expected_fill_entered_dttm'])
#df_dedup2.show()

# COMMAND ----------

#read temp123 file
path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,PAR_OUTPUT_STG_FILE_2,PAR_BATCH_ID)
df_temp_file=spark.read.parquet(path)
#df_temp_file.show()

# COMMAND ----------

df_sort4=df_temp_file.sort("store_nbr","rx_nbr","expected_fill_enter_dt")

# COMMAND ----------

df_join1=df_sort4.alias("in0").join(df_dedup2.alias("in1"),( (df_sort4.store_nbr ==  df_dedup2.str_nbr) &  (df_sort4.rx_nbr ==  df_dedup2.rx_nbr) & (df_sort4.expected_fill_enter_dt ==  to_date(df_dedup2.expected_fill_entered_dttm)) ),"right").select(col("in1.generic_prod_id"),coalesce(col("in1.rx_nbr"),col("in0.rx_nbr")).alias("rx_nbr"),coalesce(col("in1.str_nbr"),col("in0.store_nbr")).alias("store_nbr"),col("in1.same_gpi_rx").alias("xfer_to_rx_nbr"),col("in1.same_gpi_str").alias("xfer_to_str_nbr"),  coalesce(col("in1.rx_fill_nbr"),col("in0.rx_fill_nbr")).alias("rx_fill_nbr"),  coalesce(col("in1.dspn_fill_nbr"),col("in0.dspn_fill_nbr")).alias("dspn_fill_nbr"), coalesce(col("in1.fill_sold_dt"),col("in0.fill_sold_dt")).alias("fill_sold_dt"),  coalesce(col("in1.fill_est_pick_up_dttm"),col("in0.fill_est_pick_up_dttm")).alias("fill_est_pick_up_dttm"),  coalesce(col("in1.fill_enter_dt"),col("in0.fill_enter_dt")).alias("fill_enter_dt"),    coalesce(col("in1.fill_enter_user_id"),col("in0.fill_enter_user_id")).alias("fill_enter_user_id"),     coalesce(col("in1.fill_vrfy_dt"),col("in0.fill_vrfy_dt")).alias("fill_vrfy_dt"),  coalesce(col("in1.fill_qty_dspn"),col("in0.fill_qty_dspn")).alias("fill_qty_dspn"),     coalesce(col("in1.update_dttm"),col("in0.update_dttm")).alias("update_dttm"), coalesce(col("in1.fill_stat_cd"),col("in0.fill_stat_cd")).alias("fill_stat_cd"), coalesce(col("in1.fill_vrfy_user_id"),col("in0.fill_vrfy_user_id")).alias("fill_vrfy_user_id"), coalesce(col("in1.fill_print_dt"),col("in0.fill_print_dt")).alias("fill_print_dt"), coalesce(col("in1.fill_days_supply"),col("in0.fill_days_supply")).alias("fill_days_supply"), coalesce(col("in1.first_name"),col("in0.first_name")).alias("first_name"), coalesce(col("in1.last_name"),col("in0.last_name")).alias("last_name"), coalesce(col("in1.gndr_cd"),col("in0.gndr_cd")).alias("gndr_cd"), coalesce(col("in1.brth_dt"),col("in0.brth_dt")).alias("brth_dt"), coalesce(col("in1.pat_id"),col("in0.pat_id")).alias("pat_id"), coalesce(col("in1.third_party_plan_id"),col("in0.third_party_plan_id")).alias("third_party_plan_id"), coalesce(col("in1.plan_group_nbr"),col("in0.plan_group_nbr")).alias("plan_group_nbr"),coalesce(col("in1.bin_nbr"),col("in0.bin_nbr")).alias("bin_nbr"),coalesce(col("in1.prcs_ctrl_nbr"),col("in0.prcs_ctrl_nbr")).alias("prcs_ctrl_nbr"),coalesce(col("in1.fill_type_cd"),col("in0.fill_type_cd")).alias("fill_type_cd"),coalesce(col("in1.work_order"),col("in0.work_order")).alias("work_order"),col("in0.copy_created"),lit("Y").alias("similar_gpi"),coalesce(col("in1.expected_fill_entered_dttm"),to_date(col("in0.expected_fill_enter_dt"))).alias("expected_fill_enter_dt"),col("in0.max_fill_enter_dt"),coalesce(col("in1.drug_id"),col("in0.drug_id")).alias("drug_id"),coalesce(col("in1.drug_name"),col("in0.drug_name")).alias("drug_name"),coalesce(col("in1.orig_fill_dspn_qnty"),col("in0.orig_fill_dspn_qnty")).alias("orig_fill_dspn_qnty") )
#display(df_join1)

# COMMAND ----------

df_join2_anti=df_sort4.join(df_dedup2,( (df_sort4.store_nbr ==  df_dedup2.str_nbr) &  (df_sort4.rx_nbr ==  df_dedup2.rx_nbr) & (df_sort4.expected_fill_enter_dt ==  to_date(df_dedup2.expected_fill_entered_dttm)) ),"leftanti")
#display(df_join2_anti)

# COMMAND ----------

df_union1=df_join1.unionByName(df_join2_anti,allowMissingColumns = True)
#display(df_union1)

# COMMAND ----------

df_sort5=df_union1.sort("store_nbr","rx_nbr","expected_fill_enter_dt")

# COMMAND ----------

query2="select * from {0}.{1}.{2}".format(PAR_STG_DB,PAR_PHARMACY_SCHEMA,PAR_STG_TABLE_2)
df_q2_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_STG_DB) \
   .option("query",query2)\
   .load()
#df_q2_out.show()
df_q2_out=df_q2_out.select([F.col(x).alias(x.lower()) for x in df_q2_out.columns])
#df_q2_out.show()

# COMMAND ----------

df_sort6=df_q2_out.sort("store_nbr","rx_nbr","expected_fill_enter_dt")

# COMMAND ----------

#print(df_sort5.columns)

# COMMAND ----------

df_join3=df_sort5.alias("in0").join(df_sort6.alias("in1"),( (df_sort5.store_nbr ==  df_sort6.store_nbr) &  (df_sort5.rx_nbr ==  df_sort6.rx_nbr) & (to_date(df_sort5.expected_fill_enter_dt) ==  df_sort6.expected_fill_enter_dt) ),"inner").drop(col("in0.xfer_to_str_nbr")).drop(col("in0.fill_type")).drop(col("in0.orig_fill_dspn_qnty")).select(col("in0.*"),lit("Y").alias("fill_created"),col("in1.pickup_store_nbr").alias("xfer_to_str_nbr"),col("in1.fill_type").alias("fill_type"),col("in1.orig_fill_dspn_qnty").alias("orig_fill_dspn_qnty"))
#display(df_join3)


# COMMAND ----------

df_join4_anti=df_sort6.alias("in1").join(df_sort5.alias("in0"),( (df_sort5.store_nbr ==  df_sort6.store_nbr) &  (df_sort5.rx_nbr ==  df_sort6.rx_nbr) & (to_date(df_sort5.expected_fill_enter_dt) ==  df_sort6.expected_fill_enter_dt) ),"leftanti").withColumn("fill_created",lit("N")).withColumn("xfer_to_str_nbr",col("pickup_store_nbr"))
#display(df_join4_anti)

# COMMAND ----------

df_union2=df_join3.unionByName(df_join4_anti,allowMissingColumns = True)
#display(df_union2)

# COMMAND ----------

df_sort7=df_union2.sort(col("rx_nbr").desc(),col("store_nbr").desc())
df_dedup3= df_sort7.dropDuplicates(['rx_nbr', 'store_nbr'])
df_lst_fill_sold_lkp=df_dedup3

# COMMAND ----------

query3="select * from {0}.{1}.{2}".format(PAR_PE_DB,PAR_PHARMACY_SCHEMA,PAR_CALDR_TABLE)
df_q3_out = spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", PAR_PE_DB) \
   .option("query",query3)\
   .load()
#df_q3_out.show()
df_q3_out=df_q3_out.select([F.col(x).alias(x.lower()) for x in df_q3_out.columns])
#df_q3_out.show()
df_satr_caldr_lkp=df_q3_out

# COMMAND ----------

df_cald_join=df_union2.alias("in0").join(df_satr_caldr_lkp.alias("in1"),(to_date(df_union2.expected_fill_enter_dt)==df_satr_caldr_lkp.reporting_dt),"left").select(col("in0.*"),col("in1.reporting_wk").alias("rpt_wk"),col("in1.reporting_yr").alias("rpt_yr"),concat(col("in1.reporting_yr"),col("in1.reporting_wk")).alias("rpt_period"))
#display(df_cald_join)

# COMMAND ----------

df_lst_fil_sd_join=df_cald_join.alias("in0").join(df_lst_fill_sold_lkp.alias("in1"),((df_cald_join.rx_nbr==df_lst_fill_sold_lkp.rx_nbr) & (df_cald_join.store_nbr==df_lst_fill_sold_lkp.store_nbr)),"left").select(col("in0.*"),col("in1.fill_qty_dspn").alias("last_fill_dspn_qty"),col("in1.fill_sold_dt").alias("last_fill_sold_dt"))
#display(df_lst_fil_sd_join)

# COMMAND ----------

df_final=df_lst_fil_sd_join.withColumn("actual_promise_dt", when( ((F.datediff(to_date(col("fill_est_pick_up_dttm"),'yyyy-MM-dd'),to_date(col("fill_enter_dt"),'yyyy-MM-dd')) < 0 ) & (col("similar_gpi") !=lit('Y'))) , to_date(col("fill_enter_dt"),'yyyy-MM-dd')).otherwise(to_date(col("fill_est_pick_up_dttm"),'yyyy-MM-dd')) ) \
.withColumn("fill_vrfy_dt", when ( ((F.datediff(to_date(col("fill_vrfy_dt"),'yyyy-MM-dd'),to_date(col("fill_enter_dt"),'yyyy-MM-dd')) < 0 ) & (col("similar_gpi").isNull()) | (col("similar_gpi")=='') ) , to_date(col("fill_enter_dt"),'yyyy-MM-dd')    )  .otherwise(to_date(col("fill_vrfy_dt"),'yyyy-MM-dd')) ) \
.withColumn("expect_promise_dt",F.date_add(col("expected_fill_enter_dt"),4)) \
.withColumn("on_tm_ind",when( (F.datediff( (coalesce(col("fill_vrfy_dt"),current_date())), to_date(col("expected_fill_enter_dt"),'yyyy-MM-dd') ) < 5),lit('Y')).otherwise(lit('N'))  ) \
.withColumn("sla_missed_days", (F.datediff( coalesce(col("fill_vrfy_dt"),current_date()) , to_date(col("expected_fill_enter_dt"),'yyyy-MM-dd') ) ) - 4 ) \
.withColumn("copy_create_ind", when( ((col("copy_created").isNull()) | (col("copy_created")=='')),lit('N') ).otherwise(col("copy_created")) ) \
.withColumn("sim_generic_prod_id_ind", when( ((col("similar_gpi").isNull()) | (col("similar_gpi")=='')),lit('N') ).otherwise(col("similar_gpi")) ) \
.withColumn("xfer_fm_rx_nbr", col("rx_nbr")) \
.withColumn("rx_nbr", coalesce(col("xfer_to_rx_nbr"),col("rx_nbr"))) \
.withColumn("str_nbr", col("xfer_to_str_nbr")) \
.withColumn("dspn_qty_msmh_cd",  when ( ( col("fill_qty_dspn").isNull() ),lit("N/A")).when( (col("fill_qty_dspn") == col("orig_fill_dspn_qnty") ),lit("N") ).otherwise(lit('Y'))) \
.withColumn("xfer_fm_str_nbr", col("store_nbr")) \
.withColumn("expect_fill_enter_dt", col("expected_fill_enter_dt")) \
.withColumn("edw_batch_id", lit(PAR_BATCH_ID)) \
.withColumn("fill_update_dttm", col("update_dttm")) \
.withColumn("work_ord", col("work_order")) \
.withColumn("fill_create_ind", col("fill_created")) \
.withColumn("orig_fill_dspn_qty", col("orig_fill_dspn_qnty")) \
.withColumn("fill_dspn_qty", col("fill_qty_dspn")) \
.withColumn("fill_supply_days", col("fill_days_supply")) \
.withColumn("pat_brth_dt", col("brth_dt")) \
.withColumn("pat_first_name", col("first_name")) \
.withColumn("pat_last_name", col("last_name")) \
.withColumn("pat_gndr_cd", col("gndr_cd")) 
#display(df_final)

# COMMAND ----------

df_final_select=df_final.select("rpt_yr", "rpt_wk", "rx_nbr", "str_nbr", "xfer_fm_rx_nbr", to_date(col("expect_fill_enter_dt")).alias("expect_fill_enter_dt"), "rpt_period", "pat_id", "xfer_fm_str_nbr", "fill_create_ind", "copy_create_ind", "fill_enter_dt", "expect_promise_dt", "actual_promise_dt", "fill_vrfy_dt", "fill_sold_dt", "work_ord", "fill_stat_cd", "fill_dspn_qty", "fill_update_dttm", "fill_type_cd", "fill_enter_user_id", "generic_prod_id", "sim_generic_prod_id_ind", "on_tm_ind", "sla_missed_days", "drug_id", "drug_name", "orig_fill_dspn_qty", "dspn_qty_msmh_cd", "third_party_plan_id", "plan_group_nbr", "bin_nbr", "prcs_ctrl_nbr", "pat_first_name", "pat_last_name", "pat_brth_dt", "pat_gndr_cd", "fill_vrfy_user_id", "fill_print_dt", "fill_supply_days", "last_fill_sold_dt", "last_fill_dspn_qty", "edw_batch_id")
#display(df_final_select)

# COMMAND ----------

path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,PAR_OUTPUT_STG_FILE_3,PAR_BATCH_ID)
df_final_select.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

'''
df_final_select.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", PAR_PE_DB) \
        .option("dbtable",  "PHARMACY_HEALTHCARE.SATR_METRICS_RAWDATA") \
        .option("ON_ERROR","SKIP_FILE")\
        .save()
        '''

# COMMAND ----------

#df_final_select.printSchema()

# COMMAND ----------

rec_count=df_final_select.count()
from pyspark.sql.types import StructType,StructField,StringType,TimestampType
data2 = [(PAR_PROJ_NAME,PAR_SRC_STREAM_NAME,PAR_BATCH_ID,PAR_PSET_NAME,PAR_SRC_STREAM_NAME,'1900-01-01 00:00:00',PAR_OUTPUT_STG_FILE_3,rec_count,PAR_EXEC_WK_END_DT)]
print(data2)
 

schema = StructType([ \
    StructField("PROJ_NAME",StringType(),True), \
    StructField("SRC_STREAM_NAME",StringType(),True), \
    StructField("EDW_BATCH_ID",StringType(),True), \
    StructField("PSET_NAME", StringType(), True), \
    StructField("EXTRACT_TABLE_NAME", StringType(), True), \
    StructField("EXTRACT_DTTM", StringType(), True), \
                     StructField("EXTRACT_FILE_NAME", StringType(), True), \
                     StructField("EXTRACT_RECORD_CNT", StringType(), True), \
                     StructField("EXTRACT_CREATE_DT", StringType(), True)])
 
df_proc = spark.createDataFrame(data=data2,schema=schema)
df_proc=df_proc.withColumn("EXTRACT_DTTM",to_timestamp(col("EXTRACT_DTTM"))) \
                .withColumn("EXTRACT_CREATE_DT",to_date(col("EXTRACT_CREATE_DT")))

path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,'dap_out_pharmacy_extracts_satr_extrct_proc_cntrl_extract_meta_detail_ldr',PAR_BATCH_ID)
df_proc.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

#display(df_proc)
# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#dbutils.widgets.remove('PAR_DB_INPUT_FILE1')
#dbutils.widgets.text('PAR_DB_SNFK_CONSUMP_DB', 'DEV_CONSUMPTION')

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from functools import reduce
#from pyspark.sql import *

#from pyspark.sql.functions import col,when

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
#IN_PATH = dbutils.widgets.get("PAR_DB_INPUT_FILE1")



OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFK_DB_PHAR = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFK_DB_MAST = dbutils.widgets.get("PAR_DB_SNFK_MASTR_DB")
SNFK_DB_CONS = dbutils.widgets.get("PAR_DB_SNFK_CONSUMP_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")



#IN_DATAFILE2 = mountPoint + '/'+ IN_PATH #+ '/' + IN_FILE
#IN_DATAFILE1 = mountPoint + '/'+ IN_FILE1 + '/'+ BATCH_ID

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID
#REJ_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID



#print (IN_DATAFILE2)

print (OUT_FILEPATH)



# COMMAND ----------

#SNFL_WH = 'WBADEVDBENGINEER_WH'
#SNFK_DB_PHAR = 'DEV_PHARMACY_HEALTHCARE'
#SNFK_DB_MAST = 'DEV_MASTER_DATA'
SNFK_SC_PS = 'PATIENT_SERVICES'
SNFK_SC_P = 'PATIENT'
SNFK_SC_D = 'DRUG'
SNFK_SC_L='LOCATION'
SNFK_SC_PR = 'PRDFDLVWB'
SNFK_SC_PL = 'PLAN'
SNFK_TBL_PRES = 'PRESCRIPTION'
SNFK_TBL_PRES_FILL = 'PRESCRIPTION_FILL'
SNFK_TBL_PRES_FILL_M = 'PRESCRIPTION_FILL_SALES_METRIC'
SNFK_TBL_PRES_FILL_P = 'PRESCRIPTION_FILL_PLAN'
SNFK_TBL_P = 'PATIENT'
SNFK_TBL_D = 'DRUG_IC'
SNFK_TBL_DSL = 'DRUG_SPECIALTY_LIST'
SNFK_TBL_DLS = 'DIM_LOCATION_STORE'
SNFK_TBL_DLA = 'LOCATION_STORE_ADDRESS'
SNFK_TBL_GPG = 'GOVERNMENT_PLAN_GROUP'
# pIN_PROCESS_MNTH_START_DT = '0000-12-31'
# pIN_PROCESS_MNTH_END_DT = '9999-12-31'
# pIN_PROCESS_2QTR_START_DT = '0000-12-31'
# pIN_PROCESS_2QTR_END_DT = '9999-12-31'
pTD_EDW_END_DATE = '9999-12-31'
#(0SNFK_DB_PHAR,1SNFK_DB_MAST,2SNFK_SC_PS,3SNFK_SC_P,4SNFK_SC_D,5SNFK_SC_L,6SNFK_SC_PL,7SNFK_TBL_PRES,8SNFK_TBL_PRES_FILL,9SNFK_TBL_PRES_FILL_M,10SNFK_TBL_PRES_FILL_P,11SNFK_TBL_P,12SNFK_TBL_D,13SNFK_TBL_DSL,14SNFK_TBL_DLS,15SNFK_TBL_DLA,16SNFK_TBL_GPG)

# COMMAND ----------

#import org.apache.spark.sql.functions.*
# date1 = spark.sql("select current_date(), trunc(current_date(), 'month') as First,  last_day(current_date()) as Last, date_sub(current_date(), 60) as sub_date, weekofyear(current_date())")
# date1.show()

# COMMAND ----------

# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Select query to make a load ready file
#some columns are commented out as those are missing from the snowflakes talbes


SEL_QUERY = """SELECT  pat.pat_id,
        pat.brth_dt,
        pat.gndr_cd,
        pr.rx_nbr,
        pr.str_nbr,
        pr.rx_create_dt,
        pr.drug_id,
        pr.rx_stat_cd,
        pr.rx_tot_dspn_qty,
        pr.rx_added_qty,
        pr.rx_orig_fill_dttm,
        pr.rx_orig_qty,
        dr.ndc_mfgr_nbr || dr.ndc_prod_nbr || dr.ndc_pkg_cd as ndc11,
        pf.rx_fill_nbr,
        pf.rx_partial_fill_nbr,
        pf.dspn_fill_nbr,
        pf.partial_fill_cd,
        pf.pbr_id,
        pf.pbr_loc_id,
        pf.fill_sold_dt,
        pf.fill_sold_tm,
        pf.fill_sold_dlrs,
        pf.fill_stat_cd,
        pf.fill_qty_dspn,
        pf.fill_days_supply,
        pf.fill_type_cd,
        pf.fill_enter_dt,
        pf.fill_enter_tm,
        sm.fill_revenue_dlrs,
        sm.fill_gross_profit_dlrs,
        fp.third_party_plan_id,
        fp.plan_tot_paid_dlrs,
        fp.plan_copay_dlrs
      FROM {0}.{2}.{7}                   pr
INNER JOIN {0}.{2}.{8}              pf
        ON pr.rx_nbr              = pf.rx_nbr
       AND pr.str_nbr             = pf.str_nbr
       AND pr.rx_create_dt        = pf.rx_create_dt
INNER JOIN {0}.{2}.{9} sm
        ON pf.rx_nbr              = sm.rx_nbr
       AND pf.str_nbr             = sm.str_nbr
       AND pf.rx_fill_nbr         = sm.rx_fill_nbr
       AND pf.rx_partial_fill_nbr = sm.rx_partial_fill_nbr 
       AND pf.fill_sold_dt        = sm.fill_sold_dt
INNER JOIN {0}.{2}.{10}         fp
        ON pf.rx_nbr              = fp.rx_nbr
       AND pf.str_nbr             = fp.str_nbr
       AND pf.rx_fill_nbr         = fp.rx_fill_nbr
       AND pf.rx_partial_fill_nbr = fp.rx_partial_fill_nbr 
       AND pf.fill_sold_dt        = fp.fill_sold_dt
INNER JOIN {0}.{3}.{11}              pat
        ON pf.pat_id              = pat.pat_id
INNER JOIN {0}.{4}.{12}                 dr
        ON pf.drug_id             = dr.drug_id
INNER JOIN {18}.{19}.{14} l
        ON pf.str_nbr             = l.store_nbr
        AND l.edw_rec_end_dt      = '{17}'
INNER JOIN {1}.{5}.{15} a
        ON pf.str_nbr             = a.store_nbr
        AND l.edw_rec_end_dt      = '{17}'
WHERE 
       pf.fill_sold_dt BETWEEN add_months(trunc(current_date(), 'month'),-1) and add_months(last_day(current_date()),-1)
       AND pf.fill_stat_cd   = 'SD'
       AND pf.fill_del_dt    IS NULL
       AND pf.fill_sold_dt   IS NOT NULL
       AND pf.fill_sold_dlrs IS NOT NULL
       AND dr.history_seq_cd = 'C'
       AND fp.cob_ind       <> 'Y'
       AND l.loc_type_cd     = 'S'
       AND a.addr_type_cd    = 'STR'
       AND a.edw_rec_end_dt in ('9999-12-31', '2999-12-31') 
       AND l.district_nbr IS NOT NULL
       AND l.region_nbr IS NOT NULL
       AND fp.third_party_plan_id  NOT IN
           (SELECT DISTINCT gp.third_party_plan_id
              FROM {0}.{6}.{16} gp
             WHERE gp.plan_type_cd   = '340B'
               AND gp.plan_group_nbr = 'ALL'
               AND gp.bin_nbr        = 'ALL'
               AND gp.end_dt        is NULL
            ) 
       AND pat.pat_id IN
           (SELECT DISTINCT pt.pat_id
              FROM {0}.{2}.{8}     pf2
        INNER JOIN {0}.{3}.{11}             pt
                ON pf2.pat_id           = pt.pat_id
        INNER JOIN {0}.{4}.{12}                 drg
                ON pf2.drug_id          = drg.drug_id
        INNER JOIN {0}.{4}.{13}  sl
                ON drg.ndc_mfgr_nbr || drg.ndc_prod_nbr || drg.ndc_pkg_cd = sl.ndc11
             WHERE pf2.fill_sold_dt BETWEEN add_months(trunc(add_months(trunc(current_date(), 'month'),-1), 'month'),-5) and add_months(last_day(current_date()),-1)
               AND pf2.fill_stat_cd     = 'SD'
               AND pf2.fill_del_dt      IS NULL
               AND pf2.fill_sold_dt     IS NOT NULL
               AND pf2.fill_sold_dlrs   IS NOT NULL
               AND sl.catg_cd          = 5
               AND drg.history_seq_cd  = 'C') """.format(SNFK_DB_PHAR,SNFK_DB_MAST, SNFK_SC_PS,SNFK_SC_P,SNFK_SC_D,SNFK_SC_L,SNFK_SC_PL,SNFK_TBL_PRES,SNFK_TBL_PRES_FILL,SNFK_TBL_PRES_FILL_M,SNFK_TBL_PRES_FILL_P,SNFK_TBL_P,SNFK_TBL_D,SNFK_TBL_DSL,SNFK_TBL_DLS,SNFK_TBL_DLA, SNFK_TBL_GPG,pTD_EDW_END_DATE,  SNFK_DB_CONS, SNFK_SC_PR)

# COMMAND ----------


#query = "SELECT pat_id FROM {0}.{1}".format(SNFK_DB_PHAR, SNFK_SC_PS,table_name1)

df_extr = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", SEL_QUERY) \
  .load()

df_extr = df_extr.sort("pat_id")
df_extr= df_extr.drop_duplicates()

#df_extr1 = df_extr.select(lower("pat_id").alias( "pat_id") )
df_extr1 = df_extr.select(df_extr.PAT_ID.alias( "pat_id")
                         ,df_extr.BRTH_DT.alias( "brth_dt")
                         ,df_extr.GNDR_CD.alias( "gndr_cd")
                         ,df_extr.RX_NBR.alias( "rx_nbr")
                         ,df_extr.STR_NBR.alias( "str_nbr")
                         ,df_extr.RX_CREATE_DT.alias( "rx_create_dt")
                         ,df_extr.DRUG_ID.alias( "drug_id")
                         ,df_extr.RX_STAT_CD.alias( "rx_stat_cd")
                         ,df_extr.RX_TOT_DSPN_QTY.alias( "rx_tot_dspn_qty")
                         ,df_extr.RX_ADDED_QTY.alias( "rx_added_qty")
                         ,df_extr.RX_ORIG_FILL_DTTM.alias( "rx_orig_fill_dttm")
                         ,df_extr.RX_ORIG_QTY.alias( "rx_orig_qty")
                         ,df_extr.NDC11.alias( "ndc11")
                         ,df_extr.RX_FILL_NBR.alias( "rx_fill_nbr")
                         ,df_extr.RX_PARTIAL_FILL_NBR.alias( "rx_partial_fill_nbr")
                         ,df_extr.DSPN_FILL_NBR.alias( "dspn_fill_nbr")
                         ,df_extr.PARTIAL_FILL_CD.alias( "partial_fill_cd")
                         ,df_extr.PBR_ID.alias( "pbr_id")
                         ,df_extr.PBR_LOC_ID.alias( "pbr_loc_id")
                         ,df_extr.FILL_SOLD_DT.alias( "fill_sold_dt")
                         ,df_extr.FILL_SOLD_TM.alias( "fill_sold_tm")
                         ,df_extr.FILL_SOLD_DLRS.alias( "fill_sold_dlrs")
                         ,df_extr.FILL_STAT_CD.alias( "fill_stat_cd")
                         ,df_extr.FILL_QTY_DSPN.alias( "fill_qty_dspn")
                         ,df_extr.FILL_DAYS_SUPPLY.alias( "fill_days_supply")
                         ,df_extr.FILL_TYPE_CD.alias( "fill_type_cd")
                         ,df_extr.FILL_ENTER_DT.alias( "fill_enter_dt")
                         ,df_extr.FILL_ENTER_TM.alias( "fill_enter_tm")
                         ,df_extr.FILL_REVENUE_DLRS.alias( "fill_revenue_dlrs")
                         ,df_extr.FILL_GROSS_PROFIT_DLRS.alias( "fill_gross_profit_dlrs")
                         ,df_extr.THIRD_PARTY_PLAN_ID.alias( "third_party_plan_id")
                         ,df_extr.PLAN_TOT_PAID_DLRS.alias( "plan_tot_paid_dlrs")
                         ,df_extr.PLAN_COPAY_DLRS.alias( "plan_copay_dlrS"))

#display(df_extr)
df_extr1.show()

# COMMAND ----------

#Writing data in Parquet format
df_extr1.write.mode('overwrite').parquet(OUT_FILEPATH)

# COMMAND ----------

#SNFK_TBL1 = 'ARV_PATIENT'
#QRY_ARV_PAT = "SELECT distinct pat_id FROM {0}.{1}.{2}".format(SNFK_DB_PHAR, SNFK_SC_PS,SNFK_TBL1)

QRY_ARV_PAT = "SELECT distinct pat_id FROM {0}.{1}".format(SNFK_DB_PHAR, SNFL_TBL_NAME)

df_arv_pat = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", QRY_ARV_PAT) \
  .load()

df_arv_pat = df_arv_pat.sort("pat_id")
df_arv_pat = df_arv_pat.select(df_arv_pat.PAT_ID.alias( "pat_id"))
#df_extr= df_extr.drop_duplicates()
#df_arv_pat.show()

# COMMAND ----------

#Joining two dataframes
df_join = df_extr1.join(df_arv_pat, on=['pat_id'], how='left_anti')
df_join = df_join.select("pat_id", "brth_dt", "gndr_cd")
df_final = df_join.withColumn("edw_batch_id",lit(BATCH_ID)) \
                 .withColumn("edw_create_dttm",current_timestamp()) \
                 .withColumn("edw_last_update_dttm",current_timestamp())
df_final=df_final.dropDuplicates()
#display(df_final)

# COMMAND ----------

df_final.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFK_DB_PHAR) \
   .option("dbtable", SNFL_TBL_NAME) \
   .mode("append") \
   .save()
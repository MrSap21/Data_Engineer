# Databricks notebook source
# Create the notebook parameters

# dbutils.widgets.text("SNOWFLAKE_WAREHOUSE", "")
# dbutils.widgets.text("SNOWFLAKE_DATABASE", "")
# dbutils.widgets.text("SNOWFLAKE_TABLE_NAME", "")
# dbutils.widgets.text("transaction", "")
# dbutils.widgets.text("SNOWFLAKE_SCHEMA", "")
# dbutils.widgets.text("SNOWFLAKE_VIEW_SCHEMA_NAME", "")
# dbutils.widgets.text("SNOWFLAKE_VIEW_DATABASE_NAME", "")
# dbutils.widgets.text("SRX_SCHEMA", "")

# COMMAND ----------

query1 = "DROP TABLE " + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get("SNOWFLAKE_SCHEMA") + "." \
+ dbutils.widgets.get("SNOWFLAKE_TABLE_NAME")

# COMMAND ----------

query2 = "CREATE TABLE " + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get('SNOWFLAKE_SCHEMA') + "." + dbutils.widgets.get('SNOWFLAKE_TABLE_NAME') + "( \
      pat_id DECIMAL(13,0), \
      Fill_Enter_Dt DATE, \
      fill_src_cd CHAR(1), \
      RX_Create_Date DATE, \
      fill_stat_cd CHAR(2), \
      Prescription_Number INTEGER, \
      Store_Number INTEGER, \
      Store_Number_Phone VARCHAR(100), \
      Drug_Name VARCHAR(35), \
      NDC11 CHAR(11), \
      Patient_First_Name VARCHAR(20), \
      Patient_Last_Name VARCHAR(20), \
      Patient_Phone VARCHAR(100), \
      DOB DATE, \
      third_party_plan_id CHAR(8), \
      Insurance_Name VARCHAR(60), \
      plan_type_cd CHAR(2), \
      government_plan_cd VARCHAR(21), \
      plan_return_copay_dlrs DECIMAL(8,2), \
      fill_adjud_cd CHAR(1), \
      Last_Adjud_DTTM VARCHAR(19),\
      Delete_Ind VARCHAR(1), \
      PRIMARY KEY (pat_id,NDC11))"

# COMMAND ----------

query3 = "insert into " + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get('SNOWFLAKE_SCHEMA') + "." + dbutils.widgets.get('SNOWFLAKE_TABLE_NAME') + \
  """ SELECT
  fill.pat_id, 
  fill.fill_enter_dt as Fill_Enter_Dt,
  fill.fill_src_cd as fill_src_cd,
  fill.rx_create_dt as RX_Create_Date,
  fill.fill_stat_cd as fill_stat_cd,
  fill.rx_nbr as Prescription_Number,
  fill.str_nbr as Store_Number,
  strcomm.comm_channel_val as Store_Number_Phone,
  d.prod_name_abbr as Drug_Name,
  d.ndc_mfgr_nbr || d.ndc_prod_nbr || d.ndc_pkg_cd  as NDC11,
  pat.first_name as Patient_First_Name,
  pat.last_name as Patient_Last_Name,
  patcomm.comm_channel_val as Patient_Phone,
  pat.brth_dt as DOB,
  pfp.third_party_plan_id,
  tp.plan_name as Insurance_Name,
  tp.plan_type_cd,
  case when tp.government_plan_cd is null then 'Not Government Funded' else tp.government_plan_cd end  as government_plan_cd,
  pfp.plan_return_copay_dlrs,
  pfp.fill_adjud_cd,
  CAST ( pfp.fill_adjud_dt AS CHAR(10 ) ) || ' ' || CAST ( pfp.fill_adjud_tm AS CHAR(08 ) ) AS Last_Adjud_DTTM ,
  case when fill.fill_stat_cd = 'DL' then 'Y' else 'N' end as Delete_Ind
from 
(select 
rx_nbr, 
fill_src_cd,
str_nbr, 
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt, 
rx_create_dt, 
fill_stat_cd, 
fill_sold_dt, 
dspn_fill_nbr,
pat_id,pbr_id,
drug_id, 
pbr_loc_id,
fill_vrfy_dt

from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "prescription_fill" + """ where fill_enter_dt = (current_date -1) and fill_stat_cd in ('SD','RD')
group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
 ) fill

join 

(select pat_id from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "patient_plan_information " + """where cob_ind = 'N' group by 1
Minus
select pat_id from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "patient_plan_information " +  """where cob_ind  = 'Y' group by 1) ppi on fill.pat_id = ppi.pat_id

left join """ + \
dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "prescription_fill_plan " + """pfp on pfp.rx_nbr = fill.rx_nbr
and pfp.str_nbr = fill.str_nbr 
and pfp.rx_fill_nbr = fill.rx_fill_nbr 
and pfp.rx_partial_fill_nbr = fill.rx_partial_fill_nbr
and pfp.fill_enter_dt = (current_date -1)

left join """ + \
dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "patient pat " + \
"""on (fill.pat_id = pat.pat_id)

left join """ + \
dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "patient_communication_channel " + """patcomm on pat.pat_id = patcomm.pat_id 
and patcomm.channel_type_cd = 'PRIM' 
and patcomm.history_seq_cd = 'C' 

 join """ + \
dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "drug " +"""d on (d.drug_id = fill.drug_id 
and d.history_seq_cd = 'C')

join """ + \
\
dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." + dbutils.widgets.get("SRX_SCHEMA") + \
"." + "SRx_NDC_COPAY " + """srxndc
on (d.ndc11 = srxndc.ndc11 )

left join """ + \
\
dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "location_store_comm_channel " + """strcomm
on (strcomm.str_nbr = fill.str_nbr 
and strcomm.channel_type_cd = 'Str Ph  ' 
and strcomm.src_end_dt is null)
	
left join 

(select * from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "third_party_plan " + """where history_seq_cd = 'C') tp
on (pfp.third_party_plan_id = tp.third_party_plan_id)

join """ + \
dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "location_store " + """ls
on (ls.str_nbr = fill.str_nbr
and ls.ldb_str_type_cd = '01'
and ls.str_nbr not in (select str_nbr from """ + dbutils.widgets.get("SNOWFLAKE_DATABASE") + "." \
+ dbutils.widgets.get("SRX_SCHEMA") + \
"." + "SRx_STORE_COPAY" + """))

where  (pfp.plan_copay_dlrs is null or  pfp.plan_copay_dlrs > 35.00)
and 
(tp.third_party_plan_id is null or
tp.third_party_plan_id in (select third_party_plan_id from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "third_party_plan " + """where history_seq_cd = 'C'
minus
(select third_party_plan_id from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "third_party_plan " + """t where t.history_seq_cd = 'C'
and (t.third_party_plan_id like '%MED' or t.third_party_plan_id like '%DPA' or t.third_party_plan_id in ('KANPA', 'MIDPA', 'TNCAR', 'WISPA') or t.discnt_plan_cd ='MEDI' ) /*Medicaid and Gov't criteria*/
MINUS
select third_party_plan_id from """ + dbutils.widgets.get("SNOWFLAKE_VIEW_DATABASE_NAME") + "." + dbutils.widgets.get("SNOWFLAKE_VIEW_SCHEMA_NAME") + \
"." + "third_party_plan tpp " +  """where   tpp.history_seq_cd = 'C' and (tpp.third_party_plan_id LIKE '%MPD' OR  tpp.discnt_plan_cd IN ('MEDD', 'SECD', 'SUPD' ) or tpp.third_party_plan_id in
(
'ADVMPD',
'AHFCMPD',
'AHFLMPD',
'CAMA',
'CMRKMPD',
'FISERVSP',
'HPMIMPD',
'HPMNEGWP',
'HUMMDC',
'MDCRP',
'OKSPD',
'SIMPMPD',
'SUMEGWP'
)))))
group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22"""

# COMMAND ----------

dbutils.notebook.run("../Utilities/RunSnowSQL", 120, { "query" : query1, "query": query2, "query": query3, "SNOWFLAKE_DATABASE" : dbutils.widgets.get("SNOWFLAKE_DATABASE"), "SNOWFLAKE_WAREHOUSE" : dbutils.widgets.get("SNOWFLAKE_WAREHOUSE"),"transaction" : dbutils.widgets.get("transaction")})
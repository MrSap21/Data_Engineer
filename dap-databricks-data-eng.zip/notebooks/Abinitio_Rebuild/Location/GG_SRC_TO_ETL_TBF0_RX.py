# Databricks notebook source
# Our imported libraries
from functools import reduce
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import input_file_name


# COMMAND ----------
# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 200)

# COMMAND ----------

# dbutils.widgets.text("PAR_DB_BATCH_ID","20220111183013")
# dbutils.widgets.text("PAR_DB_SNFK_ETL","DEV_ETL")
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_OUTPUT_FILENAME","gg_tbf0_rx")
# dbutils.widgets.text("PAR_DB_SNFK_TBL_NAME","PATIENT_SERVICES.ETL_TBF0_RX_STG")
# dbutils.widgets.text("PAR_DB_OUTPUT_PATH","master_data/location/output")
# dbutils.widgets.text("PAR_DB_SNFK_DB","DEV_STAGING")
# dbutils.widgets.text("PAR_DB_REJECT_PATH","master_data/location/reject")
# dbutils.widgets.text("PAR_ETL_HIVE_CUTOFF_TBL","PRDSTGMET.ETL_HIVE_CUTOFF_STG")
# dbutils.widgets.text("PAR_FEED_NAME","GG_TBF0_RX,GG_TBF0_RX_control")
# dbutils.widgets.text("PAR_READAPI_URL","https://dapdevidfappservice-appserver.azurewebsites.net/getUnprocessedFiles")
# dbutils.widgets.text("PAR_WRITEAPI_URL",'https://dapdevidfappservice-appserver.azurewebsites.net/assetUpdate')

# COMMAND ----------
# initializing variables
BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")

OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
REJECT_PATH = dbutils.widgets.get("PAR_DB_REJECT_PATH")

SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_DB = dbutils.widgets.get("PAR_DB_SNFK_DB")
SNFL_TBL_NAME = dbutils.widgets.get("PAR_DB_SNFK_TBL_NAME")
SNFK_ETL_DB = dbutils.widgets.get("PAR_DB_SNFK_ETL")
ETL_HIVE_CUTOFF_TBL = dbutils.widgets.get("PAR_ETL_HIVE_CUTOFF_TBL")

OUT_FILEPATH = mountPoint + '/'+ OUTPUT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID

REJ_BAD_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/bad_records'
REJ_SHORT_FILEPATH = mountPoint + '/'+ REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/schema_mismatch_records'
REJ_FILE_NOISE_RMV =  mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateInsertCheckRejected_Recs'
REJ_FILE_PAT_MOD = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/PatIdCheckRejected_Recs'
REJ_FILE_UPD_NULL = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/UpdateNullReject_Recs'
REJ_FILE_CDC_CHECK = mountPoint + '/' + REJECT_PATH + '/' + OUTPUT_FILENAME + '/' + BATCH_ID + '/cdc_operation_type_cd_nullCheck_Recs'

# COMMAND ----------
# MAGIC %run ../../Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH
# COMMAND ----------
# Noise Reduction below
pRxCutoffTableCheck="( table_name == 'gg_tbf0_rx_close_log' OR table_name == 'gg_tbf0_rx_cmpnd_ingrdnt' OR  table_name == 'gg_tbf0_rx_cmpnd_nonsys' OR   table_name == 'gg_tbf0_erx_msg_mapping' OR table_name == 'gg_tbf0_rx_open_log' OR  table_name == 'gg_tbf0_ret_to_stk_call_list')"  

pRxCutoffTableCheckEqual="(table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist')"

pRxTransCutoffTableCheck="(table_name  == 'gg_tbf0_fill' OR  table_name == 'gg_tbf0_rx_transaction' OR   table_name  == 'gg_tbf0_dur_history' OR   table_name  ==  'gg_tbf0_rx_cntrl_substance' OR table_name  == 'gg_tbf0_sdl_history' OR  table_name  == 'gg_tbf0_exception')" 

pRxTransCutoffTableCheckEqual="(table_name  == 'gg_tbf0_rx_consult_actv' OR table_name  == 'gg_tbf0_rx_consult_adhoc')"

pNopartitionTableCheck="(table_name  != 'gg_tbf0_fill' AND table_name != 'gg_tbf0_rx_transaction' AND table_name  != 'gg_tbf0_rx_consult_actv' AND  table_name  != 'gg_tbf0_dur_history' AND table_name  != 'gg_tbf0_rx_consult_adhoc'   AND  table_name  !=  'gg_tbf0_rx_cntrl_substance' AND table_name  != 'gg_tbf0_sdl_history' AND  table_name  != 'gg_tbf0_exception' AND  table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_close_log' AND table_name != 'gg_tbf0_rx_cmpnd_ingrdnt' AND  table_name != 'gg_tbf0_rx_cmpnd_nonsys' AND table_name != 'gg_tbf0_rx_consult_hist' AND  table_name != 'gg_tbf0_erx_msg_mapping' AND table_name != 'gg_tbf0_rx_open_log' AND  table_name != 'gg_tbf0_ret_to_stk_call_list')" 

pUpdateReform="((store_nbr == store_nbr_after AND  store_nbr IS NOT NULL AND  store_nbr_after IS NOT NULL) AND    (rx_nbr == rx_nbr_after AND  rx_nbr IS NOT NULL AND  rx_nbr_after IS NOT NULL) AND    (create_dttm == create_dttm_after AND  create_dttm IS NOT NULL AND  create_dttm_after IS NOT NULL) AND    (cdc_seq_nbr == cdc_seq_nbr_after AND  cdc_seq_nbr IS NOT NULL AND  cdc_seq_nbr_after IS NOT NULL) AND    (cdc_rba_nbr == cdc_rba_nbr_after AND  cdc_rba_nbr IS NOT NULL AND  cdc_rba_nbr_after IS NOT NULL)  AND    (cdc_txn_commit_dttm == cdc_txn_commit_dttm_after AND  cdc_txn_commit_dttm IS NOT NULL AND  cdc_txn_commit_dttm_after IS NOT NULL) AND    (cdc_before_after_cd_after == 'AFTER' AND  cdc_before_after_cd_after IS NOT NULL ) AND    (cdc_operation_type_cd_after == 'SQL COMPUPDATE' AND  cdc_operation_type_cd_after IS NOT NULL) AND    (cdc_before_after_cd == 'BEFORE' AND  cdc_before_after_cd IS NOT NULL ) AND    (cdc_operation_type_cd == 'SQL COMPUPDATE' AND  cdc_operation_type_cd IS NOT NULL) AND  (( RTRIM(LOWER(pat_id)) == RTRIM(LOWER(pat_id_after ))  AND pat_id IS NOT NULL AND pat_id_after IS NOT NULL ) OR ( pat_id IS NULL AND pat_id_after IS NULL )) AND  (( RTRIM(LOWER(drug_id)) == RTRIM(LOWER(drug_id_after ))  AND drug_id IS NOT NULL AND drug_id_after IS NOT NULL ) OR ( drug_id IS NULL AND drug_id_after IS NULL )) AND  (( RTRIM(LOWER(drug_class)) == RTRIM(LOWER(drug_class_after ))  AND drug_class IS NOT NULL AND drug_class_after IS NOT NULL ) OR ( drug_class IS NULL AND drug_class_after IS NULL )) AND  (( RTRIM(LOWER(drug_non_system_cd)) == RTRIM(LOWER(drug_non_system_cd_after ))  AND drug_non_system_cd IS NOT NULL AND drug_non_system_cd_after IS NOT NULL ) OR ( drug_non_system_cd IS NULL AND drug_non_system_cd_after IS NULL )) AND  (( RTRIM(LOWER(pbr_id)) == RTRIM(LOWER(pbr_id_after ))  AND pbr_id IS NOT NULL AND pbr_id_after IS NOT NULL ) OR ( pbr_id IS NULL AND pbr_id_after IS NULL )) AND  (( RTRIM(LOWER(fill_qty_dispensed)) == RTRIM(LOWER(fill_qty_dispensed_after ))  AND fill_qty_dispensed IS NOT NULL AND fill_qty_dispensed_after IS NOT NULL ) OR ( fill_qty_dispensed IS NULL AND fill_qty_dispensed_after IS NULL )) AND  (( RTRIM(LOWER(fill_days_supply)) == RTRIM(LOWER(fill_days_supply_after ))  AND fill_days_supply IS NOT NULL AND fill_days_supply_after IS NOT NULL ) OR ( fill_days_supply IS NULL AND fill_days_supply_after IS NULL )) AND  (( RTRIM(LOWER(rx_daw_ind)) == RTRIM(LOWER(rx_daw_ind_after ))  AND rx_daw_ind IS NOT NULL AND rx_daw_ind_after IS NOT NULL ) OR ( rx_daw_ind IS NULL AND rx_daw_ind_after IS NULL )) AND  (( RTRIM(LOWER(rx_written_dttm)) == RTRIM(LOWER(rx_written_dttm_after ))  AND rx_written_dttm IS NOT NULL AND rx_written_dttm_after IS NOT NULL ) OR ( rx_written_dttm IS NULL AND rx_written_dttm_after IS NULL )) AND  (( RTRIM(LOWER(rx_original_fill_dttm)) == RTRIM(LOWER(rx_original_fill_dttm_after ))  AND rx_original_fill_dttm IS NOT NULL AND rx_original_fill_dttm_after IS NOT NULL ) OR ( rx_original_fill_dttm IS NULL AND rx_original_fill_dttm_after IS NULL )) AND  (( RTRIM(LOWER(rx_added_qty)) == RTRIM(LOWER(rx_added_qty_after ))  AND rx_added_qty IS NOT NULL AND rx_added_qty_after IS NOT NULL ) OR ( rx_added_qty IS NULL AND rx_added_qty_after IS NULL )) AND  (( RTRIM(LOWER(rx_sig)) == RTRIM(LOWER(rx_sig_after ))  AND rx_sig IS NOT NULL AND rx_sig_after IS NOT NULL ) OR ( rx_sig IS NULL AND rx_sig_after IS NULL )) AND  (( RTRIM(LOWER(rx_refills_by_dttm)) == RTRIM(LOWER(rx_refills_by_dttm_after ))  AND rx_refills_by_dttm IS NOT NULL AND rx_refills_by_dttm_after IS NOT NULL ) OR ( rx_refills_by_dttm IS NULL AND rx_refills_by_dttm_after IS NULL )) AND  (( RTRIM(LOWER(fill_nbr_prescribed)) == RTRIM(LOWER(fill_nbr_prescribed_after ))  AND fill_nbr_prescribed IS NOT NULL AND fill_nbr_prescribed_after IS NOT NULL ) OR ( fill_nbr_prescribed IS NULL AND fill_nbr_prescribed_after IS NULL )) AND  (( RTRIM(LOWER(fill_nbr_dispensed)) == RTRIM(LOWER(fill_nbr_dispensed_after ))  AND fill_nbr_dispensed IS NOT NULL AND fill_nbr_dispensed_after IS NOT NULL ) OR ( fill_nbr_dispensed IS NULL AND fill_nbr_dispensed_after IS NULL )) AND  (( RTRIM(LOWER(fill_nbr_added)) == RTRIM(LOWER(fill_nbr_added_after ))  AND fill_nbr_added IS NOT NULL AND fill_nbr_added_after IS NOT NULL ) OR ( fill_nbr_added IS NULL AND fill_nbr_added_after IS NULL )) AND  (( RTRIM(LOWER(fill_auto_ind)) == RTRIM(LOWER(fill_auto_ind_after ))  AND fill_auto_ind IS NOT NULL AND fill_auto_ind_after IS NOT NULL ) OR ( fill_auto_ind IS NULL AND fill_auto_ind_after IS NULL )) AND  (( RTRIM(LOWER(fill_nbr_last_disp)) == RTRIM(LOWER(fill_nbr_last_disp_after ))  AND fill_nbr_last_disp IS NOT NULL AND fill_nbr_last_disp_after IS NOT NULL ) OR ( fill_nbr_last_disp IS NULL AND fill_nbr_last_disp_after IS NULL )) AND  (( RTRIM(LOWER(fill_entered_dttm)) == RTRIM(LOWER(fill_entered_dttm_after ))  AND fill_entered_dttm IS NOT NULL AND fill_entered_dttm_after IS NOT NULL ) OR ( fill_entered_dttm IS NULL AND fill_entered_dttm_after IS NULL )) AND  (( RTRIM(LOWER(image_id)) == RTRIM(LOWER(image_id_after ))  AND image_id IS NOT NULL AND image_id_after IS NOT NULL ) OR ( image_id IS NULL AND image_id_after IS NULL )) AND  (( RTRIM(LOWER(scanned_user_id)) == RTRIM(LOWER(scanned_user_id_after ))  AND scanned_user_id IS NOT NULL AND scanned_user_id_after IS NOT NULL ) OR ( scanned_user_id IS NULL AND scanned_user_id_after IS NULL )) AND  (( RTRIM(LOWER(scanned_dttm)) == RTRIM(LOWER(scanned_dttm_after ))  AND scanned_dttm IS NOT NULL AND scanned_dttm_after IS NOT NULL ) OR ( scanned_dttm IS NULL AND scanned_dttm_after IS NULL )) AND  (( RTRIM(LOWER(scanned_store_nbr)) == RTRIM(LOWER(scanned_store_nbr_after ))  AND scanned_store_nbr IS NOT NULL AND scanned_store_nbr_after IS NOT NULL ) OR ( scanned_store_nbr IS NULL AND scanned_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(tip_rx_ind)) == RTRIM(LOWER(tip_rx_ind_after ))  AND tip_rx_ind IS NOT NULL AND tip_rx_ind_after IS NOT NULL ) OR ( tip_rx_ind IS NULL AND tip_rx_ind_after IS NULL )) AND  (( RTRIM(LOWER(pbr_order_nbr)) == RTRIM(LOWER(pbr_order_nbr_after ))  AND pbr_order_nbr IS NOT NULL AND pbr_order_nbr_after IS NOT NULL ) OR ( pbr_order_nbr IS NULL AND pbr_order_nbr_after IS NULL )) AND  (( RTRIM(LOWER(drug_sub_cd)) == RTRIM(LOWER(drug_sub_cd_after ))  AND drug_sub_cd IS NOT NULL AND drug_sub_cd_after IS NOT NULL ) OR ( drug_sub_cd IS NULL AND drug_sub_cd_after IS NULL )) AND  (( RTRIM(LOWER(pbr_loc_id)) == RTRIM(LOWER(pbr_loc_id_after ))  AND pbr_loc_id IS NOT NULL AND pbr_loc_id_after IS NOT NULL ) OR ( pbr_loc_id IS NULL AND pbr_loc_id_after IS NULL )) AND  (( RTRIM(LOWER(pay_cd)) == RTRIM(LOWER(pay_cd_after ))  AND pay_cd IS NOT NULL AND pay_cd_after IS NOT NULL ) OR ( pay_cd IS NULL AND pay_cd_after IS NULL )) AND  (( RTRIM(LOWER(rx_comment)) == RTRIM(LOWER(rx_comment_after ))  AND rx_comment IS NOT NULL AND rx_comment_after IS NOT NULL ) OR ( rx_comment IS NULL AND rx_comment_after IS NULL )) AND  (( RTRIM(LOWER(rx_status_cd)) == RTRIM(LOWER(rx_status_cd_after ))  AND rx_status_cd IS NOT NULL AND rx_status_cd_after IS NOT NULL ) OR ( rx_status_cd IS NULL AND rx_status_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_unlimited_ind)) == RTRIM(LOWER(fill_unlimited_ind_after ))  AND fill_unlimited_ind IS NOT NULL AND fill_unlimited_ind_after IS NOT NULL ) OR ( fill_unlimited_ind IS NULL AND fill_unlimited_ind_after IS NULL )) AND  (( RTRIM(LOWER(ordered_drug_id)) == RTRIM(LOWER(ordered_drug_id_after ))  AND ordered_drug_id IS NOT NULL AND ordered_drug_id_after IS NOT NULL ) OR ( ordered_drug_id IS NULL AND ordered_drug_id_after IS NULL )) AND  (( RTRIM(LOWER(generic_subs_pref)) == RTRIM(LOWER(generic_subs_pref_after ))  AND generic_subs_pref IS NOT NULL AND generic_subs_pref_after IS NOT NULL ) OR ( generic_subs_pref IS NULL AND generic_subs_pref_after IS NULL )) AND  (( RTRIM(LOWER(routing_store_nbr)) == RTRIM(LOWER(routing_store_nbr_after ))  AND routing_store_nbr IS NOT NULL AND routing_store_nbr_after IS NOT NULL ) OR ( routing_store_nbr IS NULL AND routing_store_nbr_after IS NULL )) AND  (( RTRIM(LOWER(rx_original_qty_disp)) == RTRIM(LOWER(rx_original_qty_disp_after ))  AND rx_original_qty_disp IS NOT NULL AND rx_original_qty_disp_after IS NOT NULL ) OR ( rx_original_qty_disp IS NULL AND rx_original_qty_disp_after IS NULL )) AND  (( RTRIM(LOWER(rx_original_days_supply)) == RTRIM(LOWER(rx_original_days_supply_after ))  AND rx_original_days_supply IS NOT NULL AND rx_original_days_supply_after IS NOT NULL ) OR ( rx_original_days_supply IS NULL AND rx_original_days_supply_after IS NULL )) AND  (( RTRIM(LOWER(rx_original_qty)) == RTRIM(LOWER(rx_original_qty_after ))  AND rx_original_qty IS NOT NULL AND rx_original_qty_after IS NOT NULL ) OR ( rx_original_qty IS NULL AND rx_original_qty_after IS NULL )) AND  (( RTRIM(LOWER(rx_total_dispensed_qty)) == RTRIM(LOWER(rx_total_dispensed_qty_after ))  AND rx_total_dispensed_qty IS NOT NULL AND rx_total_dispensed_qty_after IS NOT NULL ) OR ( rx_total_dispensed_qty IS NULL AND rx_total_dispensed_qty_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd)) == RTRIM(LOWER(diagnosis_cd_after ))  AND diagnosis_cd IS NOT NULL AND diagnosis_cd_after IS NOT NULL ) OR ( diagnosis_cd IS NULL AND diagnosis_cd_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_qualifier)) == RTRIM(LOWER(diagnosis_cd_qualifier_after ))  AND diagnosis_cd_qualifier IS NOT NULL AND diagnosis_cd_qualifier_after IS NOT NULL ) OR ( diagnosis_cd_qualifier IS NULL AND diagnosis_cd_qualifier_after IS NULL )) AND  (( RTRIM(LOWER(origin_cd)) == RTRIM(LOWER(origin_cd_after ))  AND origin_cd IS NOT NULL AND origin_cd_after IS NOT NULL ) OR ( origin_cd IS NULL AND origin_cd_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_2)) == RTRIM(LOWER(diagnosis_cd_2_after ))  AND diagnosis_cd_2 IS NOT NULL AND diagnosis_cd_2_after IS NOT NULL ) OR ( diagnosis_cd_2 IS NULL AND diagnosis_cd_2_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_3)) == RTRIM(LOWER(diagnosis_cd_3_after ))  AND diagnosis_cd_3 IS NOT NULL AND diagnosis_cd_3_after IS NOT NULL ) OR ( diagnosis_cd_3 IS NULL AND diagnosis_cd_3_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_4)) == RTRIM(LOWER(diagnosis_cd_4_after ))  AND diagnosis_cd_4 IS NOT NULL AND diagnosis_cd_4_after IS NOT NULL ) OR ( diagnosis_cd_4 IS NULL AND diagnosis_cd_4_after IS NULL )) AND  (( RTRIM(LOWER(rx_pad_program_ind)) == RTRIM(LOWER(rx_pad_program_ind_after ))  AND rx_pad_program_ind IS NOT NULL AND rx_pad_program_ind_after IS NOT NULL ) OR ( rx_pad_program_ind IS NULL AND rx_pad_program_ind_after IS NULL )) AND  (( RTRIM(LOWER(rx_pad_barcode)) == RTRIM(LOWER(rx_pad_barcode_after ))  AND rx_pad_barcode IS NOT NULL AND rx_pad_barcode_after IS NOT NULL ) OR ( rx_pad_barcode IS NULL AND rx_pad_barcode_after IS NULL )) AND  (( RTRIM(LOWER(rx_vacc_manuf_lot_nbr)) == RTRIM(LOWER(rx_vacc_manuf_lot_nbr_after ))  AND rx_vacc_manuf_lot_nbr IS NOT NULL AND rx_vacc_manuf_lot_nbr_after IS NOT NULL ) OR ( rx_vacc_manuf_lot_nbr IS NULL AND rx_vacc_manuf_lot_nbr_after IS NULL )) AND  (( RTRIM(LOWER(rx_vacc_exp_dttm)) == RTRIM(LOWER(rx_vacc_exp_dttm_after ))  AND rx_vacc_exp_dttm IS NOT NULL AND rx_vacc_exp_dttm_after IS NOT NULL ) OR ( rx_vacc_exp_dttm IS NULL AND rx_vacc_exp_dttm_after IS NULL )) AND  (( RTRIM(LOWER(rx_vacc_area_of_admin)) == RTRIM(LOWER(rx_vacc_area_of_admin_after ))  AND rx_vacc_area_of_admin IS NOT NULL AND rx_vacc_area_of_admin_after IS NOT NULL ) OR ( rx_vacc_area_of_admin IS NULL AND rx_vacc_area_of_admin_after IS NULL )) AND  (( RTRIM(LOWER(rx_vacc_consent_ind)) == RTRIM(LOWER(rx_vacc_consent_ind_after ))  AND rx_vacc_consent_ind IS NOT NULL AND rx_vacc_consent_ind_after IS NOT NULL ) OR ( rx_vacc_consent_ind IS NULL AND rx_vacc_consent_ind_after IS NULL )) AND  (( RTRIM(LOWER(rx_vacc_pnl_ent_dttm)) == RTRIM(LOWER(rx_vacc_pnl_ent_dttm_after ))  AND rx_vacc_pnl_ent_dttm IS NOT NULL AND rx_vacc_pnl_ent_dttm_after IS NOT NULL ) OR ( rx_vacc_pnl_ent_dttm IS NULL AND rx_vacc_pnl_ent_dttm_after IS NULL )) AND  (( RTRIM(LOWER(rx_vacc_pnl_status_cd)) == RTRIM(LOWER(rx_vacc_pnl_status_cd_after ))  AND rx_vacc_pnl_status_cd IS NOT NULL AND rx_vacc_pnl_status_cd_after IS NOT NULL ) OR ( rx_vacc_pnl_status_cd IS NULL AND rx_vacc_pnl_status_cd_after IS NULL )) AND  (( RTRIM(LOWER(rx_90day_pref_ind)) == RTRIM(LOWER(rx_90day_pref_ind_after ))  AND rx_90day_pref_ind IS NOT NULL AND rx_90day_pref_ind_after IS NOT NULL ) OR ( rx_90day_pref_ind IS NULL AND rx_90day_pref_ind_after IS NULL )) AND  (( RTRIM(LOWER(rx_90day_pref_dttm)) == RTRIM(LOWER(rx_90day_pref_dttm_after ))  AND rx_90day_pref_dttm IS NOT NULL AND rx_90day_pref_dttm_after IS NOT NULL ) OR ( rx_90day_pref_dttm IS NULL AND rx_90day_pref_dttm_after IS NULL )) AND  (( RTRIM(LOWER(rx_90day_pref_stat_cd)) == RTRIM(LOWER(rx_90day_pref_stat_cd_after ))  AND rx_90day_pref_stat_cd IS NOT NULL AND rx_90day_pref_stat_cd_after IS NOT NULL ) OR ( rx_90day_pref_stat_cd IS NULL AND rx_90day_pref_stat_cd_after IS NULL )) AND  (( RTRIM(LOWER(rx_90day_pref_stat_dttm)) == RTRIM(LOWER(rx_90day_pref_stat_dttm_after ))  AND rx_90day_pref_stat_dttm IS NOT NULL AND rx_90day_pref_stat_dttm_after IS NOT NULL ) OR ( rx_90day_pref_stat_dttm IS NULL AND rx_90day_pref_stat_dttm_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_5)) == RTRIM(LOWER(diagnosis_cd_5_after ))  AND diagnosis_cd_5 IS NOT NULL AND diagnosis_cd_5_after IS NOT NULL ) OR ( diagnosis_cd_5 IS NULL AND diagnosis_cd_5_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_qualifier_2)) == RTRIM(LOWER(diagnosis_cd_qualifier_2_after ))  AND diagnosis_cd_qualifier_2 IS NOT NULL AND diagnosis_cd_qualifier_2_after IS NOT NULL ) OR ( diagnosis_cd_qualifier_2 IS NULL AND diagnosis_cd_qualifier_2_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_qualifier_3)) == RTRIM(LOWER(diagnosis_cd_qualifier_3_after ))  AND diagnosis_cd_qualifier_3 IS NOT NULL AND diagnosis_cd_qualifier_3_after IS NOT NULL ) OR ( diagnosis_cd_qualifier_3 IS NULL AND diagnosis_cd_qualifier_3_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_qualifier_4)) == RTRIM(LOWER(diagnosis_cd_qualifier_4_after ))  AND diagnosis_cd_qualifier_4 IS NOT NULL AND diagnosis_cd_qualifier_4_after IS NOT NULL ) OR ( diagnosis_cd_qualifier_4 IS NULL AND diagnosis_cd_qualifier_4_after IS NULL )) AND  (( RTRIM(LOWER(diagnosis_cd_qualifier_5)) == RTRIM(LOWER(diagnosis_cd_qualifier_5_after ))  AND diagnosis_cd_qualifier_5 IS NOT NULL AND diagnosis_cd_qualifier_5_after IS NOT NULL ) OR ( diagnosis_cd_qualifier_5 IS NULL AND diagnosis_cd_qualifier_5_after IS NULL )) AND  (( RTRIM(LOWER(pbr_dea_nbr)) == RTRIM(LOWER(pbr_dea_nbr_after ))  AND pbr_dea_nbr IS NOT NULL AND pbr_dea_nbr_after IS NOT NULL ) OR ( pbr_dea_nbr IS NULL AND pbr_dea_nbr_after IS NULL )) AND  (( RTRIM(LOWER(pbr_dea_suf)) == RTRIM(LOWER(pbr_dea_suf_after ))  AND pbr_dea_suf IS NOT NULL AND pbr_dea_suf_after IS NOT NULL ) OR ( pbr_dea_suf IS NULL AND pbr_dea_suf_after IS NULL )) AND  (( RTRIM(LOWER(buyout_rx_ind)) == RTRIM(LOWER(buyout_rx_ind_after ))  AND buyout_rx_ind IS NOT NULL AND buyout_rx_ind_after IS NOT NULL ) OR ( buyout_rx_ind IS NULL AND buyout_rx_ind_after IS NULL )) AND  (( RTRIM(LOWER(trmt_type_cd)) == RTRIM(LOWER(trmt_type_cd_after ))  AND trmt_type_cd IS NOT NULL AND trmt_type_cd_after IS NOT NULL ) OR ( trmt_type_cd IS NULL AND trmt_type_cd_after IS NULL )) AND  (( RTRIM(LOWER(fill_sold_dttm)) == RTRIM(LOWER(fill_sold_dttm_after ))  AND fill_sold_dttm IS NOT NULL AND fill_sold_dttm_after IS NOT NULL ) OR ( fill_sold_dttm IS NULL AND fill_sold_dttm_after IS NULL )) AND  (( RTRIM(LOWER(erx_pat_automatch_ind)) == RTRIM(LOWER(erx_pat_automatch_ind_after ))  AND erx_pat_automatch_ind IS NOT NULL AND erx_pat_automatch_ind_after IS NOT NULL ) OR ( erx_pat_automatch_ind IS NULL AND erx_pat_automatch_ind_after IS NULL )) AND  (( RTRIM(LOWER(rx_90day_switch_ind)) == RTRIM(LOWER(rx_90day_switch_ind_after ))  AND rx_90day_switch_ind IS NOT NULL AND rx_90day_switch_ind_after IS NOT NULL ) OR ( rx_90day_switch_ind IS NULL AND rx_90day_switch_ind_after IS NULL )) AND (( RTRIM(LOWER(fill_adv_rfl_opt_ind)) == RTRIM(LOWER(fill_adv_rfl_opt_ind_after ))  AND fill_adv_rfl_opt_ind IS NOT NULL AND fill_adv_rfl_opt_ind_after IS NOT NULL ) OR ( fill_adv_rfl_opt_ind IS NULL AND fill_adv_rfl_opt_ind_after IS NULL )) AND (( RTRIM(LOWER(fill_adv_rfl_opt_dttm)) == RTRIM(LOWER(fill_adv_rfl_opt_dttm_after ))  AND fill_adv_rfl_opt_dttm IS NOT NULL AND fill_adv_rfl_opt_dttm_after IS NOT NULL ) OR ( fill_adv_rfl_opt_dttm IS NULL AND fill_adv_rfl_opt_dttm_after IS NULL )) AND (( RTRIM(LOWER(rx_vacc_info_race)) == RTRIM(LOWER(rx_vacc_info_race_after )) AND rx_vacc_info_race IS NOT NULL AND rx_vacc_info_race_after IS NOT NULL ) OR ( rx_vacc_info_race IS NULL AND rx_vacc_info_race_after IS NULL )) AND (( RTRIM(LOWER(rx_vacc_info_ethnicity)) == RTRIM(LOWER(rx_vacc_info_ethnicity_after )) AND rx_vacc_info_ethnicity IS NOT NULL AND rx_vacc_info_ethnicity_after IS NOT NULL ) OR ( rx_vacc_info_ethnicity IS NULL AND rx_vacc_info_ethnicity_after IS NULL )) AND (( RTRIM(LOWER(rx_vacc_info_comorbidity)) == RTRIM(LOWER(rx_vacc_info_comorbidity_after )) AND rx_vacc_info_comorbidity IS NOT NULL AND rx_vacc_info_comorbidity_after IS NOT NULL ) OR ( rx_vacc_info_comorbidity IS NULL AND rx_vacc_info_comorbidity_after IS NULL )))"

pPatIdModCheck="(CAST(pat_id AS LONG)%4 == CAST(src_partition_nbr AS INTEGER) -1) AND (table_name == 'gg_tbf0_rx' OR table_name == 'gg_tbf0_rx_consult_hist' OR table_name == 'gg_tbf0_sdl_history' OR table_name == 'gg_tbf0_pat_thrd_pty' OR table_name == 'gg_tbf0_patient' OR table_name == 'gg_tbf0_pat_algy_hlth_cd' OR table_name == 'gg_tbf0_pat_rca_service')"

pNoPatIdTableCheck="(table_name != 'gg_tbf0_rx' AND table_name != 'gg_tbf0_rx_consult_hist' AND table_name != 'gg_tbf0_sdl_history' AND table_name != 'gg_tbf0_pat_thrd_pty' AND table_name != 'gg_tbf0_patient' AND table_name != 'gg_tbf0_pat_algy_hlth_cd' AND table_name != 'gg_tbf0_pat_rca_service')" 

pTgtUDFcleanXfr="cdc_txn_commit_dttm AS cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr, cdc_operation_type_cd, cdc_before_after_cd, cdc_txn_position_cd, edw_batch_id, store_nbr, rx_nbr, pat_id, drug_id, drug_class, drug_non_system_cd, pbr_id, fill_qty_dispensed, fill_days_supply, rx_daw_ind,rx_written_dttm AS rx_written_dttm, rx_original_fill_dttm AS rx_original_fill_dttm,rx_added_qty, rx_sig, rx_refills_by_dttm AS rx_refills_by_dttm, fill_nbr_prescribed, fill_nbr_dispensed, fill_nbr_added, fill_auto_ind, fill_nbr_last_disp, fill_entered_dttm AS fill_entered_dttm, image_id, scanned_user_id, scanned_dttm AS scanned_dttm, scanned_store_nbr, tip_rx_ind, pbr_order_nbr, drug_sub_cd, pbr_loc_id, pay_cd, rx_comment, rx_status_cd, fill_unlimited_ind, ordered_drug_id, create_user_id, create_dttm AS create_dttm, update_user_id, update_dttm AS update_dttm, generic_subs_pref, routing_store_nbr, rx_original_qty_disp, rx_original_days_supply, src_partition_nbr, rx_total_dispensed_qty, rx_original_qty, diagnosis_cd, diagnosis_cd_qualifier, origin_cd, diagnosis_cd_2, diagnosis_cd_3, diagnosis_cd_4, rx_pad_program_ind, rx_pad_barcode, rx_vacc_manuf_lot_nbr, rx_vacc_exp_dttm AS rx_vacc_exp_dttm, rx_vacc_area_of_admin, rx_vacc_consent_ind, rx_vacc_pnl_ent_dttm AS rx_vacc_pnl_ent_dttm, rx_vacc_pnl_status_cd, rx_90day_pref_ind, rx_90day_pref_dttm AS rx_90day_pref_dttm, rx_90day_pref_stat_cd, rx_90day_pref_stat_dttm AS rx_90day_pref_stat_dttm, diagnosis_cd_5, diagnosis_cd_qualifier_2, diagnosis_cd_qualifier_3, diagnosis_cd_qualifier_4, diagnosis_cd_qualifier_5, pbr_dea_nbr, pbr_dea_suf, buyout_rx_ind,trmt_type_cd,fill_sold_dttm AS fill_sold_dttm,erx_pat_automatch_ind,rx_90day_switch_ind,fill_adv_rfl_opt_ind, CONCAT(fill_adv_rfl_opt_dttm,'.000000') AS fill_adv_rfl_opt_dttm,  rx_vacc_info_race, rx_vacc_info_ethnicity, rx_vacc_info_comorbidity "

#, src_partition_nbr, tracking_id, partition_column"
# COMMAND ----------
# Read ETL_HIVE_CUTOFF table:
from pyspark.sql import *

sel_ETL_Hive_Cutoff_tbl = "Select * FROM {0}".format(ETL_HIVE_CUTOFF_TBL)

#print(sel_ETL_Hive_Cutoff_tbl)
df_cutoff_records_output=spark.read \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase",SNFK_ETL_DB) \
   .option("query",sel_ETL_Hive_Cutoff_tbl) \
   .load()

#display(df_cutoff_records_output)
# Filtering the cutoff timestamp for the current batch
cutoff_records_filter = df_cutoff_records_output.filter((col("EDW_BATCH_ID") == BATCH_ID) & (col("PROJ_NAME") == "WALGREENS"))
#display(cutoff_records_filter)

cutoff_records_filter.createOrReplaceTempView("cutoff_records_filter")

#Selecting rx_min(lower bound) and rx_max(upper bound) cutoff values
cutoff_range_rx_sql = """select RX_CUT_OFF_MIN_DTTM as rx_min, 
RX_CUT_OFF_MAX_DTTM as rx_max,
CONCAT(SUBSTRING(RX_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MAX_DTTM,9,2)) as rx_max_substring,
CONCAT(SUBSTRING(RX_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_CUT_OFF_MIN_DTTM,9,2)) as rx_min_substring 
from cutoff_records_filter""" 

cutoff_range_rx = spark.sql(cutoff_range_rx_sql)
#display(cutoff_range_rx)

#Selecting rx_trans_min(lower bound) and rx_trans_max(upper bound) cutoff values
cutoff_range_trans_sql = """select RX_TRAN_CUT_OFF_MIN_DTTM as rx_trans_min, 
RX_TRAN_CUT_OFF_MAX_DTTM as rx_trans_max,
CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MAX_DTTM,9,2)) as rx_trans_max_substring,
CONCAT(SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,0,4),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,6,2),SUBSTRING(RX_TRAN_CUT_OFF_MIN_DTTM,9,2)) as rx_trans_min_substring 
from cutoff_records_filter"""

cutoff_range_trans = spark.sql(cutoff_range_trans_sql)
#display(cutoff_range_trans)

# COMMAND ----------

#Applying Filter on Partitioned Source Tables based on cutoff value

nr_input_filter_rxpartition_sql = "select * from staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg where " + pRxCutoffTableCheck + " or " + pRxCutoffTableCheckEqual

nr_input_filter_transpartition_sql = "select * from staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg where " + pRxTransCutoffTableCheck + " or " + pRxTransCutoffTableCheckEqual

nr_input_filter_nopartition_sql = "select * from staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_stg where " + pNopartitionTableCheck

#print(nr_input_filter_nopartition_sql)

nr_input_filter_rxpartition = spark.sql(nr_input_filter_rxpartition_sql)

nr_input_filter_transpartition = spark.sql(nr_input_filter_transpartition_sql)

nr_input_filter_nopartition = spark.sql(nr_input_filter_nopartition_sql)
#display(nr_input_filter_rxpartition)

#Fetching rx_max and rx_trans_max as values
rx_max = cutoff_range_rx.select("rx_max").collect()[0].rx_max
#print(rx_max)
rx_trans_max = cutoff_range_trans.select("rx_trans_max").collect()[0].rx_trans_max
#print(rx_trans_max)

#Applying rx_cutoff range on rx related tables
nr_input_file_filter_rx = nr_input_filter_rxpartition.filter(pRxCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_max)

nr_input_file_filter_rx_equal = nr_input_filter_rxpartition.filter(pRxCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_max)

#Applying trans_cutoff range on trans related tables
nr_input_file_filter_trans = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheck).filter(col("cdc_txn_commit_dttm") < rx_trans_max)

nr_input_file_filter_trans_equal = nr_input_filter_transpartition.filter(pRxTransCutoffTableCheckEqual).filter(col("cdc_txn_commit_dttm") <= rx_trans_max)

#Applying UNION on cutoff filters. (Based on above filters, any one of the relations will contain the output for further steps)
nr_input_file_final = nr_input_file_filter_rx.union(nr_input_file_filter_trans)

nr_input_file_final = nr_input_file_final.union(nr_input_filter_nopartition)

nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_rx_equal)

nr_input_file_final = nr_input_file_final.union(nr_input_file_filter_trans_equal)

#Remove duplicates
dedup_group = nr_input_file_final.distinct()

dedup_group.createOrReplaceTempView("dedup_group")

ded = spark.sql("select * from dedup_group")

# COMMAND ----------

nr_spacetrim_sql = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm_after,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr_after,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr_after,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd_after,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd_after,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd_after,
(case when (LENGTH(trim( edw_batch_id )) ==0) then edw_batch_id else trim(edw_batch_id) end) as edw_batch_id,
(case when (LENGTH(trim( edw_batch_id_after )) ==0) then edw_batch_id_after else trim(edw_batch_id_after) end) as edw_batch_id_after,
(case when (LENGTH(trim( store_nbr ))==0) then store_nbr else trim(store_nbr) end) as store_nbr,
(case when (LENGTH(trim( store_nbr_after ))==0) then store_nbr_after else trim(store_nbr_after) end) as store_nbr_after,
(case when (LENGTH(trim( rx_nbr )) ==0) then rx_nbr else trim(rx_nbr) end) as rx_nbr,
(case when (LENGTH(trim( rx_nbr_after )) ==0) then rx_nbr_after else trim(rx_nbr_after) end) as rx_nbr_after,
(case when (LENGTH(trim( pat_id )) ==0) then pat_id else trim(pat_id) end) as pat_id,
(case when (LENGTH(trim( pat_id_after )) ==0) then pat_id_after else trim(pat_id_after) end) as pat_id_after,
(case when (LENGTH(trim(drug_id))==0) then drug_id else trim(drug_id ) end) as drug_id,
(case when (LENGTH(trim( drug_id_after )) ==0) then drug_id_after else trim(drug_id_after) end) as drug_id_after,
(case when (LENGTH(trim( drug_class )) ==0) then drug_class else trim(drug_class) end) as drug_class,
(case when (LENGTH(trim( drug_class_after )) ==0) then drug_class_after else trim(drug_class_after) end) as drug_class_after,
(case when (LENGTH(trim( drug_non_system_cd )) ==0) then drug_non_system_cd else trim(drug_non_system_cd) end) as drug_non_system_cd,
(case when (LENGTH(trim( drug_non_system_cd_after )) ==0) then drug_non_system_cd_after else trim(drug_non_system_cd_after) end) as drug_non_system_cd_after,
(case when (LENGTH(trim( drug_sub_cd )) ==0) then drug_sub_cd else trim(drug_sub_cd) end) as drug_sub_cd,
(case when (LENGTH(trim( drug_sub_cd_after )) ==0) then drug_sub_cd_after else trim(drug_sub_cd_after) end) as drug_sub_cd_after,
(case when (LENGTH(trim( pbr_id )) ==0) then pbr_id else trim(pbr_id) end) as pbr_id,
(case when (LENGTH(trim( pbr_id_after )) ==0) then pbr_id_after else trim(pbr_id_after) end) as pbr_id_after,
(case when (LENGTH(trim(pbr_loc_id )) ==0 ) then pbr_loc_id else trim(pbr_loc_id) end ) as pbr_loc_id,
(case when (LENGTH(trim(pbr_loc_id_after )) ==0 ) then pbr_loc_id_after else trim(pbr_loc_id_after) end ) as pbr_loc_id_after,
(case when (LENGTH(trim(pay_cd )) ==0 ) then pay_cd else trim(pay_cd) end ) as pay_cd,
(case when (LENGTH(trim(pay_cd_after )) ==0 ) then pay_cd_after else trim(pay_cd_after) end ) as pay_cd_after,
(case when (LENGTH(trim(rx_comment ) ) ==0 ) then rx_comment else trim(rx_comment) end ) as rx_comment,
(case when (LENGTH(trim(rx_comment_after ) ) ==0 ) then rx_comment_after else trim(rx_comment_after) end ) as rx_comment_after,
(case when (LENGTH(trim(rx_daw_ind ) ) ==0 ) then rx_daw_ind else trim(rx_daw_ind) end ) as rx_daw_ind,
(case when (LENGTH(trim(rx_daw_ind_after ) ) ==0 ) then rx_daw_ind_after else trim(rx_daw_ind_after) end ) as rx_daw_ind_after,
(case when (LENGTH(trim(rx_written_dttm ) ) ==0 ) then rx_written_dttm else concat(substring(rx_written_dttm,1,10),' ',substring(rx_written_dttm,12,8)) end ) as rx_written_dttm,
(case when (LENGTH(trim(rx_written_dttm_after ) ) ==0 ) then rx_written_dttm_after else concat(substring(rx_written_dttm_after,1,10),' ',substring(rx_written_dttm,12,8)) end ) as rx_written_dttm_after,
(case when (LENGTH(trim(rx_original_fill_dttm ) ) ==0 ) then rx_original_fill_dttm else concat(substring(rx_original_fill_dttm,1,10),' ',substring(rx_original_fill_dttm,12,8)) end ) as rx_original_fill_dttm,
(case when (LENGTH(trim(rx_original_fill_dttm_after ) ) ==0 ) then rx_original_fill_dttm_after else concat(substring(rx_original_fill_dttm_after,1,10),' ',substring(rx_original_fill_dttm_after,12,8)) end ) as rx_original_fill_dttm_after,
(case when (LENGTH(trim(rx_status_cd ) ) ==0 ) then rx_status_cd else trim(rx_status_cd) end ) as rx_status_cd,
(case when (LENGTH(trim(rx_status_cd_after ) ) ==0 ) then rx_status_cd_after else trim(rx_status_cd_after) end ) as rx_status_cd_after,
(case when (LENGTH(trim(rx_sig ) ) ==0 ) then rx_sig else trim(rx_sig) end ) as rx_sig,
(case when (LENGTH(trim(rx_sig_after ) ) ==0 ) then rx_sig_after else trim(rx_sig_after) end ) as rx_sig_after,
(case when (LENGTH(trim(rx_original_qty ) ) ==0 ) then rx_original_qty else trim(rx_original_qty) end ) as rx_original_qty,
(case when (LENGTH(trim(rx_original_qty_after ) ) ==0 ) then rx_original_qty_after else trim(rx_original_qty_after) end ) as rx_original_qty_after,
(case when (LENGTH(trim(rx_total_dispensed_qty ) ) ==0 ) then rx_total_dispensed_qty else trim(rx_total_dispensed_qty) end ) as rx_total_dispensed_qty,
(case when (LENGTH(trim(rx_total_dispensed_qty_after ) ) ==0 ) then rx_total_dispensed_qty_after else trim(rx_total_dispensed_qty_after) end ) as rx_total_dispensed_qty_after,
(case when (LENGTH(trim(rx_refills_by_dttm ) ) ==0 ) then rx_refills_by_dttm else concat(substring(rx_refills_by_dttm,1,10),' ',substring(rx_refills_by_dttm,12,8)) end ) as rx_refills_by_dttm,
(case when (LENGTH(trim(rx_refills_by_dttm_after ) ) ==0 ) then rx_refills_by_dttm_after else concat(substring(rx_refills_by_dttm_after,1,10),' ',substring(rx_refills_by_dttm_after,12,8)) end ) as rx_refills_by_dttm_after,
(case when (LENGTH(trim(fill_nbr_prescribed ) ) ==0 ) then fill_nbr_prescribed else trim(fill_nbr_prescribed) end ) as fill_nbr_prescribed,
(case when (LENGTH(trim(fill_nbr_prescribed_after ) ) ==0 ) then fill_nbr_prescribed_after else trim(fill_nbr_prescribed_after) end ) as fill_nbr_prescribed_after,
(case when (LENGTH(trim(fill_nbr_dispensed ) ) ==0 ) then fill_nbr_dispensed else trim(fill_nbr_dispensed) end ) as fill_nbr_dispensed,
(case when (LENGTH(trim(fill_nbr_dispensed_after ) ) ==0 ) then fill_nbr_dispensed_after else trim(fill_nbr_dispensed_after) end ) as fill_nbr_dispensed_after,
(case when (LENGTH(trim(fill_nbr_added ) ) ==0 ) then fill_nbr_added else trim(fill_nbr_added) end ) as fill_nbr_added,
(case when (LENGTH(trim(fill_nbr_added_after ) ) ==0 ) then fill_nbr_added_after else trim(fill_nbr_added_after) end ) as fill_nbr_added_after,
(case when (LENGTH(trim(fill_unlimited_ind ) ) ==0 ) then fill_unlimited_ind else trim(fill_unlimited_ind) end ) as fill_unlimited_ind,
(case when (LENGTH(trim(fill_unlimited_ind_after ) ) ==0 ) then fill_unlimited_ind_after else trim(fill_unlimited_ind_after) end ) as fill_unlimited_ind_after,
(case when (LENGTH(trim(fill_auto_ind ) ) ==0 ) then fill_auto_ind else trim(fill_auto_ind) end ) as fill_auto_ind,
(case when (LENGTH(trim(fill_auto_ind_after ) ) ==0 ) then fill_auto_ind_after else trim(fill_auto_ind_after) end ) as fill_auto_ind_after,
(case when (LENGTH(trim(ordered_drug_id ) ) ==0 ) then ordered_drug_id else trim(ordered_drug_id) end ) as ordered_drug_id,
(case when (LENGTH(trim(ordered_drug_id_after ) ) ==0 ) then ordered_drug_id_after else trim(ordered_drug_id_after) end ) as ordered_drug_id_after,
(case when (LENGTH(trim(rx_original_qty_disp ) ) ==0 ) then rx_original_qty_disp else trim(rx_original_qty_disp) end ) as rx_original_qty_disp,
(case when (LENGTH(trim(rx_original_qty_disp_after ) ) ==0 ) then rx_original_qty_disp_after else trim(rx_original_qty_disp_after) end ) as rx_original_qty_disp_after,
(case when (LENGTH(trim(rx_original_days_supply ) ) ==0 ) then rx_original_days_supply else trim(rx_original_days_supply) end ) as rx_original_days_supply,
(case when (LENGTH(trim(rx_original_days_supply_after ) ) ==0 ) then rx_original_days_supply_after else trim(rx_original_days_supply_after) end ) as rx_original_days_supply_after,
(case when (LENGTH(trim(create_user_id ) ) ==0 ) then create_user_id else trim(create_user_id) end ) as create_user_id,
(case when (LENGTH(trim(create_user_id_after ) ) ==0 ) then create_user_id_after else trim(create_user_id_after) end ) as create_user_id_after,
(case when (LENGTH(trim(create_dttm ) ) ==0 ) then create_dttm else concat(substring(create_dttm,1,10),' ',substring(create_dttm,12,8)) end ) as create_dttm,
(case when (LENGTH(trim(create_dttm_after ) ) ==0 ) then create_dttm_after else concat(substring(create_dttm_after,1,10),' ',substring(create_dttm_after,12,8)) end ) as create_dttm_after,
(case when (LENGTH(trim(update_user_id ) ) ==0 ) then update_user_id else trim(update_user_id) end ) as update_user_id,
(case when (LENGTH(trim(update_user_id_after ) ) ==0 ) then update_user_id_after else trim(update_user_id_after) end ) as update_user_id_after,
(case when (LENGTH(trim(update_dttm ) ) ==0 ) then update_dttm else concat(substring(update_dttm,1,10),' ',substring(update_dttm,12,8)) end ) as update_dttm,
(case when (LENGTH(trim(update_dttm_after ) ) ==0 ) then update_dttm_after else concat(substring(update_dttm_after,1,10),' ',substring(update_dttm_after,12,8)) end ) as update_dttm_after,
(case when (LENGTH(trim(generic_subs_pref ) ) ==0 ) then generic_subs_pref else trim(generic_subs_pref) end ) as generic_subs_pref,
(case when (LENGTH(trim(generic_subs_pref_after ) ) ==0 ) then generic_subs_pref_after else trim(generic_subs_pref_after) end ) as generic_subs_pref_after,
(case when (LENGTH(trim(diagnosis_cd ) ) ==0 ) then diagnosis_cd else trim(diagnosis_cd) end ) as diagnosis_cd,
(case when (LENGTH(trim(diagnosis_cd_after ) ) ==0 ) then diagnosis_cd_after else trim(diagnosis_cd_after) end ) as diagnosis_cd_after,
(case when (LENGTH(trim(image_id ) ) ==0 ) then image_id else trim(image_id) end ) as image_id,
(case when (LENGTH(trim(image_id_after ) ) ==0 ) then image_id_after else trim(image_id_after) end ) as image_id_after,
(case when (LENGTH(trim(routing_store_nbr ) ) ==0 ) then routing_store_nbr else trim(routing_store_nbr) end ) as routing_store_nbr,
(case when (LENGTH(trim(routing_store_nbr_after ) ) ==0 ) then routing_store_nbr_after else trim(routing_store_nbr_after) end ) as routing_store_nbr_after,
(case when (LENGTH(trim(scanned_user_id ) ) ==0 ) then scanned_user_id else trim(scanned_user_id) end ) as scanned_user_id,
(case when (LENGTH(trim(scanned_user_id_after ) ) ==0 ) then scanned_user_id_after else trim(scanned_user_id_after) end ) as scanned_user_id_after,
(case when (LENGTH(trim(scanned_dttm ) ) ==0 ) then scanned_dttm else concat(substring(scanned_dttm,1,10),' ',substring(scanned_dttm,12,8)) end ) as scanned_dttm,
(case when (LENGTH(trim(scanned_dttm_after ) ) ==0 ) then scanned_dttm_after else concat(substring(scanned_dttm_after,1,10),' ',substring(scanned_dttm_after,12,8)) end ) as scanned_dttm_after,
(case when (LENGTH(trim(scanned_store_nbr ) ) ==0 ) then scanned_store_nbr else trim(scanned_store_nbr) end ) as scanned_store_nbr,
(case when (LENGTH(trim(scanned_store_nbr_after ) ) ==0 ) then scanned_store_nbr_after else trim(scanned_store_nbr_after) end ) as scanned_store_nbr_after,
(case when (LENGTH(trim(diagnosis_cd_qualifier ) ) ==0 ) then diagnosis_cd_qualifier else trim(diagnosis_cd_qualifier) end ) as diagnosis_cd_qualifier,
(case when (LENGTH(trim(diagnosis_cd_qualifier_after ) ) ==0 ) then diagnosis_cd_qualifier_after else trim(diagnosis_cd_qualifier_after) end ) as diagnosis_cd_qualifier_after,
(case when (LENGTH(trim(tip_rx_ind ) ) ==0 ) then tip_rx_ind else trim(tip_rx_ind) end ) as tip_rx_ind,
(case when (LENGTH(trim(tip_rx_ind_after ) ) ==0 ) then tip_rx_ind_after else trim(tip_rx_ind_after) end ) as tip_rx_ind_after,
(case when (LENGTH(trim(pbr_order_nbr ) ) ==0 ) then pbr_order_nbr else trim(pbr_order_nbr) end ) as pbr_order_nbr,
(case when (LENGTH(trim(pbr_order_nbr_after ) ) ==0 ) then pbr_order_nbr_after else trim(pbr_order_nbr_after) end ) as pbr_order_nbr_after,
(case when (LENGTH(trim(origin_cd ) ) ==0 ) then origin_cd else trim(origin_cd) end ) as origin_cd,
(case when (LENGTH(trim(origin_cd_after ) ) ==0 ) then origin_cd_after else trim(origin_cd_after) end ) as origin_cd_after,
(case when (LENGTH(trim(diagnosis_cd_2 ) ) ==0 ) then diagnosis_cd_2 else trim(diagnosis_cd_2) end ) as diagnosis_cd_2,
(case when (LENGTH(trim(diagnosis_cd_2_after ) ) ==0 ) then diagnosis_cd_2_after else trim(diagnosis_cd_2_after) end ) as diagnosis_cd_2_after,
(case when (LENGTH(trim(diagnosis_cd_3 ) ) ==0 ) then diagnosis_cd_3 else trim(diagnosis_cd_3) end ) as diagnosis_cd_3,
(case when (LENGTH(trim(diagnosis_cd_3_after ) ) ==0 ) then diagnosis_cd_3_after else trim(diagnosis_cd_3_after) end ) as diagnosis_cd_3_after,
(case when (LENGTH(trim(diagnosis_cd_4 ) ) ==0 ) then diagnosis_cd_4 else trim(diagnosis_cd_4) end ) as diagnosis_cd_4,
(case when (LENGTH(trim(diagnosis_cd_4_after ) ) ==0 ) then diagnosis_cd_4_after else trim(diagnosis_cd_4_after) end ) as diagnosis_cd_4_after,
(case when (LENGTH(trim(rx_pad_program_ind ) ) ==0 ) then rx_pad_program_ind else trim(rx_pad_program_ind) end ) as rx_pad_program_ind,
(case when (LENGTH(trim(rx_pad_program_ind_after ) ) ==0 ) then rx_pad_program_ind_after else trim(rx_pad_program_ind_after) end ) as rx_pad_program_ind_after,
(case when (LENGTH(trim(rx_pad_barcode ) ) ==0 ) then rx_pad_barcode else trim(rx_pad_barcode) end ) as rx_pad_barcode,
(case when (LENGTH(trim(rx_pad_barcode_after ) ) ==0 ) then rx_pad_barcode_after else trim(rx_pad_barcode_after) end ) as rx_pad_barcode_after,
(case when (LENGTH(trim(fill_qty_dispensed ) ) ==0 ) then fill_qty_dispensed else trim(fill_qty_dispensed) end ) as fill_qty_dispensed,
(case when (LENGTH(trim(fill_qty_dispensed_after ) ) ==0 ) then fill_qty_dispensed_after else trim(fill_qty_dispensed_after) end ) as fill_qty_dispensed_after,
(case when (LENGTH(trim(fill_days_supply ) ) ==0 ) then fill_days_supply else trim(fill_days_supply) end ) as fill_days_supply,
(case when (LENGTH(trim(fill_days_supply_after ) ) ==0 ) then fill_days_supply_after else trim(fill_days_supply_after) end ) as fill_days_supply_after,
(case when (LENGTH(trim(rx_added_qty ) ) ==0 ) then rx_added_qty else trim(rx_added_qty) end ) as rx_added_qty,
(case when (LENGTH(trim(rx_added_qty_after ) ) ==0 ) then rx_added_qty_after else trim(rx_added_qty_after) end ) as rx_added_qty_after,
(case when (LENGTH(trim(fill_nbr_last_disp ) ) ==0 ) then fill_nbr_last_disp else trim(fill_nbr_last_disp) end ) as fill_nbr_last_disp,
(case when (LENGTH(trim(fill_nbr_last_disp_after ) ) ==0 ) then fill_nbr_last_disp_after else trim(fill_nbr_last_disp_after) end ) as fill_nbr_last_disp_after,
(case when (LENGTH(trim(fill_entered_dttm ) ) ==0 ) then fill_entered_dttm else concat(substring(fill_entered_dttm,1,10),' ',substring(fill_entered_dttm,12,8)) end ) as fill_entered_dttm,
(case when (LENGTH(trim(fill_entered_dttm_after ) ) ==0 ) then fill_entered_dttm_after else concat(substring(fill_entered_dttm_after,1,10),' ',substring(fill_entered_dttm_after,12,8)) end ) as fill_entered_dttm_after,
(case when (LENGTH(trim(fill_part_nbr_last_disp ) ) ==0 ) then fill_part_nbr_last_disp else trim(fill_part_nbr_last_disp) end ) as fill_part_nbr_last_disp,
(case when (LENGTH(trim(fill_part_nbr_last_disp_after ) ) ==0 ) then fill_part_nbr_last_disp_after else trim(fill_part_nbr_last_disp_after) end ) as fill_part_nbr_last_disp_after,
(case when (LENGTH(trim(rx_vacc_manuf_lot_nbr ) ) ==0 ) then rx_vacc_manuf_lot_nbr else trim(rx_vacc_manuf_lot_nbr) end ) as rx_vacc_manuf_lot_nbr,
(case when (LENGTH(trim(rx_vacc_manuf_lot_nbr_after ) ) ==0 ) then rx_vacc_manuf_lot_nbr_after else trim(rx_vacc_manuf_lot_nbr_after) end ) as rx_vacc_manuf_lot_nbr_after,
(case when (LENGTH(trim(rx_vacc_exp_dttm ) ) ==0 ) then rx_vacc_exp_dttm else concat(substring(rx_vacc_exp_dttm,1,10),' ',substring(rx_vacc_exp_dttm,12,8))  end ) as rx_vacc_exp_dttm,
(case when (LENGTH(trim(rx_vacc_exp_dttm_after ) ) ==0 ) then rx_vacc_exp_dttm_after else concat(substring(rx_vacc_exp_dttm_after,1,10),' ',substring(rx_vacc_exp_dttm_after,12,8)) end ) as rx_vacc_exp_dttm_after,
(case when (LENGTH(trim(rx_vacc_area_of_admin ) ) ==0 ) then rx_vacc_area_of_admin else trim(rx_vacc_area_of_admin) end ) as rx_vacc_area_of_admin,
(case when (LENGTH(trim(rx_vacc_area_of_admin_after ) ) ==0 ) then rx_vacc_area_of_admin_after else trim(rx_vacc_area_of_admin_after) end ) as rx_vacc_area_of_admin_after,
(case when (LENGTH(trim(rx_vacc_consent_ind ) ) ==0 ) then rx_vacc_consent_ind else trim(rx_vacc_consent_ind) end ) as rx_vacc_consent_ind,
(case when (LENGTH(trim(rx_vacc_consent_ind_after ) ) ==0 ) then rx_vacc_consent_ind_after else trim(rx_vacc_consent_ind_after) end ) as rx_vacc_consent_ind_after,
(case when (LENGTH(trim(rx_vacc_pnl_ent_dttm ) ) ==0 ) then rx_vacc_pnl_ent_dttm else concat(substring(rx_vacc_pnl_ent_dttm,1,10),' ',substring(rx_vacc_pnl_ent_dttm,12,8)) end ) as rx_vacc_pnl_ent_dttm,
(case when (LENGTH(trim(rx_vacc_pnl_ent_dttm_after ) ) ==0 ) then rx_vacc_pnl_ent_dttm_after else concat(substring(rx_vacc_pnl_ent_dttm_after,1,10),' ',substring(rx_vacc_pnl_ent_dttm_after,12,8)) end ) as rx_vacc_pnl_ent_dttm_after,
(case when (LENGTH(trim(rx_vacc_pnl_status_cd ) ) ==0 ) then rx_vacc_pnl_status_cd else trim(rx_vacc_pnl_status_cd) end ) as rx_vacc_pnl_status_cd,
(case when (LENGTH(trim(rx_vacc_pnl_status_cd_after ) ) ==0 ) then rx_vacc_pnl_status_cd_after else trim(rx_vacc_pnl_status_cd_after) end ) as rx_vacc_pnl_status_cd_after,
(case when (LENGTH(trim(rx_90day_pref_ind ) ) ==0 ) then rx_90day_pref_ind else trim(rx_90day_pref_ind) end ) as rx_90day_pref_ind,
(case when (LENGTH(trim(rx_90day_pref_ind_after ) ) ==0 ) then rx_90day_pref_ind_after else trim(rx_90day_pref_ind_after) end ) as rx_90day_pref_ind_after,
(case when (LENGTH(trim(rx_90day_pref_dttm ) ) ==0 ) then rx_90day_pref_dttm else concat(substring(rx_90day_pref_dttm,1,10),' ',substring(rx_90day_pref_dttm,12,8)) end ) as rx_90day_pref_dttm,
(case when (LENGTH(trim(rx_90day_pref_dttm_after ) ) ==0 ) then rx_90day_pref_dttm_after else concat(substring(rx_90day_pref_dttm_after,1,10),' ',substring(rx_90day_pref_dttm_after,12,8)) end  ) as rx_90day_pref_dttm_after,
(case when (LENGTH(trim(rx_90day_pref_stat_cd ) ) ==0 ) then rx_90day_pref_stat_cd else trim(rx_90day_pref_stat_cd) end ) as rx_90day_pref_stat_cd,
(case when (LENGTH(trim(rx_90day_pref_stat_cd_after ) ) ==0 ) then rx_90day_pref_stat_cd_after else trim(rx_90day_pref_stat_cd_after) end ) as rx_90day_pref_stat_cd_after,
(case when (LENGTH(trim(rx_90day_pref_stat_dttm ) ) ==0 ) then rx_90day_pref_stat_dttm else concat(substring(rx_90day_pref_stat_dttm,1,10),' ',substring(rx_90day_pref_stat_dttm,12,8)) end ) as rx_90day_pref_stat_dttm,
(case when (LENGTH(trim(rx_90day_pref_stat_dttm_after ) ) ==0 ) then rx_90day_pref_stat_dttm_after else concat(substring(rx_90day_pref_stat_dttm_after,1,10),' ',substring(rx_90day_pref_stat_dttm_after,12,8)) end ) as rx_90day_pref_stat_dttm_after,
(case when (LENGTH(trim(rx_immu_ind ) ) ==0 ) then rx_immu_ind else trim(rx_immu_ind) end ) as rx_immu_ind,
(case when (LENGTH(trim(rx_immu_ind_after ) ) ==0 ) then rx_immu_ind_after else trim(rx_immu_ind_after) end ) as rx_immu_ind_after,
(case when (LENGTH(trim(diagnosis_cd_5 ) ) ==0 ) then diagnosis_cd_5 else trim(diagnosis_cd_5) end ) as diagnosis_cd_5,
(case when (LENGTH(trim(diagnosis_cd_5_after ) ) ==0 ) then diagnosis_cd_5_after else trim(diagnosis_cd_5_after) end ) as diagnosis_cd_5_after,
(case when (LENGTH(trim(diagnosis_cd_qualifier_2 ) ) ==0 ) then diagnosis_cd_qualifier_2 else trim(diagnosis_cd_qualifier_2) end ) as diagnosis_cd_qualifier_2,
(case when (LENGTH(trim(diagnosis_cd_qualifier_2_after ) ) ==0 ) then diagnosis_cd_qualifier_2_after else trim(diagnosis_cd_qualifier_2_after) end ) as diagnosis_cd_qualifier_2_after,
(case when (LENGTH(trim(diagnosis_cd_qualifier_3 ) ) ==0 ) then diagnosis_cd_qualifier_3 else trim(diagnosis_cd_qualifier_3) end ) as diagnosis_cd_qualifier_3,
(case when (LENGTH(trim(diagnosis_cd_qualifier_3_after ) ) ==0 ) then diagnosis_cd_qualifier_3_after else trim(diagnosis_cd_qualifier_3_after) end ) as diagnosis_cd_qualifier_3_after,
(case when (LENGTH(trim(diagnosis_cd_qualifier_4 ) ) ==0 ) then diagnosis_cd_qualifier_4 else trim(diagnosis_cd_qualifier_4) end ) as diagnosis_cd_qualifier_4,
(case when (LENGTH(trim(diagnosis_cd_qualifier_4_after ) ) ==0 ) then diagnosis_cd_qualifier_4_after else trim(diagnosis_cd_qualifier_4_after) end ) as diagnosis_cd_qualifier_4_after,
(case when (LENGTH(trim(diagnosis_cd_qualifier_5 ) ) ==0 ) then diagnosis_cd_qualifier_5 else trim(diagnosis_cd_qualifier_5) end ) as diagnosis_cd_qualifier_5,
(case when (LENGTH(trim(diagnosis_cd_qualifier_5_after ) ) ==0 ) then diagnosis_cd_qualifier_5_after else trim(diagnosis_cd_qualifier_5_after) end ) as diagnosis_cd_qualifier_5_after,
(case when (LENGTH(trim(pbr_dea_nbr ) ) ==0 ) then pbr_dea_nbr else trim(pbr_dea_nbr) end ) as pbr_dea_nbr,
(case when (LENGTH(trim(pbr_dea_nbr_after ) ) ==0 ) then pbr_dea_nbr_after else trim(pbr_dea_nbr_after) end ) as pbr_dea_nbr_after,
(case when (LENGTH(trim(pbr_dea_suf ) ) ==0 ) then pbr_dea_suf else trim(pbr_dea_suf) end ) as pbr_dea_suf,
(case when (LENGTH(trim(pbr_dea_suf_after ) ) ==0 ) then pbr_dea_suf_after else trim(pbr_dea_suf_after) end ) as pbr_dea_suf_after,
(case when (LENGTH(trim(buyout_rx_ind ) ) ==0 ) then buyout_rx_ind else trim(buyout_rx_ind) end ) as buyout_rx_ind,
(case when (LENGTH(trim(buyout_rx_ind_after ) ) ==0 ) then buyout_rx_ind_after else trim(buyout_rx_ind_after) end ) as buyout_rx_ind_after,
(case when (LENGTH(trim(trmt_type_cd ) ) ==0 ) then trmt_type_cd else trim(trmt_type_cd) end ) as trmt_type_cd,
(case when (LENGTH(trim(trmt_type_cd_after ) ) ==0 ) then trmt_type_cd_after else trim(trmt_type_cd_after) end ) as trmt_type_cd_after,
(case when (LENGTH(trim(fill_sold_dttm ) ) ==0 ) then fill_sold_dttm else concat(substring(fill_sold_dttm,1,10),' ',substring(fill_sold_dttm,12,8)) end ) as fill_sold_dttm,
(case when (LENGTH(trim(fill_sold_dttm_after ) ) ==0 ) then fill_sold_dttm_after else concat(substring(fill_sold_dttm_after,1,10),' ',substring(fill_sold_dttm_after,12,8)) end ) as fill_sold_dttm_after,
(case when (LENGTH(trim(erx_pat_automatch_ind ) ) ==0 ) then erx_pat_automatch_ind else trim(erx_pat_automatch_ind) end ) as erx_pat_automatch_ind,
(case when (LENGTH(trim(erx_pat_automatch_ind_after ) ) ==0 ) then erx_pat_automatch_ind_after else trim(erx_pat_automatch_ind_after) end ) as erx_pat_automatch_ind_after,
(case when (LENGTH(trim(rx_90day_switch_ind ) ) ==0 ) then rx_90day_switch_ind else trim(rx_90day_switch_ind) end ) as rx_90day_switch_ind,
(case when (LENGTH(trim(rx_90day_switch_ind_after ) ) ==0 ) then rx_90day_switch_ind_after else trim(rx_90day_switch_ind_after) end ) as rx_90day_switch_ind_after,
(case when (LENGTH(trim(src_partition_nbr))==0) then src_partition_nbr else trim(src_partition_nbr) end) as src_partition_nbr,
(case when (LENGTH(trim(src_partition_nbr_after))==0) then src_partition_nbr_after else trim(src_partition_nbr_after) end) as src_partition_nbr_after,
(case when (LENGTH(trim(fill_adv_rfl_opt_ind ) ) ==0 ) then fill_adv_rfl_opt_ind else trim(fill_adv_rfl_opt_ind) end ) as fill_adv_rfl_opt_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_ind_after ) ) ==0 ) then fill_adv_rfl_opt_ind_after else trim(fill_adv_rfl_opt_ind_after) end ) as fill_adv_rfl_opt_ind_after,
(case when (LENGTH(trim(fill_adv_rfl_opt_dttm ) ) ==0 ) then fill_adv_rfl_opt_dttm else concat(substring(fill_adv_rfl_opt_dttm,1,10),' ',substring(fill_adv_rfl_opt_dttm,12,8)) end ) as fill_adv_rfl_opt_dttm,
(case when (LENGTH(trim(fill_adv_rfl_opt_dttm_after ) ) ==0 ) then fill_adv_rfl_opt_dttm_after else concat(substring(fill_adv_rfl_opt_dttm_after,1,10),' ',substring(fill_adv_rfl_opt_dttm_after,12,8)) end ) as fill_adv_rfl_opt_dttm_after,
(case when (LENGTH(trim(rx_vacc_info_race ) ) ==0 ) then rx_vacc_info_race else trim(rx_vacc_info_race) end ) as rx_vacc_info_race,
(case when (LENGTH(trim(rx_vacc_info_race_after ) ) ==0 ) then rx_vacc_info_race_after else trim(rx_vacc_info_race_after) end ) as rx_vacc_info_race_after,
(case when (LENGTH(trim(rx_vacc_info_ethnicity ) ) ==0 ) then rx_vacc_info_ethnicity else trim(rx_vacc_info_ethnicity) end ) as rx_vacc_info_ethnicity,
(case when (LENGTH(trim(rx_vacc_info_ethnicity_after ) ) ==0 ) then rx_vacc_info_ethnicity_after else trim(rx_vacc_info_ethnicity_after) end ) as rx_vacc_info_ethnicity_after,
(case when (LENGTH(trim(rx_vacc_info_comorbidity ) ) ==0 ) then rx_vacc_info_comorbidity else trim(rx_vacc_info_comorbidity) end ) as rx_vacc_info_comorbidity,
(case when (LENGTH(trim(rx_vacc_info_comorbidity_after ) ) ==0 ) then rx_vacc_info_comorbidity_after else trim(rx_vacc_info_comorbidity_after) end ) as rx_vacc_info_comorbidity_after
from dedup_group
"""

# COMMAND ----------

#Apply data cleansing such as trim to the source data (just pass across the cdc_* columns)
nr_spacetrim = spark.sql(nr_spacetrim_sql)
#display(nr_spacetrim)

nr_update_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'SQL COMPUPDATE')
#display(nr_update_check)

nr_insert_check = nr_spacetrim.filter(nr_spacetrim.cdc_operation_type_cd  == 'INSERT')
#display(nr_insert_check)
nr_insert_check.createOrReplaceTempView("nr_insert_check")

nr_rejected = nr_spacetrim.filter( (nr_spacetrim.cdc_operation_type_cd  != 'SQL COMPUPDATE' ) & ( nr_spacetrim.cdc_operation_type_cd  != 'INSERT' ) )
#display(nr_rejected)
#print("Rejected Count : ", nr_rejected.count())
             
if nr_rejected.count()>0:
  nr_rejected.write.mode("overwrite").parquet(REJ_FILE_NOISE_RMV) 
  
nr_update_check.createOrReplaceTempView("nr_update_check")

query1 = "select * from nr_update_check where " + pUpdateReform
gg_tbf0_rejected = spark.sql(query1)

gg_tbf0_update =  nr_update_check.subtract(gg_tbf0_rejected)

if gg_tbf0_rejected.count()>0:
  #print(gg_tbf0_rejected.count())
  gg_tbf0_rejected.write.mode("overwrite").parquet(REJ_FILE_UPD_NULL) 

#print(gg_tbf0_rejected.count())  
#display(gg_tbf0_update)
gg_tbf0_update.createOrReplaceTempView("gg_tbf0_update")

# COMMAND ----------

pTgtUpdAftXfr = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm_after )) ==0) then  cdc_txn_commit_dttm_after else concat(substring(cdc_txn_commit_dttm_after,1,10),' ',substring(cdc_txn_commit_dttm_after,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr_after )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr_after) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr_after )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr_after) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd_after )) ==0) then  cdc_operation_type_cd_after  else trim( cdc_operation_type_cd_after ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim(src_partition_nbr_after )) ==0) then src_partition_nbr_after else trim(src_partition_nbr_after ) end) as src_partition_nbr,
(case when (LENGTH(trim(store_nbr_after )) ==0) then store_nbr_after else trim(store_nbr_after ) end) as store_nbr,
(case when (LENGTH(trim(rx_nbr_after )) ==0) then rx_nbr_after else trim(rx_nbr_after ) end) as rx_nbr,
(case when (LENGTH(trim(pat_id_after )) ==0) then pat_id_after else trim(pat_id_after ) end) as pat_id,
(case when (LENGTH(trim(drug_id_after )) ==0) then drug_id_after else trim(drug_id_after ) end) as drug_id,
(case when (LENGTH(trim(drug_class_after )) ==0) then drug_class_after else trim(drug_class_after ) end) as drug_class,
(case when (LENGTH(trim(drug_non_system_cd_after )) ==0) then drug_non_system_cd_after else trim(drug_non_system_cd_after ) end) as drug_non_system_cd,
(case when (LENGTH(trim(drug_sub_cd_after )) ==0) then drug_sub_cd_after else trim(drug_sub_cd_after ) end) as drug_sub_cd,
(case when (LENGTH(trim(pbr_id_after )) ==0) then pbr_id_after else trim(pbr_id_after ) end) as pbr_id,
(case when (LENGTH(trim(pbr_loc_id_after )) ==0) then pbr_loc_id_after else trim(pbr_loc_id_after ) end) as pbr_loc_id,
(case when (LENGTH(trim(pay_cd_after )) ==0) then pay_cd_after else trim(pay_cd_after ) end) as pay_cd,
(case when (LENGTH(trim(rx_comment_after )) ==0) then rx_comment_after else trim(rx_comment_after ) end) as rx_comment,
(case when (LENGTH(trim(rx_daw_ind_after )) ==0) then rx_daw_ind_after else trim(rx_daw_ind_after ) end) as rx_daw_ind,
(case when (LENGTH(trim(rx_written_dttm_after )) ==0) then rx_written_dttm_after else trim(rx_written_dttm_after ) end) as rx_written_dttm,
(case when (LENGTH(trim(rx_original_fill_dttm_after )) ==0) then rx_original_fill_dttm_after else trim(rx_original_fill_dttm_after ) end) as rx_original_fill_dttm,
(case when (LENGTH(trim(rx_status_cd_after )) ==0) then rx_status_cd_after else trim(rx_status_cd_after ) end) as rx_status_cd,
(case when (LENGTH(trim(rx_sig_after )) ==0) then rx_sig_after else trim(rx_sig_after ) end) as rx_sig,
(case when (LENGTH(trim(rx_original_qty_after )) ==0) then rx_original_qty_after else trim(rx_original_qty_after ) end) as rx_original_qty,
(case when (LENGTH(trim(rx_total_dispensed_qty_after )) ==0) then rx_total_dispensed_qty_after else trim(rx_total_dispensed_qty_after ) end) as rx_total_dispensed_qty,
(case when (LENGTH(trim(rx_refills_by_dttm_after )) ==0) then rx_refills_by_dttm_after else trim(rx_refills_by_dttm_after ) end) as rx_refills_by_dttm,
(case when (LENGTH(trim(fill_nbr_prescribed_after )) ==0) then fill_nbr_prescribed_after else trim(fill_nbr_prescribed_after ) end) as fill_nbr_prescribed,
(case when (LENGTH(trim(fill_nbr_dispensed_after )) ==0) then fill_nbr_dispensed_after else trim(fill_nbr_dispensed_after ) end) as fill_nbr_dispensed,
(case when (LENGTH(trim(fill_nbr_added_after )) ==0) then fill_nbr_added_after else trim(fill_nbr_added_after ) end) as fill_nbr_added,
(case when (LENGTH(trim(fill_unlimited_ind_after )) ==0) then fill_unlimited_ind_after else trim(fill_unlimited_ind_after ) end) as fill_unlimited_ind,
(case when (LENGTH(trim(fill_auto_ind_after )) ==0) then fill_auto_ind_after else trim(fill_auto_ind_after ) end) as fill_auto_ind,
(case when (LENGTH(trim(ordered_drug_id_after )) ==0) then ordered_drug_id_after else trim(ordered_drug_id_after ) end) as ordered_drug_id,
(case when (LENGTH(trim(rx_original_qty_disp_after )) ==0) then rx_original_qty_disp_after else trim(rx_original_qty_disp_after ) end) as rx_original_qty_disp,
(case when (LENGTH(trim(rx_original_days_supply_after )) ==0) then rx_original_days_supply_after else trim(rx_original_days_supply_after ) end) as rx_original_days_supply,
(case when (LENGTH(trim(create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after ) end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after )) ==0) then create_dttm_after else trim(create_dttm_after ) end) as create_dttm,
(case when (LENGTH(trim(update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after ) end) as update_user_id,
(case when (LENGTH(trim(update_dttm_after )) ==0) then update_dttm_after else trim(update_dttm_after ) end) as update_dttm,
(case when (LENGTH(trim(generic_subs_pref_after )) ==0) then generic_subs_pref_after else trim(generic_subs_pref_after ) end) as generic_subs_pref,
(case when (LENGTH(trim(diagnosis_cd_after )) ==0) then diagnosis_cd_after else trim(diagnosis_cd_after ) end) as diagnosis_cd,
(case when (LENGTH(trim(image_id_after )) ==0) then image_id_after else trim(image_id_after ) end) as image_id,
(case when (LENGTH(trim(routing_store_nbr_after )) ==0) then routing_store_nbr_after else trim(routing_store_nbr_after ) end) as routing_store_nbr,
(case when (LENGTH(trim(scanned_user_id_after )) ==0) then scanned_user_id_after else trim(scanned_user_id_after ) end) as scanned_user_id,
(case when (LENGTH(trim(scanned_dttm_after )) ==0) then scanned_dttm_after else trim(scanned_dttm_after ) end) as scanned_dttm,
(case when (LENGTH(trim(scanned_store_nbr_after )) ==0) then scanned_store_nbr_after else trim(scanned_store_nbr_after ) end) as scanned_store_nbr,
(case when (LENGTH(trim(diagnosis_cd_qualifier_after )) ==0) then diagnosis_cd_qualifier_after else trim(diagnosis_cd_qualifier_after ) end) as diagnosis_cd_qualifier,
(case when (LENGTH(trim(tip_rx_ind_after )) ==0) then tip_rx_ind_after else trim(tip_rx_ind_after ) end) as tip_rx_ind,
(case when (LENGTH(trim(pbr_order_nbr_after )) ==0) then pbr_order_nbr_after else trim(pbr_order_nbr_after ) end) as pbr_order_nbr,
(case when (LENGTH(trim(origin_cd_after )) ==0) then origin_cd_after else trim(origin_cd_after ) end) as origin_cd,
(case when (LENGTH(trim(diagnosis_cd_2_after )) ==0) then diagnosis_cd_2_after else trim(diagnosis_cd_2_after ) end) as diagnosis_cd_2,
(case when (LENGTH(trim(diagnosis_cd_3_after )) ==0) then diagnosis_cd_3_after else trim(diagnosis_cd_3_after ) end) as diagnosis_cd_3,
(case when (LENGTH(trim(diagnosis_cd_4_after )) ==0) then diagnosis_cd_4_after else trim(diagnosis_cd_4_after ) end) as diagnosis_cd_4,
(case when (LENGTH(trim(rx_pad_program_ind_after )) ==0) then rx_pad_program_ind_after else trim(rx_pad_program_ind_after ) end) as rx_pad_program_ind,
(case when (LENGTH(trim(rx_pad_barcode_after )) ==0) then rx_pad_barcode_after else trim(rx_pad_barcode_after ) end) as rx_pad_barcode,
(case when (LENGTH(trim(fill_qty_dispensed_after )) ==0) then fill_qty_dispensed_after else trim(fill_qty_dispensed_after ) end) as fill_qty_dispensed,
(case when (LENGTH(trim(fill_days_supply_after )) ==0) then fill_days_supply_after else trim(fill_days_supply_after ) end) as fill_days_supply,
(case when (LENGTH(trim(rx_added_qty_after )) ==0) then rx_added_qty_after else trim(rx_added_qty_after ) end) as rx_added_qty,
(case when (LENGTH(trim(fill_nbr_last_disp_after )) ==0) then fill_nbr_last_disp_after else trim(fill_nbr_last_disp_after ) end) as fill_nbr_last_disp,
(case when (LENGTH(trim(fill_entered_dttm_after )) ==0) then fill_entered_dttm_after else trim(fill_entered_dttm_after ) end) as fill_entered_dttm,
(case when (LENGTH(trim(fill_part_nbr_last_disp_after )) ==0) then fill_part_nbr_last_disp_after else trim(fill_part_nbr_last_disp_after ) end) as fill_part_nbr_last_disp,
(case when (LENGTH(trim(rx_vacc_manuf_lot_nbr_after )) ==0) then rx_vacc_manuf_lot_nbr_after else trim(rx_vacc_manuf_lot_nbr_after ) end) as rx_vacc_manuf_lot_nbr,
(case when (LENGTH(trim(rx_vacc_exp_dttm_after )) ==0) then rx_vacc_exp_dttm_after else trim(rx_vacc_exp_dttm_after ) end) as rx_vacc_exp_dttm,
(case when (LENGTH(trim(rx_vacc_area_of_admin_after )) ==0) then rx_vacc_area_of_admin_after else trim(rx_vacc_area_of_admin_after ) end) as rx_vacc_area_of_admin,
(case when (LENGTH(trim(rx_vacc_consent_ind_after )) ==0) then rx_vacc_consent_ind_after else trim(rx_vacc_consent_ind_after ) end) as rx_vacc_consent_ind,
(case when (LENGTH(trim(rx_vacc_pnl_ent_dttm_after )) ==0) then rx_vacc_pnl_ent_dttm_after else trim(rx_vacc_pnl_ent_dttm_after ) end) as rx_vacc_pnl_ent_dttm,
(case when (LENGTH(trim(rx_vacc_pnl_status_cd_after )) ==0) then rx_vacc_pnl_status_cd_after else trim(rx_vacc_pnl_status_cd_after ) end) as rx_vacc_pnl_status_cd,
(case when (LENGTH(trim(rx_90day_pref_ind_after )) ==0) then rx_90day_pref_ind_after else trim(rx_90day_pref_ind_after ) end) as rx_90day_pref_ind,
(case when (LENGTH(trim(rx_90day_pref_dttm_after )) ==0) then rx_90day_pref_dttm_after else trim(rx_90day_pref_dttm_after ) end) as rx_90day_pref_dttm,
(case when (LENGTH(trim(rx_90day_pref_stat_cd_after )) ==0) then rx_90day_pref_stat_cd_after else trim(rx_90day_pref_stat_cd_after ) end) as rx_90day_pref_stat_cd,
(case when (LENGTH(trim(rx_90day_pref_stat_dttm_after )) ==0) then rx_90day_pref_stat_dttm_after else trim(rx_90day_pref_stat_dttm_after ) end) as rx_90day_pref_stat_dttm,
(case when (LENGTH(trim(rx_immu_ind_after )) ==0) then rx_immu_ind_after else trim(rx_immu_ind_after ) end) as rx_immu_ind,
(case when (LENGTH(trim(diagnosis_cd_5_after )) ==0) then diagnosis_cd_5_after else trim(diagnosis_cd_5_after ) end) as diagnosis_cd_5,
(case when (LENGTH(trim(diagnosis_cd_qualifier_2_after )) ==0) then diagnosis_cd_qualifier_2_after else trim(diagnosis_cd_qualifier_2_after ) end) as diagnosis_cd_qualifier_2,
(case when (LENGTH(trim(diagnosis_cd_qualifier_3_after )) ==0) then diagnosis_cd_qualifier_3_after else trim(diagnosis_cd_qualifier_3_after ) end) as diagnosis_cd_qualifier_3,
(case when (LENGTH(trim(diagnosis_cd_qualifier_4_after )) ==0) then diagnosis_cd_qualifier_4_after else trim(diagnosis_cd_qualifier_4_after ) end) as diagnosis_cd_qualifier_4,
(case when (LENGTH(trim(diagnosis_cd_qualifier_5_after )) ==0) then diagnosis_cd_qualifier_5_after else trim(diagnosis_cd_qualifier_5_after ) end) as diagnosis_cd_qualifier_5,
(case when (LENGTH(trim(pbr_dea_nbr_after )) ==0) then pbr_dea_nbr_after else trim(pbr_dea_nbr_after ) end) as pbr_dea_nbr,
(case when (LENGTH(trim(pbr_dea_suf_after )) ==0) then pbr_dea_suf_after else trim(pbr_dea_suf_after ) end) as pbr_dea_suf,
(case when (LENGTH(trim(buyout_rx_ind_after )) ==0) then buyout_rx_ind_after else trim(buyout_rx_ind_after ) end) as buyout_rx_ind,
(case when (LENGTH(trim(trmt_type_cd_after )) ==0) then trmt_type_cd_after else trim(trmt_type_cd_after ) end) as trmt_type_cd,
(case when (LENGTH(trim(fill_sold_dttm_after )) ==0) then fill_sold_dttm_after else trim(fill_sold_dttm_after ) end) as fill_sold_dttm,
(case when (LENGTH(trim(erx_pat_automatch_ind_after )) ==0) then erx_pat_automatch_ind_after else trim(erx_pat_automatch_ind_after ) end) as erx_pat_automatch_ind,
(case when (LENGTH(trim(rx_90day_switch_ind_after )) ==0) then rx_90day_switch_ind_after else trim(rx_90day_switch_ind_after ) end) as rx_90day_switch_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_ind_after )) ==0) then fill_adv_rfl_opt_ind_after else trim(fill_adv_rfl_opt_ind_after ) end) as fill_adv_rfl_opt_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_dttm_after )) ==0) then fill_adv_rfl_opt_dttm_after else trim(fill_adv_rfl_opt_dttm_after ) end) as fill_adv_rfl_opt_dttm,
(case when (LENGTH(trim(rx_vacc_info_race_after )) ==0) then rx_vacc_info_race_after else trim(rx_vacc_info_race_after ) end) as rx_vacc_info_race,
(case when (LENGTH(trim(rx_vacc_info_ethnicity_after )) ==0) then rx_vacc_info_ethnicity_after else trim(rx_vacc_info_ethnicity_after ) end) as rx_vacc_info_ethnicity,
(case when (LENGTH(trim(rx_vacc_info_comorbidity_after )) ==0) then rx_vacc_info_comorbidity_after else trim(rx_vacc_info_comorbidity_after ) end) as rx_vacc_info_comorbidity,
'gg_tbf0_rx' as table_name
from gg_tbf0_update"""

pTgtUpdBfrXfr = """select 
(case when (LENGTH(trim(cdc_txn_commit_dttm )) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then cdc_operation_type_cd else trim(cdc_operation_type_cd) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd )) ==0) then cdc_before_after_cd else trim(cdc_before_after_cd) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd )) ==0) then cdc_txn_position_cd else trim(cdc_txn_position_cd) end) as cdc_txn_position_cd,
edw_batch_id as edw_batch_id,
(case when (LENGTH(trim(src_partition_nbr )) ==0) then src_partition_nbr else trim(src_partition_nbr ) end) as src_partition_nbr,
(case when (LENGTH(trim(store_nbr )) ==0) then store_nbr else trim(store_nbr ) end) as store_nbr,
(case when (LENGTH(trim(rx_nbr )) ==0) then rx_nbr else trim(rx_nbr ) end) as rx_nbr,
(case when (LENGTH(trim(pat_id )) ==0) then pat_id else trim(pat_id ) end) as pat_id,
(case when (LENGTH(trim(drug_id )) ==0) then drug_id else trim(drug_id ) end) as drug_id,
(case when (LENGTH(trim(drug_class )) ==0) then drug_class else trim(drug_class ) end) as drug_class,
(case when (LENGTH(trim(drug_non_system_cd )) ==0) then drug_non_system_cd else trim(drug_non_system_cd ) end) as drug_non_system_cd,
(case when (LENGTH(trim(drug_sub_cd )) ==0) then drug_sub_cd else trim(drug_sub_cd ) end) as drug_sub_cd,
(case when (LENGTH(trim(pbr_id )) ==0) then pbr_id else trim(pbr_id ) end) as pbr_id,
(case when (LENGTH(trim(pbr_loc_id )) ==0) then pbr_loc_id else trim(pbr_loc_id ) end) as pbr_loc_id,
(case when (LENGTH(trim(pay_cd )) ==0) then pay_cd else trim(pay_cd ) end) as pay_cd,
(case when (LENGTH(trim(rx_comment )) ==0) then rx_comment else trim(rx_comment ) end) as rx_comment,
(case when (LENGTH(trim(rx_daw_ind )) ==0) then rx_daw_ind else trim(rx_daw_ind ) end) as rx_daw_ind,
(case when (LENGTH(trim(rx_written_dttm )) ==0) then rx_written_dttm else trim(rx_written_dttm ) end) as rx_written_dttm,
(case when (LENGTH(trim(rx_original_fill_dttm )) ==0) then rx_original_fill_dttm else trim(rx_original_fill_dttm ) end) as rx_original_fill_dttm,
(case when (LENGTH(trim(rx_status_cd )) ==0) then rx_status_cd else trim(rx_status_cd ) end) as rx_status_cd,
(case when (LENGTH(trim(rx_sig )) ==0) then rx_sig else trim(rx_sig ) end) as rx_sig,
(case when (LENGTH(trim(rx_original_qty )) ==0) then rx_original_qty else trim(rx_original_qty ) end) as rx_original_qty,
(case when (LENGTH(trim(rx_total_dispensed_qty )) ==0) then rx_total_dispensed_qty else trim(rx_total_dispensed_qty ) end) as rx_total_dispensed_qty,
(case when (LENGTH(trim(rx_refills_by_dttm )) ==0) then rx_refills_by_dttm else trim(rx_refills_by_dttm ) end) as rx_refills_by_dttm,
(case when (LENGTH(trim(fill_nbr_prescribed )) ==0) then fill_nbr_prescribed else trim(fill_nbr_prescribed ) end) as fill_nbr_prescribed,
(case when (LENGTH(trim(fill_nbr_dispensed )) ==0) then fill_nbr_dispensed else trim(fill_nbr_dispensed ) end) as fill_nbr_dispensed,
(case when (LENGTH(trim(fill_nbr_added )) ==0) then fill_nbr_added else trim(fill_nbr_added ) end) as fill_nbr_added,
(case when (LENGTH(trim(fill_unlimited_ind )) ==0) then fill_unlimited_ind else trim(fill_unlimited_ind ) end) as fill_unlimited_ind,
(case when (LENGTH(trim(fill_auto_ind )) ==0) then fill_auto_ind else trim(fill_auto_ind ) end) as fill_auto_ind,
(case when (LENGTH(trim(ordered_drug_id )) ==0) then ordered_drug_id else trim(ordered_drug_id ) end) as ordered_drug_id,
(case when (LENGTH(trim(rx_original_qty_disp )) ==0) then rx_original_qty_disp else trim(rx_original_qty_disp ) end) as rx_original_qty_disp,
(case when (LENGTH(trim(rx_original_days_supply )) ==0) then rx_original_days_supply else trim(rx_original_days_supply ) end) as rx_original_days_supply,
(case when (LENGTH(trim(create_user_id )) ==0) then create_user_id else trim(create_user_id ) end) as create_user_id,
(case when (LENGTH(trim(create_dttm )) ==0) then create_dttm else trim(create_dttm ) end) as create_dttm,
(case when (LENGTH(trim(update_user_id )) ==0) then update_user_id else trim(update_user_id ) end) as update_user_id,
(case when (LENGTH(trim(update_dttm )) ==0) then update_dttm else trim(update_dttm ) end) as update_dttm,
(case when (LENGTH(trim(generic_subs_pref )) ==0) then generic_subs_pref else trim(generic_subs_pref ) end) as generic_subs_pref,
(case when (LENGTH(trim(diagnosis_cd )) ==0) then diagnosis_cd else trim(diagnosis_cd ) end) as diagnosis_cd,
(case when (LENGTH(trim(image_id )) ==0) then image_id else trim(image_id ) end) as image_id,
(case when (LENGTH(trim(routing_store_nbr )) ==0) then routing_store_nbr else trim(routing_store_nbr ) end) as routing_store_nbr,
(case when (LENGTH(trim(scanned_user_id )) ==0) then scanned_user_id else trim(scanned_user_id ) end) as scanned_user_id,
(case when (LENGTH(trim(scanned_dttm )) ==0) then scanned_dttm else trim(scanned_dttm ) end) as scanned_dttm,
(case when (LENGTH(trim(scanned_store_nbr )) ==0) then scanned_store_nbr else trim(scanned_store_nbr ) end) as scanned_store_nbr,
(case when (LENGTH(trim(diagnosis_cd_qualifier )) ==0) then diagnosis_cd_qualifier else trim(diagnosis_cd_qualifier ) end) as diagnosis_cd_qualifier,
(case when (LENGTH(trim(tip_rx_ind )) ==0) then tip_rx_ind else trim(tip_rx_ind ) end) as tip_rx_ind,
(case when (LENGTH(trim(pbr_order_nbr )) ==0) then pbr_order_nbr else trim(pbr_order_nbr ) end) as pbr_order_nbr,
(case when (LENGTH(trim(origin_cd )) ==0) then origin_cd else trim(origin_cd ) end) as origin_cd,
(case when (LENGTH(trim(diagnosis_cd_2 )) ==0) then diagnosis_cd_2 else trim(diagnosis_cd_2 ) end) as diagnosis_cd_2,
(case when (LENGTH(trim(diagnosis_cd_3 )) ==0) then diagnosis_cd_3 else trim(diagnosis_cd_3 ) end) as diagnosis_cd_3,
(case when (LENGTH(trim(diagnosis_cd_4 )) ==0) then diagnosis_cd_4 else trim(diagnosis_cd_4 ) end) as diagnosis_cd_4,
(case when (LENGTH(trim(rx_pad_program_ind )) ==0) then rx_pad_program_ind else trim(rx_pad_program_ind ) end) as rx_pad_program_ind,
(case when (LENGTH(trim(rx_pad_barcode )) ==0) then rx_pad_barcode else trim(rx_pad_barcode ) end) as rx_pad_barcode,
(case when (LENGTH(trim(fill_qty_dispensed )) ==0) then fill_qty_dispensed else trim(fill_qty_dispensed ) end) as fill_qty_dispensed,
(case when (LENGTH(trim(fill_days_supply )) ==0) then fill_days_supply else trim(fill_days_supply ) end) as fill_days_supply,
(case when (LENGTH(trim(rx_added_qty )) ==0) then rx_added_qty else trim(rx_added_qty ) end) as rx_added_qty,
(case when (LENGTH(trim(fill_nbr_last_disp )) ==0) then fill_nbr_last_disp else trim(fill_nbr_last_disp ) end) as fill_nbr_last_disp,
(case when (LENGTH(trim(fill_entered_dttm )) ==0) then fill_entered_dttm else trim(fill_entered_dttm ) end) as fill_entered_dttm,
(case when (LENGTH(trim(fill_part_nbr_last_disp )) ==0) then fill_part_nbr_last_disp else trim(fill_part_nbr_last_disp ) end) as fill_part_nbr_last_disp,
(case when (LENGTH(trim(rx_vacc_manuf_lot_nbr )) ==0) then rx_vacc_manuf_lot_nbr else trim(rx_vacc_manuf_lot_nbr ) end) as rx_vacc_manuf_lot_nbr,
(case when (LENGTH(trim(rx_vacc_exp_dttm )) ==0) then rx_vacc_exp_dttm else trim(rx_vacc_exp_dttm ) end) as rx_vacc_exp_dttm,
(case when (LENGTH(trim(rx_vacc_area_of_admin )) ==0) then rx_vacc_area_of_admin else trim(rx_vacc_area_of_admin ) end) as rx_vacc_area_of_admin,
(case when (LENGTH(trim(rx_vacc_consent_ind )) ==0) then rx_vacc_consent_ind else trim(rx_vacc_consent_ind ) end) as rx_vacc_consent_ind,
(case when (LENGTH(trim(rx_vacc_pnl_ent_dttm )) ==0) then rx_vacc_pnl_ent_dttm else trim(rx_vacc_pnl_ent_dttm ) end) as rx_vacc_pnl_ent_dttm,
(case when (LENGTH(trim(rx_vacc_pnl_status_cd )) ==0) then rx_vacc_pnl_status_cd else trim(rx_vacc_pnl_status_cd ) end) as rx_vacc_pnl_status_cd,
(case when (LENGTH(trim(rx_90day_pref_ind )) ==0) then rx_90day_pref_ind else trim(rx_90day_pref_ind ) end) as rx_90day_pref_ind,
(case when (LENGTH(trim(rx_90day_pref_dttm )) ==0) then rx_90day_pref_dttm else trim(rx_90day_pref_dttm ) end) as rx_90day_pref_dttm,
(case when (LENGTH(trim(rx_90day_pref_stat_cd )) ==0) then rx_90day_pref_stat_cd else trim(rx_90day_pref_stat_cd ) end) as rx_90day_pref_stat_cd,
(case when (LENGTH(trim(rx_90day_pref_stat_dttm )) ==0) then rx_90day_pref_stat_dttm else trim(rx_90day_pref_stat_dttm ) end) as rx_90day_pref_stat_dttm,
(case when (LENGTH(trim(rx_immu_ind )) ==0) then rx_immu_ind else trim(rx_immu_ind ) end) as rx_immu_ind,
(case when (LENGTH(trim(diagnosis_cd_5 )) ==0) then diagnosis_cd_5 else trim(diagnosis_cd_5 ) end) as diagnosis_cd_5,
(case when (LENGTH(trim(diagnosis_cd_qualifier_2 )) ==0) then diagnosis_cd_qualifier_2 else trim(diagnosis_cd_qualifier_2 ) end) as diagnosis_cd_qualifier_2,
(case when (LENGTH(trim(diagnosis_cd_qualifier_3 )) ==0) then diagnosis_cd_qualifier_3 else trim(diagnosis_cd_qualifier_3 ) end) as diagnosis_cd_qualifier_3,
(case when (LENGTH(trim(diagnosis_cd_qualifier_4 )) ==0) then diagnosis_cd_qualifier_4 else trim(diagnosis_cd_qualifier_4 ) end) as diagnosis_cd_qualifier_4,
(case when (LENGTH(trim(diagnosis_cd_qualifier_5 )) ==0) then diagnosis_cd_qualifier_5 else trim(diagnosis_cd_qualifier_5 ) end) as diagnosis_cd_qualifier_5,
(case when (LENGTH(trim(pbr_dea_nbr )) ==0) then pbr_dea_nbr else trim(pbr_dea_nbr ) end) as pbr_dea_nbr,
(case when (LENGTH(trim(pbr_dea_suf )) ==0) then pbr_dea_suf else trim(pbr_dea_suf ) end) as pbr_dea_suf,
(case when (LENGTH(trim(buyout_rx_ind )) ==0) then buyout_rx_ind else trim(buyout_rx_ind ) end) as buyout_rx_ind,
(case when (LENGTH(trim(trmt_type_cd )) ==0) then trmt_type_cd else trim(trmt_type_cd ) end) as trmt_type_cd,
(case when (LENGTH(trim(fill_sold_dttm )) ==0) then fill_sold_dttm else trim(fill_sold_dttm ) end) as fill_sold_dttm,
(case when (LENGTH(trim(erx_pat_automatch_ind )) ==0) then erx_pat_automatch_ind else trim(erx_pat_automatch_ind ) end) as erx_pat_automatch_ind,
(case when (LENGTH(trim(rx_90day_switch_ind )) ==0) then rx_90day_switch_ind else trim(rx_90day_switch_ind ) end) as rx_90day_switch_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_ind )) ==0) then fill_adv_rfl_opt_ind else trim(fill_adv_rfl_opt_ind ) end) as fill_adv_rfl_opt_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_dttm )) ==0) then fill_adv_rfl_opt_dttm else trim(fill_adv_rfl_opt_dttm ) end) as fill_adv_rfl_opt_dttm,
(case when (LENGTH(trim(rx_vacc_info_race )) ==0) then rx_vacc_info_race else trim(rx_vacc_info_race ) end) as rx_vacc_info_race,
(case when (LENGTH(trim(rx_vacc_info_ethnicity )) ==0) then rx_vacc_info_ethnicity else trim(rx_vacc_info_ethnicity ) end) as rx_vacc_info_ethnicity,
(case when (LENGTH(trim(rx_vacc_info_comorbidity )) ==0) then rx_vacc_info_comorbidity else trim(rx_vacc_info_comorbidity ) end) as rx_vacc_info_comorbidity,
'gg_tbf0_rx' as table_name
from gg_tbf0_update """

pTgtInsBfrAftXfr="""select 
(case when (LENGTH(trim(cdc_txn_commit_dttm)) ==0) then  cdc_txn_commit_dttm else concat(substring(cdc_txn_commit_dttm,1,10),' ',substring(cdc_txn_commit_dttm,12,8))  end) as cdc_txn_commit_dttm,
(case when (LENGTH(trim( cdc_seq_nbr )) ==0) then cdc_seq_nbr_after else trim(cdc_seq_nbr) end) as cdc_seq_nbr,
(case when (LENGTH(trim( cdc_rba_nbr )) ==0) then cdc_rba_nbr_after else trim(cdc_rba_nbr) end) as cdc_rba_nbr,
(case when (LENGTH(trim( cdc_operation_type_cd )) ==0) then  cdc_operation_type_cd  else trim( cdc_operation_type_cd ) end) as cdc_operation_type_cd,
(case when (LENGTH(trim( cdc_before_after_cd_after )) ==0) then cdc_before_after_cd_after else trim(cdc_before_after_cd_after) end) as cdc_before_after_cd,
(case when (LENGTH(trim( cdc_txn_position_cd_after )) ==0) then cdc_txn_position_cd_after else trim(cdc_txn_position_cd_after) end) as cdc_txn_position_cd,
edw_batch_id_after as edw_batch_id,
(case when (LENGTH(trim(src_partition_nbr_after )) ==0) then src_partition_nbr_after else trim(src_partition_nbr_after ) end) as src_partition_nbr,
(case when (LENGTH(trim(store_nbr_after )) ==0) then store_nbr_after else trim(store_nbr_after ) end) as store_nbr,
(case when (LENGTH(trim(rx_nbr_after )) ==0) then rx_nbr_after else trim(rx_nbr_after ) end) as rx_nbr,
(case when (LENGTH(trim(pat_id_after )) ==0) then pat_id_after else trim(pat_id_after ) end) as pat_id,
(case when (LENGTH(trim(drug_id_after )) ==0) then drug_id_after else trim(drug_id_after ) end) as drug_id,
(case when (LENGTH(trim(drug_class_after )) ==0) then drug_class_after else trim(drug_class_after ) end) as drug_class,
(case when (LENGTH(trim(drug_non_system_cd_after )) ==0) then drug_non_system_cd_after else trim(drug_non_system_cd_after ) end) as drug_non_system_cd,
(case when (LENGTH(trim(drug_sub_cd_after )) ==0) then drug_sub_cd_after else trim(drug_sub_cd_after ) end) as drug_sub_cd,
(case when (LENGTH(trim(pbr_id_after )) ==0) then pbr_id_after else trim(pbr_id_after ) end) as pbr_id,
(case when (LENGTH(trim(pbr_loc_id_after )) ==0) then pbr_loc_id_after else trim(pbr_loc_id_after ) end) as pbr_loc_id,
(case when (LENGTH(trim(pay_cd_after )) ==0) then pay_cd_after else trim(pay_cd_after ) end) as pay_cd,
(case when (LENGTH(trim(rx_comment_after )) ==0) then rx_comment_after else trim(rx_comment_after ) end) as rx_comment,
(case when (LENGTH(trim(rx_daw_ind_after )) ==0) then rx_daw_ind_after else trim(rx_daw_ind_after ) end) as rx_daw_ind,
(case when (LENGTH(trim(rx_written_dttm_after )) ==0) then rx_written_dttm_after else trim(rx_written_dttm_after ) end) as rx_written_dttm,
(case when (LENGTH(trim(rx_original_fill_dttm_after )) ==0) then rx_original_fill_dttm_after else trim(rx_original_fill_dttm_after ) end) as rx_original_fill_dttm,
(case when (LENGTH(trim(rx_status_cd_after )) ==0) then rx_status_cd_after else trim(rx_status_cd_after ) end) as rx_status_cd,
(case when (LENGTH(trim(rx_sig_after )) ==0) then rx_sig_after else trim(rx_sig_after ) end) as rx_sig,
(case when (LENGTH(trim(rx_original_qty_after )) ==0) then rx_original_qty_after else trim(rx_original_qty_after ) end) as rx_original_qty,
(case when (LENGTH(trim(rx_total_dispensed_qty_after )) ==0) then rx_total_dispensed_qty_after else trim(rx_total_dispensed_qty_after ) end) as rx_total_dispensed_qty,
(case when (LENGTH(trim(rx_refills_by_dttm_after )) ==0) then rx_refills_by_dttm_after else trim(rx_refills_by_dttm_after ) end) as rx_refills_by_dttm,
(case when (LENGTH(trim(fill_nbr_prescribed_after )) ==0) then fill_nbr_prescribed_after else trim(fill_nbr_prescribed_after ) end) as fill_nbr_prescribed,
(case when (LENGTH(trim(fill_nbr_dispensed_after )) ==0) then fill_nbr_dispensed_after else trim(fill_nbr_dispensed_after ) end) as fill_nbr_dispensed,
(case when (LENGTH(trim(fill_nbr_added_after )) ==0) then fill_nbr_added_after else trim(fill_nbr_added_after ) end) as fill_nbr_added,
(case when (LENGTH(trim(fill_unlimited_ind_after )) ==0) then fill_unlimited_ind_after else trim(fill_unlimited_ind_after ) end) as fill_unlimited_ind,
(case when (LENGTH(trim(fill_auto_ind_after )) ==0) then fill_auto_ind_after else trim(fill_auto_ind_after ) end) as fill_auto_ind,
(case when (LENGTH(trim(ordered_drug_id_after )) ==0) then ordered_drug_id_after else trim(ordered_drug_id_after ) end) as ordered_drug_id,
(case when (LENGTH(trim(rx_original_qty_disp_after )) ==0) then rx_original_qty_disp_after else trim(rx_original_qty_disp_after ) end) as rx_original_qty_disp,
(case when (LENGTH(trim(rx_original_days_supply_after )) ==0) then rx_original_days_supply_after else trim(rx_original_days_supply_after ) end) as rx_original_days_supply,
(case when (LENGTH(trim(create_user_id_after )) ==0) then create_user_id_after else trim(create_user_id_after ) end) as create_user_id,
(case when (LENGTH(trim(create_dttm_after )) ==0) then create_dttm_after else trim(create_dttm_after ) end) as create_dttm,
(case when (LENGTH(trim(update_user_id_after )) ==0) then update_user_id_after else trim(update_user_id_after ) end) as update_user_id,
(case when (LENGTH(trim(update_dttm_after )) ==0) then update_dttm_after else trim(update_dttm_after ) end) as update_dttm,
(case when (LENGTH(trim(generic_subs_pref_after )) ==0) then generic_subs_pref_after else trim(generic_subs_pref_after ) end) as generic_subs_pref,
(case when (LENGTH(trim(diagnosis_cd_after )) ==0) then diagnosis_cd_after else trim(diagnosis_cd_after ) end) as diagnosis_cd,
(case when (LENGTH(trim(image_id_after )) ==0) then image_id_after else trim(image_id_after ) end) as image_id,
(case when (LENGTH(trim(routing_store_nbr_after )) ==0) then routing_store_nbr_after else trim(routing_store_nbr_after ) end) as routing_store_nbr,
(case when (LENGTH(trim(scanned_user_id_after )) ==0) then scanned_user_id_after else trim(scanned_user_id_after ) end) as scanned_user_id,
(case when (LENGTH(trim(scanned_dttm_after )) ==0) then scanned_dttm_after else trim(scanned_dttm_after ) end) as scanned_dttm,
(case when (LENGTH(trim(scanned_store_nbr_after )) ==0) then scanned_store_nbr_after else trim(scanned_store_nbr_after ) end) as scanned_store_nbr,
(case when (LENGTH(trim(diagnosis_cd_qualifier_after )) ==0) then diagnosis_cd_qualifier_after else trim(diagnosis_cd_qualifier_after ) end) as diagnosis_cd_qualifier,
(case when (LENGTH(trim(tip_rx_ind_after )) ==0) then tip_rx_ind_after else trim(tip_rx_ind_after ) end) as tip_rx_ind,
(case when (LENGTH(trim(pbr_order_nbr_after )) ==0) then pbr_order_nbr_after else trim(pbr_order_nbr_after ) end) as pbr_order_nbr,
(case when (LENGTH(trim(origin_cd_after )) ==0) then origin_cd_after else trim(origin_cd_after ) end) as origin_cd,
(case when (LENGTH(trim(diagnosis_cd_2_after )) ==0) then diagnosis_cd_2_after else trim(diagnosis_cd_2_after ) end) as diagnosis_cd_2,
(case when (LENGTH(trim(diagnosis_cd_3_after )) ==0) then diagnosis_cd_3_after else trim(diagnosis_cd_3_after ) end) as diagnosis_cd_3,
(case when (LENGTH(trim(diagnosis_cd_4_after )) ==0) then diagnosis_cd_4_after else trim(diagnosis_cd_4_after ) end) as diagnosis_cd_4,
(case when (LENGTH(trim(rx_pad_program_ind_after )) ==0) then rx_pad_program_ind_after else trim(rx_pad_program_ind_after ) end) as rx_pad_program_ind,
(case when (LENGTH(trim(rx_pad_barcode_after )) ==0) then rx_pad_barcode_after else trim(rx_pad_barcode_after ) end) as rx_pad_barcode,
(case when (LENGTH(trim(fill_qty_dispensed_after )) ==0) then fill_qty_dispensed_after else trim(fill_qty_dispensed_after ) end) as fill_qty_dispensed,
(case when (LENGTH(trim(fill_days_supply_after )) ==0) then fill_days_supply_after else trim(fill_days_supply_after ) end) as fill_days_supply,
(case when (LENGTH(trim(rx_added_qty_after )) ==0) then rx_added_qty_after else trim(rx_added_qty_after ) end) as rx_added_qty,
(case when (LENGTH(trim(fill_nbr_last_disp_after )) ==0) then fill_nbr_last_disp_after else trim(fill_nbr_last_disp_after ) end) as fill_nbr_last_disp,
(case when (LENGTH(trim(fill_entered_dttm_after )) ==0) then fill_entered_dttm_after else trim(fill_entered_dttm_after ) end) as fill_entered_dttm,
(case when (LENGTH(trim(fill_part_nbr_last_disp_after )) ==0) then fill_part_nbr_last_disp_after else trim(fill_part_nbr_last_disp_after ) end) as fill_part_nbr_last_disp,
(case when (LENGTH(trim(rx_vacc_manuf_lot_nbr_after )) ==0) then rx_vacc_manuf_lot_nbr_after else trim(rx_vacc_manuf_lot_nbr_after ) end) as rx_vacc_manuf_lot_nbr,
(case when (LENGTH(trim(rx_vacc_exp_dttm_after )) ==0) then rx_vacc_exp_dttm_after else trim(rx_vacc_exp_dttm_after ) end) as rx_vacc_exp_dttm,
(case when (LENGTH(trim(rx_vacc_area_of_admin_after )) ==0) then rx_vacc_area_of_admin_after else trim(rx_vacc_area_of_admin_after ) end) as rx_vacc_area_of_admin,
(case when (LENGTH(trim(rx_vacc_consent_ind_after )) ==0) then rx_vacc_consent_ind_after else trim(rx_vacc_consent_ind_after ) end) as rx_vacc_consent_ind,
(case when (LENGTH(trim(rx_vacc_pnl_ent_dttm_after )) ==0) then rx_vacc_pnl_ent_dttm_after else trim(rx_vacc_pnl_ent_dttm_after ) end) as rx_vacc_pnl_ent_dttm,
(case when (LENGTH(trim(rx_vacc_pnl_status_cd_after )) ==0) then rx_vacc_pnl_status_cd_after else trim(rx_vacc_pnl_status_cd_after ) end) as rx_vacc_pnl_status_cd,
(case when (LENGTH(trim(rx_90day_pref_ind_after )) ==0) then rx_90day_pref_ind_after else trim(rx_90day_pref_ind_after ) end) as rx_90day_pref_ind,
(case when (LENGTH(trim(rx_90day_pref_dttm_after )) ==0) then rx_90day_pref_dttm_after else trim(rx_90day_pref_dttm_after ) end) as rx_90day_pref_dttm,
(case when (LENGTH(trim(rx_90day_pref_stat_cd_after )) ==0) then rx_90day_pref_stat_cd_after else trim(rx_90day_pref_stat_cd_after ) end) as rx_90day_pref_stat_cd,
(case when (LENGTH(trim(rx_90day_pref_stat_dttm_after )) ==0) then rx_90day_pref_stat_dttm_after else trim(rx_90day_pref_stat_dttm_after ) end) as rx_90day_pref_stat_dttm,
(case when (LENGTH(trim(rx_immu_ind_after )) ==0) then rx_immu_ind_after else trim(rx_immu_ind_after ) end) as rx_immu_ind,
(case when (LENGTH(trim(diagnosis_cd_5_after )) ==0) then diagnosis_cd_5_after else trim(diagnosis_cd_5_after ) end) as diagnosis_cd_5,
(case when (LENGTH(trim(diagnosis_cd_qualifier_2_after )) ==0) then diagnosis_cd_qualifier_2_after else trim(diagnosis_cd_qualifier_2_after ) end) as diagnosis_cd_qualifier_2,
(case when (LENGTH(trim(diagnosis_cd_qualifier_3_after )) ==0) then diagnosis_cd_qualifier_3_after else trim(diagnosis_cd_qualifier_3_after ) end) as diagnosis_cd_qualifier_3,
(case when (LENGTH(trim(diagnosis_cd_qualifier_4_after )) ==0) then diagnosis_cd_qualifier_4_after else trim(diagnosis_cd_qualifier_4_after ) end) as diagnosis_cd_qualifier_4,
(case when (LENGTH(trim(diagnosis_cd_qualifier_5_after )) ==0) then diagnosis_cd_qualifier_5_after else trim(diagnosis_cd_qualifier_5_after ) end) as diagnosis_cd_qualifier_5,
(case when (LENGTH(trim(pbr_dea_nbr_after )) ==0) then pbr_dea_nbr_after else trim(pbr_dea_nbr_after ) end) as pbr_dea_nbr,
(case when (LENGTH(trim(pbr_dea_suf_after )) ==0) then pbr_dea_suf_after else trim(pbr_dea_suf_after ) end) as pbr_dea_suf,
(case when (LENGTH(trim(buyout_rx_ind_after )) ==0) then buyout_rx_ind_after else trim(buyout_rx_ind_after ) end) as buyout_rx_ind,
(case when (LENGTH(trim(trmt_type_cd_after )) ==0) then trmt_type_cd_after else trim(trmt_type_cd_after ) end) as trmt_type_cd,
(case when (LENGTH(trim(fill_sold_dttm_after )) ==0) then fill_sold_dttm_after else trim(fill_sold_dttm_after ) end) as fill_sold_dttm,
(case when (LENGTH(trim(erx_pat_automatch_ind_after )) ==0) then erx_pat_automatch_ind_after else trim(erx_pat_automatch_ind_after ) end) as erx_pat_automatch_ind,
(case when (LENGTH(trim(rx_90day_switch_ind_after )) ==0) then rx_90day_switch_ind_after else trim(rx_90day_switch_ind_after ) end) as rx_90day_switch_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_ind_after )) ==0) then fill_adv_rfl_opt_ind_after else trim(fill_adv_rfl_opt_ind_after ) end) as fill_adv_rfl_opt_ind,
(case when (LENGTH(trim(fill_adv_rfl_opt_dttm_after )) ==0) then fill_adv_rfl_opt_dttm_after else trim(fill_adv_rfl_opt_dttm_after ) end) as fill_adv_rfl_opt_dttm,
(case when (LENGTH(trim(rx_vacc_info_race_after )) ==0) then rx_vacc_info_race_after else trim(rx_vacc_info_race_after ) end) as rx_vacc_info_race,
(case when (LENGTH(trim(rx_vacc_info_ethnicity_after )) ==0) then rx_vacc_info_ethnicity_after else trim(rx_vacc_info_ethnicity_after ) end) as rx_vacc_info_ethnicity,
(case when (LENGTH(trim(rx_vacc_info_comorbidity_after )) ==0) then rx_vacc_info_comorbidity_after else trim(rx_vacc_info_comorbidity_after ) end) as rx_vacc_info_comorbidity,
'gg_tbf0_rx' as table_name
from nr_insert_check"""

# COMMAND ----------

gg_tbf0_update_afr = spark.sql(pTgtUpdAftXfr)

gg_tbf0_update_bfr = spark.sql(pTgtUpdBfrXfr)

gg_tbf0_insert_afr = spark.sql(pTgtInsBfrAftXfr) 

# COMMAND ----------

gg_tbf0_insert_afr.createOrReplaceTempView("gg_tbf0_insert_afr")

sel_query = "select * from gg_tbf0_insert_afr where"

gg_tbf0_insert_patid_check = spark.sql(sel_query+pPatIdModCheck)

gg_tbf0_insert_nopatid = spark.sql(sel_query+pNoPatIdTableCheck)

gg_tbf0_insert_patid_check_rejected = gg_tbf0_insert_afr.subtract(gg_tbf0_insert_patid_check).subtract(gg_tbf0_insert_nopatid)
#display(gg_tbf0_insert_patid_check_rejected)

if gg_tbf0_insert_patid_check_rejected.count()>0:
  gg_tbf0_insert_patid_check_rejected.write.mode("overwrite").parquet(REJ_FILE_PAT_MOD)
  
gg_tbf0_insert_final = gg_tbf0_insert_nopatid.union(gg_tbf0_insert_patid_check)

etl_tbf0_file = gg_tbf0_update_afr.union(gg_tbf0_update_bfr)
etl_tbf0_file = etl_tbf0_file.union(gg_tbf0_insert_final)

etl_tbf0_file.createOrReplaceTempView("etl_tbf0_file")

# COMMAND ----------

#Rearrangement column position for the the common ETL_TBF0_* schema format and  applying UDF for replacing ':' with  space in the dttm field and adding .000000 end of dttm for sqoop timestamp matching
etl_tbf0_reformat_sql = "select "+ pTgtUDFcleanXfr +" from etl_tbf0_file"
#print(etl_tbf0_reformat_sql)

etl_tbf0_reformat = spark.sql(etl_tbf0_reformat_sql)

etl_tbf0_reformat = etl_tbf0_reformat.withColumn("rx_create_yr", lit("")) \
                                     .withColumn("rx_create_mnth", lit("")) 

#Rejecting records if cdc_operation_type_cd is NULL
etl_tbf0_reformat_cdc_check = etl_tbf0_reformat.filter((etl_tbf0_reformat.cdc_operation_type_cd.isNull()) | (etl_tbf0_reformat.cdc_operation_type_cd == '' ))
#display(etl_tbf0_reformat_cdc_check)

etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat.filter(etl_tbf0_reformat.cdc_operation_type_cd.isNotNull()) \
.withColumn("cdc_txn_commit_dttm",to_timestamp(etl_tbf0_reformat["cdc_txn_commit_dttm"])) \
.withColumn("cdc_seq_nbr",when(col("cdc_seq_nbr") == "",None).otherwise(col("cdc_seq_nbr"))) \
.withColumn("cdc_rba_nbr",when(col("cdc_rba_nbr") == "",None).otherwise(col("cdc_rba_nbr"))) \
.withColumn("cdc_operation_type_cd",when(col("cdc_operation_type_cd") == "",None).otherwise(col("cdc_operation_type_cd"))) \
.withColumn("cdc_before_after_cd",when(col("cdc_before_after_cd") == "",None).otherwise(col("cdc_before_after_cd"))) \
.withColumn("cdc_txn_position_cd",when(col("cdc_txn_position_cd") == "",None).otherwise(col("cdc_txn_position_cd"))) \
.withColumn("edw_batch_id",when(col("edw_batch_id") == "",None).otherwise(col("edw_batch_id"))) \
.withColumn("store_nbr",when(col("store_nbr") == "",None).otherwise(col("store_nbr"))) \
.withColumn("rx_nbr",when(col("rx_nbr") == "",None).otherwise(col("rx_nbr"))) \
.withColumn("pat_id",when(col("pat_id") == "",None).otherwise(col("pat_id"))) \
.withColumn("drug_id",when(col("drug_id") == "",None).otherwise(col("drug_id"))) \
.withColumn("drug_class",when(col("drug_class") == "",None).otherwise(col("drug_class"))) \
.withColumn("drug_non_system_cd",when(col("drug_non_system_cd") == "",None).otherwise(col("drug_non_system_cd"))) \
.withColumn("pbr_id",when(col("pbr_id") == "",None).otherwise(col("pbr_id"))) \
.withColumn("fill_qty_dispensed",when(col("fill_qty_dispensed") == "",None).otherwise(col("fill_qty_dispensed"))) \
.withColumn("fill_days_supply",when(col("fill_days_supply") == "",None).otherwise(col("fill_days_supply"))) \
.withColumn("rx_daw_ind",when(col("rx_daw_ind") == "",None).otherwise(col("rx_daw_ind"))) \
.withColumn("rx_written_dttm",when(col("rx_written_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_written_dttm"]))) \
.withColumn("rx_original_fill_dttm",when(col("rx_original_fill_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_original_fill_dttm"]))) \
.withColumn("rx_added_qty",when(col("rx_added_qty") == "",None).otherwise(col("rx_added_qty"))) \
.withColumn("rx_sig",when(col("rx_sig") == "",None).otherwise(col("rx_sig"))) \
.withColumn("rx_refills_by_dttm",when(col("rx_refills_by_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_refills_by_dttm"]))) \
.withColumn("fill_nbr_prescribed",when(col("fill_nbr_prescribed") == "",None).otherwise(col("fill_nbr_prescribed"))) \
.withColumn("fill_nbr_dispensed",when(col("fill_nbr_dispensed") == "",None).otherwise(col("fill_nbr_dispensed"))) \
.withColumn("fill_nbr_added",when(col("fill_nbr_added") == "",None).otherwise(col("fill_nbr_added"))) \
.withColumn("fill_auto_ind",when(col("fill_auto_ind") == "",None).otherwise(col("fill_auto_ind"))) \
.withColumn("fill_nbr_last_disp",when(col("fill_nbr_last_disp") == "",None).otherwise(col("fill_nbr_last_disp"))) \
.withColumn("fill_entered_dttm",when(col("fill_entered_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["fill_entered_dttm"]))) \
.withColumn("image_id",when(col("image_id") == "",None).otherwise(col("image_id"))) \
.withColumn("scanned_user_id",when(col("scanned_user_id") == "",None).otherwise(col("scanned_user_id"))) \
.withColumn("scanned_dttm",when(col("scanned_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["scanned_dttm"]))) \
.withColumn("scanned_store_nbr",when(col("scanned_store_nbr") == "",None).otherwise(col("scanned_store_nbr"))) \
.withColumn("tip_rx_ind",when(col("tip_rx_ind") == "",None).otherwise(col("tip_rx_ind"))) \
.withColumn("pbr_order_nbr",when(col("pbr_order_nbr") == "",None).otherwise(col("pbr_order_nbr"))) \
.withColumn("drug_sub_cd",when(col("drug_sub_cd") == "",None).otherwise(col("drug_sub_cd"))) \
.withColumn("pbr_loc_id",when(col("pbr_loc_id") == "",None).otherwise(col("pbr_loc_id"))) \
.withColumn("pay_cd",when(col("pay_cd") == "",None).otherwise(col("pay_cd"))) \
.withColumn("rx_comment",when(col("rx_comment") == "",None).otherwise(col("rx_comment"))) \
.withColumn("rx_status_cd",when(col("rx_status_cd") == "",None).otherwise(col("rx_status_cd"))) \
.withColumn("fill_unlimited_ind",when(col("fill_unlimited_ind") == "",None).otherwise(col("fill_unlimited_ind"))) \
.withColumn("ordered_drug_id",when(col("ordered_drug_id") == "",None).otherwise(col("ordered_drug_id"))) \
.withColumn("create_user_id",when(col("create_user_id") == "",None).otherwise(col("create_user_id"))) \
.withColumn("create_dttm",when(col("create_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["create_dttm"]))) \
.withColumn("update_user_id",when(col("update_user_id") == "",None).otherwise(col("update_user_id"))) \
.withColumn("update_dttm",when(col("update_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["update_dttm"]))) \
.withColumn("generic_subs_pref",when(col("generic_subs_pref") == "",None).otherwise(col("generic_subs_pref"))) \
.withColumn("routing_store_nbr",when(col("routing_store_nbr") == "",None).otherwise(col("routing_store_nbr"))) \
.withColumn("rx_original_qty_disp",when(col("rx_original_qty_disp") == "",None).otherwise(col("rx_original_qty_disp"))) \
.withColumn("rx_original_days_supply",when(col("rx_original_days_supply") == "",None).otherwise(col("rx_original_days_supply"))) \
.withColumn("src_partition_nbr",when(col("src_partition_nbr") == "",None).otherwise(col("src_partition_nbr"))) \
.withColumn("rx_total_dispensed_qty",when(col("rx_total_dispensed_qty") == "",None).otherwise(col("rx_total_dispensed_qty"))) \
.withColumn("rx_original_qty",when(col("rx_original_qty") == "",None).otherwise(col("rx_original_qty"))) \
.withColumn("diagnosis_cd",when(col("diagnosis_cd") == "",None).otherwise(col("diagnosis_cd"))) \
.withColumn("diagnosis_cd_qualifier",when(col("diagnosis_cd_qualifier") == "",None).otherwise(col("diagnosis_cd_qualifier"))) \
.withColumn("origin_cd",when(col("origin_cd") == "",None).otherwise(col("origin_cd"))) \
.withColumn("diagnosis_cd_2",when(col("diagnosis_cd_2") == "",None).otherwise(col("diagnosis_cd_2"))) \
.withColumn("diagnosis_cd_3",when(col("diagnosis_cd_3") == "",None).otherwise(col("diagnosis_cd_3"))) \
.withColumn("diagnosis_cd_4",when(col("diagnosis_cd_4") == "",None).otherwise(col("diagnosis_cd_4"))) \
.withColumn("rx_pad_program_ind",when(col("rx_pad_program_ind") == "",None).otherwise(col("rx_pad_program_ind"))) \
.withColumn("rx_pad_barcode",when(col("rx_pad_barcode") == "",None).otherwise(col("rx_pad_barcode"))) \
.withColumn("rx_vacc_manuf_lot_nbr",when(col("rx_vacc_manuf_lot_nbr") == "",None).otherwise(col("rx_vacc_manuf_lot_nbr"))) \
.withColumn("rx_vacc_exp_dttm",when(col("rx_vacc_exp_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_vacc_exp_dttm"]))) \
.withColumn("rx_vacc_area_of_admin",when(col("rx_vacc_area_of_admin") == "",None).otherwise(col("rx_vacc_area_of_admin"))) \
.withColumn("rx_vacc_consent_ind",when(col("rx_vacc_consent_ind") == "",None).otherwise(col("rx_vacc_consent_ind"))) \
.withColumn("rx_vacc_pnl_ent_dttm",when(col("rx_vacc_pnl_ent_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_vacc_pnl_ent_dttm"]))) \
.withColumn("rx_vacc_pnl_status_cd",when(col("rx_vacc_pnl_status_cd") == "",None).otherwise(col("rx_vacc_pnl_status_cd"))) \
.withColumn("rx_90day_pref_ind",when(col("rx_90day_pref_ind") == "",None).otherwise(col("rx_90day_pref_ind"))) \
.withColumn("rx_90day_pref_dttm",when(col("rx_90day_pref_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_90day_pref_dttm"]))) \
.withColumn("rx_90day_pref_stat_cd",when(col("rx_90day_pref_stat_cd") == "",None).otherwise(col("rx_90day_pref_stat_cd"))) \
.withColumn("rx_90day_pref_stat_dttm",when(col("rx_90day_pref_stat_dttm") == "",None).otherwise(to_timestamp(etl_tbf0_reformat["rx_90day_pref_stat_dttm"]))) \
.withColumn("diagnosis_cd_5",when(col("diagnosis_cd_5") == "",None).otherwise(col("diagnosis_cd_5"))) \
.withColumn("diagnosis_cd_qualifier_2",when(col("diagnosis_cd_qualifier_2") == "",None).otherwise(col("diagnosis_cd_qualifier_2"))) \
.withColumn("diagnosis_cd_qualifier_3",when(col("diagnosis_cd_qualifier_3") == "",None).otherwise(col("diagnosis_cd_qualifier_3"))) \
.withColumn("diagnosis_cd_qualifier_4",when(col("diagnosis_cd_qualifier_4") == "",None).otherwise(col("diagnosis_cd_qualifier_4"))) \
.withColumn("diagnosis_cd_qualifier_5",when(col("diagnosis_cd_qualifier_5") == "",None).otherwise(col("diagnosis_cd_qualifier_5"))) \
.withColumn("pbr_dea_nbr",when(col("pbr_dea_nbr") == "",None).otherwise(col("pbr_dea_nbr"))) \
.withColumn("pbr_dea_suf",when(col("pbr_dea_suf") == "",None).otherwise(col("pbr_dea_suf"))) \
.withColumn("buyout_rx_ind",when(col("buyout_rx_ind") == "",None).otherwise(col("buyout_rx_ind"))) \
.withColumn("trmt_type_cd",when(col("trmt_type_cd") == "",None).otherwise(col("trmt_type_cd"))) \
.withColumn("fill_sold_dttm",to_timestamp(etl_tbf0_reformat["fill_sold_dttm"])) \
.withColumn("erx_pat_automatch_ind",when(col("erx_pat_automatch_ind") == "",None).otherwise(col("erx_pat_automatch_ind"))) \
.withColumn("rx_90day_switch_ind",when(col("rx_90day_switch_ind") == "",None).otherwise(col("rx_90day_switch_ind"))) \
.withColumn("fill_adv_rfl_opt_ind",when(col("fill_adv_rfl_opt_ind") == "",None).otherwise(col("fill_adv_rfl_opt_ind"))) \
.withColumn("fill_adv_rfl_opt_dttm",to_timestamp(etl_tbf0_reformat["fill_adv_rfl_opt_dttm"]))\
.withColumn("rx_vacc_info_race",when(col("rx_vacc_info_race") == "",None).otherwise(col("rx_vacc_info_race"))) \
.withColumn("rx_vacc_info_ethnicity",when(col("rx_vacc_info_ethnicity") == "",None).otherwise(col("rx_vacc_info_ethnicity"))) \
.withColumn("rx_vacc_info_comorbidity",when(col("rx_vacc_info_comorbidity") == "",None).otherwise(col("rx_vacc_info_comorbidity"))) \
.withColumn("rx_create_yr",when(col("rx_create_yr") == "",None).otherwise(col("rx_create_yr"))) \
.withColumn("rx_create_mnth",when(col("rx_create_mnth") == "",None).otherwise(col("rx_create_mnth")))


#display(etl_tbf0_reformat_cdc_check_notnull)

#Storing rejected records from above step in a separate Reject File
#print(etl_tbf0_reformat_cdc_check.count())
if etl_tbf0_reformat_cdc_check.count()>0:
  etl_tbf0_reformat_cdc_check.write.mode("overwrite").parquet(REJ_FILE_CDC_CHECK)

#print(etl_tbf0_reformat_cdc_check_notnull.count())  

#etl_tbf0_reformat_cdc_check_notnull.printSchema()
etl_tbf0_reformat_cdc_check_notnull.write.mode("overwrite").parquet(OUT_FILEPATH)

# COMMAND ----------

# import pyspark.sql.functions as func
# for col in etl_tbf0_reformat_cdc_check_notnull.columns:
#     etl_tbf0_reformat_cdc_check_notnull = etl_tbf0_reformat_cdc_check_notnull.withColumn(col, when(func.ltrim(func.rtrim(etl_tbf0_reformat_cdc_check_notnull[col])) == "",None).otherwise(etl_tbf0_reformat_cdc_check_notnull[col]))
    
#display(etl_tbf0_reformat_cdc_check_notnull)

etl_tbf0_reformat_cdc_check_notnull_cons_tl=etl_tbf0_reformat_cdc_check_notnull.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd",etl_tbf0_reformat_cdc_check_notnull.cdc_txn_position_cd.substr(1,10).alias('cdc_txn_position_cd'),"edw_batch_id","store_nbr","rx_nbr","pat_id","drug_id","drug_class","drug_non_system_cd","pbr_id","fill_qty_dispensed","fill_days_supply","rx_daw_ind","rx_written_dttm","rx_original_fill_dttm","rx_added_qty","rx_sig","rx_refills_by_dttm","fill_nbr_prescribed","fill_nbr_dispensed","fill_nbr_added","fill_auto_ind","fill_nbr_last_disp","fill_entered_dttm","image_id","scanned_user_id","scanned_dttm","scanned_store_nbr","tip_rx_ind","pbr_order_nbr","drug_sub_cd","pbr_loc_id","pay_cd",etl_tbf0_reformat_cdc_check_notnull.rx_comment.substr(1,50).alias('rx_comment'),"rx_status_cd","fill_unlimited_ind","ordered_drug_id","create_user_id","create_dttm","update_user_id","update_dttm","generic_subs_pref","routing_store_nbr","rx_original_qty_disp","rx_original_days_supply","src_partition_nbr","rx_total_dispensed_qty","rx_original_qty","diagnosis_cd","diagnosis_cd_qualifier","origin_cd","diagnosis_cd_2","diagnosis_cd_3","diagnosis_cd_4","rx_pad_program_ind","rx_pad_barcode","rx_vacc_manuf_lot_nbr","rx_vacc_exp_dttm","rx_vacc_area_of_admin","rx_vacc_consent_ind","rx_vacc_pnl_ent_dttm","rx_vacc_pnl_status_cd","rx_90day_pref_ind","rx_90day_pref_dttm","rx_90day_pref_stat_cd","rx_90day_pref_stat_dttm","diagnosis_cd_5","diagnosis_cd_qualifier_2","diagnosis_cd_qualifier_3","diagnosis_cd_qualifier_4","diagnosis_cd_qualifier_5","pbr_dea_nbr","pbr_dea_suf","buyout_rx_ind","trmt_type_cd","fill_sold_dttm","erx_pat_automatch_ind","rx_90day_switch_ind","fill_adv_rfl_opt_dttm","fill_adv_rfl_opt_ind", "rx_vacc_info_race", "rx_vacc_info_ethnicity", "rx_vacc_info_comorbidity", "rx_create_yr", "rx_create_mnth")

etl_tbf0_reformat_cdc_check_notnull=etl_tbf0_reformat_cdc_check_notnull.select("cdc_txn_commit_dttm","cdc_seq_nbr","cdc_rba_nbr","cdc_operation_type_cd","cdc_before_after_cd",etl_tbf0_reformat_cdc_check_notnull.cdc_txn_position_cd.substr(1,10).alias('cdc_txn_position_cd'),"edw_batch_id","store_nbr","rx_nbr","pat_id","drug_id","drug_class","drug_non_system_cd","pbr_id","fill_qty_dispensed","fill_days_supply","rx_daw_ind","rx_written_dttm","rx_original_fill_dttm","rx_added_qty","rx_sig","rx_refills_by_dttm","fill_nbr_prescribed","fill_nbr_dispensed","fill_nbr_added","fill_auto_ind","fill_nbr_last_disp","fill_entered_dttm","image_id","scanned_user_id","scanned_dttm","scanned_store_nbr","tip_rx_ind","pbr_order_nbr","drug_sub_cd","pbr_loc_id","pay_cd",etl_tbf0_reformat_cdc_check_notnull.rx_comment.substr(1,50).alias('rx_comment'),"rx_status_cd","fill_unlimited_ind","ordered_drug_id","create_user_id","create_dttm","update_user_id","update_dttm","generic_subs_pref","routing_store_nbr","rx_original_qty_disp","rx_original_days_supply","src_partition_nbr","rx_total_dispensed_qty","rx_original_qty","diagnosis_cd","diagnosis_cd_qualifier","origin_cd","diagnosis_cd_2","diagnosis_cd_3","diagnosis_cd_4","rx_pad_program_ind","rx_pad_barcode","rx_vacc_manuf_lot_nbr","rx_vacc_exp_dttm","rx_vacc_area_of_admin","rx_vacc_consent_ind","rx_vacc_pnl_ent_dttm","rx_vacc_pnl_status_cd","rx_90day_pref_ind","rx_90day_pref_dttm","rx_90day_pref_stat_cd","rx_90day_pref_stat_dttm","diagnosis_cd_5","diagnosis_cd_qualifier_2","diagnosis_cd_qualifier_3","diagnosis_cd_qualifier_4","diagnosis_cd_qualifier_5","pbr_dea_nbr","pbr_dea_suf","buyout_rx_ind","trmt_type_cd", "fill_adv_rfl_opt_ind", "fill_adv_rfl_opt_dttm", "rx_vacc_info_race", "rx_vacc_info_ethnicity", "rx_vacc_info_comorbidity", "rx_create_yr", "rx_create_mnth")

# COMMAND ----------

delete_gg_snowflake = "Truncate table {0}.{1}".format(SNFL_DB, SNFL_TBL_NAME)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#Load ETL_TBF0_* formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", SNFL_TBL_NAME) \
        .option("continue_on_error","on")\
        .save()


# COMMAND ----------

delete_gg_snowflake_cons = "Truncate table {0}.PATIENT_SERVICES.CONS_TL_ETL_TBF0_RX_STG".format(SNFL_DB)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake_cons, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

delete_gg_snowflake_tl = "Truncate table {0}.PATIENT_SERVICES.TL_ETL_TBF0_RX_STG".format(SNFL_DB)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_gg_snowflake_tl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#Load CONS_TL_ETL_TBF0_* formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull_cons_tl.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", "PATIENT_SERVICES.CONS_TL_ETL_TBF0_RX_STG") \
        .option("continue_on_error","on")\
        .save()

#Load TL_ETL_TBF0_* formatted records to the Snowflake Table
etl_tbf0_reformat_cdc_check_notnull_cons_tl.write \
        .format("net.snowflake.spark.snowflake") \
        .mode("append") \
        .options(**options) \
        .option("sfWarehouse", SNFL_WH) \
        .option("sfDatabase", SNFL_DB) \
        .option("dbtable", "PATIENT_SERVICES.TL_ETL_TBF0_RX_STG") \
        .option("continue_on_error","on")\
        .save()


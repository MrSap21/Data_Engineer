# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Reading input file IT145P.csv

input_file1 = dbutils.widgets.get("PAR_NB_INPUT_FILE1")
input_file2 = dbutils.widgets.get("PAR_NB_INPUT_FILE2")
input1_path = dbutils.widgets.get("PAR_NB_INPUT1_PATH")
input2_path = dbutils.widgets.get("PAR_NB_INPUT2_PATH")
ldr_path = dbutils.widgets.get("CIF_LOAD_READY_FILE_LOC")

preFile = mountPoint + '/' + input1_path + '/' + input_file1 
currFile = mountPoint + '/' + input2_path + '/' + input_file2 
outFilePath = mountPoint + '/' + ldr_path 

dfIT145P = spark.read.options(delimiter="|",header="true", inferSchema="false").csv(preFile)
dfIT145P.show()

    
#dfIT145P = spark.read.csv("/mnt/wrangled/location/serial/main/IT145P.csv", header="true", inferSchema="true")


#global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")
#dfIT145P = table(global_temp_db + ".dfIT145P")

#dfIT145P = dfIT145P.when(substring(col("date_stamp"), 1,1) = 1 

dfIT145P = dfIT145P.withColumn("DateAux1", when(length(col("date_stamp")) < 7, concat(lit('0'), col("date_stamp")))
                              .when(length(col("date_stamp")) == 7, col("date_stamp")))\
                   .withColumn("DateAux", when(substring(col("DateAux1"),1,1) == 0, to_date(concat((1900 + substring(col("DateAux1"), 2,2)).cast(IntegerType()), lit("/"), substring(col("DateAux1"), 4,2), lit("/"), substring(col("DateAux1"), 6,2)), "yyyy/MM/dd"))
                              .when(substring(col("DateAux1"),1,1) == 1, to_date(concat((2000 + substring(col("DateAux1"), 2,2)).cast(IntegerType()), lit("/"), substring(col("DateAux1"), 4,2), lit("/"), substring(col("DateAux1"), 6,2)), "yyyy/MM/dd"))
                              .when(substring(col("DateAux1"),1,1) == 2, to_date(concat((2100 + substring(col("DateAux1"), 2,2)).cast(IntegerType()), lit("/"), substring(col("DateAux1"), 4,2), lit("/"), substring(col("DateAux1"), 6,2)), "yyyy/MM/dd")))\
                   .withColumn("TimeAux1", when(length(col("TIME_STAMP")) < 6, concat(lit('0'), col("TIME_STAMP")))
                               .when(length(col("TIME_STAMP")) == 6, col("TIME_STAMP")))\
                   .withColumn("TimeAux", concat(substring(col("TimeAux1"), 1,2), lit(":"), substring(col("time_stamp"), 3,2), lit(":"), substring(col("time_stamp"), 5,2)))\
                   .withColumn("SRC_CREATE_DTTM", to_timestamp(concat(col("DateAux"), lit(" "), col("TimeAux"))))\
                   .withColumn("ZONE_NUMBER", when((trim(col("zone_number")) == "") | (col("zone_number").isNull()), 0).otherwise(col("zone_number")))\
                   .drop("DateAux", "TimeAux", "date_stamp", "time_stamp")
dfIT145P.show()

# COMMAND ----------

# Reading input file IT144P.csv

#dfIT144P = spark.read.csv("/mnt/wrangled/location/serial/main/IT144P.csv", header="true", inferSchema="true")

#dfIT144P = spark.read.options(delimiter="|").csv(currFile,header="true", inferSchema="true")
dfIT144P = spark.read.options(delimiter="|",header="true", inferSchema="false").csv(currFile)
dfIT144P.show()

#global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")
#dfIT144P = table(global_temp_db + ".dfIT144P")

dfIT144P = dfIT144P.withColumn("DateAux1", when(length(col("date_stamp")) < 7, concat(lit('0'), col("date_stamp")))
                              .when(length(col("date_stamp")) == 7, col("date_stamp")))\
.withColumn("DateAux", when(substring(col("DateAux1"),1,1) == 0, to_date(concat((1900 + substring(col("DateAux1"), 2,2)).cast(IntegerType()), lit("/"), substring(col("DateAux1"), 4,2), lit("/"), substring(col("DateAux1"), 6,2)), "yyyy/MM/dd")).when(substring(col("DateAux1"),1,1) == 1, to_date(concat((2000 + substring(col("DateAux1"), 2,2)).cast(IntegerType()), lit("/"), substring(col("DateAux1"), 4,2), lit("/"), substring(col("DateAux1"), 6,2)), "yyyy/MM/dd")).when(substring(col("DateAux1"),1,1) == 2, to_date(concat((2100 + substring(col("DateAux1"), 2,2)).cast(IntegerType()), lit("/"), substring(col("DateAux1"), 4,2), lit("/"), substring(col("DateAux1"), 6,2)), "yyyy/MM/dd")))\
                   .withColumn("TimeAux1", when(length(col("TIME_STAMP")) < 6, concat(lit('0'), col("TIME_STAMP")))
                              .when(length(col("TIME_STAMP")) == 6, col("TIME_STAMP")))\
                   .withColumn("TimeAux", concat(substring(col("TimeAux1"), 1,2), lit(":"), substring(col("TimeAux1"), 3,2), lit(":"), substring(col("TimeAux1"), 5,2)))\
                   .withColumn("SRC_CREATE_DTTM", to_timestamp(concat(col("DateAux"), lit(" "), col("TimeAux"))))\
                   .drop("DateAux", "TimeAux", "date_stamp", "time_stamp")
dfIT144P.show()

# COMMAND ----------

# Reading input file IT144P.csv

#dfIT144P = spark.read.csv("/mnt/wrangled/location/serial/main/IT144P.csv", header="true", inferSchema="true")

#dfIT144P = spark.read.options(delimiter="|").csv(currFile,header="true", inferSchema="true")
#dfIT144P.show()

#global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")
#dfIT144P = table(global_temp_db + ".dfIT144P")

#dfIT144P = dfIT144P.withColumn("DateAux", to_date(concat((1900 + substring(col("date_stamp"), 2,2)).cast(IntegerType()), lit("/"), substring(col("date_stamp"), 4,2), lit("/"), substring(col("date_stamp"), 6,2)), "yyyy/MM/dd"))\
 #                  .withColumn("TimeAux", concat(substring(col("time_stamp"), 1,2), lit(":"), substring(col("time_stamp"), 3,2), lit(":"), substring(col("time_stamp"), 5,2)))\
 #                  .withColumn("SRC_CREATE_DTTM", to_timestamp(concat(col("DateAux"), lit(" "), col("TimeAux"))))\
 #                  .drop("DateAux", "TimeAux", "date_stamp", "time_stamp")
#dfIT144P.show()

# COMMAND ----------

# Reformat dfIT145P and generate output

dfIT145PValidated = dfIT145P\
                    .withColumn("v_composite_key", when(col("COMPOSITE_KEY") < 1, " * invalid composite_key ").otherwise(lit("")))\
                    .withColumn("v_pricing_region_number", when(col("PRICING_REGION_NUMBER").isNull(), " * invalid pricing_region_number ").otherwise(lit("")))\
                    .withColumn("v_pricing_region_name", when(col("PRICING_REGION_NAME").isNull(), " * invalid price_region_name ").otherwise(lit("")))\
                    .withColumn("v_pricing_region_long_name", when(col("PRICING_REGION_DESC").isNull(), " * invalid pricing_region_long_name ").otherwise(lit("")))\
                    .withColumn("v_zone_number", when(col("ZONE_NUMBER").isNull(), " * invalid zone_number ").otherwise(lit("")))\
                    .withColumn("v_zone_name", when(col("ZONE_NAME").isNull(), " * invalid zone_name ").otherwise(lit("")))\
                    .withColumn("v_src_create_dttm", when(col("SRC_CREATE_DTTM").isNull(), " * invalid date_stamp/time_stamp ").otherwise(lit("")))

dfIT145PValidated = dfIT145PValidated.withColumn("error",concat(col("v_composite_key"),col("v_pricing_region_number"),col("v_pricing_region_name"),col("v_pricing_region_long_name"),col("v_zone_number"),col("v_zone_name"),col("v_src_create_dttm")))

dfIT145PValidationResults = dfIT145PValidated.filter(col("error") != "")

if dfIT145PValidationResults.count() > 0:
  raise Exception("The Record is invalid due to " + dfIT145PValidationResults.collect()[0]["error"])

dfOutput1 = dfIT145PValidated.select(col("COMPOSITE_KEY").alias("general_compete_lvl"), col("PRICING_REGION_NUMBER").alias("price_region_nbr"), col("PRICING_REGION_NAME").alias("price_region_name"), col("PRICING_REGION_DESC").alias("price_region_long_name"), lit("").alias("rpting_price_region_nbr"), lit("").alias("rpting_price_region_name"), lit("").alias("rpting_price_region_long_name"), col("ZONE_NUMBER").alias("zone_nbr"), col("zone_name"), col("user_stamp").alias("src_create_user_id"), col("SRC_CREATE_DTTM"), current_timestamp().alias("edw_create_dttm"), current_timestamp().alias("edw_update_dttm"), lit(dbutils.widgets.get("pDAP_BATCH_ID")).alias("edw_batch_id"))

# COMMAND ----------

# Reformat dfIT144P and generate output

dfIT144PValidated = dfIT144P\
                    .withColumn("v_pricing_region_number", when(col("REPORTING_REGION_NBR").isNull(), " * invalid pricing_region_number ").otherwise(lit("")))\
                    .withColumn("v_pricing_region_name", when(col("REPORTING_REGION_NAME").isNull(), " * invalid price_region_name ").otherwise(lit("")))\
                    .withColumn("v_Description", when(col("REPORTING_REGION_DESC").isNull(), " * invalid Description ").otherwise(lit("")))\
                    .withColumn("v_src_create_dttm", when(col("src_create_dttm").isNull(), " * invalid date_stamp/time_stamp ").otherwise(lit("")))

dfIT144PValidated = dfIT144PValidated.withColumn("error", concat(col("v_pricing_region_number"), col("v_pricing_region_name"),col("v_Description"),col("v_src_create_dttm")))

dfIT144ValidationResults = dfIT144PValidated.filter(col("error") != "")

if dfIT144ValidationResults.count() > 0:
  raise Exception("The Record is invalid due to " + dfIT144ValidationResults.collect()[0]["error"])

dfOutput2 = dfIT144PValidated.select(lit("-1").alias("general_compete_lvl"), lit("").alias("price_region_nbr"), lit("").alias("price_region_name"), lit("").alias("price_region_long_name"), col("REPORTING_REGION_NBR").alias("rpting_price_region_nbr"), col("REPORTING_REGION_NAME").alias("rpting_price_region_name"), col("REPORTING_REGION_DESC").alias("rpting_price_region_long_name"), lit("").alias("zone_nbr"), lit("").alias("zone_name"), col("user_stamp").alias("src_create_user_id"), col("src_create_dttm"), current_timestamp().alias("edw_create_dttm"), current_timestamp().alias("edw_update_dttm"), lit(dbutils.widgets.get("pDAP_BATCH_ID")).alias("edw_batch_id"))

# COMMAND ----------

# Gather both Datasets

dfOutputFinal = dfOutput1.union(dfOutput2)

# COMMAND ----------

# Write output

dfOutputFinal_Location = "{0}/{1}/edw_idl_location_store_zoning_cif_location_store_region_zone_{2}".format(mountPoint, dbutils.widgets.get('CIF_LOAD_READY_FILE_LOC'), dbutils.widgets.get('pDAP_BATCH_ID'))

#dfOutputFinal.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(dfOutputFinal_Location)
dfOutputFinal.write.format("parquet").mode("overwrite").save(outFilePath)

# Renaming output and adding the correct extention

#output = dbutils.fs.ls(dfOutputFinal_Location)
#csv_file_output = [x.path for x in output if x.path.endswith(".parquet")][0]
#dbutils.fs.mv(csv_file_output, dfOutputFinal_Location.rstrip('/') + ".parquet")
#dbutils.fs.rm(dfOutputFinal_Location, recurse = True)
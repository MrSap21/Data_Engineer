# Databricks notebook source
import json

# COMMAND ----------

# Return connection details

options = eval(dbutils.notebook.run("../Utilities/SnowflakeConnOptions", 60))

# COMMAND ----------

# Load data to dataframe

df = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("query", "SELECT * FROM \"DNADEVEDWDB01\".\"DRUG_SPECIALTY_LIST\"") \
  .load()

df.show()

# COMMAND ----------

# Run queries

query = "update \"DNADEVEDWDB01\".\"DRUG_SPECIALTY_LIST\" set CATG_CD = 20 WHERE NDC11 = 58468009003"

dbutils.notebook.run("../Utilities/RunSnowSQL", 60, { "query" : query, "transaction" : True})

# COMMAND ----------


# Databricks notebook source
#Defining paramters

var_Input_File_Path = dbutils.widgets.get("PAR_NB_FILEPATH")
var_delimiter = dbutils.widgets.get("PAR_NB_DELIMITER")
adlsAccountName = dbutils.widgets.get("PAR_NB_ACCOUNT_NAME")
adlsContainerName = dbutils.widgets.get("PAR_NB_CONTAINER_NAME")
namesOfSheets = dbutils.widgets.get("PAR_NB_LIST_NAME_OF_SHEETS")
outFileName = dbutils.widgets.get("PAR_NB_OUT_FILE_NAME")
headerInOut = dbutils.widgets.get("PAR_NB_HEADER_TRUE_FALSE")
                                          
#var_Input_File_Path = "common/dap_out_missouri_price_modify_extr"
#var_delimiter = ","
#adlsAccountName = "dapdevadlswrng01"
#adlsContainerName = "wrangled"
#mountPoint = "/mnt/" + adlsContainerName + "/"
#namesOfSheets="sheet1,sheet2"
#outFileName="abc"
#headerInOut="True"


# COMMAND ----------

# Define the variables used for creating connection strings
mountPoint = "/mnt/" + adlsContainerName + "/"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
# if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
#   dbutils.fs.mount(
#     source = source,
#     mount_point = mountPoint,
#     extra_configs = configs)
   
  
   

# COMMAND ----------

#print(ListOfSheets)
ListOfSheets=list(namesOfSheets.split(","))

for sheet in ListOfSheets:
#  print(i)

  df = spark.read.format("csv")\
      .option("header", headerInOut)\
      .option("delimiter", var_delimiter)\
      .load(mountPoint  + var_Input_File_Path + "/" + sheet+".csv")
 # display(df)

  outSheet="'"+sheet+"'"+"!A1"
  print(outSheet)
  df.write.format("com.crealytics.spark.excel").option("dataAddress", outSheet).option("header", headerInOut).mode("append").save(mountPoint  + var_Input_File_Path + "/" + outFileName + ".xlsx")
  
 # dbutils.fs.rm(mountPoint  + var_Input_File_Path + "/" + sheet+".csv")

    

# COMMAND ----------



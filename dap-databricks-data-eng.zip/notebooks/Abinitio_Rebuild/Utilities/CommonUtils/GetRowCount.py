# Databricks notebook source
import pyspark
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType
import datetime
import pyspark.sql.column 

# COMMAND ----------

dbutils.widgets.text("PAR_DB_INPUT_ACCOUNT_NAME","",label="PAR_DB_INPUT_ACCOUNT_NAME")
dbutils.widgets.text("PAR_DB_INPUT_CONTAINER_NAME","",label="PAR_DB_INPUT_CONTAINER_NAME")
dbutils.widgets.text("PAR_DB_INPUT_PATH","",label="PAR_DB_INPUT_PATH")
dbutils.widgets.text("PAR_DB_OUTPUT_CONTAINER_NAME","",label="PAR_DB_OUTPUT_CONTAINER_NAME")
dbutils.widgets.text("PAR_DB_OUTPUT_PATH","",label="PAR_DB_OUTPUT_PATH")
dbutils.widgets.text("PAR_DB_DELIMITER","",label="PAR_DB_DELIMITER")
dbutils.widgets.text("PAR_DB_PROJ_NAME","",label="PAR_DB_PROJ_NAME")
dbutils.widgets.text("PAR_DB_SRC_STREAM_NAME","",label="PAR_DB_SRC_STREAM_NAME")
dbutils.widgets.text("PAR_DB_BATCH_ID","",label="PAR_DB_BATCH_ID")
dbutils.widgets.text("PAR_DB_PSET_FILE_NAME","",label="PAR_DB_PSET_FILE_NAME")
dbutils.widgets.text("PAR_DB_TABLE_NAME","",label="PAR_DB_TABLE_NAME")
dbutils.widgets.text("PAR_DB_EXTR_DTTM","",label="PAR_DB_EXTR_DTTM")

adlsInputAccountName=dbutils.widgets.get("PAR_DB_INPUT_ACCOUNT_NAME")
adlsInputContainerName=dbutils.widgets.get("PAR_DB_INPUT_CONTAINER_NAME")
adlsInputFolderPath=dbutils.widgets.get("PAR_DB_INPUT_PATH")
adlsOutputContainerName=dbutils.widgets.get("PAR_DB_OUTPUT_CONTAINER_NAME")
adlsOutputFolderPath=dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
adlsProjectName=dbutils.widgets.get("PAR_DB_PROJ_NAME")
adlsSrcStreamName=dbutils.widgets.get("PAR_DB_SRC_STREAM_NAME")
adlsBatchId=dbutils.widgets.get("PAR_DB_BATCH_ID")
adlsPsetFileName=dbutils.widgets.get("PAR_DB_PSET_FILE_NAME")
adlsTableName=dbutils.widgets.get("PAR_DB_TABLE_NAME")
adlsExtrDttm=dbutils.widgets.get("PAR_DB_EXTR_DTTM")
delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')

# COMMAND ----------

# Python code to mount and access Azure Data Lake Storage Gen2 Account to Azure Databricks with Service Principal and OAuth
# Author: Dhyanendra Singh Rathore
# Define the variables used for creating connection strings
# adlsAccountName = adlsInputAccountName
# adlsContainerName = adlsInputContainerName
mountPoint = "/mnt/"+adlsInputContainerName

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsInputContainerName + "@" + adlsInputAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)
  

# COMMAND ----------

# Load File

df = spark.read.format("csv")\
      .option("header", False)\
      .option("delimiter",delimiter)\
      .load('dbfs:/mnt/'+adlsInputContainerName+'/'+adlsInputFolderPath+'/')

# COMMAND ----------

dfNew = spark.createDataFrame([(df.count(), adlsProjectName, adlsSrcStreamName,adlsBatchId,adlsPsetFileName,adlsTableName,adlsExtrDttm[0:19],adlsOutputFolderPath[adlsOutputFolderPath.rindex('/')+1:len(adlsOutputFolderPath)],datetime.datetime.now())], ['extract_record_cnt','proj_name', 'src_stream_name','edw_batch_id','pset_name','extract_table_name','extract_dttm','extract_file_name', 'extract_create_dt'])

# COMMAND ----------

dfNew.show()

# COMMAND ----------

# Create output path

data_location_output = mountPoint + "/" + str.replace(adlsOutputFolderPath, ".dat", "")
  
# Write in ADLS

dfNew.write.format("parquet").mode("overwrite").save(data_location_output)

# Renaming output and adding the correct extention

# filesoutput = dbutils.fs.ls(data_location_output)
# csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
# dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
# dbutils.fs.rm(data_location_output, recurse = True)
# Databricks notebook source
# Public variables

var_Input_File_Path = dbutils.widgets.get('PAR_DB_INPUT_PATH')
var_Output_File_Path = dbutils.widgets.get('PAR_DB_OUTPUT_PATH')
v_delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')
v_numColumns = int(dbutils.widgets.get('PAR_DB_NUMBER_OF_COLUMNS'))

if var_Output_File_Path.strip() == '' or "/" not in var_Output_File_Path:
  raise Exception("Output path invalid!!")

# COMMAND ----------

# Python code to mount and access Azure Data Lake Storage Gen2 Account to Azure Databricks with Service Principal and OAuth
# Author: Dhyanendra Singh Rathore
# Define the variables used for creating connection strings
adlsAccountName = "dapdevadlslnd01"
adlsContainerName = "landing"
mountPoint = "/mnt/staging/rowDelimiterTransformation"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)
  

# COMMAND ----------

# Load File

df = spark.read.format("text")\
      .option("header", False)\
      .load("/mnt/landing/" + var_Input_File_Path)

#display(df)

# COMMAND ----------

# Split based on delimiter provided

from pyspark.sql.functions import *
df1 = df.withColumn("AllColumns", split("value", v_delimiter)).drop("value")

#display(df1)

# COMMAND ----------

# Explode the entire data into a column

df2 = df1.select(explode('AllColumns'))
#display(df2)

# COMMAND ----------

# Pivot data to desired format based on number of columns provided

result = df2.withColumn('id', monotonically_increasing_id()).withColumn('id2', (col('id') / v_numColumns).cast('int')).withColumn('id3', col('id') % v_numColumns).groupBy('id2').pivot('id3').agg(first('col')).orderBy('id2').drop('id2')

#display(result)

# COMMAND ----------

# Create output path

data_location_output = mountPoint + "/" + str.replace(var_Output_File_Path, ".dat", "")
  
# Write in ADLS

result.coalesce(1).write.options(header='false', delimiter = v_delimiter).format("csv").mode("overwrite").save(data_location_output)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

# COMMAND ----------


# Databricks notebook source
# MAGIC %run ../Utilities/NB_DAP_MULTIPLE_HC_XML_FILE_PROCESSING_UTILITIES

# COMMAND ----------

# MAGIC %run ../Utilities/COMMON_UTILITIES_NB

# COMMAND ----------

# Import Python libs
import json
from functools import reduce

# Import PySpark libs
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Mounting ADLS
mount_point = dbutils.notebook.run("../Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# Read ADF inputs and assign to variables
dbutils.widgets.text("INPUT_DATA_FILES_LIST","",label="INPUT_DATA_FILES_LIST")
dbutils.widgets.text("DELTA_FILE_NAME","",label="DELTA_FILE_NAME")
dbutils.widgets.text("DELTA_FILE_DIR","",label="DELTA_FILE_DIR")
dbutils.widgets.text("BATCH_ID","",label="BATCH_ID")
batch_id = dbutils.widgets.get("BATCH_ID")
delta_file_name = dbutils.widgets.get("DELTA_FILE_NAME")
delta_file_dir = dbutils.widgets.get("DELTA_FILE_DIR")
input_data_files_list = dbutils.widgets.get("INPUT_DATA_FILES_LIST")
delta_file_path = mount_point + '/' + delta_file_dir + '/' + delta_file_name + '/' + batch_id

# COMMAND ----------

inputs_dict = {'BATCH_ID': batch_id, 'INPUT_DATA_FILES_LIST': input_data_files_list, 'DELTA_FILE_NAME': delta_file_name, \
               'DELTA_FILE_DIR': delta_file_dir}
# validate ADF inputs
validate_inputs(inputs_dict)

# COMMAND ----------

import time
from datetime import datetime
#Required fields for all the tables
fields_in_scope = ["Column<'messageInfo.updateDTTM AS `messageInfo_updateDTTM`'>",
"Column<'messageInfo.updateUserId AS `messageInfo_updateUserId`'>",
"Column<'messageInfo.createDTTM AS `messageInfo_createDTTM`'>",
"Column<'messageInfo.createUserId AS `messageInfo_createUserId`'>",
 
"Column<'messageInfo.SourceSystem AS `messageInfo_SourceSystem`'>",
"Column<'messageInfo_SourceSystem.updateDTTM AS `messageInfo_SourceSystem_updateDTTM`'>", 
 
"Column<'providerInfo.entityID AS `providerInfo_entityID`'>",

"Column<'providerInfo.providerLocationInfo AS `providerInfo_providerLocationInfo`'>",
"Column<'providerInfo_providerLocationInfo.locationEntityID AS `providerInfo_providerLocationInfo_locationEntityID`'>",

"Column<'providerInfo_providerLocationInfo.address AS `providerInfo_providerLocationInfo_address`'>",
"Column<'providerInfo_providerLocationInfo_address.line AS `providerInfo_providerLocationInfo_address_line`'>",
"Column<'providerInfo_providerLocationInfo_address.line0 AS `providerInfo_providerLocationInfo_address_line0`'>",
"Column<'providerInfo_providerLocationInfo_address.line1 AS `providerInfo_providerLocationInfo_address_line1`'>",
"Column<'providerInfo_providerLocationInfo_address.city AS `providerInfo_providerLocationInfo_address_city`'>",
"Column<'providerInfo_providerLocationInfo_address.state AS `providerInfo_providerLocationInfo_address_state`'>",
"Column<'providerInfo_providerLocationInfo_address.ZipCode AS `providerInfo_providerLocationInfo_address_ZipCode`'>",
"Column<'providerInfo_providerLocationInfo_address_ZipCode.zip AS `providerInfo_providerLocationInfo_address_ZipCode_zip`'>",
"Column<'providerInfo_providerLocationInfo_address_ZipCode.plus4 AS `providerInfo_providerLocationInfo_address_ZipCode_plus4`'>",
"Column<'providerInfo_providerLocationInfo_address.rank AS `providerInfo_providerLocationInfo_address_rank`'>",
"Column<'providerInfo_providerLocationInfo_address.standardizationCode AS `providerInfo_providerLocationInfo_address_standardizationCode`'>",
"Column<'providerInfo_providerLocationInfo_address.businessName AS `providerInfo_providerLocationInfo_address_businessName`'>",
 
"Column<'providerInfo_providerLocationInfo.locationValidIndicator AS `providerInfo_providerLocationInfo_locationValidIndicator`'>",

"Column<'providerInfo_providerLocationInfo.sourceSystem AS `providerInfo_providerLocationInfo_sourceSystem`'>",
"Column<'providerInfo_providerLocationInfo_sourceSystem.name AS `providerInfo_providerLocationInfo_sourceSystem_name`'>",
"Column<'providerInfo_providerLocationInfo_sourceSystem.id AS `providerInfo_providerLocationInfo_sourceSystem_id`'>",
"Column<'providerInfo_providerLocationInfo_sourceSystem.id2 AS `providerInfo_providerLocationInfo_sourceSystem_id2`'>",

                   
"Column<'providerInfo_providerLocationInfo.phone AS `providerInfo_providerLocationInfo_phone`'>",
"Column<'providerInfo_providerLocationInfo_phone.type AS `providerInfo_providerLocationInfo_phone_type`'>",
"Column<'providerInfo_providerLocationInfo_phone.areaCode AS `providerInfo_providerLocationInfo_phone_areaCode`'>",
"Column<'providerInfo_providerLocationInfo_phone.number AS `providerInfo_providerLocationInfo_phone_number`'>",
"Column<'providerInfo_providerLocationInfo_phone.extension AS `providerInfo_providerLocationInfo_phone_extension`'>",

"Column<'providerInfo_providerLocationInfo.dea AS `providerInfo_providerLocationInfo_dea`'>",
"Column<'providerInfo_providerLocationInfo_dea.number AS `providerInfo_providerLocationInfo_dea_number`'>",
"Column<'providerInfo_providerLocationInfo_dea.suffix AS `providerInfo_providerLocationInfo_dea_suffix`'>",
"Column<'providerInfo_providerLocationInfo_dea.expirationDate AS `providerInfo_providerLocationInfo_dea_expirationDate`'>",
"Column<'providerInfo_providerLocationInfo_dea.data2000WaiverID AS `providerInfo_providerLocationInfo_dea_data2000WaiverID`'>",
"Column<'providerInfo_providerLocationInfo_dea.rank AS `providerInfo_providerLocationInfo_dea_rank`'>",
"Column<'providerInfo_providerLocationInfo_dea.activeIndicator AS `providerInfo_providerLocationInfo_dea_activeIndicator`'>",
"Column<'providerInfo_providerLocationInfo_dea.businessActivityCode AS `providerInfo_providerLocationInfo_dea_businessActivityCode`'>",
"Column<'providerInfo_providerLocationInfo_dea.businessActivitySubCode AS `providerInfo_providerLocationInfo_dea_businessActivitySubCode`'>",
 
"Column<'providerInfo_providerLocationInfo_dea.scheduleCodes AS `providerInfo_providerLocationInfo_dea_scheduleCodes`'>",
"Column<'providerInfo_providerLocationInfo_dea_scheduleCodes.schedulePermitted2 AS `providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted2`'>",
"Column<'providerInfo_providerLocationInfo_dea_scheduleCodes.schedulePermitted2N AS `providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted2N`'>",
"Column<'providerInfo_providerLocationInfo_dea_scheduleCodes.schedulePermitted3 AS `providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted3`'>",
"Column<'providerInfo_providerLocationInfo_dea_scheduleCodes.schedulePermitted3N AS `providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted3N`'>",
"Column<'providerInfo_providerLocationInfo_dea_scheduleCodes.schedulePermitted4 AS `providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted4`'>",
"Column<'providerInfo_providerLocationInfo_dea_scheduleCodes.schedulePermitted5 AS `providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted5`'>",

"Column<'providerInfo_providerLocationInfo.spi AS `providerInfo_providerLocationInfo_spi`'>",
"Column<'providerInfo_providerLocationInfo_spi.locationId AS `providerInfo_providerLocationInfo_spi_locationId`'>",
"Column<'providerInfo_providerLocationInfo_spi.locationActiveDate AS `providerInfo_providerLocationInfo_spi_locationActiveDate`'>",
"Column<'providerInfo_providerLocationInfo_spi.locationDeactiveDate AS `providerInfo_providerLocationInfo_spi_locationDeactiveDate`'>",
 
"Column<'providerInfo_providerLocationInfo_spi.locationServiceLevel AS `providerInfo_providerLocationInfo_spi_locationServiceLevel`'>",
"Column<'providerInfo_providerLocationInfo_spi_locationServiceLevel.serviceLevelCode AS `providerInfo_providerLocationInfo_spi_locationServiceLevel_serviceLevelCode`'>",

"Column<'providerInfo.email AS `providerInfo_email`'>",
"Column<'providerInfo_email.type AS `providerInfo_email_type`'>",
"Column<'providerInfo_email.address AS `providerInfo_email_address`'>",
"Column<'providerInfo_email.rank AS `providerInfo_email_rank`'>",
"Column<'providerInfo_email.activeIndicator AS `providerInfo_email_activeIndicator`'>",
 
"Column<'providerInfo.phone AS `providerInfo_phone`'>",
"Column<'providerInfo_phone.type AS `providerInfo_phone_type`'>",
"Column<'providerInfo_phone.areaCode AS `providerInfo_phone_areaCode`'>",
"Column<'providerInfo_phone.number AS `providerInfo_phone_number`'>",
"Column<'providerInfo_phone.extension AS `providerInfo_phone_extension`'>",
 
"Column<'providerInfo.professionalInfo AS `providerInfo_professionalInfo`'>",

"Column<'providerInfo_professionalInfo.dea AS `providerInfo_professionalInfo_dea`'>",
"Column<'providerInfo_professionalInfo_dea.number AS `providerInfo_professionalInfo_dea_number`'>",
"Column<'providerInfo_professionalInfo_dea.suffix AS `providerInfo_professionalInfo_dea_suffix`'>",
"Column<'providerInfo_professionalInfo_dea.expirationDate AS `providerInfo_professionalInfo_dea_expirationDate`'>",
"Column<'providerInfo_professionalInfo_dea.data2000WaiverID AS `providerInfo_professionalInfo_dea_data2000WaiverID`'>",
"Column<'providerInfo_professionalInfo_dea.rank AS `providerInfo_professionalInfo_dea_rank`'>",
"Column<'providerInfo_professionalInfo_dea.activeIndicator AS `providerInfo_professionalInfo_dea_activeIndicator`'>",
"Column<'providerInfo_professionalInfo_dea.businessActivityCode AS `providerInfo_professionalInfo_dea_businessActivityCode`'>",
"Column<'providerInfo_professionalInfo_dea.businessActivitySubCode AS `providerInfo_professionalInfo_dea_businessActivitySubCode`'>",

"Column<'providerInfo_professionalInfo_dea.scheduleCodes AS `providerInfo_professionalInfo_dea_scheduleCodes`'>",
"Column<'providerInfo_professionalInfo_dea_scheduleCodes.schedulePermitted2 AS `providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted2`'>",
"Column<'providerInfo_professionalInfo_dea_scheduleCodes.schedulePermitted2N AS `providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted2N`'>",
"Column<'providerInfo_professionalInfo_dea_scheduleCodes.schedulePermitted3 AS `providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted3`'>",
"Column<'providerInfo_professionalInfo_dea_scheduleCodes.schedulePermitted3N AS `providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted3N`'>",
"Column<'providerInfo_professionalInfo_dea_scheduleCodes.schedulePermitted4 AS `providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted4`'>",
"Column<'providerInfo_professionalInfo_dea_scheduleCodes.schedulePermitted5 AS `providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted5`'>",
 
"Column<'providerInfo_professionalInfo.medicaid AS `providerInfo_professionalInfo_medicaid`'>",
"Column<'providerInfo_professionalInfo_medicaid.idNumber AS `providerInfo_professionalInfo_medicaid_idNumber`'>",
"Column<'providerInfo_professionalInfo_medicaid.issuingAuthority AS `providerInfo_professionalInfo_medicaid_issuingAuthority`'>",

"Column<'providerInfo_professionalInfo.foreign AS `providerInfo_professionalInfo_foreign`'>",
"Column<'providerInfo_professionalInfo_foreign.idNumber AS `providerInfo_professionalInfo_foreign_idNumber`'>",
"Column<'providerInfo_professionalInfo_foreign.country AS `providerInfo_professionalInfo_foreign_country`'>",

"Column<'providerInfo_professionalInfo.controlledSubstance AS `providerInfo_professionalInfo_controlledSubstance`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance.number AS `providerInfo_professionalInfo_controlledSubstance_number`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance.issuingState AS `providerInfo_professionalInfo_controlledSubstance_issuingState`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance.issueDate AS `providerInfo_professionalInfo_controlledSubstance_issueDate`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance.expirationDate AS `providerInfo_professionalInfo_controlledSubstance_expirationDate`'>",
 
"Column<'providerInfo_professionalInfo_controlledSubstance.scheduleCodes AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance_scheduleCodes.schedulePermitted2 AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted2`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance_scheduleCodes.schedulePermitted2N AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted2N`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance_scheduleCodes.schedulePermitted3 AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted3`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance_scheduleCodes.schedulePermitted3N AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted3N`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance_scheduleCodes.schedulePermitted4 AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted4`'>",
"Column<'providerInfo_professionalInfo_controlledSubstance_scheduleCodes.schedulePermitted5 AS `providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted5`'>",

"Column<'providerInfo_professionalInfo.sanction AS `providerInfo_professionalInfo_sanction`'>",
"Column<'providerInfo_professionalInfo_sanction.startDate AS `providerInfo_professionalInfo_sanction_startDate`'>",
"Column<'providerInfo_professionalInfo_sanction.boardCode AS `providerInfo_professionalInfo_sanction_boardCode`'>",
"Column<'providerInfo_professionalInfo_sanction.endDate AS `providerInfo_professionalInfo_sanction_endDate`'>",

"Column<'providerInfo_professionalInfo_sanction.offense AS `providerInfo_professionalInfo_sanction_offense`'>",
"Column<'providerInfo_professionalInfo_sanction_offense.offenseCode AS `providerInfo_professionalInfo_sanction_offense_offenseCode`'>",

"Column<'providerInfo_professionalInfo_sanction_offense.action AS `providerInfo_professionalInfo_sanction_offense_action`'>",                  
"Column<'providerInfo_professionalInfo_sanction_offense_action.actionCode AS `providerInfo_professionalInfo_sanction_offense_action_actionCode`'>",
 
"Column<'providerInfo_professionalInfo.stateLicense AS `providerInfo_professionalInfo_stateLicense`'>",
"Column<'providerInfo_professionalInfo_stateLicense.idNumber AS `providerInfo_professionalInfo_stateLicense_idNumber`'>",
"Column<'providerInfo_professionalInfo_stateLicense.issuingAuthority AS `providerInfo_professionalInfo_stateLicense_issuingAuthority`'>",
"Column<'providerInfo_professionalInfo_stateLicense.expirationDTTM AS `providerInfo_professionalInfo_stateLicense_expirationDTTM`'>",
"Column<'providerInfo_professionalInfo_stateLicense.activeIndicator AS `providerInfo_professionalInfo_stateLicense_activeIndicator`'>",
"Column<'providerInfo_professionalInfo_stateLicense.issueDate AS `providerInfo_professionalInfo_stateLicense_issueDate`'>",

"Column<'providerInfo_professionalInfo.credential AS `providerInfo_professionalInfo_credential`'>",
"Column<'providerInfo_professionalInfo_credential.code AS `providerInfo_professionalInfo_credential_code`'>",
 
"Column<'providerInfo_professionalInfo.practitioner AS `providerInfo_professionalInfo_practitioner`'>",
"Column<'providerInfo_professionalInfo_practitioner.code AS `providerInfo_professionalInfo_practitioner_code`'>",

"Column<'providerInfo_professionalInfo.specialty AS `providerInfo_professionalInfo_specialty`'>",
"Column<'providerInfo_professionalInfo_specialty.code AS `providerInfo_professionalInfo_specialty_code`'>",
 
"Column<'providerInfo.prescriberType AS `providerInfo_prescriberType`'>",
"Column<'providerInfo.validIndicator AS `providerInfo_validIndicator`'>",
"Column<'providerInfo.status AS `providerInfo_status`'>",

"Column<'providerInfo.demographicInfo AS `providerInfo_demographicInfo`'>",   
"Column<'providerInfo_demographicInfo.birthDate AS `providerInfo_demographicInfo_birthDate`'>",
"Column<'providerInfo_demographicInfo.gender AS `providerInfo_demographicInfo_gender`'>",
"Column<'providerInfo_demographicInfo.deceasedDate AS `providerInfo_demographicInfo_deceasedDate`'>",
                   
"Column<'providerInfo_demographicInfo.Name AS `providerInfo_demographicInfo_Name`'>",
"Column<'providerInfo_demographicInfo_Name.firstName AS `providerInfo_demographicInfo_Name_firstName`'>",
"Column<'providerInfo_demographicInfo_Name.middleName AS `providerInfo_demographicInfo_Name_middleName`'>",
"Column<'providerInfo_demographicInfo_Name.lastName AS `providerInfo_demographicInfo_Name_lastName`'>",
"Column<'providerInfo_demographicInfo_Name.prefix AS `providerInfo_demographicInfo_Name_prefix`'>",
"Column<'providerInfo_demographicInfo_Name.suffix AS `providerInfo_demographicInfo_Name_suffix`'>",
                   
"Column<'providerInfo_professionalInfo.medicareParticipationIndicator AS `providerInfo_professionalInfo_medicareParticipationIndicator`'>",
                   
"Column<'providerInfo_professionalInfo.npi AS `providerInfo_professionalInfo_npi`'>",
"Column<'providerInfo_professionalInfo_npi.id AS `providerInfo_professionalInfo_npi_id`'>",
"Column<'providerInfo_professionalInfo_npi.enumerationDate AS `providerInfo_professionalInfo_npi_enumerationDate`'>",
"Column<'providerInfo_professionalInfo_npi.deactivationDate AS `providerInfo_professionalInfo_npi_deactivationDate`'>",
"Column<'providerInfo_professionalInfo_npi.reactivationDate AS `providerInfo_professionalInfo_npi_reactivationDate`'>",
"Column<'providerInfo_professionalInfo_npi.taxonomyCode AS `providerInfo_professionalInfo_npi_taxonomyCode`'>"]


# COMMAND ----------

# Define column values in List((tuple0,tuple1)) -- List((columnnamewithrelativetags,onlycolumnname))
col_list = [("messageInfo_updateDTTM","updateDTTM"),("messageInfo_updateUserId","updateUserId"),("messageInfo_createDTTM","createDTTM"),("messageInfo_createUserId","createUserId"),("providerInfo_entityID","entityID"),("providerInfo_professionalInfo_stateLicense_idNumber","idNumber"),("providerInfo_professionalInfo_stateLicense_issuingAuthority","issuingAuthority"),("providerInfo_professionalInfo_stateLicense_expirationDTTM","expirationDTTM"),("providerInfo_professionalInfo_stateLicense_activeIndicator","activeIndicator"),("providerInfo_professionalInfo_stateLicense_issueDate","issueDate"),("providerInfo_providerLocationInfo_locationEntityID","locationEntityID"),("providerInfo_providerLocationInfo_address_line0","line0"),("providerInfo_providerLocationInfo_address_line1","line1"),("providerInfo_providerLocationInfo_address_city","city"),("providerInfo_providerLocationInfo_address_state","state"),("providerInfo_providerLocationInfo_address_ZipCode_zip","zip"),("providerInfo_providerLocationInfo_address_ZipCode_plus4","plus4"),("providerInfo_providerLocationInfo_address_rank","addrank"),("providerInfo_providerLocationInfo_address_standardizationCode","standardizationCode"),("providerInfo_providerLocationInfo_address_businessName","businessName"),("providerInfo_providerLocationInfo_locationValidIndicator","locationValidIndicator"),("providerInfo_providerLocationInfo_dea_number","deanumber"),("providerInfo_providerLocationInfo_dea_suffix","suffix"),("providerInfo_providerLocationInfo_dea_expirationDate","expirationDate"),("providerInfo_providerLocationInfo_dea_data2000WaiverID","data2000WaiverID"),("providerInfo_providerLocationInfo_dea_rank","dearank"),("providerInfo_providerLocationInfo_dea_businessActivityCode","businessActivityCode"),("providerInfo_providerLocationInfo_dea_businessActivitySubCode","businessActivitySubCode"),("providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted2","schedulePermitted2"),("providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted2N","schedulePermitted2N"),("providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted3","schedulePermitted3"),("providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted3N","schedulePermitted3N"),("providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted4","schedulePermitted4"),("providerInfo_providerLocationInfo_dea_scheduleCodes_schedulePermitted5","schedulePermitted5"),
("providerInfo_providerLocationInfo_phone_type","loctype0"),("providerInfo_providerLocationInfo_phone_areaCode","locareaCode"),("providerInfo_providerLocationInfo_phone_number","phnumber"),("providerInfo_providerLocationInfo_phone_extension","providerextension"),
("providerInfo_providerLocationInfo_dea_activeIndicator","deaactiveIndicator"),("providerInfo_providerLocationInfo_spi_locationId","locationId"),("providerInfo_providerLocationInfo_spi_locationActiveDate","locationActiveDate"),("providerInfo_providerLocationInfo_spi_locationDeactiveDate","locationDeactiveDate"),("providerInfo_providerLocationInfo_spi_locationServiceLevel_serviceLevelCode","serviceLevelCode"),
("providerInfo_email_type","mailtype0"),("providerInfo_email_address","address"),("providerInfo_email_rank","mailrank"),("providerInfo_email_activeIndicator","mailactiveIndicator"),
("providerInfo_phone_type","type0"),("providerInfo_phone_areaCode","areaCode"),("providerInfo_phone_number","infnumber"),("providerInfo_phone_extension","extension"),("providerInfo_professionalInfo_dea_number","deainfnumber"),("providerInfo_professionalInfo_dea_suffix","profsuffix"),("providerInfo_professionalInfo_dea_expirationDate","deaexpirationDate"),("providerInfo_professionalInfo_dea_data2000WaiverID","profdata2000WaiverID"),("providerInfo_professionalInfo_dea_rank","rank"),("providerInfo_professionalInfo_dea_activeIndicator","profactiveIndicator"),("providerInfo_professionalInfo_dea_businessActivityCode","profbusinessActivityCode"),("providerInfo_professionalInfo_dea_businessActivitySubCode","profbusinessActivitySubCode"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted2","profschedulePermitted2"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted2N","profschedulePermitted2N"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted3","profschedulePermitted3"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted3N","profschedulePermitted3N"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted4","profschedulePermitted4"),("providerInfo_professionalInfo_dea_scheduleCodes_schedulePermitted5","profschedulePermitted5"), 
("providerInfo_professionalInfo_medicaid_idNumber","mediidNumber"), ("providerInfo_professionalInfo_medicaid_issuingAuthority","mediissuingAuthority"),
("providerInfo_professionalInfo_foreign_idNumber","foreignidNumber"), ("providerInfo_professionalInfo_foreign_country","country"),
("providerInfo_professionalInfo_controlledSubstance_number","subnumber"), ("providerInfo_professionalInfo_controlledSubstance_issuingState","issuingState"), ("providerInfo_professionalInfo_controlledSubstance_issueDate","substissueDate"), ("providerInfo_professionalInfo_controlledSubstance_expirationDate","substexpirationDate"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted2","substschedulePermitted2"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted2N","substschedulePermitted2N"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted3","substschedulePermitted3"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted3N","substschedulePermitted3N"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted4","substschedulePermitted4"), ("providerInfo_professionalInfo_controlledSubstance_scheduleCodes_schedulePermitted5","substschedulePermitted5"),
("messageInfo_SourceSystem_updateDTTM","sourceupdateDTTM"),("providerInfo_providerLocationInfo_sourceSystem_name","name"),("providerInfo_providerLocationInfo_sourceSystem_id","id"),("providerInfo_providerLocationInfo_sourceSystem_id2","id2"),
("providerInfo_professionalInfo_sanction_offense_offenseCode","offenseCode"),("providerInfo_professionalInfo_sanction_startDate","startDate"),("providerInfo_professionalInfo_sanction_boardCode","boardCode"),("providerInfo_professionalInfo_sanction_endDate","endDate"),("providerInfo_professionalInfo_sanction_offense_action_actionCode","actionCode"),
("providerInfo_professionalInfo_credential_code","credcode"),("providerInfo_professionalInfo_practitioner_code","practcode"),
("providerInfo_professionalInfo_specialty_code","speccode"),("providerInfo_prescriberType","prescriberType"),("providerInfo_validIndicator","validIndicator"),("providerInfo_status","status"),("providerInfo_demographicInfo_birthDate","birthDate"),("providerInfo_demographicInfo_Name_firstName","firstName"),("providerInfo_demographicInfo_Name_middleName","middleName"),("providerInfo_demographicInfo_Name_lastName","lastName"),("providerInfo_demographicInfo_Name_prefix","prefix"),("providerInfo_demographicInfo_Name_suffix","namesuffix"),("providerInfo_demographicInfo_gender","gender"),("providerInfo_demographicInfo_deceasedDate","deceasedDate"),("providerInfo_professionalInfo_medicareParticipationIndicator","medicareParticipationIndicator"),("providerInfo_professionalInfo_npi_id","npiid"),("providerInfo_professionalInfo_npi_enumerationDate","enumerationDate"),("providerInfo_professionalInfo_npi_deactivationDate","deactivationDate"),("providerInfo_professionalInfo_npi_reactivationDate","reactivationDate"),("providerInfo_professionalInfo_npi_taxonomyCode","taxonomyCode")]

selected  = [col(j) for k, j in col_list]


# COMMAND ----------

def filter_df_columns(columns_list):
  result = []
  for cl in columns_list:
    if str(cl) in fields_in_scope:
      result.append(cl)
  return result

# COMMAND ----------

# Function to read single XML file to a dataframe, flatten and select the required columns
def read_single_xml(df_files_meta, asset_item_id):  
  # Retrieve the specific input file path
  
  input_file = df_files_meta.filter('asset_id = {0}'.format(asset_item_id))\
                              .select('input_file_path')\
                              .rdd.flatMap(lambda x: x).collect()[0]
  df1 = spark.read.format("com.databricks.spark.xml").option("rowTag","ns2:getProviderDetailResp").load(input_file)
  #adding columns to split line column values to line0 and line1 as per GDE-Specific to Address table alone
  if "providerInfo_providerLocationInfo_address_line1" in df1.columns:
    df1 = df1.withColumn("providerInfo_providerLocationInfo_address_line1",lit("#"))
  if "providerInfo_providerLocationInfo_address_line1" in df1.columns:
    df1 = df1.withColumn("providerInfo_providerLocationInfo_address_line0",lit("#"))
  #Flattens all required columns for all tables
  df=flatten_dataframe(df1)
  #add missing tags
  final_df=add_missing_tag(df,col_list)
  final_df = final_df.select(*selected)
  final_df1 = final_df.dropDuplicates()
  return final_df1

# COMMAND ----------

# Get the files metadata
df_files_meta = get_files_meta_data(input_data_files_list)
# Read multiple xml files in parallel based on the files metedata and merge all in a single dataframe
df_final = process_multi_xml_parallel(df_files_meta)

# COMMAND ----------

#Function to write flattened XML into Delta file
def write_into_delta(df_input, delta_path, write_format='delta', write_mode='overwrite'):
  df_input.write.format(write_format).mode(write_mode).save(delta_path)
  


# COMMAND ----------

# Writing into delta
write_into_delta(df_final,delta_file_path)

# COMMAND ----------

#Read from delta
delta_df = spark.read.format("delta").load(delta_file_path)

# COMMAND ----------

# Get the asset ids and return as comma separated values
asset_ids_list = df_files_meta.select('asset_id')\
                              .rdd.flatMap(lambda x: x).collect()
asset_ids_list_str = [str(_item) for _item in asset_ids_list]
asset_ids_csv_str = ','.join(asset_ids_list_str)

dbutils.notebook.exit(asset_ids_csv_str)

# Databricks notebook source
# Databricks notebook source
import struct
import pyodbc
from adal import AuthenticationContext

# COMMAND ----------

#creating a class to get a sql connection  from the database
class dbConnect:
    def __init__(self, dbConfig ,spark):
        self._dbConfig = dbConfig
        self._spark = spark
        self._conn = None

    def sqlConn(self):
        if self._conn is None:
            #getting the required credentials from the scope
            TenantId = dbutils.secrets.get(scope=self._dbConfig["keyVaultScope"],key=self._dbConfig["keyVaultSecret_tenantIDKey"])
            authority = "https://login.windows.net/" + TenantId
            resourceAppIdURI = "https://database.windows.net/"
            servicePrincipalId = dbutils.secrets.get(scope=self._dbConfig["keyVaultScope"],key=self._dbConfig["keyVaultSecret_sqlClientIDKey"])
            client_secret = dbutils.secrets.get(scope=self._dbConfig["keyVaultScope"],key=self._dbConfig["keyVaultSecret_sqlClientSecretKey"])
            server = self._dbConfig["sqlServerName"]
            database = self._dbConfig["dbName"]

            context = AuthenticationContext(authority)
            newtoken = context.acquire_token_with_client_credentials(resourceAppIdURI, servicePrincipalId,
                                                                     client_secret)
            properties = {"accessToken": newtoken.get('accessToken'), "hostNameInCertificate": "*.database.windows.net",
                          "encrypt": "true"}

            databaseToken = properties.get('accessToken')
            tokenb = bytes(databaseToken, "UTF-8")

            exptoken = b''
            for i in tokenb:
                exptoken += bytes({i})
                exptoken += bytes(1)
            tokenstruct = struct.pack("=i", len(exptoken)) + exptoken
            
            #creating a connection string to connect with SQL Server.
            connString = "Driver={ODBC Driver 17 for SQL Server};SERVER=" + server + ";DATABASE=" + database + ""

            SQL_COPT_SS_ACCESS_TOKEN = 1256
            conn = pyodbc.connect(connString, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: tokenstruct})

            self._conn = conn.cursor()

        return self._conn

    def __enter__(self):
        return self
    # defining the exit function so that the connection get closed automatically.
    def __exit__(self, type, value, traceback):
        if self._conn is not None:
            self._conn.close()
            self._conn = None

# COMMAND ----------

# function to insert or update data in database
def upsertData(queryToInsert,valuesToInsert):
  with dbConnect(dbConfig,spark) as connectionObject:
    con = connectionObject.sqlConn()
    con.execute(queryToInsert,valuesToInsert)
    con.commit()

# COMMAND ----------

import json
# JSON file
configFile = open ('/dbfs/FileStore/apps/projects/edw_pharmacy_prd/config/project.json', "r")
 
# Reading from file
data = json.loads(configFile.read())

#database configuration
dbConfig = {
  "keyVaultScope":data["keyVaultSQScope"],
  "keyVaultSecret_tenantIDKey":data["keyVaultSecret_tenantIDKey"],
  "keyVaultSecret_sqlClientIDKey":data["keyVaultSecret_sqlClientIDKey"],
  "keyVaultSecret_sqlClientSecretKey":data["keyVaultSecret_sqlClientSecretKey"],
  "sqlServerName":data["sqlServerName"],
  "dbName":data["procCntrlDBName"]
}

# COMMAND ----------

# function to get the count of the asset with status id other then 24014 from database
def getCountFromDB(assetId):
  placeholders = ','.join('?' for i in range(len(assetId)))
  with dbConnect(dbConfig,spark) as connectionObject:
    query = "SELECT count(a.FeedID) FROM idfwba.asset a INNER JOIN idfwba.assetstatus b ON a.assetID = b.assetID WHERE DTEffectiveTo is null and StatusID ='24014' and a.assetID IN (%s)" % placeholders
    con = connectionObject.sqlConn()
    con.execute(query, assetId)
    row = con.fetchone()
    return row[0]

# COMMAND ----------

#Notebook to POST API request and get the unprocessed file details

import requests,json,time

#Read parameters from Pipeline 

url = dbutils.widgets.get("PAR_WRITEAPI_URL")
key1 = dbutils.widgets.get("PAR_WRITEAPI_KEY1")
value1 = dbutils.widgets.get("PAR_WRITEAPI_VALUE1")
key2 = dbutils.widgets.get("PAR_WRITEAPI_KEY2")
value2 = dbutils.widgets.get("PAR_WRITEAPI_VALUE2")

checkCountFlag = True

#convert the value passed into List
value2= (value2.split(','))

#Create K,V and send request as JSON String
body = {key1:value1,key2:value2}
request_string = json.dumps(body)

#Define the header Content type as JSON
headers = {'Content-Type': 'application/json'}

responseText = "No response"
retryCount = 0
while checkCountFlag:
  
  #Post the request to the API 
  response =requests.post(url,data=request_string,headers=headers)
  responseText = response.text
  print(responseText)
  
  #checking the response status
  if(response.status_code == 200 and json.loads(responseText)["msg"] == "Asset updated Successfully"):
    count = getCountFromDB(value2) #fetching the count from the DB for assest Id to check actual status in DB 
    if(count == 0):
      checkCountFlag = False
  else:
    print("Waiting")
    time.sleep(30)  #if the response is not success full waiting for some time to retry again
  
  
  retryCount += 1
  if retryCount == 4: 
    checkCountFlag = False #making checkCountFlag false to end the retry cycle.
  else:
    print("Retry No :- "+str(retryCount))

    
#Return the status to Pipeline
dbutils.notebook.exit(responseText)

# COMMAND ----------
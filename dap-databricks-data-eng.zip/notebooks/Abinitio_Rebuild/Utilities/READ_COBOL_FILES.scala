// Databricks notebook source
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{StringType,StructType}
import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.col

def flattenStructSchema(schema: StructType, prefix: String = null) : Array[Column] = {
    schema.fields.flatMap(f => {
      val columnName = if (prefix == null) f.name else (prefix + "." + f.name)

      f.dataType match {
        case st: StructType => flattenStructSchema(st, columnName)
        case _ => Array(col(columnName).as(columnName.replace("RECORD.", "").replace(".","_")))
      }
    })
  }

val df = spark
  .read
  .format("cobol")
  .option("copybook_contents", dbutils.widgets.get("copybook"))
  .load(dbutils.widgets.get("file_location"))

val dfResult = df.select(flattenStructSchema(df.schema):_*)

dfResult.createOrReplaceGlobalTempView(dbutils.widgets.get("result_view_name"))

dbutils.notebook.exit(dbutils.widgets.get("result_view_name"))
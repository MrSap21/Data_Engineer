# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)

# COMMAND ----------

# Public variables

var_Input_File_Path = dbutils.widgets.get('PAR_DB_INPUT_PATH')
v_delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')


# COMMAND ----------

print(mountPoint +'/'+ var_Input_File_Path)

# COMMAND ----------

# Load File

df = spark.read.parquet(mountPoint +'/'+ var_Input_File_Path)
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
df = df.withColumn("MsgSeq",split(col("Column_1"),"\\|")[0])
df.display()

# COMMAND ----------

# Split based on delimiter provided

from pyspark.sql.functions import split, explode
df1 = df.withColumn('Data',explode(split('Column_1',"\\^\\~\\|"))) #^~|
df1=df1.filter(df1.Data != "")
df1=df1.drop("Column_1")
display(df1)

# COMMAND ----------

# Create output path

df1.write.format("parquet").mode("overwrite").save(mountPoint +'/'+ var_Input_File_Path)

# COMMAND ----------


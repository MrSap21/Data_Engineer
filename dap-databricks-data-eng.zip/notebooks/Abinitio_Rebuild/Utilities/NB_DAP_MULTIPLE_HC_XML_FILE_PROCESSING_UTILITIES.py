# Databricks notebook source
# DBTITLE 1,Import libraries
# Import Python libs
import json
from functools import reduce

# COMMAND ----------

# DBTITLE 1,Function to get files metadata in a DF from JSON
def get_files_meta_data(input_data_files_list):
  rdd_list_json = sc.parallelize([input_data_files_list])
  df_files_list = sqlContext.read.json(rdd_list_json)
  df_files_meta = df_files_list.withColumn('input_file_path', \
                                           concat(lit(mount_point), lit('/'), df_files_list.assetcurrentlocation, df_files_list.assetname)) \
                                .selectExpr('assetid AS asset_id', 'input_file_path') \
                                .drop('assetcurrentlocation') \
                                .drop('assetname')
  return df_files_meta

# COMMAND ----------

# DBTITLE 1,Function to Flatten array of structs and structs
#Flatten all column execpt the line column
def flatten_dataframe(df):
   # compute Complex types in Schema   
    complex_fields = dict([(field.name, field.dataType)
                             for field in df.schema.fields
                             if type(field.dataType) == ArrayType or  type(field.dataType) == StructType])
    
    while len(complex_fields)!=0:
        col_name=list(complex_fields.keys())[0]
        if (type(complex_fields[col_name]) == StructType):
            expanded = [col(col_name+'.'+k).alias(col_name+'_'+k) for k in [ n.name for n in  complex_fields[col_name]]]
            selectedColumns = filter_df_columns(expanded)
            df=df.select("*", *selectedColumns).drop(col_name)
      # i.e. explode Arrays
        elif (type(complex_fields[col_name]) == ArrayType):
          if col_name == "providerInfo_providerLocationInfo_address_line":
                df = df.withColumn("providerInfo_providerLocationInfo_address_line0",\
                                   when(size(col(col_name))>0,col(col_name).getItem(0)).otherwise(None))
                df = df.withColumn("providerInfo_providerLocationInfo_address_line1",\
                                   when(size(col(col_name))==2,col(col_name).getItem(1)).otherwise(None))
                df = df.drop(col_name)
          else:
            df=df.withColumn(col_name,explode_outer(col_name))
      # recompute remaining Fields in Schema       
        complex_fields = dict([ (field.name,field.dataType)
                             for field in df.schema.fields 
                             if type(field.dataType) == ArrayType or  type(field.dataType) == StructType])
    return df

# COMMAND ----------

# DBTITLE 1,Function to Add Missing tags 
def add_missing_tag(df,columnlist):
  out_df=df
  for i in columnlist:
    if i[0] in df.columns:
      out_df=out_df.withColumnRenamed(i[0],i[1])
    else:
      out_df=out_df.withColumn(i[1],lit(None).cast(StringType()))
  return out_df

# COMMAND ----------

# DBTITLE 1,Function to process multiple XML read in parallel and merge all into a single DF
def process_multi_xml_parallel(df_files_meta):
  # Get all asset ids in a list
  assets_list = df_files_meta.select('asset_id').rdd.flatMap(lambda x: x).collect()
  # Parallelize the XML data read asset/file item wise and union all dataframes as part of reduce
  single_xml_rdds = map(lambda asset_item_id: read_single_xml(df_files_meta, asset_item_id), assets_list)
  df_final = reduce(lambda xml_df_1, xml_df_2: xml_df_1.unionByName(xml_df_2), single_xml_rdds)
  return df_final

# COMMAND ----------

# DBTITLE 1,Function to process multiple DEL XML read in parallel and merge all into a single DF
def process_multi_xml_del_parallel(df_files_meta):
  # Get all asset ids in a list
  assets_list = df_files_meta.select('asset_id').rdd.flatMap(lambda x: x).collect()
  # Parallelize the XML data read asset/file item wise and union all dataframes as part of reduce
  single_xml_rdds = map(lambda asset_item_id: read_del_xml(df_files_meta, asset_item_id), assets_list)
  df_final = reduce(lambda xml_df_1, xml_df_2: xml_df_1.unionByName(xml_df_2), single_xml_rdds)
  return df_final
# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)


# COMMAND ----------

dbutils.widgets.text("par_file_path","",label="par_file_path")
dbutils.widgets.text("par_input_file","",label="par_input_file")
dbutils.widgets.text("par_output_file","",label="par_output_file")

par_file_path = dbutils.widgets.get("par_file_path")
par_input_file = dbutils.widgets.get("par_input_file")
par_output_file = dbutils.widgets.get("par_output_file")

InputFile  = mountPoint +"/"+ par_file_path + "/" + par_input_file
outputFile = mountPoint +"/"+ par_file_path + "/" + par_output_file

# COMMAND ----------

from pyspark.sql.types import (StringType,IntegerType,StructType,StructField)
from pyspark.sql.functions import lit,row_number,col
from pyspark.sql.window import Window

#This function will use the Data and sheet# as input and append the new sheet into existing Output Excel File
def write_to_sheet(df,sheet_num):
      Sheet_Name ={"SheetName":sheet_num}
      df.write.format("com.crealytics.spark.excel")\
              .option("header", True)\
              .options(**Sheet_Name)\
              .mode("append")\
              .save(outputFile) 

#Read Input File 
df = spark.read.format("csv").option("header", True).load(InputFile)

#write to excel
write_to_sheet(df,1)

#Delete the Input file used
dbutils.fs.rm(InputFile)

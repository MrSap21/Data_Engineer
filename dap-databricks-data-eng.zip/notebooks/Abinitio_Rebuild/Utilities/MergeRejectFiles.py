# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60) 

# COMMAND ----------

import datetime
import os
from pyspark.sql.types import StructType,StructField, StringType
import subprocess, re
from functools import reduce


# COMMAND ----------

dbutils.widgets.text("AI_SERIAL","",label="AI_SERIAL")

AI_SERIAL=dbutils.widgets.get("AI_SERIAL")

# COMMAND ----------

def removePartFiles(ls_path):
  files = dbutils.fs.ls(ls_path)
  csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
  dbutils.fs.mv(csv_file, ls_path.rstrip('_rej')+".rej")
  dbutils.fs.rm(ls_path, recurse = True)  


# COMMAND ----------

ls_path = mountPoint+'/'+AI_SERIAL
dir_paths = dbutils.fs.ls(ls_path+'/copyactivity-logs')
files = [get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != ls_path]
df = reduce(lambda x,y: x.unionAll(y), 
            [sqlContext.read.format('com.databricks.spark.csv')
                       .load(f, header="true", inferSchema="true") 
             for f in files])
#df.show()
df.distinct().coalesce(1).write.options(header='true',delimiter=' ').format("csv").mode("overwrite").save(ls_path)
removePartFiles(ls_path)
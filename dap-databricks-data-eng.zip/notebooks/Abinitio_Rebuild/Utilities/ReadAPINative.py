# Databricks notebook source
#Notebook to POST API request and get the unprocessed file details
dbutils.widgets.text("PAR_READAPI_KEY","feednames")
dbutils.widgets.text("PAR_READAPI_VALUE","")
dbutils.widgets.text("PAR_READAPI_URL","")
dbutils.widgets.text("PAR_RETURN_FILE_TYPE","O")
# COMMAND ----------
import requests,json,os
import pandas as pd
import time
from itertools import groupby

#Get the request object key,value and API url
key = dbutils.widgets.get("PAR_READAPI_KEY")
value = dbutils.widgets.get("PAR_READAPI_VALUE")
url = dbutils.widgets.get("PAR_READAPI_URL")
filetype = dbutils.widgets.get("PAR_RETURN_FILE_TYPE")
values = value.split(",")

#Create body for API request
def readApi(url, key, value):
    values = value.split(",")
    body=json.dumps({key:values})
    headers={'Content-Type': 'application/json'}
    response = requests.post(url,data = body,headers=headers)
    print("Response text:- "+response.text)
    print("Status code:-")
    print(response.status_code)
    response_list = []
    if (response.status_code == 200):
       if response.text != 'No Records Found!':
          response_list = json.loads(response.text)
    return (response.status_code, response_list)

  # Retry the call for 3 times from API before exit
retry_count = 0;
status_code = 0;
response_list = []
while retry_count  < 3:
      (status_code,response_list) = readApi(url, key, value)
      retry_count = retry_count + 1
      if status_code == 200:
         break;
      print("retry")
      time.sleep(4)
print(response_list)

# COMMAND ----------
output = {}
if(filetype=="A"):
  sortedList = sorted(response_list, key=lambda response_list: response_list['feedname'])
  for k,v in groupby(sortedList, lambda response_list: response_list['feedname']):  
    output[k] = [{'assetid': i['assetid'], 'assetname': i['assetname'], 'assetcurrentlocation': i['assetcurrentlocation']} for i in list(v)]
else:
  if(filetype=="N"):
    sortedList = sorted(response_list, key=lambda response_list: (response_list['feedname'], response_list['assetid']), reverse=True)
    for k,v in groupby(sortedList, lambda response_list: response_list['feedname']): 
      out = list(v)[0]
      output[k] = {'assetid': out['assetid'], 'assetname': out['assetname'], 'assetcurrentlocation': out['assetcurrentlocation']}
  else:
    sortedList = sorted(response_list, key=lambda response_list: (response_list['feedname'], response_list['assetid']))
    for k,v in groupby(sortedList, lambda response_list: response_list['feedname']): 
      out = list(v)[0]
      output[k] = {'assetid': out['assetid'], 'assetname': out['assetname'], 'assetcurrentlocation': out['assetcurrentlocation']}


if output == {}:
  raise Exception("ERROR: ReadAPI Returning Empty Response For Given Feed")
  
dbutils.notebook.exit(output)
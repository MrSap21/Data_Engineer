# Databricks notebook source
#Imports
from pyspark.sql.functions import *

# COMMAND ----------

#Func to replace single backslash with double backslash
def escape_slash(df_input):
  df_output = df_input.select([regexp_replace(col(_col),"\\\\","\\\\\\\\").alias(_col) for _col in df_input.columns])
  return df_output

# COMMAND ----------

#Func to trim extra spaces in all columns
def trim_column(df_input):
  df_output = df_input.select([trim(col(_col)).alias(_col) for _col in df_input.columns])
  return df_output

# COMMAND ----------

# Function to write a dataframe to a specified path with format and mode mentioned (or default in case not provided)
def write_data(df_input, output_path, write_format='parquet', write_mode='overwrite'):
  df_input.write \
          .format(write_format) \
          .mode(write_mode) \
          .save(output_path)

# COMMAND ----------

# Function to union all columns for two dataframes
def custom_union(df1, df2):
    cols1 = df1.columns
    cols2 = df2.columns
    total_cols = sorted(cols1 + list(set(cols2) - set(cols1)))
    def expr(mycols, allcols):
        def process_cols(colname):
            if colname in mycols:
                return colname
            else:
                return lit("").alias(colname)
        cols = map(process_cols, allcols)
        return list(cols)
    appended = df1.select(expr(cols1, total_cols)).union(df2.select(expr(cols2, total_cols)))
    return appended

# COMMAND ----------

# Function to validate input parameters
## Input: Parameters in a dict as -- key: param_name & value: param_value
## Returns: None
## Throws Exception: If at least one input value is either None/Null or Empty
def validate_inputs(params_dict):
  def _check_params(_dict):
    def _validate(_key):
      if type(_dict[_key]) is str:
        if _dict[_key] is None or (not _dict[_key].strip()):
          return _key
      else:
        if _dict[_key] is None:
          return _key
    out_list_w_None = list(map(_validate, params_dict.keys()))
    out_list = [_item for _item in out_list_w_None if _item is not None]
    return out_list
  missing_params_list = _check_params(params_dict)
  if len(missing_params_list):
    err_msg = 'ERROR: INPUT PARAMETERS ARE EITHER NULL OR EMPTY: ' + ','.join(missing_params_list)
    raise Exception(err_msg)
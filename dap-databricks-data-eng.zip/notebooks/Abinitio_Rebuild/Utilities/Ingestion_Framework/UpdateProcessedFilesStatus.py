# Databricks notebook source
# Declare variables 
pJobName = dbutils.widgets.get("PAR_PIPELINE_NAME")
pUpdateAssetAPI = dbutils.widgets.get("PAR_WRITEAPI_URL")
pFeedNames = dbutils.widgets.get("PAR_FEED_NAMES").split(",")
pAssetStatus = dbutils.widgets.get("PAR_ASSET_STATUS")
pSQLServer = dbutils.widgets.get("PAR_SQL_SERVER")
pSQLServerDB = dbutils.widgets.get("PAR_SQL_SERVER_DB")
pSQLServerClientID = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_ID")
pSQLServerClientSecret = dbutils.widgets.get("PAR_SQL_SERVER_AD_CLIENT_SECRET")

# COMMAND ----------

# Connect to Azure SQL Server
import pyodbc 
import os
import adal

conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                      f'Server={pSQLServer};'
                      f'Database={pSQLServerDB};'
                      f'UID={dbutils.secrets.get(scope="dapadbscope",key=pSQLServerClientID)};'
                      f'PWD={dbutils.secrets.get(scope="dapadbscope",key=pSQLServerClientSecret)};'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )
cursor = conn.cursor()


# COMMAND ----------

import requests
import json
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

def update_asset_ingfr(list_assets_to_close, pUpdateAssetAPI, pAssetStatus):
    # defining the api-endpoint
    API_ENDPOINT = pUpdateAssetAPI

    # data to be sent to api
    body = json.dumps({"assetId": list_assets_to_close, "statusId": pAssetStatus})

    # sending post request and saving response as response object
    headers = {'Content-Type': 'application/json'}

    # configure retries
    retry_strategy = Retry(
        total=5,
        status_forcelist=[429, 500, 502, 503, 504],
        method_whitelist=["POST", "PUT", "GET", "DELETE"]
    )

    adapter = HTTPAdapter(max_retries=retry_strategy)
    http = requests.Session()
    http.mount("https://", adapter)
    http.mount("http://", adapter)

    print(f"Calling endpoint: {API_ENDPOINT}")
    print(f"Payload: {body}")

    response = http.post(API_ENDPOINT, data=body, headers=headers)

    if response.status_code != requests.codes.ok:
        raise "Not able to update asset ids " + list_assets_to_close + ". Response: " + response.history

# Method responsible for retrieving job-feed mapping
def get_job_map(pJobName, pFeedName):
    feed_job_map_id = cursor.execute(
        (
            "select map.feed_job_id  "
            "from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] map "
            "inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on map.job_id = jobs.job_id "
            "where jobs.job_name = ? "
            "and map.feed_name = ? "
        ), (pJobName, pFeedName)).fetchone()

    return feed_job_map_id
  
# Method responsible for checking what assets of a feed can be closed based on the status of the pipelines which depend on it
def update_asset_status(feedName, pJobName, pJobFeedMap, pUpdateAssetAPI, pAssetStatus):

    # Update asset status for this job
    cursor.execute(
        (
            '''update [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution]
               set close_job_dttm = getdate()
               where feed_job_id = ?
               and close_job_dttm is null
            '''
        ), (pJobFeedMap))
    
    # Get number of jobs depending on the feed
    feed_dependencies_count = cursor.execute(
        (
            '''select count(distinct job_name) dependencies
               from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] mp
               inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on mp.job_id = jobs.job_id
               where feed_name = ?'''
        ), (feedName)).fetchone()

    print(f"Number of dependencies mapped to feed {feedName}: {feed_dependencies_count[0]}")

    # For a asset, get how many jobs which depend on it have been successfully completed
    jobs_completed_successfully = cursor.execute(
        (
          '''select ex.asset_id, count(distinct jobs.job_id) dependencies_successfully_executed
             from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] mp
             inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on mp.job_id = jobs.job_id
             inner join [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] ex on ex.feed_job_id = mp.feed_job_id
             where mp.feed_name = ?
             and ex.close_job_dttm is not null
             and ex.close_asset_dttm is null
             group by asset_id'''
        ), (feedName)).fetchall()

    list_assets_to_close = []
    for row_by_asset in jobs_completed_successfully:
        asset_id = row_by_asset[0]
        jobs_executed_count = row_by_asset[1]
        print(f"For asset {asset_id}, {jobs_executed_count} job(s) have been successfully executed")

        # If all dependencies have been successfully executed, then set the asset to be updated
        if jobs_executed_count == feed_dependencies_count[0]:
            print(f"Adding asset {asset_id} to the list of assets to be closed")
            list_assets_to_close.append(asset_id)

    # Close assets
    if list_assets_to_close:
        # Close assets in Ingestion Framework
        print(f"Assets to be closed: {list_assets_to_close}")
        update_asset_ingfr(list_assets_to_close, pUpdateAssetAPI, pAssetStatus)
        print(f"Assets successfully closed")
    else:
        print(f"No assets are ready to be closed")
    cursor.commit()

# COMMAND ----------

for feedName in pFeedNames:
    print(f"Job {pJobName} to start closing assets for feed: {feedName}")
    feed_job_map = get_job_map(pJobName,feedName)

    if feed_job_map:
        update_asset_status(feedName, pJobName, feed_job_map[0], pUpdateAssetAPI, pAssetStatus)
    else:
        raise Exception("INGESTION FRAMEWORK ERROR: Feed " + feedName + " is not mapped to job " + pJobName)
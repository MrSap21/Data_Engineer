# Databricks notebook source
# Notebook for mounting ADLS for L4_CUSTOMER_DIM: A CCPA/SPL Right to Access dependency 

# mounting point

mountPoint = "/mnt/l4_customer_dim"
l4Source ='abfss://l4-customer-dim@proddseus2fosfs01.dfs.core.windows.net'


# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapadbscope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapadbscope",key="dapdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapadbscope",key="adtenantid")
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = l4Source, ##dbutils.secrets.get(scope="dapadbscope",key="dapadlswrngurl"),
    mount_point = mountPoint,
    extra_configs = configs)  
  
dbutils.notebook.exit(mountPoint)

# Databricks notebook source
#Writingto file in parquet format

data_location_output = dbutils.widgets.get("file_path")
global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")
df = table(global_temp_db + "." + dbutils.widgets.get("view_name"))

df.write.format("parquet").mode("overwrite").save(data_location_output)

spark.catalog.dropGlobalTempView(dbutils.widgets.get("view_name"))

dbutils.notebook.exit(True)

# COMMAND ----------



# Databricks notebook source
import json
import logging
import os
import requests
import time
from typing import Dict, List, Set

logging.basicConfig(format='[%(levelname)s] %(asctime)s :%(message)s', datefmt='%d-%b-%y %H:%M:%S')

# logging.basicConfig(level=logging.INFO)
dbutils.widgets.text("PAR_FEED_NAME", "")
dbutils.widgets.text("PAR_FEED_NAME_ADDTL", "")
dbutils.widgets.text("PAR_READAPI_URL", "")
dbutils.widgets.text("PAR_READAPI_KEY", "feedNames")
dbutils.widgets.text("TIMER", "10800")
dbutils.widgets.text("CYCLE_TIMER", "30")


PAR_FEED_NAME = dbutils.widgets.get("PAR_FEED_NAME")
if dbutils.widgets.get("PAR_FEED_NAME_ADDTL") != "":
  PAR_FEED_NAME = f"{PAR_FEED_NAME},{dbutils.widgets.get('PAR_FEED_NAME_ADDTL')}"

PAR_READAPI_URL = dbutils.widgets.get("PAR_READAPI_URL")
PAR_READAPI_KEY = dbutils.widgets.get("PAR_READAPI_KEY")

timer = int(dbutils.widgets.get("TIMER"))
cycle_timer = int(dbutils.widgets.get("CYCLE_TIMER"))

# COMMAND ----------

class ControlChecker:
    def __init__(self, value: str = None, url: str = None, key: str = None, control_file_pattern: str = '_control', low_memory_flag: bool = True):
        logging.warning('ControlChecker initialized ============================================================================================================')
        self.key: str = key
        self.values: List = value
        self.url: str = url
        self.control_file_pattern: str = control_file_pattern
        self.low_memory_flag: bool = low_memory_flag
        self.status_report: Dict = {}
        self.control_file_set: Set = control_file_pattern
        self.control_files_not_found_output: Set = set()
        self.api = url
        self.response_json: List = self.api
        self.data: Dict = { 'assetid': [], 'assetname': [], 'assetname_normalized_no_ext': [], 'assetname_normalized': [], 'assetcurrentlocation': [], 'feedname': [], 'controlFlag': [] }
        self.control_files_found: Set = self.data
        self.control_files_existence_check: bool = self.control_files_found
        self.file_collection_check: bool = self.data
        
    def status(self, detailed: bool = False) -> None:
        if not self.low_memory_flag:
            if not self.control_files_existence_check:
                logging.warning(f"Some control files given in the feednames values are not present in the ReadAPI response: {self.control_files_not_found_output}")
            
            if not self.file_collection_check:
                if detailed:
                    logging.warning(f"{json.dumps(self.status_report, indent=4)}")
                else:
                    output = {}
                    for k,v in self.status_report.items():
                        if v['percent_collected'] < 1: 
                            output[k] = v
                    logging.warning(f"{json.dumps(output, indent=4)}")
        else:
            logging.warning("No Status Report option when low_memory_flag is set to True")
            
    @property
    def values(self) -> List:
        return self._values

    @values.setter
    def values(self, var: str) -> None:
        # set a list of the given feed names, which should be an input string of comma delimited values
        self._values = var.split(",")

    @property
    def control_file_set(self) -> Set:
        return self._control_file_set

    @control_file_set.setter
    def control_file_set(self, control_file_pattern: str) -> None:
        # create a set that contains all expected control files
        self._control_file_set = set([s if s.strip().lower().endswith(control_file_pattern) else "" for s in self.values])
        self._control_file_set.remove("")

    @property
    def api(self) -> requests.models.Response:
        return self._api

    @api.setter
    def api(self, url: str) -> None:
        # Send our ReadAPI Request
        self._api = requests.post(
            url,
            data=json.dumps({"feedNames": self.values}),
            headers={"Content-Type": "application/json"}
        )
        logging.info(f"API Response Status Code: {self._api.status_code}")

    @property
    def response_json(self) -> List:
        return self._response_json

    @response_json.setter
    def response_json(self, api_response) -> None:
        # parse JSON Object from API Response. This will return a list of dictionaries.
        self._response_json = {}
        if api_response.status_code == 200:
            if api_response.text != 'No Records Found!':
                self._response_json = json.loads(api_response.text)
            else:
                logging.warning('API Returning no files for given feed names.')
                self._response_json = [{'assetid':'', 'assetname':'', 'feedname':'', 'assetcurrentlocation': ''}]
        else:
            logging.warning('API Returning non-200 status code. Throwing Exception.')


    @property
    def data(self) -> Dict:
        return self._data

    @data.setter
    def data(self, data_struct: Dict) -> None:
        # parse JSON Object from API Response into an efficiently scanned dict object. also useful to troubleshoot with
        self._data = data_struct
        if self._response_json != [{}]:
            # transpose for easier lookup
            for resp in self._response_json:
                self._data['assetid'].append(resp.get('assetid'))
                self._data['assetname'].append(resp.get('assetname'))
                self._data['assetname_normalized'].append(f"{'_'.join(resp.get('assetname').split('_')[:-1])}.dsv")
                self._data['assetname_normalized_no_ext'].append(f"{'_'.join(resp.get('assetname').split('_')[:-1])}")
                self._data['assetcurrentlocation'].append(resp.get('assetcurrentlocation'))
                self._data['feedname'].append(resp.get('feedname'))
                if resp.get('feedname').endswith(self.control_file_pattern):
                    self._data['controlFlag'].append(True)
                else: 
                    self._data['controlFlag'].append(False)

    @property
    def control_files_found(self) -> Set:
        return self._control_files_found

    @control_files_found.setter
    def control_files_found(self, data: Dict) -> None:
        # create a set that contains all expected control files
        if len(data['controlFlag']) > 0:
            self._control_files_found = set([data['feedname'][i] if v == True else "" for i, v in enumerate(data['controlFlag'])])
            self._control_files_found.remove("")
        else:
            logging.warning('No items from the api response to create a control files found set')


    @property
    def control_files_existence_check(self) -> bool:
        return self._control_files_existence_check

    @control_files_existence_check.setter
    def control_files_existence_check(self, control_files_found: Set) -> None:
        # create a set that contains all expected control files
        if self.control_file_set == control_files_found:
            self._control_files_existence_check = True
        else:
            self._control_files_existence_check = False
            self.control_files_not_found_output = self.control_file_set.difference(self.control_files_found)
            

    @property
    def file_collection_check(self) -> bool:
        return self._file_collection_check

    @file_collection_check.setter
    def file_collection_check(self, data: Dict) -> None:
        # are all files listed in control files present and ready for ingestion?
        self._file_collection_check = True
        for i, chk in enumerate(data.get('controlFlag')):
            if chk == True:
                try:
                    cntrl_file_path = f"/dbfs/mnt/wrangled/{data['assetcurrentlocation'][i]}{data['assetname'][i]}".replace('//', '/')
                    with open(cntrl_file_path, 'r') as f:
                        files = [line.split('/')[-1].replace('\n', '') for line in f.read().split(',')]
                    
                    if not self.low_memory_flag:
                        collected = 0
                        file_count = len(files)
                        self.status_report[data['assetname'][i]] = { 'control_feed': data['feedname'][i], 'control_asset_id': data['assetid'][i], 'file_count': file_count, 'percent_collected': 0.00, 'collected': [], 'missing': []}
                    
                    for file in files:
                        file = file.split('.')[0]
                        if file not in data['assetname'] and file not in data['assetname_normalized'] and file not in data['assetname_normalized_no_ext']:
                            logging.debug(f"Control File: {data['assetname'][i]}, Missing File: {file}")
                            if not self.low_memory_flag:
                                # data collection for reporting status:
                                self.status_report[data['assetname'][i]]['missing'].append(file)
                            self._file_collection_check = False
                        else:
                            if not self.low_memory_flag:
                                # if file not in data['assetname'] and file in data['assetname_normalized']:
                                #     self.status_report[data['assetname'][i]]['suffix_issue'].append(file)
                                collected+=1
                                self.status_report[data['assetname'][i]]['percent_collected'] = collected/file_count
                                self.status_report[data['assetname'][i]]['collected'].append(file)
                        
                except Exception as e:
                    logging.error(f"[FATAL] File not found or could not access file: {cntrl_file_path}")
                    self._file_collection_check = False
                    pass

    @staticmethod
    def wait(timer: int = 3000, cycle_timer: int = 30):
      # helper method to sleep breifly
      logging.debug(f"Sleeping for {cycle_timer} seconds. There are {timer/60} minutes of idle time remaining.")
      time.sleep(cycle_timer)
      timer = timer - cycle_timer
      return timer
    
    
# =====================================================================================================================================================================
# invoke ControlChecker obj
# =====================================================================================================================================================================

while timer > 0:
  control_check = ControlChecker(
      value=PAR_FEED_NAME,
      url=PAR_READAPI_URL,
      key=PAR_READAPI_KEY,
      control_file_pattern="_control",
      low_memory_flag=False,
  )
  logging.warning(f"Control Files Check:       {control_check.control_files_existence_check}")
  logging.warning(f"File Collection Check:     {control_check.file_collection_check}")
  if control_check.control_files_existence_check and control_check.file_collection_check:
    logging.warning('All files ready for processing')
    dbutils.notebook.exit(True)
  else:
    control_check.status()
    if (timer - cycle_timer) > 0:
      timer = ControlChecker.wait(timer=timer, cycle_timer=cycle_timer)
      del control_check
    else:
      timer = -1
      logging.warning('Time out value reached. Shutting Down.')
      raise Exception(f"Time out value reached. Shutting Down. Files have not arrived for the given Feeds/Control Feeds within {int(dbutils.widgets.get('TIMER'))/60/60} Hour Limit.")
#       dbutils.notebook.exit(False) 


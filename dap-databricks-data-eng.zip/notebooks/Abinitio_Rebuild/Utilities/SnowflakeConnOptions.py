# Databricks notebook source
#Create the notebook parameters

#dbutils.widgets.text("SNOWFLAKE_DATABASE", "")
#dbutils.widgets.text("SNOWFLAKE_WAREHOUSE", "")

# COMMAND ----------

import os
import re
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import serialization

password=dbutils.secrets.get(scope = "dapadbscope", key = "dapsfprivatekey") # dapdevdbrauthn

val1 = bytearray(re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",password).replace("\\n","\n").encode())

p_key = serialization.load_pem_private_key(
    val1,
    password = None,#'devsnowcli'.encode(),
    backend = default_backend()
    )

pkb = p_key.private_bytes(
  encoding = serialization.Encoding.PEM,
  format = serialization.PrivateFormat.PKCS8,
  encryption_algorithm = serialization.NoEncryption()
  )

pkb = pkb.decode("UTF-8")
pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",pkb).replace("\\n","")
options = {
  "sfURL":dbutils.secrets.get(scope= "dapadbscope", key= "dapsfurl"),
  "sfUser" : dbutils.secrets.get(scope= "dapadbscope", key= "dapsfsparkusername"),
  "pem_private_key" : pkb,
  "sfDatabase" : dbutils.widgets.get("SNOWFLAKE_DATABASE"), #"DEV_ETL",
  #"sfSchema" : "PRDETLSAND01",
  "sfWarehouse" : dbutils.widgets.get("SNOWFLAKE_WAREHOUSE"), #"WBADEVDBENGINEER_WH",
  #"sfRole" : "PUBLIC"
  #"sfRole" : "WBADEVDBENGINEER_ROLE"
}

# df = spark.read.format("snowflake").options(**sfOptions).option("query", "select count(*) from PRDETLSAND01.PROC_CNTRL_BATCH_DETAIL").load()
# df.show()

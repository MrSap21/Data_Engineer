# Databricks notebook source
#Notebook to POST API request and get the unprocessed file details
dbutils.widgets.text("PAR_RETURN_FILE_TYPE","O")

import requests,json,os
import pandas as pd
import time
#Get the request object key,value and API url
key = dbutils.widgets.get("PAR_READAPI_KEY")
value = dbutils.widgets.get("PAR_READAPI_VALUE")
url = dbutils.widgets.get("PAR_READAPI_URL")
filetype = dbutils.widgets.get("PAR_RETURN_FILE_TYPE")
values = value.split(",")

#Create body for API request
def readApi(url, key, value):
    values = value.split(",")
    body=json.dumps({key:values})
    headers={'Content-Type': 'application/json'}
    response = requests.post(url,data = body,headers=headers)
    print("Response text:- "+response.text)
    print("Status code:-")
    print(response.status_code)
    response_list = []
    if (response.status_code == 200):
       if response.text != 'No Records Found!':
          response_list = json.loads(response.text)
    return (response.status_code, response_list)

  # Retry the call for 3 times from API before exit
retry_count = 0;
status_code = 0;
response_list = []
while retry_count  < 3:
      (status_code,response_list) = readApi(url, key, value)
      retry_count = retry_count + 1
      if status_code == 200:
         break;
      print("retry")
      time.sleep(4)


#Create Dataframe from the response object
assetid = []
assetname = []
assetcurrentlocation = []
feedname = []
for dict in response_list:
  assetid.append(dict.get('assetid'))
  assetname.append(dict.get('assetname'))
  assetcurrentlocation.append(dict.get('assetcurrentlocation'))
  feedname.append(dict.get('feedname'))
entire_dict = {'assetid':assetid, 'assetname':assetname, 'assetcurrentlocation':assetcurrentlocation, 'feedname':feedname}
print(entire_dict)

# COMMAND ----------

dataframe_table = pd.DataFrame(entire_dict)
# display(dataframe_table)
df = spark.createDataFrame(dataframe_table)

if(filetype=="N"):
  #Pick the newest file for the input FeedNames
  df2 = df.groupBy('feedname').max('assetid').withColumnRenamed('max(assetid)','assetid')
  act_df = df.join(df2,"assetid").drop(df2.feedname)
  #Pass the dictionary to Pipeline
  end_result = act_df.toPandas().set_index('feedname').T.to_dict('dict')
  
elif(filetype=="A"):
  #Pick All unprocessed files for the input FeedNames
  #Pass the dictionary to Pipeline
  end_result = df.toPandas().set_index('feedname').groupby('feedname').apply(lambda x:x.to_dict('r')).to_dict()
  
else: 
  #Pick the oldest file for the input FeedNames
  df2 = df.groupBy('feedname').min('assetid').withColumnRenamed('min(assetid)','assetid')
  act_df = df.join(df2,"assetid").drop(df2.feedname)
  #Pass the dictionary to Pipeline
  end_result = act_df.toPandas().set_index('feedname').T.to_dict('dict')
  
dbutils.notebook.exit(end_result)

# COMMAND ----------


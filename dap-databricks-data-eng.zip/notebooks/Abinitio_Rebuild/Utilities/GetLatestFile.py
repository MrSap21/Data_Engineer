# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)


# COMMAND ----------

import datetime
import os
from pyspark.sql.types import StructType,StructField, StringType

# COMMAND ----------

dbutils.widgets.text("AI_SERIAL","",label="AI_SERIAL")
dbutils.widgets.text("FILE_PATTERN","",label="FILE_PATTERN")
dbutils.widgets.text("FILE_EXTENSION","",label="FILE_EXTENSION")

AI_SERIAL=dbutils.widgets.get("AI_SERIAL")
FILE_PATTERN=dbutils.widgets.get("FILE_PATTERN")
FILE_EXTENSION=dbutils.widgets.get("FILE_EXTENSION")

# COMMAND ----------

def file_exists(filename):
  try:
    if dbutils.fs.ls('dbfs:/mnt/wrangled/'+filename)[0][-1]>0:
      return True
    else:
      return False
  except:
    return False
  
def get_latest_file(path,pattern,extension):
  files=[]
  for file in os.listdir(path):
    if file.startswith(pattern) and file.endswith(extension):
      files.append(file)
  latest_file=files[0]
  latest=latest_file
  for file in files:
    if os.path.getctime(path+file)>os.path.getctime(path+latest_file):
      latest=file
  return latest


# COMMAND ----------

LATEST_FILE=''
LATEST_FILE=get_latest_file('/dbfs/mnt/wrangled/'+AI_SERIAL+'/',FILE_PATTERN,FILE_EXTENSION) 
dbutils.notebook.exit(LATEST_FILE)

# COMMAND ----------



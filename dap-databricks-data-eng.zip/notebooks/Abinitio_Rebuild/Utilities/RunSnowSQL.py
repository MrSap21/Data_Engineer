# Databricks notebook source
# dbutils.widgets.text("transaction","")
# dbutils.widgets.text("query","")

# COMMAND ----------

# import the snowflake.connector package
import snowflake.connector
import os
import re
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import serialization

password=dbutils.secrets.get(scope = "dapadbscope", key = "dapsfprivatekey") #"dapdevdbrauthn")

val1 = bytearray(re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",password).replace("\\n","\n").encode())

p_key = serialization.load_pem_private_key(
    val1,
    password = None,#'devsnowcli'.encode(),   
    backend = default_backend()
    )

pkb = p_key.private_bytes(
  encoding = serialization.Encoding.DER,
  format = serialization.PrivateFormat.PKCS8,
  encryption_algorithm = serialization.NoEncryption()
  )

v_autocommit = False 

if dbutils.widgets.get("transaction").lower() == "false":
  print("Auto Commit True")
  v_autocommit = True

with snowflake.connector.connect(
  user=	dbutils.secrets.get(scope= "dapadbscope", key= "dapsfpythonusername"),
  account=dbutils.secrets.get(scope='dapadbscope', key='dapsfshortaccountname'), #"wba_rpu_nprod_datainsight_01.east-us-2.privatelink",
  password=dbutils.secrets.get(scope='dapadbscope', key='dapsfpassword'),#pkb,
  database=dbutils.widgets.get("SNOWFLAKE_DATABASE"), #"DEV_ETL",
  #schema="PRDETLSAND01",
  warehouse=dbutils.widgets.get("SNOWFLAKE_WAREHOUSE"),#"WBADEVDBENGINEER_WH",
  #role="WBADEVDBENGINEER_ROLE",
  autocommit=v_autocommit
  ) as con:
  con.execute_string(dbutils.widgets.get("query").replace ("\\'", "'"))

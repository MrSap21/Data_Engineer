# Databricks notebook source
# Public variables

var_Input_File_Path = dbutils.widgets.get('PAR_DB_INPUT_PATH')
v_delimiter = dbutils.widgets.get('PAR_DB_DELIMITER').encode('utf-8').decode('unicode-escape')
v_numColumns = int(dbutils.widgets.get('PAR_DB_NUMBER_OF_COLUMNS'))

# COMMAND ----------

# Load File

df = spark.read.format("text")\
      .option("header", False)\
      .load(var_Input_File_Path)

# COMMAND ----------

# Split based on delimiter provided

from pyspark.sql.functions import *
df1 = df.withColumn("AllColumns", split("value", v_delimiter)).drop("value")

# COMMAND ----------

# Explode the entire data into a column

df2 = df1.select(explode('AllColumns'))

# COMMAND ----------

# Pivot data to desired format based on number of columns provided

dfResult = df2.withColumn('id', monotonically_increasing_id()).withColumn('id2', (col('id') / v_numColumns).cast('int')).withColumn('id3', col('id') % v_numColumns).groupBy('id2').pivot('id3').agg(first('col')).orderBy('id2').drop('id2')

# COMMAND ----------

dfResult.createOrReplaceGlobalTempView(dbutils.widgets.get("PAR_RESULT_VIEW"))
dbutils.notebook.exit(dbutils.widgets.get("PAR_RESULT_VIEW"))
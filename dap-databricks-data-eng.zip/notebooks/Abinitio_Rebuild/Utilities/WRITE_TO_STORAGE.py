# Databricks notebook source
data_location_output = dbutils.widgets.get("file_path")

global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")

df = table(global_temp_db + "." + dbutils.widgets.get("view_name"))

df.coalesce(1).write.options(header=dbutils.widgets.get("has_header"), delimiter = dbutils.widgets.get("delimiter")).format("csv").mode("overwrite").save(data_location_output)

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + "." + dbutils.widgets.get("file_extention"))
dbutils.fs.rm(data_location_output, recurse = True)

spark.catalog.dropGlobalTempView(dbutils.widgets.get("view_name"))
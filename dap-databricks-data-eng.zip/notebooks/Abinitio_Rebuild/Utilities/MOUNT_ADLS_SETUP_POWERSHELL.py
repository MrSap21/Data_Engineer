# Databricks notebook source
# Common notebook for mounting ADLS

# mounting point

mountPoint = "/mnt/utility_powershell"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapadbscope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapadbscope",key="dapdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapadbscope",key="adtenantid")
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = dbutils.secrets.get(scope="dapadbscope",key="dapadlsutlpowershellurl"),
    mount_point = mountPoint,
    extra_configs = configs)  
  
dbutils.notebook.exit(mountPoint)
# Databricks notebook source
mountPointA = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP",60)
mountPoint = dbutils.notebook.run("../../Abinitio_Rebuild/Utilities/GEN_MOUNT_ADLS_CONTAINER",60,{"PAR_MOUNT_POINT":"/mnt/utility"})
input_path = dbutils.widgets.get("PAR_FILE_PATH")
input_file = dbutils.widgets.get("PAR_FILE_NAME")


# COMMAND ----------

import os.path
from pathlib import Path
def pathValidation(fpath):
  if(os.path.exists(fpath)):
     print(fpath)
     print("Already present!")
  else:
    Path(fpath).mkdir(parents=True, exist_ok=True)
    print(fpath)
    print("Directory craeted successfully!")

# COMMAND ----------

filePath="/dbfs/mnt/utility_main"+input_path+"/"+input_file
file=open(filePath,'r')
lines=file.readlines()
for line in lines:
  folderPath=line.rstrip()
  pathValidation(folderPath)
  

# COMMAND ----------

# MAGIC %sh
# MAGIC ls /dbfs/mnt/wrangled/

# COMMAND ----------


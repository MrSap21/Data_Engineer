// Databricks notebook source

dbutils.widgets.text("PAR_DB_AI_SERIAL","",label="PAR_DB_AI_SERIAL")
dbutils.widgets.text("PAR_DB_OUT_FILE","",label="PAR_DB_OUT_FILE")
dbutils.widgets.text("PAR_DB_BATCH_ID","",label="PAR_DB_BATCH_ID")
dbutils.widgets.text("PAR_DB_OUT_DELIMITER","",label="PAR_DB_OUT_DELIMITER")
dbutils.widgets.text("PAR_DB_QUERY","",label="PAR_DB_QUERY")
dbutils.widgets.text("PAR_DB_OUT_DELIMITER","",label="PAR_DB_OUT_DELIMITER")
dbutils.widgets.text("PAR_DB_OUT_FORMAT","",label="PAR_DB_OUT_FORMAT")
dbutils.widgets.text("PAR_DB_PSET","",label="PAR_DB_PSET")
dbutils.widgets.text("PAR_DB_CONTAINERNAME","",label="PAR_DB_CONTAINERNAME")

// COMMAND ----------

 var outputFilePath = dbutils.widgets.get("PAR_DB_AI_SERIAL")
 var outputFileName = dbutils.widgets.get("PAR_DB_OUT_FILE")
 var outputbatchid = dbutils.widgets.get("PAR_DB_BATCH_ID")
 var outputDelimiter = dbutils.widgets.get("PAR_DB_OUT_DELIMITER")
 var query = dbutils.widgets.get("PAR_DB_QUERY")
 var outputformat= dbutils.widgets.get("PAR_DB_OUT_FORMAT")
var pset=dbutils.widgets.get("PAR_DB_PSET")
var adlsInputContainerName=dbutils.widgets.get("PAR_DB_CONTAINERNAME")



// COMMAND ----------

import org.apache.spark.sql.types.{StructType, StructField, StringType, IntegerType};
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}


def writeToADLS(df:DataFrame,containerName:String,filePath:String,fileName:String, intermediateformat:String,FinalForamt:String, delimiter:String,mode:String ="overwrite"):Integer={
  
  df.coalesce(1)
     .write
     .format(intermediateformat)
     .mode(mode)
     .option("delimiter",delimiter)
     .save("/mnt/" + containerName + "/" + filePath + "/" + fileName + "." + intermediateformat)
  
  val partition_path = dbutils.fs.ls("/mnt/" +  containerName+ "/" + filePath + "/"+ fileName + "."+intermediateformat)
                                    .filter(file=>file.name.endsWith(".csv"))(0).path

  print("path "+partition_path)
  dbutils.fs.cp(partition_path,"/mnt/"  + containerName + "/"+filePath + "/"+ fileName + "." + FinalForamt)
  dbutils.fs.rm( "/mnt/" + containerName + "/"+filePath + "/"+ fileName +"."+intermediateformat,recurse=true)
  
  return 0
  
}

// COMMAND ----------

import com.microsoft.aad.adal4j.{AuthenticationContext, ClientCredential}
import org.apache.spark.sql.SparkSession
import java.util.concurrent.Executors

val url = "jdbc:sqlserver://dapdevsqldwhsrv01.database.windows.net:1433;databaseName=dapdevdwh01"
val dbTable = "dbo.DNADEVEDWDB01__PATIENT_ADDRESS_bkp" //Replace with your database table
outputformat
val principalClientId = "3c3353bc-a254-4cb0-abbc-51ec3852c7c5"
val principalSecret = dbutils.secrets.get(scope = "dapdevdataenggscope", key = "devdnasynapse")
val TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"

val authority = "https://login.windows.net/" + TenantId
val resourceAppIdURI = "https://database.windows.net/"

val service = Executors.newFixedThreadPool(1)
val context = new AuthenticationContext(authority, true, service);
val ClientCred = new ClientCredential(principalClientId, principalSecret)
val authResult = context.acquireToken(resourceAppIdURI, ClientCred, null)
val accessToken = authResult.get().getAccessToken

// COMMAND ----------

// MAGIC %scala
// MAGIC 
// MAGIC var jdbcDF = spark.read
// MAGIC     .format("com.microsoft.sqlserver.jdbc.spark")
// MAGIC     .option("url", url)
// MAGIC     .option("accessToken", accessToken)
// MAGIC     .option("encrypt", "true")
// MAGIC     .option("hostNameInCertificate", "*.database.windows.net")
// MAGIC     .option("query",query)
// MAGIC     .load()
// MAGIC //display(jdbcDF)

// COMMAND ----------





if(pset=="edw_idl_customer_segment_cdi_cif_emnos_customer_segment_rej.pset" || pset=="edw_idl_customer_segments_cdi_cif_customer_segment_rej.pset")
{
  //Do nothing
}

else if(pset=="edw_idl_customer_segments_emnos_customer_link_lty_rej.pset"||pset=="edw_idl_customer_segments_emnos_customer_link_mid_rej.pset")
{
jdbcDF.withColumn("edw_rec_begin_dt",regexp_replace(jdbcDF("edw_rec_begin_dt"), "-", ""))
}
else
{
val trimColumns=jdbcDF.schema.fields.filter(_.dataType.isInstanceOf[StringType])

trimColumns.foreach(f=>{jdbcDF=jdbcDF.withColumn(f.name,ltrim(jdbcDF(f.name)))
})
}
//jdbcDF.show()
//display(jdbcDF)

// COMMAND ----------

 var outputFile = outputFileName+"_"+outputbatchid

var writeInd = writeToADLS(jdbcDF,
                           adlsInputContainerName,
                           outputFilePath,
                           outputFile,
                           "csv",
                           outputformat,
                           outputDelimiter,
                           "overwrite")

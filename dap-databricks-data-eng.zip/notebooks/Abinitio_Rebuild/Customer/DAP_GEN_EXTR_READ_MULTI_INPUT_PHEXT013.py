# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)
mountPointSchema=dbutils.notebook.run(dbutils.widgets.get("pSCHEMA_MOUNT_PATH"),60)
#mountPointSchema=dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_SHELL",60)

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("pIN_FILE_LIST")
rddjson = sc.parallelize([inputFileList])
print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

#display(dfNamePath)

# COMMAND ----------

# Filter the latest files

from pyspark.sql.functions import col

EXTR_DTTM = dbutils.widgets.get("pEXTR_DTTM")

dfFiltered = dfNamePath\
             .withColumn("filedate", unix_timestamp(regexp_replace(reverse(split(reverse(col("filename")), "_")[0]), ".dat", ""), "yyyyMMddHHmmss").cast("timestamp"))\
             .withColumn("lastExtractDate", unix_timestamp(lit(EXTR_DTTM), "yyyy-MM-dd HH:MM:SS").cast("timestamp"))

dfFiltered = dfFiltered.filter(col("filedate") > col("lastExtractDate")).drop("filedate", "lastExtractDate")

#display(dfFiltered)

# COMMAND ----------

# Reading files content
from pyspark.sql.functions import *

readList=[mountPoint + row[0] + '/' + row[1] for row in dfFiltered.select('filepath','filename').collect()]

readFileSchema = (
  StructType([
    StructField("read_data", StringType(), False)
  ])
)

dfMulti = spark.read.option("sep","??~~??").csv(readList).withColumn("filename", input_file_name())
#display(dfMulti)
print(dfMulti.count())

# COMMAND ----------

# Validation

# Validate Number of Columns
import re
import datetime

delimiter = re.escape(dbutils.widgets.get("pIN_FILE_DELIM"))
newDelimiter = re.escape("\x01")
rejHeaderIndicator = dbutils.widgets.get("pREJ_HDR_GEN_IND")
expectedColumnCount = 0 if dbutils.widgets.get("pIN_FILE_COL_CNT") == "" else int(dbutils.widgets.get("pIN_FILE_COL_CNT"))

dfMultiValidated = dfMulti\
                   .withColumn("numberOfColumns", size(split(col("_c0"), delimiter)))

dfMultiValidated = dfMultiValidated\
                   .withColumn("numberOfColumnsWithHeader", when(lit(rejHeaderIndicator) == "Y", col("numberOfColumns") + 5).otherwise(col("numberOfColumns")))

dfMultiValidated = dfMultiValidated\
                   .withColumn("numberOfColumnsValidation", when((lit(expectedColumnCount) > 0) & (lit(expectedColumnCount) != col("numberOfColumnsWithHeader")), concat(lit("Invalid record layout ("), col("numberOfColumnsWithHeader"), lit(" columns found out of "), lit(expectedColumnCount), lit(" total expected)"))).otherwise(lit("")))

# Validate Extract DT
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", split(col("filename"), "_"))
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", col("edw_gen_mi_last_update_dttm")[size(col("edw_gen_mi_last_update_dttm")) - 1])
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", split(col("edw_gen_mi_last_update_dttm"), "\.")[0])
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", unix_timestamp(col("edw_gen_mi_last_update_dttm"), "yyyyMMddHHmmss").cast("timestamp"))
dfMultiValidated = dfMultiValidated\
                   .withColumn("ExtractDTValidation", when(col("edw_gen_mi_last_update_dttm").isNull(), "Invalid source file date [{0}]".format(col("edw_gen_mi_last_update_dttm"))).otherwise(lit("")))


# Add Reject Header
dfMultiValidated = dfMultiValidated\
                             .withColumn("src_name", split(col("filename"), "\/")[9])\
                             .withColumn("src_type", lit("F"))\
                             .withColumn("src_key", lit(""))\
                             .withColumn("err_desc", when((col("numberOfColumnsValidation") != "") | (col("ExtractDTValidation") != ""), trim(concat(lit("ERROR: "), col("numberOfColumnsValidation"), lit(" "), col("ExtractDTValidation")))))\
                             .withColumn("prty_cd", when((col("numberOfColumnsValidation") != "") | (col("ExtractDTValidation") != ""), 2).otherwise(0))\
                             .withColumn("read_data", concat(when(col("edw_gen_mi_last_update_dttm").isNull(), lit("")).otherwise(col("edw_gen_mi_last_update_dttm")), lit(newDelimiter) ,regexp_replace(col("_c0"), delimiter, newDelimiter)))\
                             .drop("numberOfColumns", "numberOfColumnsWithHeader", "numberOfColumnsValidation", "ExtractDTValidation", "_c0")

# Moving reject header to front
dfMultiValidated = dfMultiValidated.select("src_name", "src_type", "src_key", "err_desc", "prty_cd", "read_data")

#display(dfMultiValidated)

# COMMAND ----------

# Filter Invalid Layout

dfInvalidLayout = dfMultiValidated\
                             .filter(col("prty_cd") != 0)

dfValid = dfMultiValidated\
                              .filter(col("prty_cd") == 0)

# Save OUTF_REJ - Invalid File Layout
#dfInvalidLayout.createOrReplaceGlobalTempView("dfInvalidLayout")
file_path = "{0}/{1}/stdrej_{2}_in_dml_{3}/{4}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"),dbutils.widgets.get("pEXTR_TABLE_NAME"), dbutils.widgets.get("pEDW_BATCH_ID"))
#print(file_path)

dfInvalidLayout.write.format("parquet").mode("overwrite").save(file_path)
#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfInvalidLayout"})

#display(dfValid)

# COMMAND ----------

#  RFMT - Prepare for Data Read

dataReadDF = dfValid

if rejHeaderIndicator != "Y":
  dataReadDF = dfValid.drop("src_name", "src_type", "src_key", "err_desc", "prty_cd")
else:
  dataReadDF = dfValid.withColumn("src_key", lit(dbutils.widgets.get("pTGT_KEY_LIST")))
  
#display(dataReadDF)

# COMMAND ----------

# Apply Schema

import json

dfFormated = dataReadDF.withColumn("read_data", split(col("read_data"), newDelimiter))

if rejHeaderIndicator == "Y":
  dfFormated = dfFormated.select(['src_name', 'src_type', 'src_key', 'err_desc', 'prty_cd'] + [expr('read_data[' + str(x) + ']') for x in range(0, expectedColumnCount - 4)])
else:
  dfFormated = dfFormated.select([expr('read_data[' + str(x) + ']') for x in range(0, expectedColumnCount - 4)])

readrdd= sc.wholeTextFiles(mountPointSchema + dbutils.widgets.get("pGEN_IN_FILE_SCHEMA"))

readrdd1=readrdd.map(lambda x:x[1])
readrdd2=readrdd1.collect()
readrdd3=''.join(readrdd2)

#print(readrdd)
dfFormated = spark.createDataFrame(dfFormated.rdd, StructType.fromJson(json.loads(readrdd3)))
#dfFormated = sqlContext.createDataFrame(dfFormated.collect(), StructType.fromJson(json.loads(readrdd3)))
#display(dfFormated)

# COMMAND ----------

###########################################################################################################################################################################################
# In case $pCLEANSE_KEY_XFR and $pCLEANSE_KEY_FLTR_EXP have implmentation defined at Plan Level, this cell should be used to handle the different types of logic for these two parameters #
###########################################################################################################################################################################################

# COMMAND ----------

# Perform Dedup based on pDEDUP_DATA_IND. Expecting pTGT_KEY_LIST to be in the format "col1, col2, col3..."

dfFormated = dfFormated.orderBy(desc("me_last_activity_date"))
dfBeforeDedup = dfFormated.withColumn("UID", monotonically_increasing_id())

keysSortDedupList = [x.strip(' ') for x in dbutils.widgets.get("pTGT_KEY_LIST").split(",")]

dfDedup = None

if dbutils.widgets.get("pDEDUP_DATA_IND") == "Y":
#   dfDedup = dfBeforeDedup.orderBy(keysSortDedupList)
  dfDedup = dfBeforeDedup.dropDuplicates(keysSortDedupList)
  dfDuplicated = dfBeforeDedup.alias("t1").join(dfDedup.alias("t2"), col("t1.UID") == col("t2.UID"), how='left')\
                 .filter(col("t2.UID").isNull()).select("t1.*")\
                 .withColumn("err_desc", lit("WARNING: Duplicate record (not within end-of-day snapshot)"))\
                 .withColumn("prty_cd", lit(3))\
                 .drop("UID")
  dfDedup = dfDedup.drop("UID")
  dfFormated = dfDedup
  
  # Write OUTF_REJ - Duplicates  
  #dfDuplicated.createOrReplaceGlobalTempView("dfDuplicated")

  file_path = "{0}/{1}/stdrej_{2}_dup_{3}/{4}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEXTR_TABLE_NAME"),dbutils.widgets.get("pEDW_BATCH_ID"))
#  print(file_path)
  
  dfDuplicated.write.format("parquet").mode("overwrite").save(file_path)
#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfDuplicated"})

# COMMAND ----------

# Output Max src_file_dttm

dfEOFSnapshot = dfFormated

dfMaxFileDTTM = dfEOFSnapshot.agg(max("edw_gen_mi_last_update_dttm").alias("src_file_dttm")).select("src_file_dttm")

# Write OUTF_INT - Max src_file_dttm
#dfMaxFileDTTM.createOrReplaceGlobalTempView("dfMaxFileDTTM")
file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pTGT_PROC_MAX_DTTM_FILE"),dbutils.widgets.get("pEDW_BATCH_ID"))

#print(file_path)

dfMaxFileDTTM.write.format("parquet").mode("overwrite").save(file_path)
#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfMaxFileDTTM"})

#display(dfMaxFileDTTM)

# COMMAND ----------

##################################################################################################################################################################
# In case $pTGT_XFORM_REJ_XFR have implmentation defined at Plan Level, this cell should be used to handle the different types of logic for these two parameters #
##################################################################################################################################################################

# COMMAND ----------

# !!TO BE REVIEWED WITH KIRAN: WHAT TYPES OF $pTGT_XFORM_REJ_XFR are among the plans!! (To be developed as part of the Plan development)
# !!TO BE REVIEWED WITH KIRAN: IF VALIDATION IS ENABLED WHY ARE WE JOINING THE RESULT BACK THE FULL DATASET? THIS WILL CREATE REPETITION

# Data Validations

dfFinal = dfEOFSnapshot
dfFinal=dfFinal.drop("edw_gen_mi_last_update_dttm")

if dbutils.widgets.get("pVALIDATE_DATA_IND") == "Y":
  dfValidationRejects = dfEOFSnapshot.filter((col("prty_cd") == 1) | (col("prty_cd") == 2))
  
  readrddd= sc.wholeTextFiles(mountPointSchema + dbutils.widgets.get("pTGT_FILE_SCHEMA"))
  
  readrdd11=readrddd.map(lambda x:x[1])
  readrdd22=readrdd11.collect()
  readrdd33=''.join(readrdd22)
  # Updating to target schema
  dfValidationRejects = spark.createDataFrame(dfValidationRejects.rdd, StructType.fromJson(json.loads(readrdd33)))
  #dfValidationRejects = sqlContext.createDataFrame(dfValidationRejects.collect(), StructType.fromJson(json.loads(readrdd33)))
  # Validation_reject:
  #dfFinal.createOrReplaceGlobalTempView("dfValidationRejects")
  file_path_val_rej = "{0}/{1}/stdrej_{2}_val_{3}/{4}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEXTR_TABLE_NAME"),dbutils.widgets.get("pEDW_BATCH_ID"))
  print(file_path_val_rej)
  
  dfValidationRejects.write.format("parquet").mode("overwrite").save(file_path_val_rej)
  #dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path_val_rej  , "view_name": "dfValidationRejects"})
  
  dfFinal = spark.createDataFrame(dfFinal.rdd, StructType.fromJson(json.loads(readrdd33)))
  #dfFinal = sqlContext.createDataFrame(dfFinal.collect(), StructType.fromJson(json.loads(readrdd33)))
  TgtKeyList= dbutils.widgets.get("pTGT_KEY_LIST").split(',')
#Updating src_key columnn value and Removing "
#for i in dfFinal.columns:
    #dfFinal = dfFinal.withColumn(i , regexp_replace(col(i), '"', ''))
dfFinal = dfFinal.withColumn('src_key' , concat_ws('^|~',*TgtKeyList))
dfFinal = dfFinal.withColumn('src_key' , regexp_replace(col('src_key'), '"', ''))
#Blank to Null
for i in dfFinal.columns:
    dfFinal = dfFinal.withColumn(i , when(col(i) == '', None ).otherwise(col(i)))
#display(dfFinal)
  
# OUTF_LDR - Target Load Ready
#dfFinal.createOrReplaceGlobalTempView("dfFinal")
file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pTGT_FILE"),dbutils.widgets.get("pEDW_BATCH_ID"))
# print(file_path.count())
dfFinal.write.format("parquet").mode("overwrite").save(file_path)
#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfFinal"})




# COMMAND ----------

dbutils.notebook.exit(dfAssetIdStr)

# COMMAND ----------

# df = spark.read.parquet("/mnt/wrangled//master_data/customer/staging/edw_idl_customer_ec_PHEXT013_extr/1234")
# print(df.count())
# df1 = spark.read.csv("/mnt/wrangled//master_data/customer/input/PHEXT013_20211125145200_20211126033742.dat")
# print(df1.count())
# Databricks notebook source
import os
import json

# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

#Parameters
os.environ['wrangledZone'] = "/dbfs" + mountPoint
os.environ['PAR_DB_TRG_DIR'] = dbutils.widgets.get('PAR_DB_TRG_DIR')
os.environ['PAR_DB_CDI_DIST_WAL_DATA_DIR']=dbutils.widgets.get('PAR_DB_CDI_DIST_WAL_DATA_DIR')

# COMMAND ----------

# MAGIC %sh
# MAGIC #Shell Script to Copy Files
# MAGIC cp ${wrangledZone}/${PAR_DB_CDI_DIST_WAL_DATA_DIR}/Geo_dates.trg ${wrangledZone}/${PAR_DB_TRG_DIR}/Geo_dates.trg
# MAGIC if [ -s ${wrangledZone}/${PAR_DB_TRG_DIR}/Geo_dates.trg ]; then
# MAGIC   if [ `cat ${wrangledZone}/${PAR_DB_TRG_DIR}/Geo_dates_prev.trg` -ne `cat ${wrangledZone}/${PAR_DB_TRG_DIR}/Geo_dates.trg` ]; then
# MAGIC     if [ -s ${wrangledZone}/${PAR_DB_TRG_DIR}/Geo_dates.trg ]; then 
# MAGIC       GEOCODE_DATA_FILE_DATE=`cat ${wrangledZone}/${PAR_DB_TRG_DIR}/Geo_dates.trg` ; 
# MAGIC     else 
# MAGIC       echo 0; fi;
# MAGIC     cp ${wrangledZone}/${PAR_DB_CDI_DIST_WAL_DATA_DIR}/cdi_waldist_out_$GEOCODE_DATA_FILE_DATE.dat   ${wrangledZone}/${PAR_DB_TRG_DIR}/cust_geo_$GEOCODE_DATA_FILE_DATE.dat ;
# MAGIC   fi;
# MAGIC fi

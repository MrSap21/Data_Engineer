# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from collections import Counter

def replace_id(arr):
    id = arr[0].split("^|~")[0]
    nextID = arr[1].split("^|~")[0]
    
    value = None
    if nextID in id:
      value = nextID
    else:
      listIds = []
      for item in arr:
          listIds.append(item.split("^|~")[0])          
      c = Counter(listIds)
      value, count = c.most_common()[0]
      
    nestedArray = arr[0].split("^|~")
    nestedArray[0] = value
    arr[0] = "^|~".join(nestedArray)
    return arr

replace_id_udf = udf(replace_id, ArrayType(StringType()))
  
df = spark.read.option("lineSep", "\x00\x00").text(mountPoint + "/" + dbutils.widgets.get("PAR_NB_INPUT_FOLDER") + "/" + dbutils.widgets.get("PAR_NB_INPUT_FILE"))
df = df.filter(col("value") != "")
df = df.withColumn("value", split(col("value"), "\^\~\|"))
df = df.withColumn("value", replace_id_udf("value"))
df = df.withColumn("value", concat_ws("^~|",col("value")))

# COMMAND ----------

df.write.mode("overwrite").parquet(mountPoint + "/" + dbutils.widgets.get("PAR_NB_OUTPUT_FOLDER"))
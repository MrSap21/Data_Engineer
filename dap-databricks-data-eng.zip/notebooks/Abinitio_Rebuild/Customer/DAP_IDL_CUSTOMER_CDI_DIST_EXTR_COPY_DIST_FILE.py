# Databricks notebook source
import os
import json

# Mounting ADLS
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

#Parameters
os.environ['wrangledZone'] = "/dbfs" + mountPoint
os.environ['PAR_DB_TRG_DIR'] = dbutils.widgets.get('PAR_DB_TRG_DIR')
os.environ['PAR_DB_CDI_DIST_WAL_DATA_DIR']=dbutils.widgets.get('PAR_DB_CDI_DIST_WAL_DATA_DIR')

# COMMAND ----------

# MAGIC %sh
# MAGIC #Shell Script to Copy Files
# MAGIC cp ${wrangledZone}/${PAR_DB_CDI_DIST_WAL_DATA_DIR}/cust_dcal.trg ${wrangledZone}/${PAR_DB_TRG_DIR}/cust_dcal.trg
# MAGIC if [ `cat ${wrangledZone}/${PAR_DB_TRG_DIR}/cust_dcal_prev.trg` -ne `cat ${wrangledZone}/${PAR_DB_TRG_DIR}/cust_dcal.trg` ]; then
# MAGIC   if [ -s ${wrangledZone}/${PAR_DB_TRG_DIR}/cust_dcal.trg ]; then 
# MAGIC     DIST_DATA_FILE_DATE=`cat ${wrangledZone}/${PAR_DB_TRG_DIR}/cust_dcal.trg` ; 
# MAGIC   else 
# MAGIC     echo 0; fi;
# MAGIC   cp ${wrangledZone}/${PAR_DB_CDI_DIST_WAL_DATA_DIR}/cdi_waldist_out_$DIST_DATA_FILE_DATE.dat   ${wrangledZone}/${PAR_DB_TRG_DIR}/cdi_waldist_out_$DIST_DATA_FILE_DATE.dat ;
# MAGIC   cp ${wrangledZone}/${PAR_DB_CDI_DIST_WAL_DATA_DIR}/cdi_compdist_out_$DIST_DATA_FILE_DATE.dat   ${wrangledZone}/${PAR_DB_TRG_DIR}/cdi_compdist_out_$DIST_DATA_FILE_DATE.dat ;
# MAGIC fi

# Databricks notebook source
mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

ec_extr_file_path = dbutils.widgets.get("EC_FILE_PATH")+'/'+dbutils.widgets.get("EDW_BATCH_ID")
pc_extr_file_path = dbutils.widgets.get("PC_FILE_PATH")+'/'+dbutils.widgets.get("EDW_BATCH_ID")
sm_extr_file_path = dbutils.widgets.get("SM_FILE_PATH")+'/'+dbutils.widgets.get("EDW_BATCH_ID")
ic_extr_file_path = dbutils.widgets.get("IC_FILE_PATH")+'/'+dbutils.widgets.get("EDW_BATCH_ID")

ec_inlist_file=mountPoint+'/'+dbutils.widgets.get("EC_FILE_PATH")+'_inList'
pc_inlist_file=mountPoint+'/'+dbutils.widgets.get("PC_FILE_PATH")+'_inList'
sm_inlist_file=mountPoint+'/'+dbutils.widgets.get("SM_FILE_PATH")+'_inList'
ic_inlist_file=mountPoint+'/'+dbutils.widgets.get("IC_FILE_PATH")+'_inList'



# COMMAND ----------

#creating dataframes of filenames

ec=spark.read.csv(sc.parallelize(ec_extr_file_path.split('\n')))
pc=spark.read.csv(sc.parallelize(pc_extr_file_path.split('\n')))
sm=spark.read.csv(sc.parallelize(sm_extr_file_path.split('\n')))
ic=spark.read.csv(sc.parallelize(ic_extr_file_path.split('\n')))



# COMMAND ----------

#writing extr file names to respective inList file

ec.write.format("csv").mode("append").save(ec_inlist_file)
pc.write.format("csv").mode("append").save(pc_inlist_file)
sm.write.format("csv").mode("append").save(sm_inlist_file)
ic.write.format("csv").mode("append").save(ic_inlist_file)
# Databricks notebook source
# Mounting ADLS
dbutils.widgets.text("pSCHEMA_MOUNT_PATH","/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_SHELL")
dbutils.widgets.get("pEXTR_TABLE_NAME")

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)
#mountPointSchema=dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP_SHELL",60)
mountPointSchema=dbutils.notebook.run(dbutils.widgets.get("pSCHEMA_MOUNT_PATH"),60)

# COMMAND ----------

inFile=dbutils.widgets.get("pINPUT_FILENAME")
batchID= dbutils.widgets.get("pBATCH_ID")
Staging_Folder =dbutils.widgets.get('pSTAGING_FOLDER')
rejHeaderIndicator = dbutils.widgets.get("pREJ_HDR_GEN_IND")
dbutils.widgets.get("AI_SERIAL_REJECT")
dbutils.widgets.get("AI_GRAPH_NAME")
dbutils.widgets.get("pTGT_KEY_LIST")
dbutils.widgets.get("pTGT_FILE_SCHEMA")
print(inFile,Staging_Folder)

# COMMAND ----------

# Filter the latest files
from pyspark.sql.functions import *
from pyspark.sql.types import *
import pandas as pd
from pyspark.sql import functions as F

#currFile=mountPoint + '/' + Staging_Folder +'/'+ inFile + '/' + batchID + '/' + '*.parquet'

currFile=mountPoint + '/' + Staging_Folder +'/'+ inFile+'_inList/*.csv'
print(currFile)
currDF =spark.read.csv(currFile)
 
currDF=currDF.withColumn("_c0",concat(lit('/'),F.col('_c0'),lit('/*.parquet')))
display(currDF)
#currDF =spark.read.parquet(currFile).toDF(*InputSchema)
#currDF=currDF.withColumn("lastExtractDate",current_timestamp())
#currDF.show()



# COMMAND ----------

from pyspark.sql.functions import *
readList=[mountPoint + row[0] for row in currDF.select('_c0').collect()]
print(readList)


#currDF =spark.read.parquet(currFile).toDF(*InputSchema)
#currDF=currDF.withColumn("lastExtractDate",current_timestamp())

# Load Input File
InputSchema=["src_name","src_type","src_key","err_desc","prty_cd","cust_src_id","cust_src_cd","composite_type_cd","msg_type_cd","cdi_cust_src_id","cdi_composite_type_cd","cdi_msg_type_cd","mbr_stat_cd"]
inputSchema =StructType([
    StructField("src_name", StringType(), False),
    StructField("src_type", StringType(), False),
    StructField("src_key", StringType(), False),
    StructField("err_desc", StringType(), False),
    StructField("prty_cd", StringType(), False),
    StructField("cust_src_id", StringType(), False),
    StructField("cust_src_cd", StringType(), False),
    StructField("composite_type_cd", StringType(), False),
    StructField("msg_type_cd", StringType(), False),
    StructField("cdi_cust_src_id", StringType(), False),
    StructField("cdi_composite_type_cd", StringType(), False),
    StructField("cdi_msg_type_cd", StringType(), False),
    StructField("mbr_stat_cd", StringType(), False),
  StructField("newline", StringType(), False)
  ])


dfMulti = spark.read.parquet(*readList).toDF(*InputSchema)
#display(dfMulti)

# COMMAND ----------

dfMultiValidated = dfMulti.withColumn("edw_gen_mi_last_update_dttm", split(col("src_name"), "_"))
dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", col("edw_gen_mi_last_update_dttm")[size(col("edw_gen_mi_last_update_dttm")) - 1])

dfMultiValidated = dfMultiValidated\
                   .withColumn("edw_gen_mi_last_update_dttm", split(col("edw_gen_mi_last_update_dttm"), "\.")[0])
dfMultiValidated = dfMultiValidated\
                   .withColumn("ExtractDTValidation", when(col("edw_gen_mi_last_update_dttm").isNull(), "Invalid source file date #[{0}]".format(col("edw_gen_mi_last_update_dttm"))).otherwise(lit("")))
#dfMultiValidated.show()

# COMMAND ----------

# Filter Invalid Layout
dfInvalidLayout = dfMultiValidated.filter(col("prty_cd") != 0)

dfValid = dfMultiValidated.filter(col("prty_cd") == 0)

# Save OUTF_REJ - Invalid File Layout
#dfInvalidLayout.createOrReplaceGlobalTempView("dfInvalidLayout")
file_path = "{0}/{1}/stdrej_{2}_in_dml_{3}/{4}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"),dbutils.widgets.get("pEXTR_TABLE_NAME"), dbutils.widgets.get("pBATCH_ID"))
print(file_path)

#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfInvalidLayout"})

dfInvalidLayout.write.format("parquet").mode("overwrite").save(file_path)

#display(dfValid)

#${AI_SERIAL_REJECT}/stdrej_${AI_GRAPH_NAME}_in_dml_${pEXTR_TABLE_NAME}_${pEDW_BATCH_ID}.rej

# COMMAND ----------

#  RFMT - Prepare for Data Read

dataReadDF = dfValid

if rejHeaderIndicator == "Y":
  dataReadDF = dfValid.drop("src_name", "src_type", "src_key", "err_desc", "prty_cd","ExtractDTValidation")
else:
  dataReadDF = dfValid.withColumn("src_key", lit(dbutils.widgets.get("pTGT_KEY_LIST")))
  
#display(dataReadDF)
dfFormated=dataReadDF

# COMMAND ----------

# Perform Dedup based on pDEDUP_DATA_IND. Expecting pTGT_KEY_LIST to be in the format "col1, col2, col3..."

dfBeforeDedup = dfFormated.withColumn("UID", monotonically_increasing_id())

keysSortDedupList = [x.strip(' ') for x in dbutils.widgets.get("pTGT_KEY_LIST").split(",")]

dfDedup = None

if dbutils.widgets.get("pDEDUP_DATA_IND") == "Y":
  dfDedup = dfBeforeDedup.sort(keysSortDedupList)
  dfDedup = dfDedup.dropDuplicates(keysSortDedupList)
  dfDuplicated = dfBeforeDedup.alias("t1").join(dfDedup.alias("t2"), col("t1.UID") == col("t2.UID"), how='left')\
                 .filter(col("t2.UID").isNull()).select("t1.*")\
                 .withColumn("err_desc", lit("WARNING: Duplicate record (not within end-of-day snapshot)"))\
                 .withColumn("prty_cd", lit(3))\
                 .drop("UID")
  dfDedup = dfDedup.drop("UID")
  dfFormated = dfDedup
  
  # Write OUTF_REJ - Duplicates  
  #dfDuplicated.createOrReplaceGlobalTempView("dfDuplicated")

  file_path = "{0}/{1}/stdrej_{2}_dup_{3}/{4}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEXTR_TABLE_NAME"),dbutils.widgets.get("pBATCH_ID"))
  print(file_path)
  

#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfDuplicated"})

dfDuplicated.write.format("parquet").mode("overwrite").save(file_path)

#dbutils.widgets.get("pEXTR_TABLE_NAME")

#{AI_SERIAL_REJECT}/stdrej_${AI_GRAPH_NAME}_dup_${pEXTR_TABLE_NAME}_${pEDW_BATCH_ID}.re


# COMMAND ----------

# Output Max src_file_dttm

dfEOFSnapshot = dfFormated

dfMaxFileDTTM = dfEOFSnapshot.agg(max("edw_gen_mi_last_update_dttm").alias("src_file_dttm")).select("src_file_dttm")

# Write OUTF_INT - Max src_file_dttm
#dfMaxFileDTTM.createOrReplaceGlobalTempView("dfMaxFileDTTM")
file_path = "{0}/{1}/{2}".format(mountPoint, dbutils.widgets.get("pSTAGING_FOLDER"),dbutils.widgets.get("pTGT_PROC_MAX_DTTM_FILE"),dbutils.widgets.get("pBATCH_ID"))

print(file_path)

#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfMaxFileDTTM"})

dfMaxFileDTTM.write.format("parquet").mode("overwrite").save(file_path)

#display(dfMaxFileDTTM)

# COMMAND ----------

# !!TO BE REVIEWED WITH KIRAN: WHAT TYPES OF $pTGT_XFORM_REJ_XFR are among the plans!! (To be developed as part of the Plan development)
# !!TO BE REVIEWED WITH KIRAN: IF VALIDATION IS ENABLED WHY ARE WE JOINING THE RESULT BACK THE FULL DATASET? THIS WILL CREATE REPETITION
import json
# Data Validations

dfFinal = dfEOFSnapshot
dfFinal=dfFinal.drop("edw_gen_mi_last_update_dttm")

if dbutils.widgets.get("pVALIDATE_DATA_IND") == "Y":
  dfValidationRejects = dfEOFSnapshot.filter((col("prty_cd") == 1) | (col("prty_cd") == 2))
  
  readrddd= sc.wholeTextFiles(mountPointSchema + dbutils.widgets.get("pTGT_FILE_SCHEMA"))
  
  readrdd11=readrddd.map(lambda x:x[1])
  readrdd22=readrdd11.collect()
  #print(readrdd22)
  readrdd33=''.join(readrdd22)
  #print(readrdd33)
  # Updating to target schema
  dfValidationRejects = sqlContext.createDataFrame(dfValidationRejects.collect(), StructType.fromJson(json.loads(readrdd33)))
  # Validation_reject:
  #dfFinal.createOrReplaceGlobalTempView("dfValidationRejects")
  file_path_val_rej = "{0}/{1}/stdrej_{2}_val_{3}/{4}".format(mountPoint, dbutils.widgets.get("AI_SERIAL_REJECT"), dbutils.widgets.get("AI_GRAPH_NAME"), dbutils.widgets.get("pEXTR_TABLE_NAME"),dbutils.widgets.get("pBATCH_ID"))
  print(file_path_val_rej)
  #dfFinal.show()
  #dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path_val_rej  , "view_name": "dfValidationRejects"})
  
  dfValidationRejects.write.format("parquet").mode("overwrite").save(file_path)
  
  #dfFinal = sqlContext.createDataFrame(dfFinal.collect(), StructType.fromJson(json.loads(readrdd33)))
  #display(dfFinal)
# OUTF_LDR - Target Load Ready
#dfFinal.createOrReplaceGlobalTempView("dfFinal")
file_path = "{0}/{1}/{2}/{3}".format(mountPoint,dbutils.widgets.get("pSTAGING_FOLDER"), dbutils.widgets.get("pTGT_FILE"), dbutils.widgets.get("pBATCH_ID"))
print(file_path)
#dbutils.notebook.run("/Abinitio_Rebuild/Utilities/WRITE_TO_STORAGE_PARQUET", 60, {"file_path": file_path  , "view_name": "dfFinal"})

dfFinal.write.format("parquet").mode("overwrite").save(file_path)
#print(dbutils.widgets.get("pTGT_PROC_MAX_DTTM_FILE")[len(dbutils.widgets.get("pTGT_FILE")) -5:])
#${AI_SERIAL_REJECT}/stdrej_${AI_GRAPH_NAME}_val_${pEXTR_TABLE_NAME}_${pEDW_BATCH_ID}.rej

# COMMAND ----------

#Trim all column's data in parquet file
from pyspark.sql.functions import trim,col

#Reading parquet file
ldrDf = spark.read.format("parquet").load(file_path)
trimDf = ldrDf.select([trim(col(c)).alias(c) for c in ldrDf.columns])

#overwrite trimmed data
trimDf.write.format("parquet").mode("overwrite").save(file_path)
# Databricks notebook source
adlsAccountNameInput = "dapdevadlslnd01"
adlsContainerNameInput = "landing"
mountPointInput = "/mnt/DAP_IDL_PROMO_MSS_PROGRAM_EVENT_CIF_XFORM/Input"

adlsAccountNameOutput = "dapdevadlswrng01"
adlsContainerNameOutput = "wrangled"
mountPointOutput = "/mnt/DAP_IDL_PROMO_MSS_PROGRAM_EVENT_CIF_XFORM/Output"


# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdatascope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdatascope",key="devdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdatascope",key="adtenantid")
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"

# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

sourceInput = "abfss://" + adlsContainerNameInput + "@" + adlsAccountNameInput + ".dfs.core.windows.net/"
sourceOutput = "abfss://" + adlsContainerNameOutput + "@" + adlsAccountNameOutput + ".dfs.core.windows.net/"

# Mounting Input ADLS
if not any(mount.mountPoint == mountPointInput for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = sourceInput,
    mount_point = mountPointInput,
    extra_configs = configs)
  
# Mounting Output ADLS
if not any(mount.mountPoint == mountPointOutput for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = sourceOutput,
    mount_point = mountPointOutput,
    extra_configs = configs)

# COMMAND ----------

# Load Input File

from pyspark.sql.types import *

inputSchema = (
  StructType([
    StructField("file_name", StringType(), False)
  ])
)

inputFilePath = mountPointInput + "/" + dbutils.widgets.get('AI_SERIAL')
inputFileName = "edw_idl_promo_mss_program_event_filelist_" + dbutils.widgets.get('pDAP_BATCH_ID') + ".dat"

dfListFiles = spark.read.format("csv").options(header='false').schema(inputSchema).load(inputFilePath + "/" + inputFileName)

#display(dfListFiles)

# COMMAND ----------

# Extract list of files

from pyspark.sql.functions import *

dfListFilesPath = dfListFiles\
                  .withColumn("file_path", concat(lit(inputFilePath), lit("/"), col("file_name")))\
                  .drop("file_name")

inputSchema = (
  StructType([
    StructField("opt_in_program_code", StringType(), False),
    StructField("pgm_seq_nbr", StringType(), False),
    StructField("opt_in_program_name", StringType(), False),
    StructField("opt_in_program_description", StringType(), False),
    StructField("opt_in_program_start_date", StringType(), False),
    StructField("opt_in_program_end_date", StringType(), False),
    StructField("opt_in_start_date", StringType(), False),
    StructField("opt_in_end_date", StringType(), False),
    StructField("opt_in_program_type", StringType(), False),
    StructField("opt_in_program_details", StringType(), False),
    StructField("program_channels", StringType(), False),
    StructField("ADV_EVENT_TYPE", StringType(), False),
    StructField("ADV_EVENT_SEQ_NBR", StringType(), False),
    StructField("ADV_EV_VER_TYPE_CODE", StringType(), False),
    StructField("ADV_EV_VER_SEQ_NBR", StringType(), False),
    StructField("adv_filler_1", StringType(), False),
    StructField("adv_filler_2", StringType(), False),
    StructField("adv_filler_3", StringType(), False),
    StructField("adv_filler_4", StringType(), False),
    StructField("adv_filler_5", StringType(), False),
    StructField("opt_in_channel_prompt", StringType(), False),
    StructField("loyalty_media_record_sts", StringType(), False),
    StructField("CREATION_DATE", StringType(), False),
    StructField("CREATION_TIME", StringType(), False)
  ])
)

dfMultiFiles = spark.read.format("csv").options(header='false', delimiter = '|').schema(inputSchema).load(dfListFilesPath.select("file_path").rdd.flatMap(lambda x: x).collect())

dfMultiFiles = dfMultiFiles\
               .withColumn("filename", regexp_replace(split(split(input_file_name(), "WAG_ADV_PGM_EDW_")[1], ".dat")[0], "_", ""))

#display(dfMultiFiles)

# COMMAND ----------

# Reformat, Sort and Dedup

dfFinal = dfMultiFiles\
          .withColumn("src_sys_cd", lit("ADR7"))\
          .select(col("src_sys_cd"),\
                  trim(col("ADV_EVENT_SEQ_NBR")).alias("ad_evt_seq_nbr"),\
                  trim(col("ADV_EV_VER_SEQ_NBR")).alias("ad_evt_vers_seq_nbr"),\
                  trim(col("ADV_EVENT_TYPE")).alias("ad_evt_type"),\
                  trim(col("ADV_EV_VER_TYPE_CODE")).alias("ad_evt_vers_type_cd"),\
                  trim(col("opt_in_program_code")).alias("cust_pref_prog_cd"),\
                  trim(col("opt_in_channel_prompt")).alias("prog_prompt_channel"),\
                  trim(col("adv_filler_4")).alias("prog_override_cd"),\
                  col("filename"))

dfFinal = dfFinal.orderBy("src_sys_cd", "ad_evt_seq_nbr", "ad_evt_vers_seq_nbr", "ad_evt_type", "ad_evt_vers_type_cd", "filename", ascending=False)\
                 .groupBy("src_sys_cd", "ad_evt_seq_nbr", "ad_evt_vers_seq_nbr", "ad_evt_type", "ad_evt_vers_type_cd")\
                 .agg(max(col("cust_pref_prog_cd")).alias("cust_pref_prog_cd"), max(col("prog_prompt_channel")).alias("prog_prompt_channel"), max(col("prog_override_cd")).alias("prog_override_cd"))

#display(dfFinal)

# COMMAND ----------

# Write output files

data_location_output = "{0}/{1}/edw_idl_promo_mss_cif_mss_program_event_ldr_{2}".format(mountPointOutput, dbutils.widgets.get('AI_SERIAL'), dbutils.widgets.get('pDAP_BATCH_ID'))

dfFinal.coalesce(1).write.options(header='false', delimiter = '\x01').format("csv").mode("overwrite").save(data_location_output)

# Renaming output and adding the correct extention

filesoutput = dbutils.fs.ls(data_location_output)
csv_file_output = [x.path for x in filesoutput if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file_output, data_location_output.rstrip('/') + ".dat")
dbutils.fs.rm(data_location_output, recurse = True)

# COMMAND ----------


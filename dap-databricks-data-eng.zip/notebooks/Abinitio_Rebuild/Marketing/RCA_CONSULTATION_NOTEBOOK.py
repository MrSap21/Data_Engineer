# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#INPUT PARAMETERS  
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_STG_DB = dbutils.widgets.get("PAR_DB_SNFK_DB_STG")
EDW_BATCH_ID=dbutils.widgets.get("pEDW_BATCH_ID")
SNFL_MRKT_DB=dbutils.widgets.get("PAR_DB_SNFK_DB_MRK")
RCA_Schema=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_SCHEMA")
TgtTblName=dbutils.widgets.get("PAR_DB_SNFK_TGT_TBL")
PAR_OUTPUT_STG_FILE_PATH=dbutils.widgets.get("PAR_OUTPUT_FILE_PATH")
PAR_OUTPUT_STG_FILE_3=dbutils.widgets.get("PAR_OUTPUT_FILE_NAME")
STG_TblName=dbutils.widgets.get("PAR_DB_SNFK_RCA_STG_TBL")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit,col
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("pIN_FILE")
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
#print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

# COMMAND ----------

# Reading files contentfrom pyspark.sql.functions import *


schema = StructType() \
      .add("PAT_ID",DecimalType(13),True) \
      .add("CONSULT_DT",StringType(),True) \
      .add("CONSULT_TM",StringType(),True) \
      .add("CONSULT_TYPE_CD",StringType(),True) \
      .add("CONSULT_PARTY_CD",StringType(),True) \
      .add("CONSULT_ACCEPT_IND",StringType(),True) \
      .add("RX_NBR",DecimalType(38),True) \
      .add("STR_NBR",DecimalType(38),True) \
      .add("CAMPGN_ID",DecimalType(38),True) \
      .add("CAMPGN_COMPONENT_SEQ_ID",DecimalType(10),True) \
      .add("COMPONENT_DCTNRY_ID",DecimalType(38),True) \
      .add("CONSULT_CMNT",StringType(),True) \
      .add("EMP_INITIALS",StringType(),True) \
      .add("FREE_TXT_IND",StringType(),True) \
      .add("CONSULT_RSLT_CMNT",StringType(),True) \
      .add("CONSULT_RSLT_RPH_INITIALS",StringType(),True) \
      .add("CONSULT_RSLT_DTTM",TimestampType(),True) \
      .add("CONSULT_ADD_TYPE_CD",StringType(),True) \
      .add("RCA_CD_ID",DecimalType(38),True) \
      .add("SRC_CREATE_USER_ID",DecimalType(38),True) \
      .add("SRC_UPDATE_USER_ID",DecimalType(38),True) \
      .add("SRC_CREATE_DTTM",TimestampType(),True) \
      .add("SRC_UPDATE_DTTM",TimestampType(),True)
      

readList=[mountPoint + row[0] + '/' + row[1] for row in dfNamePath.select('filepath','filename').collect()]

dfMulti = spark.read.format("csv").schema(schema).option("sep","").load(readList)

# print(readList)
# display(dfMulti)

# COMMAND ----------

#MAKING A SORT ON  SRC_CREATE_DTTM IN DESC
df_sort=dfMulti.sort(col("SRC_CREATE_DTTM").desc())
# display(df_sort)
df_sort.count()

# COMMAND ----------

#REMOVING DUPLICATES BASED ON PAT_ID,CAMPGN_ID 
df_dedup=df_sort.dropDuplicates(['PAT_ID','CONSULT_DT','CONSULT_TM','CONSULT_TYPE_CD'])
df_dedup.count()

# COMMAND ----------

#GETTING THE DATA FROM TARGET TABLE TO PERFORM CAMPARISSION BETWEEN SOURCE FILE AND TARGET TABLE
Input_Table =""" select PAT_ID,
 CONSULT_DT,
 CONSULT_TM,
 CONSULT_TYPE_CD,
 CONSULT_PARTY_CD,
 CONSULT_ACCEPT_IND,
 RX_NBR,
 STR_NBR,
 CAMPGN_ID,
 CAMPGN_COMPONENT_SEQ_ID,
 COMPONENT_DCTNRY_ID,
 CONSULT_CMNT,
 EMP_INITIALS,
 FREE_TXT_IND,
 CONSULT_RSLT_CMNT,
 CONSULT_RSLT_RPH_INITIALS,
 CONSULT_RSLT_DTTM,
 CONSULT_ADD_TYPE_CD,
 RCA_CD_ID,
 SRC_CREATE_USER_ID,
 SRC_UPDATE_USER_ID,
 SRC_CREATE_DTTM,
 SRC_UPDATE_DTTM
FROM {0}.{1}.{2}""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName)

# COMMAND ----------

#REDAING THE DATA FROM TARGET TABLE
df_target_table = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", Input_Table) \
  .load()

# display(df_target_table)
df_target_table.count()

# COMMAND ----------

#MAKING AN INNER JOIN TO GET UPDATE RECORDS, DERIVING THE EDW_DML_IND COLUMN

join1=df_dedup.alias("in0").join(df_target_table.alias("in1"),((df_dedup.PAT_ID==df_target_table.PAT_ID)  &       (df_dedup.CONSULT_DT==df_target_table.CONSULT_DT) & (df_dedup.CONSULT_TM==df_target_table.CONSULT_TM) & (df_dedup.CONSULT_TYPE_CD==df_target_table.CONSULT_TYPE_CD)),"inner").select(col("in0.PAT_ID").alias("MERGED_FM_PAT_ID"),col("in0.CONSULT_DT"),col("in0.CONSULT_TM"),col("in0.CONSULT_TYPE_CD"),col("in0.PAT_ID"),col("in0.CONSULT_PARTY_CD"),col("in0.CONSULT_ACCEPT_IND"),col("in0.RX_NBR"),col("in0.STR_NBR"),col("in0.CAMPGN_ID"),col("in0.CAMPGN_COMPONENT_SEQ_ID"),col("in0.COMPONENT_DCTNRY_ID"),col("in0.CONSULT_CMNT"),col("in0.EMP_INITIALS"),col("in0.FREE_TXT_IND"),col("in0.CONSULT_RSLT_CMNT"),col("in0.CONSULT_RSLT_RPH_INITIALS"),col("in0.CONSULT_RSLT_DTTM"),col("in0.CONSULT_ADD_TYPE_CD"),col("in0.RCA_CD_ID"),col("in0.SRC_CREATE_USER_ID"),col("in0.SRC_UPDATE_USER_ID"),col("in0.SRC_CREATE_DTTM"),col("in0.SRC_UPDATE_DTTM"),lit("U").alias("EDW_DML_IND")).withColumn("EDW_BATCH_ID", lit(EDW_BATCH_ID)).withColumn("EDW_CREATE_DTTM",current_timestamp())

# display(join1)
join1.count()

# COMMAND ----------

#SELECTING THE LIST OF THE COLUMNS IN ORDER
df_src_final=join1.select(join1.MERGED_FM_PAT_ID
,join1.CONSULT_DT
,join1.CONSULT_TM
,join1.CONSULT_TYPE_CD
,join1.PAT_ID
,join1.CONSULT_PARTY_CD
,join1.CONSULT_ACCEPT_IND
,join1.RX_NBR
,join1.STR_NBR
,join1.CAMPGN_ID
,join1.CAMPGN_COMPONENT_SEQ_ID
,join1.COMPONENT_DCTNRY_ID
,join1.CONSULT_CMNT
,join1.EMP_INITIALS
,join1.FREE_TXT_IND
,join1.CONSULT_RSLT_CMNT
,join1.CONSULT_RSLT_RPH_INITIALS
,join1.CONSULT_RSLT_DTTM
,join1.CONSULT_ADD_TYPE_CD
,join1.RCA_CD_ID
,join1.SRC_CREATE_USER_ID
,join1.SRC_UPDATE_USER_ID
,join1.SRC_CREATE_DTTM
,join1.SRC_UPDATE_DTTM
,join1.EDW_CREATE_DTTM
,join1.EDW_BATCH_ID
,join1.EDW_DML_IND)

# COMMAND ----------

#MAKING leftAntijoin TO GET THE INSERT RECORDS
df_leftjoin=df_dedup.alias("in0").join(df_target_table.alias("in1"),((df_dedup.PAT_ID==df_target_table.PAT_ID)  &    (df_dedup.CONSULT_DT==df_target_table.CONSULT_DT) & (df_dedup.CONSULT_TM==df_target_table.CONSULT_TM) & (df_dedup.CONSULT_TYPE_CD==df_target_table.CONSULT_TYPE_CD)),"left").select(col("in1.PAT_ID").alias("tgt_PAT_ID"),col("in1.CONSULT_DT").alias("tgt_CONSULT_DT"),col("in1.CONSULT_TM").alias("tgt_CONSULT_TM"),col("in1.CONSULT_TYPE_CD").alias("tgt_CONSULT_TYPE_CD"),col("in0.PAT_ID").alias("MERGED_FM_PAT_ID"),col("in0.CONSULT_DT"),col("in0.CONSULT_TM"),col("in0.CONSULT_TYPE_CD"),col("in0.PAT_ID"),col("in0.CONSULT_PARTY_CD"),col("in0.CONSULT_ACCEPT_IND"),col("in0.RX_NBR"),col("in0.STR_NBR"),col("in0.CAMPGN_ID"),col("in0.CAMPGN_COMPONENT_SEQ_ID"),col("in0.COMPONENT_DCTNRY_ID"),col("in0.CONSULT_CMNT"),col("in0.EMP_INITIALS"),col("in0.FREE_TXT_IND"),col("in0.CONSULT_RSLT_CMNT"),col("in0.CONSULT_RSLT_RPH_INITIALS"),col("in0.CONSULT_RSLT_DTTM"),col("in0.CONSULT_ADD_TYPE_CD"),col("in0.RCA_CD_ID"),col("in0.SRC_CREATE_USER_ID"),col("in0.SRC_UPDATE_USER_ID"),col("in0.SRC_CREATE_DTTM"),col("in0.SRC_UPDATE_DTTM"),lit("I").alias("EDW_DML_IND")).withColumn("EDW_BATCH_ID", lit(EDW_BATCH_ID)).withColumn("EDW_CREATE_DTTM",current_timestamp())

# display(df_leftjoin)
df_leftjoin.count()

# COMMAND ----------

#SELECTING THE COLUMNS IN ORDER
df_final_left_join = df_leftjoin.filter(df_leftjoin.tgt_PAT_ID.isNull() & df_leftjoin.tgt_CONSULT_DT.isNull() & df_leftjoin.tgt_CONSULT_TM.isNull() & df_leftjoin.tgt_CONSULT_TYPE_CD.isNull()).select(df_leftjoin.MERGED_FM_PAT_ID
,df_leftjoin.CONSULT_DT
,df_leftjoin.CONSULT_TM
,df_leftjoin.CONSULT_TYPE_CD
,df_leftjoin.PAT_ID
,df_leftjoin.CONSULT_PARTY_CD
,df_leftjoin.CONSULT_ACCEPT_IND
,df_leftjoin.RX_NBR
,df_leftjoin.STR_NBR
,df_leftjoin.CAMPGN_ID
,df_leftjoin.CAMPGN_COMPONENT_SEQ_ID
,df_leftjoin.COMPONENT_DCTNRY_ID
,df_leftjoin.CONSULT_CMNT
,df_leftjoin.EMP_INITIALS
,df_leftjoin.FREE_TXT_IND
,df_leftjoin.CONSULT_RSLT_CMNT
,df_leftjoin.CONSULT_RSLT_RPH_INITIALS
,df_leftjoin.CONSULT_RSLT_DTTM
,df_leftjoin.CONSULT_ADD_TYPE_CD
,df_leftjoin.RCA_CD_ID
,df_leftjoin.SRC_CREATE_USER_ID
,df_leftjoin.SRC_UPDATE_USER_ID
,df_leftjoin.SRC_CREATE_DTTM
,df_leftjoin.SRC_UPDATE_DTTM
,df_leftjoin.EDW_CREATE_DTTM
,df_leftjoin.EDW_BATCH_ID
,df_leftjoin.EDW_DML_IND)

# Reording_the_insert=
df_final_left_join.count()

# COMMAND ----------

#TRUNCATE RCA_PATIENT_CAMPAIGN_TMP TABLE
delete_SNFK_TBL_RCA_CONSULTATION_STG_tbl = "Truncate table {0}.{1}.{2}".format(SNFL_STG_DB,RCA_Schema,STG_TblName)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_SNFK_TBL_RCA_CONSULTATION_STG_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#UNION OF INSERT AND UPDATE RECORDS
df_union=df_src_final.unionByName(df_final_left_join)
#display(df_union)
df_union.count()

# COMMAND ----------

#INSERTING THE DATA TO RCA_CONSULTATION TABLE
# records not matched with table schema will be skipped here, OPTION(continue_on_error, on)
df_union.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_STG_DB) \
   .option("dbtable", RCA_Schema + '.' + STG_TblName) \
   .option("continue_on_error", "on") \
   .mode("append") \
   .save()

# COMMAND ----------

#CREATING A LOADREADY FILE
#from pyspark.sql import functions as F
#from pyspark.sql.functions import col
#from pyspark.sql.functions import *


#CONVERTING THE UPPERCASE COLUMN INTO LOWERCASE
df_q1_out=df_union.select([F.col(x).alias(x.lower()) for x in df_union.columns])
#display(df_q1_out)

#CREATING A LOADREADY FILE 
path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,PAR_OUTPUT_STG_FILE_3,EDW_BATCH_ID)
df_q1_out.write.format("parquet").mode("overwrite").save(path)

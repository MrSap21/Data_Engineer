# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# #INPUT PARAMETERS
# dbutils.widgets.text("PAR_DB_SNFK_WH","WBADEVDBENGINEER_WH")
# dbutils.widgets.text("PAR_DB_SNFK_DB_STG","DEV_STAGING")
# dbutils.widgets.text("pEDW_BATCH_ID","20220526153800")
# dbutils.widgets.text("PAR_DB_SNFK_DB_MRK","DEV_MARKETING")
# dbutils.widgets.text("PAR_DB_SNFK_CAMPAIGN_SCHEMA","CAMPAIGN")
# dbutils.widgets.text("PAR_DB_SNFK_TGT_TBL","RCA_PATIENT_CAMPAIGN")
# dbutils.widgets.text("PAR_DB_SNFK_PATIENT_SCHEMA","PATIENT")
# dbutils.widgets.text("PAR_DB_SNFK_MASTER_PATIENT_MERGE_TBL","MASTER_PATIENT_MERGE_STG")
# dbutils.widgets.text("PAR_DB_SNFK_CAMPAIGN_TMP_TBL","RCA_PATIENT_CAMPAIGN_TMP_STG")
# dbutils.widgets.text("PAR_DB_SNFK_CAMPAIGN_TBL","RCA_PATIENT_CAMPAIGN")
# dbutils.widgets.text("PAR_OUTPUT_FILE_PATH","marketing/campaign/staging")
# dbutils.widgets.text("PAR_OUTPUT_FILE_NAME","edw_rca_rca_patient_campaign_loadready")
# #Temp_table=dbutils.widgets.text("PAR_DB_SNFK_CAMPAIGN_STATUS_TMP_TBL","")
# dbutils.widgets.text("PAR_DB_SNFK_CAMPAIGN_STG_TBL","RCA_PATIENT_CAMPAIGN_ML_STG")
# dbutils.widgets.text("pIN_FILE","")#")

# COMMAND ----------

#INPUT PARAMETERS
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_STG_DB = dbutils.widgets.get("PAR_DB_SNFK_DB_STG")
EDW_BATCH_ID=dbutils.widgets.get("pEDW_BATCH_ID")
SNFL_MRKT_DB=dbutils.widgets.get("PAR_DB_SNFK_DB_MRK")
RCA_Schema=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_SCHEMA")
TgtTblName=dbutils.widgets.get("PAR_DB_SNFK_TGT_TBL")
Patient_Schema=dbutils.widgets.get("PAR_DB_SNFK_PATIENT_SCHEMA")
TableName_Master_Patient_Merge=dbutils.widgets.get("PAR_DB_SNFK_MASTER_PATIENT_MERGE_TBL")
SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_TMP_TBL")
SNWFLK_CAMPAIGN_TBL=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_TBL")
PAR_OUTPUT_STG_FILE_PATH=dbutils.widgets.get("PAR_OUTPUT_FILE_PATH")
PAR_OUTPUT_STG_FILE_3=dbutils.widgets.get("PAR_OUTPUT_FILE_NAME")
#Temp_table=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_STATUS_TMP_TBL")
TEMP_TgtTblName=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_STG_TBL")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit,col
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("pIN_FILE")
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

# COMMAND ----------

# Reading files contentfrom pyspark.sql.functions import *


schema = StructType() \
      .add("PAT_ID",DecimalType(13),True) \
      .add("PAT_EXC_SEQ_ID",IntegerType(),True) \
      .add("CAMPGN_COMPONENT_SEQ_ID",DecimalType(10),True)\
      .add("CAMPGN_ID",DecimalType(38),True) \
      .add("PAT_CAMPGN_MIN_START_DT",TimestampType(),True) \
      .add("COMPONENT_DCTNRY_ID",DecimalType(10),True)\
      .add("PAT_EXC_DTTM",TimestampType(),True) \
      .add("PAT_EXIT_DTTM",TimestampType(),True) \
      .add("PAT_STAT_IND",StringType(),True) \
      .add("SRC_CREATE_DTTM",TimestampType(),True) \
      .add("PAT_COMPONENT_SCORE",DecimalType(10),True)\
      .add("PAT_ENTER_DTTM",TimestampType(),True)
      

readList=[mountPoint + row[0] + '/' + row[1] for row in dfNamePath.select('filepath','filename').collect()]

dfMulti = spark.read.format("csv").schema(schema).option("sep","\ufffd").load(readList).withColumn("FileName", input_file_name())
#display(dfMulti)
# print(dfMulti.count())
#display(dfMulti)

# COMMAND ----------

#READING THE DATA FROM FILE DATAFRAME AND DOPPING THE FILENAME COLUMN

from pyspark.sql.window import Window
 
df_select=dfMulti.drop(col("FileName"))
display(df_select)

# COMMAND ----------

#MAKING A SORT ON PAT_ID,CAMPGN_ID IN ASC AND SRC_CREATE_DTTM IN DESC
df_sort=df_select.sort(col("PAT_ID").asc(),col("PAT_EXC_SEQ_ID").asc(),col("CAMPGN_ID").asc(),col("SRC_CREATE_DTTM").desc())
#display(df_sort)

# COMMAND ----------

#REMOVING DUPLICATES BASED ON PAT_ID,CAMPGN_ID 
df_dedup=df_sort.dropDuplicates(['PAT_ID','PAT_EXC_SEQ_ID','CAMPGN_ID'])

#display(df_dedup)
# print(df_sort.count())
# print(df_dedup.count())

# COMMAND ----------

#GETTING THE DATA FROM TARGET TABLE TO PERFORM CAMPARISSION BETWEEN SOURCE FILE AND TARGET TABLE
Input_Table ="""select
              merged_fm_pat_id as PAT_ID,
              PAT_EXC_SEQ_ID,
              CAMPGN_COMPONENT_SEQ_ID,
              CAMPGN_ID,
              PAT_CAMPGN_MIN_START_DT,
              COMPONENT_DCTNRY_ID,
              PAT_EXC_DTTM,PAT_EXIT_DTTM,
              trim(pat_stat_ind) PAT_STAT_IND ,
              SRC_CREATE_DTTM,
              PAT_COMPONENT_SCORE,
              PAT_ENTER_DTTM
FROM {0}.{1}.{2}""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName)

#REDAING THE DATA FROM PATIENT_CAMPAIGN TABLE
df_target_table = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", Input_Table) \
  .load()

# COMMAND ----------

# #GETTING THE DATA FROM ML TableTEMP_TgtTblName
# PAT_Table ="""select
#               merged_fm_pat_id as PAT_ID,
#               PAT_EXC_SEQ_ID,
#               CAMPGN_COMPONENT_SEQ_ID,
#               CAMPGN_ID,
#               PAT_CAMPGN_MIN_START_DT,
#               COMPONENT_DCTNRY_ID,
#               PAT_EXC_DTTM,PAT_EXIT_DTTM,
#               trim(pat_stat_ind) PAT_STAT_IND ,
#               SRC_CREATE_DTTM,
#               PAT_COMPONENT_SCORE,
#               PAT_ENTER_DTTM
# FROM {0}.{1}.{2}""".format(SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)

# #REDAING THE DATA FROM PATIENT_CAMPAIGN TABLE
# df_MERGE_table = spark.read \
#   .format("snowflake") \
#   .options(**options) \
#   .option("sfWarehouse", SNFL_WH) \
#   .option("query", PAT_Table) \
#   .load()

# COMMAND ----------

# df_target_table=df_camp.join(df_dedup, ((df_camp.PAT_ID==df_dedup.PAT_ID) & (df_camp.CAMPGN_COMPONENT_SEQ_ID==df_dedup.CAMPGN_COMPONENT_SEQ_ID) & (df_camp.PAT_EXC_SEQ_ID==df_dedup.PAT_EXC_SEQ_ID)), 'inner').select(df_camp['*'])

# COMMAND ----------

#MAKING AN INNER JOIN TO GET UPDATE RECORDS, DERIVING THE EDW_DML_IND COLUMN

df_join1=df_dedup.alias("in0").join(df_target_table.alias("in1"),(  (df_dedup.PAT_ID==df_target_table.PAT_ID)  &       (df_dedup.CAMPGN_ID==df_target_table.CAMPGN_ID) & (df_dedup.PAT_EXC_SEQ_ID==df_target_table.PAT_EXC_SEQ_ID)  ),"inner")\
.select(col("in0.PAT_ID").alias("MERGED_FM_PAT_ID"),df_dedup['*']).withColumn("EDW_CREATE_DTTM",current_timestamp()).withColumn("EDW_BATCH_ID", lit(EDW_BATCH_ID))\
.withColumn("EDW_DML_IND",lit("U"))

#display(join1)

# COMMAND ----------

#MAKING leftAntijoin TO GET THE INSERT RECORDS
df_leftAntijoin=df_dedup.alias("in0").join(df_target_table.alias("in1"),( (df_dedup.PAT_ID==df_target_table.PAT_ID)  &       (df_dedup.CAMPGN_ID==df_target_table.CAMPGN_ID) & (df_dedup.PAT_EXC_SEQ_ID==df_target_table.PAT_EXC_SEQ_ID)),"leftanti")\
.select(col("in0.PAT_ID").alias("MERGED_FM_PAT_ID"),df_dedup['*'])\
.withColumn("EDW_CREATE_DTTM",current_timestamp()).withColumn("EDW_BATCH_ID", lit(EDW_BATCH_ID))\
.withColumn("EDW_DML_IND",lit("I"))

# display(df_leftAntijoin)

# COMMAND ----------

#Condition Partition Started

#SORT ON PAT_ID,CAMPGN_ID
df_conditional_sort=df_leftAntijoin.sort("PAT_ID","CAMPGN_ID","PAT_EXC_SEQ_ID")

#REMOVE DUPLICATES ON PAT_ID,CAMPGN_ID
df_conditional_dedup=df_conditional_sort.dropDuplicates(['PAT_ID','CAMPGN_ID','PAT_EXC_SEQ_ID'])

# print(df_conditional_sort.count())
# print(df_conditional_dedup.count())

# COMMAND ----------

#TRUNCATE RCA_PATIENT_CAMPAIGN_TMP TABLE
delete_SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP_tbl = "Truncate table {0}.{1}.{2}".format(SNFL_STG_DB,RCA_Schema,SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#SELECTING REQUIRED COLUMNS FOR RCA_PATIENT_CAMPAIGN_TMP TABLE
df_select=df_conditional_dedup.select(df_conditional_dedup.PAT_ID,df_conditional_dedup.CAMPGN_ID)

# COMMAND ----------

#INSERTING THE DATA TO RCA_PATIENT_CAMPAIGN_TMP TABLE
df_select.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_STG_DB) \
   .option("dbtable", "CAMPAIGN.RCA_PATIENT_CAMPAIGN_TMP_STG") \
   .option("ON_ERROR", "CONTINUE") \
   .mode("append") \
   .save()

# COMMAND ----------

#REDAING THE DATA FROM RCA_PATIENT_CAMPAIGN AND RCA_PATIENT_CAMPAIGN_TMP TABLE
Input_table18="""select 
a.merged_fm_pat_id as PAT_ID,
a.campgn_id AS CAMPGN_ID,
min(src_create_dttm) as PAT_CAMPGN_MIN_START_DT
from {0}.{1}.{2} a ,
{3}.{1}.{4} b
where a.merged_fm_pat_id= b.pat_id
and a.campgn_id = b.campgn_id
group by ( a.merged_fm_pat_id, a.campgn_id)""".format(SNFL_MRKT_DB,RCA_Schema,SNWFLK_CAMPAIGN_TBL,SNFL_STG_DB,SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP)

# COMMAND ----------

df_Input_table18 = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", Input_table18) \
  .load()

#display(df_Input_table18)

# COMMAND ----------

#MAKING A FULLOUTER JOIN TO GET ALL RECORDS
df_join20=df_leftAntijoin.alias("in0").join(df_Input_table18.alias("in1"),(  (df_leftAntijoin.PAT_ID==df_Input_table18.PAT_ID)  &       (df_leftAntijoin.CAMPGN_ID==df_Input_table18.CAMPGN_ID)),"fullouter")\
.select(df_leftAntijoin['*'],df_Input_table18.PAT_CAMPGN_MIN_START_DT).drop(df_leftAntijoin.PAT_CAMPGN_MIN_START_DT)
 

# COMMAND ----------

#MAKING AN INNER JOIN TO GET THE REQUIRED DATA
df_join23=df_conditional_dedup.alias("in0").join(df_join20.alias("in1"),(  (df_conditional_dedup.PAT_ID==df_join20.PAT_ID)  &       (df_conditional_dedup.CAMPGN_ID==df_join20.CAMPGN_ID) & (df_conditional_dedup.PAT_EXC_SEQ_ID==df_join20.PAT_EXC_SEQ_ID)),"inner")\
.select(df_join20['*'],coalesce(col("in1.PAT_CAMPGN_MIN_START_DT"),col("in0.PAT_CAMPGN_MIN_START_DT")).alias("PAT_CAMPGN_MIN_START_DT_TEMP")).drop(df_join20.PAT_CAMPGN_MIN_START_DT)\
.withColumnRenamed('PAT_CAMPGN_MIN_START_DT_TEMP','PAT_CAMPGN_MIN_START_DT')\
#display(df_join23)

# COMMAND ----------

#UNION OF INSERT AND UPDATE RECORDS
df_union=df_join1.unionByName(df_join23)
#display(df_union)

df_union=df_union.select('MERGED_FM_PAT_ID','CAMPGN_COMPONENT_SEQ_ID','PAT_EXC_SEQ_ID','PAT_ID','CAMPGN_ID','PAT_CAMPGN_MIN_START_DT','COMPONENT_DCTNRY_ID','PAT_EXC_DTTM','PAT_EXIT_DTTM','PAT_STAT_IND','SRC_CREATE_DTTM','PAT_COMPONENT_SCORE','PAT_ENTER_DTTM','EDW_CREATE_DTTM','EDW_BATCH_ID','EDW_DML_IND')


# COMMAND ----------

#CREATING A LOADREADY FILE
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.sql.functions import *


#CREATING A LOADREADY FILE 
path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,PAR_OUTPUT_STG_FILE_3,EDW_BATCH_ID)
df_union.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

#TRUNCATING THE STAGING TABLE
df_truncate_ML_table="Truncate table {0}.{1}.{2}".format(SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : df_truncate_ML_table, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


# COMMAND ----------

#INSERTING THE DATA INTO STAGING TABLE
df_union.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_STG_DB) \
   .option("dbtable", "CAMPAIGN.RCA_PATIENT_CAMPAIGN_ML_STG") \
   .option("ON_ERROR", "CONTINUE") \
   .mode("append") \
   .save()

# COMMAND ----------

#UPDATING THE DATA FROM STAGING TABLES TO TARGET TABLE FOR UPDATE RECORDS
# Df_update_target_table="""update {0}.{1}.{2} tgt
# from {3}.{4}.{5} stg
# SET  tgt.pat_exc_seq_id = stg.pat_exc_seq_id ,
#          tgt.campgn_component_seq_id = stg.campgn_component_seq_id,
#          tgt.campgn_id= stg.campgn_id,
#          tgt.component_dctnry_id = stg.component_dctnry_id,
#          tgt.pat_exc_dttm= stg.pat_exc_dttm,
#          tgt.pat_exit_dttm= stg.pat_exit_dttm,
#          tgt.pat_stat_ind= stg.pat_stat_ind,
#          tgt.src_create_dttm= stg.src_create_dttm,
#          tgt.pat_component_score= stg.pat_component_score,
#          tgt.pat_enter_dttm= stg.pat_enter_dttm,
#          tgt.edw_batch_id = stg.edw_batch_id
# WHERE tgt.merged_fm_pat_id=stg.merged_fm_pat_id
# and tgt.campgn_component_seq_id=stg.campgn_component_seq_id
# and tgt.pat_exc_seq_id=stg.pat_exc_seq_id and (tgt.campgn_id!=stg.campgn_id or          
# tgt.component_dctnry_id != stg.component_dctnry_id or
#          tgt.pat_exc_dttm!= stg.pat_exc_dttm or
#          tgt.pat_exit_dttm!= stg.pat_exit_dttm or
#          tgt.pat_stat_ind!= stg.pat_stat_ind or
#          tgt.src_create_dttm!= stg.src_create_dttm or
#          tgt.pat_component_score!= stg.pat_component_score or
#          tgt.pat_enter_dttm!= stg.pat_enter_dttm)
# and edw_dml_ind='U' """.format(SNFL_MRKT_DB,RCA_Schema,TgtTblName,SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)

# dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : Df_update_target_table, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_MRKT_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})
# %run Abinitio_Rebuild/Utilities/RunSnowSQL $query= Df_update_target_table,$transaction= True,$SNOWFLAKE_DATABASE= SNFL_MRKT_DB,$SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#INSERTING THE DATA FROM STAGING TABLES TO TARGET TABLE FOR INSERT RECORDS
# Df_Insert_target_table="""INSERT INTO {0}.{1}.{2}
# SELECT  merged_fm_pat_id,
#         campgn_component_seq_id,
#         pat_exc_seq_id,
#         pat_id,
#         campgn_id,
#         pat_campgn_min_start_dt,
#         component_dctnry_id,
#         pat_exc_dttm,
#         pat_exit_dttm,
#         pat_stat_ind,
#         src_create_dttm,
#         pat_component_score,
#         pat_enter_dttm,
#         edw_create_dttm,
#         edw_batch_id
# FROM {3}.{4}.{5}
# where edw_dml_ind='I'""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName,SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)

# dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : Df_Insert_target_table, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_MRKT_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#UPDATING THE DATA FROM STAGING PATIENT TABLES TO TARGET TABLE FOR MATCHING merged_fm_pat_id
# generic_130_update="""UPDATE {0}.{1}.{2} tgt 
#                 set tgt.pat_id = mpm1.pat_id
#                 FROM    {3}.{4}.{5} mpm1
#                 where tgt.merged_fm_pat_id=mpm1.merged_fm_pat_id 
#                 and tgt.pat_id <> mpm1.pat_id
#                 and mpm1.edw_batch_id = (select max(mpm2.edw_batch_id)
#                 from {3}.{4}.{5} mpm2
#                 where mpm1.merged_fm_pat_id=mpm2.merged_fm_pat_id)""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName,SNFL_STG_DB,Patient_Schema,TableName_Master_Patient_Merge)
               
# dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : generic_130_update, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

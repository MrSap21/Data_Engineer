# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

# initializing variables

BATCH_ID = dbutils.widgets.get("PAR_DB_BATCH_ID")
INPUT_FILE = dbutils.widgets.get("PAR_DB_INPUT_FILENAME")
INPUT_FILEPATH = dbutils.widgets.get("PAR_DB_INPUT_PATH")
OUTPUT_PATH = dbutils.widgets.get("PAR_DB_OUTPUT_PATH")
OUTPUT_FILENAME = dbutils.widgets.get("PAR_DB_OUTPUT_FILENAME")
SNFL_STG_DB = dbutils.widgets.get("PAR_DB_SNFLK_DB_STAGING")
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
CIF_TABLE = dbutils.widgets.get("PAR_DB_SNFLK_CIF_TABLE")
TABLE_SCHEMA = dbutils.widgets.get("PAR_DB_SNFLK_DB_SCHEMA")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

import os
from pyspark.sql.types import *
from pyspark.sql.functions import * 

schema = StructType() \
      .add("wic_nbr",StringType(),True) \
      .add("upc_nbr",StringType(),True) \
      .add("loc_id",StringType(),True) \
      .add("vend_id",StringType(),True) \
      .add("deal_id",StringType(),True) \
      .add("adv_evnt_typ",StringType(),True) \
      .add("adv_evnt_seq_nbr",StringType(),True) \
      .add("adv_evnt_ver_typ_cd",StringType(),True) \
      .add("adv_evnt_ver_seq_nbr",StringType(),True) \
      .add("adv_offer_cd",StringType(),True) \
      .add("transaction_dt",StringType(),True) \
      .add("posted_dt",StringType(),True) \
      .add("transaction_cnt",StringType(),True) \
      .add("int_ext_fund_ind",StringType(),True) \
      .add("dlrs_tendered",StringType(),True) \
      .add("points",StringType(),True) \
      .add("rate",StringType(),True) \
      .add("dlrs_rate",StringType(),True)


dfMulti = spark.read.format("csv").schema(schema).option("sep","\ufffd").load(mountPoint + '/'+INPUT_FILEPATH + INPUT_FILE)
      

# COMMAND ----------

print(mountPoint + '/' + INPUT_FILEPATH + INPUT_FILE)

# COMMAND ----------

#REMOVE DUPLICATE RECORDS
df_valid_rec = dfMulti.dropDuplicates(['wic_nbr','upc_nbr','loc_id','adv_evnt_typ','adv_evnt_seq_nbr','adv_evnt_ver_typ_cd','adv_evnt_ver_seq_nbr','adv_offer_cd','transaction_dt'])


# COMMAND ----------

df_valid_rec.createOrReplaceTempView("df_derived")

# COMMAND ----------

qry = """
select 
case when LENGTH(trim(wic_nbr)) > 0 then substring(trim(wic_nbr),2,length(trim(wic_nbr))) else null end as wic,
case when LENGTH(trim(upc_nbr)) > 0 then trim(upc_nbr) else null end as upc_nbr,
case when LENGTH(trim(loc_id)) > 0 and loc_id == -1 then '-1' else trim(loc_id) end as store_nbr,
case when LENGTH(trim(adv_evnt_typ)) > 0 and adv_evnt_typ == 'NA' then '#' else trim(adv_evnt_typ) end as ad_evt_typ,
case when LENGTH(trim(adv_evnt_seq_nbr)) > 0 and adv_evnt_seq_nbr == 'NA' then '#' else trim(adv_evnt_seq_nbr) end as ad_evt_seq_nbr,
case when LENGTH(trim(adv_evnt_ver_typ_cd)) > 0 and adv_evnt_ver_typ_cd == 'NA' then '#' else trim(adv_evnt_ver_typ_cd) end as ad_evt_vers_typ_cd,
case when LENGTH(trim(adv_evnt_ver_seq_nbr)) > 0 and adv_evnt_ver_seq_nbr == 'NA' then '#' else trim(adv_evnt_ver_seq_nbr) end as ad_evt_ver_seq_nbr,
case when LENGTH(trim(adv_offer_cd)) > 0 and adv_offer_cd == 'NA' then '#' else trim(adv_offer_cd) end as ad_offer_cd,
case when LENGTH(trim(transaction_dt)) > 0 and LENGTH(trim(transaction_dt)) == 8 then concat(substring(transaction_dt,1,4),'-',substring(transaction_dt,5,2),'-',substring(transaction_dt,7,2)) else null end as sales_txn_dt,
case when LENGTH(trim(posted_dt)) > 0 and LENGTH(trim(posted_dt)) == 8 then to_timestamp(concat(substring(posted_dt,1,4),'-',substring(posted_dt,5,2),'-',substring(posted_dt,7,2))) else null end as postd_dttm,
case when LENGTH(trim(vend_id)) > 0 and vend_id == '-1' then null else trim(vend_id) end as vndr_id,
case when LENGTH(trim(deal_id)) > 0 and deal_id == '-1' then null else trim(deal_id) end as deal_id,
case when LENGTH(trim(transaction_cnt)) > 0 then trim(transaction_cnt) else null end as txn_cnt,
case when LENGTH(trim(dlrs_tendered)) > 0 then trim(dlrs_tendered) else null end as dlrs_tendered,
case when LENGTH(trim(points)) > 0 then trim(points) else null end as points,
case when LENGTH(trim(rate)) > 0 then trim(rate) else null end as rate,
case when LENGTH(trim(dlrs_rate)) > 0 then trim(dlrs_rate) else null end as calc_cost,
case when LENGTH(trim(int_ext_fund_ind)) > 0 then trim(int_ext_fund_ind) else null end as int_ext_fund_ind
from df_derived"""

dfFinal = spark.sql(qry)

# COMMAND ----------

#TRUNCATE CIF TABLE CIF_LTY_MSS_VENDOR_DEAL_STG
delete_SNFK_TBL_CIF_LTY_MSS_VENDOR_DEAL_STG = "Truncate table {0}.{1}.{2}".format(SNFL_STG_DB,TABLE_SCHEMA,CIF_TABLE)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_SNFK_TBL_CIF_LTY_MSS_VENDOR_DEAL_STG, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#CREATING A LOADREADY FILE 
path="{0}/{1}/{2}/{3}".format(mountPoint,OUTPUT_PATH,OUTPUT_FILENAME,BATCH_ID)
dfFinal.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

from pyspark.sql import functions as F
#INSERTING THE DATA TO CIF_LTY_MSS_VENDOR_DEAL_STG TABLE
dfFinal.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_STG_DB) \
   .option("dbtable", TABLE_SCHEMA + '.' + CIF_TABLE) \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

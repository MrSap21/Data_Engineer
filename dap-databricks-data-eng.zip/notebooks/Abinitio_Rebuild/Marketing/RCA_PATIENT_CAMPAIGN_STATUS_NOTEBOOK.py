# Databricks notebook source
# Mounting ADLS

mountPoint = dbutils.notebook.run("/Abinitio_Rebuild/Utilities/MOUNT_ADLS_SETUP", 60)

# COMMAND ----------

#INPUT PARAMETERS
SNFL_WH = dbutils.widgets.get("PAR_DB_SNFK_WH")
SNFL_STG_DB = dbutils.widgets.get("PAR_DB_SNFK_DB_STG")
EDW_BATCH_ID=dbutils.widgets.get("pEDW_BATCH_ID")
SNFL_MRKT_DB=dbutils.widgets.get("PAR_DB_SNFK_DB_MRK")
RCA_Schema=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_SCHEMA")
TgtTblName=dbutils.widgets.get("PAR_DB_SNFK_TGT_TBL")
Patient_Schema=dbutils.widgets.get("PAR_DB_SNFK_PATIENT_SCHEMA")
TableName_Master_Patient_Merge=dbutils.widgets.get("PAR_DB_SNFK_MASTER_PATIENT_MERGE_TBL")
SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_TMP_TBL")
SNWFLK_CAMPAIGN_TBL=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_TBL")
PAR_OUTPUT_STG_FILE_PATH=dbutils.widgets.get("PAR_OUTPUT_FILE_PATH")
PAR_OUTPUT_STG_FILE_3=dbutils.widgets.get("PAR_OUTPUT_FILE_NAME")
#Temp_table=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_STATUS_TMP_TBL")
TEMP_TgtTblName=dbutils.widgets.get("PAR_DB_SNFK_CAMPAIGN_STATUS_STG_TBL")

# COMMAND ----------

# MAGIC %run Abinitio_Rebuild/Utilities/SnowflakeConnOptions $SNOWFLAKE_DATABASE=SNFL_STG_DB $SNOWFLAKE_WAREHOUSE=SNFL_WH

# COMMAND ----------

#Convert json asset location/filname to Multi FIle Name List
import json
from pyspark.sql import functions as F
from pyspark.sql.functions import concat,lit,col
from pyspark.sql.types import *

inputFileList= dbutils.widgets.get("pIN_FILE")
rddjson = sc.parallelize([inputFileList])
#print(rddjson.collect())

dfFileList = sqlContext.read.json(rddjson)
dfRaw = dfFileList.select(concat(lit('/'),dfFileList.assetcurrentlocation,lit('/'),dfFileList.assetname).alias('full_filename'))

#display(dfRaw)

#Create list of asset id's to return for WriteAPI
dfAssetId = dfFileList.select(dfFileList.assetid).alias('assetid')
dfAssetIdArray = [int(row['assetid']) for row in dfAssetId.collect()]
dfAssetIdStr=str(dfAssetIdArray).replace("[","").replace("]","")
#print(dfAssetIdStr)

# COMMAND ----------

# Extracting File Name and Path

import os
from pyspark.sql.functions import *

getPathUDF = udf(lambda z:z[0:str.rindex(z, "/")],StringType())
getNameUDF = udf(lambda z:z[str.rindex(z, "/") + 1:len(z)],StringType())

dfNamePath = dfRaw\
             .withColumn("filepath", getPathUDF("full_filename"))\
             .withColumn("filename", getNameUDF("full_filename"))\
             .drop("full_filename")

display(dfNamePath)

# COMMAND ----------

# Reading files contentfrom pyspark.sql.functions import *


schema = StructType() \
      .add("PAT_ID",DecimalType(13),True) \
      .add("CAMPGN_ID",DecimalType(38),True) \
      .add("PAT_CAMPGN_MIN_START_DT",StringType(),True) \
      .add("STAT_CD",StringType(),True) \
      .add("SRC_CREATE_DTTM",TimestampType(),True) \
      .add("SRC_UPDATE_DTTM",TimestampType(),True)
      

readList=[mountPoint + row[0] + '/' + row[1] for row in dfNamePath.select('filepath','filename').collect()]

dfMulti = spark.read.format("csv").schema(schema).option("sep","\ufffd").load(readList).withColumn("FileName", input_file_name())
#display(dfMulti)
#print(dfMulti.count())
#display(dfMulti)

# COMMAND ----------

#READING THE DATA FROM FILE DATAFRAME AND DOPPING THE FILENAME COLUMN

from pyspark.sql.window import Window
 
df_select=dfMulti.select(col("PAT_ID"),col("CAMPGN_ID"),col("PAT_CAMPGN_MIN_START_DT").cast("date"),
                        col("STAT_CD"),col("SRC_CREATE_DTTM").cast("timestamp"),col("SRC_UPDATE_DTTM").cast("timestamp")).drop(col("FileName"))
# display(df_select)

# COMMAND ----------

#MAKING A SORT ON PAT_ID,CAMPGN_ID IN ASC AND SRC_CREATE_DTTM IN DESC
df_sort=df_select.sort(col("PAT_ID").asc(),col("CAMPGN_ID").asc(),col("SRC_CREATE_DTTM").desc())
#display(df_sort)

# COMMAND ----------

#REMOVING DUPLICATES BASED ON PAT_ID,CAMPGN_ID 
df_dedup=df_sort.dropDuplicates(['PAT_ID','CAMPGN_ID'])

# COMMAND ----------

#GETTING THE DATA FROM TARGET TABLE TO PERFORM CAMPARISSION BETWEEN SOURCE FILE AND TARGET TABLE
Input_Table ="""select
              merged_fm_pat_id as PAT_ID,
              campgn_id,
              trim(stat_cd) stat_cd ,
              src_create_dttm ,
              src_update_dttm
FROM {0}.{1}.{2}""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName)

# COMMAND ----------

#REDAING THE DATA FROM TARGET TABLE
df_target_table = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", Input_Table) \
  .load()

#display(df_target_table)

# COMMAND ----------

#MAKING AN INNER JOIN TO GET UPDATE RECORDS, DERIVING THE EDW_DML_IND COLUMN

join1=df_dedup.alias("in0").join(df_target_table.alias("in1"),(  (df_dedup.PAT_ID==df_target_table.PAT_ID)  &       (df_dedup.CAMPGN_ID==df_target_table.CAMPGN_ID)),"inner").select(col("in0.PAT_ID"),col("in0.CAMPGN_ID"),col("in0.PAT_CAMPGN_MIN_START_DT"),col("in0.STAT_CD"),col("in0.SRC_CREATE_DTTM"),col("in0.SRC_UPDATE_DTTM"),lit("U").alias("EDW_DML_IND"),col("in0.PAT_ID").alias("MERGED_FM_PAT_ID")).withColumn("EDW_BATCH_ID", lit(EDW_BATCH_ID)).withColumn("EDW_CREATE_DTTM",current_timestamp())

#display(join1)

# COMMAND ----------

#SELECTING THE LIST OF THE COLUMNS IN ORDER
Reording_the_update=join1.select(join1.PAT_ID
,join1.CAMPGN_ID
,join1.PAT_CAMPGN_MIN_START_DT
,join1.STAT_CD
,join1.SRC_CREATE_DTTM
,join1.SRC_UPDATE_DTTM                                
,join1.EDW_DML_IND
,join1.EDW_BATCH_ID
,join1.EDW_CREATE_DTTM
,join1.MERGED_FM_PAT_ID)

# COMMAND ----------

#MAKING leftAntijoin TO GET THE INSERT RECORDS
df_leftAntijoin=df_dedup.alias("in0").join(df_target_table.alias("in1"),(  (df_dedup.PAT_ID==df_target_table.PAT_ID)  &       (df_dedup.CAMPGN_ID==df_target_table.CAMPGN_ID)),"leftanti").select(col("in0.PAT_ID"),col("in0.CAMPGN_ID"),col("in0.PAT_CAMPGN_MIN_START_DT"),col("in0.STAT_CD"),col("in0.SRC_CREATE_DTTM"),col("in0.SRC_UPDATE_DTTM"),lit("I").alias("EDW_DML_IND"),col("in0.PAT_ID").alias("MERGED_FM_PAT_ID")).withColumn("EDW_BATCH_ID", lit(EDW_BATCH_ID)).withColumn("EDW_CREATE_DTTM",current_timestamp())

#display(df_leftAntijoin)

# COMMAND ----------

#SELECTING THE COLUMNS IN ORDER
Reording_the_insert=df_leftAntijoin.select(df_leftAntijoin.PAT_ID
,df_leftAntijoin.CAMPGN_ID
,df_leftAntijoin.PAT_CAMPGN_MIN_START_DT
,df_leftAntijoin.STAT_CD
,df_leftAntijoin.SRC_CREATE_DTTM
,df_leftAntijoin.SRC_UPDATE_DTTM                                          
,df_leftAntijoin.EDW_DML_IND
,df_leftAntijoin.EDW_BATCH_ID
,df_leftAntijoin.EDW_CREATE_DTTM
,df_leftAntijoin.MERGED_FM_PAT_ID)
#display(Reording_the_insert)

# COMMAND ----------

#Condition Partition Started

#SORT ON PAT_ID,CAMPGN_ID
df_conditional_sort=df_leftAntijoin.sort("PAT_ID","CAMPGN_ID")

#REMOVE DUPLICATES ON PAT_ID,CAMPGN_ID
df_conditional_dedup=df_conditional_sort.dropDuplicates(['PAT_ID','CAMPGN_ID'])

#print(df_conditional_sort.count())
#print(df_conditional_dedup.count())

# COMMAND ----------

#TRUNCATE RCA_PATIENT_CAMPAIGN_TMP TABLE
delete_SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP_tbl = "Truncate table {0}.{1}.{2}".format(SNFL_STG_DB,RCA_Schema,SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : delete_SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP_tbl, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#SELECTING REQUIRED COLUMNS FOR RCA_PATIENT_CAMPAIGN_TMP TABLE
df_select=df_conditional_dedup.select(df_conditional_dedup.PAT_ID,df_conditional_dedup.CAMPGN_ID)

# COMMAND ----------

#INSERTING THE DATA TO RCA_PATIENT_CAMPAIGN_TMP TABLE
df_select.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_STG_DB) \
   .option("dbtable", "CAMPAIGN.RCA_PATIENT_CAMPAIGN_TMP_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

#REDAING THE DATA FROM RCA_PATIENT_CAMPAIGN AND RCA_PATIENT_CAMPAIGN_TMP TABLE
Input_table18="""select 
a.merged_fm_pat_id as PAT_ID,
a.campgn_id AS CAMPGN_ID,
min(src_create_dttm) as PAT_CAMPGN_MIN_START_DT
from {0}.{1}.{2} a ,
{3}.{1}.{4} b
where a.merged_fm_pat_id= b.pat_id
and a.campgn_id = b.campgn_id
group by ( a.merged_fm_pat_id, a.campgn_id)""".format(SNFL_MRKT_DB,RCA_Schema,SNWFLK_CAMPAIGN_TBL,SNFL_STG_DB,SNFK_TBL_RCA_PATIENT_CAMPAIGN_TMP)

# COMMAND ----------

df_Input_table18 = spark.read \
  .format("snowflake") \
  .options(**options) \
  .option("sfWarehouse", SNFL_WH) \
  .option("query", Input_table18) \
  .load()

#display(df_Input_table18)

# COMMAND ----------

#MAKING A FULLOUTER JOIN TO GET ALL RECORDS
df_join20=Reording_the_insert.alias("in0").join(df_Input_table18.alias("in1"),(  (Reording_the_insert.PAT_ID==df_Input_table18.PAT_ID)  &       (Reording_the_insert.CAMPGN_ID==df_Input_table18.CAMPGN_ID)),"fullouter").select(col("in0.PAT_ID"),col("in0.CAMPGN_ID"),col("in1.PAT_CAMPGN_MIN_START_DT"),col("in0.STAT_CD"),col("in0.SRC_CREATE_DTTM"),col("in0.SRC_UPDATE_DTTM"),col("in0.EDW_DML_IND"),col("in0.EDW_BATCH_ID"),col("in0.EDW_CREATE_DTTM"),col("in0.MERGED_FM_PAT_ID"))

#display(df_join20)
 

# COMMAND ----------

#display(df_conditional_dedup)

# COMMAND ----------

#MAKING AN INNER JOIN TO GET THE REQUIRED DATA
df_join23=df_conditional_dedup.alias("in0").join(df_join20.alias("in1"),(  (df_conditional_dedup.PAT_ID==df_join20.PAT_ID)  &       (df_conditional_dedup.CAMPGN_ID==df_join20.CAMPGN_ID)),"inner").select(col("in1.PAT_ID"),col("in1.CAMPGN_ID"),coalesce(col("in1.PAT_CAMPGN_MIN_START_DT"),col("in0.PAT_CAMPGN_MIN_START_DT")).alias("PAT_CAMPGN_MIN_START_DT"),col("in1.STAT_CD"),col("in1.SRC_CREATE_DTTM"),col("in1.SRC_UPDATE_DTTM"),col("in1.EDW_DML_IND"),col("in1.EDW_BATCH_ID"),col("in1.EDW_CREATE_DTTM"),col("in1.MERGED_FM_PAT_ID"))
#display(df_join23)

# COMMAND ----------

#UNION OF INSERT AND UPDATE RECORDS
df_union=Reording_the_update.unionByName(df_join23)
#display(df_union)

# COMMAND ----------

#SELECTING THE COLUMNS IN ORDER
df_Reording_Column = df_union.select(df_union.MERGED_FM_PAT_ID
,df_union.CAMPGN_ID
,df_union.PAT_ID
,df_union.PAT_CAMPGN_MIN_START_DT
,df_union.STAT_CD
,df_union.SRC_CREATE_DTTM
,df_union.SRC_UPDATE_DTTM                                   
,df_union.EDW_CREATE_DTTM
,df_union.EDW_BATCH_ID
,df_union.EDW_DML_IND)


#display(df_Reording_Column)

# COMMAND ----------

#CREATING A LOADREADY FILE
#from pyspark.sql import functions as F
#from pyspark.sql.functions import col
#from pyspark.sql.functions import *


#CONVERTING THE UPPERCASE COLUMN INTO LOWERCASE
df_q1_out=df_Reording_Column.select([F.col(x).alias(x.lower()) for x in df_Reording_Column.columns])
#display(df_q1_out)

#CREATING A LOADREADY FILE 
path="{0}/{1}/{2}/{3}".format(mountPoint,PAR_OUTPUT_STG_FILE_PATH,PAR_OUTPUT_STG_FILE_3,EDW_BATCH_ID)
df_q1_out.write.format("parquet").mode("overwrite").save(path)

# COMMAND ----------

#TRUNCATING THE STAGING TABLE
df_truncate_ML_table="Truncate table {0}.{1}.{2}".format(SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)

dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : df_truncate_ML_table, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})


# COMMAND ----------

#INSERTING THE DATA INTO STAGING TABLE
df_Reording_Column.write \
   .format("snowflake") \
   .options(**options) \
   .option("sfWarehouse", SNFL_WH) \
   .option("sfDatabase", SNFL_STG_DB) \
   .option("dbtable", "CAMPAIGN.RCA_PATIENT_CAMPAIGN_STATUS_ML_STG") \
   .option("ON_ERROR", "SKIP_FILE") \
   .mode("append") \
   .save()

# COMMAND ----------

#UPDATING THE DATA FROM STAGING TABLES TO TARGET TABLE FOR UPDATE RECORDS
# Df_update_target_table="""update {0}.{1}.{2} tgt
# from {3}.{4}.{5} stg
# SET     tgt.campgn_id = stg.campgn_id,
#         tgt.stat_cd = stg.stat_cd,
#         tgt.src_create_dttm = stg.src_create_dttm,
#         tgt.src_update_dttm = stg.src_update_dttm,
#         tgt.edw_batch_id = stg.edw_batch_id
# WHERE tgt.merged_fm_pat_id=stg.merged_fm_pat_id
# and tgt.campgn_id = stg.campgn_id
# and edw_dml_ind='U' and (tgt.stat_cd != stg.stat_cd or tgt.src_create_dttm != stg.src_create_dttm or tgt.src_update_dttm != stg.src_update_dttm)""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName,SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)


# dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : Df_update_target_table, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_MRKT_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#and (   tgt.stat_cd != stg.stat_cd or
     #   tgt.src_create_dttm != stg.src_create_dttm or
      #  tgt.src_update_dttm != stg.src_update_dttm)

# COMMAND ----------

#INSERTING THE DATA FROM STAGING TABLES TO TARGET TABLE FOR INSERT RECORDS
# Df_Insert_target_table="""INSERT INTO {0}.{1}.{2}
# SELECT  merged_fm_pat_id,
#         campgn_id,
#         pat_id,
#         pat_campgn_min_start_dt,
#         stat_cd,
#         src_create_dttm,
#         src_update_dttm,
#         edw_create_dttm,
#         edw_batch_id
# FROM {3}.{4}.{5}
# where edw_dml_ind='I'""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName,SNFL_STG_DB,RCA_Schema,TEMP_TgtTblName)

# dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : Df_Insert_target_table, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_MRKT_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

# COMMAND ----------

#UPDATING THE DATA FROM STAGING PATIENT TABLES TO TARGET TABLE FOR MATCHING merged_fm_pat_id
# generic_130_update="""UPDATE {0}.{1}.{2} tgt 
#                 set tgt.pat_id = mpm1.pat_id
#                 FROM    {3}.{4}.{5} mpm1
#                 where tgt.merged_fm_pat_id=mpm1.merged_fm_pat_id 
#                 and tgt.pat_id <> mpm1.pat_id
#                 and mpm1.edw_batch_id = (select max(mpm2.edw_batch_id)
#                 from {3}.{4}.{5} mpm2
#                 where mpm1.merged_fm_pat_id=mpm2.merged_fm_pat_id)""".format(SNFL_MRKT_DB,RCA_Schema,TgtTblName,SNFL_STG_DB,Patient_Schema,TableName_Master_Patient_Merge)
               
# dbutils.notebook.run("/Abinitio_Rebuild/Utilities/RunSnowSQL",1000, { "query" : generic_130_update, "transaction" : True, "SNOWFLAKE_DATABASE" : SNFL_STG_DB,"SNOWFLAKE_WAREHOUSE" : SNFL_WH})

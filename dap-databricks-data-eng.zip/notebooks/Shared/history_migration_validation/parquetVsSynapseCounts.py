# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):
  new_row.write \
    .format("com.microsoft.sqlserver.jdbc.spark") \
    .mode("append") \
    .option("url", url) \
    .option("dbtable", "dbo.validationstatus_"+migration_id) \
    .option("accessToken", access_token) \
    .option("encrypt", "true") \
    .option("hostNameInCertificate", "*.database.windows.net") \
    .option("mssqlIsolationLevel", "READ_UNCOMMITTED")\
    .save()
  
def get_target_schema(database,table): 
  if environment.lower() == 'pro' or environment.lower() == 'uat':
    target_schema = "dbo"
  else:
    synapse_query = "select target_schema_name from dbo.source_target_cross_ref where source_schema_name = '"+database+"' and source_table_name= '"+table+"'"

    df_target_schema = spark.read \
              .format("com.microsoft.sqlserver.jdbc.spark") \
              .option("url", url) \
              .option("accessToken", access_token) \
              .option("encrypt", "true") \
              .option("hostNameInCertificate", "*.database.windows.net") \
              .option("query",synapse_query) \
              .load()

    target_schema = df_target_schema.collect()[0][0]
    
  return target_schema

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    parent_folder = "/mnt/landing"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)    
    file_row_count = df_file.count()
    adls_path_array = adls_path.strip().split('/')
    table_name = adls_path_array[len(adls_path_array) - 3]
    db_name = adls_path_array[len(adls_path_array) - 4]
    synapse_schema = get_target_schema(db_name,table_name)
    
    df_table = spark.read \
        .format("com.microsoft.sqlserver.jdbc.spark") \
        .option("url", url) \
        .option("accessToken", access_token) \
        .option("encrypt", "true") \
        .option("hostNameInCertificate", "*.database.windows.net") \
        .option("dbTable", synapse_schema+"."+table_name) \
        .load()

    table_row_count = df_table.count()

    validation_status = "Failure"

    if table_row_count == file_row_count:
      validation_status = "Success"

    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
  
    new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSynapseTable","ParquetVsSynapseRowCount",validation_status,"",file_row_count,table_row_count,None,None,migration_id,current_time)], schema=schema)
    write_to_synapse(new_row)

    if len(df_table.columns) == len(df_file.columns):
      validation_status = "Success"
    else:
      validation_status = "Failure"
   
    new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSynapseTable","ParquetVsSynapseColumnCount",validation_status,"",None,None,len(df_file.columns),len(df_table.columns),migration_id,current_time)], schema=schema)
   
    write_to_synapse(new_row)  

# COMMAND ----------


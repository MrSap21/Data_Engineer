# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
import pyarrow.parquet as pq
import os
from pyspark.sql.functions import udf, expr, concat, col

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):
  new_row.write \
    .format("com.microsoft.sqlserver.jdbc.spark") \
    .mode("append") \
    .option("url", url) \
    .option("dbtable", "dbo.validationstatus_"+migration_id) \
    .option("accessToken", access_token) \
    .option("encrypt", "true") \
    .option("hostNameInCertificate", "*.database.windows.net") \
    .option("mssqlIsolationLevel", "READ_UNCOMMITTED")\
    .save()

#function to fetch synapse schema name corresponding to the td schema
def get_target_schema(database,table):
  if environment.lower() == 'pro' or environment.lower() == 'uat':
    target_schema = "dbo"
  else:
    synapse_query = "select target_schema_name from dbo.source_target_cross_ref where source_schema_name = '"+database+"' and source_table_name= '"+table+"'"

    df_target_schema = spark.read \
              .format("com.microsoft.sqlserver.jdbc.spark") \
              .option("url", url) \
              .option("accessToken", access_token) \
              .option("encrypt", "true") \
              .option("hostNameInCertificate", "*.database.windows.net") \
              .option("query",synapse_query) \
              .load()
  
  target_schema = df_target_schema.collect()[0][0]
  return target_schema

#query to find number of td tables and dbname 
syn_query_tdname_tddb= "select databasename, tablename from dbo.teradatametadata_"+migration_id+" group by databasename, tablename"

df_tdname_tddb = spark.read \
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .option("url", url) \
            .option("accessToken", access_token) \
            .option("encrypt", "true") \
            .option("hostNameInCertificate", "*.database.windows.net") \
            .option("query",syn_query_tdname_tddb) \
            .load()

ls_tdname_tddb=[]
tdname_tddb=df_tdname_tddb.collect()
for k in tdname_tddb:
  
  error_file_path = '/dbfs/mnt/landing/common/tframework/tf_schemacomparisonfiles/td_vs_synapse_'+migration_id+'.csv'
  
  synapse_schema = get_target_schema(k[0],k[1])
  
  query_td_meta="select t.databasename as td_databasename, t.tablename as td_tablename, t.columnname as td_columnname, c.sy_type as td_columntype, t.nullable as td_nullable, t.columnlength as td_columnlength from dbo.teradatametadata_"+migration_id+" t left join (select td_type,sy_type from dbo.col_type_xref_csv where sy_type IS not NULL group by td_type,sy_type) c on (t.columntype = c.td_type) where t.databasename='"+k[0]+"' and t.tablename='"+k[1]+"'"
  
  query_sy_meta="select table_schema as sy_databasename, table_name as sy_tablename, column_name as sy_columnname, UPPER(data_type) as synapse_columntype, CASE WHEN is_nullable='YES' THEN 'Y' WHEN is_nullable='NO' THEN 'N' ELSE 'NA' END as sy_nullable, character_maximum_length as sy_columnlength from information_schema.columns where table_name='"+k[1]+"' and table_schema='"+synapse_schema+"'"
  
  df_td_meta = spark.read \
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .option("url", url) \
            .option("accessToken", access_token) \
            .option("encrypt", "true") \
            .option("hostNameInCertificate", "*.database.windows.net") \
            .option("query",query_td_meta) \
            .load()
  print('************df_td_meta META*************')
  df_td_meta.show()
    
  df_sy_meta = spark.read \
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .option("url", url) \
            .option("accessToken", access_token) \
            .option("encrypt", "true") \
            .option("hostNameInCertificate", "*.database.windows.net") \
            .option("query",query_sy_meta) \
            .load()
  print('************df_sy_meta META*************')
  df_sy_meta.show()
  
  df_join_tdsy = df_td_meta.join(df_sy_meta,df_td_meta.td_columnname==df_sy_meta.sy_columnname,'outer')
  
  df_join= df_join_tdsy.select ("td_databasename", "td_tablename", "td_columnname", "td_columntype", "td_nullable", "td_columnlength", "sy_databasename", "sy_tablename", "sy_columnname", "synapse_columntype", "sy_nullable", "sy_columnlength", expr("CASE WHEN (td_columnname=sy_columnname) AND (td_columntype=synapse_columntype) AND (td_nullable=sy_nullable) THEN 'SUCCESS' ELSE 'FAILURE' END AS Status"))
  print('************df_join META*************')
  df_join.show()
  
  df_validation=df_join.filter("Status ='FAILURE'")
  df_validation.show()
  
  diff_count = df_validation.count()
  
  if (diff_count==0):
    validation_status="Success"
  else:
    validation_status="Failure"
  pd = df_join.toPandas()
  pd.to_csv(error_file_path,index=False)
  current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
  new_row = spark.createDataFrame([(k[0],k[1],k[1],"CreateSynapseTable","TDVsSynapseSchema",validation_status,error_file_path,None,None,None,None,migration_id,current_time)], schema=schema)
  write_to_synapse(new_row)
      
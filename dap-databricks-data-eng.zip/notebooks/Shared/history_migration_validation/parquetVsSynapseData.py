# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import *

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def get_target_schema(database,table):  
  
  if environment.lower() == 'pro' or environment.lower() == 'uat':
    target_schema = "dbo"
  else:
    synapse_query = "select target_schema_name from dbo.source_target_cross_ref where source_schema_name = '"+database+"' and source_table_name= '"+table+"'"

    df_target_schema = spark.read \
              .format("com.microsoft.sqlserver.jdbc.spark") \
              .option("url", url) \
              .option("accessToken", access_token) \
              .option("encrypt", "true") \
              .option("hostNameInCertificate", "*.database.windows.net") \
              .option("query",synapse_query) \
              .load()

    target_schema = df_target_schema.collect()[0][0]
    
  return target_schema

#Checks for time data type in from dataframes
def checkifTimeOnly(fldname,dfx):
    sql1 = fldname + " is not null"
    rw2 = dfx.select(fldname).take(1)[0]
    
    if (rw2[0] != None):
      rw = dfx.select(fldname).take(1)[0]
      if (rw[0].year == 1900):
         return True
      else:
        return False;

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    parent_folder = "/mnt/landing"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)    
    adls_path_array = adls_path.strip().split('/')
    table_name = adls_path_array[len(adls_path_array) - 3]
    db_name = adls_path_array[len(adls_path_array) - 4]
    synapse_schema = get_target_schema(db_name,table_name)
    
    if df_file.count() < row_count_limit:
      df_table = spark.read \
              .format("com.microsoft.sqlserver.jdbc.spark") \
              .option("url", url) \
              .option("accessToken", access_token) \
              .option("encrypt", "true") \
              .option("hostNameInCertificate", "*.database.windows.net") \
              .option("dbTable", synapse_schema+"."+table_name) \
              .load()

      sch1 = df_table.schema
      lst  = []
      for f in sch1.fields:
          if (str(f.dataType) =='TimestampType' ):
             if checkifTimeOnly(f.name,df_table):
                lst.append(f.name)
      print(lst)

      #Removing date value from timestamp of time data type columns only
      for k in lst:
        df_table = df_table.withColumn(k, date_format(k, 'HH:mm:ss'))

      df_table_selcol=df_table.select(*(trim(col(c)).alias(c) for c in df_table.columns))
      df_file_selcol=df_file.select(*(trim(col(c)).alias(c) for c in df_file.columns))

      test_diff = df_table_selcol.subtract(df_file_selcol)
      test_diff2 = df_file_selcol.subtract(df_table_selcol)

      diff_count = test_diff.count()
      diff_count2 = test_diff2.count()

      if diff_count == 0 and diff_count2 == 0:  
          validation_status = "Success"
      else:    
          validation_status = "Failure"
      result_str = 'Synapase_v_File_diff:' + str(diff_count) + ',File_v_Synapase_diff:' + str(diff_count2)

      #print("validation status: "+validation_status)
      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
      new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSynapseTable","DataComparison",validation_status,result_str,None,None,None,None,migration_id,current_time)], schema=schema)

      try:
        new_row.write \
          .format("com.microsoft.sqlserver.jdbc.spark") \
          .mode("append") \
          .option("url", url) \
          .option("dbtable", "dbo.validationstatus_"+migration_id) \
          .option("accessToken", access_token) \
          .option("encrypt", "true") \
          .option("hostNameInCertificate", "*.database.windows.net") \
          .option("mssqlIsolationLevel", "READ_UNCOMMITTED")\
          .save()
      except ValueError as error :
          print("Connector write failed", error)
          
    else:
      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
      new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSynapseTable","DataComparison","Unverified","FileSizeExceedsLimit",None,None,None,None,migration_id,current_time)], schema=schema)

      try:
        new_row.write \
          .format("com.microsoft.sqlserver.jdbc.spark") \
          .mode("append") \
          .option("url", url) \
          .option("dbtable", "dbo.validationstatus_"+migration_id) \
          .option("accessToken", access_token) \
          .option("encrypt", "true") \
          .option("hostNameInCertificate", "*.database.windows.net") \
          .option("mssqlIsolationLevel", "READ_UNCOMMITTED")\
          .save()
      except ValueError as error :
          print("Connector write failed", error)
  
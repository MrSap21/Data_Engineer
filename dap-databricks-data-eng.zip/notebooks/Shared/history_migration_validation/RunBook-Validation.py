# Databricks notebook source
import adal
#pre-requisite: Landing folder of files from on-prem must be mounted before executing the runbook.

migration_id = dbutils.widgets.get("migration_id")
environment = dbutils.widgets.get("env")

#migration_id = 'rvdataextract002202104201229'
#environment = 'dev'
print(migration_id)
migration_id = migration_id.strip()
environment = environment.strip()

#hard coded row count limit for cell to cell data comparison
row_count_limit = 50000

#location of manifest file to be generated in this step for files in ADLS
adls_manifest='/dbfs/mnt/landing/common/tframework/tf_checksumadlsfiles/checksum_'+migration_id+'.txt'

mapping_file='/dbfs/mnt/landing/common/historical_data_migration/hdfs_adls_mapping/move'+migration_id+'.csv'

#location of manifest file copied from on-prem
onprem_manifest='/dbfs/mnt/landing/common/tframework/tf_checksumonpremfiles/checksum_'+migration_id+'.csv'

#create folders in ADLS
dbutils.fs.mkdirs("/mnt/landing/common/tframework/tf_checksumadlsfiles")
dbutils.fs.mkdirs("/mnt/landing/common/tframework/tf_columnprofilingfiles")
dbutils.fs.mkdirs("/mnt/landing/common/tframework/tf_schemacomparisonfiles")
dbutils.fs.mkdirs("/mnt/landing/common/tframework/tf_col_type_xref")
dbutils.fs.mkdirs("/mnt/landing/common/etlerrorfiles")

#Set up Synapse connection based on environment
if environment.lower() == 'dev':  
  url = "jdbc:sqlserver://dapdevsqldwhsrv01.database.windows.net:1433;databaseName=dapdevdwh01"  
  service_principal_id = "3c3353bc-a254-4cb0-abbc-51ec3852c7c5"    
  service_principal_secret = dbutils.secrets.get(scope = "dapdevdataenggscope", key = "devdnasynapse")  
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
    
elif environment.lower() == 'tes':
  url = "jdbc:sqlserver://daptestsqldwhsrv01.database.windows.net:1433;databaseName=daptestdwh01"  
  service_principal_id = "6a275b50-6111-40ec-94d3-e1604a349e34" 
  service_principal_secret = dbutils.secrets.get(scope = "daptestdataenggscope", key = "testdnasynapse")  
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  
elif environment.lower() == 'uat':
  url = "jdbc:sqlserver://dapuatsqldwhsrv01.database.windows.net:1433;databaseName=dapuatdwh01"
  service_principal_id = "8eedd2eb-c552-402f-bab4-0e9e06c2c9da"
  service_principal_secret = dbutils.secrets.get(scope = "dapuatdataenggscope", key = "uatdnasynapse")
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  
elif environment.lower() == 'pro':
  url = "jdbc:sqlserver://dapprodsqldwhsrv01.database.windows.net:1433;databaseName=dapproddwh01"  
  service_principal_id = "bf188d70-069b-40be-a7b1-4c561e308652" 
  service_principal_secret = dbutils.secrets.get(scope = "dapproddataenggscope", key = "proddnasynapse")  
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  
authority = "https://login.windows.net/" + TenantId
resource_app_id_url = "https://database.windows.net/"

context = adal.AuthenticationContext(authority)
token = context.acquire_token_with_client_credentials(resource_app_id_url, service_principal_id, service_principal_secret)
access_token = token["accessToken"]


# COMMAND ----------

# MAGIC %run ./generateChecksum

# COMMAND ----------

# MAGIC %run ./comparechecksum

# COMMAND ----------

# MAGIC %run ./parquetVsSynapseCounts

# COMMAND ----------

# MAGIC %run ./parquetVsSynapseData

# COMMAND ----------

# %run ./parquetVsSynapseSchema

# COMMAND ----------

#%run ./teradataVsSynapseRowcount

# COMMAND ----------

#%run ./TDvsSynapseSchema
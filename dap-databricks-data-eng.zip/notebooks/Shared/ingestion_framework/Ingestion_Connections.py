# Databricks notebook source
pip install msal

# COMMAND ----------

import msal
import json
import urllib3
import logging
import requests

# COMMAND ----------

config_environment = dbutils.widgets.get('Env')

# COMMAND ----------

#Connect to Azure SQL Server
jdbcHostname = 'dap{0}sqlsrv01.database.windows.net'.format(config_environment)
jdbcDatabase = 'dap{0}sqldb01'.format(config_environment)
jdbcPort = 1433
## sql database info
sql_principalClientId = dbutils.secrets.get(scope="dap{0}dataenggscope".format(config_environment),key="sqldbapplicationid")
sql_principalSecret = dbutils.secrets.get(scope = "dap{0}dataenggscope".format(config_environment), key = "{0}dnasqldb".format(config_environment))
tenantId = dbutils.secrets.get(scope="dap{0}dataenggscope".format(config_environment),key="adtenantid")
sql_authority = "https://login.microsoftonline.com/" + tenantId
sql_resource_app_id_url = "https://database.windows.net/"
scope ="https://database.windows.net/.default"
# SERVICE PRINCIPAL AUTHENTICATION
app = msal.ConfidentialClientApplication(
    sql_principalClientId, sql_principalSecret,sql_authority
    )
sql_token = app.acquire_token_for_client(scopes=scope)
# Set Access Token
conn_string = 'jdbc:sqlserver://' + str(jdbcHostname) + ';database=' + str(jdbcDatabase)+';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
sql_access_token = sql_token["access_token"]
hostNameInCertificate = '*.database.windows.net'
jdbcUrl = conn_string
connectionProperties = {"accessToken" : sql_access_token,"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}

# COMMAND ----------

#Connect to ADLS
adlsAccountName = "dap{0}adlswrng01".format(config_environment)
adlsContainerName = "wrangled"
mountPoint = '/mnt/wrangled_signal'

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dap{0}dataenggscope".format(config_environment),key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dap{0}dataenggscope".format(config_environment),key="{0}dnaadls".format(config_environment))
endpoint = "https://login.microsoftonline.com/" + tenantId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" 

# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
             "fs.azure.account.oauth2.client.id": applicationId,
             "fs.azure.account.oauth2.client.secret": authenticationKey,
             "fs.azure.account.oauth2.client.endpoint": endpoint}
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

#Connect to Log Analytics
resource = "https://api.loganalytics.io"
payload = {
        'grant_type': 'client_credentials',
        'client_id': applicationId,
        'client_secret': authenticationKey,
        'Content-Type': 'x-www-form-urlencoded',
        'resource': resource
    }

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning) 
response = requests.post(endpoint, data=payload, verify=False)
token = json.loads(response.content)["access_token"]
logConnectionProperties = {"Authorization": str("Bearer "+ token), 'Content-Type': 'application/json'}

# COMMAND ----------

dbutils.notebook.exit(json.dumps({
  "connectionProperties": connectionProperties,
  "jdbcUrl": jdbcUrl,
  "logConnectionProperties": logConnectionProperties
}))

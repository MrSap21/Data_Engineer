# Databricks notebook source
import pyspark.sql.functions as sqlf
import json
from datetime import datetime
import pandas as pd
import os
import sys
import requests
from pyspark.sql.types import *

# COMMAND ----------

#Create widgets for ADF parameters 
dbutils.widgets.text("FeedID", '', '')
dbutils.widgets.text("FeedName", '', '')
dbutils.widgets.text("SignalFeedID", '', '')
dbutils.widgets.text("SignalDestinationPath", '', '')
dbutils.widgets.text("AssetID", '', '')
dbutils.widgets.text("SignalFeedName", '', '')
dbutils.widgets.text("Env", '', '')

# COMMAND ----------

#Load input parameters from ADF
config_feedid = dbutils.widgets.get('FeedID') 
config_feedname = dbutils.widgets.get('FeedName')
config_signal_feedid = dbutils.widgets.get('SignalFeedID')
config_signal_path = dbutils.widgets.get('SignalDestinationPath')
config_assetid = dbutils.widgets.get('AssetID')
config_signal_feedname = dbutils.widgets.get('SignalFeedName')
config_environment = dbutils.widgets.get('Env')

# COMMAND ----------

connection_object = dbutils.notebook.run("Ingestion_Connections", 240,  {"Env": config_environment})
connection_json = json.loads(connection_object)
connectionProperties = connection_json["connectionProperties"]
jdbcUrl = connection_json["jdbcUrl"]
logConnectionProperties = connection_json["logConnectionProperties"]

# COMMAND ----------

#Select last processed signal file in wrangled
last_signal_file_query = "(SELECT AssetCurrentLocation from idfwba.asset where assetid = (SELECT max(assetid) FROM idfwba.asset where assetcurrentlocation like '/wrangled%' and FeedID='"+config_signal_feedid+"')) as t1"
last_signal_file = spark.read.jdbc(url=jdbcUrl, table=last_signal_file_query, properties=connectionProperties).collect()[0][0]
last_signal_file

# COMMAND ----------

dbutils.fs.ls('/mnt/' + last_signal_file)

# COMMAND ----------

#Read signal file
if len(dbutils.fs.ls('/mnt/' + last_signal_file))>0:
  df = spark.read.format('csv').load('/mnt/' + last_signal_file)
  if df.count()>0:
    signal_df = df.withColumnRenamed("_c0","AssetName").distinct()
  else:  
    dbutils.notebook.exit({"message" : "Signal file empty"})
else:
  dbutils.notebook.exit({"message" : "Signal file missing"})

# COMMAND ----------

#Check if Batch framework skipped some corrupted XML files
azure_log_customer_id = "4ef03773-1a15-42f5-93c1-54e34d42662f"
query = """AppTraces 
| extend jobId=tostring(Properties.jobId)
| extend failedStep=tostring(Properties.failedStep)
| extend processFailedTime = TimeGenerated
| extend batchHostname=tostring(Properties.hostname)
| extend filepath=tostring(Properties.filepath)
| extend failedFilepath=coalesce(tostring(Properties.failedFilepath), tostring(Properties.filepath))
| extend inputSize=tostring(Properties.size)
| extend encryptionConfig=tostring(Properties.configFile)
| where Message == "Failed to process file"
| where filepath matches regex @"wagpos"
| project processFailedTime,
    batchHostname,
    filepath,
    failedFilepath,
    failedStep,
    inputSize,
    encryptionConfig
| join kind=leftouter batchHostnameEnvironment() on $left.batchHostname == $right.hostname
| project-away hostname
| where environment in ("{}") and processFailedTime between (startofday(now(),-1)..startofday(now(),1))
| project-away environment
| order by processFailedTime desc  """.format(config_environment.upper())
az_url = "https://api.loganalytics.io/v1/workspaces/"+ azure_log_customer_id + "/query"
query = {"query": query}
response = requests.get(az_url, params=query, headers=logConnectionProperties)
batchLog=json.loads(response.content)

# COMMAND ----------

skipped_files = pd.DataFrame(columns = ['skippedasset'])  
columns = StructType([StructField('skippedasset',StringType(), True)])
 
skippedDF = spark.createDataFrame([], schema = columns)


i=0
if len(batchLog['tables'][0]['rows']) == 0:
    print('No skipped files by Batсh Framework!')
else:
  for x in batchLog['tables'][0]['rows']:
    skipped_files.loc[len(skipped_files)] = batchLog['tables'][0]['rows'][i][3].rsplit('/',1)[1]
    i=i+1
  skippedDF=spark.createDataFrame(skipped_files)
  skippedDF.display()

# COMMAND ----------

#Select assets of the wagpos feed
pushdown_query = "(SELECT a.assetname as assetnamedb,a.assetcurrentlocation, dtcreated, a.FeedID FROM idfwba.asset a WHERE a.assetcurrentlocation like '/wrangled%' and a.ParentAssetID is not null and CAST(a.dtcreated AS DATE) in ( CAST(GETDATE() AS DATE)) and a.FeedID ='"+config_feedid+"' ) as t1"
asset_df = spark.read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties);

# COMMAND ----------

#Match assets in db agains file names in signal file
asset_check_db = signal_df.join(asset_df,signal_df["AssetName"] == asset_df["assetnamedb"],"leftanti")
#Match missing assets against files skipped by Batch
asset_check_batch = asset_check_db.join(skippedDF,asset_check_db["AssetName"] == skippedDF['skippedasset'],"left")
#Missing assets 
asset_missing = asset_check_batch.filter(sqlf.col("skippedasset").isNull())


#Missing assets counts: skipped by batch and present in signal, missing
asset_check_batch_ctn =  asset_check_batch.filter(sqlf.col("skippedasset").isNotNull()).count()
asset_missing_ctn = asset_missing.count()

# COMMAND ----------

display(asset_missing)

# COMMAND ----------

if asset_missing_ctn > 0:
  print('Files Missing')
  dbutils.notebook.exit({"message" : "Missing Files " + str(asset_missing_ctn) + ", Skipped Files " + str(asset_check_batch_ctn)})
else:
  #delete signal files
  for i in dbutils.fs.ls('/mnt/' + last_signal_file):
     dbutils.fs.rm(i[0])
  dbutils.notebook.exit({"message" : "WAGPOS processing OK " + ", Skipped Files " + str(asset_check_batch_ctn) }) 

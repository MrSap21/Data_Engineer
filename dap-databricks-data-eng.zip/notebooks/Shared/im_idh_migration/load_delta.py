# Databricks notebook source
# Common notebook for mounting ADLS

# mounting point

mountPoint = "/mnt/wrangled"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapadbscope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapadbscope",key="dapdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapadbscope",key="adtenantid")
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = dbutils.secrets.get(scope="dapadbscope",key="dapadlswrngurl"),
    mount_point = mountPoint,
    extra_configs = configs)  
  

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

migration_id = dbutils.widgets.get("folder_path").strip()
#migration_id = "test7feb2"

print ("migration_id--"+migration_id)

mapping_file = "/dbfs/mnt/wrangled/common/im_idh_incremental_migration/hdfs_adls_mapping/move"+migration_id+".csv"


# COMMAND ----------

def schema_final_df(table_name):
  df=spark.sql("select * from {0}".format(table_name))
  lst_schema = df.schema.names
  return lst_schema


# COMMAND ----------

with open (mapping_file, 'rt') as myfile:
  
  for myline in myfile: 
    
    adls_path = myline.split(',')[1]
    parquet_file_path = "/mnt/wrangled"+adls_path.strip()
    print(parquet_file_path)
    
    path_len = len(adls_path.split('/'))   
    idh_table_name = adls_path.split('/')[path_len - 3]      
    sub_domain_name = adls_path.split('/')[path_len - 4]   
    domain_name = adls_path.split('/')[path_len - 5] 
    
    #check if sub-domain is empty
    if sub_domain_name:
      delta_table_name = domain_name+"__"+sub_domain_name+"."+idh_table_name
    else:    
      delta_table_name = domain_name+"."+idh_table_name
           
    print("table: "+idh_table_name)
    print("sub domain: "+sub_domain_name)
    print("domain: "+domain_name)
    
    print(delta_table_name)

# COMMAND ----------

df_batch=spark.read.parquet(parquet_file_path)

lst_schema_batch=df_batch.schema.names

delta_schema=schema_final_df(delta_table_name)

for ls in delta_schema:
  if ls not in lst_schema_batch:
    df_batch=df_batch.withColumn(ls,F.lit(None))
    
df_final=df_batch.select(*delta_schema)

df_final.createOrReplaceTempView("delta_view")

spark.sql("insert overwrite table {} select * from delta_view".format(delta_table_name))

# COMMAND ----------

# def get_parquet_file_path(parquet_file_path):
#   dir_paths = dbutils.fs.ls(parquet_file_path)
#   for p in dir_paths:
#     if p.isDir() and p.path != parquet_file_path:
#       subdir_paths = p.path
#       subdir_new_path = dbutils.fs.ls(subdir_paths)
#       for p1 in subdir_new_path:
#         if p1.isDir() and p1.path != subdir_paths:
#           return p1.path
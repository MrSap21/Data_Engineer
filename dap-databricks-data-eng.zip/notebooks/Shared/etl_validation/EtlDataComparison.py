# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql.functions import *

#migration_id = 'tr001tc9202104222322'
#environment = 'DEV'
migration_id = dbutils.widgets.get("migration_id")
environment = dbutils.widgets.get("env")

print(migration_id)
migration_id = migration_id.strip()
environment = environment.strip()
if environment.lower() == 'dev':  
  url = "jdbc:sqlserver://dapdevsqldwhsrv01.database.windows.net:1433;databaseName=dapdevdwh01"  
  service_principal_id = "3c3353bc-a254-4cb0-abbc-51ec3852c7c5"    
  service_principal_secret = dbutils.secrets.get(scope = "dapdevdataenggscope", key = "devdnasynapse")  
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  
elif environment.lower() == 'tes':
  url = "jdbc:sqlserver://daptestsqldwhsrv01.database.windows.net:1433;databaseName=daptestdwh01"  
  service_principal_id = "6a275b50-6111-40ec-94d3-e1604a349e34" 
  service_principal_secret = dbutils.secrets.get(scope = "daptestdataenggscope", key = "testdnasynapse")  
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  
elif environment.lower() == 'uat':
  url = "jdbc:sqlserver://dapuatsqldwhsrv01.database.windows.net:1433;databaseName=dapuatdwh01"
  service_principal_id = "8eedd2eb-c552-402f-bab4-0e9e06c2c9da"
  service_principal_secret = dbutils.secrets.get(scope = "dapuatdataenggscope", key = "uatdnasynapse")
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  
elif environment.lower() == 'pro':
  url = "jdbc:sqlserver://dapprodsqldwhsrv01.database.windows.net:1433;databaseName=dapproddwh01"  
  service_principal_id = "bf188d70-069b-40be-a7b1-4c561e308652" 
  service_principal_secret = dbutils.secrets.get(scope = "dapproddataenggscope", key = "proddnasynapse")  
  TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"

authority = "https://login.windows.net/" + TenantId
resource_app_id_url = "https://database.windows.net/"

context = adal.AuthenticationContext(authority)
token = context.acquire_token_with_client_credentials(resource_app_id_url, service_principal_id, service_principal_secret)
access_token = token["accessToken"]

csv_path = '/mnt/landing/common/sftdatacopylocationmapping/source'+'.csv'
error_file_path = '/dbfs/mnt/landing/common/etlerrorfiles/mismatch_synapse2file_'+migration_id+'.csv'
error_file_path2 = '/dbfs/mnt/landing/common/etlerrorfiles/mismatch_file2synapse_'+migration_id+'.csv'

df_csv = spark.read.options(header=True).csv(csv_path)
df_csv_list = df_csv.filter(df_csv.status == "active").collect();

#schema for output dataframe
schema = StructType([
             StructField('test_run_id', StringType()),
             StructField('test_case_id', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),                         
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),             
             StructField('validation_execution_time', StringType()),
             StructField('source_count', IntegerType()),
             StructField('destination_count', IntegerType()),
             StructField('source_vs_destination_count', IntegerType()),
             StructField('destination_vs_source_count', IntegerType())           
            ])

def get_target_schema(database,table):  
  synapse_query = "select target_schema_name from dbo.source_target_cross_ref where source_schema_name = '"+database+"' and source_table_name= '"+table+"'"
  
  df_target_schema = spark.read \
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .option("url", url) \
            .option("accessToken", access_token) \
            .option("encrypt", "true") \
            .option("hostNameInCertificate", "*.database.windows.net") \
            .option("query",synapse_query) \
            .load()
  
  target_schema = df_target_schema.collect()[0][0]
  return target_schema

#Function for checking time data type columns from dataframes
def checkifTimeOnly(fldname,dfx):
    value_check = dfx.where(col(fldname).isNotNull())
    value_c = value_check.count()
    if (value_c == 0):
      return False
    else:
      print('NOT EMPTY')
      value_check2=value_check.take(1)[0]
      value_check_datetime = value_check2[fldname]
      if (value_check_datetime.year == 1900):
        return True
      else:
        return False
  
for item in df_csv_list :
  if item[0]+item[1] in migration_id:
    qq=item[7].replace("[","'").replace("]","'")
    #query = 'select * from '+item[2].lower()+'.'+item[3].lower()+' where '+qq
    #synapse_schema = get_target_schema(item[2],item[3])
    query = 'select * from '+item[5]+'.'+item[6].lower()+' where '+qq
    #file_name = 'pq_'+item[2].lower()+'__'+item[3].lower()+'_'+migration_id.lower()
    folder_path = '/mnt/landing/common/etldata/'+item[2].lower()+'/'+item[3].lower()+'/'+migration_id.lower()+'/'
    #file_path = folder_path+file_name
    file_path = '/mnt/landing/common/etldata/'+item[2].lower()+'/'+item[3].lower()+'/'+migration_id.lower()
    print(query)      
    df_file = spark.read.parquet(file_path)
    
    #df_file.show(1)
    

    df_table = spark.read \
            .format("com.microsoft.sqlserver.jdbc.spark") \
            .option("url", url) \
            .option("accessToken", access_token) \
            .option("encrypt", "true") \
            .option("hostNameInCertificate", "*.database.windows.net") \
            .option("query",query) \
            .load()
    
    #checks for time data type columns from table dataframe
    sch1 = df_table.schema
    print(sch1)
    lst  = []
    for f in sch1.fields:
        if (str(f.dataType) =='TimestampType' ):
           if checkifTimeOnly(f.name,df_table):
              lst.append(f.name)
    print(lst)
    
    for k in lst:
      df_table = df_table.withColumn(k, date_format(k, 'HH:mm:ss'))
      df_table.show(2)
    
    #Trims all the columns before compare
    df_table_selcol=df_table.select(*(trim(col(c)).alias(c) for c in df_table.columns))
    df_file_selcol=df_file.select(*(trim(col(c)).alias(c) for c in df_file.columns))
            
    synapse_file_path = '/dbfs/mnt/landing/common/etldata/synapse_data/synapse_'+item[2]+'__'+item[3]+'_'+migration_id+'.csv'
    pd3 = df_table.toPandas()
    pd3.to_csv(synapse_file_path,index=False)
    
    test_diff = df_table_selcol.subtract(df_file_selcol)
    test_diff2 = df_file_selcol.subtract(df_table_selcol)
    print("result")
    print(test_diff.count())
    print(test_diff2.count())
    #test_diff.show(2)
    diff_count = test_diff.count()
    diff_count2 = test_diff2.count()
    output_df = test_diff.limit(1000)
    output_df2 = test_diff2.limit(1000)
    tdrowcount = df_file_selcol.count()
    synapaserowcount = df_table_selcol.count()
    pd = output_df.toPandas()
    pd.to_csv(error_file_path,index=False)
    pd2 = output_df2.toPandas()
    pd2.to_csv(error_file_path2,index=False)
    
    ValidationStatus = 'Failure'
    
    if diff_count == 0 and diff_count2 == 0:   
        ValidationStatus = 'Success'
   
    print("validation status: "+ValidationStatus)
    
    def write_to_synapse(new_row):
      try:
        new_row.write \
          .format("com.microsoft.sqlserver.jdbc.spark") \
          .mode("append") \
          .option("url", url) \
          .option("dbtable", "dbo.ETLvalidationstatus") \
          .option("accessToken", access_token) \
          .option("hostNameInCertificate", "*.database.windows.net") \
          .option("mssqlIsolationLevel", "READ_UNCOMMITTED")\
          .save()
      except ValueError as error :
          print("Connector write failed", error)
    
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    new_row = spark.createDataFrame([(item[0],item[1],file_path,item[3],ValidationStatus,error_file_path,current_time,tdrowcount,synapaserowcount,diff_count,diff_count2)], schema=schema)
   
    write_to_synapse(new_row)
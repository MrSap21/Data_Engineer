# Databricks notebook source
from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql import Row
import adal
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import to_timestamp

########


spark = SparkSession.builder.appName("comparechecksum").getOrCreate()
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

#schema for dataframes
onprem_schema = StructType([
             StructField('onprem_filename', StringType()),
             StructField('onprem_md5value', StringType())            
            ])
adls_schema = StructType([
              StructField('adls_filename', StringType()),
              StructField('adls_md5value', StringType())
            ])

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):
  new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()
  #new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","dnadevedwdb01.validationstatus_carsontery202106230119").mode("append").save()
   
#create empty dataframe with ValidationStatus schema
df_to_save = spark.createDataFrame([],schema)

onprem_df = spark.read.csv(onprem_manifest.replace('/dbfs',''),inferSchema=True,header=False,sep=' ',ignoreLeadingWhiteSpace=True)
adls_df = spark.read.csv(adls_manifest.replace('/dbfs',''),inferSchema=True,header=False,sep=' ',ignoreLeadingWhiteSpace=True)

print(onprem_manifest)
print(adls_manifest)

#extract filename from file path
def slice_string(input): 
  print(input)
  path_array = input._c1.split("/")
  length=len(path_array)
  #file_name = path_array[length-2]+"/"+path_array[length-1]
  file_name = path_array[length-1]
  return Row(file_name,input._c0) 
   
#extract filename from file path for each record  
adls_rdd = adls_df.rdd.map(slice_string)
onprem_rdd = onprem_df.rdd.map(slice_string)

#generate dataframe from modified rdds
adls_df1 = spark.createDataFrame(adls_rdd, adls_schema)
onprem_df1 = spark.createDataFrame(onprem_rdd, onprem_schema)

#join the dataframes to validate checksum value
df_join = onprem_df1.join(adls_df1, adls_df1.adls_filename == onprem_df1.onprem_filename, how='inner')

#register temp table to run sql queries
df_join.registerTempTable("temp")
pass_df = spark.sql("select adls_filename as filename, adls_md5value, onprem_md5value, 'Success' as validation_status from temp where adls_md5value == onprem_md5value")
fail_df = spark.sql("select adls_filename as filename, adls_md5value, onprem_md5value, 'Failure' as validation_status from temp where adls_md5value != onprem_md5value")
output_df=pass_df.union(fail_df)

output_list = output_df.collect()

for item in output_list:
  current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]  
  new_row = spark.createDataFrame([("",item[0],item[0],"CopyFilesToAdls","Checksum",item[3],"",None,None,None,None,migration_id,current_time)], schema=schema)
   
  write_to_synapse(new_row)
  #new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","dnadevedwdb01.validationstatus_carsontery202106230119").mode("append").save()
  #add the new row to existing dataframe
  #df_to_save = df_to_save.union(new_row)
  
#write_to_synapse(df_to_save)      

# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import *

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

#Checks for time data type in from dataframes
def checkifTimeOnly(fldname,dfx):
    sql1 = fldname + " is not null"
    rw2 = dfx.select(fldname).take(1)[0]
    
    if (rw2[0] != None):
      rw = dfx.select(fldname).take(1)[0]
      if (rw[0].year == 1900):
         return True
      else:
        return False;

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    td_1 = myline.split(',')[0]
    path_len = len(td_1.split('/'))    
    td_2 = td_1.split('/')[path_len - 2]    
    td_3 = td_2.split('__')[0]
    td_4 = td_2.split('__')[1]
    td_5 = "_" + migration_id
    db_name = td_3.replace("pq_","")
    table_name = td_4.replace(td_5,"")
    
    parent_folder = "/mnt/wrangled"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)    
    file_row_count = df_file.count()
    
    df_snow_map = spark.read.parquet(teradata_snowflake_map_path)
    df_snow_map2=df_snow_map.select(upper(col("td_database")).alias("td_database"),upper(col("td_table")).alias("td_table"),"sf_database","sf_schema","sf_table","environment")                                    
    
    df_snow_map3 = (df_snow_map2.filter((df_snow_map2.td_database==db_name.upper()) & (df_snow_map2.td_table==table_name.upper()) & (df_snow_map2.environment==environment.upper()[:3])))
    df_snow_map_list = df_snow_map3.select("sf_database","sf_schema","sf_table").drop_duplicates().collect()
    print(df_snow_map_list)
    snowtable=df_snow_map_list[0][0]+"."+df_snow_map_list[0][1]+"."+df_snow_map_list[0][2]
    print(snowtable)
    
    if df_file.count() < row_count_limit:
      df_table = spark.read.format("snowflake").options(**sfOptions).option("dbTable",snowtable).load()

      sch1 = df_table.schema
      lst  = []
      for f in sch1.fields:
          if (str(f.dataType) =='TimestampType' ):
             if checkifTimeOnly(f.name,df_table):
                lst.append(f.name)
      print(lst)

      #Removing date value from timestamp of time data type columns only
      for k in lst:
        df_table = df_table.withColumn(k, date_format(k, 'HH:mm:ss'))

      df_table_selcol=df_table.select(*(trim(col(c)).alias(c) for c in df_table.columns))
      df_file_selcol=df_file.select(*(trim(col(c)).alias(c) for c in df_file.columns))

      test_diff = df_table_selcol.subtract(df_file_selcol)
      test_diff2 = df_file_selcol.subtract(df_table_selcol)

      diff_count = test_diff.count()
      diff_count2 = test_diff2.count()

      if diff_count == 0 and diff_count2 == 0:  
          validation_status = "Success"
      else:    
          validation_status = "Failure"
      result_str = 'Snowflake_v_File_diff:' + str(diff_count) + ',File_v_Snowflake_diff:' + str(diff_count2)

      #print("validation status: "+validation_status)
      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
      
      new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSnowflakeTable","DataComparison",validation_status,result_str,None,None,None,None,migration_id,current_time)], schema=schema)

      try:
        new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()
      except ValueError as error :
          print("Connector write failed", error)
          
    else:
      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
      new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSnowflakeTable","DataComparison","Unverified","FileSizeExceedsLimit",None,None,None,None,migration_id,current_time)], schema=schema)

      try:
        new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()
      except ValueError as error :
          print("Connector write failed", error)
  
// Databricks notebook source
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import net.snowflake.client.core.QueryStatus;
import net.snowflake.client.jdbc.SnowflakeConnection;
import net.snowflake.client.jdbc.SnowflakeResultSet;
import net.snowflake.client.jdbc.SnowflakeStatement;


// COMMAND ----------

val migration_id = dbutils.widgets.get("migration_id")

// COMMAND ----------

val password=dbutils.secrets.get(scope = "dapadbscope", key = "dapsfpassword")
val user=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfpythonusername")
val account=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfshortaccountname")
val warehouse=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfwarehouse")

val properties = new java.util.Properties()
  properties.put("user", user)
  properties.put("password", password) 
  properties.put("warehouse", warehouse) 
   
val jdbcUrl = "jdbc:snowflake://"+account+".snowflakecomputing.com/"

// COMMAND ----------

val sqlfile = "/mnt/staging/Common/historical_data_migration/validation_script_ddl/"+ migration_id +"_SQL.csv"
val txt = spark.read.format("text").load(sqlfile)

// COMMAND ----------

val sql_command = txt.select("value").collect().map(_.getString(0)).mkString(" \n")

// COMMAND ----------

val con = DriverManager.getConnection(jdbcUrl, properties)
val statement = con.createStatement();
var sfstmt = statement.unwrap(classOf[SnowflakeStatement])
sfstmt.setParameter("MULTI_STATEMENT_COUNT", 0)
var resultSet  = sfstmt.executeAsyncQuery(sql_command);
val queryId = resultSet.unwrap(classOf[SnowflakeResultSet]).getQueryID();
println(queryId)
statement.close();
con.close();

val conn = DriverManager.getConnection(jdbcUrl, properties)
resultSet = conn.unwrap(classOf[SnowflakeConnection]).createResultSet(queryId);
var  queryStatus = QueryStatus.RUNNING;

while (queryStatus == QueryStatus.RUNNING) {
      Thread.sleep(10000); // 2000 milliseconds.
      queryStatus = resultSet.unwrap(classOf[SnowflakeResultSet]).getStatus();
      println(queryStatus)
 }
conn.close()

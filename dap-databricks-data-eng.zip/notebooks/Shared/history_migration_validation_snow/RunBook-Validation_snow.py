# Databricks notebook source
#pre-requisite: Landing folder of files from on-prem must be mounted before executing the runbook.

#for snowflake
from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os

migration_id = dbutils.widgets.get("migration_id")
environment = dbutils.widgets.get("env")

print(migration_id)
migration_id = migration_id.strip()

#environment variable value change to align with database names
if environment.lower() == 'pro':  
  environment='prod'
elif environment.lower() == 'tes':
  environment='test'
  
#snowflake config
database = environment.lower()+"_pharmacy_healthcare"
account=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfshortaccountname")
url = "https://"+account+".snowflakecomputing.com"
password=dbutils.secrets.get(scope = "dapadbscope", key = "dapsfpassword")
user=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfpythonusername")  
warehouse=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfwarehouse")
sfOptions = {
    "sfURL" : url,
    "sfUser" : user,
    "sfPassword" : password, 
    "sfDatabase" : database,
    "sfWarehouse" : warehouse
}

#validation tables in Snowflake
minmax=database+'.public.minmaxavg_' + migration_id
rowcount=database+'.public.rowcount_' + migration_id
teradatametadata=database+'.public.teradatametadata_' + migration_id
validationstatus=database+'.public.validationstatus_' + migration_id 

#environment variable value change to align with teradata_snowflake_map table
if environment.lower() == 'prod':  
  environment='prd'
elif environment.lower() == 'test':
  environment='tst'
  
#hard coded row count limit for cell to cell data comparison
row_count_limit = 50000

#location of manifest file to be generated in this step for files in ADLS
adls_manifest='/dbfs/mnt/wrangled/common/tframework/tf_checksumadlsfiles/checksum_'+migration_id+'.txt'

#location of mapping file from migration run
mapping_file='/dbfs/mnt/wrangled/common/historical_data_migration/hdfs_adls_mapping/move'+migration_id+'.csv'

#location of manifest file copied from on-prem
onprem_manifest='/dbfs/mnt/wrangled/common/tframework/tf_checksumonpremfiles/checksum_'+migration_id+'.csv'

#validation table file location
minmax_path= '/mnt/wrangled/common/tframework/tf_validationtables/minmaxavg_'+migration_id
rowcount_path= '/mnt/wrangled/common/tframework/tf_validationtables/rowcount_'+migration_id
teradatametadata_path= '/mnt/wrangled/common/tframework/tf_validationtables/teradatametadata_'+migration_id
validationstatus_path= '/mnt/wrangled/common/tframework/tf_validationtables/validationstatus_'+migration_id
teradata_snowflake_map_path= '/mnt/wrangled/common/tframework/tf_validationtables/teradata_snowflake_map_'+migration_id
col_type_xref_map_path= '/mnt/wrangled/common/tframework/tf_col_type_xref'

#create folders in ADLS
dbutils.fs.mkdirs("/mnt/wrangled/common/tframework/tf_checksumadlsfiles")
dbutils.fs.mkdirs("/mnt/wrangled/common/tframework/tf_columnprofilingfiles")
dbutils.fs.mkdirs("/mnt/wrangled/common/tframework/tf_schemacomparisonfiles")
dbutils.fs.mkdirs("/mnt/wrangled/common/tframework/tf_col_type_xref")
dbutils.fs.mkdirs("/mnt/wrangled/common/etlerrorfiles")
dbutils.fs.mkdirs("/mnt/wrangled/common/tframework/tf_template")
dbutils.fs.mkdirs("/mnt/staging/Common/historical_data_migration/validation_script_ddl")
 

# COMMAND ----------

# MAGIC %run ./snow_write_table

# COMMAND ----------

# MAGIC %run ./generateChecksum_snow

# COMMAND ----------

# MAGIC %run ./comparechecksum_snow

# COMMAND ----------

# MAGIC %run ./parquetVsSnowflakeCounts

# COMMAND ----------

# MAGIC %run ./parquetVsSnowflakeData

# COMMAND ----------

# MAGIC %run ./teradataVsSnowflakeRowcount

# COMMAND ----------

#%run ./TDvsSnowflakeSchema
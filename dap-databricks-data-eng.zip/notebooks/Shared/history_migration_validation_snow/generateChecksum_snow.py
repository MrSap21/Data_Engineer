# Databricks notebook source
from pyspark.sql import SparkSession
from datetime import datetime,timedelta 
import hashlib
from pyspark.sql.types import *
from pyspark.sql import functions as f

output_file = open(adls_manifest, "w")

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    parent_folder = "/mnt/wrangled"+adls_path.strip()    
    file_list = dbutils.fs.ls(parent_folder)
       
    for file in file_list:
        file_name = '/'+file[0].replace(':','')        
        md5value = hashlib.md5(open(file_name,'rb').read()).hexdigest()        
        value = md5value+" "+file_name+"\n"      
        output_file.write(value)  
      
output_file.close()

# COMMAND ----------


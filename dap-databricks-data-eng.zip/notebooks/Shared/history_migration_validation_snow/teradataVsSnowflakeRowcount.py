# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit, upper, col
import pandas as pd

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', LongType()),
             StructField('destination_row_count', LongType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):
  new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()
  
def extract_tablename(table_name):
  temp = table_name.split('__')[1]
  temp = temp.split('_')
  return "_".join(temp[:-1])

def query_to_dataframe(synapse_query):
  print("Performing query :"+ synapse_query)
  df_table_py = spark.read.format("snowflake").options(**sfOptions).option("query",synapse_query).load()
  
  df_table = df_table_py.toPandas()
  return df_table

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    td_1 = myline.split(',')[0]
    path_len = len(td_1.split('/'))    
    td_2 = td_1.split('/')[path_len - 2]     
    td_3 = td_2.split('__')[0]
    td_4 = td_2.split('__')[1]
    td_5 = "_" + migration_id
    db_name = td_3.replace("pq_","")
    table_name = td_4.replace(td_5,"")
    
    parent_folder = "/mnt/wrangled"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)    
    file_row_count = df_file.count()
    print(db_name, table_name)

    print("TABLE NAME :"+ table_name)
    
    df_snow_map = spark.read.parquet(teradata_snowflake_map_path)
    df_snow_map2 = df_snow_map.select(upper(col("td_database")).alias("td_database"),upper(col("td_table")).alias("td_table"),"sf_database","sf_schema","sf_table","environment")                                    
    
    df_snow_map3 = (df_snow_map2.filter((df_snow_map2.td_database==db_name.upper()) & (df_snow_map2.td_table==table_name.upper()) & (df_snow_map2.environment==environment.upper()[:3])))
    df_snow_map_list = df_snow_map3.select("sf_database","sf_schema","sf_table").drop_duplicates().collect()
    print(df_snow_map_list)
    snowtable=df_snow_map_list[0][0]+"."+df_snow_map_list[0][1]+"."+df_snow_map_list[0][2]
    
    synapse_query = "select * from public.validationstatus_"+migration_id

    df_table = query_to_dataframe(synapse_query) 
    source_data = str(df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsHiveRowCount']['SOURCE'].values[0])
    print(df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsHiveRowCount']['SOURCE_ROW_COUNT'].values[0])
   #Teradata_synapse_rowcount
  
    teraData_rowcount = int(df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsHiveRowCount']['SOURCE_ROW_COUNT'].values[0])
    #teraData_rowcount = df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsHiveRowCount']['SOURCE_ROW_COUNT'].values[0]
    synapse_rowcount = int(df_table.loc[df_table['VALIDATION_TYPE'] == 'ParquetVsSnowflakeRowCount']['DESTINATION_ROW_COUNT'].values[0])
    #synapse_rowcount = df_table.loc[df_table['VALIDATION_TYPE'] == 'ParquetVsSnowflakeRowCount']['DESTINATION_ROW_COUNT'].values[0]
    
    if teraData_rowcount == synapse_rowcount:
      validation_status = 'Success'
    else:
      validation_status = 'Failure'
    
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
  
    new_row = spark.createDataFrame([(db_name,source_data,table_name,"CreateSnowflakeTable","TDVsSnowflakeRowCount",validation_status,"",teraData_rowcount,synapse_rowcount,None,None,migration_id,current_time)], schema=schema)
    new_row.show()
    write_to_synapse(new_row)
    
    
    #teradata_synapse_column_count
    source_data = str(df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsParquetColumnCount']['SOURCE'].values[0])
    teraData_columncount = int(df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsParquetColumnCount']['SOURCE_COLUMN_COUNT'].values[0])
    #teraData_columncount = df_table.loc[df_table['VALIDATION_TYPE'] == 'TDVsParquetColumnCount']['SOURCE_COLUMN_COUNT'].values[0]
    synapse_columncount = int(df_table.loc[df_table['VALIDATION_TYPE'] == 'ParquetVsSnowflakeColumnCount']['DESTINATION_COLUMN_COUNT'].values[0])
    #synapse_columncount = df_table.loc[df_table['VALIDATION_TYPE'] == 'ParquetVsSnowflakeColumnCount']['DESTINATION_COLUMN_COUNT'].values[0]
    
    if teraData_columncount == synapse_columncount:
      validation_status = 'Success'
    else:
      validation_status = 'Failure'
      
    new_row = spark.createDataFrame([(db_name,source_data,table_name,"CreateSnowflakeTable","TDVsSnowflakeColumnCount",validation_status,"",None,None,teraData_columncount,synapse_columncount,migration_id,current_time)], schema=schema)
    new_row.show()
    write_to_synapse(new_row)
    
    #Minmaxavg 
    minmaxavg_data_columnslist = ['td_database','table_name','column_name','td_avg','td_min','td_max','syn_database','syn_tablename','sy_avg','sy_min','sy_max','status']
    column_profiling_alltables = pd.DataFrame(columns = minmaxavg_data_columnslist) 
    minmax_query = "select DISTINCT td_database, table_name from public.minmaxavg_"+migration_id
    df_table = query_to_dataframe(minmax_query)
    print(df_table)
    for index, row in df_table.iterrows():
      
      minmaxavg_data = "select * from public.minmaxavg_"+migration_id+" where UPPER(td_database)=UPPER('"+row['TD_DATABASE']+"') and UPPER(table_name) =UPPER('"+row['TABLE_NAME']+"')"
      
      minmaxavg_data_df = query_to_dataframe(minmaxavg_data)
      print(minmaxavg_data_df)
      
      tablename = extract_tablename(row['TABLE_NAME'])
      print(tablename)
      
      minmaxavg_data_columnslist = ['td_database','table_name','column_name','td_avg','td_min','td_max','syn_database','syn_tablename','sy_avg','sy_min','sy_max','status']
      column_profiling = pd.DataFrame(columns = minmaxavg_data_columnslist)
      
      for index_2, row_2 in minmaxavg_data_df.iterrows():
        
        column_data_query = "select avg(cast("+row_2['COLUMN_NAME']+" AS BIGINT)) as sy_avg,min("+row_2['COLUMN_NAME']+") as sy_min,max("+row_2['COLUMN_NAME']+") as sy_max from "+snowtable
        
        column_data_query_df = query_to_dataframe(column_data_query)
        
        td_avg = int(row_2['AVG']) if row_2['AVG'] is not None else None
        td_min = int(row_2['MIN']) if row_2['MIN'] is not None else None
        td_max = int(row_2['MAX']) if row_2['MAX'] is not None else None
        print(td_avg)
        sy_avg = None if column_data_query_df['SY_AVG'].isnull().values.any() else int(column_data_query_df['SY_AVG'])
        print(sy_avg)
        sy_min = None if column_data_query_df['SY_MIN'].isnull().values.any() else int(column_data_query_df['SY_MIN'])
        sy_max = None if column_data_query_df['SY_MAX'].isnull().values.any() else int(column_data_query_df['SY_MAX'])
        #sy_min = int(column_data_query_df['SY_MIN']) if column_data_query_df['SY_MIN'] is not None else None
        #sy_max = int(column_data_query_df['SY_MAX']) if column_data_query_df['SY_MAX'] is not None else None
        
        if td_avg == sy_avg and td_min == sy_min and td_max == sy_max:
        #if int(row_2['AVG']) == int(column_data_query_df['SY_AVG']) and int(row_2['MIN']) == int(column_data_query_df['SY_MIN']) and int(row_2['MAX']) == int(column_data_query_df['SY_MAX']):
          status = 'Success'
        else:
          status = 'Failure'
        
        data1 = [{'td_database':row_2['TD_DATABASE'],'table_name':row_2['TABLE_NAME'],'column_name':row_2['COLUMN_NAME'],'td_avg':td_avg,'td_min':row_2['MIN'],'td_max':row_2['MAX'],'syn_database':db_name,'syn_tablename':tablename, 'sy_avg':sy_avg,'sy_min':sy_min,'sy_max':sy_max,'status':status}]
        
        column_profiling = column_profiling.append(data1, ignore_index = True)
        
      if 'Failure' in column_profiling['status']:
        table_status = 'Failure'
      else:
        table_status = 'Success'
      
      synapse_file_path = '/dbfs/mnt/wrangled/common/tframework/tf_columnprofilingfiles/td_vs_synapse_'+migration_id+'.csv'
      
      new_row = spark.createDataFrame([(db_name,row['TABLE_NAME'],tablename,"CreateSynapseTable","TDVsSnowflakeColumnProfiling",table_status,synapse_file_path,None,None,None,None,migration_id,current_time)], schema=schema)
      new_row.show() 
      write_to_synapse(new_row)
      
      column_profiling_alltables = column_profiling_alltables.append(column_profiling)
      
      print(column_profiling_alltables)
     
    synapse_file_path = '/dbfs/mnt/wrangled/common/tframework/tf_columnprofilingfiles/td_vs_snowflake_'+migration_id+'.csv'
    column_profiling_alltables.to_csv(synapse_file_path,index=False)
      


# COMMAND ----------


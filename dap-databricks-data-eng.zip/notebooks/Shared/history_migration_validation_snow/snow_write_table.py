# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import *
import adal

df_file_minmax = spark.read.parquet(minmax_path)
df_file_rowcount = spark.read.parquet(rowcount_path)
df_file_teradatametadata = spark.read.parquet(teradatametadata_path)
df_file_validationstatus = spark.read.parquet(validationstatus_path)

df_file_minmax_dedup=df_file_minmax.dropDuplicates()
df_file_rowcount_dedup=df_file_rowcount.dropDuplicates()
df_file_teradatametadata_dedup=df_file_teradatametadata.dropDuplicates()
df_file_validationstatus_dedup=df_file_validationstatus.dropDuplicates()

df_file_minmax_dedup.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",minmax).mode("append").save()
df_file_rowcount_dedup.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",rowcount).mode("append").save()
df_file_teradatametadata_dedup.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",teradatametadata).mode("append").save()
df_file_validationstatus_dedup.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validationstatus).mode("append").save()
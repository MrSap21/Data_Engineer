# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
import pyarrow.parquet as pq
import os
from pyspark.sql.functions import udf, expr, concat, col, upper

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):
  new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()

#query to find number of td tables and dbname 
syn_query_tdname_tddb= "select databasename, tablename from public.teradatametadata_"+migration_id+" group by databasename, tablename"

df_tdname_tddb = spark.read.format("snowflake").options(**sfOptions).option("query",syn_query_tdname_tddb).load()


ls_tdname_tddb=[]
tdname_tddb=df_tdname_tddb.collect()
for k in tdname_tddb:
  
  error_file_path = '/dbfs/mnt/wrangled/common/tframework/tf_schemacomparisonfiles/td_vs_snowflake_'+migration_id+'.csv'
  print('************col_type_xref*********')
  df_col_type_xref = spark.read.option('header',True).csv(col_type_xref_map_path)
  df_col_type_xref.show()
    
  #query_td_meta="select t.databasename as td_databasename, t.tablename as td_tablename, t.columnname as td_columnname, c.sf_type as td_columntype, t.nullable as td_nullable, t.columnlength as td_columnlength from public.teradatametadata_"+migration_id+" t left join (select td_type,sf_type from dnadevedwdb01.col_type_xref_snowflake where sf_type IS not NULL group by td_type,sf_type) c on (t.columntype = c.td_type) where UPPER(t.databasename)= UPPER('"+k[0]+"') and UPPER(t.tablename)= UPPER('"+k[1]+"'"+")"
  query_td_meta="select t.databasename as td_databasename, t.tablename as td_tablename, t.columnname as td_columnname, t.columntype as columntype, t.nullable as td_nullable, t.columnlength as td_columnlength from public.teradatametadata_"+migration_id+" t where UPPER(t.databasename)= UPPER('"+k[0]+"') and UPPER(t.tablename)= UPPER('"+k[1]+"'"+")"
  
  #left join (select td_type,sf_type from dnadevedwdb01.col_type_xref_snowflake where sf_type IS not NULL group by td_type,sf_type) c
  #td_columntype
  df_snow_map = spark.read.parquet(teradata_snowflake_map_path)
  df_snow_map2=df_snow_map.select(upper(col("td_database")).alias("td_database"),upper(col("td_table")).alias("td_table"),"sf_database","sf_schema","sf_table")
  df_snow_map3 = df_snow_map2.filter((df_snow_map2.td_database==k[0].upper()) & (df_snow_map2.td_table==k[1].upper()))
  df_snow_map_list = df_snow_map3.select("sf_database","sf_schema","sf_table").drop_duplicates().collect()
  snowtable=df_snow_map_list[0][0]+"."+df_snow_map_list[0][1]+"."+df_snow_map_list[0][2]
  
  
  query_sy_meta="select table_schema as sy_databasename, table_name as sy_tablename, column_name as sy_columnname, UPPER(data_type) as synapse_columntype, CASE WHEN is_nullable='YES' THEN 'Y' WHEN is_nullable='NO' THEN 'N' ELSE 'NA' END as sy_nullable, character_maximum_length as sy_columnlength from information_schema.columns where UPPER(table_name)=UPPER('"+df_snow_map_list[0][2]+"'"+") and UPPER(table_schema)=UPPER('"+df_snow_map_list[0][1]+"') and UPPER(table_catalog)=UPPER('"+df_snow_map_list[0][0]+"')"
  
  
  df_td_meta2 = spark.read.format("snowflake").options(**sfOptions).option("query",query_td_meta).load()
  df_td_meta2.show()
  df_td_meta3 = df_td_meta2.join(df_col_type_xref, df_td_meta2.COLUMNTYPE == df_col_type_xref.td_type,'inner')
  df_td_meta = df_td_meta3.select ("td_databasename", "td_tablename", "td_columnname", "sf_type", "td_nullable", "td_columnlength")
  print('************df_td_meta META*************')
  df_td_meta.show()
    
  df_sy_meta = spark.read.format("snowflake").options(**sfOptions).option("query",query_sy_meta).load()
  print('************df_sy_meta META*************')
  df_sy_meta.show()
  
  df_join_tdsy = df_td_meta.join(df_sy_meta,df_td_meta.td_columnname==df_sy_meta.SY_COLUMNNAME,'outer')
  
  df_join= df_join_tdsy.select ("td_databasename", "td_tablename", "td_columnname", "sf_type", "td_nullable", "td_columnlength", "sy_databasename", "sy_tablename", "sy_columnname", "synapse_columntype", "sy_nullable", "sy_columnlength", expr("CASE WHEN (td_columnname=sy_columnname) AND (sf_type=synapse_columntype) AND (td_nullable=sy_nullable) THEN 'SUCCESS' ELSE 'FAILURE' END AS Status"))
  print('************df_join META*************')
  df_join.show()
  
  df_validation=df_join.filter("Status ='FAILURE'")
  df_validation.show()
  
  diff_count = df_validation.count()
  
  if (diff_count==0):
    validation_status="Success"
  else:
    validation_status="Failure"
  pd = df_join.toPandas()
  pd.to_csv(error_file_path,index=False)
  current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
  new_row = spark.createDataFrame([(k[0],k[1],k[1],"CreateSnowflakeTable","TDVsSnowflakeSchema",validation_status,error_file_path,None,None,None,None,migration_id,current_time)], schema=schema)
  new_row.show()
  write_to_synapse(new_row)
      
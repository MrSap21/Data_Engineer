# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):  new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    td_1 = myline.split(',')[0]
    path_len = len(td_1.split('/'))    
    td_2 = td_1.split('/')[path_len - 2]    
    td_3 = td_2.split('__')[0]
    td_4 = td_2.split('__')[1]
    td_5 = "_" + migration_id
    db_name = td_3.replace("pq_","")
    table_name = td_4.replace(td_5,"")
    
    parent_folder = "/mnt/landing"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)
    df_snow_map = spark.read.parquet(teradata_snowflake_map_path)
    df_snow_map2=df_snow_map.select(upper(col("td_database")).alias("td_database"),upper(col("td_table")).alias("td_table"),"sf_database","sf_schema","sf_table","environment")
                                    
    
    df_snow_map3 = (df_snow_map2.filter((df_snow_map2.td_database==db_name.upper()) & (df_snow_map2.td_table==table_name.upper()) & (df_snow_map2.environment==environment.upper()[:3])))
    df_snow_map_list = df_snow_map3.select("sf_database","sf_schema","sf_table").drop_duplicates().collect()
    print(df_snow_map_list)
    snowtable=df_snow_map_list[0][0]+"."+df_snow_map_list[0][1]+"."+df_snow_map_list[0][2]
    print(snowtable)
    df_table = spark.read.format("snowflake").options(**sfOptions).option("dbTable",snowtable).load()
     

    validation_status = "Failure"  
  
    #schema comparison
    table_schema = df_table.schema
    file_schema = df_file.schema

    for i in range(len(file_schema)):
      table_data_type = str(table_schema[i].dataType).replace('Type','') 
      file_data_type = str(file_schema[i].dataType).replace('Type','')
      if table_data_type == file_data_type:
        validation_status="Success"
      else:
        validation_status="Failure"
      
      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
      new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSnowflakeTable","ParquetVsSnowflakeSchema",validation_status,table_schema[i].name,None,None,None,None,migration_id,current_time)], schema=schema)
      write_to_synapse(new_row)
      #new_row.show()
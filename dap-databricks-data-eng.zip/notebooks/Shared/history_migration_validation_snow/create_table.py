# Databricks notebook source
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import *

#code to create DDL statement
migration_id = dbutils.widgets.get("migration_id")
environment = dbutils.widgets.get("env")
migration_id = migration_id.strip()
environment = environment.strip()

#environment variable value change to align with database names
if environment.lower() == 'pro':  
  environment='prod'
elif environment.lower() == 'tes':
  environment='test'
  
minmax=environment.lower()+'_pharmacy_healthcare.public.minmaxavg_' + migration_id
rowcount=environment.lower()+'_pharmacy_healthcare.public.rowcount_' + migration_id
teradatametadata=environment.lower()+'_pharmacy_healthcare.public.teradatametadata_' + migration_id
validationstatus=environment.lower()+'_pharmacy_healthcare.public.validationstatus_' + migration_id  

#validation table ddl location
tpt_input_script='/dbfs/mnt/wrangled/common/tframework/tf_template/template.txt'
tpt_output_script = '/dbfs/mnt/staging/Common/historical_data_migration/validation_script_ddl/'+migration_id+'_SQL.csv'

lines = []

with open (tpt_input_script, 'rt') as myfile:
  for inline in myfile: 
    outline = inline
    if '@sch.@db.minmaxavg_@migration_id' in inline:
        outline = inline.replace('@sch.@db.minmaxavg_@migration_id', minmax)   
    elif '@sch.@db.rowcount_@migration_id' in inline:   
        outline = inline.replace('@sch.@db.rowcount_@migration_id', rowcount)
    elif '@sch.@db.teradatametadata_@migration_id' in inline:   
        outline = inline.replace('@sch.@db.teradatametadata_@migration_id', teradatametadata)
    elif '@sch.@db.validationstatus_@migration_id' in inline:
        outline = inline.replace('@sch.@db.validationstatus_@migration_id', validationstatus)
    lines.append(outline)
    
#write to TPT script    
output_file = open(tpt_output_script, "w")
for ln in lines:
    output_file.write(ln)
output_file.close()
myfile.close()
# Databricks notebook source
import adal
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit, upper, col

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', LongType()),
             StructField('destination_row_count', LongType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

def write_to_synapse(new_row):
  new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.validationstatus_"+migration_id).mode("append").save()
  
  
with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    td_1 = myline.split(',')[0]
    path_len = len(td_1.split('/'))    
    td_2 = td_1.split('/')[path_len - 2]
    td_3 = td_2.split('__')[0]
    td_4 = td_2.split('__')[1]
    td_5 = "_" + migration_id
    db_name = td_3.replace("pq_","")
    table_name = td_4.replace(td_5,"")
    
    parent_folder = "/mnt/wrangled"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)    
    file_row_count = df_file.count()
    
    df_snow_map = spark.read.parquet(teradata_snowflake_map_path)
    df_snow_map2 = df_snow_map.select(upper(col("td_database")).alias("td_database"),upper(col("td_table")).alias("td_table"),"sf_database","sf_schema","sf_table","environment")                                    
    
    df_snow_map3 = (df_snow_map2.filter((df_snow_map2.td_database==db_name.upper()) & (df_snow_map2.td_table==table_name.upper()) & (df_snow_map2.environment==environment.upper()[:3])))
    df_snow_map_list = df_snow_map3.select("sf_database","sf_schema","sf_table").drop_duplicates().collect()
    print(df_snow_map_list)
    snowtable=df_snow_map_list[0][0]+"."+df_snow_map_list[0][1]+"."+df_snow_map_list[0][2]
    #print(snowtable)
          
    #df_table = spark.read.format("snowflake").options(**sfOptions).option("dbTable",db_name+"."+table_name).load()
    df_table = spark.read.format("snowflake").options(**sfOptions).option("dbTable",snowtable).load()
    df_table.show()

    table_row_count = df_table.count()

    validation_status = "Failure"

    if table_row_count == file_row_count:
      validation_status = "Success"

    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
    #cur_time = eval(current_time)
  
    new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSnowflakeTable","ParquetVsSnowflakeRowCount",validation_status,"",file_row_count,table_row_count,None,None,migration_id,current_time)], schema=schema)
    write_to_synapse(new_row)

    if len(df_table.columns) == len(df_file.columns):
      validation_status = "Success"
    else:
      validation_status = "Failure"
   
    new_row = spark.createDataFrame([(db_name,adls_path.strip(),table_name,"CreateSnowflakeTable","ParquetVsSnowflakeColumnCount",validation_status,"",None,None,len(df_file.columns),len(df_table.columns),migration_id,current_time)], schema=schema)
    print(new_row)
 
    write_to_synapse(new_row)
    

# COMMAND ----------


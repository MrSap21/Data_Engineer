# Databricks notebook source
base_path = '/mnt/pharmacy/ARCH/OUT/retail/ic_prescription_fill_plan/load-ready/'

outputColList =['dna_eff_dttm', 'dna_end_dttm', 'dna_stat_cd', 'dna_create_dttm', 'dna_update_dttm', 'dna_batch_id', 'dna_rx_sk', 'rx_nbr', 'str_nbr', 'rx_fill_nbr', 'rx_partial_fill_nbr', 'fill_enter_dt', 'fill_enter_tm', 'third_party_plan_id', 'fill_sold_dt', 'cob_ind', 'fill_adjud_dt', 'fill_adjud_tm', 'fill_adjud_cd', 'claim_ref_nbr', 'plan_tot_paid_dlrs', 'plan_return_cost_dlrs', 'plan_return_fee_dlrs', 'plan_return_copay_dlrs', 'plan_return_tax_dlrs', 'plan_submit_copay_dlrs', 'plan_submit_cost_dlrs', 'plan_submit_fee_dlrs', 'plan_submit_tax_dlrs', 'relocate_fm_str_nbr', 'plan_ar_dlrs', 'src_create_user_id', 'src_update_dttm', 'src_update_user_id', 'src_create_dttm', 'src_partition_nbr', 'plan_gross_due_dlrs', 'basis_of_reimb_detrm', 'bin_nbr', 'plan_group_nbr', 'del_adjud_cd', 'general_phrm_nbr', 'general_recipient_nbr', 'general_rph_nbr', 'maj_med_prior_auth_nbr', 'plan_incent_submtd_dlrs', 'plan_incentive_paid_dlrs', 'plan_other_paid_dlrs', 'plan_other_submtd_dlrs', 'attributed_to_tax_dlrs', 'reimburs_loss_dlrs', 'plan_copay_dlrs', 'plan_other_dlrs', 'plan_tax_dlrs', 'dna_src_ind', 'plan_rtrnd_coins_dlrs', 'plan_returnd_coins_dlrs', 'plan_other_dlrs_paid_type_cd', 'plan_other_dlrs_subm_type_cd', 'plan_other_paid_2_dlrs', 'plan_other_dlrs_paid_2_type_cd', 'plan_other_paid_3_dlrs', 'plan_other_dlrs_paid_3_type_cd', 'plan_other_info', 'prcs_ctrl_nbr', 'benefit_stg_1_amt', 'benefit_stg_1_qlfr_cd', 'benefit_stg_2_amt', 'benefit_stg_2_qlfr_cd', 'benefit_stg_3_amt', 'benefit_stg_3_qlfr_cd', 'benefit_stg_4_amt', 'benefit_stg_4_qlfr_cd', 'coupon_ind', 'coupon_drug_id', 'other_payr_coverage_cd', 'additional_mfgr_coupon_w1_msg', 'additional_msg_qlfr_w1_cd', 'aprv_msg_cd1', 'aprv_msg_cd2', 'aprv_msg_cd3', 'aprv_msg_cd4', 'aprv_msg_cd5', 'general_recipient_return_id', 'ntwrk_remb_return_id', 'return_plan_group_nbr', 'return_plan_id', 'general_pbr_nbr', 'general_rph_nbr_qlfr', 'prior_auth_cd', 'prior_auth_nbr', 'rx_denial_override_cd', 'rx_denial_override_cd_2', 'rx_denial_override_cd_3']

surrogateKeys = ['dna_rx_sk','rx_fill_nbr','rx_partial_fill_nbr','fill_enter_dt','fill_enter_tm','cob_ind']

delta_file_location = '/mnt/test/delta/ic_prescription_fill_plan'

table_name = 'ic_prescription_fill_plan'


# COMMAND ----------

import pyspark.sql.functions as F

def historic_type_one(df, surrogateKeys):
  
  if (df.where(F.col("dna_batch_id").isNull()).count()) == 0:
    order_by_str = "dna_batch_id desc, dna_update_dttm"
  else:
    order_by_str = "dna_update_dttm"   
    
  df.createOrReplaceTempView("df_view")
  df=spark.sql("SELECT distinct RANK() OVER (partition by {0} ORDER BY {1} desc) AS rank,* from df_view ".format(",".join(surrogateKeys),order_by_str))
  result_df=df.filter("rank=1" )
  return result_df

# COMMAND ----------

def records_with_D(df):
  df_new = df.filter("dna_cdc_cd != 'D'")
  return df_new

# COMMAND ----------

from pyspark.sql import functions as F
#creating a delta file from base data.

base_df = spark.read.parquet(base_path+"*/*")

lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)

#latest_date = save_batchDate(base_df)
file_names = []
for x in lst1:
  if "bkp" not in str(x.name):
    file_names.append(x.name)

print("latest_batch file :" + file_names[0])
  
delta_df = historic_type_one(base_df, surrogateKeys)

delta_df = delta_df.dropDuplicates(surrogateKeys)

delta_df = records_with_D(delta_df)

delta_df = delta_df.select(outputColList)

#delta_df.write.parquet("save parquet files location")

delta_df.write.format("delta").save(delta_file_location)
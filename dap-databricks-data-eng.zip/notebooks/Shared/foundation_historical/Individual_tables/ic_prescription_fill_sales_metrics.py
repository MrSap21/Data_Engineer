# Databricks notebook source
base_path = '/mnt/pharmacy/ARCH/OUT/retail/ic_prescription_fill_sales_metric/load-ready/'

outputColList= ['dna_eff_dttm','dna_end_dttm','dna_stat_cd','dna_create_dttm','dna_update_dttm','dna_batch_id','dna_rx_sk','rx_nbr','str_nbr','rx_fill_nbr','rx_partial_fill_nbr','fill_enter_dt','fill_enter_tm','fill_sold_dt','fill_gross_profit_dlrs','fill_revenue_dlrs','fill_cost_dlrs','fill_tax_dlrs','script_type','dna_src_ind']

delta_file_location="/mnt/test/delta/ic_prescription_fill_sales_metric_06072021"

table_name = "ic_prescription_fill_sales_metric"

surrogateKeys = ['dna_rx_sk' ,'rx_fill_nbr','rx_partial_fill_nbr','fill_enter_dt','fill_enter_tm']


# COMMAND ----------

import pyspark.sql.functions as F

def historic_type_one(df, surrogateKeys):
  
  if (df.where(F.col("dna_batch_id").isNull()).count()) == 0:
    order_by_str = "dna_batch_id desc, dna_update_dttm"
  else:
    order_by_str = "dna_update_dttm"   
    
  df.createOrReplaceTempView("df_view")
  df=spark.sql("SELECT distinct RANK() OVER (partition by {0} ORDER BY {1} desc) AS rank,* from df_view ".format(",".join(surrogateKeys),order_by_str))
  result_df=df.filter("rank=1" )
  return result_df

# COMMAND ----------

def records_with_D(df):
  df_new = df.filter("dna_cdc_cd != 'D'")
  return df_new

# COMMAND ----------

from pyspark.sql import functions as F
#creating a delta file from base data.

base_df = spark.read.parquet(base_path+"*/*")

lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)

#latest_date = save_batchDate(base_df)
file_names = []
for x in lst1:
  if "bkp" not in str(x.name):
    file_names.append(x.name)

print("latest_batch file :" + file_names[0])
  
delta_df = historic_type_one(base_df, surrogateKeys)

delta_df = delta_df.dropDuplicates(surrogateKeys)

delta_df = records_with_D(delta_df)

delta_df = delta_df.select(outputColList)

#delta_df.write.parquet("save parquet files location")

delta_df.write.format("delta").save(delta_file_location)
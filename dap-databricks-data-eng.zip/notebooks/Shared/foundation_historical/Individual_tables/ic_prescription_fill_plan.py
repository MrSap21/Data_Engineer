# Databricks notebook source
from pyspark.sql.functions import trim
import pyspark.sql.functions as F
from pyspark.sql.types import StructField
from pyspark.sql.types import *
from datetime import timedelta
from datetime import datetime
from datetime import date



# COMMAND ----------

history_loc = "/mnt/staging/phase1/ic_prescription_fill_plan/"
bad_loc = "/mnt/wrangled/baddata/history/ic_prescription_fill_plan/"
delta_loc = "/mnt/curated/health services/ic_prescription_fill_plan/"

# COMMAND ----------

def getParametersForHistory(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
    return (table_type, surrogateKeys, outputColList,clean_sql,dedup_column,bad_sql)

# COMMAND ----------

def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    stage_path = ""
    load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
        if tableName == 'ic_prescription_fill_plan':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"               
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"           
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)

# COMMAND ----------

def filterClean(df, clean_sql):
    if len(clean_sql.strip()) <= 3:
       return df
    df.createOrReplaceTempView("clean_df")
    sql1 = "select * from clean_df " + clean_sql
    df1 = spark.sql(sql1)
    return df1
def trimStringFields(df):
    df1 = df
    for fld in df.schema.fields:
        if str(fld.dataType) == 'StringType':
           df1 = df1.withColumn(fld.name, F.trim(df1[fld.name]))
    return df1

# COMMAND ----------

import pyspark.sql.functions as F
def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

def removeHighBatchId(fle, last_batch_id):
    lst1 = dbutils.fs.ls(fle.path)
    lst2 = list(filter(lambda rw: rw.name.replace("/","") <= str(last_batch_id), lst1))
    return lst2

# COMMAND ----------

def historic_type_one1(df, surrogateKeys):
  order_by_str = "dna_batch_id desc, dna_update_dttm"
  df.createOrReplaceTempView("df_view")
  df=spark.sql("SELECT distinct RANK() OVER (partition by {0} ORDER BY {1} desc) AS rank,* from df_view ".format(",".join(surrogateKeys),order_by_str))
  result_df=df.filter("rank=1" )
  return result_df

def fixDataType(df, outputColList, fldList):
    df1 = df
    colSet = set(df1.columns)
    outSet = set(outputColList)
    diffSet = outSet - colSet
    print(diffSet)
    baseList = df1.schema.fields
    for cle in diffSet:
        print(cle)
        df1 = df1.withColumn(cle,  F.lit(None).cast(fldList[cle].dataType))
    for cle in baseList:
        if cle.name in fldList:
           df1 = df1.withColumn(cle.name,  df1[cle.name].cast(fldList[cle.name].dataType))
    return df1.select(outputColList)
def runprsfill(prefix, fldList,outputColList,surrogateKeys, clean_sql,bad_sql, last_batch_id):
    lst5 = dbutils.fs.ls("/mnt/pharmacy/ARCH/OUT/retail/ic_prescription_fill_plan/snapshot/fill_enter_dt/")
    #year = prefix[0:4]
    lst6 =  list(filter(lambda rw: rw.name.startswith(prefix), lst5))
    
    #print("lst6-->" + lst6.collect())
    sze = len(lst6)
    dct2 = {}
    dct3 = {}
    for  ent in lst6:
        lst7 = dbutils.fs.ls(ent.path)
        #base_df = spark.read.parquet( lst7[0].path + "/*/*")
        #base_df = fixDataType(base_df, outputColList, fldList)
        if len(lst7) > 0:
           for i in list(range(0,len(lst7))):
               #print(lst7[i].path)
               lst10 = []
               ky = lst7[i].name[0:4]
               if last_batch_id is not None:
                  if lst7[i].name.replace("/", "") > last_batch_id:
                     #print("skipping file path:" + lst7[i].path)
                     continue
               if lst7[i].name.startswith("20210228222222"):
                  print(lst7[i].path)
                  lst11 = []
                  if ky in dct3:
                     lst11 = dct3[ky]
                  lst11.append(lst7[i].path + "*/*")
                  dct3[ky] = lst11
               else:
                 if ky in dct2:
                    lst10 = dct2[ky]
                 lst10.append(lst7[i].path + "*/*")
                 path_final = lst7[i].path + "*/*"
                 #print (path_final)
                 dct2[ky] = lst10
               
    
    kys = sorted(list(dct2.keys()))
    base_df = spark.read.parquet(*dct2[kys[0]])
    base_df = fixDataType(base_df,outputColList, fldList)
    i = 0
    for ky in kys:
        if i > 0:
            dfx = spark.read.parquet(*dct2[ky])
            dfx = fixDataType(dfx,outputColList, fldList)
            base_df = base_df.union(dfx)
        i = i + 1
        
    kys = sorted(list(dct3.keys()))
    for ky in kys:
        print(ky)
        dfx = spark.read.parquet(*dct3[ky])
        dfx = fixDataType(dfx,outputColList, fldList)
        base_df = base_df.union(dfx)
    base_df.createOrReplaceTempView("prs_fill")
    #base_df.printSchema()
    ##### FIX FOR PRESCRITON_FILL
    
    delta_df = base_df.filter("dna_stat_cd != 'R'")
    delta_df = historic_type_one1(delta_df, surrogateKeys)
    ## remove duplicate.
    delta_df = delta_df.dropDuplicates(surrogateKeys)
    delta_df = delta_df.select(outputColList)
    delta_df.persist()
    delta_df.createOrReplaceTempView("df_view")
    print('delta--'+str(delta_df.count()))
    dfclean = spark.sql("select * from df_view " + clean_sql)
    print('dfclean--'+str(dfclean.count()))
    history_location = history_loc + prefix
    dbutils.fs.rm(history_location,True)
    dfclean.write.format("parquet").mode('overwrite').save(history_location)

    badlocation = bad_loc + prefix
    dfbad = spark.sql("select * from df_view " + bad_sql)
    print('dfbad--'+str(dfbad.count()))
    dbutils.fs.rm(badlocation,True)
    dfbad.write.format("parquet").mode('overwrite').save(badlocation)
    
    

# COMMAND ----------

#(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql) = getParameters('ic_prescription_fill')
(table_type, surrogateKeys, outputColList,clean_sql,dedup_column,bad_sql) = getParametersForHistory('ic_prescription_fill_plan')


# COMMAND ----------


prefix='2021-08-01'
fldList = {}
#delta_file_location_4 = "/mnt/staging/phase1/ic_prescription_fill_plan/" + prefix
phas1_src_file = "/mnt/pharmacy/ARCH/OUT/retail/ic_prescription_fill_plan/snapshot/fill_enter_dt/" + prefix +"/*/*"
print (phas1_src_file)
df1 = spark.read.parquet(phas1_src_file)
for fld in df1.schema.fields:
    fldList[fld.name] = fld
    

# COMMAND ----------

print (bad_sql)

# COMMAND ----------

lst = ['2021-01','2021-02','2021-03','2021-04','2021-05','2021-06','2021-07']
#lst = ['2020-01','2020-02','2020-03','2020-04','2020-05','2020-06','2020-07','2020-08','2020-09','2020-10','2020-11','2020-12']
#lst = ['2020-11','2020-12']
#lst = ['2019-07','2019-08','2019-09','2019-10','2019-11','2019-12']
#lst = ['2018-01','2018-02','2018-03','2018-04','2018-05','2018-06','2018-07','2018-08','2018-09','2018-10','2018-11','2018-12']
#lst = ['2020-01-01']
#lst = ['2017-07','2017-08','2017-09','2017-10','2017-11','2017-12']

for prefix in lst:
    print(prefix)
    runprsfill(prefix, fldList,outputColList,surrogateKeys, clean_sql,bad_sql,'20210806134300')

# COMMAND ----------

#dbutils.fs.ls("/mnt/staging/phase1/ic_prescription_fill_plan/2020-01/")
#dbutils.fs.ls("/mnt/wrangled/baddata/history/ic_prescription_fill_plan/2020-01")


# COMMAND ----------


#df_fill_plan = spark.read.parquet("/mnt/staging/phase1/ic_prescription_fill_plan/*")
#adf = df_fill_plan.filter("fill_enter_dt == '2021-08-01'")

#df_fill_plan.select('dna_rx_sk','rx_fill_nbr','rx_partial_fill_nbr','fill_enter_dt','fill_enter_tm','cob_ind').distinct().count()
#print ("dst-->"+str(adf.count()))


# COMMAND ----------

#dbutils.fs.ls("/mnt/staging/phase1/ic_prescription_fill_plan/2021-08/")

# COMMAND ----------

#tmp_df = spark.read.parquet("/mnt/pharmacy/ARCH/OUT/retail/ic_prescription_fill_plan/snapshot/fill_enter_dt/2021-08-01/20210801162502/ic_prescription_fill_plan_ldr_20210801162502/")
#tmp_df.printSchema()
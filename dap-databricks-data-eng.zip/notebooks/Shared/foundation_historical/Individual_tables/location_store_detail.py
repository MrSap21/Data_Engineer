# Databricks notebook source
from datetime import datetime

# COMMAND ----------

targetLoc = "/mnt/staging/phase1/location_store_detail/"
badrecLoc = "/mnt/wrangled/baddata/history/location_store_detail/"
base_path= "/mnt/location/ARCH/OUT/location/location_store_detail/load-ready/"

# COMMAND ----------

def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = ''
    if rw['dedup_column'] is not None:
       dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    stage_path = ""
    load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
        if tableName == 'ic_prescription_fill':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"               
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"           
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)

# COMMAND ----------

table_name = 'location_store_detail'

# COMMAND ----------

import pyspark.sql.functions as F
def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------


def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele


# COMMAND ----------

def fixType2DataWithDelete(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'],x['dna_update_dttm'])))
  for rw in rowList:
      ky = createKey(rw)
      mp[ky] = rw
       
  for k in kst:
        rw = rowList[k]
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           delList.append(createKey(rw))
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
           if (rw2 is None):
              lst.append(createKey(rw))
           else:
              if (((type(rw['dna_end_dttm']) is datetime) and rw['dna_end_dttm'].year == 9999)  or  ((type(rw['dna_end_dttm']) is str ) and rw['dna_end_dttm'].startswith('9999'))):
                 continue
              else:
                 lst.append(createKey(rw))
  for f in lst:
        f1 = f.split("----")
        if len(delList) == 0:
           retList.append(mp[f])
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if d1[0] == f1[0]:
                  match = True
                  break
           if match == False:
              retList.append(mp[f])
  rowList2 = list(sorted(retList, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'])))
  dct1 = {}
  for rw in rowList2:
      ky1 = getStringKey(rw['dna_eff_dttm'])
      endKy = getStringKey(rw['dna_end_dttm'])
      if ky1 not in dct1:
         dct1[ky1] = rw
      else:
          endKy2 = getStringKey(dct1[ky1]['dna_end_dttm'])
          if endKy2 < endKy:
             dct1[ky1] = rw
          if endKy2 == endKy:
             if rw['dna_update_dttm'] > dct1[ky1]['dna_update_dttm']:
                dct1[ky1] = rw
  retList2 = []
  for ky in dct1.keys():
      retList2.append(dct1[ky])
  
  return retList2



# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location, bad_sql) = getParameters('location_store_detail')
        
lst = []
lst.append(base_path+"201*/*")
lst.append(base_path+"2020*/*")
lst.append(base_path+"202101*/*")
lst.append(base_path+"202102*/*")
lst.append(base_path+"202103*/*")
lst.append(base_path+"202104*/*")
lst.append(base_path+"202105*/*")
lst.append(base_path+"202106*/*")
lst.append(base_path+"2021070*/*")
lst.append(base_path+"2021071*/*")
lst.append(base_path+"20210721*/*")
lst.append(base_path+"20210722*/*")
lst.append(base_path+"20210723*/*")
lst.append(base_path+"20210724*/*")
lst.append(base_path+"20210725*/*")
lst.append(base_path+"20210726*/*")
### stopping 7/26 so to test incremental load
locDf = spark.read.parquet(*lst)


list_column = table_name + "_list"

schema = locDf.schema

df4 = groupBySurrgoteKey(locDf,table_name, surrogateKeys)

rd1 = df4.rdd.map(lambda rw:fixType2DataWithDelete(rw[list_column])).flatMap(lambda x:x)

df5 = spark.createDataFrame(rd1, schema)


df6 = df5.select(outputColList)

df6 = convertToTimestampToString(df6)


df6.createOrReplaceTempView("lc_detail")

dfclean = spark.sql("select * from lc_detail " + clean_sql)
dfbad = spark.sql("select * from lc_detail " + bad_sql)

dbutils.fs.rm(targetLoc, True)
dbutils.fs.rm(badrecLoc, True)

dfclean.write.mode("overwrite").parquet(targetLoc)
dfbad.write.mode("overwrite").parquet(badrecLoc)




#df6.write.parquet("/mnt/landing/common/foundation_testing/drug/out/drug")

##df6.write.format("delta").save(delta_file_location)

# COMMAND ----------

dbutils.fs.rm("/mnt/curated/config/", True)

# COMMAND ----------

# MAGIC %fs 
# MAGIC ls dbfs:/FileStore/shared_uploads/sunjay.karan@walgreens.com/
# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import when

# COMMAND ----------

targetLoc = "/mnt/staging/phase1/plan_category/"
badrecLoc = "/mnt/wrangled/baddata/history/plan_category/"
base_path= "/mnt/pharmacy/ARCH/OUT/insurance/plan_category/load-ready/"

# COMMAND ----------

def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = ''
    if rw['dedup_column'] is not None:
       dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    stage_path = ""
    load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
        if tableName == 'ic_prescription_fill':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"               
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"           
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)

# COMMAND ----------

def getParametersForHistory(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
    return (table_type, surrogateKeys, outputColList,clean_sql,dedup_column,bad_sql)

# COMMAND ----------

import pyspark.sql.functions as F
def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------


def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele


# COMMAND ----------

def fixType2DataWithDelete(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  #rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'],x['dna_update_dttm'])))
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_update_dttm'])))
  for rw in rowList:
      ky = createKey(rw)
      mp[ky] = rw
       
  for k in kst:
        rw = rowList[k]
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           delList.append(createKey(rw))
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
           if (rw2 is None):
              lst.append(createKey(rw))
           else:
              if (((type(rw['dna_end_dttm']) is datetime) and rw['dna_end_dttm'].year == 9999)  or  ((type(rw['dna_end_dttm']) is str ) and rw['dna_end_dttm'].startswith('9999'))):
                 continue
              else:
                 lst.append(createKey(rw))
  for f in lst:
        f1 = f.split("----")
        if len(delList) == 0:
           retList.append(mp[f])
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if d1[0] == f1[0]:
                  match = True
                  break
           if match == False:
              retList.append(mp[f])
  rowList2 = list(sorted(retList, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'])))
  dct1 = {}
  for ln in rowList2:
      print(getStringKey(ln['dna_eff_dttm'] ) +   ":" + getStringKey(ln['dna_end_dttm']) + ":" + getStringKey(ln['dna_update_dttm']))
  for rw in rowList2:
      ky1 = getStringKey(rw['dna_eff_dttm'])
      endKy = getStringKey(rw['dna_end_dttm'])
      if ky1 not in dct1:
         dct1[ky1] = rw
      else:
          endKy2 = getStringKey(dct1[ky1]['dna_end_dttm'])
          if endKy2 < endKy:
             dct1[ky1] = rw
          if endKy2 == endKy:
             if rw['dna_update_dttm'] > dct1[ky1]['dna_update_dttm']:
                dct1[ky1] = rw
  retList2 = []
  for ky in dct1.keys():
      retList2.append(dct1[ky])
  
  return retList2



# COMMAND ----------

def fixDataType(df, outputColList, fldList):
    df1 = df
    colSet = set(df1.columns)
    outSet = set(outputColList)
    diffSet = outSet - colSet        
    baseList = df1.schema.fields
    for cle in diffSet:
        #print(cle)
        df1 = df1.withColumn(cle,  F.lit(None).cast(fldList[cle].dataType))
    for cle in baseList:
        if cle.name in fldList:
           df1 = df1.withColumn(cle.name,  df1[cle.name].cast(fldList[cle.name].dataType))
    return df1.select(outputColList)    

# COMMAND ----------

def readAndConvertDataType(base_path,outputColList, fldList ):
   
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    #base_df = spark.read.parquet( lst1[0].path + "*/*" ).select(outputColList)  
    #20210810001502
    base_df = spark.read.parquet( base_path + "20210727001944/*").select(outputColList)  
    #base_df = spark.read.parquet( base_path + "20210810001502/*").select(outputColList) 
    #yearList = ['2017', '2018', '2019', '2020','202101','202102','202103','202104','202105','202106','2021071','2021072']
    yearList = ['2017', '2018', '2019', '2020','202101','202102','202103','202104','202105','202106','2021071']
    #yearList = ['2017', '2018', '2019', '2020','202101','202102','202103','202104','202105','202106']
    
    for ln in yearList:        
        lst2 = list(filter(lambda rw: ln in rw.name,lst1 ))
        lst3 = [rw.path + "*/*" for rw in lst2]        
        dfx = spark.read.parquet( *lst3 )        
        dfx = fixDataType(dfx, outputColList, fldList)
        base_df = base_df.union(dfx)
    
    return base_df

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2
  
def trimStringFields(df):
    df1 = df
    for fld in df.schema.fields:
        if str(fld.dataType) == 'StringType':
           df1 = df1.withColumn(fld.name, F.trim(df1[fld.name]))
    return df1
  
def convertDateToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "DateType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2
  
def updateEffDate(df):    
    df3 = df2.withColumn("dna_eff_dttm", when(df.dna_eff_dttm == "0001-01-03 00:00:00","0001-01-01 00:00:00")    
    return df3

# COMMAND ----------

def getMaxbatchId(base_path):
    maxBatchId = '0'
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    maxBatchId = lst1[0].name.replace("/","")
    return  maxBatchId

# COMMAND ----------

def getLatestSchema(base_path,maxbatchId, outputColList):
    lc = base_path + str(maxbatchId) + "/*/*"
    df = spark.read.parquet(lc)
    #df1 = df.select(outputColList)
    fldList = {}
    fields = df.schema.fields
    for fld in fields:
        fldList[fld.name] = fld
    return fldList

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location, bad_sql) = getParameters('plan_category')

#(table_type, surrogateKeys, outputColList,clean_sql,dedup_column,bad_sql) =getParametersForHistory('plan_category')


# COMMAND ----------

#actual
maxBatchId = getMaxbatchId(base_path)
fldList = getLatestSchema(base_path,maxBatchId, outputColList)
dfinput = readAndConvertDataType(base_path,outputColList, fldList )
df = dfinput.withColumn("dna_eff_dttm", when(dfinput.dna_eff_dttm == "0001-01-03 00:00:00","0001-01-01 00:00:00").
    otherwise(dfinput.dna_eff_dttm))
df = trimStringFields(df)
df_delete_records = df.filter("dna_stat_cd = 'D'")
df = df.filter("dna_stat_cd != 'D'")

table_name = 'plan_category'
list_column = table_name + "_list"
schema = df.schema

dfGr = groupBySurrgoteKey (df, table_name, surrogateKeys)
rd1 = dfGr.rdd.map(lambda rw:fixType2DataWithDelete(rw[list_column])).flatMap(lambda x:x)
df5 = spark.createDataFrame(rd1, schema)

#df6 = df5.select(outputColList)
#df6 = trimStringFields(df6)

df6 = df5.union(df_delete_records)
df6 = convertToTimestampToString(df6)
df6 = convertDateToString(df6)

df6.persist()
df6.createOrReplaceTempView("df_view")

dfclean = spark.sql("select * from df_view " + clean_sql)
dfbad = spark.sql("select * from df_view " + bad_sql)



# COMMAND ----------

#remove existing file from output location
dbutils.fs.rm(targetLoc,True)
dbutils.fs.rm(badrecLoc,True)

# COMMAND ----------

#write output to staging location
dfclean.write.parquet(targetLoc)
dfbad.write.parquet(badrecLoc)


# COMMAND ----------

dfclean.count()
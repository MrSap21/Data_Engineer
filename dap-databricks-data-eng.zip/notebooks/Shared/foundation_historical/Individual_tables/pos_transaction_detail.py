# Databricks notebook source
from pyspark.sql.functions import trim
import pyspark.sql.functions as F
from pyspark.sql.types import StructField
from pyspark.sql.types import *
from datetime import datetime
from datetime import date
from datetime import timedelta

# COMMAND ----------

def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    stage_path = ""
    load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
        if tableName == 'ic_prescription_fill':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"               
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"           
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)

# COMMAND ----------

def dedup(df, surrogateKeys, dedup_keys):
   whereClause =  " where dna_stat_cd != 'R'"
   df = df.createOrReplaceTempView("df_view")
   sql1 = """select * from (select *, row_number() over
            (partition by {0} order by {1} desc) as rn from {2} {3})as A
            where rn=1""".format(",".join(surrogateKeys), ",".join(dedup_keys), "df_view", whereClause)
   print(sql1)
    
   df1 = spark.sql(sql1)
   return df1

# COMMAND ----------

def filterClean(df, clean_sql):
    if len(clean_sql.strip()) <= 3:
       return df
    df.createOrReplaceTempView("clean_df")
    sql1 = "select * from clean_df " + clean_sql
    df1 = spark.sql(sql1)
    return df1
def trimStringFields(df):
    df1 = df
    for fld in df.schema.fields:
        if str(fld.dataType) == 'StringType':
           df1 = df1.withColumn(fld.name, F.trim(df1[fld.name]))
    return df1

# COMMAND ----------

import pyspark.sql.functions as F
def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

def filterOutBatches(dt_key, last_batchId):
    #last_batchId = "20210726091816"
    part_key = "partition_key=" + dt_key
    lst = dbutils.fs.ls("/mnt/pos/ARCH/OUT/idl/pos_transaction_detail/snapshot/sales_txn_dt/")
    lst1 = list(filter(lambda rw: rw.name.startswith(part_key),lst))
    finalList = []
    for ln in lst1:
        lst2 = dbutils.fs.ls(ln.path)
        lst3 = list(filter(lambda flinfo: flinfo.name.split("=")[1].replace("/","") <= last_batchId,lst2))
        for fl in lst3:
            finalList.append(fl.path + "*/*")
    return finalList  

# COMMAND ----------

def load_data(fullload, dt_key, last_batch_id):
    if fullload == True:
       df1 = spark.read.parquet('/mnt/pos/ARCH/OUT/idl/pos_transaction_detail/snapshot/sales_txn_dt/partition_key={0}*/partition_dna_batch_id=*/partition_file_name=*/'.format(dt_key))
       return df1
    else:
       lst1 = filterOutBatches(dt_key, last_batch_id)
       print(lst1)
       df1 = spark.read.parquet(*lst1)
       return df1

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql) = getParameters('pos_transaction_detail')
print(dedup_column)
#mthList = ['2018-10','2018-11','2018-12','2019-01','2019-02','2019-03', '2019-04','2019-05','2019-06','2019-07','2019-08','2019-09','2019-10','2019-11','2019-12','2020-01','2020-02','2020-03', '2020-04','2020-05','2020-06','2020-07','2020-08','2020-09','2020-10','2020-11','2020-12' ]
#mthList = ['2018-10','2018-11','2018-12','2019-01','2019-02','2019-03', '2019-04','2019-05','2019-06','2019-07','2019-08','2019-09','2019-10','2019-11','2019-12','2020-01','2020-02','2020-03', '2020-04','2020-05','2020-06','2020-07','2020-08','2020-09','2020-10','2020-11','2020-12' ]

mthList = ['2021-01','2021-02','2021-03','2021-04','2021-05', '2021-06', '2021-07']
last_batch_id = '20210726105246'
fullload = False
for mth in mthList:
    print(mth)
    df1 = load_data(fullload, mth, last_batch_id)
    df3 = trimStringFields(df1)
    df3 = dedup(df3,surrogateKeys,dedup_column  )

    df3 = df3.select(outputColList)
    df3 = convertToTimestampToString(df3)
    cleanLoc = "/mnt/staging/phase1/pos_transaction_detail/" + mth 
    df3.persist()
    print("delete:" + cleanLoc)
    dbutils.fs.rm(cleanLoc, True)
    df3.createOrReplaceTempView("df_view")
    dfclean = spark.sql ("select * from df_view " + clean_sql);
    dfclean.write.format("parquet").mode('overwrite').save(cleanLoc)
    dfbad = spark.sql ("select * from df_view " + bad_sql);
    delta_file_bad_location_4 = "/mnt/wrangled/baddata/pos_transaction_detail/" + mth 
    dbutils.fs.rm(delta_file_bad_location_4,True)
    dfbad.write.format("parquet").mode('overwrite').save(delta_file_bad_location_4)

# COMMAND ----------

lst1 = dbutils.fs.ls("/mnt/staging/phase1/pos_transaction_detail/")

# COMMAND ----------

lst1
# Databricks notebook source
table_name = "ic_drug_medispan"


base_path = '/mnt/pharmacy/ARCH/OUT/drug/ic_drug_medispan/load-ready/'

outputColList = ['dna_drug_medispan_sk', 'dna_eff_dttm', 'dna_end_dttm', 'dna_stat_cd', 'dna_create_dttm', 'dna_update_dttm', 'dna_batch_id', 'ndc_upc_hri_id', 'upc_hri_form_cd', 'drug_stat_cd', 'seq_cd', 'labeler_cd', 'generic_id_type_cd', 'generic_ingrd_id', 'dea_class_cd', 'ahfscc_therapeutic_class_cd', 'fda_therapeutic_equivlnc_cd', 'format_id_nbr', 'rx_otc_ind', 'third_party_restrict_cd', 'maint_drug_ind', 'dspn_unit_cd', 'unit_dose_unit_of_use_cd', 'route_admin', 'form_type_cd', 'dlrs_rank', 'rx_rank_cd', 'secondary_upc_hri_form_cd', 'secondary_drug_id', 'generic_drug_cd', 'drug_type_cd', 'internal_external_cd', 'single_ingrd_cd', 'storage_cond_cd', 'limit_stability_cd', 'old_id_form_cd', 'old_drug_id', 'old_format_id_nbr', 'old_id_eff_dt', 'new_id_form_cd', 'new_drug_id', 'new_format_id_nbr', 'new_id_eff_dt', 'prod_name', 'prod_name_extn', 'drug_to_drug_interact_cd', 'pcm_pattern_cd', 'allergy_pattern_cd', 'hfpg_ind', 'generic_prod_id', 'generic_prod_id_name', 'mfgr_name', 'mfgr_name_abbr', 'prod_desc_abbr', 'drug_name_cd', 'generic_prod_pkg_cd', 'drug_strength', 'drug_strength_uom', 'dosage_form_cd', 'pkg_sz', 'pkg_sz_uom', 'pkg_qty', 'repack_cd', 'tot_pkg_qty', 'desi_class_cd', 'pkg_desc', 'legend_chng_dt', 'next_smaller_ndc_suffix_nbr', 'next_larger_ndc_suffix_nbr', 'dur_knwlgbsd_drug_cd_nbr', 'wholesale_unit_price', 'awp_reportd_ind', 'medispan_drug_class', 'medispan_drug_class_grp', 'medispan_drug_subclass', 'medispan_drug_name', 'ppg_ind', 'hzrds_lvl_cd']



surrogateKeys = ['dna_drug_medispan_sk']


delta_file_location="/mnt/test/delta/ic_prescriber-full"


# COMMAND ----------

import pyspark.sql.functions as F
def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------

import datetime
def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime.datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele


# COMMAND ----------

def fixType2DataWithDelete(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'],x['dna_update_dttm'])))
  for rw in rowList:
      ky = createKey(rw)
      mp[ky] = rw
       
  for k in kst:
        rw = rowList[k]
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           delList.append(createKey(rw))
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
           if (rw2 is None):
              lst.append(createKey(rw))
           else:
              if (((type(rw['dna_end_dttm']) is datetime.datetime) and rw['dna_end_dttm'].year == 9999)  or  ((type(rw['dna_end_dttm']) is str ) and rw['dna_end_dttm'].startswith('9999'))):
                 continue
              else:
                 lst.append(createKey(rw))
  for f in lst:
        f1 = f.split("----")
        if len(delList) == 0:
           retList.append(mp[f])
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if d1[0] == f1[0]:
                  match = True
                  break
           if match == False:
              retList.append(mp[f])
  rowList2 = list(sorted(retList, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'])))
  dct1 = {}
  for rw in rowList2:
      ky1 = getStringKey(rw['dna_eff_dttm'])
      endKy = getStringKey(rw['dna_end_dttm'])
      if ky1 not in dct1:
         dct1[ky1] = rw
      else:
          endKy2 = getStringKey(dct1[ky1]['dna_end_dttm'])
          if endKy2 < endKy:
             dct1[ky1] = rw
  retList2 = []
  for ky in dct1.keys():
      retList2.append(dct1[ky])
  
  return retList2



# COMMAND ----------

patDf = spark.read.parquet(base_path+"*/*")

lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)

file_names = []
for x in lst1:
  if "bkp" not in str(x.name):
    file_names.append(x.name)

print("latest_batch file :" + file_names[0])

list_column = table_name + "_list"

schema = patDf.schema

df4 = groupBySurrgoteKey(patDf,table_name, surrogateKeys)

rd1 = df4.rdd.map(lambda rw:fixType2DataWithDelete(rw[list_column])).flatMap(lambda x:x)

df5 = spark.createDataFrame(rd1, schema)

df6 = df5.select(outputColList)

#df6.write.parquet("/mnt/landing/common/foundation_testing/drug/out/drug")

df6.write.format("delta").save(delta_file_location)

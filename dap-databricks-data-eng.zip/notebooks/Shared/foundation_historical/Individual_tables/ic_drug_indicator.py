# Databricks notebook source
import pyspark.sql.functions as F
from datetime import datetime 
from pyspark.sql import Row



# COMMAND ----------

staging_area = "/mnt/staging/phase1/ic_drug_indicator/"
bad_record_area = "/mnt/wrangled/baddata/phase1/ic_drug_indicator/"

# COMMAND ----------

def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    stage_path = ""
    load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
        if tableName == 'ic_prescription_fill':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"               
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"           
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)

# COMMAND ----------

def getMaxbatchId(base_path):
    maxBatchId = '0'
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    maxBatchId = lst1[0].name.replace("/","")
    return  maxBatchId

# COMMAND ----------

def getMaxbatchIdMinusOne(base_path):
    maxBatchId = '0'
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    maxBatchId = lst1[1].name.replace("/","")
    return  maxBatchId

# COMMAND ----------

def getLatestSchema(base_path,maxbatchId, outputColList):
    lc = base_path + str(maxbatchId) + "/ic*/*"
    df = spark.read.parquet(lc)
    df1 = df.select(outputColList)
    fldList = {}
    fields = df1.schema.fields
    for fld in fields:
        fldList[fld.name] = fld
    return fldList
    
    

# COMMAND ----------

def fixDataType(df, outputColList, fldList):
    df1 = df
    colSet = set(df1.columns)
    outSet = set(outputColList)
    diffSet = outSet - colSet
    if len(diffSet) > 0:
        print("different dataset")
        print(diffSet)
    baseList = df1.schema.fields
    for cle in diffSet:
        #print(cle)
        df1 = df1.withColumn(cle,  F.lit(None).cast(fldList[cle].dataType))
    for cle in baseList:
        if cle.name in fldList:
           df1 = df1.withColumn(cle.name,  df1[cle.name].cast(fldList[cle.name].dataType))
    return df1.select(outputColList)

# COMMAND ----------

def readAndConvertDataType(base_path,outputColList, fldList ):
   
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    base_df = spark.read.parquet( lst1[1].path + "ic_*/*" ).select(outputColList)
    for ln in lst1[2:]:
        #print("running:" + ln.path)
        dfx = spark.read.parquet(ln.path + "ic_*/*")
        dfx = fixDataType(dfx, outputColList, fldList)
        base_df = base_df.union(dfx)
    return base_df
  
    

# COMMAND ----------



# COMMAND ----------

def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------


def fixData(rowListin, outputColList):  
  rwList = list(filter(lambda rw: rw['dna_stat_cd'] != 'R', rowListin))
  if len(rwList) == 0:
     return []
  rowList = list(sorted(rwList, key = lambda x: (x['dna_update_dttm'], x['dna_eff_dttm']), reverse = True))
  latestRow = rowList[0]
  outList = []
  if latestRow['dna_stat_cd'] == 'C':
     outList.append(latestRow)
  else:
     dct = latestRow.asDict()
     dct['dna_stat_cd'] = 'C'
     rwx = Row(**dct)
     outList.append(rwx)
  for rw in rowList[1:]:
      if rw['dna_stat_cd'] == 'H':
         outList.append(rw)
      else:
        dct = rw.asDict()
        dct['dna_stat_cd'] = 'H'
        rwx = Row(**dct)
        outList.append(rwx)
  return outList



# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2
  
def trimStringFields(df):
    df1 = df
    for fld in df.schema.fields:
        if str(fld.dataType) == 'StringType':
           df1 = df1.withColumn(fld.name, F.trim(df1[fld.name]))
    return df1

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location, bad_sql) = getParameters('ic_drug_indicator')
base_path = "/mnt/pharmacy/ARCH/OUT/drug/ic_drug_indicator/load-ready/"
maxBatchId = getMaxbatchId(base_path)
print("max batch Id:Skipping:" + str(maxBatchId))

maxBatchId = getMaxbatchIdMinusOne(base_path)

print("max batch Id -1:" + str(maxBatchId))

fldList = getLatestSchema(base_path,maxBatchId, outputColList)
df = readAndConvertDataType(base_path,outputColList, fldList )
table_name = 'ic_dr_temp'
list_column = table_name + "_list"
schema = df.schema
dfGr = groupBySurrgoteKey (df, table_name, surrogateKeys)

# COMMAND ----------


rd1 = dfGr.rdd.map(lambda rw:fixData(rw[list_column], outputColList)).flatMap(lambda x:x)
df5 = spark.createDataFrame(rd1,schema)
df6 = convertToTimestampToString(df5)
##df6 = df6.filter("dna_")
#df6.write.mode("overwrite").save("/mnt/staging/phase1/ic_drug_indicator")

# COMMAND ----------

clean_sql

# COMMAND ----------

#delta_file_location_4 = "/mnt/staging/phase1/good/ic_drug_indicator/" 
dbutils.fs.rm(staging_area, True)
dbutils.fs.rm(bad_record_area, True)


df6.persist()
df6.createOrReplaceTempView("df_view")
dfclean = spark.sql ("select * from df_view " + clean_sql);
dfclean.write.format("parquet").mode('overwrite').save(staging_area)

dfbad = spark.sql ("select * from df_view " + bad_sql);
dfbad.write.format("parquet").mode('overwrite').save(bad_record_area)


    

# COMMAND ----------

20210724024011

# COMMAND ----------

# MAGIC %sql
# MAGIC select table_name,last_loaded_batch_id from proc_config

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/staging/phase1/
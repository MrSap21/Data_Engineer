# Databricks notebook source
from pyspark.sql.functions import trim
import pyspark.sql.functions as F
from pyspark.sql.types import StructField
from pyspark.sql.types import *
from datetime import datetime
from datetime import date
from datetime import timedelta

# COMMAND ----------


targetLoc = "/mnt/staging/phase1/ic_prescriber_location/"
dbutils.fs.rm(targetLoc, True)
sourceLoc = "/mnt/pharmacy/ARCH/OUT/prescriber/ic_prescriber_location/load-ready/*/ic_prescriber_location_ld*/*"
badrecordLoc = "/mnt/wrangled/prescriber/ic_prescriber_location/history/badrecords/"
dbutils.fs.rm(badrecordLoc, True)
historicalDeltaLoc = "/mnt/curated/prescriber/ic_prescriber_location/delta/"
loadReadyLoc = "/mnt/curated/prescriber/ic_prescriber_location/load-ready/"


# COMMAND ----------

##This is final
def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
    batchIdList = []
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    #stage_path = ""
    #load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                batchIdList.append(batch_id)
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
                  
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          batchIdList.append(batch_id)
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
        if tableName == 'ic_prescription_fill':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      batchIdList.append(ln_batch_id)
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          batchIdList.append(batch_id)
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
    year = datetime.now().year
    if current_batch_id[0:4] > str( year + 1):
       lst3 = list(filter(lambda fld : fld[0:4] <= str(year + 1), batchIdList))
       lst1 = sorted(lst3, reverse=True)
       current_batch_id = lst1[0]
    stage_path = stage_path + current_batch_id + "/"
    load_ready_path = load_ready_path + current_batch_id + "/"     
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)
    

# COMMAND ----------


def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------


def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele

# COMMAND ----------

def fixType2DataWithDelete(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'], x['dna_update_dttm'])))
  for rw in rowList:
      ky = createKey(rw)
      mp[ky] = rw
       
  for k in kst:
        rw = rowList[k]
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           delList.append(createKey(rw))
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
           if (rw2 is None):
              ky = createKey(rw)
              if ky not in lst:
                 lst.append(ky)
           else:
              if (((type(rw['dna_end_dttm']) is datetime) and rw['dna_end_dttm'].year == 9999)  or  ((type(rw['dna_end_dttm']) is str ) and rw['dna_end_dttm'].startswith('9999'))):
                 continue
              else:
                 lst.append(createKey(rw))
  lset = set(lst)
  lst = list(lset)
  lst = sorted(lst)
  print(lst)
  dct1 = {}
  for f in lst:
      f1 = f.split("----")
      arr = []
      if f1[0] in dct1:
         arr = dct1[f1[0]]
      arr.append(f)
      dct1[f1[0]] = arr
  lst2 = []
  for ky in dct1.keys():
      if len(dct1[ky]) == 1:
         lst2.append(dct1[ky][0])
      if len(dct1[ky]) > 1:
         arr = dct1[ky]
         arr1 = list(sorted(arr, key = lambda x : x, reverse = True))
         lst2.append(arr1[0])
          
  for f in lst2:
        f1 = f.split("----")
        if len(delList) == 0:
           retList.append(mp[f])
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if d1[0] == f1[0]:
                  drw = mp[dl]
                  rw = mp[f]
                  if drw['dna_update_dttm'] >= rw['dna_update_dttm']:
                     match = True
                     break
           if match == False:
              retList.append(mp[f])
  return retList

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2
  
def convertDateToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "DateType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

def trimStringFields(df):
    df1 = df
    for fld in df.schema.fields:
        if str(fld.dataType) == 'StringType':
           df1 = df1.withColumn(fld.name, F.trim(df1[fld.name]))
    return df1
  
def fixDataType(df, outputColList, fldList):
    df1 = df
    colSet = set(df1.columns)
    outSet = set(outputColList)
    diffSet = outSet - colSet        
    baseList = df1.schema.fields
    for cle in diffSet:
        #print(cle)
        df1 = df1.withColumn(cle,  F.lit(None).cast(fldList[cle].dataType))
    for cle in baseList:
        if cle.name in fldList:
           df1 = df1.withColumn(cle.name,  df1[cle.name].cast(fldList[cle.name].dataType))
    return df1.select(outputColList) 
  
def getLatestSchema(base_path,maxbatchId, outputColList):
    lc = base_path + str(maxbatchId) + "/*/*"
    df = spark.read.parquet(lc)
    #df1 = df.select(outputColList)
    fldList = {}
    fields = df.schema.fields
    for fld in fields:
        fldList[fld.name] = fld
    return fldList
  
def getMaxbatchId(base_path):
    maxBatchId = '0'
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    maxBatchId = lst1[0].name.replace("/","")
    return  maxBatchId

# COMMAND ----------

#sourceLoc
base_path='/mnt/pharmacy/ARCH/OUT/prescriber/ic_prescriber_location/load-ready/'

# COMMAND ----------

year_month_list=['200811', '200812','202101','202102','202103','202104','202105','202106','202107','2021080','2021081','20210821','20210822']

start_year=2009
i=1

while start_year < 2021:
  while i < 10:
    year_month_list.append(str(start_year)+'0'+str(i))
    i+=1
  while i <= 12:
    year_month_list.append(str(start_year)+str(i))
    i+=1
  i=1  
  start_year += 1

year_list = sorted(year_month_list)
  

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql) = getParameters('ic_prescriber_location')
print(dedup_column)
table_name = 'ic_prescriber_location'
list_column = table_name + "_list"
lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
     
maxBatchId = getMaxbatchId(base_path)
fldList = getLatestSchema(base_path,maxBatchId, outputColList)
df = spark.read.parquet( base_path + "20210822004025/*").select(outputColList) 

# COMMAND ----------

#testing 
for ln in year_list:        
        lst2 = list(filter(lambda rw: ln in rw.name,lst1 ))
        for lnn in lst2:
            dfx = spark.read.parquet(lnn.path+ "ic_prescriber_location_ld*/*")               
            dfx = fixDataType(dfx, outputColList, fldList)
            df = df.union(dfx)              
        
#df.write.format("delta").save("/mnt/wrangled/common/delta2/ic_prescriber_location_inputtillaug22")

# COMMAND ----------

#testing
def historyLoadType2(df,table_name, suggrogateKeys,outputColList):
    schema = df.schema
    list_column = table_name + "_list"
    df4 = groupBySurrgoteKey(df,table_name, suggrogateKeys)
    rd1 = df4.rdd.map(lambda rw:fixType2DataWithDelete(rw[list_column])).flatMap(lambda x:x)
    df5 = spark.createDataFrame(rd1, schema)
    df6 = df5.select(outputColList)
    return df6
df.persist()
for prefix in list(range(1,10)):
    df1 = df.filter("dna_pbr_sk like '{0}%'".format(prefix))
    df6 = historyLoadType2(df1,table_name, surrogateKeys,outputColList)
    df6 = convertToTimestampToString(df6)
    df6 = convertDateToString(df6)
    df6 = trimStringFields(df6)
#dbutils.fs.rm("/mnt/staging/phase1/ic_patient/", True)

    df6.createOrReplaceTempView("df_view")

    df6.persist()

    dfclean = spark.sql ("select * from df_view " + clean_sql)
    dfbad = spark.sql("select * from df_view " + bad_sql)
   
    dbutils.fs.rm(targetLoc + str(prefix), True)
    dbutils.fs.rm(badrecordLoc + str(prefix), True)
    dfclean.write.mode("overwrite").parquet(targetLoc + str(prefix))
    dfbad.write.mode("overwrite").parquet(badrecordLoc + str(prefix))
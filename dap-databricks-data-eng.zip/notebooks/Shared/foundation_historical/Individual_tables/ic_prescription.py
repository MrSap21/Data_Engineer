# Databricks notebook source
base_path = '/mnt/pharmacy/ARCH/OUT/retail/ic_prescription/load-ready/'

outputColList =['dna_eff_dttm', 'dna_end_dttm', 'dna_stat_cd', 'dna_create_dttm', 'dna_update_dttm', 'dna_batch_id', 'dna_rx_sk', 'rx_nbr', 'str_nbr', 'rx_create_dt', 'rx_create_tm', 'pat_id', 'dna_pat_sk', 'pbr_id', 'pbr_loc_id', 'dna_pbr_sk', 'pbr_ord_nbr', 'drug_id', 'dna_drug_sk', 'dea_class_cd', 'drug_non_sys_cd', 'drug_sub_cd', 'ord_drug_id', 'generic_substn_pref_ind', 'fill_unlimited_ind', 'fill_qty_dispensed', 'fill_days_supply', 'rx_daw_cd', 'rx_daw_ind', 'rx_sig', 'rx_stat_cd', 'rx_tot_dspn_qty', 'rx_written_dt', 'rx_written_tm', 'rx_orig_fill_dttm', 'rx_added_qty', 'rx_refill_expire_dt', 'rx_refill_expire_tm', 'rx_cmnt', 'fill_nbr_prescribed', 'fill_nbr_dspn', 'fill_nbr_added', 'fill_auto_ind', 'fill_nbr_last_disp', 'fill_entered_dttm', 'image_id', 'scan_user_id', 'scan_dt', 'scan_tm', 'scan_str_nbr', 'tip_rx_ind', 'route_str_nbr', 'src_create_user_id', 'src_update_user_id', 'src_update_dttm', 'rx_orig_qty_dspn', 'rx_orig_days_supply', 'rx_orig_qty', 'src_partition_nbr', 'diagnosis_cd_1', 'diagnosis_cd_2', 'diagnosis_cd_3', 'diagnosis_cd_4', 'diagnosis_cd_qlfr', 'origin_cd', 'rx_pad_barcode', 'rx_pad_prgm_ind', 'rx_vacc_mfg_lot_nbr', 'rx_vacc_exp_dttm', 'rx_vacc_area_of_admin', 'rx_vacc_consent_ind', 'rx_vacc_pnl_ent_dttm', 'rx_vacc_pnl_status_cd', 'rx_90day_ind', 'rx_90day_dttm', 'rx_90day_stat_cd', 'rx_90day_stat_dttm', 'pbr_dea_nbr', 'pbr_dea_suffix', 'buyout_rx_cd', 'diagnosis_cd_5', 'diagnosis_cd_qlfr_2', 'diagnosis_cd_qlfr_3', 'diagnosis_cd_qlfr_4', 'diagnosis_cd_qlfr_5', 'trmt_type_cd', 'last_fill_sold_dt', 'last_fill_sold_tm', 'erx_pat_automatch_ind', 'rx_90day_switch_ind', 'cdc_txn_commit_dttm']

delta_file_location = '/mnt/test/delta/ic_prescription-full'

surrogateKeys = ['dna_rx_sk']

table_name = 'ic_prescription'

# COMMAND ----------

import pyspark.sql.functions as F

def historic_type_one(df, surrogateKeys):
  
  if (df.where(F.col("dna_batch_id").isNull()).count()) == 0:
    order_by_str = "dna_batch_id desc, dna_update_dttm"
  else:
    order_by_str = "dna_update_dttm"   
    
  df.createOrReplaceTempView("df_view")
  df=spark.sql("SELECT distinct RANK() OVER (partition by {0} ORDER BY {1} desc) AS rank,* from df_view ".format(",".join(surrogateKeys),order_by_str))
  result_df=df.filter("rank=1" )
  return result_df

# COMMAND ----------

def records_with_D(df):
  df_new = df.filter("dna_cdc_cd != 'D'")
  return df_new

# COMMAND ----------

from pyspark.sql import functions as F
#creating a delta file from base data.

base_df = spark.read.parquet(base_path+"*/*")

lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)

#latest_date = save_batchDate(base_df)
file_names = []
for x in lst1:
  if "bkp" not in str(x.name):
    file_names.append(x.name)

print("latest_batch file :" + file_names[0])
  
delta_df = historic_type_one(base_df, surrogateKeys)

delta_df = delta_df.dropDuplicates(surrogateKeys)

delta_df = records_with_D(delta_df)

delta_df = delta_df.select(outputColList)

#delta_df.write.parquet("save parquet files location")

delta_df.write.format("delta").save(delta_file_location)
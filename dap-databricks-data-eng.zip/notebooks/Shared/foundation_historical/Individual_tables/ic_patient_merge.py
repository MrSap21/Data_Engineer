# Databricks notebook source
from pyspark.sql.functions import trim
import pyspark.sql.functions as F
from pyspark.sql.types import StructField
from pyspark.sql.types import *
from datetime import datetime
from datetime import date
from datetime import timedelta

# COMMAND ----------


targetLoc = "/mnt/staging/phase1/patient_merge/"
#dbutils.fs.rm(targetLoc, True)
badrecordLoc = "/mnt/wrangled/customer/ic_patient_merge/history/badrecords/"

#dbutils.fs.rm(badrecordLoc, True)
historicalDeltaLoc = "/mnt/curated/customer/ic_patient_merge/delta/"
loadReadyLoc = "/mnt/curated/customer/ic_patient_merge/load-ready/"

base_path = "/mnt/pharmacy/ARCH/OUT/customer/ic_patient_merge/load-ready/"

path_list = []

#path_list.append("/mnt/pharmacy/ARCH/OUT/customer/ic_patient_merge/load-ready/200*/*")
#path_list.append("/mnt/pharmacy/ARCH/OUT/customer/ic_patient_merge/load-ready/201*/*")
#path_list.append("/mnt/pharmacy/ARCH/OUT/customer/ic_patient_merge/load-ready/2020*/*")

## There no data after 7//12, we are loading data up 7/9 so as test incremental feed.

# COMMAND ----------

##This is final
def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_name = rw['table_name']
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
    batchIdList = []
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    #stage_path = ""
    #load_ready_path = ""
    in_path_list = []
    stage_path = stage_path + current_batch_id + "/"
    load_ready_path = load_ready_path + current_batch_id + "/"
    year = datetime.now().year
    if current_batch_id[0:4] > str( year + 1):
       lst3 = list(filter(lambda fld : fld[0:4] <= str(year + 1), batchIdList))
       lst1 = sorted(lst3, reverse=True)
       current_batch_id = lst1[0]
    stage_path = stage_path + current_batch_id + "/"
    load_ready_path = load_ready_path + current_batch_id + "/"     
    return (table_name,table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql)
    

# COMMAND ----------


def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    #df1.display(5)
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
   # df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_set(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------


def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele

# COMMAND ----------

def fixType2DataWithDelete(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'], x['dna_update_dttm'])))
  for rw in rowList:
      ky = createKey(rw)
      mp[ky] = rw
       
  for k in kst:
        rw = rowList[k]
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           delList.append(createKey(rw))
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
           if (rw2 is None):
              ky = createKey(rw)
              if ky not in lst:
                 lst.append(ky)
           else:
              if (((type(rw['dna_end_dttm']) is datetime) and rw['dna_end_dttm'].year == 9999)  or  ((type(rw['dna_end_dttm']) is str ) and rw['dna_end_dttm'].startswith('9999'))):
                 continue
              else:
                 lst.append(createKey(rw))
  lset = set(lst)
  lst = list(lset)
  lst = sorted(lst)
  print(lst)
  dct1 = {}
  for f in lst:
      f1 = f.split("----")
      arr = []
      if f1[0] in dct1:
         arr = dct1[f1[0]]
      arr.append(f)
      dct1[f1[0]] = arr
  lst2 = []
  for ky in dct1.keys():
      if len(dct1[ky]) == 1:
         lst2.append(dct1[ky][0])
      if len(dct1[ky]) > 1:
         arr = dct1[ky]
         arr1 = list(sorted(arr, key = lambda x : x, reverse = True))
         lst2.append(arr1[0])
          
  for f in lst2:
        f1 = f.split("----")
        if len(delList) == 0:
           retList.append(mp[f])
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if d1[0] == f1[0]:
                  drw = mp[dl]
                  rw = mp[f]
                  if drw['dna_update_dttm'] >= rw['dna_update_dttm']:
                     match = True
                     break
           if match == False:
              retList.append(mp[f])
  print (rowListin)
  return retList

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

def trimStringFields(df):
    df1 = df
    for fld in df.schema.fields:
        if str(fld.dataType) == 'StringType':
           df1 = df1.withColumn(fld.name, F.trim(df1[fld.name]))
    return df1

# COMMAND ----------

def readAndConvertDataType(base_path,outputColList, fldList ):
   
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    base_df = spark.read.parquet( lst1[0].path + "*/*" ).select(outputColList)
    base_df = base_df.filter("1 = 2")
    base_df.count()
    
    
    #lst2 = list(filter(lambda rw: '20201220' in rw.name,lst1 ))
    #lst3 = [rw.path + "*/*" for rw in lst2]
    #base_df = spark.read.parquet( *lst3 ).select(outputColList)
    
   
    yearList = ['2001', '2002','2003', '2004','2005','2006' , '2007','2008', '2009', '2010', '2011' ,'2012','2013','2014','2015', '2016', '2017', '2018', '2019', '202001','202002', '202003','202004','202005','202006','202007','202008','202009', '202010' ,              '202011','20201206','20201213','20201220','2021']
    #yearList = ['2001']
    
    for ln in yearList:
        #lst21 = list(filter(lambda rw: ln in rw.name,lst1 ))
        print (ln)
        lst21 = ""
        lst21 = list(filter(lambda rw: rw.name.startswith(str(ln) ) ,lst1 ))
        #if (ln == '202101' or ln == '202102' or ln == '202103' or ln == '202104' or ln == '202105' or ln == '202106' or ln == '202107' or ln == '202108' or ln == '20201220') :
        if ln == '2021' or ln == '20201220':
          lst3 = [rw.path + "*/*" for rw in lst21]
        else:
          lst3 = [rw.path + "*" for rw in lst21]
          
        
        for ls31 in lst3:
          #print (ls31)
          dfx = spark.read.parquet(ls31)
          dfx = fixDataType(dfx, outputColList, fldList)
          base_df = base_df.union(dfx)
    return base_df

# COMMAND ----------

def getMaxbatchId(base_path):
    maxBatchId = '0'
    lst1 = sorted(dbutils.fs.ls(base_path),reverse=True)
    maxBatchId = lst1[0].name.replace("/","")
    return  maxBatchId

# COMMAND ----------

def getLatestSchema(base_path,maxbatchId, outputColList):
    lc = base_path + str(maxbatchId) + "/*/*"
    df = spark.read.parquet(lc)
    #df1 = df.select(outputColList)
    fldList = {}
    fields = df.schema.fields
    for fld in fields:
        fldList[fld.name] = fld
    return fldList

# COMMAND ----------

def historyLoadType2(patDf,table_name, suggrogateKeys,outputColList):
    schema = patDf.schema
    list_column = table_name + "_list"
    df4 = groupBySurrgoteKey(patDf,table_name, suggrogateKeys)
    #print ('df4--'+str(df4.count()))
    rd1 = df4.rdd.map(lambda rw:fixType2DataWithDelete(rw[list_column])).flatMap(lambda x:x)
    #print (rd1.collect())
    print (schema)
    df5 = spark.createDataFrame(rd1, schema)
    #print ('df5--'+str(df5.count()))
    df6 = df5.select(outputColList)
    return df6
#lc = "/mnt/pharmacy/ARCH/OUT/customer/ic_patient/load-ready/2*/ic_*/*"

# COMMAND ----------

def fixDataType(df, outputColList, fldList):
    df1 = df
    colSet = set(df1.columns)
    outSet = set(outputColList)
    diffSet = outSet - colSet
    print("different dataset")
    print(diffSet)
    baseList = df1.schema.fields
    for cle in diffSet:
        #print(cle)
        df1 = df1.withColumn(cle,  F.lit(None).cast(fldList[cle].dataType))
    for cle in baseList:
        if cle.name in fldList:
           df1 = df1.withColumn(cle.name,  df1[cle.name].cast(fldList[cle.name].dataType))
    return df1.select(outputColList)

# COMMAND ----------


(table_name,table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql) = getParameters('ic_patient_merge')
print(dedup_column)

# COMMAND ----------

maxBatchId = getMaxbatchId(base_path)
print (maxBatchId)

# COMMAND ----------


fldList = getLatestSchema(base_path,maxBatchId, outputColList)


# COMMAND ----------

base_path

# COMMAND ----------

df = readAndConvertDataType(base_path,outputColList, fldList )

# COMMAND ----------

patDf=df.select(outputColList)

# COMMAND ----------



#table_name = 'patient'

#for prefix in list(range(1,4)):
#    print("running:" + str(prefix))
 #   patDf1 = patDf.filter("dna_merged_fm_pat_sk like '{0}%'".format(prefix))
df6 = historyLoadType2(patDf,table_name, surrogateKeys,outputColList)
df6 = convertToTimestampToString(df6)
df6 = trimStringFields(df6)



df6.createOrReplaceTempView("df_view")

df6.persist()

dfclean = spark.sql ("select * from df_view " + clean_sql)
dfbad = spark.sql("select * from df_view " + bad_sql)


### patient sample loaded in here, just for testing
dbutils.fs.rm(targetLoc ,True)
dbutils.fs.rm(badrecordLoc ,True)

dfclean.write.mode('overwrite').parquet(targetLoc)
dfbad.write.mode('overwrite').parquet(badrecordLoc)



    #df7 = spark.read.parquet("/mnt/landing/common/foundation_testing/patient/out1")
#df7.show()



# COMMAND ----------

#adf=dfclean.filter("dna_merged_fm_pat_sk = 4658840")
#adf.display()
#dfclean.printSchema()
#dfclean.count()
#dfclean.write.mode("overwrite").parquet(targetLoc)


# COMMAND ----------

#dfbad.count()
#dfbad.write.mode("overwrite").parquet(badrecordLoc)

# COMMAND ----------

#df7_bad = spark.read.parquet("/mnt/wrangled/customer/ic_patient_merge/history/badrecords/")
#df7_bad.count()
#df7.createOrReplaceTempView("patient_merge_bad_view")

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC --select count(1) from patient_merge_view--11941672 -41267197

# COMMAND ----------

# MAGIC %sql
# MAGIC --select  dna_merged_fm_pat_sk,dna_eff_dttm,merged_fm_pat_id,* from patient_merge_bad_view
# MAGIC --where --merged_fm_pat_id =1139096917
# MAGIC -- merged_fm_pat_id = '300079868' and dna_merged_fm_pat_sk = 4658840 and dna_stat_cd='C'

# COMMAND ----------

#df7 = spark.read.parquet("/mnt/staging/phase1/patient_merge/")
#df7.createOrReplaceTempView("patient_merge_view")

# COMMAND ----------

# MAGIC %sql
# MAGIC --select  dna_merged_fm_pat_sk,dna_eff_dttm,merged_fm_pat_id from patient_merge_view
# MAGIC --where DNA_MERGED_FM_PAT_SK is null

# COMMAND ----------

# MAGIC %sql
# MAGIC --select  dna_merged_fm_pat_sk,dna_eff_dttm,merged_fm_pat_id,* from patient_merge_view
# MAGIC --where merged_fm_pat_id =1139096917

# COMMAND ----------

# MAGIC %sql
# MAGIC --select  dna_merged_fm_pat_sk,dna_eff_dttm,merged_fm_pat_id from patient_merge_view
# MAGIC --where dna_merged_fm_pat_sk=453747054 and ;
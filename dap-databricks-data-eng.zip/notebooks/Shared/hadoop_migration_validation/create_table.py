# Databricks notebook source
#create table commands
create_validationstatus_table="DROP TABLE IF EXISTS dbo.idh_validationstatus_@migration_id; CREATE TABLE dbo.idh_validationstatus_@migration_id(database_name varchar(256),source varchar(500),destination varchar(1000),migration_step varchar(128),validation_type varchar(128),validation_status varchar(128),result_details varchar(500),source_row_count bigint,destination_row_count bigint,migration_id varchar(128),validation_execution_time varchar(50));"

create_rowcount_table="DROP TABLE IF EXISTS dbo.idh_rowcount_@migration_id; CREATE TABLE dbo.idh_rowcount_@migration_id(database_name varchar(256),table_name varchar(256),row_count bigint,filter_clause varchar(1000));"

create_minmaxavg_table="DROP TABLE IF EXISTS dbo.idh_minmaxavg_@migration_id; CREATE TABLE dbo.idh_minmaxavg_@migration_id(database_name varchar(256),table_name varchar(256), column_name varchar(256),avg numeric(12,2), min numeric(12,2), max numeric(12,2));"

#input file paths
minmaxavg_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_minmaxavg_'+migration_id
rowcount_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_rowcount_'+migration_id
validationstatus_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_validationstatus_'+migration_id

#insert commands
minmax_insert = "INSERT INTO idh_minmaxavg_@migration_id (database_name,table_name,column_name,avg,min,max) values(?,?,?,?,?,?)"
rowcount_insert = "INSERT INTO idh_rowcount_@migration_id (database_name,table_name,row_count,filter_clause) values(?,?,?,?)"
validationstatus_insert = "INSERT INTO idh_validationstatus_@migration_id (database_name,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time) values(?,?,?,?,?,?,?,?,?,?,?)"


# COMMAND ----------

#create tables for the migration ID
create_table(create_validationstatus_table.replace("@migration_id",migration_id))
create_table(create_rowcount_table.replace("@migration_id",migration_id))
create_table(create_minmaxavg_table.replace("@migration_id",migration_id))

# COMMAND ----------

def insert_records(file_path,insert_command):
  #read input file
  df_file = spark.read.parquet(file_path)
  
  #convert dataframe to list
  dflist =  df_file.collect()
  
  column_list = []
  i = 0

  #generate column list in the format "item[0],item[1],.."
  while i < len(df_file.columns):
    column_list.append("item["+str(i)+"]")
    i += 1
    
  column_string = ','.join(column_list)

  #iterate through the dataframe list and insert records into the table
  for item in dflist:
    upsert_data(insert_command.replace("@migration_id",migration_id), eval(column_string))
  

# COMMAND ----------

#insert records
insert_records(rowcount_path,rowcount_insert)
insert_records(validationstatus_path,validationstatus_insert)
insert_records(minmaxavg_path,minmax_insert)
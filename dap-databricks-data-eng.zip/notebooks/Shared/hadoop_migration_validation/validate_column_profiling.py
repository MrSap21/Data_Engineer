# Databricks notebook source
import pandas as pd
import datetime
import time

with open (mapping_file, 'rt') as myfile:
  
  for myline in myfile: 
    
    #get ADLS path of landed parquet file from on-prem mapping file
    adls_path = myline.split(',')[1]
    
    #get IDH DB and Table Name from on-prem mapping file    
    path_len = len(adls_path.split('/'))   
    table_name = adls_path.split('/')[path_len - 3]      
    sub_domain_name = adls_path.split('/')[path_len - 4]   
    domain_name = adls_path.split('/')[path_len - 5] 
    
    #check if sub-domain is empty
    if sub_domain_name:
      delta_table = domain_name+"__"+sub_domain_name+"."+table_name
      db_name = domain_name+"__"+sub_domain_name
    else:    
      delta_table = domain_name+"."+table_name   
      db_name = domain_name
    
    print("table: "+table_name) 
    
    #get delta table name from idh-delta map file
    #df_delta_map = spark.read.parquet(idh_delta_map_path)                                 
    
    #df_delta_map_filtered = df_delta_map.filter((df_delta_map.idh_database==db_name.lower()) & (df_delta_map.idh_table==table_name.lower()))
    #df_delta_map_list = df_delta_map_filtered.select("domain","sub_domain","idh_table").drop_duplicates().collect()
    #delta_table=df_delta_map_list[0][0]+"__"+df_delta_map_list[0][1]+"."+df_delta_map_list[0][2]
    
    print(delta_table)
       
    minmaxavg_data_columnslist = ['database_name','table_name','column_name','idh_avg','idh_min','idh_max','delta_database','delta_tablename','delta_avg','delta_min','delta_max','status']
        
    #on-prem min max avg
    minmaxavg_data_df = spark.read.parquet(minmaxavg_path).toPandas()      
    print(minmaxavg_data_df)
 
    column_profiling = pd.DataFrame(columns = minmaxavg_data_columnslist)
      
    for index_2, row_2 in minmaxavg_data_df.iterrows():        
       
        column_data_query = "select avg(cast("+row_2['column_name']+" AS BIGINT)) as delta_avg,min("+row_2['column_name']+") as delta_min,max("+row_2['column_name']+") as delta_max from "+delta_table+where_clause        
        
        print(column_data_query)
        
        #delta min max avg
        column_data_query_df = spark.sql(column_data_query).toPandas()        

        #compare values from IDH and Delta column profiling
        idh_avg = float(row_2['avg']) if row_2['avg'] is not None else None
        idh_min = float(row_2['min']) if row_2['min'] is not None else None
        idh_max = float(row_2['max']) if row_2['max'] is not None else None
        print(idh_avg)
        delta_avg = None if column_data_query_df['delta_avg'].isnull().values.any() else round(float(column_data_query_df['delta_avg']),2)
        print(delta_avg)
        delta_min = None if column_data_query_df['delta_min'].isnull().values.any() else round(float(column_data_query_df['delta_min']),2)
        delta_max = None if column_data_query_df['delta_max'].isnull().values.any() else round(float(column_data_query_df['delta_max']),2)
        
        if idh_avg == delta_avg and idh_min == delta_min and idh_max == delta_max:        
          status = 'Success'
        else:
          status = 'Failure'
        
        data1 = [{'database_name':row_2['database_name'],'table_name':row_2['table_name'],'column_name':row_2['column_name'],'idh_avg':idh_avg,'idh_min':row_2['min'],'idh_max':row_2['max'],'delta_database':db_name,'delta_tablename':delta_table, 'delta_avg':delta_avg,'delta_min':delta_min,'delta_max':delta_max,'status':status}]
        
        column_profiling = column_profiling.append(data1, ignore_index = True)
        
    if 'Failure' in column_profiling['status']:
        validation_status = 'Failure'
    else:
        validation_status = 'Success'
    
    #output column profiling comparison to ADLS
    idh_file_path = '/dbfs/mnt/wrangled/common/idh_tframework/tf_columnprofilingfiles/idh_vs_delta_'+migration_id+'.csv'
    column_profiling.to_csv(idh_file_path,index=False)
    
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    
    #validationstatus table columns
    column_list = "database_name,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time"
    
    #query to insert into validationstatus table
    queryToInsert = "INSERT INTO dbo.idh_validationstatus_"+migration_id+"(" + column_list + ") VALUES (?,?,?,?,?,?,?,?,?,?,?)"

    #validationstatus table insert for column profiling
    valuesToInsert = "db_name,table_name,delta_table,'LoadDeltaTable','IDHVsDeltaColumnProfiling',validation_status,idh_file_path,None,None,migration_id,current_time"

    upsert_data(queryToInsert,eval(valuesToInsert))    
    
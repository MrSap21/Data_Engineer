# Databricks notebook source
# Common notebook for mounting ADLS

# mounting point

mountPoint = "/mnt/wrangled"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapadbscope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapadbscope",key="dapdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapadbscope",key="adtenantid")
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = dbutils.secrets.get(scope="dapadbscope",key="dapadlswrngurl"),
    mount_point = mountPoint,
    extra_configs = configs)  
  

# COMMAND ----------

#get migration ID
migration_id = dbutils.widgets.get("migrationid").strip()

#validation files location
minmaxavg_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_minmaxavg_'+migration_id
rowcount_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_rowcount_'+migration_id
validationstatus_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_validationstatus_'+migration_id

#delete existing files if any
dbutils.fs.rm(minmaxavg_path,True)
dbutils.fs.rm(rowcount_path,True)
dbutils.fs.rm(validationstatus_path,True)
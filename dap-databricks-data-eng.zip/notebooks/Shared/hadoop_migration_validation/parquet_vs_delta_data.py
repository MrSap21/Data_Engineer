# Databricks notebook source
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit, upper, col

#extract where clause from validationstatus table
validationstatus_df = spark.read.parquet(validationstatus_path)
validation_where_clause = validationstatus_df.filter("validation_type='LandingVsEncryptedDataComparison'").select("result_details").collect()[0][0]

#validationstatus table columns
column_list = "database_name,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time"
    
#query to insert into validationstatus table
queryToInsert = "INSERT INTO dbo.idh_validationstatus_"+migration_id+"(" + column_list + ") VALUES (?,?,?,?,?,?,?,?,?,?,?)"

#open mapping file
with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    
    #get ADLS path of landed parquet file from on-prem mapping file
    adls_path = myline.split(',')[1]
    
    #get IDH DB and Table Name from on-prem mapping file    
    path_len = len(adls_path.split('/'))   
    table_name = adls_path.split('/')[path_len - 3]      
    sub_domain_name = adls_path.split('/')[path_len - 4]   
    domain_name = adls_path.split('/')[path_len - 5] 
    
    #check if sub-domain is empty
    if sub_domain_name:
      delta_table = domain_name+"__"+sub_domain_name+"."+table_name
      db_name = domain_name+"__"+sub_domain_name
    else:    
      delta_table = domain_name+"."+table_name   
      db_name = domain_name
    
    print("table: "+table_name)
    
    #add mounted container path to parquet file path
    parent_folder = "/mnt/wrangled"+adls_path.strip()
      
    #check if validation where clause is empty
    if validation_where_clause == 'ValidationWhereClauseIsEmpty':  
      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
      #status table insert for ParquetVsDeltaRowCount
      valuesToInsert = "db_name,parent_folder.strip(),delta_table,'LoadDeltaTable','ParquetVsDeltaDataComparison','Unverified','ValidationWhereClauseIsEmpty',None,None,migration_id,current_time"
      upsert_data(queryToInsert,eval(valuesToInsert)) 
    
    else:  
      #generate combined where clause for comparison
      if not where_clause:
          filter_where_clause=" where "+validation_where_clause
      else:
          filter_where_clause=where_clause+" and "+validation_where_clause

      print(filter_where_clause) 
      
      #read parquet file to data frame
      df_file = spark.read.parquet(parent_folder) 
      df_file.show(1)    
       
      #read delta table to data frame
      df_table = spark.sql("select * from {} {}".format(delta_table,filter_where_clause))
      df_table.show(1)    

      #apply validation where clause on parquet file dataframe
      df_file.createOrReplaceTempView("parquet_file_view")
      df_file_filtered=spark.sql("select * from parquet_file_view {}".format(filter_where_clause))
    
      ################################## Parquet file vs Delta table data comparison ####################################  

      df_delta_vs_file = df_table.subtract(df_file_filtered)    
      df_file_vs_delta = df_file_filtered.subtract(df_table)  

      validation_status = "Failure"

      #set validation status after comparing file and table row counts
      if df_delta_vs_file.count() == 0 and df_file_vs_delta.count() == 0:
        validation_status = "Success"   

      current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    
    #validationstatus table columns
    #column_list = "database_name,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time"
    
    #query to insert into validationstatus table
    #queryToInsert = "INSERT INTO dbo.idh_validationstatus_"+migration_id+"(" + column_list + ") VALUES (?,?,?,?,?,?,?,?,?,?,?)"

    #status table insert for ParquetVsDeltaRowCount
      valuesToInsert = "db_name,parent_folder.strip(),delta_table,'LoadDeltaTable','ParquetVsDeltaDataComparison',validation_status,'',None,None,migration_id,current_time"

      upsert_data(queryToInsert,eval(valuesToInsert))    
    
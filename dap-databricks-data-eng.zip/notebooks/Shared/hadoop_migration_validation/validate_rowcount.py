# Databricks notebook source
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import lit, upper, col

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    
    #get ADLS path of landed parquet file from on-prem mapping file
    adls_path = myline.split(',')[1]
    
    #get IDH DB and Table Name from on-prem mapping file    
    path_len = len(adls_path.split('/'))   
    table_name = adls_path.split('/')[path_len - 3]      
    sub_domain_name = adls_path.split('/')[path_len - 4]   
    domain_name = adls_path.split('/')[path_len - 5] 
    
    #check if sub-domain is empty
    if sub_domain_name:
      delta_table = domain_name+"__"+sub_domain_name+"."+table_name
      db_name = domain_name+"__"+sub_domain_name
    else:    
      delta_table = domain_name+"."+table_name  
      db_name = domain_name
    
    print("table: "+table_name)
    print("db: "+db_name)    
       
    #generate ADLS parquet file path
    parent_folder = "/mnt/wrangled"+adls_path.strip()
    df_file = spark.read.parquet(parent_folder)  
    
    #get parquet file row count
    file_row_count = df_file.count()    
       
    #get delta table row count
    df_table = spark.sql("select count(*) from {} {}".format(delta_table,where_clause))
    df_table.show()
    table_row_count = df_table.collect()[0][0]

    ################################## Parquet file vs Delta table count comparison ####################################    
    validation_status = "Failure"
    
    #set validation status after comparing file and table row counts
    if table_row_count == file_row_count:
      validation_status = "Success"   

    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    
    #validationstatus table columns
    column_list = "database_name,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time"
    
    #query to insert into validationstatus table
    queryToInsert = "INSERT INTO dbo.idh_validationstatus_"+migration_id+"(" + column_list + ") VALUES (?,?,?,?,?,?,?,?,?,?,?)"

    #status table insert for ParquetVsDeltaRowCount
    valuesToInsert = "db_name,parent_folder.strip(),delta_table,'LoadDeltaTable','ParquetVsDeltaRowCount',validation_status,'',file_row_count,table_row_count,migration_id,current_time"

    upsert_data(queryToInsert,eval(valuesToInsert))
    
    ################################# IDH table vs Delta table count comparison ##########################################
    rowcount_df_filtered = rowcount_df.filter("table_name like 'lidh%'")
    idh_table_row_count = rowcount_df_filtered.select("row_count").drop_duplicates().collect()[0][0]
    print(idh_table_row_count)    
    validation_status = "Failure"
    
    #set validation status after comparing idh and delta table row counts
    if table_row_count == idh_table_row_count:
      validation_status = "Success"  
    
    #status table insert for IDHVsDeltaRowCount
    valuesToInsert = "db_name,table_name,delta_table,'LoadDeltaTable','IDHVsDeltaRowCount',validation_status,'',file_row_count,table_row_count,migration_id,current_time"

    upsert_data(queryToInsert,eval(valuesToInsert))
# Databricks notebook source
# Common notebook for mounting ADLS

# mounting point

mountPoint = "/mnt/wrangled"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapadbscope",key="applicationId")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapadbscope",key="dapdnaadls")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapadbscope",key="adtenantid")
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = dbutils.secrets.get(scope="dapadbscope",key="dapadlswrngurl"),
    mount_point = mountPoint,
    extra_configs = configs)  
  

# COMMAND ----------

#pre-requisite: Landing folder of files from on-prem must be mounted before executing the runbook.

#from proOrcFramUtilities.dbConnect import *
#migration_id='uatidhrun01feb162022220216040635'
#environment = 'uat'

migration_id = dbutils.widgets.get("migration_id").strip()
environment = dbutils.widgets.get("env")

print(migration_id)

#environment variable value change to align with database names
if environment.lower() == 'pro':  
  environment='prod'
elif environment.lower() == 'tes':
  environment='test'


#location of manifest file to be generated in ADLS
adls_manifest='/dbfs/mnt/wrangled/common/idh_tframework/tf_checksumadlsfiles/idh_checksum_'+migration_id+'.txt'

#location of mapping file from migration run
mapping_file='/dbfs/mnt/wrangled/common/idh_historical_data_migration/hdfs_adls_mapping/move'+migration_id+'.csv'

#location of manifest file copied from on-prem
onprem_manifest='/dbfs/mnt/wrangled/common/idh_tframework/tf_checksumonpremfiles/idh_checksum_'+migration_id+'/checksum.csv'

#validation table file location
minmaxavg_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_minmaxavg_'+migration_id
rowcount_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_rowcount_'+migration_id
validationstatus_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_validationstatus_'+migration_id
idh_delta_map_path= '/mnt/wrangled/common/idh_tframework/tf_validationtables/idh_table_domain_map_'+migration_id

#create folders in ADLS
dbutils.fs.mkdirs("/mnt/wrangled/common/idh_tframework/tf_checksumadlsfiles")
dbutils.fs.mkdirs("/mnt/wrangled/common/idh_tframework/tf_columnprofilingfiles")

sql_server_name = "dap"+environment+"sqlsrv01.database.windows.net"
db_name = "dap"+environment+"sqldb01"
sql_client_secret_key = environment+"dnasqldb"

#Initialing database configurations
dbConfig = {"keyVaultScope" : "dapadbscope",
"keyVaultSecret_tenantIDKey" : "adtenantid",
"keyVaultSecret_sqlClientIDKey" : "sqldbapplicationid",
"keyVaultSecret_sqlClientSecretKey" : sql_client_secret_key,
"sqlServerName" : sql_server_name,
"dbName" : db_name}

#function to create table
def create_table(queryToCreateDDL):
  with dbConnect(dbConfig,spark) as connectionObject:
    con = connectionObject.sqlConn()
    con.execute(queryToCreateDDL)
    con.commit()

#function to insert data into table
def upsert_data(queryToInsert,valuesToInsert):
  with dbConnect(dbConfig,spark) as connectionObject:
    con = connectionObject.sqlConn()
    con.execute(queryToInsert,valuesToInsert)
    con.commit()
    
#read rowcount file from on-prem  
rowcount_df = spark.read.parquet(rowcount_path)

#retrieve filter clause from rowcount file
filter_clause = rowcount_df.select("filter_clause").collect()[0][0]

#generate where clause for comparison
where_clause=""

if filter_clause:
    where_clause=" where "+filter_clause

# COMMAND ----------

# MAGIC %run ./db_connect

# COMMAND ----------

# MAGIC %run ./create_table

# COMMAND ----------

# MAGIC %run ./validate_checksum

# COMMAND ----------

# MAGIC %run ./validate_rowcount

# COMMAND ----------

# MAGIC %run ./parquet_vs_delta_data

# COMMAND ----------

# MAGIC %run ./validate_column_profiling
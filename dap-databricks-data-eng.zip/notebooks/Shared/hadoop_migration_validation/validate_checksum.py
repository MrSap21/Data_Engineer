# Databricks notebook source
#generate ADLS checksum
from datetime import datetime,timedelta 
import hashlib
from pyspark.sql.types import *
from pyspark.sql import functions as f

output_file = open(adls_manifest, "w")

with open (mapping_file, 'rt') as myfile:
  for myline in myfile: 
    adls_path = myline.split(',')[1]
    parent_folder = "/mnt/wrangled"+adls_path.strip()    
    file_list = dbutils.fs.ls(parent_folder)
       
    for file in file_list:
        file_name = '/'+file[0].replace(':','')        
        md5value = hashlib.md5(open(file_name,'rb').read()).hexdigest()        
        value = md5value+" "+file_name+"\n"      
        output_file.write(value)  
      
output_file.close()

# COMMAND ----------

#validate checksum
from datetime import datetime
from pyspark.sql import Row
import adal
import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.functions import to_timestamp

#schema for dataframes
onprem_schema = StructType([
             StructField('onprem_filename', StringType()),
             StructField('onprem_md5value', StringType())            
            ])
adls_schema = StructType([
              StructField('adls_filename', StringType()),
              StructField('adls_md5value', StringType())
            ])

onprem_df = spark.read.csv(onprem_manifest.replace('/dbfs',''),inferSchema=True,header=False,sep=' ',ignoreLeadingWhiteSpace=True)
adls_df = spark.read.csv(adls_manifest.replace('/dbfs',''),inferSchema=True,header=False,sep=' ',ignoreLeadingWhiteSpace=True)

print(onprem_manifest)
print(adls_manifest)

#extract filename from file path
def slice_string(input): 
  print(input)
  path_array = input._c1.split("/")
  length=len(path_array)  
  file_name = path_array[length-1]
  return Row(file_name,input._c0) 
   
#extract filename from file path for each record  
adls_rdd = adls_df.rdd.map(slice_string)
onprem_rdd = onprem_df.rdd.map(slice_string)

#generate dataframe from modified rdds
adls_df1 = spark.createDataFrame(adls_rdd, adls_schema)
onprem_df1 = spark.createDataFrame(onprem_rdd, onprem_schema)

#join the dataframes to validate checksum value
df_join = onprem_df1.join(adls_df1, adls_df1.adls_filename == onprem_df1.onprem_filename, how='inner')

#register temp table to run sql queries
df_join.registerTempTable("temp")
pass_df = spark.sql("select adls_filename as filename, adls_md5value, onprem_md5value, 'Success' as validation_status from temp where adls_md5value == onprem_md5value")
fail_df = spark.sql("select adls_filename as filename, adls_md5value, onprem_md5value, 'Failure' as validation_status from temp where adls_md5value != onprem_md5value")
output_df=pass_df.union(fail_df)

output_list = output_df.collect()

for item in output_list:
  current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    
  column_list = "database_name,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time"
  queryToInsert = "INSERT INTO dbo.idh_validationstatus_"+migration_id+"(" + column_list + ") VALUES (?,?,?,?,?,?,?,?,?,?,?)"

  valuesToInsert = "'',item[0],item[0],'CopyFilesToAdls','Checksum',item[3],'',None,None,migration_id,current_time"

  upsert_data(queryToInsert,eval(valuesToInsert))
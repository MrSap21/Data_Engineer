# Databricks notebook source
import struct
import pyodbc
from adal import AuthenticationContext

#creating a class to get a sql connection  from the database
class dbConnect:
    def __init__(self, dbConfig ,spark):
        self._dbConfig = dbConfig
        self._spark = spark
        self._conn = None

    def sqlConn(self):
        if self._conn is None:
            #getting the required credentials from the scope
            TenantId = dbutils.secrets.get(scope=self._dbConfig["keyVaultScope"],key=self._dbConfig["keyVaultSecret_tenantIDKey"])
            authority = "https://login.windows.net/" + TenantId
            resourceAppIdURI = "https://database.windows.net/"
            servicePrincipalId = dbutils.secrets.get(scope=self._dbConfig["keyVaultScope"],key=self._dbConfig["keyVaultSecret_sqlClientIDKey"])
            client_secret = dbutils.secrets.get(scope=self._dbConfig["keyVaultScope"],key=self._dbConfig["keyVaultSecret_sqlClientSecretKey"])
            server = self._dbConfig["sqlServerName"]
            database = self._dbConfig["dbName"]

            context = AuthenticationContext(authority)
            newtoken = context.acquire_token_with_client_credentials(resourceAppIdURI, servicePrincipalId,
                                                                     client_secret)
            properties = {"accessToken": newtoken.get('accessToken'), "hostNameInCertificate": "*.database.windows.net",
                          "encrypt": "true"}

            databaseToken = properties.get('accessToken')
            tokenb = bytes(databaseToken, "UTF-8")

            exptoken = b''
            for i in tokenb:
                exptoken += bytes({i})
                exptoken += bytes(1)
            tokenstruct = struct.pack("=i", len(exptoken)) + exptoken
            
            #creating a connection string to connect with SQL Server.
            connString = "Driver={ODBC Driver 17 for SQL Server};SERVER=" + server + ";DATABASE=" + database + ""

            SQL_COPT_SS_ACCESS_TOKEN = 1256
            conn = pyodbc.connect(connString, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: tokenstruct})

            self._conn = conn.cursor()

        return self._conn

    def __enter__(self):
        return self
    # defining the exit function so that the connection get closed automatically.
    def __exit__(self, type, value, traceback):
        if self._conn is not None:
            self._conn.close()
            self._conn = None
# Databricks notebook source
#%run ./inputConfig
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_pos_curated'
table_name='pos_transaction'
phase1_file_location='/mnt/pos/ARCH/OUT/idl/pos_transaction/load-ready/*/*'
phase2_delta_location='/mnt/landing/foundation_testing/pos_trans/delta'
#output config
phase1_vs_phase2_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
phase2_vs_phase1_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
phase1_vs_phase2_output_file_name = '/phase1file_vs_phase2delta_keys.csv'
phase2_vs_phase1_output_file_name = '/phase2delta_vs_phase1file_keys.csv'
surrogate_key=['sales_txn_id']

# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------

#create folder path
dbutils.fs.mkdirs(phase1_vs_phase2_output_folder_path)
dbutils.fs.mkdirs(phase2_vs_phase1_output_folder_path)
#load dataframe
df_phase1_file = spark.read.parquet(phase1_file_location)
df_phase2_file = spark.read.format("delta").load(phase2_delta_location)

# COMMAND ----------

#validation
phase1_sk_list=df_phase1_file.select(surrogate_key).distinct()
phase2_sk_list=df_phase2_file.select(surrogate_key).distinct()
print(phase1_sk_list.count())
#comparison
phase1_vs_phase2 = phase1_sk_list.subtract(phase2_sk_list)
phase2_vs_phase1 = phase2_sk_list.subtract(phase1_sk_list)

if phase1_vs_phase2.count() == 0:
  validation_status = 'Success'
else:
  validation_status = 'Failure'  
  #write to error file
  output_df1 = phase1_vs_phase2.limit(1000) 
  output_file_1 = phase1_vs_phase2_output_folder_path+'/'+phase1_vs_phase2_output_file_name  
  output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_1)
  result_detail = output_file_1
  
if phase2_vs_phase1.count() == 0:
  validation_status = 'Success'  
else:
  validation_status = 'Failure'  
  #write to error file  
  output_df2 = phase2_vs_phase1.limit(1000)
  output_file_2 = phase2_vs_phase1_output_folder_path+'/'+phase2_vs_phase1_output_file_name  
  #output_df2.toPandas().to_csv('/dbfs'+phase2_vs_phase1_output_folder_path+'/'+phase2_vs_phase1_output_file_name,index=False)
  output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_2)
  result_detail = output_file_2

if validation_status == 'Success':
  result_detail = ""
  
if phase1_vs_phase2.count() > 0 and phase2_vs_phase1.count() > 0:
  result_detail = output_file_1+','+output_file_2
  

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase1_file_location,phase2_delta_location,"Phase1FileVsPhase2DeltaKeyCount",validation_status,result_detail,None,None,phase1_sk_list.count(),phase2_sk_list.count(),current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
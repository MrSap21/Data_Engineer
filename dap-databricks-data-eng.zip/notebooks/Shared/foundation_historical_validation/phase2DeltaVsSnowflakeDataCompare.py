# Databricks notebook source
#%run ./inputConfig
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_pos_curated'
table_name='pos_transaction'
#phase1_file_location='/mnt/pos/ARCH/OUT/idl/pos_transaction/load-ready/*/*'
#dbutils.fs.ls(phase1_file_location)
phase2_delta_location='/mnt/landing/foundation_testing/pos_trans/delta'
#output config
delta_vs_snowflake_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
snowflake_vs_delta_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
delta_vs_snowflake_output_file_name = 'delta_vs_snowflake_data_compare.csv'
snowflake_vs_delta_output_file_name = 'snowflake_vs_delta_data_compare.csv'
where_clause = "sales_txn_id='102010135029128' and dna_stat_cd='C'"

# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------


#generating where clause for phase2 file
#where_phase2 ="rank=='1' and dna_stat_cd=='C'"
#sp2= where_phase2.split(' and ')
#sp_len2=len(sp2)
#whr4=''
#for j in sp2:
  
 # whr3 = '(df_phase2_file.'+j + ') '
 # whr4 = whr4 + ' & ' + whr3
#whr_ph_2 = whr4.replace('&','',1)
#print('Phase2 file where clause')
#print(whr_ph_2)

df_phase2_file = spark.read.format("delta").load(phase2_delta_location).drop('rank')
df_phase2_file.registerTempTable("df_phase2_table")
df_phase2_file_where_clause = spark.sql("select * from df_phase2_table where {}".format(where_clause))
#df_phase2_whr = df_phase2_file.filter(eval(whr_ph_2) ).drop('rank')
#col_ph2=df_phase2_whr.columns

#Snowflake query
query_to_get_data = "select * from "+db_name+"."+schema_name+"."+table_name + " where "+where_clause
df_table = spark.read.format("snowflake").options(**sfOptions).option("query",query_to_get_data).load()

delta_vs_table = df_phase2_file_where_clause.subtract(df_table)
table_vs_delta = df_table.subtract(df_phase2_file_where_clause)

if table_vs_delta.count() == 0:
  validation_status = 'Success'
else:
  validation_status = 'Failure'  
  #write to error file
  output_df1 = table_vs_delta.limit(1000) 
  output_file_1 = snowflake_vs_delta_output_folder_path+'/'+snowflake_vs_delta_output_file_name    
  output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_1)
  result_detail = output_file_1
  
if delta_vs_table.count() == 0:
  validation_status = 'Success'  
else:
  validation_status = 'Failure'  
  #write to error file  
  output_df2 = delta_vs_table.limit(1000)
  output_file_2 = delta_vs_snowflake_output_folder_path+'/'+delta_vs_snowflake_output_file_name
  output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_2)
  result_detail = output_file_2

if validation_status == 'Success':
  result_detail = ""
  
if table_vs_delta.count() > 0 and delta_vs_table.count() > 0:
  result_detail = output_file_1+','+output_file_2

 #write to error file
output_df1 = delta_vs_table.limit(1000)
output_df2 = table_vs_delta.limit(1000)

output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(delta_vs_snowflake_output_folder_path+'/'+delta_vs_snowflake_output_file_name)
output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(snowflake_vs_delta_output_folder_path+'/'+snowflake_vs_delta_output_file_name)
    

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase2_delta_location,schema_name+"."+table_name,"Phase2DeltaVsSnowflakeDataCompare",validation_status,where_clause+','+result_detail,None,None,None,None,current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
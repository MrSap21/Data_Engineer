# Databricks notebook source
import pyspark.sql.functions as F

def historic_type_one(df, surrogateKeys):
  
  if (df.where(F.col("dna_batch_id").isNull()).count()) == 0:
    order_by_str = "dna_batch_id desc, dna_update_dttm"
  else:
    order_by_str = "dna_update_dttm"   
    
  df.createOrReplaceTempView("df_view")
  df=spark.sql("SELECT distinct RANK() OVER (partition by {0} ORDER BY {1} desc) AS rank,* from df_view ".format(",".join(surrogateKeys),order_by_str))
  result_df=df.filter("rank=1" )
  return result_df

def records_with_D(df):
  df_new = df.filter("dna_cdc_cd != 'D'")
  return df_new

delta_df = historic_type_one(df_phase1_whr, surrogateKeys_1)

df_phase1_whr = records_with_D(delta_df)

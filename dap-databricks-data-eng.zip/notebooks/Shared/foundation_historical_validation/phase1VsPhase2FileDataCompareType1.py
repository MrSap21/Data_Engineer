# Databricks notebook source
#run config file
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_pos_curated'
table_name='pos_transaction'
phase1_file_location='/mnt/pos/ARCH/OUT/idl/pos_transaction/load-ready'
phase2_delta_location='/mnt/landing/foundation_testing/pos_trans/delta-test'
surrogateKeys_1=['sales_txn_id']
#output config
phase1_vs_phase2_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
phase2_vs_phase1_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
phase1_vs_phase2_output_file_name = '/phase1file_vs_phase2delta_unmatched_type1.csv'
phase2_vs_phase1_output_file_name = '/phase2delta_vs_phase1file_unmatched_type1.csv'
phase1_vs_phase2_output_file_name_m = '/phase1file_vs_phase2delta_matched_type1.csv'
where_clause = "sales_txn_id='102010135029128' and dna_stat_cd='C'"

# COMMAND ----------

df_phase2_file = spark.read.format("delta").load(phase2_delta_location)
df_phase2_file.registerTempTable("df_phase2_table")
df_phase2_whr = spark.sql("select * from df_phase2_table where {}".format(where_clause))
col_ph2=df_phase2_whr.columns

df_phase1_file = spark.read.parquet(phase1_file_location+"/*/*")
df_phase1_file.registerTempTable("df_phase1_table")
df_phase1_whr = spark.sql("select * from df_phase1_table where {}".format(where_clause))

# COMMAND ----------

#generating where clause for phase1 file
where_phase1 ="dna_batch_seq_id=='201805130000000001' and dna_stat_cd=='C'"
sp= where_phase1.split(' and ')
sp_len=len(sp)
whr2=''
for i in sp:
  whr = '(df_phase1_file.'+i + ') '
  whr2 = whr2 + ' & ' + whr
whr_ph_1 = whr2.replace('&','',1)
print('Phase1 file where clause')
print(whr_ph_1)

#generating where clause for phase2 file
where_phase2 ="rank=='1' and dna_stat_cd=='C'"
sp2= where_phase2.split(' and ')
sp_len2=len(sp2)
whr4=''
for j in sp2:
  
  whr3 = '(df_phase2_file.'+j + ') '
  whr4 = whr4 + ' & ' + whr3
whr_ph_2 = whr4.replace('&','',1)
print('Phase2 file where clause')
print(whr_ph_2)

df_phase2_file = spark.read.format("delta").load(phase2_delta_location)
df_phase2_whr = df_phase2_file.filter(eval(whr_ph_2) ).drop('rank')
col_ph2=df_phase2_whr.columns

df_phase1_file = spark.read.parquet(phase1_file_location)
df_phase1_whr = df_phase1_file.filter(eval(whr_ph_1) )

    

# COMMAND ----------

# MAGIC %run ./phase1Type1Processing

# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------

#selecting only phase2 columns for phase1
df_ph1_col = df_phase1_whr.select(col_ph2)

#comparing processed phase1 file with phase2 file
phase1_vs_phase2 = df_ph1_col.subtract(df_phase2_whr).sort('dna_update_dttm',ascending=False)
phase2_vs_phase1 = df_phase2_whr.subtract(df_ph1_col).sort('dna_update_dttm',ascending=False)

#finding matched records
phase1_vs_phase2_m = df_ph1_col.intersect(df_phase2_whr).sort('dna_update_dttm',ascending=False)
phase1_vs_phase2_m.repartition(1).write.mode("overwrite").format('csv').option("compression","none").option("header", "true").save(phase1_vs_phase2_output_folder_path+'/'+phase1_vs_phase2_output_file_name_m)

# COMMAND ----------

if phase1_vs_phase2.count() == 0:
  validation_status = 'Success'
else:
  validation_status = 'Failure'  
  #write to error file
  output_df1 = phase1_vs_phase2.limit(1000) 
  output_file_1 = phase1_vs_phase2_output_folder_path+'/'+phase1_vs_phase2_output_file_name
  output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_1)
  result_detail = output_file_1

  
if phase2_vs_phase1.count() == 0:
  validation_status = 'Success'  
else:
  validation_status = 'Failure'  
  #write to error file  
  output_df2 = phase2_vs_phase1.limit(1000)
  output_file_2 = phase2_vs_phase1_output_folder_path+'/'+phase2_vs_phase1_output_file_name
  output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_2)
  result_detail = output_file_2

if validation_status == 'Success':
  
  output_file_3 = phase2_vs_phase1_output_folder_path+'/'+phase1_vs_phase2_output_file_name_m
  result_detail = output_file_3
  
if phase1_vs_phase2.count() > 0 and phase2_vs_phase1.count() > 0:
  result_detail = output_file_1+','+output_file_2

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase1_file_location,phase2_delta_location,"Phase1FileVsPhase2DataCompare",validation_status,"whereClause:"+where_clause+',outputFile:'+result_detail,df_phase1_whr.count(),df_phase2_whr.count(),None,None,current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
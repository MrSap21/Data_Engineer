# Databricks notebook source
#%run ./inputConfig
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_pos_curated'
table_name='pos_transaction'
phase1_synapse_location='/mnt/landing/foundation_testing/pos_trans/delta-test-1'
#output config
synapse_vs_snowflake_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
snowflake_vs_synapse_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
synapse_vs_snowflake_output_file_name = 'synapse_vs_snowflake_data_compare.csv'
snowflake_vs_synapse_output_file_name = 'snowflake_vs_synapse_data_compare.csv'
where_clause = "sales_txn_id='102010135029128' and dna_stat_cd='C'"


# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------

df_synapse_file = spark.read.format("csv").load(phase2_synapse_location)
df_synapse_file.registerTempTable("df_synapse_table")
df_synapse_file_where_clause = spark.sql("select * from df_synapse_table where {}".format(where_clause))

#Snowflake query
query_to_get_data = "select * from "+db_name+"."+schema_name+"."+table_name + " where "+where_clause
df_snowflake = spark.read.format("snowflake").options(**sfOptions).option("query",query_to_get_data).load()

synapse_vs_snowflake = df_synapse_file_where_clause.subtract(df_snowflake)
snowflake_vs_synapse = df_snowflake.subtract(df_synapse_file_where_clause)

if snowflake_vs_synapse.count() == 0:
  validation_status = 'Success'
else:
  validation_status = 'Failure'  
  #write to error file
  output_df1 = snowflake_vs_synapse.limit(1000) 
  output_file_1 = snowflake_vs_synapse_output_folder_path+'/'+snowflake_vs_synapse_output_file_name    
  output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_1)
  result_detail = output_file_1
  
if synapse_vs_snowflake.count() == 0:
  validation_status = 'Success'  
else:
  validation_status = 'Failure'  
  #write to error file  
  output_df2 = synapse_vs_snowflake.limit(1000)
  output_file_2 = synapse_vs_snowflake_output_folder_path+'/'+synapse_vs_snowflake_output_file_name
  output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_2)
  result_detail = output_file_2

if validation_status == 'Success':
  result_detail = ""
  
if snowflake_vs_synapse.count() > 0 and synapse_vs_snowflake.count() > 0:
  result_detail = output_file_1+','+output_file_2

 #write to error file
output_df1 = snowflake_vs_synapse.limit(1000)
output_df2 = synapse_vs_snowflake.limit(1000)

output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(snowflake_vs_synapse_output_folder_path+'/'+snowflake_vs_synapse_output_file_name)
output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(synapse_vs_snowflake_output_folder_path+'/'+synapse_vs_snowflake_output_file_name)
    

# COMMAND ----------

synapse_vs_snowflake.count()

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase2_delta_location,schema_name+"."+table_name,"Phase1SynapseVsSnowflakeDataCompare",validation_status,where_clause+','+result_detail,df_synapse_file_where_clause.count(),df_snowflake.count(),None,None,current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
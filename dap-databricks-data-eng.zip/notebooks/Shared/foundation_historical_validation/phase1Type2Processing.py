# Databricks notebook source
import pyspark.sql.functions as F
def groupBySurrogateKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, F.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(F.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------

import datetime
def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime.datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele


# COMMAND ----------

def fixType2DataWithDelete(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'],x['dna_update_dttm'])))
  for rw in rowList:
      ky = createKey(rw)
      mp[ky] = rw
       
  for k in kst:
        rw = rowList[k]
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           delList.append(createKey(rw))
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
           if (rw2 is None):
              lst.append(createKey(rw))
           else:
              if (((type(rw['dna_end_dttm']) is datetime.datetime) and rw['dna_end_dttm'].year == 9999)  or  ((type(rw['dna_end_dttm']) is str ) and rw['dna_end_dttm'].startswith('9999'))):
                 continue
              else:
                 lst.append(createKey(rw))
  for f in lst:
        f1 = f.split("----")
        if len(delList) == 0:
           retList.append(mp[f])
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if d1[0] == f1[0]:
                  match = True
                  break
           if match == False:
              retList.append(mp[f])
  rowList2 = list(sorted(retList, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'])))
  dct1 = {}
  for rw in rowList2:
      ky1 = getStringKey(rw['dna_eff_dttm'])
      endKy = getStringKey(rw['dna_end_dttm'])
      if ky1 not in dct1:
         dct1[ky1] = rw
      else:
          endKy2 = getStringKey(dct1[ky1]['dna_end_dttm'])
          if endKy2 < endKy:
             dct1[ky1] = rw
  retList2 = []
  for ky in dct1.keys():
      retList2.append(dct1[ky])
  
  return retList2

# COMMAND ----------

list_column = table_name + "_list"

schema = df_phase1_whr.schema
df4 = groupBySurrogateKey(df_phase1_whr,table_name, surrogateKeys)

rd1 = df4.rdd.map(lambda rw:fixType2DataWithDelete(rw[list_column])).flatMap(lambda x:x)
df5 = spark.createDataFrame(rd1, schema)

df_phase1_whr= df5
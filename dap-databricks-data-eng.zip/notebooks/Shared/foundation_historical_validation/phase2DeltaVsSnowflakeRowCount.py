# Databricks notebook source
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_pos_curated'
table_name='pos_transaction'
phase2_delta_location='/mnt/landing/foundation_testing/pos_trans/delta'
where_clause= "sales_txn_id = '102010135029128'"

# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------

#Snowflake query
query_to_get_table_row_count = "select count(*) from "+schema_name+"."+table_name+" where "+where_clause

#load to dataframe
df_table = spark.read.format("snowflake").options(**sfOptions).option("query",query_to_get_table_row_count).load()
df_phase2_file = spark.read.format("delta").load(phase2_delta_location)

#get table row count
table_row_count = int(df_table.collect()[0][0])

#get file row count
df_phase2_file.registerTempTable("phase2_file")
df_phase2_file_where_clause = spark.sql("select count(*) from phase2_file where {}".format(where_clause))
file_row_count = df_phase2_file_where_clause.count()

print(table_row_count)
print(file_row_count)

#compare row count
if table_row_count == file_row_count:
  validation_status = 'Success'
else:
  validation_status = 'Failure'
 

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase2_delta_location,schema_name+"."+table_name,"Phase2DeltaVsSnowflakeRowCount",validation_status,where_clause,file_row_count,table_row_count,None,None,current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
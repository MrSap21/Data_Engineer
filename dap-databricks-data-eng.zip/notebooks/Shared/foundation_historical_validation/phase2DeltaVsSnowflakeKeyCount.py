# Databricks notebook source
#%run ./inputConfig
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_pos_curated'
table_name='pos_transaction'
phase1_file_location='/mnt/pos/ARCH/OUT/idl/pos_transaction/load-ready/*/*'
phase2_delta_location='/mnt/landing/foundation_testing/pos_trans/delta'
#output config
delta_vs_snowflake_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
snowflake_vs_delta_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
delta_vs_snowflake_output_file_name = '/phase2delta_vs_snowflake_keys.csv'
snowflake_vs_delta_output_file_name = '/phase2snowflake_vs_delta_keys.csv'
surrogate_key='sales_txn_id'

# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------

#create folder path
dbutils.fs.mkdirs(delta_vs_snowflake_output_folder_path)
dbutils.fs.mkdirs(snowflake_vs_delta_output_folder_path)
#load dataframe
#Snowflake query
query_to_get_table_keys = "select distinct " + surrogate_key + " from "+db_name+"."+schema_name+"."+table_name
df_table = spark.read.format("snowflake").options(**sfOptions).option("query",query_to_get_table_keys).load()
df_phase2_file = spark.read.format("delta").load(phase2_delta_location)

# COMMAND ----------

#validation
table_sk_list=df_table
phase2_sk_list=df_phase2_file.select(surrogate_key).distinct()
print(table_sk_list.count())
#comparison
table_vs_delta = table_sk_list.subtract(phase2_sk_list)
delta_vs_table = phase2_sk_list.subtract(table_sk_list)

if table_vs_delta.count() == 0:
  validation_status = 'Success'
else:
  validation_status = 'Failure'  
  #write to error file
  output_df1 = table_vs_delta.limit(1000) 
  output_file_1 = snowflake_vs_delta_output_folder_path+'/'+snowflake_vs_delta_output_file_name    
  output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_1)
  result_detail = output_file_1
  
if delta_vs_table.count() == 0:
  validation_status = 'Success'  
else:
  validation_status = 'Failure'  
  #write to error file  
  output_df2 = delta_vs_table.limit(1000)
  output_file_2 = delta_vs_snowflake_output_folder_path+'/'+delta_vs_snowflake_output_file_name
  output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_2)
  result_detail = output_file_2

if validation_status == 'Success':
  result_detail = ""
  
if table_vs_delta.count() > 0 and delta_vs_table.count() > 0:
  result_detail = output_file_1+','+output_file_2
  

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase2_delta_location,schema_name+"."+table_name,"Phase2DeltaVsSnowflakeKeyCount",validation_status,result_detail,None,None,phase2_sk_list.count(),table_sk_list.count(),current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
# Databricks notebook source
#run config file
db_name='DAPDEVDWH01'
validation_db_name='DAPDEVDWH01'
schema_name='dna_location_curated'
table_name='location_store_detail'
phase1_file_location='/mnt/location/ARCH/OUT/location/location_store_detail/load-ready/*/*'
#dbutils.fs.ls(phase1_file_location)
phase2_delta_location='/mnt/landing/foundation_testing/location_store_detail/delta'
surrogateKeys=['store_nbr']
#output config
phase1_vs_phase2_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
phase2_vs_phase1_output_folder_path = '/mnt/landing/common/tframework/tf_foundation/'+table_name
phase1_vs_phase2_output_file_name = '/phase1file_vs_phase2delta_unmatched_type1.csv'
phase2_vs_phase1_output_file_name = '/phase2delta_vs_phase1file_unmatched_type1.csv'
phase1_vs_phase2_output_file_name_m = '/phase1file_vs_phase2delta_matched_type1.csv'
where_clause="store_nbr='14202' and dna_stat_cd='C'"

# COMMAND ----------

df_phase2_file = spark.read.format("delta").load(phase2_delta_location)
df_phase2_file.registerTempTable("df_phase2_table")
df_phase2_whr = spark.sql("select * from df_phase2_table where {}".format(where_clause))
#df_phase2_whr = df_phase2_file.filter(eval(whr_ph_2) )
col_ph2=df_phase2_whr.columns

df_phase1_file = spark.read.parquet(phase1_file_location)
df_phase1_file.registerTempTable("df_phase1_table")
df_phase1_whr = spark.sql("select * from df_phase1_table where {}".format(where_clause))


# COMMAND ----------

# MAGIC %run ./phase1Type2Processing

# COMMAND ----------

# MAGIC %run ./snowflakeConfig

# COMMAND ----------

#selecting only phase2 columns for phase1
df_ph1_col = df_phase1_whr.select(col_ph2)

#comparing processed phase1 file with phase2 file
phase1_vs_phase2 = df_ph1_col.subtract(df_phase2_whr).sort('dna_update_dttm',ascending=False)
phase2_vs_phase1 = df_phase2_whr.subtract(df_ph1_col).sort('dna_update_dttm',ascending=False)

#finding matched records
phase1_vs_phase2_m = df_ph1_col.intersect(df_phase2_whr).sort('dna_update_dttm',ascending=False)
phase1_vs_phase2_m.repartition(1).write.format('csv').option("compression","none").option("header", "true").save(phase1_vs_phase2_output_folder_path+'/'+phase1_vs_phase2_output_file_name_m)

# COMMAND ----------

if phase1_vs_phase2.count() == 0:
  validation_status = 'Success'
else:
  validation_status = 'Failure'  
  #write to error file
  output_df1 = phase1_vs_phase2.limit(1000) 
  output_file_1 = phase1_vs_phase2_output_folder_path+'/'+phase1_vs_phase2_output_file_name
  output_df1.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_1)
  result_detail = output_file_1

  
if phase2_vs_phase1.count() == 0:
  validation_status = 'Success'  
else:
  validation_status = 'Failure'  
  #write to error file  
  output_df2 = phase2_vs_phase1.limit(1000)
  output_file_2 = phase2_vs_phase1_output_folder_path+'/'+phase2_vs_phase1_output_file_name
  output_df2.repartition(1).write.format('csv').mode("overwrite").option("compression","none").option("header", "false").save(output_file_2)
  result_detail = output_file_2

if validation_status == 'Success':  
  output_file_3 = phase2_vs_phase1_output_folder_path+'/'+phase1_vs_phase2_output_file_name_m
  result_detail = output_file_3
  
if phase1_vs_phase2.count() > 0 and phase2_vs_phase1.count() > 0:
  result_detail = output_file_1+','+output_file_2

# COMMAND ----------

import datetime
import time

#write results to Snowflake
current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

new_row = spark.createDataFrame([(table_name,phase1_file_location,phase2_delta_location,"Phase1FileVsPhase2DataCompare",validation_status,"whereClause:"+where_clause+',outputFile:'+result_detail,df_phase1_whr.count(),df_phase2_whr.count(),None,None,current_time)], schema=schema)

new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable",validation_db_name+"."+"PUBLIC.PHASE1HISTORICAL_VALIDATIONSTATUS").mode("append").save()
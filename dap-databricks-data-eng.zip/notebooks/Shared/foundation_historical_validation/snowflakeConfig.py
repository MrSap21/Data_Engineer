# Databricks notebook source
#environment = dbutils.widgets.get("env")

#for snowflake
from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os
from pyspark.sql.types import *

dbutils.secrets.list('dapdevdataenggscope')
password=dbutils.secrets.get(scope = "dapdevdataenggscope", key = "dapdevdbrauthn")

val1 = bytearray(re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",password).replace("\\n","\n").encode())

vL2  = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",password).replace("\\n","\n")

p_key = serialization.load_pem_private_key(
    val1,
    password = 'devsnowcli'.encode(),
    backend = default_backend()
    )

pkb = p_key.private_bytes(
  encoding = serialization.Encoding.PEM,
  format = serialization.PrivateFormat.PKCS8,
  encryption_algorithm = serialization.NoEncryption()
  )

pkb = pkb.decode("UTF-8")
pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n","",pkb).replace("\\n","")


sfOptions = {
  "sfURL" : "https://wba_rpu_nprod_datainsight_01.east-us-2.privatelink.snowflakecomputing.com",
  "sfUser" : "DEVSNOWCLI_USER",
  "pem_private_key" : pkb,
  "sfDatabase" : db_name,
  #"sfSchema" : "DNADEVEDWDB01",
  "sfWarehouse" : "WBADEVDBENGINEER_WH"
}

SNOWFLAKE_SOURCE_NAME = "net.snowflake.spark.snowflake"

#hard coded row count limit for cell to cell data comparison
row_count_limit = 50000
  
resource_app_id_url = "https://database.windows.net/"

#output table schema
#schema for output dataframe
schema = StructType([
             StructField('table_name', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),             
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_key_count', IntegerType()),
             StructField('destination_key_count', IntegerType()),            
             StructField('validation_execution_time', StringType())            
            ])
# Databricks notebook source
from datetime import datetime
import pyspark.sql.functions as F

# COMMAND ----------

#staging_area = "/mnt/staging/uat_pharmacy_healthcare/patient_services/ic_prescription_fill/"
#bad_record_area = "/mnt/wrangled/baddata/uat_staging/patient_services/ic_prescription_fill_plan/"

# COMMAND ----------

##This is final
def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    path_to_process = ""
    current_batch_id = '0'
    stage_path = ""
    load_ready_path = ""
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
    table_name = rw['table_name']
    bad_record_area = rw['bad_data_area']
    batchIdList = []
 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                batchIdList.append(batch_id)
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
                  
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          batchIdList.append(batch_id)
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
        if tableName == 'ic_prescription_fill_plan':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      batchIdList.append(ln_batch_id)
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          batchIdList.append(ln_batch_id)
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
    year = datetime.now().year
    if current_batch_id[0:4] > str( year + 1):
       lst3 = list(filter(lambda fld : fld[0:4] <= str(year + 1), batchIdList))
       lst1 = sorted(lst3, reverse=True)
       if len(lst1) == 0:
          return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, [],-1,clean_sql,dedup_column,
                  in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,
                  bad_sql,table_name,bad_record_area)
       current_batch_id = lst1[0]
    stage_path = stage_path + current_batch_id + "/"
    load_ready_path = load_ready_path + current_batch_id + "/"     
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql,table_name,bad_record_area)
    

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

def generateDMLScript(snow_input_script, batchid, snow_output_script):
    
    lines = []
    with open (snow_input_script, 'rt') as myfile:
      for inline in myfile: 
        outline = inline
        if '@batchid' in inline:
            #print (inline)
            outline = inline.replace('@batchid' , batchid)
        lines.append(outline)    
   
    output_file = open(snow_output_script, "w")
    for ln in lines:
        output_file.write(ln)
    output_file.close()
    myfile.close()
    

# COMMAND ----------

def trimStringFields(df): 
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "StringType":
           df2 = df2.withColumn(fld.name, F.trim(df2[fld.name]))
    return df2

# COMMAND ----------



def historic_type_one1(df, surrogateKeys):
  order_by_str = "dna_batch_id desc, dna_update_dttm"
  df.createOrReplaceTempView("df_view")
  df=spark.sql("SELECT distinct RANK() OVER (partition by {0} ORDER BY {1} desc) AS rank,* from df_view ".format(",".join(surrogateKeys),order_by_str))
  result_df=df.filter("rank=1" )
  return result_df

def fixDataType(df, outputColList, fldList):
    df1 = df
    colSet = set(df1.columns)
    outSet = set(outputColList)
    diffSet = outSet - colSet
    print(diffSet)
    baseList = df1.schema.fields
    for cle in diffSet:
        print(cle)
        df1 = df1.withColumn(cle,  F.lit(None).cast(fldList[cle].dataType))
    for cle in baseList:
        if cle.name in fldList:
           df1 = df1.withColumn(cle.name,  df1[cle.name].cast(fldList[cle.name].dataType))
    return df1.select(outputColList)
  
def runprs_fill_incremental(prefix, fldList,outputColList,surrogateKeys,clean_sql,bad_sql, in_path_list, last_batch_id, stage_path):
    lst5 = in_path_list
    #year = prefix[0:4]
    lst6 = lst5
    if prefix is not None:
       lst6 =  list(filter(lambda rw: prefix in rw, lst5))
    lst6 =  list(filter(lambda rw: rw.split("/")[10] <= str(last_batch_id), lst6))
    #print(lst6)
    sze = len(lst6)
    dct2 = {}
    dct3 = {}
   
    for  ent in lst6:
         lst10 = []
         batchId = ent.split("/")[10]
         ky = batchId[0:4]
         ##print(batchId)
         if batchId.startswith("20210228222222"):
            print(ent)
            lst11 = []
            if ky in dct3:
               lst11 = dct3[ky]
            lst11.append(ent )
            dct3[ky] = lst11
         else:
            if ky in dct2:
               lst10 = dct2[ky]
            lst10.append(ent)
            dct2[ky] = lst10
    
    ##print(dct2)
    kys = sorted(list(dct2.keys()))
    base_df = spark.read.parquet(*dct2[kys[0]])
    base_df = fixDataType(base_df,outputColList, fldList)
    i = 0
    for ky in kys:
        if i > 0:
            #print(dct2[ky])
            dfx = spark.read.parquet(*dct2[ky])
            dfx = fixDataType(dfx,outputColList, fldList)
            base_df = base_df.union(dfx)
        i = i + 1
        
    kys = sorted(list(dct3.keys()))
    for ky in kys:
        print(ky)
        print(dct3[ky])
        dfx = spark.read.parquet(*dct3[ky])
        dfx = fixDataType(dfx,outputColList, fldList)
        base_df = base_df.union(dfx)
    base_df.createOrReplaceTempView("prs_fill")
    #base_df.printSchema()
    ##### FIX FOR PRESCRITON_FILL
   
    delta_df = base_df.filter("dna_stat_cd != 'R'")
    delta_df = historic_type_one1(delta_df, surrogateKeys)
    ## remove duplicate.
    delta_df = delta_df.dropDuplicates(surrogateKeys)
    #remove R (rejected) records
    #delta_file_location_4 = "/mnt/staging/phase1/ic_prescription_fill/correct/" + prefix
    delta_file_location_4 = stage_path
    dbutils.fs.rm(delta_file_location_4,True)
    delta_df = delta_df.select(outputColList)
    delta_df.persist()
    print('delta--'+str(delta_df.count()))
    deleted_record = delta_df.filter("dna_cdc_cd='D'")
    delta_df = delta_df.filter("dna_cdc_cd != 'D'")
    delta_df.createOrReplaceTempView("df_view")
    delta_df1 = spark.sql ("select * from df_view " + clean_sql);
    print('delta_df1--'+str(delta_df1.count()))
    delta_df1.unionAll(deleted_record).write.format("parquet").mode('overwrite').save(delta_file_location_4)
    
    delta_file_bad_location_4 = bad_record_area + last_batch_id
    
    dbutils.fs.rm(delta_file_bad_location_4,True)  
    #bad_record_area
    #delta_file_bad_location_4 = "/mnt/staging/phase1/baddata/ic_prescription_fill/" + prefix
    bad_df = spark.sql ("select * from df_view " + bad_sql);
    print('bad--'+str(bad_df.count()))
    bad_df.write.format("parquet").mode('overwrite').save(delta_file_bad_location_4)

# COMMAND ----------

prefix='2021-07'
fldList = {}
delta_file_location_4 = "/mnt/staging/phase1/ic_prescription_fill_plan/" + prefix
df1 = spark.read.parquet(delta_file_location_4)
for fld in df1.schema.fields:
    fldList[fld.name] = fld

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,bad_sql,table_name,
bad_record_area) = getParameters('ic_prescription_fill_plan')
if (len(in_path_list) == 0 or current_batch_id == -1):
  dbutils.notebook.exit(["no-data","","/dbfs/mnt/dmlstaging/Common/no-data", "" ])
#except:
#    dbutils.notebook.exit(["failed","","", "" ])
#dbutils.notebook.exit(["success","","", "" ])    
    

# COMMAND ----------

#try:
runprs_fill_incremental(None, fldList,outputColList,surrogateKeys,clean_sql,bad_sql, in_path_list, current_batch_id , stage_path)
#except:
#    dbutils.notebook.exit(["failed","","", "" ])
#dbutils.notebook.exit(["success","","", "" ]) 

# COMMAND ----------

sql1 = "update proc_config set last_loaded_batch_id = '{0}' where table_name = 'ic_prescription_fill_plan'".format(current_batch_id)
spark.sql(sql1)

# COMMAND ----------


### work on template
snow_output_loc = base_dml_out_location + str(current_batch_id)
## create folder
snow_output_script = snow_output_loc  + "/" + table_name+"_sql.csv"

try:
  dbutils.fs.rm(snow_output_loc,True)
  dbutils.fs.mkdirs(snow_output_loc)
  snow_incrememt_dml_file_name_new = '/dbfs'+snow_incrememt_dml_file_name
  snow_output_script_new = '/dbfs'+snow_output_script
  generateDMLScript(snow_incrememt_dml_file_name_new, current_batch_id, snow_output_script_new)
except:
  print("error") # fatal error
  dbutils.notebook.exit(["fail","", "" ])

dbutils.notebook.exit(["sucess",stage_path,snow_output_script_new ])
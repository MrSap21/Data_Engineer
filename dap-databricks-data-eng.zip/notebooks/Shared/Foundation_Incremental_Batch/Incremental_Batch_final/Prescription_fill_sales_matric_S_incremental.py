# Databricks notebook source
#bad_data_area = "/mnt/wrangled/baddata/uat_pharmacy_healthcare/patient_services/ic_prescription_fill_sales_metric/"
#import pyspark.sql.functions as F
import pyspark.sql.functions as f
#import datetime
from datetime import datetime


# COMMAND ----------

def getParameters(tableName):
    sql1 = "select * from proc_config where table_name = '" + tableName + "'"
    arr = spark.sql(sql1).collect()
    rw = arr[0]
    table_type = rw['table_type']
    surrogateKeys = rw['surrogateKeys'].split(",")
    outputColList = rw['outputColList'].split(",")
    outputColList = [item.strip() for item in outputColList]
    last_loaded_batch_id = rw['last_loaded_batch_id']
    base_path = rw['base_path']
    stage_path = rw['stage_path']
    load_ready_path = rw['load_ready_path']
    clean_sql = rw['clean_sql']
    dedup_column = rw['dedup_column'].split(",")
    snapshot = rw['snapshot']
    snow_incrememt_dml_file_name = rw['snow_incrememt_dml_file_name']
    base_dml_out_location = rw['base_dml_out_location']
    bad_sql = rw['bad_sql']
    bad_data_area = rw['bad_data_area']
    #print ('test value-->'+snow_incrememt_dml_file_name) 
    in_path_list = []
    if snapshot == "Y":
       history_path = base_path.replace("<batch>", "*")
    else:
       history_path = base_path + "*/*/*"
    
    path_to_process = ""
    current_batch_id = '0'
    #stage_path = ""
    load_ready_path = ""
    in_path_list = []
    if snapshot != "Y":
        lst1 = dbutils.fs.ls(base_path)
        #print(lst1)
        lst2 = list(filter(lambda fld : fld.name.startswith("bkp") == False, lst1))
        lst3 = list(filter(lambda fld : fld.name.replace("/", "") > last_loaded_batch_id, lst2))
        lst4 = sorted(lst3) 
        if len(lst4) > 0:
            for ln in lst4:
                path_to_process = ln.path + "*/*"
                in_path_list.append(path_to_process)
                batch_id = ln.name.replace("/", "")
                if batch_id > current_batch_id:
                   current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
    if snapshot == "Y":
        snap_base_path = rw['snapshot_base_path']
        lst5 = dbutils.fs.ls(snap_base_path)
        if tableName.startswith('pos_'):
            ff = datetime.now() - timedelta(days=30)
            current_dt = ff.strftime("%Y-%m-%d")
            print(current_dt)
            for ln in lst5:
                if ln.name.replace("/","").split("=")[1] > current_dt:
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
            stage_path = stage_path + current_batch_id + "/"
            load_ready_path = load_ready_path + current_batch_id + "/"
        if tableName == 'ic_prescription_fill':         
           for ln in lst5:
               lst54 =  dbutils.fs.ls(ln.path)
               for ln1 in lst54:
                   ln_batch_id = ln1.name.replace("/", "")
                   if ln_batch_id > str(last_loaded_batch_id):
                      in_path_list.append(ln1.path + "*/*" )
                      if ln_batch_id > current_batch_id:
                         current_batch_id = ln_batch_id
           stage_path = stage_path + current_batch_id + "/"
           load_ready_path = load_ready_path + current_batch_id + "/"               
        if tableName == 'ic_prescription_fill_sales_metric': 
           lst54 = list(filter(lambda rw:rw.name.startswith("partition_key"), lst5))
           for ln in lst54:
               if ln.name.startswith("partition_key"):
                   #print(ln.name)
                   lst2 = dbutils.fs.ls(ln.path)
                   for ln1 in lst2:
                       #print(ln1.name)
                       batch_id = ln1.name.replace("/","").split("=")[1]
                       if batch_id > str(last_loaded_batch_id):
                          in_path_list.append(ln1.path + "*/*")
                          if batch_id > current_batch_id:
                             current_batch_id = batch_id
    year = datetime.now().year
    if current_batch_id[0:4] > str( year + 1):
       lst3 = list(filter(lambda fld : fld[0:4] <= str(year + 1), batchIdList))
       lst1 = sorted(lst3, reverse=True)
       if len(lst1) == 0:
          return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, [],-1,clean_sql,dedup_column,
                  in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location,
                  bad_sql,table_name)
       current_batch_id = lst1[0]
    stage_path = stage_path + current_batch_id + "/"
    load_ready_path = load_ready_path + current_batch_id + "/"           
    return (table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location, bad_sql , bad_data_area)
    

# COMMAND ----------


def createKey(rw):
    ky = getStringKey(rw['dna_eff_dttm'])+ "----" + getStringKey(rw['dna_end_dttm']) + "----" + rw['dna_cdc_cd']
    return ky
def getStringKey(ele):
    if type(ele) is datetime:
       return ele.strftime("%Y-%m-%d %H:%M:%S")
    if type(ele) is str:
       return ele
      

# COMMAND ----------


def groupBySurrgoteKey (df, table_name, groupColNames):
    struct_col_name = table_name + "_struct"
    list_col_name =  table_name + "_list"
    new_store_colname = table_name + "_" + groupColNames[0]
    df1 = df.withColumn(struct_col_name, f.struct(df.columns))
    colList = []
    for cl in groupColNames:
        colList.append(cl)
    colList.append(struct_col_name)
    df2 = df1.select(colList)
    grBy2 = groupColNames
    df2Gr  = df2.groupBy(grBy2).agg(f.collect_list(struct_col_name).alias(list_col_name))
    #df2Gr = df2Gr.withColumnRenamed(store_col_name, new_store_colname)
    return df2Gr

# COMMAND ----------

def fixType1DataWithIncremental(rowListin):  
  retList = []
  kst = list(range(0, len(rowListin)))
  sze = len(rowListin)
  delList = []
  mp = {}
  lst = []
  rowList = list(sorted(rowListin, key = lambda x: (x['dna_batch_id'],x['dna_update_dttm'],x['dna_eff_dttm'], x['dna_end_dttm'])))
  #print(rowList)
  for rw in rowList:
      ky = createKey(rw)
      #print(ky)
      mp[ky] = rw
   
  for k in kst:
        rw = rowList[k]
        ##print(rw)
        rw2 = None
        if k < sze -1:
           rw2 = rowList[k + 1]
        if  (rw['dna_cdc_cd'] == 'D'):
           kx = createKey(rw)
           print(delList)
           print(kx)
           if kx not in delList:
              delList.append(kx)
        if ((rw['dna_cdc_cd'] == 'I') or  (rw['dna_cdc_cd'] == 'U')):
            lst.append(createKey(rw))
  #print(lst)
  appliedDList = {}
  for f in lst:
        print(f)
        f1 = f.split("----")
        print(f1)
        if len(delList) == 0:
           retList.append(mp[f])
           #print(retList)
        match = False;
        if len(delList) > 0:
           for dl in delList:
               d1 = dl.split("----")
               if ((d1[0] == f1[0]) and (d1[1] >= f1[1])):
                  match = True
                  appliedDList[dl] = dl
                  break
           if match == False:
              retList.append(mp[f])
  for dl in delList:
      if dl not in appliedDList:
         retList.append(mp[dl])
          
  rowList2 = list(sorted(retList, key = lambda x: (x['dna_eff_dttm'], x['dna_end_dttm'])))
  
  dct1 = {}
  for rw in rowList2:
      ky1 = getStringKey(rw['dna_eff_dttm'])
      endKy = getStringKey(rw['dna_end_dttm'])
      if ky1 not in dct1:
         dct1[ky1] = rw
      else:
          endKy2 = getStringKey(dct1[ky1]['dna_end_dttm'])
          if endKy2 < endKy:
             dct1[ky1] = rw
  retList2 = []
  st = set(dct1.keys())
  for ky in dct1.keys():
      retList2.append(dct1[ky])
  #print(appliedDList)
  for dl in delList:
      if ((dl not in appliedDList) and (dl not in st)) :
         retList2.append(mp[dl]) 
  #print(retList2)
  return retList2

# COMMAND ----------

def convertToTimestampToString(df):
    df2 = df
    fields = df2.schema.fields
    for fld in fields:
        if str(fld.dataType) == "TimestampType":
           df2 = df2.withColumn(fld.name, df2[fld.name].cast("string"))
    return df2

# COMMAND ----------

def generateDMLScript(snow_input_script, batchid, snow_output_script):
    
    lines = []
    with open (snow_input_script, 'rt') as myfile:
      for inline in myfile: 
        outline = inline
        if '@batchid' in inline:
            #print (inline)
            outline = inline.replace('@batchid' , batchid)
        elif 'POS_TRANSACTION_STAGING' in inline:
          outline = inline.replace('POS_TRANSACTION_STAGING', 'POS_TRANSACTION_STAGING_1') 
        lines.append(outline)    
   
    output_file = open(snow_output_script, "w")
    for ln in lines:
        output_file.write(ln)
    output_file.close()
    myfile.close()

# COMMAND ----------

(table_type, surrogateKeys, outputColList,stage_path,load_ready_path, in_path_list, current_batch_id,clean_sql,dedup_column,in_path_list,dedup_column, history_path,snow_incrememt_dml_file_name,base_dml_out_location, bad_sql, bad_data_area) = getParameters('ic_prescription_fill_sales_metric')
if (len(in_path_list) == 0 or current_batch_id == -1):
   dbutils.notebook.exit(["no-data","","/dbfs/mnt/dmlstaging/Common/no-data", "" ])

# COMMAND ----------

snow_incrememt_dml_file_name , current_batch_id


# COMMAND ----------


dfdaily =  spark.read.parquet(*in_path_list)
table_name = "ic_prescription_fill_sales_metric"
list_column = table_name + "_list"
schema = dfdaily.schema

bad_data_loc = bad_data_area + str(current_batch_id) + "/"
df4 = groupBySurrgoteKey(dfdaily,table_name, surrogateKeys)

rd1 = df4.rdd.map(lambda rw:fixType1DataWithIncremental(rw[list_column])).flatMap(lambda x:x)

df5 = spark.createDataFrame(rd1, schema)
df6 = convertToTimestampToString(df5)
df6 = df6.select(outputColList)

print ('test1 -->'+snow_incrememt_dml_file_name)

try:
   print ('test')
   df6.createOrReplaceTempView("xxx")
   df7 = spark.sql("select * from xxx " + clean_sql)
   dbutils.fs.rm(stage_path,True)
   print("writing")
   df7.write.mode("overwrite").parquet(stage_path)
  
  
   dfbad = spark.sql("select * from xxx " + bad_sql)
   dbutils.fs.rm(bad_data_loc,True)
   dfbad.write.mode("overwrite").parquet(bad_data_loc)
  
   sql1 = "update proc_config set last_loaded_batch_id = '{0}' where table_name = 'ic_prescription_fill_sales_metric'".format(str(current_batch_id))
   spark.sql(sql1)
  
except Exception as e:
    tb = traceback.format_exc()
    print(e)
    print("error") # fatal error
    dbutils.notebook.exit(["fail","","", "" ])

print ('test2 -->'+snow_incrememt_dml_file_name)

### work on template
snow_output_loc = base_dml_out_location + str(current_batch_id)
## create folder
snow_output_script = snow_output_loc  + "/" + table_name+"_sql.csv"

try:
  dbutils.fs.rm(snow_output_loc,True)
  dbutils.fs.mkdirs(snow_output_loc)
  snow_incrememt_dml_file_name_new = '/dbfs'+snow_incrememt_dml_file_name
  snow_output_script_new = '/dbfs'+snow_output_script
  generateDMLScript(snow_incrememt_dml_file_name_new, current_batch_id, snow_output_script_new)
except:
  print("error") # fatal error
  dbutils.notebook.exit(["fail","", "" ])


# COMMAND ----------

dbutils.notebook.exit(["sucess",stage_path,snow_output_script_new ])
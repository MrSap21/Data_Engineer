# Databricks notebook source
# MAGIC %sql 
# MAGIC -- DDL to create table 'schema_journal'
# MAGIC --create table schema_journal (
# MAGIC --table_key string,
# MAGIC --md5 string,
# MAGIC --batch_id string,
# MAGIC --mismatch string
# MAGIC --)
# MAGIC --using DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- DML to truncate table and insert test records
# MAGIC --truncate table schema_journal;
# MAGIC --insert into schema_journal values ('ic_drug','\n#&\xd4\xeb\xff\x833\x0e\x90\xd0v\xf5\xa5>\xf6','20080921000000','F');
# MAGIC --insert into schema_journal values ('ic_drug','\n#&\xd4\xeb\xff\x833\x0e\x90\xd0v\xf5\xa5>\xf6','20201101000000','F');
# MAGIC --select count(*) from schema_journal;
# MAGIC --select * from schema_journal;

# COMMAND ----------

# Example code to select and display most recent record for table_key = 'ic_drug'
#df1 = spark.sql("select table_key, md5, batch_id, mismatch from schema_journal where table_key = 'ic_drug' order by batch_id desc limit 1");
#display(df1);

# COMMAND ----------

# function detectSchemaChange()
# When a new batch is processed, the new schema is compared to the most recent previous schema.
# If a mismatch is detected, flag 'mismatch' is set to 'T', and flags for all subsequent batch will be set to 'T'
# until the schema mismatch has been investigated and remediated. Once corrected, an SQL is executed 
# that resets flags for previous records from 'T' to 'F'.
#
# Uses arg 'table_key' to fetch the most recent previous record based on 'batch_id' from table 'schema_journal'.
# if found, if previous 'mismatch' = 'T' then sets 'mismatch' = 'F'.
# else compares arg md5 to previous md5, if equal sets 'mistatch' = 'F', else 'T'.
# if not found, sets 'mismatch' = 'F'.
# Inserts new record (table_key,md5,batch_id,mismatch) into 'schema_journal' 
# returns value of 'mismatch'

def detectSchemaChange(table_key, md5, batch_id):
# fetch most recent prev table_key record sorted by batch_id
  df=spark.sql("""select
  table_key, md5, batch_id, mismatch
  from schema_journal
  where table_key = '{0}'
  order by batch_id desc limit 1
  """.format(table_key));
# if count > 0, extract prev mismatch & md5 values
  if (df.count() > 0):
    prevMismatch = df.select("mismatch").collect()[0][0]
    prevMd5 = df.select("md5").collect()[0][0]
# compare & compute new mismatch value
    if (prevMismatch == 'T'):
      mismatch = 'T'
    elif (prevMd5 == md5):
      mismatch = 'F'
    else:
      mismatch = 'T';   
# if count = 0, set mismatch = 'F'
  else:
    mismatch = 'F'  
# insert new record for 'table_key'
  spark.sql("""insert into schema_journal values ('{0}', '{1}', '{2}', '{3}')""".format(table_key,md5,batch_id,mismatch));
  return mismatch

-- example function call
--retcode = detectSchemaChange('ic_drug','\xfb\xc0\x062\xd4\x05,\x1dH8\x12\x9d3G\xc8\xb4','20201126045045');
--print (retcode)

# COMMAND ----------

# MAGIC %sql -- example of SQL resetting mismatch flag after schema changes have been remediated
# MAGIC --update schema_journal set mismatch = 'F' where table_key = 'ic_drug' and mismatch = 'T';

# COMMAND ----------

# example of code fetching schema from Parquet files and generating md5 hash string from Prod
#import hashlib
#import string
#import base64

#lst1 = dbutils.fs.ls('/mnt/pharmacy/ARCH/OUT/drug/ic_drug/load-ready/')
#f = []
#for x in lst1:
#    print(x.path)
#    schema = spark.read.parquet(x.path + "*/*").schema
#    pschema = str(schema.fields)
#    print(x.path + " : " + pschema)
#    hash = hashlib.md5(pschema.encode('utf-8')).digest()
#    md5_str = str(hash)

# Databricks notebook source
from pyspark.sql.types import *
import datetime
import time
from pyspark.sql.functions import *
from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os

#migration_id = 'trs06tc06202110061012'
#environment = 'dev'
migration_id = dbutils.widgets.get("migration_id")
environment = dbutils.widgets.get("env")

print(migration_id)
migration_id = migration_id.strip()
environment = environment.strip()

#snowflake config
database = environment.lower()+"_pharmacy_healthcare"
account=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfshortaccountname")
url = "https://"+account+".snowflakecomputing.com"
password=dbutils.secrets.get(scope = "dapadbscope", key = "dapsfpassword")
user=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfpythonusername")  
warehouse=dbutils.secrets.get(scope= "dapadbscope", key= "dapsfwarehouse")
sfOptions = {
    "sfURL" : url,
    "sfUser" : user,
    "sfPassword" : password, 
    "sfDatabase" : database,
    "sfWarehouse" : warehouse
}

dbutils.fs.mkdirs("/mnt/wrangled/common/etlerrorfiles")
dbutils.fs.mkdirs("/mnt/wrangled/common/etldata/snowflake_data")

csv_path = '/mnt/wrangled/common/source/source_'+migration_id+'.csv'
error_file_path = '/dbfs/mnt/wrangled/common/etlerrorfiles/mismatch_snowflake2file_'+migration_id+'.csv'
error_file_path2 = '/dbfs/mnt/wrangled/common/etlerrorfiles/mismatch_file2snowflake_'+migration_id+'.csv'


df_csv = spark.read.options(header=True).csv(csv_path)
df_csv_list = df_csv.filter(df_csv.status == "active").collect();

print(df_csv_list)

#schema for output dataframe
schema = StructType([
             StructField('test_run_id', StringType()),
             StructField('test_case_id', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),                         
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),             
             StructField('validation_execution_time', StringType()),
             StructField('source_count', IntegerType()),
             StructField('destination_count', IntegerType()),
             StructField('source_vs_destination_count', IntegerType()),
             StructField('destination_vs_source_count', IntegerType())           
            ])


#Function for checking time data type columns from dataframes
def checkifTimeOnly(fldname,dfx):
    value_check = dfx.where(col(fldname).isNotNull())
    value_c = value_check.count()
    if (value_c == 0):
      return False
    else:
      print('NOT EMPTY')
      value_check2=value_check.take(1)[0]
      value_check_datetime = value_check2[fldname]
      if (value_check_datetime.year == 1900):
        return True
      else:
        return False

for item in df_csv_list :
  if item[0]+item[1] in migration_id:
    qq=item[8].replace("[","'").replace("]","'")  
    query = 'select * from '+item[5]+'.'+item[6].lower()+'.'+item[7].lower()+' where '+qq  
    folder_path = '/mnt/wrangled/common/etldata/'+item[2].lower()+'/'+item[3].lower()+'/'+migration_id.lower()+'/'  
    file_path = '/mnt/wrangled/common/etldata/'+item[2].lower()+'/'+item[3].lower()+'/'+migration_id.lower()
    print(query)      
    df_file = spark.read.parquet(file_path)
    
    df_file.show(5)
    df_table = spark.read.format("snowflake").options(**sfOptions).option("query",query).load()    
   
    #checks for time data type columns from table dataframe
    sch1 = df_table.schema
    print(sch1)
    lst  = []
    for f in sch1.fields:
        if (str(f.dataType) =='TimestampType' ):
           if checkifTimeOnly(f.name,df_table):
              lst.append(f.name)
    print(lst)
    
    for k in lst:
      df_table = df_table.withColumn(k, date_format(k, 'HH:mm:ss'))
      df_table.show(2)
    
    #Trims all the columns before compare
    df_table_selcol=df_table.select(*(trim(col(c)).alias(c) for c in df_table.columns))
    df_file_selcol=df_file.select(*(trim(col(c)).alias(c) for c in df_file.columns))
            
    synapse_file_path = '/dbfs/mnt/wrangled/common/etldata/snowflake_data/snowflake_'+item[2]+'__'+item[3]+'_'+migration_id+'.csv'
    pd3 = df_table.toPandas()
    pd3.to_csv(synapse_file_path,index=False)
    
    test_diff = df_table_selcol.subtract(df_file_selcol)
    test_diff2 = df_file_selcol.subtract(df_table_selcol)
    print("result")
    print(test_diff.count())
    print(test_diff2.count())
    #test_diff.show(2)
    diff_count = test_diff.count()
    diff_count2 = test_diff2.count()
    output_df = test_diff.limit(1000)
    output_df2 = test_diff2.limit(1000)
    tdrowcount = df_file_selcol.count()
    synapaserowcount = df_table_selcol.count()
    pd = output_df.toPandas()
    pd.to_csv(error_file_path,index=False)
    pd2 = output_df2.toPandas()
    pd2.to_csv(error_file_path2,index=False)
    
    ValidationStatus = 'Failure'
    
    if diff_count == 0 and diff_count2 == 0:   
        ValidationStatus = 'Success'
   
    print("validation status: "+ValidationStatus)
    
    def write_to_synapse(new_row):
      new_row.write.format("net.snowflake.spark.snowflake").options(**sfOptions).option("dbtable","public.ETLvalidationstatus").mode("append").save()
      
    
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    new_row = spark.createDataFrame([(item[0],item[1],file_path,item[3],ValidationStatus,error_file_path,current_time,tdrowcount,synapaserowcount,diff_count,diff_count2)], schema=schema)  
    write_to_synapse(new_row)
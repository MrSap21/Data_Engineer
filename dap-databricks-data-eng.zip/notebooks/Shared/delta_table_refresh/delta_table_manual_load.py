# Databricks notebook source
import pyspark.sql.functions as F

# Get INPUT FILE PATH
dbutils.widgets.text("INPUT_FILE_PATH","",label="INPUT_FILE_PATH")
input_file_path = dbutils.widgets.get("INPUT_FILE_PATH").strip()

# Get INPUT FILE TYPE
dbutils.widgets.text("INPUT_FILE_TYPE","",label="INPUT_FILE_TYPE")
input_file_type = dbutils.widgets.get("INPUT_FILE_TYPE").strip()

# Get Delta Table Name
dbutils.widgets.text("DELTA_TABLE_NAME","",label="DELTA_TABLE_NAME")
delta_table_name = dbutils.widgets.get("DELTA_TABLE_NAME").strip()

def schema_final_df(table_name):
  df=spark.sql("select * from {0}".format(table_name))
  lst_schema = df.schema.names
  return lst_schema


# COMMAND ----------

if input_file_type.lower() == 'orc':
  df_final=spark.read.orc(input_file_path)
      
if input_file_type.lower() == 'parquet':
  df_batch=spark.read.parquet(input_file_path)

  lst_schema_batch=df_batch.schema.names

  delta_schema=schema_final_df(delta_table_name)

  for ls in delta_schema:
    if ls not in lst_schema_batch:
      df_batch=df_batch.withColumn(ls,F.lit(None))
      
  df_final=df_batch.select(*delta_schema)
  
df_final.createOrReplaceTempView("delta_view")

spark.sql("insert into {} select * from delta_view".format(delta_table_name))
# Databricks notebook source
import os
import json

# Initial snippet
# os.environ['PROJECT'] = getArgument("PROJECT", "default_project")
# os.environ['JOB'] = getArgument("JOB", "default_job")
# os.environ['INVID'] = getArgument("INVID", "NOINVID")
# os.environ['ESP_CYCLE_ID'] = getArgument("ESP_CYCLE_ID", "1")

# Variable textbox creation
dbutils.widgets.text("PROJECT","")
dbutils.widgets.text("JOB","")
dbutils.widgets.text("INVID","")
dbutils.widgets.text("ESP_CYCLE_ID","")

# Get variable values
os.environ['PROJECT'] = dbutils.widgets.get("PROJECT")
os.environ['JOB'] = dbutils.widgets.get("JOB")
os.environ['INVID'] = dbutils.widgets.get("INVID")
os.environ['ESP_CYCLE_ID'] = dbutils.widgets.get("ESP_CYCLE_ID")

# Test variables
print('---------------------------')
print('Project Name: ' + os.environ['PROJECT'])
print('Job Name: ' + os.environ['JOB'])
print('Invid: ' + os.environ['INVID'])
print('Esp Cycle ID: ' + os.environ['ESP_CYCLE_ID'])
print('---------------------------')

DBFSROOT = "/dbfs/FileStore/apps/"
# project_json = os.path.join(DBFSROOT, "projects", getArgument("PROJECT", "default_project"), "config/project.json")
project_json = os.path.join(DBFSROOT, "projects", os.environ['PROJECT'], "config/project.json")
with open(project_json, 'rb') as conf:
  project_conf = json.load(conf)
if project_conf["keyVaultSecret"] == "true":
  os.environ['API_TOKEN'] = dbutils.secrets.get(scope = project_conf["keyVaultScope"],
                                                key = project_conf["keyVaultSecret_databricksApiAccessToken"])
  os.environ['SF_USER_PWD_PASSED'] = dbutils.secrets.get(scope = project_conf["keyVaultScope"],
                                                key = project_conf["keyVaultSecret_sfPassword"]) 
  os.environ['SQ_SERVER_CLIENT_ID'] = dbutils.secrets.get(scope = project_conf["keyVaultSQScope"],
                                                key = project_conf["keyVaultSecret_sqlserverClientID"])
  os.environ['SQ_SERVER_CLIENT_SECRET'] = dbutils.secrets.get(scope = project_conf["keyVaultSQScope"],
                                                key = project_conf["keyVaultSecret_sqlserverClientSecret"]) 
else:
  os.environ['API_TOKEN'] = project_conf["databricksApiAccessToken"]
os.environ['EDWSCRIPT'] = os.path.dirname(project_conf["globalConfig"])

# COMMAND ----------

# MAGIC %sh -e $EDWSCRIPT/edw_dsjob_mgr.ksh $PROJECT $JOB $INVID $ESP_CYCLE_ID
# Databricks notebook source
import os
import json

# Initial snippet
os.environ['PROJECT'] = getArgument("PROJECT", "")
os.environ['JOB'] = getArgument("JOB", "")
os.environ['INVID'] = getArgument("INVID", "")
os.environ['ESP_CYCLE_ID'] = getArgument("ESP_CYCLE_ID", "")

# Variable textbox creation
# dbutils.widgets.text("P_PL_PROJECT_NAME","EDW_photo_prd")
# dbutils.widgets.text("P_PL_SEQ_JOB_NAME","ds_sequence_123")
# dbutils.widgets.text("P_PL_INVID","NOINV")
# dbutils.widgets.text("P_PL_ESP_CYCLE_ID","999")

# Get variable values
# os.environ['PROJECT'] = dbutils.widgets.get("P_PL_PROJECT_NAME")
# os.environ['JOB'] = dbutils.widgets.get("P_PL_SEQ_JOB_NAME")
# os.environ['INVID'] = dbutils.widgets.get("P_PL_INVID")
# os.environ['ESP_CYCLE_ID'] = dbutils.widgets.get("P_PL_ESP_CYCLE_ID")

# Test variables
print('---------------------------')
print('Project Name: ' + os.environ['PROJECT'])
print('Job Name: ' + os.environ['JOB'])
print('Invid: ' + os.environ['INVID'])
print('Esp Cycle ID: ' + os.environ['ESP_CYCLE_ID'])
print('---------------------------')

DBFSROOT = "/dbfs/FileStore/apps/"
# project_json = os.path.join(DBFSROOT, "projects", getArgument("PROJECT", "default_project"), "config/project.json")
project_json = os.path.join(DBFSROOT, "projects", os.environ['PROJECT'], "config/project.json")
with open(project_json, 'rb') as conf:
  project_conf = json.load(conf)
if project_conf["keyVaultSecret"] == "true":
  os.environ['API_TOKEN'] = dbutils.secrets.get(scope = project_conf["keyVaultScope"],
                                                key = project_conf["keyVaultSecret_databricksApiAccessToken"])
  os.environ['SF_USER_PWD_PASSED'] = dbutils.secrets.get(scope = project_conf["keyVaultScope"],
                                                key = project_conf["keyVaultSecret_sfPassword"]) 
  os.environ['SQ_SERVER_CLIENT_ID'] = dbutils.secrets.get(scope = project_conf["keyVaultSQScope"],
                                                key = project_conf["keyVaultSecret_sqlserverClientID"])
  os.environ['SQ_SERVER_CLIENT_SECRET'] = dbutils.secrets.get(scope = project_conf["keyVaultSQScope"],
                                                key = project_conf["keyVaultSecret_sqlserverClientSecret"])
else:
  os.environ['API_TOKEN'] = project_conf["databricksApiAccessToken"]
os.environ['EDWSCRIPT'] = os.path.dirname(project_conf["globalConfig"])

# COMMAND ----------

# MAGIC %sh -e $EDWSCRIPT/edw_dsjob_mgr.ksh $PROJECT $JOB $INVID $ESP_CYCLE_ID
# Databricks notebook source
import dedupeCoreProcess as dedupeops
import dataDefination as dataDef
import json
from flask_cors import CORS
from flask import Flask, jsonify, request

app = Flask(__name__)
cors = CORS(app, resources={r"/app/*": {"origins": "*"}})

@app.route('/',methods=['GET'])
def testing():
    return "Test Successful "

@app.route('/app/datadef/getdetails/<inputSource>' ,methods=['GET'])
def dataDefDetails(inputSource):
    PathSt="/webdatamnt/batchData/"+str(inputSource)
    return dataDef.dataDefFinder(PathSt)

@app.route('/app/dedupe/connectionCheck/<inputSource>' ,methods=['GET'])
def connectionCheck(inputSource):
    return str(inputSource)+" Successful"

@app.route('/app/dedupe/fieldsdisplay/<inputSource>' ,methods=['GET'])
def dedupeFieldsDisplay(inputSource):
    basePathSt="/webmnt/inputFiles/"
    URLfile=basePathSt+str(inputSource)
    return dedupeops.FieldsUsedforSetup(URLfile)
    
@app.route('/app/dedupe/aclearningchk/<inputSource>' ,methods=['GET'])
def startActiveLearning(inputSource):
    basePathSt="/webmnt/inputFiles/"
    URLfile=basePathSt+str(inputSource)
    return dedupeops.activeLearingSetup(URLfile)
    

@app.route('/app/dedupe/labled/<inputSource>', methods=['POST'])
def prLabled(inputSource):
    basePathSt="/webmnt/inputFiles/"
    URLfile=basePathSt+str(inputSource)
    content=request.get_json()
    jsonStr=json.dumps(content)
    return dedupeops.processLabled(URLfile, jsonStr)
    
    
if __name__ == '__main__':
    app.run()
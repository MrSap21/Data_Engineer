# Databricks notebook source
fileContent="The 1st line of HPSchema.pickle file"
import pickle
pickle.dump(fileContent, open("/dbfs/mnt/mountdatalake/schemaMatchingHello.pickle", 'wb'))
print("command executed without any error and the file HPSchema.pickle has been written successfully")

# COMMAND ----------

data=pickle.load(open("/dbfs/mnt/mountdatalake/HPSchema.pickle",'rb'))
print(data)
# Databricks notebook source
# MAGIC %fs unmount /mnt/mountcodebase

# COMMAND ----------

# Author: Dhiren Desai

# Define the variables used for creating connection strings
adlsAccountName = "dapdevidfadls01"
adlsContainerName = "idfappdata"
adlsFolderName = ""
mountPoint = "/mnt/idfwbadevmount"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdataenggscope",key="applicationId")

# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdataenggscope",key="devdnaadls")

# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdataenggscope",key="adtenantid")

endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}
# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)
  
#dbutils.fs.unmount("/mnt/csvFiles");
#dbutils.fs.unmount("/mnt/csvFiles1")
#display(dbutils.fs.mounts())

# COMMAND ----------

# Author: Dhiren Desai

# Define the variables used for creating connection strings
adlsAccountName = "dapdevidfadls01"
adlsContainerName = "cleansed"
adlsFolderName = ""
mountPoint = "/mnt/idfwbadevcleansedmount"

# Application (Client) ID
applicationId = dbutils.secrets.get(scope="dapdevdataenggscope",key="applicationId")

# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope="dapdevdataenggscope",key="devdnaadls")

# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope="dapdevdataenggscope",key="adtenantid")

endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName

# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}
# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)
  
#dbutils.fs.unmount("/mnt/csvFiles");
#dbutils.fs.unmount("/mnt/csvFiles1")
#display(dbutils.fs.mounts())

# COMMAND ----------

tenandId = dbutils.secrets.get(scope="dapdevdataenggscope",key="adtenantid")

endpoint = "https://login.microsoftonline.com/92cb778e-8ba7-4f34-a011-4ba6e7366996/oauth2/token"

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": "79b492f4-9f1f-4b7a-ae27-bb757857e43a",
           "fs.azure.account.oauth2.client.secret": "devdnaadls",
           "fs.azure.account.oauth2.client.endpoint": endpoint}



# COMMAND ----------

# MAGIC %fs ls /mnt/idfwbadevcleansedmount/Accenture/Ingestion/Delimited/delimeted_test_file.csv

# COMMAND ----------


dbutils.fs.mount(
  source = "abfss://idfappdata@dapdevidfadls01.dfs.core.windows.net",
  mount_point = "/mnt/mountcodebasedev/",
  extra_configs = configs)

# COMMAND ----------

#dbutils.fs.refreshMounts()
dbutils.fs.ls("/mnt/mountdatalake/")

# COMMAND ----------

dbutils.fs.put("/mnt/mountdatalake/schemaMatching/Hello.txt","Hello World", True)

# COMMAND ----------

dbutils.fs.put("/mnt/mountdatalake/Hello.txt","Hello World", True)

# COMMAND ----------

# MAGIC %sh
# MAGIC cat /dbfs/mnt/mountdatalake/mount.err

# COMMAND ----------

f= open("abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/schemaMatching/schemaMatchingInput/HP_Main.csv", 'rb')
var=r.read()
print(var)

# COMMAND ----------

# dbutils.fs.mkdirs("/mnt/mountdatalake")

# COMMAND ----------

# filepath = "/mnt/datalakemount/schemaMatching/schemaMatchingInput/HP_Main.csv"
filepath = "abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/schemaMatching/schemaMatchingInput/HP_Main.csv"
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext, Window
from pyspark import SparkConf, SparkContext
import pyspark.sql.functions as f 
spark = SparkSession.builder.master("local").appName("SchemaMatchingApplication").getOrCreate()
spark.conf.set("fs.azure.account.auth.type.idfadbworkspace.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.idfadbworkspace.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.idfadbworkspace.dfs.core.windows.net", "6a7b7707-74c7-42d3-887d-f374bf063a60")
spark.conf.set("fs.azure.account.oauth2.client.secret", "idfrgkvadb-01")
# spark.conf.set("fs.azure.account.oauth2.client.secret.idfadbworkspace.dfs.core.windows.net", dbutils.secrets.get(scope="Idfrgscope1",key="idfrgkvadb-01"))
spark.conf.set("fs.azure.account.oauth2.client.endpoint.idfadbworkspace.dfs.core.windows.net", "https://login.microsoftonline.com/dcc5be65-5889-4ef9-be02-4352e92c9f98/oauth2/token")

dnb_data_healthcare = spark.read.option("header", "true").option("inferSchema", "true").csv(filepath)
#to see distinct states abbreviation
#dnb_data_healthcare.select("`duns.state_province_abbreviation`").distinct().collect()
# dnb_data_healthcare.write.partitionBy("duns.state_province_abbreviation").format("csv").save(r'/mnt/intelligent-data-foundation/raw/dnb_data/partitions',header = 'true')
# dnb_data_healthcare.show(10)

# COMMAND ----------

dbutils.fs.ls("/mnt/mountdatalake")

# COMMAND ----------

dbutils.fs.put("/mnt/mountdatalake/Hello.txt","Hello World", True)

# COMMAND ----------

dbutils.fs.mount(
  source = "wasbs://dedupe@idfadbworkspace.dfs.core.windows.net",
  mount_point = "/mnt/dedupemount/",
  extra_configs = configs)

# COMMAND ----------



# COMMAND ----------

dbutils.fs.ls("abfss://dedupe@idfadbworkspace.dfs.core.windows.net/")

# COMMAND ----------



# COMMAND ----------

# MAGIC %fs unmount /mnt/dedupe/datastage

# COMMAND ----------

# MAGIC %fs unmount /mnt/adlsdedupe

# COMMAND ----------

# MAGIC %fs unmount /mnt/dedupe/testdata

# COMMAND ----------

# MAGIC %fs unmount /mnt/testdata

# COMMAND ----------

# MAGIC %fs unmount /mnt/idfadlsmount

# COMMAND ----------

# MAGIC %fs unmount /mnt/testdatamount

# COMMAND ----------

# MAGIC %fs unmount /mnt/idfdatamount

# COMMAND ----------

# MAGIC %fs unmount /mnt/testdatamount1

# COMMAND ----------

dbutils.fs.ls("abfss://dedupe@idfadbworkspace.dfs.core.windows.net/azure")

# COMMAND ----------

# MAGIC %fs ls /mnt/idfmount/

# COMMAND ----------

spark.conf.set("fs.azure.account.key.idfadbworkspace.dfs.core.windows.net","U51BTllKR3MLuXDjfu5GcRuBPnTbsWRlauhP+Oa3SGWLQzaAxvP8+isDBYdaeJ24IDKzZeqpGKZw864Yw7kBTA==")
spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")
dbutils.fs.ls("abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/")
spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "false")

# COMMAND ----------

dbutils.fs.ls("abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/schemaMatching")

# COMMAND ----------

dbutils.fs.ls("abfss://dedupe@idfadbworkspace.dfs.core.windows.net")
# Databricks notebook source
from datetime import datetime
import logging
import traceback
import datetime 

log_filename= "/dbfs/mnt/mountdatalake/AZ_Dataquality/log/"+"DQ_dataqulity_datasetchart_Logfile_"+(str(datetime.datetime.now())).replace(" ","")+".log"

logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

logger.info("dataqulity_datasetchart processing started")

dchart={}
Completeness=[]
Consistency=[]
Accuracy=[]
Timeliness=[]
completeness={}
consistency={}
accuracy={}
tim={}

filename=dbutils.widgets.get('file')
path=dbutils.widgets.get('path')
timestamp=dbutils.widgets.get('timestamp')
filepath = "/mnt/idfwbadevcleansedmount/"+str(path)+str(filename)
logger.debug("dataqulity_datasetchart processing started"+str(filepath))
df = spark.read.format('csv').options(header='true', inferSchema='true').load(filepath)
test_df=df
row_cnt=df.count()

# COMMAND ----------

from pyspark.sql import SparkSession, DataFrame
import os
import sys
import json
# Custom Library
sys.path.insert(0, os.path.abspath("/dbfs/mnt/mountdatalake/pydeequ"))
from base import AnalysisRunner,VerificationSuite
import analyzers as analyzers

#########dataset level caculation of completeness,uniquness and consistency etc ##########.
  # SparkSession startup
spark = (SparkSession.builder.master('local[*]').config("spark.driver.memory","4G").config("spark.driver.maxResultSize", "2G").config('spark.jars.packages','com.amazon.deequ:deequ:1.0.5').appName('dq-profiler').getOrCreate())

cols=df.columns
tmp=[]
for x in cols:
  r = AnalysisRunner(spark).onData(df).addAnalyzer(analyzers.Distinctness(x)).run()
  out1=r.successMetricsAsJson()
  tmp.append(out1)

sum=0.0
for y in tmp:
  z=json.loads(y)
  for p in z:
    sum=sum+(p['value']*100)
distinctness=sum/len(df.columns)
logger.debug("dataqulity_datasetchart distinctness processing started"+str(distinctness))
consistency['distinctness']=distinctness

# COMMAND ----------

## Completeness on Dataset 
try:
  df=df.toPandas()
  completenessDataset=(df.notna().sum().sum()/df.size) * 100
  logger.debug("dataqulity_datasetchart completenessDataset processing started"+str(completenessDataset))
  completeness['completeness']=completenessDataset
except Exception as e:
  logger.error("Exception occured details are : "+str(e))
  
## Uniquness on Dataset 
try:
  uniquness_dataset=(df.drop_duplicates().nunique().sum()/df.size)*100
  logger.debug("dataqulity_datasetchart uniquness_dataset processing started"+str(uniquness_dataset))
  consistency['uniquness']=uniquness_dataset
except Exception as e:
  logger.error("Exception occured details are : "+str(e))

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
import pyspark.sql.functions as f
from datetime import datetime
####### timeliness  for the data calculations ###########
for datatype in test_df.dtypes:
  if datatype[1] =='timestamp':
    col_name=datatype[0]
  elif datatype[1] =='Date':
    col_name=datatype[0]
  else:
    tmp_df=test_df.withColumn('insert_timestamp',f.lit(timestamp).cast('timestamp'))
    col_name='insert_timestamp'

df1 = tmp_df.withColumn("current_time",current_timestamp())
df2=df1.withColumn("time_diff", (f.col("current_time").cast("long") - f.col(col_name).cast("long"))/60.)

from pyspark.sql.functions import min, max
timeliness=df2.select("time_diff").distinct().count()
timeliness1=int(timeliness)

logger.debug("dataqulity_datasetchart uniquness_dataset processing started"+str(timeliness1))
tim['timeliness']=timeliness1

# COMMAND ----------

import numpy as np
import pandas as pd
from sklearn.datasets import load_boston,load_iris

filepath = "/dbfs/mnt/idfwbadevcleansedmount/"+str(path)+str(filename)
df = pd.read_csv(filepath)
df = pd.DataFrame(df)
###df.shape
num_train = df.select_dtypes(include=["number"])
cat_train = df.select_dtypes(exclude=["number"])
boston = df
columns = boston.columns
boston_df=df
boston_df.columns = columns
boston_df_o = boston_df
boston_df_o = df
###boston_df.shape

from scipy import stats
import numpy as np
z = np.abs(stats.zscore(num_train))

threshold = 3
##print(np.where(z > 3))
columns_rows = np.where(z > 3)

size = df.size
outlier_size = columns_rows[0].size
accuracy1 = (1-(outlier_size/size))*100
logger.info(accuracy1)
accuracy2=int(accuracy1.item())
logger.info(type(accuracy2))
accuracy['accuracy']=accuracy2

# COMMAND ----------

Completeness.append(completeness)
Consistency.append(consistency)
Accuracy.append(accuracy)
Timeliness.append(tim)
dchart['completeness']=Completeness
dchart['consistency']=Consistency
dchart['accuracy']=Accuracy
dchart['timeliness']=Timeliness
logger.info("dataqulity_datasetchart processing completed"+str(dchart))
dbutils.notebook.exit(json.dumps(dchart))
# Databricks notebook source
# MAGIC %sh
# MAGIC pip install pip==8.1.1
# MAGIC pip uninstall certifi==2019.3.9 -y
# MAGIC pip install --upgrade pip
# MAGIC pip install  -r /dbfs/mnt/mountdatalake/requirements.txt --use-feature=2020-resolver
# MAGIC #######pip install  pandas-profiling==2.9.0 --use-feature=2020-resolver

# COMMAND ----------

import sys
import os
import json
import yaml
import pandas as pd
import pandas_profiling
import numpy as np
from math import log, e
#from pandas_profiling.report import to_html
from datetime import datetime
import logging
import traceback
import datetime

# COMMAND ----------

########## Data profiling,caculation of entropy and CDE elements data.################
log_filename= "/dbfs/mnt/mountdatalake/AZ_Dataquality/log/"+"DQ_data_profiling_driver_new_Logfile_"+(str(datetime.datetime.now())).replace(" ","")+".log"

logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

logger.info("data_profiling_driver_new processing started")

filename= dbutils.widgets.get('file')
feedId=dbutils.widgets.get('feedid')
assetId=dbutils.widgets.get('assetid')
filepath = str(filename)
logger.debug("data_profiling_driver_new processing started:"+str(filepath))
df = pd.read_csv(filepath)
#df.count()

def pandas_entropy(column, base=None):
    logger.debug("pandas_entropy processing started:")
    vc = pd.Series(column).value_counts(normalize=True, sort=False)
    base = e if base is None else base
    logger.debug("pandas_entropy processing completed:")
    return -(vc * np.log(vc) / np.log(base)).sum()

import scipy.stats
def ent(data):
    logger.info(data)
    logger.debug("entropy processing started:")
    ###"""Calculates entropy of the passed `pd.Series`"""####
    p_data = data.value_counts()  # counts occurrence of each value
    entropy = scipy.stats.entropy(p_data)  # get entropy from counts
    logger.debug("entropy processing completed:")
    return entropy

# COMMAND ----------

 count_row = df.shape[0]
logger.debug("row Count is :" , count_row)

#applying the profiling function
try:
  if count_row>1:
      profile = pandas_profiling.ProfileReport(df)
      newdict3 = profile.description_set
      json_data = profile.to_json()
      final_dictionary = json.loads(json_data) 
  else:
    logger.debug("file has no rows")
except Exception as e:
    logger.error("Exception occured details are : "+str(e))
    
##### Remove scatter and correlations keys from dict #####
final_dictionary.pop('scatter','None')
final_dictionary.pop('correlations','None')
final_dictionary.pop('missing','None')
##### Remove scatter and correlations keys from dict #####

e_list=[]
sum=0.0
for i in range(len(df.columns)):
    entropy=pandas_entropy(df[df.columns[i]],base=None)
    if(entropy>0.0):
        e_list.append(entropy)
        sum=sum+entropy
        
logger.debug("mean of entropy will be threshold_value")
threshold_value=(sum/len(df.columns))
logger.info("mean of entropy will be threshold_value")
cols=[]
for i in range(len(df.columns)):
    entropy=pandas_entropy(df[df.columns[i]],base=None)
    if entropy < threshold_value:
        final_dictionary['variables'].pop(df.columns[i],'None')
    else:
      cols.append(df.columns[i])
final_dictionary['table']['cde_value']=len(final_dictionary['variables'])    

def converter_stringTolist(list):
  logger.debug("converter_stringTolist process started:")
  histogram_chart=[]
  for x in list:
    y=x.strip('][')
    y=','.join(y.split()).split(',')
    histogram_chart.append(y)
  logger.debug("converter_stringTolist process completed:")
  return histogram_chart   

logger.debug("adding histogram_chartdata to data profiling")
for p,q in final_dictionary['variables'].items():
  if 'histogram' in q.keys():
    histogram_chartdata=converter_stringTolist(q['histogram'])
    final_dictionary['variables'][p]['histogram_chartdata']=histogram_chartdata
  else:
    pass
logger.debug("adding histogram_chartdata to data profiling Done")
logger.info("data_profiling_driver_new processing new completed")

vat={}
vat['feedid']=feedId
vat['assetid']=assetId
vat['log']=json.dumps(final_dictionary)

path='/dbfs/mnt/mountdatalake/UIconf/data_quality/'
file_name="assetid"+".json"
file=path+file_name
with open(file, 'w') as fp:
  json.dump(final_dictionary, fp)
logger.info("End of file writing to json file>>>"+file)
#dbutils.notebook.exit(json.dumps(final_dictionary))

# COMMAND ----------

import sys
# Custom Library
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
# Logger function
logger = utilsShared.getFormattedLogger(__name__)
logger.info("Performing Init Activities")
envConfig = utilsShared.getEnvConf(logger,dbutils)
if "sqlserver" in envConfig.keys():
  jdbcHostname = envConfig['sqlserver']['jdbcHostname']
  jdbcDatabase = envConfig['sqlserver']['jdbcDatabase']
  jdbcPort = envConfig['sqlserver']['jdbcPort']
  sql_access_token=envConfig["sqlserver"]["sql_access_token"]
  hostNameInCertificate = envConfig['sqlserver']['hostNameInCertificate']
  jdbcUrl = envConfig['sqlserver']['jdbc-connection-string']
  jdbcUrl=jdbcUrl.format(jdbcHostname, jdbcPort, jdbcDatabase, hostNameInCertificate)
  connectionProperties = {"accessToken" : sql_access_token,"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}

va=[]
va.append(vat)
df = spark.createDataFrame(va)
df.write.format("jdbc").option("url", str(jdbcUrl)).mode('append').option("dbTable", 'idfwba.DQ_RunLog_v1' ).option("accessToken", str(sql_access_token)).save()
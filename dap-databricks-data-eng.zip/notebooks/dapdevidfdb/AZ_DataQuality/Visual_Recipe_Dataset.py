# Databricks notebook source
import os
import sys
import json
import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
import time 
from datetime import datetime
import logging
import traceback
import datetime 
from datetime import date

log_filename= "/dbfs/mnt/mountdatalake/AZ_Dataquality/log/"+"DQ_Visual_Recipe_Dataset_Logfile_"+(str(datetime.datetime.now())).replace(" ","")+".log"

logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

logger.info("Visual_Recipe_Dataset processing started")

# COMMAND ----------

filename=dbutils.widgets.get('file')
path=dbutils.widgets.get('path')
filepath = "/mnt/idfwbadevcleansedmount/"+str(path)+str(filename)
logger.debug("Visual_Recipe_Dataset processing started"+str(filepath))
####prameters for dataset#####
p_isDistinct=dbutils.widgets.get('isDistinct')
p_isNonNegative=dbutils.widgets.get('isNonNegative')
p_hasColumngreater=dbutils.widgets.get('hasColumngreater')
hasColumngreatervalue=dbutils.widgets.get('hasColumngreatervalue')
p_hasColumnlesser=dbutils.widgets.get('hasColumnlesser')
hasColumnlesservalue=dbutils.widgets.get('hasColumnlesservalue')
p_hasColumnAveragegreater=dbutils.widgets.get('hasColumnAveragegreater')
hasColumnAveragegreatervalue=dbutils.widgets.get('hasColumnAveragegreatervalue')
p_hasColumnAverageLess=dbutils.widgets.get('hasColumnAverageLess')
hasColumnAverageLessvalue=dbutils.widgets.get('hasColumnAverageLessvalue')
p_iscontainedIn=dbutils.widgets.get('iscontainedIn')
iscontainedInvlist=dbutils.widgets.get('iscontainedInvlist')
p_containsEmail=dbutils.widgets.get('containsEmail')
p_containsCreditCardNumber=dbutils.widgets.get('containsCreditCardNumber')
p_containsURL=dbutils.widgets.get('containsURL')
print(hasColumnAveragegreatervalue)
print(type(hasColumnAveragegreatervalue))
print(iscontainedInvlist)
#### END  ####
df_sample = spark.read.format('csv').options(header='true', inferSchema='true').load(filepath)
row_cnt=df_sample.count()
col_cnt=len(df_sample.columns)
df_sample.show(2,False)
visual_recipe_dataset={}

# COMMAND ----------

###########dataset level########
test_data=df_sample.toPandas()
if p_isDistinct == 'true':
  uniquness_dataset=(test_data.nunique().sum()/test_data.size)*100
  logger.debug("Visual_Recipe_Dataset uniquness_dataset started"+str(uniquness_dataset))
  visual_recipe_dataset['isDistinct']=uniquness_dataset
else:
  visual_recipe_dataset['isDistinct']=''

# COMMAND ----------

import pyspark.sql.functions as f
def isNonNegative(cols):
  cnt=0
  for col in cols:
    a = df_sample.filter(f.col(col) > 0).count()
    cnt=cnt+a
  return cnt

if p_isNonNegative == 'true':
  logger.debug("Visual_Recipe_Dataset isNonNegative started")
  positivecnt=isNonNegative(df_sample.columns)
  logger.info(positivecnt*100/(row_cnt*len(df_sample.columns)))
  logger.debug("Visual_Recipe_Dataset isNonNegative completed"+str(positivecnt))
  visual_recipe_dataset['isNonNegative']=positivecnt*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['isNonNegative']=''

# COMMAND ----------

def hasColumngreater(df,value):
  val=0
  for col in df.columns:
    logger.debug("Visual_Recipe_Dataset hasColumngreater started"+str(value)+str(value))
    cnt = df_sample.filter(f.col(col) >= value).count()
    val=val+cnt
  return val

if p_hasColumngreater == 'true':
  hasColumngreatervalue=int(hasColumngreatervalue)
  x=hasColumngreater(df_sample,hasColumngreatervalue)
  logger.debug("Visual_Recipe_Dataset hasColumngreater completed"+str(x))
  visual_recipe_dataset['hasColumngreater']=x*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['hasColumngreater']=''

# COMMAND ----------

def hasColumnlesser(df,value):
  val_1=0
  for col in df.columns:
    logger.debug("Visual_Recipe_Dataset hasColumngreater started"+str(value)+str(col))
    lesscount = df_sample.filter(f.col(col) <= value).count()
    val_1=val_1+lesscount
  return val_1

if p_hasColumnlesser == 'true':
  hasColumnlesservalue=int(hasColumnlesservalue)
  z=hasColumnlesser(df_sample,10)
  logger.debug("Visual_Recipe_Dataset hasColumnlesser completed"+str(z))
  visual_recipe_dataset['hasColumnlesser']=z*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['hasColumnlesser']=''

# COMMAND ----------

def hasColumnAveragegreater(df,value):
  logger.debug("Visual_Recipe_Dataset hasColumnAveragegreater started"+str(value))
  average_value=df.toPandas().mean()
  cnt=0
  for x in average_value:
    if x >= value:
      cnt=cnt+1
  return cnt

if p_hasColumnAveragegreater =='true':
  cnt=hasColumnAveragegreater(df_sample,400)
  g_cnt=cnt
  logger.debug("Visual_Recipe_Dataset hasColumnAveragegreater completed"+str(g_cnt))
  visual_recipe_dataset['hasColumnAveragegreater']=g_cnt*100/row_cnt
else:
  visual_recipe_dataset['hasColumnAveragegreater']=''

# COMMAND ----------

def hasColumnAverageLess(df,value):
  logger.debug("Visual_Recipe_Dataset hasColumnAverageLess started"+str(value))
  average_value=df.toPandas().mean()
  cnt=0
  for x in average_value:
    if x <= value:
      cnt=cnt+1
  return cnt

if p_hasColumnAverageLess =='true':
  hasColumnAverageLessvalue=int(hasColumnAverageLessvalue)
  l_cnt=hasColumnAverageLess(df_sample,400)
  logger.debug("Visual_Recipe_Dataset hasColumnAverageLess completed"+str(l_cnt))
  visual_recipe_dataset['hasColumnAverageLess']=l_cnt*100/row_cnt
else:
  visual_recipe_dataset['hasColumnAverageLess']=''

# COMMAND ----------

def iscontainedIn(df,vlist):
  fcnt=0
  logger.debug("Visual_Recipe_Dataset iscontainedIn started"+str(vlist))
  for col in df.columns:
    f=df[df[col].isin(vlist)].count()
    fcnt=fcnt+f
  return f

if p_iscontainedIn == 'true':
  vlist=iscontainedInvlist.split(",")
  fcnt=iscontainedIn(df_sample,vlist)
  logger.debug("Visual_Recipe_Dataset iscontainedIn completed"+str(fcnt))
  visual_recipe_dataset['iscontainedIn']=fcnt*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['iscontainedIn']=''

# COMMAND ----------

regex = r'^[_A-Za-z0-9-\\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$'
from pyspark.sql.functions import when,col,lit

def containsEmail(df,regex):
  emailcnt=0
  logger.debug("Visual_Recipe_Dataset containsEmail started")
  for col in df.columns:
    df_cnt=df.filter(df[col].rlike(regex)).count()
    emailcnt=emailcnt+df_cnt
  return emailcnt

if p_containsEmail == 'true':
  count=containsEmail(df_sample,regex)
  logger.debug("Visual_Recipe_Dataset containsEmail completed"+str(count))
  visual_recipe_dataset['containsEmail']=count*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['containsEmail']=''

# COMMAND ----------

CCregex = r'^(4[0-9]{12}(?:[0-9]{3})?)|((?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|(6(?:011|5[0-9]{2})[0-9]{12})|((?:2131|1800|35\d{3})\d{11})$'
from pyspark.sql.functions import when,col,lit
def containsCreditCardNumber (df,regex):
  cccnt=0
  logger.debug("Visual_Recipe_Dataset containsCreditCardNumber  started")
  for col in df.columns:
    df_cnt=df.filter(df[col].rlike(regex)).count()
    cccnt=cccnt+df_cnt
  return cccnt

if p_containsCreditCardNumber == 'true':
  CCcount=containsCreditCardNumber(df_sample,CCregex)
  logger.debug("Visual_Recipe_Dataset containsCreditCardNumber  completed"+str(CCcount))
  visual_recipe_dataset['containsCreditCardNumber']=CCcount*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['containsCreditCardNumber']=''

# COMMAND ----------

URLregex = r'^((?:ht|f)tps?)\:\/\/([a-zA-Z0-9\-\._]+:[a-zA-Z0-9\-\._]+@)?((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)(\/?)([a-zA-Z0-9\-\.\,\'\/\+\&%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\]*)$'
from pyspark.sql.functions import when,col,lit
def containsURL(df,regex):
  urlcnt=0
  logger.debug("Visual_Recipe_Dataset containsURL started")
  for col in df.columns:
    df_cnt=df.filter(df[col].rlike(regex)).count()
    urlcnt=urlcnt+df_cnt
  return urlcnt

if p_containsURL == 'true':
  URLcount=containsURL(df_sample,URLregex)
  logger.debug("Visual_Recipe_Dataset containsURL completed"+str(URLcount))
  visual_recipe_dataset['containsURL']=URLcount*100/(row_cnt*col_cnt)
else:
  visual_recipe_dataset['containsURL']=''

# COMMAND ----------

dbutils.notebook.exit(json.dumps(visual_recipe_dataset))
# Databricks notebook source
import sys
import os
import json
import yaml
import pandas as pd
import numpy as np
from math import log, e
from datetime import date
from datetime import datetime
import logging
import traceback
import datetime 
######### Correlation report API ##########
log_filename= "/dbfs/mnt/mountdatalake/AZ_Dataquality/log/"+"DQ_data_profiling_correlation_report_Logfile_"+(str(datetime.datetime.now())).replace(" ","")+".log"

logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

logger.info("data_profiling_correlation_report processing started")
filename=dbutils.widgets.get('file')
feedId=dbutils.widgets.get('feedid')
assetId=dbutils.widgets.get('assetid')
import numpy as n
filepath = str(filename)
logger.debug("data_profiling_correlation_report processing started"+str(filepath))
errFlag=False
try:
  df = pd.read_csv(filepath)
  df.count()
  correlation=df.corr(method ='pearson')
  result=correlation.to_dict()
  logger.debug("data_profiling_correlation_report processing completed")
except Exception as e:
  errFlag=True
  logger.error("Exception occured details are : "+str(e))
finally:
  if errFlag==False:
    logger.info("Successfully completed data_profiling_correlation_report")
    corr={}
    corr['feedid']=feedId
    corr['assetid']=assetId
    corr['corr_log']=json.dumps(result)
    #dbutils.notebook.exit(json.dumps(result))
  else:
    logger.error("data_profiling_correlation_report failed"+str(e))
    #dbutils.notebook.exit(json.dumps({"status": "ERROR"}))

# COMMAND ----------

import sys
# Custom Library
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
# Logger function
logger = utilsShared.getFormattedLogger(__name__)
logger.info("Performing Init Activities")
envConfig = utilsShared.getEnvConf(logger,dbutils)
if "sqlserver" in envConfig.keys():
  jdbcHostname = envConfig['sqlserver']['jdbcHostname']
  jdbcDatabase = envConfig['sqlserver']['jdbcDatabase']
  jdbcPort = envConfig['sqlserver']['jdbcPort']
  sql_access_token=envConfig["sqlserver"]["sql_access_token"]
  hostNameInCertificate = envConfig['sqlserver']['hostNameInCertificate']
  jdbcUrl = envConfig['sqlserver']['jdbc-connection-string']
  jdbcUrl=jdbcUrl.format(jdbcHostname, jdbcPort, jdbcDatabase, hostNameInCertificate)
  connectionProperties = {"accessToken" : sql_access_token,"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}

va=[]
va.append(corr)
df = spark.createDataFrame(va)
df.write.format("jdbc").option("url", str(jdbcUrl)).mode('append').option("dbTable", 'idfwba.DQ_RunLog_v2').option("accessToken", str(sql_access_token)).save()
# Databricks notebook source
import os
import sys
import json
import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
import time 
from datetime import datetime
import logging
import traceback
import datetime 
from datetime import date

log_filename= "/dbfs/mnt/mountdatalake/AZ_Dataquality/log/"+"DQ_Visual_Recipe_Column_Logfile_"+(str(datetime.datetime.now())).replace(" ","")+".log"
logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

# filename='groceries_small_20201105.csv'
# column_name='category'

filename=dbutils.widgets.get('file')
path=dbutils.widgets.get('path')
column_name=dbutils.widgets.get('column_name')
p_isDistinct=dbutils.widgets.get('isDistinct')
p_isNonNegative=dbutils.widgets.get('isNonNegative')
p_hasColumngreater=dbutils.widgets.get('hasColumngreater')
hasColumngreatervalue=dbutils.widgets.get('hasColumngreatervalue')
p_hasColumnlesser=dbutils.widgets.get('hasColumnlesser')
hasColumnlesservalue=dbutils.widgets.get('hasColumnlesservalue')
p_hasColumnAveragegreater=dbutils.widgets.get('hasColumnAveragegreater')
hasColumnAveragegreatervalue=dbutils.widgets.get('hasColumnAveragegreatervalue')
p_hasColumnAverageLess=dbutils.widgets.get('hasColumnAverageLess')
hasColumnAverageLessvalue=dbutils.widgets.get('hasColumnAverageLessvalue')
p_iscontainedIn=dbutils.widgets.get('iscontainedIn')
iscontainedInvlist=dbutils.widgets.get('iscontainedInvlist')
p_containsEmail=dbutils.widgets.get('containsEmail')
p_containsCreditCardNumber=dbutils.widgets.get('containsCreditCardNumber')
p_containsURL=dbutils.widgets.get('containsURL')
print(hasColumnAveragegreatervalue)
print(type(hasColumnAveragegreatervalue))

filepath = "/mnt/idfwbadevcleansedmount/"+str(path)+str(filename)
column=column_name
logger.debug("Input file"+str(filepath)+" received for processing")
logger.info("Input column you are passing:"+str(column))
try:
  df = spark.read.format('csv').options(header='true',inferSchema='true').load(filepath)
  row_cnt=df.count()
  df.show(2,False)
except Exception as e:
  logger.error("Exception occured details are : "+str(e))

# COMMAND ----------

visual_recipe_column={}

# COMMAND ----------

####### Is Distinct #########
def isDistinct(dataframe,col):
  try:
    distinct_count = dataframe.select(col).distinct().count()
    logger.debug("processing isDistinct:"+str(distinct_count))
    return distinct_count
  except Exception as e:
    logger.error("Exception occured in isDistinct details are : "+str(e))
    
if p_isDistinct == 'true':  
  f=isDistinct(df,column)
  visual_recipe_column['isDistinct']=f*100/row_cnt
else:
  visual_recipe_column['isDistinct']=''

# COMMAND ----------

############  Is non negative  ##############
import pyspark.sql.functions as f
def isNonNegative(dataframe,col):
  try:
    positiveCount = dataframe.filter(f.col(col) > 0).count()
    logger.debug("processing isNonNegative:"+str(positiveCount))
    return positiveCount
  except Exception as e:
    logger.error("Exception occured in isNonNegative details are : "+str(e))

if p_isNonNegative == 'true':    
  n=isNonNegative(df,column)
  visual_recipe_column['isNonNegative']=n*100/row_cnt
else:
  visual_recipe_column['isNonNegative']=''

# COMMAND ----------

def hasColumngreater(dataframe,col,value):
  try:
    grtResult = dataframe.filter(f.col(col) >= value).count()
    logger.debug("processing hasColumngreater:"+str(grtResult))
    return grtResult
  except Exception as e:
    logger.error("Exception occured in hasColumngreater details are : "+str(e))

if p_hasColumngreater == 'true':
  hasColumngreatervalue=int(hasColumngreatervalue)
  x=hasColumngreater(df,column,hasColumngreatervalue)
  print(x*100/row_cnt)
  visual_recipe_column['hasColumngreater']=x*100/row_cnt
else:
  visual_recipe_column['hasColumngreater']=''

# COMMAND ----------

def hasColumnlesser(dataframe,col,value):
  try:
    lessResult = dataframe.filter(f.col(col) <= value).count()
    logger.debug("processing hasColumnlesser:"+str(lessResult))
    return lessResult
  except Exception as e:
    logger.error("Exception occured in hasColumnlesser details are : "+str(e))
    
if p_hasColumnlesser == 'true':    
  hasColumnlesservalue=int(hasColumnlesservalue)
  z=hasColumnlesser(df,column,hasColumnlesservalue)
  print(z*100/row_cnt)
  visual_recipe_column['hasColumnlesser']=z*100/row_cnt
else:
  visual_recipe_column['hasColumnlesser']=''

# COMMAND ----------

# try:
#   df_sample1=df.dropDuplicates(([column])).select(column).count()
#   logger.debug("processing duplicates:"+str(df_sample1))
# except Exception as e:
#   logger.error("Exception occured in duplicates details are : "+str(e))
# visual_recipe_column['Duplicates']=df_sample1

# COMMAND ----------

def hasColumnAveragegreater(dataframe,value):
  try:
    average_value=dataframe.toPandas().mean()
    logger.debug("processing hasColumnAveragegreater.average_value:"+str(average_value))
    cnt=0
    for x in average_value:
      if x >= value:
        cnt=cnt+1
    logger.debug("processing hasColumnAveragegreater:"+str(cnt))
    return cnt
  except Exception as e:
    logger.error("Exception occured in hasColumnAveragegreater details are : "+str(e))

if p_hasColumnAveragegreater == 'true':    
  hasColumnAveragegreatervalue=int(hasColumnAveragegreatervalue)
  g_cnt=hasColumnAveragegreater(df,hasColumnAveragegreatervalue)
  logger.debug("processing hasColumnAveragegreater:"+str(g_cnt))
  visual_recipe_column['hasColumnAveragegreater']=g_cnt*100/row_cnt
else:
  visual_recipe_column['hasColumnAveragegreater']=''

# COMMAND ----------

def hasColumnAverageLess(dataframe,value):
  average_value=dataframe.toPandas().mean()
  logger.debug("processing hasColumnAverageLess.average_value:"+str(average_value))
  cnt=0
  for x in average_value:
    if x <= value:
      cnt=cnt+1
  logger.debug("processing hasColumnAverageLess:"+str(cnt))
  return cnt

if p_hasColumnAverageLess == 'true':
  hasColumnAverageLessvalue=int(hasColumnAverageLessvalue)
  l_cnt=hasColumnAverageLess(df,hasColumnAverageLessvalue)
  logger.info(l_cnt*100/row_cnt)
  visual_recipe_column['hasColumnAverageLess']=l_cnt*100/row_cnt
else:
  visual_recipe_column['hasColumnAverageLess']=''

# COMMAND ----------

#vlist=['1','2','6','14']
def iscontainedIn(dataframe,col1,vlist):
  logger.debug("processing iscontainedIn:"+str(col1))
  f=dataframe[dataframe[col1].isin(vlist)].count()
  return f

print(p_iscontainedIn)
print(type(p_iscontainedIn))
if p_iscontainedIn == 'true':
  vlist=iscontainedInvlist.split(",")
  cnt=iscontainedIn(df,column,vlist)
  logger.debug("processing iscontainedIn completed:"+str(cnt))
  visual_recipe_column['iscontainedIn']=cnt*100/row_cnt
else:
  visual_recipe_column['iscontainedIn']=''

# COMMAND ----------

regex = r'^[_A-Za-z0-9-\\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$'
from pyspark.sql.functions import when,col,lit
def containsEmail(dataframe,col,regex):
  logger.debug("processing containsEmail:"+str(col))
  df_cnt=dataframe.filter(dataframe[col].rlike(regex)).count()
  return df_cnt

if p_containsEmail == 'true':
  count=containsEmail(df,column,regex)
  logger.debug("processing containsEmail completed:"+str(count))
  visual_recipe_column['containsEmail']=count*100/row_cnt
else:
  visual_recipe_column['containsEmail']=''

# COMMAND ----------

CCregex = r'^(4[0-9]{12}(?:[0-9]{3})?)|((?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|(6(?:011|5[0-9]{2})[0-9]{12})|((?:2131|1800|35\d{3})\d{11})$'
from pyspark.sql.functions import when,col,lit

def containsCreditCardNumber(dataframe,col,regex):
  logger.debug("processing containsCreditCardNumber:"+str(col))
  df_cnt=dataframe.filter(dataframe[col].rlike(regex)).count()
  return df_cnt

if p_containsCreditCardNumber == 'true':
  CCcount=containsCreditCardNumber(df,column,CCregex)
  logger.debug("processing containsCreditCardNumber completed:"+str(CCcount))
  visual_recipe_column['containsCreditCardNumber']=CCcount*100/row_cnt
else:
  visual_recipe_column['containsCreditCardNumber']=''

# COMMAND ----------

URLregex = r'^((?:ht|f)tps?)\:\/\/([a-zA-Z0-9\-\._]+:[a-zA-Z0-9\-\._]+@)?((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)(\/?)([a-zA-Z0-9\-\.\,\'\/\+\&%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\]*)$'
from pyspark.sql.functions import when,col,lit

def containsURL(dataframe,col,regex):
  logger.debug("processing containsURL started:"+str(col))
  df_cnt=dataframe.filter(dataframe[col].rlike(regex)).count()
  return df_cnt

if p_containsURL == 'true':
  URLcount=containsURL(df,column,URLregex)
  logger.debug("processing containsURL completed:"+str(URLcount))
  visual_recipe_column['containsURL']=URLcount*100/row_cnt
else:
  visual_recipe_column['containsURL']=''

# COMMAND ----------

dbutils.notebook.exit(json.dumps(visual_recipe_column))
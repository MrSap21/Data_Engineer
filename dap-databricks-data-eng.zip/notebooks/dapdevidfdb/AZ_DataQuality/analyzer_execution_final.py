# Databricks notebook source
import traceback
import logging
import datetime
from datetime import date
import time
import hashlib
import json
import os
import sys

######### Correlation report API ##########
log_filename= "/dbfs/mnt/mountdatalake/AZ_Dataquality/log/"+"DQ_analyzer_execution_final_Logfile_"+(str(datetime.datetime.now())).replace(" ","")+".log"

logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

logger.info("DQ analyzer_execution_final processing started")
filename=dbutils.widgets.get('file')
path=dbutils.widgets.get('path')
column_name=dbutils.widgets.get('column_name')
timestamp=dbutils.widgets.get('timestamp')
logger.info("Input file"+str(filename)+" received for processing")
logger.info("Input column"+str(column_name)+" received for processing")
filepath = "/mnt/idfwbadevcleansedmount/"+str(path)+str(filename)
logger.debug("processing input file for dq:"+str(filepath))
df = spark.read.format('csv').options(header='true', inferSchema='true').load(filepath)

# COMMAND ----------

def finddatatype(df,col):
  for x in df.dtypes:
    if x[0]==col:
      dtype=x[1]
    else:
      pass
  return dtype

# COMMAND ----------

from pyspark.sql import SparkSession, DataFrame
import os
import sys
import json
# Custom Library
sys.path.insert(0, os.path.abspath("/dbfs/mnt/mountdatalake/pydeequ"))
from base import AnalysisRunner,VerificationSuite
from profiler import ColumnProfilerRunner
import analyzers as analyzers
import checks

####### column leve completeness,uniqueness and distinctness values and also finding data type range.
errFlag=False
try:
    # SparkSession startup
  spark = (SparkSession.builder.master('local[*]').config("spark.driver.memory","4G").config("spark.driver.maxResultSize", "2G").config('spark.jars.packages','com.amazon.deequ:deequ:1.0.5').appName('dq-profiler').getOrCreate())

  column=column_name
  #####Example: [a, a, b] contains one unique value b, so uniqueness is 1/3
  #####Example: [a, a, b] contains two distinct value a,b, so distinctness is 2/3
  logger.info("start execution of AnalysisRunner start")
  r = AnalysisRunner(spark).onData(df).addAnalyzer(analyzers.Size()).addAnalyzer(analyzers.Completeness(column)).addAnalyzer(analyzers.Uniqueness([column])).addAnalyzer(analyzers.Distinctness(column)).addAnalyzer(analyzers.DataType(column)).addAnalyzer(analyzers.Mean(column)).addAnalyzer(analyzers.StandardDeviation(column)).run()

  out1=r.successMetricsAsJson()
  x=json.loads(out1) 
  logger.info("completed execution of AnalysisRunner")


  size=df.select(column_name).count()
  coldtype=finddatatype(df,column)

  chart={}
  completeness={}
  Completeness=[]
  consistency={}
  Consistency=[]
  accuracy={}
  Accuracy=[]
  tim={}
  Timeliness=[]
  
  for z in x:
    if 'Completeness' in z['name']:
      completeness['completeness']=z['value']*100
      logger.info("adding Completeness kpi value")
      Completeness.append(completeness)
    elif 'Uniqueness' in z['name']:
      consistency['uniqueness']=z['value']*100
      logger.info("adding Uniqueness kpi value")
    elif 'Distinctness' in z['name']:
      consistency['distinctness']=z['value']*100
      logger.info("adding distinctness kpi value")
    elif 'StandardDeviation' in z['name']:
      standardDeviation=z['value']
    elif 'Mean' in z['name']:
      mean=z['value']
    elif 'Histogram.ratio.Boolean' in z['name']:
      boolean_dtype=z['value']
    elif 'Histogram.ratio.Fractional' in z['name']:
      fractional_dtype=z['value']
    elif 'Histogram.ratio.Integral' in z['name']:
      integral_dtype=z['value']
    elif 'Histogram.ratio.Unknown' in z['name']:
      unknown_dtype=z['value']
    elif 'Histogram.ratio.String' in z['name']:
      string_dtype=z['value']
    else:
      pass

  #print(coldtype)
  if(coldtype=="int"):
    dtype=integral_dtype
  elif (coldtype=="double" or coldtype=="float"):
    dtype=fractional_dtype
  elif (coldtype=="string"):
    dtype=string_dtype
  else:
    pass
  #print(dtype)
  logger.debug("caculation of value range start:")
  value_range1 =mean+(3*standardDeviation)
  value_range2 =mean-(3*standardDeviation)
  tdf1=df.filter(df[column] > value_range1).count() 
  tdf2=df.filter(df[column] < value_range2).count() 
  rangevalue=(size-tdf1-tdf2)/size
  logger.debug("caculation of value range completed:"+str(rangevalue))

  consistency['value_range']=rangevalue*100
  consistency['datatype']=dtype*100
  Consistency.append(consistency)
  chart['size']=size
  ###
  from pyspark.sql.functions import current_timestamp
  import pyspark.sql.functions as f
  from datetime import datetime
  ####### timeliness  for the data calculations ###########
  test_df=df
  for datatype in test_df.dtypes:
    if datatype[1] =='timestamp':
      col_name=datatype[0]
    elif datatype[1] =='Date':
      col_name=datatype[0]
    else:
      tmp_df=test_df.withColumn('insert_timestamp',f.lit(timestamp).cast('timestamp'))
      col_name='insert_timestamp'

  df1 = tmp_df.withColumn("current_time",current_timestamp())
  df2=df1.withColumn("time_diff", (f.col("current_time").cast("long") - f.col(col_name).cast("long"))/60.)

  from pyspark.sql.functions import min, max
  timeliness=df2.select("time_diff").distinct().count()
  timeliness1=int(timeliness)

  logger.debug("dataqulity_datasetchart uniquness_dataset processing started"+str(timeliness1))
  tim['timeliness']=timeliness1
  Timeliness.append(tim)
  ###
  ###
  import numpy as np
  import pandas as pd
  from sklearn.datasets import load_boston,load_iris

  filepath = "/dbfs/mnt/idfwbadevcleansedmount/"+str(path)+str(filename)
  df = pd.read_csv(filepath)
  df = pd.DataFrame(df)
  ###df.shape
  num_train = df.select_dtypes(include=["number"])
  cat_train = df.select_dtypes(exclude=["number"])
  boston = df
  columns = boston.columns
  boston_df=df
  boston_df.columns = columns
  boston_df_o = boston_df
  boston_df_o = df
  ###boston_df.shape

  from scipy import stats
  import numpy as np
  z = np.abs(stats.zscore(num_train))

  threshold = 3
  ##print(np.where(z > 3))
  columns_rows = np.where(z > 3)

  size = df.size
  outlier_size = columns_rows[0].size
  accuracy1 = (1-(outlier_size/size))*100
  logger.info(accuracy1)
  accuracy2=int(accuracy1.item())
  logger.info(type(accuracy2))
  accuracy['accuracy']=accuracy2
  Accuracy.append(accuracy)
  ###
  chart['completeness']=Completeness
  chart['consistency']=Consistency
  chart['accuracy']=Accuracy
  chart['timeliness']=Timeliness
  logger.debug("processing input file for dq:"+str(chart))
  logger.info("DQ analyzer_execution_final processing completed")
except Exception as e:
  errFlag=True
  logger.error("Exception occured details are : "+str(e))
finally:
  if errFlag==False:
    logger.info("Successfully completed the chart data preparation")
    dbutils.notebook.exit(json.dumps(chart))
  else:
    logger.info("chart data request got failed")
    dbutils.notebook.exit(json.dumps({"status": "ERROR"}))
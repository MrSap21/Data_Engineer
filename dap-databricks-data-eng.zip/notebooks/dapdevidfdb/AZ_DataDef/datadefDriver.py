# Databricks notebook source
import traceback
import logging
import datetime
from datetime import date
import time
import hashlib
import json
import os
import sys
log_filename= "/dbfs/mnt/mountdatalake/AZ_DataDef_Mod/log/"+"DataDef-Logfile-"+(str(datetime.datetime.now())).replace(" ","")+".log"

logger = logging.getLogger(__name__)
logging.basicConfig(filename=log_filename, filemode='w',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

sys.path.insert(0, os.path.abspath("/dbfs/mnt/mountdatalake/AZ_DataDef_Mod/code"))
logger.info("Added dependend modules into the system path")
dataUI=json.dumps({})
errFlag=False
try:
  import datadef as data
  inputFile=dbutils.widgets.get('filename')
  logger.info("Input file"+str(inputFile)+" received for processing")
  basePath="dbfs:/mnt/mountdatalake/batchData/"
  filePath=basePath+str(inputFile)
  dataUI=data.dataDefFinder(filePath)
  logger.debug("Response data for UI: "+dataUI)
except Exception as e:
  errFlag=True
  logger.error("Exception occured details are : "+str(e))
finally:
  if errFlag==False:
    logger.info("Successfully completed the Data Defination Operation")
    dbutils.notebook.exit(dataUI)
  else:
    logger.info("Operation not successful")
    dbutils.notebook.exit(json.dumps({"status": "ERROR"}))
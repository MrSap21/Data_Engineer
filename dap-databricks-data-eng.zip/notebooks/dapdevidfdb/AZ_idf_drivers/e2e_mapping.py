# Databricks notebook source
import os
import json
import glob

list_of_triggers=[]
trigger_path="C:\\Users\\vn50lsg\\idf\\arm\\trigger\\"
r2c_json_path="C:\\Users\\vn50lsg\\idf\\dataintegration\\data-conf-ingestion\\"
output_result="C:\\Users\\vn50lsg\\idf\\e2e_mapping.json"
lst_trg_dict=[]
trigger_dict={}
final_list=[]
final_dict={}

def gen_list_of_trgr(trigger_path):
    list_of_triggers=[]
    for r,d,f in os.walk(trigger_path):
        for file in f:
            if ".json" in file:
                list_of_triggers.append(os.path.join(r,file))
    return list_of_triggers

def gen_trigger_dict(list_of_triggers):
    lst_trg_dict=[]
    trigger_dict={}
    for trg in list_of_triggers:
        trigger_config = open(str(trg),'r').read()
        trigger_config_json = json.loads(trigger_config)
        #print(trigger_config_json)

        trigger_nm=trigger_config_json["name"]
        print(trigger_nm)
        pipeline_nm='NA'
        src_file_nm='NA'
        src_file_prefix='NA'
        src_id='NA'
        try:
            pipeline_ref_len=len(trigger_config_json["properties"]["pipelines"]) if "pipelines" in trigger_config_json["properties"] else len(trigger_config_json["properties"]["pipeline"])
            if pipeline_ref_len>0:
                pipeline_nm=trigger_config_json["properties"]["pipelines"][0]["pipelineReference"]["referenceName"] if "pipelines" in trigger_config_json["properties"] else trigger_config_json["properties"]["pipeline"]["pipelineReference"]["referenceName"] 
                if "parameters" in trigger_config_json["properties"]["pipelines"][0]:
                    if "prm_p_src_file_name" in trigger_config_json["properties"]["pipelines"][0]["parameters"]:
                        src_file_nm=trigger_config_json["properties"]["pipelines"][0]["parameters"]["prm_p_src_file_name"]
                    if "prm_p_file_prefix" in trigger_config_json["properties"]["pipelines"][0]["parameters"]:
                        src_file_prefix=trigger_config_json["properties"]["pipelines"][0]["parameters"]["prm_p_file_prefix"]
                    if "prm_p_src_id" in trigger_config_json["properties"]["pipelines"][0]["parameters"]:
                        src_id=trigger_config_json["properties"]["pipelines"][0]["parameters"]["prm_p_src_id"]
        except:
            src_file_nm=src_file_nm
            src_file_prefix=src_file_prefix
            src_id=src_id
        trigger_dict={"trigger_nm":trigger_nm,"pipeline_nm":pipeline_nm,"src_file_nm":src_file_nm,"r2c_config":src_file_prefix,"src_id":src_id}

        lst_trg_dict.append(trigger_dict)
    return lst_trg_dict

def gen_final_dict(lst_trg_dict,r2c_json_path):
    final_list=[]
    for conf in lst_trg_dict:
        config_path=r2c_json_path+"*"+conf["r2c_config"]+"*.json"
        list_of_config=glob.glob(config_path)
        for config in list_of_config:
            r2c_config = open(str(config),'r').read()
            r2c_config_json = json.loads(r2c_config)
            curated_path='NA'
            tgt_dir='NA'
            if "M3-ingestion-load" in r2c_config_json:
                if "curated-path" in r2c_config_json["M3-ingestion-load"]:
                    curated_path=r2c_config_json["M3-ingestion-load"]["curated-path"]
                if "target-dir" in r2c_config_json["M3-ingestion-load"]:
                    tgt_dir=r2c_config_json["M3-ingestion-load"]["target-dir"]
            conf["curated_path"]=curated_path
            conf["tgt_dir"]=tgt_dir
            final_list.append(conf)
    return final_list


list_of_triggers=gen_list_of_trgr(trigger_path)
lst_trg_dict=gen_trigger_dict(list_of_triggers)
final_list=gen_final_dict(lst_trg_dict,r2c_json_path)
print(final_list)

f=open(output_result,'a')
for conf in final_list:
    str_conf=conf["pipeline_nm"]+","+conf["src_id"]+","+conf["src_file_nm"]+","+conf["curated_path"]+","+conf["tgt_dir"]+","+conf["trigger_nm"]+","+conf["r2c_config"]
    f.write(str_conf+"\n")
f.close()
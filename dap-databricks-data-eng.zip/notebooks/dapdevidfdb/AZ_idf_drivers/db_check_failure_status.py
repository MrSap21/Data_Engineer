# Databricks notebook source
error_code = dbutils.widgets.get('prm_act_error_code')
status_desc = dbutils.widgets.get('prm_act_status_desc')
validation_error_code=("123","124","125","126","0")

print(status_desc)
print(error_code)

if error_code not in validation_error_code:
  raise Exception(" Job is failed in earlier Activity with - " + str(status_desc))
  pass
else:
    pass
print("Script Completed : " + str(status_desc))

try:
  dbutils.notebook.exit(error_code)
except:
  pass
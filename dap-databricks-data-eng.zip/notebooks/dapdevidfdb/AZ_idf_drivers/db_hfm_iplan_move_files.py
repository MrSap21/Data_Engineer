# Databricks notebook source
import sys
import json
import os 

src_period = dbutils.widgets.get("prm_act_period")
src_year = dbutils.widgets.get("prm_act_year")
raw_path = dbutils.widgets.get("prm_act_raw_path")
hfm_file_type = dbutils.widgets.get("prm_act_file_prefix")
batch_date = dbutils.widgets.get("prm_act_batchdate")
raw_path_temp = dbutils.widgets.get("prm_act_raw_tmp_path")

sys.path.insert(0, '/dbfs/Test/dataintegration/conf/')
import utilsShared

# Read the env Config Properties
envConfig = utilsShared.getEnvConf(0,dbutils)

sys.path.insert(0, envConfig["data_conf_ing_path"])

config_path = envConfig["data_conf_ing_path"] + 'hfm_iplan_filelist_rawtocurated.json'
print(config_path)
config_file=None
if os.path.isfile(config_path):
        config_file = open(str(config_path),'r').read()
        config = json.loads(config_file)
raw_tmp_path = '/mnt/fcp/' + str(raw_path_temp) + '/'
print(raw_tmp_path)
print(config_file)

import datetime
dt = datetime.datetime.now()
hr_min = str(dt.strftime('%H%M'))

file_list=None
if hfm_file_type == 'intl_mkt_iplanv2':
  file_list = config['iplan_files']['intl_mkt_iplanv2']
elif hfm_file_type == 'hfmadj':
  file_list = config['iplan_files']['adj_iplanv2']
elif hfm_file_type == 'hfmalldata':
  file_list = config['iplan_files']['alldata_iplanv2']

print(file_list)
for f in file_list:
  try:
    dbutils.fs.cp("dbfs:" + raw_tmp_path + str(f) + "_Per" + src_period + "_" + src_year + ".txt", "/mnt/" + raw_path + "/" + str(f) + "_Per" + src_period + "_" + src_year + "_" + batch_date + '_' + hr_min + ".txt", True)
  except:
    print('No file present ' + str(f))
# Databricks notebook source
import time
import os
import sys
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType

# from elasticsearch import Elasticsearch

from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import lit, col, lower, trim, coalesce,upper, when,substring
import hashlib
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import *
# Custom Library
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
# Logger function
logger = utilsShared.getFormattedLogger(__name__)

# COMMAND ----------

db="idfwba"
tbl="abinitio_employee_mst"
tableName_stg=db+"_stg."+tbl+"_stg"
tgt_table=db+tbl

envConfig = utilsShared.getEnvConf(logger,dbutils)

source_df1 = spark.read.format('jdbc').option('url',str(envConfig["sqlserver"]["connection-string"])).option('dbtable',str(tableName_stg)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').option("accessToken", str(envConfig["sqlserver"]["access_token"])).load()
source_df1.show()
source_df1.write.format("jdbc").option("url", str(envConfig["sqlserver"]["connection-string"])).mode("append").option("dbTable", tgt_table ).option("accessToken", str(envConfig["sqlserver"]["access_token"])).save()

pushdown_query = "Truncate table"+tableName_stg
connectionProperties = {"accessToken" : str(envConfig["sqlserver"]["access_token"]),"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}

df = spark.read.jdbc(url=str(envConfig["sqlserver"]["connection-string"]), table=pushdown_query, properties=connectionProperties)

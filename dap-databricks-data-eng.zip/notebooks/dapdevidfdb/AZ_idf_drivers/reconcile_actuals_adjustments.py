# Databricks notebook source
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,lit, monotonically_increasing_id, broadcast
import logging
from pyspark.sql.types import *
import sys
import json
from datetime import datetime
from collections import OrderedDict
import hashlib
import time
import os
import pandas as pd

job_start_date=str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
millis = int(round(time.time() * 1000))
prcs_id=str(hashlib.md5(str(millis).encode()).hexdigest())

dbutils.widgets.text("batch_date", "")
dbutils.widgets.text("sub_month", "")
dbutils.widgets.text("run_mode", "")
dbutils.widgets.text("segment", "")

batch_date=dbutils.widgets.get("batch_date")
run_mode=dbutils.widgets.get("run_mode")
sub_month=dbutils.widgets.get("sub_month")
seg_nm=dbutils.widgets.get("segment")


''' logger info'''
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s')
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

def get_run_year_period(batch_date, sub_month, logger):
  year_raw=int(batch_date[0:4])
  period_raw=int(batch_date[4:6])
  day_raw=int(batch_date[6:8])
  sub_month_raw=int(sub_month)
  
  sub_months_final = sub_month_raw + 2 if day_raw > 16 else sub_month_raw + 3
  if period_raw - sub_months_final <= 0:
    year_final = year_raw
    period_final = 12 if (period_raw - sub_months_final) == 0 else  (period_raw - sub_months_final) % 12
  else:
    year_final = year_raw + 1
    period_final = period_raw - sub_months_final
  
  logger.info("Running reconciliation process for fiscal year: " + str(year_final) + " and fiscal period: " + str(period_final))
  return str(year_final), str(period_final)

fyear, period = get_run_year_period(batch_date, sub_month, logger)
prof_ctr_max_from_dt = str(int(fyear) - 1) + "-" + str(int(period) + 2).rjust(2, '0') + "-05"
logger.info("Max from_dt to be used for profit_ctr table is: " + prof_ctr_max_from_dt)

# COMMAND ----------

#Define lookup table views
#Creating Temp and dataframe for Look up table cost center hierarchy
prof_ctr=spark.read.parquet("/mnt/fcp/parquet/ww_fin_dl_tables/fin_profit_cntr/")
prof_ctr.createOrReplaceTempView("prof_ctr")
connection_string="jdbc:sqlserver://gbs-financeconnectedplatform-dev-dw.database.windows.net:1433;database=cpdwuat;user=DevLoadUserMRC@gbs-financeconnectedplatform-dev-dw;password=Str0ngP@ssw0rd1!;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
driver='com.microsoft.sqlserver.jdbc.SQLServerDriver'
gcoa_hrchy=spark.read.format('jdbc').option('url',connection_string).option('dbtable',"ww_fin_fcp_rpt_tables.fcp_drm_gcoa_hrchy_flatten_v").option('driver',driver).load()
gcoa_hrchy.createOrReplaceTempView("gcoa_hrchy")
ent_hrchy=spark.read.format('jdbc').option('url',connection_string).option('dbtable',"ww_fin_fcp_rpt_tables.fcp_drm_entity_hrchy_flatten_v").option('driver',driver).load()
ent_hrchy.createOrReplaceTempView("ent_hrchy")
exs=spark.read.format('jdbc').option('url',connection_string).option('dbtable',"ww_fin_fcp_tables.FCP_FXRATES_REF").option('driver',driver).load()
exs.createOrReplaceTempView("exch_rate_sap")
ss_col_list="PERIOD, FISCYEAR, GL_ACCOUNT, PROFIT_CTR, COMP_CODE, MTD_USGAAP_LC, MTD_USGAAP_GC, COUNTRY, CURRENCY, fin_year, fin_mth"

# COMMAND ----------

config_json="""{
  "reconciliation_output_path":"/mnt/fcp/dev/reconciliation/{run_date}/run_{run_timestamp}/",
  "recon_source_name":"hfm_alldata",
  "recon_folder_path":"/mnt/fcp/test_fcp/curated/hfm/alldata/hfm_alldata/",
  "agg_query":"
  SELECT 
  {fyear} AS FISCAL_YR,
  {period} AS FISCAL_PERIOD,
  GL_ACCT,
  RECON_AMT_YTD
  FROM
      (SELECT 
      GL_ACCT,
      ABS(CAST(SUM(AMT) AS DECIMAL(20,2))) RECON_AMT_YTD
      FROM recon_df
      LEFT JOIN gcoa_hrchy
      ON recon_df.GL_ACCT=gcoa_hrchy.GL
      WHERE {filter_str}
      {adjustment_filter_str}
      AND gcoa_hrchy.GL IS NOT NULL
      AND gcoa_hrchy.lvl1 LIKE '%Income%'
      AND FISCAL_YR = {fyear}
      AND RIGHT(FISCAL_PERIOD,2) <= {period}
      GROUP BY 1)
  ",
  "join_cols":["FISCAL_YR", "FISCAL_PERIOD", "GL_ACCT"],
  "filters":["SRC_FILENAME LIKE '%AllData%'"],
  "recon_filter_col":"CNTRY",
  "recon_filter_vals":{
    "actuals":{
      "Corp":"'Corp_Seg'",
      "WMT_US":"'WMT_US_Seg'",
      "Sams":"'Sams_Seg'"
    },
    "adjustments":{
      "Corp":"'Corp_Adj'",
      "WMT_US":"'Wmt_US_Adj'",
      "Sams":"'Sams_US_Adj'"
    }
  },
  "year_col":"FISCAL_YR",
  "period_col":"FISCAL_PERIOD",
  "curated_sources":{
    "hfm_adj": {
      "source_name": "hfm_adj",
      "data": [
       { "view_name": "hfm_adj",
        "folder_path": "/mnt/fcp/test_fcp/curated/hfm/adjustments/hfm_adj/"
       }
      ],
      "agg_query":"
SELECT 
  {fyear} AS FISCAL_YR,
  {period} AS FISCAL_PERIOD,
  GL_ACCT,
  'HFM_ADJ' AS Location,
  Lgl_Entity,
  CASE WHEN LEFT(GL_ACCT,1) = '6' THEN CURATED_AMT_YTD * -1 ELSE CURATED_AMT_YTD END AS CURATED_AMT_YTD
  FROM
      (SELECT 
      GL_ACCT,
      CNTRY Lgl_Entity,
      SUM(AMT) CURATED_AMT_YTD
      FROM hfm_adj
      WHERE (SRC_FILENAME LIKE '%sLedg_Dom_Adj%' OR SRC_FILENAME LIKE '%sLedg_Dom_ROICash%' OR SRC_FILENAME LIKE '%US_Manufacturing_Total_Adjustments%' OR SRC_FILENAME LIKE '%US_Manufacturing_Total_BrandExtract%')
      {adjustment_filter_str}
      AND FISCAL_YR = {fyear}
      AND RIGHT(FISCAL_PERIOD,2) = {period}
      AND freq='YTD'
      GROUP BY 1,2)      
      "
    },
    "smartspend_lcgc_actual": {
      "source_name":"smartspend_lcgc_actual",
      "data":[
        {"view_name":"ss_gbl_src",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/smartspend/sap/gbl_src_actl/"
        },
        {"view_name":"ss_mx",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/smartspend/sap/gbl_mexico_actl/"
        },
        {"view_name":"ss_latam",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/smartspend/sap/gbl_latam_actl/"
        },
        {"view_name":"ss_ind",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/smartspend/sap/gbl_india_actl/"
        },
        {"view_name":"ss_ca",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/smartspend/sap/gbl_canada_actl/"
        },
        {"view_name":"ss_uk",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/smartspend/sap/gbl_uk_actl/"
        }
      ],
      "agg_query":"SELECT 
{fyear} FISCAL_YR,
{period} FISCAL_PERIOD,
GL_ACCT,
Location,
Lgl_Entity,
SUM(CASE WHEN LC_FLG = 'Y' THEN MTD_USGAAP_LC * SAP_CONV_RT ELSE MTD_USGAAP_GC END) CURATED_AMT_YTD
FROM
	  (select right(smartspend_lcgc_actual.PERIOD,2) FISCAL_PERIOD, 
	  FISCYEAR FISCAL_YR,
	  regexp_replace(GL_ACCOUNT,'^0*','') as GL_ACCT,
	  SUBSTRING(PROFIT_CTR,1,2) || '.' || SUBSTRING(PROFIT_CTR,3,5) AS Location,
      COMP_CODE Lgl_Entity,
	  MTD_USGAAP_LC,
      MTD_USGAAP_GC,
      1 / exch_rate_sap.FX_RATE AS SAP_CONV_RT,
      CASE WHEN SRC_FILE IN ('LATAM', 'UK', 'MX', 'IND', 'GBL_SRC')  THEN 'Y' ELSE 'N' END AS LC_FLG
	  from  (select {ss_col_list}, 'UK' as SRC_FILE from ss_uk UNION ALL (select {ss_col_list}, 'GBL_SRC' as SRC_FILE from ss_gbl_src UNION ALL  (select {ss_col_list}, 'MX' as SRC_FILE from ss_mx UNION ALL (select {ss_col_list}, 'LATAM' as SRC_FILE from ss_latam UNION ALL (select {ss_col_list}, 'IND' as SRC_FILE from ss_ind UNION ALL (select {ss_col_list}, 'CA' as SRC_FILE from ss_ca )))))) smartspend_lcgc_actual 
      LEFT JOIN (select * from exch_rate_sap where Rate_Type = 'AvgRate' and CAL_TYPE = 'CalendarRate') exch_rate_sap
      on TRIM(CASE WHEN smartspend_lcgc_actual.COUNTRY = 'CR' THEN 'CRC' WHEN smartspend_lcgc_actual.COUNTRY = 'GB' THEN 'GBP' WHEN smartspend_lcgc_actual.COUNTRY = 'MX' THEN 'MXN' ELSE smartspend_lcgc_actual.CURRENCY END)=TRIM(exch_rate_sap.FROM_CRNCY_CD) and smartspend_lcgc_actual.fin_mth=exch_rate_sap.PERIOD
      where
      FISCYEAR = {fyear} 
      and RIGHT(smartspend_lcgc_actual.PERIOD,2) <= {period}
      and SRC_FILE NOT IN ('US', 'PR'))
GROUP BY FISCAL_YR, FISCAL_PERIOD, GL_ACCT, Location, Lgl_Entity"
	  }
    ,
    "sledge":{
      "source_name":"sledge",
      "data":[
        {
        "view_name":"sledge",
        "folder_path":"/mnt/fcp/test_fcp/curated/essbase/sledge/incremental/sledge_sap_gl_us_pr_incremental/"
        }       
      ],
      "agg_query":"
      SELECT 
      {fyear} FISCAL_YR,
      {period} FISCAL_PERIOD,
      gl_acct_ GL_ACCT,
      Location,
      'NA_SLEDG' Lgl_Entity,
      SUM(amount) CURATED_AMT_YTD
      FROM (select *, CASE WHEN UPPER(LEFT(gl_acct,1))='A' THEN SUBSTRING(gl_acct, 2, length(gl_acct) - 1) ELSE gl_acct END AS gl_acct_ from sledge) sledge
      WHERE sledge.Trans_Type IN ('GL')
      AND ( '20' || RIGHT(fin_year,2)) = {fyear}
      AND fin_mth <= {period}
      GROUP BY 1,2,3,4,5
      "
    }    
  }
}""".replace('{ss_col_list}', ss_col_list)

# COMMAND ----------

config=json.loads(config_json, strict=False)

# COMMAND ----------

recon_df=spark.read.format("parquet").load(config['recon_folder_path'])

# COMMAND ----------

recon_df.createOrReplaceTempView("recon_df")
recon_df.cache()

# COMMAND ----------

display(recon_df)

# COMMAND ----------

def create_auditRecord(reconciliation):
  audit_doc=OrderedDict()
  
  
  audit_doc['PRCS_NAME']=reconciliation['PRCS_NAME']
  audit_doc['FILE_NAME']=""
  audit_doc['BATCH_DATE']=datetime.today().strftime('%Y-%m-%d')
  audit_doc['SOURCE_NAME']=""
  audit_doc['PRCS_EXECUTION_ID']=  reconciliation['PRCS_EXECUTION_ID']
  audit_doc['PIPELINE_NAME']=dbutils.widgets.get("pipeline_name")
  audit_doc['TRIG_NAME']=dbutils.widgets.get("trigger_name")
  audit_doc['STATUS']=reconciliation['STATUS']
  audit_doc['STATUS_DESC']= 'Reconciliation success.' if reconciliation['STATUS'] == 'Succeeded' else 'Not all accounts reconciled successfully.'
  audit_doc['JOB_START_TIME']=reconciliation['JOB_START_TIME']
  audit_doc['JOB_END_TIME']=str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
  audit_doc['SOURCE_PATH']=""
  audit_doc['SOURCE_ROW_COUNT']=""
  audit_doc['SOURCE_COL_COUNT']=""
  audit_doc['SOURCE_AMOUNT']=""
  audit_doc['SOURCE_FILE_SIZE']=""
  audit_doc['DEST_PATH']=""
  audit_doc['DEST_ROW_COUNT']=""
  audit_doc['DEST_COL_COUNT']=""
  audit_doc['DEST_AMOUNT']=""
  audit_doc['DEST_FILE_SIZE']=""
  audit_doc['REJECTED_ROW_COUNT']=""
  audit_doc['REJECTED_FILE_COUNT']=""
  audit_doc['LOG_PATH']=reconciliation['LOG_PATH']
  
  audit_df=spark.createDataFrame([audit_doc], StructType([
    StructField('PRCS_NAME', StringType(), True),
    StructField('FILE_NAME', StringType(), True),
    StructField('BATCH_DATE', StringType(), True),
    StructField('SOURCE_NAME', StringType(), True),
    StructField('PRCS_EXECUTION_ID', StringType(), True),
    StructField('PIPELINE_NAME', StringType(), True),
    StructField('TRIG_NAME', StringType(), True),
    StructField('STATUS', StringType(), True),
    StructField('STATUS_DESC', StringType(), True),
    StructField('JOB_START_TIME', StringType(), True),
    StructField('JOB_END_TIME', StringType(), True),
    StructField('SOURCE_PATH', StringType(), True),
    StructField('SOURCE_ROW_COUNT', StringType(), True),
    StructField('SOURCE_COL_COUNT', StringType(), True),
    StructField('SOURCE_AMOUNT', StringType(), True),
    StructField('SOURCE_FILE_SIZE', StringType(), True),
    StructField('DEST_PATH', StringType(), True),
    StructField('DEST_ROW_COUNT', StringType(), True),
    StructField('DEST_COL_COUNT', StringType(), True),
    StructField('DEST_AMOUNT', StringType(), True),
    StructField('DEST_FILE_SIZE', StringType(), True),
    StructField('REJECTED_ROW_COUNT', StringType(), True),
    StructField('REJECTED_FILE_COUNT', StringType(), True),
    StructField('LOG_PATH', StringType(), True)
]))
  
  return audit_doc, audit_df



# COMMAND ----------

def build_recon_seg_str(config, seg_nm, run_mode, logger):
  if run_mode=='actuals':
    # If run mode is 'actuals', then filter out adjustments.
    recon_filter_val=config['recon_filter_vals']['actuals'][seg_nm]
    adjustment_filter_str = "AND DATA_DESC_2 != 'Country_Adj'"
  elif run_mode=='actuals_adjustments':
    recon_filter_val=config['recon_filter_vals']['actuals'][seg_nm] + ", " + config['recon_filter_vals']['adjustments'][seg_nm]
    adjustment_filter_str = ""
    
    
  filter_str= config['recon_filter_col'] + " IN (" + recon_filter_val +") AND " + config['filters'][0]
  agg_str=config['agg_query'].replace('{filter_str}', filter_str).replace('{fyear}', fyear).replace('{period}', period).replace('{adjustment_filter_str}', adjustment_filter_str)
  logger.info("Aggregating recon dataframe with query: " + agg_str)
  return agg_str

def create_master_curated_df(config, logger, seg_nm, run_mode): 
  # Create master curated dataframe containing data from all curated sources in config file, aggregated at Fiscal_yr, fiscal_period, gl_acct, location level.
  curated_df_all=spark.createDataFrame([], StructType([StructField("FISCAL_YR", StringType(), True),\
                                                       StructField("FISCAL_PERIOD", StringType(), True),\
                                                       StructField("GL_ACCT", StringType(), True),\
                                                       StructField("Location", StringType(), True),\
                                                       StructField("Lgl_Entity", StringType(), True),\
                                                       StructField("CURATED_AMT_YTD", DecimalType(20,2), True)]))
  # If run mode is 'actuals', then filter out adjustments.
  adjustment_filter_str= "AND DATA_DESC_2 != 'Country_Adj'" if run_mode == 'actuals' else ""
  
  for curated_source in config['curated_sources']:
    # Define views from curated data source
    for view in config['curated_sources'][curated_source]['data']:
      logger.info("Defining view for " + view['view_name'] + " from folder location " + view['folder_path'])
      spark.read.format("parquet").load(view['folder_path']).createOrReplaceTempView(view['view_name'])
    # Aggregate data from curated data view using query in config file and union to master curated DF
    logger.info("Aggregateing data for " + curated_source + " and unioning to master curated df.")
    logger.info("Aggregation query: " + config['curated_sources'][curated_source]['agg_query'].replace('{fyear}', fyear).replace('{adjustment_filter_str}',adjustment_filter_str))
    curated_df=spark.sql(config['curated_sources'][curated_source]['agg_query'].replace('{fyear}', fyear).replace('{period}', period).replace('{adjustment_filter_str}',adjustment_filter_str))
    curated_df_all=curated_df_all.union(curated_df)
  
  return curated_df_all

def create_seg_curated_df(curated_df_all, prof_ctr_filter, ent_hrchy_filter, logger):
  # Apply final filters on the curated dataframe to prepare it for comparison with recon dataframe.
  # TODO: Join on dl_store to programmaticallly get list of locations for each segment.
  logger.info("Filtering and aggregating curated data based on segment being reconciled.")
  segment_query="""
  SELECT
  FISCAL_YR,
  FISCAL_PERIOD,
  GL_ACCT,
  CAST(ABS(SUM(CURATED_AMT_YTD)) AS DECIMAL(20,2)) CURATED_AMT_YTD
  FROM curated_df_all 
  LEFT JOIN gcoa_hrchy
  ON GL_ACCT=gcoa_hrchy.GL
  LEFT JOIN 
    (select distinct 
    a.cntry_key_cd || '.' || lpad(a.store_nbr, 5, '0') profit_ctr_, 
    a.seg_nbr 
    from prof_ctr a 
    INNER JOIN
    (select store_nbr, cntry_key_cd, max(to_dt) max_to_dt from prof_ctr where from_dt <= '{prof_ctr_max_from_dt}' group by store_nbr, cntry_key_cd) b
    on a.store_nbr = b.store_nbr AND a.cntry_key_cd = b.cntry_key_cd AND a.to_dt = b.max_to_dt) prof_ctr
  ON Location=prof_ctr.profit_ctr_
  LEFT JOIN ent_hrchy
  ON Lgl_Entity=ent_hrchy.entity
  WHERE gcoa_hrchy.GL IS NOT NULL
  AND gcoa_hrchy.lvl1 LIKE '%Income%'
  AND (prof_ctr.seg_nbr IN {prof_ctr_filter} OR ent_hrchy.lvl2 = {ent_hrchy_filter})
  GROUP BY 1,2,3
  """
  logger.info("Segment query: " + segment_query.replace('{prof_ctr_filter}', prof_ctr_filter).replace('{ent_hrchy_filter}', ent_hrchy_filter).replace('{prof_ctr_max_from_dt}', prof_ctr_max_from_dt))
  curated_df_seg=spark.sql(segment_query.replace('{prof_ctr_filter}', prof_ctr_filter).replace('{ent_hrchy_filter}', ent_hrchy_filter).replace('{prof_ctr_max_from_dt}', prof_ctr_max_from_dt))
  
  return curated_df_seg

# COMMAND ----------

def generate_recon_stats(joined_df, config, reconcile_output_path):
  #Generate 4 results for the comparison between recon and curated source data:
  #1. Count of keys where sum is equal.
  #2. Count of keys where sum is not equal.
  #3. Count of keys in recon file which do not exist in curated source file
  #4. Count of keys in curated source file which do not exist in recon file.
  reconcile_stats=[]
  slack_factor=str(0.0001)
  reconcile_subset_config=[
    {
      'subset_name':'sum_match',
      'filter1':'(CURATED_AMT_YTD <= RECON_AMT_YTD*(1 + {slack_factor}) AND CURATED_AMT_YTD >=RECON_AMT_YTD*(1 - {slack_factor})) OR ((CURATED_AMT_YTD=0 OR CURATED_AMT_YTD IS NULL) AND (RECON_AMT_YTD=0 OR RECON_AMT_YTD IS NULL))'.replace("{slack_factor}", slack_factor)
    },
    {
      'subset_name':'sum_discrepancy',
      'filter1':'(RECON_AMT_YTD IS NOT NULL AND CURATED_AMT_YTD IS NOT NULL AND (CURATED_AMT_YTD >= RECON_AMT_YTD*(1 + {slack_factor}) OR CURATED_AMT_YTD <=RECON_AMT_YTD*(1 - {slack_factor}))) AND ((CURATED_AMT_YTD!=0 AND CURATED_AMT_YTD IS NOT NULL) OR (RECON_AMT_YTD!=0 AND RECON_AMT_YTD IS NOT NULL))'.replace("{slack_factor}", slack_factor)
    },
    {
      'subset_name':'key_in_recon_not_curated',
      'filter1':'RECON_AMT_YTD != 0 AND RECON_AMT_YTD IS NOT NULL AND CURATED_AMT_YTD IS NULL'
    },
    {
      'subset_name':'key_in_curated_not_recon',
      'filter1':'CURATED_AMT_YTD != 0 AND CURATED_AMT_YTD IS NOT NULL AND RECON_AMT_YTD IS NULL'
    }
  ]
  
  passfail='Succeeded'
  for subset in reconcile_subset_config:
    reconcile_type_df=joined_df.filter(subset['filter1'])
    logger.info("Writing reconciliation data to: " + reconcile_output_path + "reconciliation_data/" + subset['subset_name'] + "/")
    reconcile_type_df.write.format('csv').save(reconcile_output_path + "reconciliation_data/" + subset['subset_name'] + "/", header='true')
    reconcile_type_df_count=reconcile_type_df.count()
    
    if subset['subset_name'] != 'sum_match':
      reconcile_stat={
        'reconcile_subset':subset['subset_name'],
        'subset_count':str(reconcile_type_df_count),
        'subset_vals': ",".join([i[0] for i in reconcile_type_df.select("GL_ACCT").collect()])
      }
    else:
      reconcile_stat={
        'reconcile_subset':subset['subset_name'],
        'subset_count':str(reconcile_type_df_count)
      }      
    logger.info(str(reconcile_stat))
    reconcile_stats.append(reconcile_stat)
    
    if subset['subset_name'] != 'sum_match' and reconcile_type_df_count != 0:
      passfail='Failure'
  
  return reconcile_stats,passfail

# COMMAND ----------

#seg_list=['WMT_US', 'Sams', 'Corp']
current_timestamp=str(datetime.now(tz=None))
run_date=current_timestamp.split(" ")[0]
run_timestamp=str(datetime.now(tz=None)).split(" ")[1].replace(":","").replace(".","")

#1. Read reconciliation file and aggregate data using query specified in config file. Filter data on segment currently being reconciled.
recon_df_seg=spark.sql(build_recon_seg_str(config, seg_nm, run_mode, logger))
recon_df_seg.createOrReplaceTempView("recon_df_seg")

#2. Create master curated dataframe containing data from all curated sources in config file, aggregated at Fiscal_yr, fiscal_period, gl_acct, location level.
curated_df_all=create_master_curated_df(config, logger, seg_nm, run_mode)
curated_df_all.createOrReplaceTempView("curated_df_all")

#3. Filter and aggregate master curated df based on segment currently being reconciled.
prof_ctr_filter_dict = {'WMT_US': "('13', '21')", 'Sams': "('14', '22')", 'Corp': "('15')"}
ent_hrchy_filter = {'WMT_US': "'WMT_US'", 'Sams': "'Sams'", 'Corp': "'Corp'"}
curated_df_seg=create_seg_curated_df(curated_df_all, prof_ctr_filter_dict[seg_nm], ent_hrchy_filter[seg_nm], logger)

#4. Join recon data and curated source data on key columns specified in config file
joined_df=recon_df_seg.join(curated_df_seg, config['join_cols'],how="full").repartition(1)
joined_df.cache()

#5. Write joined dataframe to output path.
reconcile_output_path=config['reconciliation_output_path'].replace('{run_date}', run_date).replace('{run_timestamp}', run_timestamp) + seg_nm + "/"

#7. Using the joined dataframe, reconcile the differences between the sums for each key on between the recon file and the curated source file. Build dictionary containing these results and other information about the run.
reconciliation={}
reconciliation['PRCS_NAME']= "functional_reconciliation_" + run_mode + "_" + seg_nm
reconciliation['FILE_NAME']= ""
reconciliation['PRCS_EXECUTION_ID']=prcs_id
reconciliation['RECONCILIATION_RESULTS'],reconciliation['STATUS']=generate_recon_stats(joined_df,config, reconcile_output_path)
reconciliation['STATUS_DESC']= 'Reconciliation success.' if reconciliation['STATUS'] == 'Succeeded' else 'Not all accounts reconciled successfully.'
reconciliation['EXIT_CODE']=""
reconciliation['JOB_START_TIME']=job_start_date
reconciliation['JOB_END_TIME']=str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
reconciliation['PRCS_TYPE']= ""
reconciliation['RECONCILIAITON_DATA_PATH']= config['recon_folder_path']  
reconciliation['SOURCE_DATA_PATH']= [config['curated_sources'][i]['data'] for i in config['curated_sources'].keys()]
reconciliation['LOG_PATH']=reconcile_output_path

#with open("/dbfs/Test/logs/reconciliation_results_{seg_nm}_{batch_timestamp}.json".replace("{batch_timestamp}", run_timestamp).replace("{seg_nm}",seg_nm), "w+") as outfile:
  #outfile.write(json.dumps(reconciliation, indent=12))

#dbutils.fs.mv("dbfs:/logs/reconciliation_results_{seg_nm}_{batch_timestamp}.json".replace("{batch_timestamp}", run_timestamp).replace("{seg_nm}",seg_nm), reconcile_output_path)

audit_doc, audit_df = create_auditRecord(reconciliation)
audit_df.write.mode('append').format('jdbc').option('url',"jdbc:sqlserver://gbs-financeconnectedplatform-dev-dw.database.windows.net:1433;database=cpdwtest;user=DevLoadUserMRC@gbs-financeconnectedplatform-dev-dw;password=Str0ngP@ssw0rd1!;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;").option('dbtable',"ww_fin_fcp_secure.PRCS_EXECUTION").option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').save()

# COMMAND ----------

dbutils.notebook.exit({'AUDIT_RECORDS': reconciliation})
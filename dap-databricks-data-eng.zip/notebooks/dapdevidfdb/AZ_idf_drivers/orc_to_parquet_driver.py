# Databricks notebook source
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,lit, monotonically_increasing_id, broadcast
import logging
from pyspark.sql.types import *
import datetime
import os
import time
import pandas as pd
import json
import hashlib
import math
import sys
from collections import OrderedDict
import json
import traceback



sys.path.insert(0,'/dbfs/Test/dataintegration/conf/')
import utilsShared
from customException import *


"""

Notebook parameters:

config_path: DBFS location of the config file to be used for execution. This config file determines the table for which the process will be executed.
read_partition_folder (optional): If applicable, this can be used to tell the notebook to only read from a specific partition folder under the base folder listed in the config file.
TARGET_FILE_SIZE_MB: Target file size for parquet records written by this notebook. Files will be at or below this size. Adding additional subsets will aid in archieving sizes closer to this number.
PARTITION_TO_FILE_SIZE_RATIO: Based on experimentation, this is the ratio between the amount of memory in a Spark partition at the time of writing the parquet file and the size of the parquet file after it is written.
NUM_SUBSETS: The number of subsets which will be used to divide the full read dataframe into smaller pieces. These subsets will have optimal partitions calculated individually.

"""
dbutils.widgets.text("read_partition_folder","")
dbutils.widgets.text("schema_name", "")
dbutils.widgets.text("table_name", "")
dbutils.widgets.text("target_file_size_mb", "256")
dbutils.widgets.text("num_subsets", "1")
dbutils.widgets.text("pipeline_name", "")
dbutils.widgets.text("trigger_name", "")
dbutils.widgets.text("incremental_flag", "")
dbutils.widgets.text("incremental_date_folder", "")

incremental_flag=dbutils.widgets.get("incremental_flag")
partition=dbutils.widgets.get("read_partition_folder")
schema_name=dbutils.widgets.get("schema_name")
table_name=dbutils.widgets.get("table_name")
target_file_size_mb=int(dbutils.widgets.get("target_file_size_mb"))
num_subsets=int(dbutils.widgets.get("num_subsets"))
pipeline_name=dbutils.widgets.get("pipeline_name")
trigger_name=dbutils.widgets.get("trigger_name")
incremental_date_folder=dbutils.widgets.get("incremental_date_folder")

millis = int(round(time.time() * 1000))

# log_file_name="/dbfs/mnt/fcp/test_fcp/logs/orc2Parquet_conversion_" + table_name + "_"+ str(datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d')) + '.log'

snappy_error_tables = ['club_catg_plan', 'club_op_plan', 'fin_store_day_dim', 'fin_store_day_dim', 'visit_type_txt', 'dl_mumd_event', 'dl_mumd_event_txt', 'dl_mumd_type', 'dl_bu']


''' spark configuration'''
conf=pyspark.SparkConf() 
spark.conf.set("spark.sql.parquet.fs.optimized.committer.optimization-enabled", True)
## Instructs to overwrite only on a partition-by-partition basis on write. Else, would overwrite entire basepath on each write. 
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
job_start_date = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

envConfig = utilsShared.getEnvConf(0,dbutils)

log_file_name=envConfig["log_path"]+"orc2parquet_conversion_" + table_name + "_"+ str(datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d')) + '.log'

logger = utilsShared.getFormattedLogger("orc_to_parquet_driver",log_file_name)


# COMMAND ----------

def create_audit_rec():
#   if incremental_flag.upper() == 'Y':
#     PRCS_NAME="incremental_orc_to_parquet_conversion"
#   elif incremental_flag.upper() == 'N':
#     PRCS_NAME="historical_orc_to_parquet_conversion"
#   else :
#     raise invalidInputParams('incremental_flag')

#   if incremental_flag.upper() == 'Y':
#     DEST_PATH="/mnt/fcp/parquet/{schema_name}/{table_name}".format(schema_name=schema_name,table_name=table_name) + " , " + "/mnt/fcp/orc/{schema_name}/{table_name}".format(schema_name=schema_name,table_name=table_name)
#   elif incremental_flag.upper() == 'N':
#     DEST_PATH="/mnt/fcp/parquet/{schema_name}/{table_name}".format(schema_name=schema_name,table_name=table_name)
  
  audit_doc = {
            "TRIG_NAME": trigger_name,
            "PIPELINE_NAME": pipeline_name,
            "VALIDATION_FLAG": "No Issue",
            "PRCS_TYPE": "",
            "EXPECTED_PERIOD_KEY": "NA",
            "BATCH_DATE": incremental_date_folder,
            "SOURCE": {
                "SOURCE_FILE_SIZE": "0",
                "SOURCE_AMOUNT": "0",
                "SOURCE_COL_COUNT": "0",
                "SOURCE_ROW_COUNT": "0",
                "SOURCE_PATH": "/mnt/fcp/dev/incremental/{incremental_date_folder}/{schema_name}/{table_name}".format(incremental_date_folder=incremental_date_folder,schema_name=schema_name,table_name=table_name)
            },
            "PRCS_EXECUTION_ID": "NA",
            "TECH_STATUS_DESC": "The orc_parquet_conversion successful",
            "LOG_PATH":log_file_name,
            "EXIT_CODE": 0,
            "STAGES": "",
            "STATUS": "Succeeded",
            "ERROR_CODE": 0,
            "SOURCE_NAME": "prod17",
            "PRCS_NAME": "raw_to_curated",
            "BUSS_STATUS_DESC": "The orc_parquet_conversion successful",
            "JOB_END_TIME": "",
            "FILE_NAME": "NA",
            "DESTINATION": {
                "REJECTED_ROW_COUNT": "0",
                "DEST_FILE_SIZE": "0",
                "REJECTED_FILE_NAME": "NA",
                "DEST_COL_COUNT": "0",
                "DEST_AMOUNT": "0",
                "DEST_PATH":  "/mnt/fcp/parquet/{schema_name}/{table_name}".format(schema_name=schema_name,table_name=table_name),
                "DEST_ROW_COUNT": "0"
            },
            "JOB_START_TIME": job_start_date,
            "STATUS_DESC": "The orc_parquet_conversion completed"
        }
  return audit_doc

# COMMAND ----------

def set_error_exit(audit_doc,e):
    logger.error(e.tech_message)
    logger.error(e.buss_message)
    audit_doc['STATUS'] = 'Failed'
    audit_doc['STATUS_DESC'] = 'The orc_parquet_conversion failed'
    audit_doc['ERROR_CODE']=e.error_code
    audit_doc['TECH_STATUS_DESC'] =e.tech_message
    audit_doc['BUSS_STATUS_DESC']=e.buss_message
    audit_doc['JOB_END_TIME'] = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    audit_doc['EXIT_CODE'] = e.error_code
    dbutils.notebook.exit({'ERROR_CODE':audit_doc['ERROR_CODE'],'AUDIT_RECORDS':audit_doc})

# COMMAND ----------

## Get hive table count from _SUCCESS file written by PROD17 script.
def get_hive_success_file_count(config, logger):
  try:
    success_file_df = spark.read.csv(config['incremental_log_path'].replace("{date}", dbutils.widgets.get("incremental_date_folder")) + config['success_file_name'])
    hive_count = int(success_file_df.collect()[1][0])
    logger.info("Hive count from success file " + config['incremental_log_path'].replace("{date}", dbutils.widgets.get("incremental_date_folder")) + config['success_file_name'] + ": " + str(hive_count))
    return hive_count
  except Exception as e:
    raise fileNotFoundError(config['incremental_log_path'].replace("{date}", dbutils.widgets.get("incremental_date_folder")) + config['success_file_name'])


# COMMAND ----------

def get_audit_result(src_df_count, tgt_df_parquet_count, tgt_df_orc_count, config, incremental_flag, audit_doc, logger):
  if incremental_flag.upper() == 'Y':
    hive_count = get_hive_success_file_count(config, logger)
    if hive_count == tgt_df_parquet_count and hive_count == tgt_df_orc_count:
      return "SUCCESS", "Count of hive table, target parquet table, and target orc table match."
    else:
      raise recordCountMismatchError("parquet:{tgt_df_parquet_count},orc:{tgt_df_orc_count}".format(tgt_df_parquet_count=tgt_df_parquet_count,tgt_df_orc_count=tgt_df_orc_count),"hive:{hiveCount},incremental:{src_df_count}".format(hiveCount=hive_count,src_df_count=src_df_count))
  elif incremental_flag.upper() == 'N':
    if src_df_count == tgt_df_parquet_count:
      return "SUCCESS", "Count of orc source table and parquet target match."
    else:
      raise recordCountMismatchError("orc:{src_df_count}".format(src_df_count=src_df_count),"parquet:{tgt_df_parquet_count}".format(tgt_df_parquet_count=tgt_df_parquet_count))

# COMMAND ----------

''' Reconciliation/audit entry '''
def reconciliation_of_file(job_start_date, basePath_read, src_df_count, tgt_df_parquet_count, logger, config, incremental_flag, partition, tgt_df_orc_count): 
  audit_doc['STATUS'],audit_doc['STATUS_DESC']=get_audit_result(src_df_count, tgt_df_parquet_count, tgt_df_orc_count, config, incremental_flag, audit_doc, logger)
  audit_doc['JOB_END_TIME']=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
  if incremental_flag.upper() == 'Y':
    audit_doc['SOURCE']['SOURCE_ROW_COUNT']=str("incremental count: " + str(src_df_count) + ", hive table count:" + str(get_hive_success_file_count(config, logger)))
  elif incremental_flag.upper() == 'N':
    audit_doc['SOURCE']['SOURCE_ROW_COUNT']=src_df_count
  if incremental_flag.upper() == 'Y':
    audit_doc['DESTINATION']['DEST_ROW_COUNT']=str("parquet:" + str(tgt_df_parquet_count) + " , orc:" + str(tgt_df_orc_count))
  elif incremental_flag.upper() == 'N':
    audit_doc['DESTINATION']['DEST_ROW_COUNT']=tgt_df_parquet_count  
  return audit_doc

# COMMAND ----------

"""

Reads config file from DBFS and returns dictionary object of its contents.

"""
def read_config(src_config_path):
  try:
    source_config_file = open(str(src_config_path),'r').read()
    config = json.loads(source_config_file)
    return config
  except FileNotFoundError as e:
    raise configNotFoundError(src_config_path)


# COMMAND ----------

def get_dt_from_string(dt_string,logger):
  if dt_string.lower()=='string':
      dataType=StringType()
  elif dt_string.lower()=='integer':
      dataType=IntegerType()
  elif dt_string.lower()=='double':
      dataType=DoubleType()
  elif dt_string.lower()=='float':
      dataType=FloatType()
  elif dt_string.lower()=='short':
      dataType=ShortType()
  elif dt_string.lower()=='long':
      dataType=LongType()
  elif dt_string.lower()=='timestamp':
      dataType=TimestampType()
  elif dt_string.lower()=='date':
      dataType=DateType()
  elif dt_string.lower()=='binary':
      dataType=BinaryType()
  elif dt_string.lower()=='boolean':
      dataType=BooleanType()
  elif dt_string.lower()=='byte':
      dataType=ByteType()
  elif "decimal" in str.lower(dt_string):
      dt_type=dt_string.replace(")","")
      s_nd_p=dt_type.split("(")[1].split(",")
      dataType=DecimalType(int(s_nd_p[0]),int(s_nd_p[1]))
  else:
      logger.info("Cant recognize data type '"+ dt_string + "' specified in config file. Defaulting to StringType.")
      dataType=StringType()
#     raise dataTypeUnrecognised(dt_string)

  return dataType

# COMMAND ----------

def gen_struct_schema(list_of_dict,logger):
  struct_schema=[]
  for col_info in list_of_dict:
    dataType = get_dt_from_string(col_info['dt_type'],logger)
    struct_schema.append(StructField(col_info['col_name'],dataType,True))

  final_schema=StructType(struct_schema)
  return final_schema

# COMMAND ----------

def append_partition_cols(df,list_of_prtns,logger):
  # Appending partition cols with suffix _ptn to create same directory structure
  logger.info("Appending partition columns to the dataframe ")
  for prtn_col in list_of_prtns:
    df=df.withColumn(prtn_col+"_ptn",col(prtn_col))
  return df

# COMMAND ----------

def get_dtype(df,colname):
    return [dtype for name, dtype in df.dtypes if name == colname][0]

# COMMAND ----------

# Apply column transformations if specified in config file

from pyspark.sql.functions import when
def apply_transformations(df, list_of_transformations, logger):

  logger.info("Apply column transformations specified in config file.")
  try:
    for trans in list_of_transformations:
      if('type' in trans):
        logger.info("transformation type is "+trans['type'])
      else:
        logger.info("transformation type is data-type-conversion")
      if (('type' not in trans) or (trans['type']=='data-type-conversion')):
        df = df.withColumn(trans['col_name'], col(trans['col_name']).cast(get_dt_from_string(trans['dt_type'], logger)))
      elif (trans['type']=='replace-set'):
        column_type = (get_dtype(df,trans['col_name'])) 
        df = df.withColumn(trans['col_name'],when(col(trans['col_name']) == trans['oldvalue'], trans['newvalue']).otherwise(col(trans['col_name'])).cast(get_dt_from_string(column_type, logger)))
      elif (trans['type']=='rename-column'):
        df = df.withColumnRenamed(trans['old_col_name'], trans['new_col_name'])
    return df
  except Exception as e:
    raise transformationError(str(e))
    


# COMMAND ----------

def get_basePath_read(incremental_flag, config, logger):
  if incremental_flag.upper() == 'Y':
    if dbutils.widgets.get("incremental_date_folder") == "":
        raise invalidInputParams("incremental_date_folder")
    incremental_date_folder = dbutils.widgets.get("incremental_date_folder")
    basePath_read = config['incremental_basepath'].replace("{date}", incremental_date_folder)
  elif incremental_flag.upper() == 'N':
    basePath_read = config['orc_basepath']
  else: 
    raise invalidInputParams("incremental_flag")
  
  return basePath_read
      

# COMMAND ----------

def get_optimal_partitions(record_count, BYTES_PER_RECORD, PARTITION_TO_FILE_SIZE_RATIO=2.97, TARGET_FILE_SIZE_MB=target_file_size_mb):
    ## Calculate how many bytes should be in each Spark partition at the time of writing to achieve target file size.
    bytes_per_partition = PARTITION_TO_FILE_SIZE_RATIO * TARGET_FILE_SIZE_MB * 1024 * 1024
    ## Calculate approximately how many total bytes are being processed by multiplying number of records by bytes per record.
    total_record_bytes = record_count * BYTES_PER_RECORD
    ## Calculate the number of partitions required to achieve files of size TARGET_FILE_SIZE_MB by dividing the total bytes being processed by the number of bytes we want in each partition.
    optimal_partitions = math.ceil(total_record_bytes / bytes_per_partition)
    logger.info("Using " + str(optimal_partitions) + " partitions given " + str(BYTES_PER_RECORD) + " bytes per record and " + str(TARGET_FILE_SIZE_MB) + " desired MB per written file. Corresponding MB per dataframe partition: " + str(bytes_per_partition / (1024 * 1024)))
    return optimal_partitions

# COMMAND ----------

"""

Build Spark SQL join clause to join two dataframes on the column names provided to the function.

"""

def build_join_clause_str(join_fields, left_alias, right_alias):
  clause = ""
  for field in join_fields:
      clause = clause + left_alias + "." + field + " IS NOT DISTINCT FROM " + right_alias + "." + field
      if field != join_fields[-1]:
        clause = clause + " AND "
  return clause

# COMMAND ----------

"""

Get folder information from config file.

"""

try:
  audit_doc = create_audit_rec()
  config_basepath="/dbfs/Test/dataintegration/orc-parquet-data-conf-conversion/"
  src_config_path= config_basepath+"orc2parquet_"+schema_name+"_"+table_name+".json"
  logger.info("Reading config file from " + str(src_config_path))
  config=read_config(src_config_path)
  ################for testing purposes - read/write to different folder################
  #config['orc_basepath'] = '/mnt/fcp/dev/backfill/ww_fin_dl_tables/store_item_receipts_dly/'
  #config['parquet_basepath'] = '/mnt/fcp/parquet/ww_pricing_dl_tables/store_mumd_dly/'
  #config['incremental_basepath'] = '/mnt/fcp/dev/ag/incremental/{date}/ww_core_dim_dl_tables.db/geo_region/'
  #config['incremental_log_path'] = '/mnt/fcp/dev/ag/logs/{date}/ww_core_dim_dl_tables.db/geo_region/'
  ########################################################################
  ## Set base read folder
  basePath_read = get_basePath_read(incremental_flag, config, logger)
  ## Set base write folder 
  basePath_write = config["parquet_basepath"]
  logger.info("Job is going to read data from : "+ basePath_read + partition +" and after conversion will placed in : " + basePath_write)

#   if incremental_flag.upper() == 'Y':
#       logger.info("Checking if _SUCCESS file exists for incremental_date_folder given...")
#       dbutils.fs.ls(config['incremental_log_path'].replace('{date}', dbutils.widgets.get('incremental_date_folder')))
#       logger.info("_SUCCESS file exists!")
  try:
      logger.info("Checking if incremental files exist for incremental_date_folder given...")
      dbutils.fs.ls(config['incremental_basepath'].replace('{date}', dbutils.widgets.get('incremental_date_folder')))
      logger.info("Incremental files exist!")
  except:
      logger.info("No incremental data found. Exiting program.")
      raise noIncrementalData(dbutils.widgets.get('incremental_date_folder'),schema_name+'.'+table_name)

  """

  Read ORC data from basePath_read while applying schema specified in config file. Apply transformations and add partition columns specified in config file.

  """

  if table_name in snappy_error_tables and incremental_flag.upper() == 'Y':
    logger.info("Table being processed is identified as a table with malformed ORC source files. Applying CSV read workaround.")
    ######APPLY SNAPPY ERROR WORKAROUND FOR AFFECTED TABLES#########
    parsed_df = spark.read.csv(basePath_read,inferSchema="true", sep="\x01")
    parsed_df = parsed_df.replace('\\N', None)
    parsed_df = spark.createDataFrame(parsed_df.rdd, schema=gen_struct_schema(config['tgt_col'], logger))
  else:
  #######ELSE, READ NORMALLY########
    parsed_df=spark.read.format("orc").option("basePath", basePath_read).schema(gen_struct_schema(config['tgt_col'], logger)).load(basePath_read + partition + "*")
    logger.info("Read metadata from " + basePath_read + " complete.")
    src_df_columns_count=len(parsed_df.columns)

  #Add columns partitions columns with suffix _ptn to dataframe
  parsed_df_trans = apply_transformations(append_partition_cols(parsed_df, config["list_of_partitions"], logger), config["transformations"], logger)

  parsed_df_final = parsed_df_trans
  ##Caching this DF could possibly overflow storage while processing entire tables, but will improve performance since this dataframe is continually referenced
  parsed_df_final.cache()

  """

  Create a dataframe which tells the program how many records exist for each file partition combination.

  """
  grouped_sorted_df = parsed_df_final.groupBy(config["repartitions"]).count().orderBy(col('count').desc()).cache()
  grouped_sorted_df.show()
  src_df_count=grouped_sorted_df.agg({'count':'sum'}).select(col("sum(count)")).collect()[0][0]
  print(src_df_count)
  grouped_sorted_list=grouped_sorted_df.collect()
  logger.info("Starting conversion process.")
  logger.info("Calculating partitions with most records to create dataframe subsets.")
  ## Get information about file partition with most records.
  top_ptn = grouped_sorted_df.first()
  ## Get total number of file partitions.
  tot_ptn = grouped_sorted_df.count()
  ## Get number of records in file partitions with most records.
  max_ptn_records = int(top_ptn[len(config["repartitions"])])
  logger.info("Total partitions: " + str(tot_ptn) + ". Maximum partition records information: " + str(top_ptn))

  logger.info("Splitting records into subsets with similar row counts in order to independently calculate optimal partitions for each subset. Number of subsets: " + str(num_subsets))
  quantiles = grouped_sorted_df.approxQuantile('count', [i / num_subsets for i in range(0, num_subsets + 1)], 0.1)
  quantiles[0] = 0.0
  quantiles[-1] = top_ptn[-1]
  logger.info ("Quantiles calculated for subset dataframes are: " + str(quantiles))

  [i / num_subsets for i in range(0, num_subsets + 1)]


  """

  Calculate number of partitions required to achieve files of size TARGET_FILE_SIZE_MB.

  """
  partition_to_file_size_ratio=2.97
  # If a value for bytes_per_record is given in the config file, use it. Else, set to 97.7 (value calculated for scanv_dly table). This value can be calcualted roughly by looking at the Spark DAG and dividing the in-memory "shuffle read" size by the number of records in the "shuffle read". 
  if config['bytes_per_record'] != "":
    bytes_per_record=float(config['bytes_per_record'])
  else:
    bytes_per_record=97.7


  """


  Main processing logic. Summary of process:

  Step 1. Given the number of subsets specified in the notebook parameters, and a dataframe containing record counts for each file partition combination, calculate the 'cut-off' points for each subset via calculating the quantiles of the dataframe's 'count' field. 
  Step 2. For each quantile, create a subset dataframe by filtering the source dataframe (containing all records) on the partition column combinations which have record counts between the min and max values in the quantile. This filter is done via a left semi join.
  Step 3. Calculate the number of spark partitions which need to be created for each file partition in order to generate files of desired size. This calculation is done using the largest file partition record count for the subset. Thus, file partitions at the lower end of the quantile will have files written somewhat smaller than the ideal file size, and vice versa for file partitions at the higher end.
  Step 4. Since spark can only partition on either columns or a number (not both), the number of optimal partitions needs to be represented as a column. This is done by 'salting' the subset dataframe with values between 1 and the optimal number of partitions.
  Step 5. Repartition the subset dataframe on the partition columns, and the partition index column generated in step 4. 
  Step 6. Write the dataframe in parquet format to the target location. Partition these files based on the partition columns specified in the config file.


  """

  ####### Step 1 #######
  ######################
  logger.info("Splitting records into subsets with similar row counts in order to independently calculate optimal partitions for each subset. Number of subsets: " + str(num_subsets))
  quantiles = grouped_sorted_df.approxQuantile('count', [i / num_subsets for i in range(0, num_subsets + 1)], 0.1)
  quantiles[0] = 0.0
  quantiles[-1] = top_ptn[-1]
  logger.info ("Quantiles calculated for subset dataframes are: " + str(quantiles))

  for n in range(len(quantiles) - 1):
    ####### Step 2 #######
    ######################
    logger.info("Started processing data for subset " + str(n+1) + " of " + str(num_subsets))
    subset_min_count = quantiles[n]
    subset_max_count = quantiles[n+1]
    logger.info("Creating a subset dataframe of partitions containing between " + str(subset_min_count) + " and " + str(subset_max_count) + " records.")
    ## Get values of visit_dt_ptn and op_cmpny_cd_ptn which have row counts between subset_min_count and subset_max_count.
    subset_partition_values_df = grouped_sorted_df.filter((lit(subset_max_count) >= col('count')) & (col('count') > lit(subset_min_count)))
    subset_partition_values_count = subset_partition_values_df.count()
    ## Filter dataframe such that resulting records will have visit_dt_ptn and op_cmpny_cd_ptn with total row counts between subset_min_count and subset_max_count.
    parsed_df_final.createOrReplaceTempView("parsed_df_final")
    subset_partition_values_df.createOrReplaceTempView("subset_partition_values_df")
    if config["repartitions"] == []:
      subset_df = parsed_df_final
    else:
      subset_df = spark.sql("SELECT * from parsed_df_final a LEFT SEMI JOIN subset_partition_values_df b ON " + build_join_clause_str(config["repartitions"], 'a', 'b'))

    ####### Step 3 #######
    ######################
    ## Repartition NON US subset dataframe on partition columns, and partition index. Results in <num unique partition column combinations> * subset_optimal_partitions number of partitions in dataframe.
    subset_optimal_partitions = get_optimal_partitions(subset_max_count,bytes_per_record)
    ## Set number of shuffle partitions equal to the number of target partitions so shuffle partitions are not flooded.
    subset_shuffle_partitions = max(subset_partition_values_count * subset_optimal_partitions,200)
    logger.info("Setting shuffle partitions to: " + str(subset_shuffle_partitions))
    spark.conf.set("spark.sql.shuffle.partitions", subset_shuffle_partitions)

    ####### Step 4 #######
    ######################
    ## Salt the dataframe with an index between 1 and subset_optimal_partitions so the dataframe can be partitioned on this column.
    subset_df_indexed = subset_df.withColumn("idx", monotonically_increasing_id()).withColumn("partition_idx", col('idx') % subset_optimal_partitions)
    partition_col_plus_salt = config["repartitions"] + ['partition_idx']
    ####### Step 5 #######
    ######################
    ## Create Spark Sql view in order to programmatically specify partition columns. DISTRIBUTE BY statement is equivalent to repartition.
    subset_df_indexed.createOrReplaceTempView("subset_df_indexed")
    subset_df_repartitioned = spark.sql("select * from subset_df_indexed DISTRIBUTE BY " + ", ".join(partition_col_plus_salt))
    subset_df_final = subset_df_repartitioned.drop('idx', 'partition_idx')

    ####### Step 6 #######
    ######################
    ## Write subset dataframe to parquet (and orc, if incremental run). Number of files will be equal to <num unique partition column combinations> * subset_optimal_partitions.
    if incremental_flag.upper() == 'Y':
      ## Write to /orc/ folder specified in config file.
      logger.info("Incremental flag is set to 'Y'. Dropping 'repartition' columns and writing to orc_basepath folder.")
      subset_df_final_orc = subset_df_final.drop(*config['repartitions'])
      logger.info("writing orc data into partitions of base folder :" +  config['orc_basepath'])
      subset_df_final.write.option("basePath", config['orc_basepath']).partitionBy(config["list_of_partitions"]).mode("overwrite").save(config['orc_basepath'] ,format="orc")

    ## Write to /parquet/ folder path speicified in config file.
    logger.info("writing parquet data into partitions of base folder :" +  str(basePath_write))
    subset_df_final.write.option("basePath", basePath_write).partitionBy(config["repartitions"]).mode("overwrite").save(basePath_write ,format="parquet")

    logger.info("Completed writing data for subset " + str(n+1) + " of " + str(num_subsets))
    ## Set shuffle partitions back to default
    spark.conf.set("spark.sql.shuffle.partitions", 200)


  if  incremental_flag.upper() == 'Y':
    lines=[]
    for ptn in grouped_sorted_list:
        ptn_folder_nm_1=str(config['repartitions'][0])+"="+str('__HIVE_DEFAULT_PARTITION__' if ptn[0] == None else ptn[0]) if len(config['repartitions']) > 0 else ""
        ptn_folder_nm_2=str(config['repartitions'][1])+"="+str('__HIVE_DEFAULT_PARTITION__' if ptn[1] == None else ptn[1]) if len(config['repartitions']) > 1 else ""
        lines.append([config['parquet_basepath'].replace("/mnt/fcp/",""),ptn_folder_nm_1,ptn_folder_nm_2, schema_name, table_name])

    path=config['incremental_log_path'].replace("{date}", dbutils.widgets.get("incremental_date_folder")) + "partitions_written_parquet.txt"
    dbutils.fs.put(path,str(pd.DataFrame(lines).to_csv(sep='|',index=False,header=False)),True) 
    logger.info("Information on parquet partitions loaded by this process written to " + path)


  # Generating target coulumns count and total number of records in target parquet folder
  tgt_df_parquet=spark.read.format("parquet").option("basePath", basePath_write).load(basePath_write + partition.replace("=","_ptn="))
  tgt_df_parquet_count=tgt_df_parquet.count()
  tgt_df_parquet_columns_count=len(tgt_df_parquet.columns)
  logger.info("Total records in target parquet folder: " + str(tgt_df_parquet_count) + ". Number of columns: " + str(tgt_df_parquet_columns_count))


  ## If incremental flag is 'Y', then perform count of number of records in orc folder
  if incremental_flag.upper() == 'Y':
    tgt_df_orc=spark.read.format("orc").option("basePath", config['orc_basepath']).load(config['orc_basepath'] + partition)
    tgt_df_orc_count=tgt_df_orc.count()
    tgt_df_orc_columns_count=len(tgt_df_orc.columns)
    logger.info("Total records in target orc folder: " + str(tgt_df_orc_count) + ". Number of columns: " + str(tgt_df_orc_columns_count))


  # Adding Audit record records in process execution file
  logger.info("Writing Audit records in historical_process_execution file ")
  if incremental_flag.upper() == 'Y':
    audit_str = reconciliation_of_file(job_start_date, basePath_read, src_df_count, tgt_df_parquet_count, logger,config,  incremental_flag, partition, tgt_df_orc_count)
  elif incremental_flag.upper() == 'N':
    audit_str = reconciliation_of_file(job_start_date, basePath_read, src_df_count, tgt_df_parquet_count, logger , config, incremental_flag, partition, None)
    logger.info("Audit record is written in historical_process_execution file ")
  print("At the end ")


except (fileNotFoundError,
        configNotFoundError,
        transformationError,
        invalidInputParams,
        noIncrementalData,
        uncatchException) as e:
     set_error_exit(audit_doc,e)

except recordCountMismatchError as e:
    if incremental_flag.upper() == 'Y':
        audit_doc['SOURCE']['SOURCE_ROW_COUNT']=str("incremental count: " + str(src_df_count) + ", hive table count:" + str(get_hive_success_file_count(config, logger)))
    elif incremental_flag.upper() == 'N':
        audit_doc['SOURCE']['SOURCE_ROW_COUNT']=src_df_count
    if incremental_flag.upper() == 'Y':
        audit_doc['DESTINATION']['DEST_ROW_COUNT']=str("parquet:" + str(tgt_df_parquet_count) + " , orc:" + str(tgt_df_orc_count))
    elif incremental_flag.upper() == 'N':
        audit_doc['DESTINATION']['DEST_ROW_COUNT']=tgt_df_parquet_count 
    set_error_exit(audit_doc,e)

except Exception as e:
    try:
      err_desc = str(traceback.format_exc())
      raise uncatchException(err_desc)
    except uncatchException as e:
      set_error_exit(audit_doc,e)

      
else: 
    dbutils.notebook.exit({'ERROR_CODE':audit_doc['ERROR_CODE'],'AUDIT_RECORDS':audit_doc})





# COMMAND ----------

### For incremental - check if _SUCCESS file exists and if incremental files exist.



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------


    

# COMMAND ----------

#grouped_sorted_list

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

    ## Flush all cached dataframes from the run.
    #spark.catalog.clearCache()

# COMMAND ----------

    ##Exit the notebook and return the audit row written to the log file
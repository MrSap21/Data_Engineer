# Databricks notebook source
'''
File validation script (including file location, record counts, size check and metadata of the file)
created on dec 10, 2019

Output - 0 for success and 1 for failure
'''

import sys
import os
from json  import loads
import glob
import time
import datetime
from collections import OrderedDict
import pandas as pd
import hashlib
import traceback

millis=int(round(time.time()*1000))
start_time = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

sys.path.insert(0,'/dbfs/Test/dataintegration/process-files-ingestion/')
sys.path.insert(0,'/dbfs/Test/dataintegration/data-conf-ingestion/')

''' all the static variables required to run this script  '''
pipeline_name =dbutils.widgets.get("prm_act_pipeline_name")
trigger_name=dbutils.widgets.get("prm_act_trigger_name")
var_batch_date= dbutils.widgets.get("prm_act_batchdate")
var_src_id= dbutils.widgets.get("prm_act_src_id")
var_src_file_id= dbutils.widgets.get("prm_act_src_file_id")
src_name= dbutils.widgets.get("prm_act_src_name")
file_ext = dbutils.widgets.get("prm_act_file_ext")[1:]

conf_file_path='/dbfs/Test/dataintegration/data-conf-ingestion/file_validation_conf.json'

log_filename = "/dbfs/mnt/fcp/test_fcp/logs/"+pipeline_name+"_"+src_name+"_"+str(datetime.datetime.now().strftime("%Y%m%d"))+".log"

audit_record=OrderedDict()
metadata_info={}

from common_logger import Logger
from metadataManager import metadataManager
logger = Logger("raw_file_validation_process_started",log_filename)

'''This method checks whether file esists or not '''
def file_exist_validation(file_properties,batch_date):
    list_of_files=None
    file_count_flag=None
    file_exist_flag=None
    logger.logging_info("properties")
    logger.logging_info(file_properties['landing_folder'])
    print("landing data:",file_properties['landing_folder'])
    logger.logging_info(file_properties['file_prefix'])
    print("landing data:",file_properties['file_prefix'])
    logger.logging_info(batch_date)
    list_of_files=glob.glob(file_properties['landing_folder']+file_properties['file_prefix']+'*'+batch_date+'*.'+file_ext)
    print("list of files",list_of_files)
    print(file_properties['landing_folder']+file_properties['file_prefix']+'*'+batch_date+'*.'+file_ext)
    logger.logging_info("List of Files - "+str(list_of_files))
    if "file_exists" in file_properties['validation_type']:
        if list_of_files:
            file_exist_flag=0
            logger.logging_info("File with expected prefix found in landing folder "+file_properties['landing_folder'] )
            if "file_count" in file_properties['validation_type']:
                file_count=len(list_of_files)
                if (int(file_properties['number_of_files'])==file_count):
                    file_count_flag=0
                    logger.logging_info("File count match with expected number for today's batch")
                else:
                    file_count_flag=1
                    logger.logging_info("File count doesn't match with expected number for today's batch")
        else:
            file_exist_flag=1
            logger.logging_info("File doesn't exist")
    metadata_info["file_names"]= [os.path.basename(x) for x in list_of_files]
    logger.logging_info(file_count_flag)
    logger.logging_info(file_exist_flag)
    return list_of_files,(0 if file_count_flag is None else file_count_flag),(0 if file_exist_flag is None else file_exist_flag)

''' This method checks header, data count and size check'''
def generic_metadata_validation(file_properties,list_of_files):
    ''' record count in a file '''
    file_size_flag=None
    rec_count_flag=None
    header_flag=None
    for file_info in list_of_files:
        if "file_size" in file_properties['validation_type']:
            file_stats = os.stat(file_info)
            file_size_in_kb=1 if int(file_stats.st_size/1024)==0 else int(file_stats.st_size/1024) 
            metadata_info["file_size_in_kb"]=file_size_in_kb
            if (file_size_in_kb>=int(file_properties['threshold_size_min']) and file_size_in_kb<=int(file_properties['threshold_size_max'])):
                file_size_flag=0
                logger.logging_info(file_info+" file size in range of threshold expected")
            else :
                file_size_flag=1
                logger.logging_info(file_info +" file size is not in range of threshold expected")
        if "count_w_threshold" in file_properties['validation_type'] or "header" in file_properties['validation_type'] or   "count_w_footer" in file_properties['validation_type']:
            file_extn=file_info.split('.')[-1]
            file_path=file_info[5:]
            logger.logging_info("file_info"+file_info)
            logger.logging_info("file_extn"+file_extn)
            if file_extn =='xlsx' or file_extn =='xlsm':
                if file_properties['data-address'] != "":
                    inputDF = spark.read.format("com.crealytics.spark.excel").option("dataAddress",file_properties['data-address']).option("useHeader",'true').option("inferSchema",'true').load(file_path)
                    inputDF=inputDF.na.drop()
                    logger.logging_info("file_info1")
                else:
                    inputDF = spark.read.format("com.crealytics.spark.excel").option("useHeader",'true').option("inferSchema",'true').load(file_path)
                    logger.logging_info("file_info2")
                    inputDF=inputDF.na.drop()
            else:
                inputDF=spark.read.option("header","true").option("inferSchema", "true").csv(file_path)
            file_rec_count=(inputDF.count())-1 if  "count_w_footer" in file_properties['validation_type'] else (inputDF.count())
            metadata_info["file_rec_count"]=file_rec_count
            logger.logging_info(display(inputDF))
            header=inputDF.columns
            footer = inputDF.take(inputDF.count()-1)
            if ( "count_w_threshold" in file_properties['validation_type']  and file_rec_count>=int(file_properties['threshold_count_min']) and file_rec_count<=int(file_properties['threshold_count_max']) ):
                rec_count_flag=0
                logger.logging_info(file_info +' file record counts is in range of threshold')
            elif ( "count_w_footer" in file_properties['validation_type']  and file_rec_count==int(footer) ):
                rec_count_flag=0
                logger.logging_info(file_info +' file record counts matched with file footer count')
            else:
                rec_count_flag=1
                logger.logging_info(file_info +" file record counts doesn't matched with file footer count")
            if ( "header" in file_properties['validation_type']):
                #if(header.strip().replace('\n','')==file_properties['header'] ):
                logger.logging_info("header"+str(header).strip().replace('\\n',''))
                logger.logging_info("header"+str(file_properties['header']).strip().replace('\n',''))
                if(str(header).strip().replace('\\n','')==str(file_properties['header']).strip().replace('\n','')):
                    header_flag=0
                    logger.logging_info(file_info +' header of the file matched with expected header')
                else:
                    header_flag=1
                    logger.logging_info(file_info +" header of the file doesn't matched with expected header")
    return file_size_flag,rec_count_flag,header_flag
    
'''
This method read all the properties required for the file validation
'''

def readconf(filepath,src_id,src_file_id):
    with open(filepath,'r') as config_file:
        config_json=config_file.read().replace('\n', '')
        config_dict=loads(config_json)
    req_info=[]
    for src_info in config_dict['src_files_properties']:
        if (src_info['src_id']==src_id):
            if(src_file_id=='ALL'):
                for file_info in src_info['list_of_files']:
                    req_info.append(file_info)
            else:
                for file_info in src_info['list_of_files']:
                    if (file_info['src_file_id']==src_file_id):
                        req_info.append(file_info)
    return req_info

def main():
    try:
        logger.logging_info("File Validation Process Started")
        src_id=var_src_id
        src_file_id=var_src_file_id
        batch_date=var_batch_date
        print("date:",batch_date)
        src_validation_flag=[]
		
        ''' reading configuration file to get all the properties for source files '''
        list_of_file_properties=readconf(conf_file_path,src_id,src_file_id)
        print("file data:",list_of_file_properties)
			
        for file_prop in list_of_file_properties:
            audit_dict={}
            ''' file name and number of files validation '''
            list_of_files,file_count_flag,file_exist_flag=file_exist_validation(file_prop,batch_date)

            ''' this method checks header, data count and size check '''
            file_size_flag,rec_count_flag,header_flag=generic_metadata_validation(file_prop,list_of_files)

            ''' auditing of each validation in file in form of dictionary'''
            audit_dict['file_count_flag']='Success' if file_count_flag != 1 else 'Failure'
            audit_dict['file_exist_flag']='Success' if file_exist_flag != 1 else 'Failure'
            audit_dict['file_size_flag']='Success' if file_size_flag != 1 else 'Failure'
            audit_dict['rec_count_flag']='Success' if rec_count_flag != 1 else 'Failure'
            audit_dict['header_flag']='Success' if header_flag != 1 else 'Failure'

            logger.logging_info("Audit process started for file validation")
            audit_record["FILE_NAME"]=metadata_info["file_names"]
            audit_record["PRCS_NAME"]="raw_file_validation"
            audit_record["PRCS_EXECUTION_ID"]=str(hashlib.md5(str(millis).encode()).hexdigest())
            audit_record["PIPELINE_NAME"]= pipeline_name
            audit_record["TRIG_NAME"]= trigger_name

            if (file_count_flag!=1 and file_exist_flag!=1 and file_size_flag!=1 and rec_count_flag!=1 and header_flag!=1):
                src_validation_flag.append(0)
                audit_record["STATUS"]="Success"
                audit_record["STATUS_DESC"]="Validation Successful"
            else:
                src_validation_flag.append(1)
                audit_record["STATUS"]="Failed"
                failed_validation_list=[]
                for val, status in audit_dict.items():
                    if status == 'Failure':
                        failed_validation_list.append(val)
                audit_record["STATUS_DESC"]="File Validation Failed In " + ', '.join(failed_validation_list)

            logger.logging_info('src_validation_flag= '+str(src_validation_flag))
            audit_record["JOB_START_TIME"]=start_time
            audit_record["JOB_END_TIME"]=None
            audit_record["SOURCE_PATH"]=file_prop['landing_folder']
            audit_record["SOURCE_ROW_COUNT"]=""
            audit_record["SOURCE_COL_COUNT"]=""
            audit_record["SOURCE_AMOUNT"]=""
            audit_record["SOURCE_FILE_SIZE"]=""#int(file_size_in_kb)/1048576
            audit_record["DEST_PATH"]=""
            audit_record["DEST_ROW_COUNT"]=""
            audit_record["DEST_COL_COUNT"]=""
            audit_record["DEST_AMOUNT"]=""
            audit_record["DEST_FILE_SIZE"]=""
            audit_record["REJECTED_ROW_COUNT"]=""
            audit_record["REJECTED_FILE_COUNT"]=""
            audit_record["LOG_PATH"]=log_filename
            audit_record["JOB_END_TIME"]=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

            metadata_obj = metadataManager()
            metadata_obj.insert_auditRecord(audit_record)
            logger.logging_info("Audit process completed for file validation")
    
        if (set(src_validation_flag)=={0}):
            logger.logging_info("All File Validations Passed")
        else:
            logger.logging_info("File Validation Failed.")
            raise Exception('All the files related to given source is not as per expectation , failing the pipeline for manual intervention.')
    except Exception as error:
        logger.logging_info("Error in script:"+str(traceback.format_exc()))
        raise Exception("Error in script:"+str(error))
if __name__ == "__main__":
    # calling main function
    main()

# COMMAND ----------


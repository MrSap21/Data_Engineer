# Databricks notebook source
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import sys
import traceback
import os
import datetime
from collections import OrderedDict
import hashlib
import time
import json
from shutil import copyfile
# Custom Library

sys.path.insert(0, '/dbfs/mnt/idfwbadevmount/idfappdata/AZ_IDFCodebase/conf/')


import utilsShared
from customException import configNotFoundError,uncatchException
from gen_audit_entry import *

# Read the env Config Properties
envConfig = utilsShared.getEnvConf(0,dbutils)

sys.path.insert(0, envConfig["data_conf_ing_path"])
sys.path.insert(0, envConfig["process_files_ing_path"])

envConfig['schemaName'] = dbutils.widgets.get('prm_act_schema_name')
envConfig['tableName'] = dbutils.widgets.get('prm_act_file_prefix')
envConfig['sourceName'] = dbutils.widgets.get('prm_act_src_name')
envConfig['srcId'] = dbutils.widgets.get('prm_act_src_id')
envConfig['batchDate'] = dbutils.widgets.get('prm_act_batchdate')
envConfig['fileName'] = dbutils.widgets.get('prm_act_filename')
envConfig['fileExt'] = dbutils.widgets.get('prm_act_file_ext')[1:]
envConfig['pipelineName'] = dbutils.widgets.get('prm_act_pipeline_name')
envConfig['triggerName'] = dbutils.widgets.get('prm_act_trigger_name')
envConfig['varbatchdate'] = dbutils.widgets.get('prm_act_varbatchdate')
u_name=dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().apply('user')
envConfig['load_userid'] = u_name[0:u_name.find('@')]
run_id = dbutils.widgets.get('prm_act_runid')
envConfig['prcs_runid'] = run_id     ###run_id[:32]   
print("=======>>>>>>"+str(envConfig['prcs_runid']))
try:
    fileName_all=dbutils.widgets.get('prm_p_filename_All')
except:
    fileName_all=envConfig['fileName']


config_file_prefix = dbutils.widgets.get("prm_act_file_prefix")
envConfig['tableName']=config_file_prefix.split("|")[str(fileName_all).split("|").index(str(envConfig['fileName']))]

                                                                                                                                                                     
local_log_file_name = envConfig["local_log_path"] + envConfig['pipelineName'] + "_"+ envConfig['sourceName'] + "_" + str(envConfig["schemaName"]).replace("/","_") + "_" + str(envConfig["tableName"]).replace("/","_") + "_" +str(datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d_%H%M%S')) + '.log'

envConfig['local_log_file_name'] = local_log_file_name
log_file_name = local_log_file_name.replace(envConfig["local_log_path"], envConfig["log_path"] + "/" + envConfig['triggerName'] + "/" +envConfig['sourceName']+ "/" + str(envConfig["schemaName"]) + "/" + str(envConfig["tableName"]) + "/"+ str(datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')) + "/")

envConfig['log_file_name'] = log_file_name
log_file_folder = "/".join(log_file_name.split("/")[:-1])
# Logger function
os.makedirs(envConfig["local_log_path"], exist_ok=True)
# Logger function
logger = utilsShared.getFormattedLogger("smart_ingestion_driver", local_log_file_name)

logger.debug('Loading pyfiles from  : '+ str(envConfig["process_files_ing_path"]))
sys.path.insert(0, envConfig["process_files_ing_path"])
from metadataManager import metadataManager
metadata_obj = metadataManager()

millis = int(round(time.time() * 1000))
start_time = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

batchDate_formatted=datetime.datetime.strptime(envConfig['batchDate'], '%Y%m%d')
batchDate_formatted=datetime.datetime.strftime(batchDate_formatted, '%Y-%m-%d')


logger.info('Performing Ingestion Activity')

exit_doc = {
        'PRCS_NAME': '',
        'FILE_NAME': '',
        'PRCS_EXECUTION_ID': '',
        'STATUS': '',
        'STATUS_DESC': '',
        'EXIT_CODE': '',
        'VALIDATION_FLAG' : 'No Issue',
        'EXPECTED_PERIOD_KEY': '',
        'JOB_START_TIME': start_time,
        'JOB_END_TIME': '',
        'PRCS_TYPE': '',
        'LOG_PATH': log_file_name,
        'STAGES': '',
        'SOURCE': {
          'SOURCE_PATH':'',
          'SOURCE_ROW_COUNT':'',
          'SOURCE_AMOUNT':'',
          'SOURCE_FILE_SIZE':''
        },
        'DESTINATION': {
          'DEST_PATH':'',
          'DEST_ROW_COUNT':'',
          'DEST_AMOUNT':'',
          'DEST_FILE_SIZE':'',
          'REJECTED_ROW_COUNT':'',
          'REJECTED_FILE_NAME':''
        }     
    }


try:

    suffixConf = "rawtocurated"

    dataProcessSourceTableConfig = envConfig["data_conf_ing_path"] + str(envConfig["sourceName"])+ "_"  + str(envConfig["tableName"]) + "_" + suffixConf + ".json"
    print(dataProcessSourceTableConfig)
    dataProcessSourceSchemaTableConfig = envConfig["data_conf_ing_path"] + str(envConfig["sourceName"])+ "_" + str(envConfig["schemaName"]) + "_" + str(envConfig["tableName"]) + "_" + suffixConf + ".json"
    print(dataProcessSourceSchemaTableConfig)
    dataProcessSourceSchemaConfig = envConfig["data_conf_ing_path"] + str(envConfig["sourceName"])+ "_" + str(envConfig["schemaName"]) + "_" + suffixConf + ".json"
    print(dataProcessSourceSchemaConfig)
    dataProcessSourceConfig = envConfig["data_conf_ing_path"] + str(envConfig["sourceName"])+ "_"  + suffixConf + ".json"
    print(dataProcessSourceConfig)
    logger.info(dataProcessSourceTableConfig)

    dataprocess_config_file=None
    if os.path.isfile(dataProcessSourceTableConfig):
        dataprocess_config_file = open(str(dataProcessSourceTableConfig),'r').read()
        config = json.loads(dataprocess_config_file)
        logger.info('Reading config from: ' + str(dataProcessSourceTableConfig))

    elif os.path.isfile(dataProcessSourceSchemaTableConfig):
        dataprocess_config_file = open(str(dataProcessSourceSchemaTableConfig),'r').read()
        config = json.loads(dataprocess_config_file)
        logger.info('Reading config from: ' + str(dataProcessSourceSchemaTableConfig))

    elif os.path.isfile(dataProcessSourceSchemaConfig):
        dataprocess_config_file = open(str(dataProcessSourceSchemaConfig),'r').read()
        config = json.loads(dataprocess_config_file)
        logger.info('Reading config from: ' + str(dataProcessSourceSchemaConfig))

    elif os.path.isfile(dataProcessSourceConfig):
        dataprocess_config_file = open(str(dataProcessSourceConfig),'r').read()
        config = json.loads(dataprocess_config_file)
        logger.info('Reading config from: ' + str(dataProcessSourceConfig))

    else:
        logger.info('Source Config is not available '+ str(dataprocess_config_file) + ', Please place the config file in order to execute the job')
        try:
            raise configNotFoundError(dataProcessSourceTableConfig)
        except configNotFoundError as cfe:
            audit_doc = OrderedDict()
            audit_rec=DriverEntry('raw_to_curated',batchDate_formatted,envConfig['sourceName'],envConfig['prcs_runid'],envConfig['pipelineName'],envConfig['triggerName'],'Failed',cfe,start_time)
            audit_doc,exit_doc=utilsShared.gen_audit_dict(audit_doc,exit_doc,audit_rec,cfe)
            metadata_obj.insert_auditRecord(dbutils,envConfig,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
        try:
            dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
        except:
            pass
    #creating raw path
    envConfig['raw-location']="/" +config["M3-ingestion-load"]['raw-path']+envConfig['fileName']+"*"

    if "forecast-plan-flag" in config["M3-ingestion-load"] or "filename-partition-flag" in config["M3-ingestion-load"] :
        target_period_folder_name=""    
    else:
        target_period_folder_name=batchDate_formatted
    #creating curated 
    envConfig['clean-location'] = "/"+ config["M3-ingestion-load"]['curated-path']+ config["M3-ingestion-load"]['target-dir'] + "/" + target_period_folder_name
    envConfig['exception-layer-location'] = "/"+ config["M3-ingestion-load"]['curated-path']+ config["M3-ingestion-load"]['target-dir'] + "/" + batchDate_formatted
    print(envConfig['exception-layer-location'])


     # Adding Common data conf process to envConfig
    if 'M0-common-conf' in config:  # config.has_key("M0-common-conf"):
        envConfig.update(config['M0-common-conf'])
        config.pop('M0-common-conf')
    TABLE_DF = 0
    loc = str(envConfig['varbatchdate'])
    
    for key in sorted(config.keys()):
        logger.info('Processing ' + key)
        val = envConfig.copy()
        val.update(config[key])
        typeValue = val['type']
                                        
        if 'NONE' != typeValue and 'D999-alert-monitor-process'!= key:
            logger.debug(typeValue)
            module = __import__(typeValue)
            function = getattr(module, 'process')
            TABLE_DF,exit_doc = function(val, TABLE_DF,dbutils,exit_doc)
            if TABLE_DF==0:
              break;
     
    try:
      logger.info("Exit dict: " + str({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']}))
      os.makedirs(log_file_folder, exist_ok=True)
      copyfile(local_log_file_name, log_file_name)
      dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
    except:
      pass
except:
    try:
        err_desc = str(traceback.format_exc())
        raise uncatchException(err_desc)
    except uncatchException as cfe:
        print(cfe)
        audit_doc = OrderedDict()
        audit_rec=DriverEntry('raw_to_curated',batchDate_formatted,envConfig['sourceName'],envConfig['prcs_runid'],envConfig['pipelineName'],envConfig['triggerName'],'Failed',cfe,start_time)
        audit_doc,exit_doc=utilsShared.gen_audit_dict(audit_doc,exit_doc,audit_rec,cfe)
        metadata_obj.insert_auditRecord(dbutils,envConfig,spark,audit_doc)
        exit_doc["EXIT_CODE"]=0
        logger.info('ERROR in  Processing file '+ str(envConfig['sourceName']) + '.'+ str(envConfig['tableName']) + '  for date '+ str(envConfig['batchDate']) + str(traceback.format_exc()))
        logger.info('Raw To Curated - Failure Audit Process Completed')
        os.makedirs(log_file_folder, exist_ok=True)
        copyfile(local_log_file_name, log_file_name)
        try:
          dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
        except:
          pass  
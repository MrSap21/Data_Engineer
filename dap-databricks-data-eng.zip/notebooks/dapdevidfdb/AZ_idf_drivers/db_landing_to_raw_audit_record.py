# Databricks notebook source
#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import time
import hashlib
import datetime
import collections
from pyspark import SparkContext
from pyspark.sql import SparkSession, DataFrame, SQLContext
from pyspark.sql import SparkSession, DataFrame, SQLContext
import pandas as pd
import os
import logging
from collections import OrderedDict

# calulating value "millis" for process execution id

millis = int(round(time.time() * 1000))

sys.path.insert(0, '/dbfs/Test/dataintegration/conf/')
import utilsShared

# Read the env Config Properties

envConfig = utilsShared.getEnvConf(0, dbutils)

sys.path.insert(0, envConfig['process_files_ing_path'])

# Taking and setting the variables from activity widget

pipeline_name = dbutils.widgets.get('prm_act_pipeline_name')
source_file = dbutils.widgets.get('prm_act_source_filename')
status = dbutils.widgets.get('prm_act_status')
batchdate = dbutils.widgets.get('prm_act_batch_date')
prcs_runid = dbutils.widgets.get('prm_act_runid')
runid = prcs_runid[:32]
#src_size = dbutils.widgets.get('prm_act_src_filesize')
#tgt_size = dbutils.widgets.get('prm_act_tgt_filesize')
#src_row_cnt = dbutils.widgets.get('prm_act_src_rowcnt')
#tgt_row_cnt = dbutils.widgets.get('prm_act_tgt_rowcnt') 


#batchDate_formatted=datetime.datetime.strptime(str(batchdate), '%Y%m%d')
#batchDate_formatted=datetime.datetime.strftime(batchDate_formatted, '%Y-%m-%d')

index = source_file.rfind('.')
source_file_name = source_file[0:index]
start_time = dbutils.widgets.get('prm_act_start_time')
start_time = start_time[0:19].replace('T', ' ')
src_name = dbutils.widgets.get('prm_act_src_name')

# setting up the logger and log file name

log_filename = str(envConfig['log_path']) + pipeline_name + '_' \
    + src_name + '_' + str(datetime.datetime.now().strftime('%Y%m%d')) \
    + '.log'

from common_logger import Logger
from metadataManager import metadataManager
logger = Logger('db_landing_raw_audit_record', log_filename)

audit_record = OrderedDict()

# try:

metadata_obj = metadataManager()
logger.logging_info('Landing to Raw Audit Process Started')
audit_record['PRCS_NAME'] = 'landing_to_raw'
audit_record['FILE_NAME'] = source_file
audit_record['BATCH_DATE'] = str(datetime.datetime.now().strftime('%Y-%m-%d'))
audit_record['SOURCE_NAME'] = source_file
audit_record['PRCS_EXECUTION_ID'] = runid
audit_record['PIPELINE_NAME'] = pipeline_name
audit_record['TRIG_NAME'] = dbutils.widgets.get('prm_act_trigger_name')
audit_record['STATUS'] = status
audit_record['STATUS_DESC'] = 'Completed Successfully!'
audit_record['JOB_START_TIME'] = start_time
audit_record['JOB_END_TIME'] = \
    str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
audit_record['SOURCE_PATH'] = dbutils.widgets.get('prm_act_source_path')
audit_record['SOURCE_ROW_COUNT'] = '' #int(src_row_cnt)
audit_record['SOURCE_COL_COUNT'] = ''
audit_record['SOURCE_AMOUNT'] = ''
audit_record['SOURCE_FILE_SIZE'] = int(dbutils.widgets.get('prm_act_source_file_size')) #/ 1048576
audit_record['DEST_PATH'] = dbutils.widgets.get('prm_act_target_path')
audit_record['DEST_ROW_COUNT'] = '' #int(tgt_row_cnt)
audit_record['DEST_COL_COUNT'] = ''
audit_record['DEST_AMOUNT'] = ''
audit_record['DEST_FILE_SIZE'] = int(dbutils.widgets.get('prm_act_target_file_size')) #/ 1048576
audit_record['REJECTED_ROW_COUNT'] = ''
audit_record['REJECTED_FILE_NAME'] = ''
audit_record['LOG_PATH'] = log_filename
audit_record['JOB_END_TIME'] = \
    str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

if audit_record['SOURCE_FILE_SIZE'] != audit_record['DEST_FILE_SIZE']:
    print('in ifff')
    audit_record['STATUS'] = 'Failure'
    audit_record['STATUS_DESC'] = \
        'ERROR:File size in source and Raw does not match'
    metadata_obj.insert_auditRecord(dbutils, envConfig, spark,
                                    audit_record)
    raise ValueError('ERROR:File size in source and Raw does not match')

print('before insert')
metadata_obj.insert_auditRecord(dbutils, envConfig, spark, audit_record)
logger.logging_info('Landing to Raw Audit Process Completed')
print('after insert')
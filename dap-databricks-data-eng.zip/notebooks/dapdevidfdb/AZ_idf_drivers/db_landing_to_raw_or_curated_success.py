# Databricks notebook source
import logging
import sys
from pyspark import SparkContext
from pyspark.sql.functions import lit
from pyspark.sql import SQLContext
import time
import hashlib
import datetime
import collections
from pyspark.sql import SparkSession,DataFrame,SQLContext
import sys
from datetime import date

sys.path.insert(0, '/dbfs/Test/dataintegration/conf/')
import utilsShared

# Read the env Config Properties
envConfig = utilsShared.getEnvConf(0,dbutils)

sys.path.insert(0, envConfig["process_files_ing_path"])
from common_logger import Logger
from metadataManager import metadataManager

#taking input parameters
src_file_name= dbutils.widgets.get("prm_act_src_file_name") 
tgt_file_name= dbutils.widgets.get("prm_act_src_file_name")
src_folder_name =dbutils.widgets.get("prm_act_src_folder_name")
tgt_folder_name = dbutils.widgets.get("prm_act_tgt_folder_name")
insert_datetime= dbutils.widgets.get("prm_act_insert_datetime")
pipeline_name = dbutils.widgets.get("prm_act_pipeline_name")
trigger_name= dbutils.widgets.get("prm_act_trigger_name")
status=dbutils.widgets.get("prm_act_status")
errors=dbutils.widgets.get("prm_act_errors")
start_time = dbutils.widgets.get("prm_act_start_time")
start_time = start_time[0:19].replace("T"," ")
end_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
src_row_count=dbutils.widgets.get("prm_act_src_row_count")
tgt_row_count=dbutils.widgets.get("prm_act_tgt_row_count")
tgt_file_size=int(dbutils.widgets.get("prm_act_target_file_size"))
src_file_size=int(dbutils.widgets.get("prm_act_source_file_size"))
process_execution_id = dbutils.widgets.get("prm_act_process_execution_id")
src_name = dbutils.widgets.get("prm_act_src_name")

 
#Generating log path
batch_date = date.today().strftime('%Y%m%d')
log_filename_path=str(envConfig["log_path"])+pipeline_name+"_"+src_name+"_"+batch_date+".log"
#printing the logger information
logger = Logger("log_file",log_filename_path)
logger.logging_info("File copied successfully")
logger.logging_info("Pipeline Name:"+pipeline_name+", Trigger Name:"+trigger_name+", Process Execution Id:"+process_execution_id+", Source File Name:"+src_file_name+", Job Start Time:"+start_time+", Job End Time:"+end_time+", Batch Date:"+batch_date)
logger.logging_info("ERROR:"+errors)
 
#generting auditing records
audit_doc = collections.OrderedDict()
audit_doc["PRCS_NAME"] = "landing to raw/curated"
audit_doc["FILE_NAME"] = str(src_file_name)
audit_doc["BATCH_DATE"]= ''
audit_doc["SOURCE_NAME"]= "NA"
audit_doc["PRCS_EXECUTION_ID"] = process_execution_id
audit_doc["PIPELINE_NAME"] = pipeline_name
audit_doc["TRIG_NAME"] = trigger_name
audit_doc["STATUS"] = status
audit_doc["STATUS_DESC"] = errors
audit_doc["JOB_START_TIME"] = start_time
audit_doc["JOB_END_TIME"] = end_time
audit_doc["SOURCE_PATH"] = str(src_folder_name)
audit_doc["SOURCE_ROW_COUNT"] = src_row_count
audit_doc["SOURCE_COL_COUNT"] = ""
audit_doc["SOURCE_AMOUNT"] = ""
audit_doc["SOURCE_FILE_SIZE"] = int(src_file_size)/1048576
audit_doc["DEST_PATH"] = str(tgt_folder_name)
audit_doc["DEST_ROW_COUNT"] = tgt_row_count
audit_doc["DEST_COL_COUNT"] = ""
audit_doc["DEST_AMOUNT"] = ""
audit_doc["DEST_FILE_SIZE"] = int(tgt_file_size)/1048576
audit_doc["REJECTED_ROW_COUNT"] = ""
audit_doc["REJECTED_FILE_NAME"] = "NA"
audit_doc["LOG_PATH"] = log_filename_path

#creating object of metadataManager class for audit entry
metadata_obj = metadataManager()
try:
  metadata_obj.insert_auditRecord(dbutils,envConfig,spark,audit_doc)
  logger.logging_info("Auditing records of success written in process_execution.txt file")
except:
  logger.logging_info("Auditing records failed to generate")
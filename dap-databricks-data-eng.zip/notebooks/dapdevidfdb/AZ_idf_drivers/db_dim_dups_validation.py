# Databricks notebook source
#!/usr/bin/python
# -*- coding: utf-8 -*-

import traceback
import json
import sys
import logging
import yaml
import datetime
from datetime import date
import os
from collections import OrderedDict
import time
import hashlib

# Custom Library
sys.path.insert(0, '/dbfs/Test/dataintegration/conf/')
import utilsShared

# Read the env Config Properties

print (dbutils)
envConfig = utilsShared.getEnvConf(0, dbutils)

sys.path.insert(0, envConfig['data_config_vault_path'])
sys.path.insert(0, envConfig['process_files_vault_path'])

import pyspark
from pyspark.sql import SparkSession


envConfig["config_name"]=dbutils.widgets.get("config_name")
envConfig['pipelineName']=dbutils.widgets.get("pipelineName")
#envConfig["config_name"]="dim_dup_record_validation"
#envConfig['pipelineName']="manual"

log_filename = envConfig['log_path'] + envConfig['pipelineName'] +"_"+ envConfig['config_name'] + "_"+str(datetime.datetime.strftime(datetime.datetime.now(),'%Y%m%d')) + '.log'

# Logger function

logger = utilsShared.getFormattedLogger('db_dimension_dup_validation',log_filename)
logger.info('Performing Init Activities')

try:
    dataVaultSourceTableConfig=envConfig['data_config_vault_path'] + envConfig["config_name"] + '.json'
    if os.path.isfile(dataVaultSourceTableConfig):
        datavault_config_file = open(str(dataVaultSourceTableConfig),'r').read()
        config = json.loads(datavault_config_file)
        logger.info('Reading config from: '+ str(dataVaultSourceTableConfig))
        print(config)
    # Adding Comman data conf process to envConfig
    if 'D0-common-conf' in config:
        envConfig.update(config['D0-common-conf'])
        config.pop('D0-common-conf')
        exit_doc = {
        'PRCS_NAME': 'dim_dups_validation',
        'STATUS': '',
        'STATUS_DESC': '',
        'DUPLICATES_IN_DIM' :''
    }
    for key in sorted(config.keys()):
        logger.info('Processing ' + key)
        val = envConfig.copy()
        val.update(config[key])
        typeValue = val['type']
        print(typeValue)

        if 'NONE' != typeValue and 'D999-alert-monitor-process'!= key:
            logger.debug(typeValue)
            module = __import__(typeValue)
            function = getattr(module, 'process')
            print(function)
            exit_doc = function(val,exit_doc)
            if exit_doc=='':
              break;
    print(exit_doc)
    try:
      dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc})
    except:
      pass
except:
    # traceback.print_exc()
    logger.info('ERROR in  Processing file '+ str(envConfig['config_name']) +  str(traceback.format_exc()))
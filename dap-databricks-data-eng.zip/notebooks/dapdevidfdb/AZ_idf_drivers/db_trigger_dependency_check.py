# Databricks notebook source
# This Script is to find whether same trigger is running for last run or not
# This Script take 2 parameters config_run which is raw to curated config and run_type is 'File-check' for file check else file-remove 

import traceback
import json
import sys
import logging
import yaml
import datetime
from datetime import date
import os
from collections import OrderedDict
import time
import hashlib


config_run = dbutils.widgets.get('prm_act_file_prefix')
run_type = dbutils.widgets.get('prm_act_run_type')


# Custom Library

sys.path.insert(0, '/dbfs/Test/dataintegration/conf/')
import utilsShared


# Read the env Config Properties
obj = utilsShared.getEnvConf(0,dbutils)

trigger_dependencies_pth=str(obj['azure']['dependency-base-path'])
file_path=trigger_dependencies_pth+config_run

if run_type=='FILE-CHECK':
  try:
    file_check_flag=len(dbutils.fs.ls(file_path))
  except:
      file_check_flag=0    
  if file_check_flag==0:
    dbutils.fs.put(file_path,"") 
elif run_type=='FILE-REMOVAL':
  dbutils.fs.rm(file_path)
  file_check_flag=0
else:
    dbutils.fs.rm(file_path)
    raise Exception(" Job is failed in earlier Activity, please check the failed Activity ")
print(file_check_flag)

try:
  dbutils.notebook.exit(file_check_flag)
except:
  pass
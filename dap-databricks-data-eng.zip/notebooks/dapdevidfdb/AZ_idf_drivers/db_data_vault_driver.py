# Databricks notebook source
#!/usr/bin/python
# -*- coding: utf-8 -*-

import traceback
import json
import sys
import logging
import yaml
import datetime
from datetime import date
import os
from collections import OrderedDict
import time
import hashlib
from shutil import copyfile

# Custom Library
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared

from customException import configNotFoundError,uncatchException
from gen_audit_entry import *

# Read the env Config Properties

print (dbutils)
millis = int(round(time.time() * 1000))
start_time = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

envConfig = utilsShared.getEnvConf(0, dbutils)

sys.path.insert(0, envConfig['data_config_vault_path'])
sys.path.insert(0, envConfig['process_files_vault_path'])

import pyspark
from pyspark.sql import SQLContext
from pyspark.sql import SparkSession


envConfig["sourceName"]=dbutils.widgets.get("prm_act_src_name")
envConfig["schemaName"]=dbutils.widgets.get("prm_act_schema_name")
envConfig["tableName"]=dbutils.widgets.get("prm_act_file_prefix_cur")
envConfig["srcId"]=dbutils.widgets.get("prm_act_src_id")
envConfig["batchDate"]=dbutils.widgets.get("prm_act_batchdate")
envConfig["fileName"]=dbutils.widgets.get("prm_act_filename")
envConfig["pipelineName"]=dbutils.widgets.get("prm_act_pipeline_name")
envConfig["triggerName"]=dbutils.widgets.get("prm_act_trigger_name")
envConfig["opt_path"]=dbutils.widgets.get("prm_act_opt_path")
envConfig["prm_act_src_path_if_any"]=dbutils.widgets.get("prm_act_src_path_if_any")
run_id = dbutils.widgets.get("prm_act_pipeline_id")
envConfig["PRC_EXECUTION_ID"] = run_id     ###run_id[:32]
print("=======>>>>>>"+str(envConfig["PRC_EXECUTION_ID"]))
envConfig['loadDate'] = ''

file_prefix_lst = str(dbutils.widgets.get("prm_act_file_prefix"))
scd_type_lst = dbutils.widgets.get("prm_act_scd_type")
print(file_prefix_lst,envConfig["tableName"])
envConfig['scd_type']=scd_type_lst.split("|")[file_prefix_lst.split("|").index(str(envConfig["tableName"]))]

u_name=dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().apply('user')
print("======="+str(u_name))
envConfig['load_userid'] = u_name[0:u_name.find('@')]
print(envConfig['load_userid'])
var_list = [envConfig["sourceName"],envConfig["schemaName"],envConfig["fileName"]]


local_log_file_name = envConfig["local_log_path"] + envConfig['pipelineName'] + "_"+ envConfig['sourceName'] + "_" + str(envConfig["schemaName"]).replace("/","_") + "_" + str(envConfig["tableName"]).replace("/","_") + "_" +str(datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d_%H%M%S')) + '.log'

envConfig['local_log_file_name'] = local_log_file_name
log_file_name = local_log_file_name.replace(envConfig["local_log_path"], envConfig["log_path"] + "/" + envConfig['triggerName'] + "/" +envConfig['sourceName']+ "/" + str(envConfig["schemaName"]) + "/" + str(envConfig["tableName"]) + "/"+ str(datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')) + "/")

envConfig['log_file_name'] = log_file_name
log_file_folder = "/".join(log_file_name.split("/")[:-1])
# Logger function
os.makedirs(envConfig["local_log_path"], exist_ok=True)
# Logger function

logger = utilsShared.getFormattedLogger("data_vault_driver", local_log_file_name)
logger.info('Performing Init Activities')
logger.info('local_log_file_name' + local_log_file_name)
logger.info('log_file_name' + log_file_name)

exit_doc = {
        'PRCS_NAME': '',
        'FILE_NAME': '',
        'PRCS_EXECUTION_ID': '',
        'STATUS': '',
        'STATUS_DESC': '',
        'EXIT_CODE': '',
        'VALIDATION_FLAG' : '',
        "BUSS_STATUS_DESC" : "",
        "TECH_STATUS_DESC" : "",
        'EXPECTED_PERIOD_KEY': '',
        'JOB_START_TIME': start_time,
        'JOB_END_TIME': '',
        'PRCS_TYPE': '',
        'LOG_PATH': log_file_name ,
        'STAGES': '',
        'SOURCE': {
          'SOURCE_PATH':'',
          'SOURCE_ROW_COUNT':'',
          'SOURCE_AMOUNT':'',
          'SOURCE_FILE_SIZE':''
        },
        'DESTINATION': {
          'DEST_PATH':'',
          'DEST_ROW_COUNT':'',
          'DEST_AMOUNT':'',
          'DEST_FILE_SIZE':'',
          'REJECTED_ROW_COUNT':'',
          'REJECTED_FILE_NAME':''
        }     
    }

sys.path.insert(0, envConfig['process_files_vault_path'])

from metadataManager import metadataManager

batchDate_formatted=datetime.datetime.strptime(envConfig['batchDate'], '%Y%m%d')
batchDate_formatted=datetime.datetime.strftime(batchDate_formatted, '%Y-%m-%d')

metadataObject = metadataManager()
try:
    if envConfig["loadDate"].strip() == "" :
        envConfig["loadDate"] = str(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
        logger.info("Since load date is not provided, considering load datetime as current/Execution timestamp")
    else:
        loadDate_object = datetime.datetime.strptime(envConfig["loadDate"], "%Y%m%d")
        if date.today() == loadDate_object.date():
            envConfig["loadDate"] = str(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
            logger.info("Since load date & execution date is same , load date/time considered as : " + envConfig["loadDate"])
        else:
            envConfig["loadDate"] = loadDate_object.strftime("%Y%m%d%H%M%S")
            logger.info("Since load date & execution date is different , load date/time used as provided : " + envConfig["loadDate"])


    suffixConf = 'datavault'
    dataVaultSourceTableConfig = envConfig['data_config_vault_path']+ str(envConfig['sourceName']) + '_' + str(envConfig['tableName']) + '_' + suffixConf + '.json'
    dataVaultSourceSchemaTableConfig = envConfig['data_config_vault_path'] + str(envConfig['sourceName']) + '_' + str(envConfig['schemaName']) + '_' + str(envConfig['tableName']) + '_' + suffixConf + '.json'
    dataVaultSourceSchemaConfig = envConfig['data_config_vault_path'] + str(envConfig['sourceName']) + '_' + str(envConfig['schemaName']) + '_' + suffixConf + '.json'
    dataVaultSourceConfig = envConfig['data_config_vault_path'] + str(envConfig['sourceName']) + '_' + suffixConf + '.json'
    print(dataVaultSourceTableConfig)

    datavault_config_file = None
    if os.path.isfile(dataVaultSourceTableConfig):
        datavault_config_file = open(str(dataVaultSourceTableConfig),'r').read()
        config = json.loads(datavault_config_file)
        logger.info('Reading config from: '+ str(dataVaultSourceTableConfig))

    elif os.path.isfile(dataVaultSourceSchemaTableConfig):
        datavault_config_file = open(str(dataVaultSourceSchemaTableConfig), 'r').read()
        config = json.loads(datavault_config_file)
        logger.info('Reading config from: '+ str(dataVaultSourceSchemaTableConfig))

    elif os.path.isfile(dataVaultSourceSchemaConfig):
        datavault_config_file = open(str(dataVaultSourceSchemaConfig),'r').read()
        config = json.loads(datavault_config_file)
        logger.info('Reading config from: '+ str(dataVaultSourceSchemaConfig))
    elif os.path.isfile(dataVaultSourceConfig):

        datavault_config_file = open(str(dataVaultSourceConfig), 'r').read()
        config = json.loads(datavault_config_file)
        logger.info('Reading config from: ' + str(dataVaultSourceConfig))
    else:

        logger.info('Source Config is not available '+ str(datavault_config_file)+ ', Please place the config file in order to execute the job')
        try:
            raise configNotFoundError(dataVaultSourceTableConfig)
        except configNotFoundError as cfe:
            audit_doc = OrderedDict()
            audit_rec=DriverEntry('curated_to_enrich',batchDate_formatted,envConfig['sourceName'],envConfig['PRC_EXECUTION_ID'],envConfig['pipelineName'],envConfig['triggerName'],'Failed',cfe,start_time)
            audit_doc,exit_doc=utilsShared.gen_audit_dict(audit_doc,exit_doc,audit_rec,cfe)
            print ('This is checkpoint exit_doc')
            print(exit_doc)
            metadataObject.insert_auditRecord(dbutils,envConfig,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
        try:
            dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
        except:
            pass
    curated_base_path="/dbfs/"+str(envConfig['azure']['clean-base-path'])+"/"
    curated_path=""
    print ('This is checkpoint2')
    for x in var_list:
        if x!="NA":
            curated_base_path = curated_base_path+x+"/"
            if os.path.isdir(curated_base_path):
                curated_path=curated_path+x+"/"
            else:
                break

    batchDate_formatted=datetime.datetime.strptime(envConfig['batchDate'], '%Y%m%d')
    batchDate_formatted=datetime.datetime.strftime(batchDate_formatted, '%Y-%m-%d')

    if "forecast-plan-flag" in config["D1-data-extract-process"]:
        target_period_folder=""
    else:
        target_period_folder=batchDate_formatted

    envConfig['curated-location'] = curated_path + target_period_folder

    # Adding Comman data conf process to envConfig
    print ('This is checkpoint3')
    if 'D0-common-conf' in config:
        envConfig.update(config['D0-common-conf'])
        config.pop('D0-common-conf')
    TABLE_DF = 0
    
    for key in sorted(config.keys()):
        logger.info('Processing ' + key)
        val = envConfig.copy()
        val.update(config[key])
        typeValue = val['type']
        
        if 'NONE' != typeValue and 'D999-alert-monitor-process'!= key:
            logger.debug(typeValue)
            module = __import__(typeValue)
            function = getattr(module, 'process')
            TABLE_DF,exit_doc = function(val, TABLE_DF,dbutils,exit_doc)
            if TABLE_DF==0:
              break;
    try:
      print('Checkpoint-------------------------->')
      #dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'expected_period_key': exit_doc['EXPECTED_PERIOD_KEY'], 'DEST_ROW_COUNT': exit_doc['DESTINATION']['DEST_ROW_COUNT'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
      logger.info("Exit dict: " + str({'AUDIT_RECORDS': exit_doc, 'expected_period_key': exit_doc['EXPECTED_PERIOD_KEY'], 'DEST_ROW_COUNT': exit_doc['DESTINATION']['DEST_ROW_COUNT'], 'ERROR_CODE': exit_doc['ERROR_CODE']}))
      os.makedirs(log_file_folder, exist_ok=True)
      copyfile(local_log_file_name, log_file_name)
      dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'expected_period_key': exit_doc['EXPECTED_PERIOD_KEY'], 'DEST_ROW_COUNT': exit_doc['DESTINATION']['DEST_ROW_COUNT'], 'ERROR_CODE': exit_doc['ERROR_CODE']})

    except:
      
        pass

except:
    try:
        err_desc = str(traceback.format_exc())
        raise uncatchException(err_desc)
    except uncatchException as cfe:
        print(cfe.error_code)
        print(cfe)
        audit_doc = OrderedDict()
               
        audit_rec=DriverEntry('curated_to_enrich',batchDate_formatted,envConfig['sourceName'],PRC_EXECUTION_ID,envConfig['pipelineName'],envConfig['triggerName'],'Failed',cfe,start_time)
        audit_doc,exit_doc=utilsShared.gen_audit_dict(audit_doc,exit_doc,audit_rec,cfe)
        
        #metadata_obj = metadataManager()
        metadataObject.insert_auditRecord(dbutils,envConfig,spark,audit_doc)
        exit_doc["EXIT_CODE"]=0

    # traceback.print_exc()
    logger.info('ERROR in  Processing file '+ str(envConfig['sourceName']) + '.'+ str(envConfig['tableName']) + '  for date '+ str(envConfig['batchDate']) + ' '+ str(traceback.format_exc()))
    dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'expected_period_key': exit_doc['EXPECTED_PERIOD_KEY'], 'DEST_ROW_COUNT': exit_doc['DESTINATION']['DEST_ROW_COUNT']})
    logger.info('Curated to Enrich - Failure Audit Process Completed')
    logger.info("Exit dict: " + str({'AUDIT_RECORDS': exit_doc, 'expected_period_key': exit_doc['EXPECTED_PERIOD_KEY'], 'DEST_ROW_COUNT': exit_doc['DESTINATION']['DEST_ROW_COUNT'], 'ERROR_CODE': exit_doc['ERROR_CODE']}))
    os.makedirs(log_file_folder, exist_ok=True)
    copyfile(local_log_file_name, log_file_name)
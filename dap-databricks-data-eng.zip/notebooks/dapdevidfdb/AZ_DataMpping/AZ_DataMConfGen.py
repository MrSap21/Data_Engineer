# Databricks notebook source
import os
import json
import pyspark
from pyspark.sql import SparkSession
from random import random
import pandas as pd
import re
import numpy as np
import scipy
import pyspark.sql.functions as f

# COMMAND ----------

jdbcHostname = "idfrgsqlmgtinstc.public.2b0dc4dd8ef3.database.windows.net"
jdbcDatabase = "idfappdb"
jdbcPort = 3342
username="AccentureAdminLogin"
password="AccentureSQL2020!"
hostNameInCertificate = "*.2b0dc4dd8ef3.database.windows.net"
jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4};encrypt=true;trustServerCertificate=false;hostNameInCertificate={5};loginTimeout=30;".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password, hostNameInCertificate)
connectionProperties = {
  "user" : username,
  "password" : password,
  "driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}
pushdown_query = "(select jsonValue from dbo.uijsoninput) as t1"
df = spark.read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties)
# baseconf={}
jsonObject=df.collect()[0].asDict()
jsonObject
# commonconf={}
# commonconf['use-case']="Data-Vault"
# commonconf['prcs-name']="clean_to_atomic"
# commonconf['logging-level']="DEBUG"
# baseconf['D0-common-conf']= commonconf
# dataextract={}
# dataextract['type']="data-extract-process"
# dataextract['sourceList']=["source1"]
# baseconf['D1-data-extract-process']=dataextract
# # baseconf
# print(jsonObject)
# if(jsonObject)
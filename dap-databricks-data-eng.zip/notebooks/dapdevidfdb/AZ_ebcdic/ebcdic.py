# Databricks notebook source
from datetime import datetime
from datetime import timedelta
from pyspark.sql.types import StringType
import json
import logging
import os
import glob
import re
import pyspark
import hashlib
import time
from pyspark.sql.functions import udf, lit, col, explode
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext
from pyspark.sql.utils import AnalysisException
import sys
sys.path.insert(0,'/dbfs/dataintegration/process-files-general')
#from metadataManager import metadataManager
import codecs
import ebcdic
import shutil

# COMMAND ----------

# MAGIC %sh 
# MAGIC pip install ebcdic

# COMMAND ----------

def has_column(df, col):
	try:
		df[col]
		return True
	except AnalysisException:
		return False

		
#COMMON
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)
millis = int(round(time.time() * 1000))

def process(argv,envConfig=0):
	batchDate = argv[0]
	fileName = argv[1]
	
	metadataObject = metadataManager(envConfig)
	conf = pyspark.SparkConf()
	spark = SparkSession.builder.appName("DataIntegration").config(conf=conf).getOrCreate()
	sourceConfigFilePath = "/dbfs/dibyajita/ebcdic/gains_rawToClean.json"            	
	logger.info("Reading config from: " + str(sourceConfigFilePath))
	
	targetFormat = 'parquet'
	
	if os.path.isfile(sourceConfigFilePath):
		source_config_file = open(str(sourceConfigFilePath),'r').read()
		config = json.loads(source_config_file)			
	else:
		logger.info("Source Config is not availabe " + str(sourceConfigFilePath) + ", Please place the config file in order to execute the job")
		sys.exit()
		
	# logic to count the no of files in zip
	
	
	if config.has_key('rawPath'):
		rawPath = str(config['rawPath'])
	else:
		rawPath = "/dbfs/dibyajita/rawMount/gains/ebcdic/" 

	if config.has_key('rawPathSplit'):
		rawPathSplit = str(config['rawPathSplit'])
	else:
		rawPathSplit = "/dbfs/dibyajita/rawMount/gains/gains/" 

		
	tempPath = "/dbfs/dibyajita/rawMount/gains/TempFold/" 
	if not os.path.exists(tempPath):
		os.mkdir(tempPath)
  	if not os.path.exists(rawPathSplit):
		os.mkdir(rawPathSplit)

	copyBookDir = "/dbfs/dibyajita/gains-copybook/"
	
	dictOfSchema = config['dictOfSchema']
	
	pathDir = rawPath + str(fileName) 
	filePointer = codecs.open(pathDir,'rb',encoding='cp1148')
	
	if config.has_key('cleanPath'):
		cleanPath = str(config['cleanPath'])
	else:
		cleanPath = "/dbfs/dibyajita/cleanMount/gains/gains/" 
	
	if config.has_key('fileLength'):
		fileLength = int(config['fileLength'])
	else:
		fileLength = 470
	
	allLines = filePointer.read()
	numOfRows = int(len(allLines)/fileLength)
	
	dictOfSplits = {}		  
	for keyName in dictOfSchema.keys():
		dictOfSplits[keyName] = []

	for i in range(0,numOfRows):  
		rowSplit = allLines[i*fileLength:(i+1)*fileLength]
		for keyName in dictOfSchema.keys():
			if eval(dictOfSchema[keyName]['condition']):
				dictOfSplits[keyName].append(rowSplit)
	
	# Split and flatten all the tags
	for tagName in dictOfSplits.keys():
		logger.debug('Tag Name being processed : ' + tagName)
		if not os.path.exists(tempPath):
			os.mkdir(tempPath)
		try:
			copyBookPath = copyBookDir + dictOfSchema[tagName]['copyBook']
			rawPathSplitCsv = rawPathSplit + tagName.lower() + "/" + tagName.lower() + "_" + str(batchDate) + ".csv"
			tempEbcdicPath = "/dbfs/dibyajita/rawMount/gains/TempFold/" + tagName + "_" + str(batchDate) + ".txt"
			sparkTempPath = "/dbfs/dibyajita/rawMount/gains/TempFold/" + tagName + "_" + str(batchDate) + ".txt"
			if not os.path.exists(rawPathSplit + tagName.lower()):
				os.mkdir(rawPathSplit + tagName.lower())
			fw = codecs.open(tempEbcdicPath,'w',encoding='cp1148')
			for line in dictOfSplits[tagName]:
				fw.write(line)
			fw.close()
			logger.debug("copybook path: "+ copyBookPath)
			logger.info(tagName + " reading into Dataframe")
			splitDF = spark.read.format("cobol") \
					.option("copybook", copyBookPath ) \
					.option("schema_retention_policy","collapse_root") \
					.load(sparkTempPath)
			splitRowCount = splitDF.count()
			logger.info("DF row count:"+ str(splitRowCount))
			ListTypes = [c[0] for c in splitDF.dtypes if c[1][:6] == "struct" or c[1][:5] == "array"]
			while len(ListTypes) > 0:
				splitDF=flatten_DF(splitDF)
				ListTypes = [c[0] for c in splitDF.dtypes if c[1][:6] == "struct" or c[1][:5] == "array"]
			#splitDF = inputDF.select(listOfTags)
			logger.info(tagName + " flattened")
			splitDF = splitDF.withColumn("ETLBATCHID", lit(hashlib.md5(str(millis).encode()).hexdigest()))
			splitDF = splitDF.toDF(*(re.sub(r'[\,\s;\n\t\={}()]+-', '_', c) for c in splitDF.columns))

			pandasSplitDF = splitDF.toPandas()
			logger.info("writing split csv : " + tagName + " to Raw at path : "+ rawPathSplitCsv)
			pandasSplitDF.to_csv(rawPathSplitCsv,index = False)
			
			output = cleanPath + tagName.lower() + "/" + str(batchDate) 
			
			logger.info("writing split  : " + tagName + " at path : "+ output)
			
			splitDF.write.mode('overwrite').save(output,format=targetFormat)
			logger.info(tagName + " written to Clean")


			document={}
			document['FILE_NAME']= tagName
			document['PRCS_NAME']= 'raw_to_clean'
			document['JOB_START_TIME']= datetime.now()
			document['SOURCE_ROW_COUNT']= '0'
			document['DEST_ROW_COUNT']= str(splitDF.count())
			document['DEST_COL_COUNT']=str(len(splitDF.columns))
			document['DEST_FILE_SIZE']='0'
			document['STATUS']='Success'
			document['SOURCE_PATH']=str(pathDir)
			document['DEST_PATH']=output
			envConfig['sourceName']='gains'
			envConfig['schemaName']='gains'
			envConfig['batchDate']=str(batchDate)
			
			metadataObject.insert_auditRecord_dataflow(envConfig,document)
			logger.info("Inserting Success Audit Entry for " +  tagName)

		except :
			logger.error("Data for table Not available in files, Skipping  : " + tagName)
			document={}
			document['FILE_NAME']= tagName
			document['PRCS_NAME']= 'raw_to_clean'
			document['JOB_START_TIME']= datetime.now()
			document['SOURCE_ROW_COUNT']= "0"
			document['DEST_ROW_COUNT']= "0"
			document['DEST_COL_COUNT']="0"
			document['DEST_FILE_SIZE']='0'
			document['STATUS']='Failure'
			document['SOURCE_PATH']=str(pathDir)
			document['DEST_PATH']='NA'
			envConfig['sourceName']='gains'
			envConfig['schemaName']='gains'
			envConfig['batchDate']=str(batchDate)
			
			metadataObject.insert_auditRecord_dataflow(envConfig,document)
			logger.info("Inserting Failure Audit Entry for " +  tagName)
		finally :
			logger.info("process finished for: " + tagName)
	
	try:
		if os.path.exists(tempPath):
			shutil.rmtree(tempPath)
	except:
		logger.debug("error deleting the temp folder")
def flatten_DF(nested_df):
    flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != 'struct']
    nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == 'struct' ]                             
    #print(nested_cols)  
    flat_df = nested_df.select(flat_cols +
                               [col(nc+'.'+c).alias(nc+'_'+c.replace(" ",""))
                                for nc in nested_cols
                                for c in nested_df.select(nc+'.*').columns]                                
                              )    
    
    nested_cols_array = [c[0] for c in flat_df.dtypes if c[1][:5] == 'array']   
    
    for nc2 in nested_cols_array:     
      #print nc2
      #print flat_df.columns
      flat_df = flat_df.withColumn(nc2,explode(nc2))      
      
    return flat_df
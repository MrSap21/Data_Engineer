# Databricks notebook source

dbutils.widgets.dropdown("TypeOfSearch", "searchText", ['searchText','transformModuleSearch','both'])
typeOfSearch = dbutils.widgets.get("TypeOfSearch")

dbutils.widgets.dropdown("TransformToSearch", "hash-key", ['hash-key','derived-key-process','default-value','concat_sep'])
moduleToSearch = dbutils.widgets.get("TransformToSearch")

dbutils.widgets.text('SearchText', "","")
textTosearch=str(dbutils.widgets.get('SearchText').lower())


import traceback
import json
import sys
import logging
import yaml
from datetime import datetime,date
import os

# Custom Library
sys.path.insert(0,'/dbfs/mnt/mountdatalake/data_process_demo/process_files/')
import utilsShared

# Logger function
logger = utilsShared.getFormattedLogger(__name__)
logger.info("Performing Init Activities")
import json
rootPath = '/dbfs/mnt/mountdatalake/data_process_demo/data_conf/'
          



# COMMAND ----------

# DBTITLE 1,Module Search
import pprint

if typeOfSearch == 'both' or typeOfSearch == "transformModuleSearch":
  for fileName in os.listdir(rootPath):
    dataprocess_config_file = open(str(rootPath) + fileName ,'r').read()
    configSource = json.loads(dataprocess_config_file)			
    for moduleName in configSource.keys():
      if 'type' in configSource[moduleName].keys():
        if configSource[moduleName]['type'] == 'data-transform-process':
          for tranModule in configSource[moduleName].keys():
            if isinstance(configSource[moduleName][tranModule],dict) and 'type' in configSource[moduleName][tranModule].keys():
              if configSource[moduleName][tranModule]['type'] == moduleToSearch:
                logger.info("Found the Module : " + moduleToSearch + " in config file : "+ fileName )
                logger.info("Sample module usage is as below")
                pprint.pprint(configSource[moduleName][tranModule])
            if isinstance(configSource[moduleName][tranModule],dict) and 'process' in configSource[moduleName][tranModule].keys() :
              if configSource[moduleName][tranModule]['process'] == moduleToSearch:
                logger.info("Found the Module : " + moduleToSearch + " in config file : "+ fileName )
                logger.info("Sample module usage is as below")
                pprint.pprint(configSource[moduleName][tranModule])          


# COMMAND ----------

# DBTITLE 1,Text Search
if typeOfSearch == 'both' or typeOfSearch == "searchText":
  for fileName in os.listdir(rootPath):
    with open(str(rootPath) + fileName ,'r') as configFile:
      for num, line in enumerate(configFile, 1):
          if textTosearch in line.lower():
              logger.info("Found the module " + textTosearch + " in file : " + fileName + " at line  " + str(num))
    
# Databricks notebook source
import traceback
import json
import sys
import logging
import yaml
from datetime import datetime,date
import os

# Custom Library
sys.path.insert(0,'/dbfs/mnt/mountdatalake/data_process_demo/process_files/')
import utilsShared

# Logger function
logger = utilsShared.getFormattedLogger(__name__)
logger.info("Performing Init Activities")
# Read the env Config Properties
envConfig = utilsShared.getEnvConf(logger,dbutils)
logger.info("Loading pyfiles from  : /dbfs/mnt/mountdatalake/data_process_demo/process_files")



####################################################################################################
listOfArg = ["sourceName","schemaName","tableName","batchDate","loadDate","batchEndDate","batchID"]
for keyValue in listOfArg:
	dbutils.widgets.text(keyValue, "","")
	envConfig[keyValue]=str(dbutils.widgets.get(keyValue).lower())
	logger.info(str(keyValue) + " value is: " + envConfig[keyValue])

if envConfig["loadDate"].strip() == "" :
	envConfig["loadDate"] = str(datetime.now().strftime("%Y%m%d%H%M%S"))
	logger.info("Since load date is not provided, considering load datetime as current/Execution timestamp")
else:
	loadDate_object = datetime.strptime(envConfig["loadDate"], "%Y%m%d")
	if date.today() == loadDate_object.date() :
		envConfig["loadDate"] = str(datetime.now().strftime("%Y%m%d%H%M%S"))
		logger.info("Since load date & execution date is same , load date/time considered as : " + envConfig["loadDate"])
	else :
		envConfig["loadDate"] = loadDate_object.strftime("%Y%m%d%H%M%S")
		logger.info("Since load date & execution date is different , load date/time used as provided : " + envConfig["loadDate"])

confFolderName = "fileload"
suffixConf = "fileLoad"

dataProcessSourceTableConfig = "/dbfs/mnt/mountdatalake/data_process_demo/data_conf/" + str(envConfig["sourceName"])+ "_"  + str(envConfig["tableName"]) + "_" + suffixConf + ".json" 
dataProcessSourceSchemaTableConfig = "/dbfs/mnt/mountdatalake/scdpoc_codebase/data_conf/" + str(envConfig["sourceName"])+ "_" + str(envConfig["schemaName"]) + "_" + str(envConfig["tableName"]) + "_" + suffixConf + ".json" 
dataProcessSourceSchemaConfig = "/dbfs/mnt/mountdatalake/scdpoc_codebase/data_conf/" + str(envConfig["sourceName"])+ "_" + str(envConfig["schemaName"]) + "_" + suffixConf + ".json" 
dataProcessSourceConfig = "/dbfs/mnt/mountdatalake/scdpoc_codebase/data_conf/" + str(envConfig["sourceName"])+ "_"  + suffixConf + ".json" 


logger.info("Reading ETL Config")
if os.path.isfile(dataProcessSourceTableConfig):
	dataprocess_config_file = open(str(dataProcessSourceTableConfig),'r').read()
	config = json.loads(dataprocess_config_file)			
elif os.path.isfile(dataProcessSourceSchemaTableConfig):
	logger.info("Reading config from: " + str(dataProcessSourceSchemaTableConfig) + " since file is not available at " + str(dataProcessSourceSchemaTableConfig))
	dataprocess_config_file = open(str(dataProcessSourceSchemaTableConfig),'r').read()
	config = json.loads(dataprocess_config_file)			
else:
	logger.info("Data Config is not availabe " + str(dataProcessSourceTableConfig) +  " or " + str(dataProcessSourceSchemaTableConfig) + ", Please place the config file in order to execute the job")
	sys.exit()

logger.info("Reading Source/Schema Level Config if available")
if os.path.isfile(dataProcessSourceSchemaConfig):
	dataprocess_config_file = open(str(dataProcessSourceSchemaConfig),'r').read()
	configSource = json.loads(dataprocess_config_file)			
	envConfig.update(configSource)
elif os.path.isfile(dataProcessSourceConfig):
	logger.info("Reading config from: " + str(dataProcessSourceConfig) + " since file is not available at " + str(dataProcessSourceSchemaConfig))
	dataprocess_config_file = open(str(dataProcessSourceConfig),'r').read()
	configSource = json.loads(dataprocess_config_file)			
	envConfig.update(configSource)

# Setting up Spark properties for the source level
if envConfig.has_key("spark-properties"):
	for keyName in envConfig["spark-properties"].keys():
		spark.conf.set(str(keyName), envConfig["spark-properties"][keyName])


try:
	# Adding Comman data conf process to envConfig
	if config.has_key("D0-common-conf"):
		envConfig.update(config["D0-common-conf"])
		config.pop("D0-common-conf")
	TABLE_DF = 0
	
	for key in sorted(config.iterkeys()):			
		
		logger.info("Processing " + key)
		val = envConfig.copy()
		val.update(config[key])
		typeValue =  val['type']
		if "NONE" != typeValue and "D999-alert-monitor-process" != key:
			logger.debug(typeValue)
			module = __import__(typeValue)
			function = getattr(module , 'process')
			TABLE_DF = function(val,TABLE_DF)
		#if
	#for
#try
except:
	#traceback.print_exc()
	raise ValueError("ERROR in  Processing file " + str(envConfig["sourceName"]) + "." + str(envConfig["tableName"]) +  " in subprocess : " + str(typeValue) + " " + str(traceback.format_exc()))
#except

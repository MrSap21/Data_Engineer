# Databricks notebook source
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
from datetime import datetime
import pandas as pd
import os
import sys
import adal
import pandas as pd
import unicodedata
import re
import pyspark
from pyspark.sql import SparkSession


def get_database_conn_props():
  sql_principalClientId = "fdf68c11-b579-4eb3-90f1-a89b3f61135a"
  sql_principalSecret = dbutils.secrets.get(scope = "dapdevdatascope", key = "devdnasqldb")
  sql_TenantId = "92cb778e-8ba7-4f34-a011-4ba6e7366996"
  sql_authority = "https://login.windows.net/" + sql_TenantId
  sql_resource_app_id_url = "https://database.windows.net/"
  context = adal.AuthenticationContext(sql_authority)
  sql_token = context.acquire_token_with_client_credentials(sql_resource_app_id_url, sql_principalClientId, sql_principalSecret)
  sql_access_token = sql_token["accessToken"]
  hostNameInCertificate = '*.database.windows.net'
  connectionProperties = {"accessToken" : sql_access_token,"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
  return connectionProperties

def get_database_conn_string():
  jdbcHostname ='dapdevsqlsrv01.database.windows.net'
  jdbcDatabase = 'dapdevsqldb01'
  conn_string = 'jdbc:sqlserver://' + str(jdbcHostname) + ';database=' + str(jdbcDatabase)+';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
  return conn_string

def get_qry_string(feedId):
  queryString = "(SELECT DataProperties,HeaderInfo,Delimiter FROM idfwba.Feed where FeedID ='"+feedId+"') as t1"
  return queryString

def get_data_frm_fileList(paths,headerExists,delim):
        df = spark.read.format("csv").option("header", headerExists).\
            option('delimiter', delim).\
            option('mode', 'DROPMALFORMED').\
            load(paths.split(','))
        return df

def copy_data_to_singleFile(df,fileName,delim):
    df.repartition(1).write.mode('overwrite').option("delimiter", delim).option("header", "true").csv(fileName)

def get_data_frm_filePattern(filePatternWithPath,headerExists,delim):
        df = spark.read.format("csv").option("header", headerExists).\
            option('delimiter', delim).\
            option('mode', 'DROPMALFORMED').\
            load(filePatternWithPath)
        return df

def get_schema_frm_json (resultList):
      schemaJsonDF = spark.read.option("multiline", "true").json(sc.parallelize([resultList]))
      schemaJsonDF.show(truncate=False)
      schemaJsonPanda = schemaJsonDF.select("columnName","columnType").toPandas()
      print(schemaJsonPanda)
      listOfCols = schemaJsonPanda['columnName'].values.tolist()
      print(listOfCols)
      return listOfCols

def normalize(column: str) -> str:
    n = re.sub(r"[ ,;{}()\n\t=]+", '_', column.lower())
    return unicodedata.normalize('NFKD', n).encode('ASCII', 'ignore').decode()

def copy_data_to_singleParquetFile(df_with_schema,fileName):
    normalize_df = df_with_schema.toDF(*map(normalize, df_with_schema.columns))
    normalize_df.repartition(1).write.mode('overwrite').parquet(fileName)
  
def get_data_with_or_without_header(headerIn,fileAdlsPaths,in_delim,resultList,output_path,out_delim):
      if headerIn is True:
        print("Header Info available in Feed Table => " + str(headerIn))
        headerExists = "true"
        df_with_schema = get_data_frm_fileList(fileAdlsPaths,headerExists,in_delim)
        df_with_schema.printSchema()
        df_with_schema.count()
        df_with_schema.show()
        df_write = copy_data_to_singleFile(df_with_schema,output_path,out_delim)
        #df_write = copy_data_to_singleParquetFile(df_with_schema,output_path)
      elif headerIn is False:
        print("Header Info available in Feed Table => " + str(headerIn))
        headerExists = "false"
        listOfCols = get_schema_frm_json (resultList)
        df_with_schema = get_data_frm_fileList(fileAdlsPaths,headerExists,in_delim)
        df_with_schema.printSchema()
        df_with_schema.count()
        df_with_schema.show()
        df_with_schema_cols = df_with_schema.rdd.map(list).toDF(listOfCols)
        df_with_schema_cols.show()
        df_write = copy_data_to_singleFile(df_with_schema_cols,output_path,out_delim)
        #df_write = copy_data_to_singleParquetFile(df_with_schema_cols,output_path)
      else: 
        print("Header Info available in Feed Table => " + str(headerIn))


#################################################################################################################################################
#          Param Values                                                                                                                         #
#################################################################################################################################################

#feedid = '198'
#feedid = '154'
feedid = dbutils.widgets.get('prm_feedid')
print(">>>>>>>feedid<<<<<<<<<<<<<<<<<"+feedid)
output_path = dbutils.widgets.get('prm_output_path')
fileAdlsPaths = dbutils.widgets.get('prm_fileAdlsPaths')

#output_path = "dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feed_results"
#fileAdlsPaths = "dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_1.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_2.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_3.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_4.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_5.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_6.csv"

#fileAdlsPaths = "dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds/test_1.csv"

#fileAdlsPaths = "dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds_with_header/test_1.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds_with_header/test_2.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds_with_header/test_3.csv,dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds_with_header/test_4.csv"

#fileAdlsPaths = "dbfs:/mnt/idfwbadevmount/idfappdata/idfdata/idfwba/raw/abinitio/test_feeds_with_header/test_1.csv"


#################################################################################################################################################
#          Param   values                                                                                                                       #
#################################################################################################################################################
        
#################################################################################################################################################
#          Declarative values                                                                                                                   #
#################################################################################################################################################
  

reqColumn = "DataProperties"
headerCol = "HeaderInfo"
delimiterCol = "Delimiter"
out_delim = ","

#################################################################################################################################################
#          Declarative values                                                                                                                  #
#################################################################################################################################################

try: 

  #################################################################################################################################################
  #          Json schema parsing and data files  load processing                                                                                  #
  #################################################################################################################################################
  
  spark = SparkSession.builder.appName("Schema Less Data File Process").getOrCreate()
  schemaDF = spark.read.jdbc(url=get_database_conn_string(), table=get_qry_string(feedid), properties=get_database_conn_props());
  headerIn = schemaDF.select(headerCol).collect()[0][0]
  print("Header Info available in Feed Table => " + str(headerIn))
  resultList = schemaDF.select(reqColumn).collect()[0][0]
  print("Json available in Feed Table => ")
  print(resultList)
  in_delim = schemaDF.select(delimiterCol).collect()[0][0]
  print(in_delim)
  print("Data feed delimiter available in Feed Table => " + str(in_delim))
  get_data_with_or_without_header(headerIn,fileAdlsPaths,in_delim,resultList,output_path,out_delim)
  
except Exception as e: 
    print(e)
pass

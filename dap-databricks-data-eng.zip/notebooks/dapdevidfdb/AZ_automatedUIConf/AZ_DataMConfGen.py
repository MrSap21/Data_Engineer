# Databricks notebook source
import os
import sys
import json
import pyspark
from pyspark.sql import SparkSession
from random import random
import pandas as pd
import re
import numpy as np
import scipy
import pyspark.sql.functions as f
import time 
import datetime 
from datetime import datetime
import logging
import traceback
import yaml
from pyspark.sql.functions import current_timestamp
from pyspark.sql.functions import col
# Custom Library
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
# Logger function
logger = utilsShared.getFormattedLogger(__name__)
logger.info("Performing Init Activities")

# COMMAND ----------

envConfig = utilsShared.getEnvConf(logger,dbutils)
try:
  if "sqlserver" in envConfig.keys():
    jdbcHostname = envConfig['sqlserver']['jdbcHostname']
    jdbcDatabase = envConfig['sqlserver']['jdbcDatabase']
    jdbcPort = envConfig['sqlserver']['jdbcPort']
#     username=envConfig['sqlserver']['username']
#     password=envConfig['sqlserver']['password']
    sql_access_token=envConfig["sqlserver"]["sql_access_token"]
    hostNameInCertificate = envConfig['sqlserver']['hostNameInCertificate']
    jdbcUrl = envConfig['sqlserver']['jdbc-connection-string']
    jdbcUrl=jdbcUrl.format(jdbcHostname, jdbcPort, jdbcDatabase, hostNameInCertificate)
    connectionProperties = {"accessToken" : sql_access_token,"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
except:
  logger.info("Sql server properties are missing")
  raise ValueError("Sql server properties are missing "+ str(traceback.format_exc()))

# COMMAND ----------

pushdown_query = "(select * from idfwba.uijsoninput order by Modified_time desc OFFSET 0 ROWS) as t1"
df = spark.read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties)
df1 = df.withColumn("current_time",current_timestamp())
df2 = df1.withColumn("date_diff_min",(f.col("current_time").cast("long") - f.col("Modified_time").cast("long"))/60.).filter(col("date_diff_min") < 2)
null = None
isNull = True
####### Modfied time dataobject##############################
for item in df2.collect():
  jsonObject = item.asDict()
  if 'ID' in jsonObject.keys():
    id= jsonObject['ID']
    #print(id)
  else:
    id="batch_id"
  if 'Modified_time' in jsonObject.keys():
    modified_time= jsonObject['Modified_time']
    modified_time1=datetime.now().strftime("%m_%d_%Y_%H_%M_%S")
    #print(modified_time1)
  else:
    modified_time=datetime.now().strftime("%m_%d_%Y_%H_%M_%S")
  batchtime=id+str(modified_time)
  baseconf={}
  commonconf={}
  commonconf['use-case']="DataIntegration"
  commonconf['prcs-name']="raw_to_curated"
  commonconf['logging-level']="DEBUG"
  baseconf['M0-common-conf']=commonconf
  for k,v in jsonObject.items():
    if k=="jsonValue":
      obj= json.loads(jsonObject['jsonValue'])
      for x in range(len(obj)):
        fobj=obj[x]
        #print(fobj)
        if fobj['type']=='Data Source Properties':
          logger.info("In Data Source Properties")
        elif fobj['type']=='Data Attribute Properties':
          logger.info("In Data Attribute Properties")
          var2='M3-ingestion-load'
          dataextract={}
          if 'sourceDataType' in fobj['fields'] and 'fileUpload' == fobj['fields']['sourceDataType']:
            if 'config'in fobj['fields']:
              if 'sourceList' in fobj['fields']['config']:
                for srclist in fobj['fields']['config']['sourceList']:
                  raw_path=fobj['fields']['config'][srclist]['path']
                  src_filename=fobj['fields']['config'][srclist]['file-name']
                  file_schema=[]
                  pobj=json.loads(fobj['fields']['dataProperties'])
                  for x in range(len(pobj)):
                    coldef={}
                    dobj=pobj[x]
                    coldef['col_name']=dobj['columnName']
                    coldef['default_value']=null
                    coldef['isNullable']=isNull
                    if 'int64' == dobj['columnType']:
                      coldef['datatype']='int'
                    elif 'float64' == dobj['columnType']:
                      coldef['datatype']='float'
                    else:
                      coldef['datatype']=dobj['columnType']
                    file_schema.append(coldef)
              targetPath=fobj['fields']['attTargetPath']
              curatedPath=id + '/'
              file_extension=src_filename.split(".")[-1]
            #if file_extension == 'csv':
              #dataextract['type']='csv-batch-ingestion-process'
            if file_extension == 'json':
              dataextract['type']='json-batch-ingestion-process'
            elif file_extension == 'xml':
              dataextract['type']='xml-batch-ingestion-process'
            else:
              dataextract['type']='txt-batch-ingestion-process'
            dataextract['delimiter']=','
            dataextract['header']='true'
            dataextract['sampling-ratio-schema-validation']='0.05'
            dataextract['data-profile']='false'
            dataextract['raw-path']=raw_path[1:]
            dataextract['curated-path']=curatedPath
            dataextract['target-dir']=targetPath
            dataextract['target-format']='parquet'
            dataextract['comment']=''
            dataextract['skippedRows']='0'
            dataextract['src_filename']=src_filename
            dataextract['nullValue']='#MI'	
            dataextract['file_schema']=file_schema
          elif 'sourceDataType' in fobj['fields'] and 'tableUpload' == fobj['fields']['sourceDataType']:
            #print(fobj['fields'])
            targetPath=fobj['fields']['attTargetPath']
            curatedPath=fobj['fields']['attTargetZone']
            dataextract['databaseName']=fobj['fields']['databaseName']
            dataextract['tableName']=fobj['fields']['tableName']
            dataextract['target-format']='parquet'
            dataextract['curated-path']=curatedPath
            dataextract['target-dir']=targetPath
          baseconf[var2]=dataextract
        elif fobj['type']=='Data Curation Rules':
          logger.info("In Data Curation Rules")
          var3='M5-rules-engine-process'
          dataextract={}
          dataextract['type']='data-rules-engine-process'
          dataextract['multi-folder']='FALSE'
          dataextract['delimiter']='NA'
          dataextract['target-format']='parquet'
          data_rules=[]
          if 'dataset' in fobj['fields']:
            datasetType=fobj['fields']['dataset']
            #if datasetType == 'Remove Blank/NA':
                #blank = {}
                #blank['pattern'] = 'functional'
                #blank['with'] = 'dropna'
                #blank['col'] = ''
                #blank['newcol'] = ''
                #data_rules.append(blank)
          if 'curationRules' in fobj['fields']:
                x=json.loads(fobj['fields']['curationRules'])
                for rules in x:
                  if 'replace value' == rules["pattern"].lower():
                    y=json.loads(rules['rule'])
                    expression=y['value']
                    expressionName=y['name']
                    rep_val={}
                    rep_val['pattern'] ='replacevalue'
                    if 'Exact' in rules['columnType']:
                      rep_val['columnType'] = rules['columnType']
                      if rules['renameColumn'] == '':
                        rules['renameColumn'] = rules['columnName']
                      rep_val['newcol'] = rules['renameColumn']
                      rep_val['col'] = rules['columnName']
                    elif 'Alias' in rules['columnType']:
                      rep_val['columnType'] = rules['columnType']
                      rep_val['col'] = rules['aliasTypes']
                    else:
                      pass
                    rep_val['rule'] = expressionName
                    rep_val['with'] = rules['newValue']
                    rep_val['on'] = rules['existingValue'] 
                    rep_val['grp'] = rules['group']
                    data_rules.append(rep_val)
                  elif 'replace partial value' == rules["pattern"].lower():
                      y=json.loads(rules['rule'])
                      expression =y['value']
                      expressionName =y['name']
                      rep_par={}
                      rep_par['pattern'] = 'replacepartial'
                      if 'Exact' in rules['columnType']:
                        if rules['renameColumn'] == '':
                          rules['renameColumn'] = rules['columnName']
                        rep_par['columnType'] = rules['columnType']
                        rep_par['newcol'] = rules['renameColumn']
                        rep_par['col'] = rules['columnName']
                      elif 'Alias' in rules['columnType']:
                        rep_par['columnType'] = rules['columnType']
                        rep_par['col'] = rules['aliasTypes']
                      else:
                        pass
                      rep_par['rule'] = expressionName
                      rep_par['with'] = rules['newValue']
                      rep_par['on'] = rules['existingValue']
                      rep_par['grp'] = rules['group']
                      data_rules.append(rep_par)
                  elif 'compliance' == rules["pattern"].lower():
                    compl={}
                    compl['pattern'] = 'anonymization'
                    if 'Exact' in rules['columnType']:
                      compl['columnType'] = rules['columnType']
                      if rules['renameColumn'] == '':
                          rules['renameColumn'] = rules['columnName']
                      compl['newcol'] = rules['renameColumn']
                      compl['col'] = rules['columnName']
                    elif 'Alias' in rules['columnType']:
                      compl['columnType'] = rules['columnType']
                      compl['col'] = rules['aliasTypes']
                    else:
                      pass
                    y=json.loads(rules['rule'])
                    if y['name'] == 'Base 64':
                      y['name'] = 'base64'
                    compl['with'] = y['name']
                    data_rules.append(compl)
                  elif 'imputation' == rules["pattern"].lower():
                    #print(rules)
                    imput={}
                    imput['pattern'] = 'imputation'
                    if 'Exact' in rules['columnType']:
                      imput['columnType'] = rules['columnType']
                      if rules['renameColumn'] == '':
                          rules['renameColumn'] = rules['columnName']
                      imput['newcol'] = rules['renameColumn']
                      imput['col'] = rules['columnName']
                    elif 'Alias' in rules['columnType']:
                      imput['columnType'] = rules['columnType']
                      imput['col'] = rules['aliasTypes']
                    else:
                      pass
                    y=json.loads(rules['rule'])
                    imput['rule'] = y['name']
                    #imput['value'] =y['value']
                    data_rules.append(imput)
                  elif 'date standardization' == rules["pattern"].lower():
                    #print(rules)
                    dt_stand={}
                    dt_stand['pattern'] = 'datestandardization'
                    if 'Exact' in rules['columnType']:
                      dt_stand['columnType'] = rules['columnType']
                      if rules['renameColumn'] == '':
                          rules['renameColumn'] = rules['columnName']
                      dt_stand['newcol'] = rules['renameColumn']
                      dt_stand['col'] = rules['columnName']
                    elif 'Alias' in rules['columnType']:
                      dt_stand['columnType'] = rules['columnType']
                      dt_stand['col'] = rules['aliasTypes']
                    else:
                      pass
                    y=json.loads(rules['rule'])
                    dt_stand['rule'] = y['name']
                    data_rules.append(dt_stand)
                  elif 'functional' == rules["pattern"].lower():
                      fun = {}
                      y=json.loads(rules['rule'])
                      expression =y['value']
                      fun['pattern'] = 'functional'
                      if 'Exact' in rules['columnType']:
                        fun['columnType'] = rules['columnType']
                        if rules['renameColumn'] == '':
                          rules['renameColumn'] = rules['columnName']
                        fun['newcol'] = rules['renameColumn']
                        fun['col'] = rules['columnName'] 
                      elif 'Alias' in rules['columnType']:
                        fun['columnType'] = rules['columnType']
                        fun['col'] = rules['aliasTypes']
                      else:
                        pass
                      fun['rule']=y['name']
                      if 'lower case' in expression.lower():
                        fun['with'] ='lower'
                      elif 'upper case' in expression.lower():
                        fun['with'] = 'upper'
                      elif 'remove accent' in expression.lower():
                        fun['with'] = 'removeaccent'
                      elif 'accent remove' in expression.lower():
                        fun['with'] = 'accentremove'
                      elif 'prefix' in expression.lower():
                        fun['with'] = 'prefix'
                        fun['value'] =rules['functValue']
                      elif 'suffix' in expression.lower():
                        fun['with'] = 'suffix'
                        fun['value'] =rules['functValue']
                      elif 'concat' in expression.lower():
                        fun['with'] = 'concat'
                        fun['value'] =rules['functValue']
                      elif 'Substring' in expression.lower():
                        fun['with'] = 'substring'
                        fun['start'] = rules['startPos']
                        fun['length'] = rules['length']
                      elif 'left trim' in expression.lower():
                        fun['with'] = 'ltrim'
                      elif 'right trim' in expression.lower():
                        fun['with'] = 'rtrim'
                      elif 'left padding' in expression.lower():
                        fun['with'] = 'lpad'
                        fun['value'] =rules['functValue']
                      elif 'right padding' in expression.lower():
                        fun['with'] = 'rpad'
                        fun['value'] =rules['functValue']
                      elif 'split' in expression.lower():
                        fun['with'] = 'split'
                        fun['value'] =rules['functValue']
                      elif 'trimdoublequotes' in expression.lower():
                        fun['with'] = 'trimdoublequotes'
                      elif 'camelcase' in expression.lower():
                        fun['with'] = 'camelcase'
                      elif 'base64' in expression.lower():
                        fun['with'] = 'base64'
                      elif 'dropduplicates' in expression.lower():
                        fun['with'] = 'dropduplicates'
                      elif 'dropna' in expression.lower():
                        fun['with'] = 'dropna'
                      elif 'rename' in expression.lower():
                        fun['with'] = 'rename'
                      elif 'drop' in expression.lower():
                        fun['with'] = 'drop'
                      data_rules.append(fun)
                  elif 'business rules' == rules["pattern"].lower():
                   #print(rules)
                    bus={}
                    bus['pattern'] = 'businessrules'
                    if 'Exact' in rules['columnType']:
                      bus['columnType'] = rules['columnType']
                      if rules['renameColumn'] == '':
                          rules['renameColumn'] = rules['columnName']
                      bus['newcol'] = rules['renameColumn']
                      bus['col'] = rules['columnName'] 
                    elif 'Alias' in rules['columnType']:
                      bus['columnType'] = rules['columnType']
                      bus['col'] = rules['aliasTypes']
                    else:
                      pass
                    y=json.loads(rules['rule'])
                    bus['rule']=y['name']
                    bus['value'] =rules['functValue']
                    data_rules.append(bus)
                  else:
                     pass
             
          dataextract['DATA-RULES']=data_rules
          baseconf[var3]=dataextract
         
        elif fobj['type']=='Data Quality Checks':
          logger.info("Data Quality Checks")
          #var4='M'+str(x)+'-data-quality-process'
          #dataextract={}
          #dataextract['type']=fobj['type']
          #dataextract['flag']=fobj['flag']
          #baseconf[var4]=dataextract
        elif fobj['type']=='Deduplication':
          logger.info("Deduplication")
          #var5='M'+str(x)+'-data-deduplication-process'
          #dataextract={}
          #dataextract['type']=fobj['type']
          #dataextract['flag']=fobj['flag']
          #baseconf[var5]=dataextract
        
        else:
          logger.info("no Data Properties ")
          pass
      logger.info("end of range loop x")
    else:
      pass
  path='/dbfs/mnt/mountdatalake/UIconf/BatchProcessing/'
  print("targetPath>>>>"+str(targetPath))
  targetPath='demo'
  file_name= id +"_"+targetPath+"_"+batchtime+".json"
  file=path+file_name
  with open(file, 'w') as fp:
    json.dump(baseconf, fp)
  logger.info("Archive File with ", file_name," is created")
  
  path='/dbfs/mnt/mountdatalake/AZ_IDFCodebase/data-conf-ingestion/'
  file_name= id +"_"+targetPath+"_rawtocurated.json"
  file=path+file_name
  with open(file, 'w') as fp:
    json.dump(baseconf, fp)
  logger.info("Config File with ", file_name," is created")
  
######## Modified time datobject#############################

# COMMAND ----------

#### data mapping code ########
pushdown_query = "(select * from dbo.dataProvisioning order by Modified_time desc OFFSET 0 ROWS) as t1"
df = spark.read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties)
df3 = df.withColumn("current_time",current_timestamp())
df4 = df3.withColumn("date_diff_min",(f.col("current_time").cast("long") - f.col("Modified_time").cast("long"))/60.).filter(col("date_diff_min") < 1)
######## Modfied time dataobject##############################
for item in df4.collect():
  try:
    obj = item.asDict()
    m_count=0
    baseconf={}
    commonconf={}
    commonconf['use-case']="Data-Vault"
    commonconf['prcs-name']="clean_to_atomic"
    commonconf['logging-level']="DEBUG"
    baseconf['D'+str(m_count)+'-common-conf']= commonconf
    m_count=m_count+1
    if "jsonValue" in obj.keys():
      jobj= json.loads(obj['jsonValue'])
      if 'frequency' in jobj['mappingMetadata'].keys():
        if jobj['mappingMetadata']['frequency'] == 'Custom':
          frq='batch-date-single'
        else:
          frq=jobj['mappingMetadata']['frequency']
      else:
        frq='batch-date-single'
      ##### START source extract informations START ##################
      logger.info("start of source extract informations>>>"+frq)
      if 'sourceMapping' in jobj.keys():
        sobj=jobj['sourceMapping']
        if 'sourceName' in sobj[0]:
          src_name = sobj[0]['sourceName']
        else:
          src_name = 'default_source'
        logger.info("start of source extract informations>>>"+src_name)
        for x in range(len(sobj)):
          vobj=sobj[x]
          src_len=len(vobj)
          m_count=m_count+x
          var1='D'+str(m_count)+'-data-extract-process'
          dataextract={}
          sourceList=[]
          filters={}
          combines=[]
          uniones=[]
          dataextract['type']="data-extract-process"
          for k,v in vobj.items():
            if 'sourceFields' in k:
              logger.info("In sourceFields")
              #count=0
              count=1
              for z in v:
                var2='source'+str(count)
                sourceList.append(var2)
                dataextract['sourceList']=sourceList
                tmp={}
                if 'zone' in z.keys():
                  if z['zone'] == 'Raw':
                    tmp['type']='raw-zone'
                  elif z['zone'] == 'Curated':
                    tmp['type']='curated-zone'
                  elif z['zone'] == 'Enriched':
                    tmp['type']='enriched-zone'
                  else:
                    pass
                tmp['read-type']=frq
                if 'sourceType' in z.keys():
                  #tmp['source-type']=z['sourceType']
                  if z['sourceType'] == 'tableName':
                    tmp['table-name']=z['tableName']
                  elif z['sourceType'] == 'fileName':
                    if 'fileType' in z.keys():
                      if(len(z['fileType'])>0):
                        tmp['file-format']=z['fileType']
                    fileName = os.path.basename(z['fileName'])
                    path=os.path.dirname(z['fileName']) 
                    if(len(path)>0):
                      path=path+'/'
                      tmp['path']=path
                    if(len(fileName)>0):
                      tmp['fileName']=fileName
                  else:
                    pass
                if(len(z['sourceAttributes'])> 0):
                  tmp['cols']=list(z['sourceAttributes'].split(","))
                if(len(z['targetAttributes'])> 0):
                   tmp['alias']=list(z['targetAttributes'].split(","))
                else:
                  pass
                dataextract[var2]=tmp
                count=count+1
            if 'whereClauseFields' in k:
              logger.info("In whereClauseFields")
              #filters={}
              filters['filter-type']=str(v['operator']).lower()
              filters['tableName']=v['tableName']
              filters['value']=v['value']
              filters['colName']= list(v['attributes'].split(","))
              vcnt=0
              for q in v.get('whereClauseSubfields'):
                v1="key"+str(vcnt)
                tmp={}
                tmp['filter-type']=str(q['operator']).lower()
                tmp['condition']=q['condition']
                tmp['tableName']=q['tableName']
                if len(q['attributes']) > 0:
                  tmp['colName']=list(q['attributes'].split(","))
                tmp['value']=q['value']        
                filters[v1]=tmp
                vcnt=vcnt+1
            if 'configureFields' in k:
              logger.info("In configureFields")
              #combines=[]
              for z in v:
                tmp1={}
                tmp1['type']='join'
                tmp1['base-table-name']=z['tableName']
                if(len(z['attributes'])>0):
                  tmp1['base-table-key']=list(z['attributes'].split(","))
                else:
                  tmp1['base-table-key']=''
                tmp1['source-table-name']=z['conditionTableName']
                if(len(z['conditionAttributes'])>0):
                  tmp1['source-table-key']=list(z['conditionAttributes'].split(","))
                else:
                  tmp1['source-table-key']=''
                #tmp1['condition']=z['condition']
                if z['joinType'] == 'Left Outer Join':
                  tmp1['join-type']='left'
                elif z['joinType'] == 'Right Outer Join':
                  tmp1['join-type']='right'
                elif z['joinType'] == 'Self Join':
                  tmp1['join-type']='self'
                elif z['joinType'] == 'Inner Join':
                  tmp1['join-type']='inner'
                else:
                  pass
                combines.append(tmp1)
            if 'unionFields' in k:
              logger.info("In unionFields")
              for z in v:
                tmp1={}
                tmp1['type']='union'
                tmp1['source-table-name']=z['tableName']
                uniones.append(tmp1)         
          logger.info("end of k,v loop")  
          ### CHange in Filter ##############################################################
          if len(filters) > 0:
            filterBaseTable ={k:v for k,v in filters.items() if 'key' not in k}
    #             for item in dataextract["sourceList"][0:1]:
    #               base = item
    #             dataextract[base]["filter"] = filterBaseTable
            for item in dataextract["sourceList"]:
              base = item
              if 'table-name' in dataextract[base].keys():
                if dataextract[base]["table-name"] == filterBaseTable["tableName"]:
                    dataextract[base]["filter"] = filterBaseTable
              elif 'path' in dataextract[base].keys() and 'fileName' not in dataextract[base].keys():
                if dataextract[base]["path"] == filterBaseTable["tableName"]:
                  dataextract[base]["filter"] = filterBaseTable
              elif 'path' not in dataextract[base].keys() and 'fileName' in dataextract[base].keys():
                if dataextract[base]["fileName"] == filterBaseTable["tableName"]:
                  dataextract[base]["filter"] = filterBaseTable
              elif 'path' in dataextract[base].keys() and 'fileName' in dataextract[base].keys():
                if (dataextract[base]["path"]+dataextract[base]["fileName"]) == filterBaseTable["tableName"]:
                  dataextract[base]["filter"] = filterBaseTable
              else:
                pass

            # Add Filter in other tables
            filterOtherTable ={k:v for k,v in filters.items() if 'key' in k}

            for k,v in filterOtherTable.items():
              for item1 in dataextract["sourceList"]:
                #if dataextract[item1]['source-type'] == 'tableName':
                if 'table-name' in dataextract[item1].keys():
                  if dataextract[item1]["table-name"] == v["tableName"]:
                    dataextract[item1]["filter"] = {k:v}
                #elif dataextract[item1]['source-type'] == 'fileName':
                elif 'path' in dataextract[item1].keys() and 'fileName' not in dataextract[item1].keys():
                  if dataextract[item1]["path"] == v["tableName"]:
                    dataextract[item1]["filter"] = {k:v}
                elif 'path' not in dataextract[item1].keys() and 'fileName' in dataextract[item1].keys():
                  if dataextract[item1]["fileName"] == v["tableName"]:
                    dataextract[item1]["filter"] = {k:v}
                elif 'path' in dataextract[item1].keys() and 'fileName' in dataextract[item1].keys() :
                  if (dataextract[item1]["path"]+dataextract[item1]["fileName"]) == v["tableName"]:
                     dataextract[item1]["filter"] = {k:v}
                else:
                  pass
          else:
            pass
          #### filter adding in sourcess logic end ##########################################
          ### Change for Combine Opearation #################################################
          if len(combines)>0:
            for item in dataextract["sourceList"][-1:]:
                src = item
            #for item in dataextract[src]["combines"]:
            for item in combines:
              for item1 in dataextract["sourceList"]:
                if 'table-name' in dataextract[item1].keys():
                  if dataextract[item1]["table-name"] == item["source-table-name"]:
                    dataextract[item1]["combine"] = item
                elif 'path' in dataextract[item1].keys() and 'fileName' not in dataextract[item1].keys():
                  #print("inside only path")
                  if dataextract[item1]["path"] == item["source-table-name"]:
                    dataextract[item1]["combine"] = item
                elif 'path' not in dataextract[item1].keys() and 'fileName' in dataextract[item1].keys():
                  if dataextract[item1]["fileName"] == item["source-table-name"]:
                    dataextract[item1]["combine"] = item
                elif 'path' in dataextract[item1].keys() and 'fileName' in dataextract[item1].keys() :
                  if (dataextract[item1]["path"]+dataextract[item1]["fileName"]) == item["source-table-name"]:
                    dataextract[item1]["combine"] = item
                else:
                   pass
          else:
            pass
            #############################################################################
          ##
          ### Change for union Opearation #################################################
          if len(uniones)>0:
            for item in dataextract["sourceList"][-1:]:
                src = item
            #for item in dataextract[src]["combines"]:
            for item in uniones:
              for item1 in dataextract["sourceList"]:
                if 'table-name' in dataextract[item1].keys():
                  if dataextract[item1]["table-name"] == item["source-table-name"]:
                    if 'combine' in dataextract[item1].keys():
                      dataextract[item1]["combine1"] = item
                    else:
                      dataextract[item1]["combine"] = item
                elif 'path' in dataextract[item1].keys() and 'fileName' not in dataextract[item1].keys():
                  #print("inside only path")
                  if dataextract[item1]["path"] == item["source-table-name"]:
                    if 'combine' in dataextract[item1].keys():
                      dataextract[item1]["combine1"] = item
                    else:
                      dataextract[item1]["combine"] = item
                elif 'path' not in dataextract[item1].keys() and 'fileName' in dataextract[item1].keys():
                  if dataextract[item1]["fileName"] == item["source-table-name"]:
                    if 'combine' in dataextract[item1].keys():
                      dataextract[item1]["combine1"] = item
                    else:
                      dataextract[item1]["combine"] = item
                elif 'path' in dataextract[item1].keys() and 'fileName' in dataextract[item1].keys() :
                  if (dataextract[item1]["path"]+dataextract[item1]["fileName"]) == item["source-table-name"]:
                    if 'combine' in dataextract[item1].keys():
                      dataextract[item1]["combine1"] = item
                    else:
                      dataextract[item1]["combine"] = item
                else:
                   pass
          else:
            pass
            #############################################################################
          ##

          baseconf[var1]=dataextract
        logger.info("end of for x loop")
        logger.info("end of source extract informations>>>")
        #print(baseconf)
      else:
        pass
    ##### END source extract informations END ##################
    #print(baseconf)
    #######START Transformations START#########
      logger.info("start of transformations extract process>>>")
      #trnf_cnt=2
      m_count=m_count+1
      if 'transformations' in jobj.keys():
        tobj=jobj['transformations']
        varT1='D'+str(m_count)+'-data-transform-process'
        transformextract={}
        transformextract['type']='data-transform-process'
        transformList=[]
        tcount=1
        for p,q in tobj.items():
          transformextract['transform-list']=transformList
          if 'default' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            m={}
            m['type']='default-value'
            def1={}
            for v1 in range(len(q)):
              tmpobj=q[v1]
              tmpv={}
              tmpv['type']=tmpobj['columnType']
              tmpv['value']=tmpobj['value']
              tmpv['tableName']=tmpobj['tableName']
              def1[tmpobj['columnName']]=tmpv
              m['def']=def1
              transformextract[var1]=m
            tcount=tcount+1
          if 'columnAlias' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='col-alias'
            def1={}
            for v1 in range(len(q)):
              tmp={}
              #tmp['tableName']=q[v1]['tableName']
              tmp['newName']=q[v1]['newColumnName']
              tmp['newType']=q[v1]['newColumnType']
              def1[q[v1]['columnName']]=tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'filterProcess' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='filter-process'
            def1={}
            for v1 in range(len(q)):
              h='key'+str(v1)
              def1[h]=q[v1]
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'derivedDataFrame' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='derived-dataframe-process'
            def1={}
            for v1 in range(len(q)):
              h='key'+str(v1)
              tmp={}
              #tmp['tableName']=q[v1]['tableName']
              tmp['type']='col-union'
              tmp['columnName']=q[v1]['columnName']
              tmp['sets-col']=list(q[v1]['columnSet'].split(","))
              def1[h]=tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'renameColumns' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='rename-cols'
            def1={}
            for v1 in range(len(q)):
              #h='key'+str(v1)
              tmp={}
              tmp['table-name']=q[v1]['tableName']
              #def1[h]=tmp
              def1 = tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'dropDuplicates' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='drop-duplicates'
            def1={}
            for v1 in range(len(q)):
              #h='key'+str(v1)
              tmp={}
              #tmp['tableName']=q[v1]['tableName']
              tmp['drop-duplicates-cols']=list(q[v1]['columnList'].split(","))   
              #def1[h]=tmp
              def1=tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'hashKey' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='hash-key'
            def1={}
            for v1 in range(len(q)):
              #h='key'+str(v1)
              tmp={}
              #tmp['tableName']=q[v1]['pathName']
              tmp[q[v1]['columnName']]=q[v1]['keyName']
              #def1[h]=tmp
              def1=tmp
              x['def']=def1
            transformextract[var1]=x
            tcount=tcount+1
          if 'typeConversion' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='type-conversion'
            def1={}
            for v1 in range(len(q)):
              h='key'+str(v1)
              tmp={}
              #tmp['tableName']=q[v1]['tableName']
              if q[v1]['newColumnName'] == '':
                q[v1]['newColumnName'] = q[v1]['columnName']
              tmp['newColName']=q[v1]['newColumnName']
              tmp['dataType']=q[v1]['Datatype']
              tmp['colName']=q[v1]['columnName']
              #def1[q[v1]['columnName']]=tmp
              def1=tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'formatDateToString' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='format-date-to-string'
            def1={}
            for v1 in range(len(q)):
              h='key'+str(v1)
              tmp={}
              #tmp['tableName']=q[v1]['tableName']
              if q[v1]['columnName'] == '':
                q[v1]['columnName'] = q[v1]['columnToFormat']
              tmp['colName']=q[v1]['columnName']
              tmp['colToFormat']=q[v1]['columnToFormat']
              tmp['replace-char']=q[v1]['replaceChar']
              def1[h]=tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'aggregation' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='aggregation'
            def1={}
            for v1 in range(len(q)):
              h='key'+str(v1)
              tmpobj=q[v1]
              tmp={}
              if tmpobj['aggregationProcessType'] == 'groupBy':
                tmp['process']='group-by-w-agg'
                tmp['group_by_list']=list(tmpobj['groupByList'].split(","))
                tm={}
                if len(tmpobj['aggregationList'].split(","))>=1:
                  for z in tmpobj['aggregationList'].split(","):
                    tm[z]=tmpobj['aggregationType']
                tmp['agg_list']=tm
                tmp['agg_type']=tmpobj['aggregationType']
              elif tmpobj['aggregationProcessType'] == 'substract':
                tmp['process']='subtract'
                tmp['colName']=tmpobj['columnName']
                tmp['left_col_name']=tmpobj['leftColName'] 
                tmp['right_col_name']=tmpobj['rightColName']
              elif tmpobj['aggregationProcessType'] == 'product':
                tmp['process']='product'
                tmp['colName']=tmpobj['columnName']
                tmp['first_col']=tmpobj['firstColName']
                tmp['second_col']=tmpobj['secondColName']
              else :
                pass
              def1[h]=tmp
              x['def']=def1
              transformextract[var1]=x
            tcount=tcount+1
          if 'derivedKeyProcess' in p:
            var1="T"+str(tcount)
            transformList.append(var1)
            x={}
            x['type']='derived-key-process'
            def1={}
            for v1 in range(len(q)):
              tmpobj=q[v1]
              h='key'+str(v1)
              if tmpobj['processType']=="case_cond":
                #print("inside case_cond")
                tmpv={}
                tmpv['columnName']=tmpobj['newColName']
                tmpv['process']=tmpobj['processType']
                case_list={}
                cnt=0
                for clist in tmpobj.get('caseConditions'):
                  cvar='case'+str(cnt)
                  case_list[cvar]=clist
                  cnt=cnt+1
                tmpv['case_list']=case_list
                #x[h]=tmpv
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='concat_sep':
                tmpv={}
                tmpv['colName']=tmpobj['newColName']
                tmpv['process']='concat_sep'         ###tmpobj['processType']
                tmpv['cols']=list(tmpobj['columnList'].split(","))
                tmpv['seprator']=tmpobj['defaultValue']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x  
              if tmpobj['processType']=='rename':
                tmpv={}
                tmpv['colTorename']=tmpobj['newColName'] 
                tmpv['process']='rename'           ###tmpobj['processType']
                tmpv['colName']=''
                tmpv['new-name']=tmpobj['renameColumnName']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='new-copy':
                tmpv={}
                tmpv['copy-col']=tmpobj['ColToCopy']
                tmpv['colName']=tmpobj['newColName']
                tmpv['process']=tmpobj['processType']                                    
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='todate':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['colToFormat']
                tmpv['colName']=tmpobj['columnName'] 
                tmpv['process']='todate'                 ###tmpobj['processType']
                tmpv['colToFormat']=tmpobj['colToFormat']
                tmpv['dateformat']=tmpobj['dateFormat']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='upper':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['colToUpper']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='upper'   ###tmpobj['processType']
                tmpv['colToUpper']=tmpobj['colToUpper']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='lower':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['colToLower']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='lower'            ###tmpobj['processType']
                tmpv['colToLower']=tmpobj['colToLower']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Prefix':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['derivedName']=tmpobj['derivedName']
                tmpv['value']=tmpobj['value']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Suffix':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['derivedName']=tmpobj['derivedName']
                tmpv['suffix']=tmpobj['suffix']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Substring':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['substring_col']=tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='substring'          #tmpobj['processType']
                tmpv['start_index']=tmpobj['startPosition']
                tmpv['length']=tmpobj['length']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Left Padding':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                #tmpv['process']=tmpobj['processType']
                tmpv['process']='lpad'
                tmpv['colToPad']=tmpobj['derivedName']
                tmpv['pad-char']=tmpobj['value']
                tmpv['length']=tmpobj['length']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Right Padding':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['colToPad']=tmpobj['derivedName']
                tmpv['pad-char']=tmpobj['value']
                tmpv['length']=tmpobj['length']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Split':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='split'        ###tmpobj['processType']
                tmpv['split-col-name']=tmpobj['derivedName']
                tmpv['delimiter']=tmpobj['value']
                #tmpv['delimiter']=tmpobj['group']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='hash-key':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='hash-key'        ###tmpobj['processType']
                tmpv['hash-key']=list(tmpobj['columnList'].split(","))
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='not-null-list':            
                tmpv={}
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['cols']=list(tmpobj['columnList'].split(","))
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='new-default':
                tmpv={}
                tmpv['default-value']=tmpobj['defaultValue']
                tmpv['colName']=tmpobj['newColName']
                tmpv['process']=tmpobj['processType']             
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='default_value_to_key':
                tmpv={}
                tmpv['colName']=tmpobj['newColName']
                tmpv['col_list']=list(tmpobj['columnList'].split(","))
                tmpv['process']='default_value_to_key'          ###tmpobj['processType']             
                tmpv['default-value']=tmpobj['defaultValue']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              ### added new transformation 
              if tmpobj['processType']=='LTrim':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['derivedColumn']=tmpobj['derivedColumn']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='RTrim':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['derivedColumn']=tmpobj['derivedColumn']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Trim':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='trim-column'           ####tmpobj['processType']
                tmpv['prevColumn']=tmpobj['derivedColumn']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='Cast':
                tmpv={}
                if tmpobj['newColName'] == '':
                  tmpobj['newColName'] = tmpobj['derivedName']
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']=tmpobj['processType']
                tmpv['derivedColumn']=tmpobj['derivedColumn']
                tmpv['datatype']=tmpobj['dataType']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              if tmpobj['processType']=='custom_expression':
                tmpv={}
                tmpv['colName']=tmpobj['newColName'] 
                tmpv['process']='replace-custom-string'
                tmpv['substring_val']=tmpobj['custom_expression']
                def1[h]=tmpv
                x['def']=def1
                transformextract[var1]=x
              else:
                pass
            tcount=tcount+1 
            ###add Transformations
        baseconf[varT1]=transformextract
        logger.info("end of p,q for loop")
      logger.info("end of transformations extract process>>>")
    else:
      pass
    ####### END Transformations END#########
    #print(baseconf)
    if 'targetMapping' in jobj.keys():
      tobjs=jobj['targetMapping']
      v1="D9-load-enrich-process"
      targetextract={}
      targetextract['type']='load-enrich-process'
      targetextract['mode-of-write']='append'
      targetextract['read-type']='full'
      targetextract['source-filter']=''
      targetextract['src-table']=''
      if 'tableName' in tobjs.keys():
        targetextract['target-table']=tobjs['tableName']
      if 'attributes' in tobjs.keys():
        #targetextract['target-col-list']=list(tobjs['attributes'].split(","))
        ##### new chnage #########
        f=tobjs['attributes'].split(",")
        targetschema={}
        targetcollist=[]
        for d in f:
          c={}
          v=d.replace(", ",",").split(" ")
          if len(v) > 1:
            c['colName']=v[0]
            c['type']=v[1]
            targetschema[v[0]]=c
            targetcollist.append(v[0])
          else:
            targetcollist.append(v[0])
        ######  new chnage for target schema ######
        targetextract['target-col-list']=targetcollist
        if not targetschema:
          targetextract['target-schema']=''
        else :
          targetextract['target-schema']=targetschema
      baseconf[v1]=targetextract
    else:
      pass
    #print(baseconf)
    batchid= obj['ID']
    current_datetime = datetime.now().strftime("%m_%d_%Y_%H_%M_%S")
    batchid_time=batchid+str(current_datetime)
    logger.info("start of writing to json file in DataLakeprocess>>>"+batchid_time)
    ##### Write as Json in DataLake #######
    path='/dbfs/mnt/mountdatalake/UIconf/DataProvisioning/'
    file_name=batchid_time+".json"
    file=path+file_name
    with open(file, 'w') as fp:
       json.dump(baseconf, fp)
    logger.info("end of writing to json file in DataLakeprocess process>>>"+file)
    path='/dbfs/mnt/mountdatalake/AZ_IDFCodebase/data-conf-datavault/'
    file_name= src_name +"_"+str(targetextract['target-table']).replace(".", "_")+"_datavault.json"
    file=path+file_name
    with open(file, 'w') as fp:
      json.dump(baseconf, fp)
    logger.info("Config File with ", file_name," is created")
    
  except:
    logger.info("Json object detils are missing, please update ")
    raise ValueError("ERROR Json object deatils are missing "+ str(traceback.format_exc()))
  #### Write as Json end in DataLake #######
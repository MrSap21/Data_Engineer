#!/bin/sh
##########################################################################################################
## Script Name: edw_idl_location_get_latest_dir.sh
## Description: Connects to the Remote Server via SSH connection and identifies the latest 
##              directory. The latest directory name is fetched from the source directory (param3) and is written
##              to a temp file (param4) which are both supplied as the script's input parameters.
##
## Usage: edw_idl_location_get_latest_dir.sh <param1> <param2> <param3> <param4> <param5> 
##
## Parameters:
##   <param1> - The host server name
##   <param2> - The SSH user id
##   <param3> - Source directory where the latest directory (in YYYYMMDD format) is available.
##   <param4> - The temp file that has the SFTP directory name. Use the following filename format to name the
##              temp file - "${AI_SERIAL}/${AI_GRAPH_NAME}_${pSFTP_TGT_FILENAME}_${pEDW_BATCH_ID}.tmp"
##   <param5> - Log file. Use the following filename format to name the log file -
##              "$AI_SERIAL_LOG/sh_edw_idl_location_get_latest_dir.sh_${AI_FILE_DATE}_${AI_PROCESS_ID}.log"
##
## Created by: Anju Singh
## Date Created: 7/10/2012
## Revision History:
##
##########################################################################################################

#pHOST_NAME=$1
#pUSER_ID=$2
pSRC_DIR=$1
pSFTP_DIRNAME_TMP_FILE=$2
pLOG_FILE=$3

######################################################################################################
##  Connect to the Remote Server to get the latest directory from remote server where source file is available 
##  using the supplied source directory path. 
######################################################################################################
pDIRNAME=`ls -1dtr $pSRC_DIR/2* | tail -1`

SSH_GET_DIR_RC=$?

if [ $SSH_GET_DIR_RC -ne 0 ]
then
   echo "************************************************************" >> $pLOG_FILE
   echo " SSH CONNECTON TO REMOTE SERVER FAILURE                     " >> $pLOG_FILE
   echo " edw_idl_location_get_latest_dir.sh ABORTING                " >> $pLOG_FILE
   echo "************************************************************" >> $pLOG_FILE
   exit 1
fi

if [ ! -z $pDIRNAME ]
then
echo $pDIRNAME > $pSFTP_DIRNAME_TMP_FILE
else
touch $pSFTP_DIRNAME_TMP_FILE
fi

OUTPUT_DIR=$pSFTP_DIRNAME_TMP_FILE

#######################################
#-------------------------------------#
# READ CONTENTS OF SSH OUTPUT DIR    #
#-------------------------------------#
#######################################
if [ -s $OUTPUT_DIR ]
then
   LATEST_DIR=`cat $OUTPUT_DIR`

   echo " LATEST_DIR = $LATEST_DIR                                   " >> $pLOG_FILE  

else
   echo "************************************************************" >> $pLOG_FILE
   echo " $OUTPUT_DIR SSH OUTPUT DIRECTORY NOT FOUND OR EMPTY        " >> $pLOG_FILE
   echo " edw_idl_location_get_latest_dir.sh ABORTING                " >> $pLOG_FILE
   echo "************************************************************" >> $pLOG_FILE
   exit 1
fi

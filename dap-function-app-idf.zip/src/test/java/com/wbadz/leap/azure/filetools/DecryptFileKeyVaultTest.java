package com.wbadz.leap.azure.filetools;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.Security;

import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;

import org.apache.commons.io.FileUtils;

import name.neuhalfen.projects.crypto.bouncycastle.openpgp.BouncyGPG;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.callbacks.KeyringConfigCallbacks;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.InMemoryKeyring;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfigs;

public class DecryptFileKeyVaultTest {

    
    private static final String TEST_KEYVAULT_ULR = "https://aznemvpkvtest01.vault.azure.net/";

	private static final String TEST_LM_PRE_PGP_SECRET_NAME = "gpg-preprod-passphrase";
    private static final String TEST_LM_PRE_PGP_SECRET_KEY = "gpg-preprod-pvtkey";

    private static final String TEST_LM_QA_PGP_SECRET_NAME = "gpg-qa-passphrase";
    private static final String TEST_LM_QA_PGP_SECRET_KEY = "gpg-qa-pvtkey";
    	
    private static final String TEST_FILE_PATH = "src/test/resources/IACL2UKCRP_20200816.zip.pgp";
    private static final String TEST_RESULT_PATH = "src/test/resources/testfile.zip";

    private static final String TEST_PGP_SECRET_NAME = "gpg-qa-passphrase";
	private static final String TEST_PGP_SECRET_KEY = "gpg-qa-pvtkey";	
    
    private static final String TEST_LM_FILE_PATH = "src/test/resources/icetestfile.txt.pgp";
    private static final String TEST_LM_RESULT_PATH = "src/test/resources/icetestfile.txt";
    

    public static void main(final String[] args) throws Exception {
        
        System.out.println("AZURE_CLIENT_ID: "+ System.getenv("AZURE_CLIENT_ID"));
		System.out.println("AZURE_CLIENT_SECRET: "+ System.getenv("AZURE_CLIENT_SECRET"));
		System.out.println("AZURE_TENANT_ID: "+ System.getenv("AZURE_TENANT_ID"));

        // ISSUE - MVP 7438        
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
        InMemoryKeyring decryptionKeyring;
        
        final SecretClient secretClient = new SecretClientBuilder()
            .vaultUrl(TEST_KEYVAULT_ULR)
            .credential(new DefaultAzureCredentialBuilder().build())
            .buildClient();	
 
        final byte[] secretKey = secretClient.getSecret(TEST_PGP_SECRET_KEY).getValue().getBytes(StandardCharsets.UTF_8);
        final String passPhrase = secretClient.getSecret(TEST_PGP_SECRET_NAME).getValue();

        decryptionKeyring = KeyringConfigs.forGpgExportedKeys(KeyringConfigCallbacks.withPassword(passPhrase));
        decryptionKeyring.addSecretKey(secretKey);

        byte[] BYTES = readBytesFromFile(TEST_FILE_PATH);

                
        try(final BufferedInputStream originalInputStream = new BufferedInputStream(new ByteArrayInputStream(BYTES))){
            try(final InputStream decryptedStream = BouncyGPG.decryptAndVerifyStream()
                .withConfig(decryptionKeyring)
                .andIgnoreSignatures()
                .fromEncryptedInputStream(originalInputStream)){

                final File targetFile = new File(TEST_RESULT_PATH); 
                FileUtils.copyInputStreamToFile(decryptedStream, targetFile);
            }
        }         
    }

    public static byte[] readBytesFromFile(String filePath) {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {

            File file = new File(filePath);
            bytesArray = new byte[(int) file.length()];

            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

        return bytesArray;

    }

}
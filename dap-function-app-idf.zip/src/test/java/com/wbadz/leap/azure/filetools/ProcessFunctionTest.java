package com.wbadz.leap.azure.filetools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.util.Optional;
import java.util.logging.Logger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskParams;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskResponse;
import com.wbadz.leap.azure.filetools.model.Status;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.vault.AzureKeyVaultService;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.crypto.*" })
@PrepareForTest({ AzureBlobStorageService.class, AzureKeyVaultService.class, AsyncProcessFunction.class })
public class ProcessFunctionTest {

	private static final String TEST_TASK_ID = "464e81ca-a773-449e-80ca-6830096455d3";

	private static final String TEST_SOURCE_ACCOUNT = "1ff2a7df";
	private static final String TEST_SOURCE_PATH = "bae9a098";

	private static final String TEST_DEST_ACCOUNT = "3e07a4c4";
	private static final String TEST_DEST_PATH = "89134587";

	private static final String TEST_FILE_NAME = "mockdata.zip";

	private static final String TEST_ASSET_ID = "9876543210";

	@Test
	@PowerMockIgnore("javax.crypto.*")
	public void testProcessFunction() throws Exception {

		// Setup
		@SuppressWarnings("unchecked")
		final HttpRequestMessage<Optional<FiletoolTaskParams>> request = mock(HttpRequestMessage.class);

		FiletoolTaskParams params = generateParams();
		final Optional<FiletoolTaskParams> queryBody = Optional.of(params);
		doReturn(queryBody).when(request).getBody();

		doAnswer(new Answer<HttpResponseMessage.Builder>() {
			@Override
			public HttpResponseMessage.Builder answer(InvocationOnMock invocation) {
				HttpStatus status = (HttpStatus) invocation.getArguments()[0];
				return new HttpResponseMessageMock.HttpResponseMessageBuilderMock().status(status);
			}
		}).when(request).createResponseBuilder(any(HttpStatus.class));

		final ExecutionContext context = mock(ExecutionContext.class);
		doReturn(Logger.getGlobal()).when(context).getLogger();

		mockStatic(AzureBlobStorageService.class);
		when(AzureBlobStorageService.checkBlobExists(anyString(), anyString(), anyString())).thenReturn(true);
		when(AzureBlobStorageService.checkBlobContainerExists(anyString(), anyString())).thenReturn(true);

		mockStatic(AsyncProcessFunction.class);
		when(AsyncProcessFunction.checkAsyncFunctionConnection()).thenReturn(true);
		when(AsyncProcessFunction.callAsync(params)).thenReturn(true);

		// Invoke
		final HttpResponseMessage response = new ProcessFunction().run(request, context);

		// Verify
		assertEquals(HttpStatus.OK, response.getStatus());
		assertTrue(response.getBody() instanceof FiletoolTaskResponse);
		FiletoolTaskResponse taskResponse = (FiletoolTaskResponse) response.getBody();
		assertEquals(TEST_TASK_ID, taskResponse.getTaskId());
		assertEquals(FileToolUtils.addFolderSeparator(TEST_DEST_PATH) + TEST_TASK_ID, taskResponse.getTaskResultFilePath());
		assertEquals(TEST_TASK_ID + ".json", taskResponse.getTaskResultFileName());

		assertEquals(Status.VALID, taskResponse.getTaskStatus().getStatusCode());
		assertFalse(taskResponse.hasErrors());
	}

	private FiletoolTaskParams generateParams() {
		FiletoolTaskParams params = new FiletoolTaskParams();
		params.setTaskId(TEST_TASK_ID);
		params.setSourceAccount(TEST_SOURCE_ACCOUNT);
		params.setSourcePath(TEST_SOURCE_PATH);
		params.setFile(TEST_FILE_NAME);
		params.setDestAccount(TEST_DEST_ACCOUNT);
		params.setDestPath(TEST_DEST_PATH);
		params.setAssetId(TEST_ASSET_ID);

		return params;
	}

}

package com.wbadz.leap.azure.filetools;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.azure.storage.blob.BlobClient;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.io.IOUtils;




public class UnzipFileTest {

    	
    private static final String TEST_FILE_PATH = "src/test/resources/testfile.zip";    
    private static final String TEST_RESULT_PATH = "src/test/resources";

    public static void main(final String[] args) throws Exception {
        
        System.out.println("AZURE_CLIENT_ID: "+ System.getenv("AZURE_CLIENT_ID"));
		System.out.println("AZURE_CLIENT_SECRET: "+ System.getenv("AZURE_CLIENT_SECRET"));
        System.out.println("AZURE_TENANT_ID: "+ System.getenv("AZURE_TENANT_ID"));
                      
        byte[] BYTES = readBytesFromFile(TEST_FILE_PATH);
        File targetDirectory = new File(TEST_RESULT_PATH);

         
        try (ZipArchiveInputStream zipArchiveInputStream = new ZipArchiveInputStream(new BufferedInputStream(new ByteArrayInputStream(BYTES)))) {            
            ZipArchiveEntry zipEntry = null;
            while ((zipEntry = zipArchiveInputStream.getNextZipEntry()) != null) {
                File entryDestination = new File(targetDirectory, zipEntry.getName());               
                if (zipEntry.isDirectory()) {
                    entryDestination.mkdirs();
                } else {
                    entryDestination.getParentFile().mkdirs();
                    BlobClient blob = AzureBlobStorageService.getBlob("https://aznednadevdl01.blob.core.windows.net/", "raw/Test/stress", zipEntry.getName());
                    //try (OutputStream out = new FileOutputStream(entryDestination)) {
                    try (OutputStream out = blob.getBlockBlobClient().getBlobOutputStream(true)) {
                        //IOUtils.copy(zipArchiveInputStream, out);
                        final byte[] buffer = new byte[8192];
                        int nRead = 0;                       

                        while ((nRead = zipArchiveInputStream.read(buffer)) != -1) {
                            out.write(buffer, 0, nRead);                            
                        }
                    }
                }
            }                    
		}
    
    }

    public static byte[] readBytesFromFile(String filePath) {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {

            File file = new File(filePath);
            bytesArray = new byte[(int) file.length()];

            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

        return bytesArray;

    }

}
    
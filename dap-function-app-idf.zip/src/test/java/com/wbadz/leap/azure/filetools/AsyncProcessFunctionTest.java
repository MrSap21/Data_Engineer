package com.wbadz.leap.azure.filetools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;
import java.util.Optional;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.models.BlobProperties;
import com.azure.storage.blob.specialized.BlobInputStream;
import com.azure.storage.blob.specialized.BlobOutputStream;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskParams;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskResponse;
import com.wbadz.leap.azure.filetools.model.Status;
import com.wbadz.leap.azure.filetools.model.TaskResult;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.crypto.*")
@PrepareForTest({ AzureBlobStorageService.class, BlobClient.class, BlobInputStream.class, BlockBlobClient.class })
public class AsyncProcessFunctionTest {

	private static final String TEST_TASK_ID = "587edef5-7fd8-4728-9547-9f518a05ca89";

	private static final String TEST_SOURCE_ACCOUNT = "18f066ec";
	private static final String TEST_SOURCE_PATH = "f51f1ae4";

	private static final String TEST_DEST_ACCOUNT = "d6e81842";
	private static final String TEST_DEST_PATH = "f485a23e";

	private static final String TEST_FILE_CONTENT = "UEsDBBQAAAAIAHREXVC1rSraiQEAAIcCAAAMAAAAbW9ja2RhdGEuY3N2ZZJNb9swDIbv/i2EYMlf8s0r0nYYustSoNipYCzGViJLgaSk8H795HnZDPTEVyDI5yUpreCofYjvFicCg3dFE2oDA1lFHvTlHZXyFELG4Q2NSlkPX3GOI3yMS8g7O0c9UWC9m+A7GgJe1YzLivGqZbwRmYAHstEQwQ+yvxwc/BJ4d9IYR70pFIVgvCxZmTOey6yAPXo8oSXYR4rBWQhhFaKbyRj3ccHhL/mJprVFQudMlDK1KLMSfqLFmCp3V3smv6hZ3WXx2QKvWyaEYEXFqjKr4AWvnmJEeNUmpU1cQtndzltossx58iwTVNRZDd+c1QF22I80w0n9iVVnXM8Gd/tntcoXTFkxwbMm7QYnZy08ex1G6seztuCH/4+6Gy8bn4KnMtamUdtMwuONjE572rk+jTYDqVU0HaYTpwZW97i1LBvGi4YJUTOZZ22ioh0IXvQwxoNTMwzmLmV3JFKHq7fkt0fmjNdiPXLaNM/hS/obg4P9mUayATCsou2OcYvmCS0LJoRc0L8BUEsBAh8AFAAAAAgAdERdULWtKtqJAQAAhwIAAAwAJAAAAAAAAAAgAAAAAAAAAG1vY2tkYXRhLmNzdgoAIAAAAAAAAQAYAH+GW9jS7tUBRvG37tLu1QE7yrfu0u7VAVBLBQYAAAAAAQABAF4AAACzAQAAAAA=";
	private static final String TEST_FILE_NAME = "mockdata.zip";
	private static final String TEST_FILE_MD5 = "F0BKWWy9DR5sfSP82EWrgg==";

	private static final String TEST_FILE_CONTENT_NAME = "mockdata.csv";
	private static final String TEST_FILE_CONTENT_MD5 = "yfojsuOK45G4op2eCIHITw==";
	private static final long TEST_FILE_CONTENT_SIZE = 551;
	private static final Long TEST_FILE_CONTENT_ROWS = 11l;

	private static final String TEST_ASSET_ID = "1234657890";

	@Test
	@PowerMockIgnore({"javax.crypto.*" })
	public void testProcessFunction() throws Exception {

		// Setup
		@SuppressWarnings("unchecked")
		final HttpRequestMessage<Optional<FiletoolTaskParams>> request = mock(HttpRequestMessage.class);

		FiletoolTaskParams params = generateParams();
		final Optional<FiletoolTaskParams> queryBody = Optional.of(params);
		doReturn(queryBody).when(request).getBody();

		doAnswer(new Answer<HttpResponseMessage.Builder>() {
			@Override
			public HttpResponseMessage.Builder answer(InvocationOnMock invocation) {
				HttpStatus status = (HttpStatus) invocation.getArguments()[0];
				return new HttpResponseMessageMock.HttpResponseMessageBuilderMock().status(status);
			}
		}).when(request).createResponseBuilder(any(HttpStatus.class));

		final ExecutionContext context = mock(ExecutionContext.class);
		doReturn(Logger.getGlobal()).when(context).getLogger();

		BlobClient mockBlob = mockBlobClient();

		mockStatic(AzureBlobStorageService.class);
		when(AzureBlobStorageService.getBlob(anyString(), anyString(), anyString())).thenReturn(mockBlob);

		// Invoke
		final HttpResponseMessage response = new AsyncProcessFunction().run(request, context);

		// Verify
		assertEquals(HttpStatus.OK, response.getStatus());
		assertTrue(response.getBody() instanceof FiletoolTaskResponse);
		FiletoolTaskResponse taskResponse = (FiletoolTaskResponse) response.getBody();
		assertEquals(TEST_TASK_ID, taskResponse.getTaskId());
		assertEquals(TEST_FILE_NAME, taskResponse.getOriginalFileName());
		assertEquals(TEST_FILE_MD5, taskResponse.getOriginalFileMd5Hash());
		assertEquals(FileToolUtils.addFolderSeparator(TEST_DEST_PATH) + TEST_TASK_ID, taskResponse.getTaskResultFilePath());
		assertEquals(TEST_TASK_ID + ".json", taskResponse.getTaskResultFileName());
		assertEquals(TEST_FILE_CONTENT_SIZE, taskResponse.getTotalBytesProcessed());
		assertEquals(TEST_FILE_CONTENT_ROWS, taskResponse.getTotalRowsProcessed());

		assertTrue(CollectionUtils.isNotEmpty(taskResponse.getTaskResults()));
		TaskResult taskResult = taskResponse.getTaskResults().get(0);
		assertEquals(TEST_FILE_CONTENT_NAME, taskResult.getFileName());
		assertEquals(TEST_FILE_CONTENT_MD5, taskResult.getMd5Hash());
		assertEquals(FileToolConstants.METADATA_NULL_STR_VALUE, taskResult.getAssetId());
		assertEquals(TEST_ASSET_ID, taskResult.getParentAssetId());
		assertEquals(TEST_FILE_CONTENT_SIZE, taskResult.getSize());
		assertEquals(TEST_FILE_CONTENT_ROWS, taskResult.getRows());
		assertEquals(FilenameUtils.getExtension(TEST_FILE_CONTENT_NAME), taskResult.getExtension());

		assertEquals(Status.VALID, taskResponse.getTaskStatus().getStatusCode());
		assertFalse(taskResponse.hasErrors());
	}

	private BlobClient mockBlobClient() {
		BlobClient blob = mock(BlobClient.class);
		//Blob stream
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(Base64.decodeBase64(TEST_FILE_CONTENT));
		BlobInputStream mockInputStream = mock(BlobInputStream.class, AdditionalAnswers.delegatesTo(byteArrayInputStream));
		when(blob.openInputStream()).thenReturn(mockInputStream);

		//Blob properties
		byte[] contentMd5 = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			contentMd5 = md.digest("mock".getBytes("UTF-8"));
		} catch (Exception e) {
			//do nothing
		}

		System.out.println(Base64.encodeBase64String(contentMd5));

		BlockBlobClient mockBlockBlobClient = mockBlockBlobClient();
		when(blob.getBlockBlobClient()).thenReturn(mockBlockBlobClient);

		when(blob.getBlobName()).thenReturn(TEST_FILE_NAME);

		BlobProperties blobProperties = new BlobProperties(null, null, null, TEST_FILE_CONTENT_SIZE, null, contentMd5, null, null, null, null//
				, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		when(blob.getProperties()).thenReturn(blobProperties);

		return blob;
	}

	private BlockBlobClient mockBlockBlobClient() {
		BlockBlobClient blockBlobClient = mock(BlockBlobClient.class);
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		BlobOutputStream mockOutputStream = mock(BlobOutputStream.class, AdditionalAnswers.delegatesTo(byteArrayOutputStream));
		when(blockBlobClient.getBlobOutputStream(true)).thenReturn(mockOutputStream);

		return blockBlobClient;
	}

	private FiletoolTaskParams generateParams() {
		FiletoolTaskParams params = new FiletoolTaskParams();
		params.setTaskId(TEST_TASK_ID);
		params.setSourceAccount(TEST_SOURCE_ACCOUNT);
		params.setSourcePath(TEST_SOURCE_PATH);
		params.setFile(TEST_FILE_NAME);
		params.setDestAccount(TEST_DEST_ACCOUNT);
		params.setDestPath(TEST_DEST_PATH);
		params.setAssetId(TEST_ASSET_ID);

		return params;
	}
}

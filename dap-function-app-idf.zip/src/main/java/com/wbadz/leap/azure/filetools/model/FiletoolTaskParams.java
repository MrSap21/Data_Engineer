package com.wbadz.leap.azure.filetools.model;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FiletoolTaskParams extends BaseTaskParams {

	private String taskId;
	private String assetId;
	private String destAccount;
	private String destPath;
	private String keyvaultUrl;
	private String privateKeySecretName;
	private String passphraseSecretName;
	private String taskType;

	//Options
	private boolean recursive = true;
	private boolean zipResults = false;
	private boolean calculateMD5 = true;
	private boolean countLines = true;
	private boolean testConnection = false;

	public String getDestAccount() {
		if (StringUtils.isEmpty(destAccount)) {
			return destAccount;
		}
		return parseStorageAccount(destAccount);
	}

	@JsonIgnore
	public String getDestPathContainer() {
		return getContainer(destPath);
	}

	@JsonIgnore
	public String getDestFilePath(String fileName) {
		String aux = getFilePath(destPath, getContainer(destPath));
		if (aux.startsWith("/")) {
			aux = aux.replaceFirst(Pattern.quote("/"), "");
		}
		return aux + fileName;
	}

	@JsonIgnore
	@Override
	public List<String> getValidationErrors() {
		ValidationUtil validation = new ValidationUtil(super.getValidationErrors());
		validation.checkMandatory("taskId", taskId);
		validation.checkMandatory("destAccount", destAccount);
		validation.checkMandatory("destPath", destPath);

		if (FileToolUtils.isEncryptedFile(super.getFile())) {
			validation.checkMandatory("keyvaultUrl", keyvaultUrl);
			validation.checkMandatory("privateKeySecretName", privateKeySecretName);
			validation.checkMandatory("passphraseSecretName", passphraseSecretName);
		}

		return validation.getErrors();
	}

}

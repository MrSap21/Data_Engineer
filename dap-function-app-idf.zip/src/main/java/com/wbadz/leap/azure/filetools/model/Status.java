package com.wbadz.leap.azure.filetools.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wbadz.leap.azure.filetools.util.FileToolUtils;

import lombok.Data;

@Data
public class Status {
	public static final String VALID = "OK";
	public static final String ERROR = "KO";

	private String statusCode;
	private List<Error> errors;

	public void addError(String message) {
		if (StringUtils.isEmpty(message)) {
			return;
		}
		this.statusCode = ERROR;
		if (errors == null) {
			this.errors = new ArrayList<>();
		}
		Error error = new Error(message);
		if (!errors.contains(error)) {
			errors.add(error);
		}
	}

	public void addErrors(List<String> errors) {
		if (CollectionUtils.isEmpty(errors)) {
			return;
		}
		for (String error : errors) {
			addError(error);
		}
	}

	public void success() {
		this.statusCode = VALID;
		this.errors = null;
	}

	@Data
	public static class Error {
		private String dateTime;
		private String message;

		public Error() {
			this.dateTime = FileToolUtils.getNowFormatted();
		}

		public Error(String message) {
			this.dateTime = FileToolUtils.getNowFormatted();
			this.message = message;
		}
	}

}
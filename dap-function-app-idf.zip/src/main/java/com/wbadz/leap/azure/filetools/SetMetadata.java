package com.wbadz.leap.azure.filetools;

import java.io.BufferedInputStream;
import java.security.MessageDigest;
import java.util.Optional;
import java.util.Map;
import java.util.HashMap;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.MDC;

import com.azure.storage.blob.BlobClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.wbadz.leap.azure.filetools.model.SetMetadataParams;
import com.wbadz.leap.azure.filetools.model.BaseResponse;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SetMetadata {

	@FunctionName("setmetadata")
	public HttpResponseMessage run(
			@HttpTrigger(name = "req", methods = { HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<SetMetadataParams>> request,
			final ExecutionContext context) {

		MDC.clear();
		log.info("Start Set Metadata Function");

		Optional<SetMetadataParams> paramsOpt = request.getBody();
		if (!paramsOpt.isPresent()) {
			final String msg = "taskParams can not be null";
			log.error(msg);
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(msg).build();
		}
		SetMetadataParams params = paramsOpt.get();		

		log.info("Start MD5Function with params: {}", params);

		BaseResponse response = new BaseResponse();
		if (!params.isValid()) {
			response.status().addErrors(params.getValidationErrors());			
		}

		//Source blob
		ValidationUtil.checkBlobExists(response, params.getSourceAccount(), params.getSourcePathContainer(), params.getSourceFilePath());

		if (response.hasErrors()) {
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(response).build();
		}

		BlobClient blob = AzureBlobStorageService.getBlob(params.getSourceAccount(), params.getSourcePathContainer(), params.getSourceFilePath());

		if(params.getAssetId() != null && params.getAssetId().length() > 0) {

			Map<String, String> blobMetaData = new HashMap<>();
			blobMetaData.put("assetId", params.getAssetId());
			blob.setMetadata(blobMetaData);			
			response.status().success();

		} else {
			
			final String msg = "Asset Id Cannot be null or Empty ";
			log.error(msg);
			response.status().addError(msg);
			
		}

		response.setDateTimeEnd(FileToolUtils.getNowFormatted());
		return request.createResponseBuilder(HttpStatus.OK).body(response).build();
	}

}

package com.wbadz.leap.azure.filetools;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Optional;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.MDC;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.specialized.BlobOutputStream;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.wbadz.leap.azure.filetools.model.BaseResponse;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskParams;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskResponse;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;
import com.wbadz.leap.azure.filetools.vault.AzureKeyVaultService;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProbeFunction {

	//CSV Zipped File and Base64 encoded
	private static final String TEST_FILE_CONTENT = "UEsDBBQAAAAIAHREXVC1rSraiQEAAIcCAAAMAAAAbW9ja2RhdGEuY3N2ZZJNb9swDIbv/i2EYMlf8s0r0nYYustSoNipYCzGViJLgaSk8H795HnZDPTEVyDI5yUpreCofYjvFicCg3dFE2oDA1lFHvTlHZXyFELG4Q2NSlkPX3GOI3yMS8g7O0c9UWC9m+A7GgJe1YzLivGqZbwRmYAHstEQwQ+yvxwc/BJ4d9IYR70pFIVgvCxZmTOey6yAPXo8oSXYR4rBWQhhFaKbyRj3ccHhL/mJprVFQudMlDK1KLMSfqLFmCp3V3smv6hZ3WXx2QKvWyaEYEXFqjKr4AWvnmJEeNUmpU1cQtndzltossx58iwTVNRZDd+c1QF22I80w0n9iVVnXM8Gd/tntcoXTFkxwbMm7QYnZy08ex1G6seztuCH/4+6Gy8bn4KnMtamUdtMwuONjE572rk+jTYDqVU0HaYTpwZW97i1LBvGi4YJUTOZZ22ioh0IXvQwxoNTMwzmLmV3JFKHq7fkt0fmjNdiPXLaNM/hS/obg4P9mUayATCsou2OcYvmCS0LJoRc0L8BUEsBAh8AFAAAAAgAdERdULWtKtqJAQAAhwIAAAwAJAAAAAAAAAAgAAAAAAAAAG1vY2tkYXRhLmNzdgoAIAAAAAAAAQAYAH+GW9jS7tUBRvG37tLu1QE7yrfu0u7VAVBLBQYAAAAAAQABAF4AAACzAQAAAAA=";
	private static final String TEST_FILE_NAME = "mockdata.zip";

	@FunctionName("probe")
	public HttpResponseMessage run(
			@HttpTrigger(name = "req", methods = { HttpMethod.GET }, authLevel = AuthorizationLevel.ANONYMOUS) HttpRequestMessage<Optional<String>> request,
			final ExecutionContext context) {

		MDC.clear();
		log.info("Start ProbeFunction");
	
		ProbeParams params = new ProbeParams(request.getQueryParameters().get("storageAccount"), request.getQueryParameters().get("keyVault"));
		BaseResponse response = new BaseResponse();
		if (!params.isValid()) {
			response.status().addErrors(params.getValidationErrors());
		}

		if (response.hasErrors()) {
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(response).build();
		}

		//Keyvault validation
		try {
			if (AzureKeyVaultService.getKeyvault(params.getKeyVault()) == null) {
				response.status().addError("Can not get keyvault: " + params.getKeyVault());
			}
		} catch (Exception e) {
			String msg = "Error retrieving keyvault";
			log.error(msg, e);
			response.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
		}

		BlobServiceClient blobService = null;
		try {
			String storageAccountURL = parseStorageAccount(params.getStorageAccount());
			blobService = AzureBlobStorageService.getBlobService(storageAccountURL);
			if (blobService == null) {
				response.status().addError("Can not get storageAccount: " + storageAccountURL);
			}
		} catch (Exception e) {
			String msg = "Error retrieving storageAccount";
			log.error(msg, e);
			response.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
		}

		if (response.hasErrors() || blobService == null) {
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(response).build();
		}

		BlobContainerClient container = blobService.getBlobContainerClient(FileToolConstants.PROBE_BLOB_CONTAINER);
		if (!container.exists()) {
			container.create();
		}
		BlobClient blob = container.getBlobClient(TEST_FILE_NAME);

		try (ByteArrayInputStream inputStream = new ByteArrayInputStream(Base64.decodeBase64(TEST_FILE_CONTENT));
				BlobOutputStream outputStream = blob.getBlockBlobClient().getBlobOutputStream(true)) {
			IOUtils.copy(inputStream, outputStream);
		} catch (Exception e) {
			String msg = "Error uploading blob";
			log.error(msg, e);
			response.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
		}

		if (response.hasErrors()) {
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(response).build();
		}

		try {
			FiletoolTaskParams taskParams = new FiletoolTaskParams();
			String taskId = java.util.UUID.randomUUID().toString();
			taskParams.setTaskId(taskId);
			String assetId = "999";
			taskParams.setAssetId(assetId);
			taskParams.setSourceAccount(params.getStorageAccount());
			taskParams.setSourcePath(FileToolConstants.PROBE_BLOB_CONTAINER);
			taskParams.setFile(blob.getBlobName());
			taskParams.setDestAccount(params.getStorageAccount());
			taskParams.setDestPath(FileToolConstants.PROBE_BLOB_CONTAINER);

			String funcResponse = AsyncProcessFunction.callSync(taskParams);
			FiletoolTaskResponse taskResponse = FiletoolTaskResponse.fromJSON(funcResponse);
			response.setTaskStatus(taskResponse.getTaskStatus());
			log.info("AsyncProcessFunction response: " + taskResponse);
		} catch (Exception e) {
			String msg = "Unexpected error";
			log.error(msg, e);
			response.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
		} finally {
			container.delete();
		}

		if (response.hasErrors()) {
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(response).build();
		}		
		return request.createResponseBuilder(HttpStatus.OK).build();
	}

	private String parseStorageAccount(String account) {
		if (FileToolUtils.isSingleWord(account)) {
			return String.format(FileToolConstants.AZURE_GENERIC_BLOB_URL, account);
		}
		return account;
	}

	@AllArgsConstructor
	@ToString
	@Getter
	@Setter
	private class ProbeParams {
		private String storageAccount;
		private String keyVault;

		@JsonIgnore
		public List<String> getValidationErrors() {
			ValidationUtil validation = new ValidationUtil();
			validation.checkMandatory("storageAccount", storageAccount);
			validation.checkMandatory("keyVault", keyVault);
			return validation.getErrors();
		}

		@JsonIgnore
		public boolean isValid() {
			return CollectionUtils.isEmpty(getValidationErrors());
		}
	}

}

package com.wbadz.leap.azure.filetools.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FiletoolTaskResponse extends BaseResponse {

	private String taskId;
	private String originalFileName;
	private String originalFileMd5Hash;
	private String taskResultFilePath;
	private String taskResultFileName;
	private long totalBytesProcessed = 0;
	private Long totalRowsProcessed;
	private List<TaskResult> taskResults;

	public FiletoolTaskResponse() {
	}

	public FiletoolTaskResponse(String taskId) {
		super();
		this.taskId = taskId;
	}

	public void addTaskResult(TaskResult taskResult) {
		if (taskResults == null) {
			taskResults = new ArrayList<>();
			totalBytesProcessed = 0l;
		}
		taskResults.add(taskResult);
		totalBytesProcessed += taskResult.getSize();
		if (taskResult.getRows() != null) {
			if (totalRowsProcessed == null) {
				totalRowsProcessed = 0l;
			}
			totalRowsProcessed += taskResult.getRows();
		}
	}

	public static FiletoolTaskResponse fromJSON(String json) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, FiletoolTaskResponse.class);
	}

}

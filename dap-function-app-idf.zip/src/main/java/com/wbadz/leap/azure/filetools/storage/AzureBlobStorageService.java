package com.wbadz.leap.azure.filetools.storage;

import java.io.File;
import java.io.InputStream;

import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.storage.blob.BlobAsyncClient;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobClientBuilder;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AzureBlobStorageService {

	private AzureBlobStorageService() {

	}

	public static void upload(BlobClient blob, File file) {
		long startTime = System.currentTimeMillis();
		log.info("Uploading file to azure: {}", blob.getBlobUrl());
		try {
			blob.uploadFromFile(file.getAbsolutePath(), true);
			log.info("Upload finished: {}", blob.getBlobUrl());
		} catch (Exception e) {
			log.error("Error uploading azure blob", e);
			throw new AzureStorageException(e.getMessage());
		} finally {
			long endTime = System.currentTimeMillis();
			long timeElapsed = endTime - startTime;
			log.info("Upload: {}", speed(file.length(), timeElapsed));
		}
	}

	public static void upload(BlobClient blob, InputStream inputStream, long streamSize) {
		long startTime = System.currentTimeMillis();
		log.info("Uploading stream to azure: {}", blob.getBlobUrl());
		try {
			blob.getBlockBlobClient().upload(inputStream, streamSize, true);
			log.info("Upload stream finished: {}", blob.getBlobUrl());
		} catch (Exception e) {
			log.error("Error uploading stream", e);
			throw new AzureStorageException(e.getMessage());
		} finally {
			long endTime = System.currentTimeMillis();
			long timeElapsed = endTime - startTime;
			log.info("Upload: {}", speed(streamSize, timeElapsed));
		}
	}

	public static void upload(String storageAccount, String container, String remotePath, File file) {
		BlobClient blob = new BlobClientBuilder()
				.endpoint(storageAccount)
				.credential(new DefaultAzureCredentialBuilder().build())
				.containerName(container)
				.blobName(remotePath)
				.buildClient();

		upload(blob, file);
	}

	public static void downloadToFile(BlobClient blob, File localFile) {
		long startTime = System.currentTimeMillis();
		log.info("Downloading file from azure: {}", blob.getBlobUrl());
		try {
			blob.downloadToFile(localFile.getAbsolutePath());
			log.info("Download finished: " + blob.getBlobUrl());
		} catch (Exception e) {
			log.error("Error downloading azure blob", e);
			throw new AzureStorageException(e.getMessage());
		} finally {
			long endTime = System.currentTimeMillis();
			long timeElapsed = endTime - startTime;
			log.info("Download: {}", speed(localFile.length(), timeElapsed));
		}
	}

	public static void downloadToFile(String storageAccount, String container, String remotePath, File localFile) {
		BlobClient blob = new BlobClientBuilder()
				.endpoint(storageAccount)
				.credential(new DefaultAzureCredentialBuilder().build())
				.containerName(container)
				.blobName(remotePath)
				.buildClient();

		downloadToFile(blob, localFile);
	}

	public static boolean checkBlobExists(String storageAccount, String container, String remotePath) {
		return getBlob(storageAccount, container, remotePath).exists();
	}

	public static BlobClient getBlob(String storageAccount, String container, String remotePath) {
		log.info("Blob: Storage Account {}, Container {} and remotePath {}", storageAccount,container,remotePath);
		return new BlobClientBuilder()
				.endpoint(storageAccount)
				.credential(new DefaultAzureCredentialBuilder().build())
				.containerName(container)
				.blobName(remotePath)
				.buildClient();
	}

	public static BlobAsyncClient getAsyncBlobClient(String storageAccount, String container, String remotePath) {
		log.info("Blob: Storage Account {}, Container {} and remotePath {}", storageAccount,container,remotePath);
		return new BlobClientBuilder()
				.endpoint(storageAccount)
				.credential(new DefaultAzureCredentialBuilder().build())
				.containerName(container)
				.blobName(remotePath)
				.buildAsyncClient();
	}

	public static BlobContainerClient getBlobContainer(String storageAccount, String container) {
		log.info("Blob Container: Storage Account {}, Container {} ", storageAccount,container);
		return new BlobContainerClientBuilder()
				.endpoint(storageAccount)
				.credential(new DefaultAzureCredentialBuilder().build())
				.containerName(container)
				.buildClient();
	}

	public static BlobServiceClient getBlobService(String storageAccount) {
		return new BlobServiceClientBuilder()
				.endpoint(storageAccount)
				.credential(new DefaultAzureCredentialBuilder().build())
				.buildClient();
	}

	public static boolean checkBlobContainerExists(String storageAccount, String container) {
		return getBlobContainer(storageAccount, container).exists();
	}

	private static String speed(final long size, final long timeElapsed) {
		StringBuilder sb = new StringBuilder();
		if (size > 1000 && timeElapsed > 1000) {
			sb.append(" Size: " + (size / 1024) + " KB");
			sb.append(" - Time: " + (timeElapsed / 1000) + " seconds");
			sb.append(" - Speed: " + (size / 1024 / 1024) / (timeElapsed / 1000) + " MB/s");
			return sb.toString();
		}
		return " Speed: -- MB/s";
	}
}
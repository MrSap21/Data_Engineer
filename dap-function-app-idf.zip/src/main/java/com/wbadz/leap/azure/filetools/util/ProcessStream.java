package com.wbadz.leap.azure.filetools.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.specialized.BlobOutputStream;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProcessStream {
	private InputStream inputStream;
	private String fileName;
	private BlobClient blob;

	private boolean countLines;
	private boolean calculateMD5;
	private boolean zipResults;

	@Getter
	private long fileRows = 0l;

	private MessageDigest messageDigest = null;

	public ProcessStream(InputStream inputStream, String fileName, BlobClient blob, boolean countLines, boolean calculateMD5, boolean zipResults) throws NoSuchAlgorithmException {
		this.inputStream = inputStream;
		this.fileName = fileName;
		this.blob = blob;
		this.countLines = countLines;
		this.calculateMD5 = calculateMD5;
		this.fileRows = 0l;
		this.zipResults = zipResults;
		if (calculateMD5) {
			this.messageDigest = MessageDigest.getInstance("MD5");
		}
	}

	public void run() throws IOException {
		if (zipResults) {
			log.info("Uncompressing ZIP file");
			try (ZipArchiveOutputStream outputStream = new ZipArchiveOutputStream(blob.getBlockBlobClient().getBlobOutputStream(true))) {
				outputStream.setMethod(ZipArchiveOutputStream.DEFLATED);
				outputStream.setEncoding(StandardCharsets.UTF_8.name());
				outputStream.putArchiveEntry(new ZipArchiveEntry(fileName + ".zip"));
				process(inputStream, outputStream);
				outputStream.closeArchiveEntry();
			}			
		} else {
			try (BlobOutputStream outputStream = blob.getBlockBlobClient().getBlobOutputStream(true)) {
				process(inputStream, outputStream);
			}
		}
	}

	public String getMD5Hash() {
		try {
			return calculateMD5 ? Base64.encodeBase64String(messageDigest.digest()) : null;
		} catch (Exception e) {
			log.error("Error getting md5hash", e);
			return null;
		}
	}

	private void process(InputStream input, OutputStream output) throws IOException {
		final byte[] buffer = new byte[FileToolConstants.STREAMING_BUFFER_SIZE];
		int nRead = 0;
		int lastPosition = 0;

		while ((nRead = input.read(buffer)) != -1) {
			output.write(buffer, 0, nRead);

			if (calculateMD5) {
				messageDigest.update(buffer, 0, nRead);
			}

			if (countLines) {
				for (int i = 0; i < nRead; i++) {
					if (buffer[i] == FileToolConstants.LINE_BREAK) {
						fileRows++;
					}
				}
				lastPosition = nRead - 1;
			}
		}

		if (countLines && lastPosition > 0 && buffer[lastPosition] != FileToolConstants.LINE_BREAK) {
			fileRows++;
		}
	}

}

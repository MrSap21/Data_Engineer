package com.wbadz.leap.azure.filetools.model;

import org.apache.commons.collections4.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseResponse {

	protected String dateTimeStart;
	private String dateTimeEnd;
	private Status taskStatus = new Status();

	public BaseResponse() {
		this.dateTimeStart = FileToolUtils.getNowFormatted();
	}

	public String toJSON() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			return null;
		}
	}

	public Status status() {
		return this.taskStatus;
	}

	public boolean hasErrors() {
		return CollectionUtils.isNotEmpty(taskStatus.getErrors());
	}

}
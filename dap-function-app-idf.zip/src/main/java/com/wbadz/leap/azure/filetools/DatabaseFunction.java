package com.wbadz.leap.azure.filetools;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.MDC;

import com.azure.security.keyvault.secrets.SecretClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskParams;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskResponse;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;
import com.wbadz.leap.azure.filetools.vault.AzureKeyVaultService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DatabaseFunction {

	@FunctionName("dbconnect")
	public HttpResponseMessage run(
			@HttpTrigger(name = "req", methods = { HttpMethod.GET }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<String>> request,
			final ExecutionContext context) {
				int count = 0;
				String errorMessage = "";
try {
 String clientSecret = AzureKeyVaultService.getSecretValue("https://dapuatkv01.vault.azure.net/", "uatdnasqldb");

		log.info("Loading application properties");
        Properties properties = new Properties();
        properties.setProperty("user", "2f7202f6-37a0-4375-9859-5593ff655bbf");
		properties.setProperty("password", clientSecret);

        log.info("Connecting to the database");
        Connection connection = DriverManager.getConnection("jdbc:sqlserver://dapuatsqlsrv01.database.windows.net:1433;database=dapuatsqldb01;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30", properties);
        log.info("Database connection test: " + connection.getCatalog());

       
	    PreparedStatement stmt = connection.prepareStatement("select count(1) from asset");
		ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		
		/*
		Todo todo = new Todo(1L, "configuration", "congratulations, you have set up JDBC correctly!", true);
        insertData(todo, connection);
        todo = readData(connection);
        todo.setDetails("congratulations, you have updated data!");
        updateData(todo, connection);
        deleteData(todo, connection);F
		*/

        log.info("Closing database connection");
        connection.close();
			}
			catch(Exception e) {
				errorMessage = e.getMessage();
				return request.createResponseBuilder(HttpStatus.OK).body(errorMessage).build();
			}
		return request.createResponseBuilder(HttpStatus.OK).body(count).build();
	}

}

package com.wbadz.leap.azure.filetools.util;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.wbadz.leap.azure.filetools.AsyncProcessFunction.FileType;

public class FileToolUtils {

	private FileToolUtils() {

	}

	public static long countLines(final File file) throws IOException {
		try (final Stream<String> lines = Files.lines(file.toPath())) {
			return lines.count();
		}
	}

	public static boolean isEncryptedFile(File file) {
		return isEncryptedFile(file.getName());
	}

	public static boolean isEncryptedFile(String fileName) {
		String extension = FilenameUtils.getExtension(fileName);
		return FileToolConstants.ENCRYPTED_FILE_EXTENSIONS.contains(extension);
	}

	public static boolean isZipFile(File file) {
		return isZipFile(file.getName());
	}

	public static boolean isZipFile(String fileName) {
		String extension = FilenameUtils.getExtension(fileName);
		return FileToolConstants.ZIP_FILE_EXTENSIONS.contains(extension);
	}

	public static boolean isGZipFile(String fileName) {
		String extension = FilenameUtils.getExtension(fileName);
		return FileToolConstants.GZIP_FILE_EXTENSIONS.contains(extension);
	}

	public static boolean isCPIOFile(String fileName) {
        String extension = FilenameUtils.getExtension(fileName);
        return FileToolConstants.CPIO_FILE_EXTENSIONS.contains(extension);
    }

    public static boolean isBZipFile(String fileName) {
        String extension = FilenameUtils.getExtension(fileName);
        return FileToolConstants.BZIP_FILE_EXTENSIONS.contains(extension);
	}
	
    public static boolean isZZipFile(String fileName) {
        String extension = FilenameUtils.getExtension(fileName);        
        return FileToolConstants.ZZIP_FILE_EXTENSIONS.contains(extension);
    }

	public static boolean isCountLinesFile(File file) {
		return isZipFile(file.getName());
	}

	public static boolean isCountLinesFile(String fileName) {
		String extension = FilenameUtils.getExtension(fileName);
		return FileToolConstants.COUNT_LINE_FILE_EXTENSIONS.contains(extension);
	}

	public static String getRandomString(String characters, int length) {
		Random random = new SecureRandom();
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			sb.append(characters.charAt(random.nextInt(characters.length())));
		}

		return sb.toString();
	}

	public static String getRandomString() {
		String characters = "abcdefghijklmnopqrstuvwxyz1234567980";
		return getRandomString(characters, 8);
	}

	public static String addFolderSeparator(String path) {
		if (path != null) {
			return path.endsWith(FileToolConstants.FOLDER_SEPARATOR) ? path : path + FileToolConstants.FOLDER_SEPARATOR;
		}
		return null;
	}

	public static String addFolderSeparatorAtStart(String path) {
		if (path != null) {
			return path.startsWith(FileToolConstants.FOLDER_SEPARATOR) ? path : FileToolConstants.FOLDER_SEPARATOR + path;
		}
		return null;
	}

	public static String base64UUID() {
		return Base64.encodeBase64String(UUID.randomUUID().toString().getBytes(StandardCharsets.UTF_8));
	}

	public static String getNowFormatted() {
		return LocalDateTime.ofInstant(Instant.now(), ZoneOffset.UTC).format(FileToolConstants.DATE_TIME_FORMATTER);
	}

	public static boolean isSingleWord(String inputString) {
		if (StringUtils.isEmpty(inputString)) {
			return false;
		}
		return Pattern.compile("\\w+").matcher(inputString).matches();
	}

	public static FileType getFileType(String fileName) {
		if (FileToolUtils.isEncryptedFile(fileName)) {
			return FileType.ENCRYPTED;
		}
		if (FileToolUtils.isZipFile(fileName)) {
			return FileType.ZIP;
		}
		if (FileToolUtils.isGZipFile(fileName)) {
			return FileType.GZIP;
		}
		if (FileToolUtils.isCPIOFile(fileName)) {
			return FileType.CPIO;
		}
		if (FileToolUtils.isBZipFile(fileName)) {
			return FileType.BZIP;
		}
		if (FileToolUtils.isZZipFile(fileName)) {
			return FileType.ZZIP;
		}
		return FileType.FINAL;
	}

	public static long parseLongMetaData(String value) {
		if (StringUtils.isNumeric(value)) {
			return Long.parseLong(value);
		}
		return FileToolConstants.METADATA_NULL_LONG_VALUE;
	}

	public static String parseStringMetaData(String value) {
		return StringUtils.isNotEmpty(value) ? value : FileToolConstants.METADATA_NULL_STR_VALUE;
	}

	public static String parseLongMetaData(Long fileRows) {
		return fileRows != null ? String.valueOf(fileRows) : FileToolConstants.METADATA_NULL_STR_VALUE;
	}

}

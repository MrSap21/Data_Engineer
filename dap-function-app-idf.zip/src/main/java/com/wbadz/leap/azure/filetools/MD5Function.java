package com.wbadz.leap.azure.filetools;

import java.io.BufferedInputStream;
import java.security.MessageDigest;
import java.util.Optional;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.MDC;

import com.azure.storage.blob.BlobClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.wbadz.leap.azure.filetools.model.BaseTaskParams;
import com.wbadz.leap.azure.filetools.model.MD5TaskResponse;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MD5Function {

	@FunctionName("md5")
	public HttpResponseMessage run(
			@HttpTrigger(name = "req", methods = { HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<BaseTaskParams>> request,
			final ExecutionContext context) {

		MDC.clear();
		log.info("Start MD5Function");

		Optional<BaseTaskParams> paramsOpt = request.getBody();
		if (!paramsOpt.isPresent()) {
			final String msg = "taskParams can not be null";
			log.error(msg);
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(msg).build();
		}
		BaseTaskParams params = paramsOpt.get();		

		log.info("Start MD5Function with params: {}", params);

		MD5TaskResponse response = new MD5TaskResponse();

		if (!params.isValid()) {
			response.status().addErrors(params.getValidationErrors());
		}
		//Source blob
		ValidationUtil.checkBlobExists(response, params.getSourceAccount(), params.getSourcePathContainer(), params.getSourceFilePath());

		if (response.hasErrors()) {
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(response).build();
		}

		BlobClient blob = AzureBlobStorageService.getBlob(params.getSourceAccount(), params.getSourcePathContainer(), params.getSourceFilePath());

		if (blob.getProperties().getContentMd5() != null && blob.getProperties().getContentMd5().length > 0) {
			response.setOriginalFileName(FilenameUtils.getName(blob.getBlobName()));
			response.setOriginalFileMd5Hash(Base64.encodeBase64String(blob.getProperties().getContentMd5()));
			response.status().success();
		} else {
			try (final BufferedInputStream input = new BufferedInputStream(blob.openInputStream())) {
				MessageDigest messageDigest = MessageDigest.getInstance("MD5");
				byte[] buffer = new byte[FileToolConstants.STREAMING_BUFFER_SIZE];
				int nRead;
				while ((nRead = input.read(buffer)) > 0) {
					messageDigest.update(buffer, 0, nRead);
				}
				response.setOriginalFileName(FilenameUtils.getName(blob.getBlobName()));
				response.setOriginalFileMd5Hash(Base64.encodeBase64String(messageDigest.digest()));
				response.status().success();
			} catch (Exception e) {
				final String msg = "Unexpected error: ";
				log.error(msg, e);
				response.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
			}
		}

		response.setDateTimeEnd(FileToolUtils.getNowFormatted());
		return request.createResponseBuilder(HttpStatus.OK).body(response).build();
	}

}

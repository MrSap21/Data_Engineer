package com.wbadz.leap.azure.filetools.model;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TaskResult {

	private String fileName;
	private String md5Hash;
	private String assetId;
	private String parentAssetId;
	private long size;
	private Long rows;
	private String extension;
	private String errorMessage;

	public TaskResult() {

	}

	public TaskResult(Map<String, String> metaData) {
		this.fileName = metaData.get("fileName");
		if (StringUtils.isNumeric(metaData.get("size"))) {
			this.size = Long.parseLong(metaData.get("size"));
		}
		this.assetId = metaData.get("assetId");
		this.parentAssetId = metaData.get("parentAssetId");
		this.extension = metaData.get("extension");
		if (StringUtils.isNumeric(metaData.get("rows"))) {
			this.rows = Long.parseLong(metaData.get("rows"));
		}
		this.md5Hash = metaData.get("md5Hash");
		this.errorMessage = null;
	}

}

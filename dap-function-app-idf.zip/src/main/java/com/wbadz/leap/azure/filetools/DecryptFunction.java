package com.wbadz.leap.azure.filetools;

import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.MDC;

import com.azure.security.keyvault.secrets.SecretClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskParams;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskResponse;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;
import com.wbadz.leap.azure.filetools.vault.AzureKeyVaultService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DecryptFunction {

	@FunctionName("decrypt")
	public HttpResponseMessage run(
			@HttpTrigger(name = "req", methods = { HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<FiletoolTaskParams>> request,
			final ExecutionContext context) {

		MDC.clear();
		Optional<FiletoolTaskParams> paramsOpt = request.getBody();
		log.info("Starting DecryptFunction ... Request: {}", paramsOpt);

		if (!paramsOpt.isPresent()) {
			String msg = "Request body is empty. Exiting...";
			log.error(msg);
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(msg).build();
		}
		FiletoolTaskParams params = paramsOpt.get();

		log.info("Start DecryptFunction with params: {}", params);
		MDC.put(FileToolConstants.CORRELATION_ID_LOG_VAR_NAME, params.getTaskId());

		FiletoolTaskResponse taskResponse = new FiletoolTaskResponse(params.getTaskId());
		if (!FileToolUtils.isEncryptedFile(params.getFile())) {
			taskResponse.status().addError("Not supported encrypted file extension. Available extensions: " + FileToolConstants.ENCRYPTED_FILE_EXTENSIONS);
		}

		if (!params.isValid()) {
			taskResponse.status().addErrors(params.getValidationErrors());
		}

		//Source blob
		ValidationUtil.checkBlobExists(taskResponse, params.getSourceAccount(), params.getSourcePathContainer(), params.getSourceFilePath());

		//Target container
		ValidationUtil.checkContainerExists(taskResponse, params.getDestAccount(), params.getDestPathContainer());

		//Keyvault validation
		SecretClient keyvault = null;
		try {
			keyvault = AzureKeyVaultService.getKeyvault(params.getKeyvaultUrl());
			if (keyvault == null) {
				taskResponse.status().addError("Can not get keyvault: " + params.getKeyvaultUrl());
			}
			ValidationUtil.checkKeyvaultSecretExists(taskResponse, keyvault, params.getPrivateKeySecretName());
			ValidationUtil.checkKeyvaultSecretExists(taskResponse, keyvault, params.getPassphraseSecretName());
		} catch (Exception e) {
			String msg = "Error retrieving keyvault";
			log.error(msg, e);
			taskResponse.status().addError(msg + " Error: " + StringEscapeUtils.unescapeJson(e.getMessage()));
		}

		try {
			if (!AsyncProcessFunction.checkAsyncFunctionConnection()) {
				taskResponse.status().addError("Can not connect to AsyncFiletoolFunction");
			}
		} catch (Exception e) {
			String msg = "Error connecting to AsyncFiletoolFunction";
			log.error(msg, e);
			taskResponse.status().addError(msg + " Error: " + StringEscapeUtils.unescapeJson(e.getMessage()));
		}

		if (taskResponse.hasErrors()) {
			taskResponse.setDateTimeEnd(FileToolUtils.getNowFormatted());
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(taskResponse).build();
		}

		if (StringUtils.isNotEmpty(FileToolConstants.ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE)) {
			taskResponse.setTaskResultFilePath(FileToolUtils.addFolderSeparator(FileToolConstants.ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE));
		} else {
			taskResponse.setTaskResultFilePath(FileToolUtils.addFolderSeparator(params.getDestPath()) + params.getTaskId());
		}

		final String taskResultFileName = params.getTaskId() + ".json";
		taskResponse.setTaskResultFileName(taskResultFileName);

		//START ASYNC
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.submit(() -> {
			params.setRecursive(false);
			try {
				AsyncProcessFunction.callAsync(params);
			} catch (Exception e) {
				log.error("Error calling to AsyncFiletoolFunction");
			}
		});
		//END ASYNC

		taskResponse.setDateTimeEnd(FileToolUtils.getNowFormatted());
		return request.createResponseBuilder(HttpStatus.OK).body(taskResponse).build();
	}

}

package com.wbadz.leap.azure.filetools.vault;

import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;

public class AzureKeyVaultService {

	private AzureKeyVaultService() {

	}

	public static String getSecretValue(String keyVaultURL, String secretName) {
		SecretClient secretClient = getKeyvault(keyVaultURL);
		KeyVaultSecret secret = secretClient.getSecret(secretName);

		return secret.getValue();
	}

	public static SecretClient getKeyvault(String keyVaultURL) {
		return new SecretClientBuilder()
				.vaultUrl(parseKeyvaultURL(keyVaultURL))
				.credential(new DefaultAzureCredentialBuilder().build())
				.buildClient();
	}

	private static String parseKeyvaultURL(String keyvault) {
		if (keyvault.startsWith("http")) {
			return keyvault;
		}
		return String.format(FileToolConstants.AZURE_GENERIC_KEYVAULT_URL, keyvault);
	}

}

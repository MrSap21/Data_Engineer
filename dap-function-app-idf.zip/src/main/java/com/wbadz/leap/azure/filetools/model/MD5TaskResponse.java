package com.wbadz.leap.azure.filetools.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MD5TaskResponse extends BaseResponse {

	private String originalFileName;
	private String originalFileMd5Hash;

	public MD5TaskResponse() {
		super();
	}

}

package com.wbadz.leap.azure.filetools;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.zip.GZIPInputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveEntry;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.z.ZCompressorInputStream;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.MDC;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.specialized.BlobOutputStream;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskParams;
import com.wbadz.leap.azure.filetools.model.FiletoolTaskResponse;
import com.wbadz.leap.azure.filetools.model.TaskResult;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ProcessStream;
import com.wbadz.leap.azure.filetools.vault.AzureKeyVaultService;

import lombok.extern.slf4j.Slf4j;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.BouncyGPG;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.callbacks.KeyringConfigCallbacks;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.InMemoryKeyring;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfigs;

@Slf4j
public class AsyncProcessFunction {

	private static final String JSON_EXTENSION = ".json";

	public enum FileType {
		GZIP, ZIP, ENCRYPTED, FINAL, BZIP, ZZIP, CPIO;
	}

	private FiletoolTaskParams params;

	private BlobClient originalBlob;

	private byte[] secretKey;

	private String passPhrase;

	private FiletoolTaskResponse taskResponse;

	private int filesProcessed = 0;

	@FunctionName("asyncProcess")
	public HttpResponseMessage run(
			@HttpTrigger(name = "req", methods = {
					com.microsoft.azure.functions.HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<FiletoolTaskParams>> request,
			final ExecutionContext context) {

		MDC.clear();
		Optional<FiletoolTaskParams> paramsOpt = request.getBody();
		log.info("Starting AsyncFiletoolFunction .., instance: {}.", System.getenv("WEBSITE_INSTANCE_ID"));			

		if (!paramsOpt.isPresent()) {
			String msg = "Request body is empty. Exiting...";
			log.error(msg);
			return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body(msg).build();
		}
		this.params = paramsOpt.get();
		log.info("Params: {}", params);
		
		if (params.isTestConnection()) {
			return request.createResponseBuilder(HttpStatus.OK).build();
		}

		MDC.put(FileToolConstants.CORRELATION_ID_LOG_VAR_NAME, params.getTaskId());

		taskResponse = new FiletoolTaskResponse(params.getTaskId());
		if (StringUtils.isNotEmpty(FileToolConstants.ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE)) {
			taskResponse.setTaskResultFilePath(FileToolUtils.addFolderSeparator(FileToolConstants.ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE));
		} else {
			taskResponse.setTaskResultFilePath(FileToolUtils.addFolderSeparator(params.getDestPath()) + params.getTaskId());
		}

		final String taskResultFileName = params.getTaskId() + JSON_EXTENSION;
		taskResponse.setTaskResultFileName(taskResultFileName);

		try {
			start();			
			taskResponse.status().success();
		} catch (Exception e) {
			final String msg = "Unexpected error: ";
			log.error(msg, e);
			taskResponse.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
		}

		try {
			writeTaskResponseFile();
		} catch (Exception e) {
			log.error("Error in writeTaskResponseFile", e);
		}

		return request.createResponseBuilder(HttpStatus.OK).body(taskResponse).build();
	}

	public void start() throws Exception {
		originalBlob = AzureBlobStorageService.getBlob(params.getSourceAccount(), params.getSourcePathContainer(), params.getSourceFilePath());			

		if (StringUtils.isNoneBlank(params.getKeyvaultUrl(), params.getPrivateKeySecretName(), params.getPassphraseSecretName())) {
			this.secretKey = AzureKeyVaultService.getSecretValue(params.getKeyvaultUrl(), params.getPrivateKeySecretName()).getBytes(StandardCharsets.UTF_8);
			this.passPhrase = AzureKeyVaultService.getSecretValue(params.getKeyvaultUrl(), params.getPassphraseSecretName());			
		}

		final String blobFileName = FilenameUtils.getName(originalBlob.getBlobName());
		taskResponse.setOriginalFileName(blobFileName);
		taskResponse.setOriginalFileMd5Hash(Base64.encodeBase64String(originalBlob.getProperties().getContentMd5()));

		try (final BufferedInputStream originalInputStream = new BufferedInputStream(originalBlob.openInputStream())) {			
			handleFile(originalInputStream, blobFileName);
        }
	
	}

	public void decrypt(final InputStream originalInputStream, final String fileName) throws Exception {
		log.info("Decrypting file: {}", fileName);
		filesProcessed++;

		if (originalInputStream == null){
			log.error("Original Inputstream null: {}", fileName);
		}

		
		// ISSUE - MVP 7438		
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		InMemoryKeyring decryptionKeyring;

		decryptionKeyring = KeyringConfigs.forGpgExportedKeys(KeyringConfigCallbacks.withPassword(passPhrase));
		decryptionKeyring.addSecretKey(secretKey);

		try (final InputStream decryptedStream = BouncyGPG.decryptAndVerifyStream()
               	.withConfig(decryptionKeyring)
                .andIgnoreSignatures()
                .fromEncryptedInputStream(originalInputStream)) {
            final String decryptedFileName = FilenameUtils.removeExtension(fileName);
            handleFile(decryptedStream, decryptedFileName);
        }	
	}

	public void unzip(final InputStream originalInputStream) throws Exception {
		log.info("Unzipping file ...");
		filesProcessed++;

		try (ZipArchiveInputStream zipArchiveInputStream = new ZipArchiveInputStream(originalInputStream)) {
			ZipArchiveEntry zipEntry;
			while ((zipEntry = zipArchiveInputStream.getNextZipEntry()) != null) {
				log.info("\tZip Entry: {}, size: {}", zipEntry.getName(), zipEntry.getSize());
				handleFile(zipArchiveInputStream, zipEntry.getName());
			}
		}
	}

	public void ungzip(final InputStream originalInputStream, final String fileName) throws Exception {
		log.info("UnGZipping file ...");
		filesProcessed++;

		try(GZIPInputStream gzipInputStream = new GZIPInputStream(originalInputStream)){
			handleFile(gzipInputStream, FilenameUtils.removeExtension(fileName));		
		}
	}

	public void unzipcpio(final InputStream originalInputStream) throws Exception {
        
        log.info("UnCPIOZipping file ...");
		filesProcessed++;
        
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(originalInputStream);
		CpioArchiveEntry zipEntry;
		while ((zipEntry = cpioInputStream.getNextCPIOEntry()) != null) {
			log.info("\tZip Entry: {} ; size: {} ", zipEntry.getName(), zipEntry.getSize());
			handleFile(cpioInputStream, zipEntry.getName());
		}
		cpioInputStream = null;
    }


	public void unzzip(final InputStream originalInputStream, String fileName) throws Exception {
		log.info("UnZZipping file ...");
		filesProcessed++;
        
		ZCompressorInputStream zZipArchiveInputStream = new ZCompressorInputStream(originalInputStream);
		String fileNameExtensions = FilenameUtils.getExtension(fileName);
		String fileNameNew = fileName.substring(0, fileName.length() - 1 - fileNameExtensions.length());
        handleFile(zZipArchiveInputStream, fileNameNew);
            
        zZipArchiveInputStream = null;
    }

    public void unbzip(final InputStream originalInputStream, String fileName) throws Exception {
		log.info("UnBZipping file ...");
		filesProcessed++;
        
        BZip2CompressorInputStream bZipArchiveInputStream = new BZip2CompressorInputStream(originalInputStream);
		String fileNameExtensions = FilenameUtils.getExtension(fileName);
		String fileNameNew = fileName.substring(0, fileName.length() - 1 - fileNameExtensions.length());
        handleFile(bZipArchiveInputStream, fileName.replace("." + FilenameUtils.getExtension(fileName), ""));

		bZipArchiveInputStream = null;
    }

	private void handleFile(final InputStream inputStream, final String fileName) throws Exception {
		final FileType fileType = (!params.isRecursive() && filesProcessed > 0) ? FileType.FINAL : FileToolUtils.getFileType(fileName);
		log.info("Handling file: {}, type: {}, Current files processed: {} ", fileName, fileType, filesProcessed);

		if(FileToolConstants.LAND_TO_RAW.equalsIgnoreCase(params.getTaskType())) {
			processFinalFile(inputStream, fileName);
		}
		else {
			switch (fileType) {
			case ZIP:
				unzip(inputStream);
				break;

			case GZIP:
				ungzip(inputStream, fileName);
				break;
			
			case BZIP:
				unbzip(inputStream, fileName);
				break;
			
			case ZZIP:
				unzzip(inputStream, fileName);
				break;

			case CPIO:
				unzipcpio(inputStream);
				break;

			case ENCRYPTED:
				decrypt(inputStream, fileName);
				break;

			case FINAL:
				processFinalFile(inputStream, fileName);
				break;

			default:
				break;
			}
		}
	}

	private void processFinalFile(final InputStream inputStream, final String fileName) throws NoSuchAlgorithmException, IOException {
		log.info("Handling final file: {}, size: {}", fileName);

		final boolean countLines = params.isCountLines() && FileToolUtils.isCountLinesFile(fileName);
		final boolean calculateMD5 = params.isCalculateMD5();
		final boolean zipResults = params.isZipResults() && !FileToolUtils.isZipFile(fileName);

		String blobName = fileName;
		if(FileToolConstants.LAND_TO_RAW.equalsIgnoreCase(params.getTaskType())) {
			blobName =  FileToolUtils.addFolderSeparator(params.getTaskId()) + fileName;
		}
		if (FileType.ZIP == FileToolUtils.getFileType(fileName)){
			blobName = blobName + ".zip";
		}else if (FileType.GZIP == FileToolUtils.getFileType(fileName)){
			blobName = blobName + ".gz";
		}

		BlobClient blob = AzureBlobStorageService.getBlob(params.getDestAccount(), params.getDestPathContainer(), params.getDestFilePath(blobName));
		log.info("Blob: {}, zipResults: {}, countLines: {}, messageDigest: {}", blob.getBlobUrl(), zipResults, countLines, calculateMD5);

		ProcessStream processStream = new ProcessStream(inputStream, fileName, blob, countLines, calculateMD5, zipResults);
		processStream.run();
		log.info("Blob: {} uploaded", blob.getBlobUrl());

		final String originalFileName = FilenameUtils.getName(originalBlob.getBlobName());

		Map<String, String> blobMetaData = new HashMap<>();
		blobMetaData.put("fileName", fileName);
		blobMetaData.put("extension", FilenameUtils.getExtension(fileName));
		blobMetaData.put("size", String.valueOf(blob.getProperties().getBlobSize()));
		blobMetaData.put("originalFileName", originalFileName);
		blobMetaData.put("originalFileMd5Hash", Base64.encodeBase64String(originalBlob.getProperties().getContentMd5()));
		blobMetaData.put("assetId", originalFileName.equalsIgnoreCase(fileName) ? params.getAssetId() : FileToolConstants.METADATA_NULL_STR_VALUE);
		blobMetaData.put("parentAssetId", !originalFileName.equalsIgnoreCase(fileName) ? params.getAssetId() : FileToolConstants.METADATA_NULL_STR_VALUE);
		blobMetaData.put("rows", countLines ? String.valueOf(processStream.getFileRows()) : FileToolConstants.METADATA_NULL_STR_VALUE);
		blobMetaData.put("md5Hash", calculateMD5 ? processStream.getMD5Hash() : FileToolConstants.METADATA_NULL_STR_VALUE);
		blob.setMetadata(blobMetaData);
		log.info("Blob metadata updated {}", blob.getBlobUrl());

		taskResponse.addTaskResult(new TaskResult(blobMetaData));
	}

	private void writeTaskResponseFile() throws IOException {
		//Response file to be uploaded with results to destination account
		taskResponse.setDateTimeEnd(FileToolUtils.getNowFormatted());
		BlobClient destBlob = null;
		String resultFile = params.getTaskId() + JSON_EXTENSION;
		if (StringUtils.isNotEmpty(FileToolConstants.ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE)) {
			destBlob = AzureBlobStorageService.getBlob(params.getDestAccount(), FileToolConstants.ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE, resultFile);
		} else {
			String blobName = FileToolUtils.addFolderSeparator(params.getTaskId()) + resultFile;
			destBlob = AzureBlobStorageService.getBlob(params.getDestAccount(), params.getDestPathContainer(), params.getDestFilePath(blobName));
		}

		try (InputStream input = IOUtils.toInputStream(taskResponse.toJSON(), StandardCharsets.UTF_8);
				BlobOutputStream output = destBlob.getBlockBlobClient().getBlobOutputStream(true)) {
			IOUtils.copy(input, output);
		}
		log.info("TaskResponse file generated and uploaded: {}", destBlob.getBlobUrl());
	}

	public static boolean callAsync(FiletoolTaskParams params) throws IOException {
		log.info("Calling Async Azure Function. URL: {} \nParams {}", FileToolConstants.ASYNC_FILETOOL_FUNCTION_URL, params);
		if (StringUtils.isEmpty(FileToolConstants.ASYNC_FILETOOL_FUNCTION_URL)) {
			throw new IllegalArgumentException("AsyncFiletoolFunction URL can not be empty");
		}

		HttpPost post = new HttpPost(FileToolConstants.ASYNC_FILETOOL_FUNCTION_URL);
		post.setEntity(new StringEntity(params.toJSON()));

		StatusLine status = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse response = httpClient.execute(post)) {
			status = response.getStatusLine();
			log.info("Response status: {}", status);
		}

		return status != null && status.getStatusCode() == HttpStatus.OK.value();
	}

	public static String callSync(FiletoolTaskParams params) throws IOException {
		log.info("Calling Sync Azure Function. URL: {} \nParams {}", FileToolConstants.ASYNC_FILETOOL_FUNCTION_URL, params);
		if (StringUtils.isEmpty(FileToolConstants.ASYNC_FILETOOL_FUNCTION_URL)) {
			throw new IllegalArgumentException("AsyncFiletoolFunction URL can not be empty");
		}

		String response = null;
		HttpPost post = new HttpPost(FileToolConstants.ASYNC_FILETOOL_FUNCTION_URL);
		post.setEntity(new StringEntity(params.toJSON()));
		try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse httpResponse = httpClient.execute(post)) {
			response = EntityUtils.toString(httpResponse.getEntity());
		}

		return response;
	}

	public static boolean checkAsyncFunctionConnection() throws IOException {
		FiletoolTaskParams params = new FiletoolTaskParams();
		params.setTestConnection(true);
		return callAsync(params);
	}

}

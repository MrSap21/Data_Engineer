package com.wbadz.leap.azure.filetools.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

import com.azure.security.keyvault.secrets.SecretClient;
import com.wbadz.leap.azure.filetools.model.BaseResponse;
import com.wbadz.leap.azure.filetools.storage.AzureBlobStorageService;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ValidationUtil {

	@Getter
	private List<String> errors;

	public ValidationUtil() {
	}

	public ValidationUtil(List<String> errors) {
		this.errors = errors;
	}

	public void checkMandatory(String paramName, String paramValue) {
		if (StringUtils.isEmpty(paramValue)) {
			addError("Missing mandatory param: " + paramName);
		}
	}

	public void addError(String error) {
		if (errors == null) {
			this.errors = new ArrayList<>();
		}
		if (!errors.contains(error)) {
			errors.add(error);
		}
	}

	public static boolean checkContainerExists(BaseResponse taskResponse, String storageAccount, String container) {
		boolean containerExists = false;
		try {
			containerExists = AzureBlobStorageService.checkBlobContainerExists(storageAccount, container);
			if (!containerExists) {
				final String error = String.format("BlobContainer does not exist. Storage account: %s ## Container: %s", storageAccount, container);
				taskResponse.status().addError(error);
			}
		} catch (Exception e) {
			final String msg = String.format("Error checking blob-container existence. Storage account: %s ## Container: %s", storageAccount, container);
			taskResponse.status().addError(msg + StringEscapeUtils.unescapeJson(e.getMessage()));
			log.error(msg, e);
			containerExists = false;
		}
		return containerExists;
	}

	public static boolean checkBlobExists(BaseResponse taskResponse, String storageAccount, String container, String remotePath) {
		boolean blobExists = false;
		try {
			blobExists = AzureBlobStorageService.checkBlobExists(storageAccount, container, remotePath);
			if (!blobExists) {
				final String error = String.format("Blob does not exist. Storage account: %s ## Container: %s ## Remote path: %s", storageAccount, container, remotePath);
				taskResponse.status().addError(error);
			}
		} catch (Exception e) {
			final String error = String.format("Error checking blob existence. Storage account: %s ##  Container: %s ## Remote path: %s", storageAccount, container, remotePath);
			taskResponse.status().addError(error + StringEscapeUtils.unescapeJson(e.getMessage()));
			log.error(error, e);
			blobExists = false;
		}
		return blobExists;
	}

	public static boolean checkKeyvaultSecretExists(BaseResponse taskResponse, SecretClient keyvault, String secretName) {
		boolean secretExists = false;
		try {
			keyvault.getSecret(secretName);
		} catch (Exception e) {
			final String error = String.format("Error checking secret existence. Keyvault: %s ## SecretName: %s", keyvault.getVaultUrl(), secretName);
			taskResponse.status().addError(error + StringEscapeUtils.unescapeJson(e.getMessage()));
			log.error(error, e);
			secretExists = false;
		}
		return secretExists;
	}

}

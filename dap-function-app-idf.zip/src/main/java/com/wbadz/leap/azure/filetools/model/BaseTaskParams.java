package com.wbadz.leap.azure.filetools.model;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.wbadz.leap.azure.filetools.util.FileToolConstants;
import com.wbadz.leap.azure.filetools.util.FileToolUtils;
import com.wbadz.leap.azure.filetools.util.ValidationUtil;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
@ToString
public class BaseTaskParams {

	private String sourceAccount;
	private String sourcePath;
	private String file;

	public String getSourceAccount() {
		if (StringUtils.isEmpty(sourceAccount)) {
			return sourceAccount;
		}
		return parseStorageAccount(sourceAccount);
	}

	@JsonIgnore
	public static String getContainer(final String path) {
		if (StringUtils.isNotEmpty(path)) {
			String aux = FileToolUtils.addFolderSeparatorAtStart(path);
			if (StringUtils.countMatches(aux, "/") == 1) {
				return path.replace("/", "");
			}
			return StringUtils.substringBetween(aux, "/", "/");
		}
		return null;
	}

	@JsonIgnore
	public static String getFilePath(final String path, final String container) {
		String aux = FileToolUtils.addFolderSeparatorAtStart(path);
		if (StringUtils.isNotEmpty(path)) {
			aux = aux.replaceFirst(Pattern.quote("/" + container), "");
		}
		return FileToolUtils.addFolderSeparator(aux);
	}

	@JsonIgnore
	public String getSourcePathContainer() {
		return getContainer(sourcePath);
	}

	@JsonIgnore
	public String getSourceFilePath() {
		String aux = getFilePath(sourcePath, getContainer(sourcePath));
		if (aux.startsWith("/")) {
			aux = aux.replaceFirst(Pattern.quote("/"), "");
		}
		return aux + file;
	}

	@JsonIgnore
	public List<String> getValidationErrors() {
		ValidationUtil validation = new ValidationUtil();
		validation.checkMandatory("sourceAccount", sourceAccount);
		validation.checkMandatory("sourcePath", sourcePath);
		validation.checkMandatory("file", file);

		return validation.getErrors();
	}

	@JsonIgnore
	public boolean isValid() {
		return CollectionUtils.isEmpty(getValidationErrors());
	}

	public static String parseStorageAccount(String accountUrl) {
		if (StringUtils.startsWith(accountUrl, "https")) {
			String aux = StringUtils.substringBetween(accountUrl, "https://", ".");
			return String.format(FileToolConstants.AZURE_GENERIC_BLOB_URL, aux);
		}
		return String.format(FileToolConstants.AZURE_GENERIC_BLOB_URL, accountUrl);
	}

	public String toJSON() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			log.error("Error generating JSON.", e);
			return null;
		}
	}

}

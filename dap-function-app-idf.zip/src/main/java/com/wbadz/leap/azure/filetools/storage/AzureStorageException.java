package com.wbadz.leap.azure.filetools.storage;

public class AzureStorageException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AzureStorageException(String message) {
		super(message);
	}

}

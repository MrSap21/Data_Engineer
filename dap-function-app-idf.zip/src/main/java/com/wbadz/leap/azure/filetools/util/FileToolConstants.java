package com.wbadz.leap.azure.filetools.util;

import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class FileToolConstants {

	private FileToolConstants() {

	}

	public static final long METADATA_NULL_LONG_VALUE = -1l;
	public static final String METADATA_NULL_STR_VALUE = String.valueOf(METADATA_NULL_LONG_VALUE);

	public static final String FOLDER_SEPARATOR = "/";
	public static final char LINE_BREAK = '\n';
	public static final String DATE_FORMAT = "yyyyMMdd HH:mm:ss.SSS";
	public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(DATE_FORMAT).withZone(ZoneOffset.UTC);

	public static final String CORRELATION_ID_LOG_VAR_NAME = "correlationId";

	public static final String AZURE_GENERIC_BLOB_URL = "https://%s.blob.core.windows.net/";
	public static final String AZURE_GENERIC_KEYVAULT_URL = "https://%s.vault.azure.net/";

	public static final String ASYNC_FILETOOL_FUNCTION_URL = System.getenv("filetool.async.function.url");
	public static final String ASYNC_FILETOOL_FUNCTION_BLOB_RESPONSE = System.getenv("filetool.async.function.blob.response");

	public static final String DEFAULT_PROBE_BLOB_CONTAINER = "filetoolprobe";
	public static final String PROBE_BLOB_CONTAINER = StringUtils.isNotEmpty(System.getenv("filetool.probe.function.blob.container"))
			? System.getenv("filetool.probe.function.blob.container")
			: DEFAULT_PROBE_BLOB_CONTAINER;

	public static final int DEFAULT_STREAMING_BUFFER_SIZE = 8 * 1024;
	public static final int STREAMING_BUFFER_SIZE = System.getenv("filetool.streaming.buffer.size") != null
			? Integer.parseInt(System.getenv("filetool.streaming.buffer.size"))
			: DEFAULT_STREAMING_BUFFER_SIZE;

	private static final List<String> DEFAULT_ENCRYPTED_FILE_EXTENSIONS = Arrays.asList("gpg", "pgp");
	public static final List<String> ENCRYPTED_FILE_EXTENSIONS = unmodifiableList("filetool.encrypted.file.extensions", DEFAULT_ENCRYPTED_FILE_EXTENSIONS);

	private static final List<String> DEFAULT_ZIP_FILE_EXTENSIONS = Arrays.asList("zip");
	public static final List<String> ZIP_FILE_EXTENSIONS = unmodifiableList("filetool.zip.file.extensions", DEFAULT_ZIP_FILE_EXTENSIONS);

	private static final List<String> DEFAULT_GZIP_FILE_EXTENSIONS = Arrays.asList("gzip", "gz");
	public static final List<String> GZIP_FILE_EXTENSIONS = unmodifiableList("filetool.gzip.file.extensions", DEFAULT_GZIP_FILE_EXTENSIONS);

	private static final List<String> DEFAULT_BZIP_FILE_EXTENSIONS = Arrays.asList("bz2");
	public static final List<String> BZIP_FILE_EXTENSIONS = unmodifiableList("filetool.bzip.file.extensions", DEFAULT_BZIP_FILE_EXTENSIONS);

	private static final List<String> DEFAULT_ZZIP_FILE_EXTENSIONS = Arrays.asList("Z");
	public static final List<String> ZZIP_FILE_EXTENSIONS = unmodifiableList("filetool.zzip.file.extensions", DEFAULT_ZZIP_FILE_EXTENSIONS);

	private static final List<String> DEFAULT_CPIO_FILE_EXTENSIONS = Arrays.asList("cpio");
	public static final List<String> CPIO_FILE_EXTENSIONS = unmodifiableList("filetool.cpio.file.extensions", DEFAULT_CPIO_FILE_EXTENSIONS);

	private static final List<String> DEFAULT_COUNT_LINE_FILE_EXTENSIONS = Arrays.asList("csv", "txt", "dat");
	public static final List<String> COUNT_LINE_FILE_EXTENSIONS = unmodifiableList("filetool.count.file.extensions", DEFAULT_COUNT_LINE_FILE_EXTENSIONS);

	private static List<String> unmodifiableList(String envProperty, List<String> defaultList) {
		String propertyValue = System.getenv(envProperty);
		if (StringUtils.isNotEmpty(propertyValue)) {
			return Collections.unmodifiableList(Arrays.asList(StringUtils.split(propertyValue, ",")));
		}
		return Collections.unmodifiableList(defaultList);
	}

	public static final String LAND_TO_RAW = "landToRaw";

}
﻿CREATE SCHEMA [hist_migration_abc]
    AUTHORIZATION [dbo];






GO
--GRANT EXECUTE
    --ON SCHEMA::[hist_migration_abc] TO [dapdevadf01];


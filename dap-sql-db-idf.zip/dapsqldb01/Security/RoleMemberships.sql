﻿/*ALTER ROLE [db_owner] ADD MEMBER [dev-rpu-dna-sqldb-1496];


GO
ALTER ROLE [db_owner] ADD MEMBER [Azure-DNA-DevRole-DBAdmin];


GO
--ALTER ROLE [db_ddladmin] ADD MEMBER [Developer];




GO
ALTER ROLE [db_datawriter] ADD MEMBER [dev-rpu-dna-synapse-1496];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [dev-rpu-dna-adls-1496];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [dapdevidfadf01];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [svc-sqluser];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [Azure-DNA-DevRole-DBEngineer];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [dev-rpu-dna-sqldb-1496];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [dapdevadf01];


GO
ALTER ROLE [db_datareader] ADD MEMBER [dev-rpu-dna-synapse-1496];


GO
ALTER ROLE [db_datareader] ADD MEMBER [dev-rpu-dna-adls-1496];


GO
ALTER ROLE [db_datareader] ADD MEMBER [dapdevidfadf01];


GO
ALTER ROLE [db_datareader] ADD MEMBER [svc-sqluser];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Azure-DNA-DevRole-MLEngineer];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Azure-DNA-DevRole-ETLDev];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Azure-DNA-DevRole-DataEng];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Azure-DNA-DevRole-BIDev];


GO
ALTER ROLE [db_datareader] ADD MEMBER [Azure-DNA-DevRole-BIArch];


GO
ALTER ROLE [db_datareader] ADD MEMBER [dev-rpu-dna-sqldb-1496];


GO
ALTER ROLE [db_datareader] ADD MEMBER [dapdevadf01];
*/

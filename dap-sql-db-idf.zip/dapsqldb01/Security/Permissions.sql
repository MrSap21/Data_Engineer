﻿--GRANT EXECUTE
   -- ON SCHEMA::[dbo] TO [dapdevadf01];


-- GO
-- GRANT EXECUTE
--     ON SCHEMA::[dbo] TO [Azure-DNA-DevRole-DataEng];


CREATE SCHEMA [idfwba]
    AUTHORIZATION [dbo];






-- GO



-- GO
-- GRANT EXECUTE
--     ON SCHEMA::[idfwba] TO [dapdevadf01];


-- GO
-- GRANT EXECUTE
--     ON SCHEMA::[idfwba] TO [Azure-DNA-DevRole-DataEng];


﻿--IF OBJECT_ID ( 'idfwba.AssetStatusChange', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.AssetStatusChange;
--GO

CREATE PROCEDURE idfwba.AssetStatusChange
(
    @pAssetID                       AS NVARCHAR(20),
    @pStatusID                      AS NVARCHAR(20), --Possible values are LOVID from RefLOV where LOVSetID=24
    @pDTCreated                     AS NVARCHAR(21), --Format: 20200430 16:58:47. If not informed, default GETDATE() if not informed
    @pUserCreated                   AS NVARCHAR(100) --Default SYSTEM_USER (login user) if not informed
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : AssetStatusChange.sql
-- Description : Insert a new row in AssetStatus and closes previous status
--
-- =============================================================================
--
-- Change History
-- Name               Date            Description
-- Daniel Santamaria  28-MAY-2020     Created
-- Daniel Santamaria  11-JUN-2020     Added default values for DTCreated and UserCreated
-- Victor Salesa Sanz 16-JUN-2020     Avoided to convert to NULL defaulting DTCreated and UserCreated values as they where being populated as null
-- Daniel Santamaria  18-JUN-2020     Undone previous for keeping consistence along SPs. Changed @vGetDate datatype SMALLDATETIME > DATETIME
-- Daniel Santamaria  16-JUL-2020     Fix wrong datatype in vProcedureMessage and vProcedureStatus
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY
        DECLARE @tTransaction VARCHAR(20) = 'tTransaction';
        BEGIN TRAN @tTransaction;

            /*Generic output variables*/
            DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
            DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';

            /*Variable for setting the same DTEffectiveFrom in new status and DTEffectiveTo in old status*/
            DECLARE @vGetDate                           AS DATETIME  = GETDATE();

            /*Convert empty strings into Null*/
            SET @pAssetID                               = NULLIF(@pAssetID        ,'');
            SET @pStatusID                              = NULLIF(@pStatusID       ,'');
            SET @pDTCreated                             = NULLIF(@pDTCreated      ,'');
            SET @pUserCreated                           = NULLIF(@pUserCreated    ,'');
            
            /*Set default values*/
            SET @pDTCreated                             = ISNULL(@pDTCreated        ,GETDATE());   --Default current date
            SET @pUserCreated                           = ISNULL(@pUserCreated      ,SYSTEM_USER); --Default user

            /*CLOSE active status*/
            UPDATE idfwba.AssetStatus
               SET DTEffectiveTo     = @vGetDate
             WHERE AssetID     = @pAssetID
               AND DTEffectiveTo IS NULL
             ;
            --Check IF @@ROWCOUNT = 0 ???-- NO need to check, if no status has been defined yet no error will raise, just 0 rows will be updated

            /*INSERT new status*/
            INSERT INTO idfwba.AssetStatus (  AssetID,   StatusID,   DTEffectiveFrom,   DTEffectiveTo,   DTCreated,   UserCreated)
                               VALUES (  @pAssetID, @pStatusID,         @vGetDate,            NULL, @pDTCreated, @pUserCreated)
            ;


            /*Return*/
            SELECT @pAssetID AS AssetID, @pStatusID AS StatusID, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

        COMMIT TRAN;
    END TRY

    BEGIN CATCH
        ROLLBACK TRAN @tTransaction;
        SELECT @pAssetID AS AssetID, @pStatusID AS StatusID
             , '-1' AS ProcedureStatus
             , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                      ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                      ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                      ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                      ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                      ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                     ) AS ProcedureMessage
        ;
    END CATCH;
END;
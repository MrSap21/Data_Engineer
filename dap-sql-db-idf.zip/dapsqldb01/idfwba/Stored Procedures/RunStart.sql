﻿--IF OBJECT_ID ( 'idfwba.RunStart', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.RunStart;
--GO

CREATE PROCEDURE idfwba.RunStart
(
    @pDTStart               AS NVARCHAR(21), -- 20200109 16:58:47.170
    @pRunLogTypeId          AS NVARCHAR(10), -- Job, Task, Pipeline 
    @pParentRunLogID        AS NVARCHAR(20), -- Null if is a job - runlogID of the Parent - 5
    @pFeedID                AS NVARCHAR(30), -- ID of the Feed itself -- 23
    @pJobID                 AS NVARCHAR(30), -- ID of the Feed Job -- 12
    @pAssetID               AS NVARCHAR(30), -- ID of the Asset related to that Feed
    @pTaskID                AS NVARCHAR(30), -- Task ID in Feed -- 10
    @pPipelineName          AS NVARCHAR(30), -- If it's a Pipeline -Test
    @pRunID                 AS NVARCHAR(100), -- RunID of the logged process (currently only DF pipeline) - 56465464
    @pParentRunID           AS NVARCHAR(100)  -- RunID of the parent's logged process (currently only DF pipeline) - 654654654
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : RunStart.sql                                                                                                           
-- Description : This procedure insert a new entity Row in idfwba.RUNLOG Table                                                        
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                         
-- Andrés Gracia     14-JAN-2020     Created                        
-- Andrés Gracia     31-JAN-2020     Changed comments & parameters due to Task 1678                                    
-- Daniel Santamaria 04-FEB-2020     Moved comments before BEGIN, removed TABs, write RunId on RunLogDefinitionJSON for RunLogTypeId='Job', added @pParentRunID
-- Victor Salesa     19-FEB-2020     Added assetid parameter to fill RunLogDefinitionJSON with the AssetID
-- Victor Salesa     25-FEB-2020     Corrected name of the Stored Procedure
-- Victor Salesa     10-MAR-2020     Added Pipelinename as available parameter for RunStart in Task Case
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @vDTStart_DT              AS DATETIME;
    DECLARE @vRunLogStatus            AS NVARCHAR(7)   = 'Running';
    DECLARE @vRunLogOutputJSON        AS NVARCHAR(30)  = '{"status": "","output": []}';
    DECLARE @vRunLogDefinitionJSON    AS NVARCHAR(200);
    DECLARE @vRunLogMessageJSON       AS NVARCHAR(2)   = '{}';
    DECLARE @vJobCount                AS NVARCHAR(2);
    DECLARE @vProcedureStatus         AS NVARCHAR(1)   = '0';
    DECLARE @vProcedureMessage        AS NVARCHAR(100) = 'OK';
    DECLARE @vRunLogID                AS NVARCHAR(20);

    /*AGO 20200117 - Avoid errors on Start Date*/
    IF (@pDTStart = '') OR (@pDTStart IS NULL)
        BEGIN
            SET @vDTStart_DT = NULL;
        END
    ELSE
        BEGIN
            SET @vDTStart_DT = CONVERT(datetime, @pDTStart, 113);
        END
    ;

    /*DS 20200204 - Null values*/
    SET @pParentRunLogID        = NULLIF(@pParentRunLogID,'');

    /*AGO 20200117 - Operate depending on what type of entity*/
    IF @pRunLogTypeId = 'Job'      
        BEGIN
            /*AGO 20200117 - It's a Job, so it won't be any PArent or Log Definition at this moment*/
            /*DS  20200204 - Included Log Definition, we need it to identify the row in RUNLOG when updating, ending, writing message/result later on*/
            SET @vRunLogDefinitionJSON = (SELECT TRIM(@pFeedID) AS FeedID, TRIM(@pJobID) AS JobID, TRIM(@pRunId) AS RunID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
            SET @vJobCount             = '1';
            SET @pParentRunLogID       = NULL;
        END
    ELSE
        BEGIN 
            /*DS  20200204 - Added ParentRunId logic*/
            IF @pParentRunLogID IS NULL 
                SELECT @pParentRunLogID = RunLogID 
                FROM idfwba.RUNLOG 
                WHERE JSON_VALUE(RunLogDefinitionJSON, '$.RunID') = @pParentRunID
            ;
            /*AGO 20200117 - It's not a Job, so we have to check if the Parent is really a Job*/
            /*DS  20200204 - Fixed logic in WHERE section*/
            SELECT @vJobCount = count(RunLogId)
            FROM   idfwba.RUNLOG
            WHERE  RunlogTypeId = 'Job'
              AND  RunLogId = @pParentRunLogID
            ;
            IF @pRunLogTypeId= 'Task'
                /*If it's a Task or Pipeline, the Definition JSon has to be set*/
                BEGIN
                    SET @vRunLogDefinitionJSON = (SELECT TRIM(@pFeedID) AS FeedID, TRIM(@pJobID) AS JobID, TRIM(@pTaskID) AS TaskID, TRIM(@pPipelineName) AS PipelineName, TRIM(@pRunID) AS RunID,TRIM(@pAssetID) AS AssetID 
                                                      FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
                END
            ELSE
                IF @pRunLogTypeId= 'Pipeline'
                    BEGIN
                        SET @vRunLogDefinitionJSON = (SELECT TRIM(@pFeedID) AS FeedID, TRIM(@pJobID) AS JobID, TRIM(@pTaskID) AS TaskID, TRIM(@pPipelineName) AS PipelineName, TRIM(@pRunID) AS RunID,TRIM(@pAssetID) AS AssetID 
                                                      FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
                    END
        END
    ;

    IF @vJobCount =0
        BEGIN
            /*AGO 20200117 - In case the parent doesn't exist an error will be raised. */
            SET @vProcedureStatus        ='-1';
            SET @vProcedureMessage       ='Task ID not found';
            SET @pParentRunLogID         ='Not Found';
        END
    ELSE
        BEGIN
            /*AGO 20200117 - Start with the parameters*/
            INSERT INTO [idfwba].[RUNLOG] ([RunLogTypeId],[ParentRunLogId],[RunLogDefinitionJSON],[DTStart],[DTEnd],[NrRecords],[DataSizeMB],[RunLogStatus],[RunLogOutputJSON],[RunLogMessageJSON])
            VALUES (@pRunLogTypeId,@pParentRunLogID,@vRunLogDefinitionJSON,@vDTStart_DT,NULL,NULL,NULL,@vRunLogStatus,@vRunLogOutputJSON,@vRunLogMessageJSON);
            
            SELECT @vRunLogID  = SCOPE_IDENTITY();
        END
    ;
    /*AGO 20200117 - Return*/
    SELECT @vRunLogID AS RunLogID, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
END TRY

BEGIN CATCH
    DECLARE @msg nvarchar(2048) = error_message();
    RAISERROR (@msg, 16, 1);
END CATCH
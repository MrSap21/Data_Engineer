﻿
CREATE PROCEDURE idfwba.AssetToProcessGet
(
    @pAssetID                       AS NVARCHAR(20), --Asset.AssetID
    @pFeedID                        AS NVARCHAR(20), --Asset.FeedID
    @pAssetStatusID                 AS NVARCHAR(20), --AssetStatus.StatusID -> RefLOVSetID.LOVID where LOVSetID=24
    @pProjectID                     AS NVARCHAR(20), --Feed.ProjectID       -> RefLOVSetID.LOVID where LOVSetID=8
    @pSourceRangeID                 AS NVARCHAR(20), --Feed.SourceRangeID   -> RefLOVSetID.LOVID where LOVSetID=16
    @pTargetLayer                   AS NVARCHAR(128), --'Load','PSA','Serve'. If null, then all are selected.
    @pLatestAssetFlag               AS NCHAR(1)      --'1':get latest AssetID for same AssetName-AssetCurrentLocation combination
                                                     --'0':get all AssetIDs regardless of AssetName-AssetCurrentLocation combination
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : AssetToProcessGet.sql
-- Description : Returns a list of assets with load process related information
--
-- =============================================================================
--
-- Change History
-- Name              Date            Description
-- Daniel Santamaria 27-MAY-2020     Created
-- Daniel Santamaria 01-JUN-2020     Added Asset Status to input and Record Source to output
-- Daniel Santamaria 02-JUN-2020     Added System of Record to output, return only PSA targeted ones, sort by FeedID and AssetID
-- Daniel Santamaria 03-JUN-2020     Added LOVID in output for reference values
-- Daniel Santamaria 18-JUN-2020     Added parameter to get latest AssetID for same AssetName-AssetCurrentLocation combination
-- Daniel Santamaria 16-JUL-2020     Fix wrong datatype in vProcedureMessage and vProcedureStatus
-- Daniel Santamaria 21-JUL-2020     Added ETLRunLog to output JSON, accept MasterRefData as Target Layer
-- Daniel Santamaria 14-AGO-2020     Bug34758: ETLRunLog set as inner array to avoid AssetID duplicates
-- Daniel Santamaria 14-AGO-2020     Added FeedStatus to JSON
-- Daniel Santamaria 18-AGO-2020     Bug35264: Poor performance, several changes. See task for further details
-- Daniel Santamaria 05-OCT-2020     Bug52481: Duplicating Asset info when there are several mappings for a Feed's Entity
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY
        DECLARE @tTransaction VARCHAR(20) = 'tTransaction';
        BEGIN TRAN @tTransaction;

            /*Generic output variables*/
            DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
            DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';

            /*JSON to store the list of Assets*/
            DECLARE @vAssetListJSON                     AS NVARCHAR(MAX);

            /*Convert empty strings into Null*/
            SET @pAssetID                               = NULLIF(@pAssetID       ,'');
            SET @pFeedID                                = NULLIF(@pFeedID        ,'');
            SET @pAssetStatusID                         = NULLIF(@pAssetStatusID ,'');
            SET @pProjectID                             = NULLIF(@pProjectID     ,'');
            SET @pSourceRangeID                         = NULLIF(@pSourceRangeID ,'');
            SET @pTargetLayer                           = NULLIF(@pTargetLayer   ,'');
            SET @pLatestAssetFlag                       = NULLIF(@pLatestAssetFlag   ,'');

            /*Set default values*/
            SET @pLatestAssetFlag                       = ISNULL(@pLatestAssetFlag ,'0'); --Get all AssetIDs regardless of AssetName-AssetCurrentLocation combination

            /*Build JSON*/
            --We use WITH <common_table_expression> in order to query MappingEntity-FeedEntity-Entity-RefLOV and RunLog only once
            WITH 
            cteMappingEntity AS (
                SELECT FeedID
                     , MAX(LoadTargetDomain)   AS LoadTargetDomain,   MAX(LoadTargetSchema)   AS LoadTargetSchema,   MAX(LoadTargetTable)   AS LoadTargetTable
                     , MAX(PSATargetDomain)    AS PSATargetDomain,    MAX(PSATargetSchema)    AS PSATargetSchema,    MAX(PSATargetTable)    AS PSATargetTable
                     , MAX(RefLOVTargetDomain) AS RefLOVTargetDomain, MAX(RefLOVTargetSchema) AS RefLOVTargetSchema, MAX(RefLOVTargetTable) AS RefLOVTargetTable
                FROM (SELECT me.MappingID
                           , fe.FeedID
                           , me.SourceEntityID
                           , me.TargetEntityID
                           , me.MappingSequence
                           , CASE WHEN rlLay.LOVKey = 'Load' THEN rlDom.LOVName ELSE NULL END AS LoadTargetDomain
                           , CASE WHEN rlLay.LOVKey = 'Load' THEN e.SchemaName  ELSE NULL END AS LoadTargetSchema
                           , CASE WHEN rlLay.LOVKey = 'Load' THEN e.TableName   ELSE NULL END AS LoadTargetTable
                           , CASE WHEN rlLay.LOVKey = 'PSA'  THEN rlDom.LOVName ELSE NULL END AS PSATargetDomain
                           , CASE WHEN rlLay.LOVKey = 'PSA'  THEN e.SchemaName  ELSE NULL END AS PSATargetSchema
                           , CASE WHEN rlLay.LOVKey = 'PSA'  THEN e.TableName   ELSE NULL END AS PSATargetTable
                           , CASE WHEN rlLay.LOVKey = 'MasterRefData'  THEN rlDom.LOVName ELSE NULL END AS RefLOVTargetDomain
                           , CASE WHEN rlLay.LOVKey = 'MasterRefData'  THEN e.SchemaName  ELSE NULL END AS RefLOVTargetSchema
                           , CASE WHEN rlLay.LOVKey = 'MasterRefData'  THEN e.TableName   ELSE NULL END AS RefLOVTargetTable
                      FROM idfwba.MappingEntity me
                      JOIN idfwba.FeedEntity    fe ON (fe.EntityID = me.SourceEntityID AND fe.FeedID IS NOT NULL) --We only want the Source Entities corresponding to feeds.
                      JOIN idfwba.Entity         e ON (e.EntityID = me.TargetEntityID AND e.ActiveFlag = 1)
                      JOIN idfwba.RefLOV     rlLay ON (rlLay.LOVID = e.LayerID)
                      JOIN idfwba.RefLOV     rlDom ON (rlDom.LOVID = e.DomainID)
                     ) sq
                GROUP BY FeedID --We don't include MappingID as we are only interested in the targets of a Feed, regardless of targets being in one Mapping or another
               ),
            cteFeed AS (
                SELECT f.FeedID
                     , f.ProjectID         AS ProjectID
                     , rlPrj.LOVName       AS ProjectName
                     , f.SourceRangeID     AS SourceRangeID
                     , rlRng.LOVName       AS SourceRangeName
                     , f.SourceSystemID    AS SourceSystemID
                     , rlSrc.LOVName       AS SourceSystemName
                     , fs.SystemOfRecordID AS SystemOfRecordID
                     , rlSoR.LOVName       AS SystemOfRecordName
                FROM idfwba.FEED        f
                JOIN idfwba.RefLOV  rlPrj ON (rlPrj.LOVID = f.ProjectID)
                JOIN idfwba.RefLOV  rlRng ON (rlRng.LOVID = f.SourceRangeID)
                JOIN idfwba.RefLOV  rlSrc ON (rlSrc.LOVID = f.SourceSystemID)
                LEFT JOIN idfwba.FEEDSOURCE fs ON (fs.FeedID = f.FeedID)
                LEFT JOIN idfwba.RefLOV  rlSoR ON (rlSoR.LOVID = fs.SystemOfRecordID)
                WHERE f.ProjectID     = ISNULL(@pProjectID,     f.ProjectID)
                  AND f.SourceRangeID = ISNULL(@pSourceRangeID, f.SourceRangeID)
                  --we don't need to filter Status='Active', a Feed may be deactivated when the Asset is still not processed
            ),
            cteRunLog AS (
                SELECT AssetID, RunLogId
                FROM (SELECT JSON_VALUE(RunLogDefinitionJSON, '$.AssetID') AS AssetID
                           , RunLogId
                           --Get the latest RunLog occurrence of each AssetID
                           , MAX(RunLogId) OVER (PARTITION BY JSON_VALUE(RunLogDefinitionJSON, '$.AssetID')) AS MaxRunLogId
                      FROM idfwba.RUNLOG 
                      WHERE JSON_VALUE(RunLogDefinitionJSON, '$.AssetID') IS NOT NULL
                        AND TRIM(RunLogTypeId) = 'Job'
                        AND TRIM(RunLogStatus) = 'Finished'
                      ) sq
                WHERE RunLogId = MaxRunLogId
               ),
            cteETLRunLog AS ( --Bug35264: JSON is built here, performance is very poor if we do it in the final query
                SELECT AssetID, CONCAT('[', STRING_AGG(ETLRunLog_Inner, ','), ']') AS ETLRunLog FROM (
                    SELECT AssetID, (SELECT ETLRunLogID, ETLProcessName, ETLRunLogStatusID, ETLRunLogStatusName FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER) AS ETLRunLog_Inner
                    FROM (SELECT erla.AssetID, erl.ETLRunLogID, erl.ETLProcessName, erl.ETLRunLogStatusID, rl.LOVName AS ETLRunLogStatusName
                               --Get the latest ETLRunLog occurrence of each AssetID-ETLProcessName pair
                               , MAX(erl.ETLRunLogId) OVER (PARTITION BY erla.AssetID, erl.ETLProcessName) AS MaxETLRunLogId
                          FROM idfwba.ETLRunLog       erl
                          JOIN idfwba.ETLRunLogAsset erla ON (erla.ETLRunLogID = erl.ETLRunLogID)
                          JOIN idfwba.RefLOV           rl ON (rl.LOVID = erl.ETLRunLogStatusID)
                         ) sq1
                    WHERE sq1.ETLRunLogID = sq1.MaxETLRunLogId
                    ) sq2
                GROUP BY AssetID
               ),
            cteAsset AS (
                SELECT AssetID, FeedID, AssetName, AssetCurrentLocation
                     --We asssume that latest created is the latest in place, including AssetID in order by in case of creation in the same minute
                     , RANK() OVER (PARTITION BY AssetName, AssetCurrentLocation ORDER BY DTCreated DESC, AssetID DESC) AS AssetLatestRank
                FROM idfwba.Asset
                --WHERE AssetID % 10 = 0 --For testing against a portion of the whole data
               )
            SELECT @vAssetListJSON = (
                SELECT a.AssetID
                     , a.FeedID
                     , fst.StatusID  AS FeedStatusID
                     , rlfst.LOVName AS FeedStatusName
                     , a.AssetName
                     , TRIM(a.AssetCurrentLocation) AS AssetLocation --We've found lots of trailing spaces in some cases
                     , r.RunLogId
                     , ast.StatusID  AS StatusID
                     , rlast.LOVName AS StatusName
                     , f.ProjectID
                     , f.ProjectName
                     , f.SourceRangeID
                     , f.SourceRangeName
                     , f.SourceSystemID
                     , f.SourceSystemName
                     , f.SystemOfRecordID
                     , f.SystemOfRecordName
                     , er.ETLRunLog --Bug35264: Replaces former query to build here the ETLRunLog JSON
                     , me.LoadTargetSchema
                     , me.LoadTargetTable
                     , me.PSATargetSchema
                     , me.PSATargetTable
                     , me.RefLOVTargetSchema
                     , me.RefLOVTargetTable
                FROM                cteAsset a
                INNER JOIN idfwba.FeedStatus  fst ON (fst.FeedID = a.FeedID AND fst.DTEffectiveTo IS NULL)
                INNER JOIN idfwba.RefLOV    rlfst ON (rlfst.LOVID = fst.StatusID)
                INNER JOIN idfwba.AssetStatus ast ON (ast.AssetID = a.AssetID AND ast.DTEffectiveTo IS NULL)
                INNER JOIN idfwba.RefLOV    rlast ON (rlast.LOVID = ast.StatusID)
                INNER JOIN cteFeed           f ON (f.FeedId = a.FeedID)
                 LEFT JOIN cteMappingEntity me ON (me.FeedID = a.FeedID)
                 LEFT MERGE JOIN cteRunLog         r ON (r.AssetID = a.AssetID) --Bug35264: Force execution plan with MERGE hint
                 LEFT MERGE JOIN cteETLRunLog er ON (er.AssetID = a.AssetID)    --Bug35264: Force execution plan with MERGE hint
                WHERE 1 = 1
                  AND a.AssetID = ISNULL(@pAssetID, a.AssetID)
                  AND a.FeedID  = ISNULL(@pFeedID,  a.FeedID)
                  AND ast.StatusID = ISNULL(@pAssetStatusID,  ast.StatusID)
                  AND (LOWER(@pTargetLayer) IS NULL 
                       OR ISNULL(me.LoadTargetTable,    'nulo') = CASE WHEN LOWER(@pTargetLayer) = 'load'           THEN me.LoadTargetTable   ELSE 'nuli' END 
                       OR ISNULL(me.PSATargetTable,     'nulo') = CASE WHEN LOWER(@pTargetLayer) = 'psa'            THEN me.PSATargetTable    ELSE 'nuli' END 
                       OR ISNULL(me.RefLOVTargetTable,  'nulo') = CASE WHEN LOWER(@pTargetLayer) = 'masterrefdata'  THEN me.RefLOVTargetTable ELSE 'nuli' END 
                      )
                  AND (    @pLatestAssetFlag = '0' 
                       OR (@pLatestAssetFlag = '1' AND a.AssetLatestRank = 1))
                ORDER BY a.FeedID, a.AssetID
                FOR JSON PATH, ROOT ('AssetList'), INCLUDE_NULL_VALUES)
            ;

            --Bug35264: ETLRunLog section is now a string, so FOR JSON adds escape character and header/trailing "'", remove them
            SET @vAssetListJSON = REPLACE(REPLACE(REPLACE(@vAssetListJSON, '\"', '"'), '"ETLRunLog":"', '"ETLRunLog":'), '","LoadTargetSchema"', ',"LoadTargetSchema"');

            /*Return*/
            SELECT @vAssetListJSON AS AssetListJSON, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

        COMMIT TRAN;
    END TRY

    BEGIN CATCH
        ROLLBACK TRAN @tTransaction;
        SELECT @vAssetListJSON AS AssetListJSON
             , '-1' AS ProcedureStatus
             , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                      ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                      ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                      ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                      ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                      ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                     ) AS ProcedureMessage
        ;
    END CATCH;
END;
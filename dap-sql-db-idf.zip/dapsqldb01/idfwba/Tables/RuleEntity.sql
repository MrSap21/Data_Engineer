﻿CREATE TABLE [idfwba].[RuleEntity] (
    [RuleEntityID] INT            IDENTITY (1, 1) NOT NULL,
    [RuleID]       INT            NOT NULL,
    [EntityID]     INT            NOT NULL,
    [AttributeID]  INT            NULL,
    [ActiveFlag]   SMALLINT       NOT NULL,
    [DTCreated]    SMALLDATETIME  NULL,
    [UserCreated]  NVARCHAR (128) NULL,
    CONSTRAINT [PK_RuleEntity] PRIMARY KEY CLUSTERED ([RuleEntityID] ASC)
);


﻿CREATE TABLE [idfwba].[Feed] (
    [FeedID]                      INT             IDENTITY (1, 1) NOT NULL,
    [FeedName]                    NVARCHAR (255)  NOT NULL,
    [SupplierID]                  INT             NOT NULL,
    [SourceSystemID]              INT             NOT NULL,
    [SourceSubsystemID]           INT             NOT NULL,
    [SourceRangeID]               INT             NOT NULL,
    [FeedNamePattern]             NVARCHAR (255)  NOT NULL,
    [AssetJSON]                   NVARCHAR (MAX)  NULL,
    [AssetTypeID]                 INT             NOT NULL,
    [FeedFrequencyID]             INT             NOT NULL,
    [InformationClassificationID] INT             NOT NULL,
    [ProjectID]                   INT             NOT NULL,
    [PlatformVersionID]           INT             NOT NULL,
    [CountryID]                   INT             NOT NULL,
    [LanguageID]                  INT             NOT NULL,
    [PromotedFromID]              INT             NULL,
    [EntityDescription]           NVARCHAR (255)  NULL,
    [AuthorisationLink]           NVARCHAR (2048) NULL,
    [RestrictionsForUse]          NVARCHAR (255)  NULL,
    [UserCreated]                 NVARCHAR (128)  NULL,
    [DTCreated]                   SMALLDATETIME   NULL,
    [SourcePathName]              NVARCHAR (2048) NULL,
    [DestinationPathName]         NVARCHAR (2048) NULL,
    [DQCheck]                     BIT             NULL,
    [Delimiter]                   NVARCHAR (50)   NULL,
    [DataProperties]              NVARCHAR (MAX)  NULL,
    [HeaderInfo]                  BIT             NULL,
    CONSTRAINT [PK_FEED] PRIMARY KEY CLUSTERED ([FeedID] ASC),
    CONSTRAINT [UniqueFeedName] UNIQUE NONCLUSTERED ([FeedName] ASC)
);


GO
CREATE TRIGGER [idfwba].[FeedTasks]
   ON  [idfwba].[Feed]
   AFTER INSERT
AS 
--BEGIN

--insert into [idfwba].[FeedTask] 
--(FeedID,JobID, TaskID,[FeedTaskJSON],ExecutionOrder,DTCreated,UserCreated)
--values 
--((select max(FeedID) from [idfwba].[Feed]), '1', '1',(select '{
--   "id":"https://walgreens-dna.com/schemas/Move_File_From_Landing_To_ADLS2.schema.json",
--   "title":"Move File between Azure Storage Configuration",
--   "type":"task",
--   "properties":{
--      "source_environment":"landing",
--      "FolderPath_SourceStore":"/$$Landing.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "FolderPath_DestinationStore":"/$$Rawhopper.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "FolderPath_QuarantineStore":"/$$Quarantine.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "FolderPath_ArchiveStore":"/$$Archive.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "SourceStorageAccountServiceEndPoint":"$$Landing.StorageAccount$$",
--      "TargetStorageAccountServiceEndPoint":"$$Rawhopper.StorageAccount$$",
--      "QuarantineStorageAccountServiceEndPoint":"$$Quarantine.StorageAccount$$",
--      "ArchiveStorageAccountServiceEndPoint":"$$Archive.StorageAccount$$",
--      "SourceStorageAccountType":"$$Landing.StorageAccountType$$",
--      "TargetStorageAccountType":"$$Rawhopper.StorageAccountType$$",
--      "QuarantineStorageAccountType":"$$Quarantine.StorageAccountType$$",
--      "ArchiveStorageAccountType":"$$Archive.StorageAccountType$$"
--   }
--}'), '1', getdate(), 'UIF')
--,
--((select max(FeedID) from [idfwba].[Feed]), '1', '2',(select '{
--   "id":"https://walgreens-dna.com/schemas/Move_File_From_ADLS2_To_ADLS2.schema.json",
--   "title":"Move File between Azure Storage Configuration",
--   "type":"task",
--   "properties":{
--      "source_environment":"raw",
--      "FolderPath_SourceStore":"/$$Raw.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "FolderPath_DestinationStore":"/$$Cleansed.Container$$/' + (select idfwba.UpdatePathNameToDate(DestinationPathName) from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "FolderPath_QuarantineStore":"/$$Quarantine.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--      "SourceStorageAccountServiceEndPoint":"$$Raw.StorageAccount$$",
--      "TargetStorageAccountServiceEndPoint":"$$Cleansed.StorageAccount$$",
--      "QuarantineStorageAccountServiceEndPoint":"$$Quarantine.StorageAccount$$",
--      "SourceStorageAccountType":"$$Raw.StorageAccountType$$",
--      "TargetStorageAccountType":"$$Cleansed.StorageAccountType$$",
--      "QuarantineStorageAccountType":"$$Quarantine.StorageAccountType$$"
--   }
--}
--'), '3', getdate(), 'UIF')
--,
--(
--(select max(FeedID) from [idfwba].[Feed]), '1', '3',(select '{
--  "id": "https://walgreens-dna.com/schemas/Unpack_File.schema.json",
--  "title": "Unpack File to RAW",
--  "type": "task",
--  "properties": {
--    "source_environment": "rawhopper",
--    "FolderPath_SourceStore": "/$$Rawhopper.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--    "FolderPath_DestinationStore": "/$$Raw.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select max(FeedId)from idfwba.Feed)) +'/",
--    "SourceStorageAccountServiceEndPoint": "$$Rawhopper.StorageAccount$$",
--    "TargetStorageAccountServiceEndPoint": "$$Raw.StorageAccount$$",
--    "SourceStorageAccountType": "$$Rawhopper.StorageAccountType$$",
--    "TargetStorageAccountType": "$$Raw.StorageAccountType$$",
--    "KeyvaultUrl": "$$KEYVAULT_URL$$",
--    "FeedPrivateKeySecretName": "",
--    "FeedPassphraseSecretName": ""
--  }
--}'), '2', getdate(), 'UIF'
--)




--END
begin
insert into [idfwba].[FeedStatus]
(FeedID, StatusID, DTEffectiveFrom, DTEffectiveTo, DTCreated, UserCreated)
(select (select max(FeedId) from [idfwba].[Feed]),'23001', getdate(), null, getdate(), 'UIF')
end
﻿CREATE TABLE [idfwba].[RuleEntityInstance] (
    [RuleEntityInstanceID] INT            IDENTITY (1, 1) NOT NULL,
    [RuleID]               INT            NOT NULL,
    [EntityID]             INT            NOT NULL,
    [AttributeID]          INT            NULL,
    [RuleDetail]           NVARCHAR (MAX) NULL,
    [ETLRunLogID]          INT            NULL,
    [SourceEntityID]       INT            NOT NULL,
    [SourceAttributeID]    NVARCHAR (128) NOT NULL,
    [RowNumber]            INT            NULL,
    [DTCreated]            SMALLDATETIME  NULL,
    [UserCreated]          NVARCHAR (128) NULL,
    CONSTRAINT [PK_RuleEntityInstance] PRIMARY KEY CLUSTERED ([RuleEntityInstanceID] ASC)
);


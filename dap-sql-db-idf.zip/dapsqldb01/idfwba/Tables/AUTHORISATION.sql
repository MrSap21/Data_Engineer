﻿CREATE TABLE [idfwba].[AUTHORISATION] (
    [AuthID]               SMALLINT      IDENTITY (1, 1) NOT NULL,
    [AuthIdentity]         VARCHAR (255) NULL,
    [AuthFunction]         VARCHAR (255) NULL,
    [AuthAuthority]        VARCHAR (255) NULL,
    [AuthControl]          VARCHAR (255) NULL,
    [AuthTransparency]     VARCHAR (255) NULL,
    [AuthInformationClass] VARCHAR (255) NULL,
    CONSTRAINT [PK_AUTHORIZATION] PRIMARY KEY CLUSTERED ([AuthID] ASC)
);


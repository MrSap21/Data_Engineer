﻿CREATE TABLE [idfwba].[DQ_CDE_Histogram] (
    [Data_Quality_Check_Files] NVARCHAR (38)   NOT NULL,
    [x_axis]                   DECIMAL (38, 2) NOT NULL,
    [y_axiz]                   DECIMAL (38, 1) NOT NULL
);


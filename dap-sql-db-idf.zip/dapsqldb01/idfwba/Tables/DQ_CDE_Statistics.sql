﻿CREATE TABLE [idfwba].[DQ_CDE_Statistics] (
    [Data_Quality_Check_Files]   NVARCHAR (38)    NOT NULL,
    [Minimum]                    INT              NOT NULL,
    [5th_Percentile]             DECIMAL (38, 10) NOT NULL,
    [Q1]                         DECIMAL (38, 2)  NOT NULL,
    [Median]                     INT              NOT NULL,
    [Q3]                         DECIMAL (38, 2)  NOT NULL,
    [95th_Percentile]            DECIMAL (38, 10) NOT NULL,
    [Maximum]                    INT              NOT NULL,
    [Range]                      INT              NOT NULL,
    [Interquartile_range]        DECIMAL (38, 2)  NOT NULL,
    [Sandard_Deviation]          DECIMAL (38, 2)  NOT NULL,
    [Coefficient_of_Variation]   DECIMAL (38, 16) NOT NULL,
    [Kurtosis]                   DECIMAL (38, 16) NOT NULL,
    [Mean]                       DECIMAL (38, 10) NOT NULL,
    [Meadian Absolute Deviation] DECIMAL (38, 10) NOT NULL,
    [Skewness]                   DECIMAL (38, 16) NOT NULL,
    [Sum]                        INT              NOT NULL,
    [Variance]                   DECIMAL (38, 5)  NOT NULL,
    [Monototocity]               NVARCHAR (38)    NOT NULL
);


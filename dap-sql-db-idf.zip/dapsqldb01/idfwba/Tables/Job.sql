﻿CREATE TABLE [idfwba].[Job] (
    [JobID]          SMALLINT       IDENTITY (1, 1) NOT NULL,
    [JobDescription] NVARCHAR (255) NULL,
    [ActiveFlag]     SMALLINT       NOT NULL,
    [DTCreated]      SMALLDATETIME  NULL,
    [UserCreated]    NVARCHAR (128) NULL,
    CONSTRAINT [PK_JOB] PRIMARY KEY CLUSTERED ([JobID] ASC)
);


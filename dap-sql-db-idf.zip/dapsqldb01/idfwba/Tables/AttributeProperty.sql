﻿CREATE TABLE [idfwba].[AttributeProperty] (
    [AttributeID]   INT            NOT NULL,
    [PropertyID]    INT            NOT NULL,
    [PropertyValue] NVARCHAR (128) NULL,
    [PropertyLOVID] INT            NULL,
    [Sequence]      SMALLINT       NULL,
    [ActiveFlag]    SMALLINT       NOT NULL,
    [DTCreated]     SMALLDATETIME  NULL,
    [UserCreated]   NVARCHAR (128) NULL,
    CONSTRAINT [PK_AttributeProperty] PRIMARY KEY CLUSTERED ([AttributeID] ASC, [PropertyID] ASC)
);


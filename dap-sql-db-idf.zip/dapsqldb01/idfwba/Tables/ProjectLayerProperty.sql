﻿CREATE TABLE [idfwba].[ProjectLayerProperty] (
    [ProjectID]     INT            NOT NULL,
    [LayerID]       INT            NOT NULL,
    [PropertyID]    INT            NOT NULL,
    [PropertyValue] NVARCHAR (128) NULL,
    [PropertyLOVID] INT            NULL,
    [Sequence]      SMALLINT       NULL,
    [ActiveFlag]    SMALLINT       NOT NULL,
    [DTCreated]     SMALLDATETIME  NULL,
    [UserCreated]   NVARCHAR (128) NULL,
    CONSTRAINT [PK_ProjectLayerProperty] PRIMARY KEY CLUSTERED ([ProjectID] ASC, [LayerID] ASC, [PropertyID] ASC)
);


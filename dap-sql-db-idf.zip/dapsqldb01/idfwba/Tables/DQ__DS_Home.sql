﻿CREATE TABLE [idfwba].[DQ__DS_Home] (
    [Data_Quality_Check_Files] NVARCHAR (100) NOT NULL,
    [Missing_Values]           DECIMAL (5, 2) NOT NULL,
    [Total_Attributes]         INT            NOT NULL,
    [Critical_Data_Elements]   INT            NOT NULL
);


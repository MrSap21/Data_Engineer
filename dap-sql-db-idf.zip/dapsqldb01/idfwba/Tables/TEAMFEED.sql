﻿CREATE TABLE [idfwba].[TEAMFEED] (
    [TeamID]         INT           NOT NULL,
    [FeedID]         INT           NOT NULL,
    [ApplicableFlag] SMALLINT      NOT NULL,
    [ApprovedFlag]   SMALLINT      NOT NULL,
    [DTApproved]     SMALLDATETIME NULL,
    CONSTRAINT [PK_TEAMFEED] PRIMARY KEY CLUSTERED ([TeamID] ASC, [FeedID] ASC)
);


﻿CREATE TABLE [idfwba].[ETLRunLog] (
    [ETLRunLogID]       INT            IDENTITY (1, 1) NOT NULL,
    [ETLProcessName]    NVARCHAR (255) NOT NULL,
    [ETLProcessRunID]   NVARCHAR (255) NOT NULL,
    [ETLRunLogStatusID] INT            NOT NULL,
    [DTStart]           DATETIME2 (7)  NULL,
    [DTEnd]             DATETIME2 (7)  NULL,
    [DTCreated]         SMALLDATETIME  NULL,
    [UserCreated]       NVARCHAR (128) NULL,
    CONSTRAINT [PK_ETLRunLog] PRIMARY KEY CLUSTERED ([ETLRunLogID] ASC)
);


﻿CREATE TABLE [idfwba].[MappingEntity] (
    [MappingID]         INT            NOT NULL,
    [SourceEntityID]    INT            NOT NULL,
    [TargetEntityID]    INT            NOT NULL,
    [MappingSequence]   SMALLINT       NULL,
    [MappingEntityJSON] NVARCHAR (MAX) NULL,
    [DTCreated]         SMALLDATETIME  NULL,
    [UserCreated]       NVARCHAR (128) NULL,
    CONSTRAINT [PK_MappingID] PRIMARY KEY CLUSTERED ([MappingID] ASC, [SourceEntityID] ASC, [TargetEntityID] ASC)
);


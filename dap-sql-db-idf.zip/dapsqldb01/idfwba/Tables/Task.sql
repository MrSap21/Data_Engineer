﻿CREATE TABLE [idfwba].[Task] (
    [TaskID]           SMALLINT       IDENTITY (1, 1) NOT NULL,
    [TaskDescription]  NVARCHAR (255) NULL,
    [TaskComponent]    NVARCHAR (255) NULL,
    [TaskJSONTemplate] NVARCHAR (MAX) NULL,
    [ExecutionOrder]   SMALLINT       NULL,
    [ActiveFlag]       SMALLINT       NOT NULL,
    [DTCreated]        SMALLDATETIME  NULL,
    [UserCreated]      NVARCHAR (128) NULL,
    CONSTRAINT [PK_TASK] PRIMARY KEY CLUSTERED ([TaskID] ASC)
);


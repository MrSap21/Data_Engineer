﻿CREATE TABLE [idfwba].[FeedTask] (
    [FeedID]         INT            NULL,
    [JobID]          SMALLINT       NOT NULL,
    [TaskID]         SMALLINT       NOT NULL,
    [FeedTaskJSON]   VARCHAR (2000) NULL,
    [ExecutionOrder] SMALLINT       NOT NULL,
    [DTCreated]      SMALLDATETIME  NULL,
    [UserCreated]    NVARCHAR (128) NULL,

);


﻿CREATE TABLE [idfwba].[RefLOVSet] (
    [LOVSetID]          INT             NOT NULL,
    [LOVSetName]        NVARCHAR (128)  NOT NULL,
    [LOVSetDescription] NVARCHAR (1024) NULL,
    [ActiveFlag]        SMALLINT        NOT NULL,
    [DTCreated]         SMALLDATETIME   NULL,
    [UserCreated]       NVARCHAR (128)  NULL,
    CONSTRAINT [PK_RefLOVSet] PRIMARY KEY CLUSTERED ([LOVSetID] ASC)
);


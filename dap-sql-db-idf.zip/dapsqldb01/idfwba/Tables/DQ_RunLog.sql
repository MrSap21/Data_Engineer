﻿CREATE TABLE [idfwba].[DQ_RunLog] (
    [_id] BIGINT         IDENTITY (1, 1) NOT NULL,
    [log] NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([_id] ASC)
);


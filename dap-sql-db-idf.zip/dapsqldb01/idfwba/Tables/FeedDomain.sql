﻿CREATE TABLE [idfwba].[FeedDomain] (
    [FeedID]      INT            NOT NULL,
    [DomainID]    INT            NOT NULL,
    [ActiveFlag]  SMALLINT       NOT NULL,
    [DTCreated]   SMALLDATETIME  NULL,
    [UserCreated] NVARCHAR (128) NULL,
    CONSTRAINT [PK_FeedDomain] PRIMARY KEY CLUSTERED ([FeedID] ASC, [DomainID] ASC)
);


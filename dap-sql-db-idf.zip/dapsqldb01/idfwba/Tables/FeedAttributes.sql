﻿CREATE TABLE [idfwba].[FeedAttributes] (
    [FeedId]             INT             NOT NULL,
    [ColumnName]         NVARCHAR (128)  NULL,
    [ColumnType]         NVARCHAR (128)  NULL,
    [IsKey]              NVARCHAR (20)   NULL,
    [Dataclassification] NVARCHAR (128)  NULL,
    [AliasName]          NVARCHAR (128)  NULL,
    [BusinessGlossary]   NVARCHAR (2000) NULL,
    [Description]        NVARCHAR (2000) NULL,
    [DefaultValue]       NVARCHAR (2000) NULL,
    CONSTRAINT [PK_FeedId] PRIMARY KEY CLUSTERED ([FeedId] ASC)
);


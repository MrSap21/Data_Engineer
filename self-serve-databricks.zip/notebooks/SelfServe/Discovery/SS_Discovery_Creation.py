# Databricks notebook source
dbutils.widgets.text('ContainerName','')
container_name=dbutils.widgets.get('ContainerName')


dbutils.widgets.text('StorageAccountName','')
storage_account_name=dbutils.widgets.get('StorageAccountName')

dbutils.widgets.text('TargetStorageAccountName','')
target_storage_account_name=dbutils.widgets.get('TargetStorageAccountName')


#To define widgets for ADF Parameter
dbutils.widgets.text('RawLocation','')
file_path=dbutils.widgets.get('RawLocation')

#To define widgets for ADF Parameters
dbutils.widgets.text('PipelineRunId','')
pipeline_runid=dbutils.widgets.get('PipelineRunId')


# COMMAND ----------

#Establish the connection to ADLS 
source = "abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net///"
folder_name=file_path.split('/')[3]

# COMMAND ----------

# MAGIC %md
# MAGIC Run the Audit Logging Notebook

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Audit_Logging

# COMMAND ----------

# MAGIC %md
# MAGIC Run the Table Summary Notebook

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Table_Summary

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import StructType

#Listing the All files from Landing Area
all_file_details=dbutils.fs.ls(source+file_path)

list_file=[]
for list_file in all_file_details:
  file_ext=list_file.name.split('.')[1]
  file_name=list_file.name

  
  #Ingesting the Metadata from Json Files 
    
  json_df=spark.read.format('json').option("header","true").option("multiLine","true").load(source+file_path+'/'+folder_name+'.json')
  
  
    
  if file_ext=='csv':
 

      file_type=json_df.collect()[0]['FileType']
      delimter=json_df.collect()[0]['Delimiter']
      discovery_area=json_df.collect()[0]['DiscoveryArea']
      file_size=json_df.collect()[0]['FileSize']
      team_name=json_df.collect()[0]['TeamName']
      timestamp=list_file.name.split('_')[-1].split('.')[0]
      rm_spch_folder=list_file.name.split('_')[1:-1]
      file_name="_".join(rm_spch_folder)
      folder_name=list_file.name.split('.')[0]
      user_id=list_file.name.split('_')[0]
      final_time=timestamp.replace('-','')
      table_name=user_id+'_'+file_name+'_'+final_time
      column_information_df=json_df.select(to_json(col('fleData')).alias('column_information'))
      column_information=column_information_df.collect()[0][0]
      task='Upload'
      tab_file_path=folder_name+'/'+folder_name+'.csv'

  #Extracting the file one by one from Wrangle location
      file_ext_df=spark.read.format("csv").option("sep","\u0001").option("header","true").option('inferSchema',True).load(source+file_path+'/'+list_file.name)

 
  
  #Count Number records in the Each Files
  
      file_records_df=file_ext_df.count()
      discoverarea= "abfss://"+team_name+"@"+target_storage_account_name+".dfs.core.windows.net//"
      target_folder=discoverarea+'/'+user_id+'_'+file_name+'_'+timestamp+'/'
      
 
  
  #Define the Target ADLS Folder path based on the Authorized schemas
      if discovery_area=='DataBricks':
    
        delta_lake_schema=json_df.collect()[0]['DeltaLakeSchema']#1

  #ingest the data into Delta Lake Storage location 
        file_ext_df.write.format("delta").mode('overwrite').option('mergeSchema',True).save(target_folder)
 
  
  #Create the external tables
        #spark.sql("create table if not exists "+delta_lake_schema+'.'+table_name+" using delta location '"+target_folder+"'")
        status='Delta Lake Table has created'
        stage='Discovery'
        table_status='Success'
  
  #insert the audit logs Notebook after delta table has created
        ss_audit_logging(pipeline_runid,file_name,user_id,target_folder,table_name,stage,status,file_records_df)
        
        ss_table_summary(user_id,file_name,task,timestamp,delta_lake_schema,table_name,tab_file_path,file_size,discovery_area,column_information,table_status,file_records_df)
      

  #Filter the only Snowflake tables
      else:
        
        snowflake_schema=json_df.collect()[0]['SnowFlakeSchema']#6
        dbutils.notebook.run('/SelfServe/Common-Setup/SS_Snowflake_Connection',0,{'TargetPath':source+file_path+'/'+list_file.name,'TargetTableName':table_name,'snowflake_schema':snowflake_schema})
        stage='Discovery'
        sf_status='Snowflake Table has created'
        table_status='Success'
        
        #Insert the Snowflake succes into Audit Log Table
        ss_audit_logging(pipeline_runid,file_name,user_id,source+file_path+'/'+list_file.name,table_name,stage,sf_status,file_records_df)
        ss_table_summary(user_id,file_name,task,timestamp,snowflake_schema,table_name,tab_file_path,file_size,discovery_area,column_information,table_status,file_records_df) 

# Databricks notebook source
dbutils.widgets.text('RawLocation','')
raw_file_path=dbutils.widgets.get('RawLocation')
dbutils.widgets.text('PipelineRunId','')
pipeline_runid=dbutils.widgets.get('PipelineRunId')
dbutils.widgets.text('StorageAccountName','')
storage_account_name=dbutils.widgets.get('StorageAccountName')
dbutils.widgets.text('ContainerName','')
container_name=dbutils.widgets.get('ContainerName')
dbutils.widgets.text('VoltageAPIurl','')
voltage_api_url=dbutils.widgets.get('VoltageAPIurl')

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Audit_Logging

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Table_Summary

# COMMAND ----------

from pyspark.sql.functions import *

source_files="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+raw_file_path+'/'

#Identified the source file Location
folder_name=source_files.split('/')[7]
output_container_name=container_name
output_storage_account_name=storage_account_name

all_file_details=dbutils.fs.ls(source_files)
list_file=[]
file_name=''
json_file=''
for list_file in all_file_details:
  file_name=list_file.name
  if(file_name.endswith('.json')):
    #Create the filename
    file_name=file_name.split('.')[0]

  
    #Identified the output file Location
    output_file_path="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+'/'
  
    #Identified the temp file Location
    voltage_file="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/voltage_"+folder_name+'/'
  
    #identified the file location
    file_ext=list_file.name.split('.')[1]
  
    input_folder='Wrangle/Decryption/Input/'+folder_name+'/Temp'
    output_folder='Wrangle/Decryption/Output/'+folder_name+'/Temp'
  
    # read meta Data Json which genrated by UI
    json_df=spark.read.format('json').option("header","true").option("multiLine","true").load(source_files+'/'+'*.json')
  
    #Create the variable for delimiter, file size, discovery area and column information   
    delimiter=json_df.collect()[0]['Delimiter']
    deltalake_schema_name=json_df.collect()[0]['DeltaLakeSchema']
    discovery_area=json_df.collect()[0]['DiscoveryArea']
    file_size=json_df.collect()[0]['FileSize']
    snowflake_schema_name=json_df.collect()[0]['SnowFlakeSchema']
    target_table_name=json_df.collect()[0]['TableName']
    user_id=json_df.collect()[0]['UserName']
    column_information_df=json_df.select(to_json(col('fleData')).alias('column_information'))
    columns_information=column_information_df.collect()[0][0]
  
    #check which schema name is not empty to set schema_name
    if(snowflake_schema_name!=''):
      schema_name=snowflake_schema_name
    elif(deltalake_schema_name!=''):
      schema_name=deltalake_schema_name
  
  
    # Select only Decryption Column information
    dff=json_df.select(col('fleData').alias('all_de'))
  
    #Split the columns from Json Elements 
    exp_df=dff.select(col('all_de.dataTypes'),col('all_de.inputFile').alias('inp_file'),\
    col('all_de.inputFolder').alias('inp_folder'),col('all_de.outputFile').alias('oup_file'),\
    col('all_de.outputFolder').alias('oup_folder'))
  
    #drop the unwanted columns 
    ss=exp_df.drop('inp_file','inp_folder','oup_file','oup_folder')
         
    #Adding the Inputfolder , Inputfile , outputfolder , outputfile and Delimiter information
    ss=ss.withColumn('inputFile',lit('')).\
    withColumn('inputFolder',lit(input_folder)).\
    withColumn('outputFile',lit('')).\
    withColumn('outputFolder',lit(output_folder)).\
    withColumn('outputStorageAccount',lit(output_storage_account_name)).\
    withColumn('outputContainer',lit(output_container_name)).\
    withColumn('columnDelimiter',lit('\u0001')).\
    withColumn('storageAccount',lit(storage_account_name)).\
    withColumn('container',lit(container_name))
    
    #Save the Voltage Json file to Temp location 
    ss.write.mode('overwrite').format('json').save(voltage_file)
    
    qfileslist=dbutils.fs.ls(voltage_file)
    #Moving the Temp file to Final location 
    for fd in qfileslist:
      fn=fd.name    
      if fn.startswith("part-"):
         
        dbutils.fs.cp(voltage_file+fn,output_file_path+'voltage_'+file_name+'.json')
        
     #Removing the temp  folder
        dbutils.fs.rm(voltage_file,True)
        
      
      #Move the Json metadata file to wrangle folder  
      dbutils.fs.cp(source_files+'/'+file_name+'.json',output_file_path+'/'+file_name+'.json')
    break    

# COMMAND ----------

#Reading the voltage json file from adls into a dataframe
import json


voltage_json_df=spark.read.format('json').option("multiline",True).load(output_file_path+'voltage_'+file_name+'.json')
voltage_json_df=voltage_json_df.select("storageAccount","container","inputFolder","inputFile","outputFolder","outputFile","outputStorageAccount","outputContainer","columnDelimiter","dataTypes")

#Storing enitire json data into a string variable

cols=voltage_json_df.columns
df2=voltage_json_df.select(to_json(struct(cols)).alias('VoltageData'))
voltage_json_str=df2.collect()[0][0]

#converting string to dict

voltage_json_dict=json.loads(voltage_json_str)

# COMMAND ----------

#setting final_time_stamp as string in desired format
from datetime import datetime

time_stamp=datetime.now()
month=time_stamp.month
day=time_stamp.day
hour=time_stamp.hour
minute=time_stamp.minute
undecrypted_file_path="abfss://"+output_container_name+"@"+output_storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+"/"+file_name+".csv"
tab_file_path=folder_name+"/"+file_name+".csv.gz"

if(month<10):  
  month='0'+str(month)
else:
  month=str(month)
  
if(day<10):  
  day='0'+str(day)
else:
  day=str(day)
  
if(hour<10):
  hour='0'+str(hour)
else:
  hour=str(hour)
  
if(minute<10):
  minute='0'+str(minute)
else:
  minute=str(minute)
final_time_stamp=str(time_stamp.year)+'-'+month+'-'+day+'-'+hour+minute

# COMMAND ----------

#checking if Decryption is needed to be done

if len(voltage_json_dict['dataTypes'])== 0 :
  input_data_file_path="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Input/"+folder_name+"/"
  output_data_file_path="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+"/"
  
  #copying the csv data file to the output location
  undecryptedfileslist=dbutils.fs.ls(input_data_file_path)
  for undecryptedfiles in undecryptedfileslist:
    ufn=undecryptedfiles.name
    if ufn.endswith(".csv"):
      undec_csv_df=spark.read.format("csv").option("delimiter","\u0001").option("header","True").option("inferSchema","True").load(input_data_file_path+ufn)
      undec_csv_df.coalesce(1).write.mode("overwrite").format("csv").option("header",True).option("delimiter",",").option("escapeQuotes",False).option("quote","").option("escape","").option("compression","gzip").save(output_data_file_path+"TEMP")
      undectempfileslist=dbutils.fs.ls(output_data_file_path+"TEMP")
      for undecfile in undectempfileslist:
            undecfn=undecfile.name    
            if undecfn.endswith(".csv.gz"):
              ufn=ufn.split('.')[0]
              dbutils.fs.cp(output_data_file_path+"TEMP/"+undecfn,output_data_file_path+ufn+'.csv.gz')
              dbutils.fs.rm(output_data_file_path+"TEMP",True)

  #audit logging and table summary for skipping decryption
  ss_audit_logging(pipeline_runid,file_name,user_id,output_data_file_path+file_name+'.csv',target_table_name,'Decryption','Decryption not needed. No sensitive columns selected.',0)
  ss_table_summary(user_id,file_name,'Download',final_time_stamp,schema_name,target_table_name,tab_file_path,file_size,discovery_area,columns_information,'Success',0)
  #skipping voltage api call as no columns are to be decrypted
  dbutils.notebook.exit(0)

# COMMAND ----------

#calling the file splitting notebook

dbutils.notebook.run("/SelfServe/Wrangle/SS_Split_File_Common",0,{"cleaned_file_path":source_files})

#making Temp directory for decryption

dbutils.fs.mkdirs(output_file_path+"/Temp")

# COMMAND ----------

#voltage api call

import requests

def api_call(inputFile, outputFile):
  voltage_json_dict['inputFile']=inputFile
  voltage_json_dict['outputFile']=outputFile
  voltage_response = requests.post(voltage_api_url,json=voltage_json_dict)
  voltage_response_text=voltage_response.text
  voltage_response_status_code=voltage_response.status_code
  return voltage_response_text,voltage_response_status_code

# COMMAND ----------

#Logging the detials based on the status_code of the api call

def api_call_audit_log(file_name,path):
  if (voltage_response_status_code == 200) or (voltage_response_status_code == 201) :
    ss_audit_logging(pipeline_runid,file_name,user_id,path,target_table_name,'Decryption','PDE api call success. Status_code : '+str(voltage_response_status_code)+', Text : '+voltage_response_text,0)
  else:
    ss_audit_logging(pipeline_runid,file_name,user_id,path,target_table_name,'Decryption','PDE api call failed. Status_code: '+str(voltage_response_status_code)+', Text: '+voltage_response_text,0) 
    raise Exception("PDE api call failed")

# COMMAND ----------

#check to see if csv file is placed in the adls output location
import time

def check_file(file_name):
  decryption_output_folder="abfss://"+output_container_name+"@"+output_storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+'/Temp/'
  timeout=time.time()+60*60
  while True:
    breakwhile=''
    fileslist1=dbutils.fs.ls(decryption_output_folder)
    for a in fileslist1:
      if a.name==file_name+'_fle_status.json':
        breakwhile='Yes'
        break
    if breakwhile=='Yes':
      break
    if time.time()>timeout:
      ss_audit_logging(pipeline_runid,file_name,user_id,decryption_output_folder,'','Decryption','Run exceeded max timeout. No fle_status json file recieved from PDE',0) 
      raise Exception("Run exceeded max timeout. No fle_status json file recieved from PDE")

# COMMAND ----------

#reading the fle_status json file

def fle_status_audit_log(file_name):
  fle_status_json_df=spark.read.format('json').option("header","true").option("multiLine","true").load("abfss://"+output_container_name+"@"+output_storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+"/Temp/"+file_name+"_fle_status.json")
  fle_status_error=fle_status_json_df.collect()[0][0]
  fle_status_status=fle_status_json_df.collect()[0][2]
  if (fle_status_status=="200") or (fle_status_status=="201"):
    decrypted_file_path="abfss://"+output_container_name+"@"+output_storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+"/Temp/"+file_name+".csv"
    ss_audit_logging(pipeline_runid,file_name,user_id,decrypted_file_path,target_table_name,'Decryption','Decryption Success. fle_status_code : '+fle_status_status,0)
  else:
    ss_audit_logging(pipeline_runid,file_name,user_id,'',target_table_name,'Decryption','Decryption Failed. fle_status_code: '+fle_status_status+', fle_error : '+fle_status_error,0) 
    raise Exception("FLE Decryption Failed")

# COMMAND ----------

#calling the voltage api
temp_file_details=dbutils.fs.ls(source_files+"Temp/")
for list_file in temp_file_details:
  file_name=list_file.name
  if file_name.endswith('.csv'):
    inputFile=file_name
    outputFile=file_name
    ss_audit_logging(pipeline_runid,file_name.split('.')[0],user_id,source_files+"Temp/"+inputFile,target_table_name,'Decryption','Calling Voltage API',0)
    voltage_response_text,voltage_response_status_code=api_call(inputFile, outputFile)
    api_call_audit_log(file_name,source_files+"Temp/"+inputFile.split('.')[0])
    check_file(file_name.split('.')[0])
    fle_status_audit_log(file_name.split('.')[0])

# COMMAND ----------

#merging the decrypted csv files in a temp location

decrypted_folder_path="abfss://"+output_container_name+"@"+output_storage_account_name+".dfs.core.windows.net//Wrangle/Decryption/Output/"+folder_name+"/"
csv_df=spark.read.format("csv").option("delimiter","\u0001").option("header","True").option("inferSchema","True").load(decrypted_folder_path+"Temp/"+"*.csv")
csv_df.coalesce(1).write.mode("overwrite").format("csv").option("header",True).option("delimiter",",").option("escapeQuotes",False).option("quote","").option("escape","").option("compression","gzip").save(decrypted_folder_path+"Temp/"+"TEMP")

#renaming the csv file and moving it outside of temp location
file_name=""
decryptedfileslist=dbutils.fs.ls(decrypted_folder_path)
for file in decryptedfileslist:
  filenameextn=file.name
  if filenameextn.endswith(".json"):
    file_name=filenameextn.split('.')[0]
    file_name=file_name.replace("voltage_","")
tempfileslist=dbutils.fs.ls(decrypted_folder_path+"Temp/TEMP")
for file in tempfileslist:
      fn=file.name    
      if fn.endswith(".csv.gz"):
        dbutils.fs.cp(decrypted_folder_path+"Temp/TEMP/"+fn,decrypted_folder_path+file_name+".csv.gz")
#Removing the temp folder
dbutils.fs.rm(decrypted_folder_path+"Temp",True)
dbutils.fs.rm(source_files+"Temp",True)
ss_audit_logging(pipeline_runid,file_name,user_id,decrypted_folder_path+file_name+'.csv.gz',target_table_name,'Decryption','Decryption Completed.',0)
ss_table_summary(user_id,file_name,'Download',final_time_stamp,schema_name,target_table_name,tab_file_path,file_size,discovery_area,columns_information,'Success',0)

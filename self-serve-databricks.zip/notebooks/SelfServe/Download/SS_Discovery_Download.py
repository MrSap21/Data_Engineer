# Databricks notebook source
dbutils.widgets.text('ContainerName','')
container_name=dbutils.widgets.get('ContainerName')


dbutils.widgets.text('StorageAccountName','')
storage_account_name=dbutils.widgets.get('StorageAccountName')

dbutils.widgets.text('SourcePath','')
source_path=dbutils.widgets.get('SourcePath')

dbutils.widgets.text('PipelineRunId','')
pipeline_runid=dbutils.widgets.get('PipelineRunId')


# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Audit_Logging

# COMMAND ----------

#Establish the connection to ADLS 
source = "abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+source_path


# COMMAND ----------

# Read the SnowFlake connection from Key Valut
dapsfurl=dbutils.secrets.get(scope = "selfservedma", key = "url")
dapsfusername=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonusername")
dapsfpassword=dbutils.secrets.get(scope= "dapadbscope", key= "dap-ss-team-dna-data-management-build-pwd-secret")
dapsfwarehouse=dbutils.secrets.get(scope= "selfservedma", key= "sfwarehouse")
dapsfRole=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonrole")
dapsfdatabase=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonreaddatabase")
dapsfdisdatabase=dbutils.secrets.get(scope= "selfservedma", key= "sfdiscoverydatabase")

# COMMAND ----------

#Extract the metadata from Json File 
foldername=source_path.split('/')[3]
json_df=spark.read.format('json').option("header","true").option("multiLine","true").load(source+'/'+'*.json')
discoveryarea=json_df.collect()[0]['DiscoveryArea']
snowflakeschemaname=json_df.collect()[0]['SnowFlakeSchema']
DeltaLakeSchema=json_df.collect()[0]['DeltaLakeSchema']
tablename=json_df.collect()[0]['TableName']
userid=json_df.collect()[0]['UserName']
EmailId=json_df.collect()[0]['EmailId']
#workspace_name=json_df.collect()[0]['HostName']
#http_path=json_df.collect()[0]['HttpPath']
#Extracting the json filename to rename the csv filename
rm_spch_folder=foldername.split('_')[1:-1]
file_name="_".join(rm_spch_folder)

# COMMAND ----------

# Read client_id from key vault
client_id = dbutils.secrets.get(scope="selfservedma",key="clientid")
# Read client_secret from key vault
client_secret = dbutils.secrets.get(scope="selfservedma",key="clientsecret")
# Read tenant_id from key vault
tenant_id = dbutils.secrets.get(scope="selfservedma",key="tenantid")

from azure.identity import ClientSecretCredential

credential = ClientSecretCredential(tenant_id=tenant_id,
                             client_id=client_id,
                              client_secret=client_secret)

dbx_scope = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default"
sp_token = credential.get_token(dbx_scope).token

# COMMAND ----------

# Establish the Snowflake connection based on the Target schema

if discoveryarea=='SnowFlake':
  sfoptions = {
         "sfUrl" : dapsfurl,
         "sfUser" : dapsfusername,
         "sfPassword" : dapsfpassword,
         "sfDatabase" : dapsfdisdatabase,
         "sfSchema" : snowflakeschemaname, #schema changes dynamically based on the Json File
         "sfWarehouse" : dapsfwarehouse,
         "sfRole" : dapsfRole
        }
  
  #Define Sql Statement#
  sql_statement='SELECT * from '+dapsfdisdatabase+'.'+snowflakeschemaname+'.'+tablename
  
  
  #Connect with Snowflake and extract the data
  snowflake_Read_discovery_df=spark.read.format("net.snowflake.spark.snowflake").options(**sfoptions).option("delimiter","\u0001")\
  .option("query", sql_statement).load()

  #Save the as CSV file to temp location 
  snowflake_Read_discovery_df.coalesce(1).write.mode("overwrite").format("csv").option("delimiter","\u0001").option("escapeQuotes",False).option("quote","").option("escape","").option("header",True)\
  .save(source+'/'+file_name+'_temp')

  #Move the cleaned file into Decryption location with proper name
  wrangle_files_list=dbutils.fs.ls(source+'/'+file_name+'_temp') 
  for fd in wrangle_files_list:
    fn=fd.name    
  #Move the parquet file from temporary location to wrangle layer  

    if fn.startswith("part-"):      
      dbutils.fs.cp(source+'/'+file_name+'_temp/'+fn,source+'/'+file_name+'.csv')
  #Remove the Temporary folder 
      dbutils.fs.rm(source+'/'+file_name+'_temp',True) 
  
#identify number of record downloaded file  
  total_records=spark.read.format("csv").option("delimiter","\u0001").option("header",True).load(source+'/'+file_name+'.csv').count()

#update the Audit log table 
  ss_audit_logging(pipeline_runid,file_name,userid,source_path,'','Download','File is ready for Decryption',total_records)
  
elif discoveryarea=='DataBricks':
  
  workspace_name=json_df.collect()[0]['HostName']
  http_path=json_df.collect()[0]['HttpPath']
  
  from databricks import sql
  import os
  connection = sql.connect(server_hostname=workspace_name,
                             http_path=http_path,
                             access_token=sp_token)

  c=connection.cursor()
  quey_var='select * from '+DeltaLakeSchema+'.'+tablename
  data=c.execute(quey_var)
  data=data.fetchall()
  df_table=spark.createDataFrame(data)
  #Save the as CSV file to temp location 
  df_table.coalesce(1).write.mode("overwrite").format("csv").option("delimiter","\u0001")\
  .option("header",True).option("escapeQuotes",False).option("quote","").option("escape","").save(source+'/'+file_name+'_temp')

  #Move the cleaned file into Decryption location with proper name
  wrangle_files_list=dbutils.fs.ls(source+'/'+file_name+'_temp') 
  for fd in wrangle_files_list:
    fn=fd.name 
  
  #Move the parquet file from temporary location to wrangle layer  
    if fn.startswith("part-"):   
      
      dbutils.fs.cp(source+'/'+file_name+'_temp/'+fn,source+'/'+file_name+'.csv')
  #Remove the Temporary folder 
      dbutils.fs.rm(source+'/'+file_name+'_temp',True)

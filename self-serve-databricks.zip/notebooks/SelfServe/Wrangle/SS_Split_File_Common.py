# Databricks notebook source
dbutils.widgets.text('cleaned_file_path','')
cleaned_file_path=dbutils.widgets.get('cleaned_file_path')

# COMMAND ----------

cleaned_file_path_temp=cleaned_file_path+'/Temp'

# COMMAND ----------

wrangle_files_list=dbutils.fs.ls(cleaned_file_path) 
for fd in wrangle_files_list:
  fn=fd.name  
  fz=fd.size
  if fn.endswith(".csv"):
   if fz//262144000>0:
      PartFiles=(fz//262144000)+2
      df1=spark.read.format('csv').option("delimiter","\u0001").option("header",True).load(cleaned_file_path+fn)
      df1.repartition(PartFiles).write.mode("overwrite").format("csv")\
        .option("delimiter","\u0001").option("header",True).option("escapeQuotes",False).option("quote","").option("escape","").save(cleaned_file_path_temp)
   else:
      df1=spark.read.format('csv').option("delimiter","\u0001").option("header",True).load(cleaned_file_path+fn)
      df1.coalesce(1).write.mode("overwrite").format("csv")\
        .option("delimiter","\u0001").option("header",True).option("escapeQuotes",False).option("quote","").option("escape","").save(cleaned_file_path_temp)

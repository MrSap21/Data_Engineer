# Databricks notebook source
dbutils.widgets.text('RawLocation','')
raw_file_path=dbutils.widgets.get('RawLocation')
dbutils.widgets.text('PipelineRunId','')
pipeline_runid=dbutils.widgets.get('PipelineRunId')
dbutils.widgets.text('StorageAccountName','')
storage_account_name=dbutils.widgets.get('StorageAccountName')
dbutils.widgets.text('ContainerName','')
container_name=dbutils.widgets.get('ContainerName')

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Audit_Logging

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Table_Summary

# COMMAND ----------

folder_name=raw_file_path.split('/')[-1]
folder_name_temp=raw_file_path.split('/')[-1]+"_temp"
source_files="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+"Landing/UnzippedFile/"
quarantined_files="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+"Landing/QuarantinedFile/"
cleaned_file_path_temp="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+"Wrangle/Encryption/Input/"+folder_name_temp+'/'
task='Upload'

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import StructType

# COMMAND ----------

# DBTITLE 1,Validating the FileName
import re
json_df=spark.read.format('json').option("header","true").option("multiLine","true").load(source_files+folder_name+'/'+'*.json')
#Spliting the UserID,FileName & TimeStamp
user_id=folder_name.split('_')[0]
rm_spch_folder=folder_name.split('_')[1:-1]
file_name="_".join(rm_spch_folder)
timestamp=folder_name.split('_')[-1]
delta_lake_schema=json_df.collect()[0]['DeltaLakeSchema']
snowflake_schema=json_df.collect()[0]['SnowFlakeSchema']
file_type=json_df.collect()[0]['FileType']
delimiter=json_df.collect()[0]['Delimiter']
discovery_area=json_df.collect()[0]['DiscoveryArea']
file_size=json_df.collect()[0]['FileSize']
team_name=json_df.collect()[0]['TeamName']
user_name=json_df.collect()[0]['UserName']
file_records_df=0

column_information_df=json_df.select(to_json(col('fleData')).alias('column_information'))
columns_information=column_information_df.collect()[0][0]

if len(user_id)>0 and len(file_name)>0 and len(timestamp)>0:
    
    status='valid File Format'  
  
  #Adding the log in SS_Audit_Logs
  
    ss_audit_logging(pipeline_runid,file_name,user_id,'','','Landing',status,0)
    
else:
  
  status='invalid File Format' 
  #Adding the log in SS_Audit_Logs

  ss_audit_logging(pipeline_runid,file_name,user_id,'','','Landing',status,0)
    
       #insert the Table Summary

  ss_table_summary(user_id,file_name,task,timestamp,delta_lake_schema,'','',file_size,discovery_area,\
                     columns_information,'Failed',file_records_df)
   
  
  dbutils.fs.cp(source_files+folder_name,quarantined_files+folder_name,True)
  
  if status=='invalid File Format':
    raise Exception(status)

# COMMAND ----------

# DBTITLE 1,Special Character Check
import re
foldername=raw_file_path.split('/')[-1]

#Checking the Special characters in the UserID

if(bool(re.match('^[a-zA-Z0-9]*$', user_id)) == True):
  status='UserID does not contain any special characters:'
  
  
  ss_audit_logging(pipeline_runid,file_name,user_id,'','','Landing',status,0)
 
 #Checking the Special Characters in the FileName
      
  if(bool(re.match('^[a-zA-Z0-9]*$', file_name)) == True):
    status='FileName does not contain any special characters:'
    
    
    ss_audit_logging(pipeline_runid,file_name,user_id,'','','Landing',status,0)
       
      
  else:
    status="special characters Found in the FileName"
    target_folder='selfserve/Landing/QuarantinedFile/'+folder_name+'/'
    allfiles=dbutils.fs.ls(source_files+folder_name)
    files=[]
    
    for files in allfiles:
      dbutils.fs.cp(source_files+folder_name,quarantined_files+folder_name,True)

    
    ss_audit_logging(pipeline_runid,file_name,user_id,'','','Landing',status,0)
    
else:
  status="special characters Found in the UserID"
  target_folder='selfserve/Landing/QuarantinedFile/'+folder_name+'/'
  
  allfiles=dbutils.fs.ls(source_files+folder_name)
  files=[]
  for files in allfiles:
      dbutils.fs.cp(source_files+folder_name,quarantined_files+folder_name,True)

  
  ss_audit_logging(pipeline_runid,file_name,user_id,target_folder,'','Landing',status,0)

# COMMAND ----------

# DBTITLE 1,Timestamp Function
from datetime import datetime

def validate(date_text):
    try:
        if date_text != datetime.strptime(date_text, "%Y-%m-%d-%H%M").strftime('%Y-%m-%d-%H%M'):
            raise ValueError
        return True
    except ValueError: 
        return False

# COMMAND ----------

# DBTITLE 1,TimeStamp Check

val_timestamp=validate(timestamp)
if val_timestamp==True:
  status='ValidTimeStamp'
    
  
  ss_audit_logging(pipeline_runid,file_name,user_id,'','','Landing',status,0)
  
else:
  status='InValidTimeStamp'
  
  allfiles=dbutils.fs.ls(source_files+folder_name)
  files=[]
  for files in allfiles:
      dbutils.fs.cp(source_files+folder_name,quarantined_files+folder_name,True)
      target_folder='selfserve/Landing/QuarantinedFile/'+folder_name+'/'
      
  
  ss_audit_logging(pipeline_runid,file_name,user_id,target_folder,'','Landing',status,0)
  ss_table_summary(user_id,file_name,task,timestamp,delta_lake_schema,'','',file_size,discovery_area,columns_information,'Failed',file_records_df)
  
  if status=='InValidTimeStamp': 
       raise Exception(status)

# COMMAND ----------

# DBTITLE 1,Removing special character
import re
sc_clean_folder_name=re.sub("[=!\/.#%+$@&|?^<>()*' ',{}]","",folder_name)
user_id=re.sub("[=!\/.#%+$@&|?^<>()*' ',{}]","",user_id)
user_file_name=re.sub("[=!\/.#%+$@&|?^<>()*' ',{}]","",file_name)
cleaned_file_path="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net///"+"Wrangle/Encryption/Input/"+sc_clean_folder_name+'/'
duplicates_file_path="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+"Landing/QuarantinedFile/"+file_name.split('.')[0]+'_Duplicate_Records/'

# COMMAND ----------

# DBTITLE 1,Display the list of files
from pyspark.sql.functions import *

all_file_details=dbutils.fs.ls(source_files+folder_name)
list_file=[]
file_name=''
json_file=''
for list_file in all_file_details:
  file_name=list_file.name
  file_ext=list_file.name.split('.')[1]


   
  #Filter the CSV,text and psv file
  if file_ext=='csv' or file_ext=='txt' or file_ext=='psv':
      #Creating the variable based on the meta datainformation
      file_name_ext=file_name

           #Create the data frame from user uploaded the file
      
      file_df=spark.read.option("header","true").option("delimiter",delimiter).csv(source_files+folder_name+'/'+file_name_ext)
      
  elif file_ext=='json':
      json_file=file_name
      cl_json_file=re.sub("[=!\/#%+$@&|?^<>()*' ',{}]","",file_name)
      

# COMMAND ----------

# DBTITLE 1,Checking the record count in DataFile
#Checking the datafile record counts

raw_record_count=file_df.count()

if raw_record_count==0:
  status='File Contains 0 records'
  target_folder=quarantined_files+folder_name+'/'
  
  #Insert the log in ss_Audit_Logs
  
  
  ss_audit_logging(pipeline_runid,user_file_name,user_id,target_folder,'','Landing',status,0)
  ss_table_summary(user_id,file_name,task,timestamp,delta_lake_schema,'','',file_size,discovery_area,columns_information,'Failed',file_records_df)
  
  #Failed the notebook if file containes o records
  
  if status=='File Contains 0 records': 
       raise Exception(status)

# COMMAND ----------

# DBTITLE 1,Trimming the columns
from pyspark.sql.functions import *
#Identify the number of columns from the user uploaded file
for cols in file_df.columns:
  #Remove the whitespaces 
  file_df=file_df.withColumn(cols, trim(cols))
file_after_trim_df=file_df.select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in file_df.columns])

# COMMAND ----------

# DBTITLE 1,Removing records with all Null columns
#Droping the rows if df contains null rows
file_after_null_remove_df=file_after_trim_df.na.drop("all")
not_null_record_count= file_after_null_remove_df.count()

#Count the record after removing Null
after_remove_null=raw_record_count-not_null_record_count

status=''

if raw_record_count==not_null_record_count:
  status='No NULL rows present'
  
  
  ss_audit_logging(pipeline_runid,user_file_name,user_id,'','','Landing',status,0)
else:
  status='NULL rows removed'
  
  
  ss_audit_logging(pipeline_runid,user_file_name,user_id,'','','Landing',status,after_remove_null)
  
#Failed the notebook if file contains 0 records

if file_after_null_remove_df.count()==0:
  status='File Contains 0 records'
    
  
  ss_audit_logging(pipeline_runid,user_file_name,user_id,'','','Landing',status,0)
  ss_table_summary(user_id,user_file_name,task,timestamp,delta_lake_schema,'','',file_size,discovery_area,columns_information,'Failed',file_records_df)
  
  #DF_After_Remove_Null
  if status=='File Contains 0 records': 
       raise Exception(status)

# COMMAND ----------

# DBTITLE 1,Remove and Quarantine full row duplicates
#Droping the duplicates rows in DataFrame
file_after_dup_remove_df=file_after_null_remove_df.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Moving the duplicate records to QuarantinedFile Location
#Checking the rows count after removing duplicates
final_record_count=file_after_dup_remove_df.count()
#Checking the rows count between source dataframe rows count and after removing duplicates
if not_null_record_count==final_record_count:
  status='Final record count'
    
  
  ss_audit_logging(pipeline_runid,user_file_name,user_id,'','','Landing',status,final_record_count)
  
else:
  duplicate_df=file_after_null_remove_df.groupBy(file_after_null_remove_df.columns).count().filter(col("count")>1).withColumn("count",col("count")-1)
  duplicate_df.coalesce(1).write.mode("overwrite").format("csv")\
  .option("header",True).save(duplicates_file_path)
  
  status='Dulicate rows quarantined'
  target_folder=quarantined_files+folder_name+'/'
  
  duplicate_count = not_null_record_count - final_record_count

  ss_audit_logging(pipeline_runid,user_file_name,user_id,target_folder,'','Landing',status,duplicate_count)

  status='Final record count'
  target_folder=cleaned_file_path
  
  ss_audit_logging(pipeline_runid,user_file_name,user_id,target_folder,'','Wrangle',status,final_record_count)
  
  #Showing the list of files available in temp '_Duplicate_Records' folder 
  qfileslist=dbutils.fs.ls(duplicates_file_path)
  #Moving the files to different directory base on the File_Name
  for fd in qfileslist:
    fn=fd.name    
    if fn.startswith("part-"):      
      dbutils.fs.cp(duplicates_file_path+fn,quarantined_files+sc_clean_folder_name+'/'+sc_clean_folder_name+'.csv')
      #Removing the temp '_Duplicate_Records' folder 
      dbutils.fs.rm(duplicates_file_path,True)
  

# COMMAND ----------

# DBTITLE 1,Writing the cleaned file in ADLS location
#Save the Cleated file into to temporary folder as parquet format
file_after_dup_remove_df.coalesce(1).write.mode("overwrite").format("csv").option("delimiter","\u0001").option("header",True).save(cleaned_file_path_temp)

#Move the cleaned file into Wrangle location with proper name
wrangle_files_list=dbutils.fs.ls(cleaned_file_path_temp) 
for fd in wrangle_files_list:
  fn=fd.name    
#Move the parquet file from temporary location to wrangle layer  
  if fn.startswith("part-"):      
    dbutils.fs.cp(cleaned_file_path_temp+fn,cleaned_file_path+sc_clean_folder_name+'.csv')
#Remove the Temporary folder 
    dbutils.fs.rm(cleaned_file_path_temp,True) 
  
#Move the Json metadata file to wrangle folder  
dbutils.fs.cp(source_files+folder_name+'/'+json_file,cleaned_file_path+cl_json_file)

# COMMAND ----------

# DBTITLE 1,Adding the final log in SS_Audit_Logs Table
#Adding the final log in ss_Audit_Logs
target_folder=cleaned_file_path
status='Folder Created Successfully in Wrangle Layer'
file_name_audit=folder_name

ss_audit_logging(pipeline_runid,user_file_name,user_id,target_folder,'','Wrangle',status,0)

# COMMAND ----------

# MAGIC %run /SelfServe/Audit-logging/SS_Meta_Data

# COMMAND ----------

#Storing the meta_data details in ss_meta_data table
meta_data_jsonfile=raw_file_path+'/'+json_file
source_files="abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//"+meta_data_jsonfile
ss_meta_data(pipeline_runid,user_id,user_file_name,source_files)

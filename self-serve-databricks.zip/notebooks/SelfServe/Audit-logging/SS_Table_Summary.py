# Databricks notebook source
from datetime import datetime

# COMMAND ----------

def ss_table_summary(user_id,folder_name,task,timestamp,delta_lake_schema,table_name,file_path,file_size,discovery_area,column_infomation,table_status,row_count):
  spark.sql('insert into selfserve.Table_Summary values ('"'{0}'"','"'{1}'"','"'{2}'"','"'{3}'"','"'{4}'"','"'{5}'"','"'{6}'"','"'{7}'"','"'{8}'"','"'{9}'"','"'{10}'"','"'{11}'"','"'{12}'"')'.format(user_id,folder_name,task,timestamp,delta_lake_schema,table_name,file_path,file_size,discovery_area,column_infomation,table_status,row_count,datetime.now()))

# Databricks notebook source
from datetime import datetime

# COMMAND ----------

def ss_audit_logging(PipelineRunId,FileName,UserID,TargetPath,TargetTableName,Stage,Status,RowCount):
  spark.sql('insert into selfserve.Audit_Logs values ('"'{0}'"','"'{1}'"','"'{2}'"','"'{3}'"','"'{4}'"','"'{5}'"','"'{6}'"','"'{7}'"','"'{8}'"')'.format(PipelineRunId,FileName,UserID,TargetPath,TargetTableName,Stage,Status,RowCount,datetime.now()))

# Databricks notebook source
from pyspark.sql.functions import *
from datetime import datetime

# COMMAND ----------

def ss_meta_data(pipeline_runid,UserID,file_name,source_files):
  

  #Reading the json file
  
  nested_json=spark.read.format('json').option('multiLine',True).load(source_files)

  #list of dataframe columns
  cols=nested_json.columns

  #Creating the dataframe to store the metadata information,pipelinerunid,user_name and file_name in a column
  metadata_fileinfo=nested_json.select(to_json(struct(cols)).alias('MetaData')).\
  withColumn('PipelineRunId',lit(pipeline_runid)).withColumn('UserID',lit(UserID)).\
  withColumn('FileName',lit(file_name)).withColumn('CreatedOn',lit(datetime.now()))

  #Selecting the dataframe columns in order to insert the data in selfserve.Meta_Data external table
  metadata_fileinfo=metadata_fileinfo.select('PipelineRunId','UserID','FileName','MetaData','CreatedOn')

  #Inserting the meta_data_info in selfserve.Meta_Data table
  metadata_fileinfo.write.insertInto('selfserve.Meta_Data',overwrite=False)

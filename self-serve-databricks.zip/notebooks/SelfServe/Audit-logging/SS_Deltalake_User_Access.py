# Databricks notebook source
dbutils.widgets.text('ContainerName','')
container_name=dbutils.widgets.get('ContainerName')


dbutils.widgets.text('StorageAccountName','')
storage_account_name=dbutils.widgets.get('StorageAccountName')

# COMMAND ----------

#setting the source and target location variables
source = "abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//MetaData/DeltalakeUserInformation/UserInformation.csv"
target = "abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//MetaData/Deltalake_User_Access/"

# COMMAND ----------

#reading the UserInformation file data into a dataframe
access_csv_df=spark.read.format('csv').option("delimiter","|").option("header","True").option("inferSchema","True").load(source)
#dropping the business_name column from the dataframe
access_csv_df=access_csv_df.drop("business_name")

# COMMAND ----------

#Reading the current data present in the table selfserve.Deltalake_User_Access
table_access_df=spark.sql("select * from selfserve.Deltalake_User_Access")

# COMMAND ----------

#Union of the csv data and table data and removing the duplicates
insert_access_df=table_access_df.union(access_csv_df).distinct()

# COMMAND ----------

#overwriting the combined data into the table selfserve.Deltalake_User_Access
insert_access_df.write.insertInto('selfserve.Deltalake_User_Access',overwrite=True)

# Databricks notebook source
# MAGIC %python
# MAGIC dbutils.widgets.text('ContainerName','')
# MAGIC container_name=dbutils.widgets.get('ContainerName')
# MAGIC 
# MAGIC 
# MAGIC dbutils.widgets.text('StorageAccountName','')
# MAGIC storage_account_name=dbutils.widgets.get('StorageAccountName')

# COMMAND ----------

# MAGIC %sql
# MAGIC --Creating the Database
# MAGIC create database if not exists selfserve 

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table selfserve.table_summary

# COMMAND ----------

table_summary_var="""CREATE external TABLE selfserve.table_summary
(
UserId string,
FileName string,
Task string,
TaskCompletedOn string,
TargetSchemaName string,
TargetTableName string,
FilePath string,
FileSize bigint,
DiscoveryArea string,
ColumnInformation string,
Status string,
RecordCount int,
TableCreatedOn timestamp
) 
using delta location 'abfss://{0}@{1}.dfs.core.windows.net///Logging/Table_Summary/'""".format(container_name,storage_account_name)

spark.sql(table_summary_var)

# COMMAND ----------

audit_log_var="""CREATE external TABLE  selfserve.Audit_Logs
(
PipelineRunID string,
FileName string,
UserID string,
TargetPath string,
TargetTableName string,
Stage string,
StatusMessage string,
RecordCount int,
UpdatedDateTime Timestamp
) 
using delta location 'abfss://{0}@{1}.dfs.core.windows.net///Logging/Audit_Logs/'""".format(container_name,storage_account_name)

spark.sql(audit_log_var)

# COMMAND ----------

meta_data_var="""create external table selfserve.Meta_Data
(
PipelineRunId string,
UserID string,
FileName string,
MetaData string,
CreatedOn Date
) 
using delta location 'abfss://{0}@{1}.dfs.core.windows.net///Logging/Meta_Data/'""".format(container_name,storage_account_name)

spark.sql(meta_data_var)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table selfserve.Deltalake_User_Access

# COMMAND ----------

delta_user_var="""create external table selfserve.Deltalake_User_Access
(
user_id string,
email_id string,
container_name string,
database_name string,
workspace_name string,
http_path string
) 
using delta location 'abfss://{0}@{1}.dfs.core.windows.net///MetaData/Deltalake_User_Access/'""".format(container_name,storage_account_name)

spark.sql(delta_user_var)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table selfserve.Snowflake_Discovery_Access

# COMMAND ----------

snowflake_discovery_var="""create external table selfserve.Snowflake_Discovery_Access
(
User_ID string,
Email_ID string,
User_Role string,
Database_Name string,
Table_Schema string,
Ingested_Time timestamp
) 
using delta location 'abfss://{0}@{1}.dfs.core.windows.net///MetaData/Snowflake_Discovery_Access/'""".format(container_name,storage_account_name)

spark.sql(snowflake_discovery_var)

# COMMAND ----------

Snowflake_Discovery_Tables_var="""create external table selfserve.Snowflake_Discovery_Tables
(
User_ID string,
Email_ID string,
User_Role string,
Database_Name string,
Table_Schema string,
Table_Name string,
Ingested_Time timestamp
) 
using delta location 'abfss://{0}@{1}.dfs.core.windows.net///MetaData/Snowflake_Discovery_Tables/'""".format(container_name,storage_account_name)

spark.sql(Snowflake_Discovery_Tables_var)

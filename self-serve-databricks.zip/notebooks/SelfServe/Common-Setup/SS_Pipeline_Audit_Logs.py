# Databricks notebook source
#To define widgets for ADF Parameters
dbutils.widgets.text('PipelineRunId','')
pipeline_runid=dbutils.widgets.get('PipelineRunId')

#To define widgets for ADF Parameter
dbutils.widgets.text('RawLocation','')
file_path=dbutils.widgets.get('RawLocation')

#To define widgets for ADF Parameter
dbutils.widgets.text('Status','')
Status=dbutils.widgets.get('Status')

#To define widgets for ADF Parameter
dbutils.widgets.text('Stage','')
Stage=dbutils.widgets.get('Stage')

# COMMAND ----------

import re
user_id=file_path.split("_")[0]
user_id=re.sub("[=!\/.#%+$@&|?^<>()*' ',{}]","",user_id)
time_stamp=file_path.split("_")[-1].split(".")[0]
file_name="_".join(file_path.split("_")[1:-1])
file_name=re.sub("[=!\/.#%+$@&|?^<>()*' ',{}]","",file_name)


# COMMAND ----------

from datetime import datetime
#Insert into Audit Log Table
spark.sql('insert into selfserve.Audit_Logs values ('"'{0}'"','"'{1}'"','"'{2}'"','"'{3}'"','"'{4}'"','"'{5}'"','"'{6}'"','"'{7}'"','"'{8}'"')'.format(pipeline_runid,file_name,user_id,"","",Stage,Status,0,datetime.now()))

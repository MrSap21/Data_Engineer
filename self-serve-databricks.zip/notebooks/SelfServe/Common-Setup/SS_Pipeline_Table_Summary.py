# Databricks notebook source
#To define widgets for ADF Parameters
dbutils.widgets.text('PipelineRunId','')
pipeline_runid=dbutils.widgets.get('PipelineRunId')

#To define widgets for ADF Parameter
dbutils.widgets.text('RawLocation','')
file_path=dbutils.widgets.get('RawLocation')

#To define widgets for ADF Parameter
dbutils.widgets.text('Status','')
Status=dbutils.widgets.get('Status')

#To define widgets for ADF Parameter
dbutils.widgets.text('Task','')
task=dbutils.widgets.get('Task')

# COMMAND ----------

import re
from datetime import datetime
user_id=file_path.split("_")[0]
user_id=re.sub("[=!\/.#%+$@&|?^<>()*' ',{}]","",user_id)
file_name=file_path

time_stamp=datetime.now()
hour=time_stamp.hour
minutes=time_stamp.minute

if(hour<10): 
  hour='0'+str(time_stamp.hour)
else:  
  hour=str(time_stamp.hour)
  
if(minutes<10):
  minutes='0'+str(time_stamp.minute)
else:  
  minutes=str(time_stamp.minute)
  
time_stamp=str(time_stamp.year)+'-'+str(time_stamp.month)+'-'+str(time_stamp.day)+'-'+hour+minutes

# COMMAND ----------

#from datetime import datetime
spark.sql('insert into selfserve.Table_Summary values ('"'{0}'"','"'{1}'"','"'{2}'"','"'{3}'"','"'{4}'"','"'{5}'"','"'{6}'"','"'{7}'"','"'{8}'"','"'{9}'"','"'{10}'"','"'{11}'"','"'{12}'"')'.format(user_id,file_name,task,time_stamp,'','','',0,'','','Failed',0,datetime.now()))

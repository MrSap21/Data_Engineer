# Databricks notebook source
dbutils.widgets.text('ContainerName','')
container_name=dbutils.widgets.get('ContainerName')


dbutils.widgets.text('StorageAccountName','')
storage_account_name=dbutils.widgets.get('StorageAccountName')

dbutils.widgets.text('DiscoveryDB','')
DiscoveryDB=dbutils.widgets.get('DiscoveryDB')


# COMMAND ----------

#Establish the connection to ADLS 
source = "abfss://"+container_name+"@"+storage_account_name+".dfs.core.windows.net//MetData/Snowflake_Discovery_Access/"

# COMMAND ----------

# Read the SnowFlake connection from Key Valut
dapsfurl=dbutils.secrets.get(scope = "selfservedma", key = "url")
dapsfusername=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonusername")
dapsfpassword=dbutils.secrets.get(scope= "dapadbscope", key= "dap-ss-team-dna-data-management-build-pwd-secret")
dapsfwarehouse=dbutils.secrets.get(scope= "selfservedma", key= "sfwarehouse")
dapsfRole=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonrole")
dapsfdatabase=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonreaddatabase")

# COMMAND ----------

# Establish the Snowflake connection based on the Target schema
sfoptions = {
         "sfUrl" : dapsfurl,
         "sfUser" : dapsfusername,
         "sfPassword" : dapsfpassword,
         "sfDatabase" : dapsfdatabase,
         "sfSchema" : "SNFK_ACCOUNT_USAGE",
         "sfWarehouse" : dapsfwarehouse,
         "sfRole" : dapsfRole
        }
          

# COMMAND ----------

#Define Sql Statement#
sql_statement='SELECT U.NAME as User_ID,U.EMAIL as Email_ID,GU.ROLE as User_Role,GR.TABLE_CATALOG as Database_Name,SC.SCHEMA_NAME as Table_Schema,CURRENT_TIMESTAMP as Ingested_Time  from '+dapsfdatabase+'.SNFK_ACCOUNT_USAGE.USERS U INNER JOIN '+dapsfdatabase+'.SNFK_ACCOUNT_USAGE.GRANTS_TO_USERS GU on U.NAME=GU.GRANTEE_NAME INNER JOIN '+dapsfdatabase+'.SNFK_ACCOUNT_USAGE.GRANTS_TO_ROLES GR ON GU.ROLE=GR.GRANTEE_NAME INNER JOIN '+DiscoveryDB+'.INFORMATION_SCHEMA.SCHEMATA SC on GR.TABLE_CATALOG=SC.CATALOG_NAME'

# COMMAND ----------

#Connect with Snowflake and extract the data
snowflake_Read_access_df1=spark.read.format("net.snowflake.spark.snowflake").options(**sfoptions).option("query", sql_statement).load()


#Filter only difined role
snowflake_user_access_df=snowflake_Read_access_df1.filter(snowflake_Read_access_df1.USER_ROLE == dapsfRole)

#Remove the full row duplications
snowflake_user_access_df=snowflake_user_access_df.distinct()

# COMMAND ----------

#Remove the existing Record
spark.sql("truncate table selfserve.Snowflake_Discovery_Access")

#Filter only difined role
snowflake_user_access_df=snowflake_Read_access_df1.filter(snowflake_Read_access_df1.USER_ROLE == dapsfRole)

#Inserting the meta_data_info in ss_poc.Meta_Data table
snowflake_user_access_df.write.insertInto('selfserve.Snowflake_Discovery_Access',overwrite=False)

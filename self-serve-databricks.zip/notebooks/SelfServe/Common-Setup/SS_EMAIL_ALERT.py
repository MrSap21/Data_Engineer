# Databricks notebook source
from pyspark.sql.functions import col
import json
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import os
import requests
from requests.auth import HTTPDigestAuth
import json
from pyspark.sql.types import *
from pyspark.sql.functions import col
from pyspark.sql.functions import *
from pyspark.sql import Row


dbutils.widgets.text("Status", '', '')
Status = dbutils.widgets.get('Status')
dbutils.widgets.text("FileName", '', '')
FileName = dbutils.widgets.get('FileName')
dbutils.widgets.text("ErrorDetails", '', '')
ErrorDetails = dbutils.widgets.get('ErrorDetails')
dbutils.widgets.text("PipelineName", '', '')
PipelineName = dbutils.widgets.get('PipelineName')
dbutils.widgets.text("PipelineRunId", '', '')
PipelineRunId = dbutils.widgets.get('PipelineRunId')
dbutils.widgets.text("SubjectLine", '', '')
SubjectLine = dbutils.widgets.get('SubjectLine')
dbutils.widgets.text("StorageAccountName", '', '')
StorageAccountName = dbutils.widgets.get('StorageAccountName')


# COMMAND ----------

#fetching the user email id from json file
if PipelineName=="PL_LF_PROCESSING_CONTROL": #for large files
  json_df=spark.read.format('json').option("multiline",True).load('abfss://selfserve@'+StorageAccountName+'.dfs.core.windows.net/Pre-Landing/'+FileName+'/'+'*.json')
  json_df=json_df.select("EmailId")
  useremailid=json_df.collect()[0][0]
elif PipelineName=="PL_SS_DOWNLOAD_VOLTAGE_DECRYPTION": #for egress
  json_df=spark.read.format('json').option("multiline",True).load('abfss://selfserve@'+StorageAccountName+'.dfs.core.windows.net/Wrangle/Decryption/Input/'+FileName+'/'+'*.json')
  json_df=json_df.select("EmailId")
  useremailid=json_df.collect()[0][0]
elif PipelineName in ("Data Standardization","PL_SS_Voltage_Encryption","Table Creation"): #for ingress
  json_df=spark.read.format('json').option("multiline",True).load('abfss://selfserve@'+StorageAccountName+'.dfs.core.windows.net/Landing/UnzippedFile/'+FileName+'/'+'*.json')
  json_df=json_df.select("EmailId")
  useremailid=json_df.collect()[0][0]
else: #for ingress unzip failure
  useremailid=""

#fetching the support team email id
supportemails=dbutils.secrets.get(scope = "selfservedma", key = "supportemails")

#final email id(s)
if len(useremailid)==0:
  EmailId = supportemails
else:
  EmailId = useremailid+';'+supportemails

# COMMAND ----------

LogicAppURL=dbutils.secrets.get(scope = "selfservedma", key = "logicappurl")

# COMMAND ----------

data ={"FileName":FileName,
        "ErrorDetails":ErrorDetails,
        "Status":Status,
        "PipelineName":PipelineName,
        "PipelineRunId":PipelineRunId,
        "SubjectLine":SubjectLine,
        "EmailId":EmailId}
myResponse = requests.post(LogicAppURL,params = data)

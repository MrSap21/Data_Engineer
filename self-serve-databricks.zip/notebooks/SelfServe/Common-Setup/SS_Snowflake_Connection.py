# Databricks notebook source
dbutils.widgets.text('TargetPath','')
Target_Folder=dbutils.widgets.get("TargetPath")
dbutils.widgets.text('TargetTableName','')
Table_Name=dbutils.widgets.get("TargetTableName")
dbutils.widgets.text('snowflake_schema','')
snowflake_schema=dbutils.widgets.get("snowflake_schema")


# COMMAND ----------

# Read the SnowFlake connection from Key Valut

dapsfurl=dbutils.secrets.get(scope = "selfservedma", key = "url")
dapsfusername=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonusername")
dapsfpassword=dbutils.secrets.get(scope= "dapadbscope", key= "dap-ss-team-dna-data-management-build-pwd-secret")
dapsfwarehouse=dbutils.secrets.get(scope= "selfservedma", key= "sfwarehouse")
dapsfdatabase=dbutils.secrets.get(scope= "selfservedma", key= "sfdiscoverydatabase")
dapsfRole=dbutils.secrets.get(scope= "selfservedma", key= "sfcommonrole")

# COMMAND ----------

# Establish the Snowflake connection based on the Target schema
sfoptions = {
         "sfUrl" : dapsfurl,
         "sfUser" : dapsfusername,
         "sfPassword" : dapsfpassword,
         "sfDatabase" : dapsfdatabase,
         "sfSchema" : snowflake_schema,
         "sfWarehouse" : dapsfwarehouse,
         "sfRole" : dapsfRole,
         "truncate_table" : "ON",  
         "usestagingtable" : "OFF"   
        }
          
  #Read the Data Frame from Delta Lake Location 
df_snowflake=spark.read.format("csv").option("sep","\u0001").option("header","true").option('inferSchema',True).load(Target_Folder)

    
  #Create the Table in Snowflake 
df_snowflake.write.format("net.snowflake.spark.snowflake").options(**sfoptions).option('mergeSchema',True).option("dbtable",Table_Name).mode('OverWrite').save()

﻿CREATE TABLE SER.PromoDeal
(
	[PromoDealId] [bigint] NOT NULL PRIMARY KEY NONCLUSTERED NOT ENFORCED, --primary key
	[DealNumber] [varchar] (100) NOT NULL,
	[PromotionNumber] [varchar]	(100) NOT NULL,
	[DealName] [varchar] (255) NOT NULL,
	[DateFrom] [date] NOT NULL,
	[DateTo] [date] NOT NULL,	
	[LastChangeDate] [date] NOT NULL,
	[LOVRecordSourceId][int] NOT NULL, --foreign key
	[SCDStartDate] [datetime] NULL,	
	[SCDEndDate] [datetime] NULL,	
	[SCDActiveFlag]	[nchar]	(1) NULL,
	[SCDVersion] [smallint] NULL,	
	[SCDLOVRecordSourceId] [int] NULL,	--foreign Key
	[ETLRunLogId] [int]	NULL,
	[PSARowKey]	[bigint] NULL	
)
WITH

(
	DISTRIBUTION = HASH([PromoDealId]),
	CLUSTERED COLUMNSTORE INDEX
)
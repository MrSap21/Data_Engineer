﻿/* 
 * TABLE: [IndicatorValue] 
 */

CREATE TABLE ser.[IndicatorValue](
    [Value]     nchar(1)    NOT NULL,
    [Sequence]  smallint    NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

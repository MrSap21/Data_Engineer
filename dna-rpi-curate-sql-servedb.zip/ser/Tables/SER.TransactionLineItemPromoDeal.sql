﻿CREATE TABLE SER.TransactionLineItemPromoDeal
(   [TranslineItemPromoDealid]	[bigint] NOT NULL PRIMARY KEY NONCLUSTERED NOT ENFORCED,
	[TransactionLineItemId]	[bigint] NOT NULL ,
	[PromoDealID] [bigint]	NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime]	NULL,
	[SCDActiveFlag] [nchar] (1)	NULL,
	[SCDVersion] [smallint]	NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int]	NULL,
	[PSARowKey]	[bigint] NULL
)
WITH

(
	DISTRIBUTION = HASH ( [TranslineItemPromoDealid] ),
	CLUSTERED COLUMNSTORE INDEX
)
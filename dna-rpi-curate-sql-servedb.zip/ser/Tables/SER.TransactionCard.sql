﻿/* 
 * TABLE: [TransactionCard] 
 */

CREATE TABLE ser.[TransactionCard](
    [TransactionId]         bigint      NOT NULL,
    [MembershipAccountId]   char(10)    NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)

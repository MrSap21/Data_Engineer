﻿/* 
 * TABLE: [PlanogramFixture] 
 */

CREATE TABLE ser.[PlanogramFixture](
    [PlanogramFixtureId]    bigint          NOT NULL,
    [PlanogramId]           bigint          NOT NULL,
    [SourceKey]             nvarchar(80)    NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)

﻿/* 
 * TABLE: [CalendarPeriod] 
 */

CREATE TABLE ser.[CalendarPeriod](
    CalendarPeriodId        int             NOT NULL,
    CalendarId              int             NOT NULL,
    PeriodId                int             NOT NULL,
    CalendarPeriodName      nvarchar(80)    NULL,
    LOVRecordSourceId       int             NOT NULL,
    SCDStartDate            datetime        NULL,
    SCDEndDate              datetime        NULL,
    SCDActiveFlag           nvarchar(1)     NULL,
    SCDVersion              smallint        NULL,
    SCDLOVRecordSourceId    int             NULL,
    ETLRunLogId             int             NULL,
    PSARowKey               bigint          NULL,
)

WITH
(
	DISTRIBUTION = HASH([CalendarId]),
	CLUSTERED COLUMNSTORE INDEX
)
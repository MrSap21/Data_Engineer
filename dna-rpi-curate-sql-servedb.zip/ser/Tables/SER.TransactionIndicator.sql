﻿/* 
 * TABLE: [TransactionIndicator] 
 */

CREATE TABLE ser.[TransactionIndicator](
    [TransactionId]         bigint      NOT NULL,
    [LOVIndicatorId]        int         NOT NULL,
    [Value]                 nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)

﻿/* 
 * TABLE: [RefLOV] 
 */

CREATE TABLE [ser].[RefLOV]
(
	[LOVId] [int] NOT NULL,
	[LOVSetId] [int] NOT NULL,
	[LOVKey] [nvarchar](128) NOT NULL,
	[LOVName] [nvarchar](128) NOT NULL,
	[LOVDescription] [nvarchar](1024) NULL,
	[LOVSequence] [int] NULL,
	[RecordSourceId] [int] NOT NULL,
	[ETLRunLogId] [int] NULL,
	[ActiveFlag] [smallint] NOT NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nvarchar](128) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)
GO

ALTER TABLE [ser].[RefLOV] ADD  DEFAULT ((1)) FOR [ActiveFlag]
GO


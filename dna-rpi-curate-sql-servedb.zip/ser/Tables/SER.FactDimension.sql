﻿/* 
 * TABLE: [FactDimension] 
 */

CREATE TABLE ser.[FactDimension](
    [FactId]                bigint      NOT NULL,
    [DimensionId]           int         NOT NULL,
    [Sequence]              smallint    NULL,
    [Mandatory]             nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)
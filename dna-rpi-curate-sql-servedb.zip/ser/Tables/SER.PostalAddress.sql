﻿/* 
 * TABLE: [PostalAddress] 
 */

CREATE TABLE ser.[PostalAddress](
    [SiteId]                bigint          NOT NULL,
    [LocationName]          nvarchar(80)    NULL,
    [AddressLine1]          nvarchar(80)    NULL,
    [AddressLine2]          nvarchar(80)    NULL,
    [Town]                  nvarchar(80)    NULL,
    [County]                nvarchar(80)    NULL,
    [PostalCode]            nvarchar(10)    NULL,
    [LOVCountryId]          int             NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[LOVCountryId],[LOVRecordSourceId])
)

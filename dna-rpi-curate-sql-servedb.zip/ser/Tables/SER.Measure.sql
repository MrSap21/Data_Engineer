﻿/* 
 * TABLE: [Measure] 
 */

CREATE TABLE ser.[Measure](
    [MeasureId]             int               NOT NULL,
    [LOVMeasureTypeId]      int               NOT NULL,
    [LOVDataTypeId]         int               NOT NULL,
    [MeasureName]           nvarchar(80)      NOT NULL,
    [MeasureDescription]    nvarchar(1000)    NULL,
    [Length]                smallint          NULL,
    [Precision]             smallint          NULL,
    [Scale]                 smallint          NULL,
    [StandardMeasureId]     int               NULL,
    [LOVUOMTypeId]          int               NULL,
    [LOVRecordSourceId]     int               NOT NULL,
    [SCDStartDate]          datetime          NULL,
    [SCDEndDate]            datetime          NULL,
    [SCDActiveFlag]         nchar(1)          NULL,
    [SCDVersion]            smallint          NULL,
    [SCDLOVRecordSourceId]  int               NULL,
    [ETLRunLogId]           int               NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)

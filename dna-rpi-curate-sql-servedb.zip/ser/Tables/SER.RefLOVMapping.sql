﻿CREATE TABLE SER.RefLOVMapping(
    LOVMappingSetId    int              NOT NULL,
    LOVFromId          int              NOT NULL,
    LOVToId            int              NOT NULL,
    RecordSourceId     int              NOT NULL,
    ActiveFlag         smallint         DEFAULT 1 NOT NULL,
    DTCreated          smalldatetime    NULL,
    UserCreated        nvarchar(128)    NULL,
    ETLRunLogId        int              NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)

﻿/* 
 * TABLE: [PartyRole] 
 */

CREATE TABLE ser.[PartyRole](
    [PartyRoleId]           bigint          NOT NULL,
    [LOVRoleId]             int             NOT NULL,
    [PartyId]               bigint          NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [PartyRoleName]         nvarchar(80)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRoleId],[PartyId],[LOVRecordSourceId])
)

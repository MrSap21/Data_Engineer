﻿/* 
 * TABLE: [Period] 
 */

CREATE TABLE ser.[Period](
    PeriodId                int         NOT NULL,
    LOVPeriodTypeId         int         NOT NULL,
    StartDatetime           datetime    NOT NULL,
    EndDatetime             datetime    NOT NULL,
    LOVRecordSourceId       int         NOT NULL,
    SCDStartDate            datetime    NULL,
    SCDEndDate              datetime    NULL,
    SCDActiveFlag           nchar(1)    NULL,
    SCDVersion              smallint    NULL,
    SCDLOVRecordSourceId    int         NULL,
    ETLRunLogId             int         NULL,
    PSARowKey               bigint      NULL,

)
WITH
(
	DISTRIBUTION = HASH([PeriodId]),
	CLUSTERED COLUMNSTORE INDEX
)

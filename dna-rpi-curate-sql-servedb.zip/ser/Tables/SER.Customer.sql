﻿/* 
 * TABLE: [Customer] 
 */

CREATE TABLE ser.[Customer](
    [PartyRoleId]           bigint          NOT NULL,
    [CustomerNumber]        nvarchar(80)    NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH([PartyRoleId]),
	CLUSTERED COLUMNSTORE INDEX
)

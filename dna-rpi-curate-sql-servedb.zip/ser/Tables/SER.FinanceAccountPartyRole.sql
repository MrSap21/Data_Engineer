﻿CREATE TABLE ser.FinanceAccountPartyRole(
    FinanceAccountId        bigint      NOT NULL,
    PartyRoleId             bigint      NOT NULL,
    EffectiveFrom           datetime    NULL,
    EffectiveTo             datetime    NULL,
    LOVRecordSourceId       int         NOT NULL,
    SCDStartDate            datetime    NULL,
    SCDEndDate              datetime    NULL,
    SCDActiveFlag           nchar(1)    NULL,
    SCDVersion              smallint    NULL,
    SCDLOVRecordSourceId    int         NULL,
    ETLRunLogId             int         NULL,
    PSARowKey               bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH ( [FinanceAccountId] ),
	CLUSTERED COLUMNSTORE INDEX
)


﻿/* 
 * TABLE: [LoyaltyAccountCardStatus] 
 */

CREATE TABLE ser.[LoyaltyAccountCardStatus](
    [LoyaltyAccountCardId]              bigint      NOT NULL,
    [LOVLoyaltyAccountCardStatusSetId]  int         NOT NULL,
    [LOVStatusId]                       int         NOT NULL,
    [EffectiveFrom]                     datetime    NULL,
    [EffectiveTo]                       datetime    NULL,
    [LOVRecordSourceId]                 int         NOT NULL,
    [SCDStartDate]                      datetime    NULL,
    [SCDEndDate]                        datetime    NULL,
    [SCDActiveFlag]                     nchar(1)    NULL,
    [SCDVersion]                        smallint    NULL,
    [SCDLOVRecordSourceId]              int         NULL,
    [ETLRunLogId]                       bigint         NULL,
    [PSARowKey]                         bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH ( [LoyaltyAccountCardId] ),
	CLUSTERED COLUMNSTORE INDEX
)
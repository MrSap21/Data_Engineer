﻿CREATE TABLE [SER].[TransactionLineItemPromoDealMeasure]
(
[TransLineItemPromoDealMeasureid] [bigint] NOT NULL PRIMARY KEY NONCLUSTERED NOT ENFORCED,
[TranslineItemPromoDealid] [bigint] NOT NULL,
[MeasureId] [int] NOT NULL,
[Value] [nvarchar] (255) NULL,
[LOVUOMId] [int] NULL,
[LOVRecordSourceId] [int] NOT NULL,
[SCDStartDate] [datetime] NULL,
[SCDEndDate] [datetime] NULL,
[SCDActiveFlag] [nchar] (1) NULL,
[SCDVersion] [smallint] NULL,
[SCDLOVRecordSourceId] [int] NULL,
[ETLRunLogId] [int] NULL,
[PSARowKey] [bigint] NULL
)
WITH
(
DISTRIBUTION = HASH ([TransLineItemPromoDealMeasureid]),
CLUSTERED COLUMNSTORE INDEX
)
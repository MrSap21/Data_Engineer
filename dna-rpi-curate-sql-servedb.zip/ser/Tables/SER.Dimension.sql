﻿/* 
 * TABLE: [Dimension] 
 */

CREATE TABLE ser.[Dimension](
    [DimensionId]           int             NOT NULL,
    [Name]                  nvarchar(80)    NOT NULL,
    [Description]           nvarchar(80)    NULL,
    [Schema]                nvarchar(80)    NULL,
    [Tablename]             nvarchar(80)    NOT NULL,
    [SurrogateKeyColumn]    nvarchar(80)    NOT NULL,
    [SourceKeyColumn]       nvarchar(80)    NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)

﻿/* 
 * TABLE: [CalendarTypePeriodType] 
 */

CREATE TABLE ser.[CalendarTypePeriodType](
    [LOVCalendarTypeId]  int    NOT NULL,
    [LOVPeriodTypeId]    int    NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE ser.ProductRelationship(
    ProductRelationshipId    bigint      NOT NULL,
    FromProductId            bigint      NOT NULL,
    ToProductId              bigint      NOT NULL,
    LOVRelationshipTypeId    int         NOT NULL,
    LOVRecordSourceId        int         NOT NULL,
    SCDStartDate             datetime    NULL,
    SCDEndDate               datetime    NULL,
    SCDActiveFlag            nchar(1)    NULL,
    SCDVersion               smallint    NULL,
    SCDLOVRecordSourceId     int         NULL,
    ETLRunLogId              int         NULL,
    PSARowKey                bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH(ProductRelationshipId),
	CLUSTERED COLUMNSTORE INDEX 
)
﻿/* 
 * TABLE: [Date] 
 */

CREATE TABLE ser.[Date](
    [DateId]                date            NOT NULL,
    [Abbreviation]          nvarchar(10)    NULL,
    [FullDate]              nvarchar(80)    NOT NULL,
    [DayName]               nvarchar(80)    NOT NULL,
    [DayNumberofMonth]      smallint        NOT NULL,
    [DayNumberofYear]       smallint        NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH([DateId]),
	CLUSTERED COLUMNSTORE INDEX
)

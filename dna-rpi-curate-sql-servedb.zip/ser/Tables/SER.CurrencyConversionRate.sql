﻿/* 
 * TABLE: [CurrencyConversionRate] 
 */

CREATE TABLE SER.CurrencyConversionRate(
    CurrencyConversionRateId    bigint            NOT NULL,
    CurrencyConversionId        bigint            NOT NULL,
    EffectiveFrom               datetime          NOT NULL,
    EffectiveTo                 datetime          NULL,
    ConversionRate              decimal(10, 8)    NOT NULL,
    LOVRecordSourceId           int               NOT NULL,
    SCDStartDate                datetime          NULL,
    SCDEndDate                  datetime          NULL,
    SCDActiveFlag               nchar(1)          NULL,
    SCDVersion                  smallint          NULL,
    SCDLOVRecordSourceId        int               NULL,
    ETLRunLogId                 int               NULL,
    PSARowKey                   bigint            NULL
)
WITH
(
	DISTRIBUTION = HASH(CurrencyConversionId),
	CLUSTERED COLUMNSTORE INDEX
)
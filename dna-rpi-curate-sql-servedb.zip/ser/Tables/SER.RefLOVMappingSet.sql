﻿CREATE TABLE SER.RefLOVMappingSet(
    LOVMappingSetId             int               NOT NULL,
    LOVFromSetId                int               NOT NULL,
    LOVToSetId                  int               NOT NULL,
    LOVMappingSetDescription    nvarchar(1024)    NOT NULL,
    LOVMappingTypeId            int               NULL,
    RecordSourceId              int               NOT NULL,
    ActiveFlag                  smallint          DEFAULT 1 NOT NULL,
    DTCreated                   smalldatetime     NULL,
    UserCreated                 nvarchar(128)     NULL,
    ETLRunLogId                 int               NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)

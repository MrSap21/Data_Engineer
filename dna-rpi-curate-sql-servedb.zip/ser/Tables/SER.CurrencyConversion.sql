﻿CREATE TABLE SER.CurrencyConversion(
    CurrencyConversionId     bigint      NOT NULL,
    LOVSourceCurrencyId      int         NOT NULL,
    LOVTargetCurrencyId      int         NOT NULL,
    LOVConversionTypeId      int         NOT NULL,
    LOVConversionMethodId    int         NOT NULL,
    LOVPeriodTypeId          int         NOT NULL,
    PartyId                  bigint      NULL,
    LOVRecordSourceId        int         NOT NULL,
    SCDStartDate             datetime    NULL,
    SCDEndDate               datetime    NULL,
    SCDActiveFlag            nchar(1)    NULL,
    SCDVersion               smallint    NULL,
    SCDLOVRecordSourceId     int         NULL,
    ETLRunLogId              int         NULL,
    PSARowKey                bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH(CurrencyConversionId),
	CLUSTERED COLUMNSTORE INDEX
)


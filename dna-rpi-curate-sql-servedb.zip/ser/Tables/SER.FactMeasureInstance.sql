﻿/* 
 * TABLE: [FactMeasureInstance] 
 */

CREATE TABLE [ser].[FactMeasureInstance]
(
	[FactInstanceId] [bigint] NOT NULL,
	[MeasureId] [int] NOT NULL,
	[Value] [nvarchar](255) NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [FactInstanceId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

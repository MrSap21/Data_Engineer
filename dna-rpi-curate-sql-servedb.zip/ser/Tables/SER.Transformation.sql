﻿/* 
 * TABLE: [Transformation] 
 */

CREATE TABLE ser.[Transformation](
    [TransformationId]                  bigint            NOT NULL,
    [Name]                              nvarchar(80)      NOT NULL,
    [Description]                       nvarchar(80)      NULL,
    [TargetTableName]                   nvarchar(80)      NOT NULL,
    [TargetColumnName]                  nvarchar(80)      NOT NULL,
    [LOVLogicTypeId]                    int               NOT NULL,
    [Logic]                             nvarchar(4000)    NOT NULL,
    [LOVTransformationTypeId]           int               NOT NULL,
    [LOVTransformationComponentTypeId]  int               NOT NULL,
    [TransformationComponentKey]        int               NOT NULL,
    [LOVRecordSourceId]                 int               NOT NULL,
    [SCDStartDate]                      datetime          NULL,
    [SCDEndDate]                        datetime          NULL,
    [SCDActiveFlag]                     nchar(1)          NULL,
    [SCDVersion]                        smallint          NULL,
    [SCDLOVRecordSourceId]              int               NULL,
    [ETLRunLogId]                       int               NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

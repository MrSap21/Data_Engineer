﻿/* 
 * TABLE: [Planogram] 
 */

CREATE TABLE [ser].[Planogram]
(
	[PlanogramId] [bigint] NOT NULL,
	[SourceKey] [nvarchar](80) NULL,
	[LOVSourceKeyTypeId] [int] NOT NULL,
	[PlanogramStartDate] [datetime] NULL,
	[PlanogramEndDate] [datetime] NULL,
	[PlanogramName] [nvarchar](100) NULL,
	[ParentPlanogramId] [bigint] NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)
GO

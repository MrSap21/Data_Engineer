﻿CREATE TABLE ser.TransactionMeasure(
    TransactionMeasureId    bigint          NOT NULL,
    TransactionId           bigint          NOT NULL,
    MeasureId               int             NOT NULL,
    Value                   varchar(255)    NULL,
    LOVUOMId                int             NOT NULL,
    LOVRecordSourceId       int             NOT NULL,
    SCDStartDate            datetime        NULL,
    SCDEndDate              datetime        NULL,
    SCDActiveFlag           nchar(1)        NULL,
    SCDVersion              smallint        NULL,
    SCDLOVRecordSourceId    int             NULL,
    ETLRunLogId             int             NULL,
    PSARowKey               bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)

﻿/* 
 * TABLE: [ProductGroup] 
 */

CREATE TABLE ser.[ProductGroup](
    [ProductGroupId]        bigint      NOT NULL,
    [ProductId]             bigint      NOT NULL,
    [LOVProductGroupSetId]  int         NOT NULL,
    [LOVGroupId]            int         NOT NULL,
    [ParentProductGroupId]  bigint      NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH ( [ProductId] ),
	CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVProductGroupSetId],[LOVRecordSourceId])
)

﻿/* 
 * TABLE: [SiteTerritory] 
 */

CREATE TABLE ser.[SiteTerritory](
    [SiteId]                 bigint      NOT NULL,
    [LOVSiteTerritorySetId]  int         NOT NULL,
    [LOVTerritoryId]         int         NOT NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [PSARowKey]              bigint      NULL
)
WITH
(
	DISTRIBUTION = HASH([SiteId]),
	CLUSTERED COLUMNSTORE INDEX
)

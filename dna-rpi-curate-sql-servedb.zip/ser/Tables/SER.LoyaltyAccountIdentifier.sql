﻿/* 
 * TABLE: [LoyaltyAccountIdentifier] 
 */

CREATE TABLE ser.[LoyaltyAccountIdentifier](
    [LoyaltyAccountId]      bigint          NOT NULL,
    [LOVIdentifierId]       bigint          NOT NULL,
    [Value]                 nvarchar(80)    NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH([LoyaltyAccountId]),
	CLUSTERED COLUMNSTORE INDEX
)

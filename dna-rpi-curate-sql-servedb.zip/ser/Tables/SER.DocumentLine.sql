﻿CREATE TABLE SER.DocumentLine(
    DocumentLineId           bigint          NOT NULL,
    DocumentId               bigint          NOT NULL,
    SourceKey                nvarchar(80)    NOT NULL,
    LOVDocumentLineTypeId    int             NOT NULL,
    ProductId                bigint          NULL,
    FinanceAccountId         bigint          NULL,
    LOVRecordSourceId        int             NOT NULL,
    SCDStartDate             datetime        NULL,
    SCDEndDate               datetime        NULL,
    SCDActiveFlag            nchar(1)        NULL,
    SCDVersion               smallint        NULL,
    SCDLOVRecordSourceId     int             NULL,
    ETLRunLogId              int             NULL,
    PSARowKey                bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH ( [DocumentLineId] ),
	CLUSTERED COLUMNSTORE INDEX
)






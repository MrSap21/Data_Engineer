﻿CREATE TABLE SER.PartyRoleRelationshipGroup(
    PartyRoleRelationshipGroupId          bigint      NOT NULL,
    PartyRoleRelationshipId               bigint      NOT NULL,
    LOVRelationshipTypeId                 int         NOT NULL,
    LOVGroupSetId                         int         NOT NULL,
    LOVGroupId                            int         NOT NULL,
    ParentPartyRoleRelationshipGroupId    bigint      NULL,
    LOVRecordSourceId                     int         NOT NULL,
    SCDStartDate                          datetime    NULL,
    SCDEndDate                            datetime    NULL,
    SCDActiveFlag                         nchar(1)    NULL,
    SCDVersion                            smallint    NULL,
    SCDLOVRecordSourceId                  int         NULL,
    ETLRunLogId                           int         NULL,
    PSARowKey                             bigint      NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)


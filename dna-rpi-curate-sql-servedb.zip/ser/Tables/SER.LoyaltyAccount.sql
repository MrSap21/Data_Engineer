﻿/* 
 * TABLE: [LoyaltyAccount] 
 */

CREATE TABLE ser.[LoyaltyAccount](
    [LoyaltyAccountId]      bigint           NOT NULL,
    [LOVLoyaltyProgramId]   int              NOT NULL,
    [SourceKey]             nvarchar(300)    NOT NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = HASH ( [LoyaltyAccountId] ),
	CLUSTERED COLUMNSTORE INDEX
)

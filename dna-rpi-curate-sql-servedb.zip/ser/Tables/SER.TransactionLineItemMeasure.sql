﻿/* 
 * TABLE: [TransactionLineItemMeasure] 
 */

CREATE TABLE ser.[TransactionLineItemMeasure](
    [TransactionLineItemMeasureId]  bigint           NOT NULL,
    [TransactionLineItemId]         bigint           NOT NULL,
    [MeasureId]                     int              NOT NULL,
    [Value]                         nvarchar(255)    NULL,
    [LOVUOMId]                      int              NULL,
    [LOVRecordSourceId]             int              NOT NULL,
    [SCDStartDate]                  datetime         NULL,
    [SCDEndDate]                    datetime         NULL,
    [SCDActiveFlag]                 nchar(1)         NULL,
    [SCDVersion]                    smallint         NULL,
    [SCDLOVRecordSourceId]          int              NULL,
    [ETLRunLogId]                   int              NULL,
    [PSARowKey]                     bigint           NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionLineItemId] ),
	CLUSTERED COLUMNSTORE INDEX
)

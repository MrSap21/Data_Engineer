﻿CREATE TABLE ser.FinanceAccount(
    FinanceAccountId           bigint          NOT NULL,
    SourceKey                  nvarchar(80)    NOT NULL,
    AccountName                nvarchar(80)    NULL,
    AccountDescription         nvarchar(80)    NULL,
    LOVFinanceAccountTypeId    int             NOT NULL,
    LOVRecordSourceId          int             NOT NULL,
    SCDStartDate               datetime        NULL,
    SCDEndDate                 datetime        NULL,
    SCDActiveFlag              nchar(1)        NULL,
    SCDVersion                 smallint        NULL,
    SCDLOVRecordSourceId       int             NULL,
    ETLRunLogId                int             NULL,
    PSARowKey                  bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH ( [FinanceAccountId] ),
	CLUSTERED COLUMNSTORE INDEX
)

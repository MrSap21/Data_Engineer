﻿CREATE TABLE ser.[Transformation Instance](
    [TransformationInstanceId]   bigint            NOT NULL,
    [TransformationId]           bigint            NOT NULL,
    [TransformationDatetime]     smalldatetime     NOT NULL,
    [LOVTransformationStatusId]  int               NOT NULL,
    [ExecutionLogic]             nvarchar(4000)    NOT NULL,
    [Result]                     nvarchar(256)     NOT NULL,
    [SurrogateKey]               bigint            NULL,
    [SourceKey]                  nvarchar(80)      NULL,
    [LOVRecordSourceId]          int               NOT NULL,
    [SCDStartDate]               datetime          NULL,
    [SCDEndDate]                 datetime          NULL,
    [SCDActiveFlag]              nchar(1)          NULL,
    [SCDVersion]                 smallint          NULL,
    [SCDLOVRecordSourceId]       int               NULL,
    [ETLRunLogId]                int               NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)


﻿/* 
 * TABLE: [Product] 
 */

CREATE TABLE ser.[Product](
    [ProductId]             bigint           NOT NULL,
    [SourceKey]             nvarchar(80)     NOT NULL,
    [LOVSourceKeyTypeId]    int              NOT NULL,
    [ProductName]           nvarchar(255)    NULL,
    [ProductDescription]    nvarchar(255)    NULL,
    [LOVBrandId]            int              NULL,
    [LOVSubBrandId]         int              NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [ParentProductId]       bigint           NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
    )
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED INDEX
	(
		[SourceKey] ASC,
		[LOVRecordSourceId] ASC
	)
)
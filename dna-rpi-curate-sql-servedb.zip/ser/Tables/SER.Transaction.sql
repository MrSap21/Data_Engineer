﻿/* 
 * TABLE: [Transaction] 
 */

CREATE TABLE ser.[Transaction](
    [TransactionId]          bigint          NOT NULL,
    [SourceKey]              nvarchar(80)    NULL,
    [LOVTransactionTypeId]   int             NOT NULL,
    [SiteRoleId]             bigint          NULL,
    [TransactionDatetime]    datetime        NOT NULL,
    [TillId]                 bigint          NULL,
    [TillTransactionNumber]  nvarchar(80)    NULL,
    [LOVLevelId]             int             NULL,
    [LOVRecordSourceId]      int             NOT NULL,
    [SCDStartDate]           datetime        NULL,
    [SCDEndDate]             datetime        NULL,
    [SCDActiveFlag]          nchar(1)        NULL,
    [SCDVersion]             smallint        NULL,
    [SCDLOVRecordSourceId]   int             NULL,
    [ETLRunLogId]            int             NULL,
    [PSARowKey]              bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)

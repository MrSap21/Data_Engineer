﻿/* 
 * TABLE: [PlanogramProperty] 
 */

CREATE TABLE ser.[PlanogramProperty](
    [PlanogramId]           bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)

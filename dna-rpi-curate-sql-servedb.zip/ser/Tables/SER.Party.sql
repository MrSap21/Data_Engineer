﻿/* 
 * TABLE: [Party] 
 */

CREATE TABLE ser.[Party](
    [PartyId]               bigint          NOT NULL,
    [LOVPartyTypeId]        int             NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVPartyTypeId],[LOVRecordSourceId])
)

﻿/* 
 * TABLE: [SiteRole] 
 */

CREATE TABLE ser.SiteRole(
    SiteRoleId              bigint          NOT NULL,
    SiteId                  bigint          NOT NULL,
    LOVRoleId               int             NOT NULL,
    SourceKey               nvarchar(80)    NULL,
    LOVSourceKeyTypeId      int             NULL,
    SiteRoleName            nvarchar(80)    NULL,
    SiteRoleShortName       nvarchar(20)    NULL,
    LOVRecordSourceId       int             NOT NULL,
    SCDStartDate            datetime        NULL,
    SCDEndDate              datetime        NULL,
    SCDActiveFlag           nchar(1)        NULL,
    SCDVersion              smallint        NULL,
    SCDLOVRecordSourceId    int             NULL,
    ETLRunLogId             int             NULL,
    PSARowKey               bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[SiteRoleId],[LOVRoleId],[LOVRecordSourceId])
)

﻿CREATE TABLE SER.FinanceCentre(
    FinanceCentreId           bigint          NOT NULL,
    SourceKey                 nvarchar(80)    NOT NULL,
    CentreName                nvarchar(80)    NULL,
    CentreDescription         nvarchar(80)    NULL,
    LOVFinanceCentreTypeId    int             NOT NULL,
    LOVRecordSourceId         int             NOT NULL,
    SCDStartDate              datetime        NULL,
    SCDEndDate                datetime        NULL,
    SCDActiveFlag             nchar(1)        NULL,
    SCDVersion                smallint        NULL,
    SCDLOVRecordSourceId      int             NULL,
    ETLRunLogId               int             NULL,
    PSARowKey                 bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH ( [FinanceCentreId] ),
	CLUSTERED COLUMNSTORE INDEX
)


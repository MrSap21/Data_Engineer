﻿/* 
 * TABLE: [Fact] 
 */

CREATE TABLE ser.[Fact](
    [FactId]                bigint          NOT NULL,
    [FactName]              nvarchar(80)    NOT NULL,
    [LOVFactTypeId]         int             NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)

﻿/* 
 * TABLE: [CalendarPeriodDate] 
 */

CREATE TABLE ser.[CalendarPeriodDate](
    [DateId]                date        NOT NULL,
    [CalendarPeriodId]      int         NOT NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = HASH([DateId]),
	CLUSTERED COLUMNSTORE INDEX
)
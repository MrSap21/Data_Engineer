﻿/* 
 * TABLE: [RefLOVSet] 
 */

CREATE TABLE ser.[RefLOVSet](
    [LOVSetId]           int               NOT NULL,
    [LOVSetName]         nvarchar(128)     NOT NULL,
    [LOVSetDescription]  nvarchar(1024)    NULL,
    [LOVSetSequence]     int          NULL,
    [RecordSourceId]     int               NOT NULL,
    [ActiveFlag]         smallint          NOT NULL,
    [DTCreated]          smalldatetime     NULL,
    [UserCreated]        nvarchar(128)     NULL,
    [ETLRunLogId]        int               NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)

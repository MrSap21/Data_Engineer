﻿/* 
 * TABLE: [PeriodDate] 
 */

CREATE TABLE ser.[PeriodDate](
    [PeriodId]              int         NOT NULL,
    [DateId]                date        NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL
)
WITH
(
	DISTRIBUTION = HASH([PeriodId]),
	CLUSTERED COLUMNSTORE INDEX
)

﻿/****** Object:  Schema [ser]    Script Date: 23/10/2020 19:15:25 ******/
CREATE SCHEMA [ser]
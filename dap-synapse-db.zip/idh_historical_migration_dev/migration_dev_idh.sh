#!/bin/bash
## comment
# "migration_dev_idh.sh"
#
# 10/11/2021 - Carter Shore - Initial creation based on script 'migration_dev_sqoop_orc.sh', migrate Voltage encrypted IDH table data to Azure ADLS.

# ############Environment Var Dev#####
# export JAVA_HOME=/usr/jdk64/jdk1.8.0_60;
# export PATH=$PATH:/usr/jdk64/jdk1.8.0_60;
# export HADOOP_HOME=/usr/hdp/2.6.4.0-91/hadoop;
# export PATH=$PATH:/usr/hdp/2.6.4.0-91/hadoop;
# export LIBHDFS_CLASSPATH=$(hadoop classpath --glob);
# export HTTPS_PROXY=corppac.walgreens.com:8080;
# export HTTP_PROXY=corppac.walgreens.com:8080;
# export SPARK_MAJOR_VERSION=2
# ###################


###########Permissions##############
chmod +rwx ./*.sh
chmod +rwx ./validation/validation_dev.sh
###################

hdfspath=/data/dnaphase2/source/db/dna_phase2/

###local landing folder for mapping file
mappingfilefolder="/tmp/copytoadls/dev/idhmigrationmapping/"

hivedbname=$1
idhdbname=${2,,} # lowercae idh dbname
idhtablename=${3,,} # lowercae idhtablename 
prefix=${4,,} # lowercase the migrationId prefix
startstep=$5
hadoophost=$6
idhusername=$7
idhpassword=$8
idhhost=$9
filterClause=${10}
validationFlag=${11}

echo $prefix
echo $idhdbname
echo $idhtablename

DATE_WITH_TIME=`date "+%Y%m%d%H%M"`
echo $DATE_WITH_TIME
migrationId=$prefix$DATE_WITH_TIME
echo $migrationId
VAR=0
mkdir -p logs
mkdir -p $mappingfilefolder

chmod +rwx $mappingfilefolder

paramfilename="./logs/"${migrationId}.param
echo $paramfilename

echo 1-hivedbname=$hivedbname > $paramfilename
echo 2-idhdbname=$idhdbname >> $paramfilename
echo 3-idhtablename=$idhtablename >> $paramfilename
echo 4-prefix=$prefix >> $paramfilename
echo 5-startstep=$startstep >> $paramfilename
echo 6-hadoophost=$hadoophost >> $paramfilename
echo 7-idhusername=$idhusername >> $paramfilename
echo 8-idhpassword=$idhpassword >> $paramfilename
echo 9-idhhost=$idhhost >> $paramfilename
echo 10-filterClause=$filterClause >> $paramfilename
echo 11-validationFlag=$validationFlag >> $paramfilename
echo $hivedbname
echo $idhdbname
echo $idhtablename
echo $prefix
echo $startstep
echo $hadoophost
echo $idhusername
echo $idhpassword
echo $idhhost
echo $filterClause
echo $validationFlag

# execute the Voltage Encryption script
spark-submit Gen_IdhVoltageEncryptSQL.py $migrationId $hivedbname $idhdbname $idhtablename $validationFlag $filterClause


# Genrate The Mapping File To copy the Parquet File
python Gen_Idh_Mapping_File.py $hdfspath $migrationId $mappingfilefolder


###logic to call validation framework if flag is set to 'validate'
#if [ "$validationFlag" == "validate" ] ; then   
#    if [ -z "${13}" ] ; then
#		echo "rowcount is null"    
#		echo $rowCountLimit
#    else
#		rowCountLimit=${13}
#		echo "rowcount has value"
#		echo $rowCountLimit
#    fi
#    cd ./validation
#   ./validation_dev.sh $hivedbname $migrationId $hdfspath $rowCountLimit "../logs/"
#else
#   echo "Validation flag not set. Migration will not be validated"
#fi

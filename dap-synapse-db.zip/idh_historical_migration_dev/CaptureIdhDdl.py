"""
CaptureIdhDdl.py

Pyspark script to capture IDH source table DDL as text, and generate equivalent
DDL for creating Azure Databricks Delta tables.

Parms: Target Hive DB name, IDH Hive database name, IDH table name

10/12/2021 - Carter Shore - Initial creation based on Gen_IdhVoltageEncryptSQL.py
10/13/2021 - Carter Shore - Add parm to designate target Databricks database

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
import os
import sys
import re

# process parms
nargs = len(sys.argv)

print(nargs)
if (nargs < 5 or nargs > 6): 
   print('Usage: Gen_IdhVoltageEncryptSQL.py <TGT Hive DB name> <IDH db name> <IDH table name> <migrationID> <databricks db name>')
   print('Enclose parms with embedded whitespace or punctuation in single quotes')
   exit(-1)

this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2].lower()
idh_database = sys.argv[3].lower()
idh_table = sys.argv[4].lower()
databricks_db = sys.argv[5].lower()

print('parm0= ' + this_script)
print('parm1= ' + migrationId)
print('parm2= ' + hive_db_name)
print('parm3= ' + idh_database)
print('parm4= ' + idh_table)
print('parm5= ' + databricks_db)

IdhTable = ('{}.{}').format(idh_database,idh_table)

print('Source IDH table: ' + IdhTable)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:IDH database name: \'' + idh_database + '\'')
logging.append(this_script + ":" + 'JobParams:IDH table name: \'' + idh_table + '\'')
logging.append(this_script + ":" + 'JobParams:IDH databricks database name: \'' + databricks_db + '\'')

logFileName = "./logs/" + migrationId + ".log"
print logFileName
ddlFileName = "./logs/" + IdhTable + ".ddl"
print ddlFileName

# get a Spark Session
spark=SparkSession.builder.appName('CaptureIdhDdl.py').enableHiveSupport().getOrCreate()

# set the Hive database with parm value
sdf_table = spark.sql("use {0}".format(idh_database))

# create DF from source landing table

srcddlDF = spark.sql("""
   SHOW CREATE TABLE {}
""".format(idh_table))

#srcddlDF.show(truncate=False)
#print srcddlDF.count()

srcDDL=srcddlDF.collect()[0][0]

#print srcDDL
#srcddlDF.printSchema()

srcDDLlines = srcDDL.split('\n')

#print(srcDDLlines)

deltaDDLary = []

for ln in srcDDLlines:
	if re.match('^ROW FORMAT SERDE',ln):
		break	
	else:
		#print('->' + ln)
		deltaDDLary.append(ln)

deltaDDLary.append("USING DELTA")

#print deltaDDLary

deltaDDL = '\n'.join(deltaDDLary)

print deltaDDL

ddlfile = open(ddlFileName, "a")
for ln in deltaDDLary:
    ddlfile.write(ln + "\n")
ddlfile.close()

logfile = open(logFileName, "a")
for ln in logging:
    logfile.write(ln + "\n")
logfile.close()

###CaptureIdhDdl.py end of script

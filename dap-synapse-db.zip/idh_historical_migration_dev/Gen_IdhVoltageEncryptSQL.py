"""
Gen_IdhVoltageEncryptSQL.py

Pyspark script to generate SQL statement that reads records from source IDH Landing table, 
Voltage encrypts columns designated in table 'idh_column_encryption_spec', and writes records
to target Encrypted table.

 landing tablename = LIDH__<IDH db name>__<IDH table name>__<migrationId>
 encrypt tablename = EIDH__<IDH db name>__<IDH table name>__<migrationId>

Parms: Target Hive DB name, IDH Hive database name, IDH table name

09/28/2021 - Carter Shore - Initial creation based on Gen_HiveVoltageParquetSQL.py
10/07/2021 - Carter Shore - Add optional parm to filter source table select, can be used to select a partition
10/11/2021 - Carter Shore - Enable imigrationID, logging, capture generated SQL
10/12/2021 - Puneet Jaiswal - Create Landing & Parquet table , Load the encrypted data in parquet Table

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
import os
import sys

# process parms
nargs = len(sys.argv)

print(nargs)
if (nargs < 5 or nargs > 6): 
   print('Usage: Gen_IdhVoltageEncryptSQL.py <migrationID> <TGT Hive DB name> <IDH db name> <IDH table name> [<filter clause>]')
   print('Enclose parms with embedded whitespace or punctuation in single quotes')
   exit(-1)

this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2].lower()
idh_database = sys.argv[3].lower()
idh_table = sys.argv[4].lower()
idh_filter = sys.argv[5]


if (idh_filter):
   fltr_str = idh_filter.replace("[","'")
   fltr_str2 = fltr_str.replace("]","'")
   src_filter = " WHERE {}".format(fltr_str2)
   print (src_filter)
else:
   src_filter = ""

print('parm0= ' + this_script)
print('parm1= ' + migrationId)
print('parm2= ' + hive_db_name)
print('parm3= ' + idh_database)
print('parm4= ' + idh_table)
print('parm5= ' + idh_filter)


#src_table = ('LIDH__{}__{}__{}').format(idh_database,idh_table,migrationId)
#tgt_table = ('EIDH__{}__{}__{}').format(idh_database,idh_table,migrationId)
src_table = ('LIDH_{}__{}__{}').format(idh_database,idh_table,migrationId)
tgt_table = ('EIDH_{}__{}__{}').format(idh_database,idh_table,migrationId)

print('Source Landing IDH table: ' + src_table)
print('Target Encrypt IDH table: ' + tgt_table)


recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:IDH database name: \'' + idh_database + '\'')
logging.append(this_script + ":" + 'JobParams:IDH table name: \'' + idh_table + '\'')
logging.append(this_script + ":" + 'JobParams:IDH filter: \'' + idh_filter + '\'')

fileName = "./logs/" + migrationId + ".log"

# get a Spark Session
spark=SparkSession.builder.appName('Gen_IdhVoltageEncryptSQL').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))

# Create Source Landing Table from IDH Table
spark.sql("create table {} as select * from {}.{}".format(src_table,idh_database,idh_table))

# create DF from source landing table
srcDF = spark.sql("""
   SELECT * FROM {}
""".format(src_table))

#srcDF.printSchema()

# capture list of landing table column names from srcDF

srcColumns = srcDF.columns

#print(srcColumns)

# create DF from table 'idh_column_encryption_spec' for the IDH database, table, and columns to be encrypted

cesDF = spark.sql("""
   SELECT * FROM idh_column_encryption_spec
   WHERE idh_database = '{}'
   AND idh_tab_name = '{}'
   AND length(voltage_format) > 0
""".format(idh_database,idh_table))

cesDF.show()

# iterate through column list, joining encryption spec by column name to generate the voltage encryption SQL statement

# initialize an empty temp array to hold the SQL statement lines
lines = []

# for each column name, fetch encryption data (if it exists) into cesRec
for colname in srcColumns:
    cesRec = cesDF.select("idh_col_name","voltage_udf","voltage_format").filter(col("idh_col_name") == colname).collect()
    
# if ces record exixts, write code to call the UDF to encrypt the data in the source column
    if cesRec:
      lines.append(cesRec[0][1] + "(`" + cesRec[0][0] + "`,'" + cesRec[0][2] + "') as `" + cesRec[0][0] + "`")
      
# else write code to fetch the data in the source column
    else:
      lines.append('`' + colname + '` as `' + colname + '`')
      

# finish by joining the clauses in temp array and the ending FROM clause into the final SQL statement 

# build the SQL statement starting with INSERT ... SELECT clause, followed by the joined column clauses, FROM clause, ending with optional WHERE clause
voltageSQL = "INSERT OVERWRITE TABLE {}.{} SELECT ".format(hive_db_name,tgt_table) + ",".join(lines) + " FROM {}.{}{}".format(hive_db_name,src_table,src_filter)

# print SQL to STDOUT
print(voltageSQL)


# Create Target Table from Landing Table
spark.sql("create table {} stored as Parquet as select * from {}.{} where 1=0".format(tgt_table,hive_db_name,src_table))

#The convention used by Spark to write Parquet data is configurable. This is determined by the property spark.sql.parquet.writeLegacyFormat The default value is false. If set to "true", Spark will use the same convention as Hive for writing the Parquet data. This will help to solve the issue.
spark.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
# execute the SQL
spark.sql(voltageSQL)

logging.append(this_script + ":" + "++++++++Append to migration_component END ++++++")
logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")



file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()



# -*- coding: utf-8 -*-
"""
Gen_Mapping_File.py

Python script to generate mapping file that maps Parquet files On-prem to ADLS.
Params: HDFS path, migrationId, mapping file folder location


10/12/2021 - Puneet Jaiswal - Intial creation
"""
import os
import sys
import subprocess

this_script = sys.argv[0]
basepath_input = sys.argv[1]
migrationId = sys.argv[2]
mapping_file_folder = sys.argv[3]

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " + this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " + this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
      splt = ln.split("::")

      if ((len(splt) > 1) & (splt[1] == "END")):
         print
         "this step  is over"
         sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Hive data path: \'' + basepath_input + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:mapping file folder: \'' + mapping_file_folder + '\'')
filelog = "./logs/" + migrationId + ".log"

args = "hdfs dfs -ls "+basepath_input+" | grep eidh_ | grep " + migrationId.lower() + " | awk '{print $8}'"
proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
logging.append ("args:" + args)


s_output, s_err = proc.communicate()
all_dart_dirs = s_output.split()

#create mapping file in common folder
flname = mapping_file_folder+ '/' +"move" + migrationId + '.csv'
logging.append ("mapping filename:" + flname)


file1 = open(flname, "w")

for file in all_dart_dirs:
   print('filename-->'+file)
   splt = file.split("/")   
   fn = splt[len(splt) - 1]
   """
   sp3 = fn.split("_")
   sp4 = fn.split("_" + migrationId)
   dbname = sp3[1]
   lastpr = sp3[len(sp3) - 1]  
   t1 = lastpr.split("__")
   print(t1)
   t2 = t1[len(t1) - 1].replace("_" + migrationId.lower() , "")
   tb = sp4[0].split(dbname + "__")
   tbname = tb[len(tb) -1]
   tbname = tbname.replace ("_" + migrationId.lower(), "")
   print("t2:" + t2)
   locSuffix =  "/common/" + sp3[1] + "/" + tbname + "/" + t2 + "/"
   """
   splitArray = fn.split("__")
   dbname = splitArray[0].replace("eidh_","")
   tbname = splitArray[1].replace("_" + migrationId.lower() , "")
   print(tbname)
   print(dbname)
   locSuffix =  "/common/idh_data_migration/tables/" + migrationId.lower() + "/" + dbname + "/" + tbname + "/"
   lne1 = file.replace("/", '',1) + "/," + locSuffix
   logging.append("mapping file data:" + lne1)
   file1.write(lne1 + "\n")
   
file1.close()

logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")
file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.close()

os.system(endCmd)




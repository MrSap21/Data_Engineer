from pyspark.sql import SparkSession
from pyspark.sql.functions import *


spark=SparkSession.builder.appName("Gen_part_csv").enableHiveSupport().getOrCreate()

output_folder_path="test_part_file/Partition_list"
db_name = "mna_cooked"
tab_name="RAD_CUSTOMER_ONE_VIEW"
spark.sql("use {0}".format(db_name))
df=spark.sql("show partitions {0}".format(tab_name))
df2=df.withColumn("src_tab_name",lit(tab_name))
df2.write.format("csv").save("{0}_{1}".format(output_folder_path,tab_name))

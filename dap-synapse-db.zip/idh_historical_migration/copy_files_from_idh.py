"""
copy_files_from_idh.py

Uses DistCp to copy HDFS files from source cluster to target cluster.

2022-02-11 Carter Shore - Fix given by Dhiraj Konjeti to prevent DistCp HDFS_DELEGATION_TOKEN errors, add parm to command string.
           '-Dmapreduce.job.hdfs-servers.token-renewal.exclude=HAProd2'

"""

import os
import sys

optional_parm = '-Dmapreduce.job.hdfs-servers.token-renewal.exclude=HAProd2'

# process parms
nargs = len(sys.argv)

print(nargs)
if (nargs != 6): 
   print('Usage: copy_files_from_idh.py <6 parameters>]')
   print('Enclose parms with embedded whitespace or punctuation in single quotes')
   exit(-1)

this_script = sys.argv[0]
source_hdfs_path = sys.argv[1]
idh_database = sys.argv[2].lower()
idh_table = sys.argv[3].lower()
mapper_count = sys.argv[4]
bandwidth = sys.argv[5]

dest_hdfs_folder = "hdfs://HADNAProd:8020/user/SVC-adgshdfsprodsa/"

dest_hdfs_path=dest_hdfs_folder+idh_table+"/"

cmd = "hadoop distcp "+optional_parm+" -update -m "+mapper_count+" -bandwidth "+bandwidth+" "+source_hdfs_path+" "+dest_hdfs_path
print(cmd)
os.system(cmd)

os.system("hadoop fs -chmod -R 777 "+dest_hdfs_path)

           

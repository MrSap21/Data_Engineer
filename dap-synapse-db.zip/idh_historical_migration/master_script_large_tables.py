from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import os
import sys
import subprocess
from datetime import datetime

# process parms
nargs = len(sys.argv)

print(nargs)
if (nargs != 7):
   print('Usage: master_script <parameters>]')
   print('Enclose parms with embedded whitespace or punctuation in single quotes')
   exit(-1)

this_script = sys.argv[0]
hive_db = sys.argv[1].lower()
idh_database = sys.argv[2].lower()
idh_table = sys.argv[3].lower()
prefix = sys.argv[4].lower()
environment = sys.argv[5].lower()
partition_pattern = sys.argv[6]

#config
hdfs_path = "/data/dna_phase_2/source/db/dnaphase2/encryptrpu/"
mapping_file_folder = "/tmp/copytoadls/"+environment+"/idhmigrationmapping/"
adls_path = "/common/idh_data_migration/tables/"

#partition log file
os.system("mkdir -p ./logs")
partition_log_file = "./logs/" + prefix + "_partitions.proc"

spark=SparkSession.builder.appName("master_script").enableHiveSupport().getOrCreate()

table_name = "lidh__"+idh_database+"__"+idh_table

partition_check_df =  spark.sql("desc {}.{}".format(hive_db,table_name)).filter("col_name == '# Partition Information'")

if partition_check_df.count() == 0:
        
	os.system("spark-submit --jars " + os.environ['HIVE_CONTRIB'] + " encrypt_table_pattern.py "+prefix+" "+hive_db+" "+idh_database+" "+idh_table+" "+"''"+" "+hdfs_path+" "+adls_path+" "+mapping_file_folder)
        
else:
	spark.sql("MSCK repair table {}.{}".format(hive_db,table_name))
	os.system("spark-submit --jars " + os.environ['HIVE_CONTRIB'] + " encrypt_table_pattern.py "+prefix+" "+hive_db+" "+idh_database+" "+idh_table+" "+'"'+partition_pattern+'"'+" "+hdfs_path+" "+adls_path+" "+mapping_file_folder)


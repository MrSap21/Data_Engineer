"""
Utility script to add all partitions in HDFS that don't follow hive's partition pattern to Hive table

creation date: 22-Mar-2022

Command to run the script: spark-submit add_partitions_to_hive_table.py <Hive DB of Landing Table> <Landing Table Name> <Partition Column Name>

"""

from pyspark.sql import SparkSession
import sys
import subprocess

spark=SparkSession.builder.appName('add_partitions_to_hive_table.py').enableHiveSupport().getOrCreate()

#get arguments
hive_db = sys.argv[1].lower()
table_name = sys.argv[2].lower()
partition_column_name = sys.argv[3].lower()

spark.sql("use {}".format(hive_db))

#fech table location in HDFS
df_desc = spark.sql("describe formatted {}".format(table_name))
path = df_desc.filter("col_name like '%Location%'").select('data_type').collect()[0][0]
args = "hdfs dfs -ls "+path+" | awk '{print $8}'"
proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
s_output, s_err = proc.communicate()
files = s_output.split()

#iterate through each partition folder and add partitions that don't have '<column>=<value>' pattern 
for item in files:
	partition_key = item.split("/")[-1]
	if len(partition_key.split('=')) == 1:
		spark.sql("alter table {} add if not exists partition ({}='{}') location '{}'".format(table_name,partition_column_name,partition_key,item)) 

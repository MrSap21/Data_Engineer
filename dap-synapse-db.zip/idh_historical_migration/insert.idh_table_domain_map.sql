insert into idh_table_domain_map values('wag_gen_cooked','prprty_tracker_portfolio_hist','property_services','property_services');
insert into idh_table_domain_map values('wag_gen_cooked','prprty_spotlight_trans_approval_hist','property_services','property_services');
insert into idh_table_domain_map values('wag_gen_cooked','prprty_tracker_idle_dispo','property_services','property_services');
insert into idh_table_domain_map values('wag_gen_cooked','prprty_tracker_parent','property_services','property_services');
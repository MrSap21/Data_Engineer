"""
encypt_table.py

Pyspark script to generate SQL statement that reads records from source IDH Landing table, 
Voltage encrypts columns designated in table 'idh_column_encryption_spec', and writes records
to target Encrypted table.

 landing tablename = LIDH__<IDH db name>__<IDH table name>__<migrationId>
 encrypt tablename = EIDH__<IDH db name>__<IDH table name>__<migrationId>

Parms: Target Hive DB name, IDH Hive database name, IDH table name

09/28/2021 - Carter Shore - Initial creation based on Gen_HiveVoltageParquetSQL.py
10/07/2021 - Carter Shore - Add optional parm to filter source table select, can be used to select a partition
10/11/2021 - Carter Shore - Enable imigrationID, logging, capture generated SQL
10/12/2021 - Puneet Jaiswal - Create Landing & Parquet table , Load the encrypted data in parquet Table
02/03/2021 - Teena Kappen - Updated insert query execution from Spar SQL to Beeline
02/07/2021 - Teena Kappen - Changes to add START and END records in proc file
02/08/2021 - Teena Kappen - Changes to handle null/empty values in sub_domain

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
from datetime import datetime
import os
import sys

# process parms
nargs = len(sys.argv)

print(nargs)
if (nargs != 9): 
   print('Usage: encrypt_table.py <parameters>')
   print('Enclose parms with embedded whitespace or punctuation in single quotes')
   exit(-1)

this_script = sys.argv[0]
prefix = sys.argv[1].lower()
hive_db_name = sys.argv[2].lower()
idh_database = sys.argv[3].lower()
idh_table = sys.argv[4].lower()
idh_filter = sys.argv[5]
hdfs_path = sys.argv[6].lower()
adls_basepath = sys.argv[7].lower()
mapping_file_folder = sys.argv[8].lower()

print('parm0= ' + this_script)
print('parm1= ' + prefix)
print('parm2= ' + hive_db_name)
print('parm3= ' + idh_database)
print('parm4= ' + idh_table)
print('parm5= ' + idh_filter)
print('parm6= ' + hdfs_path)
print('parm7= ' + adls_basepath)
print('parm8= ' + mapping_file_folder)

beeline_connection_string = "jdbc:hive2://pla-w01mstrhdpdna01.walgreens.com:2181,pla-w01mstrhdpdna02.walgreens.com:2181,pla-w01mstrhdpdna03.walgreens.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2"
partition_log_file = './logs/'+prefix+'_partitions.proc'
migration_id=prefix+datetime.now().strftime("%y%m%d%H%M%S")
start_cmd = "echo " + idh_filter + "," + migration_id + "::START >> " + partition_log_file
os.system(start_cmd)

if idh_filter:
   input_filter_string = idh_filter.replace("'","")   
   split_string = input_filter_string.split("=")
   filter_string = split_string[0]+ "=" + "'" + split_string[1] + "'" 
   src_filter = " WHERE {}".format(filter_string)
   print (src_filter)
else:
   src_filter = ""


src_table = ('lidh__{}__{}').format(idh_database,idh_table)
tgt_table = ('eidh__{}__{}__{}').format(idh_database,idh_table,migration_id)

print('Source Landing IDH table: ' + src_table)
print('Target Encrypt IDH table: ' + tgt_table)


recoverfilename = "./logs/" + migration_id + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration Id: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:IDH database name: \'' + idh_database + '\'')
logging.append(this_script + ":" + 'JobParams:IDH table name: \'' + idh_table + '\'')
logging.append(this_script + ":" + 'JobParams:IDH filter: \'' + src_filter + '\'')

fileName = "./logs/" + migration_id + ".log"

# get a Spark Session
spark=SparkSession.builder.appName('encrypt_table.py').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))

#if src_filter:
#  spark.sql("MSCK repair table {0}".format(src_table))

# Create Source Landing Table from IDH Table
#spark.sql("create table {} as select * from {}.{}".format(src_table,idh_database,idh_table))

# create DF from source landing table
srcDF = spark.sql("""
   SELECT * FROM {}
""".format(src_table))

#srcDF.printSchema()

# capture list of landing table column names from srcDF

srcColumns = srcDF.columns

#print(srcColumns)

# create DF from table 'idh_column_encryption_spec' for the IDH database, table, and columns to be encrypted

cesDF = spark.sql("""
   SELECT * FROM idh_column_encryption_spec
   WHERE idh_database = '{}'
   AND idh_tab_name = '{}'
   AND length(voltage_format) > 0
""".format(idh_database,idh_table))

cesDF.show()

# iterate through column list, joining encryption spec by column name to generate the voltage encryption SQL statement

# initialize an empty temp array to hold the SQL statement lines
lines = []

# for each column name, fetch encryption data (if it exists) into cesRec
for colname in srcColumns:
    cesRec = cesDF.select("idh_col_name","voltage_udf","voltage_format").filter(col("idh_col_name") == colname).collect()
    
# if ces record exixts, write code to call the UDF to encrypt the data in the source column
    if cesRec:
      lines.append(cesRec[0][1] + "(" + cesRec[0][0] + ",'" + cesRec[0][2] + "') as " + cesRec[0][0])
      
# else write code to fetch the data in the source column
    else:
      lines.append(colname + ' as ' + colname)
      

# finish by joining the clauses in temp array and the ending FROM clause into the final SQL statement 

# build the SQL statement starting with INSERT ... SELECT clause, followed by the joined column clauses, FROM clause, ending with optional WHERE clause
voltageSQL = "INSERT OVERWRITE TABLE {}.{} SELECT ".format(hive_db_name,tgt_table) + ",".join(lines) + " FROM {}.{}{}".format(hive_db_name,src_table,src_filter)

# print SQL to STDOUT
print(voltageSQL)


# Create Target Table from Landing Table
spark.sql("create table {} stored as ORC as select * from {}.{} where 1=0".format(tgt_table,hive_db_name,src_table))

#The convention used by Spark to write Parquet data is configurable. This is determined by the property spark.sql.parquet.writeLegacyFormat The default value is false. If set to "true", Spark will use the same convention as Hive for writing the Parquet data. This will help to solve the issue.
spark.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
# execute the SQL
beeline_query = "beeline -u "+'"'+beeline_connection_string+'"'+" -e "+'"'+voltageSQL+'"' 
print(beeline_query)
os.system(beeline_query)
#spark.sql(voltageSQL)

###########################generate mapping file#########################################

#get domain and sub-domain names
df_domain = spark.sql("select domain,sub_domain from idh_table_domain_map where lower(trim(idh_database))='{0}' and lower(trim(idh_table))='{1}'".format(idh_database,idh_table))
domain = df_domain.select("domain").collect()[0][0]
sub_domain = df_domain.select("sub_domain").collect()[0][0]
sub_domain_string = "" if not sub_domain else sub_domain.lower()
loc_suffix =  adls_basepath + domain.lower() + "/" + sub_domain_string + "/" + idh_table.lower() + "/" +migration_id.lower() + "/" 
on_prem_path = hdfs_path + tgt_table  
lne1 = on_prem_path.replace("/", '',1) + "/," + loc_suffix + ",orc"

#create mapping file in current folder
file_name = './' +"move" + migration_id + '.csv'
file1 = open(file_name, "w")   
file1.write(lne1)
file1.close()

print(lne1)

#move mapping file to common folder
os.system("mv "+file_name+" "+mapping_file_folder)

logging.append ("mapping filename:" + mapping_file_folder + "move" + migration_id + '.csv')

logging.append(this_script + ":" + "++++++++Generate eidh__ table ++++++")
logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")



file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

endCmd = "echo " + idh_filter + "," + migration_id + "::END >> " + partition_log_file
os.system(endCmd)

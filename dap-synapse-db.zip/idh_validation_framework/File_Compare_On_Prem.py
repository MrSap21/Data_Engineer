from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys
from pyspark.sql import functions as F
from pyspark.sql.functions import first
from pyspark.sql.functions import *

#spark-submit --executor-memory 6G --driver-memory 6G File_Compare_On_Prem.py /data/dnaphase2/source/db/dna_phase2/ dna_phase2 frm202103160049 10000

##############variables that can be configured###################
this_script  = sys.argv[0]
#set main folder path in Hive
hive_table_path = sys.argv[1]
#Hive DB Name
hive_db_name = sys.argv[2]
#migration id
migration_id = sys.argv[3]
database_name = sys.argv[4]
table_name = sys.argv[5]
#idh where clause
idh_where_clause = sys.argv[6]
#validation where clause
validation_where_clause = sys.argv[7]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:hive table path: \'' + hive_table_path + '\'')

#create Spark Session     
spark = SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName("File_Compare_On_Prem").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
#create Spark context
sc=spark.sparkContext
#create Hadoop file system class
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())

#metadata table name for migration id

metadata_table_for_row_counts = "idh_rowcount_"+migration_id

logging.append("metadata_table for row counts : " +metadata_table_for_row_counts)

#get row count for each table from metadata table for row counts
df_metadata_row_counts = spark.sql("select database_name,table_name,row_count from "+metadata_table_for_row_counts)
#register temp table for metadata row counts
df_metadata_row_counts.registerTempTable("table_row_counts")

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),             
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

#function to insert record into idh_validationstatus table
def insertIntoValidationStatusTable(databasename,source,result_detail,validation_type,validation_status,source_row_count,destination_row_count):
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')    
    
    new_row = spark.createDataFrame([(databasename,source,encrypted_file_path,migration_step,validation_step+validation_type,validation_status,result_detail,source_row_count,destination_row_count,migration_id,current_time)], schema=schema)
    
    new_row.createOrReplaceTempView("VS_DF_TEMP_VIEW")
    VS_DF_NEW = spark.sql("select td_database,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,migration_id,validation_execution_time FROM VS_DF_TEMP_VIEW ")
    #Write the DataFrame to ValidationStatus Table
    VS_DF_NEW.write.insertInto('idh_validationstatus'+"_"+migration_id,overwrite = False)
        
#decrypt parquet
def decryptParquet(databasename,tablename,file_df_parquet):

    colstrdy=""
    collist=[]
    
    #encryption spec table name
    col_enc_spec_table = "idh_column_encryption_spec"
    logging.append("col_enc_spec_table : " +col_enc_spec_table)

    
    #get encryption details for the td table and db from column_encryption_spec_<migrationId> table
    columndf = spark.sql("select idh_tab_name,idh_col_name,voltage_udf_de from {2}  where lower(idh_database)= lower('{0}') and lower(idh_tab_name)=lower('{1}')".format(databasename,tablename,col_enc_spec_table))

    #get the list of all columns in parquet file dataframe
    df_column_list = file_df_parquet.schema.names
    
    #get the list of columns and the corresponding voltage udf to decrypt the column data
    collist=(columndf.groupby(columndf.idh_tab_name).pivot("idh_col_name").agg(first("voltage_udf_de")))
    collist=collist.schema.names
    collist.remove("idh_tab_name")
  
    #get the data for the td table and db from column_encryption_spec_<migrationId> table into a dataframe
    DF_DEC_FUN_PARAM = spark.sql("select idh_tab_name,idh_col_name,voltage_udf_de,voltage_format_de from {2}  where lower(idh_database)= lower('{0}') and lower(idh_tab_name)=lower('{1}')".format(databasename,tablename,col_enc_spec_table));
    DF_DEC_FUN_PARAM.show()
         

    #for i in range(len(collist)):
    for i in range(len(df_column_list)):
            if(len(colstrdy) != 0):
                colstrdy = colstrdy +" "+","+" "
            if df_column_list[i] in collist:
                df_dec = DF_DEC_FUN_PARAM.filter(DF_DEC_FUN_PARAM.idh_col_name == df_column_list[i])
                list1=df_dec.rdd.map(lambda x: (str(x[2]),str(x[3]))).collect()
                for items in list1:
                    vol_func = items[0]
                    vol_func_format = items[1]
                if vol_func != "":   
                    colstrdy = colstrdy+vol_func+"("+df_column_list[i]+",'"+vol_func_format+"') as "+df_column_list[i]
                else:
                    colstrdy = colstrdy+" "+df_column_list[i]+" as "+df_column_list[i]
            else:
                colstrdy = colstrdy+" "+df_column_list[i]+" as "+df_column_list[i]
           
    print(colstrdy) 
    file_df_parquet.registerTempTable("table_parquet")
     
    if colstrdy=="":
        return file_df_parquet
    else:    
        dfen=spark.sql("select {0} from table_parquet".format(colstrdy))
        return dfen
    

logging.append("database name : " +database_name)
logging.append("table name: "+ table_name)

#generate extracted table and file paths using predefined format
landing_table_name = "lidh__"+database_name.lower()+"__"+table_name.lower() 
encrypted_table_name = "eidh__"+database_name.lower()+"__"+table_name.lower()+"__"+migration_id

landing_file_path = hive_table_path+landing_table_name  
encrypted_file_path = hive_table_path+encrypted_table_name
  
#validation and migratio step details for validation status table
validation_step = "LandingVsEncryptedDataComparison"
migration_step = "CreateEncryptedFile"

logging.append("landing file path : "+ landing_file_path)
logging.append("encrypted file path parquet : "+ encrypted_file_path)
logging.append("landing table name :" + landing_table_name)
logging.append("encrypted table name :" + encrypted_table_name)
    
path_landing = sc._jvm.org.apache.hadoop.fs.Path(landing_file_path)
path_encrypted = sc._jvm.org.apache.hadoop.fs.Path(encrypted_file_path)

#generate where clause
where_clause=""
if validation_where_clause == '""':
    insertIntoValidationStatusTable(database_name,table_name,"ValidationWhereClauseIsEmpty","","Unverified",None,None)        
    insertIntoValidationStatusTable(database_name,table_name,"ValidationWhereClauseIsEmpty","","Unverified",None,None)
    print("Where clause not provided for validation")
    sys.exit(0)
elif idh_where_clause == '""':
    where_clause=" where "+validation_where_clause
else:
    input_filter_string = idh_where_clause.replace("'","")
    split_string = input_filter_string.split("=")
    filter_string = split_string[0]+ " like " + "'" + split_string[1] + "%'"
    where_clause=" where "+validation_where_clause+" and "+filter_string

#check if encrypted Parquet file exists in the location    
if fs.exists(path_encrypted):
    if len(fs.listStatus(path_encrypted)) > 0:
    
        #read landing table    
	print(where_clause)
        file_df_landing = spark.sql("select * from {0} {1}".format(landing_table_name,where_clause))
        
        file_df_encrypted = spark.sql("select * from {0} {1}".format(encrypted_table_name,where_clause))
        #file_df_parquet = spark.read.parquet(file_path_parquet)       
                
        #compare row counts in metadata and CSV
        parquet_table_row_count = spark.sql("select row_count from table_row_counts where lower(database_name)=lower('{0}') and lower(table_name)=lower('{1}')".format(hive_db_name,landing_table_name)).collect()[0][0]
        csv_table_row_count = spark.sql("select row_count from table_row_counts where lower(database_name)=lower('{0}') and lower(table_name)=lower('{1}')".format(hive_db_name,encrypted_table_name)).collect()[0][0]
        
        result_detail=validation_where_clause           
       
        #compare column counts
        if len(file_df_landing.columns) == len(file_df_encrypted.columns) and csv_table_row_count == parquet_table_row_count:
            
            #decrypt encrypted columns
            file_df_decrypted = decryptParquet(database_name,table_name,file_df_encrypted)
            
            #check the difference of the two dataframes
            #file_df_landing2=file_df_landing.select(*(trim(col(c)).alias(c) for c in file_df_landing.columns))
            #file_df_decrypted2=file_df_decrypted.select(*(trim(col(c)).alias(c) for c in file_df_decrypted.columns))
            #compare_df = file_df_landing2.subtract(file_df_decrypted2)
            compare_df = file_df_landing.subtract(file_df_decrypted)
            
            if compare_df.count() == 0:
                validation_status = "Success"
            else:
                validation_status = "Failure"
            
        else:                
            print("counts not matching")           
            validation_status = "Failure"
        logging.append("validation status :" + validation_status)         
        
        #create dataframe for new row in ValidationStatus Table    
        
        insertIntoValidationStatusTable(database_name,landing_file_path,result_detail,"",validation_status,None,None)
        
        
    else:
        insertIntoValidationStatusTable(database_name,table_name,"EmptyFolder","","Failure",None,None)        
        insertIntoValidationStatusTable(database_name,table_name,"EmptyFolder","","Failure",None,None)

else:        
    insertIntoValidationStatusTable(database_name,table_name,"FolderDoesNotExist","","Failure",None,None)        
    insertIntoValidationStatusTable(database_name,table_name,"FolderDoesNotExist","","Failure",None,None)

logging.append ("Job:++++" + this_script + " STOP ++++++++")

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()

spark.stop()
    




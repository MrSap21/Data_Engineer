#!/bin/bash

## comment


# ############Enviorenment Var#####
# export JAVA_HOME=/usr/jdk64/jdk1.8.0_60;
# export PATH=$PATH:/usr/jdk64/jdk1.8.0_60;
# export HADOOP_HOME=/usr/hdp/2.6.4.0-91/hadoop;
# export PATH=$PATH:/usr/hdp/2.6.4.0-91/hadoop;
# export LIBHDFS_CLASSPATH=$(hadoop classpath --glob);
# export HTTPS_PROXY=corppac.walgreens.com:8080;
# export HTTP_PROXY=corppac.walgreens.com:8080;
# export SPARK_MAJOR_VERSION=2
# ###################

source ../historical_data_migration/td_migration/dependencies_dev.sh

hive_db_name=$1
hdfs_path=$2
migration_id=$3
database_name=$4
table_name=$5
idh_where_clause=$6
validation_where_clause=$7

if [ -z "$idh_where_clause" ]
then
  idh_where_clause=\"\"
fi

if [ -z "$validation_where_clause" ]
then
  validation_where_clause=\"\"
fi

echo $hive_db_name
echo $migration_id
echo $hdfs_path
echo $database_name
echo $table_name
echo $log_file_path
echo $idh_where_clause
echo $validation_where_clause

mapping_folder="/tmp/copytoadls/uat/idhvalidationmapping/"
echo $mapping_folder

adls_folder="/common/idh_tframework/tf_validationtables/"
echo $adls_folder

adls_checksum_folder="/common/idh_tframework/tf_checksumonpremfiles"
echo $adls_checksum_folder

mkdir -p validation_logs

##Generate validation tables in Hive
spark-submit Gen_Validation_Tables.py $migration_id $hive_db_name $hdfs_path

##Insert row counts from migration log to rowcount_<migration_id> table
spark-submit Log_Row_Counts.py $hdfs_path $hive_db_name $migration_id $database_name $table_name $idh_where_clause

##calculate min max avg for numeric columns
spark-submit Gen_Min_Max_Avg.py $hive_db_name $migration_id $database_name $table_name $idh_where_clause

##compare csv and parquet file data
spark-submit --executor-memory 6G --driver-memory 6G File_Compare_On_Prem.py $hdfs_path $hive_db_name $migration_id $database_name $table_name $idh_where_clause $validation_where_clause

##generate checksum file for parquet files
spark-submit Gen_Checksum.py $hdfs_path $migration_id $database_name $table_name $adls_checksum_folder

##generate mapping file for validation tables
spark-submit Convert_Table_To_Parquet.py $hive_db_name $hdfs_path $migration_id $mapping_folder $adls_folder


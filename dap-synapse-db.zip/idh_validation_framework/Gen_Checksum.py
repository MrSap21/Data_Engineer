# -*- coding: utf-8 -*-
"""

Python script to generate checksum

01/05/2022 - Teena Kappen - Initial creation

"""

import hashlib
import os
import sys
from os.path import isfile
from pyspark.sql import SparkSession
from pyspark.sql.types import *
import subprocess

##############variables that can be configured###################
this_script  = sys.argv[0]
#Hive Folder Path
hive_table_path=sys.argv[1]
#migration id
migration_id =sys.argv[2]
#DB Name
database_name=sys.argv[3]
#Table Name
table_name=sys.argv[4]
#adls_folder
adls_sub_folder = sys.argv[5]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:database name: \'' + database_name + '\'')
logging.append(this_script + ":" + 'JobParams:table name: \'' + table_name + '\'')
logging.append(this_script + ":" + 'JobParams:hive_table_path: \'' + hive_table_path + '\'')

#manifest output file path
manifest_file='./idh_checksum_'+migration_id+'.csv'

logging.append("Manifest file : "+ manifest_file)

#open output file
output_file = open(manifest_file, "w")

#generate extracted file path using predefined format   
hdfs_file_path = hive_table_path+"eidh__"+database_name.lower()+"__"+table_name.lower()+"__"+migration_id
logging.append("HDFS file path : " + hdfs_file_path)

file_array = hdfs_file_path.split('/')
file_name = file_array[len(file_array) - 1]
    	
args = "hdfs dfs -ls "+hdfs_file_path+" | awk '{print $8}'"
proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
s_output, s_err = proc.communicate()
files = s_output.split()
            
for item in files:
    md5_args = "hdfs dfs -cat "+item+" | md5sum | awk '{print $1}'"
    proc = subprocess.Popen(md5_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    md5_output, md5_err = proc.communicate()
    md5value = md5_output.split()[0]           		                    
    value = str(md5value)+" "+item+"\n"      
    output_file.write(value)     
     
output_file.close()   

logging.append ("Job:++++" + this_script + " STOP ++++++++")

#move to HDFS path
hdfs_location=hive_table_path+"testframework/idh_checksum_"+migration_id
os.system("hdfs dfs -mkdir -p "+hdfs_location)
os.system("hdfs dfs -rm "+hdfs_location+"/checksum.csv")
os.system("hdfs dfs -put "+manifest_file +' '+hdfs_location+"/checksum.csv")
os.system("rm "+manifest_file)

logging.append("HDFS Location of Checksum File : "+ hdfs_location)

#update mapping file
mapping_file = "./TFmapping_"+migration_id+".csv"
print(mapping_file)
logging.append("Mapping Filename : "+ mapping_file)

f = open(mapping_file, "w")

f.write(hdfs_location+","+ adls_sub_folder+"/idh_checksum_"+migration_id+"/"+"\n")    

f.close()

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close() 






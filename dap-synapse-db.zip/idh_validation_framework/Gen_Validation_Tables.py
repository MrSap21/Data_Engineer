# -*- coding: utf-8 -*-
"""

Pyspark script to create Framework tables having names tagged with Migration ID

Params: Migration ID, Hive DB name, HDFS folder path

table name = <table name>_<migration_id>

01/06/2022 - Teena Kappen - Initial creation

"""

from pyspark.sql import SparkSession
import sys
import os
import subprocess

# process parms
nargs = len(sys.argv)

if nargs != 4: 
	print('Usage:' + sys.argv[0] + ' <Migration ID> <Hive DB name> <HDFS folder path>') 
	print('For manual execution, choose a unique Migration ID, or supply Migration ID  from an existing Migration')
	exit(-1)

this_script  = sys.argv[0]
migration_id = sys.argv[1]   
hive_db_name = sys.argv[2]
hdfs_path    = sys.argv[3]

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:HDFS folder path: \'' + hdfs_path + '\'')

# get a Spark Session
spark=SparkSession.builder.appName('Gen_Validation_Tables').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))

validationstatus_DDL = """
CREATE TABLE IF NOT EXISTS idh_validationstatus_{}(
database_name  varchar(256),
source varchar(500),                                               
destination varchar(1000),                                         
migration_step varchar(128),                                        
validation_type varchar(128),                                       
validation_status varchar(128),                                     
result_details varchar(1000),
source_row_count bigint,
destination_row_count bigint,
migration_id  varchar(128),
validation_execution_time timestamp                                  
)
""".format(migration_id)

# Hive DDL for table minmaxavg

minmaxavg_DDL = """
CREATE TABLE IF NOT EXISTS idh_minmaxavg_{} (
database_name  varchar(256),
table_name varchar(256),
column_name varchar(256), 
avg decimal(12,2),
min decimal(12,2),
max decimal(12,2))
""".format(migration_id)

# Hive _DDL for table rowcount

rowcount_DDL = """
CREATE TABLE IF NOT EXISTS idh_rowcount_{} (
database_name  varchar(256),
table_name varchar(256),
row_count bigint,
filter_clause varchar(1000))
""".format(migration_id)

# log the DDL
logging.append(validationstatus_DDL)
logging.append(minmaxavg_DDL)
logging.append(rowcount_DDL)

# create the tables
#check if table exists in Hive
def dropTable(table_prefix):
  table_exists = bool(spark.sql("show tables like '{}_{}'".format(table_prefix,migration_id)).count())
  
  #check if table exists in the location    
  if bool(table_exists): 
    spark.sql("drop table {}_{}".format(table_prefix,migration_id))  


dropTable('idh_validationstatus')
dropTable('idh_minmaxavg')
dropTable('idh_rowcount')
spark.sql(validationstatus_DDL)
spark.sql(minmaxavg_DDL)
spark.sql(rowcount_DDL)

logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.close()

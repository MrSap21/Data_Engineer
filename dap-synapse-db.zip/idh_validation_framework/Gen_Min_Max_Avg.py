import subprocess
import os
from pyspark.sql import SparkSession
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import upper
import sys


"""
Validation_Avg_Min_Max.py

Pyspark -column for Min Max Avg
Parms: database, table 

01/13/2022 - Puneet Jaiswal - Initial creation

Assuming we can access the idh_database from 20 Node and min_max_avg table would be on 20 node cluster

spark-submit ./idh_min_max_avg.py "dae_work" "dna_phase2" "dim_loyalty_customer" "foo2202112100425"
 

"""
nargs = len(sys.argv)

if nargs != 6: 
	print('Usage: file_min_max_avg.py <migrationid> <hive_db_name> <td_inscopedb_name> <tablename>')
	print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
	exit(-1)
    
this_script = sys.argv[0]
hive_db_name = sys.argv[1]
migrationId = sys.argv[2]
idh_databasename = sys.argv[3]
idh_table_name = sys.argv[4]
#idh where clause
idh_where_clause = sys.argv[5]


minmaxavg_table = "idh_minmaxavg_"+migrationId



filelog = "./validation_logs/validation_" + migrationId + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Minmaxavg table: \'' + minmaxavg_table + '\'')


#get where clause
if idh_where_clause != '""':
  input_filter_string = idh_where_clause.replace("'","")
  split_string = input_filter_string.split("=")
  filter_string = split_string[0]+ " like " + "'" + split_string[1] + "%'"
  idh_where_clause = " where "+filter_string
else:
  idh_where_clause = " where 1=1"


spark=SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName('app1').enableHiveSupport().getOrCreate()


dtyp_aggregate=["BIGINT","LONG","DECIMAL","DOUBLE","FLOAT" ,"INT" ,"INTEGER" , "SMALLINT" ,"TINYINT"]
#print (dtyp_aggregate)
sqlstmt = ""
i=1
lst_col = []
spark.sql("use {0}".format(hive_db_name))
landing_table_name = "lidh__"+idh_databasename.lower()+"__"+idh_table_name.lower() 
df=spark.sql("select * from {0}.{1} {2}".format(hive_db_name,landing_table_name,idh_where_clause))
df.createOrReplaceTempView("table_view")
lst=df.dtypes
for item in lst:
  col_de=str(item).split(",")
  col_dtype=col_de[1].replace(")","")
  col_dtype=col_dtype.replace("'","")
  f_dtype=col_dtype.upper()
  col_name = col_de[0].replace("(","")
  col_name_f = col_name.replace("'","")
  column_details = col_name_f
  if f_dtype.strip() in dtyp_aggregate:
    lst_col.append(column_details)
print ("========")
print (lst_col)
print ("======")
for col_a in lst_col:
  if len(lst_col) > i:
    sqlstmt = sqlstmt +"select "+"'"+col_a+"'"+" as Column_Name "+","+"min("+col_a+") as min_value" + "," +"max("+col_a+") as max_value" +","+"avg("+col_a+") as avg_value"+" from table_view"+"\n"
    sqlstmt = sqlstmt+"union all"+"\n"
  else:
    sqlstmt = sqlstmt +"select "+"'"+col_a+"'"+ " as Column_Name "+","+"min("+col_a+") as min_value" + "," +"max("+col_a+") as max_value" +","+"avg("+col_a+") as avg_value"+" from table_view"+"\n"
  i= i+1
print (sqlstmt)

logging.append ("stmt:++++" + sqlstmt + " sqlstmt Genrated ++++++++")


df_new=spark.sql(sqlstmt)
#sdmf.show()      
df_new=df_new.withColumn("Table_name",lit(idh_table_name)).withColumn("Db_Nmae",lit(idh_databasename))
df_new.show()
df_new.createOrReplaceTempView("smdf_temp_view")
df_new = spark.sql("select  Db_Nmae as database_name,Table_name as table_name,Column_Name as column_name,avg_value as avg, min_value as min, max_value as max FROM smdf_temp_view ")
#sdmf_new.printSchema()
print ("before insert")
df_new.write.insertInto(minmaxavg_table)
print ("after insert")

logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()

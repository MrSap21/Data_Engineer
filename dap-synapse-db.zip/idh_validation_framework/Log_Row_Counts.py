from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys
from pyspark.sql.functions import *

##############variables that can be configured###################
this_script  = sys.argv[0]
#set main folder path in Hive
hive_table_path = sys.argv[1]
#Hive DB Name
hive_db_name = sys.argv[2]
#migration id
migration_id = sys.argv[3]
database_name = sys.argv[4]
table_name = sys.argv[5]
#idh where clause
idh_where_clause = sys.argv[6]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:hive table path: \'' + hive_table_path + '\'')

#get where clause
if idh_where_clause!='""':
  input_filter_string = idh_where_clause.replace("'","")
  split_string = input_filter_string.split("=")
  filter_string = split_string[0]+ " like " + "'" + split_string[1] + "%'"
  idh_where_clause = " where "+filter_string
else:
  idh_where_clause = ""

#create Spark Session     
spark = SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName("Log_Row_Counts").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
#create Spark context
sc=spark.sparkContext
#create Hadoop file system class
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())

logging.append("table for row counts : idh_rowcount_" +migration_id)

#schema for output dataframe
schema = StructType([
             StructField('database_name', StringType()),             
             StructField('table_name', StringType()),
             StructField('row_count', LongType()),
             StructField('filter_clause', StringType())        
            ])

#function to insert record into Validationstatus table
def insertIntoRowCountTable(database_name,table_name,filter_clause):
    
    print("filter clause: "+filter_clause+ " length: "+str(len(idh_where_clause)))
    row_count = spark.sql("select count(*) from {0}.{1} {2}".format(database_name,table_name,filter_clause)).collect()[0][0]
    new_row = spark.createDataFrame([(database_name,table_name,row_count,filter_clause)], schema=schema)
    
    new_row.createOrReplaceTempView("VS_DF_TEMP_VIEW")
    VS_DF_NEW = spark.sql("select database_name,table_name,row_count,filter_clause FROM VS_DF_TEMP_VIEW ")
    #Write the DataFrame to ValidationStatus Table
    VS_DF_NEW.write.insertInto("idh_rowcount_"+migration_id,overwrite = False)


logging.append("IDH database name : " +database_name)
logging.append("IDH table name: "+ table_name)

#generate extracted table and file paths using predefined format
landing_table_name = "lidh__"+database_name.lower()+"__"+table_name.lower() 
encrypted_table_name = "eidh__"+database_name.lower()+"__"+table_name.lower()+"__"+migration_id

logging.append("landing table name :" + landing_table_name)
logging.append("encrypted table name :" + encrypted_table_name)

#insertIntoRowCountTable(database_name,table_name,idh_where_clause)
insertIntoRowCountTable(hive_db_name,landing_table_name,idh_where_clause)
insertIntoRowCountTable(hive_db_name,encrypted_table_name,idh_where_clause) 

logging.append ("Job:++++" + this_script + " STOP ++++++++")

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()

spark.stop()
    




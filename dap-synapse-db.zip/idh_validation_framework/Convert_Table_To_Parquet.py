from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys
import os

#spark-submit Convert_Table_To_Parquet.py dna_phase2 /data/dnaphase2/source/db/dna_phase2/ frm202103160049 92cb778e-8ba7-4f34-a011-4ba6e7366996 79b492f4-9f1f-4b7a-ae27-bb757857e43a

##############variables that can be configured###################
this_script  = sys.argv[0]
#Hive DB Name
hive_db_name = sys.argv[1]
#HDFS Path
hdfs_path = sys.argv[2]
#migration id
migration_id =sys.argv[3]
#mapping folder path
mapping_folder_path = sys.argv[4]
#adls_folder
adls_sub_folder = sys.argv[5]

##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:hdfs path: \'' + hdfs_path + '\'')
logging.append(this_script + ":" + 'JobParams:mapping folder path: \'' + mapping_folder_path + '\'')
logging.append(this_script + ":" + 'JobParams:adls folder path: \'' + adls_sub_folder + '\'')

os.system('mkdir -p '+mapping_folder_path)
os.system('chmod -R 777 '+mapping_folder_path)
file_name = "./TFmapping_"+migration_id+".csv"
print(file_name)
logging.append("Filename : "+ file_name)
tmp_file = mapping_folder_path+"TFmapping_"+migration_id+".csv"

#create Spark Session     
spark = SparkSession.builder.appName("Convert_Table_To_Parquet").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
f = open(file_name, "a")

def processFile(table_name):
    
    df = spark.sql("select * from {}".format(table_name))
    if table_name == "idh_table_domain_map":
	    table_name=table_name+"_"+migration_id
    parquet_file=hdfs_path+"testframework/"+table_name
    df.repartition(1).write.mode('overwrite').parquet(parquet_file)   
    f.write(parquet_file+","+ adls_sub_folder+table_name+"/"+"\n")    

processFile("idh_minmaxavg_"+migration_id)
processFile("idh_rowcount_"+migration_id)
processFile("idh_validationstatus_"+migration_id)
processFile("idh_table_domain_map")

f.close()

os.system("mv "+file_name +' '+tmp_file)
os.system("touch -m "+mapping_folder_path)

logging.append ("Job:++++" + this_script + " STOP ++++++++")

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()  


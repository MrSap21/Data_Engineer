# -*- coding: utf-8 -*-
"""
Refresh_Metadata_Dictionary_Synapse.py

Pyspark script to generate a new version of the 'historical_ddl_map' table, overwriting any existing data.
This script uses table 'teradatametadata' as the main driver, joined to tables 'col_type_xref', 'column_encryption_spec',
'np_synapse_metadata' to derive reference metadata used by the various Generator scripts to create the executable
Migration Components, text files of type ddl, sql, cfg, etc. required to accomplish the Historicala Data Migration
from on-premise Teradata to Azure Synapse.

01/25/2021 - Carter Shore - Initial creation of .sql version
03/05/2021 - Teena Kappen - Converted to .py
03/14/2021 - Carter Shore - Revised for new Synapse metadata export, and for revised 'historical_ddl_map' table with
             new column 'sv_is_identity'.
03/20/2021 - Carter Shore - Lowercase all database, table, and column names in order to provide a consistent case
             for SQL and filename generation and comparison.
03/24/2021 - Anonymous - Added another Quality check for tables synapse_metdata and col_encryption_spec 
04/06/2021 - Carter Shore - Revised hv_col_size derivation for ORC tables, type 'string' does not have a size component. 
             Only Teradata CHARACTER types will require a size component specification in Hive ORC tables.
04/07/2021 - Carter Shore - Revised hv_col_size derivation for ORC tables, type 'character' does not have a size component. 
04/09/2021 - Carter Shore - Revised column size derivations of pq_, pb_, sy_ tables due to Sqoop ORC mapping of Teradata 
             DATE/TIME/TIMESTAMP types.
04/29/2021 - Carter Shore - Revised for Snowflake. Revised tables 'col_type_xref', 'historical_ddl_map', new table 'snowflake_metadata'
05/24/2021 - Carter Shore - Modify for generating SnowFlake components, based on Teradata only, ignoring Synapse and Whitelist.
06/01/2021 - Carter Shore - Restore mapping from table 'column_encryption_spec' for Voltage Encryption.
06/28/2021 - Carter Shore - Modify to populate column new 'sf_database' in table historical_ddl_map_<migrationID>


Parms: migrationId, TD database spec, TD table spec

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
import os
import sys

# process parms
nargs = len(sys.argv)
print(nargs)
if nargs != 4: 
	print('Usage: Refresh_Metadata_Dictionary_Synapse.py <migrationID> <Hive DB>')
	print("Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card")
	exit(-1)

# Hive SQL statement to generate Hive Parquet table DDL for the Voltage encrypted data
# Parms: database, table 

# source table name = TD_<database>__<table>
# target table name = PQ_<database>__<table>
# generated component name = PQ_<database>__<table>.ddl


this_script = sys.argv[0]
migration_id = sys.argv[1].lower()
hive_db_name = sys.argv[2]
migration_env = sys.argv[3]

recoverfilename = "./logs/" + migration_id + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;

print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       if len(ln.strip()) > 0:
          splt = ln.split("::")
          if splt[1] == "END":
             print "this step  is over"
             sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" +  'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migration_id + '\'')
fileName = "./logs/" + migration_id + ".log"
file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

logging = []


# get a Spark Session
spark=SparkSession.builder.appName('SQL_runner').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

### Quality check

#sql1 = """select LOWER(TRIM(sym.table_schema)) , LOWER(TRIM(sym.table_name)),  LOWER(TRIM(sym.column_name)), count(*)
# from synapse_metadata_{}  sym group by LOWER(TRIM(sym.table_schema)) , LOWER(TRIM(sym.table_name)),  LOWER(TRIM(sym.column_name))
#having count(*) > 1""".format(migration_id)
#
#
#sql11 = """select LOWER(TRIM(ces.td_database)), LOWER(TRIM(ces.td_tab_name)), LOWER(TRIM(ces.td_col_name)) , count(*) 
#from column_encryption_spec_{0} ces where TRIM(ces.td_database) != '' group by LOWER(TRIM(ces.td_database)), LOWER(TRIM(ces.td_tab_name)), LOWER(TRIM(ces.td_col_name))  
#having count(*) > 1""".format(migration_id)
#
#metadataerror = False
#list1 = spark.sql(sql1).collect()
#list2 = spark.sql(sql11).collect()
#if len(list1) > 0:
#   logging.append("Error in synapse metadata")
#   for rw in list1:
#       loggging.append(rw)
#   metadataerror = True
#   print("Error in synapse metadata")
#if len(list2) > 0:
#   logging.append("Error in encryption spec")
#   for rw in list2:
#       loggging.append(rw)
#   metadataerror = True
#   print("Error in encryption spec")
errorFile = "./logs/" + migration_id + ".err"
#
#if metadataerror == True:
#   for ln in logging:
#       file1.write(ln + "\n")
#   file1.close()
#   logging = []
#   cmd2 = "echo " + this_script + ":0" + ">> " + errorFile 
#   os.system(cmd2)
#   sys.exit(0)
#
#### Quality CHeck
#sql2 = """select  * from source_target_cross_ref  tgt, synapse_metadata_{}  sym
#where LOWER(TRIM(tgt.target_schema_name )) = LOWER(TRIM(sym.table_schema))
#      and LOWER(TRIM(tgt.target_table_name)) = LOWER(TRIM(sym.table_name))
#      and tgt.white_list = 'Y'""".format(migration_id)
#
#df1 = spark.sql(sql2)
#df1.createGlobalTempView("mapm1");

historical_ddl_SQL = """INSERT OVERWRITE
TABLE
historical_ddl_map_{0}
SELECT * from global_temp.hist_ddl""".format(migration_id)

selectSQL = """SELECT
LOWER(nvl(TRIM(tdm.databasename),"ERROR")) as td_database,
LOWER(nvl(TRIM(tdm.tablename),"ERROR")) as td_tab_name,
"table" as td_tab_type,
LOWER(cast(tdm.columnid AS string)) as td_col_order,
LOWER(nvl(TRIM(tdm.columnname),"ERROR")) as td_col_name,
LOWER(nvl(TRIM(tdm.columntype),"ERROR")) as td_col_type,
LOWER(nvl(TRIM(tdm.columnformat),"ERROR")) as td_col_size,
LOWER(cast(tdm.columnlength AS string)) as td_col_length,
LOWER(nvl(TRIM(tdm.nullable),"ERROR")) as td_notnull,
LOWER(nvl(TRIM(tdm.databasename),"ERROR")) as hv_schema,
LOWER(nvl(TRIM(tdm.tablename),"ERROR")) as hv_tab_name,
LOWER(cast(tdm.columnid AS string)) as hv_col_order,
LOWER(nvl(TRIM(tdm.columnname),"ERROR")) as hv_col_name,
LOWER(nvl(TRIM(ctx.hv_type),"ERROR")) as hv_col_type,
CASE nvl(TRIM(ctx.td_type),"ERROR")
   WHEN 'ERROR' THEN 'ERROR'
   ELSE ""
END as hv_col_size,
IF(nvl(TRIM(tdm.nullable),"ERROR") = 'N',"NOT NULL","") as hv_notnull,

LOWER(nvl(TRIM(tdm.databasename),"ERROR")) as pq_schema,
LOWER(nvl(TRIM(tdm.tablename),"ERROR")) as pq_tab_name,
LOWER(cast(tdm.columnid AS string)) as pq_col_order,
LOWER(nvl(TRIM(tdm.columnname),"ERROR")) as pq_col_name,
LOWER(nvl(TRIM(ctx.pq_type),"ERROR")) as pq_col_type,
CASE nvl(TRIM(ctx.td_type),"ERROR")
   WHEN 'CHARACTER' THEN concat('(',nvl(tdm.columnlength,'0'),')')
   WHEN 'DATE' THEN '(10)'
   WHEN 'DECIMAL' THEN concat('(',tdm.decimaltotaldigits,',',tdm.decimalfractionaldigits,')')
   WHEN 'PERIOD_DATE' THEN concat('(',length(nvl(TRIM(tdm.columnformat),'')),')')
   WHEN 'PERIOD_TIMESTAMP_n_WITH_TIME_ZONE' THEN concat('(',length(nvl(TRIM(tdm.columnformat),'')),')')
   WHEN 'TIME' THEN '(8)'
   WHEN 'TIME WITH TIME ZONE' THEN concat('(',length(nvl(TRIM(tdm.columnformat),'')),')')
   WHEN 'TIMESTAMP' THEN '(19)'
   WHEN 'TIMESTAMP WITH TIME ZONE' THEN concat('(',length(nvl(TRIM(tdm.columnformat),'')),')')
   WHEN 'VARCHAR' THEN concat('(',nvl(tdm.columnlength,'0'),')')
   WHEN 'ERROR' THEN 'ERROR'
   ELSE ""
END as pq_col_size,
IF(nvl(TRIM(tdm.nullable),"ERROR") = 'N',"NOT NULL","") as pq_notnull,

NULL as pb_schema,
NULL as pb_tab_name,
NULL as pb_col_order,
NULL as pb_col_name,
NULL as pb_col_type,
NULL as pb_col_size,
NULL as pb_notnull,

NULL as sy_schema,
NULL as sy_tab_name,
NULL as sy_col_order,
NULL as sy_col_name,
NULL as sy_col_type,
NULL as sy_col_size,

NULL as sy_notnull,
LOWER(nvl(TRIM(tsm.sf_database),"ERROR")) as sf_database,
LOWER(nvl(TRIM(tsm.sf_schema),"ERROR")) as sf_schema,
LOWER(nvl(TRIM(tsm.sf_table),"ERROR")) as sf_tab_name,
LOWER(cast(tdm.columnid AS string)) as sf_col_order,
LOWER(nvl(TRIM(tdm.columnname),"ERROR")) as sf_col_name,
LOWER(nvl(TRIM(ctx.sf_type),"ERROR")) as sf_col_type,
CASE nvl(TRIM(ctx.td_type),"ERROR")
   WHEN 'CHARACTER' THEN concat('(',nvl(tdm.columnlength,'0'),')')
   WHEN 'DATE' THEN ''
   WHEN 'DECIMAL' THEN concat('(',tdm.decimaltotaldigits,',',tdm.decimalfractionaldigits,')')
   WHEN 'PERIOD_DATE' THEN ''
   WHEN 'PERIOD_TIMESTAMP_n_WITH_TIME_ZONE' THEN ''
   WHEN 'TIME' THEN ''
   WHEN 'TIME WITH TIME ZONE' THEN ''
   WHEN 'TIMESTAMP' THEN ''
   WHEN 'TIMESTAMP WITH TIME ZONE' THEN ''
   WHEN 'VARCHAR' THEN concat('(',nvl(tdm.columnlength,'0'),')')
   WHEN 'ERROR' THEN 'ERROR'
   ELSE ""
END as sf_col_size,
IF(nvl(TRIM(tdm.nullable),"ERROR") = 'N',"NOT NULL","") as sf_notnull,

TRIM(coalesce(ces.voltage_udf,"")) as voltage_encrypt_udf,
TRIM(coalesce(ces.voltage_format,"")) as voltage_encrypt_fmt,
TRIM(coalesce(ces.voltage_udf_de,"")) as voltage_decrypt_udf,
TRIM(coalesce(ces.voltage_format_de,"")) as voltage_decrypt_fmt,

from_unixtime(unix_timestamp()) as change_ts

FROM teradatametadata_{0} tdm
INNER JOIN col_type_xref_{0} ctx
  ON LOWER(TRIM(tdm.columntype))=LOWER(TRIM(ctx.td_type))
LEFT OUTER JOIN column_encryption_spec_{0} ces
  ON LOWER(TRIM(tdm.tablename))=LOWER(TRIM(ces.td_tab_name))
  AND LOWER(TRIM(tdm.columnname))=LOWER(TRIM(ces.td_col_name))
  AND LOWER(TRIM(tdm.databasename))=LOWER(TRIM(ces.td_database))
LEFT OUTER JOIN teradata_snowflake_map tsm
  ON UPPER(TRIM(tdm.tablename))=UPPER(TRIM(tsm.td_table))
  AND LOWER(TRIM(tdm.databasename))=LOWER(TRIM(tsm.td_database))
  AND UPPER(TRIM(tsm.environment))=UPPER(TRIM('{1}'))
""".format(migration_id,migration_env)

df2 = spark.sql(selectSQL).repartition(1)
df2.createGlobalTempView("hist_ddl");

logging.append(historical_ddl_SQL)
spark.sql(historical_ddl_SQL)

outcount = spark.sql("select count(1) from historical_ddl_map_{}".format(migration_id)).collect()[0]['count(1)']


logging.append(this_script + ":" +   "historical_ddl_map_{}".format(migration_id) + " :record_count:" + str(outcount) )
if outcount > 0:
   logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")
else:
   cmd2 = "echo " + this_script + ":0" + ">> " + errorFile
   os.system(cmd2)
   sys.exit(1)

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)
spark.stop()
sys.exit(0)

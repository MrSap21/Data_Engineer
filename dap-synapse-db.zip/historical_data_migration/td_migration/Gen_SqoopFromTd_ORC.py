# -*- coding: utf-8 -*-
"""
Gen_SqoopFromTd.py

Pyspark script to generate Sqoop shell script Components to extract table data from Teradata to a Hive target table.
The Hive target table is named SQ_<td_database>__<td_table>__<migration_id>. 
The shell script Component is named SQ_<td_database>__<td_table>__<migration_id>.sh
The sqoop job creates the target Hive table, ensuring consistency between the Teradata table and Hive table metadata.
Various target table formats can be employed, csv, ORC, RCfile, Parquet, 

Parms: Migration ID, Hive DB, Teradata Databasename spec, Teradata Tablename spec, HDFS base path, 

03/10/2021 - Carter Shore - Initial creation based on script 'run_prod_sqoop.sh' by Volney Stefflre.
03/21/2021 - Carter Shore - Lowercase MigrationID, TD DB pattern, TD Table pattern.
04/06/2021 - Carter Shore - Modify for Sqoop ORC target table named td_<database>__<table>_<migrationId>.

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import os
import sys

# process parms
nargs = len(sys.argv)
print(nargs)

if nargs != 11: 
	print('Usage: Gen_SqoopFromTd.py <MigrationID> <Hive DB> <Teradata DB pattern> <Teradata Table pattern> <HDFS path>')
	print('       <TD DB userid> <TD DB password> <TD dbname> {<Sqoop mapper count>} {<Sqoop fetchsize>}')
	print('Enclose parms having embedded whitespace or punctuation in quotes to protect them from the shell') 
	print('Use object names, or \'%\' as pattern wild-card, or CSV lists of unquoted object names, whitespace is OK')
	print('Example: name1 - selects only DB or Table name equal to name1')
	print("Example: 'name1%' - selects all objects with matching names; 'name1', 'name23', 'name_foo', etc") 
	print("Example: 'name1,name2 , foobar' - ignores whitespace, selects objects named name1, name2, foobar")
	exit(-1)

# lowercase migrationId, database, table
this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()
hdfs_path = sys.argv[5]
userid = sys.argv[6]
password = sys.argv[7]
dbname = sys.argv[8]
mapperCount = sys.argv[9]
fetchSize = sys.argv[10]

print('this_script : ' + this_script)
print('migrationId : ' + migrationId)
print('hive_db_name : ' + hive_db_name)
print('database : ' + database)
print('table : ' + table)
print('hdfs_path : ' + hdfs_path)
print('userid : ' + userid)
print('password : ' + password)
print('dbname : ' + dbname)
print('mapperCount : ' + mapperCount)
print('fetchSize : ' + fetchSize)

fileName = "./logs/" + migrationId + ".log"
# global variable values

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename

logline = "echo " +  this_script + "::TABLE::{},{}:: >> " + recoverfilename

rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
rtableList = {}
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       print(splt)
       if len(ln) > 0:
          if splt[1] == "END":
             print "this step  is over"
             sys.exit(0)
          if splt[1] == "TABLE":
             rtableList[splt[2]] = 1
   os.system(reStartCmd)

print(rtableList)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:HDFS Path: \'' + hdfs_path + '\'')
logging.append(this_script + ":" + 'JobParams:Sqoop mapperCount \'' + mapperCount + '\'')
logging.append(this_script + ":" + 'JobParams:Sqoop fetchSize \'' + fetchSize + '\'')

# Translate database and table parms into SQL 'where clause' filters: single name, name pattern, or CSV name lists

if "," in database:
    databaseWhereClause = (" in ('" + database.replace(" ","").replace(",","','") + "')")
else:
    databaseWhereClause = (" like " + "'" + database.replace(" ","") + "'")

print("databaseWhereClause:" + databaseWhereClause)
logging.append ("databaseWhereClause:" + databaseWhereClause)

if "," in table:
    tableWhereClause = (" in ('" + table.replace(" ","").replace(",","','") + "')")
else:
    tableWhereClause = (" like " + "'" + table.replace(" ","") + "'")

print("tableWhereClause:" + tableWhereClause)
logging.append ("tableWhereClause:" + tableWhereClause)

# Get a Spark Session
spark=SparkSession.builder.appName('app1').enableHiveSupport().getOrCreate()

# Set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

# From table historical_ddl_map, fetch hdm records filtered by database & table where clauses
hdmSQL = """
   SELECT max(cast(td_col_order AS INT)) over (partition by td_database, td_tab_name) as col_max,
   '{0}' as migration_id, * 
   FROM historical_ddl_map_{0} WHERE td_database{1} AND td_tab_name{2} 
   order by td_database,td_tab_name,td_col_order
""".format(migrationId,databaseWhereClause,tableWhereClause.lower())
print hdmSQL
hdmDF = spark.sql(hdmSQL)
hdmDF.show()

# Expose hdmDF as table
hdmDF.createGlobalTempView("hdm")

# Fetch list of (database,table) found in historical_ddl_map_<migrationId> that will have Components Generated

tableDF = spark.sql("""
   SELECT distinct td_database, td_tab_name, concat('/',td_tab_name,'_',migration_id) as hive_tablename
   FROM global_temp.hdm 
""")
tableDF.show()
tableList = tableDF.collect()

for rw in tableList:
    hdfsLoc = hdfs_path + rw['td_database'] +  rw['hive_tablename'] + "/"  
    hive_table = "td_{0}__{1}_{2}".format(rw['td_database'],rw['td_tab_name'],migrationId).lower()
    lne = "dbname:" + rw['td_database'] + ", tablename:" + rw['td_tab_name'] + "hdfs Loc:" + hdfsLoc
    print(hdfsLoc)
    logging.append(this_script + ":" +  lne)
    
    
    #to be updated
    #cmd1 = "/home/users/scarteah/sunjay/run_prod_sqoop.sh " + rw['td_database'] + " " +  rw['td_tab_name'] + " 5 8192 " + hdfsLoc + " " + userid + " " + password + " " + dbname
    ky = rw['td_database'].lower() + "," + rw['td_tab_name'].lower()
    sqoopfl = "./logs/sqoop_" +  rw['td_database'].lower() + "_" +  rw['td_tab_name'].lower() + "_" +  migrationId + ".log"
    os.system("rm -r " + sqoopfl)
    if ky not in rtableList: 
       cmd1 = "./run_dev_sqoop_orc.sh {0} {1} {2} {3} {4} {5} {6} {7} {8} {9} 2> {10}".format(rw['td_database'],rw['td_tab_name'],mapperCount,fetchSize,hdfsLoc,userid,password,dbname,hive_db_name,hive_table,sqoopfl)
    
       print(cmd1)
       os.system(cmd1)
    
       pip = os.popen('cat ' + sqoopfl + ' | grep Map | grep records')
       lns = pip.read().split("\n")
       for lnx in lns:
           logging.append(this_script + ":" +  rw['td_database'] + ":" +  rw['td_tab_name'] + ":" + lnx.strip()) 
       lgcmd = logline.format(rw['td_database'].lower(), rw['td_tab_name'].lower() ) 
       os.system(lgcmd)
       rtableList[ky] = 1
os.system(endCmd)

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()


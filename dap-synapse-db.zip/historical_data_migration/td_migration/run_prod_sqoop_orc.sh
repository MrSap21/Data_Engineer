#!/usr/bin/bash

# run_prod_sqoop_orc.sh

# 04/06/2021 - Sunjay Karan,Carter Shore - Scoop script to extract data from Teradata table into Hive ORC table

export db_name=$1
export tb_name=$2

export num_mappers=$3
export fetch_size=$4

export hdfs_dir=$5
export USERID=$6
export PASSWORD=$7
export dbname1=$8
export hive_db=$9
export hive_table=${10}

echo db_name=${db_name}
echo tb_name=${tb_name}
echo num_mappers=${num_mappers}
echo fetch_size=${fetch_size}
echo hdfs_dir=${hdfs_dir}
#echo USERID=${USERID}
#echo PASSWORD=${PASSWORD}
echo dbname1=${dbname1}
echo hive_db=${hive_db}
echo hive_table=${hive_table}

# export HADOOP_CLASSPATH=$(hcat -classpath) 
# export HIVE_HOME=/usr/hdp/current/hive-client
# export HCAT_HOME=/usr/hdp/current/hive-webhcat
# export SQOOP_HOME=/usr/hdp/current/sqoop-client

# export LIB_JARS=$HCAT_HOME/share/hcatalog/hive-hcatalog-core-1.2.1000.2.6.4.0-91.jar,\
# $HIVE_HOME/lib/hive-metastore-1.2.1000.2.6.4.0-91.jar,\
# $HIVE_HOME/lib/libthrift-0.9.3.jar,\
# $HIVE_HOME/lib/hive-exec-1.2.1000.2.6.4.0-91.jar,\
# $HIVE_HOME/lib/libfb303-0.9.3.jar,\
# $HIVE_HOME/lib/jdo-api-3.0.1.jar,\
# $HIVE_HOME/lib/hive-cli-1.2.1000.2.6.4.0-91.jar,\
# /usr/hdp/2.6.4.0-91/sqoop/lib/teradata-connector-1.4.1-hadoop2.jar,\
# /usr/hdp/2.6.4.0-91/hadoop/client/slf4j-api.jar,\
# $SQOOP_HOME/lib/teradata-connector-1.4.1-hadoop2.jar,\
# $SQOOP_HOME/lib/hortonworks-teradata-connector-1.4.1.2.4.3.0-227.jar,\
# $SQOOP_HOME/lib/tdgssconfig.jar,\
# $SQOOP_HOME/lib/terajdbc4.jar

echo ${hdfs_dir}

hadoop fs -rmr ${hdfs_dir}/${hive_table}


$SQOOP_HOME/bin/sqoop import \
    -Dteradata.db.input.method=split.by.amp \
    -Dteradata.db.input.num.mappers=${num_mappers} \
    -Dtdch.input.timestamp.format="yyyy-MM-dd HH:mm:ss" \
    -Dtdch.output.timestamp.format="yyyy-MM-dd HH:mm:ss" \
    -Dteradata.job.type=hcat \
    -libjars $LIB_JARS \
    --connection-manager org.apache.sqoop.teradata.TeradataConnManager \
    --table ${db_name}.${tb_name} \
    --fetch-size ${fetch_size} \
    --connect "jdbc:teradata://${dbname1}/DATABASE=${db_name},CHARSET=UTF8"   \
    --num-mappers ${num_mappers} \
    --hcatalog-database ${hive_db} \
    --hcatalog-table ${hive_table} \
    --username $USERID \
    --password $PASSWORD 

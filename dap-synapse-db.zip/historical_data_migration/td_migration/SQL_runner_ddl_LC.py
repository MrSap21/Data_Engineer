# -*- coding: utf-8 -*-
"""
SQL_runner_ddl.py

Pyspark statement fetch and execute Components matching parameters fro 'migration_component' repository table
Parms: hiveDB, TDdatabase, TDtable, migrationID, componentPrefix

03/21/2021 - Carter Shore - Lowercase the TD database, TD table, and migrationID parms
04/20/2021 - Carter Shore - Change from 'migration_component' to ''migration_component_<migrationID>'

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
import os
import sys

# process parms
nargs = len(sys.argv)

if nargs != 6: 
	print('Usage: SQL_runner_ddl.py <Hive DB> <Teradata DB pattern> <Teradata Table pattern> <MigrationID> <Component prefix>')
	print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
	exit(-1)

# Hive SQL statement to generate Hive Parquet table DDL for the Voltage encrypted data
# Parms: database, table 

# source table name = TD_<database>__<table>
# target table name = PQ_<database>__<table>
# generated component name = PQ_<database>__<table>.ddl


this_script = sys.argv[0]
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()
migrationId = sys.argv[1].lower()
prefix = sys.argv[5]

recoverfilename = "./logs/" + migrationId + ".proc"
this_script_td = this_script + "_" + prefix
cmd2 = "cat " + recoverfilename + " | grep " + this_script_td
startCmd = "echo " +  this_script_td + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script_td + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script_td + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;

print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" +  'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Prefix: \'' + prefix + '\'')

fileName = "./logs/" + migrationId + ".log"

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()
logging = []

tbSplt = table.split(",")
multipleTables = False
tablewhereClouse = "like '" + table + "'"
if len(tbSplt) > 1:
   multipleTables = True 
   tablewhereClouse = "in ('" +  "','".join([str(elem) for elem in tbSplt])  + "')"
   
   

# get a Spark Session
spark=SparkSession.builder.appName('Gen_HiveVoltageParquetSQL_Decimal_Synapse').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

# hdm = historical_ddl_map, fetch hdm records filtered by database, table parms, expose them as temp view

sql1 = """
   SELECT * 
   FROM migration_component_{1} WHERE component_name like '{0}%' and component_name like '%{1}%' and td_database like '{2}' and td_table {3}
""".format(prefix,migrationId,database,tablewhereClouse.lower())
print(sql1)
hdmDFList = spark.sql(sql1)

hdmDFList.show()

tableDF = spark.sql("show tables").select('tablename').collect()
tableDict = {}
for rw in tableDF:
    tableDict[rw['tablename']] = rw['tablename']


sqllist = hdmDFList.collect()
for rw in sqllist:
    sql2 = rw['component_text']
    sql3 = str(sql2.replace('\n',' ').strip()).replace(";","")
    print(sql3)
    to = sql3.split("TABLE")[1].split("(")[0].strip()
    droptableSQL = "drop table if exists " + to
    logging.append(this_script + ":drop table:" + rw['td_database'] + "." + to ) 
    logging.append(this_script + ":" + droptableSQL)
    file1 = open(fileName, "a")
    for ln in logging:
        file1.write(ln + "\n")
    file1.close()
    logging = []
    if to.lower() in tableDict:
       df = spark.sql(droptableSQL)
    logging.append(this_script + ":createing table:" + rw['td_database'] + "." + to ) 
    logging.append(this_script + ":" + sql3)
    file1 = open(fileName, "a")
    for ln in logging:
        file1.write(ln + "\n")
    file1.close()
    logging = []
    df = spark.sql(sql3)
    logging.append(this_script + ":database:" + rw['td_database'] + ":tablename:" + rw['td_table'] + "+++END+++")
    file1 = open(fileName, "a")
    for ln in logging:
        file1.write(ln + "\n")
    file1.close()
    logging = []


logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)
# end of script

# -*- coding: utf-8 -*-
"""
Gen_HiveSqoopOrcDDL.py

Pyspark script to generate Hive external table DDL for the Teradata Sqoop ORC table export files
Parms: MigrationID, hive DB, TD database, TD table, HDFS base folder path

04/05/2021 - Carter Shore - Initial version created from Gen_HiveTptExportTableDDL.py
04/06/2021 - Carter Shore - Create as Managed Table, tablename = td_<database>__<table>_<migrationId>
04/21/2021 - Carter Shore - Change target from 'migration_component' to 'migration_component_<migrationID>'
06/27/2021 - Carter Shore - Enclose hive column names in backticks ` to enable embedded spaces in column names.

"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import os
import sys

# process parms
nargs = len(sys.argv)

if nargs != 6:
        print('Usage: Gen_HiveSqoopOrcDDL.py <migrationID> <Hive DB> <Teradata DB> <Teradata Table> <HDFS path>')
        print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
        exit(-1)

# lowercase migrationID, Teradata DB, Teradata Table

this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()
hdfs_path=sys.argv[5].lower()

print(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
print(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
print(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
print(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
print(this_script + ":" + 'JobParams:hdfs_path: \'' + hdfs_path + '\'')

fileName = "./logs/" + migrationId + ".log"

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;

print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:hdfs_path: \'' + hdfs_path + '\'')

tbSplt = table.split(",")
multipleTables = False
tablewhereClause = "like '" + table + "'"
if len(tbSplt) > 1:
   multipleTables = True
   tablewhereClause = "in ('" +  "','".join([str(elem) for elem in tbSplt])  + "')"

spark=SparkSession.builder.appName("Gen_HiveTptExportTableDDL").enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

# fetch historical_ddl_map records matching database and table parms provided
hdmDF = spark.sql("""SELECT MAX(cast(hv_col_order AS INT)) OVER (partition by td_database, td_tab_name) as col_max,
   '{0}' as migration_id, *
   FROM historical_ddl_map_{0} WHERE td_database = '{1}' AND td_tab_name {2}
   order by td_database,td_tab_name,td_col_order
""".format(migrationId,database,tablewhereClause))

# expose the DF as a temp view
hdmDF.createGlobalTempView("hdm")
hdmDF.show()

# fetch list of matching databases and tables found in hdm
tableList = spark.sql("""
   SELECT distinct td_database, td_tab_name
   FROM global_temp.hdm
""".format(migrationId,database,tablewhereClause)).collect()

for rw in tableList:
    lne = "dbname:" + rw['td_database'] + ",tablename:" + rw['td_tab_name']
    logging.append(this_script + ":" +  lne)

# generate create table text 
line4DF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat("CREATE TABLE IF NOT EXISTS td_", hv_schema, "__", hv_tab_name, "_" , migration_id, " ("  ) as line,
   -1 as nbr from global_temp.hdm WHERE td_col_order = col_max
""")

# generate column text in ascending order
line5DF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat( '`', hv_col_name, '` ', hv_col_type, hv_col_size, "," ) as line,
   cast(hv_col_order as int) as nbr from global_temp.hdm WHERE hv_col_order < col_max
""")

# generate last column text
line6DF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat('`', hv_col_name, '` ', hv_col_type, hv_col_size) as line,
   cast(hv_col_order as int) as nbr from global_temp.hdm WHERE hv_col_order = col_max
""")

# generate table storage spec text
line7DF = spark.sql("""select td_database, td_tab_name,  migration_id, 
   concat(") STORED AS ORC ") as line,
   cast(col_max as int)+1 as nbr from global_temp.hdm WHERE hv_col_order = col_max""".format(hdfs_path))

# generate table properties text
line8DF = spark.sql( """select td_database, td_tab_name, migration_id,
 'TBLPROPERTIES("orc.compress"="ZLIB");'
 as line, cast(col_max as int)+2 as nbr from global_temp.hdm WHERE hv_col_order = col_max""")

# union the DF ordered by "nbr" 
unionedDF = line4DF\
        .union(line5DF)\
        .union(line6DF)\
        .union(line7DF)\
        .union(line8DF)\
        .orderBy("nbr", ascending=True)

unionedDF.repartition(1)

# expose the DF as temp view
unionedDF.createGlobalTempView("unioned")
unionedDF.show()

componentDF = spark.sql("""
        select td_database, td_tab_name as td_table, migration_id,
        concat('TD_',td_database,'__',td_tab_name,'__', migration_id,'.ddl') as component_name,
        current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text 
        from global_temp.unioned
        group by td_database, td_tab_name, migration_id
""")

# display the component text to STDOUT
#componentDF.select("component_text").show(50,False)
listtoInsert = componentDF.select(['td_database', 'td_table','migration_id', 'component_name']).distinct().collect()

# insert the records for selected (database, table) into table 'migration_component_<migrationID>'
insertDF = spark.sql("""
        INSERT INTO migration_component_{}
        select td_database, td_tab_name as td_table, concat('TD_',td_database,'__',td_tab_name,'_', migration_id, '.ddl') as component_name,
        current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text, '' as created_by
        from global_temp.unioned
        group by td_database, td_tab_name,migration_id
""".format(migrationId))


logging.append(this_script + ":" + "++++++++Append to migration_component START ++++++")
for rw in listtoInsert:
    lne = this_script + ":database:" + rw['td_database'] + ",tablename:" + rw['td_table'] + ",component_name:" + rw['component_name'] + ',migration_id:' + rw['migration_id']
    logging.append(lne)

logging.append(this_script + ":" + "++++++++Append to migration_component END ++++++")
logging.append(this_script + ":" + "Job:++++" + this_script + " END ++++++++")

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)


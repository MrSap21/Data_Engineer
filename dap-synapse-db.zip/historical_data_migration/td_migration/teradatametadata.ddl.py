# -*- coding: utf-8 -*-
"""
Created on Wed Mar  3 12:18:36 2021
03/23/2015 - Carter Shore - Modify teradatametadata DDL to eliminate columns that Migration does not require.

Pyspark script to create Framework tables having names tagged with Migration ID

Params: Migration ID, Hive DB name, HDFS folder path

table name = <table name>_<migration_id>

03/04/2021 - Sunjay Karan, Carter Shore - Initial creation based on exisiting ddl tables
04/20/2021 - Carter Shore - Add table 'migration_component_<migrationId>'
04/29/2021 - Carter Shore - Modify for Snowflake. Updated tables 'col_type_xref', 
06/28/2021 - Carter Shore - Add column 'sf_database' to table historical_ddl_map_<migrationID>.
             It will be populated by script Refresh_Metadata_Dictionary from table Teradata_Snowflake_Map
             Add table teradata_snowflake_map, for each <td_database><td_table> => <sf_database>.<sf_schema>.<sf_table>

"""

from pyspark.sql import SparkSession
import sys
import os
import subprocess

# process parms
nargs = len(sys.argv)

if nargs != 4: 
	print('Usage:' + sys.argv[0] + ' <Migration ID> <Hive DB name> <HDFS folder path>') 
	print('For manual execution, choose a unique Migration ID, or supply Migration ID  from an existing Migration')
	exit(-1)

this_script  = sys.argv[0]
migration_id = sys.argv[1]   
hive_db_name = sys.argv[2]
hdfs_path    = sys.argv[3]

def mkdirs(path,spark):
    #fs = spark.sparkContext._jvm.org.apache.hadoop.fs.FileSystem.get(spark.sparkContext._jsc.hadoopConfiguration())
    #return fs.exists(spark.sparkContext._jvm.org.apache.hadoop.fs.Path(path))
    print ('creating path' + path)
    try:
        URI = spark.sparkContext._gateway.jvm.java.net.URI
        Path = spark.sparkContext._gateway.jvm.org.apache.hadoop.fs.Path
        FileSystem = spark.sparkContext._gateway.jvm.org.apache.hadoop.fs.FileSystem
        fs = FileSystem.get(URI("/data/"), spark.sparkContext._jsc.hadoopConfiguration())
        if fs.exists(Path(path)):
           return True
        else:
           fs.mkdirs(Path(path))
           return True 
    except:
        print ('failed')
        return False
# global variable values
recoverfilename = "./logs/" + migration_id + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)

rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
tableList = {}
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)
 
logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:HDFS folder path: \'' + hdfs_path + '\'')

# get a Spark Session
spark=SparkSession.builder.appName('Gen_TPT_JobVarsFile').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))

teradatametadata_DDL = """
CREATE EXTERNAL TABLE IF NOT EXISTS teradatametadata_{}(
	DataBaseName	VARCHAR(128),
	TableName	VARCHAR(128),
	TableKind	CHAR(1),
	ColumnFormat	VARCHAR(128),
	ColumnId	SMALLINT,
	ColumnLength	INTEGER,
	ColumnName	VARCHAR(128),	
	ColumnTypeOriginal	CHAR(2) ,
	ColumnType	VARCHAR(200) ,		
	DecimalFractionalDigits	SMALLINT,
	DecimalTotalDigits	SMALLINT,	
	Nullable	CHAR(1))
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '|'
STORED AS INPUTFORMAT
  'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  '{}/teradatametadata_{}'
""".format(migration_id,hdfs_path,migration_id)

# Hive _DDL for table col_type_xref
# 02/26/2021 - Carter Shore - Changed column order to match process order for clarity when loading data

col_type_xref_DDL = """
CREATE EXTERNAL TABLE IF NOT EXISTS col_type_xref_{}
(
td_type string,
hv_type string,
pq_type string,
pb_type string,
sy_type string,
sf_type string
)
 ROW FORMAT DELIMITED                                                        
   FIELDS TERMINATED BY ','                                                  
 LOCATION                                                                    
   '{}/col_type_xref_{}'
""".format(migration_id,hdfs_path,migration_id)

column_encryption_spec_DDL = """
CREATE EXTERNAL TABLE IF NOT EXISTS column_encryption_spec_{}
(
td_database string,
td_tab_name string,
td_col_name string,
voltage_udf string,
voltage_format string,
voltage_udf_de string,
voltage_format_de string 
)
 ROW FORMAT DELIMITED                                                        
   FIELDS TERMINATED BY ','                                                  
 LOCATION                                                                    
   '{}/column_encryption_spec_{}'
""".format(migration_id,hdfs_path,migration_id)

historical_ddl_map_DDL = """
CREATE TABLE IF NOT EXISTS historical_ddl_map_{} (
td_database STRING,
td_tab_name STRING,
td_tab_type STRING,
td_col_order STRING,
td_col_name STRING,
td_col_type STRING,
td_col_size STRING,
td_col_length STRING,
td_notnull STRING,
hv_schema STRING,
hv_tab_name STRING,
hv_col_order STRING,
hv_col_name STRING,
hv_col_type STRING,
hv_col_size STRING,
hv_notnull STRING,
pq_schema STRING,
pq_tab_name STRING,
pq_col_order STRING,
pq_col_name STRING,
pq_col_type STRING,
pq_col_size STRING,
pq_notnull STRING,
pb_schema STRING,
pb_tab_name STRING,
pb_col_order STRING,
pb_col_name STRING,
pb_col_type STRING,
pb_col_size STRING,
pb_notnull STRING,
sy_schema STRING,
sy_tab_name STRING,
sy_col_order STRING,
sy_col_name STRING,
sy_col_type STRING,
sy_col_size STRING,
sy_notnull STRING,
sf_database STRING,
sf_schema STRING,
sf_tab_name STRING,
sf_col_order STRING,
sf_col_name STRING,
sf_col_type STRING,
sf_col_size STRING,
sf_notnull STRING,
voltage_encrypt_udf STRING,
voltage_encrypt_fmt STRING,
voltage_decrypt_udf STRING,
voltage_decrypt_fmt STRING,
change_ts STRING
)
""".format(migration_id)

migration_component_DDL = """
CREATE TABLE migration_component_{} (
td_database STRING,
td_table STRING,
component_name STRING,
creation_ts TIMESTAMP,
component_text STRING,
created_by STRING
)STORED AS PARQUET
""".format(migration_id)

mkdirs('{}/teradatametadata_{}'.format(hdfs_path,migration_id),spark)
mkdirs('{}/col_type_xref_{}'.format(hdfs_path,migration_id),spark)
mkdirs('{}/column_encryption_spec_{}'.format(hdfs_path,migration_id),spark)
mkdirs('{}/migration_component_{}'.format(hdfs_path,migration_id),spark)

# log the DDL
logging.append(teradatametadata_DDL)
logging.append(historical_ddl_map_DDL)
logging.append(col_type_xref_DDL)
logging.append(column_encryption_spec_DDL)
logging.append(migration_component_DDL)

# create the tables
spark.sql(teradatametadata_DDL)
spark.sql(historical_ddl_map_DDL)
spark.sql(col_type_xref_DDL)
spark.sql(column_encryption_spec_DDL)
spark.sql(migration_component_DDL)

os.system(endCmd)

#!/bin/bash

## Description ###############
#One time file transfer for encryption files in HDFS 
#This script needs to be to executed only once for each user id in Dev.
##############################

#####change log############### 
# 05/04/2021 - Teena Kappen - Intial version
##############################

hadoop fs -mkdir voltage
hadoop fs -mkdir voltage/config
hadoop fs -cp /user/scarteah/voltage/config/* voltage/config

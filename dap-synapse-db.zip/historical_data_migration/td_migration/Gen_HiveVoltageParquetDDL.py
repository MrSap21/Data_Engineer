# -*- coding: utf-8 -*-
"""
Gen_HiveVoltageParquetDDL.py

Pyspark script to generate Hive Parquet table DDL Components. 
Parms: Hive DB, TD database, TD table, Migration ID 

04/07/2021 - Carter Shore - Modified to lowercase TD database, TD table, Migration ID
04/09/2021 - Carter Shore - Modified to use pq_ columns from table 'historical_ddl_map' 
04/20/2021 - Carter Shore - Replace table 'migration_component' with 'migration_component_<migrationID>'
06/28/2021 - Carter Shore - Enclose Hive column names in backtick ` to enable embedded spaces in names.

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import os
import sys

# process parms
nargs = len(sys.argv)

if nargs != 5: 
	print('Usage: Gen_ParquetToSynapse.py <Teradata DB name pattern> <Teradata Table name pattern>')
	print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
	exit(-1)

# Hive SQL statement to generate Hive Parquet table DDL for the Voltage encrypted data
# Parms: database, table 

# source table name = TD_<database>__<table>
# target table name = PQ_<database>__<table>
# generated component name = PQ_<database>__<table>.ddl


this_script = sys.argv[0]
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()
migrationId = sys.argv[1].lower()

fileName = "./logs/" + migrationId + ".log"

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;


print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" +  'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')

tbSplt = table.split(",")
multipleTables = False
tablewhereClouse = "like '" + table + "'"
if len(tbSplt) > 1:
   multipleTables = True
   tablewhereClouse = "in ('" +  "','".join([str(elem) for elem in tbSplt])  + "')"

#print this_script
#print('Hive database name: \'' + hive_db_name + '\'') 
#print('Teradata database name pattern: \'' + database + '\'')
#print('Teradata table name pattern: \'' + table + '\'')

# get a Spark Session
spark=SparkSession.builder.appName('Gen_HiveVoltageParquetDDL_Decimal_Synapse').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

# hdm = historical_ddl_map, fetch hdm records filtered by database, table parms, expose them as temp view
hdmDF = spark.sql("""
   SELECT MAX(cast(hv_col_order AS INT)) OVER (partition by td_database, td_tab_name) as col_max, * 
   FROM historical_ddl_map_{} WHERE td_database = '{}' AND td_tab_name {} 
   order by td_database,td_tab_name,td_col_order
""".format(migrationId,database,tablewhereClouse.lower()))

hdmDF = hdmDF.withColumn("migration_id", lit(migrationId))
hdmDF.createGlobalTempView("hdm")

tableList = spark.sql("""
   SELECT distinct td_database, td_tab_name
   FROM historical_ddl_map_{} WHERE td_database = '{}' AND td_tab_name {} order by td_database,td_tab_name
""".format(migrationId,database,tablewhereClouse.lower())).collect()

for rw in tableList:
    lne = "dbname:" + rw['td_database'] + ",tablename:" + rw['td_tab_name']
    logging.append(this_script + ":" +  lne)

## generate header text (note: verify comments with leading '--' on Azure platform)
#headerDF = spark.sql("""
#   select td_database, td_tab_name, migration_id, 
#   concat("-- Name: PQ_",concat(td_database,'__',td_tab_name,'_', migration_id,'.ddl')," Generated: ",current_timestamp," ID: ",
#   date_format(current_timestamp, 'yyyyMMddHHmmssSSS'), "") as line, 
#   -999999 as nbr from global_temp.hdm WHERE hv_col_order = col_max
#""")

# line4DF - Generate text segment to start creation of Parquet table
line4DF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   concat("CREATE TABLE PQ_", hv_schema, "__", pq_tab_name, "_" , migration_id, " ("  ) as line,
   -1 as nbr from global_temp.hdm WHERE td_col_order = col_max
""")

# line5DF - Generate text segment to specify Parquet column names & types 
line5DF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   concat('`', pq_col_name, '` ', pq_col_type, pq_col_size, "," ) as line, 
   cast(hv_col_order as int) as nbr from global_temp.hdm WHERE hv_col_order < col_max
""")

# line6DF - Generate text segment to specify ending Parquet column name and type
line6DF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat('`', pq_col_name,'` ',pq_col_type,pq_col_size) as line,
   cast(hv_col_order as int) as nbr from global_temp.hdm WHERE hv_col_order = col_max
""")

# line7DF - Generate text segment for Synapse target table truncate statement prior to migration data insertion
line7DF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   ") STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='GZIP')\073" as line,
   col_max+1 as nbr from global_temp.hdm WHERE hv_col_order = col_max order by nbr asc
""")

# union the text segments into a single DF, expose as temp view 'components'
unionedDF = line4DF\
	.union(line5DF)\
	.union(line6DF)\
	.union(line7DF)\
	.orderBy("nbr", ascending=True)

unionedDF = unionedDF.repartition(1)

unionedDF.createGlobalTempView("unioned")

# concat the text segments seperated by newlines into a single block of component text for each database, table 
componentDF = spark.sql("""
	select td_database, td_tab_name as td_table, migration_id,concat('PQ_',td_database,'__',td_tab_name,'_', migration_id,'.ddl') as component_name,
	current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text from global_temp.unioned
	group by td_database, td_tab_name,migration_id
""")

# display the component text to STDOUT
#componentDF.select("component_text").show(50,False)
listtoInsert = componentDF.select(['td_database', 'td_table','migration_id', 'component_name']).distinct().collect()

# insert the records for selected (database, table) into table 'migration_component_<migrationID>'
insertDF = spark.sql("""
	INSERT INTO migration_component_{}
	select td_database, td_tab_name as td_table, concat('PQ_',td_database,'__',td_tab_name,'_', migration_id, '.ddl') as component_name,
	current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text, '' as created_by 
	from global_temp.unioned
	group by td_database, td_tab_name,migration_id
""".format(migrationId))

logging.append(this_script + ":" + "++++++++Append to migration_component START ++++++")
for rw in listtoInsert:
    lne = this_script + ":database:" + rw['td_database'] + ",tablename:" + rw['td_table'] + ",component_name:" + rw['component_name'] + ',migration_id:' + rw['migration_id']
    logging.append(lne)

logging.append(this_script + ":" + "++++++++Append to migration_component END ++++++")
logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()
#ParquetToSynapse.py end of script
os.system(endCmd)

#!/usr/bin/bash

export env="DEV"
export env=${2}

echo $env

if [ "$env" == "DEV"  ] || [ "$env" == "TST"  ] ;then 
   echo "dev1"
   echo "load file"
   beeline -u "jdbc:hive2://dlw2nia-bd02.walgreens.com:2181,dlw2nia-bd03.walgreens.com:2181,dlw2nia-bd10.walgreens.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2" -f $1
else
   echo "prod"
   echo "load file"
   beeline -u "jdbc:hive2://pla-w01mstrhdpdna01.walgreens.com:2181,pla-w01mstrhdpdna02.walgreens.com:2181,pla-w01mstrhdpdna03.walgreens.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2" -f $1 

fi

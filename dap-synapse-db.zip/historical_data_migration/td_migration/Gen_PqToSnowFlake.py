# -*- coding: utf-8 -*-
"""
Created on Mon Jan 18 13:31:25 2021

02/16/2021 - Carter Shore - Initial Creation
05/03/2021 - Carter Shore - Update based on example script from Snowflake
05/05/2021 - Carter Shore - Modify generated 'COPY INTO ...' statement, based on feedback from Alex Khokhlov
05/18/2021 - Carter Shore - Add parameter for Snowflake StageName
05/19/2021 - Carter Shore - Modify to execute in Migration Framework. Removed format spec from COPY statement.
05/21/2021 - Carter Shore - Modify to integrate with existing Migration Framework.
                            Modify to wrote Component text to Snowflake script folder
05/25/2021 - Carter Shore - Remove literal " from Snowflake object specifications, preserve case.
                            Add "pattern='.*/[0-9][0-9]+_[0-9]+$'" to specify the Hive Parquet table data files,
                            and exclude 0 byte files like '_SUCCESS'. 
                            Add parameter for 'date' type format, defaulting to 'YYYY-MM-DD' and CASE statement
                            to handle applying it.
                            Add formatting to detect timestamp strings that cannot be converted to 'timestamp_ntz'
                            and map them as NULL.
05/26/2021 - Carter Shore - Remove parameter sf_date_format, generate mapping that replaces '/' with '-' in string
05/28/2021 - Carter Shore - Update transformations for 'date' 'time', 'timestamp_tz', and 'timestamp_ntz' to accomodate '' and space filled data for NULL
06/03/2021 - Carter Shore - Include migrationID into generated ADLS path <td_database>__<td_table>_<migrationID>
06/23/2021 - Carter Shore - Add code to remove trailing 0x00 chars on TD CHAR(X) to SF VARCHAR(X)
06/27/2021 - Carter Shore - Upcase Snowflake object names, enclose in double quotes to enable whitespace in names
06/28/2021 - Carter Shore - Generate Snowflake fully qualified <database>.<schema>.<table> in component
06/29/2021 - Carter Shore - Generate 2 components: <name>.ddl to create target table, and <name>.dml to ingest data from ADLS
                            Modify generation of ADLS data files in <name>.dml ingestion component.
                            Modify writing generated component to folder to be transferred to ADLS

"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import os
import sys

# process parms
nargs = len(sys.argv)

if nargs != 8:
        print('Usage: Gen_PqToSnowFlake.py <migrationID> <Hive DB> <Teradata DB> <Teradata Table> <SF Stage> <sfscriptfolder>')
        print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
        exit(-1)

# lowercase migrationID, Teradata DB, Teradata Table

this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()
stage=sys.argv[5].upper()
sfscriptfolder=sys.argv[6]
stagingformat=sys.argv[7]



print(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
print(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
print(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
print(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
print(this_script + ":" + 'JobParams:SnowFlake stage \'' + stage + '\'')
print(this_script + ":" + 'JobParams:SnowFlake scriptfolder: \'' + sfscriptfolder + '\'')

fileName = "./logs/" + migrationId + ".log"

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;

print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:stage: \'' + stage + '\'')
logging.append(this_script + ":" + 'JobParams:sfscriptfolder: \'' + sfscriptfolder + '\'')

tbSplt = table.split(",")
multipleTables = False
tablewhereClause = "like '" + table + "'"
if len(tbSplt) > 1:
   multipleTables = True
   tablewhereClause = "in ('" +  "','".join([str(elem) for elem in tbSplt])  + "')"

spark=SparkSession.builder.appName("Gen_PqToSnowFlake").enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

# fetch historical_ddl_map records matching database and table parms provided
hdmDF = spark.sql("""SELECT MAX(cast(hv_col_order AS INT)) OVER (partition by td_database, td_tab_name) as col_max,
   '{0}' as migration_id, *
   FROM historical_ddl_map_{0} WHERE td_database = '{1}' AND td_tab_name {2}
   order by td_database,td_tab_name,td_col_order
""".format(migrationId,database,tablewhereClause))

# expose the DF as a temp view
hdmDF.createGlobalTempView("hdm")
hdmDF.show()

# fetch list of matching databases and tables found in hdm
tableList = spark.sql("""
   SELECT distinct td_database, td_tab_name
   FROM global_temp.hdm
""".format(migrationId,database,tablewhereClause)).collect()

for rw in tableList:
    lne = "dbname:" + rw['td_database'] + ",tablename:" + rw['td_tab_name']
    logging.append(this_script + ":" +  lne)

headerDF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   concat('-- Name: ',concat('SF_',td_database,'__',td_tab_name,'.sql'),' Generated: ',current_timestamp,' ID: ',
   date_format(current_timestamp, 'yyyyMMddHHmmssSSS')) as line,
   -999999 as nbr from global_temp.hdm WHERE hv_col_order = col_max""")

# Require 4 things to ingest the data into Snowflake:
# Target table - existing, created per Next Pathways schema, <database>.<table> names passed as parameters
# Stage - existing, name passed as parameter
# Format - existing, created for Parquet Snappy compressed (included in Stage definition)
# Source File - ADLS base path and file passed in as parm

# Generate the Snowflake DML to load Target Table

copyDF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat('COPY INTO "',upper(sf_database),'"."',upper(sf_schema),'"."',upper(sf_tab_name),'" FROM (SELECT') as line,
   col_max + 1 as nbr from global_temp.hdm WHERE td_col_order = col_max
""")

copycolDF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   CASE sf_col_type
   WHEN 'date' THEN concat('try_cast(replace(($1:"', lower(sf_col_name), '"', "::varchar(10)),'/','-') as date)", IF(td_col_order<col_max,",",""))
   WHEN 'time' THEN concat('try_cast($1:"', lower(sf_col_name), '"::varchar(30) as time)', IF(td_col_order<col_max,",",""))
   WHEN 'timestamp_tz' THEN concat('try_cast($1:"', lower(sf_col_name), '"::varchar(30) as timestamp_tz)', IF(td_col_order<col_max,",",""))
   WHEN 'timestamp_ntz' THEN concat('try_cast($1:"', lower(sf_col_name), '"::varchar(30) as timestamp_ntz)', IF(td_col_order<col_max,",",""))
   ELSE CASE td_col_type
      WHEN 'character' THEN concat('replace(($1:"', lower(sf_col_name), '"::', sf_col_type, " ", sf_col_size,"),chr(0),'')", IF(td_col_order<col_max,",",""))
      ELSE concat('$1:"', lower(sf_col_name), '"::', sf_col_type, " ", sf_col_size, IF(td_col_order<col_max,",","")) 
      END
   END as line,
   col_max + 1 + cast(td_col_order as int) as nbr from global_temp.hdm WHERE td_col_order <= col_max
""")

fromDF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat('FROM @{0}/Common/historical_data_migration/{1}/',sf_schema,'/',sf_tab_name,"/ )",
   "\nfile_format = '{2}'",
   "\npattern='.*/[0-9][0-9]+_[0-9]+$'\;") as line,
   2*col_max + 2 as nbr from global_temp.hdm WHERE td_col_order = col_max
""".format(stage,migrationId,stagingformat))

unionedDF = headerDF\
        .union(copyDF)\
        .union(copycolDF)\
        .union(fromDF)\
        .orderBy("td_database","td_tab_name","nbr",ascending=True)

#.orderBy("td_database","td_tab_name","nbr",ascending=True).select("line")

unionedDF = unionedDF.repartition(1)

#unionedDF.show(500,False)

# expose the DF as temp view
unionedDF.createGlobalTempView("unioned")

componentDF = spark.sql("""
        select td_database, td_tab_name as td_table, migration_id,
        concat('SF_',td_database,'__',td_tab_name,'_', migration_id,'.sql') as component_name,
        current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text
        from global_temp.unioned
        group by td_database, td_tab_name, migration_id
""")

listtoInsert = componentDF.select(['td_database', 'td_table','migration_id', 'component_name']).distinct().collect()

# insert the records for selected (database, table) into table 'migration_component_<migrationID>'
insertDF = spark.sql("""
        INSERT INTO migration_component_{}
        select td_database, td_tab_name as td_table, concat('SF_',td_database,'__',td_tab_name,'_', migration_id, '.sql') as component_name,
        current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text, '' as created_by
        from global_temp.unioned
        group by td_database, td_tab_name,migration_id
""".format(migrationId))

logging.append(this_script + ":" + "++++++++Append to migration_component START ++++++")
for rw in listtoInsert:
    lne = this_script + ":database:" + rw['td_database'] + ",tablename:" + rw['td_table'] + ",component_name:" + rw['component_name'] + ',migration_id:' + rw['migration_id']
    SqlfileName = './' + rw['migration_id'] + '_SQL.csv'
    logging.append(lne)

# write component text to file
com_text_script = componentDF.select("component_text").collect()
file2 = open(SqlfileName, "w")
for ln_com_text in com_text_script:
    file2.write(ln_com_text[0] + "\n")
file2.close()

os.system("mv "+SqlfileName +' '+sfscriptfolder)
os.system("touch -m "+sfscriptfolder)
logging.append(this_script + ":" + "Write SF Component to " + SqlfileName)

logging.append(this_script + ":" + "++++++++Append to migration_component END ++++++")
logging.append(this_script + ":" + "Job:++++" + this_script + " END ++++++++")

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)


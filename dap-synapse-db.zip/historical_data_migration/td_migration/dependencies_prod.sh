echo "script run dependencies_prod.sh"
export JAVA_HOME=/usr/jdk64/jdk1.8.0_112;
export PATH=$PATH:/usr/jdk64/jdk1.8.0_112;
export HADOOP_HOME=/usr/hdp/2.6.4.0-91/hadoop;
export PATH=$PATH:/usr/hdp/2.6.4.0-91/hadoop;
export LIBHDFS_CLASSPATH=$(hadoop classpath --glob);
export HTTPS_PROXY=corppac.walgreens.com:8080;
export HTTP_PROXY=corppac.walgreens.com:8080;
export SPARK_MAJOR_VERSION=2

export HADOOP_CLASSPATH=$(hcat -classpath) 
export HIVE_HOME=/usr/hdp/current/hive-client
export HCAT_HOME=/usr/hdp/current/hive-webhcat
export SQOOP_HOME=/usr/hdp/current/sqoop-client

export LIB_JARS=$HCAT_HOME/share/hcatalog/hive-hcatalog-core-1.2.1000.2.6.4.0-91.jar,\
$HIVE_HOME/lib/hive-metastore-1.2.1000.2.6.4.0-91.jar,\
$HIVE_HOME/lib/libthrift-0.9.3.jar,\
$HIVE_HOME/lib/hive-exec-1.2.1000.2.6.4.0-91.jar,\
$HIVE_HOME/lib/libfb303-0.9.3.jar,\
$HIVE_HOME/lib/jdo-api-3.0.1.jar,\
$HIVE_HOME/lib/hive-cli-1.2.1000.2.6.4.0-91.jar,\
/usr/hdp/2.6.4.0-91/sqoop/lib/teradata-connector-1.4.1-hadoop2.jar,\
/usr/hdp/2.6.4.0-91/hadoop/client/slf4j-api.jar,\
$SQOOP_HOME/lib/teradata-connector-1.4.1-hadoop2.jar,\
$SQOOP_HOME/lib/hortonworks-teradata-connector-1.4.1.2.4.3.0-227.jar,\
$SQOOP_HOME/lib/tdgssconfig.jar,\
$SQOOP_HOME/lib/terajdbc4.jar


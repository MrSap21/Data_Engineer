# -*- coding: utf-8 -*-
"""
SQL_runner.py"

Pyspark script to execute Hive SQL Components
Parms: migrationId,hive_db_name,TD database,TD table,Component Name prefix

03/22/2021 - Carter Shore -Lowercase the migrationId,TD database,TD table
04/20/2021 - Carter Shore - Replece 'migration_component' with 'migration_component_<migrationID>'

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
import os
import sys

# process parms
nargs = len(sys.argv)
print(nargs)
if nargs != 7: 
	print('Usage: SQL_runner.py <migrationID> <Hive DB> <Teradata DB name pattern> <Teradata Table name pattern> <Component prefix>')
	print("Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card")
	exit(-1)

# Hive SQL statement to generate Hive Parquet table DDL for the Voltage encrypted data
# Parms: database, table 

# source table name = TD_<database>__<table>
# target table name = PQ_<database>__<table>
# generated component name = PQ_<database>__<table>.ddl


this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()
prefix = sys.argv[5]
mig_env = sys.argv[6]

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename

logline = "echo " +  this_script + "::TABLE::{},{}:: >> " + recoverfilename


rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
rtableList = {}
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       print(splt)
       if len(ln) > 0:
          if splt[1] == "END":
             print "this step  is over"
             sys.exit(0)
          if splt[1] == "TABLE":
             rtableList[splt[2]] = 1
   os.system(reStartCmd)

print(rtableList)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" +  'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
fileName = "./logs/" + migrationId + ".log"

tbSplt = table.split(",")
multipleTables = False
tablewhereClause = "like '" + table + "'"
if len(tbSplt) > 1:
   multipleTables = True 
   tablewhereClause = "in ('" +  "','".join([str(elem) for elem in tbSplt])  + "')"
   
   

# get a Spark Session
spark=SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName('SQL_runner').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

sql1 = """
   SELECT * 
   FROM migration_component_{1} WHERE component_name like '{0}%' and component_name like '%{1}%' and td_database like '{2}' and td_table {3}
""".format(prefix,migrationId,database,tablewhereClause.lower())
print(sql1)
hdmDFList = spark.sql(sql1)

hdmDFList.show()

sqllist = hdmDFList.collect()
i = 0
for rw in sqllist:
    sql2 = rw['component_text']
    sql3 = str(sql2.replace('\n',' ').strip()).replace(";","")
    to = sql3.split("TABLE")[1].split("SELECT")[0].strip()
    fr = sql3.split("FROM")[1].strip()
    ky = rw['td_database'].lower() + "," + to.lower()
    slSQL = "SELECT " + sql3.split("SELECT")[1].strip()
    toViewName = "PQ" + migrationId
    sqlfile = "./logs/PQ" + migrationId +  str(i) + ".sql"
    file2 = open(sqlfile, "w")
    file2.write("use " +  hive_db_name + ";\n" )
    file2.write( sql3 + ";\n" )
    file2.close()
    i = i + 1

   
    if ky not in rtableList:
       logging.append(this_script + ":database:" + rw['td_database'] + ":tablename:" + rw['td_table'] + "+++START+++")
       logging.append(this_script + ":Loading data into:" + rw['td_database'] + "." + to + " :From" + rw['td_database'] + "." + fr) 
       logging.append(this_script + ":" + sql3)
       logging.append(this_script + ":" + slSQL)
       sql10 = "insert overwrite  table {} select * from global_temp.{} limit 10".format(to,toViewName)
       logging.append(this_script + ":" + sql10)
       print(sql3)
       print(slSQL)
       file1 = open(fileName, "a")
       for ln in logging:
           file1.write(ln + "\n")
       file1.close()
       
       os.system("./beelinerunner.sh " + sqlfile + " " + mig_env)
       outcount = spark.sql("select count(1) from " + to).collect()[0]['count(1)']
       incount = spark.sql("select count(1) from " + fr).collect()[0]['count(1)']
       logging.append(this_script + ":Input:" + rw['td_database'] + "." + fr  + ":record_count:" + str(incount)) 
       ln1 = logline.format(rw['td_database'].lower(),to.lower())
       os.system(ln1)
       logging.append(this_script + ":Output:" + rw['td_database'] + "." + to  + ":record_count:" + str(outcount)) 
       logging.append(this_script + ":database:" + rw['td_database'] + ":tablename:" + rw['td_table'] + "+++END+++")


logging.append(this_script + ":" + "++++++++Append to migration_component END ++++++")
logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)

#SQL_runner.py" end of script

from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import os
import sys

# 2021-05-18 Carter Shore - Modify for Snowflake processing.
# 2021-06-28 Carter Shore - Add table teradata_snowflake_map processing

nargs = len(sys.argv)

if nargs != 4:
        print('Usage:' + sys.argv[0] + ' <Migration ID> <Hive DB name> <HDFS folder path>')
        print('For manual execution, choose a unique Migration ID, or supply Migration ID  from an existing Migration')
        exit(-1)

this_script  = sys.argv[0]
migration_id = sys.argv[1]
hive_db_name = sys.argv[2]

hdfspath    = sys.argv[3]


recoverfilename = "./logs/" + migration_id + ".proc"
logfileName = "./logs/" + migration_id + ".log"
logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive hdfspath name: \'' + hdfspath + '\'')

file1 = open(logfileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()
logging = []



cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
logline = "echo " + this_script + "::TABLE::{} >> "  + recoverfilename
print(cmd2)

rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
tableList = {}
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       print(splt)
       if len(ln) > 0: 
          if splt[1] == "END":
             print "this step  is over"
             sys.exit(0)
          if splt[1] == "TABLE":
             tableList[splt[2]] = 1
   os.system(reStartCmd)

colreffle = "col_type_xref_" + migration_id
encryptspec = "column_encryption_spec_" + migration_id

print(tableList)
spark=SparkSession.builder.appName("move_csv_py").enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")


if colreffle not in tableList:
   cmd1 = "insert overwrite TABLE col_type_xref_{} select * from col_type_xref_snowflake".format(migration_id);
   print(cmd1)
   logging.append(cmd1)
   spark.sql(cmd1)
   lglne = logline.format(colreffle)
   os.system(lglne)
if encryptspec not in tableList:
   #cmd3 = "hadoop fs -cp -f {}/column_encryption_spec/* {}/column_encryption_spec_{}/".format(hdfspath,hdfspath,migration_id)
   cmd3 = "insert overwrite TABLE  column_encryption_spec_{} select * from column_encryption_spec_newcopy".format(migration_id);
   print(cmd3)
   logging.append(cmd3)
   spark.sql(cmd3)
   lglne = logline.format(encryptspec)
   os.system(lglne)

os.system(endCmd)
file1 = open(logfileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()


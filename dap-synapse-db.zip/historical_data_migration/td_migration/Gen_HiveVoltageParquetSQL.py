"""
Gen_HiveVoltageParquetSQL.synapse.py

Pyspark statement to generate Components that load Parquet files in ADLS to Synapse Tables
Parms: database, table 

04/07/2021 - Carter Shore - Lowercased parms migrationId,database,table

"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.functions import col
import os
import sys

# process parms
nargs = len(sys.argv)

print(nargs)
if nargs != 5: 
   print('Usage: Gen_HiveVoltageParquetSQL.synapse.py <MigrationID> <HiveDB> <Teradata DB name pattern> <Teradata Table name pattern>')
   print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
   exit(-1)

# Hive SQL statement to generate Hive Parquet table DDL for the Voltage encrypted data
# Parms: database, table, migration_id

# source table name = TD_<database>__<table>__<migration_id>
# target table name = PQ_<database>__<table>__<migration_id>
# generated component name = PQ_<database>__<table>__<migration_id>.ddl


this_script = sys.argv[0]
migrationId = sys.argv[1].lower()
hive_db_name = sys.argv[2]
database = sys.argv[3].lower()
table = sys.argv[4].lower()

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'') 
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')

fileName = "./logs/" + migrationId + ".log"

tbSplt = table.split(",")
multipleTables = False
tablewhereClouse = "like '" + table + "'"
if len(tbSplt) > 1:
   multipleTables = True 
   tablewhereClouse = "in ('" +  "','".join([str(elem) for elem in tbSplt])  + "')"
   
   

# get a Spark Session
spark=SparkSession.builder.appName('Gen_HiveVoltageParquetSQL_Decimal_Synapse').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

# hdm = historical_ddl_map, fetch hdm records filtered by database, table parms, expose them as temp view
###############################
# NOTE: using Dev 'historical_ddl_map_synapse' as source, until that version is promoted into Main 'historical_ddl_map'
###############################
hdmDF = spark.sql("""
   SELECT MAX(cast(hv_col_order AS INT)) OVER (partition by td_database, td_tab_name) as col_max, * 
   FROM historical_ddl_map_{} WHERE td_database = '{}' AND td_tab_name {} order by td_database,td_tab_name,td_col_order
""".format(migrationId,database,tablewhereClouse.lower()))
hdmDF = hdmDF.withColumn("migration_id", lit(migrationId))
hdmDF.createGlobalTempView("hdm")

tableList = spark.sql("""
   SELECT distinct td_database, td_tab_name
   FROM historical_ddl_map_{} WHERE td_database = '{}' AND td_tab_name {} order by td_database,td_tab_name
""".format(migrationId,database,tablewhereClouse.lower())).collect()

for rw in tableList:
    lne = "dbname:" + rw['td_database'] + ",tablename:" + rw['td_tab_name']
    logging.append(this_script + ":" +  lne)



# generate header text (note: verify comments with leading '--' on Azure platform)
headerDF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   concat("-- Name: ETL_",concat(td_database,'__',td_tab_name,'_', migration_id, '.sql')," Generated: ",current_timestamp," ID: ",
   date_format(current_timestamp, 'yyyyMMddHHmmssSSS'), "") as line, 
   -999999 as nbr from global_temp.hdm WHERE hv_col_order = col_max
""")

logging.append(headerDF.collect()[0]['line'])



# line4DF - Generate text segment to start creation of Polybase external table on Parquet file from on-prem in ADLS
line4DF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   concat("INSERT OVERWRITE TABLE PQ_", hv_schema, "__", hv_tab_name, "_", migration_id  ) as line,
   -2 as nbr from global_temp.hdm WHERE td_col_order = col_max
""")


# line5DF - Generate text segment to specify Polybase column names & types 
line5DF = spark.sql("""
   select td_database, td_tab_name, migration_id, 
   "SELECT" as line, 
   -1 as nbr from global_temp.hdm WHERE td_col_order = col_max
""")



# line6DF - 
sq = """select
    td_database,
    td_tab_name,
    migration_id,
    concat(
            CASE
                WHEN length(voltage_encrypt_fmt)= 0 THEN                
                case
                    when pq_notnull = 'NOT NULL' and (Upper(td_col_type) in ('VARCHAR','STRING','CHARACTER'))
                        Then concat('case when ', hv_col_name, ' is null then ',  "'' else trim(", hv_col_name , ') end ')
                    else 
                        case when (Upper(td_col_type) in ('VARCHAR','STRING','CHARACTER')) 
                            Then concat('case when ', hv_col_name, ' is null then null else case when length(regexp_replace(trim(', hv_col_name ,"),","'\\\u000d'",",'')",")=0 then null else trim(", hv_col_name , ') end end ')
                        ELSE 
                            hv_col_name
                        END
                END
            ELSE
                    case
                       when pq_notnull= 'NOT NULL' and (Upper(td_col_type) in ('VARCHAR','STRING','CHARACTER'))
                            Then concat(' case when ', hv_col_name, ' is null then ',  "'' else ", voltage_encrypt_udf, '(trim(',hv_col_name ,"),'", voltage_encrypt_fmt, "')", ' end ')
                    
                    else
                        case when upper(trim(td_col_type)) IN ('VARCHAR','STRING','CHARACTER') then concat("case when ",hv_col_name," IS NULL then NULL "," else case when length(regexp_replace(trim(", hv_col_name ,"),","'\\\u000d'",",'')",")=0 then null"," else ",voltage_encrypt_udf,"(translate(trim(",hv_col_name,"),'\\\u0000',''),","'",voltage_encrypt_fmt,"') ", 'end end ')
                    else
                        case
                            when upper(pq_col_type) = 'DECIMAL' then concat("cast(",voltage_encrypt_udf,'(',hv_col_name,",'",voltage_encrypt_fmt,"')" , " as double)" )
                            else  concat("case when " , hv_col_name, " is null then null else ", voltage_encrypt_udf,'(',hv_col_name,",'",voltage_encrypt_fmt,"') end")
                        end
                        end
                    END
            END,' as ',hv_col_name,',') as line,
    cast(hv_col_order as int) as nbr
from
    global_temp.hdm
WHERE
    hv_col_order < col_max"""

print(sq)
line6DF = spark.sql(sq)


# line7DF -
line7DF = spark.sql("""
   select td_database, td_tab_name,migration_id,
    concat(CASE WHEN length(voltage_encrypt_fmt)=0
               THEN case when pq_notnull= 'NOT NULL' and (Upper(td_col_type) in ('VARCHAR','STRING','CHARACTER'))  
                    Then concat('case when ', hv_col_name, ' is null then ',  "'' else trim(", hv_col_name , ') end ')
                  else case when (Upper(td_col_type) in ('VARCHAR','STRING','CHARACTER')) 
                            Then concat('case when ', hv_col_name, ' is null then null else case when length(regexp_replace(trim(', hv_col_name ,"),","'\\\u000d'",",'')",")=0 then null else trim(", hv_col_name , ') end end ')
                        ELSE 
                            hv_col_name
                        END
                    END
              ELSE case when pq_notnull= 'NOT NULL' and (upper(trim(td_col_type)) IN ('VARCHAR','STRING','CHARACTER'))  Then concat('case when ', hv_col_name, ' is null then ',  "'' else " ,  voltage_encrypt_udf, '(',trim(hv_col_name) ,",'", voltage_encrypt_fmt, "')", ' end ')
				else case when upper(trim(td_col_type)) IN ('VARCHAR','STRING','CHARACTER') then concat("case when ",hv_col_name," IS NULL then NULL ","else case when length(regexp_replace(trim(", hv_col_name ,"),","'\\\u000d'",",'')",")=0 then null"," else ",voltage_encrypt_udf,"(translate(trim(",hv_col_name,"),'\\\u0000',''),","'",voltage_encrypt_fmt,"') end  end  ")
					else case when upper(pq_col_type) = 'DECIMAL' then concat("cast(",voltage_encrypt_udf,'(',hv_col_name,",'",voltage_encrypt_fmt,"')" , " as double)" ) 
						else  concat("case when " , hv_col_name, " is null then null else ", voltage_encrypt_udf,'(',hv_col_name,",'",voltage_encrypt_fmt,"') end")   
						end 
					end
				END
              END,' as ',hv_col_name) as line,
     cast(hv_col_order as int) as nbr from global_temp.hdm WHERE hv_col_order = col_max
""")


# line8DF - Generate text segment for Synapse target table truncate statement prior to migration data insertion
line8DF = spark.sql("""
   select td_database, td_tab_name, migration_id,
   concat('FROM TD_',hv_schema,'__',hv_tab_name,'_' ,migration_id,'\073') as line,
   col_max+1 as nbr from global_temp.hdm WHERE td_col_order = col_max
   order by nbr asc
""")
 

# union the text segments into a single DF, expose as temp view 'components'
unionedDF = line4DF\
	.union(line5DF)\
	.union(line6DF)\
	.union(line7DF)\
    .union(line8DF)\
    .orderBy("nbr", ascending=True)

unionedDF = unionedDF.repartition(1)
#unionedDF = unionedDF.withColumn("migration_id" , lit(migrationId))
unionedDF.createGlobalTempView("unioned")
unionedDF.printSchema()
# concat the text segments seperated by newlines into a single block of component text for each database, table 
componentDF = spark.sql("""
	select td_database, td_tab_name as td_table,migration_id, concat('ETL_',td_database,'__',td_tab_name,'_',migration_id,'.sql') as component_name,
	current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text from global_temp.unioned
	group by td_database, td_tab_name,migration_id
""")
#componentDF.repartition(1).write.mode('overwrite').format('parquet').saveAsTable('dna_phase2.migration_component_customer_address_check')
# display the component text to STDOUT
componentDF.select("component_text").show(50,False)

# insert the records for selected (database, table) into table 'migration_component'
#componentDF.write.format("parquet").mode("append").saveAsTable("migration_component")
insertDF = spark.sql("""
	INSERT INTO migration_component_{}
	select td_database, td_tab_name as td_table, concat('ETL_',td_database,'__',td_tab_name,'_', migration_id,'.sql') as component_name,
	current_timestamp as creation_ts, concat_ws('\n',collect_list(line)) as component_text, '' as created_by 
	from global_temp.unioned
	group by td_database, td_tab_name,migration_id
""".format(migrationId))

listtoInsert = spark.sql("select distinct td_database, td_tab_name as td_table, migration_id, concat('ETL_',td_database,'__',td_tab_name,'_' , migration_id, '.sql') as component_name from global_temp.unioned").collect()
logging.append(this_script + ":" + "++++++++Append to migration_component START ++++++")
for rw in listtoInsert:
    lne = this_script + ":database:" + rw['td_database'] + ",tablename:" + rw['td_table'] + ",component_name:" + rw['component_name'] + ',migration_id:' + rw['migration_id']
    logging.append(lne)

logging.append(this_script + ":" + "++++++++Append to migration_component END ++++++")
logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")

file1 = open(fileName, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)



#ParquetToSynapse.py end of script

# -*- coding: utf-8 -*-
"""
Gen_Mapping_File.py

Python script to generate mapping file that maps Parquet files On-prem to ADLS.
Params: HDFS path, migrationId, mapping file folder location

04/26/2021 - Teena Kappen - Initial creation. Old code file_cp1.py edited and renamed.
05/13/2021 - Teena Kappen - Fix for file content issue when Database name has underscore character
12/06/2021 - Teena Kappen - Changed the code to fetch table details usig Spark SQL
"""
import os
import sys
import subprocess
from pyspark.sql import SparkSession

this_script = sys.argv[0]
basepath_input = sys.argv[1]
migrationId = sys.argv[2]
mapping_file_folder = sys.argv[3]
env = sys.argv[4]
hive_db = sys.argv[5]

recoverfilename = "./logs/" + migrationId + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " + this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " + this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;
print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
      splt = ln.split("::")

      if ((len(splt) > 1) & (splt[1] == "END")):
         print "this step  is over"
         sys.exit(0)
   os.system(reStartCmd)


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Hive data path: \'' + basepath_input + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:mapping file folder: \'' + mapping_file_folder + '\'')
filelog = "./logs/" + migrationId + ".log"

#create spark session
spark=SparkSession.builder.appName("Gen_Mapping_File").enableHiveSupport().getOrCreate()

#use Hive DB
spark.sql("use {}".format(hive_db))
spark.sql("set outputformat=tsv2;")

args = "hdfs dfs -ls "+basepath_input+" | grep pq_ | grep " + migrationId.lower() + " | awk '{print $8}'"
proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
logging.append ("args:" + args)

s_output, s_err = proc.communicate()
all_dart_dirs = s_output.split()

#create mapping file in common folder
flname = './move' + migrationId + '.csv'

logging.append ("mapping filename:" + mapping_file_folder+'/move' + migrationId + '.csv')

file1 = open(flname, "w")

for file in all_dart_dirs:
   print('filename-->'+file)
   splt = file.split("/")   
   fn = splt[len(splt) - 1]
   splitArray = fn.split("__")
   dbname = splitArray[0].replace("pq_","")
   tbname = splitArray[1].replace("_" + migrationId.lower() , "")
   print(tbname)
   print(dbname)
   df_result = spark.sql("select sf_schema,sf_table from teradata_snowflake_map where lower(trim(td_database))='{0}' and lower(trim(td_table))='{1}' and upper(trim(environment))='{2}'".format(dbname,tbname,env))
   sf_schema = df_result.select("sf_schema").collect()[0][0]
   sf_table = df_result.select("sf_table").collect()[0][0]
   locSuffix =  "/common/historical_data_migration/tables/" + migrationId.lower() + "/" + sf_schema.lower() + "/" + sf_table.lower() + "/"
   print(locSuffix)   
   lne1 = file.replace("/", '',1) + "/," + locSuffix
   logging.append("mapping file data:" + lne1)
   file1.write(lne1 + "\n")
   
file1.close()

os.system("mv "+flname +' '+mapping_file_folder)
os.system("touch -m "+mapping_file_folder)

logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")
file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.close()

os.system(endCmd)




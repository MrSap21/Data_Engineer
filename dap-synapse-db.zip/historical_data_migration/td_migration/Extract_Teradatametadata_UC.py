# -*- coding: utf-8 -*-
"""
Created on Fri Mar  5 16:02:44 2021

Pyspark script to generate Teradatametadata using TPT
Params: migration id, database, td host, td user, td password, metadata output file name

03/05/2021 - Teena Kappen - Initial creation
03/21/2021 - Carter Shore - Added .upper() to parms database & table

"""

import sys
import os

# process parms
nargs = len(sys.argv)

if nargs != 11: 
	print('Usage: Extract_Teradatametadata.py <Migration ID> <Hive DB name> <Teradata DB name pattern> <Teradata Table name pattern><Hadoop Host> <HDFS file path for CSV files> <td user> <td pw> <td host>')
	print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
	exit(-1)

this_script = sys.argv[0]
migration_id = sys.argv[1]
database = sys.argv[2].upper()
table = sys.argv[3].upper()
hadoop_host = sys.argv[4]
hdfs_filepath = sys.argv[5]
td_username = sys.argv[6]
td_password = sys.argv[7]
td_hostname = sys.argv[8]
tdclientlogpath = sys.argv[9]
tdclientchckpointpath = sys.argv[10]


#python Extract_Teradatametadata.py off123 DNADEVAPLDB00301 HADev /data/dnaphase2/source/db/dna_phase2 <td user> <td pw> tddev

log_file_name = "./logs/" + migration_id + ".log"

tpt_input_script = "export-tpt-metadata-to-hdfs.txt"
tpt_output_script = "tpt-metadata.txt"
metadata_output_file = hdfs_filepath+"teradatametadata_"+migration_id+"/metadata_extract.txt"

recoverfilename = "./logs/" + migration_id + ".proc"
cmd2 = "cat " + recoverfilename + " | grep " + this_script
startCmd = "echo " +  this_script + "::START >> " + recoverfilename
reStartCmd = "echo " + this_script + "::RESTART >> " + recoverfilename
endCmd = "echo " +  this_script + "::END >> " + recoverfilename
print(cmd2)
rpip = os.popen(cmd2)
lns = rpip.read()
recovery = True;

print(lns)
if len(lns) == 0:
   print("new migration")
   recovery = False
   os.system(startCmd)

if recovery == True:
   for ln in lns.split("\n"):
       splt = ln.split("::")
       if splt[1] == "END":
          print "this step  is over"
          sys.exit(0)
   os.system(reStartCmd)

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + database + '\'')

# handle database and table parms: single name, name pattern, or name CSV lists

if "," in database:
    databaseWhereClause = (" in (''" + database.replace(" ","").replace(",","'',''") + "'')")
else:
    databaseWhereClause = (" like " + "''" + database.replace(" ","") + "''")

print("databaseWhereClause:" + databaseWhereClause)
logging.append ("databaseWhereClause:" + databaseWhereClause)

if "," in table:
    tableWhereClause = (" in (''" + table.replace(" ","").replace(",","'',''") + "'')")
else:
    tableWhereClause = (" like " + "''" + table.replace(" ","") + "''")

print("tableWhereClause:" + tableWhereClause)
logging.append ("tableWhereClause:" + tableWhereClause)

input_file = open(tpt_input_script, "rt")
output_file = open(tpt_output_script, "w")

lines = []

#replace placeholders with input parameters
for inline in input_file:
    outline = inline
    if '@dbname' in inline:
        outline = inline.replace('@dbname', databaseWhereClause)   
    elif '@tablename' in inline:   
        outline = inline.replace('@tablename', tableWhereClause)
    elif  '@hadoophost' in inline:   
        outline = inline.replace('@hadoophost', "'"+hadoop_host+"'")
    elif '@filename' in inline:
        outline = inline.replace('@filename', "'"+metadata_output_file+"'")
    elif '@username' in inline:
        outline = inline.replace('@username', "'"+td_username+"'")
    elif '@userpassword' in inline:
        outline = inline.replace('@userpassword', "'"+td_password+"'")    
    elif '@tdpid' in inline:
        outline = inline.replace('@tdpid', "'"+td_hostname+"'") 
    lines.append(outline)
        
#write to TPT script    
for ln in lines:
    output_file.write(ln + "\n")
output_file.close()
input_file.close()

#write to log file    
file1 = open(log_file_name, "a")
for ln in logging:
    file1.write(ln)
file1.close()

print "debug step 1"


#run TPT script
#os.system("tbuild -f {0} -C -s 1 >> {1}".format(tpt_output_script,log_file_name))
os.system("tbuild -f {0} -L {2} -r {3} >> {1}".format(tpt_output_script,log_file_name,tdclientlogpath,tdclientchckpointpath))

print "debug step 2"

logging = []
logging.append(this_script + ":" + "++++++++Append to test_component END ++++++")
logging.append (this_script + ":" + "Job:++++" + this_script + " END ++++++++")

#write to log file    
file1 = open(log_file_name, "a")
for ln in logging:
    file1.write(ln + "\n")
file1.close()

os.system(endCmd)


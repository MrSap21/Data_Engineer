#!/bin/bash

## comment
# "migration_prod_sqoop_4.sh"
#
# 03/21/2021 - Carter Shore - Refresh_Metadata_Dictionary_Synapse_LC.py, Gen_HiveTptExportTableDDL_DECIMAL.synapse_LC.py, Gen_SqoopFromTd_LC.py,
#              Extract_Teradatametadata_UC.py, SQL_runner_LC.py, SQL_runner_ddl_LC.py.
# 03/26/2021 - Carter Shore - Refresh_Metadata_Dictionary_Synapse_LC1.py
#              NOTE: line 130 is commented out: # park-submit Gen_SqoopFromTd_LC.py ... disables TD extracts of large existing datasets
# 04/05/2021 - Carter Shore - Use sqoop to ORC table.
# 05/07/2021 - Teena Kappen - Added folder paths for Synapse DDLs and mapping file. Added code to call script to create mapping file. Added validaion flag.
# 07/15/2021 - Carter Shore - Add variable mig_env to establish Migration Environment to DEV,UAT,PRD, etc.
#              Pass 'mig_env' to Refresh_Metadata_Dictionary.py to generate appropriate migration metadata.
# 07/20/2021 - Carter Shore - Define var stagingformat with Snowflake External Stage File Format, pass into script Gen_PqToSnowFlake.py

###################
mig_env="PRD"
###################

# ############Enviorenment Var#####

# export JAVA_HOME=/usr/jdk64/jdk1.8.0_112;
# export PATH=$PATH:/usr/jdk64/jdk1.8.0_112;
# export HADOOP_HOME=/usr/hdp/2.6.4.0-91/hadoop;
# export PATH=$PATH:/usr/hdp/2.6.4.0-91/hadoop;
# export LIBHDFS_CLASSPATH=$(hadoop classpath --glob);
# export HTTPS_PROXY=corppac.walgreens.com:8080;
# export HTTP_PROXY=corppac.walgreens.com:8080;
# export SPARK_MAJOR_VERSION=2

# ###################
source dependencies_prod.sh

echo "JAVA_HOME: ${JAVA_HOME}"
echo "PATH: ${PATH}"
echo "HADOOP_HOME: ${HADOOP_HOME}"
echo "PATH: ${PATH}"
echo "LIBHDFS_CLASSPATH: ${LIBHDFS_CLASSPATH}"
echo "HTTPS_PROXY: ${HTTPS_PROXY}"
echo "HTTP_PROXY: ${HTTP_PROXY}"
echo "SPARK_MAJOR_VERSION: ${SPARK_MAJOR_VERSION}"
echo "HADOOP_CLASSPATH: ${HADOOP_CLASSPATH}"
echo "HIVE_HOME: ${HIVE_HOME}"
echo "HCAT_HOME: ${HCAT_HOME}"
echo "SQOOP_HOME: ${SQOOP_HOME}"
echo "LIB_JARS: ${LIB_JARS}"
###########Permissions##############
#chmod +rwx ./run_prod_sqoop.sh
chmod +rwx ./*.sh
chmod +rwx ./validation/validation_prod.sh
###################

hdfspath=/data/dna_phase_2/source/db/dnaphase2/encryptrpu/
###local landing folder for Snowflake DDL and SQL and mapping file
mappingfilefolder="/tmp/copytoadls/pro/migrationmapping/"
snowflakescriptsfolder="/tmp/copytoadls/pro/migrationddl/"
stagingadls="prod_pharmacy_healthcare.commonservice.extstage_dapprodadlsstg01"
stagingformat="PROD_PHARMACY_HEALTHCARE.public.fileformat_pq"

tdclientlogpath="/tmp/tpt_script_execution/logging/"
tdclientchckpointpath="/tmp/tpt_script_execution/checkpoint/"

hivedbname=$1
tddbname=$2  #  ${2,,} # lowercae td dbname
tablename=${3,,} # lowercae td tablename 
prefix=${4,,} # lowercase the prefix
startstep=$5
##TD variables to be passed##
hadoophost=$6
tdusername=$7
tdpassword=$8
tdhost=$9
mapperCount=${10}
fetchSize=${11}
validationFlag=${12}
#default value for row count limit for data comparison in validation 
rowCountLimit="20000"

echo $prefix
echo $tddbname
echo tablename

tptmaxsessions="8"
tptfilenum="1"
tptspoolmode="NoSpool"

DATE_WITH_TIME=`date "+%Y%m%d%H%M"`
echo $DATE_WITH_TIME
migrationId=$prefix$DATE_WITH_TIME
echo $migrationId
VAR=0
mkdir -p logs
mkdir -p $mappingfilefolder
mkdir -p $snowflakescriptsfolder
mkdir -p $tdclientlogpath
mkdir -p $tdclientchckpointpath

paramfilename="./logs/"${migrationId}.param
echo $paramfilename

echo hivedbname=$hivedbname > $paramfilename
echo tddbname=$tddbname >> $paramfilename
echo tablename=$tablename >> $paramfilename
echo prefix=$prefix >> $paramfilename
echo hadoophost=$hadoophost >> $paramfilename
echo tdhost=$tdhost >> $paramfilename
echo mapperCount=$mapperCount >> $paramfilename
echo fetchSize=$fetchSize >> $paramfilename
echo $hadoophost
echo $hivedbname
echo $tddbname
echo $tablename
echo $prefix
echo $tdhost
echo $mapperCount
echo $fetchSize

## generate metakk terdaa_<migration> // terd, cross, syna
## populate those metadata (// moving stuff) // move_csv.sh
### generate TD_FILE DDL 
#### copy teradata table using TPT
#### generate metadata for parquet table
#### run thedl
### generate script for voltage enyption, parquet
### execute conversion

## geneate metakk terdaa_<migration> // terd, cross, syna

spark-submit teradatametadata.ddl.py $migrationId $hivedbname $hdfspath

## populate those metadata (// moving stuff) // move_csv.sh

spark-submit  move_csv.py $migrationId $hivedbname $hdfspath

#run TPT script for teradatametadata table file
#this script requires export-tpt-metadata-to-hdfs.txt in the current directory
python Extract_Teradatametadata_UC.py $migrationId $tddbname $tablename $hadoophost $hdfspath $tdusername $tdpassword $tdhost $tdclientlogpath $tdclientchckpointpath

## refresh methadata historoical map ddl
spark-submit --executor-memory 6G --driver-memory 6G Refresh_Metadata_Dictionary.py $migrationId $hivedbname $mig_env
retVal=$?

echo $retVal

if [ $retVal -eq 1 ]
   
then
    
	echo "error in metadata"
    
	exit 1
   
fi


### generate TD_FILE DDL 
spark-submit Gen_HiveSqoopOrcDDL.py $migrationId $hivedbname $tddbname $tablename $hdfspath 
spark-submit SQL_runner_ddl_LC.py $migrationId $hivedbname $tddbname $tablename TD

# Use Sqoop to extract Teradata table data to Hive ORC target table
spark-submit Gen_SqoopFromTd_ORC.py $migrationId $hivedbname $tddbname $tablename $hdfspath $tdusername $tdpassword $tdhost $mapperCount $fetchSize

echo 'RUN generate parquet table DDL'
spark-submit Gen_HiveVoltageParquetDDL.py $migrationId $hivedbname $tddbname $tablename
spark-submit SQL_runner_ddl_LC.py $migrationId $hivedbname $tddbname $tablename PQ  
#
#echo 'RUN LOAD parquet + encryption'
spark-submit Gen_HiveVoltageParquetSQL.py $migrationId $hivedbname $tddbname $tablename
spark-submit --driver-memory 10G --executor-memory 12G SQL_runner_LC.py $migrationId $hivedbname $tddbname $tablename  ETL $mig_env  
#

echo 'RUN Snowflake DDL/DML Creation: ' 
spark-submit Gen_PqToSnowFlake.py $migrationId $hivedbname $tddbname $tablename $stagingadls $snowflakescriptsfolder $stagingformat
#
spark-submit Gen_Mapping_File.py $hdfspath $migrationId $mappingfilefolder $mig_env $hivedbname
#
##logic to call validation framework if flag is set to 'validate'
if [ "$validationFlag" == "validate" ] ; then   
    if [ -z "${13}" ] ; then
		echo "rowcount is null"    
		echo $rowCountLimit
    else
		rowCountLimit=${13}
		echo "rowcount has value"
		echo $rowCountLimit
    fi
    cd ./validation
   ./validation_prod.sh $hivedbname $migrationId $hdfspath $rowCountLimit "../logs/"
else
   echo "Validation flag not set. Migration will not be validated"
fi

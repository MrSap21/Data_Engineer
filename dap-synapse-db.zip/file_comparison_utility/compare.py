import subprocess
import os
from pyspark.sql import SparkSession
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import upper
import sys
from pyspark.sql.types import *
import ConfigParser
 

"""
Pyspark statement to compare on prem file with decrpted cloud file 
Parms: database, table 

16th June 2021 - Terry David - Initial creation

spark-submit compare.py compare.ini

"""
this_script = sys.argv[0]

configfile = sys.argv[1]
print("Reading config file: " +configfile)
Config = ConfigParser.ConfigParser()
Config.read(configfile)

hivedbname = Config.get("compare_factory","hivedbname")
voltagedir = Config.get("compare_factory","voltagedir")
decrypted_file_path = Config.get("compare_factory","decrypted_files")
out_path = Config.get("compare_factory","out_path")
error_file_path = Config.get("compare_factory","error_file_path")

spark=SparkSession.builder.appName('app1').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hivedbname))
sdf_table = spark.sql("set outputformat=tsv2;")

CURR_DIR = os.path.dirname(os.path.realpath(__file__))
csv_path='file://' + CURR_DIR + '/source.csv'
sdf_table = spark.read.options(header=True).csv(csv_path);

#sdf_table = spark.read.csv(csv_path);

sdf_table.createOrReplaceTempView("VS_DF_TEMP_VIEW")
VS_DF_NEW = spark.sql("select onprem_files,cloud_files,cloud_file_name,mapping_file,op_file_format,status FROM VS_DF_TEMP_VIEW where status='active'").collect()

#schema for output dataframe
schema = StructType([
             StructField('on_prem_file', StringType()),
             StructField('on_prem_count', StringType()),
             StructField('cloud_file', StringType()),
             StructField('cloud_file_count', StringType()),             
             StructField('status', StringType()),
             StructField('on_prem_vs_cloud', StringType()),
             StructField('cloud_vs_on_prem', StringType()),
             StructField('error_file_path1', StringType()),
             StructField('error_file_path2', StringType())
            ])
            
for items in VS_DF_NEW :
        print (items[0]+"|" + items[1]+"|"+items[2]+"|"+items[3])
        decryption_execution=('java -cp '+voltagedir+'/fpeencryption-jar-with-dependencies.jar -Djava.library.path='+voltagedir+'  com.walgreen.encrypt.Encrypt1CSV2 '+voltagedir+'/voltage.properties  '+items[3]+' '+items[1]+ ' '+items[2]+' '+decrypted_file_path+'/'+items[2]+'.'+items[4]+' d')
        print(decryption_execution)
        #cmd_var="./migration_dev_sqoop_orc.sh "+hivedbname+" "+items[2]+" "+items[3]+" "+prefix+" "+"' ' "+hadoophost+" "+tdusername+" "+tdpassword+" "+tdhost+" "+mappercount+" "+fetchsize+" "+'"'+items[4]+'"'+" "+items[7]+" "+items[5]+" "+items[6]
        os.system(decryption_execution)
        decrypt_file= 'file://' +decrypted_file_path+'/'+items[2]+'.'+items[4]
        on_prem_file= 'file://' +items[0]
        decrypt_table = spark.read.options(header=False).csv(decrypt_file);
        decrypt_table.show()
        decrypt_count= decrypt_table.count()
        on_prem_table = spark.read.options(header=False).csv(on_prem_file);
        on_prem_count= on_prem_table.count()
        on_prem_table.show()
        test_diff = on_prem_table.subtract(decrypt_table)
        diff_count = test_diff.count()
        test_diff2 = decrypt_table.subtract(on_prem_table)
        diff_count2 = test_diff2.count()
        print('******************************difference of on_prem_vs_cloud*************************************************')
        print(diff_count)
        print('******************************difference of cloud_vs_on_prem*************************************************')
        print(diff_count2)
        ValidationStatus = 'Success'
        error_file1=''
        error_file2=''
    
        if (diff_count != 0 or diff_count2 !=0):
            if(diff_count != 0):
                ValidationStatus = 'Failure'
                error_file1= 'file://' + error_file_path + '/' +'error_on_prem_vs_cloud_' +items[2]+'.'+items[4]
                test_diff.repartition(1).write.format('csv').option("compression","none").option("header", "false").save(error_file1)
            if(diff_count2 != 0):
                ValidationStatus = 'Failure'
                error_file2= 'file://' + error_file_path + '/' +'error_cloud_vs_on_prem_' +items[2]+'.'+items[4]
                test_diff2.repartition(1).write.format('csv').option("compression","none").option("header", "false").save(error_file2) 
            
            
        out_file= 'file://'+ out_path + '/' +'output_' +items[2]+'.'+items[4]
        new_df=spark.createDataFrame([(items[0],on_prem_count,items[1],decrypt_count,ValidationStatus,diff_count,diff_count2,error_file1,error_file2)], schema=schema)
        new_df.show()
        new_df.repartition(1).write.format('csv').option("compression","none").option("header", "true").save(out_file) 




import subprocess
import os
from pyspark.sql import SparkSession
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
from pyspark.sql.functions import upper
import sys

"""
Validation_Avg_Min_Max.py

Pyspark statement to generate Components that load Parquet files in ADLS to Synapse Tables
Parms: database, table 

03/16/2021 - Puneet Jaiswal - Initial creation


sample table-  td_dnadevapldb00301__dim_location_store_a_old_offshore202103050137 - Column-dim_loc_store_sk
 countvalidation_1test202103120837
 
 
spark-submit Validation_avg_sum.py offshore202103050137 dna_phase2 "" "td_dnadevapldb00301__dim_location_store_a_old_offshore202103050137" "dim_loc_store_sk"

spark-submit Validation_avg_sum.py offshore202103050137 dna_phase2
 

"""

nargs = len(sys.argv)

if nargs != 3: 
	print('Usage: file_min_max_avg.py <migrationid> <hive_db_name> <td_inscopedb_name> <tablename>')
	print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
	exit(-1)

this_script = sys.argv[0]
migrationId = sys.argv[1]
hive_db_name = sys.argv[2]
#td_database = sys.argv[3]
#var_table_name = sys.argv[4]

#td_database = sys.argv[3]
#table = sys.argv[4]
#column_Name = sys.argv[5]
#hv_metadata_table = sys.argv[6]


minmaxavg_table = "minmaxavg_"+migrationId

filelog = "./validation_logs/validation_" + migrationId + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Minmaxavg table: \'' + minmaxavg_table + '\'')


list1 = ""
i=1
vartsmt=""




spark=SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName('app1').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'

sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

"""
sdf_src_table = spark.sql("select distinct tablename from teradatametadata_"+migrationId)
list1=sdf_src_table.rdd.map(lambda x: (str(x[0]))).collect()
"""


sdf_table = spark.sql("select distinct tablename,columnname, hv_type, databasename, columnname from teradatametadata_"+migrationId+" md inner join col_type_xref_"+migrationId+"  clx on clx.td_type=md.columntype where hv_type in ('BIGINT', 'DECIMAL',   'DOUBLE',    'FLOAT' ,   'INT'    ,   'INTEGER' ,  'SMALLINT' ,  'TIMESTAMP', 'TINYINT' )");

list2=sdf_table.rdd.map(lambda x: (str(x[0]),str(x[1]),str(x[2]),str(x[3]),str(x[4]))).collect()

for item in list2:
    tablename = "td_"+item[3]+"__"+item[0]+"_"+migrationId
    logging.append("table name :"+ tablename)

    if len(list2) > i: 
        vartsmt = vartsmt+"select max("+item[1]+") as Max_Value"+ "," + "min(" + item[1] + ") as Min_Value"+ "," + "avg("+item[1]+") as AVG_Value"+ "," + "'"+ item[3]+"'" +" as DBNAME "+ ","+"'"+item[4]+"'" +" as col_name"+ ","+ "'"+tablename+"'"+" as Table_Name  FROM "+tablename+"\n"
        vartsmt = vartsmt+"union all"+"\n"
    else:
        vartsmt = vartsmt+"select max("+item[1]+") as Max_Value"+ "," + "min(" + item[1] + ") as Min_Value"+ "," + "avg("+item[1]+") as AVG_Value"+ ","+"'"+ item[3]+"'" +" as DBNAME "+ ","+"'"+item[4]+ "'" +" as col_name"+ ","+ "'"+tablename+"'"+" as Table_Name  FROM "+tablename
    i = i+1
    tablename=""
print ('*************************************')      
print (vartsmt)   
logging.append("vartsmt :"+ vartsmt)
print ('*************************************')  


  
sdmf=spark.sql(vartsmt)
#sdmf.show()      

sdmf.createOrReplaceTempView("smdf_temp_view")
sdmf_new = spark.sql("select  DBNAME, Table_Name ,col_name ,AVG_Value, Min_Value, Max_Value FROM smdf_temp_view ")
sdmf_new.printSchema()
sdmf_new.write.insertInto(minmaxavg_table)

logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()

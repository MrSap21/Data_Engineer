from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys

#command to run the script: spark-submit Metadata_Tables_Check.py <migration id> <hive db name>
#sample command to run the script: spark-submit Metadata_Tables_Check.py frm202103160049 dna_phase2

this_script  = sys.argv[0]
##############variables that can be configured###################
migration_id = sys.argv[1]   
hive_db_name = sys.argv[2]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')

#create Spark Session     
spark = SparkSession.builder.appName("Metadata_Tables_Check").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)

logging.append("using hive db :" + hive_db_name)


#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])
 
#logging.append(schema)


#function to insert record into Validationstatus table
def insertIntoValidationStatusTable(migration_step,validation_type,validation_status,table_name,row_count,column_count,result_details):
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')    
    new_row = spark.createDataFrame([("","",table_name,migration_step,validation_type,validation_status,result_details,None,row_count,None,column_count,migration_id,current_time)], schema=schema)
    new_row.createOrReplaceTempView("VS_DF_TEMP_VIEW")
    VS_DF_NEW = spark.sql("select td_database,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,validation_execution_time FROM VS_DF_TEMP_VIEW ")
    #Write the DataFrame to ValidationStatus Table
    VS_DF_NEW.write.insertInto('ValidationStatus'+"_"+migration_id,overwrite = False)

#function to validate metadata tables
def table_validation(table_name):    
    
    hive_table_name = table_name+"_"+migration_id

    logging.append("Hive table name : "+ hive_table_name)

    
    #check if table exists in Hive
    table_exists = bool(spark.sql("show tables like '{0}'".format(hive_table_name)).count())

    #check if table exists in the location    
    if bool(table_exists):  
        #update validation status to 'success' for table exists
        logging.append("table exists")

        #read table to dataframe
        table_df = spark.sql("select * from {0}".format(hive_table_name))
        
        #check for table row count
        row_count =  table_df.count()
        column_count = len(table_df.columns)
        
        
        if row_count > 0:
            insertIntoValidationStatusTable("CreateMetadataTable","ValidateMetadataTable","Success",hive_table_name,row_count,column_count,"")
        else:
            insertIntoValidationStatusTable("CreateMetadataTable","ValidateMetadataTable","Failure",hive_table_name,row_count,column_count,"EmptyTable")
    
    else:
        #update validation status to 'failure' for table does not exist
        logging.append("table Does not exist")
        insertIntoValidationStatusTable("CreateMetadataTable","ValidateMetadataTable","Failure",hive_table_name,None,None,"TableDoesNotExist")   

#call validation method for all metadata tables
table_validation("col_type_xref")                        
table_validation("column_encryption_spec")              
table_validation("historical_ddl_map")                                                               
table_validation("teradatametadata") 

#minmaxavg                             
#rowcount  

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")

file2.write("\n")
file2.write("\n")
file2.close()
    
spark.stop()
    




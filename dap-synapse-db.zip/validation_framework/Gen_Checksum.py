# -*- coding: utf-8 -*-
"""
Created on Tue Mar  24 13:18:36 2021

Python script to generate checksum

Params: Migration ID, Hive DB name, HDFS folder path

table name = <table name>_<migration_id>

03/24/2021 - Teena Kappen - Initial creation

"""

import hashlib
import os
import sys
from os.path import isfile
from pyspark.sql import SparkSession
from pyspark.sql.types import *
import subprocess

##############variables that can be configured###################
this_script  = sys.argv[0]
#migration id
migration_id =sys.argv[1]
#tenant id for Azcopy
#tenantid=sys.argv[2]
#app id for Azcopy
#app_id=sys.argv[3]
#landing parent folder for Azcopy
#adls_parent_folder=sys.argv[4]
#Hive DB Name
hive_db_name=sys.argv[2]
#Hive DB Path
hive_table_path=sys.argv[3]
#checksum folder path
checksum_folder_path = sys.argv[4]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:hive_table_path: \'' + hive_table_path + '\'')
logging.append(this_script + ":" + 'JobParams:checksum folder path: \'' + checksum_folder_path + '\'')



#manifest output file path
#checksum_folder_path='/tmp/copytoadls/checksum/'
os.system('mkdir -p '+checksum_folder_path)
manifest_file='./checksum_'+migration_id+'.csv'
tmp_file=checksum_folder_path+'checksum_'+migration_id+'.csv'

logging.append("Manifest file : "+ manifest_file)

#create Spark Session     
spark = SparkSession.builder.appName("File_Row_Column_Count").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)

#metadata table name for migration id
metadata_table = "teradatametadata_"+migration_id
logging.append("metadata table : "+ metadata_table)


#get column count for each table from metadata
df_metadata_column_counts = spark.sql("select databasename,tablename from "+metadata_table+" group by databasename,tablename")
table_list = df_metadata_column_counts.collect()

output_file = open(manifest_file, "w")

#iterate through list of tables in metadata
for item in table_list:
    databasename = item[0]
    tablename = item[1]
    logging.append("database name :"+ databasename)
    logging.append("table name:"+ tablename)
    #generate extracted file path using predefined format   
    hdfs_file_path = hive_table_path+"pq_"+databasename.lower()+"__"+tablename.lower()+"_"+migration_id
    logging.append("HDFS file path : " + hdfs_file_path)

    file_array = hdfs_file_path.split('/')
    file_name = file_array[len(file_array) - 1]
    	
    args = "hdfs dfs -ls "+hdfs_file_path+" | awk '{print $8}'"
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    s_output, s_err = proc.communicate()
    files = s_output.split()
            
    for item in files:       
        md5_args = "hdfs dfs -cat "+item+" | md5sum | awk '{print $1}'"
        proc = subprocess.Popen(md5_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        md5_output, md5_err = proc.communicate()
        md5value = md5_output.split()[0]           		                    
        value = str(md5value)+" "+item+"\n"      
        output_file.write(value)     
     
output_file.close()   

logging.append ("Job:++++" + this_script + " STOP ++++++++")

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close() 

#update last modified time of checksum folder
os.system('mv '+manifest_file+' '+tmp_file)
os.system('touch -m '+checksum_folder_path)

#copy the output file to ADLS
#os.system("./azcopy_login.sh "+tenantid+" "+app_id+" "+manifest_file+" "+ adls_folder_path) 

from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys

##############variables that can be configured###################
this_script  = sys.argv[0]
#Hive DB Name
hive_db_name = sys.argv[1]
#Hive Table Type
hive_table_type= sys.argv[2]
#Migration ID
migration_id = sys.argv[3]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Hive table type: \'' + hive_table_type + '\'')


#create Spark Session     
spark = SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName("Table_Row_Column_Count").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
#create Spark context
sc=spark.sparkContext
#create Hadoop file system class
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())

#metadata table names for migration id
metadata_table = "teradatametadata_"+migration_id
logging.append("Metadata table :"+ metadata_table)

metadata_table_for_row_counts = "rowcount_"+migration_id
logging.append("Metadata table for row counts :"+ metadata_table_for_row_counts)


#get column count for each table from metadata
df_metadata_column_counts = []

df_metadata_column_counts = spark.sql("select databasename,tablename,count(columnname) from "+metadata_table+" group by databasename,tablename")

table_list = df_metadata_column_counts.collect()

#get row count for each table from metadata table for row counts
df_metadata_row_counts = spark.sql("select td_database,table_name,row_count from "+metadata_table_for_row_counts)
#register temp table for metadata row counts
df_metadata_row_counts.registerTempTable("table_row_counts")

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', LongType()),
             StructField('destination_row_count', LongType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

#function to insert record into Validationstatus table
def insertIntoValidationStatusTable(databasename,tablename,result_detail,validation_type,validation_status,source_row_count,destination_row_count,source_column_count,destination_column_count):
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')    
    
    new_row = spark.createDataFrame([(databasename,tablename,hive_table_name,migration_step,validation_step+validation_type,validation_status,result_detail,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,current_time)], schema=schema)
    
    new_row.createOrReplaceTempView("VS_DF_TEMP_VIEW")
    VS_DF_NEW = spark.sql("select td_database,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,validation_execution_time FROM VS_DF_TEMP_VIEW ")
    #Write the DataFrame to ValidationStatus Table
    VS_DF_NEW.write.insertInto('ValidationStatus'+"_"+migration_id,overwrite = False)
    
#loop through the list of tables for the migration id 
for item in table_list:    
    databasename = item[0]
    tablename = item[1]
    column_count = item[2] 
    logging.append("database name :"+ databasename)
    logging.append("table name:"+ tablename)
    
    if hive_table_type== 'csv':
        hive_table_name = ("td_"+databasename+"__"+tablename+"_"+migration_id).lower()
        logging.append("Hive table name :"+ hive_table_name)

    elif hive_table_type== 'parquet':
        hive_table_name = ("pq_"+databasename+"__"+tablename+"_"+migration_id).lower()
        logging.append("Hive table name:"+ hive_table_name)

        
    #check if table exists in Hive
    table_exists = bool(spark.sql("show tables like '{0}'".format(hive_table_name)).count())

    #check if table exists in the location    
    if bool(table_exists):  
        result_detail = ""
        #read table to dataframe
        table_df = spark.sql("select * from {0}".format(hive_table_name))
        
        #set values to insert in Validationstatus table 
        migration_step = ""
        validation_step = ""
        
        if hive_table_type == 'csv':            
            migration_step = "CreateHiveCsvTable"
            validation_step = "TDVsHive"
        if hive_table_type == 'parquet':            
            migration_step = "CreateHiveParquetTable"
            validation_step = "TDVsParquet" 
      
        #########################compare column counts in metadata and table###########################       
        #get table column count
        table_column_count = len(table_df.columns)
               
        #compare column counts in metadata and table
        if table_column_count == column_count:
            column_validation_status = "Success"
        else:
            column_validation_status = "Failure"       

        logging.append("Column validaton status :"+ column_validation_status)
     
        
        #create dataframe for new row in ValidationStatus Table        
        insertIntoValidationStatusTable(databasename,tablename,"","ColumnCount",column_validation_status,None,None,column_count,table_column_count)    
        
              
        #########################compare row counts in metadata and table###########################
        table_row_count_source_l = spark.sql("select row_count from table_row_counts where lower(td_database)=lower('{0}') and lower(table_name)=lower('{1}')".format(databasename,tablename)).collect()
        
        #table_row_count_destination_l = spark.sql("select row_count from table_row_counts where lower(td_database)=lower('{0}') and lower(table_name)=lower('{1}')".format(databasename,hive_table_name)).collect()
        
        table_row_count_source=None
        table_row_count_destination=table_df.count()
            
        #check if row count is available in metadata
        if table_row_count_source_l:
            table_row_count_source=table_row_count_source_l[0][0]
            #table_row_count_destination=table_row_count_destination_l[0][0]
            
            #compare row counts
            if table_row_count_source == table_row_count_destination:
                row_validation_status = "Success"
            else:
                row_validation_status = "Failure"
            logging.append("Row validaton status :"+ row_validation_status)

        else:
            result_detail="SourceCountNotAvailable"       
            row_validation_status = "Failure"  
            table_row_count_source=None
            
        
        #create dataframe for new row in ValidationStatus Table
        insertIntoValidationStatusTable(databasename,tablename,result_detail,"RowCount",row_validation_status,table_row_count_source,table_row_count_destination,None,None)


logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")

file2.write("\n")
file2.write("\n")
file2.close()

spark.stop()
    




# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 20:32:55 2021

@author: kteena67
"""
##python Log_Row_Counts.py /data/dnaphase2/source/db/dna_phase2/ 1test202103120837 <logs folder path>

import os
import datetime
import time
import sys

##############variables that can be configured###################
#Hive Table Path
this_script = sys.argv[0]
output_file_path = sys.argv[1]
#Teradata DB Name
migration_id = sys.argv[2]
#Log file path
logs_folder = sys.argv[3]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:output file path: \'' + output_file_path + '\'')
logging.append(this_script + ":" + 'JobParams:logs folder: \'' + logs_folder + '\'')



#temporary location to store row counts
output_file_path = output_file_path+"rowcount_"+migration_id
logging.append('Output file path : \'' + output_file_path + '\'')

log_file_path = logs_folder +"/"+ migration_id + ".log"
print(log_file_path)
local_path = "./"+migration_id+"_rowcount.txt"
output_file = open(local_path, "w")

if os.path.exists(log_file_path):
    with open (log_file_path, 'rt') as myfile:
        for myline in myfile:

            if 'record_count' in myline and 'SQL_runner' in myline:
                linearray = myline.split(':')
                length = len(linearray)
                #extract database name and table name from log
                tablestring = linearray[length - 3]
                database = tablestring.split(".")[0]
                table = tablestring.split(".")[1]
                value = database+"|"+table+"|"+linearray[length - 1]
                output_file.write(value)

            if 'Map input records' in myline:
                linearray = myline.split(':')
                length = len(linearray)
                #extract database name and table name from log
                table = linearray[length - 2]
                database = linearray[length - 3]
                value = database+"|"+table+"|"+linearray[length - 1].split('=')[1]
                output_file.write(value)
                
else:
    print("log file does not exist") 

#copy the file to HDFS (Hive table folder location)
output_file.close()
os.system("hadoop fs -put -f {0} {1}".format(local_path,output_file_path))
#remove file from temp location
os.remove(local_path)

logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()
        
 
 

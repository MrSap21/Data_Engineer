from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys
import os

#spark-submit Convert_Table_To_Parquet.py dna_phase2 /data/dnaphase2/source/db/dna_phase2/ frm202103160049 92cb778e-8ba7-4f34-a011-4ba6e7366996 79b492f4-9f1f-4b7a-ae27-bb757857e43a

##############variables that can be configured###################
this_script  = sys.argv[0]
#Hive DB Name
hive_db_name = sys.argv[1]
#HDFS Path
hdfs_path = sys.argv[2]
#migration id
migration_id =sys.argv[3]
#mapping folder path
mapping_folder_path = sys.argv[4]
#adls_folder
adls_sub_folder = sys.argv[5]

#tenant id for Azcopy
#tenantid=sys.argv[4]
#app id for Azcopy
#app_id=sys.argv[5]
#landing parent folder for Azcopy
#adls_parent_folder=sys.argv[6]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:hdfs path: \'' + hdfs_path + '\'')
logging.append(this_script + ":" + 'JobParams:mapping folder path: \'' + mapping_folder_path + '\'')
logging.append(this_script + ":" + 'JobParams:adls folder path: \'' + adls_sub_folder + '\'')



#adls_sub_folder = "/common/tframework/tf_validationtables/"
#adls_folder_path = adls_parent_folder+"/tframework/tf_mapping/"
#mapping_folder_path='/tmp/copytoadls/validationmapping/'
os.system('mkdir -p '+mapping_folder_path)
file_name = "./TFmapping_"+migration_id+".csv"
print(file_name)
logging.append("Filename : "+ file_name)
tmp_file = mapping_folder_path+"TFmapping_"+migration_id+".csv"

#create Spark Session     
spark = SparkSession.builder.appName("Convert_Table_To_Parquet").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
f = open(file_name, "w")

def processFile(table_name):
    
    df = spark.sql("select * from {}".format(table_name))
    if table_name == "teradata_snowflake_map":
	    table_name=table_name+"_"+migration_id
    parquet_file=hdfs_path+"testframework/"+table_name
    df.repartition(1).write.mode('overwrite').parquet(parquet_file)   
    f.write(parquet_file+","+ adls_sub_folder+table_name+"/"+"\n")    

processFile("minmaxavg_"+migration_id)
processFile("rowcount_"+migration_id)
processFile("validationstatus_"+migration_id)
processFile("teradatametadata_"+migration_id)
processFile("teradata_snowflake_map")
f.close()

os.system("mv "+file_name +' '+tmp_file)
os.system("touch -m "+mapping_folder_path)

logging.append ("Job:++++" + this_script + " STOP ++++++++")

file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()  


#copy the output file to ADLS
#os.system("./azcopy_login.sh "+tenantid+" "+app_id+" "+file_name+" "+ adls_folder_path)

from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys

#spark-submit File_Row_Column_Count.py /data/dnaphase2/source/db/dna_phase2/ parquet dna_phase2 frm202103160049

##############variables that can be configured###################
this_script  = sys.argv[0]
#set main folder path in Hive
hive_table_path = sys.argv[1]
#file type
file_type= sys.argv[2]
#Hive DB Name
hive_db_name = sys.argv[3]
#migration id
migration_id =sys.argv[4]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Hive table path: \'' + hive_table_path + '\'')


#create Spark Session     
spark = SparkSession.builder.appName("File_Row_Column_Count").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
#create Spark context
sc=spark.sparkContext
#create Hadoop file system class
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())

#metadata table name for migration id
metadata_table = "teradatametadata_"+migration_id
logging.append("Metadata table :"+ metadata_table)

metadata_table_for_row_counts = "rowcount_"+migration_id
logging.append("Metadata table for row counts :"+ metadata_table_for_row_counts)


#get column count for each table from metadata
df_metadata_column_counts = spark.sql("select databasename,tablename,count(columnname) from "+metadata_table+" group by databasename,tablename")
table_list = df_metadata_column_counts.collect()


#get row count for each table from metadata table for row counts
df_metadata_row_counts = spark.sql("select td_database,table_name,row_count from "+metadata_table_for_row_counts)
#register temp table for metadata row counts
df_metadata_row_counts.registerTempTable("table_row_counts")

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', LongType()),
             StructField('destination_row_count', LongType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

#function to insert record into Validationstatus table
def insertIntoValidationStatusTable(databasename,tablename,result_detail,validation_type,validation_status,source_row_count,destination_row_count,source_column_count,destination_column_count):
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')    
    
    new_row = spark.createDataFrame([(databasename,tablename,file_path,migration_step,validation_step+validation_type,validation_status,result_detail,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,current_time)], schema=schema)
    
    new_row.createOrReplaceTempView("VS_DF_TEMP_VIEW")
    VS_DF_NEW = spark.sql("select td_database,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,validation_execution_time FROM VS_DF_TEMP_VIEW ")
    #Write the DataFrame to ValidationStatus Table
    VS_DF_NEW.write.insertInto('ValidationStatus'+"_"+migration_id,overwrite = False)
        
#iterate through list of tables in metadata
for item in table_list:
    databasename = item[0]
    tablename = item[1]
    column_count = item[2] 
    logging.append("database name :"+ databasename)
    logging.append("table name:"+ tablename)
    #generate extracted file path using predefined format
    if file_type == 'csv':
        file_path = hive_table_path+databasename+"/"+tablename+"_"+migration_id
        migration_step = "CSVExtract"
        validation_step = "TDVsCSV"       
        logging.append("file path :"+ file_path)
        logging.append("Migration step  : " + migration_step + ", validation step :" + validation_step)

    if file_type == 'parquet':
        file_path = hive_table_path+"pq_"+databasename.lower()+"__"+tablename.lower()+"_"+migration_id.lower()
        migration_step = "CreateParquet"
        validation_step = "TDVsParquet"
        logging.append("file path :"+ file_path)
        logging.append("Migration step  : " + migration_step + ", validation step :" + validation_step)
        
    path = sc._jvm.org.apache.hadoop.fs.Path(file_path)

#check if extracted CSV/Parquet file exists in the location    
    if fs.exists(path):
        if len(fs.listStatus(path)) > 0:
        
            table_row_count=0
            file_row_count=0
            
            if file_type == 'csv':
                file_df = spark.read.format("csv").option("header","false").option("delimiter","\001").load(file_path)       
                
            if file_type == 'parquet':           
                file_df = spark.read.parquet(file_path)       
                    
            #compare row counts in metadata and CSV
            table_row_count_l = spark.sql("select row_count from table_row_counts where lower(td_database)=lower('{0}') and lower(table_name)=lower('{1}')".format(databasename,tablename)).collect()
            
            #row count check
            #get count of rows in file
            file_row_count=file_df.count()
            #check if row count is available
            if table_row_count_l:
                table_row_count=table_row_count_l[0][0] 
                result_detail = ""
                #compare row counts
                if table_row_count == file_row_count:
                    row_validation_status = "Success"
                else:
                    row_validation_status = "Failure"
                logging.append("row validaton status :"+ row_validation_status)
            else:
                result_detail="SourceCountNotAvailable"            
                row_validation_status = "Failure"    
                        
            #create dataframe for new row in ValidationStatus Table
            insertIntoValidationStatusTable(databasename,tablename,result_detail,"RowCount",row_validation_status,table_row_count,file_row_count,None,None)
            
            #column count check
            #get count of columns in file
            file_column_count = len(file_df.columns)
            result_detail = ""
                        
            #compare column counts in metadata and file
            if file_column_count == column_count:
                column_validation_status = "Success"
            else:
                column_validation_status = "Failure"
                if file_row_count == 0:
                    result_detail = "EmptyFile"
            logging.append("Column validaton status :"+ column_validation_status)

            #create dataframe for new row in ValidationStatus Table        
            insertIntoValidationStatusTable(databasename,tablename,result_detail,"ColumnCount",column_validation_status,None,None,column_count,file_column_count)
            
        else:
            insertIntoValidationStatusTable(databasename,tablename,"EmptyFolder","ColumnCount","Failure",None,None,None,None)        
            insertIntoValidationStatusTable(databasename,tablename,"EmptyFolder","RowCount","Failure",None,None,None,None)
   
    else:        
        insertIntoValidationStatusTable(databasename,tablename,"FolderDoesNotExist","ColumnCount","Failure",None,None,None,None)        
        insertIntoValidationStatusTable(databasename,tablename,"FolderDoesNotExist","RowCount","Failure",None,None,None,None)
    

logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()

spark.stop()
    




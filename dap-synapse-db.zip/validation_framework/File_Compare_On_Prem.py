from pyspark.sql import SparkSession
from pyspark.sql.types import *
import datetime
import time
import sys
from pyspark.sql import functions as F
from pyspark.sql.functions import first
from pyspark.sql.functions import *

#spark-submit --executor-memory 6G --driver-memory 6G File_Compare_On_Prem.py /data/dnaphase2/source/db/dna_phase2/ dna_phase2 frm202103160049 10000

##############variables that can be configured###################
this_script  = sys.argv[0]
#set main folder path in Hive
hive_table_path = sys.argv[1]
#Hive DB Name
hive_db_name = sys.argv[2]
#migration id
migration_id = sys.argv[3]
#row count limit
row_count_limit = sys.argv[4]
##################################################################

filelog = "./validation_logs/validation_" + migration_id + ".log"

logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" + 'JobParams:Migration ID: \'' + migration_id + '\'')
logging.append(this_script + ":" + 'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:hive table path: \'' + hive_table_path + '\'')
logging.append(this_script + ":" + 'JobParams:row count limit: \'' + row_count_limit + '\'')
#create Spark Session     
spark = SparkSession.builder.config("hive.exec.orc.split.strategy","ETL").appName("File_Row_Column_Count").enableHiveSupport().getOrCreate()

#connect to Hive DB
spark.sql("use "+hive_db_name)
#create Spark context
sc=spark.sparkContext
#create Hadoop file system class
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())

#metadata table name for migration id
metadata_table = "teradatametadata_"+migration_id
metadata_table_for_row_counts = "rowcount_"+migration_id
logging.append("metadata_table : " +metadata_table)
logging.append("metadata_table for row counts : " +metadata_table_for_row_counts)

#get column count for each table from metadata
df_metadata_column_counts = spark.sql("select databasename,tablename,count(columnname) from "+metadata_table+" group by databasename,tablename")
table_list = df_metadata_column_counts.collect()

#get row count for each table from metadata table for row counts
df_metadata_row_counts = spark.sql("select td_database,table_name,row_count from "+metadata_table_for_row_counts)
#register temp table for metadata row counts
df_metadata_row_counts.registerTempTable("table_row_counts")

#schema for output dataframe
schema = StructType([
             StructField('td_database', StringType()),             
             StructField('source', StringType()),
             StructField('destination', StringType()),
             StructField('migration_step', StringType()),
             StructField('validation_type', StringType()),             
             StructField('validation_status', StringType()),
             StructField('result_details', StringType()),
             StructField('source_row_count', IntegerType()),
             StructField('destination_row_count', IntegerType()),
             StructField('source_column_count', IntegerType()),
             StructField('destination_column_count', IntegerType()),
             StructField('migration_id', StringType()),
             StructField('validation_execution_time', StringType())            
            ])

#function to insert record into Validationstatus table
def insertIntoValidationStatusTable(databasename,source,result_detail,validation_type,validation_status,source_row_count,destination_row_count,source_column_count,destination_column_count):
    current_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')    
    
    new_row = spark.createDataFrame([(databasename,source,file_path_parquet,migration_step,validation_step+validation_type,validation_status,result_detail,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,current_time)], schema=schema)
    
    new_row.createOrReplaceTempView("VS_DF_TEMP_VIEW")
    VS_DF_NEW = spark.sql("select td_database,source,destination,migration_step,validation_type,validation_status,result_details,source_row_count,destination_row_count,source_column_count,destination_column_count,migration_id,validation_execution_time FROM VS_DF_TEMP_VIEW ")
    #Write the DataFrame to ValidationStatus Table
    VS_DF_NEW.write.insertInto('ValidationStatus'+"_"+migration_id,overwrite = False)
        
#decrypt parquet
def decryptParquet(databasename,tablename,file_df_parquet):

    colstr=""
    colstrdy=""
    collist=[]
    
    #encryption spec table name
    col_enc_spec_table = "column_encryption_spec_"+migration_id
    logging.append("col_enc_spec_table : " +col_enc_spec_table)

    
    #get encryption details for the td table and db from column_encryption_spec_<migrationId> table
    columndf = spark.sql("select td_tab_name,td_col_name,voltage_udf_de from {2}  where lower(td_database)= lower('{0}') and lower(td_tab_name)=lower('{1}')".format(databasename,tablename,col_enc_spec_table));

    #get the list of all columns in parquet file dataframe
    df_column_list = file_df_parquet.schema.names
    
    #get the list of columns and the corresponding voltage udf to decrypt the column data
    collist=(columndf.groupby(columndf.td_tab_name).pivot("td_col_name").agg(first("voltage_udf_de")))
    collist=collist.schema.names
    collist.remove("td_tab_name")

    for i in range(len(collist)):
            if(len(colstr) != 0):
                colstr = colstr +" "+","+" "
            colstr = colstr+collist[i]        

    print(colstr) 

    #get the data for the td table and db from column_encryption_spec_<migrationId> table into a dataframe
    DF_DEC_FUN_PARAM = spark.sql("select td_tab_name,td_col_name,voltage_udf_de,voltage_format_de from {2}  where lower(td_database)= lower('{0}') and lower(td_tab_name)=lower('{1}')".format(databasename,tablename,col_enc_spec_table));
    DF_DEC_FUN_PARAM.show()

    #for i in range(len(collist)):
    for i in range(len(df_column_list)):
            if(len(colstrdy) != 0):
                colstrdy = colstrdy +" "+","+" "
            if df_column_list[i] in collist:
                df_dec = DF_DEC_FUN_PARAM.filter(DF_DEC_FUN_PARAM.td_col_name == df_column_list[i])
                list1=df_dec.rdd.map(lambda x: (str(x[2]),str(x[3]))).collect()
                for items in list1:
                    vol_func = items[0]
                    vol_func_format = items[1]
                if vol_func != "":   
                    colstrdy = colstrdy+vol_func+"("+df_column_list[i]+",'"+vol_func_format+"') as "+df_column_list[i]
                else:
                    colstrdy = colstrdy+" "+df_column_list[i]+" as "+df_column_list[i]
            else:
                colstrdy = colstrdy+" "+df_column_list[i]+" as "+df_column_list[i]
           
    print(colstrdy) 
    file_df_parquet.registerTempTable("table_parquet")
     
    if colstrdy=="":
        return file_df_parquet
    else:    
        dfen=spark.sql("select {0} from table_parquet".format(colstrdy))
        return dfen
    
#iterate through list of tables in metadata
for item in table_list:
    databasename = item[0]
    tablename = item[1]
    column_count = item[2]

    logging.append("database name : " +databasename)
    logging.append("table name: "+ tablename)


    #generate extracted file path using predefined format
    
    file_path_csv = hive_table_path+databasename+"/"+tablename+"_"+migration_id    
    validation_step = "CSVVsParquet"     
    logging.append("file path csv : "+ file_path_csv)
    file_path_parquet = hive_table_path+"pq_"+databasename.lower()+"__"+tablename.lower()+"_"+migration_id.lower()
    migration_step = "CreateParquet"
    logging.append("file path parquet: "+ file_path_parquet)
    
    table_name_parquet = "pq_"+databasename.lower()+"__"+tablename.lower()+"_"+migration_id
    table_name_csv = "td_"+databasename.lower()+"__"+tablename.lower()+"_"+migration_id 

    logging.append("table name parquet :" + table_name_parquet)
    logging.append("table name csv :" + table_name_csv)
        
    path_csv = sc._jvm.org.apache.hadoop.fs.Path(file_path_csv)
    path_parquet = sc._jvm.org.apache.hadoop.fs.Path(file_path_parquet)

#check if extracted CSV/Parquet file exists in the location    
    if fs.exists(path_parquet):
        if len(fs.listStatus(path_parquet)) > 0:
        
            #file_df_csv = spark.read.format("csv").option("header","false").option("delimiter","\001").load(file_path_csv)    
            file_df_csv = spark.sql("select * from {0}".format(table_name_csv))
            
            file_df_parquet = spark.read.parquet(file_path_parquet)       
                    
            #compare row counts in metadata and CSV
            parquet_table_row_count = spark.sql("select row_count from table_row_counts where lower(td_database)=lower('{0}') and lower(table_name)=lower('{1}')".format(databasename,table_name_parquet)).collect()[0][0]
            csv_table_row_count = spark.sql("select row_count from table_row_counts where lower(td_database)=lower('{0}') and lower(table_name)=lower('{1}')".format(databasename,table_name_csv)).collect()[0][0]
            
            result_detail=""            
            if csv_table_row_count <= int(row_count_limit):
             
                #compare column counts
                if len(file_df_csv.columns) == len(file_df_parquet.columns) and csv_table_row_count == parquet_table_row_count:
                    
                    #decrypt encrypted columns
                    file_df_decrypted = decryptParquet(databasename,tablename,file_df_parquet)
                    
                    #check the difference of the two dataframes
                    file_df_csv2=file_df_csv.select(*(trim(col(c)).alias(c) for c in file_df_csv.columns))
                    file_df_decrypted2=file_df_decrypted.select(*(trim(col(c)).alias(c) for c in file_df_decrypted.columns))
                    compare_df = file_df_csv2.subtract(file_df_decrypted2)
                    
                    if compare_df.count() == 0:
                        validation_status = "Success"
                    else:
                        validation_status = "Failure"
                    
                else:                   
                    result_detail=""            
                    validation_status = "Failure"
                logging.append("validation status :" + validation_status)         
                
                #create dataframe for new row in ValidationStatus Table    
                
                insertIntoValidationStatusTable(databasename,file_path_csv,result_detail,"",validation_status,None,None,None,None)
            
            else:               
                result_detail="FileSizeExceedsInputLimit"
                validation_status ="Unverified"
                logging.append("validation status :" + validation_status) 
                insertIntoValidationStatusTable(databasename,tablename,result_detail,"",validation_status,None,None,None,None)
        else:
            insertIntoValidationStatusTable(databasename,tablename,"EmptyFolder","","Failure",None,None,None,None)        
            insertIntoValidationStatusTable(databasename,tablename,"EmptyFolder","","Failure",None,None,None,None)
   
    else:        
        insertIntoValidationStatusTable(databasename,tablename,"FolderDoesNotExist","","Failure",None,None,None,None)        
        insertIntoValidationStatusTable(databasename,tablename,"FolderDoesNotExist","","Failure",None,None,None,None)

logging.append ("Job:++++" + this_script + " STOP ++++++++")


file2 = open(filelog, "a")
for ln in logging:
    file2.write(ln + "\n")
file2.write("\n")
file2.write("\n")
file2.close()  


spark.stop()
    




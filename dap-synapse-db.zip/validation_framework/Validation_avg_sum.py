import subprocess
import os
from pyspark.sql import SparkSession
from pyspark.sql import functions as f
from pyspark.sql.functions import lit
import sys

"""
Validation_Avg_Min_Max.py

Pyspark statement to generate Components that load Parquet files in ADLS to Synapse Tables
Parms: database, table 

03/16/2021 - Puneet Jaiswal - Initial creation


sample table-  td_dnadevapldb00301__dim_location_store_a_old_offshore202103050137 - Column-dim_loc_store_sk
 countvalidation_1test202103120837
 
 
spark-submit Validation_avg_sum.py offshore202103050137 dna_phase2 "" "td_dnadevapldb00301__dim_location_store_a_old_offshore202103050137" "dim_loc_store_sk"
 

"""

nargs = len(sys.argv)

if nargs != 6: 
	print('Usage: Validation_Avg_Min_Max.py <Hive DB name> <Teradata DB name pattern> <Teradata Table name pattern> <migrationId>')
	print('Enclose parms with embedded whitespace or punctuation in single quotes. Use \'%\' as pattern wild-card')
	exit(-1)

this_script = sys.argv[0]
migrationId = sys.argv[1]
hive_db_name = sys.argv[2]
td_database = sys.argv[3]
table = sys.argv[4]
column_Name = sys.argv[5]
#hv_metadata_table = sys.argv[6]


count_validation_table = "countvalidation_"+migrationId


logging = []
logging.append ("Job:++++" + this_script + " START ++++++++")
#print this_script
logging.append(this_script + ":" +  'JobParams:Hive database name: \'' + hive_db_name + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata database name pattern: \'' + td_database + '\'')
logging.append(this_script + ":" + 'JobParams:Teradata table name pattern: \'' + table + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + migrationId + '\'')
logging.append(this_script + ":" + 'JobParams:migrationId: \'' + column_Name + '\'')

#fileName = "./Validation_logs/" + migrationId + ".log"

spark=SparkSession.builder.appName('app1').enableHiveSupport().getOrCreate()

# set the Hive database with parm value 'hive_db_name'
sdf_table = spark.sql("use {0}".format(hive_db_name))
sdf_table = spark.sql("set outputformat=tsv2;")

#prereq - we needd to have data in hive metadaat table for the table which we need to validate.
#hdmDF = spark.sql("""
#  select columndatatype from {0} where databasename = {1} and tablename = {2} and columnname = {3}
#""".format(hv_metadata_table,hive_db_name,table,column_Name))

#columntype=hdmDF.collect()
#columntype = columntype[0][0]

#if (columntype not in ('string','varchar','date'):
    
smdf=spark.sql("select max({0}) as Max_Value,min({1}) as Min_Value, avg({2}) as AVG_Value from {3}".format(column_Name,column_Name,column_Name,table))
   
smdf = smdf.withColumn('td_database', lit(hive_db_name))
smdf = smdf.withColumn('Table_Name', lit(table))  
smdf = smdf.withColumn('column_Name', lit(column_Name))   
smdf.show(10)
smdf.createOrReplaceTempView("smdf_temp_view")
smdf_new = spark.sql("select  td_database, Table_Name ,column_name ,AVG_Value, Min_Value, Max_Value FROM smdf_temp_view ")
smdf_new.printSchema()
smdf_new.write.insertInto(count_validation_table)



#!/bin/bash

## comment


############Enviorenment Var#####
# export JAVA_HOME=/usr/jdk64/jdk1.8.0_60;
# export PATH=$PATH:/usr/jdk64/jdk1.8.0_60;
# export HADOOP_HOME=/usr/hdp/2.6.4.0-91/hadoop;
# export PATH=$PATH:/usr/hdp/2.6.4.0-91/hadoop;
# export LIBHDFS_CLASSPATH=$(hadoop classpath --glob);
# export HTTPS_PROXY=corppac.walgreens.com:8080;
# export HTTP_PROXY=corppac.walgreens.com:8080;
# export SPARK_MAJOR_VERSION=2
###################

source ../historical_data_migration/td_migration/dependencies_dev.sh

hivedbname=$1
migrationId=$2
hdfspath=$3
rowcountlimit=$4
logfilepath=$5

#startstep=$5
#tddbname=$2
#tablename=$3

echo $hivedbname
echo $migrationId
echo $hdfspath
echo $logfilepath
echo $rowcountlimit

mapping_folder="/tmp/copytoadls/dev/validationmapping/"
echo $mapping_folder

checksum_folder="/tmp/copytoadls/dev/checksum/"
echo $checksum_folder

adls_folder="/common/tframework/tf_validationtables/"
echo $adls_folder

mkdir -p validation_logs

VAR=0
if [ -z "$startstep" ]
then
     VAR=0 
else
     VAR=`expr $startstep + 0`
fi

#echo $VAR

##Generate validation tables in Hive
spark-submit Gen_Validation_Tables.py $migrationId $hivedbname $hdfspath

##Insert row counts from Teradata to rowcount_<migrationId> table
#spark-submit sqoop_count_New.py $migrationId $hivedbname $tddbname $hdfspath $tdusername $tdpassword $tdhost

##Insert row counts from migration log to rowcount_<migrationId> table
spark-submit Log_Row_Counts.py $hdfspath $migrationId $logfilepath

##check if metadata tables are created and they are not empty
spark-submit Metadata_Tables_Check.py $migrationId $hivedbname

##Validate row and column counts of csv tables in Hive
spark-submit Table_Row_Column_Count.py $hivedbname csv $migrationId

##Validate row and column counts of parquet tables in Hive
spark-submit Table_Row_Column_Count.py $hivedbname parquet $migrationId

##Validate row and column counts of parquet files
spark-submit File_Row_Column_Count.py $hdfspath parquet $hivedbname $migrationId

##calculate min max avg for numeric columns
spark-submit File_Min_Max_Avg.py $migrationId $hivedbname

##compare csv and parquet file data
spark-submit --executor-memory 6G --driver-memory 6G File_Compare_On_Prem.py $hdfspath $hivedbname $migrationId $rowcountlimit

##generate checksum file for parquet files
spark-submit Gen_Checksum.py $migrationId $hivedbname $hdfspath $checksum_folder

##generate mapping file for validation tables
spark-submit Convert_Table_To_Parquet.py $hivedbname $hdfspath $migrationId $mapping_folder $adls_folder


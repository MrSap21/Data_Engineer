/*
**************************************************************************************************************************
Script Name                          : Drop Columbus_Release3.2
Purpose                              : Drop Columbus_Release3.2
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================

**************************************************************************************************************************
*/ 


DROP TABLE ser_pharmaceuticals.Site;
DROP TABLE ser_pharmaceuticals.Party;
DROP TABLE  ser_pharmaceuticals.Product;
DROP TABLE  ser_pharmaceuticals.SiteRole;
DROP TABLE  ser_pharmaceuticals.SiteTerritory;
DROP TABLE  ser_pharmaceuticals.PartyRole;
DROP TABLE  ser_pharmaceuticals.PharmacyStore;
DROP TABLE ser_pharmaceuticals.ServiceCentre;
DROP TABLE ser_pharmaceuticals.Patient;
DROP TABLE ser_pharmaceuticals.PharmacyProduct;
DROP TABLE ser_pharmaceuticals.PharmacyProductSKU;
DROP TABLE ser_pharmaceuticals.PatientStore;
DROP TABLE ser_pharmaceuticals.StoreServiceCentre;
DROP TABLE ser_pharmaceuticals.PatientRegistration;
DROP TABLE ser_pharmaceuticals.ProductUsage;
DROP TABLE ser_pharmaceuticals.AverageTradeSellingPrice;
DROP TABLE ser_pharmaceuticals.BasicTariffSellingPrice;
DROP TABLE ser_pharmaceuticals.ProductProductSKU;
DROP TABLE ser_pharmaceuticals.PreferredProductSKU;
DROP TABLE ser_pharmaceuticals.ProductSKUUsage;
DROP TABLE ser_pharmaceuticals.ActualProductPack;
DROP TABLE ser_pharmaceuticals.PrescriptionGroup;
DROP TABLE ser_pharmaceuticals.PrescriptionFormType;
DROP TABLE ser_pharmaceuticals.ElectronicPrescription;
DROP TABLE ser_pharmaceuticals.Stock;
DROP TABLE ser_pharmaceuticals.StockAdjustment;
DROP TABLE ser_pharmaceuticals.CountList ;
DROP TABLE ser_pharmaceuticals.ReplenishmentOrderLine;
DROP TABLE ser_pharmaceuticals.PurchaseOrder;
DROP TABLE ser_pharmaceuticals.StockMovement;
DROP TABLE ser_pharmaceuticals.OverStock;
DROP TABLE ser_pharmaceuticals.ElectronicPrescribedItem;
DROP TABLE ser_pharmaceuticals.PrescriptionForm;
DROP TABLE ser_pharmaceuticals.StockAdjustmentItem;
DROP TABLE ser_pharmaceuticals.StockAdjustmentReason;
DROP TABLE ser_pharmaceuticals.StockItem;
DROP TABLE ser_pharmaceuticals.CountListItem;
DROP TABLE ser_pharmaceuticals.ReplenishmentItem;
DROP TABLE ser_pharmaceuticals.PurchaseOrderLine;
DROP TABLE ser_pharmaceuticals.StockMovementItem;
DROP TABLE ser_pharmaceuticals.OverStockItem;
DROP TABLE ser_pharmaceuticals.DispensingSupportPharmacyTracking;
DROP TABLE ser_pharmaceuticals.DispensingEvent;
DROP TABLE ser_pharmaceuticals.PrescribedItem;
DROP TABLE ser_pharmaceuticals.StockSupplyAudit;
DROP TABLE ser_pharmaceuticals.DailyDispensedQuantity;
DROP TABLE ser_pharmaceuticals.AdditionalEndorsement;
DROP TABLE ser_pharmaceuticals.AdditionalItem;
DROP TABLE ser_pharmaceuticals.SpecialItem;
DROP TABLE ser_pharmaceuticals.OutOfPocketExpenses;
DROP TABLE ser_pharmaceuticals.NoCheaperStockObtanaible;
DROP TABLE ser_pharmaceuticals.PrescribedProduct;
DROP TABLE ser_pharmaceuticals.Owing;
DROP TABLE ser_pharmaceuticals.MasterPrescribedItem;
DROP TABLE ser_pharmaceuticals.Instalment;
DROP TABLE ser_pharmaceuticals.InstalmentItem;
DROP TABLE ser_pharmaceuticals.DispensedItem;
DROP TABLE ser_pharmaceuticals.DispensedProduct;
DROP TABLE ser_pharmaceuticals.Parameter;
DROP TABLE ser_pharmaceuticals.ParameterValue;
DROP TABLE ser_pharmaceuticals.MessageNotification;
DROP TABLE ser_pharmaceuticals.MessageReason;

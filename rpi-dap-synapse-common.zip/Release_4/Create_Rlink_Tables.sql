/
**************************************************************************************************************************
Script Name                          : Create_Rlink_Version1.1 
Purpose                              : Create Table Script for Resource Link
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================
04-Apr-2022   : Anisoor Rahman           : Created DDL script for Rlink     
14-Apr-2022   : Pandiarajan               : Removed SCD Columns and Changed the Datatype                            

**************************************************************************************************************************
*/

--#1 AbsenceType 

CREATE TABLE [ser_hr].[AbsenceType]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
AbsenceType VARCHAR(6) NOT NULL,
AbsenceTypeMLRowReference VARCHAR(15),
AbsenceTypeName VARCHAR(8),
AbsenceTypeUDFScreenReference VARCHAR(8),
AbsencePayslipCalTakenFlag VARCHAR(1),
AbsencePayslipUpdateENTFlag VARCHAR(1),
AbsenceType15MEntryFlag VARCHAR(1),
AbsenceTypeAttributeType VARCHAR(6),
AbsenceTypeCreateFlag VARCHAR(1),
AbsenceTypeDocumentLinkDirectory VARCHAR(15),
AbsenceTypeENTOnPayslip VARCHAR(1),
AbsenceTypeKronosEntitlement VARCHAR(1),
AbsenceTypeKronosGoLive VARCHAR(1),
AbsenceTypeLinkType VARCHAR(6),
AbsenceTypeLongDescription VARCHAR(40),
AbsenceTypeMaternityRelated VARCHAR(1),
AbsenceTypeMVMonWorkCode VARCHAR(3),
AbsenceTypeMVScreenTitle VARCHAR(40),
AbsenceTypeMVTimeEntry VARCHAR(6),
AbsenceTypeNarrativeCategory VARCHAR(6),
AbsenceTypeObsoleteDate DATE,
AbsenceTypeOverlapType VARCHAR(6),
AbsenceTypeOverrideType VARCHAR(6),
AbsenceTypePayslipAmountFlag VARCHAR(1),
AbsenceTypeShortCode VARCHAR(3),
AbsenceTypeDescription VARCHAR(10),
AbsenceTypeStatusHoldIndicator VARCHAR(1),
AbsenceTypeSubTypesFlag VARCHAR(1),
AbsenceTypeTeamEntlTitle1 VARCHAR(10),
AbsenceTypeTeamEntlTitle2 VARCHAR(10),
AbsenceTypeTeamEntlTitle3 VARCHAR(10),
AbsenceTypeTViewENTLFlag VARCHAR(1),
AbsenceTypeTwoYearFlag VARCHAR(1),
AbsenceUKType1 VARCHAR(6),
AbsenceTypeVacancyPayFlag VARCHAR(1),
AbsenceTypeViewEntlFlag VARCHAR(1),
AbsenceTypeWorkedFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#2 ActionRelationCode

CREATE TABLE [ser_hr].[ActionRelationCode]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
ActionRelationCodeReference VARCHAR(8) NOT NULL,
ActionRelationCodeCategory VARCHAR(6) NOT NULL,
ActionRelationCodeModuleCode VARCHAR(6) NOT NULL,
ActionRelationCodeNarrativeCode VARCHAR(6) NOT NULL,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
ActionRelationCodeScore INT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#3 ActionRelationHeader

CREATE TABLE [ser_hr].[ActionRelationHeader]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
DependentCategoryChild VARCHAR(6) NOT NULL,
DependentCategoryParent VARCHAR(6) NOT NULL,
DependentModuleCode VARCHAR(6) NOT NULL,
OGGReplicatedDateandTime DATE,
DependentScoreAllowed VARCHAR(1),
DependentTopLevel VARCHAR(1),
OGGOperation VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#4 ActionRelationType

CREATE TABLE [ser_hr].[ActionRelationType]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
ActionRelationTypeReference VARCHAR(8) NOT NULL,
ActionRelationTypeKey1 VARCHAR(14) NOT NULL,
ActionRelationTypeKey2 VARCHAR(14) NOT NULL,
ActionRelationTypeKey3 VARCHAR(14) NOT NULL,
ActionRelationTypeKey4 VARCHAR(14) NOT NULL,
ActionRelationTypeKey5 VARCHAR(14) NOT NULL,
ActionRelationTypeModuleCode VARCHAR(6),
OGGOperation VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#5 Address

CREATE TABLE [ser_hr].[Address]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
AddressReference VARCHAR(20) NOT NULL,
SourceReference VARCHAR(8),
AddresMLRowReference VARCHAR(15),
AddressMunicipality VARCHAR(255),
AddressPostalLine1 VARCHAR(264),
AddressPostalLine2 VARCHAR(264),
AddressPostalLine3 VARCHAR(264),
AddressPostalLine4 VARCHAR(264),
AddressPostalLine5 VARCHAR(264),
AddressPostalLine6 VARCHAR(264),
AddressPostalLine7 VARCHAR(264),
AddressPostalLine8 VARCHAR(264),
AddressRegion VARCHAR(264),
AddressLineFour VARCHAR(264),
AddressLineOne VARCHAR(264),
AddressLineThree VARCHAR(264),
AddressLineTwo VARCHAR(264),
OGGOperation VARCHAR(2),
AddressPostCode VARCHAR(20),
SourceIndicator VARCHAR(1),
AddressCountryId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#6 Appraisal

CREATE TABLE [ser_hr].[Appraisal]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
AppraisalCode VARCHAR(6) NOT NULL,
AppraisalApplicationTypeQuesReference VARCHAR(8),
AppraisalNoteReference VARCHAR(8),
AppraisalFrequency DECIMAL(22,2),
AppraisalFrequencyUnit VARCHAR(1),
AppraisalLETCode VARCHAR(8),
AppraisalLETVersion VARCHAR(3),
AppraisalLongDescription VARCHAR(40),
AppraisalOccurs DECIMAL(22,1),
OGGOperation VARCHAR(2),
AppraisalShortDescription VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#7 AttendenceCategory

CREATE TABLE [ser_hr].[AttendenceCategory]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
AttendanceCategory VARCHAR(10) NOT NULL,
AttendanceCategoryType VARCHAR(6) NOT NULL,
AttendanceCategoryActionFlag VARCHAR(1),
AttendanceCategoryLongDescription VARCHAR(40),
AttendanceCategoryMLRowRefrence VARCHAR(15),
AttendanceCategoryShortDescription VARCHAR(10),
OGGOperation VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#8 AttendanceStatusType

CREATE TABLE [ser_hr].[AttendanceStatusType]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
AttendanceType VARCHAR(6) NOT NULL,
AttendanceTypeMlRowReference VARCHAR(15),
AttendanceType15MEntryFlag VARCHAR(1),
AttendanceTypeLongDescription VARCHAR(40),
AttendanceTypeMVCrossCharge VARCHAR(1),
AttendanceTypeMVScreenTitle VARCHAR(40),
AttendanceTypeMVTimeEntry VARCHAR(6),
AttendanceTypeShortCode VARCHAR(3),
AttendanceTypeShortDescription VARCHAR(10),
OGGOperation VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#9 CostCentre

CREATE TABLE [ser_hr].[CostCentre]
(
CostCentreCode VARCHAR(20) NOT NULL,
CostCentreSKID BIGINT NOT NULL,
CostCentreName VARCHAR(20),
CostCentreDescription VARCHAR(40),
CostCentreCreatedDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#10 CostCentreDetail

CREATE TABLE [ser_hr].[CostCentreDetail]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
CostCentreSKID BIGINT NOT NULL,
CostCentreNoteReference VARCHAR(8),
CostCentreReference VARCHAR(40),
OGGOperation VARCHAR(2),
CostCentreShortCC VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#11 EmployeeCostCentre

CREATE TABLE [ser_hr].[EmployeeCostCentre]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
CostCentreReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
EffectiveCompDate INT NOT NULL,
Source VARCHAR(2) NOT NULL,
ERSPercentage DECIMAL(5,2),
OGGOperation VARCHAR(2),
EESPercentage DECIMAL(5,2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#12 Currency

CREATE TABLE [ser_hr].[Currency]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
CurrencyIdentifier VARCHAR(4) NOT NULL,
CurrencyNoteReference VARCHAR(8),
CountryContributionPEId1 VARCHAR(4),
CountryContributionPEId10 VARCHAR(4),
CountryContributionPEId2 VARCHAR(4),
CountryContributionPEId3 VARCHAR(4),
CountryContributionPEId4 VARCHAR(4),
CountryContributionPEId5 VARCHAR(4),
CountryContributionPEId6 VARCHAR(4),
CountryContributionPEId7 VARCHAR(4),
CountryContributionPEId8 VARCHAR(4),
CountryContributionPEId9 VARCHAR(4),
CountryFemaleRetireAge INT,
CountryMaleRetireAge INT,
CountryNameInBannerId VARCHAR(10),
CountryTaxDay VARCHAR(2),
CountryTaxMonth VARCHAR(2),
CountryTaxEndYear VARCHAR(1),
CurrencySymbol VARCHAR(4),
CurrencyUnit VARCHAR(10),
CurrencyUnitFactor INT,
CurrencyLongDescription VARCHAR(40),
CurrencyObsoleteDate DATE,
OGGOperation VARCHAR(2),
CurrencyShortDescription VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#13 DelegationRuleDefinition

CREATE TABLE [ser_hr].[DelegationRuleDefinition]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
RuleReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8),
RuleCreatedPersonReference VARCHAR(8),
RuleSelectOptionReference VARCHAR(8),
RuleUpdatedPersonReference VARCHAR(8),
OGGOperation VARCHAR(2),
RuleAbsentFlag VARCHAR(1),
RuleCategoryIndicator VARCHAR(1),
RuleFromDate DATE,
RuleItemAccessLevel VARCHAR(6),
RuleSuppressAuthorisedFlag VARCHAR(1),
RuleTitle VARCHAR(60),
RuleToDate DATE,
RuleTypeIndicator VARCHAR(1),
RuleItemId VARCHAR(10),
RuleModuleId VARCHAR(10),
RuleViewId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#14 DelegationRuleModule

CREATE TABLE [ser_hr].[DelegationRuleModule]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
RuleModuleReference VARCHAR(8) NOT NULL,
RuleReference VARCHAR(8),
OGGOperation VARCHAR(2),
RuleModuleAccessLevel VARCHAR(6),
RuleModuleType VARCHAR(1),
RuleModuleId VARCHAR(10),
RuleViewId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(EmployeePostGrade
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#15 DelegationRulePath

CREATE TABLE [ser_hr].[DelegationRulePath]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
RulePathReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8),
PostReference VARCHAR(8),
RuleReference VARCHAR(8),
RulePathPosition BIGINT,
StructureReference VARCHAR(8),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#16 PartyEmail

CREATE TABLE [ser_hr].[PartyEmail]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
EmailObjectKey VARCHAR(255) NOT NULL,
EmailObjectId VARCHAR(10) NOT NULL,
EmailAddress VARCHAR(280),
PartyEmailNote VARCHAR(40),
EmailAddressHome VARCHAR(80),
EmailAddressHomeDescription VARCHAR(40),
EmailDefaultHomeFlag VARCHAR(15),
EmailIntAppsWorkHome VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#17 EmployeeAbsenceAttendance

CREATE TABLE [ser_hr].[EmployeeAbsenceAttendance]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
EmployeeAbsencePostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
EmployeeAttendancePostSTCompDate INT NOT NULL,
EmployeeAttendanceStartCompDate INT NOT NULL,
EmployeeAttendanceStartTime INT NOT NULL,
EmployeeAbsenceCostCentreReference VARCHAR(8),
EmployeeAttendanceSSPPWTAPPFlag VARCHAR(1),
EmployeeAttendanceAbsenceReasonType VARCHAR(6),
EmployeeAttendanceActionFlag VARCHAR(1),
EmployeeAttendanceAdditionalPayFlag VARCHAR(1),
EmployeeAttendanceAdditionalPerPayAmount DECIMAL(11,5),
EmployeeAttendanceContractPayRate DECIMAL(11,5),
EmployeeAttendanceRateofPay DECIMAL(11,5),
EmployeeAttendanceAuthorisedCertificateFlag VARCHAR(1),
EmployeeAttendanceAverageDayPayFlag VARCHAR(1),
EmployeeAttendanceSSPPIWBENDaysPaid INT,
EmployeeAttendanceCalcDate DATE,
EmployeeAttendanceCategory1CFWDDays DECIMAL(11,5),
EmployeeAttendanceCategory1CFWDHours DECIMAL(11,5),
EmployeeAttendanceCategory2CFWDDays DECIMAL(11,5),
EmployeeAttendanceCategory2CFWDHours DECIMAL(11,5),
EmployeeAttendanceCause VARCHAR(6),
EmployeeAttendanceCertificateExpiryDate DATE,
EmployeeAttendanceCertificateType VARCHAR(6),
EmployeeAttendanceTCFWDDays DECIMAL(11,5),
EmployeeAttendanceTCFWDHours DECIMAL(11,5),
EmployeeAttendanceChargeFlag VARCHAR(1),
EmployeeAttendanceContractNPay DECIMAL(11,5),
EmployeeAttendanceContractPayFlag VARCHAR(1),
EmployeeAttendanceContractPE VARCHAR(4),
EmployeeAttendanceDaysRequested DECIMAL(11,5),
EmployeeAttendanceTDaysTakenCategory1 DECIMAL(11,5),
EmployeeAttendanceTDaysTakenCategory2 DECIMAL(11,5),
EmployeeAttendanceDefinitiveHoursInADay DECIMAL(7,5),
EmployeeAttendanceEndDayType VARCHAR(1),
EmployeeAttendanceENTCalcPoint VARCHAR(2),
EmployeeAttendanceENTCalcType VARCHAR(6),
EmployeeAttendanceENTCategoryDescription VARCHAR(20),
EmployeeAttendanceENTCategoryType VARCHAR(6),
EmployeeAttendanceENTALCTNIndicator VARCHAR(1),
EmployeeAttendanceEntryStatus VARCHAR(1),
EmployeeAttendanceFromHoursOff DECIMAL(7,5),
EmployeeAttendanceHealthSafetyFlag VARCHAR(1),
EmployeeAttendanceHigherLevelPercentage DECIMAL(5,2),
EmployeeAttendanceHoursRequested DECIMAL(11,5),
EmployeeAttendanceTHoursTakenCategory1 DECIMAL(11,5),
EmployeeAttendanceTHoursTakenCategory2 DECIMAL(11,5),
EmployeeAttendanceAbsenceLinkDate DATE,
EmployeeAttendanceAbsenceLinkDFlag VARCHAR(1),
EmployeeAttendanceLowerLevelPercentage DECIMAL(11,5),
EmployeeAttendanceSSPLPIWStartDate DATE,
EmployeeAttendanceMGRTDPaymentFlag VARCHAR(1),
EmployeeAttendanceMultiContractFlag VARCHAR(1),
EmployeeAttendanceNarrativeCode VARCHAR(6),
EmployeeAttendanceNOWPFlag VARCHAR(1),
EmployeeAttendanceNormalPay DECIMAL(11,5),
EmployeeAttendanceNWTContractRate DECIMAL(11,5),
EmployeeAttendanceNWTFlag VARCHAR(1),
EmployeeAttendanceNWTPayRate DECIMAL(11,5),
EmployeeAttendanceMVOverrideENTFlag VARCHAR(1),
EmployeeAttendanceMVOverridePayFlag VARCHAR(1),
EmployeeAttendancePayDaysRequested DECIMAL(11,5),
EmployeeAttendancePayHoursRequested DECIMAL(11,5),
EmployeeAttendancePayPE VARCHAR(4),
EmployeeAttendanceRLBPayPercent DECIMAL(5,2),
EmployeeAttendancePaymentPercent DECIMAL(5,2),
EmployeeAttendanceSSPPIWAveragePay DECIMAL(10,2),
EmployeeAttendanceSSPPIWBENAmount INT,
EmployeeAttendanceSSPPIWBENRate DECIMAL(12,4),
EmployeeAttendanceSSPPIWStartDate DATE,
EmployeeAttendancePreviousUpdatedBy VARCHAR(50),
EmployeeAttendancePreviousUpdatedDate DATE,
EmployeeAttendancePWTNumberOfReports INT,
EmployeeAttendanceAbsenceReason VARCHAR(6),
EmployeeAttendanceReturnWeekINTVWDate DATE,
EmployeeAttendanceRLBBandPercentage1 DECIMAL(5,2),
EmployeeAttendanceRLBBandPercentage2 DECIMAL(5,2),
EmployeeAttendanceRLBBandPercentage3 DECIMAL(5,2),
EmployeeAttendanceSSPExcelCode1 VARCHAR(6),
EmployeeAttendanceSSPIgnoreContractDays INT,
EmployeeAttendanceSSPPIWBand INT,
EmployeeAttendanceSSPPIWGeneralAmount DECIMAL(10,2),
EmployeeAttendanceSSPPIWWeeks DECIMAL(12,4),
EmployeeAttendanceSSPWithheldDays INT,
EmployeeAttendanceStartDayType VARCHAR(1),
EmployeeAttendanceAbsenceSubType VARCHAR(6),
EmployeeAttendanceToHoursOff DECIMAL(7,5),
EmployeeAttendanceTotalAbsenceContract DECIMAL(11,5),
EmployeeAttendanceTotalAbsencePay DECIMAL(11,5),
EmployeeAttendanceTotalDaysPaid DECIMAL(11,5),
EmployeeAttendanceTotalDaysTaken DECIMAL(11,5),
EmployeeAttendanceINSTAbsenceTotalHours DECIMAL(10,5),
EmployeeAttendanceTotalHoursPaid DECIMAL(11,5),
EmployeeAttendanceTotalHoursTaken DECIMAL(11,5),
EmployeeAttendanceAbsenceType VARCHAR(6),
EmployeeAttendanceUnitType VARCHAR(1),
EmployeeAttendanceWaitDaysServed INT,
EmployeeAttendanceTAddtionalDaysPaid DECIMAL(11,5),
EmployeeAttendanceTAddtionalDaysTaken DECIMAL(11,5),
EmployeeAttendanceTAddtionalHoursPaid DECIMAL(11,5),
EmployeeAttendanceTAddtionalHoursTaken DECIMAL(11,5),
EmployeeAttendanceNWTAdditionalPayRate DECIMAL(11,5),
EmployeeAttendancePPCForwardFlag VARCHAR(1),
EmployeeBENDueMatchDate DATE,
EmployeeDefinitionDeductionTotalAmount DECIMAL(11,5),
EmployeeAttendanceDurationPEId VARCHAR(4),
EmployeeBENDeductionPEId VARCHAR(4),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#18 EmployeeAbsence

CREATE TABLE [ser_hr].[EmployeeAbsence]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
PositionId VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
PostStartCompDate INT NOT NULL,
EndTimestamp INT NOT NULL,
StartCompDate INT NOT NULL,
LinkPostReference VARCHAR(8),
NoteReference VARCHAR(8),
UDKReference VARCHAR(8),
EndDate DATE,
EndTime VARCHAR(6),
LinkABSDate DATE,
LinkABSTime VARCHAR(6),
NoProcessFlag VARCHAR(1),
StartTimestamp DATE,
AbsenceType VARCHAR(6),
ApplySSPFlag VARCHAR(1),
AssumedEndDate DATE,
MPSSPProcedureIndicator VARCHAR(1),
NewPLFlag VARCHAR(1),
OEAFlag VARCHAR(1),
OEAStatus VARCHAR(1),
PLConferenceCompDate VARCHAR(6),
ProjectedDate DATE,
WebAsenceNumber VARCHAR(10),
UKOPaternityFlag VARCHAR(1),
UKOSWBMaternityIndicator VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#19 EmployeeAbsenceHRS

CREATE TABLE [ser_hr].[EmployeeAbsenceHRS]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
PersonalReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
DateinAlphabet INT NOT NULL,
PostStartCompDate INT NOT NULL,
StartCompDate INT NOT NULL,
StartTime INT NOT NULL,
AbsenceDate DATE,
AbsenceDayFlag VARCHAR(1),
AbsenceHalfDayFlag VARCHAR(1),
AbsenceHoursPerDay DECIMAL(7,5),
AbsenceSSPFlag VARCHAR(1),
AbsenceType VARCHAR(6),
EmployeeStandardDateFlag VARCHAR(1),
NWHRSHours DECIMAL(7,5),
PatternSource VARCHAR(1),
RLBENTQFlag VARCHAR(1),
RLBPayQFlag VARCHAR(1),
WorkDayFlag VARCHAR(1),
WTLLostHours DECIMAL(7,5),
EmployeeAttritionPartDayFlag VARCHAR(1),
PatternId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#20 EmployeeAbsencePay

CREATE TABLE [ser_hr].[EmployeeAbsencePay]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
PersonalReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
StartCompDate INT NOT NULL,
StartTime INT NOT NULL,
PostStartCompDate INT NOT NULL,
AbsenceDate DATE,
AbsenceType VARCHAR(6),
AdditionalDailyPay DECIMAL(11,5),
AdditionalPPaymentAmount DECIMAL(11,5),
AmountPaid DECIMAL(11,5),
RLBAveragePercentage DECIMAL(5,2),
RLBBandPercentage1 DECIMAL(5,2),
RLBBandPercentage2 DECIMAL(5,2),
RLBBandPercentage3 DECIMAL(5,2),
Category1CFWDDays DECIMAL(11,5),
Category1CFWDHours DECIMAL(11,5),
Category1DaysDeduction DECIMAL(11,5),
Category1DaysPaid DECIMAL(11,5),
Category1HoursDeduction DECIMAL(11,5),
Category1HoursPaid DECIMAL(11,5),
Category1PayRate DECIMAL(10,5),
Category2CFWDDays DECIMAL(11,5),
Category2CFWDHours DECIMAL(11,5),
Category2DaysDeduction DECIMAL(11,5),
Category2DaysPaid DECIMAL(11,5),
Category2HoursDeduction DECIMAL(11,5),
Category2HoursPaid DECIMAL(11,5),
Category2PayRate DECIMAL(10,5),
CFWDDays DECIMAL(11,5),
CFWDHours DECIMAL(11,5),
CompDate INT,
ContractAmount DECIMAL(11,5),
ContractPayRate DECIMAL(11,5),
DailyPay DECIMAL(11,5),
SSPPIWDailyRate DECIMAL(11,5),
DayNormalPay DECIMAL(11,5),
RLBDaysPaid DECIMAL(11,5),
RLBDaysPaid1 DECIMAL(11,5),
RLBDaysPaid2 DECIMAL(11,5),
RLBDaysPaid3 DECIMAL(11,5),
RLBDaysPaid4 DECIMAL(11,5),
RLBDaysTaken1 DECIMAL(11,5),
RLBDaysTaken2 DECIMAL(11,5),
RLBDaysTaken3 DECIMAL(11,5),
RLBDaysTaken4 DECIMAL(11,5),
BENDailyRate DECIMAL(11,5),
BENDaysInWeek INT,
BENFlatRate3 DECIMAL(10,5),
BENReasonCode VARCHAR(6),
BENWeeklyRate DECIMAL(8,2),
RLBENTDayFlag VARCHAR(1),
ENTDaysDeduction DECIMAL(7,5),
ENTHoursDeduction DECIMAL(7,5),
RLBHoursPaid DECIMAL(11,5),
RLBHoursPaid1 DECIMAL(11,5),
RLBHoursPaid2 DECIMAL(11,5),
RLBHoursPaid3 DECIMAL(11,5),
RLBHoursPaid4 DECIMAL(11,5),
RLBHoursTaken1 DECIMAL(11,5),
RLBHoursTaken2 DECIMAL(11,5),
RLBHoursTaken3 DECIMAL(11,5),
RLBHoursTaken4 DECIMAL(11,5),
OverrideDeductionENT VARCHAR(1),
OverrideENTPay VARCHAR(1),
RLBPayDayFlag VARCHAR(1),
PayReason VARCHAR(6),
SSPPIWDaysInWeek INT,
RateofPay DECIMAL(11,5),
RLBDaysWeek INT,
RLBWeeklyPercentage DECIMAL(9,6),
SSPHalfDayFlag VARCHAR(1),
SSPPIWBenDailyFlag VARCHAR(1),
SSPPIWBenDailyRate DECIMAL(11,5),
SSPPIWReason VARCHAR(6),
SSPQualifyDayFlag VARCHAR(1),
AdditionalDaysDeduction DECIMAL(7,5),
AdditionalDaysPaid DECIMAL(7,5),
AdditionalHoursDeduction DECIMAL(7,5),
AdditionalHoursPaid DECIMAL(7,5),
AdditionalRate DECIMAL(11,5),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#21 EmployeeAdditionalEntitilement

CREATE TABLE [ser_hr].[EmployeeAdditionalEntitilement]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PostReference VARCHAR(8) NOT NULL,
PersonalReference VARCHAR(8) NOT NULL,
StartCompDate VARCHAR(6) NOT NULL,
StartTime VARCHAR(6) NOT NULL,
AbsenceType VARCHAR(6) NOT NULL,
PostStartCompDate VARCHAR(6) NOT NULL,
EntitlementEndDate DATE,
EntitlementStartDate DATE,
AdditionalENT1 DECIMAL(11,5),
AdditionalENT2 DECIMAL(11,5),
AdditionalENT3 DECIMAL(11,5),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#22 EmployeeAppraisal

CREATE TABLE [ser_hr].[EmployeeAppraisal]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
PersonReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
DueCompDate INT NOT NULL,
NoteReference VARCHAR(8),
ApplicationQINSTReference VARCHAR(8),
CountersignPersonReference VARCHAR(8),
ReportingPersonReference VARCHAR(8),
CountersignDate DATE,
CountersignName VARCHAR(30),
DueDate DATE,
OverallResult VARCHAR(6),
ReportingDate DATE,
ReportingName VARCHAR(30),
TypeCode VARCHAR(6) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#23 EmployeePositionAttendance

CREATE TABLE [ser_hr].[EmployeePositionAttendance]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
EmployeeReference VARCHAR(10) NOT NULL,
CostCentreReference VARCHAR(8),
PersonReference VARCHAR(8),
PositionId VARCHAR(8),
AttendanceEndTimeStamp VARCHAR(6),
AttendanceHours INT,
AttendanceMinutes INT,
AttendanceProcessIndicator VARCHAR(1),
AttendanceStartTimeStamp VARCHAR(6),
AttendanceStatusTypeId VARCHAR(6),
Category VARCHAR(10),
ChargeFlag VARCHAR(1),
AttendanceNote VARCHAR(80),
EndDate DATE,
HoursDecimal DECIMAL(11,5),
InputCash DECIMAL(10,2),
PostCompDate INT,
PreviousUpdatedBy VARCHAR(50),
PreviousUpdatedDate DATE,
StartCompDate VARCHAR(6),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#24 EmployeeAttendancePay

CREATE TABLE [ser_hr].[EmployeeAttendancePay]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
AttendancePayType VARCHAR(6) NOT NULL,
AttendancePEId VARCHAR(4) NOT NULL,
OCCNumber VARCHAR(3) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
CostCentreReference VARCHAR(8),
AttendanceUnits DECIMAL(11,5),
CastAmount DECIMAL(10,2),
EndDate DATE,
FactorOT DECIMAL(5,2),
FactorPERType VARCHAR(1),
FactorServicePER VARCHAR(3),
InputCash DECIMAL(10,2),
PayRate DECIMAL(6,4),
PLFlag VARCHAR(1),
StartCompDate VARCHAR(6),
StartDate DATE,
StatusIndicator VARCHAR(1),
WeeklyEndDate DATE,
WeeklyStartDate DATE,
StringReference VARCHAR(8),
TaxPeriodSetId VARCHAR(10),
FactorId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#25 Employee

CREATE TABLE [ser_hr].[Employee]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
EmployeeIOMTaxReference VARCHAR(10),
EmployeePersonStringReference VARCHAR(8),
EmployeeSelfServiceStringReference VARCHAR(8),
EXPFinInstalmentReference VARCHAR(8),
FINInstalmentAccountReference VARCHAR(8),
Level1PayStringReference VARCHAR(8),
NoteReference VARCHAR(8),
PayStringReference VARCHAR(8),
AdvantagePastyearFlag VARCHAR(1),
CalculateStamp DECIMAL(11,6),
ConditionType VARCHAR(6),
ConditionTypeDate DATE,
EmployeeAlternativePayeeName VARCHAR(40),
EmployeeAverageHours DECIMAL(10,2),
EmployeeStandardCost DECIMAL(10,2),
EmployeeBackdateNIFlag VARCHAR(1),
EmployeeCGYear VARCHAR(4),
EmployeeDeleteDate DATE,
EmployeeELearningStartDate DATE,
EmployeeFCPayslipFlag VARCHAR(1),
EmployeeMpostAdminFlag VARCHAR(1),
EmployeeINTServiceStartDateIndicator VARCHAR(1),
EmployeeJobShare VARCHAR(1),
EmployeeLastAccountPaidRunType VARCHAR(6),
EmployeeLMENTGeneralFlag VARCHAR(1),
EmployeeLossUseOriginalStartFlag VARCHAR(1),
EmployeeNoticePeriod VARCHAR(8),
EmployeeNumberofDaysPaid INT,
EmployeeNumberPeriodsPaid INT,
EmployeeOnBoardingStartDate DATETIME2,
EmployeePayslipLanguage VARCHAR(6),
EmployeePensionPayeeEndDate DATE,
EmployeePensionPayeeStartDate DATE,
EmployeePotentialStatus VARCHAR(6),
EmployeeProbationDate DATE,
EmployeeRecalculateAveragePayIndicator VARCHAR(1),
EmployeeRNIBPayslipType VARCHAR(6),
EmployeeRTIExpatFlag VARCHAR(1),
EmployeeRTIHoursCode VARCHAR(1),
EmployeeRTIIncludeFlag VARCHAR(1),
EmployeeRTIIrregularPay VARCHAR(1),
EmployeeRTIOCCPENFlag VARCHAR(1),
EmployeeRTIPayNonIndicatorFlag VARCHAR(1),
EmployeeRTIStarterFlag VARCHAR(1),
EmployeeServiceTUPEFlag VARCHAR(1),
EmployeeSlipSuppressFlag VARCHAR(1),
EmployeeSQLSVRStarterFlag VARCHAR(1),
EmployeeTimesheetAdminFlag VARCHAR(1),
EmployeeTimesheetRequiredFlag VARCHAR(1),
EmployeeUKUseLMFlag VARCHAR(1),
EmployeeNumber VARCHAR(10),
EmployeeNumberSuffix INT,
EmployeeType VARCHAR(6),
EndDate DATE,
EXPLastBACSRunDate DATE,
EXPLastTermDate DATE,
EXPPayMethod VARCHAR(6),
FixedFlexiIndicator VARCHAR(1),
FullTimeFlag VARCHAR(1),
GradeUsageLevel INT,
EmployeeGroupCode VARCHAR(6),
EmployeeHolidayOption VARCHAR(1),
EmployeeRecruitSource VARCHAR(6),
EmployeeResetDate DATE,
EmployeeResetOperator VARCHAR(10),
EmployeeResetTime VARCHAR(6),
EmployeeTrustStartDate DATE,
EmployeeUpperRateNI VARCHAR(1),
EmployeeHowJoined VARCHAR(6),
INDLActionFlag VARCHAR(1),
LastActualPaidPeriod VARCHAR(2),
LastActualPaidSupplierNumber VARCHAR(2),
LastActualPaidYear VARCHAR(4),
LastPaidDate DATE,
LastPaidPeriod VARCHAR(2),
LastPaidYear VARCHAR(4),
LatestPRSIClass VARCHAR(6),
LeavingReason VARCHAR(255),
LegislationType VARCHAR(4),
MandateCSGradeOnEntry VARCHAR(8),
MandatePaySelectivity VARCHAR(3),
MandateQSMarker VARCHAR(1),
MandateStartDate DATE,
NICategory VARCHAR(6),
NICHolidayAuthorisedDate DATE,
NICHolidayEndDate DATE,
NICHolidayIndicator VARCHAR(1),
EmployeeOriginalHowJoined VARCHAR(6),
OriginalStartDate DATE,
PayEntrantDate DATE,
PayEntrantReason VARCHAR(6),
PayExitDate DATE,
PayExitReason VARCHAR(6),
PayMethod VARCHAR(6),
PayTaxRefundFlag VARCHAR(1),
PayrollType VARCHAR(6),
PERSWhileAdvantage VARCHAR(1),
PositionStatus VARCHAR(6),
PositionStatusDate DATE,
SlipAddressFlag VARCHAR(1),
SlipNameFlag VARCHAR(1),
StartDate DATE,
StarterFlag VARCHAR(1),
SuspendedFlag VARCHAR(1),
TemporaryFlag VARCHAR(1),
ToStaffDate DATE,
Week53PaidFlag VARCHAR(1),
WGHTCategory VARCHAR(6),
EmployeeBaseCurrencyId VARCHAR(10),
EmployeeClaimFormId VARCHAR(10),
EmployeeExpenseFormId VARCHAR(10),
EmployeePayCurrencyId VARCHAR(10),
EmployeeRegionId VARCHAR(6),
SlipMessageId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#26 EmployeeEntitlement

CREATE TABLE [ser_hr].[EmployeeEntitlement]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
StartCompDate INT NOT NULL,
EntitlementType VARCHAR(6) NOT NULL,
ADDProrataCFWD DECIMAL(10,5),
NoteReference VARCHAR(8),
ENTADDCFWDDays DECIMAL(10,5),
ENTADDCFWDHours DECIMAL(10,5),
AddDays DECIMAL(11,5),
AddHours DECIMAL(11,5),
PayFlag VARCHAR(1),
ENTADDProratavalue DECIMAL(11,5),
ADDTakenDays DECIMAL(11,5),
ADDTakenHours DECIMAL(11,5),
ALCTNIndicator VARCHAR(1),
EmployeeEntitleApply VARCHAR(1),
BalanceAdjustFlag VARCHAR(1),
BalanceBandFlag VARCHAR(1),
CalcType VARCHAR(6),
EmployeeEntitleCategoryCapDate DATE,
CapUnit DECIMAL(11,5),
CFWDDays DECIMAL(10,5),
CFWDDaysCAT1 DECIMAL(10,5),
CFWDDaysCAT2 DECIMAL(10,5),
CFWDHours DECIMAL(10,5),
CFWDHoursCAT1 DECIMAL(10,5),
CFWDHoursCAT2 DECIMAL(10,5),
CFWDUseByDate DATE,
Days DECIMAL(11,5),
DaysCategory1 DECIMAL(11,5),
DaysCAT2 DECIMAL(11,5),
DaysPurchased DECIMAL(11,5),
DaysSold DECIMAL(11,5),
EndDate DATE,
EOYChangeIndicator VARCHAR(1),
ExtraDays DECIMAL(10,5),
ExtraDaysCAT1 DECIMAL(10,5),
ExtraDaysCAT2 DECIMAL(10,5),
ExtraHours DECIMAL(10,5),
ExtraHoursCAT1 DECIMAL(10,5),
ExtraHoursCAT2 DECIMAL(10,5),
Hours DECIMAL(11,5),
HoursCAT1 DECIMAL(11,5),
HoursCAT2 DECIMAL(11,5),
HoursPurchased DECIMAL(11,5),
HoursSold DECIMAL(11,5),
IncrementalUnit DECIMAL(10,5),
LastCalDate DATE,
PPCFWDDays DECIMAL(10,5),
PPCFWDDaysCAT1 DECIMAL(10,5),
PPCFWDDaysCAT2 DECIMAL(10,5),
PPCFWDHours DECIMAL(10,5),
PPCFWDHoursCAT1 DECIMAL(10,5),
PPCFWDHoursCAT2 DECIMAL(10,5),
ProrataValue DECIMAL(11,5),
SpareField1 VARCHAR(40),
StartDate DATE,
TakenCFDaysCAT1 DECIMAL(11,5),
TakenCFDaysCAT2 DECIMAL(11,5),
TakenCFHoursCAT1 DECIMAL(11,5),
TakenCFHoursCAT2 DECIMAL(11,5),
TakenCFWDays DECIMAL(11,5),
CFWHours DECIMAL(11,5),
TakenDays DECIMAL(11,5),
TakenDaysCAT1 DECIMAL(11,5),
TakenDaysCAT2 DECIMAL(11,5),
TakenHours DECIMAL(11,5),
TakenHoursCAT1 DECIMAL(11,5),
TakenHoursCAT2 DECIMAL(11,5),
TermADDDays DECIMAL(10,5),
TermADDHours DECIMAL(10,5),
TermDays DECIMAL(10,5),
TermHours DECIMAL(10,5),
UnitType VARCHAR(1),
PPCDWDFlag VARCHAR(1),
PostStartCompDate INT NOT NULL,
ProrataCFWD DECIMAL(10,5),
ProrataToENTDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#27 EmployeePaternityLeave

CREATE TABLE [ser_hr].[EmployeePaternityLeave]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
PersonReference VARCHAR(8) NOT NULL,
EmployeePLNotesReference VARCHAR(8),
ActionConfirmationDate DATE,
AveragePay DECIMAL(10,2),
CompletedFlag VARCHAR(1),
OMPCompletedFlag VARCHAR(1),
OMPContractHours DECIMAL(4,2),
OMPMPPEndDate DATE,
OMPMPPEndTaxPeriod VARCHAR(2),
OMPMPPEndTaxYear VARCHAR(4),
OMPMPPStart023 VARCHAR(2),
OMPMPPStartDate DATE,
OMPMPPStartTaxYear VARCHAR(4),
OMPNormalPay DECIMAL(10,2),
OMPReturnToWorkDate DATE,
OMPReturnToWorkFlag VARCHAR(1),
OMPServiceDate DATE,
OMPTotalAmountPaid DECIMAL(10,2),
EmployeePLActualReturnDate DATE,
EmployeePLAdoptMATRTWDate DATE,
EmployeePLAllowDifferenceRatesFlag VARCHAR(1),
EmployeePLRecordsIndicator VARCHAR(1),
EmployeePLAppRequirement VARCHAR(1),
EmployeePlASPPAnnualAmount DECIMAL(10,2),
EmployeePLAssumedPENPayAmount DECIMAL(10,2),
EmployeePLCalcMethod VARCHAR(8),
EmployeePLCurtailmentDate DATE,
EmployeePLEarliestStartDate DATE,
EmployeePLFinalRTWDate DATE,
EmployeePLKitsDays INT,
EmployeePLLatestStartDate DATE,
EmployeePLLinkedConferenceCompDate VARCHAR(6),
EmployeePLLVWeeksRemainingENT INT,
EmployeePLMaxEndDate DATE,
EmployeePLMaxLVWeeksENT INT,
EmployeePLMaxPayWeeksENT INT,
EmployeePLMORTIndicator VARCHAR(6),
EmployeePLDeceasedFlag VARCHAR(1),
EmployeePLPartnerDeceasedFlag VARCHAR(1),
EmployeePLPATRTWDate DATE,
EmployeePLPayEndDate DATE,
EmployeePLPayWeeksRemainingENT INT,
EmployeePLPlacementDate DATE,
EmployeePLRevocationDate DATE,
EmployeePLSHLVEarliestStartDate DATE,
EmployeePLSHLVLatestStartDate DATE,
EmployeePLSHLVStartDate DATE,
EmployeePLSpreadLoadStatus VARCHAR(1),
EmployeePLSpreadLoadtoDate DATE,
EmployeePLTotalOccupationShippingPaid DECIMAL(10,2),
EmployeePLTotalStatusShippingPaid DECIMAL(10,2),
EmployeePLType VARCHAR(6),
EmployeePLType2 VARCHAR(10),
ExcludeCode1 VARCHAR(6),
ExcludeCode2 VARCHAR(6),
ExcludeCode3 VARCHAR(6),
ExcludeNTFFlag VARCHAR(1),
ConfirmationCompDate INT,
ConfirmationDate DATE NOT NULL,
EXPLeverageDate DATE,
FormReceivedDate DATE,
OMPDeductionPENSFlag VARCHAR(1),
OMPNonPENSAveragePay DECIMAL(10,2),
OMPPENSAveragePay DECIMAL(10,2),
OMPRecoverPENSDate DATE,
MPPEndDate DATE,
MPPEndTaxPeriod VARCHAR(2),
MPPEndTaxYear VARCHAR(4),
MPPStartDate DATE,
MPPStartTaxPeriod VARCHAR(2),
MPPStartTaxYear VARCHAR(4),
PartTimeFlag VARCHAR(1),
QWStartDate DATE,
WeekNumber DECIMAL(10,2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#28 EmployeePaternityLeaveKitDay

CREATE TABLE [ser_hr].[EmployeePaternityLeaveKitDay]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
CompDate VARCHAR(6) NOT NULL,
ConfCompDate VARCHAR(6) NOT NULL,
DayAttReference VARCHAR(8),
KITDayDate DATE,
DayOCCAmount DECIMAL(10,2),
DayOffsetAmount DECIMAL(10,2),
DayPaidFlag VARCHAR(1),
DayPayAmount DECIMAL(10,2),
DayStatAmount DECIMAL(10,2),
DayType VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#29 EmployeePaternityLeaveOP

CREATE TABLE [ser_hr].[EmployeePaternityLeaveOP]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
PersonReference VARCHAR(8) NOT NULL,
ConfCompDate VARCHAR(6) NOT NULL,
DayinAlphabet VARCHAR(6) NOT NULL,
DayAmount DECIMAL(10,2),
DayDate DATE,
ArrearsAmount DECIMAL(10,2),
EntitlementPercentage DECIMAL(5,2),
ExcludeReason VARCHAR(6),
OffsetFlag VARCHAR(1),
PaidFlag VARCHAR(1),
PaymentIndicator VARCHAR(1),
PROCArrearsAmount DECIMAL(10,2),
ReprocessIndicator VARCHAR(1),
ReversalFlag VARCHAR(1),
TaxPeriod VARCHAR(2),
TaxYear VARCHAR(4),
WeekNumber VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#30 EmployeePaternityLeaveOPDay

CREATE TABLE [ser_hr].[EmployeePaternityLeaveOPDay]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
DayDateinAlphabet VARCHAR(6) NOT NULL,
PayType VARCHAR(6) NOT NULL,
REVRECType VARCHAR(2) NOT NULL,
SupplierNumber VARCHAR(2) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
ExcludeCode VARCHAR(6),
DayAmount DECIMAL(10,5),
DayDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#31 EmployeePaternityLeaveSP

CREATE TABLE [ser_hr].[EmployeePaternityLeaveSP]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
DayinAlphabet INT NOT NULL,
ConfCompDate INT NOT NULL,
ADDPaymentIndicator VARCHAR(1),
DayAmount DECIMAL(10,2),
DayDate DATE,
ExclusionReason VARCHAR(6),
ArrearsAmount DECIMAL(10,2),
PaidFlag VARCHAR(1),
PayReversalFlag VARCHAR(1),
PROCArrearsAmount DECIMAL(10,2),
RateType VARCHAR(1),
ReprocessIndicator VARCHAR(1),
TaxPeriod VARCHAR(2),
TaxYear VARCHAR(4),
WeekNumber VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#32 EmployeePaternityLeaveSPDay

CREATE TABLE [ser_hr].[EmployeePaternityLeaveSPDay]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PayType VARCHAR(6) NOT NULL,
REVRECType VARCHAR(2) NOT NULL,
DayDateinAlphabet VARCHAR(6) NOT NULL,
SupplierNumber VARCHAR(2) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
ExcludeCode VARCHAR(6),
DayAmount DECIMAL(10,2),
DayDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#33 EmployeePensionScheme

CREATE TABLE [ser_hr].[EmployeePensionScheme]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
StartCompDate INT NOT NULL,
EmployeePensionSchemeId VARCHAR(10) NOT NULL,
NoteReference VARCHAR(8),
ReferenceNumber VARCHAR(20),
EmployeePensionSchemeLeaverReason VARCHAR(6),
LeaverDate DATE,
MinimumGross DECIMAL(10,2),
StartDate DATE,
EmployeePensionCategoryId VARCHAR(20),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#34 EmployeePostCondition

CREATE TABLE [ser_hr].[EmployeePostCondition]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
Reference VARCHAR(8) NOT NULL,
CompDate INT NOT NULL,
StartCompDate INT NOT NULL,
NoteReference VARCHAR(8),
EndDate DATE,
StartDate DATE,
ServiceConditionId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#35 EmployeePostFixedPayElement

CREATE TABLE [ser_hr].[EmployeePostFixedPayElement]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
StartCompDate INT NOT NULL,
Identifier VARCHAR(4) NOT NULL,
EmployeePEERSTableReference VARCHAR(8),
ERSCostCentreReference VARCHAR(8),
FININSTAccountReference VARCHAR(8),
AdminCostCentreReference VARCHAR(8),
CostCentreReference VARCHAR(8),
RateTableReference VARCHAR(8),
ReferenceNumber VARCHAR(20),
SourceReference VARCHAR(8),
TableReference VARCHAR(8),
TransferReference VARCHAR(8),
UnitsTableReference VARCHAR(8),
AcceptIndicator INT,
Adjustment DECIMAL(10,2),
AdminCharge DECIMAL(10,2),
Amount DECIMAL(10,2),
Arrears DECIMAL(10,2),
Calcarrears DECIMAL(10,2),
CIEarnsArrears DECIMAL(10,2),
COEarnsArrears DECIMAL(10,2),
DeleteFlag VARCHAR(1),
EESCIArrears DECIMAL(10,2),
EESCOArrears DECIMAL(10,2),
PECORebateArrears DECIMAL(10,2),
CourtJudgementDate DATE,
PECurrencyAmount DECIMAL(10,2),
CurrencyRate DECIMAL(12,4),
PEEERebateArrears DECIMAL(10,2),
PEEETEARNSArrears DECIMAL(10,2),
EffectiveDate DATE,
EffectiveIndicator VARCHAR(4),
PEENDIndicator VARCHAR(4),
EmployeePEERSCurrencyAmount DECIMAL(10,2),
PEETHEARNSArrears DECIMAL(10,2),
PELELEARNSArrears DECIMAL(10,2),
GrossEarnsArrears DECIMAL(10,2),
OptOutDate1 DATE,
OptOutDate2 DATE,
OptOutIndicator1 VARCHAR(4),
OptOutIndicator2 VARCHAR(4),
SchemeCategory VARCHAR(10),
StartIndicator VARCHAR(4),
PEStopDate DATE,
PEStopIndicator VARCHAR(4),
THLDEndDate DATE,
THLDENDIndicator VARCHAR(4),
THLDStartDate DATE,
THLDStartIndicator VARCHAR(4),
TotalSalaryInclusiveFlag VARCHAR(1),
PEUELEARNSArrears DECIMAL(10,2),
VacPayNowFlag VARCHAR(1),
EndDate DATE,
ERSAmount DECIMAL(10,2),
ERSArrears DECIMAL(10,2),
ERSCIArrears DECIMAL(10,2),
ERSCOArrears DECIMAL(10,2),
ERSPercentage DECIMAL(5,2),
PENAPBasic INT,
PENAPOvertime INT,
PENAPStop VARCHAR(1),
PaymentMethod VARCHAR(6),
PayProcessFlag VARCHAR(1),
Percentage DECIMAL(5,2),
PROTEarns DECIMAL(10,2),
PROTEarnsArrears DECIMAL(10,2),
Rate DECIMAL(12,4),
Reason VARCHAR(6),
SourceIndicator VARCHAR(1),
StartDate DATE,
SuspendedFlag VARCHAR(1),
Units DECIMAL(10,2),
UnitsArrears DECIMAL(10,2),
ThirdPartyId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#36 EmployeePostGrade

CREATE TABLE [ser_hr].[EmployeePostGrade]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
StartCompDate INT NOT NULL,
LinkReference VARCHAR(8),
NoteReference VARCHAR(8),
PETableReference VARCHAR(8),
Reference VARCHAR(8),
CarryForwardFlag VARCHAR(1),
ChangeSource VARCHAR(6),
CurrentPoint VARCHAR(10),
EmployeeGradeBaseSalaryRate DECIMAL(12,4),
EmployeeGradeBaseSalaryValue DECIMAL(10,2),
EmployeeGradeCurrencyId VARCHAR(10),
EmployeeGradeENHRate DECIMAL(12,4),
EndDate DATE,
EmployeeGradeChangePending VARCHAR(1),
EmployeeGradeCurrentPoint VARCHAR(2),
EmployeeGradeINCCFWDIndicator VARCHAR(1),
EmployeeGradeINCDate DATE,
EmployeeGradeINCStep BIGINT,
EmployeeGradeOffscaleAmount DECIMAL(8,2),
EmployeeGradeSessionalRate DECIMAL(7,4),
OverrideDate DATE,
OverrideReason VARCHAR(6),
OverrideStep BIGINT,
PointRate DECIMAL(12,4),
PointValue DECIMAL(10,2),
Reason VARCHAR(6),
Source VARCHAR(6),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#37 EmployeePostHold

CREATE TABLE [ser_hr].[EmployeePostHold]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
Reference VARCHAR(8) NOT NULL,
StartCompDate INT NOT NULL,
PostReferenceFlag VARCHAR(1),
JobReference VARCHAR(8),
PostUserDataKeyReference VARCHAR(8),
NoteReference VARCHAR(8),
UserDataKeyReference VARCHAR(8),
ConditionType VARCHAR(6),
ContractNumber VARCHAR(8),
AgeLess55 VARCHAR(1),
PostApparentEndDate DATE,
PostApparentNIFlag VARCHAR(1),
PostApparentStartDate DATE,
PostAverageHours DECIMAL(10,2),
PostAveragePay DECIMAL(10,2),
PostEmploymentNumber VARCHAR(2),
PostExcludeCostADD VARCHAR(1),
PostGradeHESAFlag VARCHAR(1),
PostMainSystemFlag VARCHAR(1),
PostMainTeachFlag VARCHAR(1),
PostPENIncrementDate DATE,
EmployeePostTechFlag VARCHAR(10),
PostRecalcAveragePayIndicator VARCHAR(1),
PostRedCircledIndicator VARCHAR(1),
RedeploymentCode VARCHAR(6),
PostSalaryGroup VARCHAR(10),
PostSalaryPlannerIndicator VARCHAR(1),
PostContractId VARCHAR(10),
TimesheetAdminFlag VARCHAR(1),
TimesheetRequiredFlag VARCHAR(1),
EndDate DATE,
PaidViaExpenses VARCHAR(1),
PostContractType VARCHAR(6),
PostCumulativeHoursWorked DECIMAL(8,2),
PostEndDate DATE,
PostINCGranted VARCHAR(1),
PostJobTitle VARCHAR(6),
PostMD2ndSpeciality VARCHAR(6),
PostMDADH1 DECIMAL(4,2),
PostMDADH2 DECIMAL(4,2),
PostMDADH3 DECIMAL(4,2),
PostMDADH4 DECIMAL(4,2),
PostContractNature VARCHAR(6),
PostMDExtendDate DATE,
PostMDExtendUntil DATE,
PostMDHONContractRSN VARCHAR(6),
PostMDLocumCNTRType VARCHAR(6),
PostMDMainSpeciality VARCHAR(6),
PostMDNHDS DECIMAL(4,2),
PostMDPTContractAuthorisation VARCHAR(6),
ReviewDate DATE,
PostMDSession DECIMAL(4,2),
MDTypeofPost VARCHAR(6),
PostOccupationCode VARCHAR(6),
BASHoursNewRate DECIMAL(8,2),
BASHoursWorked DECIMAL(8,2),
RecruitSource VARCHAR(6),
PostStartDate DATE,
PostWeightCategory VARCHAR(6),
JoinReason VARCHAR(6),
LeaveReason VARCHAR(6),
MainFlag VARCHAR(1),
OccupationType VARCHAR(6),
ProjectedEndDate DATE,
RLType VARCHAR(6),
StartDate DATE,
SuspendedFlag VARCHAR(1),
PostClaimFormId VARCHAR(10),
PostFormId VARCHAR(10),
PostPCONTId VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#38 EmployeePostHours

CREATE TABLE [ser_hr].[EmployeePostHours]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
EmployeePostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
PostStartCompDate INT NOT NULL,
StartCompDate INT NOT NULL,
FTESession DECIMAL(6,2),
HRPERYear DECIMAL(6,2),
HRWPY DECIMAL(6,4),
CONTSessions DECIMAL(6,2),
PostMDADH1 DECIMAL(4,2),
PostMDADH2 DECIMAL(4,2),
PostMDADH3 DECIMAL(4,2),
PostMDSessionEnd DATE,
PostMDSessionStart DATE,
AlternateHR DECIMAL(6,2),
AlternateSESS DECIMAL(6,2),
HR DECIMAL(6,2),
EndDate DATE,
HRFTEHours DECIMAL(6,2),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#39 EmployeePostLocation

CREATE TABLE [ser_hr].[EmployeePostLocation]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
EmployeePostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
EmployeePostStartCompDate INT NOT NULL,
StartCompDate INT NOT NULL,
Reference VARCHAR(8),
NoteReference VARCHAR(8),
PostEndTimeStamp DATE,
EmployeePositionLocationNote VARCHAR(6),
PostStartTimeStamp DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#40 EmployeePostPOSStatus

CREATE TABLE [ser_hr].[EmployeePostPOSStatus]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PositionStatusCompDate INT NOT NULL,
StartCompDate INT NOT NULL,
Reference VARCHAR(8) NOT NULL,
PositionStatusNoteReference VARCHAR(8),
EmployeePostionStatusNote VARCHAR(6),
StatusEndTimeStamp DATE,
StatusStartTimeStamp DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#41 EmployeePostPayElement

CREATE TABLE [ser_hr].[EmployeePostPayElement]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
PersonReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
OccupationNumber VARCHAR(3) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
Identifier VARCHAR(4) NOT NULL,
PayType VARCHAR(6) NOT NULL,
PEERSTableReference VARCHAR(8),
ERSCostCentreReference VARCHAR(8),
EXPCodeReference VARCHAR(8),
CostCentreReference VARCHAR(8),
ClaimReference VARCHAR(8),
RateTableReference VARCHAR(8),
TableReference VARCHAR(8),
UnitsTableReference VARCHAR(8),
VATCostCentreReference VARCHAR(8),
BatchId VARCHAR(10),
ActionIndicator VARCHAR(1),
Amount DECIMAL(10,2),
BatchSequenceNumber VARCHAR(6),
BatchPayOriginalDate DATE,
CIEarns DECIMAL(10,2),
ClaimDate DATE,
ClaimNumber VARCHAR(10),
ClaimSequenceNumber VARCHAR(4),
COEarns DECIMAL(10,2),
EESCIAmount DECIMAL(10,2),
EESCOAmount DECIMAL(10,2),
PEABSDeleteFlag VARCHAR(1),
PEABSENTType VARCHAR(6),
PEABSPayType VARCHAR(1),
PEABSPROCIndicator VARCHAR(1),
PEATTStartDate DATE,
PEATTStartTime VARCHAR(6),
CalcSupplierNumber VARCHAR(2),
PECORebate DECIMAL(10,2),
CurrencyAmount DECIMAL(10,2),
PECurrencyRate DECIMAL(12,4),
PEDetailDescription VARCHAR(40),
PEEERebate DECIMAL(10,2),
PEEETEarns DECIMAL(10,2),
PEERSCurrencyAmount DECIMAL(10,2),
PEETHEarns DECIMAL(10,2),
PEJurisdiction VARCHAR(10),
PELELEarns DECIMAL(10,2),
PENIGrossEarns DECIMAL(10,2),
PETaxTP VARCHAR(6),
PEUELEarns DECIMAL(10,2),
PEVacancyPayNowFlag VARCHAR(1),
EndDate DATE,
ERSAmount DECIMAL(10,2),
ERSCIAmount DECIMAL(10,2),
ERSCOAmount DECIMAL(10,2),
FormulaIndicator VARCHAR(1),
PEHoursSESS1 DECIMAL(10,2),
PEHoursSESS10 DECIMAL(10,2),
PEHoursSESS11 DECIMAL(10,2),
PEHoursSESS12 DECIMAL(10,2),
PEHoursSESS13 DECIMAL(10,2),
PEHoursSESS14 DECIMAL(10,2),
PEHoursSESS15 DECIMAL(10,2),
PEHoursSESS16 DECIMAL(10,2),
PEHoursSESS17 DECIMAL(10,2),
PEHoursSESS18 DECIMAL(10,2),
PEHoursSESS19 DECIMAL(10,2),
PEHoursSESS2 DECIMAL(10,2),
PEHoursSESS20 DECIMAL(10,2),
PEHoursSESS21 DECIMAL(10,2),
PEHoursSESS22 DECIMAL(10,2),
PEHoursSESS23 DECIMAL(10,2),
PEHoursSESS24 DECIMAL(10,2),
PEHoursSESS25 DECIMAL(10,2),
PEHoursSESS26 DECIMAL(10,2),
PEHoursSESS27 DECIMAL(10,2),
PEHoursSESS28 DECIMAL(10,2),
PEHoursSESS29 DECIMAL(10,2),
PEHoursSESS3 DECIMAL(10,2),
PEHoursSESS30 DECIMAL(10,2),
PEHoursSESS31 DECIMAL(10,2),
PEHoursSESS4 DECIMAL(10,2),
PEHoursSESS5 DECIMAL(10,2),
PEHoursSESS6 DECIMAL(10,2),
PEHoursSESS7 DECIMAL(10,2),
PEHoursSESS8 DECIMAL(10,2),
PEHoursSESS9 DECIMAL(10,2),
PENAPBasic INT,
PENAPOvertime INT,
PENAPStop VARCHAR(1),
PEOSPDate1 DATE,
PEOSPDate10 DATE,
PEOSPDate11 DATE,
PEOSPDate12 DATE,
PEOSPDate13 DATE,
PEOSPDate14 DATE,
PEOSPDate15 DATE,
PEOSPDate16 DATE,
PEOSPDate17 DATE,
PEOSPDate18 DATE,
PEOSPDate19 DATE,
PEOSPDate2 DATE,
PEOSPDate20 DATE,
PEOSPDate21 DATE,
PEOSPDate22 DATE,
PEOSPDate23 DATE,
PEOSPDate24 DATE,
PEOSPDate25 DATE,
PEOSPDate26 DATE,
PEOSPDate27 DATE,
PEOSPDate28 DATE,
PEOSPDate29 DATE,
PEOSPDate3 DATE,
PEOSPDate30 DATE,
PEOSPDate31 DATE,
PEOSPDate4 DATE,
PEOSPDate5 DATE,
PEOSPDate6 DATE,
PEOSPDate7 DATE,
PEOSPDate8 DATE,
PEOSPDate9 DATE,
PEOver53 VARCHAR(8),
PayEXPIndicator VARCHAR(1),
ProcessedFlag VARCHAR(1),
PRSIWeeks INT,
Units DECIMAL(10,2),
VATAmount DECIMAL(10,2),
Rate DECIMAL(12,4),
StartDate DATE,
SystemSource VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#42 EmployeePostWorkPattern

CREATE TABLE [ser_hr].[EmployeePostWorkPattern]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
Reference VARCHAR(8) NOT NULL,
PATStartCompDate VARCHAR(6) NOT NULL,
StartCompDate VARCHAR(6) NOT NULL,
EmployeePostPATNoTimesFlag VARCHAR(1),
PATEndDate DATE,
PATOffset BIGINT,
PATReason VARCHAR(6),
PATStartDate DATE,
StartDate DATE,
PATId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#43 EmpServiceBreak

CREATE TABLE [ser_hr].[EmpServiceBreak]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
PersonReference VARCHAR(8) NOT NULL,
StartCompDate VARCHAR(10) NOT NULL,
NoteReference VARCHAR(8),
Days BIGINT,
EmployeeBreakBackFlag VARCHAR(1),
EndDate DATE,
HolidayFlag VARCHAR(1),
HowRejoined VARCHAR(6),
LSFlag VARCHAR(1),
PENSFlag VARCHAR(1),
Reason VARCHAR(6),
StartDate DATE,
User1Flag VARCHAR(1),
User2Flag VARCHAR(1),
User3Flag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#44 FinancialInstitutionAccount

CREATE TABLE [ser_hr].[FinancialInstitutionAccount]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(240),
OGGInternalReferenceNumber BIGINT,
AccountReference VARCHAR(256) NOT NULL,
Reference VARCHAR(10),
RollNumberReference VARCHAR(8),
AccountName VARCHAR(264),
AccountNumber VARCHAR(20),
AccountType VARCHAR(10),
AccountAnalysisCode1 VARCHAR(256),
AccountAnalysisCode2 VARCHAR(20),
AccountAnalysisCode3 VARCHAR(20),
AccountIBAN VARCHAR(256),
AccountHoldRelation VARCHAR(6),
RollNumber VARCHAR(18),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#45 Bank

CREATE TABLE [ser_hr].[Bank]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
LanguagePreference VARCHAR(1),
NoteReference VARCHAR(8),
AddressReference VARCHAR(20),
CountryId VARCHAR(3),
Branch VARCHAR(30),
BankFaxNumber VARCHAR(20),
ObsoleteDate DATE,
BankName VARCHAR(6),
SortCode VARCHAR(10),
BankTelephoneNumber VARCHAR(20),
SWIFTId VARCHAR(14),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#46 GeneralLedger

CREATE TABLE [ser_hr].[GeneralLedger]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
AccountCode VARCHAR(10) NOT NULL,
Century VARCHAR(2) NOT NULL,
CompanyCode VARCHAR(4) NOT NULL,
CostCentre VARCHAR(10) NOT NULL,
Period VARCHAR(2) NOT NULL,
Run VARCHAR(2) NOT NULL,
BCB03MYear VARCHAR(2) NOT NULL,
PEId VARCHAR(4) NOT NULL,
PEDescription VARCHAR(40),
Amount DECIMAL(10,2),
CDIndicator VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#47 Gradeband

CREATE TABLE [ser_hr].[Gradeband]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
GradeReference VARCHAR(8) NOT NULL,
EffectiveCompDate INT NOT NULL,
MaximumSalary DECIMAL(10,2),
MidPoint DECIMAL(10,2),
MinimumSalary DECIMAL(10,2),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#48 Grade

CREATE TABLE [ser_hr].[Grade]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
GradeMLRowReference VARCHAR(15),
NoteReference VARCHAR(8),
Grade13thSalaryFlag VARCHAR(1),
GradeAgeMaximum INT,
GradeAgeMinimum INT,
GradeBaseSalaryAllowChangeFlag VARCHAR(1),
GradeHayFlag VARCHAR(1),
GradeHESAFlag VARCHAR(1),
GradeHESANATPayFrameworkIndicator VARCHAR(1),
GradeHESATableIndicator VARCHAR(1),
OnBoardingCampaignId VARCHAR(10),
GradePPBonusUnitValue DECIMAL(10,2),
GradePPBonusValue DECIMAL(10,2),
GradePPSalaryBill DECIMAL(10,2),
GradePPSalaryBillPercentage DECIMAL(5,2),
GradeBASSalPEId VARCHAR(6),
GradeServiceMaximum INT,
GradeServiceMinimum INT,
GradeSpinalAutoCreate VARCHAR(1),
GradeTechnoRegistrationPaySpine VARCHAR(6),
GradeTeachFlag VARCHAR(1),
GradeZone VARCHAR(6),
GradeGroup VARCHAR(6),
GradeSalaryIndicator VARCHAR(1),
GradeStaffGroup VARCHAR(15),
GradeWhitleyCouncilCode VARCHAR(6),
LongDescription VARCHAR(40),
Number VARCHAR(10),
ObsoleteDate DATE,
SecurityLevel INT,
ShortDescription VARCHAR(10),
SortCode INT,
StartDate DATE,
GradePPTableId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#49 GradeSpinalColumnHistory

CREATE TABLE [ser_hr].[GradeSpinalColumnHistory]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
GradeReference VARCHAR(8) NOT NULL,
NoteReference VARCHAR(8),
EndDate DATE,
GradehHstoryIncrementFlag VARCHAR(1),
TechPayScale VARCHAR(6),
EnhanceRate DECIMAL(8,4),
OvertimeRate DECIMAL(8,4),
SessionRate DECIMAL(8,4),
WeeklyRate DECIMAL(8,4),
IncrementStep INT,
MaxPoint VARCHAR(10),
MinPoint VARCHAR(10),
StartCompDate INT NOT NULL,
StartDate DATE,
TableId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#50 Dependent 

CREATE TABLE [ser_hr].[Dependent ]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
EmployeeId VARCHAR(10) NOT NULL,
DependentId VARCHAR(15),
NoteReference VARCHAR(8),
LongDescription VARCHAR(40),
ObsoleteDate DATE,
DependentNote VARCHAR(10),
TopLevel VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#51 HierarchyFatherToSon

CREATE TABLE [ser_hr].[HierarchyFatherToSon]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
StructureReference VARCHAR(8) NOT NULL,
DependentId VARCHAR(10) NOT NULL,
HierarchyLevelNo VARCHAR(2) NOT NULL,
STRId VARCHAR(10) NOT NULL,
DependentRelationshipTypeId VARCHAR(10),
FatherHierarchyLevelNo VARCHAR(2),
DependentRelationshipTypeName VARCHAR(8),
SubSTRCount BIGINT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#52 HierarchySonToFather

CREATE TABLE [ser_hr].[HierarchySonToFather]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
DependentRelationshipTypeName VARCHAR(8) NOT NULL,
StructureReference VARCHAR(8) NOT NULL,
DependentRelationshipTypeId VARCHAR(10) NOT NULL,
DependentId VARCHAR(10) NOT NULL,
FatherHierarchyLevelNo VARCHAR(10) NOT NULL,
HierarchyLevelNo VARCHAR(2) NOT NULL,
STRId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#53 DependentLevel

CREATE TABLE [ser_hr].[DependentLevel]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
LevelLongDescription VARCHAR(40),
LevelNo VARCHAR(2) NOT NULL,
ID VARCHAR(10) NOT NULL,
LevelShortDescription VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#54 DependentLevelDetail

CREATE TABLE [ser_hr].[DependentLevelDetail]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
EffectiveCompDate INT NOT NULL,
LevelNo VARCHAR(2) NOT NULL,
Id VARCHAR(10) NOT NULL,
HierarchyLevelMLRowReference VARCHAR(15),
LevelLongDescription VARCHAR(40),
LevelShortDescription VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#55 Job

CREATE TABLE [ser_hr].[Job]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
JobId VARCHAR(8) NOT NULL,
Gradelevel VARCHAR(8),
JobMLRowReference VARCHAR(15),
NoteReference VARCHAR(8),
JobOnBoardingCampaignId VARCHAR(10),
JobOnBoardingProfileId VARCHAR(10),
JobIrregularPayFlag VARCHAR(1),
JobDescription VARCHAR(40),
Number VARCHAR(10),
ObsoleteDate DATE,
ResourceType VARCHAR(6),
MaximumSalary DECIMAL(10,2),
MinimumSalary DECIMAL(10,2),
SecurityLevel BIGINT,
ShortDescription VARCHAR(10),
SortCode BIGINT,
StartDate DATE,
JobClaimDefinitionId VARCHAR(10),
JobEXPClaimDefinitionId VARCHAR(10),
JobIntranetProfileId VARCHAR(10),
JobPMRoleId VARCHAR(10),
JobProfileId VARCHAR(10),
JobRoleId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#56 JobFTEHours

CREATE TABLE [ser_hr].[JobFTEHours]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
StartCompDate VARCHAR(6) NOT NULL,
JobReference VARCHAR(8) NOT NULL,
AuthorisedReference VARCHAR(9),
NoteReference VARCHAR(8),
AuthorisedBody VARCHAR(6),
AuthorisedDate DATE,
JobFTEWPY DECIMAL(6,4),
RHours DECIMAL(5,2),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#57 JobGradeLink

CREATE TABLE [ser_hr].[JobGradeLink]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
DependentGradeReference VARCHAR(8) NOT NULL,
DependentObjectReference VARCHAR(8) NOT NULL,
DependentObjectType VARCHAR(10) NOT NULL,
DependentObsoleteDate DATE,
DependentStartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#58 JobWorkCondition

CREATE TABLE [ser_hr].[JobWorkCondition]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
JobReference VARCHAR(8) NOT NULL,
ConditionStartCompDate VARCHAR(6) NOT NULL,
JobWorkingConditionNote VARCHAR(8),
ConditionId VARCHAR(10),
EndDate DATE,
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#59 Location

CREATE TABLE [ser_hr].[Location]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
LocationReference VARCHAR(8) NOT NULL,
LocationRowReference VARCHAR(15),
AddressReference VARCHAR(20),
NoteReference VARCHAR(8),
LocationCentreFlag VARCHAR(1),
LocationIEParkLevyCode VARCHAR(6),
LocationLevel2 VARCHAR(6),
LocationOnboardingCampaignId VARCHAR(10),
LocationQualificationAwardBody VARCHAR(6),
LocationRegion VARCHAR(6),
LocationTrainingRegion VARCHAR(6),
LocationZone VARCHAR(6),
GlobalLocationNumber VARCHAR(10),
LocationName VARCHAR(40),
ObsoleteDate DATE,
ShortDescription VARCHAR(10),
StartDate DATE,
WeightCategory VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#60 Narrative

CREATE TABLE [ser_hr].[Narrative]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
NarrativeCategory VARCHAR(6) NOT NULL,
NarrativeCode VARCHAR(6) NOT NULL,
NarrativeMLRowReference VARCHAR(15),
ADDDetails VARCHAR(10),
LongDescription VARCHAR(40),
NarrativeAllCountriesFlag VARCHAR(1),
NarrativeExclusionModeFlag VARCHAR(1),
NarrativeLegislationType1 VARCHAR(4),
NarrativeLegislationType10 VARCHAR(4),
NarrativeLegislationType2 VARCHAR(4),
NarrativeLegislationType3 VARCHAR(4),
NarrativeLegislationType4 VARCHAR(4),
NarrativeLegislationType5 VARCHAR(4),
NarrativeLegislationType6 VARCHAR(4),
NarrativeLegislationType7 VARCHAR(4),
NarrativeLegislationType8 VARCHAR(4),
NarrativeLegislationType9 VARCHAR(4),
ObsoleteDate DATE,
ShortDescription VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#61 NominalAccount

CREATE TABLE [ser_hr].[NominalAccount]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
NominalAccountReference VARCHAR(8) NOT NULL,
NoteReference VARCHAR(8),
LongDescription VARCHAR(40),
NominalAccountCode VARCHAR(40),
ObsoleteDate DATE,
ShortDescription VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#62 PayElementBalance

CREATE TABLE [ser_hr].[PayElementBalance]
(
OGGReferenceNumber BIGINT,
EmployeePEPostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
EMPPEId VARCHAR(4) NOT NULL,
CalcArrearsAmount DECIMAL(10,2),
CalcArrearsBalance DECIMAL(10,2),
OGGReplicatedDateandTime DATE,
EESBalance DECIMAL(10,2),
CalcArrearsPERS INT,
ERSCalcArrearsAmount DECIMAL(10,2),
ERSCalcArrearsBalance DECIMAL(10,2),
ERSREDBalance DECIMAL(10,2),
ERSBalance DECIMAL(10,2),
NoPERS INT,
OGGOperation VARCHAR(2),
REDBalance DECIMAL(10,2),
OGGInternalReferenceNumber BIGINT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#63 CompensationType

CREATE TABLE [ser_hr].[CompensationType]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
CompensationTypeName VARCHAR(6) NOT NULL,
OGGInternalReferenceNumber BIGINT,
PayElementId VARCHAR(4) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#64 PayElementCategoryGroup

CREATE TABLE [ser_hr].[PayElementCategoryGroup]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
PECategoryCode VARCHAR(6) NOT NULL,
PECategoryGroupCode VARCHAR(6) NOT NULL,
OGGInternalReferenceNumber BIGINT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#65 PayElement

CREATE TABLE [ser_hr].[PayElement]
(
AdminCostCentreReference VARCHAR(8),
OGGReferenceNumber BIGINT,
EESCostCentreReference VARCHAR(8),
EESNominalAccountReference VARCHAR(8),
ERSCostCentreReference VARCHAR(8),
ERSNominalAccountReference VARCHAR(8),
FINInstalmentAccountReference VARCHAR(8),
LOCCeilingTableReference VARCHAR(8),
NoteReference VARCHAR(8),
PEERSContractCCReference VARCHAR(8),
PEERSTableReference VARCHAR(8),
PEMLRowReference VARCHAR(15),
Rate BIGINT,
RateTableReference VARCHAR(8),
ReferenceNumberTemplate VARCHAR(10),
TableReference VARCHAR(8),
Units BIGINT,
UnitsTableReference VARCHAR(8),
VATCostCentreReference VARCHAR(8),
BacpayPayElementId VARCHAR(4),
GrossUpElementId VARCHAR(4),
HLPEAdinRuleSetId VARCHAR(10),
HLPEEESRuleSetId VARCHAR(10),
HLPEERSRuleSetId VARCHAR(10),
HLPEVATRuleSetId VARCHAR(10),
AdminCharge BIGINT,
AlternativeLongDescription VARCHAR(40),
Amount DECIMAL(10,5),
BackpayFlag VARCHAR(1),
CalcArrearsBalanceFlag VARCHAR(1),
CalcStamp DECIMAL(11,5),
CCFlag VARCHAR(1),
OGGReplicatedDateandTime DATE,
CountryFlag VARCHAR(1),
CourtOrderType VARCHAR(6),
DeductionOrderPrior INT,
EESAccountBalanceFlag VARCHAR(1),
EESAmountFormulaFlag VARCHAR(1),
EESMaxAmount DECIMAL(10,5),
EESMinimumAmount DECIMAL(10,5),
EESPENSGrossAccount VARCHAR(4),
ERSAccountBalanceFlag VARCHAR(1),
ERSAmountFormulaFlag VARCHAR(1),
ERSPENSGrossAccount VARCHAR(4),
GradeRelatedFlag VARCHAR(1),
GrossUpNIFlag VARCHAR(1),
GrossUpTaxFlag VARCHAR(1),
BonusRelatedFlag VARCHAR(1),
CostElement VARCHAR(6),
HoursAccumulators1 VARCHAR(1),
HoursAccumulators2 VARCHAR(1),
HoursAccumulators3 VARCHAR(1),
HoursAccumulators4 VARCHAR(1),
HLPENAPBasic INT,
HLPENAPOvertime INT,
SalaryRelated VARCHAR(6),
IrregularPayIndicator VARCHAR(1),
LiveFlag VARCHAR(1),
LongDescription VARCHAR(40),
MandatoryEndDateFlag VARCHAR(1),
MaximumInputAmount BIGINT,
MaxPeriods INT,
MinimumInputAmount INT,
NETPayNEGAccount VARCHAR(6),
NormalPayAccumulators1 VARCHAR(1),
NormalPayAccumulators10 VARCHAR(1),
NormalPayAccumulators2 VARCHAR(1),
NormalPayAccumulators3 VARCHAR(1),
NormalPayAccumulators4 VARCHAR(1),
NormalPayAccumulators5 VARCHAR(1),
NormalPayAccumulators6 VARCHAR(1),
NormalPayAccumulators7 VARCHAR(1),
NormalPayAccumulators8 VARCHAR(1),
NormalPayAccumulators9 VARCHAR(1),
NotionalFlag VARCHAR(1),
ObsoleteDate DATE,
ONCostIndicator VARCHAR(2),
OGGOperation VARCHAR(2),
OPTAccumulators1 VARCHAR(1),
OPTAccumulators10 VARCHAR(1),
OPTAccumulators2 VARCHAR(1),
OPTAccumulators3 VARCHAR(1),
OPTAccumulators4 VARCHAR(1),
OPTAccumulators5 VARCHAR(1),
OPTAccumulators6 VARCHAR(1),
OPTAccumulators7 VARCHAR(1),
OPTAccumulators8 VARCHAR(1),
OPTAccumulators9 VARCHAR(1),
OvertimeRateNumber INT,
P11DFlag VARCHAR(1),
P11DGBENCode VARCHAR(6),
P11DGBENType VARCHAR(6),
PartPayableFlag VARCHAR(1),
PayEXPIndicator VARCHAR(1),
PayMethod VARCHAR(6),
PayOrDeduction VARCHAR(1),
PayrollIgnoreFlag VARCHAR(1),
PayrollOnlyFlag VARCHAR(1),
PEArrearsBalanceRecoverFlag VARCHAR(1),
PEBalanceCalcArrearsPERS INT,
PercentageFlag VARCHAR(8),
PECurrencyId VARCHAR(10),
PEEESERSFlag VARCHAR(1),
PEERSAmount INT,
PEERSMaximumAmount INT,
PEERSMaximumInputAmount INT,
PEERSMinimumAmount INT,
PEERSMinimumInputAmount INT,
PEERSREDBalanceFlag VARCHAR(1),
PEERSShortFormula VARCHAR(10),
OptionCode VARCHAR(9),
PE11DGBENSecurityCode VARCHAR(6),
P11DMadeGoodFlag VARCHAR(1),
PEPayslipPriority INT,
AccountContractFlag VARCHAR(8),
NotificationContract VARCHAR(8),
PEPROCIF5thWeekFlag VARCHAR(1),
PEREDBalanceRecoverFlag VARCHAR(1),
PERoundingFactor INT,
PESubType VARCHAR(6),
PESuppressYearToDateFlag VARCHAR(1),
WithHoldElementId VARCHAR(8),
PENSLimitedFlag VARCHAR(1),
PENSMultiple INT,
PENSPaidFlag VARCHAR(1),
PENSUsage VARCHAR(6),
PeriodbasedFlag VARCHAR(1),
PERSCategory VARCHAR(6),
PPCFlag VARCHAR(1),
PPCPeriods INT,
PPCYears INT,
PROCIFAdvantageFlag VARCHAR(1),
PROCIFHolidayFlag VARCHAR(1),
PROCIFMATFlag VARCHAR(1),
PROCIFSickFlag VARCHAR(1),
PROTEarnsFlag VARCHAR(1),
PRPInterimFinal VARCHAR(1),
RType VARCHAR(6),
RateFormulaFlag VARCHAR(1),
REDBalanceFlag VARCHAR(1),
RoundingAction VARCHAR(6),
OGGInternalReferenceNumber BIGINT,
ShortDescription VARCHAR(10),
ShortFormula VARCHAR(10),
StarterLeaverIndicator VARCHAR(1),
StatusAccumulators1 VARCHAR(1),
StatusAccumulators10 VARCHAR(1),
StatusAccumulators2 VARCHAR(1),
StatusAccumulators3 VARCHAR(1),
StatusAccumulators4 VARCHAR(1),
StatusAccumulators5 VARCHAR(1),
StatusAccumulators6 VARCHAR(1),
StatusAccumulators7 VARCHAR(1),
StatusAccumulators8 VARCHAR(1),
StatusAccumulators9 VARCHAR(1),
STDPayrunFlag VARCHAR(1),
SupplierPayrunFlag VARCHAR(1),
SystemPositionBoth VARCHAR(1),
TemporaryActionIndicator VARCHAR(1),
TempFormulaIndicator VARCHAR(1),
UnitsFlag VARCHAR(1),
UnitsFormulaFlag VARCHAR(1),
UserUpdateFlag VARCHAR(1),
VARInputFlag VARCHAR(1),
VATRate INT,
PayElementId VARCHAR(4) NOT NULL,
PEERSThirdPartyId VARCHAR(10),
PEGeneralSchemeId VARCHAR(10),
PELinkToElementId VARCHAR(4),
PESalarySACSchemeId VARCHAR(10),
PENSSchemeId VARCHAR(10),
PRPSchemeId VARCHAR(10),
RefundElementId VARCHAR(4),
SlipGroupId VARCHAR(10),
SlipMessageId VARCHAR(10),
SubsGroupId VARCHAR(10),
ThirdPartyId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#66 PayrollPaymentMethod

CREATE TABLE [ser_hr].[PayrollPaymentMethod]
(
OGGReferenceNumber BIGINT,
FinanceInstalmentAccountReference VARCHAR(8),
Reference VARCHAR(8) NOT NULL,
ReferenceNumber VARCHAR(20),
OGGReplicatedDateandTime DATE,
PayType VARCHAR(6) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
OGGOperation VARCHAR(2),
PayrollPaymentMethodName VARCHAR(6),
OGGInternalReferenceNumber BIGINT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#67 PayrollDetail

CREATE TABLE [ser_hr].[PayrollDetail]
(
CostCentreReference VARCHAR(8),
OGGReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PostReference VARCHAR(8) NOT NULL,
Reference VARCHAR(8),
TableReference VARCHAR(8),
BatchId VARCHAR(10),
Identifier VARCHAR(4) NOT NULL,
AccountTaxPeriod VARCHAR(2),
AccountTaxYear VARCHAR(4),
Adjustment INT,
Amount INT,
Arrears INT,
BackpayAmount INT,
BatchSequenceNumber VARCHAR(6),
BackpayOriginalDate DATE,
CalcArrears INT,
OGGReplicatedDateandTime DATE,
DerivedIndicator VARCHAR(1),
EmployeePayType VARCHAR(6),
PHPEABSENTType VARCHAR(6),
PHPEABSPayType VARCHAR(1) NOT NULL,
PHPEATTStartDate DATE,
PHPEATTStartTime VARCHAR(6),
PHPECourtOrderFlag VARCHAR(6),
EmployeeCurrencyAmount INT,
PHPEDaysPaid INT,
PHPEEESSACAmount INT,
PHPEEESExchangeRate INT,
PHPEERSBackpayAmount INT,
PHPEERSFullAmount INT,
PHPEERSSACAmount INT,
PHPEERSUnadjustedAmount INT,
PEPEERSExchangeRate INT,
PHPEJurisdiction VARCHAR(10),
PHPEOriginalTaxPeriod VARCHAR(2),
PHPEOriginalTaxYear VARCHAR(4),
PHPEPeriodDays INT,
PHPETaxTP VARCHAR(6),
PHPEVacationPayNowFlag VARCHAR(1),
PHPEZAPENRTAOffset INT,
EmployeeREVRecordType VARCHAR(2) NOT NULL,
SupplimentNumber VARCHAR(2) NOT NULL,
EmployeeTaxPeriod VARCHAR(2) NOT NULL,
EmployeeTaxYear VARCHAR(4) NOT NULL,
EndDate DATE,
SystemSource INT,
PHPEFactor INT,
PHPENAPBasic INT,
PHPENAPOvertime INT,
PHPEOSPDate1 DATE,
PHPEOSPDate10 DATE,
PHPEOSPDate11 DATE,
PHPEOSPDate12 DATE,
PHPEOSPDate13 DATE,
PHPEOSPDate14 DATE,
PHPEOSPDate15 DATE,
PHPEOSPDate16 DATE,
PHPEOSPDate17 DATE,
PHPEOSPDate18 DATE,
PHPEOSPDate19 DATE,
PHPEOSPDate2 DATE,
PHPEOSPDate20 DATE,
PHPEOSPDate21 DATE,
PHPEOSPDate22 DATE,
PHPEOSPDate23 DATE,
PHPEOSPDate24 DATE,
PHPEOSPDate25 DATE,
PHPEOSPDate26 DATE,
PHPEOSPDate27 DATE,
PHPEOSPDate28 DATE,
PHPEOSPDate29 DATE,
PHPEOSPDate3 DATE,
PHPEOSPDate30 DATE,
PHPEOSPDate31 DATE,
PHPEOSPDate4 DATE,
PHPEOSPDate5 DATE,
PHPEOSPDate6 DATE,
PHPEOSPDate7 DATE,
PHPEOSPDate8 DATE,
PHPEOSPDate9 DATE,
PHPEOSPHoursSession1 INT,
PHPEOSPHoursSession10 INT,
PHPEOSPHoursSession11 INT,
PHPEOSPHoursSession12 INT,
PHPEOSPHoursSession13 INT,
PHPEOSPHoursSession14 INT,
PHPEOSPHoursSession15 INT,
PHPEOSPHoursSession16 INT,
PHPEOSPHoursSession17 INT,
PHPEOSPHoursSession18 INT,
PHPEOSPHoursSession19 INT,
PHPEOSPHoursSession2 INT,
PHPEOSPHoursSession20 INT,
PHPEOSPHoursSession21 INT,
PHPEOSPHoursSession22 INT,
PHPEOSPHoursSession23 INT,
PHPEOSPHoursSession24 INT,
PHPEOSPHoursSession25 INT,
PHPEOSPHoursSession26 INT,
PHPEOSPHoursSession27 INT,
PHPEOSPHoursSession28 INT,
PHPEOSPHoursSession29 INT,
PHPEOSPHoursSession3 INT,
PHPEOSPHoursSession30 INT,
PHPEOSPHoursSession31 INT,
PHPEOSPHoursSession4 INT,
PHPEOSPHoursSession5 INT,
PHPEOSPHoursSession6 INT,
PHPEOSPHoursSession7 INT,
PHPEOSPHoursSession8 INT,
PHPEOSPHoursSession9 INT,
OCCNumber VARCHAR(3) NOT NULL,
OGGOperation VARCHAR(2),
OriginIndicator VARCHAR(1),
GBENOCCNumber VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
StartDate DATE,
P11DOCCNumber VARCHAR(1),
TemporaryOCC VARCHAR(3),
UnadjustedAmount INT,
PHPEABSProcedureIdentifier VARCHAR(1),
PHPEEESCurrencyId VARCHAR(10),
PHPEERSCurrencyId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#68 Payroll

CREATE TABLE [ser_hr].[Payroll]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
PersonReference VARCHAR(8) NOT NULL,
PayType VARCHAR(6) NOT NULL,
REVRecordType VARCHAR(2) NOT NULL,
Level1PayStringReference VARCHAR(8),
NoteReference VARCHAR(8),
PayStringReference VARCHAR(8),
SlipHistoryMessageReference VARCHAR(8),
BaseCurrencyId VARCHAR(10),
PayCurrencyId VARCHAR(10),
AdvantagePastYearFlag VARCHAR(1),
AdvantagePERS INT,
AdvantageType VARCHAR(6),
Status VARCHAR(8),
ArchivedFlag VARCHAR(1),
CalcStamp DECIMAL(11,5),
FCPayslipFlag VARCHAR(1),
NumberofDaysPaid INT,
PaymentDate DATE,
PayrunCalNumber VARCHAR(8),
TaxPERRunType VARCHAR(6),
PayrollTermStamp VARCHAR(12),
EmployeeNumber VARCHAR(10),
Initials VARCHAR(5),
LegislationType VARCHAR(4),
NICategory VARCHAR(6),
NINumber VARCHAR(20),
OverrideFlag VARCHAR(1),
PaidWhilstAdvantageFlag VARCHAR(1),
PayDate DATE,
PayMethod VARCHAR(6),
ProcessFlags1 VARCHAR(1),
ProcessFlags10 VARCHAR(1),
ProcessFlags2 VARCHAR(1),
ProcessFlags3 VARCHAR(1),
ProcessFlags4 VARCHAR(1),
ProcessFlags5 VARCHAR(1),
ProcessFlags6 VARCHAR(1),
ProcessFlags7 VARCHAR(1),
ProcessFlags8 VARCHAR(1),
ProcessFlags9 VARCHAR(1),
PRISClass VARCHAR(6),
PRSIClassUsed VARCHAR(6),
ROITaxAllow INT,
ROITaxTableLET VARCHAR(1),
OGGInternalReferenceNumber BIGINT,
RunPeriod VARCHAR(2),
RunSupplierNumber VARCHAR(2),
RunYear VARCHAR(4),
SupplierNumber VARCHAR(2) NOT NULL,
Surname VARCHAR(50),
TaxCode VARCHAR(7),
TaxPersonSupplierNumber VARCHAR(2),
TaxPeriod VARCHAR(2) NOT NULL,
TaxPeriodFlag VARCHAR(1),
TaxYear VARCHAR(4) NOT NULL,
TaxedATPeriod VARCHAR(2),
TaxedATSupplierNumber VARCHAR(2),
TaxedATYear VARCHAR(4),
Title VARCHAR(6),
Week53Flag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#69 PayrollLoan

CREATE TABLE [ser_hr].[PayrollLoan]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
StartCompDate VARCHAR(6) NOT NULL,
LoanType VARCHAR(10) NOT NULL,
PayType VARCHAR(6) NOT NULL,
SupplierNumber VARCHAR(2) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
LoanSuspendPeriods INT,
LoanTerminateFlag VARCHAR(1),
LoanBenefitAmount DECIMAL(10,2),
LoanCapitalAmount DECIMAL(11,2),
LoanInterestAmount DECIMAL(10,2),
LoanPaymentsMade INT,
LoanPreviousLastDeduction VARCHAR(6),
LoanPreviousTermFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#70 PayrollPayRate

CREATE TABLE [ser_hr].[PayrollPayRate]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
PayType VARCHAR(6) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
UnitsTableReference VARCHAR(8),
RateTableReference VARCHAR(8),
PECurrencyRate DECIMAL(12,4),
FullUnits INT,
Rate DECIMAL(12,4),
UnadjustedRate DECIMAL(12,4),
UnadjustedUnits INT,
Units INT,
UnitsArrears INT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#71 PensionScheme

CREATE TABLE [ser_hr].[PensionScheme]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PensionSchemeId VARCHAR(10) NOT NULL,
AddressReference VARCHAR(20),
GroupReference VARCHAR(6),
NoteReference VARCHAR(8),
ReferenceType VARCHAR(6),
PEId VARCHAR(4),
AccrualType VARCHAR(6),
AdminPosition VARCHAR(250),
AnniversaryDate DATE,
APRVDate DATE,
AVCProvider VARCHAR(30),
AVCType VARCHAR(6),
CalcStamp DECIMAL(11,6),
CloseDate DATE,
CNTRTEES DECIMAL(5,2),
CNTRTERS DECIMAL(5,2),
COFlag VARCHAR(1),
EconomicNumber VARCHAR(9),
EntryDate DATE,
ERSName VARCHAR(250),
ERSPosition VARCHAR(250),
GMPREVType VARCHAR(6),
INTRate DECIMAL(5,2),
LongDescription VARCHAR(40),
MaximumAge INT,
MinimumAge INT,
MinimumService VARCHAR(8),
NRAGEFemale INT,
NRAGEMale INT,
NRDGENType VARCHAR(6),
ObsoleteDate DATE,
PensionSchemeAESType VARCHAR(6),
PensionSchemeAUABNNumber VARCHAR(14),
PensionSchemeAUClientNumber VARCHAR(9),
PensionSchemeAUGSTNumber VARCHAR(3),
PensionSchemeAUSpinNumber VARCHAR(30),
PensionSchemeBackPENSEEAccount VARCHAR(4),
PensionSchemeBackPENSERAccount VARCHAR(4),
PensionSchemeCappedIndicator VARCHAR(1),
PensionSchemeCASVariant VARCHAR(1),
PensionSchemeClass VARCHAR(6),
PensionSchemeCONIFlag VARCHAR(1),
PensionSchemeContact VARCHAR(30),
PensionSchemeFaxNumber VARCHAR(20),
PensionSchemeFundNumber VARCHAR(30),
PensionSchemeIEDeductionExistFlag VARCHAR(1),
PensionSchemeIETaxRelevanceEEIndicator VARCHAR(1),
PensionSchemeLegislativeType VARCHAR(3),
PensionSchemeLGPSParameter VARCHAR(10),
PensionSchemeMARGRateIndicator VARCHAR(1),
PensionSchemeMaternityPE VARCHAR(4),
PensionSchemeMigrationDate DATE,
PensionSchemeMobileNumber VARCHAR(20),
PensionSchemeNICategory VARCHAR(6),
PensionSchemePERSAccountDate DATE,
PensionSchemeSalarySACFlag VARCHAR(1),
PensionSchemeTeachFlag VARCHAR(8),
PensionSchemeTelephoneNumber VARCHAR(20),
PensionSchemeTransitionDate DATE,
PensionSchemeUKRelated VARCHAR(1),
PensionSchemeRFIndicator VARCHAR(1),
SCONNumber VARCHAR(9),
ServiceFormat VARCHAR(6),
ServicePartPeriod INT,
ServiceRounding VARCHAR(6),
ShortDescription VARCHAR(10),
StartDate DATE,
TOTSERVLimit VARCHAR(8),
USPensionSchemeAssociate401KId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#72 Person

CREATE TABLE [ser_hr].[Person]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
AddressReference VARCHAR(20),
Contact1AddressReference VARCHAR(8),
Contact2AddressReference VARCHAR(8),
DoctorAddressReference VARCHAR(8),
EthnicNoteReference VARCHAR(8),
HealthNoteReference VARCHAR(8),
NoteReference VARCHAR(8),
AllQualifiedNoteReference VARCHAR(8),
AdaptationReference VARCHAR(8),
CountryId VARCHAR(3),
EPAFolderId VARCHAR(10),
IdentifierDate DATE,
IntranetProfileId VARCHAR(10),
ApplicationMainPostFlag VARCHAR(1),
BirthDate VARCHAR(50),
BirthDateAlphabet VARCHAR(6),
CountryofBirth VARCHAR(6),
DeathDate DATE,
DoctorInitials VARCHAR(5),
DoctorSurname VARCHAR(20),
DoctorTelephoneNumber VARCHAR(20),
EthnicOrigin VARCHAR(6),
FirstForename VARCHAR(40),
DateofBirthVerifiedFlag VARCHAR(1),
FailedRenew VARCHAR(1),
OverseasFellow VARCHAR(1),
ResidenceStatus VARCHAR(6),
SpecifiedInterest VARCHAR(6),
MDTrainingCountry VARCHAR(6),
UKOverseesDoctor VARCHAR(1),
RegistrationNumber VARCHAR(12),
RegistrationRenewDate DATE,
RegistrationType VARCHAR(6),
HomeTelephoneNumber VARCHAR(20),
Honours VARCHAR(30),
Initials VARCHAR(10),
KnownAs VARCHAR(20),
MandateRegistrationDiscountCode VARCHAR(2),
NationalityCitizenship VARCHAR(6),
NINumber VARCHAR(20),
AllQualifiedStandard VARCHAR(6),
OtherForenames VARCHAR(50),
BirthName VARCHAR(75),
PersonCareer VARCHAR(8),
CaseNumber VARCHAR(30),
Continued1TelephoneNumber VARCHAR(20),
Continued2TelephoneNumber VARCHAR(20),
DisabilityOne VARCHAR(6),
DisabilityTwo VARCHAR(6),
DisableFlag VARCHAR(1),
EqualOpportunityParticipation VARCHAR(1),
FaxNumber VARCHAR(20),
FistAiderFlag VARCHAR(1),
Generation VARCHAR(20),
IdentitySource VARCHAR(6),
KnownAsSurname VARCHAR(50),
LanguageCode VARCHAR(10),
LinkedInProfileURL VARCHAR(200),
MobileTelephoneNumber VARCHAR(20),
NonResident VARCHAR(6),
PersonOnboardingProfileId VARCHAR(8),
PassportNumber VARCHAR(20),
PhotoDisplay VARCHAR(1),
PinChangedDate DATE,
PinInvalidLogonCount INT,
PinNumber VARCHAR(64),
PinSuspendedFlag VARCHAR(1),
PassportIssuedCountry VARCHAR(6),
PassportExpiryDate DATE,
NotificationMethod VARCHAR(1),
PersonPregnancyMaternity VARCHAR(8),
ResidentDate DATE,
SecurityAnswer VARCHAR(20),
SexualOrientation VARCHAR(6),
SMSFlag VARCHAR(1),
ReturnDate VARCHAR(10),
StandardOCCClass VARCHAR(6),
TransGengerFlag VARCHAR(8),
VisaIssuedCountry VARCHAR(6),
VisaExpiryDate DATE,
VisaIssuedDate DATE,
VisaNumber VARCHAR(30),
PreviousSurname VARCHAR(50),
RegistrationDISExperience DATE,
RegistrationDISNumber VARCHAR(10),
Religion VARCHAR(6),
Sex VARCHAR(1),
Surname VARCHAR(50),
Title VARCHAR(6),
WorkTelephoneNumber VARCHAR(20),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#73 EmployeeDependent

CREATE TABLE [ser_hr].[EmployeeDependent]
(
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
STARTCOMPDATE VARCHAR(6) NOT NULL,
DependentId VARCHAR(10),
CHANGEREASON VARCHAR(6),
PeriodEndTimestamp DATE,
PeriodStartTimestamp DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#74 MaritalStatus

CREATE TABLE [ser_hr].[MaritalStatus]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PersonReference VARCHAR(8) NOT NULL,
PeriodStartDate DATE NOT NULL,
MaritalStatusName VARCHAR(6),
StartCompDate VARCHAR(6),
VerifyFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#75 PersonPostLink

CREATE TABLE [ser_hr].[PersonPostLink]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
EmployeePostLinkReference VARCHAR(8) NOT NULL,
EmployeePostReference VARCHAR(8),
PostLinkGroupReference VARCHAR(8),
PersonReference VARCHAR(8),
PostStartCompDate INT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#76 EmployeePartyRelationType

CREATE TABLE [ser_hr].[EmployeePartyRelationType]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
PersonReference VARCHAR(8) NOT NULL,
PersonReferenceR VARCHAR(8) NOT NULL,
EmployeePartyRelationTypeName VARCHAR(6) NOT NULL,
NoteReference VARCHAR(8),
RelationshipERSAddressReference VARCHAR(8),
UserDataKeyReference VARCHAR(8),
NextofKinFlag VARCHAR(1),
ECRestricted VARCHAR(1),
RelationshipEducationEmporium VARCHAR(6),
RelationshipERSName VARCHAR(40),
RelationshipPartnerFlag VARCHAR(1),
EmployeePartyRelationTypeDescription VARCHAR(40),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#77 Position

CREATE TABLE [ser_hr].[Position]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PositionID VARCHAR(8) NOT NULL,
AuthorityReference VARCHAR(9),
PostNoteReference VARCHAR(8),
UserDataKeyReference VARCHAR(8),
JobID VARCHAR(8),
Positionnote VARCHAR(8),
NumberReference VARCHAR(10),
ObsoleteAuthorityReference VARCHAR(9),
MLRowReference VARCHAR(15),
DefaultClaimFormId VARCHAR(10),
DefaultFormId VARCHAR(10),
IntranetProfileId VARCHAR(10),
MPWCodeId VARCHAR(10),
LGMBEmployeeCategory VARCHAR(6),
LGMBReportPart VARCHAR(6),
SSDSEmployeeCategory VARCHAR(6),
SSDSReportPart VARCHAR(6),
AnalysisCodeOne VARCHAR(8),
AnalysisCodeThree VARCHAR(8),
AnalysisCodeTwo VARCHAR(8),
AuthorityBody VARCHAR(6),
AuthorityDate DATE,
Class VARCHAR(6),
FundingBody VARCHAR(6),
FundingPercent INT,
GradeUsageLevel INT,
BankNurse VARCHAR(1),
FunctionGroup VARCHAR(30),
HourSessionIndicator VARCHAR(1),
JobTitle VARCHAR(6),
LondonIndicator VARCHAR(1),
SecondSpeciality VARCHAR(6),
MDFlag VARCHAR(1),
GPVOCScheme VARCHAR(1),
MDNHD DECIMAL(4,2),
OccasionalSHS VARCHAR(1),
RotationScheme VARCHAR(6),
MDScheme DECIMAL(4,2),
MDSession DECIMAL(4,2),
OccupationCode VARCHAR(6),
OrganizationType VARCHAR(6),
Speciality VARCHAR(6),
PositionDescription VARCHAR(40),
MinimumManualLevel DECIMAL(6,2),
MPWManualFlag VARCHAR(1),
ObsoleteAuthorityBody VARCHAR(6),
ObsoleteAuthorityDate DATE,
ObsoleteDate DATE,
OverrideHours DECIMAL(4,2),
PensionableFlag VARCHAR(1),
POLRestrictFlag VARCHAR(1),
ExcludeEmployeeDirectFlag VARCHAR(1),
PostionClosedDate DATE,
PostionCreatedDate DATE,
JSWConstructFlag VARCHAR(1),
MVStartLegislationType VARCHAR(15),
UseStartLeg VARCHAR(1),
NeedsSuccessionPlan VARCHAR(1),
PostOnboardingCampaignId VARCHAR(8),
PostOnboardingProfileId VARCHAR(8),
ProfileId VARCHAR(10),
ReportONSir VARCHAR(1),
PostTeachFlag VARCHAR(8),
SickOverheadPercent DECIMAL(5,2),
PostSIRApportion1 DECIMAL(5,2),
PostSIRApportion2 DECIMAL(5,2),
PostSIRApportion3 DECIMAL(5,2),
SIRAreaTaught VARCHAR(2),
SIRWorkCategory VARCHAR(2),
ResponsibilityPERSOff VARCHAR(9),
ResponsibilityRECROff VARCHAR(9),
PositionName VARCHAR(10),
PositionCreatedDate DATE,
PostType VARCHAR(10),
ReportRow VARCHAR(3),
VacancyFrozenFlag VARCHAR(1),
RoleId VARCHAR(10),
WorkPatternId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#78 PositionFullTimeEquationHours

CREATE TABLE [ser_hr].[PositionFullTimeEquationHours]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
PostReference VARCHAR(8) NOT NULL,
NoteReference VARCHAR(8),
AuthorityReference VARCHAR(9),
AuthorityBody VARCHAR(6),
AuthorityDate DATE,
HeadCount INT,
FTEHours DECIMAL(4,2),
FTESessions INT,
MDADH1 DECIMAL(4,2),
MDADH2 DECIMAL(4,2),
MDADH3 DECIMAL(4,2),
RHours INT,
StartCompDate VARCHAR(6),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#79 PositionGrade

CREATE TABLE [ser_hr].[PositionGrade]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PostReference VARCHAR(8) NOT NULL,
Reference VARCHAR(8) NOT NULL,
NoteReference VARCHAR(8),
EndDate DATE,
StartCompDate VARCHAR(6),
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#80 PositionGroupHistory

CREATE TABLE [ser_hr].[PositionGroupHistory]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PostReference VARCHAR(8) NOT NULL,
SonPostReference VARCHAR(8) NOT NULL,
DependentId VARCHAR(10) NOT NULL,
HierarchyEffectiveCompDate INT NOT NULL,
HierarchyLevelNumber VARCHAR(2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#81 PositionLink

CREATE TABLE [ser_hr].[PositionLink]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
LinkPostReference VARCHAR(8) NOT NULL,
EmployeePostReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
LinkPostStartCompDate VARCHAR(6) NOT NULL,
EmployeePostStartCompDate VARCHAR(6) NOT NULL,
LinkPostHoursFlag VARCHAR(1),
LinkPostSeniorityFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#82 PositionLocation

CREATE TABLE [ser_hr].[PositionLocation]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
StartCompDate INT ,
NoteReference VARCHAR(8),
PostReference VARCHAR(8) NOT NULL,
StartDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#83 PositionStructureUnitHistory

CREATE TABLE [ser_hr].[PositionStructureUnitHistory]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PostReference VARCHAR(8) NOT NULL,
StructureReference VARCHAR(8) NOT NULL,
DependentId VARCHAR(10) NOT NULL,
HierarchyEffectiveCompDate INT NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#84 PositionToPositionHieraricalRelation

CREATE TABLE [ser_hr].[PositionToPositionHieraricalRelation]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
PostReference1 VARCHAR(8) NOT NULL,
PostReference2 VARCHAR(8) NOT NULL,
DependentId VARCHAR(10) NOT NULL,
HierarchyEffectiveCompDate VARCHAR(6) NOT NULL,
PostRelationship VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#85 RuleDelegationFor

CREATE TABLE [ser_hr].[RuleDelegationFor]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
RuleForReference VARCHAR(8) NOT NULL,
RuleForEmployeePostReference VARCHAR(8),
RuleForPersonReference VARCHAR(8),
RuleReference VARCHAR(8),
RuleForPostStartCompDate INT,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#86 RuleDelegationTo

CREATE TABLE [ser_hr].[RuleDelegationTo]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
RuleDelegateReference VARCHAR(8) NOT NULL,
RuleFromPersonReference VARCHAR(8),
RuleReference VARCHAR(8),
RuleToPersonReference VARCHAR(8),
RuleType VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#87 ServiceCondition

CREATE TABLE [ser_hr].[ServiceCondition]
(
OGGReplicatedDateandTime DATE,
OGGReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
ConditionId VARCHAR(10) NOT NULL,
MLRowReference VARCHAR(15),
ConditionNoteReference VARCHAR(8),
ProRataCalcId VARCHAR(6),
EndDate DATE,
LongDescription VARCHAR(40),
NEGGroup VARCHAR(6),
PayAwardPay INT,
ShortDescription VARCHAR(10),
StartDate DATE,
LeaverCalcId VARCHAR(6),
StarterCalcId VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#88 ServiceConditionDetail

CREATE TABLE [ser_hr].[ServiceConditionDetail]
(
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
ConditionId VARCHAR(10) NOT NULL,
SetEffectiveCompDate VARCHAR(6) NOT NULL,
PayType VARCHAR(6) NOT NULL,
PositionStatus VARCHAR(6) NOT NULL,
ConditionSetType VARCHAR(6) NOT NULL,
NoteReference VARCHAR(8),
EffectiveDate DATE,
EndDate DATE,
ShipLinkIdentifier VARCHAR(1),
TypeId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#89 StructureUnit

CREATE TABLE [ser_hr].[StructureUnit]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
NoteReference VARCHAR(8),
AdminCCReference VARCHAR(8),
EESCCReference VARCHAR(8),
STRERSCCReference VARCHAR(8),
ERSContractCCReference VARCHAR(8),
LevelFinanceInstalmentAccountReference VARCHAR(8),
STRMLRowReference VARCHAR(15),
ONCContractCCReference VARCHAR(8),
OnCostCCReference VARCHAR(8),
CostCodeReference VARCHAR(8),
VATCCReference VARCHAR(8),
Identifier VARCHAR(10),
CostingPercentage VARCHAR(6),
HospitalName VARCHAR(30),
LongDescription VARCHAR(40),
ObsoleteDate DATE,
ShortDescription VARCHAR(250),
EmployeeCostMethodFlag VARCHAR(1),
STREmployer VARCHAR(10),
CostIndicator VARCHAR(1),
RecoverLateIndicator VARCHAR(1),
SlipMessageId VARCHAR(10),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#90 StructureUnitReference

CREATE TABLE [ser_hr].[StructureUnitReference]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
FINInstalmentAccountReference VARCHAR(8),
AdminCostCentreReference VARCHAR(8),
ClientReference VARCHAR(8),
VATCostCodeReference VARCHAR(8),
ACPTLockOperatorId VARCHAR(10),
CMParameterSetId VARCHAR(10),
CoinSetId VARCHAR(10),
DivisorSetId VARCHAR(10),
GenericId VARCHAR(25),
OEATaxPERSetId VARCHAR(10),
PLKITOffsetPEId VARCHAR(4),
PLKITPEId VARCHAR(4),
ProrataCalcId VARCHAR(6),
ProrataLeaverCalcId VARCHAR(6),
ProrataStarterCalcId VARCHAR(6),
ACPTLockStamp DECIMAL(11,6),
ACPTLockUserGroupCode VARCHAR(10),
AdminCharge DECIMAL(10,2),
AdvancePers INT,
AdvanceType VARCHAR(6),
AllowNegotiationNetFlag VARCHAR(1),
BACSUserNumber VARCHAR(10),
CalcStamp DECIMAL(11,6),
ContractCostCode VARCHAR(40),
DSSNote1 VARCHAR(18),
DSSNote2 VARCHAR(18),
DSSNote3 VARCHAR(18),
DSSSubhead VARCHAR(36),
GrossPayThreshold DECIMAL(10,2),
BankPayENH045 VARCHAR(1),
BankPayPRDS044 INT,
BankPostQUA046 DECIMAL(7,2),
DistrictEACode VARCHAR(6),
RegionEACode VARCHAR(6),
HLSTRResetInhibitStatus VARCHAR(1),
MaxPersonWhileAdvance INT,
NetPayThreshold DECIMAL(10,2),
NIMethod VARCHAR(1),
NICHolidayIndicator VARCHAR(1),
OnCostIndicator VARCHAR(1),
PayHistoryFlag VARCHAR(1),
PRPFlag VARCHAR(1),
ResetInhibitStatus VARCHAR(1),
RNDFactor DECIMAL(10,2),
ROIFASLevyFlag VARCHAR(1),
ROIPayFlag VARCHAR(1),
ROIPRSIDefaultClass VARCHAR(1),
SMPRecoveryFlag VARCHAR(1),
SSPQualifyingDays VARCHAR(7),
SSPRecoveryFlag VARCHAR(1),
SlipMessageId VARCHAR(10),
ASPPRecoveryFlag VARCHAR(1),
BackdateNIFlag VARCHAR(1),
StatusId VARCHAR(16),
ClaimDefaultPeriod VARCHAR(6),
CMTaxedFlag VARCHAR(1),
StringBaseCurrencyId VARCHAR(10),
FLINKCCN VARCHAR(6),
GenericFlag VARCHAR(1),
StringControlTaxSetId VARCHAR(10),
IEDeductExcessFlag VARCHAR(1),
PARKLevyCode VARCHAR(6),
PRDActive VARCHAR(1),
TAXRELAppliesFlag VARCHAR(1),
DelayTermFlag VARCHAR(1),
MPOSTAbsoluteFlag VARCHAR(1),
SERVStartDateIndicator VARCHAR(1),
LEANumber VARCHAR(10),
LegislationType VARCHAR(3),
LinkedEmp VARCHAR(1),
CAPRLBSDCRNTFlag VARCHAR(1),
LTSickPreviousPersonFlag VARCHAR(1),
MyviewBrandingFlag VARCHAR(1),
NestGroup VARCHAR(40),
NestPaymentSource VARCHAR(40),
DECRAmount DECIMAL(10,2),
DECRPercentage DECIMAL(5,2),
INCRAmount DECIMAL(10,2),
VARINCRPercentage DECIMAL(5,2),
FileExtractType VARCHAR(6),
FileNameTemplate1 VARCHAR(10),
FileNameTemplate2 VARCHAR(10),
FileNameTemplate3 VARCHAR(10),
OnboardingCampaignId VARCHAR(8),
WPRMultiFlag VARCHAR(1),
PENSERVEREmployer VARCHAR(4),
PENSERVERPayPNT VARCHAR(6),
PENSERVERPENOnly VARCHAR(1),
PENSERVERPreviousRunDate DATE,
PENSERVERRunDate DATE,
PENSERVERRunSequence INT,
PENSERVERStartDate DATE,
PensionPayrollFlag VARCHAR(1),
PayMethod VARCHAR(8),
PostBasedPension VARCHAR(8),
RCBACSFlag VARCHAR(1),
RCPreviewFlag VARCHAR(1),
RCStatusIndicator VARCHAR(6),
IrregularPayFlag VARCHAR(1),
ZeroHoursFlag VARCHAR(8),
SAPRecoveryFlag VARCHAR(1),
SickPeriodType VARCHAR(6),
SlipSupplierAddress VARCHAR(1),
SlipSupplierBankDetails VARCHAR(1),
SlipSupplierCumulativeRange DECIMAL(10,2),
SlipSupplierGross VARCHAR(1),
SlipSupplierNet VARCHAR(1),
SlipSupplierPeriod VARCHAR(2),
SlipSupplierRange DECIMAL(10,2),
SlipSuppressFlag VARCHAR(1),
RecoveryFlag VARCHAR(1),
SSSIGroup VARCHAR(40),
SSSISubGroup VARCHAR(40),
TAPERedDateFlag VARCHAR(1),
UKUserLMFlag VARCHAR(1),
UseOSPWPForSSPQD VARCHAR(1),
STRWeek53Period1Basis VARCHAR(1),
WeekStartDay VARCHAR(8),
SuspendedFlag VARCHAR(1),
TaxPersonSetId VARCHAR(10),
TempInputFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#91 TaxPeriod

CREATE TABLE [ser_hr].[TaxPeriod]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGInternalReferenceNumber BIGINT,
OGGOperation VARCHAR(2),
SetId VARCHAR(10) NOT NULL,
Number VARCHAR(2) NOT NULL,
RYear VARCHAR(4) NOT NULL,
SupplierNumber VARCHAR(2) NOT NULL,
BACSPROCDate DATE,
TaxPeriodRunNoteReference VARCHAR(8),
CostBatchDate DATE,
CostTransferDate DATE,
CreditTransferDate DATE,
EmployeeQualifiedDate DATE,
EndDate DATE,
NumberofWeeks INT,
PayDate DATE,
StartDate DATE,
TaxPeriod5thWeekFlag VARCHAR(1),
TaxPeriod8HREndDate DATE,
TaxPeriod8HRStartDate DATE,
TaxPeriod8HRWeeks INT,
TaxPeriodFinanceNumber VARCHAR(2),
TaxPeriodHRCutOffDate DATE,
TaxPeriodLastPeriodFlag VARCHAR(1),
TaxPeriodMPFPersonNumber VARCHAR(2),
TaxPeriodMPFYear VARCHAR(4),
TaxPeriodPaymentDate DATE,
TaxPeriodPayrollCutOffDate DATE,
TaxPeriodPRP6thFlag VARCHAR(1),
TaxPeriodEndDate VARCHAR(10),
TaxPeriodStartDate VARCHAR(10),
TaxPeriodPRPWeek INT,
TaxPeriodPRSIWeeks INT,
TaxPeriodQuarterNumber VARCHAR(2),
TaxPeriodReportingMonth VARCHAR(2),
TaxPeriodRunType VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#92 TemporaryPayElement

CREATE TABLE [ser_hr].[TemporaryPayElement]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
AccountReference VARCHAR(8) NOT NULL,
PersonReference VARCHAR(8) NOT NULL,
PayType VARCHAR(6) NOT NULL,
PMTPayMethod VARCHAR(6) NOT NULL,
RevRecordType VARCHAR(2) NOT NULL,
SupplierNumber VARCHAR(2) NOT NULL,
TaxPeriod VARCHAR(2) NOT NULL,
TaxYear VARCHAR(4) NOT NULL,
RTIBacsCode VARCHAR(8),
PHPMTType VARCHAR(1),
PECurrencyAmount DECIMAL(10,2),
PMTCurrencyId VARCHAR(10),
Amount DECIMAL(10,2),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#93 UserDefinationFields

CREATE TABLE [ser_hr].[UserDefinationFields]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
DataKeyReference VARCHAR(8) NOT NULL,
FieldReference VARCHAR(8) NOT NULL,
ScreenReference VARCHAR(8) NOT NULL,
DataKeyId VARCHAR(10) NOT NULL,
DataValue VARCHAR(40),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#94 UserDefinationFieldsInfo

CREATE TABLE [ser_hr].[UserDefinationFieldsInfo]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
ScreenReference VARCHAR(8) NOT NULL,
UserFieldMLRowReference VARCHAR(15),
Identifier VARCHAR(8),
LinkId VARCHAR(8),
CategoryName VARCHAR(6),
DictionaryName VARCHAR(12),
FunctionOperand VARCHAR(6),
HelpMessage VARCHAR(40),
KeyNumber VARCHAR(1),
UserFieldEventId VARCHAR(6),
MandatoryIndicator VARCHAR(1),
MaximumLength INT,
MinimumLength INT,
Modifier DECIMAL(7,2),
RType VARCHAR(6),
RangeMaximum VARCHAR(25),
RangeMinimum VARCHAR(25),
SequenceNumber INT,
Template VARCHAR(10),
Text VARCHAR(20),
UserFieldDefaultValue VARCHAR(40),
UserFieldHideField VARCHAR(1),
UserFieldObsoleteDate DATE,
ValidFunctionNumber VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#95 WorkPattern

CREATE TABLE [ser_hr].[WorkPattern]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
WorkPatternId VARCHAR(10) NOT NULL,
NoteReference VARCHAR(8),
WorkPatternMLRowReference VARCHAR(15),
EquivalentWeeklyHours DECIMAL(10,4),
Length INT,
LongDescription VARCHAR(40),
ObsoleteDate DATE,
ShortDescription VARCHAR(10),
StartDate DATE,
WorkPatternEquivalentWeeklyPay DECIMAL(10,4),
WorkPatternMyTeamRotaFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#96 WorkPatternDay

CREATE TABLE [ser_hr].[WorkPatternDay]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Number VARCHAR(3) NOT NULL,
WorkPatternId VARCHAR(10) NOT NULL,
Reference VARCHAR(8),
Flag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#97 WorkPatternSession

CREATE TABLE [ser_hr].[WorkPatternSession]
(
OGGReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
OGGOperation VARCHAR(2),
OGGInternalReferenceNumber BIGINT,
Reference VARCHAR(8) NOT NULL,
SessionNumber VARCHAR(3) NOT NULL,
WorkPatternId VARCHAR(10) NOT NULL,
SessionEnd VARCHAR(6),
SessionStart VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);



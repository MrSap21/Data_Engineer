/*
**************************************************************************************************************************
Script Name                          : Create_HRRefLov 
Purpose                              : Create the reference table for HR sources 
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================
 
14-Apr-2022   : Pandiarajan               : Create the reference table for HR sources                             

**************************************************************************************************************************
*/
	
CREATE SCHEMA ser_hr  AUTHORIZATION dbo;
	
CREATE TABLE [ser_hr].[HRRefLOV]
(
[LOVId] [int] NOT NULL,
[LOVSetId] [int] NOT NULL,
[LOVKey] [nvarchar](128) NOT NULL,
[LOVName] [nvarchar](128) NOT NULL,
[LOVDescription] [nvarchar](1024) NULL,
[LOVSequence] [int] NULL,
[RecordSourceId] [int] NOT NULL,
[ETLRunLogId] [int] NULL,
[ActiveFlag] [smallint] NOT NULL,
[DTCreated] [smalldatetime] NULL,
[UserCreated] [nvarchar](128) NULL
)
WITH
(
DISTRIBUTION = REPLICATE,
HEAP
)
GO
	

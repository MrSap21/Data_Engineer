/*
************************************************************************************************************
Script Name                          : Create_Tables_Parenting_Club_v1.0_WIP
Purpose                              : Create Table Script for Parenting Club tables
************************************************************************************************************
Modification History

**************************************************************************************************************************
Date             :      Modified By               :     Description
14-Feb-2022				Pandiarajan 					Renamed column to TRANSACTION_DATE_P_KEY FROM DATE_P_KEY
14-Feb-2022				Pandiarajan						Rename columns TOTAL_UNITS_STORE,TOTAL_TISP_STORE,TOTAL_UNITS_ONLINE,TOTAL_TISP_ONLINE
==========================================================================================================================
**************************************************************************************************************************
*/


CREATE TABLE [con_dwh].[RPT_PARENTING_CLUB]
(
[TRANSACTION_DATE_P_KEY] [DATE] NOT NULL,
[DEAL_NUMBER_P_KEY] [INT] NOT NULL,
[PROMOTION_NUMBER_P_KEY] [INT] NOT NULL,
[SUPPLIER_NUMBER_P_KEY] [INT] NOT NULL,
[PRODUCT_SOURCE_KEY_P_KEY] [NVARCHAR]  (100) NOT NULL,
[PRODUCT_DESCRIPTION] [NVARCHAR] (100) NOT NULL,
[REPORTING_COUNTRY_CODE_P_KEY] [CHAR](3) NOT NULL,
[SUPPLIER_ACCOUNT_NAME] [NVARCHAR] (50) NOT NULL,
[TOTAL_UNITS_STORE] [DECIMAL] (18,4) NOT NULL,
[TOTAL_TISP_STORE] [DECIMAL] (18,4) NOT NULL,
[TOTAL_UNITS_ONLINE] [DECIMAL] (18,4) NOT NULL,
[TOTAL_TISP_ONLINE] [DECIMAL] (18,4) NOT NULL,
[TRANSACTION_STORE_COUNT] [INT] NOT NULL,
[TRANSACTION_ONLINE_COUNT] [INT] NOT NULL,
[CREATE_DATETIME] [DATETIME2] NOT NULL,
[UPDATE_DATETIME] [DATETIME2] NULL
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO



CREATE TABLE [con_dwh].[SS_REF_PARENTING_CLUB_DEAL]
(
[START_DATE] [DATE] NOT NULL,
[EXPIRATION_DATE] [DATE] NOT NULL,
[DEAL_NUMBER_P_KEY] [INT] NOT NULL,
[PROMOTION_NUMBER_P_KEY] [INT] NOT NULL,
[REPORTING_COUNTRY_CODE_P_KEY] [CHAR] (2) NOT NULL,
[CREATE_DATETIME] [DATETIME2] NOT NULL,
[UPDATE_DATETIME] [DATETIME2] NULL
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO


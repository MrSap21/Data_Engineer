/*
**************************************************************************************************************************
Script Name                          : Create_Columbus_Release_4_Version3.0    
Purpose                              : Create Table Script for Columbus
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================
7-Apr-2022   : Sai Goutham         : Create_Columbus_Release_4_Version3.0 
25-Apr-2022  : Afifa Azad          : Added third bracket to ElectronicPharmacistsInformationFormLabel.Label as Label is a keyword           
25-Apr-2022  : Afifa Azad          : Removed duplicate scripts for GlobalCodeAndParameterElementValue 
25-Apr-2022  : Afifa Azad          : Removed GridCell.SourceSystemID in sync with Mapping Document
10-May-2022  : Afifa Azad          : Supplier.SupplierName data length increased to VARCHAR(80)
                                     Nullability of PackQualifier.PharmacyProductSKUID, PackQualifier.PharmacyRegionalProductSKUID has been updated
12-May-2022   : Sai Goutham        : AdvanceShipmentNoticeLineOrdered.SourceKey changed to nullable column
13-May-2022   : Sai Goutham        :  GridStore.PharmacySiteRoleID Changed to nullable
16-May-2022   : Sai Goutham        : OrderStatusUpdateLineOrdered,AdvanceShipmentNoticeLineOrdered,                                                                              OrderStatusUpdateLineSupplied,AdvanceShipmentNoticeLineSupplied,HandlingUnitItem,StockAvailability
                                      removed ActualProductpackID column
16-May-2022   : Sai Goutham        : In Precsriber table  PrescriberFirstName,PrescriberFullName,NormalizedName,PrescriberSurname columns                                       changed VARCHAR to NVARCHAR
25-May-2022   : Sai Goutham        : FormularyProduct.PharmacyProductID
                                     GridAxis.GridID
                                     GridLayer.GridID
                                     GlobalCodeAndParameterElementValue.GlobalCodeAndParameterElementID
                                     GridAxisThreshold.GridAxisID
                                     GridCell.GridLayerID
                                     GridCell.GridCellValueID
                                     HandlingUnit.GoodsReceiptID
                                     DispensingSupportPharmacyStockLocation.DispensingSupportPharmacyStockID
                                     OrderStatusUpdate.PurchaseOrderID
                                     BagPart.ToteID
                                     OrderStatusUpdateLine.OrderStatusUpdateID
                                     AdvanceShipmentNoticeLine.AdvanceShipmentNoticeID
                                     AdvanceShipmentNoticeLine.PurchaseOrderLineID
                                     OrderStatusUpdateLineOrdered.OrderStatusUpdateLineID
                                     AdvanceShipmentNoticeLineOrdered.AdvanceShipmentNoticeLineID
                                     BagPartItem.BagPartID
                                     OrderStatusUpdateLineSupplied.OrderStatusUpdateLineOrderedID
                                     AdvanceShipmentNoticeLineSupplied.AdvanceShipmentNoticeLineOrderedID
                                     ispensedReconciled.EmergencyDispensedItemID
                                     DispensedReconciled.ReconcilingDispensedItemID
                                      HandlingUnitItem.HandlingUnitID       columns changed to null
26-May-2022  : Anisoor Rahman           : The following columns nullability have been updated from NOT NULL to NULL:
                                        PatientAdverseReaction.PatientPartyRoleID
                                        PatientAdverseReaction.AdverseReactionID
                                        PatientCommunityMembership.PatientCommunityID
                                        PatientMedicalCondition.PatientPartyRoleID
                                        PatientMedicalCondition.MedicalConditionID
                                        PatientPreference.PatientPartyRoleID
                                        PharmacyProductBarCode.ActualProductPackID
                                        PharmacyProductLogistics.ActualProductPackID
                                        PharmacyService.PrescriptionFormID
                                        PreferredActualProductPack.ActualProductPackID
                                        PreferredActualProductPack.PharmacyProductSKUID
                                        PrescriberPractice.PrescriberID
                                        PrescriberPractice.PracticeID
                                        PrescriptionFormNote.PrescriptionFormID
                                        PrescriptionItemInformation.BagPartID
                                        PrescriptionItemInformation.DispensedItemID
                                        PrescriptionOrderItem.PrescriptionOrderID
                                        PrescriptionOrderItem.PrescribedItemID
                                        PrescriptionSiteInformation.PrescriptionGroupID
                                        TradeSellingPrice.ActualProductPackID
31-May-2022  : Anisoor Rahman          :Supplier.SupplierPartyRoleID
                                        Prescriber.PrescriberPartyRoleID
                                       Prescriber.PharmacyStoreSiteRoleId
                                       Prescriber.PrescriberTypeID
                                       CentralOffice.CentralOfficeSiteRoleID updated as nullable columns
14-June-2022  : Afifa Azad              : added SourceSystemID column to OrderUpdateNotification
15-June-2022  : Anisoor Rahman          : added SourceSystemID column to PrescriptionExemption
                                      

**************************************************************************************************************************
*/ 

--MedicalCondition

CREATE TABLE ser_pharmaceuticals.MedicalCondition
(
MedicalConditionSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CDSCode VARCHAR(50),
MedicalConditionContext VARCHAR(50),
MedicalConditionDescription VARCHAR(255),
MedicalConditionStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);


--Exemption

CREATE TABLE ser_pharmaceuticals.Exemption
(
ExemptionSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
IsAgeExemptionIndicator NUMERIC(1),
ExemptionDescription VARCHAR(255),
MaxAge NUMERIC(12),
MinAge NUMERIC(12),
IsEligibleCMSIndicator NUMERIC(1),
IsEligibleMASIndicator NUMERIC(1),
DisplaySequence NUMERIC(19),
IsMandatoryAgeExemptionIndicator NUMERIC(1),
MessageHandlingSystemCode VARCHAR(50),
IsExpiryDateRequiredIndicator NUMERIC(1),
IsEvidenceSeenIndicator NUMERIC(1),
IsNorthWestOstomySuppliesEligibleIndicator NUMERIC(1),
IsSelectableIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--AdverseReaction

CREATE TABLE ser_pharmaceuticals.AdverseReaction
(
AdverseReactionSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CDSCode VARCHAR(50),
AdverseReactionContext VARCHAR(50),
AdverseReactionStatus VARCHAR(50),
AdverseReactionType VARCHAR(50),
AdverseReactionDescription VARCHAR(3000),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DosageUnit

CREATE TABLE ser_pharmaceuticals.DosageUnit
(
DosageUnitSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
DosageUnitDescription VARCHAR(255),
DisplaySequence NUMERIC(12),
LabelDescription VARCHAR(255),
CommonDrugServiceCode VARCHAR(50),
DosageUnitStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);



--LabelInstruction

CREATE TABLE ser_pharmaceuticals.LabelInstruction
(
LabelInstructionSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
LabelInstructionStatus VARCHAR(50),
LabelInstructionSubType VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriberType

CREATE TABLE ser_pharmaceuticals.PrescriberType
(
PrescriberTypeSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
PrescriberTypeAbbreviateDescription VARCHAR(255),
PrescriberTypeDescription VARCHAR(255),
PrescriberTypeSequence NUMERIC(12),
PrescriberStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Supplier

CREATE TABLE ser_pharmaceuticals.Supplier
(
SupplierPartyRoleID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
SupplierName VARCHAR(80),
SupplierStatus VARCHAR(255),
IsThirdPartyIndicator VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--LevyFee

CREATE TABLE ser_pharmaceuticals.LevyFee
(
LevyFeeSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
LevyFeeAmount NUMERIC(24,4),
LevyFeeISOCode VARCHAR(3),
StartDate DATETIME2,
EndDate DATETIME2,
Region VARCHAR(50),
LevyFeeStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Formulary

CREATE TABLE ser_pharmaceuticals.Formulary
(
FormularySKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
FormularyName VARCHAR(255),
FormularyStatus VARCHAR(50),
IsWhiteListIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionService

CREATE TABLE ser_pharmaceuticals.PrescriptionService
(
PrescriptionServiceSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
PrescriptionServiceType VARCHAR(50),
PrescriptionServiceDescription VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--StockResponse

CREATE TABLE ser_pharmaceuticals.StockResponse
(
StockResponseSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
PSTMessage VARCHAR(255),
StockEnquiryMessage VARCHAR(255),
StockUserMessage VARCHAR(255),
StockFlag VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--InterStoreTransferListSKUExcluded

CREATE TABLE ser_pharmaceuticals.InterStoreTransferListSKUExcluded
(
InterStoreTransferListSKUSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(50) NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Grid

CREATE TABLE ser_pharmaceuticals.Grid
(
GridSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19),
GridName VARCHAR(255),
GridDescription VARCHAR(255),
IsGlobalIndicator NUMERIC(1),
GridComment VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridDate DATETIME2,
GridTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridCellValue

CREATE TABLE ser_pharmaceuticals.GridCellValue
(
GridCellValueSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
---SourceSystemID NUMERIC(19), ---this attribute is not required
DaysStockCoverNumber NUMERIC(15,5),
IsStockCoverIndicator NUMERIC(1),
RangingValue VARCHAR(50),
IsAverageDaysIndicator NUMERIC(1),
AverageDaysNumber NUMERIC(15,5),
MaxDaily VARCHAR(50),
OccurencesNumber NUMERIC(12),
IsStockedIndicator NUMERIC(1),
IsUpliftIndicator NUMERIC(1),
GridType VARCHAR(20),
MinLevelSetting VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridCellValueDate DATETIME2,
GridCellValueTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--ManualOrderReason

CREATE TABLE ser_pharmaceuticals.ManualOrderReason
(
ManualOrderReasonSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CreationTime DATETIME2,
ReasonLOVID	NUMERIC(19),
UpdateTime DATETIME2,
UserName VARCHAR(50),
ClosedTime DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--OrderType

CREATE TABLE ser_pharmaceuticals.OrderType
(
OrderTypeSKID NUMERIC(19) NOT NULL,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
OrderListTypeLOVId	NUMERIC(19),
OrderTypePriority NUMERIC(12),
OrderTypePrefix VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GlobalCodeAndParameterElement

CREATE TABLE ser_pharmaceuticals.GlobalCodeAndParameterElement
(
GlobalCodeAndParameterElementSKID NUMERIC(19) NOT NULL,
SourceKey NUMERIC(19),
MetadataSourceKey NUMERIC(19),
GlobalCodeAndParameterElementCategory VARCHAR(255),
GlobalCodeAndParameterElementComment VARCHAR(500),
CustomizationKey VARCHAR(255),
FullReference VARCHAR(500),
OrderElement NUMERIC(10),
SubCategory VARCHAR(255),
GlobalCodeAndParameterElementParentID NUMERIC(19),
LogicalName VARCHAR(255),
DefaultLabel VARCHAR(200),
DefaultValue VARCHAR(255),
GlobalCodeAndParameterElementDescription VARCHAR(1000),
MinValue VARCHAR(255),
MaxValue VARCHAR(255),
IsMandatoryIndicator NUMERIC(1),
IsListIndicator NUMERIC(1),
IsAllowAddIndicator NUMERIC(1),
IsEnumerationIndicator NUMERIC(1),
IsAllowDeleteIndicator NUMERIC(1),
EnumValueReference VARCHAR(500),
ValidityStartDate DATE,
ValidityEndDate DATE,
StartRelease NUMERIC(20),
EndRelease NUMERIC(20),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Formulation

CREATE TABLE ser_pharmaceuticals.Formulation
(
FormulationSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
SourceKey VARCHAR(80) NOT NULL,
AbbreviateDescription VARCHAR(255),
FormulationContext VARCHAR(50),
FormulationDescription VARCHAR(255),
FormulationSequence NUMERIC(12),
FormulationStatus VARCHAR(50),
StoreCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PackQualifier

CREATE TABLE ser_pharmaceuticals.PackQualifier
(
PackQualifierSKID NUMERIC(19) NOT NULL,
PharmacyProductSKUID NUMERIC(19),
PharmacyRegionalProductSKUID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
NumberOfCycles NUMERIC(12),
PackType VARCHAR(50),
PackQualifierStatus VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PharmacyUncataloguedProduct

CREATE TABLE ser_pharmaceuticals.PharmacyUncataloguedProduct
(
UncataloguedProductSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId NUMERIC,
FormulationID NUMERIC(19),
DosageUnitID NUMERIC(20),
SourceKey VARCHAR(80) NOT NULL,
AdditionalNote VARCHAR(255),
CreationTime DATETIME2,
UncataloguedProductDescription VARCHAR(255),
EndorsementDetail VARCHAR(50),
ItemName VARCHAR(255),
LegalClassification VARCHAR(50),
NormalizedName VARCHAR(255),
UncataloguedProductStatus VARCHAR(50),
StoreCode VARCHAR(50),
Strength VARCHAR(255),
UncataloguedProductType VARCHAR(50),
DosageUnitCode VARCHAR(50),
FormulationCode VARCHAR(50),
IsControlledDrugIndicator NUMERIC(1),
PackQuantity VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PatientPreference

CREATE TABLE ser_pharmaceuticals.PatientPreference
(
PatientPreferenceSKID NUMERIC(19) NOT NULL,
PatientPartyRoleID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
IsDeliveryRequiredIndicator NUMERIC(1),
IsMARChartRequiredIndicator NUMERIC(1),
RepeatServicePreference VARCHAR(50),
IsTXTConsentIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Prescriber

CREATE TABLE ser_pharmaceuticals.Prescriber
(
PrescriberPartyRoleID BIGINT ,
PharmacyStoreSiteRoleId BIGINT,
PrescriberTypeID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
PrescriberContext VARCHAR(50),
PrescriberFirstName NVARCHAR(255),   --changed from VARCHAR to NVARCHAR
PrescriberFullName NVARCHAR(255),    --changed from VARCHAR to NVARCHAR
MedicalCouncilCode VARCHAR(50),
NationalCode VARCHAR(50),
NormalizedName NVARCHAR(255),        --changed from VARCHAR to NVARCHAR
PrescriberPrivateControlledDrugCode VARCHAR(50),
ReimbursementCode VARCHAR(50),
PrescriberStatus VARCHAR(50),
StoreCode VARCHAR(50),
PrescriberSurname NVARCHAR(255),  --changed from VARCHAR to NVARCHAR
PrescriberTitle VARCHAR(50),
GMCCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Practice

CREATE TABLE ser_pharmaceuticals.Practice
(
PracticeSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
PracticeContext VARCHAR(50),
PracticeFullname VARCHAR(255),
NationalCode VARCHAR(50),
PostalCode VARCHAR(50),
PracticeName VARCHAR(255),
PracticeStatus VARCHAR(50),
StoreCode VARCHAR(50),
PracticeType VARCHAR(50),
DueBackDays NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PatientCommunity

CREATE TABLE ser_pharmaceuticals.PatientCommunity
(
PatientCommunitySKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleID BIGINT,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
IsCareServicePreferenceIndicator NUMERIC(1),
PatientCommunityName VARCHAR(255),
PatientCommunityType VARCHAR(50),
CreationTime DATE,
IsEMARStatusIndicator NUMERIC(1),
GoLiveDate DATE,
SendingEMARTime DATETIME2,
PatientCommunityStatus VARCHAR(50),
StoreCode VARCHAR(50),
UpdateTime DATE,
UserInitials VARCHAR(255),
IsLandscapeFormatIndicator NUMERIC(1),
SourceCommunityID VARCHAR(50),
EMARServiceProvider VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
SCDStartDate DATETIME2,
SCDEndDate DATETIME2,
SCDActiveFlag VARCHAR(1),
SCDVersion INT,
SCDLOVRecordSourceID INT,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PatientAdverseReaction

CREATE TABLE ser_pharmaceuticals.PatientAdverseReaction
(
PatientAdverseReactionSKID NUMERIC(19) NOT NULL,
PatientPartyRoleID BIGINT ,
AdverseReactionID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
AdverseReactionDate DATETIME2,
PatientAdverseReactionCode VARCHAR(50),
PatientAdverseReactionUserCode VARCHAR(50),
LegacyAdverseReactionCode VARCHAR(50),
PatientAdverseReactionNote NVARCHAR(4000),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PatientMedicalCondition

CREATE TABLE ser_pharmaceuticals.PatientMedicalCondition
(
PatientMedicalConditionSKID NUMERIC(19) NOT NULL,
PatientPartyRoleID BIGINT ,
MedicalConditionID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
PatientMedicalConditionCode VARCHAR(50),
PatientMedicalConditionNoteDate DATETIME2,
PatientMedicalConditionNotes VARCHAR(255),
PatientMedicalConditionUserCode VARCHAR(50),
LegacyMedicalConditionCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--FormularyProduct

CREATE TABLE ser_pharmaceuticals.FormularyProduct
(
FormularyProductSKID NUMERIC(19) NOT NULL,
PharmacyProductID NUMERIC(19) ,  --changed to null
FormularyID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
FormularyCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--ProductLabelInstruction

CREATE TABLE ser_pharmaceuticals.ProductLabelInstruction
(
ProductLabelInstructionSKID NUMERIC(19) NOT NULL,
PharmacyProductID NUMERIC(19),
LabelInstructionID NUMERIC(19),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PurchaseOrderGroup

CREATE TABLE ser_pharmaceuticals.PurchaseOrderGroup
(
PurchaseOrderGroupSKID NUMERIC(19) NOT NULL,
OrderTypeID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
OrderGroupQuantity NUMERIC(12),
PurchaseOrderGroupStatus VARCHAR(50),
OrderTypeCode VARCHAR(50),
ProcessingTime DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CentralOffice

CREATE TABLE ser_pharmaceuticals.CentralOffice
(
CentralOfficeSiteRoleID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
TerminalCode VARCHAR(50),
CentralOfficeStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Tote

CREATE TABLE ser_pharmaceuticals.Tote
(
ToteSKID NUMERIC(19) NOT NULL,
ServiceCentreSiteRoleID BIGINT,
SourceKey VARCHAR(80) NOT NULL,
ToteCode VARCHAR(50),
PhysicalTote VARCHAR(50),
SheetNumber NUMERIC(12),
ToteCreationDate DATE,
ToteType VARCHAR(50),
IsLogicalToteIndicator NUMERIC(1),
Priority VARCHAR(50),
ServiceCentreWholesalerCode VARCHAR(50),
OrderCreationDate DATETIME2,
TotalAdvanceShipmentNoticeExpected NUMERIC(12),
TotalAdvanceShipmentNoticeReceived NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridAxis

CREATE TABLE ser_pharmaceuticals.GridAxis
(
GridAxisSKID NUMERIC(19) NOT NULL,
GridID NUMERIC(19) ,  --changed to null
SourceKey VARCHAR(80) NOT NULL,
GridAxisType VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridAxisDate DATETIME2,
GridAxisTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridLayer

CREATE TABLE ser_pharmaceuticals.GridLayer
(
GridLayerSKID NUMERIC(19) NOT NULL,
GridID NUMERIC(19) ,  --changed to null
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
GridType VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridLayerDate DATETIME2,
GridLayerTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridStore

CREATE TABLE ser_pharmaceuticals.GridStore
(
GridStoreSKID NUMERIC(19) NOT NULL,
GridID NUMERIC(19),
PharmacyStoreSiteRoleId BIGINT ,     --changed to nullable column
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL, 
GridCode VARCHAR(50),
StoreCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridStoreDate DATETIME2,
GridStoreTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GlobalCodeAndParameterElementValue

CREATE TABLE ser_pharmaceuticals.GlobalCodeAndParameterElementValue
(
GlobalCodeAndParameterElementValueSKID NUMERIC(19) NOT NULL,
GlobalCodeAndParameterElementID NUMERIC(19) , --changed to null
ElementValueType VARCHAR(50) NOT NULL,
AttributeValue VARCHAR(255),
AttributeName VARCHAR(255) NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GlobalCodeAndParameterElementRelation

CREATE TABLE ser_pharmaceuticals.GlobalCodeAndParameterElementRelation
(
GlobalCodeAndParameterElementRelationSKID NUMERIC(19) NOT NULL,
GlobalCodeAndParameterElementParentID NUMERIC(19) NOT NULL,
GlobalCodeAndParameterElementChildID NUMERIC(19) NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--UnsuppliedPurchaseOrderLine

CREATE TABLE ser_pharmaceuticals.UnsuppliedPurchaseOrderLine
(
UnsuppliedPurchaseOrderLineSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
PharmacyProductSKUID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
IsUrgentIndicator NUMERIC(1),
StoreCode VARCHAR(50),
ProductSKUCode VARCHAR(50),
UnsuppliedPOLStatus VARCHAR(50),
CreationTime DATETIME2,
ProcessingTime DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--StockSupplyRequest

CREATE TABLE ser_pharmaceuticals.StockSupplyRequest
(
StockSuppyRequestSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleID BIGINT,
PharmacyProductID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
StockSupplyRequestStatus VARCHAR(50),
StoreCode VARCHAR(255),
OperationType VARCHAR(255),
ProcessingTime DATETIME2,
ProductCode VARCHAR(255),
CreationTime DATETIME2,
IsRecoveredIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GoodsReceipt

CREATE TABLE ser_pharmaceuticals.GoodsReceipt
(
GoodsReceiptSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CreationTime DATETIME2,
DeliveryReference VARCHAR(50),
GoodsReceiptStatus VARCHAR(50),
SupplierType VARCHAR(50),
WorkType VARCHAR(50),
StoreCode VARCHAR(50),
ReceivedTime DATETIME2,
DeliveryDate DATE,
DeliveryWarehouse VARCHAR(255),
ServiceEntryMode VARCHAR(255),
ServiceType VARCHAR(255),
IsTelesaleOrderIndicator NUMERIC(1),
DeliverySlot NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PharmacyProductBarCode

CREATE TABLE ser_pharmaceuticals.PharmacyProductBarCode
(
ProductBarcodeSKID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
Barcode VARCHAR(50),
ProductBarcodeStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--TradeSellingPrice

CREATE TABLE ser_pharmaceuticals.TradeSellingPrice
(
TradeSellingPriceSKID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
StartDate DATE,
EndDate DATE,
PriceAmount NUMERIC(24,4),
PriceISOCode VARCHAR(3),
PriceScheme VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PreferredActualProductPack

CREATE TABLE ser_pharmaceuticals.PreferredActualProductPack
(
PreferredAppSKID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19) ,
PharmacyProductSKUID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
StartDate DATE,
EndDate DATE,
Region VARCHAR(50),
PreferredType VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PharmacyProductLogistics

CREATE TABLE ser_pharmaceuticals.PharmacyProductLogistics
(
PharmacyProductLogisticsSKID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19) ,
ServiceCentreSiteRoleID BIGINT,
SourceKey VARCHAR(80) NOT NULL,
AutomationStatus VARCHAR(50),
ServiceCentreCode VARCHAR(50),
SourceType VARCHAR(50),
IsCentralisableDSPIndicator NUMERIC(1),
IsCentralisableStopSplitPackIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PatientCommunityMembership

CREATE TABLE ser_pharmaceuticals.PatientCommunityMembership
(
PatientCommunityMembershipSKID NUMERIC(19) NOT NULL,
PatientCommunityID NUMERIC(19) ,
PatientPartyRoleID BIGINT,
SourceKey VARCHAR(80) NOT NULL,
CreationTime DATETIME2,
PatientCode VARCHAR(50),
PatientCommunityCode VARCHAR(50),
PatientCommunityMembershipPosition VARCHAR(255),
PatientCommunityMembershipStatus VARCHAR(50),
UpdateTime DATETIME2,
OldPatientCode VARCHAR(50),
ChildCareHomeCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
SCDStartDate DATETIME2,
SCDEndDate DATETIME2,
SCDActiveFlag VARCHAR(1),
SCDVersion INT,
SCDLOVRecordSourceID INT,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriberPractice

CREATE TABLE ser_pharmaceuticals.PrescriberPractice
(
PrescriberPracticeSKID NUMERIC(19) NOT NULL,
PrescriberID NUMERIC(19) ,
PracticeID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
IsDefaultPracticeIndicator NUMERic(1),
StartDate DATE,
EndDate DATE,
PrescriberPracticeStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--MedicinesUseReviewForm

CREATE TABLE ser_pharmaceuticals.MedicinesUseReviewForm
(
MedicinesUseReviewFormSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
PatientPartyRoleID BIGINT,
PrescriberPartyRoleID BIGINT,
PracticeID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
IsCompiledInStoreIndicator NUMERIC(1),
IsCompiledWithPatientIndicator NUMERIC(1),
CreationTime DATETIME2,
MedicinesUseReviewFormIdentifier VARCHAR(50),
MedicinesUseReviewFormType VARCHAR(50),
PatientCode VARCHAR(50),
IsPCOPermissionIndicator NUMERIC(1),
PharmacistCode VARCHAR(50),
PharmacyContractorNumber VARCHAR(50),
PracticeCode VARCHAR(50),
PrescriberCode VARCHAR(50),
PresentRole VARCHAR(255),
ReasonNotInStore VARCHAR(500),
ReasonNotWithPatient VARCHAR(500),
ReferenceNumber VARCHAR(50),
ReviewDate DATE,
ReviewLocation VARCHAR(255),
MedicinesUseReviewFormStatus VARCHAR(50),
StoreCode VARCHAR(50),
StoreEmail VARCHAR(255),
UpdateTime DATETIME2,
IsWrittenConsentIndicator NUMERIC(1),
RegionalReviewType VARCHAR(50),
MedicinesUseReviewFormIdentifierNote VARCHAR(255),
IsAdviceLivingIndicator NUMERIC(1),
OldPatientCode VARCHAR(50),
Ethnicity VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--StockAvailability

CREATE TABLE ser_pharmaceuticals.StockAvailability
(
StockAvailabiltySKID NUMERIC(19) NOT NULL,   --dropped ActualProductPackID NUMERIC(19)
SourceKey VARCHAR(80) NOT NULL,
NextDeliveryToWarehouse DATE,
OverrideMessage VARCHAR(255),
PIPCode VARCHAR(50),
RAGStatus VARCHAR(50),
StockFlag VARCHAR(50),
WarehouseCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DispensingSupportPharmacyStock

CREATE TABLE ser_pharmaceuticals.DispensingSupportPharmacyStock
(
DispensingSupportPharmacyStockID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
PIPCode VARCHAR(50),
DispensingSupportPharmacyCode VARCHAR(50),
Location VARCHAR(50),
UpdateTime DATETIME2,
LastOrderDate DATETIME2,
LeftoverQuantity NUMERIC(12),
CarryOverQuantity NUMERIC(12),
AllocatedQuantity NUMERIC(12),
SafetyQuantity NUMERIC(15,5),
LastCountedTime DATETIME2,
ExceptionTime DATETIME2,
LastConsumptionDate DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DispensingSupportPharmacyStockMovement

CREATE TABLE ser_pharmaceuticals.DispensingSupportPharmacyStockMovement
(
DispensingSupportPharmacyStockMovementID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
LeftoverQuantityBefore NUMERIC(12),
LeftoverQuantityAfter NUMERIC(12),
CarryOverQuantityBefore NUMERIC(12),
CarryOverQuantityAfter NUMERIC(12),
AllocatedQuantityBefore NUMERIC(12),
AllocatedQuantityAfter NUMERIC(12),
CreationTime DATETIME2,
TransactionID VARCHAR(255),
OperationType VARCHAR(50),
OperationID VARCHAR(50),
PIPCode VARCHAR(50),
DispensingSupportPharmacyCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DispensingSupportPharmacyStockOperation

CREATE TABLE ser_pharmaceuticals.DispensingSupportPharmacyStockOperation
(
DispensingSupportPharmacyStockOperationID NUMERIC(19) NOT NULL,
ActualProductPackID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
CreationTime DATETIME2,
UserCode VARCHAR(50),
UpdateTime DATETIME2,
DispensingSupportPharmacyStockOperationStatus VARCHAR(50),
DispensingSupportPharmacyCode VARCHAR(50),
PIPCode VARCHAR(50),
DispensingSupportPharmacyStockOperationType VARCHAR(50),
Quantity NUMERIC(12),
LocationCode VARCHAR(50),
OperationalTime DATETIME2,
EntryType VARCHAR(50),
SourceType VARCHAR(50),
ReasonDescription VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridAxisThreshold

CREATE TABLE ser_pharmaceuticals.GridAxisThreshold
(
GridAxisThresholdSKID NUMERIC(19) NOT NULL,
GridAxisID NUMERIC(19) ,  --changed to null
SourceKey VARCHAR(80) NOT NULL,
GridAxisValue NUMERIC(22),
SequenceNumber NUMERIC(22),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridAxisThresholdDate DATETIME2,
GridAxisThresholdTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridCell

CREATE TABLE ser_pharmaceuticals.GridCell
(
GridCellSKID NUMERIC(19) NOT NULL,
GridLayerID NUMERIC(19) ,  --changed to null
GridCellValueID NUMERIC(19) , --changed to null
SourceKey VARCHAR(80) NOT NULL,
GridCellPositionX NUMERIC(12),
GridCellPositionY NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
LOVRecordSourceID INT NOT NULL,
GridCellDate DATETIME2,
GridCellTimestamp DATETIME2,
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
ActiveFlag VARCHAR(1),
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--HandlingUnit

CREATE TABLE ser_pharmaceuticals.HandlingUnit
(
HandlingUnitSKID NUMERIC(19) NOT NULL,
GoodsReceiptID VARCHAR(50) , --changed to null
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CreationTime DATETIME2,	
HandlingUnitStatus VARCHAR(50),
IsScannedIndicator NUMERIC(1),
ToteBarcode	VARCHAR(50),
RunDateTime	DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DispensingSupportPharmacyStockLocation

CREATE TABLE ser_pharmaceuticals.DispensingSupportPharmacyStockLocation
(
DispensingSupportPharmacyStockLocationID NUMERIC(19) NOT NULL,
DispensingSupportPharmacyStockID NUMERIC(19) , --changed to null
ActualProductPackID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
LocationCode VARCHAR(50),
PIPCode VARCHAR(50),
DispensingSupportPharmacyCode VARCHAR(50),
UpdateTime DATETIME2,
CreationTime DATETIME2,
SourceCreationTime DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionOrder

CREATE TABLE ser_pharmaceuticals.PrescriptionOrder
(
PrescriptionOrderSKID NUMERIC(19) NOT NULL,
PrescriptionGroupID NUMERIC(19),
PharmacyStoreSiteRoleId BIGINT,
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
PrescriptionGroupCode VARCHAR(255),
StoreCode VARCHAR(255),
PrescriptionOrderStatus VARCHAR(255),
CreationTime DATETIME2,
UpdateTime DATETIME2,
PrescriptionOrderType VARCHAR(255),
IsActiveOrderIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--ElectronicPharmacistsInformationFormLabel

CREATE TABLE ser_pharmaceuticals.ElectronicPharmacistsInformationFormLabel
(
ElectronicPharmacistsInformationFormLabelSKID NUMERIC(19) NOT NULL,
PrescriptionGroupID NUMERIC(19),
PharmacyStoreSiteRoleId BIGINT,
SourceKey VARCHAR(80) NOT NULL,
PrescriptionGroupCode VARCHAR(50),
StoreCode VARCHAR(50),
[Label] VARCHAR(255),--- introduced third bracket as Label is a keyword
CreationTime DATETIME2,
UpdateTime DATETIME2,
IsNewMedicineServiceVerifiedIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DispensingQueueItem

CREATE TABLE ser_pharmaceuticals.DispensingQueueItem
(
DispensingQueueItemSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
PrescriptionGroupID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
StoreCode VARCHAR(50),
CreationDate DATETIME2,
CreationTime DATETIME2,
DispensingQueueItemType VARCHAR(255),
TaskGroupReference VARCHAR(50),
DispensingQueueItemStatus VARCHAR(255),
BusinessStatus VARCHAR(255),
EntityType VARCHAR(255),
SourceEntry VARCHAR(255),
LinkedEntry VARCHAR(255),
NumberOfItem NUMERIC(12),
EstimatedTime DATETIME2,
CompletionTime DATETIME2,
IsCompletedInTimeIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--OrderStatusUpdate

CREATE TABLE ser_pharmaceuticals.OrderStatusUpdate
(
OrderStatusUpdateSKID NUMERIC(19) NOT NULL,
PurchaseOrderID NUMERIC(19) , --changed to null
PharmacyStoreSiteRoleID BIGINT,
SourceKey VARCHAR(80) NOT NULL,
OrderStatusUpdateCode VARCHAR(50),
CreationTime DATETIME2,
DeliveryDate DATE,
DeliveryReference VARCHAR(50),
DeliveryRoute VARCHAR(50),
DeliveryShift VARCHAR(50),
DeliveryWarehouse VARCHAR(50),
PurchaseOrderCode VARCHAR(50),
SendingTime DATETIME2,
SupplierType VARCHAR(50),
OrderStatusUpdateType VARCHAR(50),
StoreCode VARCHAR(50),
ServiceEntryMode VARCHAR(50),
DispatchTime DATETIME2,
CustomerWholesalerCode VARCHAR(50),
OrderSource VARCHAR(50),
OrderWholesalerCode VARCHAR(50),
OrderWholesalerCreationTime DATETIME2,
SOCOrderCode VARCHAR(50),
SOCOrderCreationTime DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionSiteInformation

CREATE TABLE ser_pharmaceuticals.PrescriptionSiteInformation
(
PrescriptionSiteInformationSKID NUMERIC NOT NULL,
PrescriptionGroupID NUMERIC ,
PharmacyStoreSiteRoleID BIGINT,
SourceKey VARCHAR(80) NOT NULL,
AccountNumber VARCHAR(255),
AddressLine1 VARCHAR(255),
AddressLine2 VARCHAR(255),
AddressLine3 VARCHAR(255),
AddressLine4 VARCHAR(255),
AddressLine5 VARCHAR(255),
SiteCode VARCHAR(255),
PostalCode VARCHAR(255),
SiteName VARCHAR(255),
TelephoneNumber VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--AdvanceShipmentNotice

CREATE TABLE ser_pharmaceuticals.AdvanceShipmentNotice
(
AdvanceShipmentNoticeSKID NUMERIC(19) NOT NULL,
PurchaseOrderGroupID NUMERIC(19),
PurchaseOrderID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CreationTime DATETIME2,
CustomerCode VARCHAR(50),
AdvanceShipmentNoticeType VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Bag

CREATE TABLE ser_pharmaceuticals.Bag
(
BagSKID NUMERIC(19) NOT NULL,
PrescriptionGroupID NUMERIC(19),
PatientPartyRoleID BIGINT,
PharmacyStoreSiteRoleId BIGINT,
ToteID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
PrescriptionGroupCode VARCHAR(50),
PatientCode VARCHAR(50),
StoreCode VARCHAR(50),
ToteCode VARCHAR(50),
BagStatus VARCHAR(50),
CreationTime DATETIME2,
UpdateTime DATETIME2,
BagSource VARCHAR(50) NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--BagPart

CREATE TABLE ser_pharmaceuticals.BagPart
(
BagPartSKID NUMERIC(19) NOT NULL,
PrescriptionGroupID NUMERIC(19),
PatientPartyRoleID BIGINT,
PharmacyStoreSiteRoleId NUMERIC(19),
ToteID NUMERIC(19) ,    --changed to null
SourceKey VARCHAR(80) NOT NULL,
LegacyStoreCode VARCHAR(50),
PatientCode VARCHAR(50),
PrescriptionGroupCode VARCHAR(50),
PrescriptionGroupCreationDate DATETIME2,
SourceGroupID VARCHAR(50),
SourcePatientID VARCHAR(50),
StoreCode VARCHAR(50),
WholeSalerCode VARCHAR(50),
BagPartStatus VARCHAR(50),
ExpectedQuantity NUMERIC(15,5),
ReceivedQuantity NUMERIC(15,5),
IsCPCReceivedIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionFormNote

CREATE TABLE ser_pharmaceuticals.PrescriptionFormNote
(
PrescriptionFormNoteSKID NUMERIC(19) NOT NULL,
PrescriptionFormID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
CreationDate DATETIME2,
Note VARCHAR(300),
PriceAmount NUMERIC(24,4),
PriceISOCode VARCHAR(3),
PrescriptionFormNoteStatus VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--OrderStatusUpdateLine

CREATE TABLE ser_pharmaceuticals.OrderStatusUpdateLine
(
OrderStatusUpdateLineSKID NUMERIC(19) NOT NULL,
OrderStatusUpdateID NUMERIC(19),  --changed to null
PurchaseOrderLineID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
LineNumber NUMERIC(12),
DeliveryDate DATE,
DeliveryRoute VARCHAR(50),
DeliveryShift VARCHAR(50),
DeliveryReference VARCHAR(50),
DeliveryWarehouse VARCHAR(50),
SupplierType VARCHAR(50),
OrderStatusUpdateLineType VARCHAR(50),
DispatchTime DATETIME2,
NotSuppliedQuantity NUMERIC(15,5),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--AdvanceShipmentNoticeLine

CREATE TABLE ser_pharmaceuticals.AdvanceShipmentNoticeLine
(
AdvanceShipmentNoticeLineSKID NUMERIC(19) NOT NULL,
AdvanceShipmentNoticeID NUMERIC(19), --changed to null
PurchaseOrderLineID NUMERIC(19) , --changed to null
SourceKey VARCHAR(80) NOT NULL,
LineNumber NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--BagLocation

CREATE TABLE ser_pharmaceuticals.BagLocation
(
BagLocationSKID NUMERIC(19) NOT NULL,
BagID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
LocationCode VARCHAR(50),
PrescriptionGroupCode VARCHAR(50),
StoreCode VARCHAR(50),
PatientCode VARCHAR(50),
BagCode VARCHAR(50),
BagLocationStatus VARCHAR(255),
CreationTime DATETIME2,
UpdateTime DATETIME2,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);
--ClinicalCheck
CREATE TABLE ser_pharmaceuticals.ClinicalCheck(
    ClinicalCheckSKID          numeric(19, 0)    NOT NULL ,
    PrescriptionGroupID        numeric(19, 0)    NULL,
    PharmacyStoreSiteRoleID    bigint            NULL,
    SourceKey                  numeric(19, 0)    NOT NULL,
    ClinicalCheckType          varchar(50)       NULL,
    UserName VARCHAR(255) NULL,
    CheckMode                  varchar(50)       NULL,
    CheckDate                  datetime2     NULL,
    ClinicalCheckStatus        varchar(50)       NULL,
    PharmacistGPHC             varchar(255)      NULL,
    PharmacistName             varchar(255)      NULL,
    CreationTime               datetime2      NULL,
    RunDateTime                datetime2      NULL,
    Year                       varchar(4)        NULL,
    Month                      varchar(2)        NULL,
    Day                        varchar(2)        NULL,
    RecordStatusFlag           char(1)           NULL,
    CreatedTime                datetime2      NULL,
    UpdatedTime                datetime2      NULL,
    LOVRecordSourceID          int               NOT NULL,
    ETLRunLogID                int               NULL
)

WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);
--ClinicalCheckDuration
CREATE TABLE ser_pharmaceuticals.ClinicalCheckDuration(
    ClinicalCheckDurationSKID    numeric(19, 0)    NOT NULL ,
    ClinicalCheckID              numeric(19, 0)    NULL,
    PatientPartyRoleID           bigint            NULL,
    SourceKey                    numeric(19, 0)       NOT NULL,
    StartValidityDate            datetime2      NULL,
    EndValidityDate              datetime2      NULL,
    IsActiveIndicator            numeric(1, 0)     NULL,
    CreationTime                 datetime2      NULL,
    UpdateTime                   datetime2      NULL,
    DeactivationReason           varchar(255)      NULL,
    RunDateTime                  datetime2      NULL,
    Year                         varchar(4)        NULL,
    Month                        varchar(2)        NULL,
    Day                          varchar(2)        NULL,
    RecordStatusFlag             char(1)           NULL,
    CreatedTime                  datetime2      NULL,
    UpdatedTime                  datetime2      NULL,
    LOVRecordSourceID            int               NOT NULL,
    ETLRunlogID                  int               NULL
)

WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);
--DispensingSupportPharmacyPrescription
CREATE TABLE ser_pharmaceuticals.DispensingSupportPharmacyPrescription(
    DispensingSupportPharmacyPrescriptionSKID      numeric(19, 0)    NOT NULL,
    PharmacyStoreSiteRoleID                        bigint            NULL,
    PatientPartyRoleID                             bigint            NULL,
    PrescriptionGroupID                            numeric(19, 0)    NULL,
    SourceKey                                      varchar(80)       NOT NULL,
    SourceType                                     varchar(255)      NULL,
    IsExcludedIndicator                            numeric(1, 0)     NULL,
    CreationTime                                   datetime2      NULL,
    UpdateTime                                     datetime2     NULL,
    IsPartialIndicator                             numeric(1, 0)     NULL,
    ProcessingTime                                 datetime2      NULL,
    DeliveryDate                                   datetime2      NULL,
    DispensingSupportPharmacyPrescriptionStatus    varchar(50)       NULL,
    Source                                         varchar(50)       NULL,
    RunDateTime                                    datetime2      NULL,
    Year                                           varchar(4)        NULL,
    Month                                          varchar(2)        NULL,
    Day                                            varchar(2)        NULL,
    RecordStatusFlag                               char(1)           NULL,
    CreatedTime                                    datetime2      NULL,
    UpdatedTime                                    datetime2      NULL,
    LOVRecordSourceID                              int               NOT NULL,
    ETLRunLogID                                    int               NULL
)

WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);
--PrescriptionExemption
CREATE TABLE ser_pharmaceuticals.PrescriptionExemption(
    PrescriptionExemptionSKID    numeric(19, 0)    NOT NULL ,
    PharmacyStoreSiteRoleID      bigint            NULL,
    PatientPartyRoleID           bigint            NULL,
    ExemptionID                numeric(19, 0)    NULL,
    SourceKey                    varchar(255)      NOT NULL,
    SourceSystemID               numeric(19,0)  NOT NULL,
    SourceType                   varchar(50)       NULL,
    IsActiveIndicator            numeric(1, 0)     NULL,
    CreationTime                 datetime2      NULL,
    UpdateTime                   datetime2      NULL,
    RepeatIssueNumber            varchar(255)      NULL,
    TransmissionID               varchar(255)      NULL,
    ResponseType                 varchar(50)       NULL,
    ResponseMessage              nvarchar(4000)    NULL,
    RunDateTime                  datetime2      NULL,
    Year                         varchar(4)        NULL,
    Month                        varchar(2)        NULL,
    Day                          varchar(2)        NULL,
    RecordStatusFlag             char(1)           NULL,
    CreatedTime                  datetime2      NULL,
    UpdatedTime                  datetime2      NULL,
    LOVRecordSourceID            int               NOT NULL,
    ETLRunLogID                  int               NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);
--PharmacyService
CREATE TABLE ser_pharmaceuticals.PharmacyService(
    PharmacyServiceSKID        numeric(19, 0)    NOT NULL,
    PrescriptionFormID         numeric(19, 0)    ,
    PharmacyStoreSiteRoleID    bigint            NULL,
    PatientPartyRoleID         bigint            NULL,
    PrescriberPartyRoleID      bigint            NULL,
    SourceKey                  varchar(255)      NOT NULL,
    PrescriptionFormCode       varchar(50)       NULL,
    StoreCode                  varchar(50)       NULL,
    PatientCode                varchar(50)       NULL,
    ServiceType                varchar(50)       NULL,
    ConsultationType           varchar(50)       NULL,
    PrescriberCode             varchar(50)       NULL,
    PharmacyServiceStatus      varchar(50)       NULL,
    CreationTime               datetime2      NULL,
    UpdateTime                 datetime2      NULL,
    UserCode                   varchar(50)       NULL,
    PharmacyServiceNote        varchar(1000)     NULL,
    TransmissionID             varchar(255)      NULL,
    ClinicalServiceCode       varchar(50)       NULL,
    AtRiskDate                 datetime2      NULL,
    RunDateTime                datetime2      NULL,
    Year                       varchar(4)       NULL,
    Month                      varchar(2)       NULL,
    Day                        varchar(2)       NULL,
    RecordStatusFlag           char(1)           NULL,
    CreatedTime                datetime2      NULL,
    UpdatedTime                datetime2      NULL,
    LOVRecordSourceID          int               NOT NULL,
    ETLRunLogID                int               NULL
)

WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);


--OrderStatusUpdateLineOrdered

CREATE TABLE ser_pharmaceuticals.OrderStatusUpdateLineOrdered
(
OrderStatusUpdateLineOrderedSKID NUMERIC(19) NOT NULL,
OrderStatusUpdateLineID NUMERIC(19),  --changed to null --dropped ActualProductPackID NUMERIC(19)
SourceKey VARCHAR(80) NOT NULL,
PackSize NUMERIC(12),
PIPCode VARCHAR(50),
ProductDescription VARCHAR(255),
Quantity NUMERIC(12),
OrderStatusUpdateLineOrderedCode VARCHAR(50),
SupplyingWarehouse VARCHAR(255),
LineOrderedReference VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--AdvanceShipmentNoticeLineOrdered

CREATE TABLE ser_pharmaceuticals.AdvanceShipmentNoticeLineOrdered
(
AdvanceShipmentNoticeLineorderedSKID NUMERIC(19) NOT NULL,
AdvanceShipmentNoticeLineID NUMERIC(19) ,  --changed to null --dropped ActualProductPackID NUMERIC(19)
SourceKey VARCHAR(80) ,                        --Changed to Nullable
SourceSystemID NUMERIC(19) NOT NULL,
PackSize NUMERIC(12),
PIPCode VARCHAR(50),
Quantity NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--BagPartItem

CREATE TABLE ser_pharmaceuticals.BagPartItem
(
BagPartItemSKID NUMERIC(19) NOT NULL,
BagPartID NUMERIC(19), --changed to null
SuppliedActualProductPackID NUMERIC(19),
OrderedActualProductPackID NUMERIC(19),
PrescribedItemID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
OrderedPack NUMERIC(12),
OrderLineReference VARCHAR(50),
OrderLineType VARCHAR(50),
SheetReferences VARCHAR(50),
SuppliedPack NUMERIC(12),
SuppliedProductCode VARCHAR(50),
ToteReference VARCHAR(50),
OrderedProductCode VARCHAR(50),
BagPartItemStatus VARCHAR(50),
SourcePrescriptionID VARCHAR(50),
OrderedPills NUMERIC(15,5),
SuppliedPills NUMERIC(15,5),
PrescribedProductCode VARCHAR(50),
PrescribedItemCode VARCHAR(50),
LeftOverSuppliedPills NUMERIC(12),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionOrderItem

CREATE TABLE ser_pharmaceuticals.PrescriptionOrderItem
(
PrescriptionOrderItemSKID NUMERIC(19) NOT NULL,
PrescriptionOrderID NUMERIC(19) ,
DispensedItemID NUMERIC(19),
PrescribedItemID NUMERIC(19) ,
SourceKey VARCHAR(80) NOT NULL,
DispensedItemCode VARCHAR(255),
DispensedProduct VARCHAR(255),
NotSuppliedQuantity VARCHAR(50),
PrescribedItemCode VARCHAR(255),
Quantity NUMERIC(12),
PrescriptionOrderItemStatus VARCHAR(255),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--OrderStatusUpdateLineSupplied

CREATE TABLE ser_pharmaceuticals.OrderStatusUpdateLineSupplied
(
OrderStatusUpdateLineSuppliedSKID NUMERIC(19) NOT NULL,
OrderStatusUpdateLineOrderedID NUMERIC(19), --changed to null
HandlingUnitID NUMERIC(19),  --dropped ActualProductPackID NUMERIC(19)
ToteID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
AcceptedQuantity NUMERIC(12),
OrderStatusUpdateLineSuppliedCode VARCHAR(50),
HandlingUnitCode VARCHAR(50),
Messages VARCHAR(255),
NetCostAmount NUMERIC(24,4),
NetCostISOCode VARCHAR(3),
PackSize NUMERIC(12),
PIPCode VARCHAR(50),
ProductDescription NVARCHAR(255) COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
ReasonCode VARCHAR(50),
SuppliedQuantity NUMERIC(12),
ToteCode VARCHAR(50),
VatRateAmount NUMERIC(24,4),
VatRateISOCode VARCHAR(3),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--AdvanceShipmentNoticeLineSupplied

CREATE TABLE ser_pharmaceuticals.AdvanceShipmentNoticeLineSupplied
(
AdvanceShipmentNoticeLineSuppliedSKID NUMERIC(19) NOT NULL,
AdvanceShipmentNoticeLineOrderedID NUMERIC(19) ,  --changed to null
ToteID NUMERIC(19),  --dropped ActualProductPackID NUMERIC(19)
SourceKey VARCHAR(80) NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
AdvanceShipmentNoticeSuppliedNote VARCHAR(255),
NetCostAmount NUMERIC(24,4),
NetCostISOCode VARCHAR(3),
NetCostExcrateID NUMERIC(19),
PackagingInfo VARCHAR(50),
PackSize NUMERIC(12),
PIPCode VARCHAR(50),
Quantity NUMERIC(12),
AdvanceShipmentNoticeLineSuppliedReason VARCHAR(50),
ToteCode VARCHAR(50),
ValueAddedTaxRate NUMERIC(5,2),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--DispensedReconciled

CREATE TABLE ser_pharmaceuticals.DispensedReconciled
(
DispensedReconciledSKID NUMERIC(19) NOT NULL,
EmergencyDispensedItemID NUMERIC(19) , --changed to null
ReconcilingDispensedItemID NUMERIC(19) , --changed to null
PrescriptionFormTypeID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
Quantity NUMERIC(15,5),
FormTypeCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--HandlingUnitItem

CREATE TABLE ser_pharmaceuticals.HandlingUnitItem
(
HandlingUnitItemSKID NUMERIC(19) NOT NULL,
HandlingUnitID NUMERIC(19) ,  --changed to null
PharmacyProductSKUID NUMERIC(19),
OrderStatusUpdateLineSuppliedID NUMERIC(19),
PurchaseOrderLineID NUMERIC(19),  --dropped ActualProductPackID NUMERIC(19)
SourceKey VARCHAR(80) NOT NULL,
ClosingTime DATETIME2,
ExpectedQuantity NUMERIC(12),
LineNumber NUMERIC(12),
OriginalExpectedQuantity NUMERIC(12),
OrderStatusUpdateLineSuppliedCode VARCHAR(50),
DispensingPrescribableProductCode VARCHAR(50),
ReceivedQuantity NUMERIC(12),
CreationTime DATETIME2,
HandlingUnitItemStatus VARCHAR(50),
IsScannedIndicator NUMERIC(1),
IsLapsedIndicator NUMERIC(1),
PurchaseOrderReference VARCHAR(50),
PurchaseOrderLineNumber NUMERIC(12),
PurchaseOrderCreationTime DATETIME2,
ServiceType VARCHAR(50),
IsExternalSourceOrderIndicator NUMERIC(1),
ServiceEntryMode VARCHAR(50),
OldReceivedQuantity NUMERIC(12),
PIPCode VARCHAR(50),
CommonDrugServiceCode VARCHAR(50),
PackSize NUMERIC(15,5),
ProductBarCode VARCHAR(50),
ProductDescription VARCHAR(255),
ProductSKUCode VARCHAR(50),
ReceivingQuantity NUMERIC(12),
IsTelesaleOrderIndicator NUMERIC(1),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--OrderUpdateNotification

CREATE TABLE ser_pharmaceuticals.OrderUpdateNotification
(
OrderUpdateNotificationSKID NUMERIC(19) NOT NULL,
PharmacyStoreSiteRoleId BIGINT,
DispensedItemID NUMERIC(19),
OldDispensedPharmacyProductSKUID NUMERIC(19),
NewDispensedPharmacyProductSKUID NUMERIC(19),
OldDispensedActualProductPackID NUMERIC(19),
NewDispensedActualProductPackID NUMERIC(19),
PrescriptionFormID NUMERIC(19),
SourceKey VARCHAR(255) NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL, --Added to capture Order_Update_Notification.ID
ProcessingTime DATETIME2,
CreationTime DATETIME2,
OldDispensedSKUCode VARCHAR(50),
NewDispensedSKUCode VARCHAR(50),
OldDispensedAppCode VARCHAR(50),
NewDispensedAppCode VARCHAR(50),
PrescriptionFormCode VARCHAR(255),
StoreCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogId INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionItemInformation

CREATE TABLE ser_pharmaceuticals.PrescriptionItemInformation
(
PrescriptionItemInformationSKID NUMERIC(19) NOT NULL,
BagPartID NUMERIC(19) ,
DispensedItemID NUMERIC(19) ,
DispensedProductID NUMERIC(19),
PrescribedProductID NUMERIC(19),
PrescribedItemID NUMERIC(19),
SourceKey VARCHAR(80) NOT NULL,
DispensedProductCode VARCHAR(50),
DispensedProductName VARCHAR(255),
DispensedQuantity NUMERIC(15,5),
DosageDirection VARCHAR(255),
DosageUnit VARCHAR(50),
LineNumber VARCHAR(50),
PackSize NUMERIC(15,5),
PrescribedProductCode VARCHAR(50),
PrescribedProductName VARCHAR(255),
PrescribedQuantity NUMERIC(15,5),
SourcePrescriptionID VARCHAR(50),
BNFWarning NVARCHAR(4000),
PrescribedItemCode VARCHAR(50),
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime  DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID INT NOT NULL,
ETLRunLogID INT
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

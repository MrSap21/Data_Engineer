USE npro-dna-platform-pp-ne-sqlw01;

CREATE SCHEMA test_curate  AUTHORIZATION dbo;
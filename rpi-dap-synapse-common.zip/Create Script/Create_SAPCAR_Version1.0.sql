USE npro-dna-platform-pp-ne-sqlw01;

CREATE TABLE test_curate.TransactionCoupon
(
    CouponKeyedIndicator CHAR(1) NULL,
    CouponRefundIndicator CHAR(1) NULL,
    CouponVoidedIndicator CHAR(1) NULL,
    CouponQuantityEnteredIndicator CHAR(1) NULL,
    LoyaltyUnitsCouponIndicator CHAR(1) NULL,
    CouponPriceOverrideIndicator CHAR(1) NULL,
    TransactionId CHAR(60) NOT NULL,
    CouponId CHAR(60) NOT NULL,
    TransactionCouponDiscountAmount DECIMAL(12,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionCoupon PRIMARY KEY NONCLUSTERED (TransactionId, CouponId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionPromotion
(
    PromotionDescription CHAR(40) NULL,
    TransactionId CHAR(60) NOT NULL,
    PromotionId CHAR(60) NOT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionPromotion PRIMARY KEY NONCLUSTERED (TransactionId, PromotionId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionPayment
(
    TransactionId CHAR(60) NOT NULL,
    PaymentId CHAR(60) NOT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionPayment PRIMARY KEY NONCLUSTERED (TransactionId, PaymentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.LoyaltyAccountEarning
(
    LoyaltyAdditionValidationCode CHAR(8) NULL,
    LoyaltyProgramId INT NOT NULL,
    LoyaltyAccountId INT NOT NULL,
    Timestamp DATETIME NOT NULL,
    EarnedLoyaltyUnits DECIMAL(13,2) NULL,
    LoyaltyEarningTypeId INT NULL,
    TransactionId CHAR(60) NULL,
	LoyaltyCardId CHAR(25) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_LoyaltyAccountEarning PRIMARY KEY NONCLUSTERED (TransactionId, LoyaltyCardId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionAdjustment
(
    BonusBuyIdentifier CHAR(20) NULL,
    RewardAmount DECIMAL(12,2) NULL,
    QualificationRedeemableStatus CHAR(1) NULL,
    QualificationReason CHAR(40) NULL,
    QualificationCount INT NULL,
    QualificationListXIndicator CHAR(1) NULL,
    QualificationListCIndicator CHAR(1) NULL,
    QualificationListBIndicator CHAR(1) NULL,
    QualificationListAIndicator CHAR(1) NULL,
    QualificationExemptStatus CHAR(1) NULL,
    QualificationBrandStatus CHAR(1) NULL,
    QualificationAmount DECIMAL(8,2) NULL,
    ExtraLoyaltyUnitsCount DECIMAL(12,2) NULL,
    DiscountReasonCode CHAR(4) NULL,
    DiscountTypeCode CHAR(4) NULL,
    TransactionNumber CHAR(10) NULL,
    TransactionId CHAR(60) NOT NULL,
    AdjustmentId CHAR(60) NOT NULL,
    AdjustmentAmount DECIMAL(15,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionAdjustment PRIMARY KEY NONCLUSTERED (TransactionId, AdjustmentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionLineItemAdjustment
(
    VATExemptDiscountIndicator CHAR(1) NULL,
    TransactionLineItemNumber CHAR(10) NULL,
    TransactionLevelDiscountIndicator CHAR(1) NULL,
    StaffDiscountOverriddenIndicator CHAR(1) NULL,
    DiscountVoidedIndicator CHAR(1) NULL,
    DiscountTypeCode CHAR(4) NULL,
    DiscountRefundedIndicator CHAR(1) NULL,
    DiscountReasonCode CHAR(4) NULL,
    DiscountPercentage CHAR(3) NULL,
    DiscountOverriddenIndicator CHAR(1) NULL,
    DealLoyaltyRewardUnits DECIMAL(12,2) NULL,
    DealListRedeemableIndicator CHAR(30) NULL,
    DealListExemptItemIndicator CHAR(30) NULL,
    BootsItemDealListId CHAR(30) NULL,
    BonusBuyIdentifier CHAR(20) NULL,
    TransactionId CHAR(60) NOT NULL,
    TransactionLineItemId CHAR(60) NOT NULL,
    AdjustmentId CHAR(60) NOT NULL,
    AdjustmentAmount DECIMAL(13,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionLineItemAdjustment PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId, AdjustmentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionLoyaltyAccount
(
    LoyaltyCardId CHAR(25) NULL,
    LoyaltyCardUsageCount INT NULL,
    LoyaltyAccountBalanceAmount DECIMAL(11,2) NULL,
    TransactionId CHAR(60) NOT NULL,
    LoyaltyProgramId INT NOT NULL,
    LoyaltyAccountId INT NOT NULL,
    LoyaltyUnitsUsed DECIMAL(11,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionLoyaltyAccount PRIMARY KEY NONCLUSTERED (TransactionId, LoyaltyCardId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.GiftCardTransaction
(
    TransactionLineItemId CHAR(60) NULL,
    GiftCardTransactionType CHAR(40) NULL,
    SubsequentSaleIndicator CHAR(40) NULL,
    FirstSaleIndicator CHAR(40) NULL,
    GiftCardTransactionNumber CHAR(13) NULL,
    GiftCardOpeningBalanceAmount DECIMAL(12,2) NULL,
    TransactionId CHAR(60) NOT NULL,
    GiftCardId CHAR(20) NOT NULL,
    Timestamp DATETIME NOT NULL,
    Amount DECIMAL(12,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_GiftCardTransaction PRIMARY KEY NONCLUSTERED (TransactionId, GiftCardId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.Transaction
(
    FinancialMovementTypeCode CHAR(8) NULL,
    OriginalTransactionTime CHAR(4) NULL,
    TransactionDate DATE NULL,
    SourceTransactionNumber CHAR(20) NULL,
    OperatorIndicator CHAR(1) NULL,
    OperatorId CHAR(30) NULL,
    AccountSaleIndicator CHAR(1) NULL,
    AccountSaleAccountNumber CHAR(13) NULL,
    ManagerKeyIndicator CHAR(1) NULL,
    TransactionNumberSetIndicator CHAR(1) NULL,
    RingDuration CHAR(8) NULL,
    PaymentDuration CHAR(8) NULL,
    TransactionNonSalesDuration CHAR(8) NULL,
    InactiveDuration CHAR(8) NULL,
    TransactionBaseCurrencyType CHAR(3) NULL,
    OperatorEmployeeId INT NULL,
    OperatorEmployeeIndicator CHAR(1) NULL,
    OperatorEmployeeGroupCode CHAR(2) NULL,
    SupervisorId CHAR(8) NULL,
    SupervisorEmployeeId CHAR(8) NULL,
    SupervisorEmployeeIndicator CHAR(1) NULL,
    SupervisorEmployeeGroupCode CHAR(2) NULL,
    TransactionGrossPlusAmount DECIMAL(12,2) NULL,
    TransactionGrossMinusAmount DECIMAL(12,2) NULL,
    NetCashAmount DECIMAL(12,2) NULL,
    NetNonCashAmount DECIMAL(12,2) NULL,
    NegativeTenderIndicator CHAR(12) NULL,
    NetTotalAmount DECIMAL(12,2) NULL,
    TransactionSuspendedIndicator CHAR(1) NULL,
    TransactionRetrievedIndicator CHAR(1) NULL,
    AccountSalePointOfSaleId CHAR(14) NULL,
    AccountSaleTransactionAmount DECIMAL(14,2) NULL,
    StaffDiscountCardNumber CHAR(18) NULL,
    OriginalReceiptPresentIndicator CHAR(1) NULL,
    OriginalTransactionId CHAR(4) NULL,
    OriginalPointOfSaleId CHAR(3) NULL,
    OriginalOperatorId CHAR(8) NULL,
    OriginalTransactionDate DATE NULL,
    DotcomOrderNumber CHAR(40) NULL,
    FinancialMovementAmount DECIMAL(12,2) NULL,
    ChangeIssuedPointOfSaleId CHAR(3) NULL,
    PromotionName CHAR(40) NULL,
    LoyaltyAccountNumber CHAR(10) NULL,
    LoyaltyProgramId CHAR(8) NULL,
    LoyaltyEligibleAmount DECIMAL(8,2) NULL,
    LoyaltyEligibleQuantity DECIMAL(7,2) NULL,
    LoyaltyEligibleUOM CHAR(3) NULL,
    LoyaltyCardHolderName CHAR(40) NULL,
    LoyaltyCardCategory CHAR(4) NULL,
    LoyaltyCardValidFromDate DATETIME NULL,
    LoyaltyCardValidToDate DATETIME NULL,
    LoyaltyCardAcquisitionMethodId CHAR(10) NULL,
    LoyaltyValidationBarcode CHAR(26) NULL,
    TransactionId CHAR(60) NOT NULL,
    TransactionInitiatedTimestamp DATETIME NULL,
    TransactionCompletedTimestamp DATETIME NULL,
    PromotionId INT NULL,
    TransactionTypeId INT NULL,
    IsoCurrencyCode NVARCHAR(3) NULL,
    PointOfSaleId INT NULL,
    StoreId INT NULL,
    LoyaltyCardId CHAR(25) NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_Transaction PRIMARY KEY NONCLUSTERED (TransactionId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionLineItem
(
    UnitOfMeasure CHAR(3) NULL,
    TransactionReasonCode CHAR(4) NULL,
    QuantityEnteredIndicator CHAR(1) NULL,
    ArticleIdentifierType CHAR(1) NULL,
    ItemPriceManuallyEnteredIndicator CHAR(1) NULL,
    ItemLocallyPricedIndicator CHAR(1) NULL,
    ItemVoidedIndicator CHAR(1) NULL,
    ItemSoldOfflineIndicator CHAR(1) NULL,
    ItemRefundedIndicator CHAR(1) NULL,
    ItemMovementKeptIndicator CHAR(1) NULL,
    DiscountExemptIndicator CHAR(1) NULL,
    LoyaltyUnitsAcquisitionExemptIndicator CHAR(1) NULL,
    EntryMethodType INT NULL,
    EligibleForRedemptionIndicator CHAR(1) NULL,
    DummyArticleNumber CHAR(20) NULL,
    DotcomOrderRefundIndicator CHAR(1) NULL,
    BootsOwnBrandIndicator CHAR(1) NULL,
    TransactionBaseLoyaltyUnits DECIMAL(13,2) NULL,
    TransactionId CHAR(60) NOT NULL,
    TransactionLineItemId CHAR(60) NOT NULL,
    ProductId INT NULL,
    Quantity DECIMAL(13,2) NULL,
    ProductListPriceAmount DECIMAL(13,2) NULL,
    TransactionProductPriceAmount DECIMAL(13,2) NULL,
    TotalTransactionLineItemAmount DECIMAL(13,2) NULL,
    ProductPriceOverrideIndicator BIT NULL,
    TransactionLineItemTypeId INT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionLineItem PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.Payment
(
    PaymentMethodTypeCode CHAR(4) NULL,
    PaymentTenderNumber CHAR(10) NULL,
    TenderId CHAR(32) NULL,
    AccountSaleAccountNumber CHAR(20) NULL,
    NegativeTenderIndicator CHAR(1) NULL,
    PaymentCardPAN CHAR(32) NULL,
    PaymentCardTypeId CHAR(3) NULL,
    TerminalVerificationResults CHAR(10) NULL,
    TokenizedIndicator CHAR(1) NULL,
    PaymentCardNumberMasked CHAR(24) NULL,
    PaymentCardTenderNumber CHAR(2) NULL,
    PaymentCardNumber CHAR(40) NULL,
    CardTenderType CHAR(2) NULL,
    CustomerVerificationMethod CHAR(2) NULL,
    PaymentAuthorizationType CHAR(40) NULL,
    PaymentResponseCode CHAR(40) NULL,
    PaymentCardName CHAR(20) NULL,
    PaymentCardMerchantId CHAR(15) NULL,
    PaymentTNSTokenNumber CHAR(40) NULL,
    PaymentId CHAR(60) NOT NULL,
    PaymentTimestamp DATETIME NULL,
    PaymentAmount DECIMAL(13,2) NULL,
    PaymentCardAuthorizationCode NVARCHAR(16) NULL,
    PaymentCardAcquisitionMethodId INT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_Payment PRIMARY KEY NONCLUSTERED (PaymentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.ETopupEVoucher
(
    TransactionId CHAR(60) NOT NULL,
    TransactionLineItemId CHAR(60) NOT NULL,
    CardNumber CHAR(24) NULL,
    ItemCode CHAR(7) NULL,
    TopUpAmount DECIMAL(12,2) NULL,
    NetworkName CHAR(34) NULL,
    NetworkProductName CHAR(34) NULL,
    CardNumberAcquisitionMethodId CHAR(1) NULL,
    ItemVoidedIndicator CHAR(1) NULL,
    ResponseCode CHAR(5) NULL,
    TopupMobileNumber CHAR(16) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_ETopupEVoucher PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE test_curate.TransactionCreditClaim
(
    TransactionNumber CHAR(20) NULL,
    TransactionId CHAR(60) NULL,
    TransactionDate DATE NULL,
    TransactionInitiatedTimestamp DATETIME NULL,
    CreditClaimNumber CHAR(8) NOT NULL,
    BusinessCentreLetter CHAR(8) NULL,
    CreditClaimReasonCode CHAR(2) NULL,
    InvoiceNumber CHAR(9) NULL,
    FolioNumber CHAR(6) NULL,
    BatchReference CHAR(6) NULL,
    ConsignmentType CHAR(1) NULL,
    RepairCategoryReasonCode CHAR(1) NULL,
    RepairNumber CHAR(6) NULL,
    Plan4PolicyNumber CHAR(6) NULL,
    DDDADCDRNumber CHAR(4) NULL,
    DeliveryNoteNumber CHAR(9) NULL,
    DeliveryDate DATE NULL,
    CartonsReceivedCount CHAR(2) NULL,
    OrderNumber CHAR(7) NULL,
    CreditClaimComment CHAR(20) NULL,
    CreditClaimTotalItemCount CHAR(5) NULL,
    ProductId CHAR(60) NOT NULL,
    UnitOfMeasureId CHAR(3) NULL,
    Quantity DECIMAL(10,2) NULL,
    ItemUnitPrice DECIMAL(11,2) NULL,
    CreditClaimAuthorisation CHAR(15) NULL,
    StockAdjustmentIndicator CHAR(1) NULL,
    UnitOfDeliveryNumber CHAR(14) NULL,
    UnitOfDeliveryStatus CHAR(1) NULL,
    UnitOfDeliveryQuantity CHAR(4) NULL,
    SupplyRouteType CHAR(1) NULL,
    DispensaryLocationType CHAR(1) NULL,
    RecallNumber CHAR(8) NULL,
    ReturnMethodId CHAR(1) NULL,
    CarrierId CHAR(1) NULL,
    StoreId CHAR(4) NULL,
    DamageReasonCode CHAR(1) NULL,
    UnitOfDeliveryType CHAR(1) NULL,
	TransactionYear INT NOT NULL,
	TransactionMonth INT NOT NULL,
	TransactionDay INT NOT NULL,
	RunDate DATE NOT NULL,
    CONSTRAINT PK_TransactionCreditClaim PRIMARY KEY NONCLUSTERED (CreditClaimNumber, ProductId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.7
Purpose                              : Alter Script for Data length changes
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
23-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.7

**************************************************************************************************************************

*/



ALTER TABLE test_curate.ETopupEVoucher  DROP CONSTRAINT PK_ETopupEVoucher;


ALTER TABLE test_curate.ETopupEVoucher ALTER COLUMN TransactionLineItemId CHAR(60)  null;

ALTER TABLE test_curate.ETopupEVoucher ADD CONSTRAINT PK_ETopupEVoucher 
PRIMARY KEY NONCLUSTERED (TransactionId) NOT ENFORCED;




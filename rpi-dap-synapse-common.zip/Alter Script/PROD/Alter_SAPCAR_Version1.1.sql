/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.1
Purpose                              : Alter Script to extend Data type length
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
28-Aug-2021   :  Shainee Mangal        :  Incremental Version 1.1

**************************************************************************************************************************

*/


--ALTER COLUMN 

ALTER TABLE SER_RETAIL.[Transaction] ALTER COLUMN TransactionBaseCurrencyType varchar(7);

ALTER TABLE SER_RETAIL.[Transaction] ALTER COLUMN  SiteSourceKey varchar(10);
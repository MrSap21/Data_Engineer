/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.2
Purpose                              : Alter Script to change RunDate Data type from date to datetime
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
02-Sep-2021   :  Arindam Pathak       :  Incremental Version 1.2

**************************************************************************************************************************

*/


--ALTER COLUMN 


ALTER TABLE SER_RETAIL.[ETopupEVoucher]  ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[GiftCardTransaction] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[LoyaltyAccountEarning] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[Payment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[Transaction] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionAdjustment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionCoupon] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionCreditClaim] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionLineItem] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionLineItemAdjustment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionLoyaltyAccount] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionPayment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE SER_RETAIL.[TransactionPromotion] ALTER COLUMN RunDate datetime not null;
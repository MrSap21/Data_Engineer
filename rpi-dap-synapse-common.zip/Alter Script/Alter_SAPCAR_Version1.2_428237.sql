ALTER TABLE test_curate.[Transaction] ALTER COLUMN IsoCurrencyCode CHAR(5);

ALTER TABLE test_curate.LoyaltyAccountEarning ALTER COLUMN [Timestamp] DATETIME  NULL;

ALTER TABLE test_curate.GiftCardTransaction ALTER COLUMN [Timestamp] DATETIME  NULL;


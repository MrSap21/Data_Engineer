/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.8
Purpose                              : Alter Script for NetworkName & NetworkProductName data length chnage to  varchar(60)
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
24-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.8

**************************************************************************************************************************

*/

ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN NetworkName char(60);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN NetworkProductName char(60);




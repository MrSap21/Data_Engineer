/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.11
Purpose                              : Alter Script for Data type changes ( CHAR to VARCHAR)
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
25-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.11

**************************************************************************************************************************

*/

--ALTER SCRIPT FOR PK DROP 


ALTER TABLE test_curate.[LoyaltyAccountEarning] DROP CONSTRAINT PK_LoyaltyAccountEarning;
ALTER TABLE test_curate.[Payment] DROP CONSTRAINT PK_Payment;
ALTER TABLE test_curate.[TransactionAdjustment] DROP CONSTRAINT PK_TransactionAdjustment;
ALTER TABLE test_curate.[TransactionCoupon] DROP CONSTRAINT PK_TransactionCoupon;
ALTER TABLE test_curate.[TransactionCreditClaim] DROP CONSTRAINT PK_TransactionCreditClaim;
ALTER TABLE test_curate.[TransactionLineItem] DROP CONSTRAINT PK_TransactionLineItem;
ALTER TABLE test_curate.[TransactionLineItemAdjustment] DROP CONSTRAINT PK_TransactionLineItemAdjustment;
ALTER TABLE test_curate.[TransactionLoyaltyAccount] DROP CONSTRAINT PK_TransactionLoyaltyAccount;
ALTER TABLE test_curate.[TransactionPayment] DROP CONSTRAINT PK_TransactionPayment;
ALTER TABLE test_curate.[TransactionPromotion] DROP CONSTRAINT PK_TransactionPromotion;

--ALTER COLUMN 


ALTER TABLE test_curate.[LoyaltyAccountEarning] ALTER COLUMN LoyaltyAdditionValidationCode varchar(8);
ALTER TABLE test_curate.[LoyaltyAccountEarning] ALTER COLUMN LoyaltyCardId varchar(255) NOT NULL;
ALTER TABLE test_curate.[LoyaltyAccountEarning] ALTER COLUMN TransactionId varchar(60) NOT NULL;


ALTER TABLE test_curate.[Payment] ALTER COLUMN AccountSaleAccountNumber varchar(20);
ALTER TABLE test_curate.[Payment] ALTER COLUMN CardTenderType varchar(2);
ALTER TABLE test_curate.[Payment] ALTER COLUMN CustomerVerificationMethod varchar(2);
ALTER TABLE test_curate.[Payment] ALTER COLUMN NegativeTenderIndicator varchar(1);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentAuthorizationType varchar(40);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardAuthorizationCode varchar(32);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardMerchantId varchar(15);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardName varchar(40);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardNumber varchar(40);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardNumberMasked varchar(24);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardPAN varchar(255);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardTenderNumber varchar(2);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentCardTypeId varchar(3);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentId varchar(60) NOT NULL;
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentMethodTypeCode varchar(4);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentResponseCode varchar(40);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentTenderNumber varchar(10);
ALTER TABLE test_curate.[Payment] ALTER COLUMN PaymentTNSTokenNumber varchar(40);
ALTER TABLE test_curate.[Payment] ALTER COLUMN TenderId varchar(32) ;
ALTER TABLE test_curate.[Payment] ALTER COLUMN TerminalVerificationResults varchar(10);
ALTER TABLE test_curate.[Payment] ALTER COLUMN TokenizedIndicator varchar(1);

ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN AdjustmentId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN DiscountIdentifier varchar(60);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN DiscountReasonCode varchar(4);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN DiscountTypeCode varchar(4);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationBrandStatus varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationCount varchar(40);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationExemptStatus varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationListAIndicator varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationListBIndicator varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationListCIndicator varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationListXIndicator varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationReason varchar(40);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN QualificationRedeemableStatus varchar(1);
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN TransactionNumber varchar(10);



ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN CouponId varchar(60)NOT NULL;
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN CouponKeyedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN CouponPriceOverrideIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN CouponQuantityEnteredIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN CouponRefundIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN CouponVoidedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN LoyaltyUnitsCouponIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN TransactionId varchar(60) NOT NULL;


ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN BatchReference varchar(6);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN BusinessCentreLetter varchar(8);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CarrierId varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CartonsReceivedCount varchar(2);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN ConsignmentType varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CreditClaimAuthorisation varchar(15);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CreditClaimComment varchar(20);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CreditClaimNumber varchar(8) NOT NULL;
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CreditClaimReasonCode varchar(2);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN CreditClaimTotalItemCount varchar(5);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN DamageReasonCode varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN DDDADCDRNumber varchar(4);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN DeliveryNoteNumber varchar(9);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN DispensaryLocationType varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN FolioNumber varchar(6);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN InvoiceNumber varchar(9);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN OrderNumber varchar(7);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN Plan4PolicyNumber varchar(6);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN ProductSourceKey varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN RecallNumber varchar(8);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN RepairCategoryReasonCode varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN RepairNumber varchar(6);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN ReturnMethodId varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN SiteSourceKey varchar(10);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN StockAdjustmentIndicator varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN SupplyRouteType varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN TransactionNumber varchar(20);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN UnitOfDeliveryNumber varchar(14);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN UnitOfDeliveryQuantity varchar(4);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN UnitOfDeliveryStatus varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN UnitOfDeliveryType varchar(1);
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN UnitOfMeasureId varchar(3);


ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ArticleIdentifierType varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN BootsOwnBrandIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN DiscountExemptIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN DotcomOrderRefundIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN DummyArticleNumber varchar(20);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN EligibleForRedemptionIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN EntryMethodType varchar(4);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ItemLocallyPricedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ItemMovementKeptIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ItemPriceManuallyEnteredIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ItemRefundedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ItemSoldOfflineIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ItemVoidedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN LoyaltyUnitsAcquisitionExemptIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN ProductSourceKey varchar(60);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN QuantityEnteredIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN TransactionLineItemId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN TransactionReasonCode varchar(4);
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN UnitOfMeasure varchar(3);


ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN AdjustmentId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN BootsItemDealListId varchar(30);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DealListExemptItemIndicator varchar(30);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DealListRedeemableIndicator varchar(30);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountIdentifier varchar(60);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountOverriddenIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountPercentage varchar(3);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountReasonCode varchar(4);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountRefundedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountTypeCode varchar(4);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN DiscountVoidedIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN StaffDiscountOverriddenIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN TransactionLevelDiscountIndicator varchar(1);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN TransactionLineItemId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN TransactionLineItemNumber varchar(10);
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN VATExemptDiscountIndicator varchar(1);


ALTER TABLE test_curate.[TransactionLoyaltyAccount] ALTER COLUMN LoyaltyCardId varchar(255) NOT NULL;
ALTER TABLE test_curate.[TransactionLoyaltyAccount] ALTER COLUMN TransactionId varchar(60) NOT NULL;


ALTER TABLE test_curate.[TransactionPayment] ALTER COLUMN PaymentId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionPayment] ALTER COLUMN TransactionId varchar(60) NOT NULL;


ALTER TABLE test_curate.[TransactionPromotion] ALTER COLUMN PromotionDescription varchar(40);
ALTER TABLE test_curate.[TransactionPromotion] ALTER COLUMN PromotionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[TransactionPromotion] ALTER COLUMN TransactionId varchar(60) NOT NULL;






--ALTER SCRIPT FOR PK CREATE




ALTER TABLE test_curate.[LoyaltyAccountEarning] ADD CONSTRAINT PK_LoyaltyAccountEarning PRIMARY KEY NONCLUSTERED (TransactionId, LoyaltyCardId) NOT ENFORCED;

ALTER TABLE test_curate.[Payment] ADD CONSTRAINT PK_Payment PRIMARY KEY NONCLUSTERED (PaymentId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionAdjustment] ADD CONSTRAINT PK_TransactionAdjustment PRIMARY KEY NONCLUSTERED (TransactionId, AdjustmentId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionCoupon] ADD CONSTRAINT PK_TransactionCoupon PRIMARY KEY NONCLUSTERED (TransactionId, CouponId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionCreditClaim] ADD CONSTRAINT PK_TransactionCreditClaim PRIMARY KEY NONCLUSTERED (CreditClaimNumber, TransactionId, ProductSourceKey) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionLineItem] ADD CONSTRAINT PK_TransactionLineItem PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionLineItemAdjustment] ADD CONSTRAINT PK_TransactionLineItemAdjustment PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId, AdjustmentId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionLoyaltyAccount] ADD CONSTRAINT PK_TransactionLoyaltyAccount PRIMARY KEY NONCLUSTERED (TransactionId, LoyaltyCardId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionPayment] ADD CONSTRAINT PK_TransactionPayment PRIMARY KEY NONCLUSTERED  (TransactionId, PaymentId) NOT ENFORCED;

ALTER TABLE test_curate.[TransactionPromotion] ADD CONSTRAINT PK_TransactionPromotion PRIMARY KEY NONCLUSTERED (TransactionId, PromotionId) NOT ENFORCED;
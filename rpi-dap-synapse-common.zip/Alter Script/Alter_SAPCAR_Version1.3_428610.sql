/* Rename TransactionLineItem.ProductId to TransactionLineItem.ProductSourceKey*/

EXEC sp_rename 'test_curate.TransactionLineItem.ProductId', 'ProductSourceKey', 'COLUMN';
ALTER TABLE test_curate.TransactionLineItem  ALTER COLUMN  ProductSourceKey CHAR(60);

/* Rename TransactionCreditClaim.ProductId to TransactionCreditClaim.ProductSourceKey*/

ALTER TABLE test_curate.TransactionCreditClaim  DROP CONSTRAINT PK_TransactionCreditClaim;

EXEC sp_rename 'test_curate.TransactionCreditClaim.ProductId', 'ProductSourceKey', 'COLUMN';

ALTER TABLE test_curate.TransactionCreditClaim  ALTER COLUMN  ProductSourceKey CHAR(60) NOT NULL;
ALTER TABLE test_curate.TransactionCreditClaim  ALTER COLUMN  TransactionId CHAR(60) NOT NULL;

ALTER TABLE test_curate.TransactionCreditClaim ADD CONSTRAINT PK_TransactionCreditClaim 
PRIMARY KEY NONCLUSTERED (CreditClaimNumber,TransactionId,ProductSourceKey) NOT ENFORCED;


/* Transaction.StoreId renamed to Transaction.SiteSourceKey*/
EXEC sp_rename 'test_curate.[Transaction].StoreId', 'SiteSourceKey', 'COLUMN';
ALTER TABLE test_curate.[Transaction]  ALTER COLUMN  SiteSourceKey CHAR(4);

/*  TransactionCreditClaim.StoreId renamed to  TransactionCreditClaim.SiteSourceKey*/
EXEC sp_rename 'test_curate.TransactionCreditClaim.StoreId', 'SiteSourceKey', 'COLUMN';
ALTER TABLE test_curate. TransactionCreditClaim  ALTER COLUMN  SiteSourceKey CHAR(4);



/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.4
Purpose                              : Alter Script for Data length changes
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
19-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.4

**************************************************************************************************************************

*/


--429269
ALTER TABLE test_curate.Payment ALTER COLUMN PaymentCardPAN   CHAR(255);

--429274,429285
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorId CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN AccountSaleAccountNumber CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorEmployeeIndicator CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorEmployeeGroupCode CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SupervisorId CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SupervisorEmployeeId CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN StaffDiscountCardNumber CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OriginalOperatorId CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyAccountNumber CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyCardId CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyCardHolderName CHAR(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorEmployeeId CHAR(255);


--429282
ALTER TABLE test_curate.TransactionLoyaltyAccount  DROP CONSTRAINT PK_TransactionLoyaltyAccount;


ALTER TABLE test_curate.TransactionLoyaltyAccount ALTER COLUMN LoyaltyCardId CHAR(255) not null;

ALTER TABLE test_curate.TransactionLoyaltyAccount ADD CONSTRAINT PK_TransactionLoyaltyAccount 
PRIMARY KEY NONCLUSTERED (TransactionId,LoyaltyCardId) NOT ENFORCED;



/* PHI column from SAP_CAR_data_tracker */
ALTER TABLE test_curate.LoyaltyAccountEarning  DROP CONSTRAINT PK_LoyaltyAccountEarning;
ALTER TABLE test_curate.LoyaltyAccountEarning ALTER COLUMN LoyaltyCardId CHAR(255) not null;

ALTER TABLE test_curate.LoyaltyAccountEarning ADD CONSTRAINT PK_LoyaltyAccountEarning
PRIMARY KEY NONCLUSTERED (TransactionId,LoyaltyCardId) NOT ENFORCED;



ALTER TABLE test_curate.ETopupEVoucher ALTER COLUMN CardNumber CHAR(255);
ALTER TABLE test_curate.ETopupEVoucher ALTER COLUMN TopupMobileNumber CHAR(255);
ALTER TABLE test_curate.Payment ALTER COLUMN PaymentCardName CHAR(40);



ALTER TABLE test_curate.GiftCardTransaction  DROP CONSTRAINT PK_GiftCardTransaction;


ALTER TABLE test_curate.GiftCardTransaction ALTER COLUMN GiftCardId CHAR(40) not null;

ALTER TABLE test_curate.GiftCardTransaction ADD CONSTRAINT PK_GiftCardTransaction
PRIMARY KEY NONCLUSTERED (TransactionId,GiftCardId) NOT ENFORCED;



--429279

ALTER TABLE test_curate.TransactionAdjustment  DROP CONSTRAINT PK_TransactionAdjustment;

EXEC sp_rename 'test_curate.TransactionAdjustment.AdjustmentId', 'DiscountIdentifier', 'COLUMN';
EXEC sp_rename 'test_curate.TransactionAdjustment.BonusBuyIdentifier', 'AdjustmentId', 'COLUMN';
ALTER TABLE test_curate.TransactionAdjustment  ALTER COLUMN  AdjustmentId CHAR(60) NOT NULL;


ALTER TABLE test_curate.TransactionAdjustment ADD CONSTRAINT PK_TransactionAdjustment 
PRIMARY KEY NONCLUSTERED (TransactionId,AdjustmentId) NOT ENFORCED;




--429278
ALTER TABLE test_curate.TransactionLineItemAdjustment  DROP CONSTRAINT PK_TransactionLineItemAdjustment;

EXEC sp_rename 'test_curate.TransactionLineItemAdjustment.AdjustmentId', 'DiscountIdentifier', 'COLUMN';
EXEC sp_rename 'test_curate.TransactionLineItemAdjustment.BonusBuyIdentifier', 'AdjustmentId', 'COLUMN';
ALTER TABLE test_curate.TransactionLineItemAdjustment  ALTER COLUMN  AdjustmentId CHAR(60) NOT NULL;


ALTER TABLE test_curate.TransactionLineItemAdjustment ADD CONSTRAINT PK_TransactionLineItemAdjustment 
PRIMARY KEY NONCLUSTERED (TransactionId,TransactionLineItemId,AdjustmentId) NOT ENFORCED;
/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.10
Purpose                              : Alter Script for Data type changes ( CHAR to VARCHAR)
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
25-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.10

**************************************************************************************************************************

*/

--ALTER SCRIPT FOR PK DROP 
ALTER TABLE test_curate.[ETopupEVoucher] DROP CONSTRAINT PK_ETopupEVoucher;
ALTER TABLE test_curate.[GiftCardTransaction] DROP CONSTRAINT PK_GiftCardTransaction;
ALTER TABLE test_curate.[Transaction] DROP CONSTRAINT PK_Transaction;



--ALTER COLUMN 
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN CardNumber varchar(255);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN CardNumberAcquisitionMethodId varchar(1);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN ItemCode varchar(7);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN ItemVoidedIndicator varchar(1);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN NetworkName varchar(60);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN NetworkProductName varchar(60);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN ResponseCode varchar(5);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN TopupMobileNumber varchar(255);
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[ETopupEVoucher] ALTER COLUMN TransactionLineItemId varchar(60);

ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN FirstSaleIndicator varchar(40);
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN GiftCardId varchar(40) NOT NULL;
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN GiftCardTransactionNumber varchar(13);
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN GiftCardTransactionType varchar(40);
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN SubsequentSaleIndicator varchar(40);
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN TransactionLineItemId varchar(60);

ALTER TABLE test_curate.[Transaction] ALTER COLUMN AccountSaleAccountNumber varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN AccountSaleIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN AccountSalePointOfSaleId varchar(14);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN ChangeIssuedPointOfSaleId varchar(3);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN DotcomOrderNumber varchar(40);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN FinancialMovementTypeCode varchar(8);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN InactiveDuration varchar(8);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN IsoCurrencyCode varchar(5);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyAccountNumber varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyCardAcquisitionMethodId varchar(10);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyCardCategory varchar(4);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyCardHolderName varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyCardId varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyEligibleUOM varchar(3);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyProgramId varchar(8);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN LoyaltyValidationBarcode varchar(40);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN ManagerKeyIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN NegativeTenderIndicator varchar(12);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorEmployeeGroupCode varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorEmployeeId varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorEmployeeIndicator varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorId varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OperatorIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OriginalOperatorId varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OriginalPointOfSaleId varchar(3);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OriginalReceiptPresentIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OriginalTransactionId varchar(4);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN OriginalTransactionTime varchar(4);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN PaymentDuration varchar(8);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN PromotionName varchar(40);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN RingDuration varchar(8);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SiteSourceKey varchar(4);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SourceTransactionNumber varchar(20);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN StaffDiscountCardNumber varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SupervisorEmployeeGroupCode varchar(2);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SupervisorEmployeeId varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SupervisorEmployeeIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SupervisorId varchar(255);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionBaseCurrencyType varchar(3);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionId varchar(60) NOT NULL;
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionNonSalesDuration varchar(8);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionNumberSetIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionRetrievedIndicator varchar(1);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionSuspendedIndicator varchar(1);








--ALTER SCRIPT FOR PK CREATE

ALTER TABLE test_curate.ETopupEVoucher ADD CONSTRAINT PK_ETopupEVoucher PRIMARY KEY NONCLUSTERED (TransactionId) NOT ENFORCED;

ALTER TABLE test_curate.GiftCardTransaction ADD CONSTRAINT PK_GiftCardTransaction PRIMARY KEY NONCLUSTERED (TransactionId, GiftCardId) NOT ENFORCED;

ALTER TABLE test_curate.[Transaction] ADD CONSTRAINT PK_Transaction PRIMARY KEY NONCLUSTERED (TransactionId) NOT ENFORCED;



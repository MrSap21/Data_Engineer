/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.12
Purpose                              : Alter Script to change RunDate Data type from date to datetime
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
02-Sep-2021   :  Arindam Pathak        :  Incremental Version 1.12

**************************************************************************************************************************

*/


--ALTER COLUMN 
ALTER TABLE test_curate.[ETopupEVoucher]  ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[GiftCardTransaction] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[LoyaltyAccountEarning] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[Payment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[Transaction] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionAdjustment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionCoupon] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionCreditClaim] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionLineItem] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionLineItemAdjustment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionLoyaltyAccount] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionPayment] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.[TransactionPromotion] ALTER COLUMN RunDate datetime not null;
ALTER TABLE test_curate.LoyaltyAccountEarning ALTER COLUMN LoyaltyProgramId INT NULL;
ALTER TABLE test_curate.LoyaltyAccountEarning ALTER COLUMN LoyaltyAccountId INT NULL;


ALTER TABLE test_curate.TransactionLoyaltyAccount ALTER COLUMN LoyaltyProgramId INT NULL;
ALTER TABLE test_curate.TransactionLoyaltyAccount ALTER COLUMN LoyaltyAccountId INT NULL;
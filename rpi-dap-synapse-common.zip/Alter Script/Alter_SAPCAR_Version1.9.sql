/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.9
Purpose                              : Alter Script for Not null
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
24-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.8

**************************************************************************************************************************

*/

--431245
ALTER TABLE test_curate.TransactionAdjustment  ALTER COLUMN  DiscountIdentifier CHAR(60)  NULL;
ALTER TABLE test_curate.TransactionLineItemAdjustment  ALTER COLUMN  DiscountIdentifier CHAR(60)  NULL;




/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.5
Purpose                              : Alter Script for Data length changes
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
19-Aug-2021   :  Arindam Pathak        :  Incremental Version 1.5

**************************************************************************************************************************

*/

--429944
ALTER TABLE test_curate.TransactionLineItem ALTER COLUMN EntryMethodType   CHAR(4);

--429936
ALTER TABLE test_curate.TransactionAdjustment ALTER COLUMN 	QualificationCount CHAR(40);

/* Analysed by Shainee */
ALTER TABLE test_curate.[Transaction]  ALTER COLUMN  LoyaltyValidationBarcode  CHAR(40);

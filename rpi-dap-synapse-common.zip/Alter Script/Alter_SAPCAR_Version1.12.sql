/*
************************************************************************************************************

Script Name                          : Alter_SAPCAR_Version1.12
Purpose                              : Alter Script to extend Data type length
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
28-Aug-2021   :  Shainee Mangal        :  Incremental Version 1.12

**************************************************************************************************************************

*/


--ALTER COLUMN 
ALTER TABLE test_curate.[Transaction] ALTER COLUMN TransactionBaseCurrencyType varchar(7);
ALTER TABLE test_curate.[Transaction] ALTER COLUMN SiteSourceKey varchar(10);
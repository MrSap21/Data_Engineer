/*
************************************************************************************************************

Script Name                          : Create_SAPCAR_Version3.0
Purpose                              : Create Table Script for 13 SAP CAR tables(Pre-Pord & QA)
************************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
20-Oct-2021   :  Arindam Pathak        :  Create_SAPCAR_Version3.0

**************************************************************************************************************************

*/





CREATE TABLE SER_RETAIL.TransactionCoupon
(
    CouponKeyedIndicator VARCHAR(1) NULL,
    CouponRefundIndicator VARCHAR(1) NULL,
    CouponVoidedIndicator VARCHAR(1) NULL,
    CouponQuantityEnteredIndicator VARCHAR(1) NULL,
    LoyaltyUnitsCouponIndicator VARCHAR(1) NULL,
    CouponPriceOverrideIndicator VARCHAR(1) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    CouponId VARCHAR(60) NOT NULL,
    TransactionCouponDiscountAmount DECIMAL(12,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL
    CONSTRAINT PK_TransactionCoupon PRIMARY KEY NONCLUSTERED (TransactionId, CouponId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionPromotion
(
    PromotionDescription VARCHAR(40) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    PromotionId VARCHAR(60) NOT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionPromotion PRIMARY KEY NONCLUSTERED (TransactionId, PromotionId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionPayment
(
    TransactionId VARCHAR(60) NOT NULL,
    PaymentId VARCHAR(60) NOT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionPayment PRIMARY KEY NONCLUSTERED (TransactionId, PaymentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.LoyaltyAccountEarning
(
    LoyaltyAdditionValidationCode VARCHAR(8) NULL,
    LoyaltyProgramId INT  NULL,
    LoyaltyAccountId INT  NULL,
    Timestamp DATETIME  NULL,
    EarnedLoyaltyUnits DECIMAL(13,2) NULL,
    LoyaltyEarningTypeId INT NULL,
    TransactionId VARCHAR(60) NULL,
	LoyaltyCardId VARCHAR(255) NOT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_LoyaltyAccountEarning PRIMARY KEY NONCLUSTERED (TransactionId, LoyaltyCardId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionAdjustment
(
    AdjustmentId VARCHAR(60) NOT NULL,
    RewardAmount DECIMAL(12,2) NULL,
    QualificationRedeemableStatus VARCHAR(1) NULL,
    QualificationReason VARCHAR(40) NULL,
    QualificationCount VARCHAR(40) NULL,
    QualificationListXIndicator VARCHAR(1) NULL,
    QualificationListCIndicator VARCHAR(1) NULL,
    QualificationListBIndicator VARCHAR(1) NULL,
    QualificationListAIndicator VARCHAR(1) NULL,
    QualificationExemptStatus VARCHAR(1) NULL,
    QualificationBrandStatus VARCHAR(1) NULL,
    QualificationAmount DECIMAL(8,2) NULL,
    ExtraLoyaltyUnitsCount DECIMAL(12,2) NULL,
    DiscountReasonCode VARCHAR(4) NULL,
    DiscountTypeCode VARCHAR(4) NULL,
    TransactionNumber VARCHAR(10) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    DiscountIdentifier VARCHAR(60)  NULL,
    AdjustmentAmount DECIMAL(15,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionAdjustment PRIMARY KEY NONCLUSTERED (TransactionId, AdjustmentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionLineItemAdjustment
(
    VATExemptDiscountIndicator VARCHAR(1) NULL,
    TransactionLineItemNumber VARCHAR(10) NULL,
    TransactionLevelDiscountIndicator VARCHAR(1) NULL,
    StaffDiscountOverriddenIndicator VARCHAR(1) NULL,
    DiscountVoidedIndicator VARCHAR(1) NULL,
    DiscountTypeCode VARCHAR(4) NULL,
    DiscountRefundedIndicator VARCHAR(1) NULL,
    DiscountReasonCode VARCHAR(4) NULL,
    DiscountPercentage VARCHAR(3) NULL,
    DiscountOverriddenIndicator VARCHAR(1) NULL,
    DealLoyaltyRewardUnits DECIMAL(12,2) NULL,
    DealListRedeemableIndicator VARCHAR(30) NULL,
    DealListExemptItemIndicator VARCHAR(30) NULL,
    BootsItemDealListId VARCHAR(30) NULL,
    AdjustmentId VARCHAR(60) NOT NULL,
    TransactionId VARCHAR(60) NOT NULL,
    TransactionLineItemId VARCHAR(60) NOT NULL,
    DiscountIdentifier VARCHAR(60)  NULL,
    AdjustmentAmount DECIMAL(13,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionLineItemAdjustment PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId, AdjustmentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionLoyaltyAccount
(
    LoyaltyCardId VARCHAR(255) NOT NULL,
    LoyaltyCardUsageCount INT NULL,
    LoyaltyAccountBalanceAmount DECIMAL(11,2) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    LoyaltyProgramId INT  NULL,
    LoyaltyAccountId INT  NULL,
    LoyaltyUnitsUsed DECIMAL(11,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionLoyaltyAccount PRIMARY KEY NONCLUSTERED (TransactionId, LoyaltyCardId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.GiftCardTransaction
(
    TransactionLineItemId VARCHAR(60) NULL,
    GiftCardTransactionType VARCHAR(40) NULL,
    SubsequentSaleIndicator VARCHAR(40) NULL,
    FirstSaleIndicator VARCHAR(40) NULL,
    GiftCardTransactionNumber VARCHAR(13) NULL,
    GiftCardOpeningBalanceAmount DECIMAL(12,2) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    GiftCardId VARCHAR(40) NOT NULL,
    Timestamp DATETIME  NULL,
    Amount DECIMAL(12,2) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_GiftCardTransaction PRIMARY KEY NONCLUSTERED (TransactionId, GiftCardId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.[Transaction]
(
    FinancialMovementTypeCode VARCHAR(8) NULL,
    OriginalTransactionTime VARCHAR(4) NULL,
    TransactionDate DATE NULL,
    SourceTransactionNumber VARCHAR(20) NULL,
    OperatorIndicator VARCHAR(1) NULL,
    OperatorId VARCHAR(255) NULL,
    AccountSaleIndicator VARCHAR(1) NULL,
    AccountSaleAccountNumber VARCHAR(255) NULL,
    ManagerKeyIndicator VARCHAR(1) NULL,
    TransactionNumberSetIndicator VARCHAR(1) NULL,
    RingDuration VARCHAR(8) NULL,
    PaymentDuration VARCHAR(8) NULL,
    TransactionNonSalesDuration VARCHAR(8) NULL,
    InactiveDuration VARCHAR(8) NULL,
    TransactionBaseCurrencyType VARCHAR(7) NULL,
    OperatorEmployeeId VARCHAR(255) NULL,
    OperatorEmployeeIndicator VARCHAR(255) NULL,
    OperatorEmployeeGroupCode VARCHAR(255) NULL,
    SupervisorId VARCHAR(255) NULL,
    SupervisorEmployeeId VARCHAR(255) NULL,
    SupervisorEmployeeIndicator VARCHAR(1) NULL,
    SupervisorEmployeeGroupCode VARCHAR(2) NULL,
    TransactionGrossPlusAmount DECIMAL(12,2) NULL,
    TransactionGrossMinusAmount DECIMAL(12,2) NULL,
    NetCashAmount DECIMAL(12,2) NULL,
    NetNonCashAmount DECIMAL(12,2) NULL,
    NegativeTenderIndicator VARCHAR(12) NULL,
    NetTotalAmount DECIMAL(12,2) NULL,
    TransactionSuspendedIndicator VARCHAR(1) NULL,
    TransactionRetrievedIndicator VARCHAR(1) NULL,
    AccountSalePointOfSaleId VARCHAR(14) NULL,
    AccountSaleTransactionAmount DECIMAL(14,2) NULL,
    StaffDiscountCardNumber VARCHAR(255) NULL,
    OriginalReceiptPresentIndicator VARCHAR(1) NULL,
    OriginalTransactionId VARCHAR(4) NULL,
    OriginalPointOfSaleId VARCHAR(3) NULL,
    OriginalOperatorId VARCHAR(255) NULL,
    OriginalTransactionDate DATE NULL,
    DotcomOrderNumber VARCHAR(40) NULL,
    FinancialMovementAmount DECIMAL(12,2) NULL,
    ChangeIssuedPointOfSaleId VARCHAR(3) NULL,
    PromotionName VARCHAR(40) NULL,
    LoyaltyAccountNumber VARCHAR(255) NULL,
    LoyaltyProgramId VARCHAR(8) NULL,
    LoyaltyEligibleAmount DECIMAL(8,2) NULL,
    LoyaltyEligibleQuantity DECIMAL(7,2) NULL,
    LoyaltyEligibleUOM VARCHAR(3) NULL,
    LoyaltyCardHolderName VARCHAR(255) NULL,
    LoyaltyCardCategory VARCHAR(4) NULL,
    LoyaltyCardValidFromDate DATETIME NULL,
    LoyaltyCardValidToDate DATETIME NULL,
    LoyaltyCardAcquisitionMethodId VARCHAR(10) NULL,
    LoyaltyValidationBarcode VARCHAR(40) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    TransactionInitiatedTimestamp DATETIME NULL,
    TransactionCompletedTimestamp DATETIME NULL,
    PromotionId INT NULL,
    TransactionTypeId INT NULL,
    IsoCurrencyCode VARCHAR(5) NULL,
    PointOfSaleId INT NULL,
    SiteSourceKey VARCHAR(10)  NULL,
    LoyaltyCardId VARCHAR(255) NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_Transaction PRIMARY KEY NONCLUSTERED (TransactionId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionLineItem
(
    UnitOfMeasure VARCHAR(3) NULL,
    TransactionReasonCode VARCHAR(4) NULL,
    QuantityEnteredIndicator VARCHAR(1) NULL,
    ArticleIdentifierType VARCHAR(1) NULL,
    ItemPriceManuallyEnteredIndicator VARCHAR(1) NULL,
    ItemLocallyPricedIndicator VARCHAR(1) NULL,
    ItemVoidedIndicator VARCHAR(1) NULL,
    ItemSoldOfflineIndicator VARCHAR(1) NULL,
    ItemRefundedIndicator VARCHAR(1) NULL,
    ItemMovementKeptIndicator VARCHAR(1) NULL,
    DiscountExemptIndicator VARCHAR(1) NULL,
    LoyaltyUnitsAcquisitionExemptIndicator VARCHAR(1) NULL,
    EntryMethodType VARCHAR(4) NULL,
    EligibleForRedemptionIndicator VARCHAR(1) NULL,
    DummyArticleNumber VARCHAR(20) NULL,
    DotcomOrderRefundIndicator VARCHAR(1) NULL,
    BootsOwnBrandIndicator VARCHAR(1) NULL,
    TransactionBaseLoyaltyUnits DECIMAL(13,2) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    TransactionLineItemId VARCHAR(60) NOT NULL,
    ProductSourceKey VARCHAR(60) NULL,
    Quantity DECIMAL(13,2) NULL,
    ProductListPriceAmount DECIMAL(13,2) NULL,
    TransactionProductPriceAmount DECIMAL(13,2) NULL,
    TotalTransactionLineItemAmount DECIMAL(13,2) NULL,
    ProductPriceOverrideIndicator BIT NULL,
    TransactionLineItemTypeId INT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionLineItem PRIMARY KEY NONCLUSTERED (TransactionId, TransactionLineItemId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.Payment
(
    PaymentMethodTypeCode VARCHAR(4) NULL,
    PaymentTenderNumber VARCHAR(10) NULL,
    TenderId VARCHAR(32) NULL,
    AccountSaleAccountNumber VARCHAR(20) NULL,
    NegativeTenderIndicator VARCHAR(1) NULL,
    PaymentCardPAN VARCHAR(255) NULL,
    PaymentCardTypeId VARCHAR(3) NULL,
    TerminalVerificationResults VARCHAR(10) NULL,
    TokenizedIndicator VARCHAR(1) NULL,
    PaymentCardNumberMasked VARCHAR(24) NULL,
    PaymentCardTenderNumber VARCHAR(2) NULL,
    PaymentCardNumber VARCHAR(40) NULL,
    CardTenderType VARCHAR(2) NULL,
    CustomerVerificationMethod VARCHAR(2) NULL,
    PaymentAuthorizationType VARCHAR(40) NULL,
    PaymentResponseCode VARCHAR(40) NULL,
    PaymentCardName VARCHAR(40) NULL,
    PaymentCardMerchantId VARCHAR(15) NULL,
    PaymentTNSTokenNumber VARCHAR(40) NULL,
    PaymentId VARCHAR(60) NOT NULL,
    PaymentTimestamp DATETIME NULL,
    PaymentAmount DECIMAL(13,2) NULL,
    PaymentCardAuthorizationCode NVARCHAR(16) NULL,
    PaymentCardAcquisitionMethodId INT NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_Payment PRIMARY KEY NONCLUSTERED (PaymentId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.ETopupEVoucher
(
    TransactionId VARCHAR(60) NOT NULL,
    TransactionLineItemId VARCHAR(60)  NULL,
    CardNumber VARCHAR(255) NULL,
    ItemCode VARCHAR(7) NULL,
    TopUpAmount DECIMAL(12,2) NULL,
    NetworkName VARCHAR(60) NULL,
    NetworkProductName VARCHAR(60) NULL,
    CardNumberAcquisitionMethodId VARCHAR(1) NULL,
    ItemVoidedIndicator VARCHAR(1) NULL,
    ResponseCode VARCHAR(5) NULL,
    TopupMobileNumber VARCHAR(255) NULL,
	TransactionDate DATE NOT NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_ETopupEVoucher PRIMARY KEY NONCLUSTERED (TransactionId) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE SER_RETAIL.TransactionCreditClaim
(
    TransactionNumber VARCHAR(20) NULL,
    TransactionId VARCHAR(60) NOT NULL,
    TransactionDate DATE NULL,
    TransactionInitiatedTimestamp DATETIME NULL,
    CreditClaimNumber VARCHAR(8) NOT NULL,
    BusinessCentreLetter VARCHAR(8) NULL,
    CreditClaimReasonCode VARCHAR(2) NULL,
    InvoiceNumber VARCHAR(9) NULL,
    FolioNumber VARCHAR(6) NULL,
    BatchReference VARCHAR(6) NULL,
    ConsignmentType VARCHAR(1) NULL,
    RepairCategoryReasonCode VARCHAR(1) NULL,
    RepairNumber VARCHAR(6) NULL,
    Plan4PolicyNumber VARCHAR(6) NULL,
    DDDADCDRNumber VARCHAR(4) NULL,
    DeliveryNoteNumber VARCHAR(9) NULL,
    DeliveryDate DATE NULL,
    CartonsReceivedCount VARCHAR(2) NULL,
    OrderNumber VARCHAR(7) NULL,
    CreditClaimComment VARCHAR(20) NULL,
    CreditClaimTotalItemCount VARCHAR(5) NULL,
    ProductSourceKey VARCHAR(60) NOT NULL,
    UnitOfMeasureId VARCHAR(3) NULL,
    Quantity DECIMAL(10,2) NULL,
    ItemUnitPrice DECIMAL(11,2) NULL,
    CreditClaimAuthorisation VARCHAR(15) NULL,
    StockAdjustmentIndicator VARCHAR(1) NULL,
    UnitOfDeliveryNumber VARCHAR(14) NULL,
    UnitOfDeliveryStatus VARCHAR(1) NULL,
    UnitOfDeliveryQuantity VARCHAR(4) NULL,
    SupplyRouteType VARCHAR(1) NULL,
    DispensaryLocationType VARCHAR(1) NULL,
    RecallNumber VARCHAR(8) NULL,
    ReturnMethodId VARCHAR(1) NULL,
    CarrierId VARCHAR(1) NULL,
    SiteSourceKey VARCHAR(10) NULL,
    DamageReasonCode VARCHAR(1) NULL,
    UnitOfDeliveryType VARCHAR(1) NULL,
	TransactionYear VARCHAR(4) NOT NULL,
	TransactionMonth VARCHAR(2) NOT NULL,
	TransactionDay VARCHAR(2) NOT NULL,
	RunDateTime DATETIME NULL,
	SourceSystemID INT NULL

    CONSTRAINT PK_TransactionCreditClaim PRIMARY KEY NONCLUSTERED (CreditClaimNumber, TransactionId, ProductSourceKey) NOT ENFORCED
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


/
**************************************************************************************************************************
Script Name                          : Drop_Script_SAP_CAR_Release1
Purpose                              : Drop_SAP_CAR_TABLES_Release1
**************************************************************************************************************************
*/


DROP TABLE SER_RETAIL.Transaction;
DROP TABLE SER_RETAIL.TransactionLineItem;
DROP TABLE SER_RETAIL.TransactionAdjustment;
DROP TABLE SER_RETAIL.TransactionLineItemAdjustment;
DROP TABLE SER_RETAIL.GiftCardTransaction;
DROP TABLE SER_RETAIL.ETopupEVoucher;
DROP TABLE SER_RETAIL.LoyaltyAccountEarning;
DROP TABLE SER_RETAIL.Payment;
DROP TABLE SER_RETAIL.TransactionCoupon;
DROP TABLE SER_RETAIL.TransactionCreditClaim;
DROP TABLE SER_RETAIL.TransactionLoyaltyAccount;
DROP TABLE SER_RETAIL.TransactionPromotion;
DROP TABLE SER_RETAIL.TransactionPayment;

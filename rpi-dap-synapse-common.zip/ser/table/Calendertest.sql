/*
 * ER/Studio Data Architect SQL Code Generation
 * Company :      Walgreens Boots Alliance - Data & Analytics Platform
 * Project :      Curated V2.0.0.dm1
 * Author :       Andy Williams
 *
 * Date Created : Tuesday, October 06, 2020 17:09:56
 * Target DBMS : Microsoft SQL Server 2017
 */

/* 
 * TABLE: [Calendar] 
 */

CREATE TABLE [ser].[Calendartest](
    CalendarId              int             NOT NULL,
    CalendarName            nvarchar(80)    NOT NULL,
    CalendarDescription     nvarchar(80)    NULL,
    PartyId                 bigint          NULL,
    LOVCalendarTypeId       int             NOT NULL,
    LOVRecordSourceId       int             NOT NULL,
    SCDStartDate            datetime        NULL,
    SCDEndDate              datetime        NULL,
    SCDActiveFlag           nchar(1)        NULL,
    SCDVersion              smallint        NULL,
    SCDLOVRecordSourceId    int             NULL,
    ETLRunLogId             int             NULL,
    PSARowKey               bigint          NULL,

)
WITH
(
	DISTRIBUTION = HASH([CalendarId]),
	CLUSTERED COLUMNSTORE INDEX
)

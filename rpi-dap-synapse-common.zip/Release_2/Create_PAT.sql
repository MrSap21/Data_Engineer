/*
************************************************************************************************************

Script Name                          : Create_PAT_Version4.0
Purpose                              : Create TABLE Script 
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
2-Dec-2021   :  Arindam Pathak        :  Create_PAT_Version3.0 (Changed UserInitials column data length to 255 as suggested for Data profiling)

**************************************************************************************************************************

*/





CREATE TABLE SER_PHARMACEUTICALS.CreditClaim
(
    CreditClaimingDate 			DATE 			NOT NULL,
	SiteSourceKey 				INT 			NOT NULL,
	ReasonCodeID 				INT 			NOT NULL,
	UserInitials 				VARCHAR(255) 	NULL,
	MedicinalProductCode 		VARCHAR(100) 	NOT NULL,
	QuantityInPacks 			DECIMAL (18,3) 	NULL,
	RunDateTime					DATETIME 		NOT NULL,
	[Year] 						VARCHAR(4) 		NOT NULL,
	[Month]						VARCHAR(2) 		NOT NULL,
	[Day] 						VARCHAR(2) 		NOT NULL,
	SourceSystemID 				INT 			NOT NULL,
	LOVRECORDSOURCEID	    	INT           	NULL,
	SCDSTARTDATE	        	DATETIME      	NULL,
	SCDENDDATE	            	DATETIME      	NULL,
	SCDACTIVEFLAG	        	VARCHAR(1)    	NULL,
	SCDVERSION              	INT           	NULL,
	SCDLOVRECORDSOURCEID    	INT           	NULL,
	ETLRUNLOGID         		INT           	NULL
    
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO

CREATE TABLE SER_PHARMACEUTICALS.StoreStockTransaction
(
    PharmacyAccountingGroup 	VARCHAR(200) 	NOT NULL,
	TransactionDate 			DATE 			NOT NULL,
	SiteSourceKey 				INT 			NOT NULL,
	MedicinalProductCode 		VARCHAR(100)  	NULL,
	ItemsCount 					INT 			NULL,
	PrescriptionFormsCount 		INT 			NULL,
	EPOSTransactionType 		VARCHAR(255) 	NULL,
	MerchandisingGroupName 		VARCHAR(255) 	NULL,
	IsoCurrencyCode 			VARCHAR(100) 	NOT NULL,
	NumberFormat 				VARCHAR(20) 	NOT NULL,
	RunDateTime					DATETIME 		NOT NULL,
	[Year] 						VARCHAR(4) 		NOT NULL,
	[Month]						VARCHAR(2) 		NOT NULL,
	[Day] 						VARCHAR(2) 		NOT NULL,
	SourceSystemID 				INT 			NOT NULL,
	LOVRECORDSOURCEID	    	INT           	NULL,
	SCDSTARTDATE	        	DATETIME      	NULL,
	SCDENDDATE	            	DATETIME      	NULL,
	SCDACTIVEFLAG	        	VARCHAR(1)    	NULL,
	SCDVERSION              	INT           	NULL,
	SCDLOVRECORDSOURCEID    	INT           	NULL,
	ETLRUNLOGID         		INT           	NULL
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


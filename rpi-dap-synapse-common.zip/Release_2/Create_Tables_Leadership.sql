/*
**************************************************************************************************************************

Script Name                          : Create_Tables_Leadership
Purpose                              : Create Tables for Consumption Layer
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description
==========================================================================================================================

**************************************************************************************************************************

*/

-- EXEC SCORECARD
CREATE TABLE [SS_BUKMI].[Exec_Monthly_Data]
(
[Metric] VARCHAR(100) NOT NULL,
[Legend] VARCHAR(100),
[Date] DATE NOT NULL,
[Actual] DECIMAL(18,4),
[ActualItems] DECIMAL(18,0),
[Actual�] DECIMAL(18,2),
[Actual%] DECIMAL(18,4),
[Target/LY] DECIMAL(18,4),
[TargetItems] DECIMAL(18,0),
[Target/LY�] DECIMAL(18,2),
[Target/LY%] DECIMAL(18,4),
[Variance] DECIMAL(18,4),
[KPI] VARCHAR(100),
[RunDate] DATETIME NOT NULL
CONSTRAINT PK_Monthly_Data PRIMARY KEY NONCLUSTERED ([Date],[Metric]) NOT ENFORCED
)
WITH
(
CLUSTERED COLUMNSTORE INDEX,
DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE [SS_BUKMI].[Exec_Weekly_Data]
(
[Metric] VARCHAR(100) NOT NULL,
[Legend] VARCHAR(100),
[Date] DATE NOT NULL,
[Actual] DECIMAL(18,4),
[ActualItems] DECIMAL(18,0),
[Actual�] DECIMAL(18,2),
[Actual%] DECIMAL(18,4),
[Target/LY] DECIMAL(18,4),
[TargetItems] DECIMAL(18,0),
[Target/LY�] DECIMAL(18,2),
[Target/LY%] DECIMAL(18,4),
[Target/LLY] DECIMAL(18,4),
[TargetItemsLLY] DECIMAL(18,0),
[Target/LLY�] DECIMAL(18,2),
[Target/LLY%] DECIMAL(18,4),
[Variance] DECIMAL(18,4),
[VarianceLLY] DECIMAL(18,4),
[KPI] VARCHAR(100),
[RunDate] DATETIME NOT NULL
CONSTRAINT PK_Weekly_Data PRIMARY KEY NONCLUSTERED ([Date],[Metric]) NOT ENFORCED
)
WITH
(
CLUSTERED COLUMNSTORE INDEX,
DISTRIBUTION = ROUND_ROBIN
);
GO

CREATE TABLE [SS_BUKMI].[Exec_Date]
(
[WeeklyDate] DATE NOT NULL,
[MaxMonthlyDate] DATE,
[PreviousMonthDate] DATE NOT NULL,
[RunDate] DATETIME NOT NULL
CONSTRAINT PK_Exec_Date PRIMARY KEY NONCLUSTERED ([WeeklyDate],[PreviousMonthDate]) NOT ENFORCED
)
WITH
(
CLUSTERED COLUMNSTORE INDEX,
DISTRIBUTION = ROUND_ROBIN
);
GO

--OMNI CHANNEL
CREATE TABLE [SS_BUKMI].[Omni_Channel_Data]
(
[Date]       [DATE] NOT NULL,
[Category]   [VARCHAR](100) NULL,
[Data]       [VARCHAR](100) NOT NULL,
[TimeFrame]  [VARCHAR](100) NOT NULL,
[ValueCY]    [VARCHAR](100) NULL,
[ValueLY]    [VARCHAR](100) NULL,
[YoY%]       [VARCHAR](100) NULL,
[RunDate]    [DATETIME] NOT NULL 
CONSTRAINT PK_Omni_Channel_Data PRIMARY KEY NONCLUSTERED ([Date],[TimeFrame],[Data]) NOT ENFORCED
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO


--OPERATIONAL DATA

CREATE TABLE [SS_BUKMI].[Operational_Data]
(
[Metric] VARCHAR(225) NOT NULL,
[Date] DATE NOT NULL,
[Value] DECIMAL(18,4) NULL,
[%Osat] DECIMAL(18,4) NULL,
[LY] DECIMAL(18,4) NULL,
[%Diff] DECIMAL(18,4) NULL,
[KPIIndex] VARCHAR(100) NULL,
[RunDate] DATETIME NOT NULL
CONSTRAINT PK_Operational_Data PRIMARY KEY NONCLUSTERED ([Date],[Metric]) NOT ENFORCED

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO



CREATE TABLE [SS_BUKMI].[Operational_Gauge]
(
[Date] DATE NOT NULL,
[Min] INT NOT NULL,
[Max] INT NOT NULL,
[TargetStart] INT NOT NULL,
[TargetEnd] INT NOT NULL,
[ActualStart] INT NOT NULL,
[ActualEnd] INT NOT NULL,
[PointerValue] INT NULL,
[Percentage] DECIMAL(24,10) NULL,
[RunDate] DATETIME NOT NULL
CONSTRAINT PK_Operational_Gauge PRIMARY KEY NONCLUSTERED ([Date]) NOT ENFORCED)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO



CREATE TABLE [SS_BUKMI].[Operational_Date]
(
[Date] DATE NOT NULL,
[FiscalMonth] VARCHAR(100) NULL,
[FiscalYear] VARCHAR(100) NULL,
[RunDate] DATETIME NOT NULL
CONSTRAINT PK_Operational_Date PRIMARY KEY NONCLUSTERED ([Date]) NOT ENFORCED)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO
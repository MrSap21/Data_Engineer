/*
************************************************************************************************************

Script Name                          : Create_PSB_Version2.0
Purpose                              : Create TABLE Script 
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description

==========================================================================================================================
13-Dec-2021   :  Arindam Pathak        :  Create_PSB_Version2.0 

**************************************************************************************************************************

*/





CREATE TABLE SER_PHARMACEUTICALS.PharmacyServiceBillingTransaction
(
TransactionDate					Date			,
SiteSourceKey					VARCHAR(4)		,
ServiceContractId				INT				,
ServiceContractSnapshotId		INT				,
ServiceId						INT				,
ServiceSnapshotId				INT				,
PSBTransactionLineItemType		VARCHAR(1)		,
ArticleCode						VARCHAR(18)		,
PharmacyServiceBillingSubType	VARCHAR(2)		,
SnapshotId						INT		 		,
PharmacyServiceBillingFeeId		INT		 		,
MedicinalProductId				INT		 		,
VATCode							VARCHAR(5)		,
ProductDescription				NVARCHAR(60) COLLATE Latin1_General_100_CI_AI_KS_WS NULL		,
PSBListPriceAmount				DECIMAL(17,2)	,
TaxInclusiveSalePrice			DECIMAL(17,2)	,
TaxExclusiveSalePrice			DECIMAL(17,2)	,
IsoCurrencyCode					VARCHAR(5)		,
Quantity						DECIMAL(17,3)	,
UnitOfMeasureId					VARCHAR(3)	 	,
PackQuantity					INT		 		,
UnitQuantityInPack				INT		 		,
ClaimedDate						DATE		 	,
RunDateTime					DATETIME 		,
	Year 						VARCHAR(4) 		,
	Month						VARCHAR(2) 		,
	Day 						VARCHAR(2) 		,
	SourceSystemID 				INT 			,	
	LOVRECORDSOURCEID	    	INT           	,
	SCDSTARTDATE	        	DATETIME      	,
	SCDENDDATE	            	DATETIME      	,
	SCDACTIVEFLAG	        	VARCHAR(1)    	,
	SCDVERSION              	INT           	,
	SCDLOVRECORDSOURCEID    	INT           	,
	ETLRUNLOGID         		INT           	
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
);


GO

CREATE TABLE SER_PHARMACEUTICALS.ServiceContract
(
ServiceContractId				INT				,
SnapshotId						INT				,
ServiceContractName				NVARCHAR(60)	COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
ServiceContractCreationDate		DATE			,
ServiceContractStartDate		DATE			,
ServiceContractEndDate			DATE			,
ServiceContractExpirationDate	DATE			,
Commissioner					NVARCHAR(60)	COLLATE Latin1_General_100_CI_AI_KS_WS NULL	,
PaymentBodyId					NVARCHAR(10)	COLLATE Latin1_General_100_CI_AI_KS_WS NULL	,
ClaimFrequency					VARCHAR(10)		,
ClaimDueDays					INT				,
ClaimMethod						VARCHAR(2)		,
PurchaseOrderType				VARCHAR(2)		,
PurchaseOrderNumber				VARCHAR(20)		,
CountryCode						VARCHAR(3)		,
RunDateTime						DATETIME 		,
	Year 						VARCHAR(4) 		,
	Month						VARCHAR(2) 		,
	Day 						VARCHAR(2) 		,
	SourceSystemID 				INT 			,
	LOVRECORDSOURCEID	    	INT           	,
	SCDSTARTDATE	        	DATETIME      	,
	SCDENDDATE	            	DATETIME      	,
	SCDACTIVEFLAG	        	VARCHAR(1)    	,
	SCDVERSION              	INT           	,
	SCDLOVRECORDSOURCEID    	INT           	,
	ETLRUNLOGID         		INT           	
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
);


GO

CREATE TABLE SER_PHARMACEUTICALS.HealthService
(
ServiceId						INT				,
SnapshotId						INT				,
ServiceDescription				NVARCHAR(512)	COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
PatientContributionIndicator	VARCHAR(1)		,
FreeTextProductIndicator		VARCHAR(1)		,
WarningThreshold				INT				,
RunDateTime						DATETIME 		,
	Year 						VARCHAR(4) 		,
	Month						VARCHAR(2) 		,
	Day 						VARCHAR(2) 		,
	SourceSystemID 				INT 			,
	LOVRECORDSOURCEID	    	INT           	,
	SCDSTARTDATE	        	DATETIME      	,
	SCDENDDATE	            	DATETIME      	,
	SCDACTIVEFLAG	        	VARCHAR(1)    	,
	SCDVERSION              	INT           	,
	SCDLOVRECORDSOURCEID    	INT           	,
	ETLRUNLOGID         		INT           	

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
);


GO


CREATE TABLE SER_PHARMACEUTICALS.PharmacyServiceBillingFee
(
PharmacyServiceBillingFeeId				INT				,
PharmacyServiceBillingFeeType			VARCHAR(1)		,
SnapshotId								INT				,
PharmacyServiceBillingFeeDescription	NVARCHAR(60)		COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
ArticleCode								VARCHAR(18)		,
PriceTypeId								VARCHAR(2)		,
CentreDefinedPrice						DECIMAL(19,2)	,
IsoCurrencyCode							VARCHAR(5)		,
VATCode									VARCHAR(5)		,
WarningThreshold						INT				,
MedicinalProductId						VARCHAR(10)		,
RunDateTime						DATETIME 		,
	Year 						VARCHAR(4) 		,
	Month						VARCHAR(2) 		,
	Day 						VARCHAR(2) 		,
	SourceSystemID 				INT 			,
	LOVRECORDSOURCEID	    	INT           	,
	SCDSTARTDATE	        	DATETIME      	,
	SCDENDDATE	            	DATETIME      	,
	SCDACTIVEFLAG	        	VARCHAR(1)    	,
	SCDVERSION              	INT           	,
	SCDLOVRECORDSOURCEID    	INT           	,
	ETLRUNLOGID         		INT           	

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
);


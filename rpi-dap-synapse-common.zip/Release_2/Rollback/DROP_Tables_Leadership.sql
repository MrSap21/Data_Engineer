/*
**************************************************************************************************************************

Script Name                          : DROP_Tables_Leadership
Purpose                              : DROP Tables for Leadership Consumption Layer
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description
==========================================================================================================================

**************************************************************************************************************************

*/

-- EXEC SCORECARD
DROP TABLE [SS_BUKMI].[Exec_Monthly_Data];

DROP TABLE [SS_BUKMI].[Exec_Weekly_Data];

DROP TABLE [SS_BUKMI].[Exec_Date];

--OMNI CHANNEL
DROP TABLE [SS_BUKMI].[Omni_Channel_Data];

--OPERATIONAL DATA

DROP TABLE [SS_BUKMI].[Operational_Data];

DROP TABLE [SS_BUKMI].[Operational_Gauge];

DROP TABLE [SS_BUKMI].[Operational_Date];

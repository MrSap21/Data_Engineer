/*
************************************************************************************************************

Script Name                          : DROP_PAT_TABLE_Version4.0
Purpose                              : DROP TABLE Script 
***************************************************************************************** 

*/





DROP TABLE SER_PHARMACEUTICALS.CreditClaim;

DROP TABLE SER_PHARMACEUTICALS.StoreStockTransaction;

/*
**************************************************************************************************************************

Script Name                          : Drop_Tables_DORA_and_SSV
Purpose                              : DROP TABLEs for Consumption Layer
***************************************************************************************** 
Modification History

*/




--DORA 

DROP TABLE [con_dwh].[SS_DIM_DORA_HEX_CATCHMENTS];
  

DROP TABLE [con_dwh].[SS_FACT_CUSTOMER_AGE_GROUP_PROFILE];
   

DROP TABLE [con_dwh].[SS_FACT_MARKET_SHARE_YLY];
   

DROP TABLE [con_dwh].[SS_FACT_STORE_SALES_WLY];
   

DROP TABLE [con_dwh].[SS_DIM_PLANOGRAM];
   
DROP TABLE [con_dwh].[SS_FACT_PLANOGRAM_WLY];
   

--SSV

DROP TABLE [con_dwh].[SS_DIM_DATE_SVOS_YEAR]; 
   
DROP TABLE [con_dwh].[SS_DIM_STORE_OPENING_TIME];
   
DROP TABLE [con_dwh].[SS_FACT_TRADING_YLY];
   

DROP TABLE [con_dwh].[SS_DIM_STORE];
   
DROP TABLE [con_dwh].[SS_DIM_STORE_RELATION_MAPPING];
   
/*
************************************************************************************************************
Script Name : Drop_Table_SAP_BW
Purpose : Drop Table Script for SAP BW tables [ Consolidate alter script v1.0,v2.0,v3.0,v4.0 & v5.0]
*****************************************************************************************
Modification History
**************************************************************************************************************************
DATE : Modified By : Description
==========================================================================================================================


/* Drop Script For BudgetStockMovements */

DROP TABLE [SER_RETAIL].[BudgetStockMovements];

/* Drop Script For ForecastStockMovements */

DROP TABLE [SER_RETAIL].[ForecastStockMovements];


/* Drop Script For PharmacyStockMovements*/

DROP TABLE [SER_RETAIL].[PharmacyStockMovements];

/* Drop Script For COGSStockMovements*/

DROP TABLE [SER_RETAIL].[COGSStockMovements];

/* Drop Script For OrderPlaced*/

DROP TABLE [SER_RETAIL].[OrderPlaced];

/* Drop Script For OrderEOD*/

DROP TABLE [SER_RETAIL].[OrderEOD];

/* Drop Script For CustomerSurveyHeader*/

DROP TABLE [SER_RETAIL].[CustomerSurveyHeader];
/* Drop Script For CustomerSurveyDetail*/

DROP TABLE [SER_RETAIL].[CustomerSurveyDetail];


/* Drop Script For WeeklyLabourCostReportingActual*/

DROP TABLE [SER_RETAIL].[WeeklyLabourCostReportingActual];


/* Drop Script For StatisticalKeyFigures*/

DROP TABLE [SER_RETAIL].[StatisticalKeyFigures]
(
FiscalYearPerPeriod			Varchar	(7)   	NULL,
UnitOfMeasure				Varchar(3)   	NULL,
ProfitCenter				Varchar(10)   	NULL,
CostCenter					Varchar(10)   	NULL,
CompanyCode					Varchar(4)  	NULL,
TransactionType				Varchar(1)  	NULL,
PharmacyAccountingGroup		Varchar(3)  	NULL,
StatisticalKeyFigure		Varchar(6)  	NULL,
Version						Varchar(3)  	NULL,
InventoryQuantity			Decimal(17,2)   NULL,
Quantity					Decimal(17,2)   NULL,
RunDateTime					DATETIME 		NULL,
[Year] 						Varchar(4) 		NULL,
[Month]						Varchar(2) 		NULL,
[Day] 						Varchar(2) 		NULL,
SourceSystemID 				INT 			NULL,
LOVRECORDSOURCEID	    	INT             NULL,
SCDSTARTDATE	        	DATETIME        NULL,
SCDENDDATE	            	DATETIME        NULL,
SCDACTIVEFLAG	        	VARCHAR(1)      NULL,
SCDVERSION              	INT             NULL,
SCDLOVRECORDSOURCEID    	INT             NULL,
ETLRUNLOGID         		INT             NULL
)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO


/* Drop Script For WeeklyLabourCostReportingBudget*/

DROP TABLE [SER_RETAIL].[WeeklyLabourCostReportingBudget]
(
PayGroup                   Varchar(4)    NULL,
JobTitle                   Varchar(5)    NULL,
ValueType                  Varchar(3)    NULL,
Version                    Varchar(3)    NULL,
GeneralLedgerAccount       Varchar(10)   NULL,
Amount                     DECIMAL(17,2) NULL,
Currency                   Varchar(5)    NULL,
CompanyCode                Varchar(4)    NULL,
WeekendDate                Date    		 NULL,
PayElementId               Varchar(4)    NULL,
WLCRTransferType           Varchar(1)    NULL,
WLCRTransferDetail         Varchar(1)    NULL,
RoleFlag                   Varchar(1)    NULL,
ReportingLevel             Varchar(5)    NULL,
CostCenter                 Varchar(10)   NULL,
RunDateTime                DATETIME      NULL,
[Year]                     Varchar(4)    NULL,
[Month]                    Varchar(2)    NULL,
[Day]                      Varchar(2)    NULL,
SourceSystemID             INT    		 NULL,
LOVRecordSourceID          INT    		 NULL,
SCDStartDate               DateTime      NULL,
SCDEndDate                 DateTime      NULL,
SCDActiveFlag              VARCHAR(1)    NULL,
SCDVersion                 INT    		 NULL,
SCDLOVRecordSourceID       INT    		 NULL,
ETLRunLogID                INT    		 NULL
)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO
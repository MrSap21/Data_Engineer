/*
************************************************************************************************************

Script Name                          : DROP_TABLE_PSB_Version2.0
Purpose                              : DROP TABLE Script 
***************************************************************************************** 
*********************************************************************************************************************

*/





DROP TABLE SER_PHARMACEUTICALS.PharmacyServiceBillingTransaction;

DROP TABLE SER_PHARMACEUTICALS.ServiceContract;

DROP TABLE SER_PHARMACEUTICALS.HealthService;

DROP TABLE SER_PHARMACEUTICALS.PharmacyServiceBillingFee;


/*
************************************************************************************************************
Script Name : Create_SAP_BW_CreateScript_v2.0
Purpose : Create Table Script for SAP BW tables [ Consolidate alter script v1.0,v2.0,v3.0,v4.0 & v5.0]
*****************************************************************************************
Modification History
**************************************************************************************************************************
DATE : Modified By : Description
==========================================================================================================================
13-Dec-2021 : Pandiarajan & Arindam: 
06-May=2022 : Anisoor : Synced the DDL to include the changes made by Alter_SAPBW_Version5.0.sql script.

***************************************************************************************************************************/



/* Create Script For BudgetStockMovements */

CREATE TABLE [SER_RETAIL].[BudgetStockMovements]
(
WeekEndingDate          Date          NULL,
ReportingGroup          Varchar(10)   NULL,
SiteSourceKey           Varchar(4)    NULL,
BudgetStockValue        DECIMAL(17,4) NULL,
RunDateTime             DateTime      NULL,
[Year]                  varchar(4)    NULL,
[Month]                 varchar(2)    NULL,
[Day]                   varchar(2)    NULL,
SourceSystemID          int           NULL,
LOVRecordSourceID	    int           NULL,
SCDStartDate	        DateTime      NULL,
SCDEndDate	            DateTime      NULL,
SCDActiveFlag	        Varchar(1)    NULL,
SCDVersion              int           NULL,
SCDLOVRecordSourceID    int           NULL,
ETLRunLogID         	int           NULL

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO


/* Create Script For ForecastStockMovements */

CREATE TABLE [SER_RETAIL].[ForecastStockMovements]
(
WeekEndingDate       Date            NULL,
ReportingGroup       Varchar(10)     NULL,
SiteSourceKey        Varchar(4)      NULL,
ForecastStockValue   DECIMAL(17,4)   NULL,
RunDateTime          DateTime        NULL,
[Year]               varchar(4)      NULL,
[Month]              varchar(2)      NULL,
[Day]                varchar(2)      NULL,
SourceSystemID       int             NULL,
LOVRecordSourceID	 int             NULL,
SCDStartDate	     DateTime        NULL,
SCDEndDate	         DateTime        NULL,
SCDActiveFlag	     Varchar(1)      NULL,
SCDVersion           int             NULL,
SCDLOVRecordSourceID int             NULL,
ETLRunLogID	         int             NULL

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO


/* Create Script For PharmacyStockMovements*/

CREATE TABLE [SER_RETAIL].[PharmacyStockMovements]
(
WeekEndingDate        Date            NULL,
ReportingGroup        Varchar(10)     NULL,
SiteSourceKey         Varchar(4)      NULL,
PharmacyStockValue    DECIMAL(17,4)   NULL,
RunDateTime           DateTime        NULL,
[Year]                varchar(4)      NULL,
[Month]               varchar(2)      NULL,
[Day]                 varchar(2)      NULL,
SourceSystemID        int             NULL,
LOVRecordSourceID	  int             NULL,
SCDStartDate	      DateTime        NULL,
SCDEndDate	          DateTime        NULL,
SCDActiveFlag	      Varchar(1)      NULL,
SCDVersion            int             NULL,
SCDLOVRecordSourceID  int             NULL,
ETLRunLogID	          int             NULL

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO


/* Create Script For COGSStockMovements*/

CREATE TABLE [SER_RETAIL].[COGSStockMovements]
(
WeekEndingDate       Date            NULL,
ReportingGroup       Varchar(10)     NULL,
COGSStockValue       DECIMAL(17,4)   NULL,
RunDateTime          DateTime        NULL,
[Year]               varchar(4)      NULL,
[Month]              varchar(2)      NULL,
[Day]                varchar(2)      NULL,
SourceSystemID       int             NULL,
LOVRecordSourceID	 int             NULL,
SCDStartDate	     DateTime        NULL,
SCDEndDate	         DateTime        NULL,
SCDActiveFlag	     Varchar(1)      NULL,
SCDVersion           int             NULL,
SCDLOVRecordSourceID int             NULL,
ETLRunLogID	         int             NULL

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO


/* Create Script For OrderPlaced*/

CREATE TABLE [SER_RETAIL].[OrderPlaced]
(
SiteSourceKey                Varchar(4)      NULL,
ISOCurrencyCode              Varchar(5)      NULL,
CountryCode                  Varchar(3)      NULL,
PoNumber                     Varchar(14)     NULL,
OriginalOrderNumber          Varchar(9)      NULL,
DistributionChannelID        Varchar(10)      NULL,
SalesChannelID               Varchar(2)      NULL,
OrderMessageContent          Varchar(1)      NULL,
OrderTypeID                  Varchar(1)      NULL,
OrderEntryDate               Date            NULL,
TimeOrderPlaced              Varchar(10)     NULL,
CancellationReason           NVarchar(30)    COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
OrderCommitedDeliveryDate    Date            NULL,
OrderActualDeliveryDate      Date            NULL,
DeliveryPromise              Varchar(16)     COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
DeliverySite                 Varchar(1)      NULL,
OrderFromStore               Varchar(4)      NULL,
CFSStoreNumber               Varchar(4)      NULL,
PODRequired                  Varchar(1)      NULL,
Over18PODRequired            Varchar(1)      NULL,
AerosolIncluded              Varchar(1)      NULL,
TenderType1                  Varchar(25)     NULL,
CreditCardType1              Varchar(20)     NULL,
TenderType2                  Varchar(20)     NULL,
CreditCardType2              Varchar(20)     NULL,
TotalShippingChargeAmount    DECIMAL(28,2)   NULL,
DeliveryChargeCurr           Varchar(3)      NULL,
OrderTotalAmount             DECIMAL(17,2)   NULL,
OrderLevelDiscount           DECIMAL(28,2)   NULL,
OrderLevelDealNumber         Varchar(4)      NULL,
OrderLeveDealName            Varchar(10)     NULL,
OrderLevelMediaCo            Varchar(20)     NULL,
TotalOrderDiscount           DECIMAL(17,2)   NULL,
CustomerCardNumber           Varchar(25)     NULL,
CustomerIdentificationID     Varchar(20)     NULL,
StaffDiscount                Varchar(1)      NULL,
DeliveryWeight               Varchar(1)      NULL,
Material                     Varchar(18)     NULL,
OldArticle                   Varchar(18)     NULL,
TotalOrderWeight             DECIMAL(17,2)   NULL,
WeightUomID                  Varchar(3)      NULL,
NormalSalesValue             DECIMAL(17,2)   NULL,
DiscountValue                DECIMAL(17,2)   NULL,
SalesRetailValue             DECIMAL(17,2)   NULL,
OrderLineValue               DECIMAL(17,2)   NULL,
TotalOrderLineDiscount       DECIMAL(17,2)   NULL,
TotalOrderLineValue          DECIMAL(17,2)   NULL,
TaxesinRetailValue           Varchar(1)      NULL,
DealNumber                   Varchar(4)      NULL,
DealType                     Varchar(10)     NULL,
ItemLevelMediaCOD            Varchar(20)     NULL,
NumberofPointaddition        INT             NULL,
NumberofExtraAdva            INT             NULL,
GiftBoxedItem                Varchar(1)      NULL,
CurrencyCode                 Varchar(5)      NULL,
DocumentCurrency             Varchar(5)      NULL,
TransactionType              Varchar(4)      NULL,
PostingDate                  Date            NULL,
StartTime                    Varchar(10)     NULL,
TenderValue                  DECIMAL(17,2)   NULL,
MeansofPayment               Varchar(4)      NULL,
LocationZipCode              Varchar(10)     NULL,
DisabledCustomerCA           Varchar(1)      NULL,
MiVirtualBundleFl            Varchar(1)      NULL,
RunDateTime                  DateTime        NULL,
[Year]                       varchar(4)      NULL,
[Month]                      varchar(2)      NULL,
[Day]                        varchar(2)      NULL,
SourceSystemID               int             NULL,
LOVRecordSourceID	         int             NULL,
SCDStartDate	             DateTime        NULL,
SCDEndDate	                 DateTime        NULL,
SCDActiveFlag	             Varchar(1)      NULL,
SCDVersion                   int             NULL,
SCDLOVRecordSourceID         int             NULL,
ETLRunLogID	                 int             NULL
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO



/* Create Script For OrderEOD*/

CREATE TABLE [SER_RETAIL].[OrderEOD]
(
SiteSourceKey                   Varchar(4)   NULL,
ISOCurrencyCode                 Varchar(5)   NULL,
CountryCode                     Varchar(3)   NULL,
DistributionChannelID           Varchar(5)   NULL,
SalesChannelID                  Varchar(2)   NULL,
OrderTypeID                     Varchar(1)   NULL,
DeliverySite                    Varchar(1)   NULL,
OrderFromStore                  Varchar(4)   NULL,
TenderType1                     Varchar(20)   NULL,
TenderType2                     Varchar(20)   NULL,
TotalShippingChargeAmount       DeCIMAL(28,6)   NULL,
SalesUnit                       Varchar(3)   NULL,
TransactionType                 Varchar(4)   NULL,
PostingDate                     Date   NULL,
StartTime                       Varchar(6)   NULL,
TenderValue                     DECIMAL(17,2)   NULL,
EODTotalByPaypal                DECIMAL(17,2)   NULL,
EODTotalByAMEX                  DECIMAL(17,2)   NULL,
EODTotalByVISA                  DECIMAL(17,2)   NULL,
EODTotalByMasterCard            DECIMAL(17,2)   NULL,
EODTotalByDebitCard             DECIMAL(17,2)   NULL,
EODTotalAllISO                  DECIMAL(17,2)   NULL,
EODTotalPaidbyCheque            DECIMAL(17,2)   NULL,
EODTotalbyCreditAcc             DECIMAL(17,2)   NULL,
EODTotalGiftVoucher             DECIMAL(17,2)   NULL,
EODTotalbyPoints                DECIMAL(17,2)   NULL,
EODTotalbyCoupon                DECIMAL(17,2)   NULL,
EODTotalsByCard                 DECIMAL(17,2)   NULL,
EODTotalBrandCoupon             DECIMAL(17,2)   NULL,
EODCapIncenBond                 DECIMAL(17,2)   NULL,
EODTotalByCash                  DECIMAL(17,2)   NULL,
EODHighStreetVoucher            DECIMAL(17,2)   NULL,
EODTotalbyBonus                 DECIMAL(17,2)   NULL,
EODTotalByluncheo               DECIMAL(17,2)   NULL,
EODSodexhoVoucher               DECIMAL(17,2)   NULL,
EODTotalByNet                   DECIMAL(17,2)   NULL,
Currency                        Varchar(5)   NULL,
DocumentCurrency                Varchar(5)   NULL,
RunDateTime                     DateTime   NULL,
Year                            varchar(4)   NULL,
Month                           varchar(2)   NULL,
Day                             varchar(2)   NULL,
SourceSystemID                  int   NULL,
LOVRecordSourceID	            int NULL,
SCDStartDate	                DateTime NULL,
SCDEndDate	                    DateTime NULL,
SCDActiveFlag	                Varchar(1) NULL,
SCDVersion                      int NULL,
SCDLOVRecordSourceID            int NULL,
ETLRunLogID	                    int NULL

)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
GO

/* Create Script For CustomerSurveyHeader*/

CREATE TABLE [SER_RETAIL].[CustomerSurveyHeader]
(
SurveyId				Varchar(255)	NULL,
CouponNumber			Varchar(50)		NULL,
SiteSourceKey			Varchar(4)		NULL,
VisitDate				Varchar(25)		NULL,
ResponseDate			Varchar(25)		NULL,
CountryCode				Varchar(3)		NULL,
RunDateTime				DATETIME 		NULL,
[Year] 					Varchar(4) 		NULL,
[Month]					Varchar(2) 		NULL,
[Day] 					Varchar(2) 		NULL,
SourceSystemID 			INT 			NULL,
LOVRECORDSOURCEID	    INT           NULL,
SCDSTARTDATE	        DATETIME      NULL,
SCDENDDATE	            DATETIME      NULL,
SCDACTIVEFLAG	        VARCHAR(1)    NULL,
SCDVERSION              INT           NULL,
SCDLOVRECORDSOURCEID    INT           NULL,
ETLRUNLOGID         	INT           NULL

)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO
/* Create Script For CustomerSurveyDetail*/

CREATE TABLE [SER_RETAIL].[CustomerSurveyDetail]
(
SurveyId				Varchar(255)	NULL,
QuestionId				Varchar(20)		NULL,
QuestionResponseText	NVarchar(4000)	COLLATE Latin1_General_100_CI_AI_KS_WS NULL,
RunDateTime				DATETIME 		NULL,
[Year] 					Varchar(4) 		NULL,
[Month]					Varchar(2) 		NULL,
[Day] 					Varchar(2) 		NULL,
SourceSystemID 			INT 			NULL,
LOVRECORDSOURCEID	    INT           	NULL,
SCDSTARTDATE	        DATETIME      	NULL,
SCDENDDATE	            DATETIME      	NULL,
SCDACTIVEFLAG	        VARCHAR(1)    	NULL,
SCDVERSION              INT           	NULL,
SCDLOVRECORDSOURCEID    INT           	NULL,
ETLRUNLOGID         	INT           	NULL

)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = HASH(QuestionId)
);
GO


/* Create Script For WeeklyLabourCostReportingActual*/

CREATE TABLE [SER_RETAIL].[WeeklyLabourCostReportingActual]
(
PayGroup				Varchar	(4) 	NULL,
EmployeeId				Varchar(255) 	NULL,
EmployeeTitle			Varchar(255) 	NULL,
EmployeeFirstName		Varchar(255) 	NULL,
EmployeeLastName		Varchar(255) 	NULL,
JobTitle				Varchar(5) 		NULL,
GeneralLedgerAcoount	Varchar(10) 	NULL,
WLCRDataCode			Varchar(1)    	NULL,
Amount					Decimal(17,2) 	NULL,
Currency				Varchar(5) 		NULL,
CompanyCode				Varchar(4) 		NULL,
WeekendDate				Varchar(10) 	NULL,
PayElementId			Varchar(4) 		NULL,
WLCRTransferType		Varchar(1)    	NULL,
WLCRTransferDetail		Varchar(1)    	NULL,
RoleFlag				Varchar(1) 		NULL,
ReportingLevel			Varchar(5) 		NULL,
CostCenter				Varchar(10) 	NULL,
RunDateTime				DATETIME 		NULL,
[Year] 					Varchar(4) 		NULL,
[Month]					Varchar(2) 		NULL,
[Day] 					Varchar(2) 		NULL,
SourceSystemID 			INT 			NULL,
LOVRECORDSOURCEID	    INT           	NULL,
SCDSTARTDATE	        DATETIME      	NULL,
SCDENDDATE	            DATETIME      	NULL,
SCDACTIVEFLAG	        VARCHAR(1)    	NULL,
SCDVERSION              INT           	NULL,
SCDLOVRECORDSOURCEID    INT           	NULL,
ETLRUNLOGID         	INT           	NULL
)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO


/* Create Script For StatisticalKeyFigures*/

CREATE TABLE [SER_RETAIL].[StatisticalKeyFigures]
(
FiscalYearPerPeriod			Varchar	(7)   	NULL,
UnitOfMeasure				Varchar(3)   	NULL,
ProfitCenter				Varchar(10)   	NULL,
CostCenter					Varchar(10)   	NULL,
CompanyCode					Varchar(4)  	NULL,
TransactionType				Varchar(1)  	NULL,
PharmacyAccountingGroup		Varchar(3)  	NULL,
StatisticalKeyFigure		Varchar(6)  	NULL,
Version						Varchar(3)  	NULL,
InventoryQuantity			Decimal(17,2)   NULL,
Quantity					Decimal(17,2)   NULL,
RunDateTime					DATETIME 		NULL,
[Year] 						Varchar(4) 		NULL,
[Month]						Varchar(2) 		NULL,
[Day] 						Varchar(2) 		NULL,
SourceSystemID 				INT 			NULL,
LOVRECORDSOURCEID	    	INT             NULL,
SCDSTARTDATE	        	DATETIME        NULL,
SCDENDDATE	            	DATETIME        NULL,
SCDACTIVEFLAG	        	VARCHAR(1)      NULL,
SCDVERSION              	INT             NULL,
SCDLOVRECORDSOURCEID    	INT             NULL,
ETLRUNLOGID         		INT             NULL
)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO


/* Create Script For WeeklyLabourCostReportingBudget*/

CREATE TABLE [SER_RETAIL].[WeeklyLabourCostReportingBudget]
(
PayGroup                   Varchar(4)    NULL,
JobTitle                   Varchar(5)    NULL,
ValueType                  Varchar(3)    NULL,
Version                    Varchar(3)    NULL,
GeneralLedgerAccount       Varchar(10)   NULL,
Amount                     DECIMAL(17,2) NULL,
Currency                   Varchar(5)    NULL,
CompanyCode                Varchar(4)    NULL,
WeekendDate                Date    		 NULL,
PayElementId               Varchar(4)    NULL,
WLCRTransferType           Varchar(1)    NULL,
WLCRTransferDetail         Varchar(1)    NULL,
RoleFlag                   Varchar(1)    NULL,
ReportingLevel             Varchar(5)    NULL,
CostCenter                 Varchar(10)   NULL,
RunDateTime                DATETIME      NULL,
[Year]                     Varchar(4)    NULL,
[Month]                    Varchar(2)    NULL,
[Day]                      Varchar(2)    NULL,
SourceSystemID             INT    		 NULL,
LOVRecordSourceID          INT    		 NULL,
SCDStartDate               DateTime      NULL,
SCDEndDate                 DateTime      NULL,
SCDActiveFlag              VARCHAR(1)    NULL,
SCDVersion                 INT    		 NULL,
SCDLOVRecordSourceID       INT    		 NULL,
ETLRunLogID                INT    		 NULL
)WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

GO
/*
**************************************************************************************************************************

Script Name                          : Create_Tables_Likelihood_To_Return_v1.0_WIP
Purpose                              : Create Tables for Consumption Layer
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description
==========================================================================================================================
01-Dec-2021   :   Anisoor Rahman        : Draft version of create tables script for Likelihood To Return
15-Dec-2021   :   Anisoor Rahman        : Column renamed, data type changed from [COUNTRY_P_KEY] [VARCHAR] (3) to [COUNTRY_CODE_P_KEY] [CHAR] (2)
15-Dec-2021   :   Anisoor Rahman        : Column renamd from CUSTOMERS to CUSTOMER_COUNT
15-Dec-2021   :   Anisoor Rahman        : Distribution type changed from HASH to ROUND ROBIN
19-Jan-2022   :   Anisoor Rahman        : Data Length for COUNTRY_CODE_P_KEY has been changed from 2 to 3
19-Jan-2022   :   Anisoor Rahman        : Primary Key Constraint have been removed from the script as per Kannan's comments
19-Jan-2022   :   Anisoor Rahman        : CUSTOMER_COUNT has been set to NOT NULL
**************************************************************************************************************************

*/

CREATE TABLE [con_dwh].[RPT_LIKELIHOOD_TO_RETURN]
    (
     [REPORTING_COUNTRY_CODE_P_KEY] [CHAR] (3) NOT NULL ,
	 [VISIT_YEAR_MONTH_P_KEY] [INT] NOT NULL ,
	 [RETURN_YEAR_MONTH_P_KEY] [INT] NOT NULL ,
	 [CUSTOMER_COUNT] [INT] NOT NULL ,
	 [CREATE_DATETIME] [DATETIME2] NOT NULL ,
	 [UPDATE_DATETIME] [DATETIME2] NULL
)
WITH 
(
    DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);
GO





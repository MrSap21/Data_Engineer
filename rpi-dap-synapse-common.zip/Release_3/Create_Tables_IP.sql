/*
***************************************************************************************************************************

Script Name                          : Create_Tables_IP_v1.0_WIP
Purpose                              : Draft version DDL for Consumption Layer tables for Internal Performance Report 
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date            :      Modified By                      : Description

==========================================================================================================================
22-Jan-2022    :		Daffrin Jeyapraba			         : Create_Tables_IP_v1.0_WIP
06-Dec-2022	   :		Daffrin Jeyapraba					 : Rationalised the data length
19-Dec-2022    :		Daffrin Jeyapraba				     : AddED new columns PRODUCT_NAME,LADDER_ID,BRAND,SALES_TYPE,LADDER_WITH_OTHERS,
															   BRAND_WITH_OTHERS	in RPT_INTERNAL_PERFORMANCE_MAIN
															   Updated Columns in DIM_CHANNEL Table
20-Dec-2022	   :		Daffrin Jeyapraba					 : Removed primary key constraints 
24-Dec-2022	   :		Daffrin Jeyapraba					 : Added new table RPT_INTERNAL_PERFORMNCE_STORE
03-Feb-2022	   :		Daffrin Jeyapraba					 : Updated DIM_INTERNAL_PERFORMANCE_SALES_LOCATION table with latest update on the LDM
11-Feb-2022    :        Rajadeepika                          : Updated nullable columns to Not null except UPDATE_DATETIME as per Kannan's review
15-Feb-2022    :        Daffrin Jeyapraba                    : Updated columns names 
                                                                FROM CUMULATIVE_UNITS_PERCENT to 'TOTAL_CUMULATIVE_UNITS_PERCENT' ,
                                                                FROM CUMULATIVE_TESP_PERCENT TO 'TOTAL_CUMULATIVE_TESP_PERCENT' IN RPT_INTERNAL_PERFORMANCE_PARETO
                                                                FROM TESP_LY                TO 'TOTAL_TESP_LY' ,
                                                                FROM TESP_TY                TO 'TOTAL_TESP_LY' ,
                                                                FROM PROFIT_LY              TO 'TOTAL_PROFIT_LY',
                                                                FROM PROFIT_TY              TO 'TOTAL_PROFIT_TY',
                                                                FROM UNITS_LY               TO 'TOTAL_UNITS_LY' ,
                                                                FROM UNITS_TY               TO 'TOTAL_UNITS_TY'                     IN STG_UK_MARGIN_SCALC                                                                                   FROM UNITS_LY               TO 'TOTAL_UNITS_LY' ,
                                                                FROM UNITS_TY               TO 'TOTAL_UNITS_TY' ,
                                                                FROM UNITS_CHANGE           TO  TOTAL_UNITS_CHANGE,
                                                                FROM TESP_TY                TO 'TOTAL_TESP_TY',
                                                                FROM TESP_LY                TO 'TOTAL_TESP_TY'                  
                                                                FROM TESP_CHANGE            TO 'TOTAL_TESP_CHANGE'                 IN   RPT_INTERNAL_PERFORMANCE_STORE
                                                                FROM BRAND_VALUE            TO 'TOTAL_BRAND_VALUE'
                                                                FROM BRAND_SKUS_WITH_CPI    TO 'TOTAL_BRAND_SKUS_WITH_CPI'          IN RPT_INTERNAL_PERFORMANCE_MAIN
                                                               Updated data type for the below columns 
                                                                PRODUCT_TYPE_P_KEY IN RPT_INTERNAL_PERFORMANCE_MAIN, 
                                                                PRODUCT_TYPE_PLUS_LY_P_KEY  in RPT_INTERNAL_PERFORMANCE_WATERFALL,
                                                                STORE_FORMAT_P_KEY,STORE_TYPE_P_KEY,PRODUCT_SOURCE_KEY_P_KEY in RPT_INTERNAL_PERFORMANCE_STORE,
                                                                SS_RETROS_LY,SS_RETROS_TY,ADJUSTED_PROFIT_LY,ADJUSTED_PROFIT_TY,ADJUSTED_MARGIN_LY,ADJUSTED_MARGIN_TY  in
                                                                STG_UK_MARGINS_CALC 

*************************************************************************************************************************

*/

CREATE TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_MAIN] 
    ( 
 [TIME_PERIOD]						[VARCHAR] (40)	NOT NULL
,[CALENDAR_YEAR_WEEK]				[INT] 			NOT NULL
,[PRODUCT_SOURCE_KEY_P_KEY]			[NVARCHAR] (30) NOT NULL
,[REPORTING_COUNTRY_CODE_P_KEY]		[CHAR] 		(3)	NOT NULL
,[PRODUCT_TYPE_P_KEY]				[NVARCHAR] (20)	NOT NULL
,[SALES_LOCATION_S_KEY]				[INT] NOT NULL
,[PRODUCT_NAME]					    [NVARCHAR] (100) NOT NULL
,[LADDER_ID]						[NVARCHAR] (30) NOT NULL
,[BRAND]							[NVARCHAR] (50) NOT NULL
,[SALES_TYPE]						[VARCHAR] (20)  NOT NULL
,[LADDER_WITH_OTHERS]				[NVARCHAR] (30) NOT NULL
,[BRAND_WITH_OTHERS]				[NVARCHAR] (50) NOT NULL
,[DISTRIBUTION_STORE_COUNT]			[INT]           NOT NULL
,[TOTAL_BRAND_VALUE]						[DECIMAL] (18,4) 	NOT NULL
,[TOTAL_BRAND_SKUS_WITH_CPI]				[INT]	NOT NULL
,[AVERAGE_CPI]								[DECIMAL] (28,10)	 NOT NULL
,[MIN_CPI_1_SKUS]						[INT]   NOT NULL
,[MIN_CPI_1_TESP]						[DECIMAL] (18,4)	 NOT NULL
,[MIN_CPI_2_SKUS]						[INT]   NOT NULL
,[MIN_CPI_2_TESP]						[DECIMAL] (18,4)     NOT NULL
,[MIN_CPI_3_SKUS]						[INT]  NOT  NULL
,[MIN_CPI_3_TESP]						[DECIMAL] (18,4)    NOT NULL
,[MIN_CPI_4_SKUS]						[INT]  NOT NULL
,[MIN_CPI_4_TESP]						[DECIMAL] (18,4) NOT NULL
,[TOTAL_TESP_TY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_TESP_YOY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_TESP_LY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_UNITS_TY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_UNITS_YOY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_UNITS_LY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_ADJUSTED_PROFIT_TY]		[DECIMAL] (18,4) NOT NULL
,[TOTAL_ADJUSTED_PROFIT_YOY]	[DECIMAL] (18,4) NOT NULL
,[TOTAL_ADJUSTED_PROFIT_LY]		[DECIMAL] (18,4) NOT NULL
,[ADJUSTED_MARGIN_TY]				[DECIMAL] (18,4) NOT NULL
,[ADJUSTED_MARGIN_LY]				[DECIMAL] (18,4) NOT NULL
,[CREATE_DATETIME] [DATETIME2] NOT NULL
,[UPDATE_DATETIME] [DATETIME2] NULL
)
WITH 
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
);
GO

CREATE TABLE [con_dwh].RPT_INTERNAL_PERFORMANCE_STORE (	
 [TIME_PERIOD]				[VARCHAR]   (40) NOT NULL
,[PRODUCT_SOURCE_KEY_P_KEY]	[NVARCHAR]  (30) NOT NULL
,[REPORTING_COUNTRY_CODE_P_KEY]			[CHAR]	    (3)	 NOT NULL
,[STORE_FORMAT_P_KEY]			[NVARCHAR]	(50) NOT NULL
,[STORE_TYPE_P_KEY]			[NVARCHAR]	(50) NOT NULL
,[SALES_LOCATION_TYPE_S_KEY]		[INT]    NOT NULL
,[TOTAL_UNITS_TY]					[DECIMAL]	(18,4) NOT NULL
,[TOTAL_UNITS_LY]					[DECIMAL]	(18,4) NOT NULL
,[TOTAL_UNITS_CHANGE]				[DECIMAL]	(18,4) NOT NULL
,[TOTAL_TESP_TY]						[DECIMAL]	(18,4) NOT NULL
,[TOTAL_TESP_LY]						[DECIMAL]	(18,4) NOT NULL
,[TOTAL_TESP_CHANGE]					[DECIMAL]	(18,4) NOT NULL
,[CREATE_DATETIME]				[DATETIME2] NOT NULL
,[UPDATE_DATETIME]				[DATETIME2]  NULL
)
WITH 
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
);
GO


CREATE TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_WATERFALL]
    (  
 [TIME_PERIOD] 						[VARCHAR]   (40)         NOT NULL
,[PRODUCT_SOURCE_KEY_P_KEY]			[NVARCHAR]	(30)		 NOT NULL
,[REPORTING_COUNTRY_CODE_P_KEY]		[CHAR]		(3)     	 NOT NULL
,[PRODUCT_TYPE_PLUS_LY_P_KEY]		[NVARCHAR]	(20) 		 NOT NULL	
,[SALES_LOCATION_TYPE_S_KEY]		[INT]			 		 NOT NULL
,[LADDER_PLUS_LY]					[NVARCHAR]	(30)		 NOT NULL
,[BRAND_PLUS_LY] 					[NVARCHAR]	(50)		 NOT NULL
,[TESP_AMOUNT]						[DECIMAL]	(18,4)   NOT NULL
,[UNITS_SOLD]						[DECIMAL]	(18,4)   NOT NULL
,[ADJUSTED_PROFIT]					[DECIMAL]	(18,4)  	 NOT NULL
,[CREATE_DATETIME] 					[DATETIME2] 			 NOT NULL
,[UPDATE_DATETIME] 					[DATETIME2] 			 NULL
)
WITH 
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
);
GO

CREATE TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_PARETO]
    (
[PRODUCT_SOURCE_KEY_P_KEY]			[NVARCHAR]	(30)	NOT NULL
,REPORTING_COUNTRY_CODE_P_KEY       CHAR(2)             NOT NULL  
,[SALES_LOCATION_VALUE_PLUS_ALL]			[VARCHAR]	(20)	NOT NULL
,[SALES_TYPE]						[VARCHAR]	(20)    NOT NULL
,[TOTAL_TESP_TY]					[DECIMAL]	(18,4)  NOT NULL
,[TOTAL_UNITS_TY]					[DECIMAL]	(18,4)  NOT NULL
,[ANNUALISED_TESP_TY]				[DECIMAL]	(18,4)  NOT NULL
,[ANNUALISED_UNITS_TY]				[DECIMAL]	(18,4)  NOT NULL
,[SKU_TESP_RANK_PERCENT]			[DECIMAL]	(18,4)  NOT NULL
,[TOTAL_CUMULATIVE_TESP_PERCENT]			[DECIMAL]	(18,4)  NOT NULL
,[SKU_UNITS_RANK_PERCENT]			[DECIMAL]	(18,4)  NOT NULL
,[TOTAL_CUMULATIVE_UNITS_PERCENT]			[DECIMAL]	(18,4) 	NOT NULL
,[CREATE_DATETIME] 					[DATETIME2] 		NOT NULL
,[UPDATE_DATETIME] 					[DATETIME2] 			NULL
      )
WITH 
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
);
GO



CREATE TABLE [con_dwh].[DIM_INTERNAL_PERFORMANCE_SALES_LOCATION]
    (
[SALES_LOCATION_S_KEY] 			[INT]  NOT NULL
,[SALES_LOCATION_TYPE_S_KEY]	[INT] NOT NULL
,[SALES_LOCATION]				[VARCHAR]	(20)    NOT	NULL
,[SALES_LOCATION_TYPE]			[VARCHAR]	(10)	NOT NULL
,[SIMPLIFIED_SALES_LOCATION]		[VARCHAR]	(20)    NOT NULL
,[CREATE_DATETIME] 				[DATETIME2] 	NOT NULL
,[UPDATE_DATETIME] 				[DATETIME2] 	NULL
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = REPLICATE 
);
GO 


CREATE TABLE [CON_DWH].[DIM_RPT_PRODUCT_BRAND_CATEGORY]
(
PRODUCT_SOURCE_KEY_P_KEY	NVARCHAR(30) NOT NULL,
PRODUCT_NAME	NVARCHAR(100) NOT NULL,
PRODUCT_SOURCE_KEY_AND_NAME	NVARCHAR(130) NOT NULL,
BRAND	NVARCHAR(50) NOT NULL,
LADDER_ID	NVARCHAR(30) NOT NULL,
SUB_LADDER_ID	NVARCHAR(30) NOT NULL,
CATEGORY	NVARCHAR(70) NOT NULL,
PRODUCT_HIERARCHY_1_NAME	NVARCHAR(40) NOT NULL,
PRODUCT_HIERARCHY_2_NAME	NVARCHAR(70) NOT NULL,
PRODUCT_HIERARCHY_3_NAME	NVARCHAR(70) NOT NULL,
PRODUCT_HIERARCHY_4_NAME	NVARCHAR(70) NOT NULL,
PRODUCT_HIERARCHY_5_NAME	NVARCHAR(50) NOT NULL,
PRODUCT_HIERARCHY_6_NAME	NVARCHAR(50) NOT NULL,
SS_CRP_CATEGORY	VARCHAR(50) NOT NULL,
OWN_BRAND_FLAG	VARCHAR(7) NOT NULL,
CREATE_DATETIME	DATETIME2 NOT NULL,
UPDATE_DATETIME	DATETIME2 NULL
)
WITH
(
CLUSTERED COLUMNSTORE INDEX,
DISTRIBUTION = REPLICATE 
)


CREATE TABLE [con_dwh].[STG_UK_MARGINS_CALC]
(
[RUN_DATE] 					[DATE] NOT NULL
,[DATE_RANGE] 				[INT] NOT NULL
,[PRODUCT_SOURCE_KEY] 		[NVARCHAR] (30) NOT NULL
,[AREA] 					[VARCHAR] (10) NOT NULL
,[REPORTING_COUNTRY_CODE_P_KEY]	[CHAR] (3) NOT NULL
,[SALES_LOCATION]			[VARCHAR] (10) NOT NULL
,[TOTAL_TESP_LY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_TESP_TY]					[DECIMAL] (18,4) NOT NULL
,[TOTAL_PROFIT_LY]				[DECIMAL] (18,4) NOT NULL
,[TOTAL_PROFIT_TY] 				[DECIMAL] (18,4) NOT NULL
,[SS_RETROS_LY] 			[DECIMAL] (28,10) NOT NULL
,[SS_RETROS_TY] 			[DECIMAL] (28,10) NOT NULL
,[TOTAL_UNITS_LY] 				[DECIMAL] (18,4) NOT NULL
,[TOTAL_UNITS_TY] 				[DECIMAL] (18,4) NOT NULL
,[ADJUSTED_PROFIT_LY]  		[DECIMAL] (28,10) NOT NULL
,[ADJUSTED_PROFIT_TY] 		[DECIMAL] (28,10) NOT NULL
,[ADJUSTED_MARGIN_LY]  		[DECIMAL] (28,10) NOT NULL
,[ADJUSTED_MARGIN_TY] 		[DECIMAL] (28,10) NOT NULL
,[CREATE_DATETIME] [DATETIME2] NOT NULL
,[UPDATE_DATETIME] [DATETIME2] NULL
  )
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = HASH(DATE_RANGE)
);
GO


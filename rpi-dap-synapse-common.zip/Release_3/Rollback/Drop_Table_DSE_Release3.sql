/*
************************************************************************************************************

Script Name                          : DROP_TABLE_DSE_Release3

***************************************************************************************** 
*********************************************************************************************************************

*/




DROP TABLE [con_dwh].[RPT_LIKELIHOOD_TO_RETURN];
DROP TABLE [con_dwh].[SS_RPT_SUPPLIER_FUNDING];
DROP TABLE [con_dwh].[SS_DIM_CLINICAL_COMMISSIONING_GROUPS_AREA];
DROP TABLE [con_dwh].[SS_DIM_NHS_AREA];
DROP TABLE [con_dwh].[SS_DIM_PHARMACY];
DROP TABLE [con_dwh].[SS_DIM_PHARMACY_REGION_AREA];
DROP TABLE [con_dwh].[SS_FACT_COMBINED_PHARMACY_MARKET_SHARE];
DROP TABLE [con_dwh].[SS_FACT_PHARMACY_MARKET_SHARE];
DROP TABLE [con_dwh].[VW_DIM_DATE];
DROP TABLE [con_dwh].[RPT_FOOTFALL];
DROP TABLE [con_dwh].[RPT_BABY_TRADERS];
DROP TABLE [con_dwh].[SS_DIM_RPT_SWITCHING_CATEGORY];
DROP TABLE [con_dwh].[DIM_RPT_PRODUCT_BRAND_CATEGORY];
DROP TABLE [con_dwh].[DIM_INTERNAL_PERFORMANCE_SALES_LOCATION];
DROP TABLE [con_dwh].[RPT_SWITCHING_BRAND_VIEWER];
DROP TABLE [con_dwh].[RPT_SWITCHING_PRODUCT_VIEWER];
DROP TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_MAIN];
DROP TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_WATERFALL];
DROP TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_PARETO];
DROP TABLE [con_dwh].[STG_UK_MARGINS_CALC];
DROP TABLE [con_dwh].[RPT_INTERNAL_PERFORMANCE_STORE];



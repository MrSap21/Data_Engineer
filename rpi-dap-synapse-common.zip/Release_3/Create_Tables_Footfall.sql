/*
**************************************************************************************************************************

Script Name                          : Create_Tables_Footfall_v1.0_WIP
Purpose                              : Create Tables for Consumption Layer
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description
==========================================================================================================================
01-Dec-2021   :   Anisoor Rahman        : Draft version of create tables script for Footfall.
17-Dec-2021   :   Anisoor Rahman        : The dimensions have been removed and all the relevant attributes have been appended to the RPT_FOOTFALL table.
17-Dec-2021   :   Anisoor Rahman        : Distribution type has been changed from HASH to ROUND_ROBIN.
17-Dec-2021   :   Anisoor Rahman        : Column renamed from COUNTRY_CODE to COUNTRY_CODE_P_KEY.
17-Dec-2021   :   Anisoor Rahman        : COUNTRY_CODE_P_KEY added to constraint PK_RPT_FOOTFALL.
17-Dec-2021   :   Anisoor Rahman        : Column VALUE renamed to TRANSACTION_SALES_SUM and TRANSACTIONS to TRANSACTION_COUNT
03-Jan-2022   :   Anisoor Rahman        : YEAR_WEEK column has been added to the table.
19-Jan-2022   :   Anisoor Rahman        : Data Length for COUNTRY_CODE_P_KEY changed from CHAR(2) to CHAR(3)
**************************************************************************************************************************

*/
CREATE TABLE [con_dwh].[RPT_FOOTFALL]
    (
	 [TRANSACTION_DATE_P_KEY] [DATE] NOT NULL ,
	 [TRANSACTION_HOUR_P_KEY] [TINYINT] NOT NULL ,
	 [CALENDAR_WEEK] [TINYINT] NOT NULL ,
	 [YEAR_WEEK] [INT] NOT NULL ,
	 [DAY_NAME] [VARCHAR] (10) NOT NULL ,
	 [SALES_PLAN_A_PERIOD] [VARCHAR] (10) NOT NULL ,
	 [SALES_PLAN_B_PERIOD] [VARCHAR] (10) NOT NULL ,
	 [SITE_SOURCE_KEY_P_KEY] [NVARCHAR] (10) NOT NULL ,
	 [SITE_NAME] [NVARCHAR] (90) NOT NULL ,
	 [STORE_FORMAT] [NVARCHAR] (40) NOT NULL ,
	 [STORE_FILTER] [NVARCHAR] (100) NOT NULL,
	 [ITEM_HIERARCHY_3_DESCRIPTION] [NVARCHAR] (50) NOT NULL,
	 [REPORTING_COUNTRY_CODE_P_KEY] [CHAR] (2) NOT NULL ,
	 [FOOTFALL] [INT] NOT NULL,
	 [TRANSACTION_COUNT] [INT] NOT NULL,
	 [TOTAL_TRANSACTION_SALES] [DECIMAL] (30,4) NOT NULL,
	 [UNITS] [DECIMAL] (30,4) NOT NULL,
	 [CREATE_DATETIME] [DATETIME2] NOT NULL ,
	 [UPDATE_DATETIME] [DATETIME2]
)
WITH 
(
    DISTRIBUTION = HASH ( [YEAR_WEEK] ),
	CLUSTERED COLUMNSTORE INDEX
);
GO





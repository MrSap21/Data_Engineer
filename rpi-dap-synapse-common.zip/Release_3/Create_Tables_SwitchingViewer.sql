/*
************************************************************************************************************
Script Name : Create_Tables_SwitchingViewer_v1.0_WIP
Purpose : Create Table Script for SwitchingViewer tables
*****************************************************************************************
Modification History
**************************************************************************************************************************
DATE : Modified By : Description
***************************************************************************************************************************
10-2-2022 : Rajadeepika Chandrasekeran : REPORTING_COUNTRY_CODE_P_KEY has been added
***************************************************************************************************************************/

CREATE TABLE [con_dwh].[SS_DIM_RPT_SWITCHING_CATEGORY]
(
[SWITCHING_GROUP_KEY_S_KEY] [int] NOT NULL,
[SWITCHING_GROUP_KEY_P_KEY] [nvarchar](80) NOT NULL,
[SWITCHING_GROUP] [nvarchar](80)  NOT NULL,
[CATEGORY] [varchar](80) NOT NULL,
[REPORTING_COUNTRY_CODE_P_KEY] [char](2) NOT NULL,
[CREATE_DATETIME] [datetime2](7) NOT NULL,
[UPDATE_DATETIME] [datetime2](7) NULL
)
WITH
(
DISTRIBUTION = REPLICATE,
CLUSTERED COLUMNSTORE INDEX
)
GO




CREATE TABLE [con_dwh].[RPT_SWITCHING_BRAND_VIEWER]
(
[SWITCH_DATE_P_KEY] [DATE] NOT NULL ,
[SWITCHING_GROUP_KEY_S_KEY] [INT] NOT NULL ,
[REPORTING_COUNTRY_CODE_P_KEY] [CHAR] (2) NOT NULL ,
[BRAND_NAME1_P_KEY] [VARCHAR] (100) NOT NULL ,
[BRAND_NAME2_P_KEY] [VARCHAR] (100) NOT NULL ,
[CANN_PERCENT] [DECIMAL] (30,3) NOT NULL,
[RBP] [DECIMAL] (30,3) NOT NULL,
[PROPORTION_OF_RBP] [DECIMAL] (30,3) NOT NULL,
[PRODUCT_COUNT] [INT] NOT NULL ,
[CREATE_DATETIME] [DATETIME2] NOT NULL ,
[UPDATE_DATETIME] [DATETIME2] NULL
)
WITH
(
DISTRIBUTION = REPLICATE,
CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [con_dwh].[RPT_SWITCHING_PRODUCT_VIEWER]
(
[SWITCH_DATE_P_KEY] [DATE] NOT NULL ,
[SWITCHING_GROUP_KEY_S_KEY] [INT] NOT NULL ,
[REPORTING_COUNTRY_CODE_P_KEY] [CHAR] (2) NOT NULL ,
[PRODUCT1_SOURCE_P_KEY] [NVARCHAR] (90) NOT NULL ,
[PRODUCT2_SOURCE_P_KEY] [NVARCHAR] (90) NOT NULL ,
[CANN_PERCENT] [DECIMAL] (30,3) NOT NULL,
[RPP] [DECIMAL] (30,3) NOT NULL,
[PROPORTION_OF_RPP] [DECIMAL] (30,3) NOT NULL,
[CREATE_DATETIME] [DATETIME2] NOT NULL,
[UPDATE_DATETIME] [DATETIME2] NULL
)
WITH
(
DISTRIBUTION = REPLICATE,
CLUSTERED COLUMNSTORE INDEX
)
GO




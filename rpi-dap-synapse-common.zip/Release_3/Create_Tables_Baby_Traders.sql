/*
**************************************************************************************************************************

Script Name                          : Create_Tables_Baby_Traders_v1.0_WIP
Purpose                              : Create Tables for Consumption Layer
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description
==========================================================================================================================
01-Dec-2021   :   Anisoor Rahman        : Draft version of create tables script for Baby Traders
17-Dec-2021   :   Anisoor Rahman        : The following column names have been renamed: 1.COUNTRY_CODE to COUNTRY_CODE_P_KEY, 2.STATUS to TRANSACTION_STATUS_P_KEY, 3.CUSTOMERS to CUSTOMER_COUNT 4. TRANSACTIONS to TRANSACTION_COUNT 5. VALUE to TRANSACTION_TISP_SUM.
17-Dec-2021   :   Anisoor Rahman        : Data type for COUNTRY_CODE_P_KEY has been changd from CHAR (3) to CHAR (2)
17-Dec-2021   :   Anisoor Rahman        : Data type for LADDER_P_KEY,SUB_LADDER_P_KEY, BRAND_P_KEY,SUB_BRAND_P_KEY has been chanegd from VARCHAR (50) to NVARCHAR with appropriate lengths.
17-Dec-2021   :   Anisoor Rahman        : Data length for CHANNEL_P_KEY,TRANSACTION_STATUS_P_KEY,CARD_FLAG_P_KEY has been changed from 50 to 10.
17-Dec-2021   :   Anisoor Rahman        : COUNTRY_CODE_P_KEY has been added to PK constraint.
17-Dec-2021   :   Anisoor Rahman        : Data type for TRANSACTION_TISP_SUM and UNITS has been changed from INT to DECIMAL (30,4)
17-Dec-2021   :   Anisoor Rahman        : Distribution type changed from HASH to ROUND_ROBIN
24-Jan-2022   :   Anisoor Rahman        : Data type for TRADING_WEEK_P_KEY changed from SMALLINT to TINYINT
24-Jan-2022   :   Anisoor Rahman        : Data type and length for CARD_FLAG_P_KEY has been changed from VARCHAR(10) to CHAR(1)
24-Jan-2022   :   Anisoor Rahman        : Data length for COUNTRY_CODE_P_KEY has been changed from 2 to 6 for 'UK_ROI' hadrdcoded value.
24-Jan-2022   :   Anisoor Rahman        : CUSTOMER_COUNT, TRANSACTION_COUNT, TRANSACTION_TISP_SUM, UNITS has been set to NOT NULL.
24-Jan-2022   :   Anisoor Rahman        : Primary Key constraint has been removed from the script.
25-Jan-2022   :   Anisoor Rahman        : Data Lengths, Column Names have been updated. 
27-Jan-2022   :   Anisoor Rahman        : Data Length updated fro COUNTRY_CODE_P_KEY from 6 to 2.
03-Feb-2022   :   Pandiarajan           : COUNTRY_CODE_P_KEY renamed as REPORTING_COUNTRY_CODE
17-feb-2022    :  Pandiarajan           : CARD_FLAG_P_KEY length increased
**************************************************************************************************************************

*/
CREATE TABLE [con_dwh].[RPT_BABY_TRADERS]
    (
	 [TRADING_YEAR_P_KEY] [SMALLINT] NOT NULL,
	 [TRADING_WEEK_P_KEY] [TINYINT] NOT NULL,
     [LADDER_P_KEY] [NVARCHAR] (30) NOT NULL ,
	 [SUB_LADDER_P_KEY] [NVARCHAR] (30) NOT NULL ,
	 [BRAND_P_KEY] [NVARCHAR] (50) NOT NULL ,
	 [SUB_BRAND_P_KEY] [NVARCHAR] (50) NOT NULL ,
	 [CHANNEL_P_KEY] [VARCHAR] (10) NOT NULL ,
	 [TRANSACTION_STATUS_P_KEY] [VARCHAR] (10) NOT NULL ,
	 [CARD_FLAG_P_KEY] [VARCHAR] (7) NOT NULL ,
	 [REPORTING_COUNTRY_CODE_P_KEY] [CHAR] (2) NOT NULL ,
     [LOYALTY_ACCOUNT_SOURCE_KEY] [BIGINT] NOT NULL,
	 [BASKET_SOURCE_KEY] [NVARCHAR] (50) NOT NULL,
	 [TISP] [DECIMAL] (15,4) NOT NULL,
	 [UNITS]  [DECIMAL] (15,4) NOT NULL,
     [CREATE_DATETIME] [DATETIME2] NOT NULL ,
	 [UPDATE_DATETIME] [DATETIME2] 
)
WITH 
(
    DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);
GO





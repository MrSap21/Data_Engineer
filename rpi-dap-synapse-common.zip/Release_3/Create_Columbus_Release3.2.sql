/*
**************************************************************************************************************************
Script Name                          : Create_Columbus_Release3.2_Version4.0 
Purpose                              : Create Table Script for Columbus
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================
22-Mar-2022   : Anisoor Rahman           : Create_Columbus_Release3.2_Version4.0                                                             
23-Mar-2022   : Anisoor Rahman           : DDL for RefLOV and RefLOVSet have been added
23-Mar-2022   : Anisoor Rahman           : Added RunDateTime, Year, Month, Day columns for the copy of GDH tables                           
25-Mar-2022   : Sai Goutham              : Removed SCD columns in tables wherever applicable       
26-Mar-2022   : Sai Goutham              : Added RecordStatusFlag,CreatedTime ,UpdatedTime (AuditColumns)columns for SCD Type1 tables as per DE team request,ReplenishmentOrderLine Changed SourceSystemID Datatype
28-Mar-2022   : Afifa Azad               : Nullability updated for Party.LOVPartyTypeId, SiteRole.SiteRoleId, SiteRole.SiteId,SiteRole.LOVRoleId,SiteRole.LOVRecordSourceId,SiteTerritory.SiteId,Product.ProductId, Product.SourceKey, Product.LOVSourceKeyTypeId, Product.LOVRecordSourceId, PharmacyProduct.SourceKey, PharmacyProduct.LOVRecordSourceId, PharmacyProductSKU.SourceKey, PharmacyProductSKU.LOVRecordSourceID
7-Apr-2022   : Sai Goutham              : updated all DATETIME columns to DATETIME2
21-Apr-2022  : Sai Goutham              : Updated NULL columns to NOT NULL for 
                                           Table:ActualProductPack   Columns:ActualProductPackSKID,LOVRecordSourceID
                                           Table:DailyDispensedQuantity   Columns:LOVRecordSourceID
                                           Table:DispensingSupportPharmacyTracking   Columns:LOVRecordSourceID
                                           Table:DispensingSupportPharmacyTracking   Columns:SourceKey
                                           Table:OutOfPocketExpenses      Columns:SourceKey
                                           Table:PartyRole   Columns:LOVRecordSourceId,LOVRoleId,PartyId,PartyRoleId
                                           Table:Patient   Columns:LOVRecordSourceID
                                           Table:PatientStore   Columns:LOVRecordSourceID
                                           Table:PreferredProductSKU   Columns:LOVRecordSourceID,SourceKey
                                           Table:ProductProductSKU   Columns:LOVRecordSourceID
                                           Table:ProductSKUUsage   Columns:LOVRecordSourceID
                                           Table:ProductSKUUsage   Columns:LOVRecordSourceID
                                           Table:ProductUsage   Columns:LOVRecordSourceID
                                           Table:BasicTariffSellingPrice   Columns:LOVRecordSourceID
                                           Table:PatientRegistration  Columns:PharmacyStoreSiteRoleId
22-Apr-2022   : Afifa Azad               : PrescriptionForm.TotalPriceISOCode data length changed to varchar(4)  
16-May-2022  : Sai Goutham               : StockSupplyAudit.ProductProductSKUID  renamed to PharmacyProductSKUID   
17-May-2022  : Sai Goutham               : Owing.SourceKey  Nullability
20-May-2022  : Sai Goutham               :added PharmacyProductSKU.DosageUnitID 
                                          StockAdjustment.PharmacyStoreSiteRoleId	
                                          PrescribedItem.DosageUnitID 
                                          ActualProductPack.SupplierID 
                                          PurchaseOrder.OrderTypeID 
                                          PrescriptionGroup.PatientPartyRoleID (R4 impactedcolumns)
25-May-2022  : Sai Goutham               : AverageTradeSellingPrice.PharmacyProductID
                                          BasicTariffSellingPrice.PharmacyProductID
                                         ActualProductPack.PharmacyProductSKUID
                                         ElectronicPrescribedItem.ElectronicPrescriptionID
                                         CountListItem.CountListID
                                         AdditionalItem.AdditionalEndorsementID
                                         OutOfPocketExpenses.AdditionalEndorsementID
                                         NoCheaperStockObtainable.AdditionalEndorsementID
                                         Instalment.PrescribedItemID
                                         InstalmentItem.InstalmentID
                                         InstalmentItem.DispensedItemID
                                         DispensedItem.PrescribedItemID
                                         DispensedProduct.DispensedItemID
                                         MessageNotification.PharmacyStoreSiteRoleId   columns changed to nullable 
26-May-2022  : Anisoor Rahman           : The following columns nullability have been updated from NOT NULL to NULL:
                                        Owing.PrescribedItemID
                                        ParameterValue.ParameterID
                                        PatientRegistration.PatientPartyRoleID
                                        PatientRegistration.PharmacyStoreSiteRoleId
                                        PatientStore.PharmacyStoreSiteRoleId
                                        PatientStore.PatientPartyRoleID
                                        PreferredProductSKU.PharmacyProductID
                                        PreferredProductSKU.PharmacyProductSKUID
                                        PrescribedItem.PrescriptionFormID
                                        PrescribedProduct.PrescribedItemID
                                        PrescriptionForm.PrescriptionGroupID
                                        PrescriptionFormType.FormularyID
                                        ProductProductSKU.PharmacyProductID
                                        ProductProductSKU.PharmacyProductSKUID
                                        ProductSKUUsage.PharmacyStoreSiteRoleID
                                        ProductUsage.PharmacyStoreSiteRoleID
                                        PurchaseOrderLine.PurchaseOrderID
                                        SpecialItem.AdditionalEndorsementID
                                        StockAdjustmentItem.StockAdjustmentID
                                        StockAdjustmentItem.AdjustmentReasonID
                                        StockItem.StockID
                                        StockMovementItem.StockMovementID
                                        StoreServiceCentre.PharmacyStoreSiteRoleId
                                        StoreServiceCentre.ServiceCentreSiteRoleID
31-May-2022  : Sai Goutham             :ServiceCentre.ServiceCentreSiteRoleID
                                        PharmacyStore.PharmacyStoreSiteRoleId
                                        PharmacyProduct.PharmacyProductID
                                        PharmacyProductSKU.PharmacyProductSKUID
                                        PartyRole.PartyId
                                        Siteterriorty.LOVTerritoryId,Siteterriorty.SiteId  updated as nullable columns
31-May-2022  : Anisoor Rahman          :SiteRole.SiteId
                                        Patient.PatientPartyRoleID updated as nullable columns 
03-June-2022  : Sai Goutham             : added ElectronicPrescribedItem.SourceSystemID column as per consumption requirement
03-June-2022  : Anisoor Rahman          :Nullability for PrescriptionGroup.SourceSystemID has been updated to NOT NULL.
07-June-2022  : Anisoor Rahman          : The Nullability of PatientRegistration.SourceKey has been updated from NOT NULL to NULL.
08-June-2022  : Sai Goutham             : added IsDispensedAdditionalEndorsementIndicator ,DispensedItemID columns
14-June-2022  : Afifa Azad              : added SourceSystemID column to PatientRegistration  
16-June-2022  : Sai Goutham             : added  PurchaseOrderLine.CDCApplyTime for  consumption requirement 
18-June-2022  : Sai Goutham             : added  ProductSKUUsage.CDCApplyTime	DATETIME2 for  consumption requirement                                    
**************************************************************************************************************************
*/ 


--Site
CREATE TABLE ser_pharmaceuticals.Site
(
SiteId  BIGINT  NOT NULL,
SourceKey  NVARCHAR(80)  NOT NULL,
SiteName  VARCHAR(255)  ,
LOVSiteTypeId  INT  NOT NULL,
LOVRecordSourceId  INT  NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
ETLRunLogId  INT  ,
PSARowKey  BIGINT  
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER (LOVSiteTypeId,LOVRecordSourceId)
);


--Party
CREATE TABLE ser_pharmaceuticals.Party
(
PartyId  BIGINT  NOT NULL,
LOVPartyTypeId  INT NOT NULL,
SourceKey  NVARCHAR(80)  NOT NULL,
LOVRecordSourceId  INT  NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
ETLRunLogId  INT  ,
PSARowKey  BIGINT  
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER (LOVPartyTypeId,LOVRecordSourceId)
);



--Product

CREATE TABLE ser_pharmaceuticals.Product
(
ProductId  BIGINT  NOT NULL,
SourceKey  NVARCHAR(80)  NOT NULL,
LOVSourceKeyTypeId  INT  NOT NULL,
ProductName  NVARCHAR(255)  ,
ProductDescription  NVARCHAR(255)  ,
LOVBrandId  INT  ,
LOVSubBrandId  INT  ,
LOVRecordSourceId  INT  NOT NULL,
ParentProductId  BIGINT  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
ETLRunLogId  INT  ,
PSARowKey  BIGINT  
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED INDEX
	(
		SourceKey ASC,
		LOVRecordSourceId ASC
	)
);


--SiteRole
CREATE TABLE ser_pharmaceuticals.SiteRole
(
SiteRoleId  BIGINT  NOT NULL,
SiteId  BIGINT  ,
LOVRoleId  INT  NOT NULL,
SourceKey  NVARCHAR(80)  NOT NULL,
LOVSourceKeyTypeId  INT  NOT NULL,
SiteRoleName  NVARCHAR(80)  ,
SiteRoleShortName  NVARCHAR(20)  ,
LOVRecordSourceId  INT  NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
ETLRunLogId  INT  ,
PSARowKey  BIGINT  
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[SiteRoleId],[LOVRoleId],[LOVRecordSourceId])
);

--SiteTerritory

CREATE TABLE ser_pharmaceuticals.SiteTerritory
(
SiteId  BIGINT  ,
LOVSiteTerritorySetId  INT  NOT NULL,
LOVTerritoryId  INT  ,
LOVRecordSourceId  INT  NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
ETLRunLogId  INT  ,
PSARowKey  BIGINT  
)
WITH
(
	DISTRIBUTION = HASH ( [SiteId] ),
	CLUSTERED COLUMNSTORE INDEX
);

--PartyRole
CREATE TABLE ser_pharmaceuticals.PartyRole
(
PartyRoleId  BIGINT NOT NULL ,
LOVRoleId  INT NOT NULL,
PartyId  BIGINT,
SourceKey  NVARCHAR(80)  NOT NULL,
PartyRoleName  NVARCHAR(80)  ,
LOVRecordSourceId  INT NOT NULL,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
ETLRunLogId  INT  ,
PSARowKey  BIGINT  
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRoleId],[PartyId],[LOVRecordSourceId])
);

/*  changed Nullability for PartyRoleId,LOVRoleId,PartyId,LOVRecordSourceId columns from NULL to NOT NULL*/



--RefLOV
CREATE TABLE [ser_pharmaceuticals].[RefLOV]
(
	[LOVId] [int] NOT NULL,
	[LOVSetId] [int] NOT NULL,
	[LOVKey] [nvarchar](128) NOT NULL,
	[LOVName] [nvarchar](128) NOT NULL,
	[LOVDescription] [nvarchar](1024) NULL,
	[LOVSequence] [int] NULL,
	[RecordSourceId] [int] NOT NULL,
	[ETLRunLogId] [int] NULL,
	[ActiveFlag] [smallint] NOT NULL DEFAULT 1,
	[DTCreated] [DATETIME2] NULL,
	[UserCreated] [nvarchar](128) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
);


--RefLOVSet
CREATE TABLE [ser_pharmaceuticals].[RefLOVSet]
(
	[LOVSetId] [int] NOT NULL,
	[LOVSetName] [nvarchar](128) NOT NULL,
	[LOVSetDescription] [nvarchar](1024) NULL,
	[LOVSetSequence] [int] NULL,
	[RecordSourceId] [int] NOT NULL,
	[ActiveFlag] [smallint] NOT NULL,
	[DTCreated] [DATETIME2] NULL,
	[UserCreated] [nvarchar](128) NULL,
	[ETLRunLogId] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
);

--PharmacyStore
CREATE TABLE ser_pharmaceuticals.PharmacyStore
(
PharmacyStoreSiteRoleId  BIGINT,
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
IsCentralPharmacyIndicator  NUMERIC(1)  ,
WholesalerCode  VARCHAR(50)  ,
Description  VARCHAR(255)  ,
TerminalCode  VARCHAR(50)  ,
LegacyStoreID  NUMERIC(19)  ,
LegacyCode  VARCHAR(50)  ,
CompanyCode  VARCHAR(50)  ,
PrinterLabelAddress  VARCHAR(255)  ,
PrinterLabelName  VARCHAR(255)  ,
StoreStatus  VARCHAR(50)  ,
NACSCode  VARCHAR(50)  ,
NHSCode  VARCHAR(50)  ,
EPSPriority  NUMERIC(12)  ,
PDCCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--ServiceCentre
CREATE TABLE ser_pharmaceuticals.ServiceCentre
(
ServiceCentreSiteRoleID  BIGINT ,
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
TerminalCode  VARCHAR(50)  ,
TrunkingPriority  NUMERIC(12)  ,
WholesalerCode  VARCHAR(50)  ,
CompanyCode  VARCHAR(50)  ,
ServiceCentreStatus  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--Patient
CREATE TABLE ser_pharmaceuticals.Patient
(
PatientPartyRoleID  BIGINT  ,
SourceKey  VARCHAR(80)  NOT NULL,
Alias  VARCHAR(255)  ,
BirthDate  DATE  ,
SourceSystemID  NUMERIC(19)  NOT NULL,
ExemptionDate  DATE  ,
FirstName  VARCHAR(255)  ,
FullName  VARCHAR(255)  ,
Gender  VARCHAR(50)  ,
LastName  VARCHAR(255)  ,
NationalCode  VARCHAR(50)  ,
IsNoFixedAddressIndicator  NUMERIC(1)  ,
PostalCode  VARCHAR(255)  ,
PracticeCode  VARCHAR(50)  ,
PracticeContext  VARCHAR(50)  ,
PrescriberCode  VARCHAR(50)  ,
PrescriberContext  VARCHAR(50)  ,
PatientStatus  VARCHAR(50)  ,
PatientTitle  VARCHAR(50)  ,
PatientType  VARCHAR(50)  ,
ExemptionID  NUMERIC(19)  NOT NULL,
SourcePatientID  VARCHAR(50)  ,
UpdateTime  DATETIME2  ,
CreationTime  DATETIME2  ,
IsEMarOptOutIndicator  NUMERIC(1)  ,
SendingEMarTime  DATETIME2  ,
SynchronizedTime  DATETIME2  ,
IsVisuallyImpairedIndicator  NUMERIC(1)  ,
IsNationalCodeRetrievedIndicator  NUMERIC(1)  ,
LastMURDate  DATE  ,
IsExemptionEvidenceSeenIndicator  NUMERIC(1)  ,
ExemptionExpiryDate  DATE  ,
LastDurDate  DATETIME2  ,
SerialChangeNumber  VARCHAR(255)  ,
NormalizedFirstname  VARCHAR(255)  ,
NormalizedSurname  VARCHAR(255)  ,
MergedInto  VARCHAR(50)  ,
MergedDate  DATE  ,
IsPrescriberLockIndicator  NUMERIC(1)  NOT NULL,
IsExcludeDspIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
SCDStartDate  DATETIME2  ,
SCDEndDate  DATETIME2  ,
SCDActiveFlag  VARCHAR(1)  ,
SCDVersion  INT  ,
SCDLOVRecordSourceID  INT  ,
LOVRecordSourceID  INT NOT NULL,      /* changed LOVRecordSourceID NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);




--PharmacyProduct
CREATE TABLE ser_pharmaceuticals.PharmacyProduct
(
PharmacyProductID  NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
ApplianceRefNumber  VARCHAR(50)  ,
CDSchedule  VARCHAR(50)  ,
CommonDrugServiceCode  VARCHAR(50)  ,
SourceSystemID  NUMERIC(19)  NOT NULL,
ProductDescription  VARCHAR(255)  ,
IsNoCheaperStockObtainableIndicator  NUMERIC(1)  ,
NoCheaperStockObtainableEffectiveEndDate  DATE  ,
NoCheaperStockObtainableEffectiveStartDate  DATE  ,
NormalizedProductName  VARCHAR(255)  ,
ProductClass  VARCHAR(50)  ,
ProductName  VARCHAR(255)  ,
ProductShortName  VARCHAR(255)  ,
ProductStatus  VARCHAR(50)  ,
IsSugarFreeIndicator  NUMERIC(1)  ,
ProductFormID  NUMERIC(19)  ,
ProductFlavourID  NUMERIC(19)  ,
ControlledDrugCode  VARCHAR(50)  ,
IsHighRiskIndicator  NUMERIC(1)  ,
IsContraceptiveUseIndicator  NUMERIC(1)  ,
SnomedCode  VARCHAR(50)  ,
VTMCode  VARCHAR(255)  ,
VTMDescription  VARCHAR(255)  ,
IsNMSEligibleIndicator  NUMERIC(1)  ,
IsForceClinicalCheckIndicator  NUMERIC(1)  ,
OldCommonDrugServiceCode  VARCHAR(50)  ,
OldSnomedCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PharmacyProductSKU
CREATE TABLE ser_pharmaceuticals.PharmacyProductSKU
(
PharmacyProductSKUID  NUMERIC(19),
DosageUnitID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
PackQuantity  NUMERIC(15,5)  ,
ProductSKUName  VARCHAR(255)  ,
ProductSKUStatus  VARCHAR(50)  ,
IsSubPackIndicator  NUMERIC(1)  ,
SubPackQuantity  NUMERIC(15,5)  ,
IsCSSPLineIndicator  NUMERIC(1)  ,
IsRetailTypeIndicator  NUMERIC(1)  ,
DosageUnitCode  VARCHAR(50)  ,
ProductFlavourID  NUMERIC(19)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


--PatientStore
CREATE TABLE ser_pharmaceuticals.PatientStore
(
PatientStoreSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
SourceKey  VARCHAR(80)  NOT NULL,
LastVisitedDate  DATE  ,
SiteCode  VARCHAR(50)  ,
PatientPartyRoleID  BIGINT  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,    /* changed LOVRecordSourceID NULL to NOT NULL*/
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--StoreServiceCentre
CREATE TABLE ser_pharmaceuticals.StoreServiceCentre
(
StoreServiceCentreSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
ServiceCentreSiteRoleID  BIGINT  ,
SourceKey  VARCHAR(80)  NOT NULL,
Type  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--PatientRegistration
CREATE TABLE ser_pharmaceuticals.PatientRegistration
(
PatientRegistrationSKID  NUMERIC(19)  NOT NULL,
PatientPartyRoleID  BIGINT  ,
PharmacyStoreSiteRoleId  BIGINT  , 
SourceKey  VARCHAR(80)  ,
SourceSystemID  NUMERIC(19)  NOT NULL, --Added to capture Patient_Registration.ID
PatientCode  VARCHAR(50)  NOT NULL,
PrescribeCode  VARCHAR(50)  ,
PatientRegistrationStatus  VARCHAR(50)  ,
StatusDescription  VARCHAR(255)  ,
ProcessedDate  DATETIME2  ,
SiteCode  VARCHAR(50)  NOT NULL,
TransmissionStatus  VARCHAR(50)  ,
RequestID  VARCHAR(50)  ,
StatusRequested  VARCHAR(50)  ,
CreationTime  DATETIME2  ,
UpdateTime  DATETIME2  ,
ServiceType  VARCHAR(50)  ,
RejectionCode  VARCHAR(50)  ,
RejectionClass  VARCHAR(255)  ,
RejectionDescription  VARCHAR(255)  ,
StartDate  DATETIME2  ,
EndDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,  /* changed LOVRecordSourceID NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


--ProductUsage
CREATE TABLE ser_pharmaceuticals.ProductUsage
(
ProductUsageSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleID  BIGINT  ,
PharmacyProductID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
AverageDayQuantity  NUMERIC(15,5)  ,
HoldingDemand  NUMERIC(15,5)  ,
HoldingFrequency  NUMERIC(15,5)  ,
HoldingPeriodScripts  NUMERIC(12)  ,
LongTermFrequency  NUMERIC(15,5)  ,
LongTermScripts  NUMERIC(12)  ,
MaxDailyQuantity  NUMERIC(15,5)  ,
ProductCode  VARCHAR(50)  ,
RangingCostAmount  NUMERIC(24,4)  ,
RangingCostISOCode  VARCHAR(3)  ,
RangingFrequency  NUMERIC(15,5)  ,
RangingFrequencyType  VARCHAR(50)  ,
ShortTermFrequency  NUMERIC(15,5)  ,
ShortTermScripts  NUMERIC(12)  ,
StoreCode  VARCHAR(50)  ,
TradingAdjustmentFactor  NUMERIC(15,5)  ,
IsTradingAdjustmentFactorUpliftIndicator  NUMERIC(1)  ,
LongTermUnits  NUMERIC(19)  ,
ShortTermUnits  NUMERIC(19)  ,
DemandMovement  VARCHAR(50)  ,
WeekTermScript  NUMERIC(12)  ,
WeekTermUnits  NUMERIC(15,5)  ,
JobExecutionID  NUMERIC(19)  ,
GridID  NUMERIC(19)  ,
RangingX  NUMERIC(19)  ,
RangingY  NUMERIC(19)  ,
HoldingX  NUMERIC(19)  ,
HoldingY  NUMERIC(19)  ,
JobCalculationDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,   /*changed LOVRecordSourceID from NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--AverageTradeSellingPrice
CREATE TABLE ser_pharmaceuticals.AverageTradeSellingPrice
(
AverageTradeSellingPriceSKID  NUMERIC(19)  NOT NULL,
PharmacyProductID  NUMERIC(19)  ,  --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
PriceAmount  NUMERIC(24,4)  ,
PriceISOCode  VARCHAR(3)  ,
PriceScheme  VARCHAR(50)  ,
StartDate  DATETIME2  ,
EndDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  ,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--BasicTariffSellingPrice
CREATE TABLE ser_pharmaceuticals.BasicTariffSellingPrice
(
BasicTariffSellingPriceSKID  NUMERIC(19)  NOT NULL,
PharmacyProductID  NUMERIC(19) , --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
PriceAmount  NUMERIC(24,4)  ,
PriceISOCode  VARCHAR(3)  ,
PriceScheme  VARCHAR(50)  ,
Region  VARCHAR(50)  ,
StartDate  DATETIME2  ,
EndDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,  /* changed LOVRecordSourceID NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
--ProductProductSKU
CREATE TABLE ser_pharmaceuticals.ProductProductSKU
(
ProductProductSKUSKID  NUMERIC(19)  NOT NULL,
PharmacyProductID  NUMERIC(19)  ,
PharmacyProductSKUID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
IsPreferredIndicator  NUMERIC(1)  ,
IsPrimarySKUIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL, /*changed LOVRecordSourceID from NULL to NOT NULL*/
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PreferredProductSKU
CREATE TABLE ser_pharmaceuticals.PreferredProductSKU
(
PreferredProductSKUSKID  NUMERIC(19)  NOT NULL,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyProductID  NUMERIC(19)  ,
SourceKey  VARCHAR(80) NOT NULL,  /*changed SourceKey from NULL to NOT NULL*/
Region  VARCHAR(50)  ,
PreferredType  VARCHAR(50)  ,
StartDate  DATETIME2  ,
EndDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL, /*changed LOVRecordSourceID from NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--ProductSKUUsage
CREATE TABLE ser_pharmaceuticals.ProductSKUUsage
(
ProductSKUUsageSKID  NUMERIC(19)  NOT NULL,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleID  BIGINT  ,
PharmacyProductID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
AverageDayQuantity  NUMERIC(15,5)  ,
DistributionPercentage  NUMERIC(5,2)  ,
ProductSKUCode  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
MinimunValue  NUMERIC(15,5)  ,
MaximumValue  NUMERIC(15,5)  ,
ProductCode  VARCHAR(50)  ,
CDCApplyTime DATETIME2,                     --added for requirement in consumption
JobExecutionID  NUMERIC(19)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,  /*changed LOVRecordSourceID from NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--ActualProductPack
CREATE TABLE ser_pharmaceuticals.ActualProductPack
(
ActualProductPackSKID  NUMERIC(19) NOT NULL,   /* Changed  ActualProductPackSKID from NULL to NOT NULL */
PharmacyProductSKUID  NUMERIC(19)  ,  --Changed to nullable
SupplierID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
CommonDrugServiceCode  VARCHAR(50)  ,
Description  VARCHAR(255)  ,
IsNotAutomatableProductIndicator  NUMERIC(1)  ,
BuyingMultiple  NUMERIC(12)  ,
IsBuyingMultipleOptimisationIndicator  NUMERIC(1)  ,
IsNorthWestOstomySuppliesIndicator  NUMERIC(1)  ,
IsBuyingMultipleEnforcedIndicator  NUMERIC(1)  ,
PackName  VARCHAR(255)  ,
IsPreferredIndicator  NUMERIC(1)  ,
PIPCode  VARCHAR(50)  ,
Quantity  NUMERIC(15,5)  ,
ReceivingQuantity  NUMERIC(15,5)  ,
RegionCode  VARCHAR(50)  ,
ShortName  VARCHAR(255)  ,
IsSpecialItemIndicator  NUMERIC(1)  ,
Status  VARCHAR(50)  ,
SupplierCode  VARCHAR(50)  ,
IsTenderLineIndicator  NUMERIC(1)  ,
BusinessItemCode  VARCHAR(50)  ,
IsControlledDrugIndicator  NUMERIC(1)  ,
DmdSpecial  VARCHAR(50)  ,
IsFridgeLineIndicator  NUMERIC(1)  ,
LegalCategory  VARCHAR(50)  ,
SnomedDescription  VARCHAR(255)  ,
NWOSCategory  VARCHAR(50)  ,
NWOSStartDate  DATE  ,
NWOSEndDate  DATE  ,
IsMASEligibleIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,  /* Changed LOVRecordSourceID  from NULL to NOT NULL */
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


/* Changed  ActualProductPackSKID,LOVRecordSourceID  from NULL to NOT NULL */


--PrescriptionGroup
CREATE TABLE ser_pharmaceuticals.PrescriptionGroup
(
PrescriptionGroupSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
PatientPartyRoleID BIGINT,
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19) NOT NULL ,
PatientCode  VARCHAR(50)  ,
ServiceEntryMode  VARCHAR(50)  ,
ServiceType  VARCHAR(50)  ,
SourceGroupID  VARCHAR(255)  ,
PrescriptionGroupStatus  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
UpdateTime  DATETIME2  ,
ProcessingTime  DATETIME2  ,
IsCentralPharmacyIndicator  NUMERIC(1)  ,
IsOrderableIndicator  NUMERIC(1)  ,
Forms  NUMERIC(12)  ,
PrescriptionSourceType  VARCHAR(50)  ,
CreationTime  DATETIME2  ,
DeliveryDate  DATE  ,
AnimalCode  VARCHAR(50)  ,
MessageType  VARCHAR(50)  ,
IsDummyGroupIndicator  NUMERIC(1)  ,
OldPatientCode  VARCHAR(50)  ,
IsFMDVerifiedIndicator  NUMERIC(1)  ,
PrescriptionSource  VARCHAR(50)  ,
Fulfilled  VARCHAR(50)  ,
DSPSendingTime  DATETIME2  ,
RetrievalStatus  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


--PrescriptionFormType
CREATE TABLE ser_pharmaceuticals.PrescriptionFormType
(
PrescriptionFormTypeSKID  NUMERIC(19)  NOT NULL,
FormularyID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
ColourDark  VARCHAR(50)  ,
ColourDescription  VARCHAR(255)  ,
ColourLight  VARCHAR(50)  ,
IsDefaultValueIndicator  NUMERIC(1)  ,
Description  VARCHAR(255)  ,
IsEndorsableIndicator  NUMERIC(1)  ,
IsNationalFormTypeIndicator  NUMERIC(1)  ,
IsPerformDURIndicator  NUMERIC(1)  ,
PrescriptionFormTypeStatus  VARCHAR(50)  ,
IsCentralPharmacyDispensingIndicator  NUMERIC(1)  ,
ExpiryPeriod  NUMERIC(12)  ,
InstalmentDefaultDays  NUMERIC(12)  ,
InstalmentSchedule  VARCHAR(50)  ,
MaxItemNumber  NUMERIC(12)  ,
IsPrivateNumberRequiredIndicator  NUMERIC(1)  ,
IsSelectableIndicator  NUMERIC(1)  ,
IsVATExtempIndicator  NUMERIC(1)  ,
InstalmentScheduleType  VARCHAR(50)  ,
IsNWOSEligibleIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--ElectronicPrescription
CREATE TABLE ser_pharmaceuticals.ElectronicPrescription	
(
ElectronicPrescriptionSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
SourceKey  VARCHAR(80)  NOT NULL,
NumberOfItem  NUMERIC(12)  ,
OriginalPrescription  NVARCHAR(4000)  ,
ProducedDate  DATETIME2  ,
RepeatIssueNumber  VARCHAR(255)  ,
RepeatMasterID  VARCHAR(50)  ,
SourceElectronicPrescriptionID  VARCHAR(255)  ,
ElectronicPrescriptionStatus  VARCHAR(50)  ,
UpdateTime  DATETIME2  ,
SourceFormType  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
Type  VARCHAR(50)  ,
ClaimStatus  VARCHAR(50)  ,
Note  VARCHAR(255)  ,
IsUrgentFlagIndicator  NUMERIC(1)  ,
NHSStatus  VARCHAR(50)  ,
ReceivedTime  DATETIME2  ,
Duration  VARCHAR(255)  ,
DurationUOM  VARCHAR(50)  ,
DeliveryDate  DATE  ,
DispensingDate  DATETIME2  ,
ClinicalEventID  VARCHAR(255)  ,
TreatmentType  VARCHAR(50)  ,
TransmissionID  VARCHAR(255)  ,
ClaimID  VARCHAR(100)  ,
ClaimSendDateTime  DATETIME2  ,
DailyReportProcessingTime  DATETIME2  ,
IsSendingMessageIndicator  NUMERIC(1)  ,
DispenseNotificationID  VARCHAR(255)  ,
ReturnReasonCode  VARCHAR(50)  ,
ResponseStatus  VARCHAR(50)  ,
SignerName  VARCHAR(255)  ,
IsLevyIndicator  NUMERIC(1)  ,
BusinessStatus  VARCHAR(255)  ,
PrintingTime  DATETIME2  ,
ReviewDate  DATE  ,
SignerDateTime  DATETIME2  ,
NonCDExpiryDate  DATE  ,
CDExpiryDate  DATE  ,
SupplyStartDate  DATETIME2  ,
SupplyEndDate  DATETIME2  ,
ExpectedDaysSupply  NUMERIC(12)  ,
MaxRepeatNumber  NUMERIC(12)  ,
PrintStatus  VARCHAR(50)  ,
TransmissionSource  VARCHAR(255)  ,
ClinicalServiceCode  VARCHAR(50)  ,
IsControlledDrugFlagIndicator  NUMERIC(1)  ,
NotificationID  VARCHAR(100)  ,
DefinitionParametersVersion  VARCHAR(255)  ,
IsSendWaitingClaimIndicator  NUMERIC(1)  ,
AtRiskDate  DATETIME2  ,
CreationDate  DATETIME2  ,
DispenseNotificationDate  DATETIME2  ,
RepeatRequestCodes  VARCHAR(255)  ,
RepeatRequestStatus  VARCHAR(255)  ,
CollectionDeliveryDate  DATE  ,
IsDigitalIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);  

  
--Stock
CREATE TABLE ser_pharmaceuticals.Stock
(
StockSKID  NUMERIC(19)  NOT NULL,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId  BIGINT  ,
SourceKey  VARCHAR(80)  NOT NULL,
LastUpdateTime  DATETIME2  ,
NextDeliveryDate  DATETIME2  ,
ProductSKUCode  VARCHAR(50)  ,
StockStatus  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
OnShelfQuantity  NUMERIC(15,5)  ,
LastOperation  VARCHAR(50)  ,
StartDate  DATETIME2  ,
EndDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


--StockAdjustment
CREATE TABLE ser_pharmaceuticals.StockAdjustment
(
StockAdjustmentSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId	BIGINT,
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
CreationTime  DATETIME2  ,
EntityCode  VARCHAR(60)  ,
EntityType  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
UserInitial  VARCHAR(255)  ,
UserName  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--CountList
CREATE TABLE ser_pharmaceuticals.CountList 
(
CountListSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
PrescribedProductID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
CreationTime  DATETIME2  ,
PrescribedProductCode  VARCHAR(50)  ,
Source  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
ThirdPartyCompany  VARCHAR(255)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--ReplenishmentOrderLine
CREATE TABLE ser_pharmaceuticals.ReplenishmentOrderLine
(
ReplenishmentOrderLineSKID  NUMERIC(19)  NOT NULL,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId  BIGINT  ,
ActualProductPackID	NUMERIC(19),
OrderTypeID  NUMERIC(19)  ,
ManualOrderReasonID  NUMERIC(19)  ,
DispensedItemID	NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
ActualProductPackCode  VARCHAR(50)  ,
SourceSystemID  NUMERIC(19)  NOT NULL,
DispensedItemCode  VARCHAR(50)  ,
IsDPPExcludeIndicator  NUMERIC(1)  ,
OrderQuantity  NUMERIC(12)  ,
PackSize  NUMERIC(15,5)  ,
IsPatientPreferenceIndicator  NUMERIC(1)  ,
PIPCode  VARCHAR(50)  ,
QuantityUsed  NUMERIC(15,5)  ,
ServiceEntryMode  VARCHAR(50)  ,
ServiceType  VARCHAR(50)  ,
SiteCode  VARCHAR(50)  ,
IsSpecialConfirmationIndicator  NUMERIC(1)  ,
ProcessingTime  DATETIME2  ,
CreationTime  DATETIME2  ,
ProductSKUCode  VARCHAR(50)  ,
SuggestedOrderQuantity  NUMERIC(12)  ,
IsTransmittedIndicator  NUMERIC(1)  ,
IsExcludedIndicator  NUMERIC(1)  ,
IsDebarredIndicator  NUMERIC(1)  ,
IsCSSPLineIndicator  NUMERIC(1)  ,
UserName  VARCHAR(50)  ,
IsFullUsedIndicator  NUMERIC(1)  ,
ProductDescription  VARCHAR(255)  ,
IsUncataloguedProductIndicator  NUMERIC(1)  ,
UnitOfMeasure  VARCHAR(50)  ,
ReceivingQuantity  NUMERIC(15,5)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PurchaseOrder
CREATE TABLE ser_pharmaceuticals.PurchaseOrder
(
PurchaseOrderSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
OrderTypeID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
CreationTime  DATETIME2  ,
CustomerCode  VARCHAR(50)  ,
ProductCodeType  VARCHAR(50)  ,
SourceSystemID  NUMERIC(19)  NOT NULL,
SendingTime  DATETIME2  ,
SiteCode  VARCHAR(50)  ,
Status  VARCHAR(50)  ,
TerminalID  VARCHAR(50)  ,
ServiceType  VARCHAR(50)  ,
PurchaseOrderGroupID  NUMERIC(19)  ,
OrderResponseID  NUMERIC(19)  ,
OrderTypeCode  VARCHAR(50)  ,
ServiceEntryMode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);


--StockMovement
CREATE TABLE ser_pharmaceuticals.StockMovement
(
StockMovementSKID  NUMERIC(19)  NOT NULL,
PharmacyProductID  NUMERIC(19)  ,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId BIGINT,
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
CreationTime  DATETIME2  ,
EntityType  VARCHAR(50)  ,
StockAdjustmentID  NUMERIC(19)  ,
StockAdjustmentItemID  NUMERIC(19)  ,
PrescriptionFormID  NUMERIC(19)  ,
PrescribedItemID  NUMERIC(19)  ,
DispensedItemID  NUMERIC(19)  ,
CountListID  NUMERIC(19)  ,
CountListItemID  NUMERIC(19)  ,
NextDeliveryDate  DATETIME2  ,
Operation  VARCHAR(50)  ,
Process  VARCHAR(255)  ,
ProcessingTime  DATETIME2  ,
ProductCode  VARCHAR(50)  ,
ProductSKUCode  VARCHAR(50)  ,
Reason  VARCHAR(50)  ,
StockedTime  DATETIME2  ,
StoreCode  VARCHAR(50)  ,
UserName  VARCHAR(50)  ,
ServiceEntryMode  VARCHAR(255)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--OverStock
CREATE TABLE ser_pharmaceuticals.OverStock
(
OverStockSKID  NUMERIC(19)  NOT NULL,
PharmacyProductID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId  BIGINT  ,
SourceKey  VARCHAR(80)  NOT NULL,
CreationTime  DATETIME2  ,
ProductCode  VARCHAR(50)  ,
Quantity  NUMERIC(15,5)  ,
StoreCode  VARCHAR(50)  ,
TotalOnShelfQuantity  NUMERIC(15,5)  ,
UpdateTime  DATETIME2  ,
QuantitySecondary  NUMERIC(15,5)  ,
TOTOnShelfSecondary  NUMERIC(15,5)  ,
TOTOverstockSecondary  NUMERIC(15,5)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--ElectronicPrescribedItem
CREATE TABLE ser_pharmaceuticals.ElectronicPrescribedItem
(
ElectronicPrescribedItemSKID  NUMERIC(19)  NOT NULL,
ElectronicPrescriptionID  NUMERIC(19) , --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID NUMERIC(19) NOT NULL,
CommonDrugServiceCode  VARCHAR(50)  ,
Description  VARCHAR(400)  ,
DosageUnit  VARCHAR(200)  ,
Quantity  VARCHAR(255)  ,
UpdateTime  DATETIME2  ,
ClaimStatus  VARCHAR(50)  ,
DispensingEvent  VARCHAR(50)  ,
ControlledDrugIndicator  VARCHAR(50)  ,
ControlledDrugSchedule  VARCHAR(50)  ,
NHSStatus  VARCHAR(50)  ,
Duration  VARCHAR(255)  ,
DurationUOM  VARCHAR(50)  ,
Frequency  VARCHAR(255)  ,
DispensingEventNumber  NUMERIC(12)  ,
DosageUnitCommonDrugServiceCode  VARCHAR(50)  ,
MedicationStartDate  DATE  ,
CurrentEventNumber  NUMERIC(12)  ,
DosageDirection  NVARCHAR(4000)  ,
QuantityDescription  VARCHAR(255)  ,
AdditionalDirection  VARCHAR(4000)  ,
ItemSequence  NUMERIC(12)  ,
DictionaryVersion  VARCHAR(255)  ,
DrugDictionary  VARCHAR(255)  ,
DoseDescription  VARCHAR(255)  ,
MappingInformation  VARCHAR(255)  ,
AmendmentReason  VARCHAR(255)  ,
AmendmentDateTime  DATETIME2  ,
IsNotDispensableIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PrescriptionForm
CREATE TABLE ser_pharmaceuticals.PrescriptionForm
(
PrescriptionFormSKID  NUMERIC(19)  NOT NULL,
PrescriptionFormTypeID  NUMERIC(19)  ,
ElectronicPrescriptionID  NUMERIC(19)  ,
PrescriptionGroupID  NUMERIC(19)  ,
PracticeID NUMERIC(19),
PrescriberID NUMERIC(19),
PrescriptionServiceID  NUMERIC(19)  ,
LevyFeeID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
PracticeCode  VARCHAR(50)  ,
PracticeContext  VARCHAR(50)  ,
PrescriberCode  VARCHAR(50)  ,
PrescriberContext  VARCHAR(50)  ,
PrescriptionDate  DATETIME2  ,
PrescriptionNumber  NUMERIC(12)  ,
PrescriptionTypeCode  VARCHAR(50)  ,
Reason  VARCHAR(255)  ,
SourcePrescriptionID  VARCHAR(255)  ,
PrescriptionFormStatus  VARCHAR(50)  ,
PrescriberLegacyCode  VARCHAR(50)  ,
PracticeLegacyCode  VARCHAR(50)  ,
LastEnteredTime  DATETIME2  ,
TotalPriceAmount  NUMERIC(24,4)  ,
TotalPriceISOCode  VARCHAR(4)  , --data length changed to varchar(4)
ProcessingTime  DATETIME2  ,
LevyFeeCode  VARCHAR(50)  ,
DiscountAmount  NUMERIC(24,4)  ,
DiscountISOCode  VARCHAR(3)  ,
PrivateReferenceNumber  VARCHAR(50)  ,
IsElectronicIndicator  NUMERIC(1)  ,
IsStockedIndicator  NUMERIC(1)  ,
ExpirationDate  DATE  ,
IsManualPriceIndicator  NUMERIC(1)  ,
LocalPracticeName  VARCHAR(255)  ,
LocalPrescriberName  VARCHAR(255)  ,
DefaultPracticeCode  VARCHAR(50)  ,
DefaultPrescriberCode  VARCHAR(50)  ,
EPSServiceType  VARCHAR(50)  ,
ClaimedTime  DATETIME2  ,
UniquePrescriptionNumber  VARCHAR(255)  ,
AdditionalFeeAmount  NUMERIC(24,4)  ,
AdditionalFeeISOCode  VARCHAR(3)  ,
VATApplied  NUMERIC(12)  ,
TotalVATAmount  NUMERIC(24,4)  ,
TotalVATISOCode  VARCHAR(3)  ,
ProducedDate  DATE  ,
IsPrescriberFullMatchIndicator  NUMERIC(1)  ,
ClaimStatus  VARCHAR(50)  ,
IsExemptionEvidenceSeenIndicator  NUMERIC(1)  ,
NotifiedExemptionCode  VARCHAR(50)  ,
Fulfilled  VARCHAR(50)  ,
ExemptionType  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--StockAdjustmentItem
CREATE TABLE ser_pharmaceuticals.StockAdjustmentItem
(
StockAdjustmentItemSKID  NUMERIC(19)  NOT NULL,
StockAdjustmentID  NUMERIC(19)  ,
AdjustmentReasonID  NUMERIC(19)  ,
PharmacyProductSKUID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
AdjustedPackQuantity  NUMERIC(15,5)  ,
AdjustedUnitQuantity  NUMERIC(15,5)  ,
OnShelfUnitQuantity  NUMERIC(15,5)  ,
ProductSKUCode  VARCHAR(50)  ,
DestinationStore  VARCHAR(50)  ,
TransferOrderCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);  

--StockAdjustmentReason
CREATE TABLE ser_pharmaceuticals.StockAdjustmentReason
(
StockAdjustmentReasonSKID  NUMERIC(19)  NOT NULL,
SourceKey VARCHAR(80)  NOT NULL,
ClosedTime  DATETIME2  ,
SourceSystemID NUMERIC(19)  NOT NULL,
CreationTime  DATETIME2  ,
Description  VARCHAR(255)  ,
LastUpdate  DATETIME2  ,
StockAdjustmentReasonType  VARCHAR(50)  ,
UserName  VARCHAR(50)  ,
IsSendToFinanceIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);  

--StockItem
CREATE TABLE ser_pharmaceuticals.StockItem
(
StockItemSKID  NUMERIC(19)  NOT NULL,
StockID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
Quantity  NUMERIC(15,5)  ,
IsSoftAllocatedIndicator  NUMERIC(1)  ,
StockItemType  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--CountListItem
CREATE TABLE ser_pharmaceuticals.CountListItem
(
CountListItemSKID  NUMERIC(19)  NOT NULL,
CountListID  NUMERIC(19)  , --Changed to nullable
PharmacyProductSKUID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
CountedPackQuantity  NUMERIC(12)  ,
CountedUnitQuantity  NUMERIC(15,5)  ,
OnShelfUnitQuantity  NUMERIC(15,5)  ,
IsPreferredIndicator  NUMERIC(1)  ,
IsPrimaryIndicator  NUMERIC(1)  ,
ProductSKUCode  VARCHAR(50)  ,
Reason  VARCHAR(50)  ,
CountListItemStatus  VARCHAR(50)  ,
UpdateTime  DATETIME2  ,
UserInitial  VARCHAR(255)  ,
UserName  VARCHAR(50)  ,
IsOrderableIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--ReplenishmentItem
CREATE TABLE ser_pharmaceuticals.ReplenishmentItem
(
ReplenishmentItemSKID  NUMERIC(19)  NOT NULL,
ReplenishmentOrderLineID  NUMERIC(19)  ,
PharmacyProductID  NUMERIC(19)  ,
DispensedItemID	NUMERIC(19),
PrescriptionFormID NUMERIC(19),
PrescribedItemID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
DispensedItemCode  VARCHAR(50)  ,
GroupCode  VARCHAR(50)  ,
Quantity  NUMERIC(15,5)  ,
PrescriptionFormCode  VARCHAR(50)  ,
ReplenishmentItemStatus  VARCHAR(50)  ,
IsOverstockedIndicator  NUMERIC(1)  ,
PrescribedItemCode  VARCHAR(50)  ,
ProductCode  VARCHAR(50)  ,
LinkedROLCode  VARCHAR(50)  ,
CumulativeQuantity  NUMERIC(15,5)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PurchaseOrderLine
CREATE TABLE ser_pharmaceuticals.PurchaseOrderLine
(
PurchaseOrderLineSKID  NUMERIC(19)  NOT NULL,
PurchaseOrderID  NUMERIC(19)  ,
ReplenishmentOrderLineID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
LineNumber  NUMERIC(12)  ,
ReplenishmentOrderLineCode  VARCHAR(50)  ,
PurchaseOrderLineStatus  VARCHAR(50)  ,
UpdateTime  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
CDCApplyTime DATETIME2 ,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--StockMovementItem
CREATE TABLE ser_pharmaceuticals.StockMovementItem
(
StockMovementItemSKID  NUMERIC(19)  NOT NULL,
StockMovementID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
OriginalStockQuantity  NUMERIC(15,5)  ,
StockMovementQuantity  NUMERIC(15,5)  ,
QuantityType  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--OverStockItem
CREATE TABLE ser_pharmaceuticals.OverStockItem
(
OverStockItemSKID  NUMERIC(19)  NOT NULL,
OverStockID  NUMERIC(19)  NOT NULL,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId	BIGINT,
SourceKey  VARCHAR(80)  NOT NULL,
ProductSKUCode  VARCHAR(50)  ,
Quantity  NUMERIC(15,5)  ,
Type  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--DispensingSupportPharmacyTracking
CREATE TABLE ser_pharmaceuticals.DispensingSupportPharmacyTracking
(
DspTrackingSKID  NUMERIC(19)  NOT NULL,
PrescriptionGroupID NUMERIC(19),    
PrescriptionFormID NUMERIC(19), 
SourceKey  VARCHAR(80) NOT NULL,  /* Changed from NULL to NOT NULL*/
CreationTime  DATETIME2  ,
PrescriptionGroupCode  VARCHAR(50)  ,
Result  VARCHAR(255)  ,
NumberOfItems  NUMERIC(12)  ,
Process  VARCHAR(255)  ,
AppCodeFailed  VARCHAR(50)  ,
Reason  VARCHAR(255)  ,
TriagedItems  NUMERIC(12)  ,
PrescriptionFormCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,  
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--DispensingEvent
CREATE TABLE ser_pharmaceuticals.DispensingEvent
(
DispensingEventSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
PrescriptionFormID NUMERIC(19);  
SourceKey  VARCHAR(80)  NOT NULL,
MasterUPN  VARCHAR(255)  ,
PrescriptionFormCode  VARCHAR(50)  ,
IsClaimedItemsIndicator  NUMERIC(1)  ,
DispensingDate  DATE  ,
IsExceptionItemsIndicator  NUMERIC(1)  ,
IsToBeClaimedItemsIndicator  NUMERIC(1)  ,
Status  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
IsDueDateItemsIndicator  NUMERIC(1)  ,
AtRiskDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PrescribedItem
CREATE TABLE ser_pharmaceuticals.PrescribedItem
(
PrescribedItemSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
PrescriptionFormID  NUMERIC(19)  ,
DosageUnitID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
SourceSystemID  NUMERIC(19)  NOT NULL,
DosageUnit  VARCHAR(50)  ,
IsEmergencySuppliedIndicator  NUMERIC(1)  ,
EnteredQuantity  VARCHAR(255)  ,
ItemNumber  NUMERIC(12)  ,
IsNotDispensedIndicator  NUMERIC(1)  ,
Ordering  NUMERIC(12)  ,
PrescribedItemDate  DATETIME2  ,
IsReconciledIndicator  NUMERIC(1)  ,
Status  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
Quantity  NUMERIC(15,5)  ,
StockedTime  DATETIME2  ,
LastUpdatedTime  DATETIME2  ,
ProcessingTime  DATETIME2  ,
IsDosageAmendedIndicator  NUMERIC(1)  ,
ElectronicItemCode  VARCHAR(50)  ,
IsElectronicIndicator  NUMERIC(1)  ,
PrescribedItemUOM  VARCHAR(255)  ,
IsTrustedDirectionIndicator  NUMERIC(1)  ,
VisuallyImpairedRefLetter  VARCHAR(50)  ,
ClaimedTime  DATETIME2  ,
ReconciliationType  VARCHAR(50)  ,
ExpirationDate  DATE  ,
DosageDirections  NVARCHAR(4000)  ,
DosageDirections2  VARCHAR(4000)  ,
PriceAmount  NUMERIC(24,4)  ,
PriceISOCode  VARCHAR(3)  ,
NotDispensedUpdateTime  DATETIME2  ,
NotDispensedReason  VARCHAR(50)  ,
NotificationTime  DATETIME2  ,
IsExpirationProcessedIndicator  NUMERIC(1)  ,
OriginalQuantity  NUMERIC(15,5)  ,
OriginalDosageUnit  VARCHAR(50)  ,
IsLevyIndicator  NUMERIC(1)  ,
IsNewItemPMRIndicator  NUMERIC(1)  ,
ItemNote  VARCHAR(500)  ,
Fulfilled  VARCHAR(50)  ,
IsOverstockConsumedIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--StockSupplyAudit
CREATE TABLE ser_pharmaceuticals.StockSupplyAudit
(
StockSupplyAuditSKID  NUMERIC(19)  NOT NULL,
PurchaseOrderID  NUMERIC(19)  ,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId  BIGINT  ,
PharmacyProductID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
OnOrder  NUMERIC(15,5)  ,
OnShelf  NUMERIC(15,5)  ,
Reserved  NUMERIC(15,5)  ,
Overstock  NUMERIC(15,5)  ,
Status  VARCHAR(50)  ,
StoreCode  VARCHAR(255)  ,
OperationType  VARCHAR(255)  ,
ProductCode  VARCHAR(255)  ,
PurchaseOrderRef  VARCHAR(255)  ,
ProductSKUCode  VARCHAR(255)  ,
RequestTime  DATETIME2  ,
ResultDescription  VARCHAR(255)  ,
MinimumSKUValue  NUMERIC(15,5)  ,
MaximumSKUValue  NUMERIC(15,5)  ,
StockSupplyRequestID  BIGINT  ,    --changed datatype from NUMERIC(19) to bigint
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--DailyDispensedQuantity
CREATE TABLE ser_pharmaceuticals.DailyDispensedQuantity
(
DailyDispensedQuantitySKID  NUMERIC(19)  NOT NULL,
PharmacyProductID  NUMERIC(19)  ,
ActualProductPackID NUMERIC(19), 
PharmacyProductSKUID NUMERIC(19),  
PharmacyStoreSiteRoleId BIGINT,
SourceKey  VARCHAR(80)  NOT NULL,
AppCode  VARCHAR(50)  ,
DispensedDate  DATE  ,
PipCode  VARCHAR(50)  ,
ProductCode  VARCHAR(50)  ,
Quantity  NUMERIC(15,5)  ,
ScriptNumber  NUMERIC(12)  ,
SKUCode  VARCHAR(50)  ,
StoreCode  VARCHAR(50)  ,
ServiceEntryMode  VARCHAR(50)  ,
OwingQuantityRedeemed  NUMERIC(15,5)  ,
OwingQuantityOutstanding  NUMERIC(15,5)  ,
OwingNumber  NUMERIC(12)  ,
ServiceType  VARCHAR(50)  ,
PrescriptionDate  DATE  ,
ScriptNumberOutstanding  NUMERIC(12)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT NOT NULL,   /*LOVRecordSourceID changed from NULL to NOT NULL*/
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--AdditionalEndorsement
create table ser_pharmaceuticals.AdditionalEndorsement
(
AdditionalEndorsementSKID  NUMERIC(19)  NOT NULL,
PrescribedItemID  NUMERIC(19)  ,
DispensedItemID NUMERIC(19);
SourceKey  VARCHAR(80)  NOT NULL,
IsDispensedAdditionalEndorsementIndicator NUMERIC(1);
AdditionalDescription  VARCHAR(500)  ,
BatchNumber  VARCHAR(50)  ,
IsBrokenBulkIndicator  NUMERIC(1)  ,
IsBrokenBulkSurplusIndicator  NUMERIC(1)  ,
IsContraceptiveItemIndicator  NUMERIC(1)  ,
IsExtempIndicator  NUMERIC(1)  ,
IsExtraContainerIndicator  NUMERIC(1)  ,
IsExtraItemIndicator  NUMERIC(1)  ,
InvoiceNumber  VARCHAR(50)  ,
Manufacturer  NUMERIC(1)  ,
IsMeasuredFittedIndicator  NUMERIC(1)  ,
IsNotCollectIndicator  NUMERIC(1)  ,
PrescriptionDispensedDate  DATETIME2  ,
IsPrescriberContactedIndicator  NUMERIC(1)  ,
PrescriberDetail  VARCHAR(255)  ,
IsPrescriberPCFlagIndicator  NUMERIC(1)  ,
Region  VARCHAR(50)  ,
IsRepeatDispensedIndicator  NUMERIC(1)  ,
IsRepeatInterventionIndicator  NUMERIC(1)  ,
SupplierLicenceID  VARCHAR(50)  ,
IsUrgentSupplyIndicator  NUMERIC(1)  ,
UrgentSupplyDispensedTime  DATETIME2  ,
UserInitial  VARCHAR(255)  ,
NumberPackagedDose  NUMERIC(12)  ,
IsPackagedDoseIndicator  NUMERIC(1)  ,
IsRebatClaimedIndicator  NUMERIC(1)  ,
IsWasteReductionIndicator  NUMERIC(1)  ,
IsInvoicePriceIndicator  NUMERIC(1)  ,
InvoicePriceValue  NUMERIC(15,5)  ,
IsLevyChargedIndicator  NUMERIC(1)  ,
IsUrgentDispensingIndicator  NUMERIC(1)  ,
IsPublicHolidayIndicator  NUMERIC(1)  ,
UrgentDispensingDateTime  DATETIME2  ,
IsPMRCheckedIndicator  NUMERIC(1)  ,
PharmacistName  VARCHAR(255)  ,
AmendmentNote  VARCHAR(255)  ,
PrescriberContactedDate  DATE  ,
Licence  VARCHAR(255)  ,
BrokenBulkDate  DATE  ,
IsShortSupplyIndicator  NUMERIC(1)  ,
IsLimitedLifeIndicator  NUMERIC(1)  ,
IsInstalmentDispenseIndicator  NUMERIC(1)  ,
IsNotCollectedIndicator  NUMERIC(1)  ,
IsMadeToMeasureIndicator  NUMERIC(1)  ,
IsOtherEndorsementIndicator  NUMERIC(1)  ,
BrandOrManufacturer  VARCHAR(255)  ,
InvoicePricePackQuantity  VARCHAR(50)  ,
InvoicePriceManufacturer  VARCHAR(255)  ,
BrokenBulkPackQuantity  VARCHAR(50)  ,
IsSSPIndicator  NUMERIC(1)  ,
SSPCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--AdditionalItem
create table ser_pharmaceuticals.AdditionalItem
(
AdditionalItemSKID  NUMERIC(19)  NOT NULL,
AdditionalEndorsementID  NUMERIC(19) ,  --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
AdditionalItemQuantity  NUMERIC(15,5)  ,
AdditionalItemUOMCode  VARCHAR(50)  ,
AdditionalItemUOMDescription  VARCHAR(255)  ,
AdditionalItemDescription  VARCHAR(255)  ,
AdditionalItemCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--SpecialItem
create table ser_pharmaceuticals.SpecialItem
(
SpecialItemSKID  NUMERIC(19)  NOT NULL,
AdditionalEndorsementID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
SpecialItemPriceAmount  NUMERIC(24,4)  ,
SpecialItemPriceISOCode  VARCHAR(3)  ,
SpecialManufacturer  VARCHAR(255)  ,
SpecialPackQuantity  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--OutOfPocketExpenses
create table ser_pharmaceuticals.OutOfPocketExpenses
(
OutOfPocketExpensesSKID  NUMERIC(19)  NOT NULL,
AdditionalEndorsementID  NUMERIC(19)  ,         --Changed to nullable
SourceKey  VARCHAR(80) NOT NULL,                 /* Changed from NULL to NOT NULL*/
OutOfPocketExpensesItemPriceAmount  NUMERIC(24,4)  ,
OutOfPocketExpensesItemPriceISOCode  VARCHAR(3)  ,
OutOfPocketExpensesReason  VARCHAR(255)  ,
IsOutOfPocketExpensesVATIncludedIndicator  NUMERIC(1)  ,
IsOutOfPocketExpensesPostagePackagingIndicator  NUMERIC(1)  ,
OutOfPocketExpensesPostagePriceAmount  NUMERIC(24,4)  ,
OutOfPocketExpensesPostagePriceISOCode  VARCHAR(3)  ,
IsOutOfPocketExpensesHandlingChargeIndicator  NUMERIC(1)  ,
OutOfPocketExpensesHandlingPriceAmount  NUMERIC(24,4)  ,
OutOfPocketExpensesHandlingPriceISOCode  VARCHAR(3)  ,
IsOutOfPocketExpensesOtherChargeIndicator  NUMERIC(1)  ,
OutOfPocketExpensesOtherPriceAmount  NUMERIC(24,4)  ,
OutOfPocketExpensesOtherPriceISOCode  VARCHAR(3)  ,
OutOfPocketExpensesOtherExpensesDescr  VARCHAR(255)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--NoCheaperStockObtainable
create table ser_pharmaceuticals.NoCheaperStockObtanaible
(
NoCheaperStockObtainableSKID  NUMERIC(19)  NOT NULL,
AdditionalEndorsementID  NUMERIC(19) , --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
NoCheaperStockObtainableDispensedDate  DATETIME2  ,
NoCheaperStockObtainablePackSize  NUMERIC(15,5)  ,
NoCheaperStockObtainableSupplier  VARCHAR(255)  ,
NoCheaperStockObtainableUserInitial  VARCHAR(255)  ,
NoCheaperStockObtainablePackQuantity  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--PrescribedProduct
CREATE TABLE ser_pharmaceuticals.PrescribedProduct
(
PrescribedProductSKID  NUMERIC(19)  NOT NULL,
PrescribedItemID  NUMERIC(19)  ,
PharmacyProductID  NUMERIC(19)  ,
SourceKey  VARCHAR(80)  NOT NULL,
BNFWarning  NVARCHAR(4000)  ,
CommonDrugServiceCode  VARCHAR(50)  ,
PrescribedProductName  VARCHAR(255)  ,
ProductCode  VARCHAR(50)  ,
ShortName  VARCHAR(255)  ,
AverageTradePriceAmount  NUMERIC(24,4)  ,
AverageTradePriceISOCode  VARCHAR(3)  ,
BasicTariffPriceAmount  NUMERIC(24,4)  ,
BasicTariffPriceISOCode  VARCHAR(3)  ,
ProductClass  VARCHAR(50)  ,
IsDrugNotMappedIndicator  NUMERIC(1)  ,
IsFreeFormatDrugIndicator  NUMERIC(1)  ,
DosageUnitDescription  VARCHAR(255)  ,
IsEndorsableIndicator  NUMERIC(1)  ,
IsFlavouredIndicator  NUMERIC(1)  ,
PrescribedProductType  VARCHAR(50)  ,
IsHighRiskIndicator  NUMERIC(1)  ,
IsCommonDrugServiceCodeMatchedIndicator  NUMERIC(1)  ,
ControlledDrugCode  VARCHAR(50)  ,
UncatalogueProductType  VARCHAR(50)  ,
BNFWarning2  VARCHAR(4000)  ,
Form  VARCHAR(255)  ,
Strength  VARCHAR(255)  ,
IsControlledDrugIndicator  NUMERIC(1)  ,
DMDDescription  VARCHAR(255)  ,
OriginalProductName  VARCHAR(255)  ,
VTMCode  VARCHAR(255)  ,
VTMDescription  VARCHAR(255)  ,
OldCommonDrugServiceCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--Owing
create table ser_pharmaceuticals.Owing
(
OwingSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
PrescribedItemID  NUMERIC(19)  ,
DispensedItemID	NUMERIC(19),     
SourceKey VARCHAR(80),    -- changed to nullable
CreationDate  DATETIME2  ,
LastChangeDate  DATETIME2  ,
IsNotDispensedIndicator  NUMERIC(1)  ,
OwingQuantity  NUMERIC(15,5)  ,
OwingStatus  VARCHAR(50)  ,
DispensedItemCode  VARCHAR(255)  ,
SourceSystemID  NUMERIC(19)  NOT NULL,
QuantityNotSupplied  NUMERIC(15,5)  ,
OldQuantity  NUMERIC(15,5)  ,
StoreCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);  


--MasterPrescribedItem
create table ser_pharmaceuticals.MasterPrescribedItem
(
MasterPrescribedItemSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
ElectronicPrescribedItemID NUMERIC(19),       
PrescriptionFormID NUMERIC(19),
PrescribedItemID NUMERIC(19),
SourceKey  VARCHAR(255)  NOT NULL,
EPrescribedItemCode  VARCHAR(50)  ,
PrescriptionFormCode  VARCHAR(50)  ,
PrescribedItemCode  VARCHAR(255)  ,
EventsNumber  NUMERIC(12)  ,
CurrentEventNumber  NUMERIC(12)  ,
Duration  VARCHAR(255)  ,
DurationUOM  VARCHAR(50)  ,
Frequency  VARCHAR(255)  ,
IsNotDispensableIndicator  NUMERIC(1)  ,
DispensingEventQuantity  NUMERIC(15,5)  ,
StoreCode  VARCHAR(50)  ,
MasterPrescribedItemStatus  VARCHAR(50)  ,
ProductDescription  VARCHAR(255)  ,
ProductCommonDrugServiceCode  VARCHAR(50)  ,
RunningTotal  NUMERIC(15,5)  ,
PrescribedDate  DATE  ,
TSRPracticeReportID  NUMERIC(19)  ,
TSRReferenceCode  VARCHAR(50)  ,
IsElectronicIndicator  NUMERIC(1)  ,
NotDispensableDate  DATE  ,
CancelledDate  DATE  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--Instalment
create table ser_pharmaceuticals.Instalment
(
InstalmentSKID  NUMERIC(19)  NOT NULL,
PharmacyProductSKUID  NUMERIC(19)  ,
PrescribedItemID  NUMERIC(19)  ,  --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
CollectionDays  NUMERIC(12)  ,
CollectionFrequency  VARCHAR(50)  ,
Duration  NUMERIC(12)  ,
InstalmentStartDate  DATETIME2  ,
IsMondayIndicator  NUMERIC(1)  ,
IsTuesdayIndicator  NUMERIC(1)  ,
IsWednesdayIndicator  NUMERIC(1)  ,
IsThursdayIndicator  NUMERIC(1)  ,
IsFridayIndicator  NUMERIC(1)  ,
IsSaturdayIndicator  NUMERIC(1)  ,
IsSundayIndicator  NUMERIC(1)  ,
IsSeparateContainersIndicator  NUMERIC(1)  ,
IsSupervisedIndicator  NUMERIC(1)  ,
IsTwoInstalmentsPerDayIndicator  NUMERIC(1)  ,
ProductSKUCode  VARCHAR(50)  ,
LinePrinted  NUMERIC(12)  ,
InstalmentType  VARCHAR(50)  ,
UpdateTime  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--InstalmentItem
create table ser_pharmaceuticals.InstalmentItem
(
InstalmentItemSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
InstalmentID  NUMERIC(19)  , --Changed to nullable
DispensedItemID NUMERIC(19), --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
CollectionDate  DATE  ,
DailyQuantity  NUMERIC(15,5)  ,
InstalmentDate  DATE  ,
Ordering  NUMERIC(12)  ,
Progressive  NUMERIC(12)  ,
Quantity  NUMERIC(15,5)  ,
InstalmentStatus  VARCHAR(50)  ,
IsSupervisedIndicator  NUMERIC(1)  ,
IsPrintedIndicator  NUMERIC(1)  ,
DispensedItemCode  VARCHAR(50)  ,
UpdateStatusTime  DATETIME2  ,
IsCollectedIndicator  NUMERIC(1)  ,
StoreCode  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--DispensedItem
CREATE TABLE ser_pharmaceuticals.DispensedItem
(
DispensedItemSKID  NUMERIC(19)  NOT NULL,
OwingID  NUMERIC(19)  ,
PrescribedItemID  NUMERIC(19) , --Changed to nullable
SourceKey  VARCHAR(255)  NOT NULL,
AutomationStatus  VARCHAR(50)  ,
SourceSystemID  nUMERIC(19)  NOT NULL,
DispensedDate  DATETIME2  ,
ItemNumber  NUMERIC(12)  ,
Quantity  NUMERIC(15,5)  ,
Sequence  NUMERIC(12)  ,
IsPatientPreferenceIndicator  NUMERIC(1)  ,
ReasonForSupply  VARCHAR(50)  ,
ReasonManualConfirmation  VARCHAR(50)  ,
ReplacedDispensedCode  VARCHAR(50)  ,
ReplacedUser  VARCHAR(50)  ,
ScannedQuantity  NUMERIC(15,5)  ,
ScanStatus  VARCHAR(50)  ,
DosageUnit  VARCHAR(50)  ,
DispensedQuantity  NUMERIC(15,5)  ,
IsSKUOverStockedIndicator  NUMERIC(1)  ,
ExpirationDate  DATE  ,
QuantityNotified  NUMERIC(15,5)  ,
NotificationTime  DATETIME2  ,
Orderable  VARCHAR(50)  ,
IsAdditionalEndorsementIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--DispensedProduct
CREATE TABLE ser_pharmaceuticals.DispensedProduct
(
DispensedProductSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,
PharmacyProductSKUID  NUMERIC(19)  ,
DispensedItemID  NUMERIC(19) , --Changed to nullable
ActualProductPackID NUMERIC(19) ,   
SupplierID NUMERIC(19),
SourceKey  VARCHAR(80)  NOT NULL,
ActualProductPackCode  VARCHAR(50)  ,
CommonDrugServiceCode  VARCHAR(50)  ,
CostPriceAmount  NUMERIC(24,4)  ,
CostPriceISOCode  VARCHAR(3)  ,
DispensedProductName  VARCHAR(255)  ,
ProductSKUCode  VARCHAR(50)  ,
ShortName  VARCHAR(255)  ,
SourceType  VARCHAR(50)  ,
TariffPriceAmount  NUMERIC(24,4)  ,
TariffPriceISOCode  VARCHAR(3)  ,
UnitPriceAmount  NUMERIC(24,4)  ,
UnitPriceISOCode  VARCHAR(3)  ,
PackQuantity  NUMERIC(15,5)  ,
BuyingMultiple  NUMERIC(12)  ,
IsBuyingMultipleEnforcedIndicator  NUMERIC(1)  ,
IsBuyingMultipleOptimisationIndicator  NUMERIC(1)  ,
PackName  VARCHAR(255)  ,
IsPreferredIndicator  NUMERIC(1)  ,
PIPCode  VARCHAR(50)  ,
RecevingQuantity  NUMERIC(15,5)  ,
SupplierCode  VARCHAR(50)  ,
IsRetailUsedIndicator  NUMERIC(1)  ,
DosageUnitDescription  VARCHAR(255)  ,
StoreCode  VARCHAR(50)  ,
FullDescription  VARCHAR(255)  ,
DMDDescription  VARCHAR(255)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);

--Parameter
CREATE TABLE ser_pharmaceuticals.Parameter
(
ParameterSKID  NUMERIC(19)  NOT NULL,
SourceKey  VARCHAR(80)  NOT NULL,
GroupingReference  VARCHAR(50)  ,
ParameterCategory  VARCHAR(50)  ,
ParameterCode  VARCHAR(50)  ,
DefaultValue  VARCHAR(255)  ,
Format  VARCHAR(50)  ,
ParameterName  VARCHAR(255)  ,
SubCategory  VARCHAR(50)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);  


--ParameterValue
CREATE TABLE ser_pharmaceuticals.ParameterValue
(
ParameterValueSKID  NUMERIC(19)  NOT NULL,
ParameterID  NUMERIC(19)  ,
PharmacyProductID  VARCHAR(80)  ,
PharmacyProductSKUID  NUMERIC(19)  ,
PharmacyStoreSiteRoleId  BIGINT  ,
SourceType  VARCHAR(50)  ,
ServiceTypeCode  VARCHAR(50)  ,
CreationTime  DATETIME2  ,
UpdateTime  DATETIME2  ,
SiteCode  VARCHAR(50)  ,
Value  VARCHAR(255)  ,
ValueComment  VARCHAR(255)  ,
Area  VARCHAR(50)  ,
ReviewDate  DATE  ,
ConfigurationLevel  VARCHAR(50)  ,
SourceKey  NUMERIC(19)  NOT NULL,
StartDate  DATETIME2 ,
EndDate  DATETIME2  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--MessageNotification
CREATE TABLE ser_pharmaceuticals.MessageNotification
(
MessageNotificationSKID  NUMERIC(19)  NOT NULL,
PharmacyStoreSiteRoleId  BIGINT  ,  --Changed to nullable
SourceKey  VARCHAR(80)  NOT NULL,
SiteCode  VARCHAR(50)  ,
SendingTime  DATETIME2  ,
MessageReasonCode  VARCHAR(255)  ,
MessageNotificationStatus  VARCHAR(50)  ,
APIVersion  VARCHAR(255)  ,
Payload  NVARCHAR(4000)  ,
MessageID  VARCHAR(255)  ,
TotalMessages  NUMERIC(12)  ,
RecipientList  VARCHAR(4000)  ,
ErrorPayload  NVARCHAR(4000)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT 
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
); 

--MessageReason
CREATE TABLE ser_pharmaceuticals.MessageReason
(
MessageReasonSKID  NUMERIC(19)  NOT NULL,
SourceKey  VARCHAR(80)  NOT NULL,
ReasonType  VARCHAR(255)  ,
MessageBody  VARCHAR(255)  ,
CarerMessageBody  VARCHAR(255)  ,
DisplayOrder  NUMERIC(12)  ,
IsDefaultReasonIndicator  NUMERIC(1)  ,
RunDateTime DATETIME2,
Year VARCHAR(4),
Month VARCHAR(2),
Day VARCHAR(2),
RecordStatusFlag  CHAR(1),
CreatedTime DATETIME2,
UpdatedTime DATETIME2,
LOVRecordSourceID  INT  NOT NULL,
ETLRunLogID  INT  
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);















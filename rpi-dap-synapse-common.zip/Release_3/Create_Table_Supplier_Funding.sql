
/*
**************************************************************************************************************************

Script Name                          : Create_Tables_SS_RPT_SUPPLIER_FUNDING
Purpose                              : Create Tables for Consumption Layer
***************************************************************************************** 
Modification History

**************************************************************************************************************************
Date         :      Modified By         : Description
==========================================================================================================================
20-Dec-2021   :   Pandiarajan        : First version of create tables script for SS_RPT_SUPPLIER_FUNDING
20-Dec-2021   :  Rajadeepika Chandrasekeran : In PRODUCT_DESCRIPTION,Modified data type [VARCHAR](256) to [VARCHAR](254)
20-Dec-2021   :  Rajadeepika Chandrasekeran : In PERIOD_P_KEY,Modified data type [VARCHAR](10) to [VARCHAR](6)
20-Dec-2021   :  Rajadeepika Chandrasekeran : campaign_NUMBER_P_KEY attribute name changed to CAMPAIGN_NUMBER_P_KEY
**************************************************************************************************************************

*/

CREATE TABLE [CON_DWH].[SS_RPT_SUPPLIER_FUNDING]
	(
	 [DATE_FROM] [DATE] NOT NULL,
	 [DATE_TO] [DATE] NOT NULL,
	 [PRODUCT_SOURCE_KEY_P_KEY] [INT] NOT NULL,
	 [PRODUCT_DESCRIPTION] [VARCHAR](150) NOT NULL,
	 [AREA_P_KEY] [VARCHAR] (50) NOT NULL,
	 [PERIOD_P_KEY] [VARCHAR] (7) NOT NULL,
	 [CAMPAIGN_NUMBER_P_KEY] [INT] NOT NULL,
	 [FILE_NAME_CODE] [VARCHAR] (180) NOT NULL,
	 [RETROSPECTIVE_FUNDING_AMOUNT] [DECIMAL] (30,5) NOT NULL,
	 [CREATE_DATETIME] [DATETIME2] NOT NULL,
	 [UPDATE_DATETIME] [DATETIME2] NULL
	
)
WITH 
(
    CLUSTERED COLUMNSTORE INDEX,
    DISTRIBUTION = ROUND_ROBIN
);
GO
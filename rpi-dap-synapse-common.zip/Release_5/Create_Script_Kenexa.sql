
--UserType

CREATE TABLE [ser_hr].[UserType]
(
UserTypeSKId BIGINT NOT NULL,
UserTypeId INT NOT NULL,
UserTypeDescription NVARCHAR(255),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL, 
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);



--UserDetail

CREATE TABLE [ser_hr].[UserDetail]
(
UserSKId BIGINT NOT NULL,
UserDetailUserTypeId BIGINT NOT NULL,
UserId INT NOT NULL,
Country VARCHAR(50),
Locale INT,
LanguageCode VARCHAR(2),
IsManagerIndicator TINYINT,
IsRecruiterIndicator TINYINT,
EnterpriseUser TINYINT,
UserStatus INT NOT NULL,
UserType INT NOT NULL,
UserGroupName NVARCHAR(30),
EmployeeId NVARCHAR(15),
Department NVARCHAR(50),
Title NVARCHAR(50),
Phone NVARCHAR(300),
Fax NVARCHAR(40),
SupervisorId NVARCHAR(40),
Role NVARCHAR(100),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CandidateType

CREATE TABLE [ser_hr].[CandidateType]
(
CandidateTypeSKId BIGINT NOT NULL,
CandidateTypeId INT NOT NULL,
CandidateTypeDescription NVARCHAR(75) NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Candidate

CREATE TABLE [ser_hr].[Candidate]
(
CandidateSKId BIGINT NOT NULL,
CandidateTypeChangedUserId BIGINT,
CandidateResumeKey INT NOT NULL,
CandidateAddress1 NVARCHAR(300),
CandidateAddress2 NVARCHAR(300),
CandidateCity NVARCHAR(45),
CandidateType NVARCHAR(75),
CandidateState NVARCHAR(100),
CandidateCountry NVARCHAR(50),
CandidateDateAdded DATETIME2,
CandidateDateModified DATETIME2,
CandidateDegree NVARCHAR(300),
CandidateEmail NVARCHAR(300),
CandidateFirstName NVARCHAR(300),
CandidateGPA FLOAT,
GraduationYear INT,
HomePhoneNumber NVARCHAR(300),
JobTitle NVARCHAR(60),
CandidateLastName NVARCHAR(300),
CandidateLocale INT,
Major NVARCHAR(80),
CandidateMiddleName NVARCHAR(300),
OrganisationName NVARCHAR(300),
CandidateOtherPhoneNumber NVARCHAR(300),
CandidateSchoolName NVARCHAR(100),
CandidateAddressZipCode NVARCHAR(300),
IsCandidateActiveIndicator INT NOT NULL,
IsCandidateSecureIndicator INT NOT NULL,
CandidateStackingField NVARCHAR(128),
CandidateCellPhone NVARCHAR(300),
CandidateHomePage VARCHAR(300),
CandidateFaxNumber NVARCHAR(300),
BrassringReferenceID INT NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--FormType

CREATE TABLE [ser_hr].[FormType]
(
FormTypeSKId BIGINT NOT NULL,
FormTypeId INT NOT NULL,
FormName NVARCHAR(255),
FormTypeIndicator VARCHAR(1),
IsFormTypeActiveIndicator INT NOT NULL,
IsMultiple NVARCHAR(10),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--MasterRefLOV

CREATE TABLE [ser_hr].[MasterRefLOV]
(
MasterRefLOVSKId BIGINT NOT NULL,
CodeId INT NOT NULL,
Code NVARCHAR(35) NOT NULL,
Description NVARCHAR(70),
LongDescription NVARCHAR(4000),
CodeTypeId INT NOT NULL,
CodeTypeDescription NVARCHAR(70),
IsCodeActiveIndicator INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--TalentGatewaySite

CREATE TABLE [ser_hr].[TalentGatewaySite]
(
TalentGatewaySiteSKId BIGINT NOT NULL,
SiteId INT NOT NULL,
SiteName NVARCHAR(50),
Language NVARCHAR(50),
SiteType NVARCHAR(50),
IsActiveIndicator INT NOT NULL,
GroupId INT,
GroupName NVARCHAR(50),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--GridAxis

CREATE TABLE [ser_hr].[GridAxis]
(
GridAxisSKId BIGINT NOT NULL,
GridAxisId INT NOT NULL,
QuestionId INT NOT NULL,
GridAxisName NVARCHAR(255) NOT NULL,
GridType  VARCHAR(6) NOT NULL,
IsGridAxisActiveIndicator NVARCHAR(10),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--SearchLogMaster

CREATE TABLE [ser_hr].[SearchLogMaster]
(
SearchLogMasterSKId BIGINT NOT NULL,
SearchId INT NOT NULL,
SearchLogMasterUserId BIGINT,
SearchType NVARCHAR(25),
SortField NVARCHAR(255),
SortFieldType NVARCHAR(255),
RequisitionFolderId INT,
ReasonForNoRequistion NVARCHAR(255),
SearchReason NVARCHAR(255),
FilterFolderId INT,
SearchedOn DATETIME2,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CandidateEducation

CREATE TABLE [ser_hr].[CandidateEducation]
(
CandidateEducationSKId BIGINT NOT NULL,
EducationSequence INT NOT NULL,
CandidateId BIGINT NOT NULL,
CandidateResumeKey INT NOT NULL,
CandidateDegree NVARCHAR(60),
CandidateGraduateYear INT,
Major NVARCHAR(80),
CandidateGPA FLOAT,
IsMostRecentEducationIndicator VARCHAR(5),
SchoolName NVARCHAR(100),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CandidateExperience

CREATE TABLE [ser_hr].[CandidateExperience]
(
CandidateExperienceSKId BIGINT NOT NULL,
ExperienceSequence INT NOT NULL,
CandidateId BIGINT NOT NULL,
CandidateResumeKey INT NOT NULL,
JobTitle NVARCHAR(80),
OrganisationName NVARCHAR(80),
WorkStartYear INT,
WorkEndYear INT,
IsMostRecentExperienceIndicator VARCHAR(5),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--QuestionType

CREATE TABLE [ser_hr].[QuestionType]
(
QuestionTypeSKId BIGINT NOT NULL,
QuestionTypeFormTypeId BIGINT NOT NULL,
QuestionTypeId INT NOT NULL,
LanguageCode VARCHAR(2),
QuestionDataType NVARCHAR(50) NOT NULL,
QuestionDBName NVARCHAR(255) NOT NULL,
QuestionDescription NVARCHAR(4000),
IsQuestionTypeActiveIndicator INT NOT NULL,
DisplayOrder INT,
OptionQuestionId INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--UserApproval

CREATE TABLE [ser_hr].[UserApproval]
(
UserApprovalSKId BIGINT NOT NULL,
UserApprovalUserId BIGINT NOT NULL,
UserId INT NOT NULL,
ApprovalId INT NOT NULL,
ApprovalTitle NVARCHAR(50),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--SearchLogDetail

CREATE TABLE [ser_hr].[SearchLogDetail]
(
SearchLogDetailSKId BIGINT NOT NULL,
SearchLogDetailSearchId BIGINT NOT NULL,
SearchField NVARCHAR(255),
SearchValue NVARCHAR(4000),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--UserOrganisationGroup

CREATE TABLE [ser_hr].[UserOrganisationGroup]
(
UserOrganisationGroupSKId BIGINT NOT NULL,
UserOrganisationGroupUserId BIGINT NOT NULL,
UserId INT NOT NULL,
OrganisationGroupId INT NOT NULL,
OrganisationGroupName NVARCHAR(40),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Option

CREATE TABLE [ser_hr].[Option]
(
OptionSKId BIGINT NOT NULL,
OptionQuestionTypeId BIGINT NOT NULL,
OptionId INT NOT NULL,
LanguageCode VARCHAR(2),
OptionCode NVARCHAR(255),
OptionDescription NVARCHAR(255),
IsOptionActiveIndicator INT NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--FormFolder

CREATE TABLE [ser_hr].[FormFolder]
(
FormFolderSKId BIGINT NOT NULL,
FolderId INT NOT NULL,
FolderDescription NVARCHAR(70),
FolderType NVARCHAR(50) NOT NULL,
FolderStatus NVARCHAR(10),
FolderOwner INT NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CandidateTypeHistory

CREATE TABLE [ser_hr].[CandidateTypeHistory]
(
CandidateTypeHistorySKId BIGINT NOT NULL,
CandidateTypeHistoryCandidateId BIGINT NOT NULL,
CandidateTypeHistoryCandidateTypeId BIGINT NOT NULL,
CandidateTypeHistoryId INT NOT NULL,
ChangeDate DATETIME2 NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--ReferralSource

CREATE TABLE [ser_hr].[ReferralSource]
(
ReferralSourceSKId BIGINT NOT NULL,
ReferralSourceCandidateId BIGINT,
ReferralSourceFormFolderId BIGINT,
SubmissionId BIGINT NOT NULL,
ReferrerLastName NVARCHAR(12),
ReferrerFirstName NVARCHAR(100),
ReferrerEmail NVARCHAR(200),
ReferrerSubmissionDate DATETIME2,
ReferralStatus NVARCHAR(100),
ReferralStatusDescription NVARCHAR(150),
ReferralStatusDescriptionName NVARCHAR(150),
StatusDate DATETIME2,
StatusUpdatedBy INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CandidateSubmissionRefLOV

CREATE TABLE [ser_hr].[CandidateSubmissionRefLOV]
(
CandidateSubmissionRefLOVSKId BIGINT NOT NULL,
CandidateSubmissionRefLOVFolderId BIGINT,
CandidateSubmissionRefLOVCandidateId BIGINT NOT NULL,
CandidateSubmissionRefLOVCodeId BIGINT NOT NULL,
CodeDetailId INT NOT NULL,
CodeText NVARCHAR(35) NOT NULL,
AddedOn DATETIME2 NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--FormDeleteHistory

CREATE TABLE [ser_hr].[FormDeleteHistory]
(
FormDeleteHistorySKId BIGINT NOT NULL,
FormDeleteHistoryCandidateId BIGINT,
FormDeleteHistoryFolderId BIGINT,
FormDeleteHistoryAddedByUserId BIGINT,
FormDeleteHistoryEditedByUserId BIGINT,
FormHistoryId INT NOT NULL,
DeletedBy INT NOT NULL,
DeletedDate DATETIME2 NOT NULL,
FormId INT NOT NULL,
FormTypeId INT NOT NULL,
LanguageCode VARCHAR(2),
AddedOn DATETIME2,
EditedOn DATETIME2,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--HRStatus

CREATE TABLE [ser_hr].[HRStatus]
(
HRStatusSKId BIGINT NOT NULL,
HRStatusCandidateId BIGINT NOT NULL,
HRStatusFolderId BIGINT NOT NULL,
CandidateResumeKey INT NOT NULL,
FolderId INT NOT NULL,
HRStatus NVARCHAR(70) NOT NULL,
IsHRStatusActiveIndicator INT NOT NULL,
AutoRequisition VARCHAR(40),
StatusDate DATETIME2,
ActionDate DATETIME2,
ApplyDate DATETIME2,
CandidateType NVARCHAR(75),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--FormInstance

CREATE TABLE [ser_hr].[FormInstance]
(
FormInstanceSKId BIGINT NOT NULL,
FormInstanceCandidateId BIGINT,
FormInstanceFolderId BIGINT,
FormInstanceFormTypeId BIGINT NOT NULL,
FormInstanceAddedByUserId BIGINT,
FormInstanceEditedByUserId BIGINT,
FormId INT NOT NULL,
LanguageCode VARCHAR(2),
AddedOn DATETIME2,
EditedOn DATETIME2,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--HRStatusHistory

CREATE TABLE [ser_hr].[HRStatusHistory]
(
HRStatusHistorySKId BIGINT NOT NULL,
HRStatusHistoryCandidateId BIGINT NOT NULL,
HRStatusHistoryFolderId BIGINT NOT NULL,
HRStatusHistoryUpdatedByUserId BIGINT NOT NULL,
CandidateResumeKey INT NOT NULL,
FolderId INT NOT NULL,
HRStatusHistoryId INT NOT NULL,
CurrentHRStatus NVARCHAR(70) NOT NULL,
UpdatedOn DATETIME2,
ActionDate DATETIME2,
CurrentStatus INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Communicationlink

CREATE TABLE [ser_hr].[Communicationlink]
(
CommunicationlinkSKId BIGINT NOT NULL,
CommunicationlinkCandidateId BIGINT NOT NULL,
CommunicationlinkSentForFolderId BIGINT,
CommunicationlinkSentByUserId BIGINT NOT NULL,
ElinkId INT NOT NULL,
EmailKey INT,
RecipientEmailAddress VARCHAR(300),
Response NVARCHAR(2000),
ResponseDate DATETIME2,
SentDate DATETIME2,
ViewedDate DATETIME2,
FormTypeId INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Stacking

CREATE TABLE [ser_hr].[Stacking]
(
StackingSKId BIGINT NOT NULL,
NewCandidateResumeKey INT NOT NULL,
OldCandidateResumeKey INT,
AddedOn DATETIME2 NOT NULL,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Requisition

CREATE TABLE [ser_hr].[Requisition]
(
RequisitionSKId BIGINT NOT NULL,
RequisitionFolderId BIGINT NOT NULL,
RequisitionFormTypeId BIGINT,
FolderId INT NOT NULL,
LanguageCode VARCHAR(2),
FormId INT,
RequisitionStatus NVARCHAR(50),
AutoRequisition NVARCHAR(40),
OptionalRequisition NVARCHAR(30),
NumberOfOfferedPosition INT,
DateOpen DATETIME2,
ManagerId INT,
RecruiterId INT,
RequisitionAddedBy INT,
RequisitionAddedDate DATETIME2,
RequisitionType NVARCHAR(30),
College NVARCHAR(4),
RequisitionPosition NVARCHAR(12),
AdvertisementCost NUMERIC(18),
TravelCost NUMERIC(18),
RelocationCost NUMERIC(18),
HRCost NUMERIC(18),
ExternalCost NUMERIC(18),
BonusCost NUMERIC(18),
JobTitle NVARCHAR(70),
JobCode NVARCHAR(35),
PositionsRemaining INT,
RequisitionClosedDate DATETIME2,
RequisitionApprovedDate DATETIME2,
Department NVARCHAR(75),
Location NVARCHAR(50),
DepartmentCode NVARCHAR(75),
LocationCode NVARCHAR(50),
DaysOpen INT,
DaysOnHold INT,
DraftStatus INT,
IsRequisitionSecureIndicator INT,
RequisitionStartDate DATETIME2,
RequisitionNote NVARCHAR(4000),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--FormResponse

CREATE TABLE [ser_hr].[FormResponse]
(
FormResponseSKId BIGINT NOT NULL,
FormResponseFolderId BIGINT,
FormResponseQuestionTypeId BIGINT NOT NULL,
FormResponseFormId BIGINT NOT NULL,
FormId INT NOT NULL,
FormResponseId BIGINT NOT NULL,
LanguageCode VARCHAR(2),
QuestionResponseText NVARCHAR(4000),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--RequisitionTeam

CREATE TABLE [ser_hr].[RequisitionTeam]
(
RequisitionTeamSKId BIGINT NOT NULL,
RequisitionTeamFolderId BIGINT,
RequisitionTeamUserId BIGINT,
FolderId INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--RequistionPostingActivity

CREATE TABLE [ser_hr].[RequistionPostingActivity]
(
RequistionPostingActivitySKId BIGINT NOT NULL,
RequistionPostingActivityFolderId BIGINT NOT NULL,
RequistionPostingActivityGatewaySiteId BIGINT NOT NULL,
FolderId INT NOT NULL,
GatewaySiteId INT NOT NULL,
GatewaySiteName NVARCHAR(50),
AddedOn DATETIME2,
DaysBeforePosting INT,
GatewayQuestionnaire NVARCHAR(128),
PostingStatus INT,
GatewayPostingDate DATETIME2,
GatewayPostingEndDate DATETIME2,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--RequistionPostingHistory

CREATE TABLE [ser_hr].[RequistionPostingHistory]
(
RequistionPostingHistorySKId BIGINT NOT NULL,
RequistionPostingHistoryFolderId BIGINT NOT NULL,
RequistionSiteId INT NOT NULL,
GatewaySiteId INT NOT NULL,
GatewaySiteName NVARCHAR(50),
OriginalPostedDate DATETIME2,
PostingRemovedDate DATETIME2,
ScheduledRemovalDate DATETIME2,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--RequisitionApproval

CREATE TABLE [ser_hr].[RequisitionApproval]
(
RequisitionApprovalSKId BIGINT NOT NULL,
RequisitionApprovalFolderId BIGINT NOT NULL,
RequisitionApprovalApprovalUserId BIGINT NOT NULL,
JobRequisitionApprovalId INT NOT NULL,
ApprovalTitle NVARCHAR(50),
ApprovalDate DATETIME2,
ApprovalStatusFlag INT NOT NULL,
ApprovalEmail NVARCHAR(80),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--RequisitionResponse

CREATE TABLE [ser_hr].[RequisitionResponse]
(
RequisitionResponseSKId BIGINT NOT NULL,
RequisitionResponseFolderId BIGINT NOT NULL,
RequisitionResponseQuestionTypeId BIGINT NOT NULL,
ResponseId INT NOT NULL,
FormId INT NOT NULL,
LanguageCode VARCHAR(2),
ResponseText NVARCHAR(4000),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--RequistionStatusHistory

CREATE TABLE [ser_hr].[RequistionStatusHistory]
(
RequistionStatusHistorySKId BIGINT NOT NULL,
RequistionStatusHistoryFolderId BIGINT NOT NULL,
RequistionStatusHistoryActionByUserId BIGINT NOT NULL,
RequistionStatusHistoryId INT NOT NULL,
RequisitionStatusDate DATETIME2,
RequistionStatus NVARCHAR(200),
FormId INT,
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

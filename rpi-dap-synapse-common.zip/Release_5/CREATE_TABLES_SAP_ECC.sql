/*
**************************************************************************************************************************
Script Name                          : Create_SAP_ECC_Version1.1 
Purpose                              : Create Table Script for SAP ECC
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================
05-Apr-2022   : Anisoor Rahman           : Created DDL script for SAP ECC 
18-Apr-2022   : Pandiarajan              : Updated the DDL                                
29-Apr-2022   : Afifa Azad               : Updated the DDL                                
**************************************************************************************************************************
*/

--CostCentreECC

CREATE TABLE [ser_hr].[CostCentreECC]
(
CostCentreSKId	BITINT NOT NULL,
CostCenterCode VARCHAR(10) NOT NULL,
ControllingArea VARCHAR(4),
ValidTo DATE,
ValidFrom DATE,
OrganizationCode VARCHAR(4),
CostCentreCategory VARCHAR(1),
PersonResponsible VARCHAR(20),
Currency VARCHAR(5),
ProfitCenter VARCHAR(10),
EnteredBy VARCHAR(12),
IsActualRevenuesIndicator VARCHAR(1),
IsPlanRevenuesIndicator VARCHAR(1),
HierarchyArea VARCHAR(12),
IsCompleteIndicator VARCHAR(1),
ObjectNumber VARCHAR(18),
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--CostCentreHierarchy

CREATE TABLE [ser_hr].[CostCentreHierarchy]
(
CostCentreCode VARCHAR(12),
CostCentre VARCHAR(10),
CostCentreParent VARCHAR(12),
CostCentreDescription VARCHAR(40),
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);


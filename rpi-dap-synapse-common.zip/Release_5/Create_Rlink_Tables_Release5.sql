/
**************************************************************************************************************************
Script Name                          : Create_Rlink_Release5 
Purpose                              : Create Table Script for Resource Link
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          : Modified By              : Description
==========================================================================================================================
04-Apr-2022   : Anisoor Rahman           : Created DDL script for Rlink     
22-Jun-2022   : Pandiarajan               : Create statement for Release 5                           

**************************************************************************************************************************
*/


--#9 CostCentre

CREATE TABLE [ser_hr].[CostCentre]
(
CostCentreCode VARCHAR(20) NOT NULL,
CostCentreSKID BIGINT NOT NULL,
CostCentreName VARCHAR(20),
CostCentreDescription VARCHAR(40),
CostCentreCreatedDate DATE,
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--#10 CostCentreDetail

CREATE TABLE [ser_hr].[CostCentreDetail]
(
OGGReferenceNumber BIGINT,
OGGInternalReferenceNumber BIGINT,
OGGReplicatedDateandTime DATE,
CostCentreSKID BIGINT NOT NULL,
CostCentreNoteReference VARCHAR(8),
CostCentreReference VARCHAR(40),
OGGOperation VARCHAR(2),
CostCentreShortCC VARCHAR(6),
RunDateTime DATETIME2 NOT NULL,
Year  VARCHAR(4) NOT NULL,
Month  VARCHAR(2) NOT NULL,
Day  VARCHAR(2) NOT NULL,
SourceSystemID  INT NOT NULL,
ActiveFlag VARCHAR(1)
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);



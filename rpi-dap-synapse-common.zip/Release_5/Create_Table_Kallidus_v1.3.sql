/*
**************************************************************************************************************************

Script Name                          : Create_Table_Kallidus_v1.3_WIP
Purpose                              : Create Tables for Curate 
***************************************************************************************** 
Modification History

************************************************************************************************************************ **
Date         :      Modified By         : Description
27-May-22    :      Goutham             :UserTrainingLesson.SignInHistoryTime and UserTrainingLesson.LessonCompletedTime changed to 
                                         varchar(25)
27-May-22    :      Goutham             : LearningEvent tableLearningEventStartTime,LearningEventEndTime  datatype length updated
30-May-22    :      Goutham             :UserLearningEvent.LearningEventCompletedTime datatype length updated


**************************************************************************************************************************

*/


--Lesson

CREATE TABLE [ser_hr].[Lesson]
(
LessonSKId BIGINT NOT NULL,
LessonId VARCHAR(40) NOT NULL,
LessonTypeId VARCHAR(30) NOT NULL,
LessonTitle VARCHAR(270) NOT NULL,
LessonCode VARCHAR(270) NOT NULL,
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--LearningEvent

CREATE TABLE [ser_hr].[LearningEvent]
(
LearningEventSKId BIGINT NOT NULL,
LearningEventId VARCHAR(38) NOT NULL,
LearningEventStartDate DATE,
LearningEventStartTime VARCHAR(25),
LearningEventEndDate DATE,
LearningEventEndTime VARCHAR(25),
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--Training

CREATE TABLE [ser_hr].[Training]
(
TrainingSKId BIGINT NOT NULL,
TrainingId VARCHAR(38) NOT NULL,
TrainingName VARCHAR(256) NOT NULL,
TrainingDescription VARCHAR(200) NOT NULL,
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--User


CREATE TABLE [ser_hr].[User]
(
UserSKId BIGINT NOT NULL,
UserId VARCHAR(40) NOT NULL,
UserName VARCHAR(300),
FirstName NVARCHAR(200) COLLATE Latin1_General_100_CI_AI_KS_WS,
LastName NVARCHAR(200) COLLATE Latin1_General_100_CI_AI_KS_WS,
FullName NVARCHAR(500) COLLATE Latin1_General_100_CI_AI_KS_WS,
Email VARCHAR(300),
ActiveFlag VARCHAR(1) NOT NULL,
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = REPLICATE
);


--UserGroup

CREATE TABLE [ser_hr].[UserGroup]
(
UserGroupSKId BIGINT NOT NULL,
UserId VARCHAR(40) NOT NULL,
UserPrimaryUserGroup VARCHAR(200),
UserGroupName NVARCHAR(200) COLLATE Latin1_General_100_CI_AI_KS_WS NOT NULL,
UserGroupCode NVARCHAR(200) COLLATE Latin1_General_100_CI_AI_KS_WS NOT NULL,
UserGroupCategory VARCHAR(200),
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = REPLICATE
);

--UserLearningCourse

CREATE TABLE [ser_hr].[UserLearningCourse]
(
TrainingId VARCHAR(40) NOT NULL,
UserId VARCHAR(40) NOT NULL,
TrainingAssignedIndicator VARCHAR(3) NOT NULL,
TrainingEnabledIndicator VARCHAR(3) NOT NULL,
TrainingCompletedDate VARCHAR(25),
UserOrganisationId	VARCHAR(10) NOT NULL,
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--UserLearningEvent

CREATE TABLE [ser_hr].[UserLearningEvent]
(
UserId VARCHAR(40) NOT NULL,
LearningEventId VARCHAR(38) NOT NULL,
LearningEventCode VARCHAR(200) NOT NULL,
LearningEventEnabledIndicator VARCHAR(3),
LearningEventCompletedDate varchar(25),
LearningEventCompletedTime VARCHAR(25),
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

--UserTrainingLesson

CREATE TABLE [ser_hr].[UserTrainingLesson]
(
UserId VARCHAR(40) NOT NULL,
LessonId VARCHAR(40) NOT NULL,
LessonCertifiedDate	VARCHAR(25),
LessonDurationSeconds INT NOT NULL,
LessonEnabledIndicator	VARCHAR(3)	NOT NULL,
LessonResultAutoResetDate DATE,
LessonResultLastResetDate	DATE,
LessonBestStatus VARCHAR(20) NOT NULL,
LessonLatestStatus	VARCHAR(20) NOT NULL,
LessonLatestScore	DECIMAL(7,2) NOT NULL,
LessonBestScore	DECIMAL(7,2)	NOT NULL,
NumberOfLessonsUsed	INT	NOT NULL,
LessonCompletedDate	VARCHAR(25),
LessonCompletedTime VARCHAR(25),
LessonCustomField01 VARCHAR(1024),
LessonStartDate VARCHAR(25),
DatabaseLastRefreshed VARCHAR(25),
SigninHistoryDate VARCHAR(25),
SignInHistoryTime VARCHAR(25),
ActiveFlag VARCHAR(1),
RunDateTime DATETIME2 NOT NULL,
Year VARCHAR(4) NOT NULL,
Month VARCHAR(2) NOT NULL,
Day VARCHAR(2) NOT NULL,
SourceSystemID INT NOT NULL
)
WITH
(
 CLUSTERED COLUMNSTORE INDEX,
 DISTRIBUTION = ROUND_ROBIN
);

/*
**************************************************************************************************************************
Script Name                          : Drop_Table_RS

**************************************************************************************************************************
*/
--RecruitmentServiceCenterActivity

DROP TABLE [ser_hr].[RecruitmentServiceCenterActivity]

--RecruitmentServiceCenterApplication

DROP TABLE [ser_hr].[RecruitmentServiceCenterApplication]

--RecruitmentServiceCenterOffer

DROP TABLE [ser_hr].[RecruitmentServiceCenterOffer]

--RecruitmentServiceCenterOnboarding

DROP TABLE [ser_hr].[RecruitmentServiceCenterOnboarding]

--RecruitmentServiceCenterRequisition

DROP TABLE [ser_hr].[RecruitmentServiceCenterRequisition]

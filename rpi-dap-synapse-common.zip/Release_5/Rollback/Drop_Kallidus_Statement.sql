DROP TABLE [ser_hr].[Lesson];
DROP TABLE [ser_hr].[LearningEvent];
DROP TABLE [ser_hr].[Training];
DROP TABLE [ser_hr].[User];
DROP TABLE [ser_hr].[UserGroup];
DROP TABLE [ser_hr].[UserTraining];
DROP TABLE [ser_hr].[UserLearningEvent];
DROP TABLE [ser_hr].[UserTrainingLesson];

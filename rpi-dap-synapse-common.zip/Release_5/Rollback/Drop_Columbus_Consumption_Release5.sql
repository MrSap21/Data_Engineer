/
**************************************************************************************************************************
Script Name                          : Drop_Columbus_Consumption_Release5 
Purpose                              : Drop_Columbus_Consumption_Release5 
**************************************************************************************************************************
*/



DROP TABLE [con_columbus].[DIM_DISPENSING_PACK_SIZE];
DROP TABLE [con_columbus].[DIM_PRESCRIBABLE_PRODUCT];
DROP TABLE [con_columbus].[DIM_MESSAGE_REASON];
DROP TABLE [con_columbus].[DIM_CALENDAR];
DROP TABLE [con_columbus].[DIM_PHARMACY_SITE];
DROP TABLE [con_columbus].[DIM_ADJUSTMENT_REASON];
DROP TABLE [con_columbus].[DIM_PHARMACY_PRODUCT_PRODUCT_SKU];
DROP TABLE [con_columbus].[DIM_PREFERRED_PRODUCT_SKU];
DROP TABLE [con_columbus].[DIM_ACTUAL_PRODUCT_PACK];
DROP TABLE [con_columbus].[FACT_ADDITIONAL_ENDORSEMENT];
DROP TABLE [con_columbus].[FACT_ADJUSTMENT_REASON];
DROP TABLE [con_columbus].[FACT_DAILY_DISPENSED_QUANTITY];
DROP TABLE [con_columbus].[FACT_DAILY_PRESCRIPTION_REPEAT];
DROP TABLE [con_columbus].[FACT_DISPENSED_EVENT];
DROP TABLE [con_columbus].[FACT_EPS_ERD_INSTALMENT_CLAIMED_DISPENSED];
DROP TABLE [con_columbus].[FACT_HOLDING_VALUES];
DROP TABLE [con_columbus].[FACT_MESSAGE_NOTIFICATION];
DROP TABLE [con_columbus].[FACT_NORTH_WEST_OSTOMY_ SUPPLY_PRESCRIBING];
DROP TABLE [con_columbus].[FACT_TOTAL_NORTH_WEST_OSTOMY_ SUPPLY_PRESCRIBING];
DROP TABLE [con_columbus].[FACT_ODS_OWINGS];
DROP TABLE [con_columbus].[FACT_ODS_OWINGS_WEEKLY];
DROP TABLE [con_columbus].[FACT_OVERSTOCK_PRODUCT_STOCK_KEEPING_UNITS];
DROP TABLE [con_columbus].[FACT_PATIENT_MCR];
DROP TABLE [con_columbus].[FACT_PATIENT_MCR_TOTAL];
DROP TABLE [con_columbus].[FACT_STOCK_VALUE];
DROP TABLE [con_columbus].[FACT_CLINICAL_CHECK];
DROP TABLE [con_columbus].[FACT_ELECTRONIC_SCRIPTS_RISK];
DROP TABLE [con_columbus].[FACT_DISP_ITEMS_CAREHOME];
DROP TABLE [con_columbus].[FACT_DISPENSING_INSTALMENT];
DROP TABLE [con_columbus].[FACT_DISPENSED_NO_BARCODE];
DROP TABLE [con_columbus].[FACT_DSP_PRESCRIPTION_DAILY];
DROP TABLE [con_columbus].[FACT_DDS_PRESCRIPTION];
DROP TABLE [con_columbus].[FACT_PATIENT_NMS];
DROP TABLE [con_columbus].[FACT_PATIENT_NMS_TOTAL];
DROP TABLE [con_columbus].[FACT_DISP_DRUG_TARIFF];
DROP TABLE [con_columbus].[FACT_AMS_ELECTRONIC_SCRIPTS];
DROP TABLE [con_columbus].[FACT_OWINGS_REDEMPTION_DAILY];
DROP TABLE [con_columbus].[FACT_EMERGENCY_SUPPLY_RECONCILIATION];
DROP TABLE [con_columbus].[FACT_SCOTLAND_PRESCRIPTION_AT_RISK];
DROP TABLE [con_columbus].[FACT_PREFERENCE_OVERRIDE];
DROP TABLE [con_columbus].[FACT_PRODUCT_SKU_USAGE];
DROP TABLE [con_columbus].[FACT_DISPENSED_MCR_REPORT];
DROP TABLE [con_columbus].[RPT_HIGH_DISPENSES];
DROP TABLE [con_columbus].[RPT_INVESTIGATION_NEW_STOCK];
DROP TABLE [con_columbus].[RPT_STOCK_ADJUSTMENTS];
DROP TABLE [con_columbus].[RPT_PURCHASE_ORDER_AND_GOODS_RECEIPT];
DROP TABLE [con_columbus].[RPT_EXCEPTION_COUNTS];
DROP TABLE [con_columbus].[DIM_SCRIPT_MODE];
DROP TABLE [con_columbus].[DIM_DISPENSING_PACK_PRICE];

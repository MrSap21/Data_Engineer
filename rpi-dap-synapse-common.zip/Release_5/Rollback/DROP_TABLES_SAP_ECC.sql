--Drop script for SAP ECC Tables

DROP TABLE test_curate.ResponsibilityCenter
DROP TABLE test_curate.RelatedResponsibilityCenter
/*
**************************************************************************************************************************
Script Name                          : Drop_Table_Kenexa

**************************************************************************************************************************
*/

DROP TABLE  [ser_hr].[Candidate];
DROP TABLE  [ser_hr].[CandidateEducation];
DROP TABLE  [ser_hr].[CandidateExperience];
DROP TABLE  [ser_hr].[QuestionType];
DROP TABLE  [ser_hr].[Option];
DROP TABLE  [ser_hr].[ReferralSource];
DROP TABLE  [ser_hr].[RequistionPostingActivity];
DROP TABLE  [ser_hr].[RequistionPostingHistory];
DROP TABLE  [ser_hr].[RequistionStatusHistory];
DROP TABLE  [ser_hr].[RequisitionApproval];
DROP TABLE  [ser_hr].[RequisitionResponse];
DROP TABLE  [ser_hr].[Requisition];
DROP TABLE  [ser_hr].[RequisitionTeam];
DROP TABLE  [ser_hr].[UserApproval];
DROP TABLE  [ser_hr].[Stacking];
DROP TABLE  [ser_hr].[TalentGatewaySite];
DROP TABLE  [ser_hr].[UserType];
DROP TABLE  [ser_hr].[FormResponse];
DROP TABLE  [ser_hr].[User];
DROP TABLE  [ser_hr].[UserOrganisationGroup];
DROP TABLE  [ser_hr].[CandidateSubmissionRefLOV];
DROP TABLE  [ser_hr].[MasterReflLOV];
DROP TABLE  [ser_hr].[FormFolder];
DROP TABLE  [ser_hr].[FormInstance];
DROP TABLE  [ser_hr].[FormType];
DROP TABLE  [ser_hr].[FormDeleteHistory];
DROP TABLE  [ser_hr].[GridAxis];
DROP TABLE  [ser_hr].[GridAxis];
DROP TABLE  [ser_hr].[HRStatus];
DROP TABLE  [ser_hr].[SearchLogMaster];
DROP TABLE  [ser_hr].[SearchLogDetails];
DROP TABLE  [ser_hr].[HRStatusHistory];
DROP TABLE  [ser_hr].[CandidateTypeHistory];
DROP TABLE  [ser_hr].[CandidateTypes];
DROP TABLE  [ser_hr].[Communicationlink];

package com.wba.datalynx.ingest.preprocess.model;

import java.util.List;

public class ProcessResult {

    private final FileToProcess fileToProcess;
    private final List<ProcessedFile> outputFiles;
    private final List<FileToTrack> filesToTrack;

    public ProcessResult(FileToProcess fileToProcess, List<ProcessedFile> outputFiles, List<FileToTrack> filesToTrack) {
        this.fileToProcess = fileToProcess;
        this.outputFiles = outputFiles;
        this.filesToTrack = filesToTrack;
    }

    public FileToProcess getFileToProcess() {
        return fileToProcess;
    }

    public List<ProcessedFile> getOutputFiles() {
        return outputFiles;
    }

    public List<FileToTrack> getFilesToTrack() {
        return filesToTrack;
    }
}

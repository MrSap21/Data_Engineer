package com.wba.datalynx.ingest.preprocess.error;

public class UnknownTransformerException extends RuntimeException {

    public UnknownTransformerException() {
    }

    public UnknownTransformerException(String message) {
        super(message);
    }

    public UnknownTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnknownTransformerException(Throwable cause) {
        super(cause);
    }

    public UnknownTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.annotation.TransformerService;
import com.wba.datalynx.ingest.preprocess.error.XsltTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.MultipleXsltTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.OutputFile;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import com.wba.datalynx.ingest.preprocess.model.XsltTransformerOptions;
import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.QName;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.Serializer;
import net.sf.saxon.s9api.XdmAtomicValue;
import net.sf.saxon.s9api.XsltCompiler;
import net.sf.saxon.s9api.XsltExecutable;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.context.ApplicationContext;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@TransformerService("XSLT_TRANSFORMER")
public class XsltTransformer extends BaseTransformer {

    private final MultipleXsltTransformerOptions multipleXsltTransformerOptions;
    private final FileToProcessReader fileToProcessReader;
    private final OutputFileWriter outputFileWriter;

    public XsltTransformer(ApplicationContext applicationContext, Map<String, Object> transformerOptions) {
        super(applicationContext, transformerOptions);
        this.multipleXsltTransformerOptions = convertTransformerOptions(MultipleXsltTransformerOptions.class);
        this.fileToProcessReader = applicationContext.getBean(FileToProcessReader.class);
        this.outputFileWriter = applicationContext.getBean(OutputFileWriter.class);

        if (Objects.isNull(this.multipleXsltTransformerOptions)) {
            throw new XsltTransformerException("no XSLT transformer options specified");
        }

        if (CollectionUtils.isEmpty(this.multipleXsltTransformerOptions.getTransformations())) {
            throw new XsltTransformerException("no XSLT transformations specified");
        }
    }

    @Override
    public TransformResult transform(FileToProcess fileToProcess, OutputDirectory outputDirectory) {
        String inputFilepath = fileToProcess.getFilepath();

        List<ProcessedFile> processedFiles = multipleXsltTransformerOptions.getTransformations()
                                                                           .stream()
                                                                           .map(xsltTransformerOptions -> transformData(fileToProcess, outputDirectory, inputFilepath, xsltTransformerOptions))
                                                                           .collect(Collectors.toList());
        return new TransformResult(processedFiles);
    }

    private ProcessedFile transformData(FileToProcess fileToProcess, OutputDirectory outputDirectory, String inputFilepath, XsltTransformerOptions xsltTransformerOptions) {
        String inputFilepathRegex = xsltTransformerOptions.getInputFilepathRegex();
        String outputFilenameSubstitution = xsltTransformerOptions.getOutputFilenameSubstitution();
        String outputFilename = inputFilepath.replaceAll(inputFilepathRegex, outputFilenameSubstitution);
        String stylesheet = xsltTransformerOptions.getStylesheet();
        String outputFilepath = Paths.get(outputDirectory.getDirectoryPath(), outputFilename).toString();

        try {
            return doTransformData(fileToProcess, outputDirectory, xsltTransformerOptions, stylesheet, outputFilepath);
        } catch (SaxonApiException | IOException e) {
            throw new XsltTransformerException("failed to transform file " + fileToProcess.getFilepath()
                                                       + " in container " + fileToProcess.getContainerName()
                                                       + " on Storage Account " + fileToProcess.getStorageAccountName()
                                                       + " to file " + outputFilepath
                                                       + " in container " + outputDirectory.getContainerName()
                                                       + " on Storage Account " + outputDirectory.getStorageAccountName(),
                                               e);
        }
    }

    private ProcessedFile doTransformData(FileToProcess fileToProcess, OutputDirectory outputDirectory, XsltTransformerOptions xsltTransformerOptions, String stylesheet, String outputFilepath) throws SaxonApiException, IOException {
        try (InputStream dataStream = fileToProcessReader.readToStream(fileToProcess);
             Reader dataReader = new InputStreamReader(dataStream, StandardCharsets.UTF_8);
             Reader stylesheetReader = new StringReader(stylesheet);
             ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {

            Source xsltSource = new StreamSource(stylesheetReader);

            Processor processor = new Processor(false);
            XsltCompiler xsltCompiler = processor.newXsltCompiler();
            XsltExecutable xsltExecutable = xsltCompiler.compile(xsltSource);
            Serializer serializer = processor.newSerializer(byteArrayOutputStream);

            net.sf.saxon.s9api.XsltTransformer xsltTransformer = xsltExecutable.load();
            Optional<String> optionalInputParameterName = Optional.ofNullable(xsltTransformerOptions.getInputParameterName());

            if (optionalInputParameterName.isPresent()) {
                // if an input parameter name is present, pass the source data as a parameter;
                // useful for e.g., JSON transformations
                String dataString = IOUtils.toString(dataReader);
                xsltTransformer.setParameter(new QName(optionalInputParameterName.get()), new XdmAtomicValue(dataString));
            } else {
                // otherwise, pass it as source
                Source dataSource = new StreamSource(dataReader);
                xsltTransformer.setSource(dataSource);
            }

            xsltTransformer.setDestination(serializer);
            xsltTransformer.transform();

            String transformedData = new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8);

            OutputFile outputFile = new OutputFile();
            outputFile.setFilepath(outputFilepath);
            outputFile.setContainerName(outputDirectory.getContainerName());
            outputFile.setStorageAccountName(outputDirectory.getStorageAccountName());

            outputFileWriter.writeString(transformedData, outputFile);

            return new ProcessedFile(outputFilepath, outputDirectory.getStorageAccountName(), outputDirectory.getContainerName());
        }
    }

}

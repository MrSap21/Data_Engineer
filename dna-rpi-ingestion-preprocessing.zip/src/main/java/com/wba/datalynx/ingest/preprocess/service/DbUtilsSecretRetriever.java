package com.wba.datalynx.ingest.preprocess.service;

import com.databricks.dbutils_v1.DBUtilsHolder;
import com.databricks.dbutils_v1.DBUtilsV1;

public class DbUtilsSecretRetriever implements SecretRetriever {

    private final String secretScope;
    private final DBUtilsV1 dbUtils;

    public DbUtilsSecretRetriever(String secretScope) {
        this.secretScope = secretScope;
        this.dbUtils = DBUtilsHolder.dbutils();
    }

    @Override
    public String getSecret(String secretKey) {
        return dbUtils.secrets().get(secretScope, secretKey);
    }

}

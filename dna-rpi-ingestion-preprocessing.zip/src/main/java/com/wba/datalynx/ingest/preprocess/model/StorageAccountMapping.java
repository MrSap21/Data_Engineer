package com.wba.datalynx.ingest.preprocess.model;

public class StorageAccountMapping {

    private String storageAccountName;
    private ServicePrincipalCredential servicePrincipalCredential;

    public String getStorageAccountName() {
        return storageAccountName;
    }

    public void setStorageAccountName(String storageAccountName) {
        this.storageAccountName = storageAccountName;
    }

    public ServicePrincipalCredential getServicePrincipalCredential() {
        return servicePrincipalCredential;
    }

    public void setServicePrincipalCredential(ServicePrincipalCredential servicePrincipalCredential) {
        this.servicePrincipalCredential = servicePrincipalCredential;
    }

}

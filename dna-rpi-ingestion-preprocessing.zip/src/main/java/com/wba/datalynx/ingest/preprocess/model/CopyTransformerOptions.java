package com.wba.datalynx.ingest.preprocess.model;

public class CopyTransformerOptions {

    private String inputFilepathRegex;
    private String outputFilenameSubstitution;

    public String getInputFilepathRegex() {
        return inputFilepathRegex;
    }

    public void setInputFilepathRegex(String inputFilepathRegex) {
        this.inputFilepathRegex = inputFilepathRegex;
    }

    public String getOutputFilenameSubstitution() {
        return outputFilenameSubstitution;
    }

    public void setOutputFilenameSubstitution(String outputFilenameSubstitution) {
        this.outputFilenameSubstitution = outputFilenameSubstitution;
    }

}

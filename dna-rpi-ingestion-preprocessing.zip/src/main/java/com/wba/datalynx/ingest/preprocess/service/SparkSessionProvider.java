package com.wba.datalynx.ingest.preprocess.service;

import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.stereotype.Service;

@Service
public class SparkSessionProvider {

    public SparkSession getSparkSession() {
        return SparkSession.builder().getOrCreate();
    }

    public SparkContext getSparkContext() {
        return getSparkSession().sparkContext();
    }

}

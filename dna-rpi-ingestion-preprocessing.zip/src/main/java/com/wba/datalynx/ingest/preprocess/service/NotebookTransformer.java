package com.wba.datalynx.ingest.preprocess.service;

import com.databricks.dbutils_v1.DBUtilsHolder;
import com.wba.datalynx.ingest.preprocess.annotation.TransformerService;
import com.wba.datalynx.ingest.preprocess.error.NotebookTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.NotebookTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContext;
import scala.collection.JavaConverters;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@TransformerService("NOTEBOOK_TRANSFORMER")
public class NotebookTransformer extends BaseTransformer {

    private static final String FILE_TO_PROCESS_FILEPATH = "fileToProcessFilepath";
    private static final String FILE_TO_PROCESS_STORAGE_ACCOUNT = "fileToProcessStorageAccount";
    private static final String FILE_TO_PROCESS_CONTAINER = "fileToProcessContainer";
    private static final String OUTPUT_DIRECTORY_PATH = "outputDirectoryPath";
    private static final String OUTPUT_DIRECTORY_STORAGE_ACCOUNT = "outputDirectoryStorageAccount";
    private static final String OUTPUT_DIRECTORY_CONTAINER = "outputDirectoryContainer";

    private final NotebookTransformerOptions notebookTransformerOptions;
    private final JsonMapper jsonMapper;

    public NotebookTransformer(ApplicationContext applicationContext, Map<String, Object> transformerOptions) {
        super(applicationContext, transformerOptions);
        this.notebookTransformerOptions = convertTransformerOptions(NotebookTransformerOptions.class);
        this.jsonMapper = applicationContext.getBean(JsonMapper.class);

        if (Objects.isNull(this.notebookTransformerOptions)) {
            throw new NotebookTransformerException("no notebook transformer options specified");
        }

        if (StringUtils.isBlank(this.notebookTransformerOptions.getPath())) {
            throw new NotebookTransformerException("notebook path cannot be blank or null");
        }

        if (Objects.isNull(this.notebookTransformerOptions.getTimeoutSeconds())) {
            throw new NotebookTransformerException("notebook timeout seconds cannot be null");
        }

        if (StringUtils.isBlank(this.notebookTransformerOptions.getClusterSpec())) {
            throw new NotebookTransformerException("notebook cluster spec cannot be blank or null");
        }
    }

    @Override
    public TransformResult transform(FileToProcess fileToProcess, OutputDirectory outputDirectory) {
        Map<String, String> notebookArguments = new HashMap<>();
        Optional.ofNullable(notebookTransformerOptions.getArguments()).ifPresent(notebookArguments::putAll);

        notebookArguments.putIfAbsent(FILE_TO_PROCESS_FILEPATH, fileToProcess.getFilepath());
        notebookArguments.putIfAbsent(FILE_TO_PROCESS_STORAGE_ACCOUNT, fileToProcess.getStorageAccountName());
        notebookArguments.putIfAbsent(FILE_TO_PROCESS_CONTAINER, fileToProcess.getContainerName());
        notebookArguments.putIfAbsent(OUTPUT_DIRECTORY_PATH, outputDirectory.getDirectoryPath());
        notebookArguments.putIfAbsent(OUTPUT_DIRECTORY_STORAGE_ACCOUNT, outputDirectory.getStorageAccountName());
        notebookArguments.putIfAbsent(OUTPUT_DIRECTORY_CONTAINER, outputDirectory.getContainerName());

        try {
            String notebookRunResult = DBUtilsHolder.dbutils()
                                                    .notebook()
                                                    .run(notebookTransformerOptions.getPath(),
                                                         notebookTransformerOptions.getTimeoutSeconds(),
                                                         JavaConverters.mapAsScalaMap(notebookArguments),
                                                         notebookTransformerOptions.getClusterSpec());

            return new TransformResult(jsonMapper.collectionFromJson(List.class, ProcessedFile.class, notebookRunResult));
        } catch (Exception e) {
            throw new NotebookTransformerException("failed to run notebook transformer for file " + fileToProcess.getFilepath()
                                                           + " in container " + fileToProcess.getContainerName()
                                                           + " on Storage Account " + fileToProcess.getStorageAccountName()
                                                           + " to output directory " + outputDirectory.getDirectoryPath()
                                                           + " in container " + outputDirectory.getContainerName()
                                                           + " on Storage Account " + outputDirectory.getStorageAccountName(),
                                                   e);
        }
    }


}

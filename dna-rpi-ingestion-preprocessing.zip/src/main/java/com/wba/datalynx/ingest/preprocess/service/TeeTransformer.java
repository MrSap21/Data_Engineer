package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.annotation.TransformerService;
import com.wba.datalynx.ingest.preprocess.error.TeeTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.FileToTrack;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.OutputFile;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.TeeTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import org.springframework.context.ApplicationContext;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;

@TransformerService("TEE_TRANSFORMER")
public class TeeTransformer extends BaseTransformer {

    private final TeeTransformerOptions teeTransformerOptions;
    private final FileToProcessReader fileToProcessReader;
    private final OutputFileWriter outputFileWriter;

    public TeeTransformer(ApplicationContext applicationContext, Map<String, Object> transformerOptions) {
        super(applicationContext, transformerOptions);
        this.teeTransformerOptions = convertTransformerOptions(TeeTransformerOptions.class);
        this.fileToProcessReader = applicationContext.getBean(FileToProcessReader.class);
        this.outputFileWriter = applicationContext.getBean(OutputFileWriter.class);

        if (Objects.isNull(this.teeTransformerOptions)) {
            throw new TeeTransformerException("no tee transformer options specified");
        }

        if (Objects.isNull(this.teeTransformerOptions.getInputFilepathRegex())) {
            throw new TeeTransformerException("no input filepath regex specified");
        }

        if (Objects.isNull(this.teeTransformerOptions.getOutputFilenameSubstitution())) {
            throw new TeeTransformerException("no output filename substitution specified");
        }

        if (Objects.isNull(this.teeTransformerOptions.getOutputDirectoryPath())) {
            throw new TeeTransformerException("no output directory path specified");
        }

        if (Objects.isNull(this.teeTransformerOptions.getOutputStorageAccountName())) {
            throw new TeeTransformerException("no output storage account name specified");
        }

        if (Objects.isNull(this.teeTransformerOptions.getOutputContainerName())) {
            throw new TeeTransformerException("no output container name specified");
        }
    }

    @Override
    public TransformResult transform(FileToProcess fileToProcess, OutputDirectory outputDirectory) {
        String inputFilepath = fileToProcess.getFilepath();
        String inputFilepathRegex = teeTransformerOptions.getInputFilepathRegex();
        String outputFilenameSubstitution = teeTransformerOptions.getOutputFilenameSubstitution();
        String outputFilename = inputFilepath.replaceAll(inputFilepathRegex, outputFilenameSubstitution);
        String outputFilepath = Paths.get(outputDirectory.getDirectoryPath(), outputFilename).toString();
        String outputCopyFilepath = Paths.get(teeTransformerOptions.getOutputDirectoryPath(), outputFilename).toString();

        OutputFile outputFile = new OutputFile();
        outputFile.setFilepath(outputFilepath);
        outputFile.setContainerName(outputDirectory.getContainerName());
        outputFile.setStorageAccountName(outputDirectory.getStorageAccountName());

        OutputFile outputCopyFile = new OutputFile();
        outputCopyFile.setFilepath(outputCopyFilepath);
        outputCopyFile.setContainerName(teeTransformerOptions.getOutputContainerName());
        outputCopyFile.setStorageAccountName(teeTransformerOptions.getOutputStorageAccountName());

        // input file copied to output and piped as input to the next step
        copyFile(fileToProcess,
                 outputDirectory.getStorageAccountName(),
                 outputDirectory.getContainerName(),
                 outputFilepath,
                 outputFile);

        // copy of input file exported to specified storage account, container and path
        copyFile(fileToProcess,
                 teeTransformerOptions.getOutputStorageAccountName(),
                 teeTransformerOptions.getOutputContainerName(),
                 outputCopyFilepath,
                 outputCopyFile);

        ProcessedFile processedFile = new ProcessedFile(outputFilepath, outputDirectory.getStorageAccountName(), outputDirectory.getContainerName());
        FileToTrack fileToTrack = new FileToTrack(outputCopyFilepath, teeTransformerOptions.getOutputStorageAccountName(), teeTransformerOptions.getOutputContainerName());
        return new TransformResult(Collections.singletonList(processedFile), Collections.singletonList(fileToTrack));
    }

    private void copyFile(FileToProcess fileToProcess, String storageAccountName, String containerName, String outputFilepath, OutputFile outputFile) {
        try (InputStream inputStream = fileToProcessReader.readToStream(fileToProcess)) {
            outputFileWriter.writeStream(inputStream, outputFile);
        } catch (IOException e) {
            throw new TeeTransformerException("failed to copy file " + fileToProcess.getFilepath()
                                                      + " in container " + fileToProcess.getContainerName()
                                                      + " on Storage Account " + fileToProcess.getStorageAccountName()
                                                      + " to file " + outputFilepath
                                                      + " in container " + containerName
                                                      + " on Storage Account " + storageAccountName,
                                              e);
        }
    }

}

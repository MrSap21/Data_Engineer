package com.wba.datalynx.ingest.preprocess.error;

public class XsltTransformerException extends RuntimeException {

    public XsltTransformerException() {
    }

    public XsltTransformerException(String message) {
        super(message);
    }

    public XsltTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public XsltTransformerException(Throwable cause) {
        super(cause);
    }

    public XsltTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

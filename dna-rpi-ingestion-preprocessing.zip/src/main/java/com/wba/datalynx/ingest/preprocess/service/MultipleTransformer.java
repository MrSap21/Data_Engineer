package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.annotation.TransformerService;
import com.wba.datalynx.ingest.preprocess.error.MultipleTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.FileToTrack;
import com.wba.datalynx.ingest.preprocess.model.MultipleTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import org.jetbrains.annotations.NotNull;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@TransformerService("MULTIPLE_TRANSFORMER")
public class MultipleTransformer extends BaseTransformer {

    private final MultipleTransformerOptions multipleTransformerOptions;
    private final TransformerFactory transformerFactory;

    public MultipleTransformer(ApplicationContext applicationContext, Map<String, Object> transformerOptions) {
        super(applicationContext, transformerOptions);
        this.multipleTransformerOptions = convertTransformerOptions(MultipleTransformerOptions.class);
        this.transformerFactory = applicationContext.getBean(TransformerFactory.class);

        if (Objects.isNull(this.multipleTransformerOptions)) {
            throw new MultipleTransformerException("no multiple transformer options specified");
        }

        if (Objects.isNull(this.multipleTransformerOptions.getTransformers())) {
            throw new MultipleTransformerException("no transformers specified");
        }
    }

    @Override
    public TransformResult transform(FileToProcess fileToProcess, OutputDirectory outputDirectory) {
        return multipleTransformerOptions.getTransformers()
                                         .stream()
                                         .map(transformerFactory::createTransformer)
                                         .map(transformer -> transformer.transform(fileToProcess, outputDirectory))
                                         .reduce(MultipleTransformer::mergeTransformResults)
                                         .orElseGet(TransformResult::new);
    }

    @NotNull
    private static TransformResult mergeTransformResults(TransformResult a, TransformResult b) {
        List<ProcessedFile> processedFiles = new ArrayList<>(a.getProcessedFiles());
        processedFiles.addAll(b.getProcessedFiles());
        List<FileToTrack> filesToTrack = a.getFilesToTrack();
        filesToTrack.addAll(b.getFilesToTrack());
        return new TransformResult(processedFiles, filesToTrack);
    }

}

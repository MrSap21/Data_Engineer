package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;

public interface Transformer {

    TransformResult transform(FileToProcess fileToProcess, OutputDirectory outputDirectory);

}

package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.annotation.TransformerService;
import com.wba.datalynx.ingest.preprocess.error.InvalidTransformerException;
import com.wba.datalynx.ingest.preprocess.error.UnknownTransformerException;
import com.wba.datalynx.ingest.preprocess.model.InputArgs;
import org.reflections.Reflections;
import org.reflections.scanners.Scanners;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Component
public class TransformerFactory {

    private static final Logger logger = LoggerFactory.getLogger(TransformerFactory.class);

    private final ApplicationContext applicationContext;

    public TransformerFactory(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    public Transformer createTransformer(InputArgs inputArgs) {
        String transformerType = inputArgs.getTransformerType();
        Map<String, Object> transformerOptions = inputArgs.getTransformerOptions();
        if (Objects.isNull(transformerOptions)) {
            transformerOptions = Collections.emptyMap();
        }
        final Map<String, Object> finalTransformerOptions = transformerOptions;

        Reflections reflections = new Reflections("com.wba.datalynx.ingest.preprocess");
        Set<Class<?>> transformerServices = reflections.get(Scanners.SubTypes.of(Scanners.TypesAnnotated.with(TransformerService.class)).asClass());

        Transformer transformer = transformerServices.stream()
                                                     .filter(BaseTransformer.class::isAssignableFrom)
                                                     .filter(transformerService -> Objects.equals(transformerService.getAnnotation(TransformerService.class).value(), transformerType))
                                                     .map(transformerService -> instantiateTransformer(transformerService, finalTransformerOptions))
                                                     .findFirst()
                                                     .orElseThrow(() -> new UnknownTransformerException(transformerType + " is not a valid transformer type"));

        logger.info("Transformer {} ready to process files", transformerType);

        return transformer;
    }

    private Transformer instantiateTransformer(Class<?> clazz, Map<String, Object> transformerOptions) {
        try {
            return (Transformer) getDefaultConstructor(clazz).newInstance(applicationContext, transformerOptions);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
            throw new InvalidTransformerException("failed to instantiate transformer for class " + clazz, e);
        }
    }

    private Constructor<?> getDefaultConstructor(Class<?> clazz) {
        try {
            return clazz.getDeclaredConstructor(ApplicationContext.class, Map.class);
        } catch (NoSuchMethodException e) {
            throw new InvalidTransformerException("no default constructor for class " + clazz, e);
        }
    }

}

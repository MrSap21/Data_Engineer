package com.wba.datalynx.ingest.preprocess.error;

public class StorageAccountCredentialNotConfiguredException extends RuntimeException {

    public StorageAccountCredentialNotConfiguredException() {
    }

    public StorageAccountCredentialNotConfiguredException(String message) {
        super(message);
    }

    public StorageAccountCredentialNotConfiguredException(String message, Throwable cause) {
        super(message, cause);
    }

    public StorageAccountCredentialNotConfiguredException(Throwable cause) {
        super(cause);
    }

    public StorageAccountCredentialNotConfiguredException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

package com.wba.datalynx.ingest.preprocess.error;

public class CopyTransformerException extends RuntimeException {

    public CopyTransformerException() {
    }

    public CopyTransformerException(String message) {
        super(message);
    }

    public CopyTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public CopyTransformerException(Throwable cause) {
        super(cause);
    }

    public CopyTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

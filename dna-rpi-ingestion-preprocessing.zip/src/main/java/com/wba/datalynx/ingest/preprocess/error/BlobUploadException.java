package com.wba.datalynx.ingest.preprocess.error;

public class BlobUploadException extends RuntimeException {

    public BlobUploadException() {
    }

    public BlobUploadException(String message) {
        super(message);
    }

    public BlobUploadException(String message, Throwable cause) {
        super(message, cause);
    }

    public BlobUploadException(Throwable cause) {
        super(cause);
    }

    public BlobUploadException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

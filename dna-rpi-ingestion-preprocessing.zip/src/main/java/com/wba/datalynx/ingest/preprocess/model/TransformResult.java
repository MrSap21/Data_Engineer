package com.wba.datalynx.ingest.preprocess.model;

import java.util.Collections;
import java.util.List;

public class TransformResult {

    private final List<ProcessedFile> processedFiles;
    private final List<FileToTrack> filesToTrack;

    public TransformResult() {
        this(Collections.emptyList());
    }

    public TransformResult(List<ProcessedFile> processedFiles) {
        this(processedFiles, Collections.emptyList());
    }

    public TransformResult(List<ProcessedFile> processedFiles, List<FileToTrack> filesToTrack) {
        this.processedFiles = processedFiles;
        this.filesToTrack = filesToTrack;
    }

    public List<ProcessedFile> getProcessedFiles() {
        return processedFiles;
    }

    public List<FileToTrack> getFilesToTrack() {
        return filesToTrack;
    }
}

package com.wba.datalynx.ingest.preprocess.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.wba.datalynx.ingest.preprocess.error.JsonParsingException;
import com.wba.datalynx.ingest.preprocess.error.JsonSerializerException;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class JsonMapper {

    private final ObjectMapper objectMapper;

    public JsonMapper() {
        this.objectMapper = new ObjectMapper();
    }

    public <T> T fromJson(Class<T> clazz, String json) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            throw new JsonParsingException("failed to parse JSON", e);
        }
    }

    public <T,
            C extends Collection<?>,
            R extends Collection<? extends T>>
    R collectionFromJson(Class<C> collectionClass, Class<T> elementClass, String json) {
        try {
            CollectionType collectionType = objectMapper.getTypeFactory().constructCollectionType(collectionClass, elementClass);
            return objectMapper.readValue(json, collectionType);
        } catch (JsonProcessingException e) {
            throw new JsonParsingException("failed to parse collection from JSON", e);
        }
    }

    public <T> String toJson(T value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new JsonSerializerException("failed to serialize JSON", e);
        }
    }

}

package com.wba.datalynx.ingest.preprocess.service;

public class EnvironmentSecretRetriever implements SecretRetriever {

    @Override
    public String getSecret(String secretKey) {
        return System.getenv(secretKey);
    }

}

package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.annotation.TransformerService;
import com.wba.datalynx.ingest.preprocess.error.CopyTransformerException;
import com.wba.datalynx.ingest.preprocess.model.CopyTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.OutputFile;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import org.springframework.context.ApplicationContext;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;

@TransformerService("COPY_TRANSFORMER")
public class CopyTransformer extends BaseTransformer {

    private final CopyTransformerOptions copyTransformerOptions;
    private final FileToProcessReader fileToProcessReader;
    private final OutputFileWriter outputFileWriter;

    public CopyTransformer(ApplicationContext applicationContext, Map<String, Object> transformerOptions) {
        super(applicationContext, transformerOptions);
        this.copyTransformerOptions = convertTransformerOptions(CopyTransformerOptions.class);
        this.fileToProcessReader = applicationContext.getBean(FileToProcessReader.class);
        this.outputFileWriter = applicationContext.getBean(OutputFileWriter.class);

        if (Objects.isNull(this.copyTransformerOptions)) {
            throw new CopyTransformerException("no copy transformer options specified");
        }

        if (Objects.isNull(this.copyTransformerOptions.getInputFilepathRegex())) {
            throw new CopyTransformerException("no input filepath regex specified");
        }

        if (Objects.isNull(this.copyTransformerOptions.getOutputFilenameSubstitution())) {
            throw new CopyTransformerException("no output filename substitution specified");
        }
    }

    @Override
    public TransformResult transform(FileToProcess fileToProcess, OutputDirectory outputDirectory) {
        String inputFilepath = fileToProcess.getFilepath();
        String inputFilepathRegex = copyTransformerOptions.getInputFilepathRegex();
        String outputFilenameSubstitution = copyTransformerOptions.getOutputFilenameSubstitution();
        String outputFilename = inputFilepath.replaceAll(inputFilepathRegex, outputFilenameSubstitution);
        String outputFilepath = Paths.get(outputDirectory.getDirectoryPath(), outputFilename).toString();

        OutputFile outputFile = new OutputFile();
        outputFile.setFilepath(outputFilepath);
        outputFile.setContainerName(outputDirectory.getContainerName());
        outputFile.setStorageAccountName(outputDirectory.getStorageAccountName());

        try (InputStream inputStream = fileToProcessReader.readToStream(fileToProcess)) {
            outputFileWriter.writeStream(inputStream, outputFile);
        } catch (IOException e) {
            throw new CopyTransformerException("failed to copy file " + fileToProcess.getFilepath()
                                                       + " in container " + fileToProcess.getContainerName()
                                                       + " on Storage Account " + fileToProcess.getStorageAccountName()
                                                       + " to file " + outputFilepath
                                                       + " in container " + outputDirectory.getContainerName()
                                                       + " on Storage Account " + outputDirectory.getStorageAccountName(),
                                               e);
        }

        ProcessedFile processedFile = new ProcessedFile(outputFilepath, outputDirectory.getStorageAccountName(), outputDirectory.getContainerName());
        return new TransformResult(Collections.singletonList(processedFile));
    }

}

package com.wba.datalynx.ingest.preprocess.error;

public class TeeTransformerException extends RuntimeException {

    public TeeTransformerException() {
    }

    public TeeTransformerException(String message) {
        super(message);
    }

    public TeeTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public TeeTransformerException(Throwable cause) {
        super(cause);
    }

    public TeeTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

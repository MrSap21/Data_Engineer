package com.wba.datalynx.ingest.preprocess.model;

public class FileToTrack {

    private String filepath;
    private String storageAccountName;
    private String containerName;

    public FileToTrack(String filepath, String storageAccountName, String containerName) {
        this.filepath = filepath;
        this.storageAccountName = storageAccountName;
        this.containerName = containerName;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getStorageAccountName() {
        return storageAccountName;
    }

    public void setStorageAccountName(String storageAccountName) {
        this.storageAccountName = storageAccountName;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

}

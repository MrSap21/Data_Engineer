package com.wba.datalynx.ingest.preprocess.runner;

import com.wba.datalynx.ingest.preprocess.error.InvalidArgsException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.InputArgs;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.OutputFile;
import com.wba.datalynx.ingest.preprocess.model.ProcessResults;
import com.wba.datalynx.ingest.preprocess.model.StorageAccountMapping;
import com.wba.datalynx.ingest.preprocess.service.AzureCredentialProvider;
import com.wba.datalynx.ingest.preprocess.service.DbUtilsSecretRetriever;
import com.wba.datalynx.ingest.preprocess.service.EnvironmentSecretRetriever;
import com.wba.datalynx.ingest.preprocess.service.JsonMapper;
import com.wba.datalynx.ingest.preprocess.service.OutputFileWriter;
import com.wba.datalynx.ingest.preprocess.service.SecretRetriever;
import com.wba.datalynx.ingest.preprocess.service.Transformer;
import com.wba.datalynx.ingest.preprocess.service.TransformerFactory;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Component
public class PreprocessCommandLineRunner implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(PreprocessCommandLineRunner.class);

    private final ApplicationContext applicationContext;
    private final JsonMapper jsonMapper;
    private final TransformerRunner transformerRunner;
    private final OutputFileWriter outputFileWriter;
    private final AzureCredentialProvider azureCredentialProvider;
    private final TransformerFactory transformerFactory;

    public PreprocessCommandLineRunner(ApplicationContext applicationContext, JsonMapper jsonMapper, TransformerRunner transformerRunner, OutputFileWriter outputFileWriter, AzureCredentialProvider azureCredentialProvider, TransformerFactory transformerFactory) {
        this.applicationContext = applicationContext;
        this.jsonMapper = jsonMapper;
        this.transformerRunner = transformerRunner;
        this.outputFileWriter = outputFileWriter;
        this.azureCredentialProvider = azureCredentialProvider;
        this.transformerFactory = transformerFactory;
    }

    @Override
    public void run(String... args) {
        logger.info("DataLynx preprocess engine invoked with args: {}", Arrays.toString(args));

        if (args.length == 0) {
            throw new InvalidArgsException("No args provided");
        }

        InputArgs inputArgs = jsonMapper.fromJson(InputArgs.class, args[0]);

        OutputFile outputResultsFile = inputArgs.getOutputResultsFile();
        if (Objects.isNull(outputResultsFile)) {
            throw new InvalidArgsException("outputResultsFile property must not be null");
        }
        if (StringUtils.isBlank(outputResultsFile.getFilepath())) {
            throw new InvalidArgsException("outputResultsFile.filepath property must not be blank");
        }

        SecretRetriever secretRetriever;
        if (Arrays.stream(applicationContext.getEnvironment().getActiveProfiles()).anyMatch(profile -> StringUtils.equals("dev", profile))) {
            secretRetriever = new EnvironmentSecretRetriever();
        } else {
            String dbutilsSecretScope = inputArgs.getDbutilsSecretScope();
            if (StringUtils.isBlank(dbutilsSecretScope)) {
                throw new InvalidArgsException("dbutilsSecretScope property must not be blank");
            }
            secretRetriever = new DbUtilsSecretRetriever(dbutilsSecretScope);
        }

        OutputDirectory outputDirectory = inputArgs.getOutputDirectory();
        if (Objects.isNull(outputDirectory)) {
            throw new InvalidArgsException("outputDirectory property must not be null");
        }

        List<StorageAccountMapping> storageAccountMappings = inputArgs.getStorageAccountMappings();
        if (Objects.isNull(storageAccountMappings)) {
            storageAccountMappings = Collections.emptyList();
        }
        storageAccountMappings.forEach(storageAccountMapping -> azureCredentialProvider.addAzureCredentialForStorageAccount(secretRetriever, storageAccountMapping.getStorageAccountName(), storageAccountMapping.getServicePrincipalCredential()));

        Transformer transformer = transformerFactory.createTransformer(inputArgs);

        List<FileToProcess> filesToProcess = inputArgs.getFilesToProcess();
        if (Objects.isNull(filesToProcess)) {
            filesToProcess = Collections.emptyList();
        }

        ProcessResults processResults = transformerRunner.runTransformer(transformer, filesToProcess, outputDirectory);
        outputFileWriter.writeAsJson(processResults, outputResultsFile);
    }

}

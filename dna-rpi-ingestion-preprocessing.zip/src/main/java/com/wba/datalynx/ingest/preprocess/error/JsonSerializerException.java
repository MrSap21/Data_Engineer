package com.wba.datalynx.ingest.preprocess.error;

public class JsonSerializerException extends RuntimeException {

    public JsonSerializerException() {
    }

    public JsonSerializerException(String message) {
        super(message);
    }

    public JsonSerializerException(String message, Throwable cause) {
        super(message, cause);
    }

    public JsonSerializerException(Throwable cause) {
        super(cause);
    }

    public JsonSerializerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

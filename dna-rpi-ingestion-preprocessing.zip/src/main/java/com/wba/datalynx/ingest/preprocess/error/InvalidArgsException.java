package com.wba.datalynx.ingest.preprocess.error;

public class InvalidArgsException extends RuntimeException {

    public InvalidArgsException() {
    }

    public InvalidArgsException(String message) {
        super(message);
    }

    public InvalidArgsException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidArgsException(Throwable cause) {
        super(cause);
    }

    public InvalidArgsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

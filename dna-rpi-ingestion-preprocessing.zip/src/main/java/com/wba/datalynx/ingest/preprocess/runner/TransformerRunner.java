package com.wba.datalynx.ingest.preprocess.runner;

import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.ProcessResult;
import com.wba.datalynx.ingest.preprocess.model.ProcessResults;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import com.wba.datalynx.ingest.preprocess.service.Transformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class TransformerRunner {

    private static final Logger logger = LoggerFactory.getLogger(TransformerRunner.class);

    public ProcessResults runTransformer(Transformer transformer, List<FileToProcess> filesToProcess, OutputDirectory outputDirectory) {
        List<ProcessResult> processResultList = filesToProcess.parallelStream()
                                                              .map(fileToProcess -> processFile(transformer, fileToProcess, outputDirectory))
                                                              .collect(Collectors.toList());

        return new ProcessResults(processResultList);
    }

    private ProcessResult processFile(Transformer transformer, FileToProcess fileToProcess, OutputDirectory outputDirectory) {
        logger.info("Processing file {} in container {} on Storage Account {}", fileToProcess.getFilepath(), fileToProcess.getContainerName(), fileToProcess.getStorageAccountName());
        TransformResult transformResult = transformer.transform(fileToProcess, outputDirectory);
        logger.info("Processed file {} in container {} on Storage Account {}", fileToProcess.getFilepath(), fileToProcess.getContainerName(), fileToProcess.getStorageAccountName());
        return new ProcessResult(fileToProcess, transformResult.getProcessedFiles(), transformResult.getFilesToTrack());
    }

}

package com.wba.datalynx.ingest.preprocess.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.ApplicationContext;

import java.util.Map;

public abstract class BaseTransformer implements Transformer {

    protected final ApplicationContext applicationContext;
    protected final Map<String, Object> transformerOptions;

    public BaseTransformer(ApplicationContext applicationContext, Map<String, Object> transformerOptions) {
        this.applicationContext = applicationContext;
        this.transformerOptions = transformerOptions;
    }

    protected <T> T convertTransformerOptions(Class<T> toValueClass) {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.convertValue(transformerOptions, toValueClass);
    }

}

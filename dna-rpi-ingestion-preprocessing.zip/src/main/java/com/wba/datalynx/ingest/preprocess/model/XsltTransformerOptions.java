package com.wba.datalynx.ingest.preprocess.model;

public class XsltTransformerOptions {

    private String stylesheet;
    private String inputFilepathRegex;
    private String outputFilenameSubstitution;

    private String inputParameterName;

    public String getStylesheet() {
        return stylesheet;
    }

    public void setStylesheet(String stylesheet) {
        this.stylesheet = stylesheet;
    }

    public String getInputFilepathRegex() {
        return inputFilepathRegex;
    }

    public void setInputFilepathRegex(String inputFilepathRegex) {
        this.inputFilepathRegex = inputFilepathRegex;
    }

    public String getOutputFilenameSubstitution() {
        return outputFilenameSubstitution;
    }

    public void setOutputFilenameSubstitution(String outputFilenameSubstitution) {
        this.outputFilenameSubstitution = outputFilenameSubstitution;
    }

    public String getInputParameterName() {
        return inputParameterName;
    }

    public void setInputParameterName(String inputParameterName) {
        this.inputParameterName = inputParameterName;
    }

}

package com.wba.datalynx.ingest.preprocess.model;

public class TeeTransformerOptions {

    private String inputFilepathRegex;
    private String outputFilenameSubstitution;
    private String outputDirectoryPath;
    private String outputStorageAccountName;
    private String outputContainerName;

    public String getInputFilepathRegex() {
        return inputFilepathRegex;
    }

    public void setInputFilepathRegex(String inputFilepathRegex) {
        this.inputFilepathRegex = inputFilepathRegex;
    }

    public String getOutputFilenameSubstitution() {
        return outputFilenameSubstitution;
    }

    public void setOutputFilenameSubstitution(String outputFilenameSubstitution) {
        this.outputFilenameSubstitution = outputFilenameSubstitution;
    }

    public String getOutputDirectoryPath() {
        return outputDirectoryPath;
    }

    public void setOutputDirectoryPath(String outputDirectoryPath) {
        this.outputDirectoryPath = outputDirectoryPath;
    }

    public String getOutputStorageAccountName() {
        return outputStorageAccountName;
    }

    public void setOutputStorageAccountName(String outputStorageAccountName) {
        this.outputStorageAccountName = outputStorageAccountName;
    }

    public String getOutputContainerName() {
        return outputContainerName;
    }

    public void setOutputContainerName(String outputContainerName) {
        this.outputContainerName = outputContainerName;
    }

}

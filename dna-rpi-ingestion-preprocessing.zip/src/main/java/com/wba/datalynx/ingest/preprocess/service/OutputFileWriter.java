package com.wba.datalynx.ingest.preprocess.service;

import com.azure.storage.blob.BlobClient;
import com.wba.datalynx.ingest.preprocess.error.BlobUploadException;
import com.wba.datalynx.ingest.preprocess.model.OutputFile;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Service
public class OutputFileWriter {

    private final BlobClientProvider blobClientProvider;
    private final JsonMapper jsonMapper;

    public OutputFileWriter(BlobClientProvider blobClientProvider, JsonMapper jsonMapper) {
        this.blobClientProvider = blobClientProvider;
        this.jsonMapper = jsonMapper;
    }

    public <T> void writeAsJson(T objectToWrite, OutputFile outputFile) {
        String processResultsJson = jsonMapper.toJson(objectToWrite);
        writeString(processResultsJson, outputFile);
    }

    public void writeString(String stringToWrite, OutputFile outputFile) {
        String storageAccountName = outputFile.getStorageAccountName();
        String containerName = outputFile.getContainerName();
        String filepath = outputFile.getFilepath();

        try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(stringToWrite.getBytes(StandardCharsets.UTF_8))) {
            writeStream(byteArrayInputStream, outputFile);
        } catch (IOException e) {
            throw new BlobUploadException("failed to write file " + filepath
                                                  + " to container " + containerName
                                                  + " on Storage Account " + storageAccountName,
                                          e);
        }
    }

    public void writeStream(InputStream streamToWrite, OutputFile outputFile) {
        String storageAccountName = outputFile.getStorageAccountName();
        String containerName = outputFile.getContainerName();
        String filepath = outputFile.getFilepath();

        BlobClient blobClient = blobClientProvider.getBlobClient(storageAccountName, containerName, filepath);

        try {
            blobClient.upload(streamToWrite);
        } catch (Exception e) {
            throw new BlobUploadException("failed to write file " + filepath
                                                  + " to container " + containerName
                                                  + " on Storage Account " + storageAccountName,
                                          e);
        }
    }

}

package com.wba.datalynx.ingest.preprocess.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wba.datalynx.ingest.preprocess.mapper.ProcessedFileToFileToProcess;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ProcessResults {

    private final List<ProcessResult> processResults;

    public ProcessResults(List<ProcessResult> processResults) {
        this.processResults = processResults;
    }

    public List<ProcessResult> getProcessResults() {
        return processResults;
    }

    @JsonProperty("newFilesToProcess")
    public List<FileToProcess> getNewFilesToProcess() {
        ProcessedFileToFileToProcess processedFileToFileToProcess = new ProcessedFileToFileToProcess();
        return getProcessResults().stream()
                                  .flatMap(processResult -> processResult.getOutputFiles()
                                                                         .stream()
                                                                         .map(processedFileToFileToProcess::processedFileToFileToProcess))
                                  .collect(Collectors.toList());
    }

    @JsonProperty("filesToTrack")
    public List<FileToTrack> getFilesToTrack() {
        return getProcessResults().stream()
                                  .flatMap(processResult -> processResult.getFilesToTrack().stream())
                                  .collect(Collectors.toList());
    }

}

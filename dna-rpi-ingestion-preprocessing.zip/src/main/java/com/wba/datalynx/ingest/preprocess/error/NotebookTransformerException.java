package com.wba.datalynx.ingest.preprocess.error;

public class NotebookTransformerException extends RuntimeException {

    public NotebookTransformerException() {
    }

    public NotebookTransformerException(String message) {
        super(message);
    }

    public NotebookTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotebookTransformerException(Throwable cause) {
        super(cause);
    }

    public NotebookTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

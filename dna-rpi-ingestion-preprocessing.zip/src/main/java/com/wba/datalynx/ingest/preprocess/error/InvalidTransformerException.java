package com.wba.datalynx.ingest.preprocess.error;

public class InvalidTransformerException extends RuntimeException {

    public InvalidTransformerException() {
    }

    public InvalidTransformerException(String message) {
        super(message);
    }

    public InvalidTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidTransformerException(Throwable cause) {
        super(cause);
    }

    public InvalidTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

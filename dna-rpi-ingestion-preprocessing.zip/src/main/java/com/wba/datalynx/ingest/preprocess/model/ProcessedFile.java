package com.wba.datalynx.ingest.preprocess.model;

public class ProcessedFile {

    private String filepath;
    private String storageAccountName;
    private String containerName;

    public ProcessedFile() {
    }

    public ProcessedFile(String filepath, String storageAccountName, String containerName) {
        this.filepath = filepath;
        this.storageAccountName = storageAccountName;
        this.containerName = containerName;
    }

    public String getFilepath() {
        return filepath;
    }

    public String getStorageAccountName() {
        return storageAccountName;
    }

    public String getContainerName() {
        return containerName;
    }

}

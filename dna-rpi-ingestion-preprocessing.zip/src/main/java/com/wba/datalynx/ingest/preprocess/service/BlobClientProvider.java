package com.wba.datalynx.ingest.preprocess.service;

import com.azure.core.credential.TokenCredential;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import org.springframework.stereotype.Service;

import static com.wba.datalynx.ingest.preprocess.service.AzureCredentialProvider.getCleanStorageAccountName;

@Service
public class BlobClientProvider {

    private final AzureCredentialProvider azureCredentialProvider;

    public BlobClientProvider(AzureCredentialProvider azureCredentialProvider) {
        this.azureCredentialProvider = azureCredentialProvider;
    }

    public BlobClient getBlobClient(String storageAccountName, String containerName, String filepath) {
        TokenCredential tokenCredential = azureCredentialProvider.getAzureCredentialForStorageAccount(storageAccountName);
        String blobEndpoint = "https://" + getCleanStorageAccountName(storageAccountName) + ".blob.core.windows.net/";

        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(blobEndpoint)
                                                                            .credential(tokenCredential)
                                                                            .buildClient();

        BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(containerName);
        return blobContainerClient.getBlobClient(filepath);
    }

}

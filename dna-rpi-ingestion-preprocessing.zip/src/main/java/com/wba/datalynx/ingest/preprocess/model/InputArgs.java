package com.wba.datalynx.ingest.preprocess.model;

import java.util.List;
import java.util.Map;

public class InputArgs {

    private String transformerType;
    private List<FileToProcess> filesToProcess;
    private OutputFile outputResultsFile;
    private OutputDirectory outputDirectory;
    private Map<String, Object> transformerOptions;
    private List<StorageAccountMapping> storageAccountMappings;
    private String dbutilsSecretScope;

    public String getTransformerType() {
        return transformerType;
    }

    public void setTransformerType(String transformerType) {
        this.transformerType = transformerType;
    }

    public List<FileToProcess> getFilesToProcess() {
        return filesToProcess;
    }

    public void setFilesToProcess(List<FileToProcess> filesToProcess) {
        this.filesToProcess = filesToProcess;
    }

    public OutputFile getOutputResultsFile() {
        return outputResultsFile;
    }

    public void setOutputResultsFile(OutputFile outputResultsFile) {
        this.outputResultsFile = outputResultsFile;
    }

    public OutputDirectory getOutputDirectory() {
        return outputDirectory;
    }

    public void setOutputDirectory(OutputDirectory outputDirectory) {
        this.outputDirectory = outputDirectory;
    }

    public Map<String, Object> getTransformerOptions() {
        return transformerOptions;
    }

    public void setTransformerOptions(Map<String, Object> transformerOptions) {
        this.transformerOptions = transformerOptions;
    }

    public List<StorageAccountMapping> getStorageAccountMappings() {
        return storageAccountMappings;
    }

    public void setStorageAccountMappings(List<StorageAccountMapping> storageAccountMappings) {
        this.storageAccountMappings = storageAccountMappings;
    }

    public String getDbutilsSecretScope() {
        return dbutilsSecretScope;
    }

    public void setDbutilsSecretScope(String dbutilsSecretScope) {
        this.dbutilsSecretScope = dbutilsSecretScope;
    }

}

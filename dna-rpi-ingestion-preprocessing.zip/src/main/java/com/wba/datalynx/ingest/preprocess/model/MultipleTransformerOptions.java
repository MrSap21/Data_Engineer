package com.wba.datalynx.ingest.preprocess.model;

import java.util.List;

public class MultipleTransformerOptions {

    private List<InputArgs> transformers;

    public List<InputArgs> getTransformers() {
        return transformers;
    }

    public void setTransformers(List<InputArgs> transformers) {
        this.transformers = transformers;
    }

}

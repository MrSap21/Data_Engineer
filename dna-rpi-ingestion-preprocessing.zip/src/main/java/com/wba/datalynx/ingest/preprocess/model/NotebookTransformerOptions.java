package com.wba.datalynx.ingest.preprocess.model;

import java.util.Map;

public class NotebookTransformerOptions {

    private String path;
    private Integer timeoutSeconds;
    private Map<String, String> arguments;
    private String clusterSpec;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Integer getTimeoutSeconds() {
        return timeoutSeconds;
    }

    public void setTimeoutSeconds(Integer timeoutSeconds) {
        this.timeoutSeconds = timeoutSeconds;
    }

    public Map<String, String> getArguments() {
        return arguments;
    }

    public void setArguments(Map<String, String> arguments) {
        this.arguments = arguments;
    }

    public String getClusterSpec() {
        return clusterSpec;
    }

    public void setClusterSpec(String clusterSpec) {
        this.clusterSpec = clusterSpec;
    }

}

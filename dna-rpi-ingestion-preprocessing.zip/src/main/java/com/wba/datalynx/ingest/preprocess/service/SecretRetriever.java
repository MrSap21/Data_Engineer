package com.wba.datalynx.ingest.preprocess.service;

public interface SecretRetriever {

    String getSecret(String secretKey);

}

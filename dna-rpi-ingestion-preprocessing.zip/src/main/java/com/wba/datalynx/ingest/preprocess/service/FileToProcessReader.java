package com.wba.datalynx.ingest.preprocess.service;

import com.azure.storage.blob.BlobClient;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import org.springframework.stereotype.Service;

import java.io.InputStream;

@Service
public class FileToProcessReader {

    private final BlobClientProvider blobClientProvider;

    public FileToProcessReader(BlobClientProvider blobClientProvider) {
        this.blobClientProvider = blobClientProvider;
    }

    public String readToString(FileToProcess fileToProcess) {
        BlobClient blobClient = blobClientProvider.getBlobClient(fileToProcess.getStorageAccountName(),
                                                                 fileToProcess.getContainerName(),
                                                                 fileToProcess.getFilepath());
        return blobClient.downloadContent().toString();
    }

    public InputStream readToStream(FileToProcess fileToProcess) {
        BlobClient blobClient = blobClientProvider.getBlobClient(fileToProcess.getStorageAccountName(),
                                                                 fileToProcess.getContainerName(),
                                                                 fileToProcess.getFilepath());
        return blobClient.downloadContent().toStream();
    }

}

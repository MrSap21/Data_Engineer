package com.wba.datalynx.ingest.preprocess.service;

import com.azure.core.credential.TokenCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.wba.datalynx.ingest.preprocess.error.StorageAccountCredentialNotConfiguredException;
import com.wba.datalynx.ingest.preprocess.model.ServicePrincipalCredential;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AzureCredentialProvider {

    public static final Pattern STORAGE_ACCOUNT_NAME_PATTERN = Pattern.compile("(?:http.?://)?(.*?)\\..*", Pattern.MULTILINE);
    private final Map<String, TokenCredential> azureCredentialProviderMap;

    public AzureCredentialProvider() {
        this.azureCredentialProviderMap = new ConcurrentHashMap<>();
    }

    public TokenCredential getAzureCredentialForStorageAccount(String storageAccountName) {
        String cleanStorageAccountName = getCleanStorageAccountName(storageAccountName);

        TokenCredential tokenCredential = azureCredentialProviderMap.get(cleanStorageAccountName);
        if (Objects.isNull(tokenCredential)) {
            throw new StorageAccountCredentialNotConfiguredException("no credentials provided for Storage Account " + cleanStorageAccountName + " (" + storageAccountName + ")");
        }

        return tokenCredential;
    }

    public void addAzureCredentialForStorageAccount(SecretRetriever secretRetriever, String storageAccountName, ServicePrincipalCredential servicePrincipalCredential) {
        String tenantId = secretRetriever.getSecret(servicePrincipalCredential.getTenantId());
        String clientId = secretRetriever.getSecret(servicePrincipalCredential.getClientId());
        String clientSecret = secretRetriever.getSecret(servicePrincipalCredential.getClientSecret());

        String cleanStorageAccountName = getCleanStorageAccountName(storageAccountName);

        TokenCredential credential = new ClientSecretCredentialBuilder().tenantId(tenantId)
                                                                        .clientId(clientId)
                                                                        .clientSecret(clientSecret)
                                                                        .build();
        azureCredentialProviderMap.put(cleanStorageAccountName, credential);
    }

    public static String getCleanStorageAccountName(String storageAccountName) {
        Matcher matcher = STORAGE_ACCOUNT_NAME_PATTERN.matcher(storageAccountName);
        return matcher.replaceAll("$1");
    }

}

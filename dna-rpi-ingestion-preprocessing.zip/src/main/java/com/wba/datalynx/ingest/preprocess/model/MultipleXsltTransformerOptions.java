package com.wba.datalynx.ingest.preprocess.model;

import java.util.List;

public class MultipleXsltTransformerOptions {

    private List<XsltTransformerOptions> transformations;

    public List<XsltTransformerOptions> getTransformations() {
        return transformations;
    }

    public void setTransformations(List<XsltTransformerOptions> transformations) {
        this.transformations = transformations;
    }

}

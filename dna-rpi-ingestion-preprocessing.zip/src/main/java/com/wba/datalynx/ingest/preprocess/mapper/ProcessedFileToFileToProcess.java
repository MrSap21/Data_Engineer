package com.wba.datalynx.ingest.preprocess.mapper;

import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;

public class ProcessedFileToFileToProcess {

    public FileToProcess processedFileToFileToProcess(ProcessedFile processedFile) {
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(processedFile.getFilepath());
        fileToProcess.setContainerName(processedFile.getContainerName());
        fileToProcess.setStorageAccountName(processedFile.getStorageAccountName());
        return fileToProcess;
    }

}

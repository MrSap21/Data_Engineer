package com.wba.datalynx.ingest.preprocess.error;

public class MultipleTransformerException extends RuntimeException {

    public MultipleTransformerException() {
    }

    public MultipleTransformerException(String message) {
        super(message);
    }

    public MultipleTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    public MultipleTransformerException(Throwable cause) {
        super(cause);
    }

    public MultipleTransformerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

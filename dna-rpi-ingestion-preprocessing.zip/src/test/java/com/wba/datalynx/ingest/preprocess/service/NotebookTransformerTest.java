package com.wba.datalynx.ingest.preprocess.service;


import com.databricks.WorkflowException;
import com.databricks.dbutils_v1.DBUtilsHolder;
import com.databricks.dbutils_v1.DBUtilsV1;
import com.databricks.dbutils_v1.NotebookUtils;
import com.wba.datalynx.ingest.preprocess.error.NotebookTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.NotebookTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.context.ApplicationContext;
import scala.collection.JavaConverters;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotebookTransformerTest {

    @Test(expected = NotebookTransformerException.class)
    public void shouldThrowExceptionWhenCreatingNotebookTransformerAndNoNotebookTransformerOptionIsSpecified() {
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        new NotebookTransformer(applicationContext, null);
    }

    @Test(expected = NotebookTransformerException.class)
    public void shouldThrowExceptionWhenCreatingNotebookTransformerAndNotebookTransformerOptionIsEmpty() {
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        Map<String, Object> transformerOptions = new HashMap<>();
        new NotebookTransformer(applicationContext, transformerOptions);
    }

    @Test
    public void shouldCreateNotebookTransformerWhenNotebookTransformerOptionsAreCorrectlySpecified() {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setArguments(Collections.singletonMap("aKey", "aValue"));
        notebookTransformerOptions.setTimeoutSeconds(0);
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
        NotebookTransformer notebookTransformer = new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(notebookTransformer);
    }

    @Test(expected = NotebookTransformerException.class)
    public void shouldThrowExceptionWhenCreatingNotebookTransformerAndNoPathIsSpecified() {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setArguments(Collections.singletonMap("aKey", "aValue"));
        notebookTransformerOptions.setTimeoutSeconds(0);
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
        new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
    }

    @Test(expected = NotebookTransformerException.class)
    public void shouldThrowExceptionWhenCreatingNotebookTransformerAndNoTimeoutIsSpecified() {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setArguments(Collections.singletonMap("aKey", "aValue"));
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
        new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
    }

    @Test(expected = NotebookTransformerException.class)
    public void shouldThrowExceptionWhenCreatingNotebookTransformerAndNoClusterSpecIsSpecified() {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setArguments(Collections.singletonMap("aKey", "aValue"));
        notebookTransformerOptions.setTimeoutSeconds(0);
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
        new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
    }

    @Test
    public void shouldCreateNotebookTransformerWhenNotebookTransformerOptionsAreCorrectlySpecifiedWithoutArguments() {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setTimeoutSeconds(0);
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
        NotebookTransformer notebookTransformer = new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(notebookTransformer);
    }

    @Test
    public void shouldInvokeNotebookWhenNotebookTransformerOptionsAreCorrectlySpecified() throws WorkflowException {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setTimeoutSeconds(0);
        notebookTransformerOptions.setArguments(Collections.singletonMap("aKey", "aValue"));
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == JsonMapper.class) {
                                   return new JsonMapper();
                               }
                               throw new RuntimeException();
                           }
               );

        ProcessedFile processedFile = new ProcessedFile("/processed/filepath", "storage_account", "container_name");
        List<ProcessedFile> processedFiles = Collections.singletonList(processedFile);
        JsonMapper jsonMapper = new JsonMapper();
        String processedFilesJson = jsonMapper.toJson(processedFiles);

        DBUtilsV1 mockedDBUtils = Mockito.mock(DBUtilsV1.class);
        NotebookUtils mockedNotebookUtils = Mockito.mock(NotebookUtils.class);

        Mockito.when(mockedDBUtils.notebook()).thenReturn(mockedNotebookUtils);
        Mockito.when(mockedNotebookUtils.run(Mockito.anyString(),
                                             Mockito.anyInt(),
                                             Mockito.any(scala.collection.Map.class),
                                             Mockito.anyString()))
               .thenReturn(processedFilesJson);

        try (MockedStatic<DBUtilsHolder> mockedDBUtilsHolder = Mockito.mockStatic(DBUtilsHolder.class)) {
            mockedDBUtilsHolder.when(DBUtilsHolder::dbutils).thenReturn(mockedDBUtils);

            String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
            NotebookTransformer notebookTransformer = new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
            FileToProcess fileToProcess = new FileToProcess();
            fileToProcess.setStorageAccountName("in_storage_account");
            fileToProcess.setFilepath("in_filepath");
            fileToProcess.setContainerName("in_container");
            OutputDirectory outputDirectory = new OutputDirectory();
            outputDirectory.setContainerName("out_container");
            outputDirectory.setDirectoryPath("out_dir");
            outputDirectory.setStorageAccountName("out_storage_account");

            List<ProcessedFile> processedFileList = notebookTransformer.transform(fileToProcess, outputDirectory).getProcessedFiles();

            ArgumentCaptor<scala.collection.Map<String, String>> notebookArgumentsCaptor = ArgumentCaptor.forClass(scala.collection.Map.class);

            Mockito.verify(mockedNotebookUtils).run(Mockito.eq("/Shared/notebook"),
                                                    Mockito.eq(0),
                                                    notebookArgumentsCaptor.capture(),
                                                    Mockito.eq("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}"));

            Assert.assertNotNull(processedFileList);
            Assert.assertEquals(1, processedFileList.size());
            ProcessedFile processedFileOutput = processedFileList.get(0);
            Assert.assertEquals("/processed/filepath", processedFileOutput.getFilepath());
            Assert.assertEquals("storage_account", processedFileOutput.getStorageAccountName());
            Assert.assertEquals("container_name", processedFileOutput.getContainerName());

            scala.collection.Map<String, String> scalaNotebookArguments = notebookArgumentsCaptor.getValue();
            Assert.assertNotNull(scalaNotebookArguments);
            Assert.assertFalse(scalaNotebookArguments.isEmpty());
            Map<String, String> notebookArguments = JavaConverters.mapAsJavaMap(scalaNotebookArguments);
            Assert.assertEquals("aValue", notebookArguments.get("aKey"));
            Assert.assertEquals("in_filepath", notebookArguments.get("fileToProcessFilepath"));
            Assert.assertEquals("in_storage_account", notebookArguments.get("fileToProcessStorageAccount"));
            Assert.assertEquals("in_container", notebookArguments.get("fileToProcessContainer"));
            Assert.assertEquals("out_dir", notebookArguments.get("outputDirectoryPath"));
            Assert.assertEquals("out_storage_account", notebookArguments.get("outputDirectoryStorageAccount"));
            Assert.assertEquals("out_container", notebookArguments.get("outputDirectoryContainer"));
        }
    }

    @Test
    public void shouldInvokeNotebookWhenNotebookTransformerOptionsAreCorrectlySpecifiedWithNoArguments() throws WorkflowException {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setTimeoutSeconds(0);
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == JsonMapper.class) {
                                   return new JsonMapper();
                               }
                               throw new RuntimeException();
                           }
               );

        ProcessedFile processedFile = new ProcessedFile("/processed/filepath", "storage_account", "container_name");
        List<ProcessedFile> processedFiles = Collections.singletonList(processedFile);
        JsonMapper jsonMapper = new JsonMapper();
        String processedFilesJson = jsonMapper.toJson(processedFiles);

        DBUtilsV1 mockedDBUtils = Mockito.mock(DBUtilsV1.class);
        NotebookUtils mockedNotebookUtils = Mockito.mock(NotebookUtils.class);

        Mockito.when(mockedDBUtils.notebook()).thenReturn(mockedNotebookUtils);
        Mockito.when(mockedNotebookUtils.run(Mockito.anyString(),
                                             Mockito.anyInt(),
                                             Mockito.any(scala.collection.Map.class),
                                             Mockito.anyString()))
               .thenReturn(processedFilesJson);

        try (MockedStatic<DBUtilsHolder> mockedDBUtilsHolder = Mockito.mockStatic(DBUtilsHolder.class)) {
            mockedDBUtilsHolder.when(DBUtilsHolder::dbutils).thenReturn(mockedDBUtils);

            String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
            NotebookTransformer notebookTransformer = new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
            FileToProcess fileToProcess = new FileToProcess();
            fileToProcess.setStorageAccountName("in_storage_account");
            fileToProcess.setFilepath("in_filepath");
            fileToProcess.setContainerName("in_container");
            OutputDirectory outputDirectory = new OutputDirectory();
            outputDirectory.setContainerName("out_container");
            outputDirectory.setDirectoryPath("out_dir");
            outputDirectory.setStorageAccountName("out_storage_account");

            List<ProcessedFile> processedFileList = notebookTransformer.transform(fileToProcess, outputDirectory).getProcessedFiles();

            ArgumentCaptor<scala.collection.Map<String, String>> notebookArgumentsCaptor = ArgumentCaptor.forClass(scala.collection.Map.class);

            Mockito.verify(mockedNotebookUtils).run(Mockito.eq("/Shared/notebook"),
                                                    Mockito.eq(0),
                                                    notebookArgumentsCaptor.capture(),
                                                    Mockito.eq("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}"));

            Assert.assertNotNull(processedFileList);
            Assert.assertEquals(1, processedFileList.size());
            ProcessedFile processedFileOutput = processedFileList.get(0);
            Assert.assertEquals("/processed/filepath", processedFileOutput.getFilepath());
            Assert.assertEquals("storage_account", processedFileOutput.getStorageAccountName());
            Assert.assertEquals("container_name", processedFileOutput.getContainerName());

            scala.collection.Map<String, String> scalaNotebookArguments = notebookArgumentsCaptor.getValue();
            Assert.assertNotNull(scalaNotebookArguments);
            Assert.assertFalse(scalaNotebookArguments.isEmpty());
            Map<String, String> notebookArguments = JavaConverters.mapAsJavaMap(scalaNotebookArguments);
            Assert.assertEquals("in_filepath", notebookArguments.get("fileToProcessFilepath"));
            Assert.assertEquals("in_storage_account", notebookArguments.get("fileToProcessStorageAccount"));
            Assert.assertEquals("in_container", notebookArguments.get("fileToProcessContainer"));
            Assert.assertEquals("out_dir", notebookArguments.get("outputDirectoryPath"));
            Assert.assertEquals("out_storage_account", notebookArguments.get("outputDirectoryStorageAccount"));
            Assert.assertEquals("out_container", notebookArguments.get("outputDirectoryContainer"));
        }
    }

    @Test
    public void shouldThrowExceptionWhenInvokedNotebookThrowsException() throws WorkflowException {
        NotebookTransformerOptions notebookTransformerOptions = new NotebookTransformerOptions();
        notebookTransformerOptions.setPath("/Shared/notebook");
        notebookTransformerOptions.setTimeoutSeconds(0);
        notebookTransformerOptions.setClusterSpec("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == JsonMapper.class) {
                                   return new JsonMapper();
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();

        DBUtilsV1 mockedDBUtils = Mockito.mock(DBUtilsV1.class);
        NotebookUtils mockedNotebookUtils = Mockito.mock(NotebookUtils.class);

        Mockito.when(mockedDBUtils.notebook()).thenReturn(mockedNotebookUtils);
        Mockito.when(mockedNotebookUtils.run(Mockito.anyString(),
                                             Mockito.anyInt(),
                                             Mockito.any(scala.collection.Map.class),
                                             Mockito.anyString()))
               .thenThrow(new WorkflowException(new RuntimeException("test exception")));

        try (MockedStatic<DBUtilsHolder> mockedDBUtilsHolder = Mockito.mockStatic(DBUtilsHolder.class)) {
            mockedDBUtilsHolder.when(DBUtilsHolder::dbutils).thenReturn(mockedDBUtils);

            String transformerOptionsJson = jsonMapper.toJson(notebookTransformerOptions);
            NotebookTransformer notebookTransformer = new NotebookTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
            FileToProcess fileToProcess = new FileToProcess();
            fileToProcess.setStorageAccountName("in_storage_account");
            fileToProcess.setFilepath("in_filepath");
            fileToProcess.setContainerName("in_container");
            OutputDirectory outputDirectory = new OutputDirectory();
            outputDirectory.setContainerName("out_container");
            outputDirectory.setDirectoryPath("out_dir");
            outputDirectory.setStorageAccountName("out_storage_account");

            try {
                notebookTransformer.transform(fileToProcess, outputDirectory);
                Assert.fail("should have thrown exception");
            } catch (NotebookTransformerException e) {
                Assert.assertNotNull(e);
                Assert.assertTrue(e.getCause() instanceof WorkflowException);
            }

            ArgumentCaptor<scala.collection.Map<String, String>> notebookArgumentsCaptor = ArgumentCaptor.forClass(scala.collection.Map.class);

            Mockito.verify(mockedNotebookUtils).run(Mockito.eq("/Shared/notebook"),
                                                    Mockito.eq(0),
                                                    notebookArgumentsCaptor.capture(),
                                                    Mockito.eq("{\"existing_cluster_id\": \"abcd-01234567-efghijkl\"}"));
        }
    }

}

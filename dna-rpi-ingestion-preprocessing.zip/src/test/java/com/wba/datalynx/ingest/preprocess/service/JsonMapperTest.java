package com.wba.datalynx.ingest.preprocess.service;

import com.wba.datalynx.ingest.preprocess.error.JsonParsingException;
import com.wba.datalynx.ingest.preprocess.error.JsonSerializerException;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class JsonMapperTest {

    @Test
    public void shouldMapObjectToJson() {
        Map<String, String> object = Collections.singletonMap("testKey", "testValue");
        JsonMapper jsonMapper = new JsonMapper();
        String json = jsonMapper.toJson(object);
        Assert.assertEquals("{\"testKey\":\"testValue\"}", json);
    }

    @Test(expected = JsonSerializerException.class)
    public void shouldThrowExceptionWhenMappingObjectToJsonAndObjectIsInvalid() {
        Object object = Mockito.mock(Object.class);
        JsonMapper jsonMapper = new JsonMapper();
        jsonMapper.toJson(object);
    }

    @Test
    public void shouldMapJsonToObject() {
        String json = "{\"testKey\":\"testValue\"}";
        JsonMapper jsonMapper = new JsonMapper();
        Map<?, ?> object = jsonMapper.fromJson(Map.class, json);
        Assert.assertEquals(Collections.singletonMap("testKey", "testValue"), object);
    }

    @Test(expected = JsonParsingException.class)
    public void shouldThrowExceptionWhenMappingJsonToObjectAndJsonIsInvalid() {
        String json = "invalidJson";
        JsonMapper jsonMapper = new JsonMapper();
        jsonMapper.fromJson(Map.class, json);
    }

    @Test
    public void shouldMapObjectToJsonAndBack() {
        Map<String, String> object = Collections.singletonMap("testKey", "testValue");
        JsonMapper jsonMapper = new JsonMapper();
        String json = jsonMapper.toJson(object);
        Object remappedObject = jsonMapper.fromJson(Map.class, json);
        Assert.assertEquals(object, remappedObject);
    }

    @Test
    public void shouldMapJsonCollectionToListOfObjectsAndBack() {
        Map<String, String> object = Collections.singletonMap("testKey", "testValue");
        List<Map<String, String>> list = Collections.singletonList(object);
        JsonMapper jsonMapper = new JsonMapper();
        String json = jsonMapper.toJson(list);
        Object remappedObject = jsonMapper.collectionFromJson(List.class, Map.class, json);
        Assert.assertEquals(list, remappedObject);
    }

    @Test(expected = JsonParsingException.class)
    public void shouldThrowExceptionWhenMappingJsonCollectionToListOfObjectsAndJsonIsInvalid() {
        String json = "invalidJson";
        JsonMapper jsonMapper = new JsonMapper();
        jsonMapper.collectionFromJson(List.class, Object.class, json);
    }

}

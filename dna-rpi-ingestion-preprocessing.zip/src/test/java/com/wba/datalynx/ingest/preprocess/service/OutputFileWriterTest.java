package com.wba.datalynx.ingest.preprocess.service;


import com.azure.storage.blob.BlobClient;
import com.wba.datalynx.ingest.preprocess.error.BlobUploadException;
import com.wba.datalynx.ingest.preprocess.model.OutputFile;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class OutputFileWriterTest {

    @Test
    public void shouldWriteStringToBlob() throws IOException {
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);
        JsonMapper jsonMapper = Mockito.mock(JsonMapper.class);
        OutputFileWriter outputFileWriter = new OutputFileWriter(blobClientProvider, jsonMapper);

        String filepath = "testFilepath";
        String containerName = "testContainerName";
        String storageAccountName = "testStorageAccountName";
        OutputFile outputFile = new OutputFile();
        outputFile.setFilepath(filepath);
        outputFile.setContainerName(containerName);
        outputFile.setStorageAccountName(storageAccountName);

        String stringToWrite = "testStringToWrite";

        outputFileWriter.writeString(stringToWrite, outputFile);

        Mockito.verify(blobClientProvider).getBlobClient(storageAccountName, containerName, filepath);

        ArgumentCaptor<InputStream> dataArgumentCaptor = ArgumentCaptor.forClass(InputStream.class);
        Mockito.verify(blobClient).upload(dataArgumentCaptor.capture());
        Assert.assertEquals(stringToWrite, IOUtils.toString(dataArgumentCaptor.getValue(), StandardCharsets.UTF_8));
    }

    @Test
    public void shouldWriteObjectAsJsonToBlob() throws IOException {
        String json = "testJson";
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);
        JsonMapper jsonMapper = Mockito.mock(JsonMapper.class);
        Mockito.when(jsonMapper.toJson(Mockito.any())).thenReturn(json);
        OutputFileWriter outputFileWriter = new OutputFileWriter(blobClientProvider, jsonMapper);

        String filepath = "testFilepath";
        String containerName = "testContainerName";
        String storageAccountName = "testStorageAccountName";
        OutputFile outputFile = new OutputFile();
        outputFile.setFilepath(filepath);
        outputFile.setContainerName(containerName);
        outputFile.setStorageAccountName(storageAccountName);

        outputFileWriter.writeAsJson(new Object(), outputFile);

        Mockito.verify(blobClientProvider).getBlobClient(storageAccountName, containerName, filepath);

        ArgumentCaptor<InputStream> dataArgumentCaptor = ArgumentCaptor.forClass(InputStream.class);
        Mockito.verify(blobClient).upload(dataArgumentCaptor.capture());
        Assert.assertEquals(json, IOUtils.toString(dataArgumentCaptor.getValue(), StandardCharsets.UTF_8));
    }

    @Test(expected = BlobUploadException.class)
    public void shouldThrowExceptionWhenWritingStringToBlobAndBlobClientThrowsException() {
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        BDDMockito.willAnswer(i -> {
            throw new IOException();
        }).given(blobClient).upload(Mockito.any(InputStream.class));
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);
        JsonMapper jsonMapper = Mockito.mock(JsonMapper.class);
        OutputFileWriter outputFileWriter = new OutputFileWriter(blobClientProvider, jsonMapper);

        String filepath = "testFilepath";
        String containerName = "testContainerName";
        String storageAccountName = "testStorageAccountName";
        OutputFile outputFile = new OutputFile();
        outputFile.setFilepath(filepath);
        outputFile.setContainerName(containerName);
        outputFile.setStorageAccountName(storageAccountName);

        String stringToWrite = "testStringToWrite";
        outputFileWriter.writeString(stringToWrite, outputFile);
    }


}

package com.wba.datalynx.ingest.preprocess.service;


import com.azure.core.credential.TokenCredential;
import com.azure.storage.blob.BlobClient;
import com.wba.datalynx.ingest.preprocess.error.StorageAccountCredentialNotConfiguredException;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

public class BlobClientProviderTest {

    @Test
    public void shouldGetBlobClient() {
        AzureCredentialProvider azureCredentialProvider = Mockito.mock(AzureCredentialProvider.class);
        TokenCredential tokenCredential = Mockito.mock(TokenCredential.class);
        Mockito.when(azureCredentialProvider.getAzureCredentialForStorageAccount(Mockito.anyString())).thenReturn(tokenCredential);

        BlobClientProvider blobClientProvider = new BlobClientProvider(azureCredentialProvider);

        String storageAccountName = "testStorageAccountName";
        String containerName = "testContainerName";
        String filepath = "testFilepath";

        BlobClient blobClient = blobClientProvider.getBlobClient(storageAccountName, containerName, filepath);
        Assert.assertNotNull(blobClient);
        Assert.assertEquals(filepath, blobClient.getBlobName());
        Assert.assertEquals(containerName, blobClient.getContainerName());
        Assert.assertEquals(storageAccountName, blobClient.getAccountName());
    }

    @Test(expected = StorageAccountCredentialNotConfiguredException.class)
    public void shouldThrowExceptionWhenGetBlobClientWithMissingStorageAccountConfiguration() {
        String storageAccountName = "testStorageAccountName";
        String containerName = "testContainerName";
        String filepath = "testFilepath";

        AzureCredentialProvider azureCredentialProvider = Mockito.mock(AzureCredentialProvider.class);
        Mockito.when(azureCredentialProvider.getAzureCredentialForStorageAccount(Mockito.anyString()))
               .thenThrow(new StorageAccountCredentialNotConfiguredException("no credentials provided for Storage Account " + storageAccountName));

        BlobClientProvider blobClientProvider = new BlobClientProvider(azureCredentialProvider);
        blobClientProvider.getBlobClient(storageAccountName, containerName, filepath);
    }

}

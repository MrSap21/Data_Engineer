package com.wba.datalynx.ingest.preprocess.service;


import com.wba.datalynx.ingest.preprocess.error.TeeTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.FileToTrack;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.TeeTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.TransformResult;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.springframework.context.ApplicationContext;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeeTransformerTest {

    @Test(expected = TeeTransformerException.class)
    public void shouldThrowExceptionWhenCreatingTeeTransformerAndNoTeeTransformerOptionIsSpecified() {
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        new TeeTransformer(applicationContext, null);
    }

    @Test(expected = TeeTransformerException.class)
    public void shouldThrowExceptionWhenCreatingTeeTransformerAndNoTeeTransformationIsSpecified() {
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        Map<String, Object> transformerOptions = new HashMap<>();
        new TeeTransformer(applicationContext, transformerOptions);
    }

    @Test
    public void shouldCreateTeeTransformerWhenTeeTransformerOptionsAreCorrectlySpecified() {
        TeeTransformerOptions teeTransformerOptions = new TeeTransformerOptions();
        teeTransformerOptions.setInputFilepathRegex("(.*)");
        teeTransformerOptions.setOutputFilenameSubstitution("$1");
        teeTransformerOptions.setOutputContainerName("output-container-name");
        teeTransformerOptions.setOutputStorageAccountName("output-storage-account-name");
        teeTransformerOptions.setOutputDirectoryPath("output-directory-path");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(teeTransformerOptions);
        TeeTransformer teeTransformer = new TeeTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(teeTransformer);
    }

    @Test(expected = TeeTransformerException.class)
    public void shouldThrowExceptionWhenCreatingTeeTransformerAndNoInputFilepathRegexIsSpecified() {
        TeeTransformerOptions teeTransformerOptions = new TeeTransformerOptions();
        teeTransformerOptions.setOutputFilenameSubstitution("$1");
        teeTransformerOptions.setOutputContainerName("output-container-name");
        teeTransformerOptions.setOutputStorageAccountName("output-storage-account-name");
        teeTransformerOptions.setOutputDirectoryPath("output-directory-path");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(teeTransformerOptions);
        new TeeTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
    }

    @Test(expected = TeeTransformerException.class)
    public void shouldThrowExceptionWhenCreatingTeeTransformerAndNoOutputFilenameSubstitutionIsSpecified() {
        TeeTransformerOptions teeTransformerOptions = new TeeTransformerOptions();
        teeTransformerOptions.setInputFilepathRegex("(.*)");
        teeTransformerOptions.setOutputContainerName("output-container-name");
        teeTransformerOptions.setOutputStorageAccountName("output-storage-account-name");
        teeTransformerOptions.setOutputDirectoryPath("output-directory-path");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(teeTransformerOptions);
        new TeeTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
    }

    @Test
    public void shouldDuplicateInputWhenTeeTransformerOptionsAreCorrectlySpecified() throws IOException {
        TeeTransformerOptions teeTransformerOptions = new TeeTransformerOptions();
        teeTransformerOptions.setInputFilepathRegex("(.*)");
        teeTransformerOptions.setOutputFilenameSubstitution("$1");
        teeTransformerOptions.setOutputContainerName("output-container-name");
        teeTransformerOptions.setOutputStorageAccountName("output-storage-account-name");
        teeTransformerOptions.setOutputDirectoryPath("output-directory-path");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        String stringToCopy = "test\nto copy\nabc";
        mockFileToProcessReader(fileToProcessReader, stringToCopy);
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(teeTransformerOptions);
        TeeTransformer teeTransformer = new TeeTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(teeTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        TransformResult transformResult = teeTransformer.transform(fileToProcess, outputDirectory);
        List<ProcessedFile> processedFiles = transformResult.getProcessedFiles();
        Assert.assertNotNull(processedFiles);
        Assert.assertEquals(1, processedFiles.size());

        ProcessedFile processedFile = processedFiles.get(0);
        Assert.assertEquals(testContainerName, processedFile.getContainerName());
        Assert.assertEquals(Paths.get(testDirectoryPath, testFilepath), Paths.get(processedFile.getFilepath()));
        Assert.assertEquals(testStorageAccountName, processedFile.getStorageAccountName());

        List<FileToTrack> filesToTrack = transformResult.getFilesToTrack();
        Assert.assertNotNull(filesToTrack);
        Assert.assertEquals(1, filesToTrack.size());

        FileToTrack fileToTrack = filesToTrack.get(0);
        Assert.assertEquals("output-container-name", fileToTrack.getContainerName());
        Assert.assertEquals(Paths.get("output-directory-path", testFilepath), Paths.get(fileToTrack.getFilepath()));
        Assert.assertEquals("output-storage-account-name", fileToTrack.getStorageAccountName());

        ArgumentCaptor<InputStream> argument = ArgumentCaptor.forClass(InputStream.class);
        Mockito.verify(outputFileWriter, Mockito.times(2)).writeStream(argument.capture(), Mockito.any());
        Assert.assertEquals(stringToCopy, IOUtils.toString(argument.getAllValues().get(0), StandardCharsets.UTF_8));
        Assert.assertEquals(stringToCopy, IOUtils.toString(argument.getAllValues().get(1), StandardCharsets.UTF_8));
    }

    @Test
    public void shouldThrowExceptionWhenOutputFileWriterThrowsException() {
        TeeTransformerOptions teeTransformerOptions = new TeeTransformerOptions();
        teeTransformerOptions.setInputFilepathRegex("(.*)");
        teeTransformerOptions.setOutputFilenameSubstitution("$1");
        teeTransformerOptions.setOutputContainerName("output-container-name");
        teeTransformerOptions.setOutputStorageAccountName("output-storage-account-name");
        teeTransformerOptions.setOutputDirectoryPath("output-directory-path");
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);

        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        String stringToCopy = "test\nto copy\nabc";
        mockFileToProcessReader(fileToProcessReader, stringToCopy);
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        BDDMockito.doAnswer(invocation -> {
            throw new IOException("test exception");
        }).when(outputFileWriter).writeStream(Mockito.any(), Mockito.any());

        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(teeTransformerOptions);
        TeeTransformer teeTransformer = new TeeTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(teeTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        try {
            teeTransformer.transform(fileToProcess, outputDirectory);
            Assert.fail("should have thrown exception");
        } catch (TeeTransformerException e) {
            Assert.assertNotNull(e);
            Assert.assertTrue(e.getCause() instanceof IOException);
        }
    }

    private static void mockFileToProcessReader(FileToProcessReader fileToProcessReader, String toReturn) {
        Mockito.when(fileToProcessReader.readToString(Mockito.any())).thenReturn(toReturn);
        Mockito.when(fileToProcessReader.readToStream(Mockito.any())).thenAnswer((Answer<InputStream>) invocationOnMock -> IOUtils.toInputStream(toReturn, StandardCharsets.UTF_8));
    }

}

package com.wba.datalynx.ingest.preprocess.service;


import com.azure.core.credential.TokenCredential;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.implementation.IdentityClient;
import com.wba.datalynx.ingest.preprocess.error.StorageAccountCredentialNotConfiguredException;
import com.wba.datalynx.ingest.preprocess.model.ServicePrincipalCredential;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

public class AzureCredentialProviderTest {

    @Test
    public void shouldGetAzureCredentialForStorageAccountWhenStorageAccountIsAdded() {
        AzureCredentialProvider azureCredentialProvider = new AzureCredentialProvider();

        SecretRetriever secretRetriever = Mockito.mock(SecretRetriever.class);
        Mockito.when(secretRetriever.getSecret(Mockito.anyString())).thenAnswer(i -> "secret-" + i.getArguments()[0]);

        ServicePrincipalCredential servicePrincipalCredential = new ServicePrincipalCredential();
        servicePrincipalCredential.setClientSecret("testClientSecret");
        servicePrincipalCredential.setClientId("testClientId");
        servicePrincipalCredential.setTenantId("testTenantId");

        String storageAccountName = "testStorageAccountName";
        azureCredentialProvider.addAzureCredentialForStorageAccount(secretRetriever, storageAccountName, servicePrincipalCredential);

        TokenCredential azureCredentialForStorageAccount = azureCredentialProvider.getAzureCredentialForStorageAccount(storageAccountName);
        Assert.assertNotNull(azureCredentialForStorageAccount);
    }

    @Test(expected = StorageAccountCredentialNotConfiguredException.class)
    public void shouldThrowExceptionWhenGettingAzureCredentialForStorageAccountAndStorageAccountIsNotAdded() {
        AzureCredentialProvider azureCredentialProvider = new AzureCredentialProvider();
        String storageAccountName = "testStorageAccountName";
        azureCredentialProvider.getAzureCredentialForStorageAccount(storageAccountName);
    }

    @Test
    public void shouldGetCorrectAzureCredentialForStorageAccountWhenMultipleStorageAccountsAreAdded() throws NoSuchFieldException, IllegalAccessException {
        AzureCredentialProvider azureCredentialProvider = new AzureCredentialProvider();

        SecretRetriever secretRetriever = Mockito.mock(SecretRetriever.class);
        Mockito.when(secretRetriever.getSecret(Mockito.anyString())).thenAnswer(i -> "secret-" + i.getArguments()[0]);

        ServicePrincipalCredential servicePrincipalCredential = new ServicePrincipalCredential();
        servicePrincipalCredential.setClientSecret("testClientSecret");
        servicePrincipalCredential.setClientId("testClientId");
        servicePrincipalCredential.setTenantId("testTenantId");

        String storageAccountName = "testStorageAccountName";
        azureCredentialProvider.addAzureCredentialForStorageAccount(secretRetriever, storageAccountName, servicePrincipalCredential);


        ServicePrincipalCredential servicePrincipalCredential2 = new ServicePrincipalCredential();
        servicePrincipalCredential2.setClientSecret("testClientSecret2");
        servicePrincipalCredential2.setClientId("testClientId2");
        servicePrincipalCredential2.setTenantId("testTenantId2");

        String storageAccountName2 = "testStorageAccountName2";
        azureCredentialProvider.addAzureCredentialForStorageAccount(secretRetriever, storageAccountName2, servicePrincipalCredential2);


        TokenCredential azureCredentialForStorageAccount = azureCredentialProvider.getAzureCredentialForStorageAccount(storageAccountName);
        Assert.assertNotNull(azureCredentialForStorageAccount);
        Assert.assertTrue(azureCredentialForStorageAccount instanceof ClientSecretCredential);

        ClientSecretCredential clientSecretCredential = (ClientSecretCredential) azureCredentialForStorageAccount;
        Field identityClientField = clientSecretCredential.getClass().getDeclaredField("identityClient");
        identityClientField.setAccessible(true);
        IdentityClient identityClient = (IdentityClient) identityClientField.get(clientSecretCredential);
        Assert.assertEquals(secretRetriever.getSecret("testClientId"), identityClient.getClientId());
        Assert.assertEquals(secretRetriever.getSecret("testTenantId"), identityClient.getTenantId());

        Field clientSecretField = identityClient.getClass().getDeclaredField("clientSecret");
        clientSecretField.setAccessible(true);
        String identityClientClientSecret = (String) clientSecretField.get(identityClient);
        Assert.assertEquals(secretRetriever.getSecret("testClientSecret"), identityClientClientSecret);
    }

}

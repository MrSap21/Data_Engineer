package com.wba.datalynx.ingest.preprocess.service;


import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

public class SparkSessionProviderTest {

    @Test
    public void shouldGetSparkSession() {
        SparkSessionProvider sparkSessionProvider = new SparkSessionProvider();
        SparkSession.Builder sparkSessionBuilder = Mockito.mock(SparkSession.Builder.class);
        SparkSession mockedSparkSession = Mockito.mock(SparkSession.class);
        Mockito.when(sparkSessionBuilder.getOrCreate()).thenReturn(mockedSparkSession);
        try (MockedStatic<SparkSession> mockedStaticSparkSession = Mockito.mockStatic(SparkSession.class)) {
            mockedStaticSparkSession.when(SparkSession::builder).thenReturn(sparkSessionBuilder);
            SparkSession sparkSession = sparkSessionProvider.getSparkSession();
            Assert.assertEquals(mockedSparkSession, sparkSession);
        }
    }

    @Test
    public void shouldGetSparkContext() {
        SparkSessionProvider sparkSessionProvider = new SparkSessionProvider();
        SparkSession.Builder sparkSessionBuilder = Mockito.mock(SparkSession.Builder.class);
        SparkSession mockedSparkSession = Mockito.mock(SparkSession.class);
        SparkContext mockedSparkContext = Mockito.mock(SparkContext.class);
        Mockito.when(mockedSparkSession.sparkContext()).thenReturn(mockedSparkContext);
        Mockito.when(sparkSessionBuilder.getOrCreate()).thenReturn(mockedSparkSession);
        try (MockedStatic<SparkSession> mockedStaticSparkSession = Mockito.mockStatic(SparkSession.class)) {
            mockedStaticSparkSession.when(SparkSession::builder).thenReturn(sparkSessionBuilder);
            SparkContext sparkContext = sparkSessionProvider.getSparkContext();
            Assert.assertEquals(mockedSparkContext, sparkContext);
        }
    }

}

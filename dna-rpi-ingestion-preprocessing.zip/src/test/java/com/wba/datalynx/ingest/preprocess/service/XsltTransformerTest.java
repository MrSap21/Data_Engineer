package com.wba.datalynx.ingest.preprocess.service;


import com.wba.datalynx.ingest.preprocess.error.XsltTransformerException;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import com.wba.datalynx.ingest.preprocess.model.MultipleXsltTransformerOptions;
import com.wba.datalynx.ingest.preprocess.model.OutputDirectory;
import com.wba.datalynx.ingest.preprocess.model.ProcessedFile;
import com.wba.datalynx.ingest.preprocess.model.XsltTransformerOptions;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.ApplicationContext;

import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class XsltTransformerTest {

    @Test(expected = XsltTransformerException.class)
    public void shouldThrowExceptionWhenCreatingXsltTransformerAndNoXSLTTransformerOptionIsSpecified() {
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        new XsltTransformer(applicationContext, null);
    }

    @Test(expected = XsltTransformerException.class)
    public void shouldThrowExceptionWhenCreatingXsltTransformerAndNoXSLTTransformationIsSpecified() {
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        Map<String, Object> transformerOptions = new HashMap<>();
        new XsltTransformer(applicationContext, transformerOptions);
    }

    @Test
    public void shouldCreateXsltTransformerWhenXSLTTransformerOptionsAreCorrectlySpecified() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("testRegex");
        xsltTransformerOptions.setStylesheet("testStylesheet");
        xsltTransformerOptions.setOutputFilenameSubstitution("testOutputFilenameSubstitution");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);
    }

    @Test
    public void shouldTransformXML() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("(.*)");
        xsltTransformerOptions.setStylesheet("<?xml version=\"1.0\" encoding=\"UTF-8\"?><xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"2.0\"><xsl:output method=\"text\" /><xsl:template match=\"/\">Article -<xsl:value-of select=\"/Article/Title\" />Authors:<xsl:apply-templates select=\"/Article/Authors/Author\" /></xsl:template><xsl:template match=\"Author\">-<xsl:value-of select=\".\" /></xsl:template></xsl:stylesheet>");
        xsltTransformerOptions.setOutputFilenameSubstitution("$1");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        mockFileToProcessReader(fileToProcessReader, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"example.xsl\"?><Article><Title>My Article</Title><Authors><Author>Mr. Foo</Author><Author>Mr. Bar</Author></Authors><Body>This is my article text.</Body></Article>");
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        List<ProcessedFile> processedFiles = xsltTransformer.transform(fileToProcess, outputDirectory).getProcessedFiles();
        Assert.assertNotNull(processedFiles);
        Assert.assertEquals(1, processedFiles.size());

        ProcessedFile processedFile = processedFiles.get(0);
        Assert.assertEquals(testContainerName, processedFile.getContainerName());
        Assert.assertEquals(Paths.get(testDirectoryPath, testFilepath), Paths.get(processedFile.getFilepath()));
        Assert.assertEquals(testStorageAccountName, processedFile.getStorageAccountName());

        Mockito.verify(outputFileWriter).writeString(Mockito.eq("Article -My ArticleAuthors:-Mr. Foo-Mr. Bar"), Mockito.any());
    }

    @Test
    public void shouldTransformJSONRootArray() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("(.*)");
        xsltTransformerOptions.setInputParameterName("jsonText");
        xsltTransformerOptions.setStylesheet("<xsl:stylesheet xmlns:array=\"http://www.w3.org/2005/xpath-functions/array\" xmlns:map=\"http://www.w3.org/2005/xpath-functions/map\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" exclude-result-prefixes=\"#all\" version=\"3.0\">\n" +
                                                     "   <xsl:param name=\"jsonText\" />\n" +
                                                     "   <xsl:variable name=\"json-xml\" select=\"json-to-xml($jsonText)\"/>\n" +
                                                     "   <xsl:output method=\"text\"/>\n" +
                                                     "   <xsl:template match=\"/\" name=\"xsl:initial-template\">\n" +
                                                     "      <xsl:value-of select=\"$json-xml/*/*!string-join(*, ',')\" separator=\"&#10;\"/>\n" +
                                                     "   </xsl:template>\n" +
                                                     "</xsl:stylesheet>");
        xsltTransformerOptions.setOutputFilenameSubstitution("$1");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        mockFileToProcessReader(fileToProcessReader, "[\n" +
                "    {\n" +
                "        \"id\": \"1\",\n" +
                "        \"name\": \"manu\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": \"2\",\n" +
                "        \"name\": \"vivek\"\n" +
                "    }\n" +
                "]");
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        List<ProcessedFile> processedFiles = xsltTransformer.transform(fileToProcess, outputDirectory).getProcessedFiles();
        Assert.assertNotNull(processedFiles);
        Assert.assertEquals(1, processedFiles.size());

        ProcessedFile processedFile = processedFiles.get(0);
        Assert.assertEquals(testContainerName, processedFile.getContainerName());
        Assert.assertEquals(Paths.get(testDirectoryPath, testFilepath), Paths.get(processedFile.getFilepath()));
        Assert.assertEquals(testStorageAccountName, processedFile.getStorageAccountName());

        Mockito.verify(outputFileWriter).writeString(Mockito.eq("1,manu\n2,vivek"), Mockito.any());
    }

    @Test
    public void shouldTransformJSONNestedArray() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("(.*)");
        xsltTransformerOptions.setInputParameterName("jsonText");
        xsltTransformerOptions.setStylesheet("<xsl:stylesheet xmlns:array=\"http://www.w3.org/2005/xpath-functions/array\" xmlns:map=\"http://www.w3.org/2005/xpath-functions/map\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" xmlns:custom=\"custom://namespace\" exclude-result-prefixes=\"#all\" version=\"3.0\">\n" +
                                                     "   <xsl:param name=\"jsonText\" />\n" +
                                                     "   <xsl:variable name=\"json-xml\" select=\"json-to-xml($jsonText)\"/>\n" + "   <xsl:output method=\"text\" />\n" +
                                                     "   <xsl:variable name=\"separator\" select=\"','\" />\n" +
                                                     "   <xsl:variable name=\"newline\" select=\"'&#xA;'\" />\n" +
                                                     "   <xsl:template match=\"/\" name=\"xsl:initial-template\">\n" +
                                                     "      <xsl:text>id,name</xsl:text>\n" +
                                                     "      <xsl:value-of select=\"$newline\" />\n" +
                                                     "      <xsl:for-each select=\"$json-xml/*[name()='map']/*[name()='array' and @key='values']\">\n" +
                                                     "        <xsl:for-each select=\"*[name()='map']\">\n" +
                                                     "            <xsl:value-of select=\"*[name()='string' and @key='id']\" />\n" +
                                                     "            <xsl:value-of select=\"$separator\" />\n" +
                                                     "            <xsl:value-of select=\"*[name()='string' and @key='name']\" />\n" +
                                                     "            <xsl:value-of select=\"$newline\" />\n" +
                                                     "        </xsl:for-each>\n" +
                                                     "     </xsl:for-each>\n" +
                                                     "   </xsl:template>\n" +
                                                     "</xsl:stylesheet>");
        xsltTransformerOptions.setOutputFilenameSubstitution("$1");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        mockFileToProcessReader(fileToProcessReader, "{\n" +
                "    \"aKey\":\"aValue\",\n" +
                "    \"values\":[\n" +
                "        {\n" +
                "            \"id\":\"1\",\n" +
                "            \"name\":\"manu\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\":\"2\",\n" +
                "            \"name\":\"vivek\"\n" +
                "        }\n" +
                "    ]\n" +
                "}");
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        List<ProcessedFile> processedFiles = xsltTransformer.transform(fileToProcess, outputDirectory).getProcessedFiles();
        Assert.assertNotNull(processedFiles);
        Assert.assertEquals(1, processedFiles.size());

        ProcessedFile processedFile = processedFiles.get(0);
        Assert.assertEquals(testContainerName, processedFile.getContainerName());
        Assert.assertEquals(Paths.get(testDirectoryPath, testFilepath), Paths.get(processedFile.getFilepath()));
        Assert.assertEquals(testStorageAccountName, processedFile.getStorageAccountName());

        Mockito.verify(outputFileWriter).writeString(Mockito.eq("id,name\n1,manu\n2,vivek\n"), Mockito.any());
    }

    @Test
    public void shouldTransformJSONNoOp() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("(.*)");
        xsltTransformerOptions.setInputParameterName("jsonText");
        xsltTransformerOptions.setStylesheet("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                                                     "<xsl:stylesheet version=\"1.0\"\n" +
                                                     "xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">\n" +
                                                     "<xsl:output method=\"text\"/>\n" +
                                                     "<xsl:param name=\"jsonText\" />\n" +
                                                     "<xsl:template match=\"/\" name=\"xsl:initial-template\">\n" +
                                                     "  <xsl:copy-of select=\"$jsonText\" />" +
                                                     "</xsl:template>\n" +
                                                     " </xsl:stylesheet>");
        xsltTransformerOptions.setOutputFilenameSubstitution("$1");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        mockFileToProcessReader(fileToProcessReader, "[\n" +
                "    {\n" +
                "        \"id\": \"1\",\n" +
                "        \"name\": \"manu\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": \"2\",\n" +
                "        \"name\": \"vivek\"\n" +
                "    }\n" +
                "]");
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        List<ProcessedFile> processedFiles = xsltTransformer.transform(fileToProcess, outputDirectory).getProcessedFiles();
        Assert.assertNotNull(processedFiles);
        Assert.assertEquals(1, processedFiles.size());

        ProcessedFile processedFile = processedFiles.get(0);
        Assert.assertEquals(testContainerName, processedFile.getContainerName());
        Assert.assertEquals(Paths.get(testDirectoryPath, testFilepath), Paths.get(processedFile.getFilepath()));
        Assert.assertEquals(testStorageAccountName, processedFile.getStorageAccountName());

        Mockito.verify(outputFileWriter).writeString(Mockito.eq("[\n" +
                                                                        "    {\n" +
                                                                        "        \"id\": \"1\",\n" +
                                                                        "        \"name\": \"manu\"\n" +
                                                                        "    },\n" +
                                                                        "    {\n" +
                                                                        "        \"id\": \"2\",\n" +
                                                                        "        \"name\": \"vivek\"\n" +
                                                                        "    }\n" +
                                                                        "]"), Mockito.any());
    }

    @Test(expected = XsltTransformerException.class)
    public void shouldThrowExceptionWhenTransformingXMLAndStylesheetIsInvalid() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("(.*)");
        xsltTransformerOptions.setStylesheet("invalidStylesheet");
        xsltTransformerOptions.setOutputFilenameSubstitution("$1");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        mockFileToProcessReader(fileToProcessReader, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"example.xsl\"?><Article><Title>My Article</Title><Authors><Author>Mr. Foo</Author><Author>Mr. Bar</Author></Authors><Body>This is my article text.</Body></Article>");
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        xsltTransformer.transform(fileToProcess, outputDirectory);
    }

    @Test(expected = XsltTransformerException.class)
    public void shouldThrowExceptionWhenTransformingXMLAndXMLIsInvalid() {
        MultipleXsltTransformerOptions multipleXsltTransformerOptions = new MultipleXsltTransformerOptions();
        XsltTransformerOptions xsltTransformerOptions = new XsltTransformerOptions();
        xsltTransformerOptions.setInputFilepathRegex("(.*)");
        xsltTransformerOptions.setStylesheet("<?xml version=\"1.0\" encoding=\"UTF-8\"?><xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"2.0\"><xsl:output method=\"text\" /><xsl:template match=\"/\">Article -<xsl:value-of select=\"/Article/Title\" />Authors:<xsl:apply-templates select=\"/Article/Authors/Author\" /></xsl:template><xsl:template match=\"Author\">-<xsl:value-of select=\".\" /></xsl:template></xsl:stylesheet>");
        xsltTransformerOptions.setOutputFilenameSubstitution("$1");
        multipleXsltTransformerOptions.setTransformations(Collections.singletonList(xsltTransformerOptions));
        ApplicationContext applicationContext = Mockito.mock(ApplicationContext.class);
        FileToProcessReader fileToProcessReader = Mockito.mock(FileToProcessReader.class);
        mockFileToProcessReader(fileToProcessReader, "invalidXml");
        OutputFileWriter outputFileWriter = Mockito.mock(OutputFileWriter.class);
        Mockito.when(applicationContext.getBean(Mockito.any(Class.class)))
               .thenAnswer(i -> {
                               Object argument = i.getArguments()[0];
                               if (argument == FileToProcessReader.class) {
                                   return fileToProcessReader;
                               } else if (argument == OutputFileWriter.class) {
                                   return outputFileWriter;
                               }
                               throw new RuntimeException();
                           }
               );

        JsonMapper jsonMapper = new JsonMapper();
        String transformerOptionsJson = jsonMapper.toJson(multipleXsltTransformerOptions);
        XsltTransformer xsltTransformer = new XsltTransformer(applicationContext, jsonMapper.fromJson(Map.class, transformerOptionsJson));
        Assert.assertNotNull(xsltTransformer);

        String testFilepath = "testFilepath";
        String testContainerName = "testContainerName";
        String testStorageAccountName = "testStorageAccountName";
        String testDirectoryPath = "testDirectoryPath";
        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setFilepath(testFilepath);
        fileToProcess.setContainerName(testContainerName);
        fileToProcess.setStorageAccountName(testStorageAccountName);

        OutputDirectory outputDirectory = new OutputDirectory();
        outputDirectory.setDirectoryPath(testDirectoryPath);
        outputDirectory.setContainerName(testContainerName);
        outputDirectory.setStorageAccountName(testStorageAccountName);

        xsltTransformer.transform(fileToProcess, outputDirectory);
    }

    private static void mockFileToProcessReader(FileToProcessReader fileToProcessReader, String toReturn) {
        Mockito.when(fileToProcessReader.readToString(Mockito.any())).thenReturn(toReturn);
        Mockito.when(fileToProcessReader.readToStream(Mockito.any())).thenReturn(IOUtils.toInputStream(toReturn, StandardCharsets.UTF_8));
    }

}

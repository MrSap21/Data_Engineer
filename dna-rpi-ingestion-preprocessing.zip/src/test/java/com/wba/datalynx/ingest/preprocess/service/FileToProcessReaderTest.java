package com.wba.datalynx.ingest.preprocess.service;

import com.azure.core.util.BinaryData;
import com.azure.storage.blob.BlobClient;
import com.wba.datalynx.ingest.preprocess.model.FileToProcess;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class FileToProcessReaderTest {

    @Test
    public void shouldReadBlobAsString() {
        String blobContent = "testBlobContent";

        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        Mockito.when(blobClient.downloadContent()).thenReturn(BinaryData.fromString(blobContent));
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);

        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setStorageAccountName("testStorageAccountName");
        fileToProcess.setFilepath("testFilepath");
        fileToProcess.setContainerName("testContainerName");

        FileToProcessReader fileToProcessReader = new FileToProcessReader(blobClientProvider);
        Assert.assertEquals(blobContent, fileToProcessReader.readToString(fileToProcess));
    }

    @Test(expected = RuntimeException.class)
    public void shouldThrowExceptionWhenReadingBlobAsStringAndBlobClientThrowsException() {
        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        Mockito.when(blobClient.downloadContent()).thenThrow(new RuntimeException());
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);

        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setStorageAccountName("testStorageAccountName");
        fileToProcess.setFilepath("testFilepath");
        fileToProcess.setContainerName("testContainerName");

        FileToProcessReader fileToProcessReader = new FileToProcessReader(blobClientProvider);
        fileToProcessReader.readToString(fileToProcess);
    }

    @Test
    public void shouldReadBlobAsStream() throws IOException {
        String blobContent = "testBlobContent";

        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        Mockito.when(blobClient.downloadContent()).thenReturn(BinaryData.fromString(blobContent));
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);

        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setStorageAccountName("testStorageAccountName");
        fileToProcess.setFilepath("testFilepath");
        fileToProcess.setContainerName("testContainerName");

        FileToProcessReader fileToProcessReader = new FileToProcessReader(blobClientProvider);
        Assert.assertEquals(blobContent, IOUtils.toString(fileToProcessReader.readToStream(fileToProcess), StandardCharsets.UTF_8));
    }

    @Test(expected = RuntimeException.class)
    public void shouldThrowExceptionWhenReadingBlobAsStreamAndBlobClientThrowsException() {
        BlobClientProvider blobClientProvider = Mockito.mock(BlobClientProvider.class);
        BlobClient blobClient = Mockito.mock(BlobClient.class);
        Mockito.when(blobClient.downloadContent()).thenThrow(new RuntimeException());
        Mockito.when(blobClientProvider.getBlobClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
               .thenReturn(blobClient);

        FileToProcess fileToProcess = new FileToProcess();
        fileToProcess.setStorageAccountName("testStorageAccountName");
        fileToProcess.setFilepath("testFilepath");
        fileToProcess.setContainerName("testContainerName");

        FileToProcessReader fileToProcessReader = new FileToProcessReader(blobClientProvider);
        fileToProcessReader.readToStream(fileToProcess);
    }

}

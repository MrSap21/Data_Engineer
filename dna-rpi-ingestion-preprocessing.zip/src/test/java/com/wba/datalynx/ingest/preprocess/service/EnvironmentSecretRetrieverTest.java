package com.wba.datalynx.ingest.preprocess.service;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

public class EnvironmentSecretRetrieverTest {

    @Test
    public void shouldGetSecretValueWhenSecretKeyIsPresentInEnvironment() throws Exception {
        String secretKey = "testSecretKey";
        String secretValue = "testSecretValue";
        getModifiableEnvironment().put(secretKey, secretValue);

        EnvironmentSecretRetriever environmentSecretRetriever = new EnvironmentSecretRetriever();
        Assert.assertEquals(secretValue, environmentSecretRetriever.getSecret(secretKey));
    }

    @Test
    public void shouldGetNullWhenSecretKeyIsMissingInEnvironment() throws Exception {
        String secretKey = "testSecretKey";
        getModifiableEnvironment().remove(secretKey);
        EnvironmentSecretRetriever environmentSecretRetriever = new EnvironmentSecretRetriever();
        Assert.assertNull(environmentSecretRetriever.getSecret(secretKey));
    }

    private static Map<String, String> getModifiableEnvironment() throws Exception {
        Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
        Optional<Field> theOptionalCaseInsensitiveEnvironment = Arrays.stream(processEnvironmentClass.getDeclaredFields()).filter(field -> StringUtils.equals("theCaseInsensitiveEnvironment", field.getName())).findFirst();

        if (theOptionalCaseInsensitiveEnvironment.isPresent()) {
            Field theCaseInsensitiveEnvironmentField = theOptionalCaseInsensitiveEnvironment.get();
            theCaseInsensitiveEnvironmentField.setAccessible(true);
            return (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
        } else {
            Class<?>[] collectionsDeclaredClasses = Collections.class.getDeclaredClasses();
            Map<String, String> systemEnv = System.getenv();
            for(Class<?> collectionsDeclaredClass : collectionsDeclaredClasses) {
                if(StringUtils.equals("java.util.Collections$UnmodifiableMap", collectionsDeclaredClass.getName())) {
                    Field field = collectionsDeclaredClass.getDeclaredField("m");
                    field.setAccessible(true);
                    Object obj = field.get(systemEnv);
                    return (Map<String, String>) obj;
                }
            }
        }

        return Collections.emptyMap();
    }

}
